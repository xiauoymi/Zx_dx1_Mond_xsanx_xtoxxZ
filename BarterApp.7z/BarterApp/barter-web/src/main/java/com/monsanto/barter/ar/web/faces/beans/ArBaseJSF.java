package com.monsanto.barter.ar.web.faces.beans;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.architecture.exception.DisconnectedUserException;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.WebApplicationContext;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.primefaces.context.RequestContext;

/**
 * AR-specific implementation of the BaseJSF
 * @author JPBENI
 */
public abstract class ArBaseJSF {

    protected static final String SUCCESS = "success";
    protected static final String ERROR = "error";
    protected static final String CANCEL = "cancel";
    protected static final String RESOURCE_BUNDLE = "com.monsanto.barter.ar.messageText";

    private static final Logger LOG = LoggerFactory.getLogger(ArBaseJSF.class);

    public static final String MONSANTO_CUIT = "30503508725";

    /**
     * Returns the context FaceContext.
     * Override it to customize its behaviour (for testing purposes).
     * @return the context FaceContext
     */
    protected FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    /**
     * Returns the context RequestContext.
     * Override it to customize its behaviour (for testing purposes).
     * @return the context RequestContext
     */
    protected RequestContext getRequestContext() {
        return RequestContext.getCurrentInstance();
    }

    /**
     * Returns the context BeanFactory.
     * Override it to customize its behaviour (for testing purposes).
     * @return the context BeanFactory
     */
    protected BeanFactory getBeanFactory() {
        ServletContext servletContext = (ServletContext)getFacesContext().getExternalContext().getContext();
        return (BeanFactory) servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
    }

    /**
     * @param throwable the Throwable to register
     */
    protected void addMessage(Throwable throwable) {
        this.addMessage(throwable.getMessage());
    }

    /**
     * @param message the message to register
     */
    protected void addMessage(String message) {
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, message , message));
    }

    /**
     * @param message the message to register
     */
    protected void addMessageNoError(String message) {
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, message , message));
    }

    protected void addMessage(String clientId, String message) {
        getFacesContext().addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, message , message));
    }

    /**
     * Returns a bean or a service instantiated by spring
     *
     * @param requiredType type the bean must match; can be an interface or superclass.
     * @return an instance of the single bean matching the required type
     */
    public <T> T getService(Class<T> requiredType) {
        return getBeanFactory().getBean(requiredType);
    }

    /**
     * Returns the {@link String}
     *
     * @param key {@link Locale}
     * @return {@link String}
     */
    //TODO: add a getMessageBundle(String, Object...) with String formatter support
    public String getMessageBundle( String key) {
        CountryHolder countryHolder = getService(CountryHolder.class);
        return ResourceBundle.getBundle(RESOURCE_BUNDLE, countryHolder.getCountry().getLocale()).getString(key);
    }

    public String getTimestampFormatted() {
        return new SimpleDateFormat("yyyy.MM.dd_HH.mm.ss").format(new Date());
    }

    protected HttpServletResponse getResponse() {
        return (HttpServletResponse) getFacesContext().getExternalContext().getResponse();
    }

    public <T> T getFacesBean(String beanId, Class<T> requiredType) {
        return getFacesContext().getApplication().evaluateExpressionGet(getFacesContext(),"#{"+ beanId +"}",requiredType);
    }

    public void addCallbackParam(String key, Object value) {
        RequestContext context = getRequestContext();
        if (context != null) {
            context.addCallbackParam(key, value);
        }
    }

    public TransactionTemplate getTransactionTemplate() {
        return getService(TransactionTemplate.class);
    }

    public String getApplicationProperty(String key) {
        try {
            String envSpecificProperty = EnvironmentHelper.getPropertyPrefix() + key;
            return ResourceBundle.getBundle("application").getString(envSpecificProperty) ;
        } catch (EnvironmentHelperException e) {
            throw new BusinessException("Error getting an application Property", e);
        }

    }

    public UserDecorator getLoggedUser() {
        try {
            return GlobalBarterSecurityHelper.getLoggedInUser();
        } catch(DisconnectedUserException ex) {
            throw new BusinessException("Error getting the logged uer:", ex);
        }
    }

    protected void logout() {
        try {
            getFacesContext().getExternalContext().invalidateSession();
            SecurityContextHolder.getContext().getAuthentication().setAuthenticated(false);
            getFacesContext().getExternalContext().redirect(GlobalBarterSecurityHelper.getLogoutUrl());
        } catch (IOException e) {
            LOG.error("An error occurred during logout: ", e);
        }
    }
}
