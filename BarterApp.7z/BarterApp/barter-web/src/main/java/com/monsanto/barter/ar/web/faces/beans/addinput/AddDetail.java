package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.lowagie.text.DocumentException;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.AddendaUnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.UnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.enumerated.AdendaState;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.AdendaService;
import com.monsanto.barter.ar.business.service.EmailService;
import com.monsanto.barter.ar.business.service.RemoteService;
import com.monsanto.barter.ar.business.service.UnsuccessfulRemoteInvocationService;
import com.monsanto.barter.ar.business.service.dto.RemoteServiceResponse;
import com.monsanto.barter.ar.web.faces.editView.EditViewBase;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.InitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.TransferSectionCC;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.event.AbortProcessingException;
import java.io.InputStream;

import static com.monsanto.barter.ar.web.faces.mode.Mode.UPDATE;
import static com.monsanto.barter.ar.web.faces.mode.Mode.VIEW;

/**
 * @author GIRIA
 */
public class AddDetail extends EditViewBase<Adenda> {
    private static final Logger LOG = LoggerFactory.getLogger(AddDetail.class);
    public static final DocumentType DOCUMENT_TYPE = DocumentType.ADD;
    private InitialDataSectionCC initialDataSectionCC;
    private TransferSectionCC transferSectionCC;
    private InputStream pdfStream;

    private AdendaService adendaService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private RemoteService remoteService;
    private EmailService emailService;

    @Override
    protected void setUpdateMode(Adenda add) {
        String idSap = add.getIdSap();
        if (idSap != null) {
            try {
                RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(getDocumentType(), idSap);
                if (serviceResponse.isOK()) {
                    setMode(UPDATE);
                } else {
                    addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + getMessageBundle(serviceResponse.getResponseMessage()));
                    setMode(VIEW);
                }
            } catch (Exception ex) {
                LOG.error("There was an error invoking SAP validation service: ", ex);
                addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + ex.getMessage());
                setMode(VIEW);
            }
        } else {
            setMode(UPDATE);
        }
    }

    public DocumentType getDocumentType() {
        return DOCUMENT_TYPE;
    }

    @Override
    protected void setViewMode(Adenda add) {
        setMode(VIEW);
    }

    @Override
    protected void init() {
        adendaService = getService(AdendaService.class);
        remoteService = getService(RemoteService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        emailService = getService(EmailService.class);
    }

    public String save() {
        LOG.debug("Begin save in AddDetailBean");
        AdendaState addState = getAdenda().getState();
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    boolean sentToSAP = getAdenda().isSentToSAP();
                    getAdenda().setSentToSAP();
                    adendaService.update(getAdenda());
                    unsuccessfulInvocationService.clearPendingInvocations(getAdenda());
                    if (sentToSAP) {
                        RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(getDocumentType(),
                                getAdenda().getIdSap());
                        if (!serviceResponse.isOK()) {
                            throw new BusinessException(serviceResponse.getResponseMessage());
                        }
                        remoteService.update(getAdenda());
                    } else {
                        remoteService.create(getAdenda());
                        adendaService.update(getAdenda());  //update it to persist the sap id
                    }
                }
            });
            getFacesBean("addSearchFormFacesBean", AddSearchFormFacesBean.class).search();
        } catch (RemoteServiceException ex) {
            LOG.error("An error occurred sending the Addenda to SAP: ", ex);
            getAdenda().setState(addState); //rollback the state changes
            addCallbackParam("remoteServicesError", true);
            getSapMessages().add(ex.getMessage());
            return null;
        } catch (BusinessException ex) {
            LOG.error("Failed save in AddDetailBean", ex);
            getAdenda().setState(addState); //rollback the state changes
            addMessage(getMessageBundle(ex.getMessage()));
            return null;
        }
        addMessageNoError("Se ha actualizado correctamente la adenda.");
        LOG.debug("Success save in AddDetailBean");
        return SUCCESS;
    }

    public String saveWithErrors() {
        LOG.debug("Begin save with errors in AddDetailBean");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    adendaService.update(getAdenda());
                    unsuccessfulInvocationService.clearPendingInvocations(getAdenda());
                    AddendaUnsuccessfulRemoteInvocation invocation = new AddendaUnsuccessfulRemoteInvocation();
                    invocation.setAdenda(getAdenda());
                    if (getAdenda().isSentToSAP()) {
                        invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.UPDATE);
                    } else {
                        invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.CREATE);
                    }
                    unsuccessfulInvocationService.save(invocation);
                }
            });
            emailService.sendRetryStartMessage(getAdenda().getIdSap(), getSapMessages(), getLoggedUser().getEmail());
            getFacesBean("addSearchFormFacesBean", AddSearchFormFacesBean.class).search();
        } catch (BusinessException ex) {
            addMessage(getMessageBundle(ex.getMessage()));
            LOG.error("Failed save with errors in AddDetailBean", ex);
            return null;
        }
        //TODO internationalize this
        addMessageNoError("Se ha actualizado correctamente la adenda.");
        LOG.debug("Success save with errors in AddDetailBean");
        return SUCCESS;
    }

    public void generatePdf() {
        LOG.debug("START pdf exportation of adenda id: {}", getIdEntity());
        try {
            pdfStream = adendaService.getPdf(getAdenda());
        } catch (DocumentException e) {
            addMessage(e);
            throw new AbortProcessingException(e);
        }
    }

    protected void createSections() {
        setInitialDataSectionCC(getService(InitialDataSectionCC.class));
        setTransferSectionCC(getService(TransferSectionCC.class));
        addSection(initialDataSectionCC);
        addSection(transferSectionCC);
        LOG.debug("End create sections AddDetailBean.");
    }

    @Override
    protected Adenda findEntity() {
        return adendaService.get(getIdEntity());
    }

    public StreamedContent getFile() {
        LOG.debug("START DOWNLOAD pdf named: ADD_{}.pdf", getAdenda().getId());
        return new DefaultStreamedContent(pdfStream, "application/pdf", "ADD_" + getAdenda().getId() + ".pdf");
    }

    public InitialDataSectionCC getInitialDataSectionCC() {
        return initialDataSectionCC;
    }

    public void setInitialDataSectionCC(InitialDataSectionCC initialDataSectionCC) {
        this.initialDataSectionCC = initialDataSectionCC;
    }

    public TransferSectionCC getTransferSectionCC() {
        return transferSectionCC;
    }

    public void setTransferSectionCC(TransferSectionCC transferSectionCC) {
        this.transferSectionCC = transferSectionCC;
    }

    public Adenda getAdenda() {
        return getEntity();
    }
}
