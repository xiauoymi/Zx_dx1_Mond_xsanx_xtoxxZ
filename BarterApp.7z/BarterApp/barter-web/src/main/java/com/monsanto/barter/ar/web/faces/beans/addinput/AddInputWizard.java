package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.AdendaState;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardFaces;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;
import com.monsanto.barter.ar.web.faces.wizard.WizardStep;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.InitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.TransferSectionCC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.*;

@SuppressWarnings("unchecked")
public class AddInputWizard extends AbstractWizardFaces {
    private static final Logger LOG = LoggerFactory.getLogger(AddInputWizard.class);

    private InitialDataSectionCC initialDataSectionCC;
    private TransferSectionCC transferSectionCC;

    private List<AbstractWizardStepCC> wizardSteps;
    private Map<String,AbstractWizardStepCC> wizardStepHashMap;

    private AdendaService adendaService;
    private RemoteService remoteService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private EmailService emailService;

    private Adenda addInput;
    private String uploadDocumentNumber;
    private DocumentsUploader<Adenda> documentsUploader;
    private BeanValidator beanValidator;

    public AddInputWizard() {
        init();
    }

    public final void init(){
        adendaService = getService(AdendaService.class);
        remoteService = getService(RemoteService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        emailService = getService(EmailService.class);
        beanValidator= getService(BeanValidator.class) ;
    }

    public String begin() {
        LOG.debug("Beginning wizard setup.");
        addInput = new Adenda();
        wizardStepHashMap = new HashMap<String, AbstractWizardStepCC>();
        wizardSteps = new ArrayList<AbstractWizardStepCC>();

        LOG.debug("Retrieving step beans.");
        setInitialDataSectionCC(getService(InitialDataSectionCC.class));
        setTransferSectionCC(getService(TransferSectionCC.class));

        LOG.debug("Adding step beans to wizard.");
        addWizardStep(initialDataSectionCC.initializeStepCC(0,"initialDataSectionCC", addInput, Mode.CREATE));
        addWizardStep(transferSectionCC.initializeStepCC(1,"transferSectionCC", addInput, Mode.CREATE));

        LOG.debug("Initializing first step bean.");
        initialDataSectionCC.begin();
        documentsUploader = new DocumentsUploader<Adenda>();
        return SUCCESS;
    }

    private void addWizardStep( AbstractWizardStepCC wizardStep ) {
        wizardSteps.add(wizardStep);
        wizardStepHashMap.put(wizardStep.getKey(),wizardStep);
    }

    @Override
    protected int getStepCount() {
        return wizardSteps.size();
    }

    @Override
    protected WizardStep getStep(int index) {
        return wizardSteps.get(index);
    }

    @Override
    protected WizardStep getStep(String step) {
        return wizardStepHashMap.get(step);
    }

    /**
     * Cancels and invalidates current (session scoped) wizard.
     */
    public String addInputWizardCancelAction()  {
        LOG.debug("about to cancel addInputWizard.");
        getFacesContext().getExternalContext().getSessionMap().put("addInputWizardFaces", getNewAddInputWizard());
        return CANCEL;
    }

    protected AddInputWizard getNewAddInputWizard() {
        AddInputWizard newBean = new AddInputWizard();
        newBean.begin();
        return newBean;
    }

    public String saveAddInput(){
        LOG.debug("About to save adenda");
        getSapMessages().clear();
        setUploadDocumentNumber("");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.addInput = tx.execute(new TransactionCallback<Adenda>() {
                @Override
                public Adenda doInTransaction(TransactionStatus status) {
                    addInput.setSentToSAP();
                    addInput = adendaService.save(addInput);
                    remoteService.create(addInput);
                    addInput = adendaService.update(addInput); //update it to persist the sap id
                    return addInput;
                }
            });
            setUploadDocumentNumber(addInput.getIdSap());
        } catch (RemoteServiceException e) {
            LOG.error("An error occurred sending the Addenda to SAP: ", e);
            addInput.setState(AdendaState.INGRESED);
            addCallbackParam("remoteServicesError", true);
            getSapMessages().add(e.getMessage());
            return "";
        } catch (BusinessException e) {
            LOG.error("An error occurred saving the Addenda: ", e);
            addInput.setState(AdendaState.INGRESED);
            addCallbackParam("isValid", false);
            addMessage(getMessageBundle(e.getMessage()));
            return "";
        }
        LOG.debug("Addenda saved with id {}", this.addInput.getId());
        addCallbackParam("isValid", true);
        documentsUploader.init((DocumentUploadService<Adenda>) adendaService, beanValidator, addInput);
        return "";
    }

    public String saveWithErrors(){
        LOG.debug("About to save adenda with errors");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.addInput = tx.execute(new TransactionCallback<Adenda>() {
                @Override
                public Adenda doInTransaction(TransactionStatus status) {
                    addInput = adendaService.save(addInput);
                    AddendaUnsuccessfulRemoteInvocation invocation = new AddendaUnsuccessfulRemoteInvocation();
                    invocation.setAdenda(addInput);
                    invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.CREATE);
                    unsuccessfulInvocationService.save(invocation);
                    return addInput;
                }
            });
            emailService.sendRetryStartMessage(addInput.getIdSap(), getSapMessages(), getLoggedUser().getEmail());
            documentsUploader.init((DocumentUploadService<Adenda>) adendaService, beanValidator, addInput);
        } catch (BusinessException e) {
            addMessage(getMessageBundle(e.getMessage()));
            LOG.error("An error occurred saving the Addenda: ", e);
            return "";
        }
        LOG.debug("Adenda saved with id {}", this.addInput.getId());
        return "";
    }

    public String attachFiles()  {
        if(!documentsUploader.isEmptyFiles()) {
            for (Attachment attachment : documentsUploader.getAttachments()) {
                addInput.addAttachment(attachment);
            }
            adendaService.update(addInput);
        }
        documentsUploader.leave();
        addInputWizardCancelAction();
        return SUCCESS;
    }

    public void cancelAttachFiles(){
        documentsUploader.leave();
    }

    public InitialDataSectionCC getInitialDataSectionCC() {
        return initialDataSectionCC;
    }

    public void setInitialDataSectionCC(InitialDataSectionCC initialDataSectionCC) {
        this.initialDataSectionCC = initialDataSectionCC;
    }

    public TransferSectionCC getTransferSectionCC() {
        return transferSectionCC;
    }

    public void setTransferSectionCC(TransferSectionCC transferSectionCC) {
        this.transferSectionCC = transferSectionCC;
    }

    public String getUploadDocumentNumber() {
        return uploadDocumentNumber;
    }

    public void setUploadDocumentNumber(final String uploadDocumentNumber) {
        this.uploadDocumentNumber = uploadDocumentNumber;
    }

    public DocumentsUploader<Adenda> getDocumentsUploader() {
        return documentsUploader;
    }

    public void setDocumentsUploader(DocumentsUploader<Adenda> documentsUploader) {
        this.documentsUploader = documentsUploader;
    }
}
