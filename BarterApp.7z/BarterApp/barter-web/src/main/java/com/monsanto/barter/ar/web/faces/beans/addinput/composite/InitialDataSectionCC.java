package com.monsanto.barter.ar.web.faces.beans.addinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.adenda.AddInitialData;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 1/7/14
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class InitialDataSectionCC extends AddInputBaseStep {

    protected static final String SENDER_KEY = "com.monsanto.barter.ar.business.entity.Adenda.sender";

    @Autowired
    private LocationCC emissionPlace;

    @Autowired
    private CustomerCC senderCC;

    private static final Logger LOG = LoggerFactory.getLogger(InitialDataSectionCC.class);

    @Override
    public void begin() {
        LOG.debug("Start begin Method.");
        if(getAddInput().getId() != null){
            setCustomerAndLocationFromAddInput();
        }
        loadParticipants();
        loadLocations();
        senderCC.setForceSelection(true);
    }

    private void setCustomerAndLocationFromAddInput(){
        senderCC.setCustomer(getAddInput().getSender());
        emissionPlace.setCity(getAddInput().getCity());
    }

    private void loadParticipants(){
        senderCC.getSelectedCustomer();
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(AddInitialData.class);
    }

    @Override
    public void setValuesFromComponents(){
        getAddInput().setSender(senderCC.getSelectedCustomer());
        getAddInput().setCity(emissionPlace.getCitySelected());
        getAddInput().setGenerationDate(getAddInput().getGenerationDate());
    }

    @Override
    public boolean validate() {
        boolean validCustomers = true;
        List<String> violationMessages = getValidator().validate(getAddInput().getSender(),SENDER_KEY);
        if (!violationMessages.isEmpty()) {
            addValidationMessages(violationMessages);
            validCustomers = false;
        }
        return super.validate() && validCustomers;
    }

    private void addValidationMessages(List<String> violationMessages) {
        for (String violationMessage : violationMessages){
            addMessage(violationMessage);
        }
    }

    private void loadLocations() {
        emissionPlace.getCitySelected();
    }

    public LocationCC getEmissionPlace() {
        return emissionPlace;
    }

    public void setEmissionPlace(LocationCC emissionPlace) {
        this.emissionPlace = emissionPlace;
    }

    public CustomerCC getSenderCC() {
        return senderCC;
    }

    public void setSenderCC(CustomerCC senderCC) {
        this.senderCC = senderCC;
    }
}
