package com.monsanto.barter.ar.web.faces.beans.addinput.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.constraints.groups.adenda.AddTransfer;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 1/7/14
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class TransferSectionCC extends AddInputBaseStep {

    private static final Logger LOG = LoggerFactory.getLogger(TransferSectionCC.class);
    protected static final String RECEPTOR_KEY = "com.monsanto.barter.ar.business.entity.Adenda.receptor";

    @Autowired
    private CustomerCC receptor;

    @Autowired
    private MaterialLasService materialLasService;

    private List<MaterialLas> materialLasList;

    private Long idMaterialLas;

    @Override
    public void begin() {
        loadCombo();
        setSelectedCropType();
        if (getAddInput() != null){
            setCustomerFromAddInput();
        }
        receptor.setForceSelection(true);
        loadParticipants();
    }

    private void setCustomerFromAddInput(){
        receptor.setCustomer(getAddInput().getReceptor());
    }

    private void loadParticipants(){
        receptor.getSelectedCustomer();
    }

    private void setSelectedCropType() {
        if (this.getAddInput().getCropType() != null && this.getAddInput().getCropType().getId() != null){
            setIdMaterialLas(getAddInput().getCropType().getId());
        } else if (idMaterialLas != null){
            MaterialLas materialLas = materialLasService.get(getIdMaterialLas());
            this.getAddInput().setCropType(materialLas);
        }
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(AddTransfer.class);
    }

    @Override
    public boolean validate() {
        boolean validCustomers = true;
        List<String> violationMessages = getValidator().validate(getAddInput().getReceptor(), RECEPTOR_KEY);
        if (!violationMessages.isEmpty()) {
            addValidationMessages(violationMessages);
            validCustomers = false;
        }
        return super.validate() && validCustomers;
    }

    private void addValidationMessages(List<String> violationMessages) {
        for (String violationMessage : violationMessages){
            addMessage(violationMessage);
        }
    }

    private void loadCombo() {
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred initializing WizardTransferSection: ", ex);
        }
    }

    private MaterialLas recoverCropType() {
        final Long id = getIdMaterialLas();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (MaterialLas) CollectionUtils.find(materialLasList, predicate);
        }
        return null;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {

            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }

    @Override
    public void setValuesFromComponents(){
        getAddInput().setReceptor(receptor.getSelectedCustomer());
        getAddInput().setCropType(recoverCropType());
    }

    public CustomerCC getReceptor() {
        return receptor;
    }

    public void setReceptor(CustomerCC receptor) {
        this.receptor = receptor;
    }

    public Long getIdMaterialLas() {
        return idMaterialLas;
    }

    public void setIdMaterialLas(Long idMaterialLas) {
        this.idMaterialLas = idMaterialLas;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public void setMaterialLasService(MaterialLasService materialLasService) {
        this.materialLasService = materialLasService;
    }
}
