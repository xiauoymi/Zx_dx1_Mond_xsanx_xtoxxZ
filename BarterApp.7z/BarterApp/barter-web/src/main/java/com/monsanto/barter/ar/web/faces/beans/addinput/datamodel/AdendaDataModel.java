package com.monsanto.barter.ar.web.faces.beans.addinput.datamodel;

import com.monsanto.barter.ar.business.service.AddFilter;
import com.monsanto.barter.ar.business.service.AdendaService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.AddView;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author LABAEZ
 */
public class AdendaDataModel extends LazyDataModel <AddView> {
    private AdendaService service;
    private AddFilter filter;

    private List<AddView> page = new ArrayList<AddView>(0);

    public AdendaDataModel(final AdendaService service, final AddFilter filter) {
        super();
        this.service = service;
        this.filter = filter;
    }

    @Override
    public List<AddView> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,String> filters) {
        Paging.SortOrder order;
        if (SortOrder.DESCENDING == sortOrder) {
            order = Paging.SortOrder.DESC;
        } else {
            order = Paging.SortOrder.ASC;
        }
        Recordset<AddView> results = service.search(filter, new Paging(first, pageSize, sortField, order));
        setRowCount((int) results.getRecordCount());
        page = results.getRecords();
        return page;
    }

    @Override
    public AddView getRowData(String rowKey) {
        return getRowData(Long.valueOf(rowKey));
    }

    public AddView getRowData(Long rowKey) {
        for (AddView row : page) {
            if (row.getId().equals(rowKey)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(AddView object) {
        return object.getId().toString();
    }
}
