package com.monsanto.barter.ar.web.faces.beans.addinput.datamodel;

import com.monsanto.barter.ar.business.service.AddReportFilter;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.ReportService;
import com.monsanto.barter.ar.business.service.dto.AddReportView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

/**
 * @author LABAEZ
 */
public class AdendaReportDataModel extends AbstractDataModel<AddReportView, AddReportFilter> {
    private final ReportService service;

    public AdendaReportDataModel(final ReportService service, final AddReportFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    protected Recordset<AddReportView> loadPage(AddReportFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public AddReportView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (AddReportView row : getPage()) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(AddReportView object) {
        return object.getId().toString();
    }
}
