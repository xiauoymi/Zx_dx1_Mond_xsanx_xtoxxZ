package com.monsanto.barter.ar.web.faces.beans.billoflading;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.BOLUnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.entity.BillOfLadingTrain;
import com.monsanto.barter.ar.business.entity.UnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingState;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.BillOfLadingService;
import com.monsanto.barter.ar.business.service.EmailService;
import com.monsanto.barter.ar.business.service.RemoteService;
import com.monsanto.barter.ar.business.service.UnsuccessfulRemoteInvocationService;
import com.monsanto.barter.ar.business.service.dto.RemoteServiceResponse;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.billoflading.composite.*;
import com.monsanto.barter.ar.web.faces.beans.growerdocuments.composite.GrowerDocumentsCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.event.AbortProcessingException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.monsanto.barter.ar.web.faces.mode.Mode.UPDATE;
import static com.monsanto.barter.ar.web.faces.mode.Mode.VIEW;

@SuppressWarnings("unchecked")
public class BillOfLadingDetail extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingDetail.class);
    public static final DocumentType DOCUMENT_TYPE = DocumentType.BILL_OF_LADING;

    private List<AbstractWizardStepCC> sections;
    private BasicDataSectionCC basicDataSectionCC;
    private ParticipantsSectionCC wizardParticipantStepCC;
    private GrainsTransportedSectionCC grainsTransportedSectionCC;
    private OriginDestinationSectionCC originDestinationSectionCC;
    private TransportSectionCC transportSectionCC;
    private DischargeSectionCC dischargeSectionCC;
    private AddressDischargeSectionCC addressDischargeSectionCC;
    private GrowerDocumentsCC growerDocumentsCC;

    private TrainWagonSectionCC trainWagonSectionCC;

    private BillOfLadingService billOfLadingService;
    private RemoteService remoteService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private EmailService emailService;

    private Mode mode;
    private BillOfLading billOfLading;

    private List<String> sapMessages = new ArrayList<String>();
    private InputStream pdfStream;
    private Long idBillOfLading;
    private UserDecorator user;
    private boolean fromGrower;

    private void createSections() {
        setBasicDataSectionCC(getService(BasicDataSectionCC.class));
        setWizardParticipantStepCC(getService(ParticipantsSectionCC.class));
        setOriginDestinationSectionCC(getService(OriginDestinationSectionCC.class));
        setTransportSectionCC(getService(TransportSectionCC.class));
        setDischargeSectionCC(getService(DischargeSectionCC.class));
        setGrainsTransportedSectionCC(getService(GrainsTransportedSectionCC.class));
        setAddressDischargeSectionCC(getService(AddressDischargeSectionCC.class));
        this.growerDocumentsCC = getService(GrowerDocumentsCC.class);
        if (billOfLading instanceof BillOfLadingTrain) {
            setTrainWagonSectionCC(getService(TrainWagonSectionCC.class));
            sections.add(trainWagonSectionCC);
        }
        sections.add(basicDataSectionCC);
        sections.add(wizardParticipantStepCC);
        sections.add(grainsTransportedSectionCC);
        sections.add(originDestinationSectionCC);
        sections.add(transportSectionCC);
        sections.add(dischargeSectionCC);
        sections.add(addressDischargeSectionCC);

        LOG.debug("End create sections BillOfLadingDetailBean.");
    }

    private void initSections() {
        LOG.debug("START initSections.");
        for (AbstractWizardStepCC section : sections) {
            section.initializeStepCC(1, "", billOfLading, getMode()).begin();
        }
        growerDocumentsCC.setDocumentId(billOfLading.getId());
        growerDocumentsCC.setDocumentType(DOCUMENT_TYPE);
        growerDocumentsCC.begin();
    }

    private void setValuesFromComponents() {
        LOG.debug("SETTING VALUES from ID: {}", getIdBillOfLading());
        for (AbstractWizardStepCC section : sections) {
            section.setValuesFromComponents();
        }
        String commercialSenderCuit = billOfLading.getCommercialSenderIdentifier();
        String mediatorCuit;
        if (billOfLading.getMediatorCommercialIdentifier() != null) {
            mediatorCuit = billOfLading.getMediatorCommercialIdentifier();
        } else {
            mediatorCuit = "";
        }
        String destinationCuit = billOfLading.getAddresseeIdentifier();
        if((commercialSenderCuit != null && commercialSenderCuit.equals(MONSANTO_CUIT))
                || (destinationCuit != null && destinationCuit.equals(MONSANTO_CUIT))) {
            billOfLading.setExporter(billOfLading.getAddressee());
            billOfLading.setExporterIdentifier(billOfLading.getAddresseeIdentifier());
        } else if(mediatorCuit.equals(MONSANTO_CUIT)) {
            billOfLading.setExporter(billOfLading.getCommercialSender());
            billOfLading.setExporterIdentifier(billOfLading.getCommercialSenderIdentifier());
        }
    }

    private void begin(Mode mode) {
        LOG.debug("Start begin Method of BillOfLadingDetailBean in mode: {}", mode.toString());
        user = GlobalBarterSecurityHelper.getLoggedInUser();
        billOfLadingService = getService(BillOfLadingService.class);
        remoteService = getService(RemoteService.class);
        emailService = getService(EmailService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        sections = new ArrayList<AbstractWizardStepCC>();
        billOfLading = loadBillOfLading();
        if (mode == UPDATE) {
            setUpdateMode(billOfLading);
        } else {
            setViewMode(billOfLading);
        }
        createSections();
        initSections();
        LOG.debug("End begin of BillOfLadingDetailBean in mode {}", getMode().toString());
    }

    protected void setUpdateMode(BillOfLading billOfLading) {
        if (billOfLading.isSentToSAP()) {
            try {
                RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(DOCUMENT_TYPE, billOfLading.getNumber());
                if (serviceResponse.isOK()) {
                    setMode(UPDATE);
                } else {
                    addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + getMessageBundle(serviceResponse.getResponseMessage()));
                    setMode(VIEW);
                }
            } catch (Exception ex) {
                LOG.error("There was an error invoking SAP validation service: ", ex);
                addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + ex.getMessage());
                setMode(VIEW);
            }
        } else {
            setMode(UPDATE);
        }
    }

    @SuppressWarnings("unused")
    protected void setViewMode(BillOfLading billOfLading) {
        setMode(VIEW);
    }


    protected BillOfLading loadBillOfLading(){
        LOG.debug("loadBillOfLading from DB  for ID: {}", getIdBillOfLading()) ;
        return billOfLadingService.get(getIdBillOfLading());
    }

    private void cleanUp() {
        setIdBillOfLading(null);
        setBillOfLading(null);
        setMode(null);
        sections = null;
    }

    private boolean validate() {
        LOG.debug("Validation on Edit");
        List<String> violationMessages = getValidator().validate(getBillOfLading());
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public String view() {
        LOG.debug("Start VIEW navigation on BillOfLadingDetailBean");
        begin(Mode.VIEW);
        return SUCCESS;
    }

    public String edit() {
        LOG.debug("Start EDIT navigation on BillOfLadingDetailBean");
        begin(Mode.UPDATE);
        return SUCCESS;
    }

    public StreamedContent getFile() {
        LOG.debug("START DOWNLOAD pdf named: CP_{}.pdf", billOfLading.getNumber());
        return new DefaultStreamedContent(pdfStream, "application/pdf", "CP_" + billOfLading.getNumber() + ".pdf");
    }

    public void generatePdf() {
        LOG.debug("START pdf exportation of billoflading_id: {}", getIdBillOfLading());
        try {
            pdfStream = billOfLadingService.getPdf(billOfLading);
        } catch (BusinessException e) {
            LOG.error("Unexpected error: ", e);
            addMessage(e);
            throw new AbortProcessingException(e);
        }
    }

    public void preSave() {
        LOG.debug("PRE_SAVE on BillOfLadingDetailBean");
        sapMessages.clear();
        setValuesFromComponents();
        boolean validForSave = false;
        if (validate()) {
            validForSave = true;
        }
        addCallbackParam("validForSave", validForSave);
    }

    public String save() {
        LOG.debug("SAVE on BillOfLadingDetailBean");
        TransactionTemplate tx = getTransactionTemplate();
        final BillOfLadingState billOfLadingState = billOfLading.getBillOfLadingState();
        try {
            this.billOfLading = tx.execute(new TransactionCallback<BillOfLading>() {
                public BillOfLading doInTransaction(TransactionStatus status) {
                    //before making any state change
                    boolean wasSentToSAP = billOfLading.isSentToSAP();
                    if (billOfLading.isDischarged()) {
                        billOfLading.setSentToSAP();
                    } else {
                        if (DischargeStatus.REJECTED.equals(billOfLading.getReceivingState())){
                            billOfLading.setBillOfLadingState(BillOfLadingState.REJECTED);
                        } else {
                            billOfLading.setBillOfLadingState(BillOfLadingState.INGRESED);
                        }
                    }


                    billOfLading = billOfLadingService.update(billOfLading);
                    unsuccessfulInvocationService.clearPendingInvocations(billOfLading);
                    //following ifs are for calling sap services depending on bill of lading states

                    if (billOfLading.isDischarged()) {
                        if (wasSentToSAP) {
                            RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(
                                    DOCUMENT_TYPE, billOfLading.getNumber());
                            if (!serviceResponse.isOK()) {
                                throw new BusinessException(serviceResponse.getResponseMessage());
                            }
                            remoteService.update(billOfLading);
                        } else {
                            remoteService.create(billOfLading);
                        }
                    } else {
                        if (wasSentToSAP) {
                            remoteService.delete(billOfLading);
                        } else {
                            unsuccessfulInvocationService.clearPendingInvocations(billOfLading);
                        }
                    }
                    return billOfLading;
                }
            });
        } catch (RemoteServiceException ex) {
            LOG.error("An error occurred sending the BillOfLading to SAP: ", ex);
            billOfLading.setBillOfLadingState(billOfLadingState); //rollback the state changes
            addCallbackParam("remoteServicesError", true);
            getSapMessages().add(ex.getMessage());
            return null;
        } catch (BusinessException ex) {
            LOG.error("Failed save in BillOfLadingDetailBean", ex);
            billOfLading.setBillOfLadingState(billOfLadingState); //rollback the state changes
            addMessage(getMessageBundle(ex.getMessage()));
            return null;
        }
        getFacesBean("billOfLadingSearchFormFacesBean", BillOfLadingSearchFormFacesBean.class).search();
        addMessageNoError("Se ha actualizado correctamente la carta de porte.");
        return SUCCESS;
    }

    public String saveWithErrors() {
        LOG.debug("Begin save with errors in BillOfLadingDetailBean");
        TransactionTemplate tx = getTransactionTemplate();
        try {
            this.billOfLading = tx.execute(new TransactionCallback<BillOfLading>() {
                public BillOfLading doInTransaction(TransactionStatus status) {
                    UnsuccessfulRemoteInvocation.Operation operation;
                    BillOfLading originalBoL = billOfLadingService.get(billOfLading.getId());
                    if (billOfLading.isDischarged()) {
                        if (originalBoL.isSentToSAP()) {
                            operation = UnsuccessfulRemoteInvocation.Operation.UPDATE;
                        } else {
                            operation = UnsuccessfulRemoteInvocation.Operation.CREATE;
                        }
                    } else {
                        if (originalBoL.isSentToSAP()) {
                            operation = UnsuccessfulRemoteInvocation.Operation.DELETE;
                        } else {
                            throw new BusinessException("generic.error");
                        }
                    }

                    BOLUnsuccessfulRemoteInvocation invocation = new BOLUnsuccessfulRemoteInvocation();
                    invocation.setBillOfLading(billOfLading);
                    invocation.setOperation(operation);
                    unsuccessfulInvocationService.clearPendingInvocations(billOfLading);
                    unsuccessfulInvocationService.save(invocation);
                    return billOfLadingService.update(billOfLading);
                }
            });
            emailService.sendRetryStartMessage(billOfLading.getIdSap(), sapMessages, getLoggedUser().getEmail());
        } catch (BusinessException ex) {
            addMessage(getMessageBundle(ex.getMessage()));
            LOG.error("Failed save with errors in BillOfLadingDetailBean", ex);
            return null;
        }
        getFacesBean("billOfLadingSearchFormFacesBean", BillOfLadingSearchFormFacesBean.class).search();
        //TODO: Internationalize this
        addMessageNoError("Se ha actualizado correctamente la carta de porte.");
        LOG.debug("Success save with errors in BillOfLadingDetailBean");
        return SUCCESS;
    }


    public String cancel() {
        LOG.debug("CANCEL on BillOfLadingDetailBean");
        cleanUp();
        return SUCCESS;
    }

    public String back() {
        LOG.debug("GO_BACK on BillOfLadingDetailBean");
        cleanUp();
        return SUCCESS;
    }

    public Long getIdBillOfLading() {
        return idBillOfLading;
    }

    public void setIdBillOfLading(Long idBillOfLading) {
        this.idBillOfLading = idBillOfLading;
    }

    public BillOfLading getBillOfLading() {
        return billOfLading;
    }

    public void setBillOfLading(BillOfLading billOfLading) {
        this.billOfLading = billOfLading;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public BasicDataSectionCC getBasicDataSectionCC() {
        return basicDataSectionCC;
    }

    public void setBasicDataSectionCC(BasicDataSectionCC basicDataSectionCC) {
        this.basicDataSectionCC = basicDataSectionCC;
    }

    public ParticipantsSectionCC getWizardParticipantStepCC() {
        return wizardParticipantStepCC;
    }

    public void setWizardParticipantStepCC(ParticipantsSectionCC wizardParticipantStepCC) {
        this.wizardParticipantStepCC = wizardParticipantStepCC;
    }

    public GrainsTransportedSectionCC getGrainsTransportedSectionCC() {
        return grainsTransportedSectionCC;
    }

    public void setGrainsTransportedSectionCC(GrainsTransportedSectionCC grainsTransportedSectionCC) {
        this.grainsTransportedSectionCC = grainsTransportedSectionCC;
    }

    public OriginDestinationSectionCC getOriginDestinationSectionCC() {
        return originDestinationSectionCC;
    }

    public void setOriginDestinationSectionCC(OriginDestinationSectionCC originDestinationSectionCC) {
        this.originDestinationSectionCC = originDestinationSectionCC;
    }

    public TransportSectionCC getTransportSectionCC() {
        return transportSectionCC;
    }

    public void setTransportSectionCC(TransportSectionCC transportSectionCC) {
        this.transportSectionCC = transportSectionCC;
    }

    public DischargeSectionCC getDischargeSectionCC() {
        return dischargeSectionCC;
    }

    public void setDischargeSectionCC(DischargeSectionCC dischargeSectionCC) {
        this.dischargeSectionCC = dischargeSectionCC;
    }

    public AddressDischargeSectionCC getAddressDischargeSectionCC() {
        return addressDischargeSectionCC;
    }

    public void setAddressDischargeSectionCC(AddressDischargeSectionCC addressDischargeSectionCC) {
        this.addressDischargeSectionCC = addressDischargeSectionCC;
    }

    public TrainWagonSectionCC getTrainWagonSectionCC() {
        return trainWagonSectionCC;
    }

    public void setTrainWagonSectionCC(TrainWagonSectionCC trainWagonSectionCC) {
        this.trainWagonSectionCC = trainWagonSectionCC;
    }

    public List<String> getSapMessages() {
        return sapMessages;
    }

    public GrowerDocumentsCC getGrowerDocumentsCC() {
        return growerDocumentsCC;
    }

    public boolean isGrowerPortalDocumentEnable(){
        boolean adminOrSuper = user.isAdministrator() || user.isSuper();
        return user.isPos() || user.isGrower() || adminOrSuper;
    }

    public boolean isFromGrower() {
        return fromGrower;
    }

    public void setFromGrower(boolean fromGrower) {
        this.fromGrower = fromGrower;
    }
}
