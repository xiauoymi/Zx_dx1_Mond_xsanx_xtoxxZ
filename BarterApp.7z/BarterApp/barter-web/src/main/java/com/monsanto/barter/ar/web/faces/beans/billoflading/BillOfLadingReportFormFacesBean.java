package com.monsanto.barter.ar.web.faces.beans.billoflading;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingState;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.business.service.BillOfLadingReportFilter;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.ReportMetadata;
import com.monsanto.barter.ar.business.service.ReportService;
import com.monsanto.barter.ar.business.service.dto.BillOfLadingReportView;
import com.monsanto.barter.ar.business.service.dto.WagonReportView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.BillOfLadingReportDataModel;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.BillOfLadingReportExportDataModel;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.monsanto.barter.ar.business.service.ReportMetadata.*;

/**
 * @author LABAEZ
 */
public class BillOfLadingReportFormFacesBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingReportFormFacesBean.class);

    public static final String PAGE_REPORT_FORM = "bill-of-lading-report-form";
    public static final String PAGE_REPORT_RESULT = "bill-of-lading-report-result";

    private static final int HEADER_OFFSET = 3;
    private static final int MIN_COLUMN_SIZE = 15;
    private static final int MAX_COLUMN_SIZE = 21;
    private static final int BOOLEAN_COLUMN = 9;
    private static final int FOOTER_CELL_19 = 19;
    private static final int FOOTER_CELL_20 = 20;
    private static final int FOOTER_CELL_21 = 21;
    private static final int HEADER_CELL_0 = 0;
    private static final int HEADER_CELL_1 = 1;
    private static final int HEADER_CELL_2 = 2;
    private static final int HEADER_CELL_3 = 3;
    private static final int HEADER_CELL_4 = 4;
    private static final int HEADER_CELL_5 = 5;
    private static final int HEADER_CELL_6 = 6;
    private static final int HEADER_CELL_7 = 7;
    private static final int HEADER_CELL_8 = 8;
    private static final int HEADER_CELL_9 = 9;
    private static final int MAX_ADJUST_COLUMN_SIZE = 29;

    private DischargeStatus[] receivingStates;
    private BillOfLadingType[] billOfLadingTypes;
    private List<MaterialLas> materialLasList;
    private BillOfLadingReportFilter filter;
    private String cropTypeDescription;
    private BillOfLadingReportDataModel searchResult;
    private BillOfLadingReportExportDataModel searchResultExport;
    private ReportService reportService;
    private MaterialLasService materialLasService;
    private BillOfLadingReportView billOfLadingReportView;
    private WagonReportView selectedWagonRO;

    public String begin() {
        reportService = getService(ReportService.class);
        materialLasService = getService(MaterialLasService.class);
        billOfLadingReportView = new BillOfLadingReportView();
        clear();
        loadCombos();
        return PAGE_REPORT_FORM;
    }

    public String report() {
        if (validateFilters()){
            searchResult = new BillOfLadingReportDataModel(reportService, filter);
            searchResultExport = new BillOfLadingReportExportDataModel(reportService, filter);
            return PAGE_REPORT_RESULT;
        }
        return null;
    }

    public String clear(){
        this.cropTypeDescription = "";
        filter = new BillOfLadingReportFilter();
        return PAGE_REPORT_FORM;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    public void preProcessXLS(Object document) {
        searchResultExport.setFixedSortField(searchResult.getPaging().getSortField());
        searchResultExport.setFixedSortOrder(searchResult.getPaging().getSortOrder());
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET +1; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                    adjustNumericColumn(cell);
                    adjustBooleanColumn(cell);
                }
            }
        }
    }

    private void adjustNumericColumn(Cell cell) {
        if((cell.getColumnIndex() >= MIN_COLUMN_SIZE && cell.getColumnIndex() <= MAX_COLUMN_SIZE) && !cell.getStringCellValue().isEmpty()){
            cell.setCellValue(Double.valueOf(cell.getStringCellValue()));
            cell.getCellStyle().setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        }
    }

    private void adjustBooleanColumn(Cell cell){
        if(cell.getColumnIndex() == BOOLEAN_COLUMN){
            if(cell.getStringCellValue().equalsIgnoreCase("false")){
                cell.setCellValue(getMessageBundle("label.report.excel.no"));
            }
            else {
                cell.setCellValue(getMessageBundle("label.report.excel.yes"));
            }

        }
    }

    private void createFooter(HSSFWorkbook wb) {
        HSSFCellStyle cellStyleTotal = wb.createCellStyle();
        cellStyleTotal.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        cellStyleTotal.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyleTotal.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyleTotal.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyleTotal.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + HEADER_OFFSET;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);


        HSSFCell cell19 = row.createCell(FOOTER_CELL_19);
        cell19.setCellStyle(cellStyleTotal);
        HSSFCell cell20 = row.createCell(FOOTER_CELL_20);
        cell20.setCellStyle(cellStyleTotal);
        HSSFCell cell21 = row.createCell(FOOTER_CELL_21);
        cell21.setCellStyle(cellStyleTotal);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        Map<ReportMetadata, Long> metadata;
        metadata = reportService.reportMetadata(filter);

        cell1.setCellValue(searchResult.getRowCount() + " " + getMessageBundle("label.report.excel.registers"));
        cell19.setCellValue(metadata.get(TotalDownloadNetWeight));
        cell20.setCellValue(metadata.get(TotalDownloadLossWeight));
        cell21.setCellValue(metadata.get(TotalDownloadFinalWeight));
    }

    private void createHeader(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET);
        HSSFRow row0 = sheet.createRow(0);
        HSSFCell cell0 = row0.createCell(HEADER_CELL_0);
        HSSFCell cell1 = row0.createCell(HEADER_CELL_1);
        HSSFCell cell2 = row0.createCell(HEADER_CELL_2);
        HSSFCell cell3 = row0.createCell(HEADER_CELL_3);
        HSSFCell cell4 = row0.createCell(HEADER_CELL_4);
        HSSFCell cell5 = row0.createCell(HEADER_CELL_5);
        HSSFCell cell6 = row0.createCell(HEADER_CELL_6);
        HSSFCell cell7 = row0.createCell(HEADER_CELL_7);
        HSSFCell cell8 = row0.createCell(HEADER_CELL_8);
        HSSFCell cell9 = row0.createCell(HEADER_CELL_9);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        cell0.setCellValue(getMessageBundle("label.report.filters.billOfLadingNumber") + ": ");
        cell0.setCellStyle(cellStyle);
        if (filter.getNumber() != null) {
            cell1.setCellValue(filter.getNumber());
        } else {
            cell1.setCellValue("");
        }

        cell2.setCellValue(getMessageBundle("label.report.filters.billOfLadingType") + ": ");
        cell2.setCellStyle(cellStyle);
        if (filter.getBillOfLadingType() != null) {
            cell3.setCellValue(getMessageBundle(filter.getBillOfLadingType().getDescription()));
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.filters.participantDocument") + ": ");
        cell4.setCellStyle(cellStyle);
        if (filter.getDocument() != null) {
            cell5.setCellValue(filter.getDocument());
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.filters.material") + ": ");
        cell6.setCellStyle(cellStyle);
        if (filter.getCropTypeId() != null) {
            cell7.setCellValue(materialLasService.get(filter.getCropTypeId()).getCommercialText());
        } else {
            cell7.setCellValue("");
        }

        cell8.setCellValue(getMessageBundle("label.report.filters.bol.state") + ": ");
        cell8.setCellStyle(cellStyle);
        if (filter.getBillOfLadingState() != null) {
            cell9.setCellValue(getMessageBundle(filter.getBillOfLadingState().getDescription()));
        } else {
            cell9.setCellValue("");
        }

        HSSFRow row1 = sheet.createRow(1);
        HSSFCell cell10 = row1.createCell(HEADER_CELL_0);
        HSSFCell cell11 = row1.createCell(HEADER_CELL_1);
        HSSFCell cell12 = row1.createCell(HEADER_CELL_2);
        HSSFCell cell13 = row1.createCell(HEADER_CELL_3);
        HSSFCell cell14 = row1.createCell(HEADER_CELL_4);
        HSSFCell cell15 = row1.createCell(HEADER_CELL_5);
        HSSFCell cell16 = row1.createCell(HEADER_CELL_6);
        HSSFCell cell17 = row1.createCell(HEADER_CELL_7);
        HSSFCell cell18 = row1.createCell(HEADER_CELL_8);
        HSSFCell cell19 = row1.createCell(HEADER_CELL_9);


        cell10.setCellValue(getMessageBundle("label.report.excel.state"));
        cell10.setCellStyle(cellStyle);
        if (filter.getDischargeStatus() != null) {
            cell11.setCellValue(getMessageBundle(filter.getDischargeStatus().getDescription()));
        } else {
            cell11.setCellValue("");
        }

        cell12.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell12.setCellStyle(cellStyle);
        if (filter.getGenerationDateFrom() != null) {
            cell13.setCellValue(sdf.format(filter.getGenerationDateFrom()));
        } else {
            cell13.setCellValue("");
        }

        cell14.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell14.setCellStyle(cellStyle);
        if (filter.getGenerationDateTo() != null) {
            cell15.setCellValue(sdf.format(filter.getGenerationDateTo()));
        } else {
            cell15.setCellValue("");
        }

        cell16.setCellValue(getMessageBundle("label.report.filters.campaign") + ": ");
        cell16.setCellStyle(cellStyle);
        if (filter.getCampaign() != null) {
            cell17.setCellValue(filter.getCampaign());
        } else {
            cell17.setCellValue("");
        }

        cell18.setCellValue(getMessageBundle("label.report.filters.contractNumber") + ": ");
        cell18.setCellStyle(cellStyle);
        if (filter.getContractNumber() != null) {
            cell19.setCellValue(filter.getContractNumber());
        } else {
            cell19.setCellValue("");
        }
    }

    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_ADJUST_COLUMN_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }

    private boolean validateFilters() {
        boolean isValid = true;
        if(filter.getGenerationDateFrom() != null && filter.getGenerationDateTo() != null
                && filter.getGenerationDateFrom().after(filter.getGenerationDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            isValid = false;
        }

        List<String> validate = getValidator().validate(filter);
        if (validate!=null && validate.size() > 0){
            addMessage(validate.get(0));
            isValid = false;
        }
        return isValid;
    }

    private void loadCombos() {
        billOfLadingTypes =  BillOfLadingType.values();
        receivingStates = DischargeStatus.values();

        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public void selectedRow(){
        billOfLadingReportView = searchResult.getRowData();
    }

    public DischargeStatus[] getReceivingStates() {
        return receivingStates;
    }

    public void setReceivingStates(DischargeStatus[] receivingStates) {
        this.receivingStates = Arrays.copyOf(receivingStates, receivingStates.length);
    }

    public BillOfLadingType[] getBillOfLadingTypes() {
        return billOfLadingTypes;
    }

    public void setBillOfLadingTypes(BillOfLadingType[] billOfLadingTypes) {
        this.billOfLadingTypes = Arrays.copyOf(billOfLadingTypes, billOfLadingTypes.length);
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public BillOfLadingReportFilter getFilter() {
        return filter;
    }

    public void setFilter(BillOfLadingReportFilter filter) {
        this.filter = filter;
    }

    public String getCropTypeDescription() {
        return cropTypeDescription;
    }

    public void setCropTypeDescription(String cropTypeDescription) {
        this.cropTypeDescription = cropTypeDescription;
    }

    public BillOfLadingReportDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(BillOfLadingReportDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public BillOfLadingReportExportDataModel getSearchResultExport() {
        return searchResultExport;
    }

    public void setSearchResultExport(BillOfLadingReportExportDataModel searchResultExport) {
        this.searchResultExport = searchResultExport;
    }

    public BillOfLadingReportView getBillOfLadingReportView() {
        return billOfLadingReportView;
    }

    public void setBillOfLadingReportView(BillOfLadingReportView billOfLadingReportView) {
        this.billOfLadingReportView = billOfLadingReportView;
    }

    public List<String> getQualityDetailsList(){
        if (billOfLadingReportView.getBillOfLadingType() == BillOfLadingType.TRUCK){
            return billOfLadingReportView.getQualityDetailsAsList();
        } else {
            if (billOfLadingReportView.getWagons() != null){
                for(WagonReportView wagon: billOfLadingReportView.getWagons()){
                    if (wagon.getWagonId() == selectedWagonRO.getWagonId()){
                        return wagon.getQualityDetailsAsList();
                    }
                }
            }
        }
        return new ArrayList<String>(0);
    }

    public WagonReportView getSelectedWagonRO() {
        return selectedWagonRO;
    }

    public void setSelectedWagonRO(WagonReportView selectedWagonRO) {
        this.selectedWagonRO = selectedWagonRO;
    }

    public BillOfLadingState[] getBillOfLadingStates() {
        return new BillOfLadingState[]{BillOfLadingState.INGRESED,BillOfLadingState.REJECTED,BillOfLadingState.CONFIRMED,BillOfLadingState.SENT_TO_SAP};
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }
}
