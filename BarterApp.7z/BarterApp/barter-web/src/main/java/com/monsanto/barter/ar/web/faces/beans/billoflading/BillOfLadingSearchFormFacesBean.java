package com.monsanto.barter.ar.web.faces.beans.billoflading;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.Attachment;
import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AttachmentView;
import com.monsanto.barter.ar.business.service.dto.BillOfLadingView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.BillOfLadingDataModel;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.ToggleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author GAVELO
 */
@SuppressWarnings("unchecked")
public class BillOfLadingSearchFormFacesBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingSearchFormFacesBean.class);

    public static final String PAGE_SEARCH_FORM = "bill-of-lading-search-form";
    public static final String PAGE_SEARCH_RESULT = "bill-of-lading-search-result";
    public static final String PAGE_VIEW = "bill-of-lading-view";


    public static final int EXCEL_TYPE_HEADER_INDEX = 0;
    public static final int EXCEL_TYPE_VALUE_HEADER_INDEX = 1;
    public static final int EXCEL_NUMBER_HEADER_INDEX = 2;
    public static final int EXCEL_NUMBER_VALUE_HEADER_INDEX = 3;
    public static final int CROP_HEADER_INDEX = 4;
    public static final int CROP_VALUE_HEADER_INDEX = 5;
    public static final int CAMPAIGN_HEADER_INDEX = 6;
    public static final int CAMPAIGN_VALUE_HEADER_INDEX = 7;

    public static final int DATE_FROM_HEADER_INDEX = 0;
    public static final int DATE_FROM_VALUE_HEADER_INDEX = 1;
    public static final int DATE_TO_HEADER_INDEX = 2;
    public static final int DATE_TO_VALUE_HEADER_INDEX = 3;
    public static final int CUIT_HEADER_INDEX = 4;
    public static final int CUIT_VALUE_HEADER_INDEX = 5;
    public static final int CONTRACT_NUMBER_HEADER_INDEX = 6;
    public static final int CONTRACT_NUMBER_VALUE_HEADER_INDEX = 7;
    public static final int TIJERETA_HEADER_INDEX = 8;
    public static final int TIJERETA_VALUE_HEADER_INDEX = 9;


    public static final int HEADER_OFFSET = 3;
    public static final int MAX_COLUMNS_SIZE = 18;

    private String deleteReason;

    private BillOfLadingFilter filter;
    private BillOfLadingDataModel searchResult;
    private DischargeStatus[] receivingStates;
    private BillOfLadingType[] billOfLadingTypes;
    private List<MaterialLas> materialLasList;
    private String cropTypeDescription;

    private BillOfLadingView billOfLading;

    private Long idAttachmentToDelete;
    private DocumentsUploader<BillOfLading> documentsUploader;

    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private BillOfLadingService billOfLadingService;
    private AttachmentService attachmentService;
    private RemoteService remoteService;

    public String begin() {
        billOfLadingService = getService(BillOfLadingService.class);
        attachmentService = getService(AttachmentService.class);
        remoteService = getService(RemoteService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        filter = new BillOfLadingFilter();
        loadCombos();
        billOfLadingTypes =  BillOfLadingType.values();
        receivingStates = DischargeStatus.values();
        documentsUploader = new DocumentsUploader<BillOfLading>();
        return PAGE_SEARCH_FORM;
    }

    private void loadCombos(){
        billOfLadingTypes =  BillOfLadingType.values();
        receivingStates = DischargeStatus.values();

        MaterialLasService materialLasService = getService(MaterialLasService.class);

        try {
            this.materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public String search() {
        if (validateFilters()){
            searchResult = new BillOfLadingDataModel(billOfLadingService, filter);
            return PAGE_SEARCH_RESULT;
        }
        return null;
    }

    public String view() {
        begin();
        return PAGE_VIEW;
    }

    public void deleteBillOfLading(){
        TransactionTemplate tx = getTransactionTemplate();
        try {
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    BillOfLading billOfLadingEntity = billOfLadingService.get(billOfLading.getId());
                    boolean sentToSAP = billOfLadingEntity.isSentToSAP();
                    billOfLadingEntity.setDeleteReason(deleteReason);
                    billOfLadingService.delete(billOfLadingEntity);
                    if (sentToSAP) {
                        unsuccessfulInvocationService.clearPendingInvocations(billOfLadingEntity);
                        remoteService.delete(billOfLadingEntity);
                    }
                }
            });
            search();
        } catch (RemoteServiceException ex){
            LOG.error("A remote error occurred deleting bill of lading: ", ex);
            addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotDelete") + getMessageBundle(ex.getMessage()));
        } catch (BusinessException ex){
            LOG.error("An error occurred deleting bill of lading: ", ex);
            addMessage(ex);
        }
    }

    public void selectedRow(){
        billOfLading = searchResult.getRowData();
    }

    private boolean validateFilters(){
        boolean isValid = true;
        if(filter.getGenerationDateFrom() != null && filter.getGenerationDateTo() != null && filter.getGenerationDateFrom().after(filter.getGenerationDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            isValid = false;
        }

        List<String> validate = getValidator().validate(filter);
        if (validate!=null && validate.size() > 0){
            addMessage(validate.get(0));
            isValid = false;
        }

        return isValid;
    }

    public void onRowToggle(ToggleEvent event) {
        BillOfLadingView billOfLadingView = (BillOfLadingView) event.getData();
        if (billOfLadingView.getListAttachmentView() == null) {
            billOfLadingView.setListAttachmentView(billOfLadingService.getAttachments(billOfLadingView.getId()));
        }
    }

    public void setAttachmentToDelete(){
        billOfLading = searchResult.getRowData();
    }

    public void deleteAttachment(){
        billOfLadingService.deleteAttachment(billOfLading.getId(), idAttachmentToDelete);
        AttachmentView attachmentToDelete = null;
        for(AttachmentView attachmentView:billOfLading.getListAttachmentView()){
            if(attachmentView.getId().equals(idAttachmentToDelete)){
                attachmentToDelete = attachmentView;
                break;
            }
        }

        if(attachmentToDelete != null){
            billOfLading.getListAttachmentView().remove(attachmentToDelete);
        }
    }

    //TODO: Revisar este metodo
    public void downloadFile(){
        Attachment attachment = attachmentService.get(idAttachmentToDelete);

        if(attachment != null){
            HttpServletResponse response = getResponse();
            response.setContentType(attachment.getFile().getMimeType());
            response.setHeader("Content-Disposition", "attachment;filename=" + attachment.getFile().getFileName());
            try {
                response.getOutputStream().write(attachment.getFile().getFileContent());
                response.getOutputStream().flush();
                response.getOutputStream().close();
                getFacesContext().responseComplete();
            } catch (IOException e) {
                LOG.error("An error occurred downloading the file", e);
                addMessage(e);
            }
        } else {
            LOG.error("An error occurred downloading an attachment: attachment not found ({})", idAttachmentToDelete);
        }
    }

    public void prepareFileUploadForm() {
        billOfLading = searchResult.getRowData();
        BillOfLading bol = billOfLadingService.get(billOfLading.getId());
        documentsUploader.init(
                (DocumentUploadService<BillOfLading>) billOfLadingService, getService(BeanValidator.class), bol);
    }

    public void attachFiles() {
        if(!documentsUploader.isEmptyFiles()) {
            BillOfLading bol = billOfLadingService.get(billOfLading.getId());
            List<AttachmentView> attachmentsView = new ArrayList<AttachmentView>();
            for (Attachment attachment : documentsUploader.getAttachments()) {
                bol.addAttachment(attachment);
                attachmentsView.add(new AttachmentView(attachment));
            }
            billOfLadingService.update(bol);

            if (billOfLading.getListAttachmentView() != null) {
                billOfLading.getListAttachmentView().addAll(attachmentsView);
            } else {
                billOfLading.setListAttachmentView(attachmentsView);
            }
        }
        documentsUploader.leave();
    }

    public void cancelAttachFiles(){
        documentsUploader.leave();
    }

    public String clear(){
        this.cropTypeDescription = "";
        filter = new BillOfLadingFilter();
        return PAGE_SEARCH_FORM;
    }

    public BillOfLadingType[] getBillOfLadingTypes() {
        return billOfLadingTypes;
    }

    public BillOfLadingView getBillOfLading() {
        return billOfLading;
    }

    public void setBillOfLading(BillOfLadingView billOfLading) {
        this.billOfLading = billOfLading;
    }

    public BillOfLadingFilter getFilter() {
        return filter;
    }

    public void setFilter(BillOfLadingFilter filter) {
        this.filter = filter;
    }

    public BillOfLadingDataModel getSearchResult() {
        return searchResult;
    }

    public String getDeleteReason() {
        return deleteReason;
    }

    public void setDeleteReason(String deleteReason) {
        this.deleteReason = deleteReason;
    }

    public DischargeStatus[] getReceivingStates() {
        return receivingStates;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public String getCropTypeDescription() {
        return cropTypeDescription;
    }

    public void setCropTypeDescription(String cropTypeDescription) {
        this.cropTypeDescription = cropTypeDescription;
    }

    public DocumentType[] getUploadDocumentTypes() {
        return DocumentType.values();
    }

    public Long getIdAttachmentToDelete() {
        return idAttachmentToDelete;
    }

    public void setIdAttachmentToDelete(Long idAttachmentToDelete) {
        this.idAttachmentToDelete = idAttachmentToDelete;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public DocumentsUploader<BillOfLading> getDocumentsUploader() {
        return documentsUploader;
    }

    public void setDocumentsUploader(DocumentsUploader<BillOfLading> documentsUploader) {
        this.documentsUploader = documentsUploader;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(EXCEL_TYPE_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(EXCEL_TYPE_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(EXCEL_NUMBER_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(EXCEL_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(CAMPAIGN_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(CAMPAIGN_VALUE_HEADER_INDEX);

        HSSFRow row1 = sheet.createRow(1);
        HSSFCell cell8 = row1.createCell(DATE_FROM_HEADER_INDEX);
        HSSFCell cell9 = row1.createCell(DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell10 = row1.createCell(DATE_TO_HEADER_INDEX);
        HSSFCell cell11 = row1.createCell(DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell12 = row1.createCell(CUIT_HEADER_INDEX);
        HSSFCell cell13 = row1.createCell(CUIT_VALUE_HEADER_INDEX);
        HSSFCell cell14 = row1.createCell(CONTRACT_NUMBER_HEADER_INDEX);
        HSSFCell cell15 = row1.createCell(CONTRACT_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell16 = row1.createCell(TIJERETA_HEADER_INDEX);
        HSSFCell cell17 = row1.createCell(TIJERETA_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        cell0.setCellValue(getMessageBundle("label.report.excel.billOfLadingType"));
        cell0.setCellStyle(cellStyle);
        if (filter.getBillOfLadingType() != null) {
            cell1.setCellValue(getMessageBundle(filter.getBillOfLadingType().toString()));
        } else {
            cell1.setCellValue("");
        }

        cell2.setCellValue(getMessageBundle("label.report.excel.number"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(filter.getNumber());

        cell4.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell4.setCellStyle(cellStyle);
        cell5.setCellValue(cropTypeDescription);

        cell6.setCellValue(getMessageBundle("label.report.excel.campaign"));
        cell6.setCellStyle(cellStyle);
        cell7.setCellValue(filter.getCampaign());

        cell8.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell8.setCellStyle(cellStyle);
        if (filter.getGenerationDateFrom() != null) {
            cell9.setCellValue(sdf.format(filter.getGenerationDateFrom()));
        } else {
            cell9.setCellValue("");
        }

        cell10.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell10.setCellStyle(cellStyle);
        if (filter.getGenerationDateTo() != null) {
            cell11.setCellValue(sdf.format(filter.getGenerationDateTo()));
        } else {
            cell11.setCellValue("");
        }

        cell12.setCellValue(getMessageBundle("label.report.excel.CUIT"));
        cell12.setCellStyle(cellStyle);
        cell13.setCellValue(filter.getDocument());

        cell14.setCellValue(getMessageBundle("label.report.excel.contractNumber"));
        cell14.setCellStyle(cellStyle);
        cell15.setCellValue(filter.getContractNumber());

        cell16.setCellValue(getMessageBundle("label.report.excel.laTijereta"));
        cell16.setCellStyle(cellStyle);
        if (!filter.getLaTijeretaDescription().equals("")) {
            cell17.setCellValue(getMessageBundle(filter.getLaTijeretaDescription()));
        } else {
            cell17.setCellValue("");
        }
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET+1; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }

    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }
}
