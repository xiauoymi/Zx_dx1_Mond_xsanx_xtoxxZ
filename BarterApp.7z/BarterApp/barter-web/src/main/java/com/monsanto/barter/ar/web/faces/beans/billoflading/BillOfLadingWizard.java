package com.monsanto.barter.ar.web.faces.beans.billoflading;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.constraints.groups.Sensible;
import com.monsanto.barter.ar.business.constraints.groups.billoflading.*;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingState;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.faces.beans.billoflading.composite.*;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.converter.DischargeStatusConverter;
import com.monsanto.barter.ar.web.faces.converter.QualityAttributesConverter;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardFaces;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;
import com.monsanto.barter.ar.web.faces.wizard.WizardStep;
import org.primefaces.event.FlowEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.convert.Converter;
import java.io.IOException;
import java.util.*;

import static com.monsanto.barter.ar.web.faces.mode.Mode.CREATE;

@SuppressWarnings("unchecked")
public class BillOfLadingWizard extends AbstractWizardFaces {
    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingWizard.class);

    public static final String PAGE_SELECT_TYPE = "bill-of-lading-select-type";
    public static final String WAGON_STEP_KEY = "wizardTrainWagonStepCC";
    public static final int WAGON_STEP_INDEX = 4;
    public static final String VALID_BOL_PARAM =  "validBillOfLading";

    private BasicDataSectionCC basicDataSectionCC;
    private TrainWagonSectionCC trainWagonSectionCC;
    private ParticipantsSectionCC wizardParticipantStepCC;
    private GrainsTransportedSectionCC grainsTransportedSectionCC;
    private OriginDestinationSectionCC originDestinationSectionCC;
    private TransportSectionCC transportSectionCC;
    private DischargeSectionCC dischargeSectionCC;
    private AddressDischargeSectionCC addressDischargeSectionCC;

    private DischargeStatusConverter dischargeStatusConverter = new DischargeStatusConverter();
    private QualityAttributesConverter qualityAttributesConverter = new QualityAttributesConverter();

    private BillOfLading billOfLading;
    private BillOfLadingType billOfLadingType;

    private List<AbstractWizardStepCC> wizardSteps;
    private Map<String,AbstractWizardStepCC> wizardStepHashMap;

    private BillOfLadingService billOfLadingService;
    private RemoteService remoteService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private EmailService emailService;

    private String uploadDocumentNumber;
    private DocumentsUploader<BillOfLading> documentsUploader;
    private BeanValidator beanValidator;
    private List<String> sapMessages = new ArrayList<String>();

    public BillOfLadingWizard() {
        super();
        injectBeans();
    }

    public UserDecorator getUser() {
        return GlobalBarterSecurityHelper.getLoggedInUser();
    }

    public BillOfLadingWizard(BillOfLading billOfLading) {
        this();
        this.billOfLading = billOfLading;
    }

    private void injectBeans() {
        beanValidator= getService(BeanValidator.class) ;
        billOfLadingService = getService(BillOfLadingService.class);
        remoteService = getService(RemoteService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        emailService = getService(EmailService.class);
    }

    public String selectType() {
        LOG.debug("Selected Bill of Lading type: {}", this.getBillOfLadingType().toString());
        if (this.getBillOfLadingType()==BillOfLadingType.TRAIN) {
            billOfLading = new BillOfLadingTrain();
        }

        if (this.getBillOfLadingType()==BillOfLadingType.TRUCK) {
            billOfLading = new BillOfLadingTruck();
        }
        doBegin();
        return "success2";
    }

    public String begin() {
        doBegin();
        return SUCCESS;
    }

    private void doBegin() {
        LOG.debug("Beginning Wizard setup.");
        wizardStepHashMap = new HashMap<String, AbstractWizardStepCC>();
        wizardSteps = new ArrayList<AbstractWizardStepCC>();

        LOG.debug("Retrieving section beans.");
        LOG.debug("Bill of Lading type: {}", billOfLading.getBillOfLadingType());

        setBasicDataSectionCC(getService(BasicDataSectionCC.class));
        if (billOfLading instanceof BillOfLadingTrain) {
            setTrainWagonSectionCC(getService(TrainWagonSectionCC.class));
        }
        setWizardParticipantStepCC(getService(ParticipantsSectionCC.class));
        setOriginDestinationSectionCC(getService(OriginDestinationSectionCC.class));
        setTransportSectionCC(getService(TransportSectionCC.class));
        setDischargeSectionCC(getService(DischargeSectionCC.class));
        setGrainsTransportedSectionCC(getService(GrainsTransportedSectionCC.class));
        setAddressDischargeSectionCC(getService(AddressDischargeSectionCC.class));

        LOG.debug("Adding section beans to wizard.");
        int i = 0;
        addWizardStep(basicDataSectionCC.initializeStepCC(i++, "wizardBasicDataStepCC", billOfLading, CREATE));
        addWizardStep(wizardParticipantStepCC.initializeStepCC(i++, "wizardParticipantsStepCC", billOfLading, CREATE));
        addWizardStep(grainsTransportedSectionCC.initializeStepCC(i++, "wizardGrainsTransportedStepCC", billOfLading,
                CREATE));
        addWizardStep(originDestinationSectionCC.initializeStepCC(i++, "wizardOriginDestinationStepCC", billOfLading,
                CREATE));
        if (billOfLading instanceof BillOfLadingTrain) {
            addWizardStep(trainWagonSectionCC.initializeStepCC(i++, "wizardTrainWagonStepCC", billOfLading, CREATE));
        }
        addWizardStep(transportSectionCC.initializeStepCC(i++, "wizardTransportStepCC", billOfLading, CREATE));
        addWizardStep(dischargeSectionCC.initializeStepCC(i++, "wizardDischargeStepCC", billOfLading, CREATE));
        addWizardStep(addressDischargeSectionCC.initializeStepCC(i, "wizardAddressDischargeStepCC", billOfLading,
                CREATE));

        LOG.debug("Initializing basic data section bean.");
        documentsUploader = new DocumentsUploader<BillOfLading>();
        basicDataSectionCC.begin();
    }

    public String selectBillOfLadingType() {
        LOG.debug("select");
        return PAGE_SELECT_TYPE;
    }

    private void addWizardStep(AbstractWizardStepCC wizardStep) {
        wizardSteps.add(wizardStep);
        wizardStepHashMap.put(wizardStep.getKey(), wizardStep);
    }

    @Override
    protected int getStepCount() {
        return wizardSteps.size();
    }

    @Override
    protected WizardStep getStep(int index) {
        return wizardSteps.get(index);
    }

    @Override
    protected WizardStep getStep(String step) {
        return wizardStepHashMap.get(step);
    }

    public String saveBillOfLading(){
        LOG.debug("About to save billOfLading");
        this.dischargeSectionCC.setValuesFromComponents();
        this.addressDischargeSectionCC.setValuesFromComponents();
        this.transportSectionCC.setValuesFromComponents();

        if(!sensibleValidate()){
            addCallbackParam(VALID_BOL_PARAM, false);
            return "";
        }

        prepareForSave();

        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.billOfLading = tx.execute(new TransactionCallback<BillOfLading>() {
                public BillOfLading doInTransaction(TransactionStatus status) {
                    if (billOfLading.isDischarged()){
                        billOfLading.setSentToSAP();
                    }else {
                        if (DischargeStatus.REJECTED.equals(billOfLading.getReceivingState())){
                            billOfLading.setBillOfLadingState(BillOfLadingState.REJECTED);
                        }
                        else {
                            billOfLading.setBillOfLadingState(BillOfLadingState.INGRESED);
                        }
                    }
                    billOfLading = billOfLadingService.save(billOfLading);
                    if (billOfLading.isDischarged()){
                        remoteService.create(billOfLading);
                    }
                    return billOfLading;
                }
            });
        } catch (RemoteServiceException e) {
            billOfLading.setBillOfLadingState(BillOfLadingState.INGRESED);
            LOG.error("An error occurred sending the BillOfLading to SAP: ", e);
            addCallbackParam("remoteServicesError", true);
            sapMessages.add(e.getMessage());
            return "";
        } catch (BusinessException e) {
            billOfLading.setBillOfLadingState(BillOfLadingState.INGRESED);
            LOG.error("An error occurred saving the BillOfLading: ", e);
            addCallbackParam(VALID_BOL_PARAM, false);
            addMessage(getMessageBundle(e.getMessage()));
            return "";
        } catch (DataIntegrityViolationException e){
            // TODO: this should never happen, we must take a look to how the transactions are being handled
            billOfLading.setBillOfLadingState(BillOfLadingState.INGRESED);
            LOG.error("An error occurred saving the BillOfLading: ", e);
            addCallbackParam(VALID_BOL_PARAM, false);
            return "";
        }
        LOG.debug("billOfLading saved with id: {}", this.billOfLading.getId());
        if (billOfLading instanceof BillOfLadingTrain) {
            LOG.debug("Number of wagons: {}", ((BillOfLadingTrain)this.billOfLading).getWagons().size());
        }
        addCallbackParam(VALID_BOL_PARAM, true);
        documentsUploader.init((DocumentUploadService<BillOfLading>) billOfLadingService, beanValidator, billOfLading);
        setUploadDocumentNumber(billOfLading.getNumber());
        return "";
    }

    public String saveWithErrors(){
        LOG.debug("About to save billOfLading with errors");
        this.dischargeSectionCC.setValuesFromComponents();
        this.addressDischargeSectionCC.setValuesFromComponents();
        this.transportSectionCC.setValuesFromComponents();

        sapMessages.clear();
        if(!sensibleValidate()){
            addCallbackParam(VALID_BOL_PARAM, false);
            return "";
        }

        prepareForSave();

        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.billOfLading = tx.execute(new TransactionCallback<BillOfLading>() {
                public BillOfLading doInTransaction(TransactionStatus status) {
                    billOfLadingService.save(billOfLading);
                    BOLUnsuccessfulRemoteInvocation invocation = new BOLUnsuccessfulRemoteInvocation();
                    invocation.setBillOfLading(billOfLading);
                    invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.CREATE);
                    unsuccessfulInvocationService.save(invocation);
                    return billOfLading;
                }
            });
            emailService.sendRetryStartMessage(billOfLading.getIdSap(), sapMessages, getLoggedUser().getEmail());
        } catch (BusinessException e) {
            LOG.error("An error occurred saving the BillOfLading: ", e);
            addCallbackParam(VALID_BOL_PARAM, false);
            addMessage(getMessageBundle(e.getMessage()));
            return "";
        }
        LOG.debug("billOfLading saved with id :{}", this.billOfLading.getId());
        if (billOfLading instanceof BillOfLadingTrain) {
            LOG.debug("Number of wagons: {}", ((BillOfLadingTrain)this.billOfLading).getWagons().size());
        }
        setUploadDocumentNumber(billOfLading.getNumber());
        documentsUploader.init((DocumentUploadService<BillOfLading>) billOfLadingService, beanValidator, billOfLading);
        addCallbackParam(VALID_BOL_PARAM, true);
        return "";
    }

    /**
     * Cancels and invalidates the current (session scoped) wizard.
     */
    public String billOfLadingWizardCancelAction() throws IOException {
        LOG.debug("about to cancel billOfLadingWizard.");
        BillOfLadingWizard newBean = getNewBillOfLadingWizard();
        getFacesContext().getExternalContext().getSessionMap().put("billOfLadingWizardFaces", newBean);
        return CANCEL;
    }

    protected BillOfLadingWizard getNewBillOfLadingWizard() {
        BillOfLadingWizard newBean = new BillOfLadingWizard(this.billOfLading);
        newBean.begin();
        return newBean;
    }

    public boolean isTruck(){
        return billOfLading.getBillOfLadingType() == BillOfLadingType.TRUCK;
    }

    @Override
    public void preSave() {
        LOG.debug("PRE_SAVE on BillOfLadingWizard");
        getActualStep().setValuesFromComponents();
        sapMessages.clear();
        if (getBillOfLading() instanceof  BillOfLadingTrain && getActualStep().getKey().equals(WAGON_STEP_KEY)){
            preSaveForWagonStep();
        } else {
            addCallbackParam("isValid", validate());
        }
    }

    private void preSaveForWagonStep() {
        for(int i = 0; i < WAGON_STEP_INDEX; i++){
            if (!getStep(i).validate()){
                addCallbackParam("stepToTravel", i);
                return;
            }
        }
        addCallbackParam("isValid", validate());
    }

    private void prepareForSave() {
        String commercialSenderCuit;
        if (billOfLading.getCommercialSenderIdentifier() != null) {
            commercialSenderCuit = billOfLading.getCommercialSenderIdentifier();
        } else {
            commercialSenderCuit = "";
        }
        String mediatorCuit = "";
        if (billOfLading.getMediatorCommercialIdentifier() != null) {
            mediatorCuit = billOfLading.getMediatorCommercialIdentifier();
        }
        String destinationCuit = billOfLading.getAddresseeIdentifier();
        if(commercialSenderCuit.equals(MONSANTO_CUIT) || destinationCuit.equals(MONSANTO_CUIT)) {
            billOfLading.setExporter(billOfLading.getAddressee());
            billOfLading.setExporterIdentifier(billOfLading.getAddresseeIdentifier());
        } else if(mediatorCuit.equals(MONSANTO_CUIT)) {
            billOfLading.setExporter(billOfLading.getCommercialSender());
            billOfLading.setExporterIdentifier(billOfLading.getCommercialSenderIdentifier());
        }
    }
    
    @Override
    protected String handleNext(WizardStep oldStep, int nextStepIndex, FlowEvent event) {
        if (getBillOfLading() instanceof  BillOfLadingTrain && oldStep.getKey().equals(WAGON_STEP_KEY)){
            return validatePreviousTabsAndRetrieveTabToShow(oldStep, nextStepIndex, event);
        }
        return super.handleNext(oldStep, nextStepIndex, event);
    }

    private String validatePreviousTabsAndRetrieveTabToShow(WizardStep oldStep, int nextStepIndex, FlowEvent event) {
        for(int i = 0; i < WAGON_STEP_INDEX; i++){
            if (!getStep(i).validate()){
                return getStep(i).getKey();
            }
        }
        return super.handleNext(oldStep, nextStepIndex, event);
    }

    private boolean validate() {
        LOG.debug("Validation");
        List<String> violationMessages = getValidator().validate(getBillOfLading(), BolBasicData.class,
                BolParticipants.class, BolGrainsTransported.class, BolOriginDestination.class, BolTransport.class, BolDischarge.class, BolAddressDischarge.class, BolTrainWagon.class);
        if (addViolationMessages(violationMessages)){
            return false;
        }
        return true;
    }

    private boolean addViolationMessages(List<String> violationMessages) {
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return true;
        }
        return false;
    }

    private boolean sensibleValidate() {
        LOG.debug("Sensible Validation");
        List<String> violationMessages = getValidator().validate(getBillOfLading(), Sensible.class);
        if (addViolationMessages(violationMessages)){
            return false;
        }
        return true;
    }

    public String attachFiles() throws IOException {
        if(!documentsUploader.isEmptyFiles()) {
            for (Attachment attachment : documentsUploader.getAttachments()) {
                billOfLading.addAttachment(attachment);
            }
            billOfLadingService.update(billOfLading);
        }
        documentsUploader.leave();
        billOfLadingWizardCancelAction();
        return SUCCESS;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public BasicDataSectionCC getBasicDataSectionCC() {
        return basicDataSectionCC;
    }

    public void setBasicDataSectionCC(BasicDataSectionCC basicDataSectionCC) {
        this.basicDataSectionCC = basicDataSectionCC;
    }

    public ParticipantsSectionCC getWizardParticipantStepCC() {
        return wizardParticipantStepCC;
    }

    public void setWizardParticipantStepCC(ParticipantsSectionCC wizardParticipantStepCC) {
        this.wizardParticipantStepCC = wizardParticipantStepCC;
    }

    public OriginDestinationSectionCC getOriginDestinationSectionCC() {
        return originDestinationSectionCC;
    }

    public void setOriginDestinationSectionCC(OriginDestinationSectionCC originDestinationSectionCC) {
        this.originDestinationSectionCC = originDestinationSectionCC;
    }

    public TransportSectionCC getTransportSectionCC() {
        return transportSectionCC;
    }

    public void setTransportSectionCC(TransportSectionCC transportSectionCC) {
        this.transportSectionCC = transportSectionCC;
    }

    public DischargeSectionCC getDischargeSectionCC() {
        return dischargeSectionCC;
    }

    public void setDischargeSectionCC(DischargeSectionCC dischargeSectionCC) {
        this.dischargeSectionCC = dischargeSectionCC;
    }

    public AddressDischargeSectionCC getAddressDischargeSectionCC() {
        return addressDischargeSectionCC;
    }

    public void setAddressDischargeSectionCC(AddressDischargeSectionCC addressDischargeSectionCC) {
        this.addressDischargeSectionCC = addressDischargeSectionCC;
    }

    public GrainsTransportedSectionCC getGrainsTransportedSectionCC() {
        return grainsTransportedSectionCC;
    }

    public void setGrainsTransportedSectionCC(GrainsTransportedSectionCC grainsTransportedSectionCC) {
        this.grainsTransportedSectionCC = grainsTransportedSectionCC;
    }

    public BillOfLadingType getBillOfLadingType() {
        return billOfLadingType;
    }

    public void setBillOfLadingType(BillOfLadingType billOfLadingType) {
        this.billOfLadingType = billOfLadingType;
    }

    public TrainWagonSectionCC getTrainWagonSectionCC() {
        return trainWagonSectionCC;
    }

    public void setTrainWagonSectionCC(TrainWagonSectionCC trainWagonSectionCC) {
        this.trainWagonSectionCC = trainWagonSectionCC;
    }

    public BillOfLading getBillOfLading() {
        return billOfLading;
    }

    public Converter getDischargeStatusConverter(){
        return dischargeStatusConverter;
    }

    public Converter getQualityAttributesConverter() {
        return qualityAttributesConverter;
    }

    public String getUploadDocumentNumber() {
        return uploadDocumentNumber;
    }

    public void setUploadDocumentNumber(final String uploadDocumentNumber) {
        this.uploadDocumentNumber = uploadDocumentNumber;
    }

    public DocumentsUploader<BillOfLading> getDocumentsUploader() {
        return documentsUploader;
    }

    public void setDocumentsUploader(DocumentsUploader<BillOfLading> documentsUploader) {
        this.documentsUploader = documentsUploader;
    }

    public List<String> getSapMessages() {
        return sapMessages;
    }
}
