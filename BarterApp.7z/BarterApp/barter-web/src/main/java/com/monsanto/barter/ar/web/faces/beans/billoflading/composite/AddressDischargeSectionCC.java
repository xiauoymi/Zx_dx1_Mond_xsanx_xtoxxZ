package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolAddressDischarge;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class AddressDischargeSectionCC extends BillOfLadingBaseStep {

    @Autowired
    private CustomerCC downloadChangeDestination;

    @Autowired
    private CustomerCC downloadChangeAddressee;

    @Autowired
    private LocationCC location;

    @Override
    public void begin() {
        if(getBillOfLading().getId()!=null){
            if (getBillOfLading().getDownloadChangeDestination() != null) {
                getDownloadChangeDestination().setCustomer(getBillOfLading().getDownloadChangeDestination());
            } else {
                getDownloadChangeDestination().setCustomer(getBillOfLading().getDownloadChangeDestinationCommercialIdentifier());
            }

            if (getBillOfLading().getDownloadChangeAddressee() != null) {
                getDownloadChangeAddressee().setCustomer(getBillOfLading().getDownloadChangeAddressee());
            } else {
                getDownloadChangeAddressee().setCustomer(getBillOfLading().getDownloadChangeAddresseeCommercialIdentifier());
            }
            getLocation().setCity(getBillOfLading().getDownloadChangeCity());
        }
        loadLocations();
        loadCustomers();
    }

    private void loadCustomers() {
        downloadChangeDestination.getSelectedCustomer();
        downloadChangeAddressee.getSelectedCustomer();
    }

    private void loadLocations() {
        location.getCitySelected();
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(BolAddressDischarge.class);
    }

    @Override
    public void setValuesFromComponents(){
        getBillOfLading().setDownloadChangeCity(this.location.getCitySelected());

        getBillOfLading().setDownloadChangeDestination(downloadChangeDestination.getSelectedCustomer());
        getBillOfLading().setDownloadChangeAddressee(downloadChangeAddressee.getSelectedCustomer());

        getBillOfLading().setDownloadChangeDestinationCommercialIdentifier(downloadChangeDestination.getSelectedCustomerIdentifier());
        getBillOfLading().setDownloadChangeAddresseeCommercialIdentifier(downloadChangeAddressee.getSelectedCustomerIdentifier());
    }

    public CustomerCC getDownloadChangeDestination() {
        return downloadChangeDestination;
    }

    public void setDownloadChangeDestination(CustomerCC downloadChangeDestination) {
        this.downloadChangeDestination = downloadChangeDestination;
    }

    public CustomerCC getDownloadChangeAddressee() {
        return downloadChangeAddressee;
    }

    public void setDownloadChangeAddressee(CustomerCC downloadChangeAddressee) {
        this.downloadChangeAddressee = downloadChangeAddressee;
    }

    public LocationCC getLocation() {
        return location;
    }

    public void setLocation(LocationCC location) {
        this.location = location;
    }
}
