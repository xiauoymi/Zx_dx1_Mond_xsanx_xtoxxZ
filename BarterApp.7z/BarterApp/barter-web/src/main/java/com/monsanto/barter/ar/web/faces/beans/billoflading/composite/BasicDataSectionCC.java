package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolBasicData;
import com.monsanto.barter.ar.business.entity.BillOfLadingTruck;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: HNEIR
 * Date: 12/30/13
 * Time: 9:29 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
@SuppressWarnings("unchecked")
public class BasicDataSectionCC extends BillOfLadingBaseStep {

    private BillOfLadingType[] billOfLadingTypes;
    private DischargeStatus[] receivingStates;
    private static final int LEFT_PAD_NUMBER = 12;

    public DischargeStatus[] getReceivingStates() {
        return receivingStates;
    }

    @Override
    public void begin() {
        billOfLadingTypes =  BillOfLadingType.values();
        receivingStates =  DischargeStatus.values();
        if(!getMode().equals(Mode.CREATE)   ){
            getBillOfLading().setBillOfLadingTypeTransient(getBillOfLading().getBillOfLadingType());
            if (isTruck()) {
            ((BillOfLadingTruck)getBillOfLading()).setReceivingStateTransient(getBillOfLading().getReceivingState());
            }
            //TODO arreglar - esto no funciona para edicion de tren
        }
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(BolBasicData.class);
    }

    public BillOfLadingType[] getBillOfLadingTypes() {
        return billOfLadingTypes;
    }

    @Override
    public void setValuesFromComponents(){
        String number = getBillOfLading().getNumber();
        if (number != null){
            getBillOfLading().setNumber(StringUtils.leftPad(number, LEFT_PAD_NUMBER, '0'));
        }
    }
}
