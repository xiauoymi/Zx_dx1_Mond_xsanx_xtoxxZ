package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;

/**
 * Created with IntelliJ IDEA.
 * User: IVERT
 * Date: 2/3/14
 * Time: 2:23 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class BillOfLadingBaseStep extends AbstractWizardStepCC {

    public boolean isTruck(){
        return getBillOfLading().getBillOfLadingType() == BillOfLadingType.TRUCK;
    }

    public boolean isDischarged(){
        return getBillOfLading().isDischarged();
    }

    public BillOfLading getBillOfLading() {
        return (BillOfLading)getEntity();
    }

}
