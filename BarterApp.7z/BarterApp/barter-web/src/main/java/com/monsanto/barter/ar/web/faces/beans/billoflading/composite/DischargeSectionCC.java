package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolDischarge;
import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import com.monsanto.barter.ar.business.entity.BillOfLadingTruck;
import com.monsanto.barter.ar.business.entity.enumerated.QualityAttributes;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.QualityItemSelectableDataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author LABAEZ
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
@SuppressWarnings("unchecked")
public class DischargeSectionCC extends BillOfLadingBaseStep {
    private static final Logger LOG = LoggerFactory.getLogger(DischargeSectionCC.class);

    private List<String> qualityErrorMessages = new ArrayList<String>();

    private QualityItemSelectableDataModel qualityItems;

    private List<BillOfLadingQualityItem> qualityItemList;

    private BillOfLadingQualityItem selectedQualityItem;

    private QualityAttributes[] qualityAttributes;

    private String qualityItemPercentage;

    private Integer qualityItemKilograms;

    private String qualityAttribute;

    private QualityAttributes qualityAttributesTransient;

    @Override
    public void begin() {
        super.begin();
        if (qualityItemList == null) {
            qualityItemList = new ArrayList<BillOfLadingQualityItem>();
        }

        qualityItems = new QualityItemSelectableDataModel(qualityItemList);
    }

    @Override
    protected void initializeValidators() {
        clearQualityItemsFields();
        getGroups().clear();
        getGroups().add(BolDischarge.class);
        qualityAttributes = QualityAttributes.values();

        //TODO: this shouldn't be in this method
        if (isTruck()) {
            qualityItemList = ((BillOfLadingTruck)getBillOfLading()).getQualityItems();
            if (qualityItemList == null){
                qualityItemList = new ArrayList<BillOfLadingQualityItem>();
                ((BillOfLadingTruck)getBillOfLading()).setQualityItems(qualityItemList);
            }
            qualityItems = new QualityItemSelectableDataModel(qualityItemList);
        }
    }

    public boolean isTruck() {
        return (getBillOfLading() instanceof BillOfLadingTruck);
    }

    public QualityAttributes[] getQualityAttributes() {
        return qualityAttributes;
    }

    public void setQualityAttributes(QualityAttributes[] newQualityAttributes) {
        if (newQualityAttributes != null) {
            this.qualityAttributes = Arrays.copyOf(newQualityAttributes, newQualityAttributes.length);
        } else {
            this.qualityAttributes = null;
        }
    }

    public QualityAttributes getQualityAttributesTransient() {
        return qualityAttributesTransient;
    }

    public void setQualityAttributesTransient(QualityAttributes qualityAttributesTransient) {
        this.qualityAttributesTransient = qualityAttributesTransient;
    }

    public Integer getQualityItemKilograms() {
        return qualityItemKilograms;
    }

    public void setQualityItemKilograms(Integer qualityItemKilograms) {
        this.qualityItemKilograms = qualityItemKilograms;
    }

    public List<BillOfLadingQualityItem> getQualityItemList() {
        return qualityItemList;
    }

    public void setQualityItemList(List<BillOfLadingQualityItem> qualityItemList) {
        this.qualityItemList = qualityItemList;
    }

    public String getQualityItemPercentage() {
        return qualityItemPercentage;
    }

    public void setQualityItemPercentage(String qualityItemPercentage) {
        this.qualityItemPercentage = qualityItemPercentage;
    }

    public QualityItemSelectableDataModel getQualityItems() {
        return qualityItems;
    }

    public void setQualityItems(QualityItemSelectableDataModel qualityItems) {
        this.qualityItems = qualityItems;
    }

    public BillOfLadingQualityItem getSelectedQualityItem() {
        return selectedQualityItem;
    }

    public void setSelectedQualityItem(BillOfLadingQualityItem selectedQualityItem) {
        this.selectedQualityItem = selectedQualityItem;
    }

    public void addQualityItem() {
        LOG.debug("add quality Item");

        selectedQualityItem = new BillOfLadingQualityItem();

        selectedQualityItem.setAttribute(qualityAttributesTransient);
        if (qualityItemPercentage!=null){
            selectedQualityItem.setPercentage(new BigDecimal(qualityItemPercentage));
        }
        if (qualityItemKilograms!=null){
            selectedQualityItem.setKilograms(qualityItemKilograms);
        }

        boolean valid = validateQualityItem();
        if(valid){
            LOG.debug("adding quality item to list");
            selectedQualityItem.setBillOfLadingTruck((BillOfLadingTruck) this.getBillOfLading());
            qualityItemList.add(selectedQualityItem);
            qualityItems = new QualityItemSelectableDataModel(qualityItemList);
            if (isTruck()) {
                ((BillOfLadingTruck)getBillOfLading()).setQualityItems(qualityItemList);
            }
            selectedQualityItem = new BillOfLadingQualityItem();
            clearQualityItemsFields();
        } else {
            valid=false;
        }

        addCallbackParam("validQualityItem", valid);
    }

    public List<String> getQualityErrorMessages() {
        return qualityErrorMessages;
    }

    public void setQualityErrorMessages(List<String> qualityErrorMessages) {
        this.qualityErrorMessages = qualityErrorMessages;
    }

    public boolean validateQualityItem() {
        LOG.debug("validateQualityItem");
        qualityErrorMessages = new ArrayList<String>();

        //INS quality items are NOT validated
        if (getSelectedQualityItem().getAttribute() != QualityAttributes.INS) {
            List<String> violationMessages = getValidator().validate(getSelectedQualityItem());

            if (!violationMessages.isEmpty()) {
                qualityErrorMessages.addAll(violationMessages);
                return false;
            }
        }

        // if it was already used, do not validate.
        for(BillOfLadingQualityItem item : qualityItemList) {
            if (item.getAttribute().equals(getSelectedQualityItem().getAttribute())) {
                qualityErrorMessages.add("Ya se usó ese atributo");
                return false;
            }
        }

        return true;
    }

    public void removeQualityItem() {
        LOG.debug("removeQualityItem");

        selectedQualityItem = qualityItems.getRowData(String.valueOf(getQualityAttribute())); // wagons.getRowData(); // wagons.getRowData(getFacesContext().getExternalContext().getRequestParameterMap().get("wagonId"));
        if (selectedQualityItem!=null) {
            qualityItemList.remove(selectedQualityItem);

            qualityItems = new QualityItemSelectableDataModel(qualityItemList);
        }
    }

    public String getQualityAttribute() {
        return qualityAttribute;
    }

    public void setQualityAttribute(String qualityAttribute) {
        this.qualityAttribute = qualityAttribute;
    }

    @SuppressWarnings("unused")
    public void updateQualityItem(BillOfLadingQualityItem row) {
        if (qualityItems!=null && selectedQualityItem!=null) {
            validateQualityItem();
        }
    }

    public void clearQualityItemsFields() {
        qualityItemKilograms = null;
        qualityItemPercentage = null;
        qualityAttributesTransient= null;
    }

    public void clearMessages(){
        qualityErrorMessages.clear();
    }

    public void clearMessagesAndQualityItemsFields(){
        clearQualityItemsFields();
        clearMessages();
    }
}
