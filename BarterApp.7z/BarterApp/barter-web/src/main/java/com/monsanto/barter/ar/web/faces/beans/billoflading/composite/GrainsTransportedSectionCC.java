package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolGrainsTransported;
import com.monsanto.barter.ar.business.entity.CerealType;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.CerealTypeService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.apache.commons.lang.StringUtils.isNotBlank;

/**
 * Created with IntelliJ IDEA.
 * User: gavelo
 * Date: 1/6/14
 * Time: 10:42 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class GrainsTransportedSectionCC extends BillOfLadingBaseStep {

    private static final Logger LOG = LoggerFactory.getLogger(GrainsTransportedSectionCC.class);

    private List<CerealType> cerealTypesList;
    private List<MaterialLas> materialLasList;

    @Autowired
    private CerealTypeService cerealTypeService;

    @Autowired
    private MaterialLasService materialLasService;

    private Long idMaterialLas;

    private String idCerealType;

    @Override
    public void begin() {
        loadLists();
        setSelectedCropType();
        setSelectedCerealType();
    }

    private void setSelectedCerealType() {
        if (this.getBillOfLading().getCropSubType() != null && this.getBillOfLading().getCropSubType().getId() != null) {
            setIdCerealType(getBillOfLading().getCropSubType().getId());
        } else if(isNotBlank(idCerealType)) {
            CerealType cerealType = cerealTypeService.get(getIdCerealType());
            this.getBillOfLading().setCropSubType(cerealType);
        }
    }

    private void setSelectedCropType() {
        if (this.getBillOfLading().getCropType() != null && this.getBillOfLading().getCropType().getId() != null){
            setIdMaterialLas(getBillOfLading().getCropType().getId());
        } else if (idMaterialLas != null){
            MaterialLas materialLas = materialLasService.get(getIdMaterialLas());
            this.getBillOfLading().setCropType(materialLas);
        }
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(BolGrainsTransported.class);
    }

    private void loadLists() {
        if(!getMode().isReadOnly()){
            try {
                if(cerealTypesList== null || cerealTypesList.isEmpty()){
                    setCerealTypesList(cerealTypeService.findAll());
                }
                if(materialLasList== null || materialLasList.isEmpty()){
                    setMaterialLasList(materialLasService.findAll());
                }
            } catch (BusinessException ex) {
                addMessage(ex);
                LOG.error("An error occurred initializing WizardGrainsTransportedStep: ", ex);
            }
        }
    }

    private CerealType recoverCerealType() {
        final String id = getIdCerealType();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (CerealType) CollectionUtils.find(cerealTypesList, predicate);
        }
        return null;
    }

    private MaterialLas recoverCropType() {
        final Long id = getIdMaterialLas();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (MaterialLas) CollectionUtils.find(materialLasList, predicate);
        }
        return null;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {

            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }

    @Override
    public void setValuesFromComponents(){
        this.getBillOfLading().setCropType(recoverCropType());
        this.getBillOfLading().setCropSubType(recoverCerealType());
    }

    public List<CerealType> getCerealTypesList() {
        return cerealTypesList;
    }

    public void setCerealTypesList(List<CerealType> cerealTypesList) {
        this.cerealTypesList = cerealTypesList;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public void setCerealTypeService(CerealTypeService cerealTypeService) {
        this.cerealTypeService = cerealTypeService;
    }

    public void setMaterialLasService(MaterialLasService materialLasService) {
        this.materialLasService = materialLasService;
    }

    public Long getIdMaterialLas() {
        return idMaterialLas;
    }

    public void setIdMaterialLas(Long idMaterialLas) {
        this.idMaterialLas = idMaterialLas;
    }

    public String getIdCerealType() {
        return idCerealType;
    }

    public void setIdCerealType(String idCerealType) {
        this.idCerealType = idCerealType;
    }

    public void setConditionallySatisfiedWithQuality(boolean conditional) {
        getBillOfLading().setConditionallySatisfiedWithQuality(conditional);
    }

    public void setSatisfiedWithQuality(boolean conditional) {
        getBillOfLading().setSatisfiedWithQuality(conditional);
    }

    public boolean isConditionallySatisfiedWithQuality() {
        return getBillOfLading().getConditionallySatisfiedWithQuality();
    }

    public boolean isSatisfiedWithQuality() {
       return getBillOfLading().getSatisfiedWithQuality();
    }

}
