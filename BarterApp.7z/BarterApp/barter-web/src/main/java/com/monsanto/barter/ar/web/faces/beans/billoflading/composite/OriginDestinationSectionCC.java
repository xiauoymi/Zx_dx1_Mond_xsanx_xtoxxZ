package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolOriginDestination;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class OriginDestinationSectionCC extends BillOfLadingBaseStep {

    @Autowired
    private LocationCC destination;

    @Autowired
    private LocationCC origin;

    @Override
    public void begin() {
        if(getBillOfLading().getId()!=null){
            origin.setCity(getBillOfLading().getOriginCity());
            destination.setCity(getBillOfLading().getDestinationCity());
        }
        loadLocations();
    }

    private void loadLocations() {
        origin.getCitySelected();
        destination.getCitySelected();
    }


    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(BolOriginDestination.class);
    }

    @Override
    public void setValuesFromComponents(){
        getBillOfLading().setOriginCity(origin.getCitySelected());
        getBillOfLading().setDestinationCity(destination.getCitySelected());
    }

    public LocationCC getOrigin() {
        return origin;
    }

    public LocationCC getDestination() {
        return destination;
    }

    public void setDestination(LocationCC destination) {
        this.destination = destination;
    }

    public void setOrigin(LocationCC origin) {
        this.origin = origin;
    }
}
