package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolParticipants;
import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.entity.BillOfLadingTruck;
import com.monsanto.barter.ar.business.entity.Vendor;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.VendorService;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.VendorCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: HNEIR
 * Date: 12/27/13
 * Time: 3:44 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class ParticipantsSectionCC extends BillOfLadingBaseStep {

    private static final Logger LOG = LoggerFactory.getLogger(ParticipantsSectionCC.class);
    @Autowired
    private CustomerCC holder;

    @Autowired
    private CustomerCC mediator;

    @Autowired
    private CustomerCC commercialSender;

    @Autowired
    private CustomerCC carrier;

    @Autowired
    private CustomerCC driver;

    @Autowired
    private VendorCC agent;

    @Autowired
    private CustomerCC broker;

    @Autowired
    private CustomerCC addressee;

    @Autowired
    private CustomerCC destination;

    @Autowired
    private VendorService vendorService;

    private boolean editAgent;

    @Override
    public void begin() {
        LOG.debug("Start begin Method WizardParticipantsStepCC");

        if(getBillOfLading().getId()!=null){
            setParticipantsFromBillOfLading();
            UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
            if (user.isAgent() || getMode().equals(Mode.VIEW)) {
                setEditAgent(true);
            }
        } else {
            UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
            if (user.isAgent()) {
                Vendor vendor = vendorService.getVendor(user.getInterventorCompany().getDocument());
                VendorCC vendorCC = new VendorCC();
                vendorCC.setVendor(vendor);
                setEditAgent(true);
                setAgent(vendorCC);
            } else {
                setEditAgent(mode.isReadOnly());
            }
        }

        loadParticipants();
    }

    private void setParticipantsFromBillOfLading(){
        BillOfLading billOfLading = getBillOfLading();

        recoverHolderFromBillOfLading(billOfLading);

        recoverMediatorFromBillOfLading(billOfLading);

        recoverCommercialSenderFromBillOfLading(billOfLading);

        recoverCarrierFromBillOfLading(billOfLading);

        recoverDriverFromBillOfLading(billOfLading);

        recoverAgentFromBillOfLading(billOfLading);

        recoverBrokerFromBillOfLading(billOfLading);

        recoverAddresseeFromBillOfLading(billOfLading);

        recoverDestinationFromBillOfLading(billOfLading);
    }

    private void recoverDestinationFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getDestination() != null) {
            destination.setCustomer(billOfLading.getDestination());
        } else {
            destination.setCustomer(billOfLading.getDestinationIdentifier());
        }
    }

    private void recoverAddresseeFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getAddressee() != null) {
            addressee.setCustomer(billOfLading.getAddressee());
        } else {
            addressee.setCustomer(billOfLading.getAddresseeIdentifier());
        }
    }

    private void recoverBrokerFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getBroker() != null) {
            broker.setCustomer(billOfLading.getBroker());
        } else {
            broker.setCustomer(billOfLading.getBrokerIdentifier());
        }
    }

    private void recoverAgentFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getAgent() != null) {
            agent.setVendor(billOfLading.getAgent());
        } else {
            agent.setVendor(billOfLading.getAgentIdentifier());
        }
    }

    private void recoverDriverFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading instanceof BillOfLadingTruck){
            if (((BillOfLadingTruck)billOfLading).getDriver() != null) {
                driver.setCustomer(((BillOfLadingTruck)billOfLading).getDriver());
            } else {
                driver.setCustomer(((BillOfLadingTruck)billOfLading).getDriverIdentifier());
            }
        }
    }

    private void recoverCarrierFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getCarrier() != null) {
            carrier.setCustomer(billOfLading.getCarrier());
        } else {
            carrier.setCustomer(billOfLading.getCarrierIdentifier());
        }
    }

    private void recoverCommercialSenderFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getCommercialSender() != null) {
            commercialSender.setCustomer(billOfLading.getCommercialSender());
        } else {
            commercialSender.setCustomer(billOfLading.getCommercialSenderIdentifier());
        }
    }

    private void recoverMediatorFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getMediator() != null) {
            mediator.setCustomer(billOfLading.getMediator());
        } else {
            mediator.setCustomer(billOfLading.getMediatorCommercialIdentifier());
        }
    }

    private void recoverHolderFromBillOfLading(BillOfLading billOfLading) {
        if (billOfLading.getHolder() != null) {
            holder.setCustomer(billOfLading.getHolder());
        } else {
            holder.setCustomer(billOfLading.getHolderIdentifier());
        }
    }

    private void loadParticipants(){
        holder.getSelectedCustomer();
        mediator.getSelectedCustomer();
        commercialSender.getSelectedCustomer();
        carrier.getSelectedCustomer();
        driver.getSelectedCustomer();
        agent.getSelectedVendor();
        broker.getSelectedCustomer();
        addressee.getSelectedCustomer();
        destination.getSelectedCustomer();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(BolParticipants.class);
    }

    @Override
    public void setValuesFromComponents(){
        getBillOfLading().setHolder(holder.getSelectedCustomer());
        getBillOfLading().setMediator(mediator.getSelectedCustomer());
        getBillOfLading().setCommercialSender(commercialSender.getSelectedCustomer());
        getBillOfLading().setCarrier(carrier.getSelectedCustomer());
        if (getBillOfLading() instanceof BillOfLadingTruck) {
            ((BillOfLadingTruck)getBillOfLading()).setDriver(driver.getSelectedCustomer());
        }
        getBillOfLading().setAgent(agent.getSelectedVendor());
        getBillOfLading().setBroker(broker.getSelectedCustomer());
        getBillOfLading().setAddressee(addressee.getSelectedCustomer());
        getBillOfLading().setDestination(destination.getSelectedCustomer());

        getBillOfLading().setHolderIdentifier(holder.getSelectedCustomerIdentifier());
        getBillOfLading().setMediatorCommercialIdentifier(mediator.getSelectedCustomerIdentifier());
        getBillOfLading().setCommercialSenderIdentifier(commercialSender.getSelectedCustomerIdentifier());
        getBillOfLading().setCarrierIdentifier(carrier.getSelectedCustomerIdentifier());
        if (getBillOfLading() instanceof BillOfLadingTruck) {
            ((BillOfLadingTruck)getBillOfLading()).setDriverIdentifier(driver.getSelectedCustomerIdentifier());
        }
        getBillOfLading().setAgentIdentifier(agent.getSelectedVendorIdentifier());
        getBillOfLading().setBrokerIdentifier(broker.getSelectedCustomerIdentifier());
        getBillOfLading().setAddresseeIdentifier(addressee.getSelectedCustomerIdentifier());
        getBillOfLading().setDestinationIdentifier(destination.getSelectedCustomerIdentifier());
    }

    public boolean isBrokerReadOnly(){
        return getMode().isReadOnly() || getBillOfLading().isDirect();
    }

    public void clearBrokerIfIsDirect(){
        if (getBillOfLading().isDirect()) {
            broker.clearCustomer();
        }
    }

    public CustomerCC getHolder() {
        return holder;
    }

    public void setHolder(CustomerCC holder) {
        this.holder = holder;
    }

    public CustomerCC getMediator() {
        return mediator;
    }

    public void setMediator(CustomerCC mediator) {
        this.mediator = mediator;
    }

    public CustomerCC getCommercialSender() {
        return commercialSender;
    }

    public void setCommercialSender(CustomerCC commercialSender) {
        this.commercialSender = commercialSender;
    }

    public CustomerCC getCarrier() {
        return carrier;
    }

    public void setCarrier(CustomerCC carrier) {
        this.carrier = carrier;
    }

    public CustomerCC getDriver() {
        return driver;
    }

    public void setDriver(CustomerCC driver) {
        this.driver = driver;
    }

    public VendorCC getAgent() {
        return agent;
    }

    public void setAgent(VendorCC agent) {
        this.agent = agent;
    }

    public CustomerCC getBroker() {
        return broker;
    }

    public void setBroker(CustomerCC broker) {
        this.broker = broker;
    }

    public CustomerCC getAddressee() {
        return addressee;
    }

    public void setAddressee(CustomerCC addressee) {
        this.addressee = addressee;
    }

    public CustomerCC getDestination() {
        return destination;
    }

    public void setDestination(CustomerCC destination) {
        this.destination = destination;
    }

    public boolean getEditAgent() {
        return editAgent;
    }

    public void setEditAgent(boolean editAgent) {
        this.editAgent = editAgent;
    }
}
