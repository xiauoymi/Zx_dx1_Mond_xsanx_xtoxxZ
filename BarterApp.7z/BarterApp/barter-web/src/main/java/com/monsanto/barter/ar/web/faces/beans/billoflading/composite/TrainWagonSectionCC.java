package com.monsanto.barter.ar.web.faces.beans.billoflading.composite;

import com.monsanto.barter.ar.business.constraints.groups.billoflading.BolTrainWagon;
import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import com.monsanto.barter.ar.business.entity.BillOfLadingTrain;
import com.monsanto.barter.ar.business.entity.Wagon;
import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import com.monsanto.barter.ar.business.entity.enumerated.QualityAttributes;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.QualityItemSelectableDataModel;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.WagonSelectableDataModel;
import org.primefaces.event.RowEditEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class TrainWagonSectionCC extends BillOfLadingBaseStep {
    private static final Logger LOG = LoggerFactory.getLogger(TrainWagonSectionCC.class);

    private List<String> qualityErrorMessages = new ArrayList<String>();

    private List<String> wagonErrorMessages = new ArrayList<String>();

    private WagonSelectableDataModel wagons;

    private List<Wagon> wagonList;

    private Wagon selectedWagon;

    private Wagon selectedWagonRO;

    private Wagon prevWagon;

    private QualityItemSelectableDataModel qualityItems;

    private List<BillOfLadingQualityItem> qualityItemList;

    private BillOfLadingQualityItem selectedQualityItem;

    private BillOfLadingQualityItem prevQualityItem;

    private DischargeStatus[] receivingStates;

    private QualityAttributes[] qualityAttributes;

    private String qualityItemPercentage;

    private Integer qualityItemKilograms;

    private QualityAttributes qualityAttributesTransient;

    private boolean isNew = false;

    private Integer editedWagonId;

    private String qualityAttribute;

    public DischargeStatus[] getReceivingStates() {
        return receivingStates;
    }

    @Override
    public void begin() {
        LOG.debug("begin");
        receivingStates =  DischargeStatus.values();
        qualityAttributes = QualityAttributes.values();
        selectedWagon = new Wagon();
        selectedQualityItem = new BillOfLadingQualityItem();
        prevWagon = new Wagon();
        prevWagon.setBillOfLadingTrain((BillOfLadingTrain)getBillOfLading());

        wagonList = ((BillOfLadingTrain)getBillOfLading()).getWagons();
        wagons = new WagonSelectableDataModel(wagonList);

        if (qualityItemList == null) {
            qualityItemList = new ArrayList<BillOfLadingQualityItem>();
        } else {
            qualityItemList = selectedWagon.getQualityItems();
        }

        qualityItems = new QualityItemSelectableDataModel(qualityItemList);
    }

    @Override
    protected void initializeValidators() {
        LOG.debug("initializeValidators");

        clearQualityItemsFields();

        getGroups().clear();
        getGroups().add(BolTrainWagon.class);

        wagonList = ((BillOfLadingTrain)getBillOfLading()).getWagons();
        wagons = new WagonSelectableDataModel(wagonList);
    }

    public Wagon getSelectedWagon() {
        LOG.debug("getSelectedWagon");
        return selectedWagon;
    }

    public void setSelectedWagon(Wagon selectedWagon) {
        LOG.debug("setSelectedWagon");
        if (selectedWagon!=null) {
            this.selectedWagon = selectedWagon;
        }
    }

    public void removeWagon() {
        LOG.debug("removeWagon");
        setNew(false);
        selectedWagon = wagons.getRowData(String.valueOf(getEditedWagonId()));
        LOG.debug("about to remove wagon: {}", selectedWagon.getWagonNumber());
        if (selectedWagon!=null) {
            BillOfLadingTrain billOfLadingTrain = (BillOfLadingTrain)getBillOfLading();
            billOfLadingTrain.removeWagon(selectedWagon);
            LOG.debug("number of wagons: {}", ((BillOfLadingTrain)getBillOfLading()).getWagons().size());
            wagons = new WagonSelectableDataModel(wagonList);
        }
    }

    public void editWagon() {
        setNew(false);
        selectedWagon = wagons.getRowData(getEditedWagonId().toString());
        LOG.debug("Wagon --> {}", selectedWagon);

        LOG.debug("editWagon");

        qualityItemList = selectedWagon.getQualityItems();
        qualityItems = new QualityItemSelectableDataModel(qualityItemList);

        LOG.debug("selectedWagon Id: {}", selectedWagon.getId());
        if (selectedWagon.getQualityItems()!=null) {
            LOG.debug("Number of selectedWagon qualityItems: {}", selectedWagon.getQualityItems().size());
        }

        selectedWagon= wagons.getRowData();
        if (selectedWagon!=null) {
            LOG.debug("selected wagon = {}", selectedWagon.getWagonNumber());
        }

        LOG.debug("editing wagon.");

        copyWagonValues(selectedWagon, prevWagon);
        wagonErrorMessages = new ArrayList<String>();
    }

    public WagonSelectableDataModel getWagons() {
        LOG.debug("getWagons");
        return wagons;
    }

    public void setWagons(WagonSelectableDataModel wagons) {
        LOG.debug("setWagons");
        this.wagons = wagons;
    }

    public void updateWagon() {
        LOG.debug("about to update wagon.");
        setNew(false);
        boolean valid = validateWagon();
        if (wagons.getRowData(String.valueOf(getEditedWagonId()))==null || getEditedWagonId().equals(selectedWagon.getWagonNumber())) {
            if(valid){
                LOG.debug("updating wagon to list");
                selectedWagon.setBillOfLadingTrain((BillOfLadingTrain) this.getBillOfLading());
            }
        } else {
            valid=false;
            //TODO internationalize this
            wagonErrorMessages.add("Ya existe un vagón con ese número.");
        }

        qualityErrorMessages = new ArrayList<String>();
        addCallbackParam("validWagon", valid);
    }


    /*
     * The purpose of this method is to keep the enumerated list
     * in synch with the newQualityAttributes used. The idea is that
     * there cannot be a qualityAttribute used twice.
     */
    public void refreshQualityAttributes() {
        //TODO this?
        // the content of the drop-down
        // newQualityAttributes
        // the quality items added to the list.
        // qualityItems
    }

    public void addQualityItem() {
        LOG.debug("add quality Item");

        selectedQualityItem = new BillOfLadingQualityItem();

        selectedQualityItem.setAttribute(qualityAttributesTransient);
        if (qualityItemPercentage!=null){
            selectedQualityItem.setPercentage(new BigDecimal(qualityItemPercentage));
        }
        if (qualityItemKilograms!=null){
            selectedQualityItem.setKilograms(qualityItemKilograms);
        }

        boolean valid = validateQualityItem(selectedQualityItem, true);
        if(valid){
            LOG.debug("adding quality item to list");
            selectedQualityItem.setWagon(selectedWagon);

            if (qualityItemList == null) {
                qualityItemList = new ArrayList<BillOfLadingQualityItem>();
            }
            qualityItemList.add(selectedQualityItem);
            qualityItems = new QualityItemSelectableDataModel(qualityItemList);
            selectedWagon.setQualityItems(qualityItemList);
            selectedQualityItem = new BillOfLadingQualityItem();

        } else {
            valid=false;
        }

        addCallbackParam("validQualityItem", valid);

        clearQualityItemsFields();
    }

    public boolean validateQualityItem(BillOfLadingQualityItem qualityItem, Boolean fromAddAction) {
        LOG.debug("validateQualityItem");
        qualityErrorMessages = new ArrayList<String>();

        //INS quality items are NOT validated
        if (getSelectedQualityItem().getAttribute() != QualityAttributes.INS) {
            List<String> violationMessages = getValidator().validate(qualityItem);
            if (!violationMessages.isEmpty()) {
                qualityErrorMessages.addAll(violationMessages);
                return false;
            }
        }


        // if it was already used, do not validate.
        if (qualityItemList != null && fromAddAction) {
            for(BillOfLadingQualityItem item : qualityItemList) {
                if (item.getAttribute().equals(qualityItem.getAttribute())) {
                    //TODO: internationalize this
                    qualityErrorMessages.add("Ya se usó ese atributo");
                    return false;
                }
            }
        }
        return true;
    }

    public void addWagon() {
        LOG.debug("About to add new wagon.");
        setNew(true);
        boolean valid = validateWagon();
        if (selectedWagon.getWagonNumber()!=null) {
            if (wagons.getRowData(selectedWagon.getWagonNumber().toString())==null) {
                if(valid){
                    BillOfLadingTrain billOfLadingTrain = (BillOfLadingTrain) this.getBillOfLading();
                    LOG.debug("adding wagon to list");
                    billOfLadingTrain.addWagon(selectedWagon);
                    wagons = new WagonSelectableDataModel(wagonList);
                    selectedWagon = new Wagon();
                    clearQualityItemsFields();
                }
            } else {
                valid=false;
                //TODO: internationalize this
                wagonErrorMessages.add("Ya existe un vagón con ese número.");
            }
        }

        qualityErrorMessages = new ArrayList<String>();
        addCallbackParam("validWagon", valid);
    }


    public boolean validateWagon() {
        LOG.debug("validateWagon");
        wagonErrorMessages = new ArrayList<String>();
        List<String> violationMessages = getValidator().validate(getSelectedWagon());
        if (!violationMessages.isEmpty()) {
            wagonErrorMessages.addAll(violationMessages);
            return false;
        }


        return true;
    }

    public List<String> getWagonErrorMessages() {
        LOG.debug("getErrorMessages");
        return wagonErrorMessages;
    }

    public void setWagonErrorMessages(List<String> wagonErrorMessages) {
        LOG.debug("setWagonErrorMessages");
        this.wagonErrorMessages = wagonErrorMessages;
    }

    public void newWagon() {
        LOG.debug("newWagon");
        setNew(true);
        selectedWagon = new Wagon();
        clearQualityItemsFields();
        qualityItemList = new ArrayList<BillOfLadingQualityItem>();
        qualityItems = new QualityItemSelectableDataModel(qualityItemList);
        wagonErrorMessages = new ArrayList<String>();
    }

    public void cancelAction() {
        LOG.debug("cancelAction");
        copyWagonValues(prevWagon, selectedWagon);
        clearQualityItemsFields();
        wagonErrorMessages = new ArrayList<String>();
        qualityErrorMessages = new ArrayList<String>();
    }

    public void rowSelect(org.primefaces.event.SelectEvent event) {
        if (event.getObject()!=null) {
            LOG.debug("rowSelect ==> {}", ((Wagon)event.getObject()).getWagonNumber());
            if (event.getObject()!=null) {
                LOG.debug("selectedWagon ==> {} ", ((Wagon)event.getObject()).getWagonNumber());
                selectedWagon= (Wagon) event.getObject();
            }
        }
    }

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public Integer getEditedWagonId() {
        return editedWagonId;
    }

    public void setEditedWagonId(Integer editedWagonId) {
        this.editedWagonId = editedWagonId;
    }

    public QualityAttributes[] getQualityAttributes() {
        return qualityAttributes;
    }

    public void setQualityAttributes(QualityAttributes[] newQualityAttributes) {
        if (newQualityAttributes != null) {
            this.qualityAttributes = Arrays.copyOf(newQualityAttributes, newQualityAttributes.length);
        } else {
            this.qualityAttributes = null;
        }
    }

    public QualityAttributes getQualityAttributesTransient() {
        return qualityAttributesTransient;
    }

    public void setQualityAttributesTransient(QualityAttributes qualityAttributesTransient) {
        this.qualityAttributesTransient = qualityAttributesTransient;
    }

    public String getQualityItemPercentage() {
        return qualityItemPercentage;
    }

    public void setQualityItemPercentage(String qualityItemPercentage) {
        this.qualityItemPercentage = qualityItemPercentage;
    }

    public Integer getQualityItemKilograms() {
        return qualityItemKilograms;
    }

    public void setQualityItemKilograms(Integer qualityItemKilograms) {
        this.qualityItemKilograms = qualityItemKilograms;
    }

    public QualityItemSelectableDataModel getQualityItems() {
        return qualityItems;
    }

    public void setQualityItems(QualityItemSelectableDataModel qualityItems) {
        this.qualityItems = qualityItems;
    }

    public List<BillOfLadingQualityItem> getQualityItemList() {
        return qualityItemList;
    }

    public void setQualityItemList(List<BillOfLadingQualityItem> qualityItemList) {
        this.qualityItemList = qualityItemList;
    }

    public BillOfLadingQualityItem getSelectedQualityItem() {
        return selectedQualityItem;
    }

    public void setSelectedQualityItem(BillOfLadingQualityItem selectedQualityItem) {
        this.selectedQualityItem = selectedQualityItem;
    }

    public void removeQualityItem() {
        LOG.debug("removeQualityItem");

        selectedQualityItem = qualityItems.getRowData(String.valueOf(getQualityAttribute()));
        if (selectedQualityItem!=null) {
            qualityItemList.remove(selectedQualityItem);

            qualityItems = new QualityItemSelectableDataModel(qualityItemList);
        }
    }

    public String getQualityAttribute() {
        return qualityAttribute;
    }

    public void setQualityAttribute(String qualityAttribute) {
        this.qualityAttribute = qualityAttribute;
    }

    public List<String> getQualityErrorMessages() {
        return qualityErrorMessages;
    }

    public void setQualityErrorMessages(List<String> qualityErrorMessages) {
        this.qualityErrorMessages = qualityErrorMessages;
    }

    public void editQualityItem(RowEditEvent event) {
        LOG.debug("editQualityItem: {}", event.getObject());
        BillOfLadingQualityItem qualItem = (BillOfLadingQualityItem) event.getObject();
        prevQualityItem = new BillOfLadingQualityItem();
        prevQualityItem.setAttribute(qualItem.getAttribute());
        prevQualityItem.setKilograms(qualItem.getKilograms());
        prevQualityItem.setPercentage(qualItem.getPercentage());
    }

    public void updatedQualityItem(RowEditEvent event) {
        LOG.debug("updatedQualityItem: {}", event.getObject());
        BillOfLadingQualityItem qualItem = (BillOfLadingQualityItem) event.getObject();

        if(validateQualityItem(qualItem, false)) {
            selectedWagon.setQualityItems(qualityItemList);
            selectedWagon.getDecreaseValue();
        } else {
            qualItem.setKilograms(prevQualityItem.getKilograms());
            qualItem.setPercentage(prevQualityItem.getPercentage());
            qualItem.setAttribute(prevQualityItem.getAttribute());
        }
        clearQualityItemsFields();
    }

    public void clearQualityItemsFields() {
        qualityItemKilograms = null;
        qualityItemPercentage = null;
        qualityAttributesTransient= null;
    }

    public Wagon getSelectedWagonRO() {
        return selectedWagonRO;
    }

    public void setSelectedWagonRO(Wagon selectedWagonRO) {
        this.selectedWagonRO = selectedWagonRO;
    }

    public void copyWagonValues(Wagon wagonSrc, Wagon wagonDest) {
        wagonDest.setWagonNumber(wagonSrc.getWagonNumber());
        wagonDest.setTare(wagonSrc.getTare());
        wagonDest.setBillOfLadingTrain(wagonSrc.getBillOfLadingTrain());
        wagonDest.setDecreaseValue(wagonSrc.getDecreaseValue());
        wagonDest.setDownloadDateTime(wagonSrc.getDownloadDateTime());
        wagonDest.setFinalNetWeight(wagonSrc.getFinalNetWeight());
        wagonDest.setGrossWeight(wagonSrc.getGrossWeight());
        wagonDest.setId(wagonSrc.getId());
        wagonDest.setQuality(wagonSrc.getQuality());
        wagonDest.setQualityAttributesTransient(wagonSrc.getQualityAttributesTransient());
        wagonDest.setQualityItems(cloneList(wagonSrc.getQualityItems()));
        wagonDest.setQuality(wagonSrc.getQuality());
        wagonDest.setStatus(wagonSrc.getStatus());
        wagonDest.setStatusTransient(wagonSrc.getStatusTransient());
    }

    private List<BillOfLadingQualityItem> cloneList(List<BillOfLadingQualityItem> list) {
        List<BillOfLadingQualityItem> clone = new ArrayList<BillOfLadingQualityItem>();
        if (list!=null) {
            for(BillOfLadingQualityItem item: list) {
                clone.add(cloneBillOFLadingQualityItem(item));
            }
        }
        return clone;
    }

    private BillOfLadingQualityItem cloneBillOFLadingQualityItem(BillOfLadingQualityItem item) {
        BillOfLadingQualityItem back = new BillOfLadingQualityItem();
        back.setAttribute(item.getAttribute());
        back.setKilograms(item.getKilograms());
        back.setPercentage(item.getPercentage());
        back.setBillOfLadingTruck(item.getBillOfLadingTruck());
        back.setId(item.getId());
        back.setWagon(item.getWagon());
        back.setCreatedBy(item.getCreatedBy());
        back.setCreatedDate(item.getCreatedDate());
        back.setLastUpdateDate(item.getLastUpdateDate());
        back.setLastUpdatedBy(item.getLastUpdatedBy());
        return back;
    }

    public BillOfLadingQualityItem getPrevQualityItem() {
        return prevQualityItem;
    }

    public void setPrevQualityItem(BillOfLadingQualityItem prevQualityItem) {
        this.prevQualityItem = prevQualityItem;
    }

    public Wagon getPrevWagon() {
        return prevWagon;
    }

    public void setPrevWagon(Wagon prevWagon) {
        this.prevWagon = prevWagon;
    }
}
