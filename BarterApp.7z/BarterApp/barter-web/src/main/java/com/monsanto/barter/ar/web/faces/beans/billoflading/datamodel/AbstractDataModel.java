package com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author JPBENI
 */
public abstract class AbstractDataModel <T, F> extends LazyDataModel<T> {
    protected List<T> page = new ArrayList<T>(0);
    protected F filter;
    private Paging paging;
    private String fixedSortField;
    private Paging.SortOrder fixedSortOrder;

    /**
     * Returns a {@link Recordset} with the page records and count
     * @param filter The filtering constraints, cannot be null.
     * @param paging The paging constraints, cannot be null.
     * @return a Recordset containing the page according to the given parameters, never null.
     */
    protected abstract Recordset<T> loadPage(F filter, Paging paging);

    /**
     * Returns the key for the given object.
     * @param object the {@value T} object to retrieve the key from.
     * @return the object's key.
     */
    public abstract Object getRowKey(T object);

    protected AbstractDataModel(F filter) {
        this.filter = filter;
    }

    @Override
    public List<T> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,String> filters) {
        Paging.SortOrder order;
        if (SortOrder.DESCENDING == sortOrder) {
            order = Paging.SortOrder.DESC;
        } else {
            order = Paging.SortOrder.ASC;
        }
        if (getFixedSortField() == null) {
            paging = new Paging(first, pageSize, sortField, order);
        } else {
            if (getFixedSortOrder() != null) {
                order = getFixedSortOrder();
            } else {
                order = Paging.SortOrder.ASC;
            }
            paging = new Paging(first, pageSize, getFixedSortField(), order);
        }
        Recordset<T> results = loadPage(filter, paging);
        setRowCount((int) results.getRecordCount());
        page = results.getRecords();
        return page;
    }

    public List<T> getPage() {
        return page;
    }

    public Paging getPaging() {
        return paging;
    }

    /**
     * Returns the fixed sort field of this DataModel.
     * While set (not null), this sort field permanently overrides the paginator sort field.
     * @return if set, the fixed sort field, null otherwise.
     */
    public String getFixedSortField() {
        return fixedSortField;
    }

    /**
     * Sets a fixed sort field to this DataModel.
     * While set (not null), this sort field will permanently override the paginator sort field.
     * @param fixedSortField the sort field to set.
     */
    public void setFixedSortField(String fixedSortField) {
        this.fixedSortField = fixedSortField;
    }

    /**
     * Returns the fixed sort order of this DataModel.
     * Optional, defaults to ASC
     * Only effective when the sort field is set. @see AbstractDataModel#setFixedSortField
     * @return the fixed sort order.
     */
    public Paging.SortOrder getFixedSortOrder() {
        return fixedSortOrder;
    }

    /**
     * Sets the fixed sort order of this DataModel.
     * Optional, defaults to ASC
     * Only effective when the sort field is set.
     * @see AbstractDataModel#setFixedSortField
     * @param fixedSortOrder the fixed sort order to set.
     */
    public void setFixedSortOrder(Paging.SortOrder fixedSortOrder) {
        this.fixedSortOrder = fixedSortOrder;
    }
}
