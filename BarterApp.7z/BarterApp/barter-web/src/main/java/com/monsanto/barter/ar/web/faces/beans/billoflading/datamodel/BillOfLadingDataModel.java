package com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel;

import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.service.BillOfLadingFilter;
import com.monsanto.barter.ar.business.service.BillOfLadingService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.BillOfLadingView;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author JPBENI
 */
public class BillOfLadingDataModel extends LazyDataModel <BillOfLadingView> {
    private final BillOfLadingService service;
    private final BillOfLadingFilter filter;

    private List<BillOfLadingView> page = new ArrayList<BillOfLadingView>(0);

    public BillOfLadingDataModel(final BillOfLadingService service, final BillOfLadingFilter filter) {
        super();
        this.service = service;
        this.filter = filter;
    }

    @Override
    public List<BillOfLadingView> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,String> filters) {
        Paging.SortOrder order;
        if (SortOrder.DESCENDING == sortOrder) {
            order = Paging.SortOrder.DESC;
        } else {
            order = Paging.SortOrder.ASC;
        }
        Recordset<BillOfLadingView> results = service.search(filter, new Paging(first, pageSize, sortField, order));
        setRowCount((int) results.getRecordCount());
        page = results.getRecords();
        return page;
    }

    @Override
    public BillOfLadingView getRowData(String rowKey) {
        return getRowData(Long.valueOf(rowKey));
    }

    public BillOfLadingView getRowData(Long rowKey) {
        for (BillOfLadingView row : page) {
            if (row.getId().equals(rowKey)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(BillOfLadingView object) {
        return object.getId().toString();
    }
}
