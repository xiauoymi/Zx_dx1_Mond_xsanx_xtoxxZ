package com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel;

import com.monsanto.barter.ar.business.service.BillOfLadingReportFilter;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.ReportService;
import com.monsanto.barter.ar.business.service.dto.BillOfLadingReportView;

/**
 * @author LABAEZ
 */
public class BillOfLadingReportDataModel extends AbstractDataModel <BillOfLadingReportView, BillOfLadingReportFilter> {
    private final ReportService service;

    public BillOfLadingReportDataModel(final ReportService service, final BillOfLadingReportFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    protected Recordset<BillOfLadingReportView> loadPage(BillOfLadingReportFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public BillOfLadingReportView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (BillOfLadingReportView row : getPage()) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(BillOfLadingReportView object) {
        return object.getId().toString();
    }
}
