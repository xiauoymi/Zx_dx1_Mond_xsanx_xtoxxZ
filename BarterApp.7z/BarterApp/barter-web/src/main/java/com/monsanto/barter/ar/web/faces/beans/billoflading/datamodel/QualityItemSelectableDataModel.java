package com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel;

import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import org.primefaces.model.SelectableDataModel;

import javax.faces.model.ListDataModel;
import java.util.List;

public class QualityItemSelectableDataModel extends ListDataModel<BillOfLadingQualityItem> implements SelectableDataModel<BillOfLadingQualityItem> {

    public QualityItemSelectableDataModel(List<BillOfLadingQualityItem> list) {
        super(list);
    }

    @Override
    public Object getRowKey(BillOfLadingQualityItem qualityItem) {
        return qualityItem.getAttribute();
    }

    @Override
    public BillOfLadingQualityItem getRowData(String rowKey) {
        List<BillOfLadingQualityItem> qualityItems = (List<BillOfLadingQualityItem>) getWrappedData();
        for (BillOfLadingQualityItem qualityItem : qualityItems) {
            if (qualityItem.getAttribute().name().equals(rowKey)){
                return qualityItem;
            }
        }
        return null;
    }
}
