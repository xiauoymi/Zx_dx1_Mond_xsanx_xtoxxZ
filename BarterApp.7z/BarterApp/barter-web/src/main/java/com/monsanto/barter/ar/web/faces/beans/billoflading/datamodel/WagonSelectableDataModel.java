package com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel;

import org.primefaces.model.SelectableDataModel;
import com.monsanto.barter.ar.business.entity.Wagon;

import javax.faces.model.ListDataModel;
import java.util.List;

public class WagonSelectableDataModel extends ListDataModel<Wagon> implements SelectableDataModel<Wagon> {

    public WagonSelectableDataModel(List<Wagon> list) {
        super(list);
    }

    @Override
    public Object getRowKey(Wagon wagon) {
        return wagon.getWagonNumber();
    }

    @Override
    public Wagon getRowData(String rowKey) {
        List<Wagon> wagons = (List<Wagon>) getWrappedData();
        for (Wagon wagon : wagons) {
            if (wagon.getWagonNumber().equals(Integer.valueOf(rowKey))){
                return wagon;
            }
        }
        return null;
    }
}
