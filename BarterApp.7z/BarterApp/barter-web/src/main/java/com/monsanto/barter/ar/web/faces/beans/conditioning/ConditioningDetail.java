package com.monsanto.barter.ar.web.faces.beans.conditioning;

import com.monsanto.Util.MessageFormatter;
import com.monsanto.barter.ar.business.entity.Conditioning;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.service.ConditioningService;
import com.monsanto.barter.ar.business.service.RemoteService;
import com.monsanto.barter.ar.business.service.dto.FileDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author VNBARR
 */
public class ConditioningDetail extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(ConditioningDetail.class);

    private Long id;

    private Conditioning conditioning;

    private ConditioningService service;
    private FileDTO pdf;


    public void init(){
        service = getService(ConditioningService.class);
        conditioning = service.get(id);
    }

    public String view(){
        LOG.info(MessageFormatter.format("Start Navigation en VIEW Mode - Class:{0} - id:{1}", getClass().getName(), id));
        init();
        return SUCCESS;
    }

    public String back() {
        LOG.info(MessageFormatter.format("GO BACK  - Class:{0} - id:{1}", getClass().getName(), id));
        cleanUp();
        return SUCCESS;
    }

    private void cleanUp() {
        conditioning = null;
        id = null;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Conditioning getConditioning() {
        return conditioning;
    }

    public void generatePDF() {
        LOG.debug("START get remote pdf from SAP");
        try {
            pdf = getService(RemoteService.class).getPdf(GrowerPortalDocumentType.CONDITIONING, conditioning.getInvoiceNumber());
        } catch (Exception e) {
            LOG.error("Unexpected error: ", e);
            addMessage("No fue posible encontrar el PDF en SAP");
        }
    }

    public StreamedContent getPdfFile() {
        if (pdf!=null) {
            LOG.debug("START DOWNLOAD pdf named: {}.pdf", pdf.getFileName());
            return new DefaultStreamedContent(pdf.getStreamFileContent(), pdf.getMimeType(), pdf.getFileName());
        }
        return null;
    }

    public FileDTO getPdf() {
        return pdf;
    }
}
