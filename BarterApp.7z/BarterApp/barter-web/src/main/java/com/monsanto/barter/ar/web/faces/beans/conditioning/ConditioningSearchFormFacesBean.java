package com.monsanto.barter.ar.web.faces.beans.conditioning;

import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.filter.ConditioningFilter;
import com.monsanto.barter.ar.business.service.ConditioningService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.conditioning.datamodel.ConditioningDataModel;
import com.monsanto.barter.ar.web.faces.beans.search.SearchBase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author VNBARR
 */
public class ConditioningSearchFormFacesBean  extends SearchBase<ConditioningDataModel, ConditioningFilter, ConditioningService> {

    private static final Logger LOG = LoggerFactory.getLogger(ConditioningSearchFormFacesBean.class);
    private PortService portService;
    private PortDestinationDTO portDestination;
    private static final int FIRST_INDEX = 0;
    private static final int FIRST_VALUE_HEADER_INDEX = 1;
    private static final int SECOND_HEADER_INDEX = 2;
    private static final int SECOND_VALUE_HEADER_INDEX = 3;
    private static final int THIRD_HEADER_INDEX = 4;
    private static final int THIRD_VALUE_HEADER_INDEX = 5;
    private static final String EXPORT_LABEL_SEPARATOR= ":";
    public static final String LABEL_SEARCH_FILTERS_CREATION_DATE = "label.search.filters.conditioning.createdDate";
    public static final String AR_BARTER_CALENDAR_FROM = "ar.barter.calendar.from";
    public static final String AR_BARTER_CALENDAR_TO = "ar.barter.calendar.to";
    private static final int HEADER_OFFSET = 4;

    @Override
    protected void initFilter() {
        this.filter = new ConditioningFilter();
        portDestination = null;
    }

    @Override
    protected void initServices() {
        service = getService(ConditioningService.class);
        portService = getService(PortService.class);
    }

    @Override
    protected void loadComponents() {

    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if(filter.getCreatedDateFrom() != null && filter.getCreatedDateTo() != null &&
                filter.getCreatedDateFrom().after(filter.getCreatedDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    @Override
    protected void initSearch() {
        LOG.debug("Search.");
        if (portDestination != null) {
            filter.setPort(portDestination);
        }
        searchResult = new ConditioningDataModel(service, filter);

    }

    @Override
    protected void createHeader(HSSFWorkbook wb) {
        setHeaderOffset(HEADER_OFFSET);
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(2);
        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());
        createCellFor(row, FIRST_INDEX, getMessageBundle(LABEL_SEARCH_FILTERS_CREATION_DATE) + " " +
                getMessageBundle(AR_BARTER_CALENDAR_FROM) + EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getCreatedDateFrom());

        createCellFor(row, SECOND_HEADER_INDEX, getMessageBundle(LABEL_SEARCH_FILTERS_CREATION_DATE) + " " +
                getMessageBundle(AR_BARTER_CALENDAR_TO) + EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getCreatedDateTo());

    }

    private void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(1);

        HSSFCell cell5 = row.createCell(FIRST_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());
        createCellFor(row,FIRST_INDEX,getMessageBundle("label.search.filters.growerContract.port")+EXPORT_LABEL_SEPARATOR);
        if (filter.getPort() != null) {
            cell5.setCellValue(filter.getPort().getDescription());
        }else{
            cell5.setCellValue("");
        }
        createCellFor(row, SECOND_HEADER_INDEX, getMessageBundle("label.search.filters.conditioning.docNumber") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, SECOND_VALUE_HEADER_INDEX, filter.getDocNumber());

        createCellFor(row, THIRD_HEADER_INDEX, getMessageBundle("label.search.filters.conditioning.docType") + EXPORT_LABEL_SEPARATOR);
        if (filter.getDocType() != null){
            createCellFor(row, THIRD_VALUE_HEADER_INDEX, getMessageBundle(filter.getDocType().toString()));
        }else{
            createCellFor(row, THIRD_VALUE_HEADER_INDEX, "");
        }

    }

    private void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), getHeaderOffset()-1);
        HSSFRow row = sheet.createRow(0);

        createCellFor(row, FIRST_INDEX, getMessageBundle("label.search.filters.conditioning.documentType") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, FIRST_VALUE_HEADER_INDEX, filter.getType());

        createCellFor(row, SECOND_HEADER_INDEX, getMessageBundle("label.search.filters.conditioning.invoice") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, SECOND_VALUE_HEADER_INDEX, filter.getInvoiceNumber());

        createCellFor(row, THIRD_HEADER_INDEX, getMessageBundle("label.search.filters.conditioning.grower") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, THIRD_VALUE_HEADER_INDEX, filter.getGrower());
    }


    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public DocumentType[] getDocumentTypes() {
        return new DocumentType[]{DocumentType.ADD,DocumentType.RT,DocumentType.BILL_OF_LADING};
    }
}
