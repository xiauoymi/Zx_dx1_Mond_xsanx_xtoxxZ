package com.monsanto.barter.ar.web.faces.beans.conditioning.datamodel;

import com.monsanto.barter.ar.business.filter.ConditioningFilter;
import com.monsanto.barter.ar.business.service.ConditioningService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ConditioningView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

/**
 * @author VNBARR
 */
public class ConditioningDataModel  extends AbstractDataModel<ConditioningView,ConditioningFilter> {

    private ConditioningService service;

    public ConditioningDataModel(ConditioningService service, ConditioningFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public ConditioningView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (ConditioningView row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    public ConditioningView getRowData(Long rowKey) {
        return getRowData(rowKey.toString());
    }

    @Override
    protected Recordset<ConditioningView> loadPage(ConditioningFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public Object getRowKey(ConditioningView object) {
        return object.getId();
    }
}
