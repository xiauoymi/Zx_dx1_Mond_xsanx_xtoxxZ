package com.monsanto.barter.ar.web.faces.beans.contract;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.TerminalService;
import com.monsanto.barter.ar.business.service.TurnAddresseeService;
import com.monsanto.barter.ar.business.service.dto.CustomerView;
import com.monsanto.barter.ar.business.service.dto.TerminalDTO;
import com.monsanto.barter.ar.business.service.dto.TurnsPerDayView;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.VendorCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ContractInput extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(ContractInput.class);
    private static final String DEFAULT_CUIT_AGENT_TIJERETA = "com.monsanto.barter.ar.contract.defaultCuit.agentTijereta";
    private static final String DEFAULT_CUIT_COMMERCIAL_SENDER = "com.monsanto.barter.ar.contract.defaultCuit.commercialSender" ;
    private ContractService contractService;
    private MaterialLasService materialLasService;
    private TerminalService terminalService;
    private Contract contract;
    private TurnAddressee addressee;
    private CustomerCC commercialSender;
    private VendorCC agent;
    private VendorCC agentTijereta;
    private CustomerCC broker;
    private CustomerCC mediator;
    private List<MaterialLas> materialLasList;
    private Mode mode = Mode.CREATE;
    private Long contractId;
    private Long turnsQuantity =0L;
    private Long availableTurnsQuantity =0L;
    private Long assignedTurnsQuantity =0L;
    private Long notAvailableTurnsQuantity =0L;
    private static final Integer CONTRACT_NUMBER_MAX_LENGTH=10;
    private Long idMaterialLas=null;
    private TurnAddresseeService turnAddresseeService;

    private List<TerminalDTO> terminals;

    private List<TurnsPerDayView> turnsByTerminals;

    private static final String VIEW ="view";

    private boolean fromCreate=false;
    private boolean fromEdit=false;
    private boolean editable=false;
    private boolean editableWithTurns=false;
    private boolean editableContractWithTurns=false;

    private String commercialSenderCuit;
    private String commercialSenderName;
    private boolean commercialSenderFieldEnabled;

    private String mediatorCuit;
    private String mediatorName;
    private boolean mediatorFieldEnabled;

    private String brokerCuit;
    private String brokerName;
    private boolean brokerFieldEnabled;

    private Contract.ContractToSend [] contractToSendOptions;

    protected void init(Mode initMode) {
        fromCreate=false;
        fromEdit=false;
        mode = initMode;
        terminals = null;
        turnsByTerminals =null;

        commercialSenderFieldEnabled=false;
        commercialSenderCuit=null;
        commercialSenderName=null;

        mediatorFieldEnabled=false;
        mediatorCuit=null;
        mediatorName=null;

        brokerFieldEnabled=false;
        brokerCuit=null;
        brokerName=null;
        addressee = null;

        materialLasService = getService(MaterialLasService.class);
        contractService = getService(ContractService.class);
        commercialSender = getService(CustomerCC.class);
        agent = getService(VendorCC.class);
        agent.setForceSelection(true);
        agentTijereta = getService(VendorCC.class);
        broker = getService(CustomerCC.class);
        mediator = getService(CustomerCC.class);
        terminalService = getService(TerminalService.class);
        turnAddresseeService = getService(TurnAddresseeService.class);
        contract = loadContractFromDB();
        idMaterialLas=contract.getCropTypeId();
        retrieveCrops();
        contractToSendOptions = Contract.ContractToSend.values();
    }

    private String newContract() {
        contractId= null;
        turnsQuantity =0L;
        availableTurnsQuantity=0L;
        assignedTurnsQuantity=0L;
        notAvailableTurnsQuantity=0L;
        init(Mode.CREATE);
        loadDefaultParticipants();
        calculateEditableContent();
        return SUCCESS;
    }

    public String editContract() {
        init(Mode.UPDATE);
        loadParticipantsFromContract(contract);
        loadTerminalsFromContract(contract);
        calculateEditableContent();
        return SUCCESS;
    }

    private void calculateEditableContent() {
        editable=calculateIsEditable();
        editableWithTurns=calculateIsEditableWithTurns();
        editableContractWithTurns=calculateIsContractNumberWithTurnsEditable();
    }

    public String viewContract() {
        init(Mode.VIEW);
        loadParticipantsFromContract(contract);
        loadTerminalsFromContract(contract);
        calculateEditableContent();
        return SUCCESS;
    }


    private Contract loadContractFromDB(){
        Contract contractDB = new Contract();
        if(contractId!=null){
            try {
                LOG.debug("Retrieve Contract from DB.");
                contractDB = contractService.get(contractId);
            } catch (BusinessException ex){
                LOG.error("An error occurred loading Crops: ", ex);
            }
        }
        return contractDB;
    }

    public void preSave(){
        setValuesFromComponents(contract);
        boolean validForSave = false;
        if (validate(contract)) {
            validForSave = true;
        }
        addCallbackParam("validForSave", validForSave);
    }

    public String save(){
        String result=VIEW;
        try{
            if(contract.getId()==null){
                contractService.save(contract);
                contractId=contract.getId();
                addMessageNoError(getMessageBundle("label.input.contract.created") + contract.getNumber());
                viewContract();
                fromCreate=true;
            }else{
                contractService.update(contract);
                addMessageNoError(getMessageBundle("label.input.contract.updated")+ contract.getNumber());
                viewContract();
                fromEdit=true;
            }

        } catch (BusinessException ex){
            LOG.error("An error occurred saving Contract: ", ex);
            addMessage(getMessageBundle("label.input.contract.creation.error") + contract.getNumber());
            result= ERROR ;
        }
        return result;
    }

    private boolean validate(Contract contract) {
        LOG.debug("VALIDATION  - Class:{} ", this.getClass().getName());
        List<String> violationMessages = getValidator().validate(contract);
        if(contract.getTerminals()== null || contract.getTerminals().size()==0){
            violationMessages.add(getMessageBundle("label.input.contract.terminals.notEmpty"));
        }
        if(contract.getContractToSend().equals(Contract.ContractToSend.EXPORTER_CONTRACT) && StringUtils.isBlank(contract.getExporterContractNumber())){
            violationMessages.add(getMessageBundle("label.input.contract.exporterNumber.notEmpty"));
        }

        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    public String cancel(){
        this.mode = Mode.CREATE;
        this.contractId = null;
        this.idMaterialLas=null;
        this.contract = new Contract();
        turnsQuantity =0L;
        availableTurnsQuantity=0l;
        assignedTurnsQuantity=0l;
        notAvailableTurnsQuantity=0L;
        terminals=null;
        turnsByTerminals= null;
        return SUCCESS;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    private void setValuesFromComponents(Contract contract){
        if(contract != null){
            setCommercialSenderFromComponent();
            setMediatorFromComponent();
            setAddresseeFromComponent();
            setBrokerFromComponent();
            contract.setAgent(agent.getSelectedVendor());
            contract.setAgentTijereta(agentTijereta.getSelectedVendor());
            contract.setTerminals(getSelectedTerminals());
            try {
                if(idMaterialLas!=null){
                    contract.setCropType(materialLasService.get(idMaterialLas));
                }else{
                    contract.setCropType(null);
                }
            } catch (BusinessException ex) {
                LOG.error("An error occurred setting Crop to Contract: ", ex);
                addMessage(ex);
            }
        }
    }

    private List<Terminal> getSelectedTerminals() {
        List<Long> terminalsToAdd = new ArrayList<Long>();

        if(terminals!=null){
            for(TerminalDTO terminalDTO: terminals){
                if(terminalDTO.isSelected()){
                    terminalsToAdd.add(terminalDTO.getId());
                }
            }
        }

        if(terminalsToAdd.size() >0){
            Long[] terminalsId = new Long[terminalsToAdd.size()];
            return terminalService.getTerminals(terminalsToAdd.toArray(terminalsId));
        }
        return null;
    }

    private void setCommercialSenderFromComponent(){
        if(commercialSender.getSelectedCustomer()!=null){
            contract.setCommercialSender(commercialSender.getSelectedCustomer());
        }else{
            contract.setCommercialSender(null);
            if(StringUtils.isBlank(commercialSenderName)){
                contract.setCommercialSenderName(null);
            }else{
                contract.setCommercialSenderName(commercialSenderName);
            }
            contract.setCommercialSenderCuit(commercialSenderCuit);
        }
    }

    private void setMediatorFromComponent(){
        if(mediator.getSelectedCustomer()!=null){
            contract.setMediator(mediator.getSelectedCustomer());
        }else{
            contract.setMediator(null);
            if(StringUtils.isBlank(mediatorName)){
                contract.setMediatorName(null);
            }else{
                contract.setMediatorName(mediatorName);
            }
            contract.setMediatorCuit(mediatorCuit);
        }
    }

    private void setAddresseeFromComponent(){
        contract.setAddressee(getAddressee());
    }

    private void setBrokerFromComponent(){
        if(broker.getSelectedCustomer()!=null){
            contract.setBroker(broker.getSelectedCustomer());
        }
        else{
            contract.setBroker(null);
            if(StringUtils.isBlank(brokerName)){
                contract.setBrokerName(null);
            }else{
                contract.setBrokerName(brokerName);
            }
            contract.setBrokerCuit(brokerCuit);
        }
    }


    private void loadDefaultParticipants(){
        agentTijereta.setVendor(getMessageBundle(DEFAULT_CUIT_AGENT_TIJERETA));
        agentTijereta.searchVendor();
        commercialSender.setCustomer(getMessageBundle(DEFAULT_CUIT_COMMERCIAL_SENDER));
        commercialSender.searchCustomer();
    }

    private void loadParticipantsFromContract(Contract contract) {
        if(contract!=null ){
            agent.setVendor(contract.getAgent());
            agentTijereta.setVendor(contract.getAgentTijereta());
            assignBrokerToContract();
            assignAddresseeToContract();
            assignMediatorToContract();
            assignCommercialSenderToContract();

        }
    }
    private void loadTerminalsFromContract(Contract contract){
        if(contract.getId()!=null ){
            turnsByTerminals = contractService.getTurnsByTerminal(contractId);
            if(mode == Mode.UPDATE && contract.getAddressee()!= null){
                terminals = terminalService.findAllByContractAndCustomerDestination(contract.getAddressee().getId(), contract.getId());
            }else{
                terminals = contractService.findTerminalsByContractId(contract.getId());
            }

            turnsQuantity =0L;
            availableTurnsQuantity=0L;
            assignedTurnsQuantity=0L;
            notAvailableTurnsQuantity=0L;
            List<TerminalDTO> terminalsDTO;
            if(turnsByTerminals!=null && turnsByTerminals.size() >0){
                for(TurnsPerDayView entry: turnsByTerminals){
                    turnsQuantity +=entry.getNumberOfTurns();
                    availableTurnsQuantity+=entry.getNumberOfAvailableTurns();
                    assignedTurnsQuantity+=entry.getNumberOfAssignedTurns();
                    notAvailableTurnsQuantity+=entry.getNumberOfCancelledTurns()+entry.getNumberOfExpiredTurns();
                    terminalsDTO = (ArrayList<TerminalDTO>) MonCollectionsUtils.selectEqualByField(terminals,"id",entry.getStorageLocationId());
                    if(entry.getNumberOfAvailableTurns() >0L &&terminalsDTO!=null &&terminalsDTO.size()>0){
                        terminalsDTO.get(0).setReadOnly(true);
                    }
                }
            }
        }
    }

    private void assignBrokerToContract(){
        if(contract.getBroker()==null){
            brokerName=contract.getBrokerName();
            brokerCuit=contract.getBrokerCuit();
            if(brokerName!=null && brokerCuit!=null){
                brokerFieldEnabled=true;
                broker.setCustomer(getCustomerView(brokerCuit,brokerName));
            }
        }else{
            broker.setCustomer(contract.getBroker());
        }
    }

    private void assignAddresseeToContract(){
     setAddressee(contract.getAddressee());
    }

    private void assignMediatorToContract(){
        if(contract.getMediator()==null){
            mediatorName=contract.getMediatorName();
            mediatorCuit=contract.getMediatorCuit();
            if(mediatorName!=null && mediatorCuit!=null){
                mediatorFieldEnabled=true;
                mediator.setCustomer(getCustomerView(mediatorCuit,mediatorName));
            }
        }else{
            mediator.setCustomer(contract.getMediator());
        }
    }

    private void assignCommercialSenderToContract(){
        if(contract.getCommercialSender()==null){
            commercialSenderName=contract.getCommercialSenderName();
            commercialSenderCuit=contract.getCommercialSenderCuit();
            if(commercialSenderName!=null && commercialSenderCuit!=null){
                commercialSenderFieldEnabled=true;
                commercialSender.setCustomer(getCustomerView(commercialSenderCuit,commercialSenderName));
            }
        }else{
            commercialSender.setCustomer(contract.getCommercialSender());
        }
    }

    private CustomerView getCustomerView(String cuit, String name) {
        if(this.mode.equals(Mode.VIEW)) {
            return new CustomerView(cuit, name);
        }
        return new CustomerView(cuit,"");

    }

    public String begin() {
        newContract();
        return SUCCESS;
    }

    private void retrieveCrops() {
        LOG.debug("Retrieve Crops from DB.");
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading Crops: ", ex);
            addMessage(ex);
        }
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public TurnAddressee getAddressee() {
        return addressee;
    }

    public void setAddressee(TurnAddressee addressee) {
        this.addressee = addressee;
    }

    public CustomerCC getCommercialSender() {
        return commercialSender;
    }

    public void setCommercialSender(CustomerCC commercialSender) {
        this.commercialSender = commercialSender;
    }

    public VendorCC getAgent() {
        return agent;
    }

    public void setAgent(VendorCC agent) {
        this.agent = agent;
    }

    public VendorCC getAgentTijereta() {
        return agentTijereta;
    }

    public void setAgentTijereta(VendorCC agentTijereta) {
        this.agentTijereta = agentTijereta;
    }

    public CustomerCC getBroker() {
        return broker;
    }

    public void setBroker(CustomerCC broker) {
        this.broker = broker;
    }

    public CustomerCC getMediator() {
        return mediator;
    }

    public void setMediator(CustomerCC mediator) {
        this.mediator = mediator;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public Long getIdMaterialLas() {
        return idMaterialLas;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Long getTurnsQuantity(){
        return this.turnsQuantity;
    }

    public void setTurnsQuantity(Long turnsQuantity) {
        this.turnsQuantity = turnsQuantity;
    }

    public void setIdMaterialLas(Long idMaterialLas) {
        this.idMaterialLas=idMaterialLas;
    }

    public void handleCommercialSenderSelect() {
        CustomerLas commercialSenderCustomer = commercialSender.getSelectedCustomer();
        commercialSenderCuit=commercialSender.getDocumentNumber();
        commercialSenderFieldEnabled=(contract.isInternal() && commercialSenderCustomer==null);
    }

    public void handleCommercialSenderClear(){
        if(contract.isInternal()){
            commercialSenderCuit=null;
            commercialSenderName=null;
            commercialSenderFieldEnabled=false;
        }
    }


    public boolean isEditMode() {
        return mode.equals(Mode.UPDATE);
    }

    public boolean isViewMode() {
        return mode.equals(Mode.VIEW);
    }

    public boolean isCreateMode() {
        return mode.equals(Mode.CREATE);
    }

    public Long getAvailableTurnsQuantity() {
        return availableTurnsQuantity;
    }

    public void setAvailableTurnsQuantity(Long availableTurnsQuantity) {
        this.availableTurnsQuantity = availableTurnsQuantity;
    }

    public Long getAssignedTurnsQuantity() {
        return assignedTurnsQuantity;
    }

    public void setAssignedTurnsQuantity(Long assignedTurnsQuantity) {
        this.assignedTurnsQuantity = assignedTurnsQuantity;
    }

    public void handleInternalContract(){
        if(contract.isInternal() ){
            String random = Long.toString(Calendar.getInstance().getTimeInMillis());
            contract.setNumber(random.substring(0,CONTRACT_NUMBER_MAX_LENGTH));
            nameFieldsEnabler();
        }else{
            commercialSenderFieldEnabled=false;
            mediatorFieldEnabled=false;
            //exporterFieldEnabled=false;
            brokerFieldEnabled=false;
            contract.setNumber("");
        }
    }

    private void nameFieldsEnabler() {
        commercialSenderFieldEnabled=(commercialSender.getSelectedCustomer()==null && commercialSenderCuit!=null );
        mediatorFieldEnabled=(mediator.getSelectedCustomer()==null && mediatorCuit!=null);
        brokerFieldEnabled=(broker.getSelectedCustomer()==null && brokerCuit!=null && !contract.isDirect());
    }

    public boolean isFromCreate() {
        return fromCreate;
    }

    public boolean isFromEdit() {
        return fromEdit;
    }

    public String getCommercialSenderName() {
        return commercialSenderName;
    }

    public void setCommercialSenderName(String commercialSenderName) {
        this.commercialSenderName = commercialSenderName;
    }

    public boolean isCommercialSenderFieldEnabled() {
        return commercialSenderFieldEnabled;
    }

    public void setCommercialSenderFieldEnabled(boolean commercialSenderFieldEnabled) {
        this.commercialSenderFieldEnabled = commercialSenderFieldEnabled;
    }

    public String getMediatorName() {
        return mediatorName;
    }

    public void setMediatorName(String mediatorName) {
        this.mediatorName = mediatorName;
    }

    public boolean isMediatorFieldEnabled() {
        return mediatorFieldEnabled;
    }

    public void setMediatorFieldEnabled(boolean mediatorFieldEnabled) {
        this.mediatorFieldEnabled = mediatorFieldEnabled;
    }

    public void handleMediatorSelect() {
        CustomerLas mediatorCustomer = mediator.getSelectedCustomer();
        mediatorCuit = mediator.getDocumentNumber();
        mediatorFieldEnabled =(contract.isInternal() && mediatorCustomer==null);
    }

    public void handleMediatorClear(){
        if(contract.isInternal()){
            mediatorCuit=null;
            mediatorName=null;
            mediatorFieldEnabled=false;
        }
    }


    public void handleExporterSelect(SelectEvent event) {
        this.addressee = (TurnAddressee) event.getObject();
        if(addressee!=null ){
           terminals =terminalService.findAllByCustomerDestination(addressee.getId());
        } else {
            terminals = null;
            turnsByTerminals= null;
        }
    }

    public void handleExporterClear(){
        terminals=null;
        this.addressee =null;
    }

    public boolean isBrokerFieldEnabled() {
        return brokerFieldEnabled;
    }

    public void setBrokerFieldEnabled(boolean brokerFieldEnabled) {
        this.brokerFieldEnabled = brokerFieldEnabled;
    }

    public String getBrokerName() {
        return brokerName;
    }

    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }


    public void handleBrokerSelect() {
        CustomerLas brokerCustomer = broker.getSelectedCustomer();
        brokerCuit = broker.getDocumentNumber();
        brokerFieldEnabled =(contract.isInternal() && brokerCustomer==null);
    }

    public void handleBrokerClear(){
        if(contract.isInternal()){
            brokerCuit=null;
            brokerName=null;
            brokerFieldEnabled=false;
        }
    }


    public void updateBroker(){
        if (contract.isDirect()) {
            broker.clearCustomer();
            brokerName=null;
            brokerCuit=null;
            brokerFieldEnabled=false;
        }else{
            if(contract.isInternal()){
                brokerFieldEnabled =(broker.getSelectedCustomer()==null && brokerCuit!=null);
            }
        }
    }


    public List<TerminalDTO> getTerminals() {
        return terminals;
    }


    public List<TurnsPerDayView> getTurnsByTerminals() {
        return turnsByTerminals;
    }

    private boolean calculateIsEditable(){
        if(isViewMode()){
            return false;
        }
        return true;
    }

    private boolean calculateIsEditableWithTurns() {
        if(isViewMode() || assignedTurnsQuantity!=0){
            return false;
        }

        return true;
    }

    private boolean calculateIsContractNumberWithTurnsEditable() {
        if(isViewMode() || (!contract.isInternal() && assignedTurnsQuantity!=0)){
            return false;
        }

        return true;
    }

    public boolean isEditable(){
        return editable;
    }

    public Long getNotAvailableTurnsQuantity() {
        return notAvailableTurnsQuantity;
    }

    public void setNotAvailableTurnsQuantity(Long notAvailableTurnsQuantity) {
        this.notAvailableTurnsQuantity = notAvailableTurnsQuantity;
    }

    public boolean isEditableWithTurns() {
        return editableWithTurns;
    }

    public boolean isEditableContractWithTurns() {
        return editableContractWithTurns;
    }

    public Contract.ContractToSend[] getContractToSendOptions() {
        return contractToSendOptions;
    }

    public List<TurnAddressee> addresseeAutocomplete(String query) {
        return turnAddresseeService.searchForAutoComplete(query);
    }
}
