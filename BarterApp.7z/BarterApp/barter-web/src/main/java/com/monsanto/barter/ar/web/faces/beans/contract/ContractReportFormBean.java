package com.monsanto.barter.ar.web.faces.beans.contract;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.ContractReportFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractReportDataModel;
import com.monsanto.barter.ar.web.faces.report.ReportBase;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.List;

public class ContractReportFormBean extends ReportBase<ContractReportDataModel, ContractReportFilter, ContractService> {

    private static final Logger LOG = LoggerFactory.getLogger(ContractReportFormBean.class);

    public static final int CONTRACT_NUMBER_HEADER_INDEX = 0;
    public static final int CONTRACT_NUMBER_VALUE_HEADER_INDEX = 1;
    public static final int EXPORTER_NUMBER_HEADER_INDEX = 2;
    public static final int EXPORTER_NUMBER_VALUE_HEADER_INDEX = 3;
    public static final int CROP_HEADER_INDEX = 4;
    public static final int CROP_VALUE_HEADER_INDEX = 5;
    public static final int INTERNAL_HEADER_INDEX = 6;
    public static final int INTERNAL_VALUE_HEADER_INDEX = 7;
    public static final int EXPORTER_HEADER_INDEX = 8;
    public static final int EXPORTER_VALUE_HEADER_INDEX = 9;

    public static final int BROKER_HEADER_INDEX = 0;
    public static final int BROKER_VALUE_HEADER_INDEX = 1;
    public static final int AGENT_HEADER_INDEX = 2;
    public static final int AGENT_VALUE_HEADER_INDEX = 3;
    public static final int DATE_FROM_HEADER_INDEX = 4;
    public static final int DATE_FROM_VALUE_HEADER_INDEX = 5;
    public static final int DATE_TO_HEADER_INDEX = 6;
    public static final int DATE_TO_VALUE_HEADER_INDEX = 7;


    private List<MaterialLas> materialLasList;
    private MaterialLasService materialLasService;

    @Override
    protected void initFilter() {
        filter = new ContractReportFilter();
    }

    @Override
    protected void initServices() {
        materialLasService = getService(MaterialLasService.class);
        service = getService(ContractService.class);
    }

    @Override
    protected void loadCombos() {
        LOG.debug("loadCombos.");
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getDeliveryDateFrom() != null && filter.getDeliveryDateTo() != null && filter.getDeliveryDateFrom().after(filter.getDeliveryDateTo())) {
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    @Override
    protected void initReport() {
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));
        searchResult = new ContractReportDataModel(service, filter);
        LOG.debug("Search -> Result");
    }

    @Override
    protected void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0, sheet.getLastRowNum(), HEADER_OFFSET - 1);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(CONTRACT_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(CONTRACT_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(EXPORTER_NUMBER_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(EXPORTER_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(INTERNAL_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(INTERNAL_VALUE_HEADER_INDEX);
        HSSFCell cell8 = row.createCell(EXPORTER_HEADER_INDEX);
        HSSFCell cell9 = row.createCell(EXPORTER_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.turn.contractNumber"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getContractNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.turn.exporterContractNumber"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(filter.getExporterContractNumber());

        cell4.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell4.setCellStyle(cellStyle);
        if (filter.getCropType() != null) {
            cell5.setCellValue(filter.getCropType().getCommercialText());
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.Internal"));
        cell6.setCellStyle(cellStyle);
        if (filter.getInternal()!=null){
            cell7.setCellValue(getMessageBundle(filter.getInternalDescription()));
        }
        else {
            cell7.setCellValue("");
        }

        cell8.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.exporter"));
        cell8.setCellStyle(cellStyle);
        cell9.setCellValue(filter.getExporter());
    }

    @Override
    protected void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell0 = row2.createCell(BROKER_HEADER_INDEX);
        HSSFCell cell1 = row2.createCell(BROKER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row2.createCell(AGENT_HEADER_INDEX);
        HSSFCell cell3 = row2.createCell(AGENT_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row2.createCell(DATE_FROM_HEADER_INDEX);
        HSSFCell cell5 = row2.createCell(DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row2.createCell(DATE_TO_HEADER_INDEX);
        HSSFCell cell7 = row2.createCell(DATE_TO_VALUE_HEADER_INDEX);



        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.broker"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getBroker());

        cell2.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.agent"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(filter.getAgent());

        cell4.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell4.setCellStyle(cellStyle);
        if (filter.getDeliveryDateFrom() != null) {
            cell5.setCellValue(sdf.format(filter.getDeliveryDateFrom()));
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell6.setCellStyle(cellStyle);
        if (filter.getDeliveryDateTo() != null) {
            cell7.setCellValue(sdf.format(filter.getDeliveryDateTo()));
        } else {
            cell7.setCellValue("");
        }
    }

    @Override
    protected void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }
}
