package com.monsanto.barter.ar.web.faces.beans.contract;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Contract;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.ContractFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractDataModel;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.text.SimpleDateFormat;
import java.util.List;

public class ContractSearchFormBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(ContractSearchFormBean.class);

    public static final String PAGE_SEARCH_RESULT = "contract-search-result";

    public static final int EXCEL_NUMBER_HEADER_INDEX = 0;
    public static final int EXCEL_NUMBER_VALUE_HEADER_INDEX = 1;
    public static final int CROP_HEADER_INDEX = 2;
    public static final int CROP_VALUE_HEADER_INDEX = 3;
    public static final int INTERNAL_HEADER_INDEX=4;
    public static final int INTERNAL_VALUE_HEADER_INDEX=5;

    public static final int DATE_FROM_HEADER_INDEX = 0;
    public static final int DATE_FROM_VALUE_HEADER_INDEX = 1;
    public static final int DATE_TO_HEADER_INDEX = 2;
    public static final int DATE_TO_VALUE_HEADER_INDEX = 3;
    public static final int BROKER_HEADER_INDEX = 4;
    public static final int BROKER_VALUE_HEADER_INDEX = 5;
    public static final int EXPORTER_HEADER_INDEX = 6;
    public static final int EXPORTER_VALUE_HEADER_INDEX = 7;


    public static final int HEADER_OFFSET = 4;
    public static final int MAX_COLUMNS_SIZE = 12;


    private ContractFilter filter;
    private ContractDataModel searchResult;

    private List<MaterialLas> materialLasList;
    private MaterialLasService materialLasService;
    private ContractService contractService;
    private PortService portService;

    private ContractView contractView;

    private String deleteReason;

    private PortDestinationDTO portDestination;


    public String begin(){
        LOG.debug("Setting filters.");
        filter = new ContractFilter();
        portDestination=null;
        LOG.debug("Retrieving services.");
        materialLasService = getService(MaterialLasService.class);
        contractService = getService(ContractService.class);
        portService = getService(PortService.class);
        LOG.debug("About to load the combos.");
        loadCombos();
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        filter = new ContractFilter();
        portDestination=null;
        return SUCCESS;
    }

    public String search(){
        LOG.debug("Search.");

        if (validateFilters()){
            for(MaterialLas material: materialLasList){
                if(material.getId().equals(filter.getCropTypeId())){
                    filter.setCropType(material);
                    break;
                }
            }

            if(portDestination !=null){
                filter.setPort(portService.get(portDestination.getId()));
            }

            searchResult = new ContractDataModel(contractService,filter);
            LOG.debug("Search -> Result");

            return PAGE_SEARCH_RESULT;
        }

        LOG.debug("Returning null.");

        return null;
    }

    private boolean validateFilters(){
        LOG.debug("validateFilters.");
        if(filter.getDeliveryDateFrom() != null && filter.getDeliveryDateTo() != null && filter.getDeliveryDateFrom().after(filter.getDeliveryDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    private void loadCombos(){
        LOG.debug("loadCombos.");
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public ContractFilter getFilter() {
        return filter;
    }

    public void setFilter(ContractFilter filter) {
        this.filter = filter;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public ContractDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(ContractDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public void selectedRow(){
        contractView = searchResult.getRowData();
    }


    public String getDeleteReason() {
        return deleteReason;
    }

    public void setDeleteReason(String deleteReason) {
        this.deleteReason = deleteReason;
    }

    public void deleteContract(){
        LOG.debug("Delete contract.");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    Contract contract = contractService.get(contractView.getContractId());
                    contract.setDeleteReason(deleteReason);
                    contractService.delete(contract);
                }
            });
            search();
        } catch (BarterException ex) {
            LOG.error("An error occurred deleting the contract: ", ex);
            addMessage(ex);
        }
    }

    public ContractView getContractView(){
        return contractView;
    }

    public void setContractView(ContractView contractView){
        this.contractView = contractView;
    }


    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }


    private void createHeader(HSSFWorkbook wb) {
        createHeaderFirstRow(wb);

        createHeaderSecondRow(wb);
    }

    private void createHeaderFirstRow(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET-1);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(EXCEL_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(EXCEL_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(INTERNAL_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(INTERNAL_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.number"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getContractNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell2.setCellStyle(cellStyle);
        if(filter.getCropType() != null){
            cell3.setCellValue(filter.getCropType().getCommercialText());
        }else{
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.internal"));
        cell4.setCellStyle(cellStyle);
        if (filter.getInternal()!=null){
            cell5.setCellValue(getMessageBundle(filter.getInternalDescription()));
        }
        else {
            cell5.setCellValue("");
        }
    }

    private void createHeaderSecondRow(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell6 = row2.createCell(DATE_FROM_HEADER_INDEX);
        HSSFCell cell7 = row2.createCell(DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell8 = row2.createCell(DATE_TO_HEADER_INDEX);
        HSSFCell cell9 = row2.createCell(DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell10 = row2.createCell(BROKER_HEADER_INDEX);
        HSSFCell cell11 = row2.createCell(BROKER_VALUE_HEADER_INDEX);
        HSSFCell cell12 = row2.createCell(EXPORTER_HEADER_INDEX);
        HSSFCell cell13 = row2.createCell(EXPORTER_VALUE_HEADER_INDEX);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell6.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell6.setCellStyle(cellStyle);
        if(filter.getDeliveryDateFrom() != null){
            cell7.setCellValue(sdf.format(filter.getDeliveryDateFrom()));
        }else{
            cell7.setCellValue("");
        }

        cell8.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell8.setCellStyle(cellStyle);
        if(filter.getDeliveryDateTo() != null){
            cell9.setCellValue(sdf.format(filter.getDeliveryDateTo()));
        }else{
            cell9.setCellValue("");
        }

        cell10.setCellValue(getMessageBundle("label.report.excel.broker"));
        cell10.setCellStyle(cellStyle);
        if(filter.isDirect()){
            cell11.setCellValue(getMessageBundle("label.report.excel.direct"));
        } else {
            cell11.setCellValue(filter.getBroker());
        }

        cell12.setCellValue(getMessageBundle("label.report.excel.exporter"));
        cell12.setCellStyle(cellStyle);
        cell13.setCellValue(filter.getExporter());
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET-1);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }


    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public void handleItemSelect(SelectEvent event) {
        portDestination = (PortDestinationDTO) event.getObject();
    }

}
