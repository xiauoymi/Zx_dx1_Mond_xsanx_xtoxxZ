package com.monsanto.barter.ar.web.faces.beans.contract.datamodel;

import com.monsanto.barter.ar.business.service.ContractFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;


/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 04/07/14
 * Time: 14:31
 * To change this template use File | Settings | File Templates.
 */
public class ContractDataModel  extends AbstractDataModel<ContractView,ContractFilter> {

    private ContractService service;

    public ContractDataModel(ContractService service, ContractFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public ContractView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (ContractView row : page) {
            if (row.getContractId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<ContractView> loadPage(ContractFilter filter, Paging paging) {
        return service.search(filter,paging);
    }

    @Override
    public Object getRowKey(ContractView object) {
        return object.getContractId().toString();
    }

    public ContractService getService() {
        return service;
    }

    public void setService(ContractService service) {
        this.service = service;
    }
}
