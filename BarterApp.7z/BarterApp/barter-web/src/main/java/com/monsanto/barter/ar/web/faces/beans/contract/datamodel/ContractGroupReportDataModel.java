package com.monsanto.barter.ar.web.faces.beans.contract.datamodel;

import com.monsanto.barter.ar.business.service.ContractGroupReportFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ContractGroupReportDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;


/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 10/07/14
 * Time: 14:31
 * To change this template use File | Settings | File Templates.
 */
public class ContractGroupReportDataModel extends AbstractDataModel<ContractGroupReportDTO,ContractGroupReportFilter> {

    private ContractService service;

    public ContractGroupReportDataModel(ContractService service, ContractGroupReportFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public ContractGroupReportDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (ContractGroupReportDTO row : page) {
            if (row.getContractId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<ContractGroupReportDTO> loadPage(ContractGroupReportFilter filter, Paging paging) {
        return service.searchForReportGroup(filter, paging);
    }

    @Override
    public Object getRowKey(ContractGroupReportDTO object) {
        return object.getContractId().toString();
    }
}
