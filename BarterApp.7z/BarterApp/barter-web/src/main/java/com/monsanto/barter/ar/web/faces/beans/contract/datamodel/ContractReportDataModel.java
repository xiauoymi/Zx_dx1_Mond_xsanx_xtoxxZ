package com.monsanto.barter.ar.web.faces.beans.contract.datamodel;

import com.monsanto.barter.ar.business.service.ContractReportFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ContractReportDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;


/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 04/07/14
 * Time: 14:31
 * To change this template use File | Settings | File Templates.
 */
public class ContractReportDataModel extends AbstractDataModel<ContractReportDTO,ContractReportFilter> {

    private ContractService service;

    public ContractReportDataModel(ContractService service, ContractReportFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public ContractReportDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (ContractReportDTO row : page) {
            if (row.getContractId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<ContractReportDTO> loadPage(ContractReportFilter filter, Paging paging) {
        return service.searchForExport(filter, paging);
    }

    @Override
    public Object getRowKey(ContractReportDTO object) {
        return object.getContractId().toString();
    }
}
