package com.monsanto.barter.ar.web.faces.beans.delivery;

import com.monsanto.Util.MessageFormatter;
import com.monsanto.barter.ar.business.entity.Delivery;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.dto.FileDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.event.AbortProcessingException;

/**
 * Created by IVERT on 17/09/2014.
 */
public class DeliveryDetail extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(DeliveryDetail.class);

    private Long id;

    private Delivery delivery;

    private DeliveryService service;

    private FileDTO pdf;
    private boolean fromSearch;

    public void init(){
        service = getService(DeliveryService.class);
        delivery = service.get(id);
    }

    public String view(){
        LOG.info(MessageFormatter.format("Start Navigation en VIEW Mode - Class:{0} - id:{1}", getClass().getName(), id));
        init();
        return SUCCESS;
    }

    public String back() {
        LOG.info(MessageFormatter.format("GO BACK  - Class:{0} - id:{1}", getClass().getName(), id));
        cleanUp();
        return SUCCESS;
    }

    private void cleanUp() {
        delivery = null;
        id = null;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    public Delivery getDelivery() {
        return delivery;
    }

    public void generatePDF() {
        LOG.debug("START generating PDF");
        try {
            setPdf(service.getPDF(delivery,GrowerPortalDocumentType.DELIVERY));
        } catch (Exception e) {
            LOG.error("Unexpected error: ", e);
            addMessage(e);
            throw new AbortProcessingException(e);
        }
    }

    public StreamedContent getPdfFile() {
        LOG.debug("START DOWNLOAD pdf named: {}.pdf", pdf.getFileName());
        return new DefaultStreamedContent(pdf.getStreamFileContent(), pdf.getMimeType(), pdf.getFileName());
    }

    public FileDTO getPdf() {
        return pdf;
    }

    public void setPdf(FileDTO pdf) {
        this.pdf = pdf;
    }

    public boolean isFromSearch() {
        return fromSearch;
    }

    public void setFromSearch(boolean fromSearch) {
        this.fromSearch = fromSearch;
    }
}
