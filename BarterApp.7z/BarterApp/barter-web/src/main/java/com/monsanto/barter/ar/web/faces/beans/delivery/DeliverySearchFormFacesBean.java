package com.monsanto.barter.ar.web.faces.beans.delivery;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.filter.DeliveryFilter;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.delivery.datamodel.DeliveryDataModel;
import com.monsanto.barter.ar.web.faces.beans.delivery.datamodel.DeliveryWithUnloadsDataModel;
import com.monsanto.barter.ar.web.faces.beans.search.SearchBase;
import org.apache.poi.hssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by IVERT on 18/09/2014.
 */
public class DeliverySearchFormFacesBean extends SearchBase<DeliveryDataModel, DeliveryFilter, DeliveryService> {

    private static final Logger LOG = LoggerFactory.getLogger(DeliverySearchFormFacesBean.class);

    private List<MaterialLas> materialLasList;
    private MaterialLasService materialLasService;
    private PortService portService;
    private PortDestinationDTO portDestination;
    private DeliveryWithUnloadsDataModel searchResultExport;

    public static final int FIRST_HEADER_INDEX = 0;
    public static final int FIRST_VALUE_HEADER_INDEX = 1;
    public static final int SECOND_HEADER_INDEX = 2;
    public static final int SECOND_VALUE_HEADER_INDEX = 3;
    public static final int THIRD_HEADER_INDEX = 4;
    public static final int THIRD_VALUE_HEADER_INDEX = 5;
    public static final int FOURTH_HEADER_INDEX = 6;
    public static final int FOURTH_VALUE_HEADER_INDEX = 7;
    private static final String EXPORT_LABEL_SEPARATOR= ":";
    private static final String CREATION_DATE = "label.search.filters.delivery.creationDate";
    private static final int HEADER_OFFSET = 3;


    @Override
    protected void initFilter() {
        filter = new DeliveryFilter();
        portDestination = null;
    }

    @Override
    protected void initServices() {
        service = getService(DeliveryService.class);
        materialLasService = getService(MaterialLasService.class);
        portService = getService(PortService.class);
    }

    @Override
    protected void loadComponents() {
        LOG.debug("loadCombos.");
        try {
            materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getCreationDateFrom() != null && filter.getCreationDateTo() != null && filter.getCreationDateFrom().after(filter.getCreationDateTo())) {
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    @Override
    protected void initSearch() {
        LOG.debug("Search.");
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));
        if (portDestination != null) {
            filter.setDeliveryCity(portDestination);
        }
        searchResult = new DeliveryDataModel(service, filter);
        searchResultExport = new DeliveryWithUnloadsDataModel(service,filter);
    }

    public void preProcessXLS(Object document) {
        searchResultExport.setFixedSortField(searchResult.getPaging().getSortField());
        searchResultExport.setFixedSortOrder(searchResult.getPaging().getSortOrder());
    }

    @Override
    protected void createHeader(HSSFWorkbook wb) {
        setHeaderOffset(HEADER_OFFSET);
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
    }

    protected void createHeaderFirstRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), getHeaderOffset()-1);
        HSSFRow row = sheet.createRow(0);

        HSSFCell cell7 = row.createCell(FOURTH_VALUE_HEADER_INDEX);
        cell7.setCellStyle(getFilterCellStyle());

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.formNumber")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getFormNumber());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.cac")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getCac());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.depositor")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,THIRD_VALUE_HEADER_INDEX,filter.getDepositor());

        createCellFor(row,FOURTH_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.crop")+EXPORT_LABEL_SEPARATOR);

        if (filter.getCropType() != null) {
            cell7.setCellValue(filter.getCropType().getCommercialText());
        }else{
            cell7.setCellValue("");
        }

    }

    protected void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(1);
        HSSFCell cell1 = row.createCell(FIRST_VALUE_HEADER_INDEX);
        cell1.setCellStyle(getFilterCellStyle());
        HSSFCell cell7 = row.createCell(FOURTH_VALUE_HEADER_INDEX);
        cell7.setCellStyle(getFilterCellStyle());

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.deliveryCity")+EXPORT_LABEL_SEPARATOR);
        if (filter.getDeliveryCity() != null) {
            cell1.setCellValue(filter.getDeliveryCity().getDescription());
        } else {
            cell1.setCellValue("");
        }

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.docNumber")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getDocNumber());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle(CREATION_DATE) + " "+
                getMessageBundle("ar.barter.calendar.from")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,THIRD_VALUE_HEADER_INDEX,filter.getCreationDateFrom());

        createCellFor(row,FOURTH_HEADER_INDEX,getMessageBundle(CREATION_DATE)+ " "+
                getMessageBundle("ar.barter.calendar.to")+ EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FOURTH_VALUE_HEADER_INDEX,filter.getCreationDateTo());

    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public DeliveryWithUnloadsDataModel getSearchResultExport() {
        return searchResultExport;
    }

    public void setSearchResultExport(DeliveryWithUnloadsDataModel searchResultExport) {
        this.searchResultExport = searchResultExport;
    }
}