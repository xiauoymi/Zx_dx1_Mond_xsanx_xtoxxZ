package com.monsanto.barter.ar.web.faces.beans.delivery.datamodel;

import com.monsanto.barter.ar.business.filter.DeliveryFilter;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.DeliveryView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;


/**
 * @author IVERT
 */
public class DeliveryDataModel extends AbstractDataModel<DeliveryView,DeliveryFilter> {

    private DeliveryService service;

    public DeliveryDataModel(DeliveryService service, DeliveryFilter filter) {
        super(filter);
        this.service = service;
    }


    @Override
    public DeliveryView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (DeliveryView row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    public DeliveryView getRowData(Long rowKey) {
        return getRowData(rowKey.toString());
    }

    @Override
    protected Recordset<DeliveryView> loadPage(DeliveryFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public Object getRowKey(DeliveryView object) {
        return object.getFormNumber();
    }

    public DeliveryService getService() {
        return service;
    }
}
