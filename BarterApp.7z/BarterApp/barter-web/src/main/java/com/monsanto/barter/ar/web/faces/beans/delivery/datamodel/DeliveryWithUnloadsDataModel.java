package com.monsanto.barter.ar.web.faces.beans.delivery.datamodel;

import com.monsanto.barter.ar.business.filter.DeliveryFilter;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.DeliveryView;

/**
 * @author VNBARR
 */
public class DeliveryWithUnloadsDataModel extends DeliveryDataModel {

    public DeliveryWithUnloadsDataModel(DeliveryService service, DeliveryFilter filter) {
        super(service, filter);
    }

    @Override
    protected Recordset<DeliveryView> loadPage(DeliveryFilter filter, Paging paging) {
        return getService().searchWithUnloads(filter, paging);
    }
}
