package com.monsanto.barter.ar.web.faces.beans.detaildownload;

import com.monsanto.barter.ar.business.entity.enumerated.BaseDocumentType;
import com.monsanto.barter.ar.business.service.RemoteService;
import com.monsanto.barter.ar.business.service.dto.FileDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.event.AbortProcessingException;

/**
 * @author JASANC5 on 11/5/2014
 */
public abstract class DetailDownload extends ArBaseJSF{

    private static final Logger LOG = LoggerFactory.getLogger(DetailDownload.class);
    private FileDTO pdf;

    protected abstract BaseDocumentType getDocType();
    protected abstract String getSAPId();

    public FileDTO getPdf() {
        return pdf;
    }

    public void setPdf(FileDTO pdf) {
        this.pdf = pdf;
    }

    public StreamedContent getPdfFile() {
        if (pdf!=null){
            LOG.debug("START DOWNLOAD pdf named: {}.pdf", pdf.getFileName());
            return new DefaultStreamedContent(pdf.getStreamFileContent(), pdf.getMimeType(), pdf.getFileName());
        }

        return null;
    }

    public void generatePDF() {
       generatePDF(getDocType(), getSAPId());
    }

    public void generatePDF(BaseDocumentType documentType,String sapId) {
        LOG.debug("START get remote pdf from SAP");
        try {
            pdf = getService(RemoteService.class).getPdf(documentType, sapId);
        } catch (Exception e) {
            LOG.error("Unexpected error: ", e);
            addMessage("No fue posible encontrar el PDF en SAP");
        }
    }

}
