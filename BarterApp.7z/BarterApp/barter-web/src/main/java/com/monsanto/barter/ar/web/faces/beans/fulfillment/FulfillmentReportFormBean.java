package com.monsanto.barter.ar.web.faces.beans.fulfillment;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.FulfillmentReportFilter;
import com.monsanto.barter.ar.business.service.FulfillmentReportService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 20/11/14
 * Time: 11:45
 * To change this template use File | Settings | File Templates.
 */
public class FulfillmentReportFormBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(FulfillmentReportFormBean.class);
    private FulfillmentReportFilter filter;
    private MaterialLasService materialLasService;
    private FulfillmentReportService fulfillmentReportService;
    private List<MaterialLas> materialLasList;

    public String begin() {
        filter = new FulfillmentReportFilter();
        materialLasService = getService(MaterialLasService.class);
        fulfillmentReportService = getService(FulfillmentReportService.class);
        loadCombos();
        return SUCCESS;
    }

    protected void loadCombos() {
        LOG.debug("loadCombos.");
        try {
            materialLasList=materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getTurnDateFrom() == null || filter.getTurnDateTo() == null || filter.getTurnDateFrom().after(filter.getTurnDateTo())) {
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }


    public String report() {
        LOG.debug("Report.");
        if (validateFilters()) {
            filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));
            if(!StringUtils.isBlank(filter.getEmailTo())){
                filter.setEmailTo(getLoggedUser().getEmail()+","+filter.getEmailTo());
            } else {
                filter.setEmailTo(getLoggedUser().getEmail());
            }
            fulfillmentReportService.createReportAndSendMail(filter);
            return "report-result";
        }
        LOG.debug("Returning null.");
        return null;
    }


    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public FulfillmentReportFilter getFilter() {
        return filter;
    }

}
