package com.monsanto.barter.ar.web.faces.beans.groweraccount;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.filter.GrowerContractFilter;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.LiquidationService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.dto.GrowerContractView;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;
import com.monsanto.barter.ar.business.service.dto.LiquidationView;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.growercontract.datamodel.GrowerContractDataModel;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author JPBENI
 */
public class GrowerAccountFaces extends ArBaseJSF {

    public static final String MY_GROWER_ACCOUNT = "myGrowerAccount";
    public static final String A_GROWER_ACCOUNT = "aGrowerAccount";

    private GrowerContractService growerContractService;

    private boolean allowGrowerSelection = false;
    private CustomerCC grower;
    private GrowerContractFilter filter = new GrowerContractFilter();
    private GrowerContractView selectedGrowerContract = null;
    private GrowerContractDataModel activeContracts;
    private List<MaterialLas> materialLasList;
    private static final Logger LOG = LoggerFactory.getLogger(GrowerAccountFaces.class);
    private MaterialLasService materialLasService;
    private LiquidationService liquidationService;
    private List<LiquidationView> selectedGrowerContractLiquidations;

    private void init() {
        this.growerContractService = getService(GrowerContractService.class);
        this.materialLasService = getService(MaterialLasService.class);
        this.liquidationService = getService(LiquidationService.class);
        grower = getService(CustomerCC.class);
        loadComponents();
        this.selectedGrowerContract = null;
    }

    protected void loadComponents() {
        LOG.debug("loadCombos.");
        try {
            materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public String beginMyAccount() {
        init();
        filter = new GrowerContractFilter();
        setGrowerInFilter();
        allowGrowerSelection = false;
        initActiveContractsList();
        return MY_GROWER_ACCOUNT;
    }

    public void setGrowerInFilter() {
        UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        filter.setGrower(user.getMainGrower().getDocument());
    }

    public String beginAccount() {
        init();
        //UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        //set current user logged in
        /*grower.setCustomer(user.get);*/
        allowGrowerSelection = false;
        initActiveContractsList();
        return MY_GROWER_ACCOUNT;
    }

    public String beginGrowerAccount(){
        init();
        filter = new GrowerContractFilter();
        activeContracts = new GrowerContractDataModel(null, null);
        allowGrowerSelection = true;
        return A_GROWER_ACCOUNT;
    }

    public void newSearch(){
        this.filter = new GrowerContractFilter();
        grower.clear();
        activeContracts = new GrowerContractDataModel(null, null);
    }

    public void initActiveContractsList() {
        filter.setCrop(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropId()));
        if (grower != null && grower.getSelectedCustomer() != null){
            filter.setGrower(grower.getSelectedCustomerIdentifier());
        }
        this.activeContracts = new GrowerContractDataModel(growerContractService, filter);
        LOG.debug("Search -> Result");
    }

    public void setSelectedGrowerContract(GrowerContractView selectedGrowerContract) {
        this.selectedGrowerContractLiquidations = null;
        this.selectedGrowerContract = selectedGrowerContract;
        if (selectedGrowerContract != null) {
            this.selectedGrowerContractLiquidations = liquidationService.getLiquidationsByGrowerContract(selectedGrowerContract.getId());
        }
    }

    public GrowerContractView getSelectedGrowerContract() {
        return selectedGrowerContract;
    }

    public boolean getAllowGrowerSelection() {
        return allowGrowerSelection;
    }

    public GrowerContractDataModel getActiveContracts() {
        return activeContracts;
    }

    public GrowerContractFilter getFilter() {
        return filter;
    }

    public GrowerPortalBalanceType[] getContractTypes(){
        return new GrowerPortalBalanceType[]{GrowerPortalBalanceType.TO_FIX,GrowerPortalBalanceType.PRICE};
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public CustomerCC getGrower() {
        return grower;
    }

    public List<LiquidationView> getSelectedGrowerContractLiquidations() {
        return selectedGrowerContractLiquidations;
    }

    public boolean getAllowPosFilter(){
        UserDecorator loggedInUser = GlobalBarterSecurityHelper.getLoggedInUser();
        if (!loggedInUser.isParticipant()){
            return true;
        } else {
            return false;
        }
    }
}
