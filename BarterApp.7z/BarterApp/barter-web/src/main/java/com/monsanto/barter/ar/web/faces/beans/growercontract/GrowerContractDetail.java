package com.monsanto.barter.ar.web.faces.beans.growercontract;

import com.monsanto.Util.MessageFormatter;
import com.monsanto.barter.ar.business.entity.GrowerContract;
import com.monsanto.barter.ar.business.entity.Liquidation;
import com.monsanto.barter.ar.business.entity.enumerated.BaseDocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.dto.LiquidationView;
import com.monsanto.barter.ar.web.faces.beans.detaildownload.DetailDownload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IVERT on 17/09/2014.
 */
public class GrowerContractDetail extends DetailDownload {

    private static final Logger LOG = LoggerFactory.getLogger(GrowerContractDetail.class);
    private Long id;
    private GrowerContract growerContract;
    private boolean fromSearch;

    public void init(){
        GrowerContractService growerContractService = getService(GrowerContractService.class);
        growerContract = growerContractService.get(id);
    }

    public String view(){
        LOG.info(MessageFormatter.format("Start Navigation en VIEW Mode - Class:{0} - id:{1}", getClass().getName(), id));
        init();
        return SUCCESS;
    }

    public String back() {
        LOG.info(MessageFormatter.format("GO BACK  - Class:{0} - id:{1}", getClass().getName(), id));
        cleanUp();
        return SUCCESS;
    }

    private void cleanUp() {
        growerContract = null;
        id = null;
    }

    public GrowerContract getGrowerContract() {
        return growerContract;
    }

    public List<LiquidationView> getLiquidationList(){
        List<LiquidationView> liquidationViewList = new ArrayList<LiquidationView>();
        if (growerContract.getLiquidations() != null){
            for (Liquidation liquidation : growerContract.getLiquidations()){
                liquidationViewList.add(new LiquidationView(liquidation));
            }
            return liquidationViewList;
        }
        return new ArrayList<LiquidationView>();
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    protected BaseDocumentType getDocType() {
        return GrowerPortalDocumentType.GROWER_CONTRACT;
    }

    @Override
    protected String getSAPId() {
        return growerContract.getNumber();
    }

    public void downloadInvoice(){
        try{
            generatePDF(GrowerPortalDocumentType.INVOICE,growerContract.getInvoiceSapId());
        }
        catch (Exception ex){
            LOG.error("An error occurred retrieving the document in sap: ", ex);
 }
    }

    public boolean isFromSearch() {
        return fromSearch;
    }

    public void setFromSearch(boolean fromSearch) {
        this.fromSearch = fromSearch;
    }
}