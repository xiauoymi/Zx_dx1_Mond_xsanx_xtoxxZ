package com.monsanto.barter.ar.web.faces.beans.growercontract;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.filter.GrowerContractFilter;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.growercontract.datamodel.GrowerContractDataModel;
import com.monsanto.barter.ar.web.faces.beans.search.SearchBase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author IVERT
 */
public class GrowerContractSearchFormFacesBean extends SearchBase<GrowerContractDataModel,GrowerContractFilter,GrowerContractService> {

    private static final Logger LOG = LoggerFactory.getLogger(GrowerContractSearchFormFacesBean.class);
    private static final int FIRST_INDEX = 0;
    private static final int FIRST_VALUE_HEADER_INDEX = 1;
    private static final int SECOND_HEADER_INDEX = 2;
    private static final int SECOND_VALUE_HEADER_INDEX = 3;
    private static final int THIRD_HEADER_INDEX = 4;
    private static final int THIRD_VALUE_HEADER_INDEX = 5;
    private static final String EXPORT_LABEL_SEPARATOR= ":";
    public static final String LABEL_SEARCH_FILTERS_GROWER_CONTRACT_CREATION_DATE = "label.search.filters.growerContract.creationDate";
    private static final String ERROR_DATE = "label.search.error.dateError";
    public static final String AR_BARTER_CALENDAR_FROM = "ar.barter.calendar.from";
    public static final String AR_BARTER_CALENDAR_TO = "ar.barter.calendar.to";
    private static final int HEADER_OFFSET = 4;

    private MaterialLasService materialLasService;
    private PortService portService;
    private List<MaterialLas> materialLasList;

    @Override
    protected void initFilter() {
        filter = new GrowerContractFilter();
    }

    @Override
    protected void initServices() {
        service = getService(GrowerContractService.class);
        materialLasService = getService(MaterialLasService.class);
        portService = getService(PortService.class);
    }

    @Override
    protected void loadComponents() {
        LOG.debug("loadCombos.");
        try {
            materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getCreationDateFrom() != null && filter.getCreationDateTo() != null && filter.getCreationDateFrom().after(filter.getCreationDateTo())) {
            addMessage(getMessageBundle(ERROR_DATE));
            return false;
        }

        if (filter.getDeliveryDateFrom() != null && filter.getDeliveryDateTo() != null && filter.getDeliveryDateFrom().after(filter.getDeliveryDateTo())) {
            addMessage(getMessageBundle(ERROR_DATE));
            return false;
        }
        return true;
    }

    @Override
    protected void initSearch() {
        filter.setCrop(MonCollectionsUtils.findByPrimaryKey(materialLasList,filter.getCropId()));
        searchResult = new GrowerContractDataModel(service, filter);
    }

    @Override
    protected void createHeader(HSSFWorkbook wb) {
        setHeaderOffset(HEADER_OFFSET);
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(2);
        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());
        createCellFor(row,FIRST_INDEX,getMessageBundle("label.search.filters.growerContract.dueDate") + " "+
                getMessageBundle(AR_BARTER_CALENDAR_FROM)+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getDeliveryDateFrom());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.growerContract.dueDate")+ " "+
                getMessageBundle(AR_BARTER_CALENDAR_TO)+ EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getDeliveryDateTo());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("label.search.filters.growerContract.port")+EXPORT_LABEL_SEPARATOR);

        if (filter.getPort() != null) {
            cell5.setCellValue(filter.getPort().getDescription());
        }else{
            cell5.setCellValue("");
        }
    }

    private void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(1);
        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());
        createCellFor(row, FIRST_INDEX, getMessageBundle(LABEL_SEARCH_FILTERS_GROWER_CONTRACT_CREATION_DATE) + " " +
                getMessageBundle(AR_BARTER_CALENDAR_FROM) + EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getCreationDateFrom());

        createCellFor(row, SECOND_HEADER_INDEX, getMessageBundle(LABEL_SEARCH_FILTERS_GROWER_CONTRACT_CREATION_DATE) + " " +
                getMessageBundle(AR_BARTER_CALENDAR_TO) + EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getCreationDateTo());

        createCellFor(row, THIRD_HEADER_INDEX, getMessageBundle("label.search.filters.growerContract.crop") + EXPORT_LABEL_SEPARATOR);

        if (filter.getCrop() != null) {
            cell5.setCellValue(filter.getCrop().getCommercialText());
        }else{
            cell5.setCellValue("");
        }
    }

    private void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), getHeaderOffset()-1);
        HSSFRow row = sheet.createRow(0);

        createCellFor(row, FIRST_INDEX, getMessageBundle("label.search.filters.growerContract.type") + EXPORT_LABEL_SEPARATOR);

        if (filter.getType() != null) {
            createCellFor(row, FIRST_VALUE_HEADER_INDEX, getMessageBundle(filter.getType().toString()));
        } else {
            createCellFor(row, FIRST_VALUE_HEADER_INDEX, "");
        }

        createCellFor(row, SECOND_HEADER_INDEX, getMessageBundle("label.search.filters.growerContract.grower") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, SECOND_VALUE_HEADER_INDEX, filter.getGrower());

        createCellFor(row, THIRD_HEADER_INDEX, getMessageBundle("label.search.filters.growerContract.number") + EXPORT_LABEL_SEPARATOR);
        createCellFor(row, THIRD_VALUE_HEADER_INDEX, filter.getContractNumber());
    }

    public GrowerPortalBalanceType[] getContractTypes(){
        return new GrowerPortalBalanceType[]{GrowerPortalBalanceType.TO_FIX,GrowerPortalBalanceType.PRICE};
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public List<PortDestinationDTO> portAutocomplete(String query) {
        return portService.search(query);
    }

    public boolean isGrower(){
        return GlobalBarterSecurityHelper.getLoggedInUser().isGrower();
    }

    public boolean isPos(){
        return GlobalBarterSecurityHelper.getLoggedInUser().isPos();
    }


}
