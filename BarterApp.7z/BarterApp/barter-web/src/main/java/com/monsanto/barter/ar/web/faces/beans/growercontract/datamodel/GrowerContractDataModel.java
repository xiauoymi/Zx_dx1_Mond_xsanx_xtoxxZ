package com.monsanto.barter.ar.web.faces.beans.growercontract.datamodel;

import com.monsanto.barter.ar.business.filter.GrowerContractFilter;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.GrowerContractView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

import java.util.ArrayList;


/**
 * @author IVERT
 */
public class GrowerContractDataModel extends AbstractDataModel<GrowerContractView,GrowerContractFilter> {

    private GrowerContractService service;

    public GrowerContractDataModel(GrowerContractService service, GrowerContractFilter filter) {
        super(filter);
        this.service = service;
    }

    public GrowerContractView getRowData(Long rowKey) {
        for (GrowerContractView row : page) {
            if (row.getId().equals(rowKey)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public GrowerContractView getRowData(String rowKey) {
        return getRowData(Long.valueOf(rowKey));
    }

    @Override
    protected Recordset<GrowerContractView> loadPage(GrowerContractFilter filter, Paging paging) {
        if (service != null){
            return service.search(filter, paging);
        } else {
            return new Recordset<GrowerContractView>(new ArrayList<GrowerContractView>(),0);
        }
    }

    @Override
    public Object getRowKey(GrowerContractView object) {
        return object.getId();
    }
}
