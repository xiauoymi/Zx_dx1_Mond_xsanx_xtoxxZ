package com.monsanto.barter.ar.web.faces.beans.growerdocuments.composite;


import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.ConditioningService;
import com.monsanto.barter.ar.business.service.LiquidationUnloadService;
import com.monsanto.barter.ar.business.service.UnloadService;
import com.monsanto.barter.ar.business.service.dto.ConditioningView;
import com.monsanto.barter.ar.business.service.dto.DeliveryView;
import com.monsanto.barter.ar.business.service.dto.LiquidationView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.model.ListDataModel;


/**
 * @author VNBARR
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class GrowerDocumentsCC extends ArBaseJSF{
    @Autowired
    private LiquidationUnloadService liquidationUnloadService;
    @Autowired
    private UnloadService unloadService;
    @Autowired
    private ConditioningService conditioningService;

    private Long documentId;
    private DocumentType documentType;
    private ListDataModel<LiquidationView> liquidations;
    private ListDataModel<DeliveryView> deliveries;
    private ListDataModel<ConditioningView> conditionings;

    public void begin(){
        liquidations = new ListDataModel<LiquidationView>(liquidationUnloadService.getLiquidationsByDocumentIdentifier(documentType,documentId));
        deliveries   = new ListDataModel<DeliveryView>(unloadService.getDeliveriesByDocumentIdentifier(documentType,documentId));
        conditionings= new ListDataModel<ConditioningView>(conditioningService.getConditioningsByDocumentIdentifier(documentType,documentId));
    }

    public void setDocumentType(DocumentType documentType) {
        this.documentType = documentType;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public ListDataModel<DeliveryView> getDeliveries() {
        return deliveries;
    }

    public ListDataModel<LiquidationView> getLiquidations() {
        return liquidations;
    }

    public ListDataModel<ConditioningView> getConditionings() {
        return conditionings;
    }
}
