package com.monsanto.barter.ar.web.faces.beans.growerliquidation;

import com.monsanto.Util.MessageFormatter;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.BaseDocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.LiquidationType;
import com.monsanto.barter.ar.business.service.LiquidationService;
import com.monsanto.barter.ar.web.faces.beans.detaildownload.DetailDownload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by RECRUZ on 18/09/2014.
 */
public class LiquidationDetail extends DetailDownload {

    private static final Logger LOG = LoggerFactory.getLogger(LiquidationDetail.class);
    private Long id;
    private Liquidation liquidation;
    private List<Liquidation> liquidations = new ArrayList<Liquidation>();
    private List<GrowerContract> contracts = new ArrayList<GrowerContract>();
    private List<LiquidationUnload> unloads = new ArrayList<LiquidationUnload>();
    private boolean fromSearch;

    public void init(){
        LiquidationService liquidationService = getService(LiquidationService.class);
        liquidations.clear();
        liquidation = liquidationService.get(id);
        contracts.clear();
        unloads.clear();
        contracts.add(liquidation.getContract());
        if (isFinalLiquidation()){
            liquidations.add(((FinalLiquidation) liquidation).getOriginalLiquidation());
        }else{
            PartialLiquidation partialLiquidation = (PartialLiquidation) liquidation;
            liquidations.addAll(partialLiquidation.getFinalLiquidations());
            unloads.addAll(partialLiquidation.getLiquidationUnloads());
        }
    }

    public String view(){
        LOG.info(MessageFormatter.format("Start Navigation en VIEW Mode - Class:{0} - id:{1}", getClass().getName(), id));
        init();
        return SUCCESS;
    }

    public String back() {
        LOG.info(MessageFormatter.format("GO BACK  - Class:{0} - id:{1}", getClass().getName(), id));
        cleanUp();
        return SUCCESS;
    }

    private void cleanUp() {
        liquidation = null;
        id = null;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Liquidation getLiquidation() {
        return liquidation;
    }


    public Float getGrossWeight(){

        if (isFinalLiquidation()){
            return ((FinalLiquidation)liquidation).getGrossWeight();
        }

        return null;
    }

    public String getBrokerInvolved(){

        if (isFinalLiquidation()){
            return ((FinalLiquidation)liquidation).getBrokerInvolved();
        }

        return null;
    }

    public boolean isFinalLiquidation() {
        return liquidation.getType().equals(LiquidationType.FINAL);
    }


    @Override
    protected BaseDocumentType getDocType() {
        if (isFinalLiquidation()){
            return GrowerPortalDocumentType.FINAL_LIQUIDATION;
        }
        return GrowerPortalDocumentType.PARTIAL_LIQUIDATION;
    }

    @Override
    protected String getSAPId() {
        return liquidation.getInvoice();
    }

    public List<Liquidation> getLiquidations() {
        return liquidations;
    }

    public List<GrowerContract> getContracts() {
        return contracts;
    }

    public List<LiquidationUnload> getUnloads() {
        return unloads;
    }

    public boolean isFromSearch() {
        return fromSearch;
    }

    public void setFromSearch(boolean fromSearch) {
        this.fromSearch = fromSearch;
    }
}




