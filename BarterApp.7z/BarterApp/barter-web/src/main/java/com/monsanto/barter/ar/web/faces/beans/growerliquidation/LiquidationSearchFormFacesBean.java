package com.monsanto.barter.ar.web.faces.beans.growerliquidation;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.SAPInvoiceType;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.LiquidationType;
import com.monsanto.barter.ar.business.filter.LiquidationFilter;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.LiquidationService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.SapInvoiceTypeService;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.growerliquidation.datamodel.LiquidationDataModel;
import com.monsanto.barter.ar.web.faces.beans.search.SearchBase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * @author RECRUZ
 */
public class LiquidationSearchFormFacesBean extends SearchBase<LiquidationDataModel, LiquidationFilter, LiquidationService> {

    private static final Logger LOG = LoggerFactory.getLogger(LiquidationSearchFormFacesBean.class);

    private List<MaterialLas> materialLasList;

    private List<SAPInvoiceType> sapDocumentTypes;

    private SapInvoiceTypeService sapInvoiceTypeService;

    private MaterialLasService materialLasService;

    private LiquidationType[] liquidationTypes;

    private static final String ERROR_DATE = "label.search.error.dateError";

    private static final int HEADER_OFFSET = 4;
    public static final int FIRST_HEADER_INDEX = 0;
    public static final int FIRST_VALUE_HEADER_INDEX = 1;
    public static final int SECOND_HEADER_INDEX = 2;
    public static final int SECOND_VALUE_HEADER_INDEX = 3;
    public static final int THIRD_HEADER_INDEX = 4;
    public static final int THIRD_VALUE_HEADER_INDEX = 5;
    public static final int FOURTH_HEADER_INDEX = 6;
    public static final int FOURTH_VALUE_HEADER_INDEX = 7;
    private static final String EXPORT_LABEL_SEPARATOR= ":";
    private static final String CREATED_DATE = "label.search.filters.liquidation.createdDate";
    private static final String PAYMENT_DATE = "label.search.filters.liquidation.paymentDate";
    private static final String CALENDAR_FROM= "ar.barter.calendar.from";
    private static final String CALENDAR_TO= "ar.barter.calendar.to";

    private UserDecorator user;

    @Override
    protected void initFilter() {
        filter = new LiquidationFilter();
        user = GlobalBarterSecurityHelper.getLoggedInUser();
    }

    @Override
    protected void initServices() {
        service = getService(LiquidationService.class);
        materialLasService = getService(MaterialLasService.class);
        sapInvoiceTypeService = getService(SapInvoiceTypeService.class);
    }

    @Override
    protected void loadComponents() {
        LOG.debug("loadCombos.");
        liquidationTypes = LiquidationType.values();
        try {
            materialLasList = materialLasService.findAll();
            sapDocumentTypes = sapInvoiceTypeService.getSapDocumentTypes();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getCreatedDateFrom() != null && filter.getCreatedDateTo() != null && filter.getCreatedDateFrom().after(filter.getCreatedDateTo())) {
            addMessage(getMessageBundle(ERROR_DATE));
            return false;
        }

        if (filter.getPaymentDateFrom() != null && filter.getPaymentDateTo() != null && filter.getPaymentDateFrom().after(filter.getPaymentDateTo())) {
            addMessage(getMessageBundle(ERROR_DATE));
            return false;
        }
        return true;
    }

    @Override
    protected void initSearch() {
        LOG.debug("Search.");
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));
        searchResult = new LiquidationDataModel(service, filter);
    }

    @Override
    protected void createHeader(HSSFWorkbook wb) {
        setHeaderOffset(HEADER_OFFSET);
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(2);

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle(CREATED_DATE) + " "+
                getMessageBundle(CALENDAR_FROM)+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getCreatedDateFrom());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle(CREATED_DATE)+ " "+
                getMessageBundle(CALENDAR_TO)+ EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getCreatedDateTo());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle(PAYMENT_DATE) + " "+
                getMessageBundle(CALENDAR_FROM)+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,THIRD_VALUE_HEADER_INDEX,filter.getPaymentDateFrom());

        createCellFor(row,FOURTH_HEADER_INDEX,getMessageBundle(PAYMENT_DATE)+ " "+
                getMessageBundle(CALENDAR_TO)+ EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FOURTH_VALUE_HEADER_INDEX,filter.getPaymentDateTo());
    }

    private void createHeaderSecondRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(1);
        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());


        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("label.search.filters.liquidation.pos")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getPos());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.liquidation.coe")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getCoe());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("label.search.filters.liquidation.type")+EXPORT_LABEL_SEPARATOR);
        if (filter.getType() != null) {
            cell5.setCellValue(getMessageBundle(filter.getType().toString()));
        } else {
            cell5.setCellValue("");
        }


    }

    private void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), getHeaderOffset()-1);
        HSSFRow row = sheet.createRow(0);

        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("label.search.filters.liquidation.grower")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,filter.getGrower());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.liquidation.harvest")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,filter.getHarvest());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.crop")+EXPORT_LABEL_SEPARATOR);

        if (filter.getCropType() != null) {
            cell5.setCellValue(filter.getCropType().getCommercialText());
        }else{
            cell5.setCellValue("");
        }
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public List<SAPInvoiceType> getSapDocumentTypes() {
        return sapDocumentTypes;
    }

    public LiquidationType[] getLiquidationTypes() {
        return liquidationTypes;
    }

    public void setLiquidationTypes(LiquidationType[] liquidationTypes) {
        this.liquidationTypes = Arrays.copyOf(liquidationTypes, liquidationTypes.length);
    }

    public boolean isGrower(){
        return user.isGrower();
    }

    public boolean isPos(){
        return user.isPos();
    }

}