package com.monsanto.barter.ar.web.faces.beans.growerliquidation.datamodel;

import com.monsanto.barter.ar.business.filter.LiquidationFilter;
import com.monsanto.barter.ar.business.service.LiquidationService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.LiquidationView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;


/**
 * @author RECRUZ
 */
public class LiquidationDataModel extends AbstractDataModel<LiquidationView,LiquidationFilter> {

        private LiquidationService service;

        public LiquidationDataModel(LiquidationService service, LiquidationFilter filter) {
            super(filter);
            this.service = service;
        }

        @Override
        public LiquidationView getRowData(String rowKey) {
            for (LiquidationView row : page) {
                if (row.getId().equals(rowKey)) {
                    return row;
                }
            }
            return null;
        }

    @Override
    protected Recordset<LiquidationView> loadPage(LiquidationFilter filter, Paging paging) {
        return service.search(filter,paging);
    }

    @Override
        public Object getRowKey(LiquidationView object) {
            return object.getId();
        }

    }

