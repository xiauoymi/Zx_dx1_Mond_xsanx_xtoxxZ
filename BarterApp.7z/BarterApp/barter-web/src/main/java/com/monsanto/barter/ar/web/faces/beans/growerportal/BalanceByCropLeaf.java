package com.monsanto.barter.ar.web.faces.beans.growerportal;

import org.primefaces.model.TreeNode;

/**
 * @author JASANC5 on 11/10/2014
 */
public class BalanceByCropLeaf {

    private TreeNode materialNode;
    private String cropTypeDescription;
    private Long cropTypeId;
    private Double fixedValue;
    private Double notFixedValue;
    private Double fixedValueUSD;
    private Double notFixedValueUSD;
    private Double inProcess;
    private Double appliedInCrop;
    private Double okYield;
    private Double pendingToApply;

    public BalanceByCropLeaf(TreeNode materialNode, Long cropTypeId, String cropTypeDescription, Double fixedValue, Double notFixedValue,
                             Double fixedValueUSD, Double notFixedValueUSD, Double inProcess, Double appliedInCrop, Double okYield, Double pendingToApply) {
        this.cropTypeId=cropTypeId;
        this.materialNode = materialNode;
        this.cropTypeDescription = cropTypeDescription;
        this.appliedInCrop = appliedInCrop;
        this.okYield = okYield;
        this.inProcess = inProcess;
        this.fixedValue = fixedValue;
        this.notFixedValue = notFixedValue;
        this.fixedValueUSD = fixedValueUSD;
        this.notFixedValueUSD=notFixedValueUSD;
        this.pendingToApply = pendingToApply;
    }

    public TreeNode getMaterialNode() {
        return materialNode;
    }

    public void setMaterialNode(TreeNode materialNode) {
        this.materialNode = materialNode;
    }

    public String getCropTypeDescription() {
        return cropTypeDescription;
    }

    public void setCropTypeDescription(String cropTypeDescription) {
        this.cropTypeDescription = cropTypeDescription;
    }

    public Double getFixedValue() {
        return fixedValue;
    }

    public void setFixedValue(Double fixedValue) {
        this.fixedValue = fixedValue;
    }

    public Double getNotFixedValue() {
        return notFixedValue;
    }

    public void setNotFixedValue(Double notFixedValue) {
        this.notFixedValue = notFixedValue;
    }

    public Double getInProcess() {
        return inProcess;
    }

    public void setInProcess(Double inProcess) {
        this.inProcess = inProcess;
    }

    public Double getAppliedInCrop() {
        return appliedInCrop;
    }

    public void setAppliedInCrop(Double appliedInCrop) {
        this.appliedInCrop = appliedInCrop;
    }

    public Double getOkYield() {
        return okYield;
    }

    public void setOkYield(Double okYield) {
        this.okYield = okYield;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }

    public Double getFixedValueUSD() {
        return fixedValueUSD;
    }

    public void setFixedValueUSD(Double fixedValueUSD) {
        this.fixedValueUSD = fixedValueUSD;
    }

    public Double getNotFixedValueUSD() {
        return notFixedValueUSD;
    }

    public void setNotFixedValueUSD(Double notFixedValueUSD) {
        this.notFixedValueUSD = notFixedValueUSD;
    }

    public Double getPendingToApply() {
        return pendingToApply;
    }

    public void setPendingToApply(Double pendingToApply) {
        this.pendingToApply = pendingToApply;
    }
}
