package com.monsanto.barter.ar.web.faces.beans.growerportal;

import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;

import java.io.Serializable;

/**
 * @author JPBENI
 */
public class BalanceTreeElement implements Serializable, Comparable<BalanceTreeElement> {

    private Long cropTypeId;
    private String label;
    private Double partial;
    private Double total;
    private String cereal;
    private GrowerPortalBalanceType balanceType;


    public BalanceTreeElement(String label, GrowerPortalBalanceType balanceType, Long cropTypeId, Double partial, Double total, String cereal) {
        this.cropTypeId = cropTypeId;
        this.label = label;
        this.partial = partial;
        this.total = total;
        this.cereal = cereal;
        this.balanceType = balanceType;
    }

    public int compareTo(BalanceTreeElement element) {
        return this.getLabel().compareTo(element.getLabel());
    }

    public String getLabel() {
        return label;
    }

    public Double getPartial() {
        return partial;
    }

    public Double getTotal() {
        return total;
    }

    public String getCereal() {
        return cereal;
    }

    public boolean isViewAccount() {
        return balanceType== null || !balanceType.isUnloadItem();
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public GrowerPortalBalanceType getBalanceType() {
        return balanceType;
    }
}