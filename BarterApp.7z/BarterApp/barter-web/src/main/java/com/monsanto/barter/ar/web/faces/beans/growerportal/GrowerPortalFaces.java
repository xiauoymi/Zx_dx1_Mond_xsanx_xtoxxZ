package com.monsanto.barter.ar.web.faces.beans.growerportal;

import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.GrowerPortalBalancesFilter;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.UnloadService;
import com.monsanto.barter.ar.business.service.dto.GrowerContractView;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalancesView;
import com.monsanto.barter.ar.business.service.dto.UnloadView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import java.util.List;
import java.util.Set;

/**
 * @author JPBENI
 */
public class GrowerPortalFaces extends ArBaseJSF {

    public static final String SELECT_CUSTOMER = "selectCustomer";
    private TreeNode contractsRoot;

    private Double totalTns;

    private String childGrowerId;
    private Set<CustomerLas> childGrowers;

    private GrowerContractService growerContractService;
    private MaterialLasService materialService;
    private UnloadService unloadService;
    private TreeNode selectedNode;
    private List<GrowerContractView> contractViews;
    private List<UnloadView> unloads;
    private CustomerLas grower;

    public String begin() {
        this.materialService = getService(MaterialLasService.class);
        this.growerContractService = getService(GrowerContractService.class);
        this.unloadService = getService(UnloadService.class);
        if(getLoggedUser().isMultipleGrowers()) {
            childGrowers = getLoggedUser().getGrowers();
            return SELECT_CUSTOMER;
        } else {
            grower = GlobalBarterSecurityHelper.getLoggedInUser().getMainGrower();
            contractsRoot = buildRootNode();
            totalTns = 0D;
            createContractsForGrower(grower);
            contractViews = null;
            unloads = null;
            return SUCCESS;
        }

    }

    private TreeNode createContractsForGrower(CustomerLas grower) {
        List<GrowerPortalBalancesView> balances = materialService.getContractsAndDocumentsBalancesGroupByCropType(grower);
        //for each balances we group it by crop type

        for (GrowerPortalBalancesView balance: balances){
            TreeNode materialNode = buildBalanceMaterialNode(contractsRoot,balance.getCropTypeId(), balance.getCropTypeDescription(),balance.getBalanceTns(), balance.getBalanceUsd());
            totalTns += balance.getBalanceTns();
            //for each crop type we look for documents and contracts information to show
            buildContractNodes(new BalanceByCropLeaf(materialNode,balance.getCropTypeId(), balance.getCropTypeDescription(),balance.getContractPriceBalanceTn(),
                    balance.getContractToFixBalanceTn(),balance.getContractPriceBalanceUSD(),balance.getContractToFixBalanceUSD(),
                    balance.getTotalInProcess(), balance.getTotalCertificated(), balance.getTotalYield(), balance.getTotalPendingToApply()));
        }
        return contractsRoot;
    }
    private TreeNode createContracts() {
        List<GrowerPortalBalancesView> balances = materialService.getContractsAndDocumentsBalancesGroupByCropType(null);
        //for each balances we group it by crop type

        for (GrowerPortalBalancesView balance: balances){
            TreeNode materialNode = buildBalanceMaterialNode(contractsRoot,balance.getCropTypeId(), balance.getCropTypeDescription(),balance.getBalanceTns(), balance.getBalanceUsd());
            totalTns += balance.getBalanceTns();
            //for each crop type we look for documents and contracts information to show
            buildContractNodes(new BalanceByCropLeaf(materialNode,balance.getCropTypeId(), balance.getCropTypeDescription(),balance.getContractPriceBalanceTn(),
                    balance.getContractToFixBalanceTn(),balance.getContractPriceBalanceUSD(),balance.getContractToFixBalanceUSD(),
                    balance.getTotalInProcess(), balance.getTotalCertificated(), balance.getTotalYield(), balance.getTotalPendingToApply()));
        }
        return contractsRoot;
    }

    private TreeNode buildRootNode() {
        return new DefaultTreeNode(new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.cereal"), null, null, null, null, null), null);
    }

    private TreeNode buildBalanceMaterialNode(final TreeNode parent, Long cropTypeId, final String material, final Double totalTn, final Double totalUSD) {
        return new DefaultTreeNode(material, new BalanceTreeElement(material, null, cropTypeId, totalTn, totalUSD, material), parent);
    }

    private void buildContractNodes(BalanceByCropLeaf balanceByCropLeaf) {
        String cropType = balanceByCropLeaf.getCropTypeDescription();
        TreeNode parent = balanceByCropLeaf.getMaterialNode();
        Long cropId = balanceByCropLeaf.getCropTypeId();
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.fixed"),GrowerPortalBalanceType.PRICE,cropId, balanceByCropLeaf.getFixedValue(), balanceByCropLeaf.getFixedValueUSD(),  cropType), parent);
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.notFixed"),GrowerPortalBalanceType.TO_FIX,cropId, balanceByCropLeaf.getNotFixedValue(), balanceByCropLeaf.getNotFixedValueUSD(),  cropType), parent);
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.yield"),GrowerPortalBalanceType.TO_YIELD,cropId, balanceByCropLeaf.getOkYield(), null,  cropType), parent);
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.applied.in.crop"),GrowerPortalBalanceType.APPLIED_IN_CROP,cropId, balanceByCropLeaf.getAppliedInCrop(), null,  cropType), parent);
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.pending.to.apply"),GrowerPortalBalanceType.PENDING_TO_APPLY,cropId, balanceByCropLeaf.getPendingToApply(), null,  cropType), parent);
        new DefaultTreeNode(cropType, new BalanceTreeElement(getMessageBundle("com.monsanto.barter.ar.business.growerportal.entity.type.inProcess"),GrowerPortalBalanceType.IN_PROCESS,cropId, balanceByCropLeaf.getInProcess(), null,  cropType), parent);

    }

    public TreeNode getContractsRoot() {
        return contractsRoot;
    }

    public Double getTotalTns() {
        return totalTns;
    }

    public void viewDocDetail(){

        if (selectedNode.isLeaf()){
            BalanceTreeElement selectedData = (BalanceTreeElement) (selectedNode.getData());
            GrowerPortalBalancesFilter filter = new GrowerPortalBalancesFilter(selectedData.getCropTypeId(),
                    selectedData.getBalanceType(), grower);
            boolean viewAccount = selectedData.isViewAccount();
            if (viewAccount){
                unloads = null;
                contractViews = growerContractService.findContractsByGrowerPortalBalanceFilter(filter);
            }else{
                contractViews = null;
                unloads = unloadService.getUnloadsByGrowerPortalBalanceFilter(filter);
            }
        }else{
            contractViews = null;
            unloads = null;
        }
    }

    public String chooseChildCustomer() {
        if(childGrowerId != null) {
            for(CustomerLas childGrower : childGrowers) {
               if(childGrower.getId().equals(childGrowerId)) {
                   grower = childGrower;
                }
            }
            totalTns = 0D;
            contractsRoot = buildRootNode();
            createContractsForGrower(grower);
            contractViews = null;
            unloads = null;
            return SUCCESS;
        } else {
            return null;
        }
    }

    public TreeNode getSelectedNode() {
        return selectedNode;
    }

    public void setSelectedNode(TreeNode selectedNode) {
        this.selectedNode = selectedNode;
    }

    public List<GrowerContractView> getContractViews() {
        return contractViews;
    }

    public void setContractViews(List<GrowerContractView> contractViews) {
        this.contractViews = contractViews;
    }

    public List<UnloadView> getUnloads() {
        return unloads;
    }

    public void setUnloads(List<UnloadView> unloads) {
        this.unloads = unloads;
    }


    public Set<CustomerLas> getChildGrowers() {
        return childGrowers;
    }

    public void setChildGrowers(Set<CustomerLas> childGrowers) {
        this.childGrowers = childGrowers;
    }

    public String getChildGrowerId() {
        return childGrowerId;
    }

    public void setChildGrowerId(String childGrowerId) {
        this.childGrowerId = childGrowerId;
    }
}
