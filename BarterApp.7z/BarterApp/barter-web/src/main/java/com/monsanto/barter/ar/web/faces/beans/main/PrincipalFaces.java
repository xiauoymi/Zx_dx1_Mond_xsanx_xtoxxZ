package com.monsanto.barter.ar.web.faces.beans.main;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.service.VendorService;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author JASANC5
 */
public class PrincipalFaces extends ArBaseJSF {

    private static final String CCS_PATH="ar.css.path";
    private VendorService vendorService;
    private String companyName = "";
    private final Logger LOG = LoggerFactory.getLogger(PrincipalFaces.class);

    public String exit() {
        logout();
        return SUCCESS;
    }

    public String getCustomerCompany() {
        if (companyName.equals("")){
            companyName = "N/A";
            try {
                if (getLoggedUser().getInterventorCompany()!=null) {
                    if (vendorService == null){
                        vendorService = getService(VendorService.class);
                    }
                    companyName = vendorService.getVendor(getLoggedUser().getInterventorCompany().getDocument()).getName();
                }
            } catch ( BusinessException be) {
                LOG.error("There was an error retrieving company:", be);
            }
        }
        return companyName;
    }

    public String getUserFullName(){
        return getLoggedUser().getName() + " " + getLoggedUser().getLastName();
    }

    public String getUserRole(){
        return getLoggedUser().getType().toString();
    }

    public String getCSSPath(){
        String css = getApplicationProperty(CCS_PATH);
        return css.replace("REQUEST_CONTEXT_PATH", getFacesContext().getExternalContext().getRequestContextPath());
    }
}
