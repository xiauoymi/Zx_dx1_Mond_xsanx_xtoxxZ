package com.monsanto.barter.ar.web.faces.beans.pointOfSale;

import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.PointOfSaleFilter;
import com.monsanto.barter.ar.business.service.PointOfSaleService;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.model.ListDataModel;

/**
 * Created by VNBARR on 9/8/2014.
 */
public class PointOfSaleSearchFormBean extends ArBaseJSF {

    private PointOfSaleFilter pointOfSaleFilter;
    private PointOfSaleService pointOfSaleService;
    private static final Logger LOG = LoggerFactory.getLogger(PointOfSaleSearchFormBean.class);
    private ListDataModel<PointOfSaleDTO> searchResult;
    private Integer status;

    public String begin(){
        LOG.debug("Setting filters.");
        this.pointOfSaleFilter = new PointOfSaleFilter();
        LOG.debug("Retrieving services.");
        this.pointOfSaleService = getService(PointOfSaleService.class);
        this.searchResult = null;
        return SUCCESS;
    }

    public String search(){
        LOG.debug("Search.");
        searchResult = new ListDataModel<PointOfSaleDTO>(pointOfSaleService.search(pointOfSaleFilter));
        LOG.debug("Search -> Result");
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        this.pointOfSaleFilter = new PointOfSaleFilter();
        this.searchResult = null;
        this.status = null;
        return SUCCESS;
    }

    public PointOfSaleFilter getPointOfSaleFilter() {
        return pointOfSaleFilter;
    }

    public void setPointOfSaleFilter(PointOfSaleFilter pointOfSaleFilter) {
        this.pointOfSaleFilter = pointOfSaleFilter;
    }

    public ListDataModel<PointOfSaleDTO> getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(ListDataModel<PointOfSaleDTO> searchResult) {
        this.searchResult = searchResult;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        if (status != null) {
            this.pointOfSaleFilter.setStatus(StatusEnum.fromOrdinalToEnum(status));
        }
        this.status = status;
    }


}
