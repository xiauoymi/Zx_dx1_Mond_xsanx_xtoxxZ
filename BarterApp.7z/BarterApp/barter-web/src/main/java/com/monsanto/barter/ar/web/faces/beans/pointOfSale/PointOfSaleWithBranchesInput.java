package com.monsanto.barter.ar.web.faces.beans.pointOfSale;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;

import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.PointOfSaleService;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.PointOfSaleCC;

import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.faces.event.ActionEvent;
import javax.faces.model.ListDataModel;
import java.util.List;

/**
 * Created by VNBARR on 9/8/2014.
 */
public class PointOfSaleWithBranchesInput extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(PointOfSaleWithBranchesInput.class);
    private PointOfSaleCC pointOfSaleCC;
    private PointOfSaleService pointOfSaleService;
    private Mode mode;
    private PointOfSale parentPointOfSale = new PointOfSale();
    private PointOfSale selectedBranchPointOfSale;
    private CustomerCC customerCC;
    @Autowired
    private BeanValidator<PointOfSale> beanValidator;
    private ListDataModel<PointOfSale> branches;
    private Long parentPointOfSaleId;

    public void init (Mode mode){
        this.mode = mode;
        this.pointOfSaleService = getService(PointOfSaleService.class);
        this.pointOfSaleCC = getService(PointOfSaleCC.class);
        this.customerCC = getService(CustomerCC.class);
        this.beanValidator = getService(BeanValidator.class);
        clear();
        loadPointOfSaleFromDB(parentPointOfSaleId);
        loadComponents();
    }

    public String begin(){
        parentPointOfSaleId = null;
        parentPointOfSale = new PointOfSale();
        init(Mode.CREATE);
        return SUCCESS;
    }

    public String editPointOfSale(){
        init(Mode.UPDATE);
        savePointOfSaleBranches();
        return SUCCESS;
    }

    public String viewPointOfSale(){
        init(Mode.VIEW);
        loadBranches();
        return SUCCESS;
    }

    private void loadComponents() {
        if (parentPointOfSale != null){
            this.customerCC.setCustomer(parentPointOfSale.getCustomer());
        }
    }

    private void loadPointOfSaleFromDB(Long pointOfSaleId) {
        if (pointOfSaleId!= null) {
            try {
                LOG.debug("Loading point of sale");
                this.parentPointOfSale = pointOfSaleService.get(pointOfSaleId);
            } catch (BusinessException e) {
                LOG.error("Error loading point of sale", e);
            }
        }
    }

    public void newPointOfSale(){
        pointOfSaleCC.clear();
    }

    public String clear(){
        this.pointOfSaleCC.clear();
        this.branches = null;
        this.selectedBranchPointOfSale=null;
        return SUCCESS;
    }


    public PointOfSaleCC getPointOfSaleCC() {
        return pointOfSaleCC;
    }

    public void setPointOfSaleCC(PointOfSaleCC pointOfSaleCC) {
        this.pointOfSaleCC = pointOfSaleCC;
    }

    public void preSave(){
        setComponents();
        addCallbackParam("isValid", isValid());
    }

    public void setComponents() {
        if (this.customerCC != null){
            this.parentPointOfSale.setCustomer(customerCC.getSelectedCustomer());
        }
    }

    private boolean isValid() {
        LOG.debug("VALIDATION  - Class:{} ", this.getClass().getName() );
        List<String> violationMessages = beanValidator.validate(parentPointOfSale);
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }


    public String cancel(){
        clear();
        return SUCCESS;
    }


    public void save(){
        try{
            if(parentPointOfSale.getId()!=null){
                LOG.debug("Update parent point of sale: {} ",parentPointOfSale.getId());
                pointOfSaleService.update(parentPointOfSale);
                addMessageNoError(getMessageBundle("label.input.pointOfSale.update.ok") + parentPointOfSale.getCustomer().getDescription());
            }else{
                LOG.debug("Save new parent point of sale");
                pointOfSaleService.save(parentPointOfSale);
                addMessageNoError(getMessageBundle("label.input.pointOfSale.creation.ok") + parentPointOfSale.getCustomer().getDescription());
                savePointOfSaleBranches();
                this.mode = Mode.UPDATE;
            }

        }catch (BusinessException be){
            LOG.error(getMessageBundle("label.input.pointOfSale.creation.error"),be);
            addMessage(getMessageBundle("label.input.pointOfSale.creation.error") + parentPointOfSale.getCustomer().getDescription());
        }

    }

    private void savePointOfSaleBranches() {
        //search branches for parent point of sale and create new point of sales
        try{
            LOG.debug("Going to save branches");
            pointOfSaleService.saveBranchesPointOfSale(parentPointOfSale);
            loadBranches();
        }catch (BusinessException ex){
            LOG.error("An error occurred saving branches point of sale: ", ex);
            addMessage(getMessageBundle("label.input.pointOfSale.saveBranches.error"));
        }
    }

    public void loadBranches() {
        try{
            LOG.debug("Going to load branches");
            List<PointOfSale> branchesPoints = pointOfSaleService.searchBranchesByParent(parentPointOfSale);
            branches = new ListDataModel<PointOfSale>( branchesPoints);
        }catch (BusinessException ex){
            LOG.error("An error occurred getting branches point of sale: ", ex);
            addMessage(getMessageBundle("label.input.pointOfSale.loadBranches.error"));
        }
    }

    public boolean isReadOnly(){
        return mode.isReadOnly();
    }

    public void selectBranch(ActionEvent event){
        selectedBranchPointOfSale =  (PointOfSale)event.getComponent().getAttributes().get("branch");
    }

    public void editBranch(){
        LOG.info("Open for Edit Branch --> {}", selectedBranchPointOfSale.getCustomer().getDescription());
        pointOfSaleCC.editPointOfSale(selectedBranchPointOfSale);
    }

    public boolean isActivePOS() {
        return parentPointOfSale.getStatus().equals(StatusEnum.ACTIVE);
    }

    public void setActivePOS(boolean checked) {
        if (checked) {
            parentPointOfSale.setStatus(StatusEnum.ACTIVE);
        } else {
            parentPointOfSale.setStatus(StatusEnum.INACTIVE);
        }
    }

    public PointOfSale getParentPointOfSale() {
        return parentPointOfSale;
    }

    public void setParentPointOfSale(PointOfSale parentPointOfSale) {
        this.parentPointOfSale = parentPointOfSale;
    }

    public ListDataModel<PointOfSale> getBranches() {
        return branches;
    }

    public void setBranches(ListDataModel<PointOfSale> branches) {
        this.branches = branches;
    }

    public CustomerCC getCustomerCC() {
        return customerCC;
    }

    public void setCustomerCC(CustomerCC customerCC) {
        this.customerCC = customerCC;
    }

    public String getCustomerCity(){
        if (this.customerCC != null){
            CustomerLas selectedCustomer = this.customerCC.getSelectedCustomer();
            if (selectedCustomer != null){
                return selectedCustomer.getCity();
            }
        }
        return "";
    }

    public Long getParentPointOfSaleId() {
        return parentPointOfSaleId;
    }

    public void setParentPointOfSaleId(Long parentPointOfSaleId) {
        this.parentPointOfSaleId = parentPointOfSaleId;
    }

    public boolean isCustomerReadOnly(){
        return !isCreateMode();
    }

    public boolean isCreateMode() {
        return mode.equals(Mode.CREATE);
    }

    public PointOfSale getSelectedBranchPointOfSale() {
        return selectedBranchPointOfSale;
    }

    public Mode getMode() {
        return mode;
    }
}
