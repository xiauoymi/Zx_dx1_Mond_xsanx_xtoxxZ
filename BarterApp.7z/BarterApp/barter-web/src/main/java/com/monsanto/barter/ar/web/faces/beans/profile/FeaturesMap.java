package com.monsanto.barter.ar.web.faces.beans.profile;

import com.monsanto.barter.ar.business.entity.GlobalBarterAction;
import com.monsanto.barter.ar.business.entity.GlobalBarterGroup;
import com.monsanto.barter.ar.business.entity.GlobalBarterProfile;
import com.monsanto.barter.ar.business.service.GlobalBarterFeatureService;
import com.monsanto.barter.ar.business.service.GlobalBarterGroupService;
import com.monsanto.barter.ar.business.service.dto.ActionView;
import com.monsanto.barter.ar.business.service.dto.FeatureView;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.*;


@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class FeaturesMap {

    @Autowired
    private GlobalBarterGroupService globalBarterGroupService;
    @Autowired
    private GlobalBarterFeatureService globalBarterFeatureService;

    private static final String DESCRIPTION_ALL_GROUPS = "label.combo.all";
    private static final long ID_ALL_GROUPS = -1L;

    private List<GlobalBarterGroup> listGroups = new ArrayList<GlobalBarterGroup>();
    private List<FeatureView> features = new ArrayList<FeatureView>();
    private List<FeatureView> featuresOnView = new ArrayList<FeatureView>();

    private GlobalBarterGroup getGroupDefault() {
        GlobalBarterGroup groupDefault = new GlobalBarterGroup();
        groupDefault.setDescription(DESCRIPTION_ALL_GROUPS);
        groupDefault.setId(ID_ALL_GROUPS);
        return groupDefault;
    }

    public List<GlobalBarterGroup> getGroups() {
        if (listGroups.isEmpty()) {
            listGroups = globalBarterGroupService.findAll();
            sortGroups();
            listGroups.add(0, getGroupDefault());
        }
        return listGroups;
    }

    private void sortGroups() {
        Collections.sort(listGroups, new Comparator<GlobalBarterGroup>() {
            @Override
            public int compare(GlobalBarterGroup o1, GlobalBarterGroup o2) {
                return new CompareToBuilder().append(o1.getDescription(),
                        o2.getDescription()).toComparison();

            }
        });
    }

    public void loadAllFeatures(GlobalBarterProfile profile) {
        features = globalBarterFeatureService.getFeatures();
        if (profile != null) {
            //Set the selected actions
            for (FeatureView feature : features) {
                for(ActionView action : feature.getActions()) {
                    if (profile.containsAction(action.getGlobalBarterAction())) {
                        action.setSelected(true);
                    }
                }
            }
        }
        featuresOnView = features;
    }

    public void loadFeaturesByGroup(Long groupId) {
        featuresOnView = new ArrayList<FeatureView>();
        if(groupId == ID_ALL_GROUPS){
            featuresOnView =  features;
        } else {
            for (FeatureView featureView : features) {
                if (featureView.getGroupId().equals(groupId)) {
                    featuresOnView.add(featureView);
                }
            }
        }
    }

    public Set<GlobalBarterAction> getSelectedActions() {
        Set<GlobalBarterAction> accessibleActions = new HashSet<GlobalBarterAction>();
        for(FeatureView featureView: features){
            for(ActionView actionView: featureView.getActions()){
                if(actionView.getSelected()){
                    accessibleActions.add(actionView.getGlobalBarterAction());
                }
            }
        }
        return accessibleActions;
    }

    public void selectAllCheckAction(Boolean checked, Long groupId) {
        for (FeatureView featureView : features) {
            List<ActionView> actions = featureView.getActions();
            for (ActionView actionView : actions){
                if(featureView.getGroupId().equals(groupId) || groupId == ID_ALL_GROUPS ) {
                    actionView.setSelected(checked);
                }
            }
        }
    }

    public List<FeatureView> getFeatures() {
        return featuresOnView;
    }
}