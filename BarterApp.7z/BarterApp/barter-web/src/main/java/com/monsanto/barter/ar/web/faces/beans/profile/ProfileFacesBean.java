package com.monsanto.barter.ar.web.faces.beans.profile;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.business.constraints.groups.Delete;
import com.monsanto.barter.ar.business.entity.GlobalBarterAccessibleAction;
import com.monsanto.barter.ar.business.entity.GlobalBarterAction;
import com.monsanto.barter.ar.business.entity.GlobalBarterProfile;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.GlobalBarterProfileService;
import com.monsanto.barter.ar.business.service.dto.FeatureView;
import com.monsanto.barter.ar.business.service.dto.GlobalBarterProfileView;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.event.ValueChangeEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ProfileFacesBean extends ArBaseJSF {

    public static final int EVERY_STATUS = -1;
    public static final Long ALL_GROUPS = -1L;
    private DataModel<GlobalBarterProfileView> profiles;
    private String description;
    private Integer status;
    private GlobalBarterProfile profile;
    private static final Logger LOG = LoggerFactory.getLogger(ProfileFacesBean.class);
    private GlobalBarterProfileService globalBarterProfileService;
    private GlobalBarterProfileView profileView;
    private Boolean allSelected;
    private Long groupId;
    private FeaturesMap featuresMap;

    public String begin() {
        LOG.debug("Start Begin");
        status = EVERY_STATUS;
        description = "";
        groupId =ALL_GROUPS;
        globalBarterProfileService = getService(GlobalBarterProfileService.class);
        featuresMap = getService(FeaturesMap.class);
        searchProfiles();
        return SUCCESS;
    }

    public void searchProfiles() {
        LOG.debug("searchProfiles");
        StatusEnum statusEnum = null;
        if (status != EVERY_STATUS) {
            if (status == 1) {
                statusEnum = StatusEnum.ACTIVE;
            } else {
                statusEnum = StatusEnum.INACTIVE;
            }
        }
        profiles = new ListDataModel<GlobalBarterProfileView>(
                globalBarterProfileService.searchByDescription(description, statusEnum));
    }

    public String newProfile() {
        LOG.debug("Action new Profile");
        profile = new GlobalBarterProfile();
        profile.setEditable(true);
        profile.setStatus(StatusEnum.ACTIVE);
        featuresMap.loadAllFeatures(null);
        clearFeatures();
        setAllSelected(Boolean.FALSE);
        return SUCCESS;
    }

    private void clearFeatures() {
        featuresMap.selectAllCheckAction(Boolean.FALSE, groupId);
    }

    public void preSave(){
        if (!validate()) {
            LOG.debug("Invalid Profile - " + profile.getDescription());
            addCallbackParam("validForSaved", false);
        } else {
            LOG.debug("Valid Profile - " + profile.getDescription());
            addCallbackParam("validForSaved", true);
        }
    }

    public String save() {
        LOG.debug("Start Saving Profile - " + profile.getDescription());
        try {
            if (profile.getId() == null){ //Save for create
                profile.setActions(featuresMap.getSelectedActions());
                globalBarterProfileService.save(profile);
                addMessageNoError(getMessageBundle("ar.barter.profile.create.success"));
            } else { //Save for update
                mergeActions(profile, featuresMap.getSelectedActions());
                globalBarterProfileService.update(profile);
                addMessageNoError(getMessageBundle("ar.barter.profile.update.success"));
            }
            searchProfiles();
            return SUCCESS;
        } catch (BusinessException be) {
            if (profile.getId() == null){ //Error message for create
                addMessage(getMessageBundle("ar.barter.profile.create.error"));
                LOG.error("An error occurred creating a Profile: ", be);
            } else { //Error message for update
                addMessage(getMessageBundle("ar.barter.profile.update.error"));
                LOG.error("An error occurred updating a Profile: ", be);
            }
        }
        return null;
    }

    private void mergeActions(GlobalBarterProfile profile, Set<GlobalBarterAction> selectedActions) {
        LOG.debug("Start merging actions");
        //Add non-existing actions
        for (GlobalBarterAction selectedAction : selectedActions) {
            if (!profile.containsAction(selectedAction)) {
                profile.addAction(selectedAction);
            }
        }

        List<GlobalBarterAction> actionsToDelete = new LinkedList<GlobalBarterAction>();
        //Remove unselected actions
        for (GlobalBarterAccessibleAction action : profile.getActions()) {
            if (!selectedActions.contains(action.getAction())) {
                actionsToDelete.add(action.getAction());
            }
        }

        //This is done this way to avoid a concurrency exception
        for(GlobalBarterAction action : actionsToDelete) {
            profile.removeAction(action);
        }
    }

    public String delete() {
        LOG.debug("Start Delete Profile - " + profile.getDescription());
        if (!validateForDelete(profile.getId())) {
            LOG.error("Invalid Profile - " + profile.getDescription());
            return null;
        }
        try {
            globalBarterProfileService.delete(profile);
            LOG.debug("Deleted Profile - " + profile.getDescription());
            addMessageNoError(getMessageBundle("ar.barter.profile.delete.success"));
            searchProfiles();
            return SUCCESS;
        } catch (BusinessException be) {
            addMessage(getMessageBundle("ar.barter.profile.delete.error"));
            LOG.error("An error occurred removing a Profile: ", be);
        }
        return null;
    }

    public void preDeleteFromGrid() {
        boolean validForDelete = validateForDelete(profileView.getId());
        addCallbackParam("validForDelete", validForDelete);
    }

    public String edit() {
        GlobalBarterProfileView profileViewAux = profiles.getRowData();
        profile = globalBarterProfileService.get(profileViewAux.getId());
        profile.getActions().size();
        featuresMap.loadAllFeatures(profile);
        LOG.debug("Start Edit Profile - " + profile.getDescription());
        status = EVERY_STATUS;
        description = "";
        groupId = ALL_GROUPS;
        setAllSelected(Boolean.FALSE);
        return SUCCESS;
    }

    @SuppressWarnings("unchecked")
    protected boolean validate() {
        LOG.debug("validate Profile - " + profile.getDescription());
        List<String> violationMessages = getValidator().validate(profile);
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    protected boolean validateForDelete(Long profiledId) {
        profile = globalBarterProfileService.get(profiledId);
        LOG.debug("validate For Delete Profile - " + profile.getDescription());
        List<String> violationMessages = getValidator().validate(profile, Delete.class);
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    public List<FeatureView> getFeatures() {
        return featuresMap.getFeatures();
    }


    public void groupChangeListener() {
        featuresMap.loadFeaturesByGroup(groupId);
    }

    public void selectAllValueChange(ValueChangeEvent event) {
        Boolean allCheck = (Boolean) event.getNewValue();
        featuresMap.selectAllCheckAction(allCheck, groupId);
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public DataModel<GlobalBarterProfileView> getProfiles() {
        return profiles;
    }

    public void setProfiles(DataModel<GlobalBarterProfileView> profiles) {
        this.profiles = profiles;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public GlobalBarterProfile getProfile() {
        return profile;
    }

    public void setProfile(GlobalBarterProfile profile) {
        this.profile = profile;
    }

    public boolean isProfileStatus() {
        return profile.getStatus().equals(StatusEnum.ACTIVE);
    }

    public void setProfileStatus(boolean checked) {
        if (checked) {
            profile.setStatus(StatusEnum.ACTIVE);
        } else {
            profile.setStatus(StatusEnum.INACTIVE);
        }
    }

    public FeaturesMap getFeaturesMap() {
        return featuresMap;
    }

    public void setFeaturesMap(FeaturesMap featuresMap) {
        this.featuresMap = featuresMap;
    }

    public Boolean getAllSelected() {
        return allSelected;
    }

    public void setAllSelected(Boolean allSelected) {
        this.allSelected = allSelected;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public GlobalBarterProfileView getProfileView() {
        return profileView;
    }

    public void setProfileView(GlobalBarterProfileView profileView) {
        this.profileView = profileView;
    }
}
