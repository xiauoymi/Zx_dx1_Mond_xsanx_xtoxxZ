package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.RTUnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.UnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.RTState;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.EmailService;
import com.monsanto.barter.ar.business.service.GrainTransferService;
import com.monsanto.barter.ar.business.service.RemoteService;
import com.monsanto.barter.ar.business.service.UnsuccessfulRemoteInvocationService;
import com.monsanto.barter.ar.business.service.dto.RemoteServiceResponse;
import com.monsanto.barter.ar.web.faces.editView.EditViewBase;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorySectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtInitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtTransferSectionCC;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.event.AbortProcessingException;
import java.io.InputStream;

import static com.monsanto.barter.ar.web.faces.mode.Mode.UPDATE;
import static com.monsanto.barter.ar.web.faces.mode.Mode.VIEW;

public class RtDetail extends EditViewBase<GrainTransfer> {
    private static final Logger LOG = LoggerFactory.getLogger(RtDetail.class);
    public static final DocumentType DOCUMENT_TYPE = DocumentType.RT;
    private RtInitialDataSectionCC rtInitialDataSectionCC;
    private DepositorySectionCC depositorySectionCC;
    private DepositorSectionCC depositorSectionCC;
    private RtTransferSectionCC rtTransferSectionCC;
    private InputStream pdfStream;

    private GrainTransferService rtService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private RemoteService remoteService;
    private EmailService emailService;

    @Override
    protected void setUpdateMode(GrainTransfer rt) {
        try {
            RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(getDocumentType(), rt.getNumber().replace("-", ""));
            if (serviceResponse.isOK()) {
                setMode(UPDATE);
            } else {
                addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + getMessageBundle(serviceResponse.getResponseMessage()));
                setMode(VIEW);
            }
        } catch (Exception ex) {
            LOG.error("There was an error invoking SAP validation service: ", ex);
            addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotUpdate") + ex.getMessage());
            setMode(VIEW);
        }
    }

    public DocumentType getDocumentType() {
        return DOCUMENT_TYPE;
    }

    @Override
    protected void setViewMode(GrainTransfer rt) {
        setMode(VIEW);
    }

    @Override
    protected void init() {
        rtService = getService(GrainTransferService.class);
        remoteService = getService(RemoteService.class);
        emailService = getService(EmailService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
    }

    protected void createSections() {
        setRtInitialDataSectionCC(getService(RtInitialDataSectionCC.class));
        setDepositorySectionCC(getService(DepositorySectionCC.class));
        setDepositorSectionCC(getService(DepositorSectionCC.class));
        setRtTransferSectionCC(getService(RtTransferSectionCC.class));
        addSection(rtInitialDataSectionCC);
        addSection(depositorySectionCC);
        addSection(depositorSectionCC);
        addSection(rtTransferSectionCC);
    }

    @Override
    protected GrainTransfer findEntity() {
        return rtService.get(getIdEntity());
    }

    public StreamedContent getFile() {
        LOG.debug("START DOWNLOAD pdf named: RT_{}.pdf", getRtInput().getNumber());
        return new DefaultStreamedContent(pdfStream, "application/pdf", "RT_" +  getRtInput().getNumber() + ".pdf");
    }

    public void generatePdf() {
        LOG.debug("START pdf exportation of RT_ID : {}", getIdEntity());
        try {
            pdfStream = rtService.getPdf(getIdEntity());
        } catch (BusinessException e) {
            addMessage(e);
            throw new AbortProcessingException(e);
        }
    }

    public String save() {
        LOG.debug("Begin save in RTDetailBean");
        final RTState rtState = getRtInput().getState();
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    boolean sentToSAP = getRtInput().isSentToSAP();
                    getRtInput().setSentToSAP();
                    rtService.update(getRtInput());
                    unsuccessfulInvocationService.clearPendingInvocations(getRtInput());
                    if (sentToSAP) {
                        RemoteServiceResponse serviceResponse = remoteService.getDocumentStatus(getDocumentType(),
                                getRtInput().getNumber().replace("-", ""));
                        if (!serviceResponse.isOK()) {
                            throw new BusinessException(serviceResponse.getResponseMessage());
                        }
                        remoteService.update(getRtInput());
                    } else {
                        remoteService.create(getRtInput());
                    }
                }
            });
            getFacesBean("rtSearchFormFacesBean", RtSearchFormFacesBean.class).search();
        } catch (RemoteServiceException ex){
            LOG.error("An error occurred sending the RT to SAP: ", ex);
            getRtInput().setState(rtState); //Rollback the state change
            addCallbackParam("remoteServicesError", true);
            getSapMessages().add(ex.getMessage());
            return null;
        } catch (BusinessException ex) {
            LOG.error("Failed save in RTDetailBean", ex);
            getRtInput().setState(rtState); //Rollback the state change
            addMessage(getMessageBundle(ex.getMessage()));
            return null;
        }
        addMessageNoError("Se ha actualizado correctamente la RT.");
        LOG.debug("Success save in RTDetailBean");
        return SUCCESS;
    }

    public String saveWithErrors() {
        LOG.debug("Begin save with errors in RTDetailBean");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    rtService.update(getRtInput());
                    RTUnsuccessfulRemoteInvocation invocation = new RTUnsuccessfulRemoteInvocation();
                    invocation.setGrainTransfer(getRtInput());
                    if (getRtInput().isSentToSAP()) {
                        invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.UPDATE);
                    } else {
                        invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.CREATE);
                    }
                    unsuccessfulInvocationService.save(invocation);
                }
            });
            emailService.sendRetryStartMessage(getRtInput().getIdSap(), getSapMessages(), getLoggedUser().getEmail());
            getFacesBean("rtSearchFormFacesBean", RtSearchFormFacesBean.class).search();
        } catch (BusinessException ex) {
            addMessage(getMessageBundle(ex.getMessage()));
            LOG.error("Failed save with errors in RTDetailBean", ex);
            return null;
        }
        addMessageNoError("Se ha actualizado correctamente la RT.");
        LOG.debug("Success save with errors in RTDetailBean");
        return SUCCESS;
    }

    public RtInitialDataSectionCC getRtInitialDataSectionCC() {
        return rtInitialDataSectionCC;
    }

    public void setRtInitialDataSectionCC(RtInitialDataSectionCC rtInitialDataSectionCC) {
        this.rtInitialDataSectionCC = rtInitialDataSectionCC;
    }

    public DepositorySectionCC getDepositorySectionCC() {
        return depositorySectionCC;
    }

    public void setDepositorySectionCC(DepositorySectionCC depositorySectionCC) {
        this.depositorySectionCC = depositorySectionCC;
    }

    public DepositorSectionCC getDepositorSectionCC() {
        return depositorSectionCC;
    }

    public void setDepositorSectionCC(DepositorSectionCC depositorSectionCC) {
        this.depositorSectionCC = depositorSectionCC;
    }

    public RtTransferSectionCC getRtTransferSectionCC() {
        return rtTransferSectionCC;
    }

    public void setRtTransferSectionCC(RtTransferSectionCC rtTransferSectionCC) {
        this.rtTransferSectionCC = rtTransferSectionCC;
    }

    public GrainTransfer getRtInput() {
        return getEntity();
    }
}
