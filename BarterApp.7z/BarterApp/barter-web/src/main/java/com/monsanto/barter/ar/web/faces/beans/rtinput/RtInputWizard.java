package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.constraints.groups.Sensible;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.RTState;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardFaces;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;
import com.monsanto.barter.ar.web.faces.wizard.WizardStep;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorySectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtInitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtTransferSectionCC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.util.*;

@SuppressWarnings("unchecked")
public class RtInputWizard extends AbstractWizardFaces {

    private static final Logger LOG = LoggerFactory.getLogger(RtInputWizard.class);
    public static final int DEPOSITOR_SECTION_INDEX = 3;
    public static final int DEPOSITORY_SECTION_INDEX = 2;
    public static final int INITIAL_DATA_SECTION_INDEX = 1;
    public static final int TRANSFER_SECTION_INDEX = 0;
    public static final String VALID_RT = "validRt";

    private RtInitialDataSectionCC rtInitialDataSectionCC;
    private DepositorySectionCC depositorySectionCC;
    private DepositorSectionCC depositorSectionCC;
    private RtTransferSectionCC rtTransferSectionCC;

    private List<AbstractWizardStepCC> wizardSteps;
    private Map<String,AbstractWizardStepCC> wizardStepHashMap;

    private GrainTransfer rtInput;

    private GrainTransferService rtService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    private RemoteService remoteService;
    private EmailService emailService;

    private String uploadDocumentNumber;

    private DocumentsUploader<GrainTransfer> documentsUploader;

    private BeanValidator beanValidator;

    private List<String> sapMessages = new ArrayList<String>();

    public RtInputWizard() {
        rtService = getService(GrainTransferService.class);
        remoteService = getService(RemoteService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        emailService = getService(EmailService.class);
        beanValidator=getService(BeanValidator.class);
    }

    public String begin() {
        LOG.debug("begining wizard setup.");
        rtInput = new GrainTransfer();
        rtInput.setDetailDate(new Date());
        wizardStepHashMap = new HashMap<String, AbstractWizardStepCC>();
        wizardSteps = new ArrayList<AbstractWizardStepCC>();

        LOG.debug("Retrieving step beans.");
        setRtInitialDataSectionCC(getService(RtInitialDataSectionCC.class));
        setDepositorySectionCC(getService(DepositorySectionCC.class));
        setDepositorSectionCC(getService(DepositorSectionCC.class));
        setRtTransferSectionCC(getService(RtTransferSectionCC.class));

        LOG.debug("Adding step beans to wizard.");
        addWizardStep(rtTransferSectionCC.initializeStepCC(TRANSFER_SECTION_INDEX, "rtTransferSectionCC", rtInput, Mode.CREATE));
        addWizardStep(rtInitialDataSectionCC.initializeStepCC(INITIAL_DATA_SECTION_INDEX, "rtInitialDataSectionCC", rtInput, Mode.CREATE));
        addWizardStep(depositorySectionCC.initializeStepCC(DEPOSITORY_SECTION_INDEX, "depositorySectionCC", rtInput, Mode.CREATE));
        addWizardStep(depositorSectionCC.initializeStepCC(DEPOSITOR_SECTION_INDEX,"depositorSectionCC", rtInput, Mode.CREATE));

        LOG.debug("Initializing first step bean.");
        rtTransferSectionCC.begin();
        documentsUploader = new DocumentsUploader<GrainTransfer>();
        return SUCCESS;
    }

    private void addWizardStep( AbstractWizardStepCC wizardStep ) {
        wizardSteps.add(wizardStep);
        wizardStepHashMap.put(wizardStep.getKey(),wizardStep);
    }

    @Override
    protected int getStepCount() {
        return wizardSteps.size();
    }

    @Override
    protected WizardStep getStep(int index) {
        return wizardSteps.get(index);
    }

    @Override
    protected WizardStep getStep(String step) {
        return wizardStepHashMap.get(step);
    }

    /**
     * Cancels and invalidate current (session scoped) wizard.
     */
    public String rtInputCancelAction() throws IOException {
        LOG.debug("about to cancel addInputWizard.");
        RtInputWizard newBean = getNewRtInputWizard();
        getFacesContext().getExternalContext().getSessionMap().put("rtInputWizardFaces", newBean);
        documentsUploader.leave();
        return CANCEL;
    }

    protected RtInputWizard getNewRtInputWizard() {
        RtInputWizard newBean = new RtInputWizard();
        newBean.begin();
        return newBean;
    }

    public String saveRtInput(){
        LOG.debug("about 2 save RT with errors");
        getSapMessages().clear();
        setUploadDocumentNumber("");

        if(!sensibleValidate()){
            addCallbackParam(VALID_RT, false);
            return "";
        }

        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.rtInput = tx.execute(new TransactionCallback<GrainTransfer>() {
                @Override
                public GrainTransfer doInTransaction(TransactionStatus status) {
                    rtInput.setSentToSAP();
                    rtInput = rtService.save(rtInput);
                    remoteService.create(rtInput);
                    return rtInput;
                }
            });
        } catch (RemoteServiceException e) {
            LOG.error("An error occurred sending the RT to SAP: ", e);
            rtInput.setState(RTState.INGRESED); //Rollback the state change
            addCallbackParam("remoteServicesError", true);
            sapMessages.add(e.getMessage());
            return "";
        } catch (BusinessException e) {
            LOG.error("An error occurred saving the RT: ", e);
            rtInput.setState(RTState.INGRESED); //Rollback the state change
            addCallbackParam(VALID_RT, false);
            addMessage(getMessageBundle(e.getMessage()));
            return "";
        } catch (DataIntegrityViolationException e){
            // TODO: this should never happen, we must take a look to how the transactions are being handled
            LOG.error("An error occurred saving the RT: ", e);
            rtInput.setState(RTState.INGRESED); //Rollback the state change
            addCallbackParam(VALID_RT, false);
            return "";
        }
        LOG.debug("RT saved with id: {}", this.rtInput.getId());
        setUploadDocumentNumber(rtInput.getNumber());
        documentsUploader.init((DocumentUploadService<GrainTransfer>) rtService, beanValidator, rtInput);
        addCallbackParam(VALID_RT, true);
        return "";
    }

    public String saveRtInputWithErrors(){
        LOG.debug("About to save RT with errors");

        if(!sensibleValidate()){
            addCallbackParam(VALID_RT, false);
            return "";
        }

        try {
            TransactionTemplate tx = getTransactionTemplate();
            this.rtInput = tx.execute(new TransactionCallback<GrainTransfer>() {
                @Override
                public GrainTransfer doInTransaction(TransactionStatus status) {
                    rtInput = rtService.save(rtInput);
                    RTUnsuccessfulRemoteInvocation invocation = new RTUnsuccessfulRemoteInvocation();
                    invocation.setGrainTransfer(rtInput);
                    invocation.setOperation(UnsuccessfulRemoteInvocation.Operation.CREATE);
                    unsuccessfulInvocationService.save(invocation);
                    return rtInput;
                }
            });
            setUploadDocumentNumber(rtInput.getNumber());
            emailService.sendRetryStartMessage(rtInput.getIdSap(), sapMessages, getLoggedUser().getEmail());
            documentsUploader.init((DocumentUploadService<GrainTransfer>) rtService, beanValidator, rtInput);
        } catch (BusinessException e) {
            LOG.error("An error occurred saving the RT: ", e);
            addCallbackParam(VALID_RT, false);
            addMessage(getMessageBundle(e.getMessage()));
            return "";
        }

        LOG.debug("RT saved with id: {}", this.rtInput.getId());
        addCallbackParam(VALID_RT, true);
        return "";
    }

    private boolean sensibleValidate() {
        LOG.debug("Sensible Validation");
        List<String> violationMessages = getValidator().validate(rtInput, Sensible.class);
        if (addViolationMessages(violationMessages)){
            return false;
        }
        return true;
    }

    private boolean addViolationMessages(List<String> violationMessages) {
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return true;
        }
        return false;
    }
    
    public String attachFiles() throws IOException {
        if(!documentsUploader.isEmptyFiles()) {
            for (Attachment attachment : documentsUploader.getAttachments()) {
                rtInput.addAttachment(attachment);
            }
            rtService.update(rtInput);
        }
        documentsUploader.leave();
        rtInputCancelAction();
        return SUCCESS;
    }

    public RtInitialDataSectionCC getRtInitialDataSectionCC() {
        return rtInitialDataSectionCC;
    }

    public void setRtInitialDataSectionCC(RtInitialDataSectionCC rtInitialDataSectionCC) {
        this.rtInitialDataSectionCC = rtInitialDataSectionCC;
    }

    public RtTransferSectionCC getRtTransferSectionCC() {
        return rtTransferSectionCC;
    }

    public void setRtTransferSectionCC(RtTransferSectionCC rtTransferSectionCC) {
        this.rtTransferSectionCC = rtTransferSectionCC;
    }

    public DepositorSectionCC getDepositorSectionCC() {
        return depositorSectionCC;
    }

    public void setDepositorSectionCC(DepositorSectionCC depositorSectionCC) {
        this.depositorSectionCC = depositorSectionCC;
    }

    public DepositorySectionCC getDepositorySectionCC() {
        return depositorySectionCC;
    }

    public void setDepositorySectionCC(DepositorySectionCC depositorySectionCC) {
        this.depositorySectionCC = depositorySectionCC;
    }

    public String getUploadDocumentNumber() {
        return uploadDocumentNumber;
    }

    public void setUploadDocumentNumber(final String uploadDocumentNumber) {
        this.uploadDocumentNumber = uploadDocumentNumber;
    }

    public DocumentsUploader<GrainTransfer> getDocumentsUploader() {
        return documentsUploader;
    }

    public void setDocumentsUploader(DocumentsUploader<GrainTransfer> documentsUploader) {
        this.documentsUploader = documentsUploader;
    }

    public List<String> getSapMessages() {
        return sapMessages;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

}
