package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.RTState;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.ReportService;
import com.monsanto.barter.ar.business.service.RtReportFilter;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel.RtReportDataModel;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * @author JPBENI
 */
public class RtReportFormFacesBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(RtReportFormFacesBean.class);

    public static final String PAGE_REPORT_FORM = "rt-report-form";
    public static final String PAGE_REPORT_RESULT = "rt-report-result";
    private static final int EXCEL_COLUMN_WIDTH_UNIT = 256;
    public static final int EXCEL_NUMBER_HEADER_INDEX = 0;
    public static final int EXCEL_NUMBER_VALUE_HEADER_INDEX = 1;
    public static final int DATE_FROM_HEADER_INDEX = 2;
    public static final int DATE_FROM_VALUE_HEADER_INDEX = 3;
    public static final int DATE_TO_HEADER_INDEX = 4;
    public static final int DATE_TO_VALUE_HEADER_INDEX = 5;
    public static final int CUIT_HEADER_INDEX = 6;
    public static final int CUIT_VALUE_HEADER_INDEX = 7;
    public static final int NAME_HEADER_INDEX = 8;
    public static final int NAME_VALUE_HEADER_INDEX = 9;
    public static final int CROP_HEADER_INDEX = 10;
    public static final int CROP_VALUE_HEADER_INDEX = 11;
    public static final int RT_STATE_HEADER_INDEX = 12;
    public static final int RT_STATE_VALUE_HEADER_INDEX = 13;
    public static final int COLUMN_WIDTH_INCREASE = 35;
    public static final int LA_TIJERETA_COLUMN_INDEX = 10;
    public static final int HEADER_OFFSET = 3;
    public static final int NUMERIC_COLUMN_INDEX = 36;
    public static final int COLUMNS_SIZE = 36;
    public static final int COLUMN_INDEX_3 = 3;
    public static final int COLUMN_INDEX_4 = 4;
    public static final int COLUMN_INDEX_5 = 5;
    public static final int COLUMN_INDEX_19 = 19;
    public static final int COLUMN_INDEX_20 = 20;
    public static final int COLUMN_INDEX_21 = 21;

    private List<MaterialLas> materialLasList;

    private RtReportFilter filter;

    private RtReportDataModel searchResult;
    private String cropTypeDescription;

    private ReportService reportService;


    public String begin() {
        MaterialLasService materialLasService = getService(MaterialLasService.class);
        reportService = getService(ReportService.class);
        clear();

        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
        return PAGE_REPORT_FORM;
    }

    public String report() {
        if (validateFilters()){
            searchResult = new RtReportDataModel(reportService, filter);
            return PAGE_REPORT_RESULT;
        }
        return null;
    }

    public String clear(){
        this.cropTypeDescription = "";
        filter = new RtReportFilter();
        return PAGE_REPORT_FORM;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(2);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                    adjustNumericColumn(cell);
                    adjustBooleanColumn(cell);
                }
            }
        }
    }

    private void adjustNumericColumn(Cell cell) {
        if(cell.getColumnIndex() == NUMERIC_COLUMN_INDEX && !cell.getStringCellValue().isEmpty()){
            cell.setCellValue(Double.valueOf(cell.getStringCellValue()));
            cell.getCellStyle().setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        }
    }

    private void adjustBooleanColumn(Cell cell){
        if(cell.getColumnIndex() == LA_TIJERETA_COLUMN_INDEX){
            if(cell.getStringCellValue().equalsIgnoreCase("false")) {
                cell.setCellValue(getMessageBundle("label.report.excel.no"));
            }else {
                cell.setCellValue(getMessageBundle("label.report.excel.yes"));
            }
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    private void createHeader(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), 2);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(EXCEL_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(EXCEL_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(DATE_FROM_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(DATE_TO_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(CUIT_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(CUIT_VALUE_HEADER_INDEX);
        HSSFCell cell8 = row.createCell(NAME_HEADER_INDEX);
        HSSFCell cell9 = row.createCell(NAME_VALUE_HEADER_INDEX);
        HSSFCell cell10 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell11 = row.createCell(CROP_VALUE_HEADER_INDEX);

        HSSFCell cell12 = row.createCell(RT_STATE_HEADER_INDEX);
        HSSFCell cell13 = row.createCell(RT_STATE_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        cell0.setCellValue(getMessageBundle("label.report.excel.number"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell2.setCellStyle(cellStyle);
        if (filter.getGenerationDateFrom() != null) {
            cell3.setCellValue(sdf.format(filter.getGenerationDateFrom()));
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell4.setCellStyle(cellStyle);
        if (filter.getGenerationDateTo() != null) {
            cell5.setCellValue(sdf.format(filter.getGenerationDateTo()));
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.CUIT"));
        cell6.setCellStyle(cellStyle);
        cell7.setCellValue(filter.getDocument());

        cell8.setCellValue(getMessageBundle("label.report.excel.name"));
        cell8.setCellStyle(cellStyle);
        cell9.setCellValue(filter.getDescription());

        cell10.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell10.setCellStyle(cellStyle);
        if (filter.getMaterialLas() != null) {
            cell11.setCellValue(filter.getMaterialLas().getCommercialText());
        } else {
            cell11.setCellValue("");
        }

        cell12.setCellValue(getMessageBundle("label.report.excel.rtState"));
        cell12.setCellStyle(cellStyle);
        if (filter.getRtState() != null) {
            cell13.setCellValue(getMessageBundle(filter.getRtState().getDescription()));
        } else {
            cell13.setCellValue("");
        }
    }

    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
        sheet.setColumnWidth(COLUMN_INDEX_3, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
        sheet.setColumnWidth(COLUMN_INDEX_4, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
        sheet.setColumnWidth(COLUMN_INDEX_5, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
        sheet.setColumnWidth(COLUMN_INDEX_19, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
        sheet.setColumnWidth(COLUMN_INDEX_20, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
        sheet.setColumnWidth(COLUMN_INDEX_21, COLUMN_WIDTH_INCREASE * EXCEL_COLUMN_WIDTH_UNIT);
    }

    private boolean validateFilters() {
        if(filter.getGenerationDateFrom() != null && filter.getGenerationDateTo() != null &&
                filter.getGenerationDateFrom().after(filter.getGenerationDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public RtReportFilter getFilter() {
        return filter;
    }

    public void setFilter(RtReportFilter filter) {
        this.filter = filter;
    }

    public String getCropTypeDescription() {
        return cropTypeDescription;
    }

    public void setCropTypeDescription(String cropTypeDescription) {
        this.cropTypeDescription = cropTypeDescription;
    }

    public RtReportDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(RtReportDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public RTState[] getRtStates() {
        return new RTState[]{RTState.INGRESED,RTState.SENT_TO_SAP};
    }
}
