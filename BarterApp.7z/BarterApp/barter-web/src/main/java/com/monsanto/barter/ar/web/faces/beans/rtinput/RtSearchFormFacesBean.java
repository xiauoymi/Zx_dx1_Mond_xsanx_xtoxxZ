package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.Attachment;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AttachmentView;
import com.monsanto.barter.ar.business.service.dto.RtView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel.RtDataModel;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.ToggleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.model.DataModel;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author LABAEZ
 */
@SuppressWarnings("unchecked")
public class RtSearchFormFacesBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(RtSearchFormFacesBean.class);

    public static final String PAGE_SEARCH_FORM = "rt-search-form";
    public static final String PAGE_SEARCH_RESULT = "rt-search-result";

    public static final int EXCEL_NUMBER_HEADER_INDEX = 0;
    public static final int EXCEL_NUMBER_VALUE_HEADER_INDEX = 1;
    public static final int DATE_FROM_HEADER_INDEX = 2;
    public static final int DATE_FROM_VALUE_HEADER_INDEX = 3;
    public static final int DATE_TO_HEADER_INDEX = 4;
    public static final int DATE_TO_VALUE_HEADER_INDEX = 5;
    public static final int CUIT_HEADER_INDEX = 6;
    public static final int CUIT_VALUE_HEADER_INDEX = 7;
    public static final int NAME_HEADER_INDEX = 8;
    public static final int NAME_VALUE_HEADER_INDEX = 9;
    public static final int CROP_HEADER_INDEX = 10;
    public static final int CROP_VALUE_HEADER_INDEX = 11;

    public static final int HEADER_OFFSET = 3;
    public static final int MAX_COLUMNS_SIZE = 12;

    private GrainTransferService grainTransferService;
    private MaterialLasService materialLasService;
    private AttachmentService attachmentService;
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;

    private RtFilter filter;
    private RtDataModel searchResult;
    private List<MaterialLas> materialLasList;
    private RtView rtView;
    private String deleteReason;
    private Long idAttachmentToDelete;
    private DocumentsUploader<GrainTransfer> documentsUploader;
    private BeanValidator beanValidator;
    private RemoteService remoteService;

    public String begin() {
        LOG.debug("retrieving services");
        grainTransferService = getService(GrainTransferService.class);
        materialLasService = getService(MaterialLasService.class);
        attachmentService = getService(AttachmentService.class);
        unsuccessfulInvocationService = getService(UnsuccessfulRemoteInvocationService.class);
        remoteService = getService(RemoteService.class);
        beanValidator= getService(BeanValidator.class);
        documentsUploader = new DocumentsUploader<GrainTransfer>();
        filter = new RtFilter();
        LOG.debug("Loading combos");
        loadCombos();
        LOG.debug("return --" + PAGE_SEARCH_FORM);
        return PAGE_SEARCH_FORM;

    }

    private void loadCombos(){
        LOG.debug("loadCombos");
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    private boolean validateFilters(){
        LOG.debug("validateFilters");

        if(filter.getGenerationDateFrom() != null && filter.getGenerationDateTo() != null && filter.getGenerationDateFrom().after(filter.getGenerationDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    public String search(){
        LOG.debug("search");
        if (validateFilters()){
            for(MaterialLas material: materialLasList){
                if(material.getId().equals(filter.getCropTypeId())){
                    filter.setMaterialLas(material);
                    break;
                }
            }

            searchResult = new RtDataModel(grainTransferService, filter);
            LOG.debug("returning search result");
            return PAGE_SEARCH_RESULT;
        }
        LOG.debug("returning null");
        return null;
    }

    public void deleteGrainTransfer(){
        LOG.debug("delete Grain Transfer");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    GrainTransfer grainTransfer = grainTransferService.get(rtView.getId());
                    grainTransfer.setDeleteReason(deleteReason);
                    grainTransferService.delete(grainTransfer);
                    unsuccessfulInvocationService.clearPendingInvocations(grainTransfer);
                    remoteService.delete(grainTransfer);
                }
            });
            search();
        } catch (RemoteServiceException ex){
            LOG.error("A remote error occurred deleting RT: ", ex);
            addMessage(getMessageBundle("com.monsanto.barter.ar.sap.cannotDelete") + getMessageBundle(ex.getMessage()));
        } catch (BusinessException ex){
            LOG.error("An error occurred deleting RT: ", ex);
            addMessage(ex);
        }
    }

    public void selectedRow(){
        rtView = searchResult.getRowData();
    }

    public String clear(){
        LOG.debug("Clear");
        filter = new RtFilter();
        return PAGE_SEARCH_FORM;
    }

    public void setAttachmentToDelete(){
        rtView = searchResult.getRowData();
    }

    public void deleteAttachment(){
        LOG.debug("Deleting Attachment");
        grainTransferService.deleteAttachment(rtView.getId(), idAttachmentToDelete);
        AttachmentView attachmentToDelete = null;
        for(AttachmentView attachmentView:rtView.getListAttachmentView()){
            if(attachmentView.getId().equals(idAttachmentToDelete)){
                attachmentToDelete = attachmentView;
                break;
            }
        }

        if(attachmentToDelete != null){
            rtView.getListAttachmentView().remove(attachmentToDelete);
        } else {
            LOG.error("An error occurred while deleting an attachment: attachment not found ({})", idAttachmentToDelete);
        }
    }

    //TODO: Revisar este metodo
    public void downloadFile(){
        LOG.debug("Downloading Attachment");
        Attachment attachment = attachmentService.get(idAttachmentToDelete);
        if (attachment != null){
            HttpServletResponse response = getResponse();
            response.setContentType(attachment.getFile().getMimeType());
            response.setHeader("Content-Disposition", "attachment;filename=" + attachment.getFile().getFileName());
            try {
                response.getOutputStream().write(attachment.getFile().getFileContent());
                response.getOutputStream().flush();
                response.getOutputStream().close();
                getFacesContext().responseComplete();
            } catch (IOException e) {
                LOG.error("An error occurred downloading the file", e);
                addMessage(e);
            }
        } else {
            LOG.error("An error occurred while downloading an attachment: attachment not found ({})", idAttachmentToDelete);
        }
    }

    public void prepareFileUploadForm() {
        LOG.debug("Preparing FileUploadForm");
        rtView = searchResult.getRowData();
        GrainTransfer grainTransfer = grainTransferService.get(rtView.getId());
        documentsUploader.init((DocumentUploadService<GrainTransfer>) grainTransferService, beanValidator, grainTransfer);
    }

    public void attachFiles() {
        if(!documentsUploader.isEmptyFiles()) {
            GrainTransfer grainTransfer = grainTransferService.get(rtView.getId());
            List<AttachmentView> attachmentsView = new ArrayList<AttachmentView>();
            for (Attachment attachment : documentsUploader.getAttachments()) {
                grainTransfer.addAttachment(attachment);
                attachmentsView.add(new AttachmentView(attachment));
            }
            grainTransferService.update(grainTransfer);
            if (rtView.getListAttachmentView() != null) {
                rtView.getListAttachmentView().addAll(attachmentsView);
            } else {
                rtView.setListAttachmentView(attachmentsView);
            }
        }
        documentsUploader.leave();
    }

    public void cancelAttachFiles(){
        documentsUploader.leave();
    }

    public void onRowToggle(ToggleEvent event) {
        RtView selectedRtView = (RtView) event.getData();
        if (selectedRtView.getListAttachmentView() == null) {
            selectedRtView.setListAttachmentView(grainTransferService.getAttachments(selectedRtView.getId()));
        }
    }

    public RtFilter getFilter() {
        return filter;
    }

    public void setFilter(RtFilter filter) {
        this.filter = filter;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public DataModel<RtView> getSearchResult() {
        return searchResult;
    }

    public String getDeleteReason() {
        return deleteReason;
    }

    public void setDeleteReason(String deleteReason) {
        this.deleteReason = deleteReason;
    }

    public RtView getRtView() {
        return rtView;
    }

    public void setRtView(RtView rtView) {
        this.rtView = rtView;
    }

    public Long getIdAttachmentToDelete() {
        return idAttachmentToDelete;
    }

    public void setIdAttachmentToDelete(Long idAttachmentToDelete) {
        this.idAttachmentToDelete = idAttachmentToDelete;
    }

    public DocumentsUploader<GrainTransfer> getDocumentsUploader() {
        return documentsUploader;
    }

    public void setDocumentsUploader(DocumentsUploader<GrainTransfer> documentsUploader) {
        this.documentsUploader = documentsUploader;
    }


    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), 2);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(EXCEL_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(EXCEL_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(DATE_FROM_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(DATE_TO_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(CUIT_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(CUIT_VALUE_HEADER_INDEX);
        HSSFCell cell8 = row.createCell(NAME_HEADER_INDEX);
        HSSFCell cell9 = row.createCell(NAME_VALUE_HEADER_INDEX);
        HSSFCell cell10 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell11 = row.createCell(CROP_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        cell0.setCellValue(getMessageBundle("label.report.excel.number"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell2.setCellStyle(cellStyle);
        if (filter.getGenerationDateFrom() != null) {
            cell3.setCellValue(sdf.format(filter.getGenerationDateFrom()));
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell4.setCellStyle(cellStyle);
        if (filter.getGenerationDateTo() != null) {
            cell5.setCellValue(sdf.format(filter.getGenerationDateTo()));
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.CUIT"));
        cell6.setCellStyle(cellStyle);
        cell7.setCellValue(filter.getDocument());

        cell8.setCellValue(getMessageBundle("label.report.excel.name"));
        cell8.setCellStyle(cellStyle);
        cell9.setCellValue(filter.getDescription());

        cell10.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell10.setCellStyle(cellStyle);

        if (filter.getMaterialLas() != null) {
            cell11.setCellValue(filter.getMaterialLas().getCommercialText());
        } else {
            cell11.setCellValue("");
        }
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(2);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

}
