package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtDepositor;
import com.monsanto.barter.ar.business.entity.RspVat;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author LABAEZ
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class DepositorSectionCC extends RtInputBaseStep {

    protected static final String DEPOSITOR_KEY = "com.monsanto.barter.ar.business.entity.GrainTransfer.depositor";

    private String idRspVat;

    private List<RspVat> rspVatList;

    @Autowired
    private RspVatService rspVatService;

    @Autowired
    private LocationCC depositorCity;

    @Autowired
    private CustomerCC depositorCC;

    private static final Logger LOG = LoggerFactory.getLogger(DepositorSectionCC.class);

    @Override
    public void begin() {
        LOG.debug("Start begin Method InitialDataSectionCC ");
        if(getRtInput().getId() != null){
            setCustomerAndLocationFromAddInput();
            if (getRtInput().getDepositorRspVat()!= null) {
                setIdRspVat(getRtInput().getDepositorRspVat().getId());
            }
        }
        depositorCC.setForceSelection(true);
        loadParticipants();
        loadLocations();
        loadIvaCombo();
    }

    private void setCustomerAndLocationFromAddInput(){
        depositorCC.setCustomer(getRtInput().getDepositor());
        depositorCity.setCity(getRtInput().getDepositorCity());
    }

    private void loadParticipants(){
        depositorCC.getSelectedCustomer();
    }

    private void loadIvaCombo() {
        try {
            setRspVatList(rspVatService.findAll());
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred initializing RtTransferSectionCC: ", ex);
        }
    }

    private RspVat recoverIva() {
        final String id = getIdRspVat();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (RspVat) CollectionUtils.find(rspVatList, predicate);
        }
        return null;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {

            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(RtDepositor.class);
    }

    @Override
    public void setValuesFromComponents(){
        getRtInput().setDepositorRspVat(recoverIva());
        getRtInput().setDepositor(depositorCC.getSelectedCustomer());
        getRtInput().setDepositorCity(depositorCity.getCitySelected());
    }

    @Override
    public boolean validate() {
        boolean validCustomers = true;
        List<String> violationMessages = getValidator().validate(getRtInput().getDepositor(), DEPOSITOR_KEY);
        if (!violationMessages.isEmpty()) {
            addValidationMessages(violationMessages);
            validCustomers = false;
        }
        return super.validate() && validCustomers;
    }

    private void addValidationMessages(List<String> violationMessages) {
        for (String violationMessage : violationMessages){
            addMessage(violationMessage);
        }
    }

    private void loadLocations() {
        depositorCity.getCitySelected();
    }

    public LocationCC getDepositorCity() {
        return depositorCity;
    }

    public void setDepositorCity(LocationCC depositorCity) {
        this.depositorCity = depositorCity;
    }

    public CustomerCC getDepositorCC() {
        return depositorCC;
    }

    public void setDepositorCC(CustomerCC depositorCC) {
        this.depositorCC = depositorCC;
    }

    public String getIdRspVat() {
        return idRspVat;
    }

    public void setIdRspVat(String idRspVat) {
        this.idRspVat = idRspVat;
    }

    public List<RspVat> getRspVatList() {
        return rspVatList;
    }

    public void setRspVatList(List<RspVat> rspVatList) {
        this.rspVatList = rspVatList;
    }

    public void setRspVatService(RspVatService rspVatService) {
        this.rspVatService = rspVatService;
    }
}
