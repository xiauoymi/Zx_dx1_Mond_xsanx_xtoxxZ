package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtDepository;
import com.monsanto.barter.ar.business.entity.RspVat;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 1/7/14
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class DepositorySectionCC extends RtInputBaseStep {

    private static final Logger LOG = LoggerFactory.getLogger(DepositorySectionCC.class);

    private List<RspVat> rspVatList;
    private String rspVatIvaId;

    @Autowired
    private RspVatService rspVatService;

    @Autowired
    private LocationCC depLocation;


    @Override
    public void begin() {
        loadCombo();
        if(getRtInput().getId()!=null){
            depLocation.setCity(getRtInput().getDepositaryCity());
            if (getRtInput().getDepositaryRspVat() != null) {
                setRspVatIvaId(getRtInput().getDepositaryRspVat().getId());
            }
        }
        loadLocations();
    }

    private void loadLocations() {
        depLocation.getCitySelected();
    }


    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(RtDepository.class);
    }

    private void loadCombo() {
        try {
            setRspVatList(rspVatService.findAll());
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred initializing WizardRTStep: ", ex);
        }
    }

    @Override
    public void setValuesFromComponents(){
        try {
            this.getRtInput().setDepositaryRspVat(recoverIva());
            if(depLocation!=null && depLocation.getCitySelected()!=null) {
                this.getRtInput().setDepositaryCity(depLocation.getCitySelected());
            }
        } catch (BusinessException e) {
            addMessage(e);
            LOG.error("An error occurred setting values in WizardRTStep: ", e);
        }
    }

    private RspVat recoverIva() {
        final String id = getRspVatIvaId();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (RspVat) CollectionUtils.find(rspVatList, predicate);
        }
        return null;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }


    public LocationCC getDepLocation() {
        return depLocation;
    }

    public void setDepLocation(LocationCC depLocation) {
        this.depLocation = depLocation;
    }

    public List<RspVat> getRspVatList() {
        return rspVatList;
    }

    public void setRspVatList(List<RspVat> rspVatList) {
        this.rspVatList = rspVatList;
    }

    public String getRspVatIvaId() {
        return rspVatIvaId;
    }

    public void setRspVatIvaId(String rspVatIvaId) {
        this.rspVatIvaId = rspVatIvaId;
    }

    public RspVatService getRspVatService() {
        return rspVatService;
    }

    public void setRspVatService(RspVatService rspVatService) {
        this.rspVatService = rspVatService;
    }
}
