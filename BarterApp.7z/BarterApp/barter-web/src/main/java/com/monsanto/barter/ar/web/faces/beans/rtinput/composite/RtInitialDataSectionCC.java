package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtInitialData;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 1/7/14
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class RtInitialDataSectionCC extends RtInputBaseStep {

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(RtInitialData.class);
    }

}
