package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;

/**
 * Created with IntelliJ IDEA.
 * User: IVERT
 * Date: 2/3/14
 * Time: 2:23 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class RtInputBaseStep extends AbstractWizardStepCC {

    public GrainTransfer getRtInput(){
        return (GrainTransfer) getEntity();
    }

}
