package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtTransfer;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.RspVat;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 1/7/14
 * Time: 8:14 AM
 * To change this template use File | Settings | File Templates.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class RtTransferSectionCC extends RtInputBaseStep {

    protected static final String RECEPTOR_KEY = "com.monsanto.barter.ar.business.entity.GrainTransfer.receptor";

    private List<MaterialLas> materialLasList;

    private Long idMaterialLas;

    private String idRspVat;

    private List<RspVat> rspVatList;

    @Autowired
    private MaterialLasService materialLasService;

    @Autowired
    private RspVatService rspVatService;

    @Autowired
    private LocationCC receptorCity;

    @Autowired
    private CustomerCC receptorCC;

    private static final Logger LOG = LoggerFactory.getLogger(DepositorSectionCC.class);

    @Override
    public void begin() {
        LOG.debug("Start begin Method RtTransferSectionCC ");
        if(getRtInput().getId() != null){
            setCustomerAndLocationFromAddInput();
            if (getRtInput().getDepositorRspVat() != null) {
                setIdRspVat(getRtInput().getDepositorRspVat().getId());
            }
            setIdMaterialLas(getRtInput().getDetailCropType().getId());
        }
        receptorCC.setForceSelection(true);
        loadParticipants();
        loadLocations();
        loadCropTypeCombo();
        loadIvaCombo();
    }

    private void loadCropTypeCombo() {
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred initializing RtTransferSectionCC: ", ex);
        }
    }

    private void loadIvaCombo() {
        try {
            setRspVatList(rspVatService.findAll());
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred initializing RtTransferSectionCC: ", ex);
        }
    }

    private void setCustomerAndLocationFromAddInput(){
        receptorCC.setCustomer(getRtInput().getReceptor());
        receptorCity.setCity(getRtInput().getReceptorCity());
    }

    private void loadParticipants(){
        receptorCC.getSelectedCustomer();
    }

    @Override
    protected void initializeValidators() {
        getGroups().clear();
        getGroups().add(RtTransfer.class);
    }

    @Override
    public void setValuesFromComponents(){
        getRtInput().setDetailCropType(recoverCropType());
        getRtInput().setReceptorRspVat(recoverIva());
        getRtInput().setReceptor(receptorCC.getSelectedCustomer());
        getRtInput().setReceptorCity(receptorCity.getCitySelected());
    }

    private MaterialLas recoverCropType() {
        final Long id = getIdMaterialLas();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (MaterialLas) CollectionUtils.find(materialLasList, predicate);
        }
        return null;
    }

    private RspVat recoverIva() {
        final String id = getIdRspVat();
        if (id != null){
            Predicate predicate = createPredicate(id);
            return (RspVat) CollectionUtils.find(rspVatList, predicate);
        }
        return null;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {

            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }

    @Override
    public boolean validate() {
        boolean validCustomers = true;
        List<String> violationMessages = getValidator().validate(getRtInput().getReceptor(), RECEPTOR_KEY);
        if (!violationMessages.isEmpty()) {
            addValidationMessages(violationMessages);
            validCustomers = false;
        }
        return super.validate() && validCustomers;
    }

    private void addValidationMessages(List<String> violationMessages) {
        for (String violationMessage : violationMessages){
            addMessage(violationMessage);
        }
    }

    private void loadLocations() {
        receptorCity.getCitySelected();
    }

    public LocationCC getReceptorCity() {
        return receptorCity;
    }

    public void setReceptorCity(LocationCC receptorCity) {
        this.receptorCity = receptorCity;
    }

    public CustomerCC getReceptorCC() {
        return receptorCC;
    }

    public void setReceptorCC(CustomerCC receptorCC) {
        this.receptorCC = receptorCC;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public Long getIdMaterialLas() {
        return idMaterialLas;
    }

    public void setIdMaterialLas(Long idMaterialLas) {
        this.idMaterialLas = idMaterialLas;
    }

    public String getIdRspVat() {
        return idRspVat;
    }

    public void setIdRspVat(String idRspVat) {
        this.idRspVat = idRspVat;
    }

    public List<RspVat> getRspVatList() {
        return rspVatList;
    }

    public void setRspVatList(List<RspVat> rspVatList) {
        this.rspVatList = rspVatList;
    }

    public void setMaterialLasService(MaterialLasService materialLasService) {
        this.materialLasService = materialLasService;
    }

    public void setRspVatService(RspVatService rspVatService) {
        this.rspVatService = rspVatService;
    }
}
