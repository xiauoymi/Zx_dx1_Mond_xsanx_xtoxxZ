package com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel;

import com.monsanto.barter.ar.business.service.GrainTransferService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.RtFilter;
import com.monsanto.barter.ar.business.service.dto.RtView;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author JPBENI
 */
public class RtDataModel extends LazyDataModel<RtView> {
    private final GrainTransferService service;
    private final RtFilter filter;

    private List<RtView> page = new ArrayList<RtView>(0);

    public RtDataModel(final GrainTransferService service, final RtFilter filter) {
        this.service = service;
        this.filter = filter;
    }

    @Override
    public List<RtView> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,String> filters) {
        Paging.SortOrder order;
        if (SortOrder.DESCENDING == sortOrder) {
            order = Paging.SortOrder.DESC;
        } else {
            order = Paging.SortOrder.ASC;
        }
        Recordset<RtView> results = service.search(filter, new Paging(first, pageSize, sortField, order));
        setRowCount((int) results.getRecordCount());
        page = results.getRecords();
        return page;
    }

    @Override
    public RtView getRowData(String rowKey) {
        return getRowData(Long.valueOf(rowKey));
    }

    public RtView getRowData(Long rowId) {
        for (RtView row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(RtView object) {
        return object.getId().toString();
    }
}