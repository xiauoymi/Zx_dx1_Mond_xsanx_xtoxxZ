package com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel;

import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.RtReportView;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

/**
 * @author LABAEZ
 */
public class RtReportDataModel extends AbstractDataModel <RtReportView, RtReportFilter> {
    private final ReportService service;

    public RtReportDataModel(final ReportService service, final RtReportFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    protected Recordset<RtReportView> loadPage(RtReportFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public RtReportView getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (RtReportView row : getPage()) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(RtReportView object) {
        return object.getId().toString();
    }
}
