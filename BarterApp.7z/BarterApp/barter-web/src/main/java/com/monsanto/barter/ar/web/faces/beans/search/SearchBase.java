package com.monsanto.barter.ar.web.faces.beans.search;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.model.LazyDataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by JASANC5 on 10/22/2014.
 */
public abstract class SearchBase<D extends LazyDataModel, F, S> extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(SearchBase.class);
    protected D searchResult;
    protected F filter;
    protected S service;
    private int headerOffset;
    private static final String PAGE_SEARCH_RESULT = "search-result";
    protected static final int MAX_COLUMNS_SIZE = 25;
    private  SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private HSSFCellStyle filterCellStyle;

    protected abstract void initFilter();

    protected abstract void initServices();

    protected abstract void loadComponents();

    protected abstract boolean validateFilters();

    protected abstract void initSearch();

    protected abstract void createHeader(HSSFWorkbook wb);

    public String begin() {
        LOG.debug("Setting filters.");
        initFilter();
        LOG.debug("Retrieving services.");
        initServices();
        loadComponents();

        return SUCCESS;
    }

    public String clear() {
        initFilter();
        LOG.debug("Clear fields.");
        return SUCCESS;
    }

    public String search() {
        LOG.debug("Search.");

        if (validateFilters()) {
            initSearch();

            return PAGE_SEARCH_RESULT;
        }

        LOG.debug("Returning null.");

        return null;
    }

    public F getFilter() {
        return filter;
    }

    public void setFilter(F filter) {
        this.filter = filter;
    }

    public D getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(D searchResult) {
        this.searchResult = searchResult;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createFilterCellsSytle(wb);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createFilterCellsSytle(HSSFWorkbook wb) {
        filterCellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        filterCellStyle.setFont(font);
    }

    private void addStyleToHeader(HSSFWorkbook wb) {
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(headerOffset - 1);
        for (int i = 0; i < header.getPhysicalNumberOfCells(); i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        for (int rowIndex = headerOffset; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }
    private void adjustColumnSize(HSSFSheet sheet) {
        for (int i = 0; i <= MAX_COLUMNS_SIZE; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    protected HSSFCell createCellFor(HSSFRow row,int columnNumber,String columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellStyle(filterCellStyle);
        cell.setCellValue(columnValue);
        return cell;
    }

    protected HSSFCell createCellFor(HSSFRow row,int columnNumber,Date columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellStyle(filterCellStyle);
        if (columnValue!=null){
            cell.setCellValue(sdf.format(columnValue));
        }else{
            cell.setCellValue("");
        }
        return cell;
    }


    protected void createFooter(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));

    }

    public HSSFCellStyle getFilterCellStyle() {
        return filterCellStyle;
    }

    public int getHeaderOffset() {
        return headerOffset;
    }

    public void setHeaderOffset(int headerOffset) {
        this.headerOffset = headerOffset;
    }
}
