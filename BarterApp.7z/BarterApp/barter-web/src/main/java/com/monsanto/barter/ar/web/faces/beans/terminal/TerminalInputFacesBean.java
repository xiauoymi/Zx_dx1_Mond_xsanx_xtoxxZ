package com.monsanto.barter.ar.web.faces.beans.terminal;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.Port;
import com.monsanto.barter.ar.business.entity.Terminal;
import com.monsanto.barter.ar.business.entity.TurnAddressee;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.entity.enumerated.TerminalType;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TerminalService;
import com.monsanto.barter.ar.business.service.TurnAddresseeService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import com.monsanto.barter.ar.web.faces.composite.TurnAddresseeCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vnbarr on 10/3/2014.
 */

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class TerminalInputFacesBean extends ArBaseJSF {

    public static final String LABEL_INPUT_TERMINAL_LOAD = "label.input.terminal.load";
    public static final String SAVED = "saved";
    public static final String LABEL_INPUT_ADDRESSEE_DELETED_ERROR = "label.input.addressee.deleted.error";
    private TerminalService terminalService;
    private TurnAddresseeService turnAddresseeService;
    private BeanValidator<Terminal> beanValidator;

    private Terminal terminal = new Terminal();
    private Port port;
    private PortDestinationDTO portDto;
    private Long terminalId;
    private CustomerCC terminalCustomer;
    private TurnAddresseeCC addresseeCC;
    private TurnAddressee addressee;
    private LocationCC stockingCenterLocation;

    private Mode mode;

    private static final Logger LOG = LoggerFactory.getLogger(TerminalInputFacesBean.class);
    private TurnAddressee addresseeSelected;
    private PortService portService;

    private String destinationCuit;
    private String destinationName;
    private boolean destinationNameEnabled;


    public Port getPort() {
        return port;
    }

    public void setPort(Port port) {
        this.port = port;
    }

    public String begin() {
        terminalId = null;
        init(Mode.CREATE);
        return SUCCESS;
    }

    public String edit() {
        init(Mode.UPDATE);
        return SUCCESS;
    }

    public String view() {
        init(Mode.VIEW);
        return SUCCESS;
    }

    private void init(Mode mode) {
        this.mode = mode;
        this.terminalService = getService(TerminalService.class);
        portService = getService(PortService.class);
        this.terminalCustomer = getService(CustomerCC.class);
        beanValidator = getService(BeanValidator.class);
        addresseeCC = getService(TurnAddresseeCC.class);
        stockingCenterLocation = getService(LocationCC.class);
        turnAddresseeService = getService(TurnAddresseeService.class);
        clear();
        loadComponentsFromTerminal();
    }

    private void loadComponentsFromTerminal() {
        try {
            if (terminalId != null) {
                terminal = terminalService.get(terminalId);
                port = terminal.getPort();
                if (port != null) {
                    portDto = portService.getPortDTO(port.getId());
                }

                this.stockingCenterLocation.setCity(terminal.getStockingCenterCity());
                this.terminalCustomer.setCustomer(terminal.getCustomerDestination());
            }
        } catch (BusinessException e) {
            LOG.error(getMessageBundle(LABEL_INPUT_TERMINAL_LOAD), e);
            addMessage(getMessageBundle(LABEL_INPUT_TERMINAL_LOAD));
        }
    }


    public TerminalInputFacesBean() {
        terminal = new Terminal();
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public void setTerminal(Terminal terminal) {
        this.terminal = terminal;
    }

    public void preSave() {
        setValuesFromComponents();
        addCallbackParam("isValid", isValid(terminal));
    }

    private void setValuesFromComponents() {

        if (isTerminalTypeStockingCenter()) {
            terminal.setStockingCenterCity(stockingCenterLocation.getCity());
            terminal.setPort(null);
        } else {
            terminal.setStockingCenterCity(null);
            terminal.setPort(getPort());
        }
        if(terminalCustomer.getSelectedCustomer()!=null && terminalCustomer.getSelectedCustomer().getId()!=null){
            terminal.setCustomerDestination(terminalCustomer.getSelectedCustomer());
            terminal.setDestinationCuit(null);
            terminal.setDestinationName(null);
        }else{
            terminal.setCustomerDestination(null);
            terminal.setDestinationCuit(destinationCuit);
            terminal.setDestinationName(destinationName);
        }
    }

    public String save() {
        String result = SUCCESS;
        try {
            LOG.debug("Save terminal");
            if (terminal.getId() != null) {
                LOG.debug("Update terminal");
                terminalService.update(terminal);
                addMessageNoError(getMessageBundle("label.input.terminal.updated") + terminal.getName());
                result = "search";
            } else {
                LOG.debug("Save new terminal");
                terminalService.save(terminal);
                addMessageNoError(getMessageBundle("label.input.terminal.created") + terminal.getName());
            }
            setPortDto(null);
            addCallbackParam(SAVED, true);
            clear();
        } catch (BusinessException be) {
            LOG.error("Error al guardar terminal", be);
            addMessage(getMessageBundle("label.input.terminal.creation.error") + terminal.getName());
            addCallbackParam(SAVED, false);
            result = ERROR;
        }
        return result;

    }

    private boolean isValid(Terminal terminal) {
        LOG.debug("VALIDATION  - Class:{} ", this.getClass().getName());
        List<String> violationMessages = beanValidator.validate(terminal);
        //validations related to terminal type
        if (isTerminalTypeStockingCenter()) {
            if (terminal.getStockingCenterCity() == null) {
                violationMessages.add(getMessageBundle("terminal.stockingCenter.location"));
            }
        } else {
            if (terminal.getOnccaNumber() == null) {
                violationMessages.add(getMessageBundle("terminal.portTerminal.oncca"));
            }
            if (port == null) {
                violationMessages.add(getMessageBundle("terminal.portTerminal.port"));
            }
        }

        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    public String cancel() {
        clear();
        return SUCCESS;
    }

    public boolean isCreateMode() {
        return mode.equals(Mode.CREATE);
    }

    public boolean isActive() {
        return terminal.getStatus().equals(StatusEnum.ACTIVE);
    }

    public void setActive(boolean checked) {
        if (checked) {
            terminal.setStatus(StatusEnum.ACTIVE);
        } else {
            terminal.setStatus(StatusEnum.INACTIVE);
        }
    }

    public boolean isTerminalTypeStockingCenter() {
        return terminal.getTerminalType().equals(TerminalType.STOCKING_CENTER);
    }

    public void setTerminalTypeStockingCenter(boolean checked) {
        if (checked) {
            terminal.setTerminalType(TerminalType.STOCKING_CENTER);
        } else {
            terminal.setTerminalType(TerminalType.PORT_TERMINAL);
        }
    }

    public void handlePortSelect(SelectEvent event) {
        portDto = (PortDestinationDTO) event.getObject();
    }

    public List<PortDestinationDTO> portAutocomplete(String query) {
        return portService.search(query);
    }

    public List<TurnAddressee> addresseeAutocomplete(String query) {
        return turnAddresseeService.searchForAutoComplete(query);
    }

    public PortDestinationDTO getPortDto() {
        return portDto;
    }

    public void setPortDto(PortDestinationDTO portDto) {
        this.portDto = portDto;
        try {
            if (portDto != null && portDto.getId()!= null) {
                if (port == null || !portDto.getId().equals(port.getId())) {
                    port = portService.get(portDto.getId());
                }
            } else {
                this.port = null;
            }
        } catch (BusinessException e) {
            addMessage("Ocurrio un error recuperando el puerto");
            LOG.debug("Ocurrio un error recuperando el puerto", e);
            this.port = null;
        }
    }

    public String getPortName() {
        if (port != null) {
            return port.getStorageLocationDescription();
        }
        return "";
    }

    public void clear() {
        destinationNameEnabled = false;
        destinationName = null;
        destinationCuit = null;
        terminal = new Terminal();
        port = null;
        portDto = null;
        terminalCustomer.clearCustomer();
        stockingCenterLocation.clear();
        addressee = new TurnAddressee();
        if(addresseeCC !=null ){
            addresseeCC.clear();
        }
    }

    public Long getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Long terminalId) {
        this.terminalId = terminalId;
    }

    public boolean isReadOnly() {
        return mode.isReadOnly();
    }

    public CustomerCC getTerminalCustomer() {
        return terminalCustomer;
    }

    public void setTerminalCustomer(CustomerCC terminalCustomer) {
        this.terminalCustomer = terminalCustomer;
    }


    public void preSaveAddressee() {
        if (validateUniqueAddresses()) {
            terminal.getAddressees().add(addressee);
            addressee = new TurnAddressee();
        } else {
            addMessage(getMessageBundle("label.input.terminal.addAddressee.error"));
        }
    }

    private boolean validateUniqueAddresses() {
        if (!terminal.getAddressees().isEmpty()) {
            TurnAddressee turnAddressee = MonCollectionsUtils.findByPrimaryKey(terminal.getAddressees(), addressee.getId());
            if (turnAddressee != null) {
                return false;
            }
        }
        return true;
    }

    public boolean isAddAddresseeEnable() {
        return (addressee != null && addressee.getId() != null);
    }

    public void selectAddressee(ActionEvent event) {
        addresseeSelected = (TurnAddressee) event.getComponent().getAttributes().get("addressee");
    }

    public void deleteAddressee() {
        try {
            LOG.debug("Going to delete addressee");
            terminal.getAddressees().remove(addresseeSelected);
            if(addresseeCC!= null){
                addresseeCC.clear();
            }
        } catch (BusinessException be) {
            addMessage(getMessageBundle(LABEL_INPUT_ADDRESSEE_DELETED_ERROR) + addresseeSelected.getAddresseeName());
            LOG.error(getMessageBundle(LABEL_INPUT_ADDRESSEE_DELETED_ERROR), be);
        }
    }

    public List<TurnAddressee> getAddressees() {
        return new ArrayList<TurnAddressee>(terminal.getAddressees());
    }

    public LocationCC getStockingCenterLocation() {
        return stockingCenterLocation;
    }

    public void setStockingCenterLocation(LocationCC stockingCenterLocation) {
        this.stockingCenterLocation = stockingCenterLocation;
    }

    public boolean isDestinationNameEnabled() {
        return destinationNameEnabled;
    }

    public void handleDestinationSelect() {
        destinationCuit = terminalCustomer.getDocumentNumber();
        destinationName = null;
        destinationNameEnabled = (terminalCustomer.getSelectedCustomer() == null);
    }

    public void handleDestinationClear() {
        destinationCuit = null;
        destinationName = null;
        destinationNameEnabled = false;
    }

    public TurnAddresseeCC getAddresseeCC() {
        return addresseeCC;
    }

    public void setAddresseeCC(TurnAddresseeCC addresseeCC) {
        this.addresseeCC = addresseeCC;
    }

    public TurnAddressee getAddressee() {
        return addressee;
    }

    public void setAddressee(TurnAddressee addressee) {
        this.addressee = addressee;
    }

    public void handleAddresseeSelect(SelectEvent event) {
        this.addressee = (TurnAddressee) event.getObject();

    }

    public void handleAddresseeClear() {
        this.addressee = new TurnAddressee();
    }

    public String getDestinationName() {
        return destinationName;
    }

    public void setDestinationName(String destinationName) {
        this.destinationName = destinationName;
    }
}
