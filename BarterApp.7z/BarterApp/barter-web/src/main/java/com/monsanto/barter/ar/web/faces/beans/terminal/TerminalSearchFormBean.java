package com.monsanto.barter.ar.web.faces.beans.terminal;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.Terminal;
import com.monsanto.barter.ar.business.entity.enumerated.TerminalType;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TerminalFilter;
import com.monsanto.barter.ar.business.service.TerminalService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.terminal.datamodel.TerminalDataModel;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by VNBARR on 7/29/2014.
 */
public class TerminalSearchFormBean extends ArBaseJSF {
    public static final String PAGE_SEARCH_RESULT = "terminal-search-result";
    private static final Logger LOG = LoggerFactory.getLogger(TerminalSearchFormBean.class);
    private static final int DESTINATION_NAME_HEADER_INDEX = 0;
    private static final int DESTINATION_NAME_VALUE_HEADER_INDEX = 1;
    private static final int ONCCA_HEADER_INDEX = 2;
    private static final int ONCCA_VALUE_HEADER_INDEX = 3;
    private static final int TERMINAL_TYPE_HEADER_INDEX=4;
    private static final int TERMINAL_TYPE_VALUE_HEADER_INDEX=5;
    private static final int LOCATION_HEADER_INDEX = 6;
    private static final int LOCATION_VALUE_HEADER_INDEX = 7;
    public static final int HEADER_OFFSET = 4;
    private static final int MAX_COLUMNS_SIZE = 9;
    private TerminalFilter terminalFilter;
    private TerminalService terminalService;
    private PortService portService;
    private TerminalDataModel searchResult;
    private Long terminalId;
    private TerminalType [] terminalTypes;
    private PortDestinationDTO portDestination;


    public String begin(){
        LOG.debug("Setting filters.");
        terminalFilter = new TerminalFilter();
        LOG.debug("Retrieving services.");
        terminalService = getService(TerminalService.class);
        portService = getService(PortService.class);
        terminalTypes = TerminalType.values();
        portDestination=null;

        return SUCCESS;
    }

    public String search(){
        LOG.debug("Search.");
        if(portDestination !=null){
            terminalFilter.setPort(portService.get(portDestination.getId()));
        }

        searchResult = new TerminalDataModel(terminalService,terminalFilter);
        LOG.debug("Search -> Result");
        return PAGE_SEARCH_RESULT;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        terminalFilter = new TerminalFilter();
        portDestination=null;
        return SUCCESS;
    }

    public TerminalFilter getTerminalFilter() {
        return terminalFilter;
    }

    public void setTerminalFilter(TerminalFilter terminalFilter) {
        this.terminalFilter = terminalFilter;
    }

    public TerminalDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(TerminalDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public void selectedRow(){
        terminalId = searchResult.getRowData().getId();
    }

    public Long getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Long terminalId) {
        this.terminalId = terminalId;
    }

    public void deleteTerminal() {
        LOG.debug("Delete Terminal.");
        try {
            Terminal terminal = terminalService.get(terminalId);
            terminalService.delete(terminal);
            addMessageNoError(getMessageBundle("label.input.terminal.deleted")+ terminal.getName());
            search();
        } catch (BarterException ex) {
            addMessage(getMessageBundle("label.input.terminal.deleted.error"));
            LOG.error("An error occurred deleting terminal: ", ex);
        }
    }


    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }


    private void createHeader(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET-1);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(DESTINATION_NAME_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(DESTINATION_NAME_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(ONCCA_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(ONCCA_VALUE_HEADER_INDEX);

        HSSFCell cell4 = row.createCell(TERMINAL_TYPE_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(TERMINAL_TYPE_VALUE_HEADER_INDEX);

        HSSFCell cell6 = row.createCell(LOCATION_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(LOCATION_VALUE_HEADER_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Terminal.name"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(terminalFilter.getName());

        cell2.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Terminal.onccaNumber"));
        cell2.setCellStyle(cellStyle);
        if (terminalFilter.getOnccaNumber() != null) {
            cell3.setCellValue(terminalFilter.getOnccaNumber());
        }else{
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.terminalType"));
        cell4.setCellStyle(cellStyle);

        if(terminalFilter.getTerminalType()!=null){
            cell5.setCellValue(getMessageBundle(terminalFilter.getTerminalType().getDescription()));
            if(terminalFilter.getTerminalType().equals(TerminalType.PORT_TERMINAL)){
                cell6.setCellValue(getMessageBundle("label.report.excel.port"));
                if(portDestination != null){
                    cell7.setCellValue(portDestination.getDescription());
                }
            }
            else{
                cell6.setCellValue(getMessageBundle("label.report.excel.location"));
                if(terminalFilter.getLocation() != null){
                    cell7.setCellValue(terminalFilter.getLocation());
                }
            }
            cell6.setCellStyle(cellStyle);
        }
        else{
            cell5.setCellValue(getMessageBundle("label.report.excel.all"));
        }


    }


    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET-1);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }


    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    public TerminalType[] getTerminalTypes() {
        return terminalTypes;
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

}
