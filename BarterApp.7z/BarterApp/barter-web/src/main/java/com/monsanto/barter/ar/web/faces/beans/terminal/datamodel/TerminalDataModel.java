package com.monsanto.barter.ar.web.faces.beans.terminal.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TerminalFilter;
import com.monsanto.barter.ar.business.service.TerminalService;
import com.monsanto.barter.ar.business.service.dto.TerminalDTO;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by VNBARR on 7/29/2014.
 */
public class TerminalDataModel extends LazyDataModel<TerminalDTO> {

    private List<TerminalDTO> page = new ArrayList<TerminalDTO>(0);
    private final TerminalService service;
    private final TerminalFilter filter;

    public TerminalDataModel(TerminalService service, TerminalFilter terminalFilter) {
        this.service = service;
        this.filter = terminalFilter;
    }


    @Override
    public List<TerminalDTO> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String,String> filters) {
        Paging.SortOrder order;
        if (SortOrder.DESCENDING == sortOrder) {
            order = Paging.SortOrder.DESC;
        } else {
            order = Paging.SortOrder.ASC;
        }

        Recordset<TerminalDTO> results = service.search(filter, new Paging(first, pageSize, sortField, order));

        setRowCount((int) results.getRecordCount());
        return results.getRecords();
    }

    @Override
    public TerminalDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (TerminalDTO row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    public Object getRowKey(TerminalDTO object) {
        return object.getId().toString();
    }



}
