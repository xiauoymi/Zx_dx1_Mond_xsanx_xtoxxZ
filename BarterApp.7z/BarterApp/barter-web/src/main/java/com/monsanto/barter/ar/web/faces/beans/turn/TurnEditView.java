package com.monsanto.barter.ar.web.faces.beans.turn;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Turn;
import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;

import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.TurnsAdd;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.RowEditEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class TurnEditView extends ArBaseJSF {

    public static final String LABEL_EDIT_TURN_GETTING_TURNS_ERROR = "label.edit.turn.gettingTurns.error";
    public static final String LABEL_EDIT_TURNS_CREATION_ERROR = "label.edit.turns.creation.error";
    public static final String LABEL_EDIT_TURN_DELETE_ERROR = "label.edit.turn.delete.error";
    public static final String LABEL_EDIT_TURN_EDIT_ERROR = "label.edit.turn.edit.error";
    public static final int CONTRACT_ID_LABEL_INDEX = 0;
    public static final int CONTRACT_ID_VALUE_INDEX = 1;
    public static final int BROKER_LABEL_INDEX = 2;
    public static final int BROKER_VALUE_INDEX = 3;
    public static final int DATE_FROM_LABEL_INDEX = 4;
    public static final int DATE_FROM_VALUE_INDEX = 5;
    public static final int DATE_TO_LABEL_INDEX = 6;
    public static final int DATE_TO_VALUE_INDEX = 7;
    public static final int EXPORTER_CONTRACT_ID_LABEL_INDEX = 0;
    public static final int EXPORTER_CONTRACT_ID_VALUE_INDEX = 1;
    public static final int EXPORTER_LABEL_INDEX = 2;
    public static final int EXPORTER_VALUE_INDEX = 3;
    public static final int CROP_LABEL_INDEX = 4;
    public static final int CROP_VALUE_INDEX = 5;
    public static final int STORAGE_LOCATION_LABEL_INDEX = 0;
    public static final int STORAGE_LOCATION_VALUE_INDEX = 1;
    public static final int DESTINATION_LABEL_INDEX = 2;
    public static final int DESTINATION_VALUE_INDEX = 3;
    public static final int ADDRESSEE_LABEL_INDEX = 4;
    public static final int ADDRESSEE_VALUE_INDEX = 5;
    public static final int COLUMNS_SIZE = 14;
    public static final String LABEL_EDIT_TURNS_DATE_UPDATED_ERROR = "label.edit.turns.dateUpdated.error";
    public static final String LABEL_EDIT_TURNS_ADDED = "label.edit.turns.added";
    public static final String LABEL_EDIT_TURN_EDIT_SUCCESS = "label.edit.turn.edit.success";
    public static final String LABEL_EDIT_TURNS_DELETED = "label.edit.turns.deleted";
    public static final String LABEL_EDIT_TURNS_DATE_UPDATED = "label.edit.turns.dateUpdated";
    public static final int ROW_INDEX_4 = 4;
    public static final int DATA_HEADER=3;

    private List<TurnDTO> turns;
    private ContractView contract;
    private Date turnDate;
    private TurnDTO selectedTurn;
    private TurnsAdd turnsAdd;
    private static final Logger LOG = LoggerFactory.getLogger(TurnEditView.class);
    private TurnService turnService;
    private Date newTurnDate;
    private List<String> turnsErrorMessages = new ArrayList<String>();
    private TurnDTO previousTurn;
    private Long storageLocationId;
    private String storageLocationDescription;
    private Long destinationId;
    private String destinationDescription;

    public String begin() {
        String response = SUCCESS;
        turnsAdd = getService(TurnsAdd.class);
        turnService = getService(TurnService.class);
        clearErrorMessages();
        if (contract != null && turnDate != null) {
            newTurnDate= turnDate;
            turnsAdd.setTurnsDate(turnDate);
            turnsAdd.setContract(contract);
            turnsAdd.setEditableTurnsDate(false);
            turnsAdd.setTerminalId(destinationId);
            turnsAdd.setDestinationDescription(destinationDescription);
            loadFromDB();
        } else {
            addMessage(getMessageBundle("label.edit.turn.noContractSelected"));
            response = ERROR;
        }
        return response;
    }

    public String clearPopup(){
        turnsAdd.clear();
        return SUCCESS;
    }

    private void loadFromDB() {
        try {
            LOG.debug("try Load turn for contract {} and date {} ", contract.getContractId(), turnDate.toString());
            turns = turnService.searchTurnsByContractIdDateAndDestination(contract.getContractId(), destinationId, turnDate);
        } catch (BusinessException ex) {
            LOG.error(getMessageBundle(LABEL_EDIT_TURN_GETTING_TURNS_ERROR),ex);
            addMessage(getMessageBundle(LABEL_EDIT_TURN_GETTING_TURNS_ERROR));
        }
    }

    public void setTurnDate(Date turnDate) {
        this.turnDate = turnDate;
    }

    public void saveNewTurns() {
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    List<Turn> newTurns = turnsAdd.getTurnsList();
                    if (!newTurns.isEmpty()) {
                        turnService.saveTurns(newTurns, contract.getContractId());
                        addMessageNoError(getMessageBundle(LABEL_EDIT_TURNS_ADDED) + newTurns.size());
                        LOG.debug(getMessageBundle(LABEL_EDIT_TURNS_ADDED) + newTurns.size());
                    }

                    turnsAdd.clear();
                    turnsAdd.setTurnsDate(turnDate);

                }
            });


            loadFromDB();
        } catch (Exception e) {
            LOG.error(getMessageBundle(LABEL_EDIT_TURNS_CREATION_ERROR), e);
            addMessage(getMessageBundle(LABEL_EDIT_TURNS_CREATION_ERROR));
            LOG.error("An error occurred creating new turns:", e);
        }


    }

    public void cancelSaveTurns() {
        LOG.debug("on Cancel");
        clearPopup();
    }

    public void onEditTurnInit(RowEditEvent event) {
        TurnDTO turnFromEvent = (TurnDTO) event.getObject();
        previousTurn = new TurnDTO(null,turnFromEvent.getCode(),null,null,null);

    }

    public void onEditTurn(RowEditEvent event) {
        TurnDTO turn = (TurnDTO) event.getObject();
        try {
            if (turn.getCode().isEmpty()){
                addMessage(getMessageBundle("label.edit.turn.required.code"));
                turn.setCode(previousTurn.getCode());
            }else {
                Turn turnToUpdate = turnService.get(turn.getId());
                turnToUpdate.setCode(turn.getCode());
                turnToUpdate.setAutogenerated(false);
                turnService.update(turnToUpdate);
                addMessageNoError(getMessageBundle(LABEL_EDIT_TURN_EDIT_SUCCESS) + turnToUpdate.getCode());
                LOG.debug(getMessageBundle(LABEL_EDIT_TURN_EDIT_SUCCESS) + turnToUpdate.getCode());
            }
        } catch (BusinessException ex) {
            LOG.error(getMessageBundle(LABEL_EDIT_TURN_EDIT_ERROR),ex);
            addMessage(getMessageBundle(LABEL_EDIT_TURN_EDIT_ERROR));
            LOG.error("An error occurred editing turns:", ex);
        }
    }

    public void deleteTurns() {
        List<TurnDTO> turnToDelete = getTurnsSelected();
        try {
            turnService.deleteTurns(turnToDelete);
            loadFromDB();
            addMessageNoError(getMessageBundle(LABEL_EDIT_TURNS_DELETED) + turnToDelete.size());
            LOG.debug(getMessageBundle(LABEL_EDIT_TURNS_DELETED) + turnToDelete.size());
        } catch (Exception e) {
            addMessage(getMessageBundle(LABEL_EDIT_TURN_DELETE_ERROR));
            LOG.error(getMessageBundle(LABEL_EDIT_TURN_DELETE_ERROR), e);
            LOG.error("An error occurred editing turns:", e);
        }
    }

    public void changeDate() {
        List<TurnDTO> selectedTurns= getTurnsSelected();
        try {
            boolean validForSave = false;
            if (validateTurnsDate()) {
                turnService.changeTurnDate(selectedTurns, newTurnDate);
                loadFromDB();
                newTurnDate = turnDate;
                addMessageNoError(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED) + selectedTurns.size());
                LOG.debug(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED) + selectedTurns.size());
                validForSave = true;
            }
            addCallbackParam("validForSave", validForSave);

        } catch (BusinessException ex) {
            addMessage(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED_ERROR));
            LOG.error(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED_ERROR), ex);
        } catch (Exception e) {
            addMessage(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED_ERROR));
            LOG.error(getMessageBundle(LABEL_EDIT_TURNS_DATE_UPDATED_ERROR), e);
        }
    }

    private boolean validateTurnsDate(){
        clearErrorMessages();
        if(newTurnDate==null) {
            turnsErrorMessages.add(getMessageBundle("ar.barter.turnsAdd.error.date"));
            return false;
        }
        return true;
    }

    public void clearErrorMessages() {
        turnsErrorMessages.clear();
    }

    public void cancelChangeDate() {
        clearErrorMessages();
        newTurnDate = turnDate;
    }


    private List<TurnDTO> getTurnsSelected() {
        List<TurnDTO> turnsToDelete = new ArrayList<TurnDTO>();
        Iterator<TurnDTO> iterator = turns.iterator();
        TurnDTO tempTurn;
        while (iterator.hasNext()) {
            tempTurn = iterator.next();
            if (tempTurn.isSelected()) {
                LOG.debug("Turn Selected {}", tempTurn.getCode());
                turnsToDelete.add(tempTurn);
            }
        }
        return turnsToDelete;
    }

    public void selectedTurn(ActionEvent event) {
        TurnDTO turn = (TurnDTO) event.getComponent().getAttributes().get("turn");
        Iterator<TurnDTO> iterator = turns.iterator();
        boolean found = false;
        while (iterator.hasNext() && !found) {
            selectedTurn = iterator.next();
            if (selectedTurn.equals(turn)) {
                found = true;
            }
        }
        if (!found) {
            selectedTurn = null;
        }
    }

    public void deleteTurn() {
        LOG.debug("Turns Quantity {}", turns.size());
        LOG.debug("Turns to remove {}", selectedTurn.getCode());
        try {
            Turn turn = turnService.get(selectedTurn.getId());
            turn.setDeleted(true);
            turnService.save(turn);
            turns.remove(selectedTurn);
            addMessageNoError(getMessageBundle("label.edit.turn.delete.success") + turn.getCode());
        } catch (BusinessException ex) {
            addMessageNoError(getMessageBundle(LABEL_EDIT_TURN_DELETE_ERROR));
            LOG.error("An error occurred deleting a turn:", ex);

        }
        LOG.debug("Turns Quantity after deleted {}", turns.size());

    }

    public TurnsAdd getTurnsAdd() {
        return turnsAdd;
    }

    public void setTurnsAdd(TurnsAdd turnsAdd) {
        this.turnsAdd = turnsAdd;
    }

    public ContractView getContract() {
        return contract;
    }

    public void setContract(ContractView contract) {
        this.contract = contract;
    }

    private int countByState(TurnStatus turnStatus){
        int countByState = 0;
        for (TurnDTO turnDTO : turns){
            if (turnDTO.getStatus().equals(turnStatus) ){
                countByState++;
            }
        }
        return countByState;
    }

    public int getAssignedTurnsCount(){
        return countByState(TurnStatus.ASSIGNED);
    }

    public int getAvailableTurnsCount(){
        return countByState(TurnStatus.AVAILABLE);
    }

    public int getUnavailableTurnsCount(){
        return countByState(TurnStatus.CANCELLED);
    }

    public int getTotalTurnsCount(){
        return turns.size();
    }

    public Date getTurnDate() {
        return turnDate;
    }

    public Date getNewTurnDate() {
        return newTurnDate;
    }

    public void setNewTurnDate(Date newTurnDate) {
        this.newTurnDate = newTurnDate;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb){
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0, sheet.getLastRowNum(), DATA_HEADER);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(CONTRACT_ID_LABEL_INDEX);
        HSSFCell cell1 = row.createCell(CONTRACT_ID_VALUE_INDEX);
        HSSFCell cell2 = row.createCell(BROKER_LABEL_INDEX);
        HSSFCell cell3 = row.createCell(BROKER_VALUE_INDEX);
        HSSFCell cell4 = row.createCell(DATE_FROM_LABEL_INDEX);
        HSSFCell cell5 = row.createCell(DATE_FROM_VALUE_INDEX);
        HSSFCell cell6 = row.createCell(DATE_TO_LABEL_INDEX);
        HSSFCell cell7 = row.createCell(DATE_TO_VALUE_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        cell0.setCellValue(getMessageBundle("label.report.excel.turn.contractNumber"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(contract.getNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.broker"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(contract.getBrokerDescription());

        cell4.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell4.setCellStyle(cellStyle);
        if (contract.getDeliveryDateFrom() != null) {
            cell5.setCellValue(sdf.format(contract.getDeliveryDateFrom()));
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell6.setCellStyle(cellStyle);
        if (contract.getDeliveryDateTo() != null) {
            cell7.setCellValue(sdf.format(contract.getDeliveryDateTo()));
        } else {
            cell7.setCellValue("");
        }

    }

    private void createHeaderSecondRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell0 = row2.createCell(EXPORTER_CONTRACT_ID_LABEL_INDEX);
        HSSFCell cell1 = row2.createCell(EXPORTER_CONTRACT_ID_VALUE_INDEX);
        HSSFCell cell2 = row2.createCell(EXPORTER_LABEL_INDEX);
        HSSFCell cell3 = row2.createCell(EXPORTER_VALUE_INDEX);
        HSSFCell cell4 = row2.createCell(CROP_LABEL_INDEX);
        HSSFCell cell5 = row2.createCell(CROP_VALUE_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.turn.exporterContractNumber"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(contract.getExporterContractNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.exporter"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(contract.getExporterDescription());

        cell4.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell4.setCellStyle(cellStyle);
        cell5.setCellValue(contract.getCropTypeDescription());

    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(2);
        HSSFCell cell0 = row2.createCell(STORAGE_LOCATION_LABEL_INDEX);
        HSSFCell cell1 = row2.createCell(STORAGE_LOCATION_VALUE_INDEX);
        HSSFCell cell2 = row2.createCell(DESTINATION_LABEL_INDEX);
        HSSFCell cell3 = row2.createCell(DESTINATION_VALUE_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.port"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(storageLocationDescription);

        cell2.setCellValue(getMessageBundle("label.report.excel.turn.destination"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(destinationDescription);
    }

    private void addStyleToHeader(HSSFWorkbook wb) {
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(DATA_HEADER);
        for (int i = 0; i < header.getPhysicalNumberOfCells(); i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        for (int rowIndex = ROW_INDEX_4; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    private void adjustColumnSize(HSSFSheet sheet) {
        for(int i = 0; i <= COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }

    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(getTotalTurnsCount() + " " +getMessageBundle("label.report.excel.registers"));
    }

    public TurnDTO getSelectedTurn() {
        return selectedTurn;
    }

    public List<String> getTurnsErrorMessages() {
        return turnsErrorMessages;
}

    public void setTurnsErrorMessages(List<String> turnsErrorMessages) {
        this.turnsErrorMessages = turnsErrorMessages;
    }

    public Long getDestinationId() {
        return destinationId;
    }

    public void setDestinationId(Long destinationId) {
        this.destinationId = destinationId;
    }

    public Long getStorageLocationId() {
        return storageLocationId;
    }

    public void setStorageLocationId(Long storageLocationId) {
        this.storageLocationId = storageLocationId;
    }

    public String getDestinationDescription() {
        return destinationDescription;
    }

    public void setDestinationDescription(String destinationDescription) {
        this.destinationDescription = destinationDescription;
    }

    public String getStorageLocationDescription() {
        return storageLocationDescription;
    }

    public void setStorageLocationDescription(String storageLocationDescription) {
        this.storageLocationDescription = storageLocationDescription;
    }

    public List<TurnDTO> getTurns() {
        return turns;
    }

    public void setTurns(List<TurnDTO> turns) {
        this.turns = turns;
    }
}
