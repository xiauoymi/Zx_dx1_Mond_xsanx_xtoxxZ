package com.monsanto.barter.ar.web.faces.beans.turn;

import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnGroupReportDataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by JASANC5 on 10/16/2014.
 */
public class TurnGroupReportFormBean extends TurnReportFormBean {
    private static final Logger LOG = LoggerFactory.getLogger(TurnGroupReportFormBean.class);

    @Override
    protected void initReport() {
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(this.getMaterialLasList(), filter.getCropTypeId()));

        if (getPortDestination() != null) {
            filter.setPort(getPortService().get(getPortDestination().getId()));
        }

        searchResult = new TurnGroupReportDataModel(service, filter);
        LOG.debug("Search -> Result");
    }



}
