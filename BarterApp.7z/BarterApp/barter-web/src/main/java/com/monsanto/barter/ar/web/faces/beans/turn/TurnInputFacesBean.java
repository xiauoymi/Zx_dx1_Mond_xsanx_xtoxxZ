package com.monsanto.barter.ar.web.faces.beans.turn;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Turn;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TurnsPerDayView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.TurnsAdd;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: GIRIA
 * Date: 6/12/14
 * Time: 4:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class TurnInputFacesBean extends ArBaseJSF {

    public static final String LABEL_EDIT_TURNS_CREATE_ERROR = "label.edit.turns.create.error";
    private ContractView contractView;

    private MaterialLasService materialLasService;

    private ContractService contractService;

    private List<TurnsPerDayView> turnsPerDayViews;

    private TurnsAdd turnsAdd;

    private TurnService turnService;

    private boolean fromView;


    private static final Logger LOG = LoggerFactory.getLogger(TurnInputFacesBean.class);
    private static final String LABEL_EDIT_TURNS_LOAD_CONTRACT="label.edit.turns.load.contract";

    public String init(){
        loadContractFromDB();
        turnsPerDayViews = contractService.searchTurnsByContractId(contractView.getContractId());
        return SUCCESS;
    }

    private void initializeServices(boolean fromView){
        this.fromView=fromView;
        contractService = getService(ContractService.class);
        turnService = getService(TurnService.class);
    }

    private void initializeTurnAdd(){
        turnsAdd = getService(TurnsAdd.class);
        turnsAdd.setEditableTurnsDate(true);
        turnsAdd.setContract(contractView);
        turnsAdd.init();
    }

    public String begin() {
        initializeServices(false);
        loadContractFromDB();
        initializeTurnAdd();
        turnsPerDayViews = contractService.searchTurnsByContractId(contractView.getContractId());
        return SUCCESS;
    }

    public String beginFromView(){
        initializeServices(true);
        loadContractFromDB();
        initializeTurnAdd();
        turnsPerDayViews = contractService.searchTurnsByContractId(contractView.getContractId());
        return SUCCESS;
    }


    public ContractView getContractView() {
        return contractView;
    }

    public void setContractView(ContractView contractView) {
        fromView=false;
        this.contractView = contractView;
    }

    public MaterialLasService getMaterialLasService() {
        return materialLasService;
    }

    public void setMaterialLasService(MaterialLasService materialLasService) {
        this.materialLasService = materialLasService;
    }

    private void loadContractFromDB(){
        try {
            LOG.debug("try Load contract ", contractView.getContractId());
            contractView = contractService.getContractViewById(contractView.getContractId());
        } catch (BusinessException ex) {
            LOG.error(getMessageBundle(LABEL_EDIT_TURNS_LOAD_CONTRACT),ex);
            addMessage(getMessageBundle(LABEL_EDIT_TURNS_LOAD_CONTRACT));
        }
    }

    public void saveNewTurns() {

        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    List<Turn> newTurns = turnsAdd.getTurnsList();
                    if (!newTurns.isEmpty()){
                        turnService.saveTurns(newTurns, contractView.getContractId());
                        turnsPerDayViews = contractService.searchTurnsByContractId(contractView.getContractId());
                        loadContractFromDB();
                        addMessageNoError("Se agregaron " + newTurns.size() + " cupos");
                        LOG.debug("Se agregaron " + newTurns.size() + " cupos");

                    }

                    turnsAdd.clear();
                }
            });
        } catch (BusinessException ex) {
            LOG.error(getMessageBundle(LABEL_EDIT_TURNS_CREATE_ERROR),ex);
            addMessage(getMessageBundle(LABEL_EDIT_TURNS_CREATE_ERROR));
        }
    }

    public void cancelSaveTurns() {
        turnsAdd.clear();
    }


    public TurnsAdd getTurnsAdd() {
        return turnsAdd;
    }

    public void setTurnsAdd(TurnsAdd turnsAdd) {
        this.turnsAdd = turnsAdd;
    }

    public List<TurnsPerDayView> getTurnsPerDayViews() {
        return turnsPerDayViews;
    }

    public void setContractId(Long contractId) {
        contractView = new ContractView();
        contractView.setContractId(contractId);
    }

    public String backToGrid(){
        return SUCCESS;
    }

    public String backToView(){
        return SUCCESS;
    }

    public boolean isFromView() {
        return fromView;
    }
}
