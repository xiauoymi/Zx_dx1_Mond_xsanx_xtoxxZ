package com.monsanto.barter.ar.web.faces.beans.turn;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.TerminalType;
import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnReportDataModel;
import com.monsanto.barter.ar.web.faces.report.ReportBase;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

/**
 * Created by JASANC5 on 10/16/2014.
 */
public class TurnReportFormBean extends ReportBase<TurnReportDataModel, TurnFilter, TurnService> {
    private static final Logger LOG = LoggerFactory.getLogger(TurnReportFormBean.class);
    private List<MaterialLas> materialLasList;
    private MaterialLasService materialLasService;
    private TurnStatus[] turnStatuses;

    private TerminalType[] terminalTypes;
    private PortDestinationDTO portDestination;
    private PortService portService;

    public static final int CONTRACT_NUMBER_HEADER_INDEX = 0;
    public static final int CONTRACT_NUMBER_VALUE_HEADER_INDEX = 1;
    public static final int CROP_HEADER_INDEX = 2;
    public static final int CROP_VALUE_HEADER_INDEX = 3;
    public static final int EXPORTER_HEADER_INDEX = 4;
    public static final int EXPORTER_VALUE_HEADER_INDEX = 5;
    public static final int STATUS_HEADER_INDEX = 6;
    public static final int STATUS_VALUE_HEADER_INDEX = 7;

    public static final int TURN_DATE_FROM_HEADER_INDEX = 0;
    public static final int TURN_DATE_FROM_VALUE_HEADER_INDEX = 1;
    public static final int TURN_DATE_TO_HEADER_INDEX = 2;
    public static final int TURN_DATE_TO_VALUE_HEADER_INDEX = 3;
    public static final int TERMINAL_TYPE_HEADER_INDEX=4;
    public static final int TERMINAL_TYPE_VALUE_HEADER_INDEX=5;
    public static final int LOCATION_HEADER_INDEX=6;
    public static final int LOCATION_VALUE_HEADER_INDEX=7;


    @Override
    protected void initFilter() {
        filter = new TurnFilter();
        portDestination=null;
    }

    @Override
    protected void initServices() {
        materialLasService = getService(MaterialLasService.class);
        service = getService(TurnService.class);
        portService = getService(PortService.class);
    }

    @Override
    protected void loadCombos() {
        LOG.debug("loadCombos.");
        turnStatuses = TurnStatus.values();
        terminalTypes = TerminalType.values();
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }

    }

    @Override
    protected boolean validateFilters() {
        if (filter.getTurnDateFrom()!=null && filter.getTurnDateTo()!=null &&
                filter.getTurnDateFrom().after( filter.getTurnDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    @Override
    protected void initReport() {
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));
        if (portDestination != null) {
            filter.setPort(portService.get(portDestination.getId()));
        }
        searchResult = new TurnReportDataModel(service, filter);
        LOG.debug("Search -> Result");
    }

    @Override
    protected void createHeaderFirstRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0, sheet.getLastRowNum(), HEADER_OFFSET - 1);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(CONTRACT_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(CONTRACT_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(EXPORTER_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(EXPORTER_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(STATUS_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(STATUS_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.turn.contractNumber"));
        cell0.setCellStyle(cellStyle);
        cell1.setCellValue(filter.getContractNumber());

        cell2.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell2.setCellStyle(cellStyle);
        if (filter.getCropType() != null) {
            cell3.setCellValue(filter.getCropType().getCommercialText());
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.exporter"));
        cell4.setCellStyle(cellStyle);
        cell5.setCellValue(filter.getExporter());

        cell6.setCellValue(getMessageBundle("com.monsanto.barter.ar.business.entity.TurnRequest.turnRequestStatus"));
        cell6.setCellStyle(cellStyle);
        if (filter.getTurnStatus() != null) {
            cell7.setCellValue(getMessageBundle(filter.getTurnStatus().getDescription()));
        } else {
            cell7.setCellValue("");
        }

    }

    @Override
    protected void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell0 = row2.createCell(TURN_DATE_FROM_HEADER_INDEX);
        HSSFCell cell1 = row2.createCell(TURN_DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row2.createCell(TURN_DATE_TO_HEADER_INDEX);
        HSSFCell cell3 = row2.createCell(TURN_DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row2.createCell(TERMINAL_TYPE_HEADER_INDEX);
        HSSFCell cell5 = row2.createCell(TERMINAL_TYPE_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row2.createCell(LOCATION_HEADER_INDEX);
        HSSFCell cell7 = row2.createCell(LOCATION_VALUE_HEADER_INDEX);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell0.setCellStyle(cellStyle);
        if (filter.getTurnDateFrom() != null) {
            cell1.setCellValue(sdf.format(filter.getTurnDateFrom()));
        } else {
            cell1.setCellValue("");
        }

        cell2.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell2.setCellStyle(cellStyle);
        if (filter.getTurnDateTo() != null) {
            cell3.setCellValue(sdf.format(filter.getTurnDateTo()));
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.terminalType"));
        cell4.setCellStyle(cellStyle);

        if(filter.getTerminalType()!=null){
            cell5.setCellValue(getMessageBundle(filter.getTerminalType().getDescription()));
            if(filter.getTerminalType().equals(TerminalType.PORT_TERMINAL)){
                cell6.setCellValue(getMessageBundle("label.report.excel.port"));
                if(portDestination != null){
                    cell7.setCellValue(portDestination.getDescription());
                }
            }
            else{
                cell6.setCellValue(getMessageBundle("label.report.excel.location"));
                if(filter.getLocation() != null){
                    cell7.setCellValue(filter.getLocation());
                }
            }
            cell6.setCellStyle(cellStyle);
        }
        else{
            cell5.setCellValue(getMessageBundle("label.report.excel.all"));
        }

    }

    @Override
    protected void createFooter(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));

    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }
    public TurnStatus[] getTurnStatuses() {
        return turnStatuses;
    }

    public void setTurnStatuses(TurnStatus[] turnStatuses) {
        this.turnStatuses = Arrays.copyOf(turnStatuses, turnStatuses.length);
    }

    public TerminalType[] getTerminalTypes() {
        return terminalTypes;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    protected PortService getPortService() {
        return portService;
    }
}
