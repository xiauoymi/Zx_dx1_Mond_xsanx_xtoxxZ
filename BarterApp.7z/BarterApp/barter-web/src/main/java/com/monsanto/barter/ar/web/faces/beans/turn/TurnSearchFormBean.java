package com.monsanto.barter.ar.web.faces.beans.turn;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.TerminalType;
import com.monsanto.barter.ar.business.entity.enumerated.TurnOperationType;
import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.business.service.dto.TurnOperationDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by JASANC5 on 09/09/2014.
 */
public class TurnSearchFormBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(TurnSearchFormBean.class);

    public static final String PAGE_SEARCH_RESULT = "turn-search-result";

    private TurnService turnService;
    private PortService portService;
    private TurnFilter turnFilter;
    private TurnDataModel searchResult;
    private MaterialLasService materialLasService;
    private List<MaterialLas> materialLasList;
    private TurnStatus[] turnStatuses;
    private Long turnId;
    private PortDestinationDTO portDestination;

    private Set<TurnDTO> turns;

    private TerminalType[] terminalTypes;

    public static final int HEADER_OFFSET = 4;
    public static final int MAX_COLUMNS_SIZE = 5;
    public static final int FIRST_HEADER_INDEX = 1;
    public static final int FIRST_VALUE_HEADER_INDEX = 2;
    public static final int SECOND_HEADER_INDEX = 3;
    public static final int SECOND_VALUE_HEADER_INDEX = 4;
    public static final int THIRD_HEADER_INDEX = 5;
    public static final int THIRD_VALUE_HEADER_INDEX = 6;
    public static final int FOURTH_HEADER_INDEX = 7;
    public static final int FOURTH_VALUE_HEADER_INDEX = 8;

    private HSSFCellStyle filterCellStyle;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private static final String EXPORT_LABEL_SEPARATOR= ":";

    private static final String CREATED_DATE = "com.monsanto.barter.ar.business.entity.TurnRequest.turnRequestDate";
    private static final String CALENDAR_FROM= "ar.barter.calendar.from";
    private static final String CALENDAR_TO= "ar.barter.calendar.to";

    public String begin(){
        LOG.debug("Setting filters.");
        turnFilter = new TurnFilter();
        turnFilter.setTurnStatus(TurnStatus.AVAILABLE);
        LOG.debug("Retrieving services.");
        turnService = getService(TurnService.class);
        materialLasService = getService(MaterialLasService.class);
        loadCombos();
        portDestination = null;
        portService = getService(PortService.class);
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        turnFilter = new TurnFilter();
        turnFilter.setTurnStatus(TurnStatus.AVAILABLE);
        portDestination = null;
        return SUCCESS;
    }

    public String search() {
        LOG.debug("Starting contract search");
        if (validateFilters()){

            for (MaterialLas material : materialLasList) {
                if (material.getId().equals(turnFilter.getCropTypeId())) {
                    turnFilter.setCropType(material);
                    break;
                }
            }
            if (portDestination != null) {
                turnFilter.setPort(portService.get(portDestination.getId()));
            }

            searchResult = new TurnDataModel(turnService, turnFilter);
            LOG.debug("Search -> Result");
            return PAGE_SEARCH_RESULT;

        }


        LOG.debug("Returning null.");

        return null;


    }

    private void loadCombos(){
        LOG.debug("loadCombos.");
        terminalTypes = TerminalType.values();
        turnStatuses = TurnStatus.values();
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public TurnFilter getTurnFilter() {
        return turnFilter;
    }

    public void setTurnFilter(TurnFilter turnFilter) {
        this.turnFilter = turnFilter;
    }

    public TurnDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(TurnDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public void selectedRow(){
        turnId = searchResult.getRowData().getId();
    }

    public Long getTurnId() {
        return turnId;
    }

    public void setTurnId(Long turnId) {
        this.turnId = turnId;
    }

    public TurnStatus[] getTurnStatuses() {
        return turnStatuses;
    }

    public void setTurnStatuses(TurnStatus[] turnStatuses) {
        this.turnStatuses = Arrays.copyOf(turnStatuses, turnStatuses.length);
    }

    private boolean validateFilters(){
        if (turnFilter.getTurnDateFrom()!=null && turnFilter.getTurnDateTo()!=null &&
                turnFilter.getTurnDateFrom().after( turnFilter.getTurnDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    public void getTurnsSelected() {
        turns = new HashSet<TurnDTO>();
        boolean isValid = false;

        for (TurnDTO tempTurn : searchResult.getPage()){
            if (tempTurn.isSelected()) {
                LOG.debug("Turn Selected {}", tempTurn.getCode());
                turns.add(tempTurn);
                isValid = true;
            }
        }

        if (!isValid){

            addMessage(getMessageBundle("label.search.turn.turnsCancellation.emptyList"));
        }

        addCallbackParam("isValid", isValid);
    }

    public String cancelTurns() {
        try{
            TurnOperationDTO turnOperationDTO = new TurnOperationDTO();
            turnOperationDTO.setType(TurnOperationType.CANCELLATION );
            turnService.suspendTurns(null, turns,turnOperationDTO );
            addMessageNoError(getMessageBundle("label.search.turn.turnsCancellation.success"));
            addCallbackParam("cancelled",true);

        }catch (BusinessException ex){
            LOG.error("An error occurred cancelling turns: ", ex);
            addMessage(getMessageBundle("label.search.turn.turnsCancellation.error"));
            addCallbackParam("cancelled",false);
            return ERROR;
        }

        return SUCCESS;
    }


    public TerminalType[] getTerminalTypes() {
        return terminalTypes;
    }

    public void setTerminalTypes(TerminalType[] terminalTypes) {
        this.terminalTypes = Arrays.copyOf(terminalTypes,terminalTypes.length);
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createFilterCellsSytle(wb);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb) {
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {

        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(2);

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle(CREATED_DATE) + " "+
                getMessageBundle(CALENDAR_FROM)+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,turnFilter.getTurnDateFrom());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle(CREATED_DATE)+ " "+
                getMessageBundle(CALENDAR_TO)+ EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,turnFilter.getTurnDateTo());

    }

    private void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row = sheet.createRow(1);
        HSSFCell cell1 = row.createCell(FIRST_VALUE_HEADER_INDEX);
        cell1.setCellStyle(getFilterCellStyle());
        HSSFCell cell3 = row.createCell(SECOND_VALUE_HEADER_INDEX);
        cell3.setCellStyle(getFilterCellStyle());
        HSSFCell cell5 = row.createCell(THIRD_VALUE_HEADER_INDEX);
        cell5.setCellStyle(getFilterCellStyle());

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("com.monsanto.barter.ar.business.entity.Terminal.terminalType")+EXPORT_LABEL_SEPARATOR);
        if (turnFilter.getTerminalType()!=null){
            cell1.setCellValue(getMessageBundle(turnFilter.getTerminalType().getDescription()));
        }
        else{
            cell1.setCellValue("");
        }

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("label.search.filters.delivery.crop")+EXPORT_LABEL_SEPARATOR);

        if (turnFilter.getCropType() != null) {
            cell3.setCellValue(turnFilter.getCropType().getCommercialText());
        }else{
            cell3.setCellValue("");
        }

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("com.monsanto.barter.ar.business.entity.TurnRequest.turnRequestStatus")+EXPORT_LABEL_SEPARATOR);
        if (turnFilter.getTurnStatus() != null) {
            cell5.setCellValue(getMessageBundle(turnFilter.getTurnStatus().getDescription()));
        }else{
            cell5.setCellValue("");
        }


    }

    private void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET-1);
        HSSFRow row = sheet.createRow(0);

        createCellFor(row,FIRST_HEADER_INDEX,getMessageBundle("label.turnInputFacesBean.turnsAdd.turnCode")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,FIRST_VALUE_HEADER_INDEX,turnFilter.getCode());

        createCellFor(row,SECOND_HEADER_INDEX,getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.number")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,SECOND_VALUE_HEADER_INDEX,turnFilter.getContractNumber());

        createCellFor(row,THIRD_HEADER_INDEX,getMessageBundle("com.monsanto.barter.ar.business.entity.Contract.exporter")+EXPORT_LABEL_SEPARATOR);
        createCellFor(row,THIRD_VALUE_HEADER_INDEX,turnFilter.getExporter());



    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET-1);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }


    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    protected HSSFCell createCellFor(HSSFRow row,int columnNumber,String columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellStyle(filterCellStyle);
        cell.setCellValue(columnValue);
        return cell;
    }

    protected HSSFCell createCellFor(HSSFRow row,int columnNumber,Date columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellStyle(filterCellStyle);
        if (columnValue!=null){
            cell.setCellValue(sdf.format(columnValue));
        }else{
            cell.setCellValue("");
        }
        return cell;
    }

    private void createFilterCellsSytle(HSSFWorkbook wb) {
        filterCellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        filterCellStyle.setFont(font);
    }

    public HSSFCellStyle getFilterCellStyle() {
        return filterCellStyle;
    }

}
