package com.monsanto.barter.ar.web.faces.beans.turn.datamodel;

import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 09/10/14
 * Time: 09:55
 * To change this template use File | Settings | File Templates.
 */
public class TurnDataModel extends AbstractDataModel<TurnDTO,TurnFilter> {

    private List<TurnDTO> page = new ArrayList<TurnDTO>(0);

    private TurnService service;

    public TurnDataModel(TurnService service, TurnFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public TurnDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (TurnDTO row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<TurnDTO> loadPage(TurnFilter filter, Paging paging) {
        return service.search(filter, paging);
    }

    @Override
    public Object getRowKey(TurnDTO object) {
        return object.getId().toString();
    }

    public TurnFilter getFilter() {
        return filter;
    }

    public Set<TurnDTO> getSelected(){
        Set<TurnDTO> turnsSelected = new HashSet<TurnDTO>();
        for (TurnDTO tempTurn : getPage()){
            if (tempTurn.isSelected()) {
                turnsSelected.add(tempTurn);
            }
        }
        return turnsSelected;
    }
}
