package com.monsanto.barter.ar.web.faces.beans.turn.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.TurnReportDTO;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 09/10/14
 * Time: 09:55
 * To change this template use File | Settings | File Templates.
 */
public class TurnGroupReportDataModel extends TurnReportDataModel {

    public TurnGroupReportDataModel(TurnService service, TurnFilter filter) {
        super(service, filter);
    }

    @Override
    protected Recordset<TurnReportDTO> loadPage(TurnFilter filter, Paging paging) {
        return service.searchAssignedTurnsByLocationAndRequest(filter, paging);
    }

}
