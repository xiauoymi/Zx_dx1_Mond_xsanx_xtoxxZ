package com.monsanto.barter.ar.web.faces.beans.turn.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.TurnReportDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 09/10/14
 * Time: 09:55
 * To change this template use File | Settings | File Templates.
 */
public class TurnReportDataModel extends AbstractDataModel<TurnReportDTO,TurnFilter> {

    private List<TurnReportDTO> page = new ArrayList<TurnReportDTO>(0);

    protected TurnService service;

    public TurnReportDataModel(TurnService service, TurnFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public TurnReportDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (TurnReportDTO row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<TurnReportDTO> loadPage(TurnFilter filter, Paging paging) {
        return service.searchForReport(filter, paging);
    }

    @Override
    public Object getRowKey(TurnReportDTO object) {
        return object.getId().toString();
    }

    public TurnFilter getFilter() {
        return filter;
    }

}
