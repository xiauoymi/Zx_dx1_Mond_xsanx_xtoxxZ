package com.monsanto.barter.ar.web.faces.beans.turnAddressee;


import com.monsanto.barter.ar.business.entity.TurnAddressee;
import com.monsanto.barter.ar.business.service.TurnAddresseeService;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.TurnAddresseeCC;

import java.util.ArrayList;
import java.util.List;

public class TurnAddresseeSearchFacesBean  extends ArBaseJSF {

    private List<TurnAddressee> addressees;
    private TurnAddresseeCC turnAddresseeCC;
    private TurnAddresseeService turnAddresseeService;
    private String cuitAddressee;
    private String nameAddressee;
    private TurnAddressee addresseesToEdit;


    public String begin() {
        turnAddresseeService = getService(TurnAddresseeService.class);
        turnAddresseeCC = getService(TurnAddresseeCC.class);
        addressees = new ArrayList<TurnAddressee>();
        return SUCCESS;
    }

    public void search(){
        addressees = turnAddresseeService.search(cuitAddressee,nameAddressee);
    }

    public void clear(){
        addressees = new ArrayList<TurnAddressee>();
        cuitAddressee=null;
        nameAddressee=null;
        turnAddresseeCC.clear();
    }

    public void edit(){
        turnAddresseeCC.loadForUpdate(addresseesToEdit);
    }

    public List<TurnAddressee> getAddressees() {
        return addressees;
    }

    public void setAddressees(List<TurnAddressee> addressees) {
        this.addressees = addressees;
    }

    public TurnAddresseeCC getTurnAddresseeCC() {
        return turnAddresseeCC;
    }

    public void setTurnAddresseeCC(TurnAddresseeCC turnAddresseeCC) {
        this.turnAddresseeCC = turnAddresseeCC;
    }

    public String getCuitAddressee() {
        return cuitAddressee;
    }

    public void setCuitAddressee(String cuitAddressee) {
        this.cuitAddressee = cuitAddressee;
    }

    public String getNameAddressee() {
        return nameAddressee;
    }

    public void setNameAddressee(String nameAddressee) {
        this.nameAddressee = nameAddressee;
    }

    public TurnAddressee getAddresseesToEdit() {
        return addresseesToEdit;
    }

    public void setAddresseesToEdit(TurnAddressee addresseesToEdit) {
        this.addresseesToEdit = addresseesToEdit;
    }
}
