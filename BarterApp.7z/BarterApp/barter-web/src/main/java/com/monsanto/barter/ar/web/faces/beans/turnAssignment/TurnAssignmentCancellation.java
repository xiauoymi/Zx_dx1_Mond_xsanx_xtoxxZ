package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;

import java.util.Date;

/**
 * Created by JASANC5 on 7/30/2014.
 */
public class TurnAssignmentCancellation extends TurnCancellation {
    /* Contract Data*/
    private Long exporterContractId;
    private ContractView exporterContractDTO;
    private Date turnDate;

    @Override
    protected void loadTurnsAndContract() {
        exporterContractDTO = getService(ContractService.class).getContractViewForAssignment(exporterContractId);
        TurnFilter turnFilter = new TurnFilter();
        turnFilter.setContractNumber(exporterContractDTO.getNumber());
        turnFilter.setTurnRequestNumber(this.getTurnRequestId());
        turnFilter.setTurnDateFrom(turnDate);
        turnFilter.setTurnDateTo(turnDate);
        turnFilter.setTurnStatus(TurnStatus.ASSIGNED);
        turnFilter.setDestinationId(getDestinationId());
        this.setTurnsFromAssignment(new TurnDataModel(this.getTurnService(), turnFilter));
    }

    @Override
    protected void sendMailTurnCancellation() {
        this.getTurnRequestService().sendMailTurnCancellation(this.getTurnRequestDTO(), turnDate,this.getTurnsToCancel(), this.getTurnOperationDTO());
    }

    public Date getTurnDate() {
        return turnDate;
    }

    public void setTurnDate(Date turnDate) {
        this.turnDate = turnDate;
    }

    public ContractView getExporterContractDTO() {
        return exporterContractDTO;
    }

    public void setExporterContractDTO(ContractView exporterContractDTO) {
        this.exporterContractDTO = exporterContractDTO;
    }
    public Long getExporterContractId() {
        return exporterContractId;
    }

    public void setExporterContractId(Long exporterContractId) {
        this.exporterContractId = exporterContractId;
    }

}