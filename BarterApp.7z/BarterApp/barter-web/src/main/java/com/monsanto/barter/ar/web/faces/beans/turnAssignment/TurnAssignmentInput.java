package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TurnAssignment;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite.AssignmentContractSearch;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite.AssignmentTurnRequestSearchCC;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.application.FacesMessage;
import java.util.*;

/**
 * Created by JASANC5 on 8/15/2014.
 */
public class TurnAssignmentInput extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(TurnAssignmentInput.class);
    public static final String LABEL_INPUT_TURN_ASSIGNMENT_ERROR_EXCEEDED_CONTRACT_QUANTITY = "label.input.turnAssignment.error.exceededContractQuantity";
    public static final String LABEL_INPUT_TURN_ASSIGNMENT_REQUEST_COMPLETED_OR_UNAVAILABLE = "label.input.turnAssignment.request.completedOrUnavailable";
    public static final String SAVED="saved";
    public static final String ERROR_RETRIEVING_TURN_REQUEST="Error retrieving turn request";
    public static final String LABEL_INPUT_TURN_ASSIGNMENT_LOAD_ERROR="label.input.turnAssignment.load.error";

    private TurnRequestService turnRequestService;
    private TurnRequest turnRequest;
    private TurnRequestDTO turnRequestDTO;
    private AssignmentContractSearch contractSearch;
    private TurnService turnService;
    private AssignmentTurnRequestSearchCC assignmentTurnRequestSearchCC;
    private List<ContractView> contractsGroupByTerminalToAssignment;
    private TurnAssignment assignment;
    private List<FacesMessage> messages;

    public String begin(){
        init();
        assignmentTurnRequestSearchCC.begin(getInitialRequestFilter());
        return SUCCESS;
    }

    private void init() {
        assignmentTurnRequestSearchCC = getService(AssignmentTurnRequestSearchCC.class);
        turnRequestService = getService(TurnRequestService.class);
        contractSearch = getService(AssignmentContractSearch.class);
        turnService = getService(TurnService.class);
        turnRequest = null;
        turnRequestDTO= null;
        messages = null;
    }


    /**
     * Validates user selection:
     *          - Contract available turns must be enough for requested turns
     *          - Total turns to assign must be less equal than turn request turns quantity value
     *          - User must assign turns to at least one contract
     * @param contractList
     * @return
     */
    private boolean isTurnsToAssignInformationValid(List<ContractView> contractList){
        boolean isValid = true;
        boolean totalExceeded=false;
        Long  totalTurnsToAssign = 0l;
        if(contractList.isEmpty()){
            addMessage(FacesMessage.SEVERITY_ERROR, "label.input.turnAssignment.error.noTurnsAssigned");
            return false;
        }
        for(ContractView contract: contractList){
            //contract available turns must be enough for requested turns
            if(!contract.hasTurnsToAssign()){
                addMessage(FacesMessage.SEVERITY_ERROR, getMessageBundle(LABEL_INPUT_TURN_ASSIGNMENT_ERROR_EXCEEDED_CONTRACT_QUANTITY)+contract.getNumber());
                isValid=false;
            }
            totalTurnsToAssign+=contract.getTurnsToAssign();
            //Total turns to assign must be less equal than turn request turns quantity value
            if(totalTurnsToAssign> turnRequestDTO.getTurnRemnantQuantity() && !totalExceeded){
                addMessage(FacesMessage.SEVERITY_ERROR, "label.input.turnAssignment.error.exceededRequestQuantity");
                isValid=false;
                totalExceeded=true;
            }
        }
        //User must assign turns to at least one contract
        return isValid;
    }


    /**
     * Validates user selection (turns quantity)
     * and if there is no error then creates turn assignment
     */
    public void preSave(){
        Map<ContractView, List<Turn>> turnsToAssignByContract = null ;
        turnRequestDTO =  turnRequestService.getDTO(turnRequestDTO.getId());
        if(!turnRequestDTO.isValidForAttend()) {
            addMessage(FacesMessage.SEVERITY_ERROR,LABEL_INPUT_TURN_ASSIGNMENT_REQUEST_COMPLETED_OR_UNAVAILABLE);
            return;
        }
        contractsGroupByTerminalToAssignment = contractSearch.getContractListSelection();
        assignment= new TurnAssignment();
        boolean isValid = isTurnsToAssignInformationValid(contractsGroupByTerminalToAssignment);
        if(isValid){
            //if we find out contracts to assign we must look for turns
            turnsToAssignByContract = getTurnsToAssignForSelectedContracts(contractsGroupByTerminalToAssignment) ;
            if(turnsToAssignByContract==null || turnsToAssignByContract.isEmpty() ){
                isValid=false;
            }
            turnRequest =  turnRequestService.get(turnRequestDTO.getId());
            assignment.setTurnDate(contractSearch.getFilter().getTurnDate());
            assignment.setTurnRequest(turnRequest);
            assignment.setTurnsToAssignByContract(turnsToAssignByContract);
            if(turnRequestDTO.getTurnRemnantQuantity() == assignment.getTurns().size() ){
                turnRequest.setStatus(TurnRequestStatus.ASSIGNED);
            }else{
                turnRequest.setStatus(TurnRequestStatus.PENDING);
            }
        }
        addCallbackParam("isValid", isValid);
    }


    /**
     * Gets turns to assign list from database checking availability
     * @param contractList
     * @return
     */
    private Map<ContractView,List<Turn>> getTurnsToAssignForSelectedContracts(List<ContractView> contractList){
        Map<ContractView,List<Turn>> turns = new HashMap<ContractView, List<Turn>>();
        for(ContractView contract: contractList){
            try {
                LOG.debug("Going to look for turns to assign");
                List<Turn> turnsByContract = turnService.getTurnToAssignByContractIdTerminalAndDate(contract.getContractId(),contract.getTerminalId(),
                        contractSearch.getFilter().getTurnDate(), contract.getTurnsToAssign());
                turns.put(contract, turnsByContract);
            }catch (BusinessException ex){
                LOG.debug("Not enough turns on data base",ex);
                addMessage(FacesMessage.SEVERITY_ERROR, getMessageBundle("label.input.turnAssignment.error.alreadyExceededContractQuantity")+contract.getNumber());
                return null;
            }
        }
        return turns;
    }

    public String save(){
        boolean saved= false;
        try{
            turnRequestService.assignTurns(assignment);
            saved = true;
            turnRequestService.sendMailTurnAssignment(assignment);
            addCallbackParam(SAVED,saved);
            this.begin();
            this.addMessage(FacesMessage.SEVERITY_INFO, "label.input.turnAssignment.created");
            return SUCCESS;

        }catch (BusinessException ex){
            LOG.error("An error occurred saving turn assigment: ", ex);
            if(!saved){
                addMessage(FacesMessage.SEVERITY_ERROR, "label.input.turnAssignment.creation.error");
            }else {
                addMessage(FacesMessage.SEVERITY_ERROR, "label.input.turnAssignment.sendMail.error");
            }
            addCallbackParam(SAVED,saved);
            return ERROR;
        }

    }


    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public AssignmentTurnRequestSearchCC getAssignmentTurnRequestSearchCC() {
        return assignmentTurnRequestSearchCC;
    }

    public void setAssignmentTurnRequestSearchCC(AssignmentTurnRequestSearchCC assignmentTurnRequestSearchCC) {
        this.assignmentTurnRequestSearchCC = assignmentTurnRequestSearchCC;
    }

    public AssignmentContractSearch getContractSearch() {
        return contractSearch;
    }

    public void setContractSearch(AssignmentContractSearch contractSearch) {
        this.contractSearch = contractSearch;
    }

    public void selectedRequestToAttend(SelectEvent event){
        messages = new ArrayList<FacesMessage>();
        try {
            Long idTurnRequest = ((TurnRequestDTO)event.getObject()).getId();
            LOG.debug("Retrieve Turn Request:{}",idTurnRequest);
            turnRequestDTO = turnRequestService.getDTO(idTurnRequest);
            if(!turnRequestDTO.isValidForAttend()) {
                addMessage(FacesMessage.SEVERITY_ERROR, getMessageBundle(LABEL_INPUT_TURN_ASSIGNMENT_REQUEST_COMPLETED_OR_UNAVAILABLE));
                turnRequestDTO= null;
                return;
            }
            contractSearch.begin(buildInitialContractFilter(turnRequestDTO));
        }catch (BusinessException be){
            LOG.error(ERROR_RETRIEVING_TURN_REQUEST,be);
            turnRequestDTO= null;
            addMessage(FacesMessage.SEVERITY_ERROR,LABEL_INPUT_TURN_ASSIGNMENT_LOAD_ERROR);
        }catch (Exception e){
            LOG.error(ERROR_RETRIEVING_TURN_REQUEST,e);
            turnRequestDTO= null;
            addMessage(FacesMessage.SEVERITY_ERROR,LABEL_INPUT_TURN_ASSIGNMENT_LOAD_ERROR);
        }
    }

    private ContractFilter buildInitialContractFilter(TurnRequestDTO turnRequest) {
        ContractFilter contractFilter =new ContractFilter();
        contractFilter.setCropTypeId(turnRequest.getCropTypeId());
        contractFilter.setTurnDate(turnRequest.getTurnRequestDate());
        contractFilter.setPortId(turnRequest.getSuggestedPortDestinationId());
        return contractFilter;
    }

    private TurnRequestFilter  getInitialRequestFilter() {
        TurnRequestFilter turnRequestFilter = new TurnRequestFilter();
        turnRequestFilter.setTurnRequestDateFrom(new Date());
        return turnRequestFilter;

    }

    public List<ContractView> getContractsGroupByTerminalToAssignment() {
        return contractsGroupByTerminalToAssignment;
    }

    public TurnRequest getTurnRequest() {
        return turnRequest;
    }

    public void setTurnRequest(TurnRequest turnRequest) {
        this.turnRequest = turnRequest;
    }

    public TurnRequestDTO getTurnRequestDTO(){
        return turnRequestDTO;
    }


    public List<FacesMessage> getMessages() {
        return messages;
    }

    private void addMessage(FacesMessage.Severity severity,String msg){
        if( messages == null){
            messages = new ArrayList<FacesMessage>();
        }
        try{
            messages.add(new FacesMessage(severity,getMessageBundle(msg),msg));
        }catch (MissingResourceException ex){
            messages.add(new FacesMessage(severity,msg,msg));
        }

    }

    public void clearMessages(){
        messages = new ArrayList<FacesMessage>();
    }

    public boolean getOldTurnDate(){
        if(assignment!=null && assignment.getTurnDate()!= null){
            return assignment.getTurnDate().before(new Date());
        }
        return false;
    }

}
