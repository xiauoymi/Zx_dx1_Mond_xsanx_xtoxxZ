package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.business.entity.ValidationConstants;
import com.monsanto.barter.ar.business.entity.enumerated.TurnCancellationReason;
import com.monsanto.barter.ar.business.entity.enumerated.TurnOperationType;
import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.business.service.dto.TurnOperationDTO;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * Created by VNBARR on 10/9/2014.
 */
public class TurnAssignmentReturn extends TurnCancellation  {

    public static final String LABEL_MESSAGE_RETURN_OK = "label.search.turn.turnsReturn.success";
    public static final String LABEL_MESSAGE_RETURN_ERROR = "label.search.turn.turnsReturn.error";
    public static final String LABEL_RETURN_CONFIRM_MESSAGE = "label.return.confirmMessage";
    private List<String> errorMessages = new ArrayList<String>();

    private TurnCancellationReason[] cancellationReasons;

    public TurnAssignmentReturn(){
        setCancelErrorMessage(LABEL_MESSAGE_RETURN_ERROR);
        setCancelOkMessage(LABEL_MESSAGE_RETURN_OK);
    }

    @Override
    protected void sendMailTurnCancellation() {
        this.getTurnRequestService().sendMailTurnReturn(this.getTurnRequestDTO(), this.getTurnsToCancel(), this.getTurnOperationDTO());
    }

    @Override
    protected void loadTurnsAndContract() {
        errorMessages.clear();
        TurnFilter turnFilter = new TurnFilter();
        turnFilter.setTurnRequestNumber(this.getTurnRequestId());
        turnFilter.setTurnStatus(TurnStatus.ASSIGNED);
        turnFilter.setDestinationId(getDestinationId());
        this.setTurnsFromAssignment(new TurnDataModel(this.getTurnService(), turnFilter));
        cancellationReasons = TurnCancellationReason.values();
    }

    public void getTurnsSelectedToReturn() {
        setTurnOperationType(TurnOperationType.RETURN);
        TurnOperationDTO turnOperationDTO = getTurnOperationDTO();
        //we set announcement date as contract expiration date by default
        turnOperationDTO.setAnnouncementDate(new Date());
        turnOperationDTO.setReason("");
        this.setTurnOperationDTO(turnOperationDTO);
        errorMessages.clear();
        getTurnsSelected(LABEL_RETURN_CONFIRM_MESSAGE);
    }

    public void preSave(){
        TurnOperationDTO turnOperationDTO = getTurnOperationDTO();
        errorMessages.clear();
        boolean validForSave = false;

        if (turnOperationDTO.getAnnouncementDate() != null){
            if(turnOperationDTO.getAnnouncementDate().after(new Date())){
                errorMessages.add(getMessageBundle("label.search.turn.turnsReturn.wrongAnnouncementDate"));
            }
        }else{
            errorMessages.add(getMessageBundle("label.search.turn.turnsReturn.emptyDate"));
        }

        if(turnOperationDTO.getTurnCancellationReason()!=null && turnOperationDTO.getTurnCancellationReason().equals(TurnCancellationReason.OTHER)
                && isBlank(turnOperationDTO.getReason())){
            errorMessages.add(getMessageBundle("label.search.turn.turnsReturn.emptyObservation"));
        }

        if(!isBlank(turnOperationDTO.getReason()) && turnOperationDTO.getReason().length()>ValidationConstants.STRING_140_SIZE){
            errorMessages.add(getMessageBundle("label.search.turn.turnsReturn.observationsMaxCharacters"));
        }

        if(errorMessages.isEmpty()){
            validForSave = true;
            confirmCancelTurns();
        }

        addCallbackParam("validForSave", validForSave);
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public TurnCancellationReason[] getCancellationReasons() {
        return cancellationReasons;
    }

}
