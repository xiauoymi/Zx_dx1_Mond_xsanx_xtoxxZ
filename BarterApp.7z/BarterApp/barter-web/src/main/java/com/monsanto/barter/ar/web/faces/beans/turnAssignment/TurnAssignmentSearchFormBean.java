package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.TerminalType;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TurnAssignmentFilter;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel.TurnAssignmentDataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by JASANC5 on 7/29/2014.
 */
public class TurnAssignmentSearchFormBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(TurnAssignmentSearchFormBean.class);

    public static final String PAGE_SEARCH_RESULT = "turn-assignment-search-result";

    private TurnRequestService turnRequestService;
    private PortService portService;
    private TurnAssignmentFilter turnAssignmentFilter;
    private TurnAssignmentDataModel searchResult;
    private MaterialLasService materialLasService;
    private List<MaterialLas> materialLasList;
    private Long turnAssignmentId;
    private PortDestinationDTO portDestination;
    private TerminalType[] terminalTypes;


    public String begin(){
        LOG.debug("Setting filters.");
        turnAssignmentFilter = new TurnAssignmentFilter();
        LOG.debug("Retrieving services.");
        turnRequestService = getService(TurnRequestService.class);
        materialLasService = getService(MaterialLasService.class);
        loadCombos();
        portDestination = null;
        portService = getService(PortService.class);
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        turnAssignmentFilter = new TurnAssignmentFilter();
        portDestination = null;
        return SUCCESS;
    }

    public String search() {
        LOG.debug("Starting contract search");
        turnAssignmentFilter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList,turnAssignmentFilter.getCropTypeId()));
        if (portDestination != null) {
           turnAssignmentFilter.setPort(portService.get(portDestination.getId()));
        }

        searchResult = new TurnAssignmentDataModel(turnRequestService, turnAssignmentFilter);
        LOG.debug("Search -> Result");
        return PAGE_SEARCH_RESULT;
    }

    private void loadCombos(){
        terminalTypes = TerminalType.values();

        LOG.debug("loadCombos.");
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public TurnAssignmentFilter getTurnAssignmentFilter() {
        return turnAssignmentFilter;
    }

    public void setTurnAssignmentFilter(TurnAssignmentFilter turnAssignmentFilter) {
        this.turnAssignmentFilter = turnAssignmentFilter;
    }

    public TurnAssignmentDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(TurnAssignmentDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public Long getTurnAssignmentId() {
        return turnAssignmentId;
    }

    public void setTurnAssignmentId(Long turnAssignmentId) {
        this.turnAssignmentId = turnAssignmentId;
    }

    public void selectedRow(){
        turnAssignmentId = searchResult.getRowData().getTurnRequestNumber();
    }

    public TerminalType[] getTerminalTypes() {
        return terminalTypes;
    }
}
