package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.enumerated.TurnOperationType;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.business.service.dto.TurnOperationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by JASANC5 on 10/1/2014.
 */
public abstract class TurnCancellation extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(TurnCancellation.class);
    public static final String LABEL_SEARCH_TURN_TURNS_CANCELLATION_SUCCESS = "label.search.turn.turnsCancellation.success";
    public static final String LABEL_SEARCH_TURN_TURNS_CANCELLATION_ERROR = "label.search.turn.turnsCancellation.error";
    private Mode mode;

    /* Turn Request Data */
    private Long turnRequestId;
    private TurnRequestService turnRequestService;

    private TurnRequestDTO turnRequestDTO;
    private TurnOperationDTO turnOperationDTO;
    /**/
    /*Turn of the assignment*/
    private TurnService turnService;
    private TurnDataModel turnsFromAssignment;
    private Set<TurnDTO> turnsToCancel;

    private String confirmationMessage = "";
    private String cancelOkMessage = LABEL_SEARCH_TURN_TURNS_CANCELLATION_SUCCESS;
    private String cancelErrorMessage = LABEL_SEARCH_TURN_TURNS_CANCELLATION_ERROR;
    private TurnOperationType turnOperationType;
    private Long destinationId;

    protected abstract void sendMailTurnCancellation();
    protected abstract void loadTurnsAndContract();

    protected void init(Mode mode) {
        turnRequestService = getService(TurnRequestService.class);
        turnService = getService(TurnService.class);
        this.mode = mode;
        turnRequestDTO = turnRequestService.getDTO(turnRequestId);
        turnOperationDTO = new TurnOperationDTO();
        loadTurnsAndContract();
    }

    public String viewTurnAssignment() {
        init(Mode.VIEW);
        turnsToCancel = new HashSet<TurnDTO>();
        return SUCCESS;
    }

    public String cancelTurns(){
        init(Mode.UPDATE);
        turnsToCancel = new HashSet<TurnDTO>();
        return SUCCESS;
    }

    public String cancel(){
        this.mode = Mode.VIEW;
        return SUCCESS;
    }


    public void getTurnsSelectedToCancel() {
        turnOperationType = TurnOperationType.CANCELLATION;
        getTurnsSelected("label.cancellation.confirmMessageCancel");
    }

    public void getTurnsSelectedToAvailable() {
        turnOperationType = TurnOperationType.DEVIATION;
        getTurnsSelected("label.cancellation.confirmMessageAvailable");

    }

    public void getTurnsSelected(String message) {
        boolean isValid = false;
        turnOperationDTO.setReason("");
        this.turnOperationDTO.setType(turnOperationType);
        turnsToCancel = turnsFromAssignment.getSelected();
        if (!turnsToCancel.isEmpty()){
            isValid = true;
            this.setConfirmationMessage(message);
        }else {
            addMessage(getMessageBundle("label.search.turn.turnsCancellation.emptyList"));
        }
        addCallbackParam("isValid", isValid);
    }

    public String confirmCancelTurns() {
        try{
            turnService.suspendTurns(turnRequestDTO,turnsToCancel, turnOperationDTO);
            sendMailTurnCancellation();
            addMessageNoError(getMessageBundle(cancelOkMessage));
            addCallbackParam("cancelled",true);
        }catch (BusinessException ex){
            LOG.error("An error occurred cancelling turns: ", ex);
            addMessage(getMessageBundle(cancelErrorMessage));
            addCallbackParam("cancelled",false);
            return ERROR;
        }
        return SUCCESS;
    }

    public boolean isEditMode() {
        return mode.equals(Mode.UPDATE);
    }

    public boolean isViewMode() {
        return mode.equals(Mode.VIEW);
    }

    public boolean isReadOnly() {
        return mode.isReadOnly();
    }

    public List<TurnDTO> getTurnsToCancelList(){
        return new ArrayList<TurnDTO>(turnsToCancel);
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public Long getTurnRequestId() {
        return turnRequestId;
    }

    public void setTurnRequestId(Long turnRequestId) {
        this.turnRequestId = turnRequestId;
    }

    public TurnRequestDTO getTurnRequestDTO() {
        return turnRequestDTO;
    }

    public void setTurnRequestDTO(TurnRequestDTO turnRequestDTO) {
        this.turnRequestDTO = turnRequestDTO;
    }

    public TurnDataModel getTurnsFromAssignment() {
        return turnsFromAssignment;
    }

    public void setTurnsFromAssignment(TurnDataModel turnsFromAssignment) {
        this.turnsFromAssignment = turnsFromAssignment;
    }

    public Set<TurnDTO> getTurnsToCancel() {
        return turnsToCancel;
    }

    public void setTurnsToCancel(Set<TurnDTO> turnsToCancel) {
        this.turnsToCancel = turnsToCancel;
    }

    public String getConfirmationMessage() {
        return confirmationMessage;
    }

    public void setConfirmationMessage(String confirmationMessage) {
        this.confirmationMessage = confirmationMessage;
    }

    public TurnOperationType getTurnOperationType() {
        return turnOperationType;
    }

    public void setTurnOperationType(TurnOperationType turnOperationType) {
        this.turnOperationType = turnOperationType;
    }

    public TurnRequestService getTurnRequestService() {
        return turnRequestService;
    }

    public void setTurnRequestService(TurnRequestService turnRequestService) {
        this.turnRequestService = turnRequestService;
    }

    public TurnService getTurnService() {
        return turnService;
    }

    public void setTurnService(TurnService turnService) {
        this.turnService = turnService;
    }

    public TurnOperationDTO getTurnOperationDTO() {
        return turnOperationDTO;
    }

    public void setTurnOperationDTO(TurnOperationDTO turnOperationDTO) {
        this.turnOperationDTO = turnOperationDTO;
    }

    public String getCancelErrorMessage() {
        return cancelErrorMessage;
    }

    public void setCancelErrorMessage(String cancelErrorMessage) {
        this.cancelErrorMessage = cancelErrorMessage;
    }

    public String getCancelOkMessage() {
        return cancelOkMessage;
    }

    public void setCancelOkMessage(String cancelOkMessage) {
        this.cancelOkMessage = cancelOkMessage;
    }

    public Long getDestinationId() {
        return destinationId;
    }

    public void setDestinationId(Long destinationId) {
        this.destinationId = destinationId;
    }
}
