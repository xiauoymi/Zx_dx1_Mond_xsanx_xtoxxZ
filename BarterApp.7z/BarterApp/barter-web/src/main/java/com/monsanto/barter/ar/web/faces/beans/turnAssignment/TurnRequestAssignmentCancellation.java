package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.ar.business.entity.enumerated.TurnStatus;
import com.monsanto.barter.ar.business.service.TurnFilter;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;

/**
 * Created by JASANC5 on 09/19/2014.
 */
public class TurnRequestAssignmentCancellation extends TurnCancellation {

    @Override
    protected void loadTurnsAndContract() {
        TurnFilter turnFilter = new TurnFilter();
        turnFilter.setTurnRequestNumber(this.getTurnRequestId());
        turnFilter.setTurnStatus(TurnStatus.ASSIGNED);
        this.setTurnsFromAssignment(new TurnDataModel(this.getTurnService(), turnFilter));
    }

    @Override
    protected void sendMailTurnCancellation() {
        this.getTurnRequestService().sendMailTurnRequestCancellation(this.getTurnRequestDTO(),
                this.getTurnsToCancel(), this.getTurnOperationDTO());
    }

}