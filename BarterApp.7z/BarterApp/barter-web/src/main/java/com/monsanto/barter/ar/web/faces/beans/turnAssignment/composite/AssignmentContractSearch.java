package com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite;

import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TerminalDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractDataModel;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel.AssignmentContractDataModel;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 20/08/14
 * Time: 11:49
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class AssignmentContractSearch extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(AssignmentContractSearch.class);

    private ContractFilter filter;

    private ContractDataModel searchResult;

    @Autowired
    private ContractService contractService;

    @Autowired
    private PortService portService;

    @Autowired
    private TerminalService terminalService;

    @Autowired
    private MaterialLasService materialLasService;

    private PortDestinationDTO portDestination;

    private List<TerminalDTO> terminals;

    private Long terminalId;

    public AssignmentContractSearch() {
        this.filter = new ContractFilter();
    }

    public void begin(ContractFilter filter){
        LOG.debug("Beginning Assignment: contract search section");
        this.filter=filter;
        this.filter.setIncludeStockingCenters(false);
        searchResult = new AssignmentContractDataModel(contractService,filter);
        this.terminalId= null;
        if(filter.getPort()==null && filter.getPortId()==null){
            this.portDestination= null;
            this.terminalId = 0L;
        }else{
            if(filter.getPort()!=null){
                this.portDestination= new PortDestinationDTO(filter.getPort());
            }else {
                this.portDestination= portService.getPortDTO(filter.getPortId());
            }
            terminals = terminalService.findAllByPortDestination(portDestination.getId());
        }
        if(filter.getTerminalId()!=null){
            this.terminalId= filter.getTerminalId();
        }
        if(filter.getCropTypeId()!=null ){
            filter.setCropType(materialLasService.get(filter.getCropTypeId()));
        }
    }

    /**
     * Returns contracts with turns to assign:
     * turns to assign must be specified by user and greater than zero
     * @return
     */
    public List<ContractView> getContractListSelection(){
        List<ContractView> contractList = new ArrayList<ContractView>();
        Iterator<ContractView> iterator = searchResult.iterator();
        ContractView contract = null;
        while(iterator.hasNext()){
            contract= iterator.next();
            //Turns to assign must be specified by user and greater than zero
            if(contract.getTurnsToAssign()!=null && contract.getTurnsToAssign()!=0){
                contractList.add(contract);
            }
        }
        return contractList;
    }

    public void search(){
        LOG.debug("Starting contract search");
        if (validateFilters()){
            filter.setTerminalId(terminalId);
            if(portDestination !=null){
                filter.setPortId(portDestination.getId());
            }else{
                filter.setPort(null);
            }
            searchResult = new AssignmentContractDataModel(contractService,filter);
        }
    }

    public void clear(){
        MaterialLas cropType = filter.getCropType();
        filter=new ContractFilter();
        filter.setCropType(cropType);
        portDestination=null;
        terminalId=null;
        terminals=null;
        searchResult=null;
    }

    private boolean validateFilters(){
        if(filter.getDeliveryDateFrom() != null && filter.getDeliveryDateTo() != null && filter.getDeliveryDateFrom().after(filter.getDeliveryDateTo())){
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        if(filter.getTurnDate()==null){
            addMessage(getMessageBundle("label.input.turnDate.dateError"));
            return false;
        }
        return true;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }


    public void handleItemSelect(SelectEvent event) {
        portDestination = (PortDestinationDTO) event.getObject();
        terminals = terminalService.findAllByPortDestination(portDestination.getId());
    }

    public List<TerminalDTO> getTerminals() {
        return terminals;
    }

    public Long getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Long terminalId) {
        this.terminalId = terminalId;
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public ContractFilter getFilter() {
        return filter;
    }

    public ContractDataModel getSearchResult() {
        return searchResult;
    }

    public void clearPort(){
        portDestination=null;
        filter.setPortId(null);
        filter.setTerminalId(null);
        filter.setPort(null);
        filter.setTerminalId(null);
        terminals=null;
    }

}
