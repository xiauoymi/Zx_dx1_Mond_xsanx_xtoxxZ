package com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TurnRequestFilter;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.TurnAssignmentInput;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel.TurnRequestForAssignmentDataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 20/08/14
 * Time: 11:49
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class AssignmentTurnRequestSearchCC extends TurnAssignmentInput {

    private static final Logger LOG = LoggerFactory.getLogger(AssignmentTurnRequestSearchCC.class);

    private TurnRequestFilter turnRequestFilter;
    private TurnRequestForAssignmentDataModel searchResult;

    private List<MaterialLas> materialLasList;

    private PortDestinationDTO portDestination;

    private TurnRequestDTO selectedTurnRequest;

    @Autowired
    private PortService portService;

    @Autowired
    private MaterialLasService materialLasService;

    @Autowired
    private TurnRequestService turnRequestService;

    private TurnRequestStatus[] turnRequestStatuses;

    public String begin(TurnRequestFilter filter) {
        turnRequestFilter =  filter;
        loadCombos();
        portDestination = null;
        searchResult = new TurnRequestForAssignmentDataModel(turnRequestService, turnRequestFilter);
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        turnRequestFilter = new TurnRequestFilter();
        portDestination = null;
        return SUCCESS;
    }


    public void search() {
        LOG.debug("Search.");
        turnRequestFilter.setCropType(null);
        turnRequestFilter.setSuggestedPort(null);
        if (turnRequestFilter.getCropTypeId() != null){
            turnRequestFilter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList,turnRequestFilter.getCropTypeId()));
        }
        if (portDestination != null){
            turnRequestFilter.setSuggestedPort(portService.get(portDestination.getId()));
        }
        searchResult = new TurnRequestForAssignmentDataModel(turnRequestService, turnRequestFilter);
        LOG.debug("Search -> Result");
    }

    public TurnRequestFilter getTurnRequestFilter() {
        return turnRequestFilter;
    }

    public void setTurnRequestFilter(TurnRequestFilter turnRequestFilter) {
        this.turnRequestFilter = turnRequestFilter;
    }

    public TurnRequestForAssignmentDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(TurnRequestForAssignmentDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    private void loadCombos(){
        LOG.debug("loadCombos.");

        turnRequestStatuses = new TurnRequestStatus[]{TurnRequestStatus.OPENED,TurnRequestStatus.PENDING, TurnRequestStatus.SUSPENDED};


        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public void newSearch(){
        clear();
        search();
    }

    public TurnRequestStatus[] getTurnRequestStatuses() {
        return this.turnRequestStatuses;
    }

    public void setTurnRequestStatuses(TurnRequestStatus[] turnRequestStatuses) {
        this.turnRequestStatuses = Arrays.copyOf(turnRequestStatuses, turnRequestStatuses.length);
    }

    public TurnRequestDTO getSelectedTurnRequest() {
        return selectedTurnRequest;
    }

    public void setSelectedTurnRequest(TurnRequestDTO selectedTurnRequest) {
        this.selectedTurnRequest = selectedTurnRequest;
    }
}
