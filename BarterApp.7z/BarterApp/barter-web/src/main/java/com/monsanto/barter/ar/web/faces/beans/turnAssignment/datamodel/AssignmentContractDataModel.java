package com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel;

import com.monsanto.barter.ar.business.service.ContractFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractDataModel;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 29/08/14
 * Time: 09:19
 * To change this template use File | Settings | File Templates.
 */
public class AssignmentContractDataModel extends ContractDataModel{

    public AssignmentContractDataModel(ContractService service, ContractFilter filter) {
        super(service,filter);
    }

    @Override
    protected Recordset<ContractView> loadPage(ContractFilter filter, Paging paging) {
        return this.getService().searchForAssignment(filter,paging);
    }
}
