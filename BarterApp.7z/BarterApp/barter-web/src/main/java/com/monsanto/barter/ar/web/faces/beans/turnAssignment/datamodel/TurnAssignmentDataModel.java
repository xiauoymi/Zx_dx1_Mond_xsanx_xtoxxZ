package com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel;


import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.TurnAssignmentDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 08/09/14
 * Time: 13:33
 * To change this template use File | Settings | File Templates.
 */
public class TurnAssignmentDataModel extends AbstractDataModel<TurnAssignmentDTO,TurnAssignmentFilter> {

    private List<TurnAssignmentDTO> page = new ArrayList<TurnAssignmentDTO>(0);

    private TurnRequestService service;


    public TurnAssignmentDataModel(TurnRequestService service, TurnAssignmentFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public TurnAssignmentDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (TurnAssignmentDTO row : page) {
            if (row.getTurnRequestNumber().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<TurnAssignmentDTO> loadPage(TurnAssignmentFilter filter, Paging paging) {
        return service.searchTurnAssignments(filter,paging);
    }

    @Override
    public Object getRowKey(TurnAssignmentDTO object) {
        return object.getTurnRequestNumber().toString();
    }

    public TurnAssignmentFilter getFilter() {
        return filter;
    }
}
