package com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TurnRequestFilter;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 29/07/14
 * Time: 13:14
 * To change this template use File | Settings | File Templates.
 */
public class TurnRequestForAssignmentDataModel extends AbstractDataModel<TurnRequestDTO,TurnRequestFilter> {

    private List<TurnRequestDTO> page = new ArrayList<TurnRequestDTO>(0);

    private TurnRequestService service;


    public TurnRequestForAssignmentDataModel(TurnRequestService service, TurnRequestFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    public TurnRequestDTO getRowData(String rowKey) {
        Long rowId = Long.valueOf(rowKey);
        for (TurnRequestDTO row : page) {
            if (row.getId().equals(rowId)) {
                return row;
            }
        }
        return null;
    }

    @Override
    protected Recordset<TurnRequestDTO> loadPage(TurnRequestFilter filter, Paging paging) {
        return service.searchFromAssignment(filter,paging);
    }

    @Override
    public Object getRowKey(TurnRequestDTO object) {
        return object.getId().toString();
    }

    public TurnRequestFilter getFilter() {
        return filter;
    }
}
