package com.monsanto.barter.ar.web.faces.beans.turnRequest;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.groups.turnRequest.TurnsAvailability;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.filter.GrowerContractFilter;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.business.service.dto.TurnSummary;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.Region;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * Created by VNBARR on 7/30/2014.
 */
public class TurnRequestInput extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(TurnRequestInput.class);

    private static final int FIRST_SHEET_NUMBER = 0;
    public static final int MAX_COLUMN_SIZE = 13;
    public static final int ROW_NUMBER_3 = 3;

    private Mode mode;
    private TurnRequestWithoutContract turnRequest;
    private Long turnRequestId;

    private GrowerContractService growerContractService;
    private TurnRequestService turnRequestService;
    private TurnService turnService;
    private MaterialLasService materialLasService;

    private CustomerCC customerPos;
    private String contract;

    private CustomerCC grower;
    private PointOfSaleDTO userPOSDTO;
    private List<MaterialLas> materialLasList;
    private List<MaterialLas> contractList;

    private PortService portService;

    private PointOfSaleService pointOfSaleService;

    private Long portId;
    private PortDestinationDTO portDestination;
    private Long cropTypeId;
    private boolean posUser;

    private List<TurnSummary> turnsSummary;
    private HSSFCellStyle cellStyle;

    //Constants for export
    private static final int REQUEST_NUMBER_COLUMN=1;
    private static final int REQUEST_DATE_COLUMN=2;
    private static final int REQUEST_STATUS_COLUMN=3;
    private static final int REQUEST_POS_COLUMN=4;
    private static final int REQUEST_CROP_COLUMN=5;
    private static final int REQUEST_GROWER_COLUMN=6;
    private static final int REQUEST_CONTRACT_COLUMN=7;
    private static final int REQUEST_CONTRACT_DUE_DATE_COLUMN=8;
    private static final int REQUEST_LA_TIJERETA_COLUMN=9;
    private static final int REQUEST_PORT_COLUMN=10;
    private static final int REQUEST_TURN_DATE_COLUMN=11;
    private static final int REQUEST_TURN_QUANTITY_COLUMN=12;
    private static final int TURN_DATE_COLUMN=1;
    private static final int TURN_CODE_COLUMN=2;
    private static final int TURN_DESTINATION_COLUMN=3;
    private static final int TURN_CITY_COLUMN=4;
    private static final int TURN_COUNTY_COLUMN=5;
    private static final int TURN_PROVINCE_COLUMN=6;
    private static final int TURN_ADDRESSEE_COLUMN =7;
    private List<PortDestinationDTO> availablePorts;

    public String begin(){
        turnRequestId=null;
        turnRequest = null;
        userPOSDTO = null;
        portDestination = null;
        portId = null;
        init(Mode.CREATE);
        loadDefaultPOS();
        return SUCCESS;
    }

    public String viewTurnRequest() {
        init(Mode.VIEW);
        loadComponentsFromTurnRequest();
        turnsSummary = turnService.getTurnsSummary(turnRequestId);
        for(TurnSummary summary: turnsSummary){
            summary.setTurns(getAssignedTurnsByDateAndTurnRequest(summary.getTurnDate()));
        }
        return SUCCESS;
    }

    private void init(Mode mode) {
        turnRequestService = getService(TurnRequestService.class);
        materialLasService = getService(MaterialLasService.class);
        portService = getService(PortService.class);
        turnService = getService(TurnService.class);
        grower = getService(CustomerCC.class);
        pointOfSaleService = getService(PointOfSaleService.class);

        this.mode = mode;

        cleanFields();
        retrieveCropTypes();
        loadTurnRequestFromDB();
        loadDefaultPOS();
        checkPosUser();
    }

    private void cleanFields() {
        this.cropTypeId = null;
        this.grower.clear();
        this.portId = null;
        this.availablePorts = null;

    }

    private void loadDefaultPOS(){
        UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        if (user.isPos()){
            this.userPOSDTO = new PointOfSaleDTO(user.getPointOfSale());
            this.turnRequest.setEmailNotification(userPOSDTO.getEmail());
        }
    }

    private void checkPosUser(){
        UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        posUser = user.isPos();
    }

    private void loadComponentsFromTurnRequest() {
        if(turnRequest!=null){
            grower.setCustomer(turnRequest.getGrower());
            setCropTypeId(turnRequest.getCropTypeId());
            portId = turnRequest.getDestination().getId();
            userPOSDTO = new PointOfSaleDTO(turnRequest.getUserPOS());
        }
    }

    private void loadTurnRequestFromDB() {
        if(turnRequestId!=null){
            try {
                LOG.debug("Retrieve Turn Request from DB.");
                turnRequest = (TurnRequestWithoutContract)turnRequestService.get(turnRequestId);
            }catch (BusinessException ex){
                LOG.error("An error occurred loading Turn Request: ", ex);
                addMessage(getMessageBundle("label.load.turnRequest.error"));
            }
        }else{
            turnRequest = new TurnRequestWithoutContract();
        }
    }

    public boolean isReadOnly() {
        return mode.isReadOnly();
    }


    public void preSave(){
        setValuesFromComponents();
        boolean validForSave = false;
        if (validate()) {
            validForSave = true;
        }
        addCallbackParam("validForSave", validForSave);
    }

    private void setValuesFromComponents() {
        turnRequest.setGrower(grower.getSelectedCustomer());
        turnRequest.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, cropTypeId));
        setPortDestination();
        setPointOfSale();
    }

    private Long getSelectedPortId(){
        if (portId != null) {
            return portId;
        }
        if (portDestination!= null){
            return portDestination.getId();
        }
        return null;
    }

    private void setPortDestination() {
        try{
            Long selectedPortId= getSelectedPortId();
            if (selectedPortId != null) {
                if ( turnRequest.getDestination() == null ||  !turnRequest.getDestination().getId().equals(selectedPortId) ) {
                    turnRequest.setDestination(portService.get(selectedPortId));
                }
            }else{
                turnRequest.setDestination(null);
            }
        }catch (BusinessException e){
            addMessage(getMessageBundle("label.load.port.error"));
            LOG.error("Error loading port",e);
        }
    }

    private void setPointOfSale() {
        try{
            if (userPOSDTO != null) {
                if (turnRequest.getUserPOS() == null ||  !turnRequest.getUserPOS().getId().equals(userPOSDTO.getId())){
                    turnRequest.setUserPOS(pointOfSaleService.get(userPOSDTO.getId()));
                }
            }else{
                turnRequest.setUserPOS(null);
            }
        }catch (BusinessException e){
            addMessage(getMessageBundle("label.load.pointOfSale.error"));
            LOG.error("Error loading point of service",e);
        }

    }

    private boolean validate() {
        List<String> violationMessages = getValidator().validate(turnRequest);
        //if contract expiration date is empty then ask to complete observation field
        if (turnRequest.getContractExpirationDate() == null && isBlank(turnRequest.getObservations())){
            violationMessages.add(getMessageBundle("turnRequest.contractExpirationDate.observations"));
        }
        if (!violationMessages.isEmpty()) {
            addMessagesErrors(violationMessages);
            return false;
        }
        return true;
    }

    private void addMessagesErrors(List<String> violationMessages) {
        for (String violationMessage : violationMessages) {
            addMessage(violationMessage);
        }
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public String save(){
        String result;
        try{
            LOG.debug("Going to save turn request");
            if(turnRequest.getId()==null){
                turnRequestService.save(turnRequest);
                addMessageNoError(getMessageBundle("label.input.turnRequest.created" )+ turnRequest.getId());
            }
            else{
                turnRequestService.update(turnRequest);
                addMessageNoError(getMessageBundle("label.input.turnRequest.updated")+ turnRequest.getId());
            }
            result = begin();
        }catch (BusinessException ex){
            LOG.error("An error occurred saving turn request: ", ex);
            addMessage(getMessageBundle("label.input.turnRequest.creation.error"));
            result = ERROR;
        }
        return result;
    }

    public String cancel(){
        this.mode = Mode.CREATE;
        turnRequest=null;
        turnRequestId=null;
        this.portDestination = null;
        portId = null;
        return SUCCESS;
    }


    public void retrieveCropTypes() {
        try {
            LOG.debug("Getting crop types");
            materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading Crops: ", ex);
            addMessage(ex);
        }
    }


    public void handlePointOfSaleSelect(SelectEvent event) {
        userPOSDTO = (PointOfSaleDTO) event.getObject();
        this.turnRequest.setEmailNotification(userPOSDTO.getEmail());
    }

    public List<PointOfSaleDTO> pointOfSaleAutocomplete(String query) {
        return pointOfSaleService.search(query);
    }

    public CustomerCC getGrower() {
        return grower;
    }

    public void setGrower(CustomerCC grower) {
        this.grower = grower;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public TurnRequestWithoutContract getTurnRequest() {
        return turnRequest;
    }

    public void setTurnRequest(TurnRequestWithoutContract turnRequest) {
        this.turnRequest = turnRequest;
    }

    public Long getTurnRequestId() {
        return turnRequestId;
    }

    public void setTurnRequestId(Long turnRequestId) {
        this.turnRequestId = turnRequestId;
    }

    public PointOfSaleDTO getUserPOSDTO() {
        return userPOSDTO;
    }

    public void setUserPOSDTO(PointOfSaleDTO userPOSDTO) {
        this.userPOSDTO = userPOSDTO;
    }

    public Long getCropTypeId() {
        return cropTypeId;
    }

    public void setCropTypeId(Long cropTypeId) {
        this.cropTypeId = cropTypeId;
    }

    public Mode getMode() {
        return mode;
    }


    /**
     * If fields for checking turn availability are completed
     * then it checks if there are destinations to load
     */
    public void loadPortDestinationsIfAvailable(){
        boolean validFields = validateAvailabilityFields();
        if (validFields) {
            availablePorts = turnService.getPortsForAvailableTurns(turnRequest.getTurnRequestDate(), turnRequest.getCropTypeId());
            portDestination=null;//set the first one by default
            portId=null;
            if (!availablePorts.isEmpty()){
                portId = availablePorts.get(0).getId();
                portDestination=null;
            }
        }else{
            availablePorts = null;
            portId=null;
            portDestination=null;
        }
    }

    /**
     * Validates only fields related to TurnsAvailability group
     * @return true if they are all valid
     */
    private boolean validateAvailabilityFields() {
        setValuesFromComponents();
        List<String> violationMessages = getValidator().validate(turnRequest, TurnsAvailability.class);
        return violationMessages.isEmpty();
    }

    public Long getTurnRemnantsQuantity(){
        return turnRequest.calculateRemnants();
    }

    public boolean isPosUser() {
        return posUser;
    }

    public void setPosUser(boolean isPosUser) {
        this.posUser = isPosUser;
    }

    public List<TurnSummary> getTurnsSummary() {
        return turnsSummary;
    }

    private List<TurnDTO> getAssignedTurnsByDateAndTurnRequest(Date turnDate){
        return turnService.getAssignedTurnsByDateAndTurnRequestId(turnRequest.getId(), turnDate);
    }

    public void postProcessXLS(Object document){
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(FIRST_SHEET_NUMBER);

        createCellStyle(wb);

        createTitle(sheet);

        createRequestHeader(wb);

        createDataTable(wb);

        createFooter(sheet);

        adjustColumnSize(sheet);
    }

    private void createTitle(HSSFSheet sheet) {
        int rowNumber=1;
        HSSFRow titleRow = sheet.createRow(rowNumber);
        HSSFCell titleCell = createCellFor(titleRow,1,getMessageBundle("label.report.turnRequest.title"));
        sheet.addMergedRegion(new Region(rowNumber,(short)1,rowNumber,(short)ROW_NUMBER_3));
        titleCell.setCellStyle(cellStyle);
    }

    private void adjustColumnSize(HSSFSheet sheet) {
        for(int i = 0; i <= MAX_COLUMN_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }

    private HSSFCell createCellFor(HSSFRow row,int columnNumber,String columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellValue(columnValue);
        return cell;
    }

    private HSSFCell createCellFor(HSSFRow row,int columnNumber,Long columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellValue(columnValue);
        return cell;
    }

    private HSSFCell createCellFor(HSSFRow row,int columnNumber,int columnValue){
        HSSFCell cell = row.createCell(columnNumber);
        cell.setCellValue(columnValue);
        return cell;
    }

    private void createRequestHeader(HSSFWorkbook wb) {
        HSSFSheet sheet= wb.getSheetAt(FIRST_SHEET_NUMBER);
        int rowNumber=ROW_NUMBER_3;
        HSSFRow headerRow = sheet.createRow(rowNumber);
        int headerRowNumber=rowNumber;

        createCellFor(headerRow,REQUEST_NUMBER_COLUMN,getMessageBundle("label.report.excel.turnRequest.requestNumber"));
        createCellFor(headerRow,REQUEST_DATE_COLUMN,getMessageBundle("label.report.excel.requestDate"));
        createCellFor(headerRow,REQUEST_STATUS_COLUMN,getMessageBundle("label.report.excel.turnRequest.requestStatus"));
        createCellFor(headerRow,REQUEST_POS_COLUMN,getMessageBundle("label.report.excel.pos"));
        createCellFor(headerRow,REQUEST_CROP_COLUMN,getMessageBundle("label.report.excel.turnRequest.crop"));
        createCellFor(headerRow,REQUEST_GROWER_COLUMN,getMessageBundle("label.report.excel.turnRequest.grower"));
        createCellFor(headerRow,REQUEST_CONTRACT_COLUMN,getMessageBundle("label.report.excel.turnRequest.contractNumber"));
        createCellFor(headerRow,REQUEST_CONTRACT_DUE_DATE_COLUMN,getMessageBundle("label.report.excel.turnRequest.contract.dueDate"));
        createCellFor(headerRow, REQUEST_LA_TIJERETA_COLUMN, getMessageBundle("label.report.excel.turnRequest.laTijereta"));
        createCellFor(headerRow, REQUEST_PORT_COLUMN, getMessageBundle("label.report.excel.turnRequest.port"));
        createCellFor(headerRow, REQUEST_TURN_DATE_COLUMN, getMessageBundle("label.report.excel.turnRequest.turnDate"));
        createCellFor(headerRow, REQUEST_TURN_QUANTITY_COLUMN, getMessageBundle("label.report.excel.turnRequest.turnQuantity"));

        HSSFRow row = sheet.createRow(++rowNumber);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        createCellFor(row,REQUEST_NUMBER_COLUMN,turnRequest.getId());
        createCellFor(row,REQUEST_DATE_COLUMN,sdf.format(turnRequest.getCreatedDate()));
        createCellFor(row,REQUEST_STATUS_COLUMN,getMessageBundle(turnRequest.getStatus().getDescription()));
        createCellFor(row,REQUEST_POS_COLUMN,turnRequest.getUserPOS().getCustomer().getDescription());
        createCellFor(row,REQUEST_CROP_COLUMN,turnRequest.getCropType().getCommercialText());
        createCellFor(row,REQUEST_GROWER_COLUMN,turnRequest.getGrower().getDescription());
        createCellFor(row,REQUEST_CONTRACT_COLUMN,turnRequest.getContractNumber());

        String contractExpirationDate="";
        if(turnRequest.getContractExpirationDate()!=null){
            contractExpirationDate=sdf.format(turnRequest.getContractExpirationDate());
        }
        createCellFor(row,REQUEST_CONTRACT_DUE_DATE_COLUMN,contractExpirationDate);

        String tijeretaMessage;
        if(turnRequest.isLaTijereta()){
            tijeretaMessage = "label.report.excel.yes";
        }
        else{
            tijeretaMessage = "label.report.excel.no";
        }
        createCellFor(row,REQUEST_LA_TIJERETA_COLUMN,getMessageBundle(tijeretaMessage));
        createCellFor(row,REQUEST_PORT_COLUMN,turnRequest.getDestination().getStorageLocationDescription());

        createCellFor(row,REQUEST_TURN_DATE_COLUMN,sdf.format(turnRequest.getTurnRequestDate()));
        createCellFor(row,REQUEST_TURN_QUANTITY_COLUMN,turnRequest.getTurnQuantity());

        addStyleToDataTableHeader(wb, headerRowNumber);
        addBordersToDataTableCells(wb, headerRowNumber, rowNumber);

    }

    private void createDataTable(HSSFWorkbook wb){
        HSSFSheet sheet= wb.getSheetAt(FIRST_SHEET_NUMBER);

        int rowNumber=sheet.getLastRowNum()+2;
        HSSFRow headerRow = sheet.createRow(rowNumber);
        int headerRowNumber=rowNumber;

        createCellFor(headerRow,TURN_DATE_COLUMN,getMessageBundle("com.monsanto.barter.ar.business.service.dto.TurnSummary.turnDate"));
        createCellFor(headerRow,TURN_CODE_COLUMN,getMessageBundle("com.monsanto.barter.ar.business.service.dto.TurnSummary.turn.code"));
        createCellFor(headerRow,TURN_DESTINATION_COLUMN,getMessageBundle("com.monsanto.barter.ar.business.service.dto.TurnSummary.turn.terminal"));
        createCellFor(headerRow,TURN_CITY_COLUMN,getMessageBundle("ar.barter.locationCC.city"));
        createCellFor(headerRow,TURN_COUNTY_COLUMN,getMessageBundle("ar.barter.locationCC.county"));
        createCellFor(headerRow,TURN_PROVINCE_COLUMN,getMessageBundle("ar.barter.locationCC.province"));
        createCellFor(headerRow,TURN_ADDRESSEE_COLUMN,getMessageBundle("com.monsanto.barter.ar.business.service.dto.TurnSummary.turn.addressee"));
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        for(TurnSummary turnSummary: getTurnsSummary()){
            for( TurnDTO turn: turnSummary.getTurns()){
                HSSFRow row = sheet.createRow(++rowNumber);
                createCellFor(row,TURN_DATE_COLUMN,sdf.format(turnSummary.getTurnDate()));
                createCellFor(row,TURN_CODE_COLUMN,turn.getCode());
                createCellFor(row,TURN_DESTINATION_COLUMN,turn.getTerminalName());
                createCellFor(row,TURN_CITY_COLUMN,turn.getCity());
                createCellFor(row,TURN_COUNTY_COLUMN,turn.getCounty());
                createCellFor(row,TURN_PROVINCE_COLUMN,turn.getProvince());
                createCellFor(row,TURN_ADDRESSEE_COLUMN,turn.getExporterDescription());
            }

        }

        addStyleToDataTableHeader(wb, headerRowNumber);
        addBordersToDataTableCells(wb, headerRowNumber, rowNumber);
    }

    private void addStyleToDataTableHeader(HSSFWorkbook wb,int rowNumber){
        HSSFCellStyle newCellStyle = wb.createCellStyle();
        newCellStyle.cloneStyleFrom(cellStyle);

        newCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        newCellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        newCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        newCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = wb.getSheetAt(FIRST_SHEET_NUMBER).getRow(rowNumber);
        for(int i=1; i <= header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(newCellStyle);
        }
    }

    private void addBordersToDataTableCells(HSSFWorkbook wb, int headerRowNumber, int rowNumber) {
        HSSFSheet sheet = wb.getSheetAt(FIRST_SHEET_NUMBER);
        for(int rowIndex = headerRowNumber+1; rowIndex <= rowNumber; rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle newCellStyle = wb.createCellStyle();
                    newCellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    newCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    newCellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    newCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    newCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(newCellStyle);
                }
            }
        }
    }

    private void createFooter(HSSFSheet sheet) {
        int newRow = sheet.getLastRowNum()+ ROW_NUMBER_3;
        int columnNumber=1;

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = createCellFor(row,columnNumber,getMessageBundle("label.report.excel.totalFechas"));
        cell0.setCellStyle(cellStyle);
        HSSFCell cell1 = createCellFor(row,columnNumber+1,turnsSummary.size());
        cell1.setCellStyle(cellStyle);
    }

    private void getGrowerContracts() {
        GrowerContractFilter filter = new GrowerContractFilter();

        filter.setPos(customerPos.getDocumentNumber());
        filter.setGrower(grower.getDocumentNumber());
        filter.setPort(new PortDestinationDTO(portId, "", ""));
        filter.setCrop(MonCollectionsUtils.findByPrimaryKey(materialLasList, cropTypeId));
        growerContractService.search(filter);
    }

    private void createCellStyle(HSSFWorkbook wb) {
        cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    }

    public List<PortDestinationDTO> getAvailablePorts() {
        return availablePorts;
    }

    public void setAvailablePorts(List<PortDestinationDTO> availablePorts) {
        this.availablePorts = availablePorts;
    }

    public Long getPortId() {
        return portId;
    }

    public void setPortId(Long portId) {
        this.portId = portId;
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public List<PortDestinationDTO> autocompletePort(String query) {
        return portService.search(query);
    }

    public void handleItemSelect(SelectEvent event) {
        portDestination = (PortDestinationDTO) event.getObject();
    }

    public boolean isAvailablePortsEnable(){
        return this.availablePorts != null && !this.availablePorts.isEmpty();
    }

    public CustomerCC getCustomerPos() {
        return customerPos;
    }

    public void setCustomerPos(CustomerCC customerPos) {
        this.customerPos = customerPos;
    }

    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    public List<MaterialLas> getContractList() {
        return contractList;
    }

    public void setContractList(List<MaterialLas> contractList) {
        this.contractList = contractList;
    }
}