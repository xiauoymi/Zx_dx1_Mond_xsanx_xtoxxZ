package com.monsanto.barter.ar.web.faces.beans.turnRequest;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.utils.MonCollectionsUtils;
import com.monsanto.barter.ar.web.faces.beans.turnRequest.datamodel.TurnRequestReportDataModel;
import com.monsanto.barter.ar.web.faces.report.ReportBase;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 15/10/14
 * Time: 10:38
 * To change this template use File | Settings | File Templates.
 */
public class TurnRequestReportFormBean extends ReportBase<TurnRequestReportDataModel, TurnRequestFilter, TurnRequestService> {

    private static final Logger LOG = LoggerFactory.getLogger(TurnRequestReportFormBean.class);
    private static final int TURN_REQUEST_NUMBER_HEADER_INDEX = 0;
    private static final int TURN_REQUEST_NUMBER_VALUE_HEADER_INDEX = 1;
    private static final int REQUEST_DATE_FROM_HEADER_INDEX = 2;
    private static final int REQUEST_DATE_FROM_VALUE_HEADER_INDEX = 3;
    private static final int REQUEST_DATE_TO_HEADER_INDEX = 4;
    private static final int REQUEST_DATE_TO_VALUE_HEADER_INDEX = 5;
    private static final int STATUS_HEADER_INDEX = 6;
    private static final int STATUS_VALUE_HEADER_INDEX = 7;
    private static final int POS_HEADER_INDEX = 8;
    private static final int POS_VALUE_HEADER_INDEX = 9;

    public static final int CROP_HEADER_INDEX = 0;
    public static final int CROP_VALUE_HEADER_INDEX = 1;
    private static final int GROWER_HEADER_INDEX = 2;
    private static final int GROWER_VALUE_HEADER_INDEX = 3;
    private static final int LA_TIJERETA_HEADER_INDEX = 4;
    private static final int LA_TIJERETA_VALUE_HEADER_INDEX = 5;
    private static final int PORT_HEADER_INDEX = 6;
    private static final int PORT_VALUE_HEADER_INDEX = 7;

    private PointOfSaleService pointOfSaleService;

    private MaterialLasService materialLasService;
    private List<MaterialLas> materialLasList;

    private TurnRequestStatus [] turnRequestStatus;

    PortService portService;
    private PortDestinationDTO portDestination;

    private boolean posUser;
    private boolean parentPos;
    private List<PointOfSale> posBranches;

    @Override
    protected void initFilter() {
        LOG.debug("Clear fields.");
        filter = new TurnRequestFilter();
        portDestination = null;
        loadDefaultPOS();
    }

    @Override
    protected void initServices() {
        service = getService(TurnRequestService.class);
        materialLasService = getService(MaterialLasService.class);
        portService = getService(PortService.class);
        pointOfSaleService =getService(PointOfSaleService.class);
    }

    @Override
    protected void loadCombos() {
        LOG.debug("loadCombos.");
        turnRequestStatus = TurnRequestStatus.values();
        try {
            materialLasList = materialLasService.findAll();
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
        loadDefaultPOS();
    }

    @Override
    protected boolean validateFilters() {
        LOG.debug("validateFilters.");
        if (filter.getTurnRequestDateFrom() != null && filter.getTurnRequestDateTo() != null && filter.getTurnRequestDateFrom().after(filter.getTurnRequestDateTo())) {
            addMessage(getMessageBundle("label.search.error.dateError"));
            return false;
        }
        return true;
    }

    @Override
    protected void initReport() {
        filter.setCropType(MonCollectionsUtils.findByPrimaryKey(materialLasList, filter.getCropTypeId()));

        if(portDestination !=null){
            filter.setSuggestedPort(portService.get(portDestination.getId()));
        }

        if (filter.getPointOfSaleId()!= null){
            filter.setUserPOSDTO(new PointOfSaleDTO(MonCollectionsUtils.findByPrimaryKey(posBranches,filter.getPointOfSaleId())));
        }

        searchResult = new TurnRequestReportDataModel(service, filter);
        LOG.debug("Search -> Result");
    }

    @Override
    protected void createHeaderFirstRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0, sheet.getLastRowNum(), HEADER_OFFSET - 1);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(TURN_REQUEST_NUMBER_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(TURN_REQUEST_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(REQUEST_DATE_FROM_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(REQUEST_DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell4= row.createCell(REQUEST_DATE_TO_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(REQUEST_DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(STATUS_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(STATUS_VALUE_HEADER_INDEX);
        HSSFCell cell8 = row.createCell(POS_HEADER_INDEX);
        HSSFCell cell9 = row.createCell(POS_VALUE_HEADER_INDEX);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.turnRequestId"));
        cell0.setCellStyle(cellStyle);
        if(filter.getId()!=null){
            cell1.setCellValue(filter.getId());
        } else {
            cell1.setCellValue("");
        }


        cell2.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell2.setCellStyle(cellStyle);
        if (filter.getTurnRequestDateFrom() != null) {
            cell3.setCellValue(sdf.format(filter.getTurnRequestDateFrom()));
        } else {
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell4.setCellStyle(cellStyle);
        cell5.setCellStyle(cellStyle);
        if (filter.getTurnRequestDateTo() != null) {
            cell5.setCellValue(sdf.format(filter.getTurnRequestDateTo()));
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.requestStatus"));
        cell6.setCellStyle(cellStyle);
        if(filter.getStatus()!=null){
            cell7.setCellValue(getMessageBundle(filter.getStatus().getDescription()));
        } else {
            cell7.setCellValue("");
        }

        cell8.setCellValue(getMessageBundle("label.report.excel.pos"));
        cell8.setCellStyle(cellStyle);
        if(filter.getUserPOSDTO()!=null){
            cell9.setCellValue(filter.getUserPOSDescription());
        } else {
            cell9.setCellValue("");
        }

    }

    @Override
    protected void createHeaderSecondRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell0 = row2.createCell(CROP_HEADER_INDEX);
        HSSFCell cell1 = row2.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row2.createCell(GROWER_HEADER_INDEX);
        HSSFCell cell3 = row2.createCell(GROWER_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row2.createCell(LA_TIJERETA_HEADER_INDEX);
        HSSFCell cell5 = row2.createCell(LA_TIJERETA_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row2.createCell(PORT_HEADER_INDEX);
        HSSFCell cell7 = row2.createCell(PORT_VALUE_HEADER_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell0.setCellStyle(cellStyle);
        if(filter.getCropType()!=null){
            cell1.setCellValue(filter.getCropType().getCommercialText());
        } else {
            cell1.setCellValue("");
        }

        cell2.setCellValue(getMessageBundle("label.report.excel.grower"));
        cell2.setCellStyle(cellStyle);
        cell3.setCellValue(filter.getGrower());

        //TODO change
        /*
                if (!isPosUser()) {
            cell22.setCellValue(getMessageBundle("label.report.result.laTijereta"));
            cell22.setCellStyle(cellStyle);
            if (turnRequestFilter.getLaTijereta() != null) {
                cell23.setCellValue(getMessageBundle(turnRequestFilter.getLaTijeretaDescription()));
            } else {
                cell23.setCellValue("");
            }
        }
         */

        cell4.setCellValue(getMessageBundle("label.report.excel.laTijereta"));
        cell4.setCellStyle(cellStyle);
        if(filter.getLaTijereta()!=null){
            if(filter.getLaTijereta()){
                cell5.setCellValue(getMessageBundle("label.report.excel.yes"));
            } else {
                cell5.setCellValue(getMessageBundle("label.report.excel.no"));
            }
        } else {
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.portDestination"));
        cell6.setCellStyle(cellStyle);
        if(portDestination!=null){
            cell7.setCellValue(portDestination.getCompleteDescription());
        } else {
            cell7.setCellValue("");
        }

    }

    @Override
    protected void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public TurnRequestStatus[] getTurnRequestStatus() {
        return turnRequestStatus;
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public List<PointOfSaleDTO> pointOfSaleAutocomplete(String query) {
        return pointOfSaleService.search(query);
    }

    private void loadDefaultPOS(){
        UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        if (user.isPos()){
            LOG.debug("POS user");
            posUser = true;
            if(user.getPointOfSale().isBranchOffice()) {
                parentPos = false;
                filter.setUserPOSDTO(new PointOfSaleDTO(user.getPointOfSale()));
                LOG.debug("POS-Branch user");
            }else{
                //load pos branches
                LOG.debug("POS-Central user");
                parentPos = true;
                posBranches = this.pointOfSaleService.searchBranchesByParent(user.getPointOfSale());
                filter.setParentPointOfSaleId(user.getPointOfSale().getId());
                posBranches.add(user.getPointOfSale());
            }
        }
    }

    public boolean isPosUser() {
        return posUser;
    }

    public void handlePointOfSaleSelect(SelectEvent event) {
        filter.setUserPOSDTO((PointOfSaleDTO) event.getObject());
    }

    public boolean isParentPos() {
        return parentPos;
    }

    public List<PointOfSale> getPosBranches() {
        return posBranches;
    }


}
