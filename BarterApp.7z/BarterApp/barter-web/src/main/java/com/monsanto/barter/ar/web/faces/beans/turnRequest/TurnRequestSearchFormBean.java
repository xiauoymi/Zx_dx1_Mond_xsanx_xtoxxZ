package com.monsanto.barter.ar.web.faces.beans.turnRequest;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.base.IPrimaryKey;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.TurnRequest;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.turnRequest.datamodel.TurnRequestDataModel;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

/**
 * Created by JASANC5 on 7/29/2014.
 */
public class TurnRequestSearchFormBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(TurnRequestSearchFormBean.class);

    public static final String PAGE_SEARCH_RESULT = "turn-request-search-result";

    private TurnRequestService turnRequestService;
    private PortService portService;
    private TurnRequestFilter turnRequestFilter;
    private TurnRequestDataModel searchResult;
    private MaterialLasService materialLasService;
    private List<MaterialLas> materialLasList;
    private TurnRequestStatus[] turnRequestStatuses;
    private PointOfSaleService pointOfSaleService;
    private Long turnRequestId;
    private String cancelReason;
    private PortDestinationDTO portDestination;

    public static final int POS_HEADER_INDEX= 0;
    public static final int POS_VALUE_HEADER_INDEX= 1;
    public static final int ID_HEADER_INDEX = 2;
    public static final int ID_VALUE_HEADER_INDEX = 3;
    public static final int CROP_HEADER_INDEX = 4;
    public static final int CROP_VALUE_HEADER_INDEX = 5;
    public static final int GROWER_HEADER_INDEX = 6;
    public static final int GROWER_VALUE_HEADER_INDEX = 7;





    public static final int REQUEST_DATE_FROM_HEADER_INDEX = 0;
    public static final int REQUEST_DATE_FROM_VALUE_HEADER_INDEX = 1;
    public static final int REQUEST_DATE_TO_HEADER_INDEX = 2;
    public static final int REQUEST_DATE_TO_VALUE_HEADER_INDEX = 3;
    public static final int TURN_DATE_FROM_HEADER_INDEX = 4;
    public static final int TURN_DATE_FROM_VALUE_HEADER_INDEX = 5;
    public static final int TURN_DATE_TO_HEADER_INDEX = 6;
    public static final int TURN_DATE_TO_VALUE_HEADER_INDEX =7 ;

    public static final int STATUS_HEADER_INDEX = 0;
    public static final int STATUS_VALUE_HEADER_INDEX = 1;
    public static final int PORT_DESTINATION_HEADER_INDEX = 2;
    public static final int PORT_DESTINATION_VALUE_HEADER_INDEX = 3;
    public static final int CONTRACT_NUMBER_HEADER_INDEX = 4;
    public static final int CONTRACT_NUMBER_VALUE_HEADER_INDEX = 5;
    public static final int TIJERETA_HEADER_INDEX= 6;
    public static final int TIJERETA_VALUE_HEADER_INDEX= 7;

    public static final int HEADER_OFFSET = 4;
    public static final int MAX_COLUMNS_SIZE = 7;
    private boolean posUser;
    private List<PointOfSale> posBranches;
    private boolean parentPos;

    public String begin(){
        LOG.debug("Setting filters.");
        turnRequestFilter = new TurnRequestFilter();
        LOG.debug("Retrieving services.");
        turnRequestService = getService(TurnRequestService.class);
        materialLasService = getService(MaterialLasService.class);
        loadCombos();
        portDestination = null;
        portService = getService(PortService.class);
        pointOfSaleService = getService(PointOfSaleService.class);
        loadDefaultPOS();
        return SUCCESS;
    }

    public String clear(){
        LOG.debug("Clear fields.");
        turnRequestFilter = new TurnRequestFilter();
        portDestination = null;
        loadDefaultPOS();
        return SUCCESS;
    }

    private Predicate createPredicate(final Object id) {
        return new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                return ((IPrimaryKey)o).getPrimaryKey().equals(id);
            }
        };
    }

    public String search() {
        LOG.debug("Search.");

        if(!validateFilters()){
            return null;
        }

        Predicate predicate = createPredicate(turnRequestFilter.getCropTypeId());
        turnRequestFilter.setCropType((MaterialLas) CollectionUtils.find(materialLasList, predicate));

        if (turnRequestFilter.getPointOfSaleId()!= null){
            Predicate predicatePos = createPredicate(turnRequestFilter.getPointOfSaleId());
            turnRequestFilter.setUserPOSDTO(new PointOfSaleDTO((PointOfSale)CollectionUtils.find(posBranches, predicatePos)));
        }

        if (portDestination != null) {
            turnRequestFilter.setSuggestedPort(portService.get(portDestination.getId()));
        }

        searchResult = new TurnRequestDataModel(turnRequestService, turnRequestFilter);
        LOG.debug("Search -> Result");
        return PAGE_SEARCH_RESULT;

    }

    private boolean validateFilters() {
        boolean valid=true;
        LOG.debug("validateFilters.");
        if(turnRequestFilter.getTurnRequestDateFrom() != null && turnRequestFilter.getTurnRequestDateTo() != null && turnRequestFilter.getTurnRequestDateFrom().after(turnRequestFilter.getTurnRequestDateTo())){
            addMessage(getMessageBundle("label.search.turnRequest.error.requestDateError"));
            valid=false;
        }

        if(turnRequestFilter.getCreationDateFrom() != null && turnRequestFilter.getCreationDateTo() != null && turnRequestFilter.getCreationDateFrom().after(turnRequestFilter.getCreationDateTo())){
            addMessage(getMessageBundle("label.search.turnRequest.error.creationDateError"));
            valid=false;
        }

        return valid;
    }

    private void loadCombos(){
        LOG.debug("loadCombos.");
        turnRequestStatuses = TurnRequestStatus.values();
        try {
            setMaterialLasList(materialLasService.findAll());
        } catch (BusinessException ex) {
            LOG.error("An error occurred loading combos: ", ex);
            addMessage(ex);
        }
    }

    public TurnRequestFilter getTurnRequestFilter() {
        return turnRequestFilter;
    }

    public void setTurnRequestFilter(TurnRequestFilter turnRequestFilter) {
        this.turnRequestFilter = turnRequestFilter;
    }

    public TurnRequestDataModel getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(TurnRequestDataModel searchResult) {
        this.searchResult = searchResult;
    }

    public List<MaterialLas> getMaterialLasList() {
        return materialLasList;
    }

    public void setMaterialLasList(List<MaterialLas> materialLasList) {
        this.materialLasList = materialLasList;
    }

    public TurnRequestStatus[] getTurnRequestStatuses() {
        return turnRequestStatuses;
    }

    public void setTurnRequestStatuses(TurnRequestStatus[] turnRequestStatuses) {
        this.turnRequestStatuses = Arrays.copyOf(turnRequestStatuses, turnRequestStatuses.length);
    }

    public List<PortDestinationDTO> autocomplete(String query) {
        return portService.search(query);
    }

    public PortDestinationDTO getPortDestination() {
        return portDestination;
    }

    public void setPortDestination(PortDestinationDTO portDestination) {
        this.portDestination = portDestination;
    }

    private void loadDefaultPOS(){
        UserDecorator user = GlobalBarterSecurityHelper.getLoggedInUser();
        if (user.isPos()){
            LOG.debug("POS user");
            posUser = true;
            if(user.getPointOfSale().isBranchOffice()) {
                parentPos = false;
                this.turnRequestFilter.setUserPOSDTO(new PointOfSaleDTO(user.getPointOfSale()));
                LOG.debug("POS-Branch user");
            }else{
                //load pos branches
                LOG.debug("POS-Central user");
                parentPos = true;
                posBranches = this.pointOfSaleService.searchBranchesByParent(user.getPointOfSale());
                turnRequestFilter.setParentPointOfSaleId(user.getPointOfSale().getId());
                posBranches.add(user.getPointOfSale());
            }
        }
    }

    public Long getTurnRequestId() {
        return turnRequestId;
}

    public void setTurnRequestId(Long turnRequestId) {
        this.turnRequestId = turnRequestId;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb) {
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
        createHeaderThirdRow(wb);
    }

    private void createHeaderThirdRow(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row3 = sheet.createRow(2);
        HSSFCell cell16 = row3.createCell(STATUS_HEADER_INDEX);
        HSSFCell cell17 = row3.createCell(STATUS_VALUE_HEADER_INDEX);
        HSSFCell cell18 = row3.createCell(PORT_DESTINATION_HEADER_INDEX);
        HSSFCell cell19 = row3.createCell(PORT_DESTINATION_VALUE_HEADER_INDEX);
        HSSFCell cell20 = row3.createCell(CONTRACT_NUMBER_HEADER_INDEX);
        HSSFCell cell21 = row3.createCell(CONTRACT_NUMBER_VALUE_HEADER_INDEX);
        HSSFCell cell22 = row3.createCell(TIJERETA_HEADER_INDEX);
        HSSFCell cell23 = row3.createCell(TIJERETA_VALUE_HEADER_INDEX);

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell16.setCellValue(getMessageBundle("label.report.excel.requestStatus"));
        cell16.setCellStyle(cellStyle);
        if(turnRequestFilter.getStatus()!=null){
            cell17.setCellValue(getMessageBundle(turnRequestFilter.getStatus().toString()));
        }else{
            cell17.setCellValue("");
        }

        cell18.setCellValue(getMessageBundle("label.report.excel.portDestination"));
        cell18.setCellStyle(cellStyle);
        if(turnRequestFilter.getSuggestedPort()!=null){
            cell19.setCellValue(turnRequestFilter.getSuggestedPort().getStorageLocationDescription());
        }else{
            cell19.setCellValue("");
        }

        cell20.setCellValue(getMessageBundle("label.report.excel.contractNumber"));
        cell20.setCellStyle(cellStyle);
        cell21.setCellValue(turnRequestFilter.getContractNumber());

        if (!isPosUser()) {
            cell22.setCellValue(getMessageBundle("label.report.result.laTijereta"));
            cell22.setCellStyle(cellStyle);
            if (turnRequestFilter.getLaTijereta() != null) {
                cell23.setCellValue(getMessageBundle(turnRequestFilter.getLaTijeretaDescription()));
            } else {
                cell23.setCellValue("");
            }
        }

    }

    private void createHeaderFirstRow(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        sheet.shiftRows(0,sheet.getLastRowNum(), HEADER_OFFSET-1);
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell0 = row.createCell(POS_HEADER_INDEX);
        HSSFCell cell1 = row.createCell(POS_VALUE_HEADER_INDEX);
        HSSFCell cell2 = row.createCell(ID_HEADER_INDEX);
        HSSFCell cell3 = row.createCell(ID_VALUE_HEADER_INDEX);
        HSSFCell cell4 = row.createCell(CROP_HEADER_INDEX);
        HSSFCell cell5 = row.createCell(CROP_VALUE_HEADER_INDEX);
        HSSFCell cell6 = row.createCell(GROWER_HEADER_INDEX);
        HSSFCell cell7 = row.createCell(GROWER_VALUE_HEADER_INDEX);


        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell0.setCellValue(getMessageBundle("label.report.excel.POS"));
        cell0.setCellStyle(cellStyle);
        if(turnRequestFilter.getUserPOSDTO()!=null){
            cell1.setCellValue(turnRequestFilter.getUserPOSDescription());
        }else{
            cell1.setCellValue("");
        }

        cell2.setCellValue(getMessageBundle("label.report.excel.turnRequestId"));
        cell2.setCellStyle(cellStyle);
        if(turnRequestFilter.getId()!=null){
            cell3.setCellValue(turnRequestFilter.getId());
        }else{
            cell3.setCellValue("");
        }

        cell4.setCellValue(getMessageBundle("label.report.excel.crop"));
        cell4.setCellStyle(cellStyle);
        if(turnRequestFilter.getCropType()!=null){
            cell5.setCellValue(turnRequestFilter.getCropType().getCommercialText());
        }else{
            cell5.setCellValue("");
        }

        cell6.setCellValue(getMessageBundle("label.report.excel.grower"));
        cell6.setCellStyle(cellStyle);
        cell7.setCellValue(turnRequestFilter.getGrower());


    }


    private void createHeaderSecondRow(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFRow row2 = sheet.createRow(1);
        HSSFCell cell8 = row2.createCell(REQUEST_DATE_FROM_HEADER_INDEX);
        HSSFCell cell9 = row2.createCell(REQUEST_DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell10 = row2.createCell(REQUEST_DATE_TO_HEADER_INDEX);
        HSSFCell cell11 = row2.createCell(REQUEST_DATE_TO_VALUE_HEADER_INDEX);
        HSSFCell cell12 = row2.createCell(TURN_DATE_FROM_HEADER_INDEX);
        HSSFCell cell13 = row2.createCell(TURN_DATE_FROM_VALUE_HEADER_INDEX);
        HSSFCell cell14 = row2.createCell(TURN_DATE_TO_HEADER_INDEX);
        HSSFCell cell15 = row2.createCell(TURN_DATE_TO_VALUE_HEADER_INDEX);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        cell8.setCellValue(getMessageBundle("label.report.excel.dateFrom"));
        cell8.setCellStyle(cellStyle);
        if(turnRequestFilter.getCreationDateFrom()!=null){
            cell9.setCellValue(sdf.format(turnRequestFilter.getCreationDateFrom()));
        }else{
            cell9.setCellValue("");
        }

        cell10.setCellValue(getMessageBundle("label.report.excel.dateTo"));
        cell10.setCellStyle(cellStyle);
        if(turnRequestFilter.getCreationDateTo()!=null){
            cell11.setCellValue(sdf.format(turnRequestFilter.getCreationDateTo()));
        }else{
            cell11.setCellValue("");
        }

        cell12.setCellValue(getMessageBundle("label.report.excel.turnDateFrom"));
        cell12.setCellStyle(cellStyle);
        if(turnRequestFilter.getTurnRequestDateFrom()!=null){
            cell13.setCellValue(sdf.format(turnRequestFilter.getTurnRequestDateFrom()));
        }else{
            cell13.setCellValue("");
        }

        cell14.setCellValue(getMessageBundle("label.report.excel.turnDateTo"));
        cell14.setCellStyle(cellStyle);
        if(turnRequestFilter.getTurnRequestDateTo()!=null){
            cell15.setCellValue(sdf.format(turnRequestFilter.getTurnRequestDateTo()));
        }else{
            cell15.setCellValue("");
        }
    }


    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET-1);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    HSSFCellStyle cellStyle = wb.createCellStyle();
                    cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                    cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                    cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }


    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


    private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }

    public void selectedRow(){
        turnRequestId = searchResult.getRowData().getId();
    }

    public void cancelTurnRequest(){
        LOG.debug("Cancel Turn Request.");
        try {
            TransactionTemplate tx = getTransactionTemplate();
            tx.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus status) {
                    TurnRequest turnRequest = turnRequestService.get(turnRequestId);
                    turnRequest.setCancelReason(cancelReason);
                    turnRequestService.delete(turnRequest);
                }
            });
            addMessageNoError(getMessageBundle("label.input.turnRequest.delete.ok"));
            search();
        } catch (BarterException ex) {
            LOG.error("An error occurred canceling turn request: ", ex);
            addMessage(getMessageBundle("label.input.turnRequest.delete.error"));
            addMessage(ex);
        }
    }


    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public void handlePointOfSaleSelect(SelectEvent event) {
        turnRequestFilter.setUserPOSDTO((PointOfSaleDTO) event.getObject());
    }

    public List<PointOfSaleDTO> pointOfSaleAutocomplete(String query) {
        return pointOfSaleService.search(query);
    }

    public boolean isPosUser() {
        return posUser;
    }

    public void setPosUser(boolean posUser) {
        this.posUser = posUser;
    }

    public List<PointOfSale> getPosBranches() {
        return posBranches;
    }

    public void setPosBranches(List<PointOfSale> posBranches) {
        this.posBranches = posBranches;
    }

    public boolean isParentPos() {
        return parentPos;
    }

    public void setParentPos(boolean parentPos) {
        this.parentPos = parentPos;
    }
}
