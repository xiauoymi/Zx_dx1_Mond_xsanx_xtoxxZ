package com.monsanto.barter.ar.web.faces.beans.turnRequest.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TurnRequestFilter;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.dto.TurnRequestReportDTO;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 15/10/14
 * Time: 10:39
 * To change this template use File | Settings | File Templates.
 */
public class TurnRequestReportDataModel extends AbstractDataModel<TurnRequestReportDTO,TurnRequestFilter> {

    private TurnRequestService service;

    public TurnRequestReportDataModel(TurnRequestService service, TurnRequestFilter filter) {
        super(filter);
        this.service = service;
    }

    @Override
    protected Recordset<TurnRequestReportDTO> loadPage(TurnRequestFilter filter, Paging paging) {
        return service.searchForExport(filter, paging);
    }

    @Override
    public Object getRowKey(TurnRequestReportDTO object) {
        return object.getId().toString();
    }
}
