package com.monsanto.barter.ar.web.faces.beans.user;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;

public class InactiveUserException extends BusinessException {
    public InactiveUserException(String msg) {
        super(msg);
    }

    public InactiveUserException(String msg, Exception e) {
        super(msg,e);
    }
}
