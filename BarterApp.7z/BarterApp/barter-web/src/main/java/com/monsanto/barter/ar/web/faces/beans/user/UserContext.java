package com.monsanto.barter.ar.web.faces.beans.user;

import com.monsanto.barter.ar.business.entity.GlobalBarterProfile;
import com.monsanto.barter.ar.business.entity.SecUser;
import com.monsanto.barter.ar.business.entity.decorator.AuthenticatedUser;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface UserContext extends SecUser, AuthenticatedUser, Authentication {

    List<GlobalBarterProfile> getAllProfileForContext();

    List<String> getCustomerDocumentsFromContextContracts();

    void setGrantAudit(String grant);

    String getGrantAudit();

    void buildPermissions();
}