package com.monsanto.barter.ar.web.faces.beans.user;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;

public class UserNotFoundException extends BusinessException {
    public UserNotFoundException(String msg) {
        super(msg);
    }

    public UserNotFoundException(String msg, Exception e) {
        super(msg,e);
    }
}
