package com.monsanto.barter.ar.web.faces.beans.user;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.groups.security.Login;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.GlobalBarterInterventorCompany;
import com.monsanto.barter.ar.business.entity.GlobalBarterUser;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.ParticipantType;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.entity.enumerated.UserTypeEnum;
import com.monsanto.barter.ar.business.filter.GlobalBarterUserFilter;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.SecUserDTO;
import com.monsanto.barter.ar.business.service.dto.UserDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import com.monsanto.wam.ws.exception.WamHandlerException;
import com.monsanto.wam.ws.service.WamUserService;
import com.monsanto.wam.ws.service.beans.ExistingWamUser;
import com.monsanto.wam.ws.service.beans.WamUser;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.validation.groups.Default;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class UserRegistrationFacesBean extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(UserRegistrationFacesBean.class);
    public static final String TRUE = "TRUE";
    public static final String FALSE = "FALSE";

    private CustomerCC grower;

    private CustomerLasService customerLasService;

    private WamUserService wamUserService;

    private DataModel<SecUserDTO> users = new ListDataModel<SecUserDTO>();
    private Integer status;
    private String login;
    private String loginForEdit;

    private String document;

    private GlobalBarterUserService userServices;
    private GlobalBarterProfileService profileService;
    private GlobalBarterInterventorCompanyService interventorCompanyService;
    private PointOfSaleService pointOfSaleService;
    private CountryHolder countryHolder;
    private UserDTO userManaged;
    private UserDecorator user;
    private Mode mode;
    private List<GlobalBarterInterventorCompany> interventorsCompanies;

    private PointOfSaleDTO pointOfSaleDTO;

    private String idGrower;

    public final String begin() {
        return doBegin();
    }

    private String doBegin() {
        userServices = getService(GlobalBarterUserService.class);
        profileService = getService(GlobalBarterProfileService.class);
        interventorCompanyService = getService(GlobalBarterInterventorCompanyService.class);
        pointOfSaleService = getService(PointOfSaleService.class);
        countryHolder = getService(CountryHolder.class);
        grower = getService(CustomerCC.class);
        customerLasService = getService(CustomerLasService.class);
        wamUserService = getService(WamUserService.class);
        clear();
        return SUCCESS;
    }

    public UserRegistrationFacesBean() {
        doBegin();
    }

    public String prependInsert() {
        setLoginForEdit(null);
        GlobalBarterUser globalBarterUser = new GlobalBarterUser();
        globalBarterUser.setStatus(StatusEnum.INACTIVE);
        globalBarterUser.setType(UserTypeEnum.PARTICIPANT);
        user= new UserDecorator(globalBarterUser,globalBarterUser);
        interventorsCompanies =  interventorCompanyService.findAll();

        userManaged = new UserDTO(user, profileService.getAllActive(), interventorCompanyService,
                countryHolder.getCountry().getLocale());
        setMode(Mode.CREATE);
        return SUCCESS;
    }


    public String prependUpdateProfiles() {
        searchUserInfo();
        interventorsCompanies =  interventorCompanyService.findAll();
        setMode(Mode.UPDATE);
        return SUCCESS;
    }

    public String search() {
        GlobalBarterUserFilter userFilter = GlobalBarterUserFilter.getInstance();
        switch (status) {
            case 1:
                userFilter.add(StatusEnum.ACTIVE);
                break;
            case 0:
                userFilter.add(StatusEnum.INACTIVE);
                break;
            default: break;
        }
        userFilter.excludeUserType(UserTypeEnum.SUPER);
        UserDecorator loggedUser = getLoggedUser();
        if (loggedUser != null && !loggedUser.isSuper()){
            userFilter.addUserId(loggedUser.getPrimaryKey());
        }
        userFilter.addDocument(document);
        userFilter.addLogin(login);
        users = new ListDataModel<SecUserDTO>(userServices.getUserBy(userFilter));
        return SUCCESS;
    }

    public void searchUserInfo(){
        LOG.debug("searchUserInfo inicio");
        try {
            user = userServices.getUserBy(loginForEdit);
            if (user.getPointOfSale() != null){
                this.pointOfSaleDTO = new PointOfSaleDTO(user.getPointOfSale());
            }
            userManaged = new UserDTO(user, profileService.getAllActive(), interventorCompanyService,
                    countryHolder.getCountry().getLocale());
        } catch (UserNotFoundException e) {
            LOG.error("UserNotFoundException: {" + loginForEdit + "}", e);
            userManaged = null;
        }
    }

    public String save() {
        LOG.debug("user {}", user.getProfiles());
        try {
            userManaged.reconstructUserDecoratorAssociations();
            setPOSInformation();
            LOG.debug("user {}", user.getProfiles());
            GlobalBarterUser currentUser = user.getCurrentUser();
            clearCompanyExtraInfo(currentUser);
            if (!validate(currentUser)){
                return null;
            }
            saveOrUpdate(currentUser);
            //TODO: internationalize this
            addMessageNoError("Se ha actualizado correctamente el usuario.");
            clear();
        } catch (Exception e) {
            LOG.error("Unexpected error saving user", e);
            return null;
        }
        return SUCCESS;
    }

    public String reset() {
        try {
            GlobalBarterUser currentUser = user.getCurrentUser();
            wamUserService.sendTemplate(currentUser.getLogin(), "TemporaryPassword");
            //TODO: internationalize this
            addMessageNoError("Se ha registrado el pedido de reset del pass.");
            clear();
        } catch (Exception e) {
            LOG.error("Unexpected error resetting user password", e);
            return null;
        }
        return SUCCESS;
    }

    public String query() {
        try {
            GlobalBarterUser currentUser = user.getCurrentUser();
            wamUserService.queryUser(currentUser.getLogin());
            //TODO: internationalize this
            addMessageNoError("Se ha registrado el pedido de consulta del usuario.");
            clear();
        } catch (Exception e) {
            LOG.error("Unexpected error querying the user", e);
            return null;
        }
        return SUCCESS;
    }

    public String lock() {
        try {
            GlobalBarterUser currentUser = user.getCurrentUser();
            ExistingWamUser existingWamUser = new ExistingWamUser(currentUser.getLogin());
            existingWamUser.setLoginDisabled(TRUE);
            wamUserService.modifyUser(existingWamUser);
            //TODO: internationalize this
            addMessageNoError("Se ha registrado el pedido de bloqueo del usuario.");
            clear();
        } catch (Exception e) {
            LOG.error("Unexpected error locking user", e);
            return null;
        }
        return SUCCESS;
    }

    public String unlock() {
        try {
            GlobalBarterUser currentUser = user.getCurrentUser();
            ExistingWamUser existingWamUser = new ExistingWamUser(currentUser.getLogin());
            existingWamUser.setLoginDisabled(FALSE);
            existingWamUser.setLockedByIntruder(FALSE);
            wamUserService.modifyUser(existingWamUser);
            //TODO: internationalize this
            addMessageNoError("Se ha registrado el pedido de desbloqueo del usuario.");
            clear();
        } catch (Exception e) {
            LOG.error("Unexpected error unlocking user", e);
            return null;
        }
        return SUCCESS;
    }

    private void clearCompanyExtraInfo(GlobalBarterUser user) {
        ParticipantType participantType = user.getParticipantType();
        if (ParticipantType.POS.equals(participantType)){
            user.setInterventorCompany(null);
            user.getGrowers().clear();
        } else if (ParticipantType.AGENT.equals(participantType)){
            user.setPointOfSale(null);
            user.getGrowers().clear();
        } else if (ParticipantType.GROWER.equals(participantType)){
            user.setInterventorCompany(null);
            user.setPointOfSale(null);
        } else {
            user.setPointOfSale(null);
            user.setInterventorCompany(null);
            user.getGrowers().clear();
        }
    }

    private void setPOSInformation() {
        try{
            if (pointOfSaleDTO != null) {
                if (user.getPointOfSale() == null || !user.getPointOfSale().getId().equals(pointOfSaleDTO.getId()) ){
                    user.setPointOfSale(pointOfSaleService.get(pointOfSaleDTO.getId()));
                }
            }else{
                user.setPointOfSale(null);
            }
        }catch (BusinessException e){
            addMessage(getMessageBundle("label.load.pointOfSale.error"));
            LOG.error("Error al cargar punto de servicio",e);
        }
    }

    private void saveOrUpdate(GlobalBarterUser currentUser) throws WamHandlerException {
        if (currentUser.getPrimaryKey() != null){
            updateUserInWam(currentUser);
            userServices.update(currentUser);
        } else {
            WamUser wamUser = createWamUser(currentUser);
            String transactionNumber = wamUserService.createUser(wamUser);
            currentUser.setLogin(transactionNumber);
            if (validate(currentUser, Login.class)){
                userServices.save(currentUser);
            } else {
                throw new WamHandlerException("transaction number returned by WAM was null or empty", null);
            }
        }
    }

    private WamUser createWamUser(GlobalBarterUser currentUser) {
        return new WamUser(getFirstName(currentUser), getInitialSecondName(currentUser), currentUser.getLastName(),
                currentUser.getEmail());
    }

    private void updateUserInWam(GlobalBarterUser currentUser) throws WamHandlerException {

        if (haveWamPropertiesBeenModified(currentUser)){
            wamUserService.modifyUser(createExistingWamUser(currentUser));
        }
    }

    private ExistingWamUser createExistingWamUser(GlobalBarterUser currentUser) {
        ExistingWamUser existingWamUser = new ExistingWamUser(currentUser.getLogin());
        existingWamUser.setFirstName(currentUser.getName());
        existingWamUser.setLastName(currentUser.getLastName());
        existingWamUser.setEmail(currentUser.getEmail());
        return existingWamUser;
    }

    private boolean haveWamPropertiesBeenModified(GlobalBarterUser currentUser) {
        GlobalBarterUser oldUser = userServices.get(currentUser.getId());
        return !oldUser.getLastName().equals(currentUser.getLastName()) ||
                !oldUser.getName().equals(currentUser.getName()) ||
                !oldUser.getEmail().equals(currentUser.getEmail());
    }

    private String getInitialSecondName(GlobalBarterUser currentUser) {
        String[] split = currentUser.getName().split(" ");
        if (split.length > 1){
            return split[1].substring(0, 1);
        } else {
            return "";
        }
    }

    private String getFirstName(GlobalBarterUser currentUser) {
        return currentUser.getName().split(" ")[0];
    }

    private boolean validate(GlobalBarterUser currentUser, Class clazz) {
        LOG.debug("Validation on Edit");
        List<String> violationMessages = getValidator().validate(currentUser, clazz);
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    private boolean validate(GlobalBarterUser currentUser) {
        return validate(currentUser, Default.class);
    }

    //TODO: this should be done in the begin method
    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    private void clear() {
        status = -1;
        login = "";
        users = null;
        this.pointOfSaleDTO = null;
        mode = Mode.CREATE;
    }

    public String back() {
        clear();
        return SUCCESS;
    }

    public void handlePointOfSaleSelect(SelectEvent event) {
        pointOfSaleDTO = (PointOfSaleDTO) event.getObject();
    }

    public List<PointOfSaleDTO> pointOfSaleAutocomplete(String query) {
        return pointOfSaleService.search(query);
    }

    /**
     * @return the list
     */
    public DataModel<SecUserDTO> getUsers() {
        return users;
    }

    /**
     * @param list the list to set
     */
    public void setUsers(DataModel<SecUserDTO> list) {
        this.users = list;
    }

    /**
     * @return the status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login.toUpperCase();
    }

    /**
     * @return the document
     */
    public String getDocument() {
        return document;
    }

    /**
     * @param document the document to set
     */
    public void setDocument(String document) {
        this.document = document;
    }

    public UserDTO getUserManaged() {
        return userManaged;
    }

    /**
     * @param loginForEdit the loginForEdit to set
     */
    public void setLoginForEdit(String loginForEdit) {
        this.loginForEdit = loginForEdit;
    }

    /**
     * @return the loginForEdit
     */
    public String getLoginForEdit() {
        return loginForEdit;
    }

    public List<GlobalBarterInterventorCompany> getInterventorsCompanies() {
        return interventorsCompanies;
    }

    public void setInterventorsCompanies(List<GlobalBarterInterventorCompany> interventorsCompanies) {
        this.interventorsCompanies = interventorsCompanies;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public List<UserTypeEnum> getUserTypes(){
        return new ArrayList<UserTypeEnum>(
                Arrays.asList(UserTypeEnum.ADMINISTRATOR, UserTypeEnum.PARTICIPANT));
    }

    public List<ParticipantType> getParticipantTypes(){
        return new ArrayList<ParticipantType>(
                Arrays.asList(ParticipantType.values()));
    }

    public boolean getParticipantTypeSelected(){
        return userManaged.getUserType().equals(UserTypeEnum.PARTICIPANT);
    }

    public boolean getPosSelected(){
        return ParticipantType.POS.equals(userManaged.getParticipantType());
    }

    public boolean getAgentSelected(){
        return ParticipantType.AGENT.equals(userManaged.getParticipantType());
    }

    public boolean getGrowerSelected(){
        return ParticipantType.GROWER.equals(userManaged.getParticipantType());
    }

    public PointOfSaleDTO getPointOfSaleDTO() {
        return pointOfSaleDTO;
    }

    public void setPointOfSaleDTO(PointOfSaleDTO pointOfSaleDTO) {
        this.pointOfSaleDTO = pointOfSaleDTO;
    }

    public CustomerCC getGrower() {
        return grower;
    }

    public void setGrower(CustomerCC grower) {
        this.grower = grower;
    }

    public void addGrower() {
        CustomerLas customer = grower.getSelectedCustomer();
        if (customer != null){
            user.getCurrentUser().getGrowers().add(customer);
            grower.clearCustomer();
        }
    }

    public void removeGrower(){
        CustomerLas customerLas = customerLasService.get(getIdGrower());
        user.getCurrentUser().getGrowers().remove(customerLas);
    }

    public String getIdGrower() {
        return idGrower;
    }

    public void setIdGrower(String idGrower) {
        this.idGrower = idGrower;
    }

    public boolean getUpdate(){
        return Mode.UPDATE.equals(mode);
    }

    public boolean getCreate(){
        return Mode.CREATE.equals(mode);
    }

}
