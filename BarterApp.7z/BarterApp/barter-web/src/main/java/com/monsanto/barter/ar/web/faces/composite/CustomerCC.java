package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.validators.CuitUtil;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.dto.CustomerView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isBlank;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class CustomerCC extends ArBaseJSF {

    private static final Logger LOG = LoggerFactory.getLogger(CustomerCC.class);

    public static final int MINIMUM_PARAMETER_LENGTH = 5;
    public static final String DEFAULT_TAX_NUMBER_TYPE = "80";

    private CustomerView customer;
    private String documentNumber;
    private List<String> customerErrorMessages = new ArrayList<String>();

    private DataModel<CustomerView> customers;
    private String customerDescriptionPopup;
    private String customerDocumentPopup;
    private boolean required = false;
    private boolean forceSelection = false;
    private String taxNumberType = DEFAULT_TAX_NUMBER_TYPE ;

    @Autowired
    private CustomerLasService customerLasService;

    public CustomerCC(){
        this.customer = null;
        this.customers = new ListDataModel<CustomerView>();
        if (this.customer != null) {
            this.documentNumber = this.customer.getDocument();
        } else {
            this.documentNumber = null;
        }
    }

    public List<CustomerView> autocomplete(String query) {
        List<CustomerView> results =  customerLasService.search(query, taxNumberType);
        if (!forceSelection && CuitUtil.isValid(query) && results.isEmpty()) {
            //TODO: Internationalize this
            results.add(0, new CustomerView(query, "No se encontró la Razón Social"));
        }
        return results;
    }

    public void handleItemSelect(SelectEvent event) {
        CustomerView view = (CustomerView) event.getObject();
        this.customer = view;
        this.documentNumber = view.getDocument();
    }

    public void searchCustomer() {
        clear();
        boolean customerFound = false;
        try {
            this.setCustomer(customerLasService.getCustomer(documentNumber, taxNumberType));
            customerFound = true;
        } catch (BusinessException e) {
            LOG.info("Customer not found to document " + documentNumber, e);
            customerDocumentPopup = null;
            customerDescriptionPopup = null;
            customer = null;
            if (StringUtils.hasText(documentNumber)){
                customerDocumentPopup = documentNumber;
                customerDescriptionPopup = "";
                searchCustomerByDocumentAndDescription();
            }
        }
        addCallbackParam("customerFound", customerFound);
    }

    public void clearCustomer() {
        customer = null;
        documentNumber = null;
    }

    public void clear() {
        customerErrorMessages.clear();
        this.customers = new ListDataModel<CustomerView>();
        customerDocumentPopup = null;
        customerDescriptionPopup = null;
    }

    /**
     * Search customer by Document and description.
     */
    public void searchCustomerByDocumentAndDescription() {
        customerErrorMessages.clear();
        customers = new ListDataModel<CustomerView>();
        try {
            if (validateFields()) {
                List<CustomerView> customersBase = customerLasService.search(customerDocumentPopup, customerDescriptionPopup, taxNumberType);
                Collections.sort(customersBase, new Comparator<CustomerView>() {
                    @Override
                    public int compare(CustomerView o1, CustomerView o2) {
                        return (new CompareToBuilder())
                                .append(o1.getDescription(), o2.getDescription())
                                .append(o1.getDocument(), o2.getDocument()).toComparison();
                    }
                });
                setCustomers(new ListDataModel<CustomerView>(customersBase));
            }
        } catch (BusinessException ex) {
            addMessage(ex);
            LOG.error("An error occurred finding customers: ", ex);
        }
    }

    public String getCustomerDescription() {
        if (customer != null && customer.getDocument() != null && customer.getDescription() != null) {
            return this.getCustomer().getDescription();
        }
        return "";
    }

    public String getCustomerDocument() {
        getCustomerSelected();
        if(customer == null){
            if (isBlank(documentNumber)) {
                return null;
            } else {
                return documentNumber.trim();
            }
        }
        return null;
    }

    public void customerSelected() {
        customer = customers.getRowData();
        documentNumber = customer.getDocument();
        customerDescriptionPopup = null;
    }

    private boolean validateFields() {
        boolean valid = false;
        if (isBlank(customerDocumentPopup) && isBlank(customerDescriptionPopup)) {
            customerErrorMessages.add(getMessageBundle("ar.barter.customerCC.error.searchCriteria"));
        }else{
            if (customerDocumentPopup.length()>= MINIMUM_PARAMETER_LENGTH || getCustomerDescriptionPopup().length() >= MINIMUM_PARAMETER_LENGTH) {
                valid = true;
            }else{
                customerErrorMessages.add(getMessageBundle("ar.barter.customerCC.error.searchCriteria"));
            }
        }
        return valid;
    }

    public void setCustomer(String customer) {
        if (customer != null) {
            this.setCustomer(new CustomerView(customer, "No se encontró la Razón Social"));
        } else {
            this.setCustomer((CustomerView)null);
        }
    }

    public void setCustomer(CustomerLas customer) {
        if (customer != null) {
            this.setCustomer(new CustomerView(customer));
        } else {
            this.setCustomer((CustomerView)null);
        }
    }

    public void setCustomer(CustomerView customer) {
        this.customer = customer;
        if(customer != null){
            documentNumber = customer.getDocument();
        }
    }

    public CustomerView getCustomer() {
        return customer;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public List<String> getCustomerErrorMessages() {
        return customerErrorMessages;
    }

    public String getCustomerDescriptionPopup() {
        return customerDescriptionPopup;
    }

    public void setCustomerDescriptionPopup(String customerDescriptionPopup) {
        this.customerDescriptionPopup = customerDescriptionPopup;
    }

    public String getCustomerDocumentPopup() {
        return customerDocumentPopup;
    }

    public void setCustomerDocumentPopup(String customerDocumentPopup) {
        this.customerDocumentPopup = customerDocumentPopup;
    }

    public DataModel<CustomerView> getCustomers() {
        return customers;
    }

    public void setCustomers(DataModel<CustomerView> customers) {
        this.customers = customers;
    }

    private CustomerView getCustomerSelected() {
        if (isBlank(documentNumber)) {
            this.customer = null;
        } else {
            if (this.customer == null || !this.customer.getDocument().equals(documentNumber)) {
                try {
                    setCustomer(customerLasService.getCustomer(this.documentNumber, taxNumberType));
                } catch (BusinessException ex) {
                    LOG.error("An error occurred finding customers: ", ex);
                    this.customer = null;
                }
            }
        }
        return this.customer;
    }

    public boolean isRequired() {
        return this.required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isForceSelection() {
        return forceSelection;
    }

    public void setForceSelection(boolean forceSelection) {
        this.forceSelection = forceSelection;
    }

    public CustomerLas getSelectedCustomer() {
        CustomerView customerView = this.getCustomerSelected();
        if (customerView != null && customerView.getId() != null) {
            return customerLasService.get(customerView.getId());
        }
        return null;
    }

    public String getSelectedCustomerIdentifier() {
        CustomerView customerView = this.getCustomerSelected();
        if (customerView != null) {
            return customerView.getDocument();
        }
        return null;
    }

    public String getTaxNumberType() {
        return taxNumberType;
    }

    public void setTaxNumberType(String taxNumberType) {
        this.taxNumberType = taxNumberType;
    }
}
