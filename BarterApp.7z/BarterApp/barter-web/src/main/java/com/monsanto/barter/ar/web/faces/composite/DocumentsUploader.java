package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.business.entity.Attachment;
import com.monsanto.barter.ar.business.entity.BaseEntity;
import com.monsanto.barter.ar.business.entity.BaseEntityHelper;
import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.DocumentUploadService;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;

import org.apache.commons.collections.CollectionUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class DocumentsUploader <T extends BaseEntity> extends FileUploadCC{

    public static final String ERROR_UPLOAD_DOCUMENT_EXIST = "ar.barter.attachfiledialog.error.uploadDocumentType.exist";
    public static final String INVALID_SIZE_ERROR = "ar.barter.fileUploadCC.invalidSize.error";
    public static final String ATTACHMENT_NOT_EQUALS = "com.monsanto.barter.ar.business.entity.Attachment.notEquals";

    private List<Attachment> attachments;
    private List<String> messagesError;
    private String documentNumber ="";
    private DocumentType documentType=null;
    private DocumentUploadService<T> documentUploadService;
    private BeanValidator<Attachment> attachmentBeanValidator;
    private T entity;
    private StreamedContent fileToDownload;
    private String parentDocumentNumber;
    private DocumentType parentDocumentType;
    private Long maxFileSize;
    private final Logger LOG = LoggerFactory.getLogger(DocumentsUploader.class);

    public void init(DocumentUploadService<T> documentUploadService,  BeanValidator<Attachment> attachmentBeanValidator ,  T entity ) {
        setDocumentNumber(null);
        setDocumentType(null);
        setAttachments(new ArrayList<Attachment>());
        setMessagesError(new ArrayList<String>());
        this.documentUploadService= documentUploadService;
        this.attachmentBeanValidator = attachmentBeanValidator;
        this.entity = entity;
    }

    public void uploadFile(ActionEvent event){
        File file = getFile();
        Attachment attachment =  new Attachment(file, getDocumentNumber(), getDocumentType());
        setParentDocumentType((String)event.getComponent().getAttributes().get("parentDocumentType"));
        setMaxFileSize((Long) event.getComponent().getAttributes().get("maxFileSize"));
        setParentDocumentNumber((String)event.getComponent().getAttributes().get("parentDocumentNumber"));
        if(isValidAttachment(attachment)) {
            BaseEntityHelper.loadCreationFields(attachment);
            BaseEntityHelper.loadCreationFields(file);
            attachments.add(attachment);
            setDocumentNumber(null);
            setDocumentType(null);
            super.clear();
        }
    }

    public void removeFile(ActionEvent event){
        Attachment attachment = (Attachment)event.getComponent().getAttributes().get("attachment");
        LOG.debug("Remove ({}) successfully!", attachment.getFileName());
        attachments.remove(attachment);
    }

    public DocumentType[] getUploadDocumentTypes() {
        return DocumentType.values();
    }

    protected boolean isValidAttachment(Attachment attachment){
        setMessagesError(attachmentBeanValidator.validate(attachment));
        if(messagesError.isEmpty()){
            if(findAttachmentIntoAttachment(attachment)!=null ){
                messagesError.add(getMessageBundle(ERROR_UPLOAD_DOCUMENT_EXIST));
                LOG.debug("Duplicated ({}) on List Attachments!", attachment.getFileName());
            }else{
                if(documentUploadService.checkDocumentExistence(entity,attachment)){
                    messagesError.add(getMessageBundle(ERROR_UPLOAD_DOCUMENT_EXIST));
                    LOG.debug("Duplicated ({}) on DB!", attachment.getFileName());
                }
            }
            fileSizeIsValid(attachment);
            isEqualDocumentNumber(attachment);
        }
        return messagesError.isEmpty();
    }

    private String getMessageBundle(String key){
        return  attachmentBeanValidator.getMessageBundle(key);
    }

    private boolean fileSizeIsValid(Attachment attachment) {
        long length = attachment.getFileSize();
        boolean valid = true;

        if (length > getMaxFileSize()) {
            valid = false;
            clear();
            messagesError.add(getMessageBundle(INVALID_SIZE_ERROR));
            LOG.debug("File({}) {}: exceeded max-size {}!", attachment.getFileName(), attachment.getFileSize());
        }
        return valid;
    }

    private boolean isEqualDocumentNumber(Attachment attachment){
        boolean valid = true;
        if(parentDocumentNumber !=null && !parentDocumentNumber.trim().isEmpty() &&
                attachment.getDocumentType().equals(parentDocumentType) &&
                !attachment.getDocumentNumber().equals(getParentDocumentNumber().trim())){
            valid= false;
            messagesError.add(getMessageBundle(ATTACHMENT_NOT_EQUALS) + " "+getMessageBundle(getParentDocumentType()));
            LOG.debug("File({}) : not equal document number of  {}!", attachment.getFileName(), parentDocumentType.getDescription());
        }
       return valid;
    }

    public void downloadFile(ActionEvent event) {
        Attachment attachment = (Attachment)event.getComponent().getAttributes().get("attachment");
        LOG.debug("START download File : {}", attachment.getDocumentNumber());
        try {
            InputStream stream = new ByteArrayInputStream(attachment.getFileContent());
            fileToDownload = new DefaultStreamedContent(stream, attachment.getMimeType(),attachment.getFileName());
        } catch (Exception e) {
            LOG.error("An error occurred downloading an attachment: " + attachment.getFileName(), e);
            throw new AbortProcessingException(e);
        }
    }

    private Attachment findAttachmentIntoAttachment(Attachment attachment){
        Attachment result = null;
        for(Attachment attach: attachments){
            if(attach.getDocumentNumber().equals(attachment.getDocumentNumber())&& attach.getDocumentType().equals(attachment.getDocumentType())){
                result= attach;
                break;
            }
        }
        return result;
    }

    public void leave() {
        super.clear();
        this.attachments = new ArrayList<Attachment>();
        this.messagesError = new ArrayList<String>();
        this.documentUploadService= null;
        this.attachmentBeanValidator = null;
        this.entity = null;
        setDocumentNumber(null);
        setDocumentType(null);
    }
    public StreamedContent  getFileToDownload() {
        return fileToDownload;
    }

    public boolean isEmptyErrors(){
        return  CollectionUtils.isEmpty(messagesError);
    }
    public boolean isEmptyFiles(){
        return  CollectionUtils.isEmpty(attachments);
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    public List<String> getMessagesError() {
        return messagesError;
    }

    public void setMessagesError(List<String> messagesError) {
        this.messagesError = messagesError;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public DocumentType getDocumentType() {
        return documentType;
    }

    public void setDocumentType(DocumentType documentType) {
        this.documentType = documentType;
    }

    public String getParentDocumentNumber() {
        return parentDocumentNumber;
    }

    public void setParentDocumentNumber(String parentDocumentNumber) {
        this.parentDocumentNumber = parentDocumentNumber;
    }

    public String getParentDocumentType() {
        return parentDocumentType.getDescription();
    }

    public void setParentDocumentType(String parentDocumentType) {
        this.parentDocumentType = DocumentType.valueOf(parentDocumentType);
    }

    public Long getMaxFileSize() {
        return maxFileSize;
    }

    public void setMaxFileSize(Long maxFileSize) {
        this.maxFileSize = maxFileSize;
    }
}
