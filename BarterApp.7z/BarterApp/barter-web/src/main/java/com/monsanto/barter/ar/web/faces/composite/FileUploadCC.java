package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.business.entity.File;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class  FileUploadCC {
    private final Logger LOG = LoggerFactory.getLogger(FileUploadCC.class);

    private File file;

    public void handleFileUpload(FileUploadEvent event) {
        UploadedFile uploadedFile = event.getFile();
        file = new File(uploadedFile.getFileName(), uploadedFile.getContentType(), uploadedFile.getSize(),
                uploadedFile.getContents());
        LOG.debug("Uploaded ({}) successfully!", getFileName());
    }

    public void clear() {
        this.file = null;
    }

    public File getFile() {
        return file;
    }

    public String getFileName(){
        if (getFile() != null) {
            String fileName = getFile().getFileName();
            if (fileName.contains("\\")) {
                return fileName.substring(fileName.lastIndexOf('\\') + 1);
            } else {
                return fileName;
            }
        }

        return "";
    }
}
