package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.business.entity.CityAfipLas;
import com.monsanto.barter.ar.business.service.CityAfipLasService;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import java.util.*;

import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNumeric;

/**
 * @author JPBENI
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class LocationCC extends ArBaseJSF {

    private final Logger log = LoggerFactory.getLogger(LocationCC.class);

    public static final int MINIMUM_PARAMETER_LENGTH = 4;

    @Autowired
    private CityAfipLasService service;
    private List<String> locationErrorMessages = new ArrayList<String>();

    private CityAfipLas city;
    private DataModel<CityAfipLas> cities;

    private String cityDescription;
    private String provinceDescription;

    public LocationCC() {
        this.cities= new ListDataModel<CityAfipLas>();
    }

    public List<CityAfipLas> autocomplete (final String query) {
        List<CityAfipLas> results = new LinkedList<CityAfipLas>();
        if(isNumeric(query.trim())) {
            results.add(service.get(Long.valueOf(query.trim()).toString()));
        } else {
            final String[] split = query.split(",");
            String cityQuery = split[0].trim();
            String provinceQuery = null;
            if (split.length > 1) {
                provinceQuery = split[1].trim();
            }
            results.addAll(service.findCities(cityQuery, provinceQuery));
        }
        return results;
    }

    public void handleItemSelect(SelectEvent event) {
        this.city = (CityAfipLas) event.getObject();
    }

    public void clear() {
        city = null;
        cityDescription=null;
        provinceDescription=null;
        this.cities= new ListDataModel<CityAfipLas>();
    }

    public void search() {
        try {
            locationErrorMessages.clear();
            if (validateFields()){
                List<CityAfipLas> results = service.findCities(cityDescription, provinceDescription);
                Collections.sort(results, new Comparator<CityAfipLas>(){
                    @Override
                    public int compare(CityAfipLas o1, CityAfipLas o2) {
                        return (new CompareToBuilder()).append(o1.getDescription(), o2.getDescription())
                                .toComparison();
                    }
                });
                cities = new ListDataModel<CityAfipLas>(results);
            }
        } catch (BusinessException ex) {
            addMessage(ex);
            log.error("An error occurred finding locations: ", ex);
        }
   }

    private boolean validateFields() {
        if(isBlank(cityDescription) || cityDescription.length() <= MINIMUM_PARAMETER_LENGTH) {
            locationErrorMessages.add(getMessageBundle("ar.barter.locationCC.error.searchCriteria"));
            return false;
        }
        return true;
    }

    public void findOne() {
        locationErrorMessages.clear();
        provinceDescription = null;
        this.cities= new ListDataModel<CityAfipLas>();

        if(!cityDescription.isEmpty()){
            this.search();
            if(cities.getRowCount() == 1) {
                this.city = cities.getRowData();
                this.cityDescription=city.getDescription();
                addCallbackParam("cityFound", true);
            }
        }
    }

    public void locationSelected() {
        city = cities.getRowData();
        cityDescription = city.getDescription();
    }

    public void setCountyDescription(String countyDescription) {}

    public void setProvinceDescription(String provinceDescription) {
        this.provinceDescription = provinceDescription;
    }

    public String getCityDescription() {
        return this.cityDescription;
    }

    public String getCountyDescription() {
        if (city == null) {
            return "";
        } else {
            return city.getCountyAfipLas().getDescription();
        }
    }

    public String getProvinceDescription() {
        return provinceDescription;
    }

    public CityAfipLas getCity() {
        return city;
    }

    public void setCity(CityAfipLas city) {
        this.city = city;
        if(city!=null){
            this.cityDescription = city.getDescription();
        }
    }

    public List<String> getLocationErrorMessages() {
        return locationErrorMessages;
    }

    public void setCityDescription(String cityDescription) {
        this.cityDescription = cityDescription;
    }

    public DataModel<CityAfipLas> getCities() {
        return cities;
    }

    public void setCities(DataModel<CityAfipLas> cities) {
        this.cities = cities;
    }

    public CityAfipLas getCitySelected() {
        if (cityDescription != null && !cityDescription.isEmpty() && this.city == null) {
            findOne();
        }
        return this.city;
    }
}
