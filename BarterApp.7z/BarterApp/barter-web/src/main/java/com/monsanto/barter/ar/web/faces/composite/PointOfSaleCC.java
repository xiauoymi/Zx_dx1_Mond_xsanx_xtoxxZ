package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.PointOfSaleService;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by VNBARR on 9/8/2014.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class PointOfSaleCC extends ArBaseJSF {

    private PointOfSale pointOfSale = new PointOfSale();
    private PointOfSale parentPointOfSale;
    @Autowired
    private PointOfSaleService pointOfSaleService;
    @Autowired
    private BeanValidator<PointOfSale> beanValidator;
    private List<String> errors;
    private static final Logger LOG = LoggerFactory.getLogger(PointOfSaleCC.class);

    private CustomerCC customerCC;
    private Mode mode;

    public PointOfSaleCC() {
        //by default
        init(Mode.UPDATE);
    }

    public final void init(Mode mode) {
        customerCC = getService(CustomerCC.class);
        this.mode = mode;
        clear();
    }

    public void preSave() {
        setComponents();
        addCallbackParam("isValid", isValid());
    }

    private void loadComponents(PointOfSale pointOfSale) {
        this.pointOfSale = pointOfSale;
        this.parentPointOfSale = pointOfSale.getParentPointOfSale();
        customerCC.setCustomer(pointOfSale.getCustomer());
    }

    private void setComponents() {
        if (this.customerCC != null){
            this.pointOfSale.setCustomer(customerCC.getSelectedCustomer());
        }
        this.pointOfSale.setParentPointOfSale(parentPointOfSale);
    }

    private boolean isValid() {
        LOG.debug("VALIDATION  - Class:{} ", this.getClass().getName() );
        List<String> violationMessages = beanValidator.validate(pointOfSale);
        if (!violationMessages.isEmpty()) {
            errors = violationMessages;
            return false;
        }
        return true;
    }

    public void newPointOfSale(){
        init(Mode.CREATE);
    }

    public void editPointOfSale(PointOfSale pointOfSale){
        init(Mode.UPDATE);
        loadComponents(pointOfSale);
    }

    public void viewPointOfSale(PointOfSale pointOfSale){
        init(Mode.VIEW);
        loadComponents(pointOfSale);
    }

    public boolean isReadOnly(){
        return this.mode.isReadOnly();
    }


    public void cancel(){
        clear();
    }

    public final void clear() {
        this.errors = null;
        this.pointOfSale = new PointOfSale();
        this.customerCC.clear();
    }

    public void save(){
        try{
            if(pointOfSale.getId()!=null){
                LOG.debug("Update branch point of sale: {} ",pointOfSale.getId());
                pointOfSaleService.update(pointOfSale);
                addMessageNoError(getMessageBundle("label.input.pointOfSale.update.ok") + pointOfSale.getCustomer().getDescription());
            }else{
                LOG.debug("Save new branch point of sale");
                pointOfSaleService.save(pointOfSale);
                addMessageNoError(getMessageBundle("label.input.pointOfSale.creation.ok") + pointOfSale.getCustomer().getDescription());
            }
            addCallbackParam("saved",true);
        }catch (BusinessException be){
            LOG.error(getMessageBundle("label.input.pointOfSale.creation.error") ,be);
            errors = new ArrayList<String>();
            errors.add(getMessageBundle("label.input.pointOfSale.creation.error") + pointOfSale.getCustomer().getDescription() ) ;
            addCallbackParam("saved", false);
        }

    }

    public PointOfSale getPointOfSale() {
        return pointOfSale;
    }

    public void setPointOfSale(PointOfSale pointOfSale) {
        this.pointOfSale = pointOfSale;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public boolean isActivePOS() {
        return pointOfSale.getStatus().equals(StatusEnum.ACTIVE);
    }

    public void setActivePOS(boolean checked) {
        if (checked) {
            pointOfSale.setStatus(StatusEnum.ACTIVE);
        } else {
            pointOfSale.setStatus(StatusEnum.INACTIVE);
        }
    }

    public CustomerCC getCustomerCC() {
        return customerCC;
    }

    public void setCustomerCC(CustomerCC customerCC) {
        this.customerCC = customerCC;
    }

    public PointOfSale getParentPointOfSale() {
        return parentPointOfSale;
    }

    public void setParentPointOfSale(PointOfSale parentPointOfSale) {
        this.parentPointOfSale = parentPointOfSale;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public String getCustomerCity(){
        if (this.customerCC != null){
            CustomerLas selectedCustomer = this.customerCC.getSelectedCustomer();
            if (selectedCustomer != null){
                return selectedCustomer.getCity();
            }
        }
        return "";
    }
}
