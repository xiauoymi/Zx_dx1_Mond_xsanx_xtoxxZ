package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.TurnAddressee;
import com.monsanto.barter.ar.business.service.TurnAddresseeService;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class TurnAddresseeCC extends ArBaseJSF {

    private boolean addresseeNameEnabled;

    @Autowired
    private CustomerCC customerAddresseeCC;
    @Autowired
    private BeanValidator <TurnAddressee> validator;
    @Autowired
    private TurnAddresseeService turnAddresseeService;

    private static final Logger LOG = LoggerFactory.getLogger(TurnAddresseeCC.class);

    private String addresseeName;
    private String addresseeCuit;
    private TurnAddressee turnAddressee;
    private boolean turnsAddRendered;
    private Mode mode=Mode.CREATE;

    public String getAddresseeName() {
        return addresseeName;
    }

    public void setAddresseeName(String addresseeName) {
        this.addresseeName = addresseeName;
    }

    public boolean isAddresseeNameEnabled() {
        return addresseeNameEnabled;
    }


    public CustomerCC getCustomerAddresseeCC() {
        return customerAddresseeCC;
    }

    public void setCustomerAddresseeCC(CustomerCC customerAddresseeCC) {
        this.customerAddresseeCC = customerAddresseeCC;
    }

    public TurnAddresseeCC(){
        turnAddressee = new TurnAddressee();
    }

    public void clear() {
        customerAddresseeCC.clear();
        customerAddresseeCC.clearCustomer();
        addresseeName = null;
        addresseeNameEnabled = false;
        addresseeCuit = null;
        turnAddressee = new TurnAddressee();
        turnsAddRendered = false;
        mode=Mode.CREATE;
    }

    public void preSave(){
        boolean validForSave =  true;
        turnAddressee.setCustomerAddressee(customerAddresseeCC.getSelectedCustomer());
        LOG.debug("Pre Saving an addresse");
        if(turnAddressee.getCustomerAddressee()!=null){
            turnAddressee.setAddresseeName(null);
            turnAddressee.setAddresseeCuit(null);
            LOG.debug("Addressee  is a customerLAS");
        }else{
            turnAddressee.setAddresseeName(addresseeName);
            turnAddressee.setAddresseeCuit(addresseeCuit);
            LOG.debug("Addressee  not exist in customerLAS ");
        }
        List<String> violationMessages = validator.validate(turnAddressee);
        if (!violationMessages.isEmpty()) {
            LOG.debug("Addressee  not not valid for Save ");
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            validForSave = false;
        }
        addCallbackParam("validForSave", validForSave);
    }

    public void save(){
        try {
            if(turnAddressee.getPrimaryKey()!=null){
                turnAddresseeService.update(turnAddressee);
                addMessageNoError(getMessageBundle("label.input.turnAddressee.updated"));
            }else{
                turnAddresseeService.save(turnAddressee);
                addMessageNoError(getMessageBundle("label.input.turnAddressee.created"));
            }
            LOG.debug("Addressee was saved");
            clear();
        }catch (BusinessException ex){
            LOG.error("An error occurred saving an addressee: ", ex);
            addMessage(getMessageBundle("label.input.turnAddressee.creation.error"));
        }
    }

    public void close(){
        turnsAddRendered = false;
        clear();
    }

    public void handleDestinationSelect(){
        addresseeName = null;
        addresseeCuit = customerAddresseeCC.getDocumentNumber();
        addresseeNameEnabled =(customerAddresseeCC.getSelectedCustomer()==null);
    }

    public void handleDestinationClear(){
        addresseeNameEnabled = false;
        addresseeName = null;
    }

    public void loadForUpdate(TurnAddressee addresseeToEdit){
        clear();
        if(addresseeToEdit!= null){
            this.turnAddressee = addresseeToEdit;
            addresseeName = addresseeToEdit.getAddresseeName();
            addresseeCuit = addresseeToEdit.getAddresseeCuit();
            customerAddresseeCC.setCustomer(addresseeToEdit.getAddresseeCuit());
            addresseeNameEnabled =(addresseeToEdit.getCustomerAddressee()==null);
            turnsAddRendered = true;
            mode=Mode.UPDATE;
        }
    }

    public boolean isTurnsAddRendered() {
        return turnsAddRendered;
    }

    public void createNew(){
        clear();
        turnsAddRendered = true;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }
}
