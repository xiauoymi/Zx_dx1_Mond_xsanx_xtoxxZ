package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.business.entity.Terminal;
import com.monsanto.barter.ar.business.entity.Turn;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.TerminalService;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TerminalDTO;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.primefaces.event.RowEditEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.apache.commons.lang.StringUtils.isBlank;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class TurnsAdd extends ArBaseJSF{
    public static final String CODE_SEPARATOR = "/";
    public static final int MIN_EXPORTER_DESCRIPTION_SIZE = 3;
    public static final int MAX_TURNS_QUANTITY = 999;
    private final Logger log = LoggerFactory.getLogger(TurnsAdd.class);

    private Date turnsDate;
    private Integer quantity;
    private Boolean autogenerate;
    private String turnsDetail;
    private List<Turn> turnsList;
    private ContractView contract;
    private String editedTurnId;
    private List<String> turnsErrorMessages = new ArrayList<String>();
    private List<TerminalDTO> terminals = new ArrayList<TerminalDTO>();
    private String destinationDescription;
    private String addresseeDescription;
    private Long terminalId;
    private Terminal destination;

    public static final String TURN_REQUIRED_MESSAGE_KEY="label.edit.turn.required.code";

    @Autowired
    private TurnService turnService;

    @Autowired
    private ContractService contractService;

    @Autowired
    private TerminalService terminalService;

    private String individualTurnCode;
    private boolean editableTurnsDate = true;
    private Turn previousTurn;
    private boolean showTurnList = false;

    public TurnsAdd(){
        turnsList = new ArrayList<Turn>();
        turnsErrorMessages = new ArrayList<String>();
    }

    public void init(){
        terminals = contractService.findTerminalsByContractId(contract.getContractId());
    }

    public boolean validateNewTurns(){
        boolean back = true;
        turnsErrorMessages.clear();

        if(turnsDate==null) {
            turnsErrorMessages.add(getMessageBundle("ar.barter.turnsAdd.error.date"));
        }


        if (terminalId==null){
            turnsErrorMessages.add(getMessageBundle("ar.barter.turnsAdd.error.destination"));
        }

        boolean quantityError = false;
        if(quantity == 0) {
            quantityError = true;
        }else{
            if(turnsErrorMessages.isEmpty()) {
                convertTextToTurnList();
                if (quantity!=turnsList.size()){
                    quantityError = true;
                }
                else{
                    updateTurnListVisibility();
                }
            }
        }

        if (quantityError){
            turnsErrorMessages.add(getMessageBundle("ar.barter.turnsAdd.error.turnsQuantity"));
        }

        if(!turnsErrorMessages.isEmpty()) {
            back = false;
            turnsList.clear();
        }
        return back;
    }

    public void convertTextToTurnList(){
        log.debug("Converting textarea to turns...");

        if (terminals.isEmpty()) {
            terminals = contractService.findTerminalsByContractId(contract.getContractId());
        }
        destination = terminalService.get(terminalId);

        if(autogenerate) {
            autoGenerateTurnList();
        } else {
            StringTokenizer stringTokenizer = new StringTokenizer(turnsDetail, "\n");
            String turnCode = "";
            while(stringTokenizer.hasMoreTokens()) {
                turnCode= stringTokenizer.nextToken();
                if(!isBlank(turnCode)) {
                    Turn turn = new Turn();
                    turn.setCode(turnCode.replaceAll("^\\s+", "").replaceAll("\\s+$", ""));
                    setTurnFields(turn);
                }
            }
        }

    }

    private void updateTurnListVisibility() {
        if (!turnsList.isEmpty()){
            showTurnList = true;
        }
    }

    private void autoGenerateTurnList() {
            Long lastTurnId = turnService.getLastInsertedID();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
            String dateStr = sdfDate.format(turnsDate);
            for (int i = 0; i < quantity; i++) {
                Turn turn = new Turn();
                String customerName;
                if (contract != null) {
                    customerName = contract.getExporterDescription().substring(0, MIN_EXPORTER_DESCRIPTION_SIZE);
                } else {
                    customerName = "EXP";
                }
                ++lastTurnId;
                turn.setCode("MON" + CODE_SEPARATOR + customerName + CODE_SEPARATOR + dateStr + CODE_SEPARATOR + lastTurnId.toString());
                setTurnFields(turn);
            }

    }

    private Turn setTurnFields(Turn turn){
        turn.setTurnDate(turnsDate);
        turn.setAutogenerated(autogenerate);
        turn.setDestination(destination);
        turnsList.add(turn);
        return turn;
    }
    public void cancelAction(){
        log.debug("Cancel action...");
        clear();
    }

    public void clear(){
        log.debug("Attempt to clear the TurnsAdd values...");
        turnsErrorMessages.clear();
        quantity = null;
        autogenerate = false;
        turnsDetail = null;
        turnsList.clear();
        editedTurnId = null;
        showTurnList = false;
        if (editableTurnsDate){
            turnsDate = null;
            terminalId=null;
        }

    }

    public void onEditTurn(RowEditEvent event) {
        Turn turn = (Turn) event.getObject();
        if (turn.getCode().isEmpty()) {
            turnsErrorMessages.add(getMessageBundle(TURN_REQUIRED_MESSAGE_KEY));
            turn.setCode(previousTurn.getCode());
            previousTurn = null;
        }else{
            turnsErrorMessages.clear();
            turn.setAutogenerated(false);
        }
    }

    public void onEditTurnInit(RowEditEvent event) {
        Turn turnFromEvent = (Turn) event.getObject();
        previousTurn = new Turn();
        previousTurn.setCode(turnFromEvent.getCode());

    }

    public void deleteTurn(){
        turnsErrorMessages.clear();
        Iterator<Turn> turnIterator = turnsList.iterator();
        while(turnIterator.hasNext()) {
            Turn oneTurn = turnIterator.next();
            if(oneTurn.getCode().equals(getEditedTurnId())) {
                turnIterator.remove();
            }
        }
        quantity = turnsList.size();
        showTurnList = true;

    }

    public void clearTextAreaCodes(){
        turnsDetail = "";
    }

    public void addIndividualTurn(){
        turnsErrorMessages.clear();
        log.debug("Adding Individual turn...");
        if (!isBlank(individualTurnCode) && turnsList.size()!=MAX_TURNS_QUANTITY) {
            Turn turn = new Turn();
            turn.setCode(individualTurnCode);
            turn.setTurnDate(turnsDate);
            turn.setAutogenerated(false);
            turn.setDestination(destination);
            turnsList.add(turn);
            individualTurnCode = "";
            quantity = turnsList.size();

            updateTurnListVisibility();
        } else {
            if(isBlank(individualTurnCode)){
                turnsErrorMessages.add(getMessageBundle(TURN_REQUIRED_MESSAGE_KEY));
            } else{
                turnsErrorMessages.add(getMessageBundle("label.edit.turn.max.quantity"));
                individualTurnCode = "";
            }
        }
    }

    public Date getTurnsDate() {
        return turnsDate;
    }

    public void setTurnsDate(Date turnsDate) {
        this.turnsDate = turnsDate;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Boolean getAutogenerate() {
        return autogenerate;
    }

    public void setAutogenerate(Boolean autogenerate) {
        this.autogenerate = autogenerate;
    }

    public String getTurnsDetail() {
        return turnsDetail;
    }

    public void setTurnsDetail(String turnsDetail) {
        this.turnsDetail = turnsDetail;
    }

    public List<Turn> getTurnsList() {
        return turnsList;
    }

    public void setTurnsList(List<Turn> turnsList) {
        this.turnsList = turnsList;
    }

    public ContractView getContract() {
        return contract;
    }

    public void setContract(ContractView contract) {
        this.contract = contract;
    }

    public String getEditedTurnId() {
        return editedTurnId;
    }

    public void setEditedTurnId(String editedTurnId) {
        this.editedTurnId = editedTurnId;
    }

    public List<String> getTurnsErrorMessages() {
        return turnsErrorMessages;
    }

    public void setTurnsErrorMessages(List<String> turnsErrorMessages) {
        this.turnsErrorMessages = turnsErrorMessages;
    }

    public TurnService getTurnService() {
        return turnService;
    }

    public void setTurnService(TurnService turnService) {
        this.turnService = turnService;
    }

    public String getIndividualTurnCode() {
        return individualTurnCode;
    }

    public void setIndividualTurnCode(String individualTurnCode) {
        this.individualTurnCode = individualTurnCode;
    }

    public boolean isEditableTurnsDate() {
        return editableTurnsDate;
    }

    public void setEditableTurnsDate(boolean editableTurnsDate) {
        this.editableTurnsDate = editableTurnsDate;
    }

    public boolean isShowTurnList() {
        return showTurnList;
    }

    public List<TerminalDTO> getTerminals() {
        return terminals;
    }

    public void setTerminals(List<TerminalDTO> terminals) {
        this.terminals = terminals;
    }

    public ContractService getContractService() {
        return contractService;
    }

    public void setContractService(ContractService contractService) {
        this.contractService = contractService;
    }

    public Long getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Long terminalId) {
        this.terminalId = terminalId;
    }

    public TerminalService getTerminalService() {
        return terminalService;
    }

    public void setTerminalService(TerminalService terminalService) {
        this.terminalService = terminalService;
    }

    public String getDestinationDescription() {
        return destinationDescription;
    }

    public void setDestinationDescription(String destinationDescription) {
        this.destinationDescription = destinationDescription;
    }

    public String getAddresseeDescription() {
        return addresseeDescription;
    }

    public void setAddresseeDescription(String addresseeDescription) {
        this.addresseeDescription = addresseeDescription;
    }
}
