package com.monsanto.barter.ar.web.faces.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.validators.CuitUtil;
import com.monsanto.barter.ar.business.entity.Vendor;
import com.monsanto.barter.ar.business.service.VendorService;
import com.monsanto.barter.ar.business.service.dto.VendorView;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * @author jpbeni
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class VendorCC extends ArBaseJSF {
    private final Logger log = LoggerFactory.getLogger(VendorCC.class);

    public static final int MINIMUM_PARAMETER_LENGTH = 5;

    private List<String> vendorErrorMessages = new ArrayList<String>();
    private DataModel<VendorView> vendors = new ListDataModel<VendorView>();

    private VendorView vendor = null;

    private String taxNumber = null;
    private String vendorNamePopup;
    private String vendorTaxNumberPopup;
    private boolean required = false;
    private boolean forceSelection = false;

    @Autowired
    private VendorService service;

    public VendorCC() {
    }

    public List<VendorView> autocomplete (final String query) {
        List<VendorView> results =  service.search(query);
        if (!forceSelection && CuitUtil.isValid(query) && results.isEmpty()) {
            //TODO: Internationalize this
            results.add(0, new VendorView(query, "No se encontró la Razón Social"));
        }
        return results;
    }

    public void handleItemSelect(SelectEvent event) {
        VendorView view = (VendorView) event.getObject();
        this.vendor = view;
        this.taxNumber = view.getTaxNumber();
    }

    public void searchVendor() {
        clear();
        boolean vendorFound = false;
        try {
            setVendor(service.getVendor(taxNumber));
            vendorFound = true;
        } catch (BusinessException e) {
            log.info("Vendor not found for taxNumber " + taxNumber, e);
            vendorTaxNumberPopup = null;
            vendorNamePopup = null;
            vendor = null;
            if (StringUtils.hasText(taxNumber)){
                vendorTaxNumberPopup = taxNumber;
                vendorNamePopup = "";
                searchVendorByTaxNumberAndName();
            }
        }
        addCallbackParam("vendorFound", vendorFound);
    }

    public void clearVendor() {
        vendor = null;
        taxNumber = null;
    }

    public void clear() {
        vendorErrorMessages.clear();
        vendors = new ListDataModel<VendorView>();
        vendorTaxNumberPopup = null;
        vendorNamePopup = null;
    }

    /**
     * Search vendor by {@link #vendorTaxNumberPopup} and {@link #vendorNamePopup}
     * The fields are validated before searching (see {@link #validateFields()})
     */
    public void searchVendorByTaxNumberAndName() {
        vendorErrorMessages.clear();
        vendors = new ListDataModel<VendorView>();
        try {
            if (validateFields()) {
                List<VendorView> vendorsBase = service.search(vendorTaxNumberPopup, vendorNamePopup);
                Collections.sort(vendorsBase, new VendorSelectItemComparator());
                vendors = new ListDataModel<VendorView>(vendorsBase);
            }
        } catch (BusinessException ex) {
            addMessage(ex);
            log.error("An error occurred finding vendors: ", ex);
        }
    }

    private class VendorSelectItemComparator implements Comparator<VendorView> {
        @Override
        public int compare(VendorView o1, VendorView o2) {
            return (new CompareToBuilder()).append(o1.getName(), o2.getName())
                    .append(o1.getTaxNumber(), o2.getTaxNumber()).toComparison();
        }
    }

    public String getVendorName() {
        if (vendor != null && vendor.getTaxNumber() != null && vendor.getName() != null) {
            return vendor.getName() ;
        }
        return "";
    }

    public String getVendorTaxNumber() {
        getVendorSelected();
        if(vendor == null){
            if (isBlank(taxNumber)) {
                return null;
            } else {
                return taxNumber.trim();
            }
        }
        return null;
    }

    public void vendorSelected() {
        vendor = vendors.getRowData();
        taxNumber = vendor.getTaxNumber();
        vendorNamePopup = null;
        //TODO ver el formatter para el cuit
    }

    private VendorView getVendorSelected() {
        if (isBlank(taxNumber)) {
            vendor = null;
        } else {
            if (vendor == null || !vendor.getTaxNumber().equals(taxNumber)) {
                try {
                    setVendor(service.getVendor(taxNumber));
                } catch (BusinessException ex) {
                    log.error("An error occurred finding vendors: ", ex);
                    vendor = null;
                }
            }
        }
        return vendor;
    }

    private boolean validateFields() {
        boolean valid = false;
        if (isBlank(vendorTaxNumberPopup) && isBlank(vendorNamePopup)) {
            vendorErrorMessages.add(getMessageBundle("ar.barter.vendorCC.error.searchCriteria"));
        } else {
            if (vendorTaxNumberPopup.length()>= MINIMUM_PARAMETER_LENGTH || vendorNamePopup.length() >= MINIMUM_PARAMETER_LENGTH) {
                valid = true;
            } else {
                vendorErrorMessages.add(getMessageBundle("ar.barter.vendorCC.error.searchCriteria"));
            }
        }
        return valid;
    }

    public Vendor getSelectedVendor() {
        VendorView vendorView = this.getVendorSelected();
        if (vendorView != null) {
            return vendorView.getVendor();
        }
        return null;
    }

    public String getSelectedVendorIdentifier() {
        VendorView vendorView = this.getVendorSelected();
        if (vendorView != null) {
            return vendorView.getTaxNumber();
        }
        return null;
    }

    public void setVendor(String vendor) {
        if(vendor!=null){
            setVendor(new VendorView(vendor, "No se encontró la Razón Social"));
        } else {
            setVendor((VendorView) null);
        }
    }

    public void setVendor(Vendor vendor) {
        if(vendor!=null){
            setVendor(new VendorView(vendor));
        } else {
            setVendor((VendorView) null);
        }
    }

    public void setVendor(VendorView vendor) {
        this.vendor = vendor;
        if(vendor!=null){
            this.taxNumber = vendor.getTaxNumber();
        }
    }

    public VendorView getVendor() {
        return vendor;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public List<String> getVendorErrorMessages() {
        return vendorErrorMessages;
    }

    public String getVendorNamePopup() {
        return vendorNamePopup;
    }

    public void setVendorNamePopup(String vendorNamePopup) {
        this.vendorNamePopup = vendorNamePopup;
    }

    public String getVendorTaxNumberPopup() {
        return vendorTaxNumberPopup;
    }

    public void setVendorTaxNumberPopup(String vendorTaxNumberPopup) {
        this.vendorTaxNumberPopup = vendorTaxNumberPopup;
    }

    public DataModel<VendorView> getVendors() {
        return vendors;
    }

    public void setVendors(DataModel<VendorView> vendors) {
        this.vendors = vendors;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isForceSelection() {
        return forceSelection;
    }

    public void setForceSelection(boolean forceSelection) {
        this.forceSelection = forceSelection;
    }
}
