package com.monsanto.barter.ar.web.faces.converter;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.WebApplicationContext;

import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.servlet.ServletContext;

/**
 * Base Spring & Faces Bean aware Converter.
 * Provides common access to Spring and Faces managed beans.
 * @author jpbeni
 */
public abstract class AbstractBeanConverter implements Converter {

    /**
     * Returns the context FaceContext.
     * Override it to customize its behaviour (for testing purposes).
     * @return the context FaceContext
     */
    protected FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    /**
     * Returns the context beanfactory.
     * Override it to customize its behaviour (for testing purposes).
     * @return the context BeanFactory
     */
    protected BeanFactory getBeanFactory() {
        ServletContext servletContext = (ServletContext)getFacesContext().getExternalContext().getContext();
        return (BeanFactory) servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
    }

    /**
     * Returns a bean or a service instantiated by spring
     *
     * @param requiredType type the bean must match; can be an interface or superclass.
     * @return an instance of the single bean matching the required type
     */
    protected <T> T getService(Class<T> requiredType) {
        return getBeanFactory().getBean(requiredType);
    }
}
