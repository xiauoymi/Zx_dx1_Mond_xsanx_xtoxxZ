package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.web.faces.formatter.BaseFormatter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

public class BaseConverter implements Converter {

    private BaseFormatter formatter;

    public BaseConverter(BaseFormatter formatter) {
        this.formatter = formatter;
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        return formatter.getAsObject(value);
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object object) {
        return formatter.getAsString(object);
    }

    protected BaseFormatter getFormatter() {
        return formatter;
    }
}
