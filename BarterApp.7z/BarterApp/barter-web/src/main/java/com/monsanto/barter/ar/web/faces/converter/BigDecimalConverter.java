package com.monsanto.barter.ar.web.faces.converter;


import com.monsanto.barter.ar.web.faces.formatter.BigDecimalFormatter;

import javax.faces.convert.FacesConverter;

@FacesConverter(value="currencyConverter")
public class BigDecimalConverter extends BaseConverter {

	public BigDecimalConverter(){
		super(new BigDecimalFormatter());
	}


}