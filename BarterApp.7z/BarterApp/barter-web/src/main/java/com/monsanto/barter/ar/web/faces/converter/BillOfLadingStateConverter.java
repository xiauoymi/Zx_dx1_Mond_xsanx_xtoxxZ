package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.EnumConverter;
import javax.faces.convert.FacesConverter;


@FacesConverter(value="billOfLadingStateConverter")
public class BillOfLadingStateConverter extends EnumConverter {

    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingStateConverter.class);

    public BillOfLadingStateConverter() {
        super(BillOfLadingState.class);
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component,String value){
        try {
            return Enum.valueOf(BillOfLadingState.class, value);
        } catch (IllegalArgumentException iae) {
            LOG.error("An error occurred converting value: " + value + " to BillOfLadingState", iae);
            return null;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component,Object value) {
        if (BillOfLadingState.class.isInstance(value)) {
            return ((Enum)value).name();
        }
        return null;

    }

}
