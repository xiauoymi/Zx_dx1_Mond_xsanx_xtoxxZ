package com.monsanto.barter.ar.web.faces.converter;


import com.monsanto.barter.ar.web.faces.formatter.CampaignFormatter;

import javax.faces.context.FacesContext;
import javax.faces.convert.FacesConverter;


@FacesConverter(value="campaignConverter")
public class CampaignConverter extends BaseConverter {
    public CampaignConverter(){
        super(new CampaignFormatter());

    }



}
