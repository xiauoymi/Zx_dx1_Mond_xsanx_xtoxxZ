package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.CityAfipLas;
import com.monsanto.barter.ar.business.service.CityAfipLasService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * @author JPBENI
 */
@FacesConverter(value="cityConverter", forClass=CityAfipLas.class)
public class CityConverter extends AbstractBeanConverter implements Converter {

    private static final Logger LOG = LoggerFactory.getLogger(CityConverter.class);

    private CityAfipLasService service;

    private void init() {
        service = getService(CityAfipLasService.class);
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        } else {
            if (component instanceof UIOutput) {
                CityAfipLas value = (CityAfipLas)((UIOutput) component).getValue();
                if (value!= null && value.getId().equals(submittedValue)) {
                    return value;
                }
            }

            init();

            CityAfipLas city;
            try {
                city = service.get(submittedValue);
            } catch (Exception ex) {
                if (!ex.getMessage().equals("ar.barter.exceptions.city.notFound")) {
                    LOG.error("An error occurred converting a City, ", ex);
                }
                city = null;
            }
            return city;
        }
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if (value == null || value.equals("")) {
            return "";
        } else {
            return ((CityAfipLas) value).getId();
        }
    }
}
