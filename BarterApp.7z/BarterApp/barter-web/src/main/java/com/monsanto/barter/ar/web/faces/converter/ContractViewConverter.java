package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * @author LABAEZ
 */
@FacesConverter(value="contractViewConverter", forClass=ContractView.class)
public class ContractViewConverter extends AbstractBeanConverter implements Converter {

    private static final Logger LOG = LoggerFactory.getLogger(ContractViewConverter.class);

    private ContractService contractService;

    private void init() {
        contractService = getService(ContractService.class);
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        }

        if (component instanceof UIOutput) {
            ContractView value = (ContractView)((UIOutput) component).getValue();
            Long valueNumber=null;
            if(value!=null && value.getContractId()!=null){
                valueNumber=value.getContractId();
                if(valueNumber.equals(Long.parseLong(submittedValue))){
                   return value;
                }
            }
        }

        init();

        ContractView view = null;
        try {
            view = contractService.getContractViewById(Long.parseLong(submittedValue));

        } catch (Exception ex) {
            if (!ex.getMessage().equals("ar.barter.exceptions.contract.notFound")) {
                LOG.error("An error occurred converting a ContractView, ", ex);
            }
        }
        return view;

    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if(value!=null && !value.equals("")){
            if (value instanceof ContractView) {
                ContractView contractView = (ContractView) value;
                if (contractView.getContractId() != null) {
                    return contractView.getContractId().toString();
                }else{
                    return "";
                }
            }
            return value.toString();
        }
        return "";

    }
}
