package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.web.faces.formatter.CuitFormatter;

import javax.faces.convert.FacesConverter;

@FacesConverter(value="cuitConverter")
public class CuitConverter extends BaseConverter{
    public CuitConverter() {
        super(new CuitFormatter());
    }
}
