package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.dto.CustomerView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * @author JPBENI
 */

@FacesConverter(value="customerConverter80", forClass=CustomerView.class)
public class CustomerConverter80 extends AbstractBeanConverter implements Converter {

    private static final Logger LOG = LoggerFactory.getLogger(CustomerConverter80.class);

    private static final String DEFAULT_TAX_NUMBER_TYPE = "80";

    private CustomerLasService customerService;

    private void init() {
        customerService = getService(CustomerLasService.class);
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        } else {
            String document = String.format("%011d", Long.valueOf(submittedValue));

            return recoverCustomer(component, document);
        }
    }

    private Object recoverCustomer(UIComponent component, String document) {
        if (component instanceof UIOutput) {
            CustomerView value = (CustomerView)((UIOutput) component).getValue();
            String valueDocument;
            if (value != null && value.getDocument() != null) {
                valueDocument = value.getDocument();
            } else {
                valueDocument = null;
            }
            if (valueDocument!= null && valueDocument.equals(document)) {
                return value;
            }
        }

        init();

        CustomerView view;
        try {
            view = new CustomerView(customerService.getCustomer(document, DEFAULT_TAX_NUMBER_TYPE));
        } catch (Exception ex) {
            if (!ex.getMessage().equals("ar.barter.exceptions.customer.notFound")) {
                LOG.error("An error occurred converting a CustomerLas, ", ex);
            }
            //TODO Internationalize this
            view = new CustomerView(document, "No se encontró la Razón Social");
        }
        return view;
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if (value == null || value.equals("")) {
            return "";
        } else {
            return ((CustomerView) value).getDocument();
        }
    }
}
