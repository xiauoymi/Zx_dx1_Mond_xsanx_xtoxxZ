package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.web.faces.formatter.DateFormatter;

import javax.faces.convert.FacesConverter;

/**
 * Date Converter 
 * 
 * @author asilveira
 * @since 
 * 
 * 
 */
@FacesConverter("barter.DateConverter")
public class DateConverter extends BaseConverter {

	public DateConverter() {
        //TODO: recover date pattern from resourceBundle
		super(new DateFormatter("dd/MM/yyyy"));
	}

}