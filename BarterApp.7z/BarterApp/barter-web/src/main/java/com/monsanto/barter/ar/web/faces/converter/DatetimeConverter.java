package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.web.faces.formatter.DateFormatter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.FacesConverter;

/**
 * Date Converter 
 * 
 * @author asilveira
 * @since 
 * 
 * 
 */
@FacesConverter("barter.DatetimeConverter")
public class DatetimeConverter extends BaseConverter {

    public static final int DATE_WITHOUT_TIME_SIZE = 10;

    public DatetimeConverter() {
        //TODO: recover date pattern from resourceBundle
		super(new DateFormatter("dd/MM/yyyy HH:mm"));

	}

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null){
            String trimmedValue = value.trim();
            if (trimmedValue.length() == DATE_WITHOUT_TIME_SIZE){
                return getFormatter().getAsObject(trimmedValue + " 00:00");
            }
        }
        return getFormatter().getAsObject(value);
    }

}