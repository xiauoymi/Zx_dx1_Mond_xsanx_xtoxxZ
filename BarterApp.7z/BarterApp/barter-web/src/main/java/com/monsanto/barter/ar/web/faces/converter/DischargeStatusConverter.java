package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.enumerated.DischargeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.EnumConverter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="dischargeStatusConverter")
public class DischargeStatusConverter extends EnumConverter {

    private static final Logger LOG = LoggerFactory.getLogger(DischargeStatusConverter.class);

    public DischargeStatusConverter() {
       super(DischargeStatus.class);
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component,String value){
        try {
            return Enum.valueOf(DischargeStatus.class, value);
        } catch (IllegalArgumentException iae) {
            LOG.error("An error occurred converting value: " + value + " to DischargeStatus", iae);
            return null;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component,Object value) {
        if (DischargeStatus.class.isInstance(value)) {
            return ((Enum)value).name();
        }
        return null;
    }
}
