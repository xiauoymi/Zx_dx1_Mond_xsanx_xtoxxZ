package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.EnumConverter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="documentTypeConverter")
public class DocumentTypeConverter extends EnumConverter {

    private static final Logger LOG = LoggerFactory.getLogger(DocumentTypeConverter.class);

    public DocumentTypeConverter() {
       super(DocumentType.class);
    }

    @Override
    public Object getAsObject(FacesContext context, UIComponent component,String value){
        try {
            return Enum.valueOf(DocumentType.class, value);
        } catch (IllegalArgumentException iae) {
            LOG.error("An error occurred converting value: " + value + " to DocumentType", iae);
            return null;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (DocumentType.class.isInstance(value)) {
            return ((DocumentType)value).name();
        }
        return null;
    }
}
