package com.monsanto.barter.ar.web.faces.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.convert.LongConverter;

/**
 * Created with IntelliJ IDEA.
 * User: IVERT
 * Date: 2/11/14
 * Time: 6:00 PM
 * To change this template use File | Settings | File Templates.
 */

@FacesConverter(value="number1116Converter")
public class Number1116Converter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        return value.replace("-","");
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        return ((String)value).replaceFirst("(\\d{4})(\\d{8})", "$1-$2");
    }
}
