package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.service.PointOfSaleService;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.FacesConverter;

/**
 * Created by VNBARR on 9/16/2014.
 */
@FacesConverter(value="pointOfSaleDTOConverter", forClass= PointOfSaleDTO.class)
public class PointOfSaleDTOConverter extends AbstractBeanConverter  {

    private static final Logger LOG = LoggerFactory.getLogger(PointOfSaleDTOConverter.class);
    private PointOfSaleService pointOfSaleService;

    private void init() {
        this.pointOfSaleService = getService(PointOfSaleService.class);
    }

        @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
            PointOfSaleDTO pointOfSaleDTO = null;
            if (value.trim().equals("")) {
                return null;
            }

            if (component instanceof UIOutput) {
                pointOfSaleDTO = (PointOfSaleDTO)((UIOutput) component).getValue();
                Long valueNumber=null;
                if (pointOfSaleDTO != null && pointOfSaleDTO.getId() != null) {
                    valueNumber = pointOfSaleDTO.getId();
                    if(valueNumber.toString().equals(value)){
                        return pointOfSaleDTO;
                    }
                }
            }

            init();

            try {
                PointOfSale pointOfSale = pointOfSaleService.get(Long.parseLong(value));
                if (pointOfSale != null){
                    pointOfSaleDTO = new PointOfSaleDTO();
                    pointOfSaleDTO.setId(pointOfSale.getId());
                    pointOfSaleDTO.setStatus(pointOfSale.getStatus());
                    pointOfSaleDTO.setCuit(pointOfSale.getCustomer().getDocument());
                    pointOfSaleDTO.setDescription(pointOfSale.getCustomer().getDescription());
                    pointOfSaleDTO.setEmail(pointOfSale.getEmail());
                }

            } catch (Exception ex) {
                if (!ex.getMessage().equals("ar.barter.exceptions.entity.notFound")) {
                    LOG.error("An error occurred converting a PointOfSaleDTO, ", ex);
                }
            }
            return pointOfSaleDTO;


    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if(value!=null && !value.equals("")){
            if (value instanceof PointOfSaleDTO) {
                PointOfSaleDTO pointOfSaleDTO = (PointOfSaleDTO) value;
                return pointOfSaleDTO.getId().toString();
            }
            return value.toString();
        }
        return "";
    }
}
