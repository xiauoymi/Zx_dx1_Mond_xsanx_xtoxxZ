package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.Port;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.FacesConverter;

/**
 * @author PSAND
 */
@FacesConverter(value="portDestinationDTOConverter", forClass=PortDestinationDTO.class)
public class PortDestinationDTOConverter extends AbstractBeanConverter {

    private static final Logger LOG = LoggerFactory.getLogger(PortDestinationDTOConverter.class);

    private PortService portService;

    private void init() {
        portService = getService(PortService.class);
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        }

        if (component instanceof UIOutput) {
            PortDestinationDTO value = (PortDestinationDTO)((UIOutput) component).getValue();
            Long valueNumber=null;
            if (value != null && value.getId() != null) {
                valueNumber = value.getId();
                if(valueNumber.toString().equals(submittedValue)){
                    return value;
                }
            }
        }

        init();

        PortDestinationDTO dto = getPortDestinationDTO(submittedValue);

        return dto;

    }

    private PortDestinationDTO getPortDestinationDTO(String submittedValue) {
        PortDestinationDTO dto = null;
        try {
            Port port = portService.get(Long.parseLong(submittedValue));

            if(port!=null){
                dto = new PortDestinationDTO(port);
            }
        } catch (Exception ex) {
            if (!ex.getMessage().equals("ar.barter.exceptions.entity.notFound")) {
                LOG.error("An error occurred converting a PortDestinationDTO, ", ex);
            }
        }
        return dto;

    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if(value!=null && !value.equals("")){
                if (value instanceof PortDestinationDTO) {
                    PortDestinationDTO port = (PortDestinationDTO) value;
                    if(port.getId()!=null){
                        return port.getId().toString();
                    }
                return "";
            }
            return value.toString();
        }
        return "";
    }
}
