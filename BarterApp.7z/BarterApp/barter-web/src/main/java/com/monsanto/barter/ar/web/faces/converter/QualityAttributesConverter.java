package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.entity.enumerated.QualityAttributes;

import javax.faces.convert.EnumConverter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="qualityAttributesConverter")
public class QualityAttributesConverter extends EnumConverter {
    public QualityAttributesConverter() {
       super(QualityAttributes.class);
    }

}
