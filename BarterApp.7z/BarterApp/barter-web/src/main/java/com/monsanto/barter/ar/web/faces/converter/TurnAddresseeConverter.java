package com.monsanto.barter.ar.web.faces.converter;


import com.monsanto.barter.ar.business.entity.TurnAddressee;
import com.monsanto.barter.ar.business.service.TurnAddresseeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="turnAddresseeConverter", forClass=TurnAddressee.class)
public class TurnAddresseeConverter extends AbstractBeanConverter {

    private static final Logger LOG = LoggerFactory.getLogger(TurnAddresseeConverter.class);

    private TurnAddresseeService turnAddresseeService;

    private void init() {
        turnAddresseeService = getService(TurnAddresseeService.class);
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        }
        if (component instanceof UIOutput) {
            TurnAddressee value = (TurnAddressee)((UIOutput) component).getValue();
            Long valueNumber=null;
            if (value != null && value.getId() != null) {
                valueNumber = value.getId();
                if(valueNumber.toString().equals(submittedValue)){
                    return value;
                }
            }
        }
        init();
        return getTurnAddressee(submittedValue);
    }

    private TurnAddressee getTurnAddressee(String submittedValue) {
        TurnAddressee turnAddressee = null;
        try {
            turnAddressee = turnAddresseeService.get(Long.parseLong(submittedValue));
        } catch (Exception ex) {
            if (!ex.getMessage().equals("ar.barter.exceptions.entity.notFound")) {
                LOG.error("An error occurred converting a PortDestinationDTO, ", ex);
            }
        }
        return turnAddressee;
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if(value!=null && !value.equals("")){
                if (value instanceof TurnAddressee) {
                    TurnAddressee turnAddressee = (TurnAddressee) value;
                    if(turnAddressee.getId()!=null){
                        return turnAddressee.getId().toString();
                    }
                return "";
            }
            return value.toString();
        }
        return "";
    }
}
