package com.monsanto.barter.ar.web.faces.converter;

import com.monsanto.barter.ar.business.service.VendorService;
import com.monsanto.barter.ar.business.service.dto.VendorView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * @author JPBENI
 */
@FacesConverter(value="vendorConverter", forClass=VendorView.class)
public class VendorConverter extends AbstractBeanConverter implements Converter {

    private static final Logger LOG = LoggerFactory.getLogger(VendorConverter.class);

    private VendorService vendorService;

    private void init() {
        if (vendorService == null) {
            vendorService = getService(VendorService.class);
        }
    }

    public Object getAsObject(FacesContext facesContext, UIComponent component, String submittedValue) {
        if (submittedValue.trim().equals("")) {
            return null;
        } else {
            String document = String.format("%010d", Long.valueOf(submittedValue));

            return recoverVendor(component, document);
        }
    }

    private Object recoverVendor(UIComponent component, String document) {
        if (component instanceof UIOutput) {
            VendorView value = (VendorView)((UIOutput) component).getValue();
            String valueDocument = null;
            if (value != null && value.getTaxNumber() != null) {
                valueDocument = value.getTaxNumber();
            }
            if (valueDocument!= null && valueDocument.equals(document)) {
                return value;
            }
        }

        init();

        VendorView view;
        try {
            view = new VendorView(vendorService.getVendor(document));
        } catch (Exception ex) {
            if (!ex.getMessage().equals("ar.barter.exceptions.vendor.notFound")) {
                LOG.error("An error occurred converting a Vendor, ", ex);
            }
            //TODO Internationalize this
            view = new VendorView(document, "No se encontró la Razón Social");
        }
        return view;
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object value) {
        if (value == null || value.equals("")) {
            return "";
        } else {
            return ((VendorView) value).getTaxNumber();
        }
    }
}
