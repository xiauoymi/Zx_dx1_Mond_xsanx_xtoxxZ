package com.monsanto.barter.ar.web.faces.editView;

import com.monsanto.Util.MessageFormatter;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.business.entity.BaseEntity;
import com.monsanto.barter.ar.web.faces.beans.growerdocuments.composite.GrowerDocumentsCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.groups.Default;
import java.util.ArrayList;
import java.util.List;

import static com.monsanto.barter.ar.web.faces.mode.Mode.UPDATE;
import static com.monsanto.barter.ar.web.faces.mode.Mode.VIEW;

public abstract class EditViewBase <T extends BaseEntity> extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(EditViewBase.class);
    private Mode mode;
    private List<AbstractWizardStepCC> sections;
    private GrowerDocumentsCC growerDocumentsCC;

    private Long idEntity;
    private T entity;
    private List<Class> groups = new ArrayList<Class>();
    private List<String> sapMessages = new ArrayList<String>();
    private UserDecorator user;

    protected abstract T findEntity();
    protected abstract String save();
    protected abstract void createSections();
    protected abstract void init();
    protected abstract DocumentType getDocumentType();
    private boolean fromGrower;

    protected void begin(Mode mode) {
        user = GlobalBarterSecurityHelper.getLoggedInUser();
        LOG.debug(MessageFormatter.format("Start Begin - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        init();
        sections = new ArrayList<AbstractWizardStepCC>();
        entity = findEntity();

        if (mode == UPDATE) {
            setUpdateMode(entity);
        } else {
            setViewMode(entity);
        }

        addGroup(Default.class);
        this.growerDocumentsCC = getService(GrowerDocumentsCC.class);
        createSections();
        initSections();
        LOG.debug(MessageFormatter.format("End Begin - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
    }

    protected abstract void setUpdateMode(T entity);

    protected abstract void setViewMode(T entity);

    private void initSections() {
        LOG.debug(MessageFormatter.format("START initSections - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        for (AbstractWizardStepCC section : sections) {
            section.initializeStepCC(1, "", entity, getMode()).begin();
        }
        growerDocumentsCC.setDocumentId(idEntity);
        growerDocumentsCC.setDocumentType(getDocumentType());
        growerDocumentsCC.begin();
    }

    private void setValuesFromComponents() {
        LOG.debug(MessageFormatter.format("SETTING VALUES setValuesFromComponents - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        for (AbstractWizardStepCC section : sections) {
            section.setValuesFromComponents();
        }
    }

    protected void addSection(AbstractWizardStepCC section){
        sections.add(section);
    }

    protected void addGroup(Class group){
        groups.add(group);
    }

    protected boolean validate() {
        LOG.debug(MessageFormatter.format("VALIDATION  - Class:{0} - id:{1}", this.getClass().getName(), getIdEntity()));
        List<String> violationMessages = getValidator().validate(groups, getEntity());
        if (!violationMessages.isEmpty()) {
            for (String violationMessage : violationMessages) {
                addMessage(violationMessage);
            }
            return false;
        }
        return true;
    }

    public void preSave() {
        LOG.debug(MessageFormatter.format("PreSave - Class:{0} - id:{1}", entity.getClass().getName(), idEntity.toString()));
        sapMessages.clear();
        setValuesFromComponents();
        boolean validForSave = false;
        if (validate()) {
            validForSave = true;
        }
        addCallbackParam("validForSave", validForSave);
    }

    public String view() {
        LOG.debug(MessageFormatter.format("Start Navigation en VIEW Mode - Class:{0} - id:{1}", getClass().getName(), idEntity));
        begin(VIEW);
        return SUCCESS;
    }

    public String edit() {
        LOG.debug(MessageFormatter.format("Start Navigation en EDIT Mode - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        begin(UPDATE);
        return SUCCESS;
    }

    public String cancel() {
        LOG.debug(MessageFormatter.format("CANCEL - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        cleanUp();
        return SUCCESS;
    }

    public String back() {
        LOG.debug(MessageFormatter.format("GO BACK  - Class:{0} - id:{1}", getClass().getName(), idEntity.toString()));
        cleanUp();
        return SUCCESS;
    }

    protected void cleanUp() {
        setIdEntity(null);
        setEntity(null);
        setMode(null);
        sections = null;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public Long getIdEntity() {
        return idEntity;
    }

    public void setIdEntity(Long idEntity) {
        this.idEntity = idEntity;
    }

    public T getEntity() {
        return entity;
    }

    public void setEntity(T entity) {
        this.entity = entity;
    }

    public List<Class> getGroups() {
        return groups;
    }

    public void setGroups(List<Class> groups) {
        this.groups = groups;
    }

    public void setSections(List<AbstractWizardStepCC> sections) {
        this.sections = sections;
    }

    public List<String> getSapMessages() {
        return sapMessages;
    }

    public GrowerDocumentsCC getGrowerDocumentsCC() {
        return growerDocumentsCC;
    }

    public boolean isGrowerPortalDocumentEnable(){
        boolean adminOrSuper = user.isAdministrator() || user.isSuper();
        return user.isPos() || user.isGrower() || adminOrSuper;
    }

    public boolean isFromGrower() {
        return fromGrower;
    }

    public void setFromGrower(boolean fromGrower) {
        this.fromGrower = fromGrower;
    }
}
