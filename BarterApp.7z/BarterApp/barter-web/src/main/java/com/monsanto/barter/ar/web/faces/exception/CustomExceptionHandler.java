package com.monsanto.barter.ar.web.faces.exception;

import org.apache.log4j.Logger;

import javax.faces.FacesException;
import javax.faces.application.NavigationHandler;
import javax.faces.application.ViewExpiredException;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;
import java.util.Iterator;

public class CustomExceptionHandler extends ExceptionHandlerWrapper {

    private static final Logger LOG = Logger.getLogger(CustomExceptionHandler.class);

    private final ExceptionHandler wrapped;

    public CustomExceptionHandler(ExceptionHandler wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public ExceptionHandler getWrapped() {
        return this.wrapped;
    }

    public void handle() {
        final Iterator<ExceptionQueuedEvent> iterator = getUnhandledExceptionQueuedEvents().iterator();
        while (iterator.hasNext()) {
            ExceptionQueuedEvent event = iterator.next();
            ExceptionQueuedEventContext context =
                    (ExceptionQueuedEventContext) event.getSource();
            Throwable throwable = context.getException();
            final FacesContext fc = FacesContext.getCurrentInstance();
                if(throwable instanceof ViewExpiredException) {
                    NavigationHandler navHandler = fc.getApplication().getNavigationHandler();
                    try {
                        navHandler.handleNavigation(fc, null, "home?faces-redirect=true&expired=true");
                    } catch(Exception e) {
                        LOG.error(e.getMessage(), e);
                    }

                }
                getWrapped().handle();
        }
    }
}

