package com.monsanto.barter.ar.web.faces.formatter;



import javax.faces.context.FacesContext;
import java.util.Locale;

public abstract class BaseFormatter {

    abstract public Object getAsObject(String value);
    abstract public String getAsString(Object object);
    private Locale locale;


    public BaseFormatter(){
        this.locale = getFacesContextLocale();
    }

    private Locale getFacesContextLocale() {
        FacesContext context = FacesContext.getCurrentInstance();
        if(context !=null){
            return context.getViewRoot().getLocale();
        }
        return null;
    }

    protected Locale getLocale() {
        return locale;
    }

// TODO: Use this to internationalize exceptions
//    private String getBundle(String bundle) {
//        ResourceBundle resourceBundle= ResourceBundle.getBundle("language", locale, getClass().getClassLoader());
//        return resourceBundle.getString(bundle);
//    }


}
