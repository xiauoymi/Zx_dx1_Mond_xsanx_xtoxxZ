package com.monsanto.barter.ar.web.faces.formatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;


public class BigDecimalFormatter extends BaseFormatter {

    private static final Logger LOG = LoggerFactory.getLogger(BigDecimalFormatter.class);

    private int minFractionDigits;

    private int maxFractionDigits;

    private NumberFormat numberFormat;

    public BigDecimalFormatter(int minFractionDigits, int maxFractionDigits) {
        super();
        this.minFractionDigits = minFractionDigits;
        this.maxFractionDigits = maxFractionDigits;
	}

    private NumberFormat getNumberFormat(){
        if (numberFormat == null){
            numberFormat = NumberFormat.getInstance(getLocale());
            numberFormat.setMaximumFractionDigits(maxFractionDigits);
            numberFormat.setMinimumFractionDigits(minFractionDigits);
            numberFormat.setGroupingUsed(true);
        }
        return numberFormat;
    }

    public BigDecimalFormatter(){
        this(2, 2);
    }

	public Object getAsObject(String value)  {
        try {
			if (value == null){
				return null;
			}
			String tmpValue = extractValueTempString(value);
			return new BigDecimal(tmpValue);
		} catch (Exception e) {
            LOG.error("An error occurred formatting number: " + value, e);
            return null;//	throw new FormatterException(value, TypeFormatterEnum.NUMBER,e);
		}
	}

    protected String extractValueTempString(String value) {
        String tmpValue = value.trim();
        if(tmpValue.isEmpty()){
            return null;
        }
        if (getLocale().equals(Locale.US)) {
            tmpValue = replaceUS(value);
        } else {
            tmpValue = replaceAR(value);
        }
        return tmpValue;
    }

	private String replaceUS(String valor) {
		return valor.replaceAll(",", "");
	}

	private String replaceAR(String value) {
		String tmpValue = value.replaceAll("\\.", "");
		return tmpValue.replaceAll(",", ".");
	}
	
	public String getAsString(Object valor)  {
		if (valor == null) {
			return "";
		}
		if(valor instanceof String) {
			if (((String)valor).equals("")) {
				return "";
			}
            return getNumberFormat().format(new BigDecimal((String) valor));
		}
		return getNumberFormat().format(((BigDecimal) valor));
	}

}