package com.monsanto.barter.ar.web.faces.formatter;

import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: HNEIR
 * Date: 1/10/14
 * Time: 12:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class BillOfLadingTypeFormatter extends BaseFormatter {

    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingTypeFormatter.class);

    @Override
    public Object getAsObject(String value) {

        try {
            return Enum.valueOf(BillOfLadingType.class, value);
        } catch (IllegalArgumentException iae) {
            LOG.error("An error occurred formatting value: " + value + " to BillOfLadingType", iae);
        }
        return null;

    }

    @Override
    public String getAsString(Object object) {
        return ((Enum)object).name();
    }
}
