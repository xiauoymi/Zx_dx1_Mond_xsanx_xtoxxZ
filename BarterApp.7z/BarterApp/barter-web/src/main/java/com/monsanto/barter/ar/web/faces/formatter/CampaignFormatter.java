package com.monsanto.barter.ar.web.faces.formatter;

import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: HNEIR
 * Date: 1/10/14
 * Time: 11:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class CampaignFormatter extends BaseFormatter {


    @Override
    public Object getAsObject(String value) {
        StringBuilder sb;

        if ( value != null ){
            sb = new StringBuilder();
            for (int i=0;i<value.length();i++){
                if (value.charAt(i)!='/'){
                    sb.append(value.charAt(i));
                }
            }
            return sb.toString();
        }

        return value;
    }

    @Override
    public String getAsString(Object object) {
        return object.toString();
    }
}
