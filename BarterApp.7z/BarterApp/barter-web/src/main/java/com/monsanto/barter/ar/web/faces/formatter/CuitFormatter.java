package com.monsanto.barter.ar.web.faces.formatter;

import java.text.DecimalFormat;

import static org.apache.commons.lang.StringUtils.isBlank;


public class CuitFormatter extends BaseFormatter  {
    @Override
    public Object getAsObject(String value) {
        if(!isBlank(value)){
            return value.replace("-","");
        }
        return null;
    }

    @Override
    public String getAsString(Object object) {
        String value = (String)object;
        if(!isBlank(value)){
           return ((String)object).replaceFirst("(\\d{2})(\\d{8})(\\d{1})", "$1-$2-$3");
        }
        return null;
    }
}
