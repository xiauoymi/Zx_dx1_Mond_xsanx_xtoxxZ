package com.monsanto.barter.ar.web.faces.formatter;

import javax.faces.convert.ConverterException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter extends BaseFormatter {
    private DateFormat df;

    public DateFormatter(final String pattern) {
        df = new SimpleDateFormat(pattern);
    }

    @Override
    public Object getAsObject(final String value)  {
        if (value == null) {
            return null;
        }
        String trimedValue = value.trim();
        if (trimedValue.length() < 1) {
            return null;
        }
        try {
            df.setLenient(false);
            return df.parse(trimedValue);
        } catch (java.text.ParseException e) {
            throw new ConverterException(e);
        }

    }

    @Override
    public String getAsString(final Object valor) {
        if (valor == null) {
            return "";
        }
        if (valor instanceof String) {
            return (String) valor;
        }
        return df.format((Date) valor);

    }

}