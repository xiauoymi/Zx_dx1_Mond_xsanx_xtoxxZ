package com.monsanto.barter.ar.web.faces.mode;

/**
 * Represents the different modes the pages, partials and components can be rendered.
 * @author JPBENI
 */
public enum Mode {
    CREATE(false), //Create mode for the wizard.
    UPDATE(false),
    VIEW(true);  //Edit and View modes for the sheet. ;

    Mode(boolean readOnly){
        setReadOnly(readOnly);
    }
    private boolean readOnly;

    public boolean isReadOnly() {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }
}
