package com.monsanto.barter.ar.web.faces.report;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.beans.billoflading.datamodel.AbstractDataModel;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by JASANC5 on 10/14/2014.
 */
public abstract class ReportBase<D extends AbstractDataModel, F, S> extends ArBaseJSF {
    private static final Logger LOG = LoggerFactory.getLogger(ReportBase.class);
    protected D searchResult;
    protected F filter;
    protected S service;
    private static final String PAGE_SEARCH_RESULT = "report-result";

    protected static final int HEADER_OFFSET = 4;
    protected static final int MAX_COLUMNS_SIZE = 25;

    protected abstract void initFilter();

    protected abstract void initServices();

    protected abstract void loadCombos();

    protected abstract boolean validateFilters();

    protected abstract void initReport();

    protected abstract void createHeaderFirstRow(HSSFWorkbook wb);

    protected abstract void createHeaderSecondRow(HSSFWorkbook wb);

    protected abstract void createFooter(HSSFWorkbook wb);

    public String begin() {
        LOG.debug("Setting filters.");
        initFilter();
        LOG.debug("Retrieving services.");
        initServices();
        loadCombos();
        return SUCCESS;
    }

    public String clear() {
        initFilter();
        LOG.debug("Clear fields.");
        return SUCCESS;
    }

    public String report() {
        LOG.debug("Report.");
        if (validateFilters()) {
            initReport();
            return PAGE_SEARCH_RESULT;
        }
        LOG.debug("Returning null.");
        return null;
    }

    public void postProcessXLS(Object document) {
        HSSFWorkbook wb = (HSSFWorkbook) document;
        HSSFSheet sheet = wb.getSheetAt(0);
        createHeader(wb);
        addStyleToHeader(wb);
        addBordersToCells(wb);
        adjustColumnSize(sheet);
        createFooter(wb);
    }

    private void createHeader(HSSFWorkbook wb) {
        createHeaderFirstRow(wb);
        createHeaderSecondRow(wb);
    }

    private void addStyleToHeader(HSSFWorkbook wb) {
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(HEADER_OFFSET - 1);
        for (int i = 0; i < header.getPhysicalNumberOfCells(); i++) {
            HSSFCell cell = header.getCell(i);

            cell.setCellStyle(cellStyle);
        }
    }

    private void addBordersToCells(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        HSSFCellStyle cellStyle = wb.createCellStyle();
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        for (int rowIndex = HEADER_OFFSET; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }
    private void adjustColumnSize(HSSFSheet sheet) {
        for (int i = 0; i <= MAX_COLUMNS_SIZE; i++) {
            sheet.autoSizeColumn(i);
        }
    }


    public F getFilter() {
        return filter;
    }

    public void setFilter(F filter) {
        this.filter = filter;
    }

    public D getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(D searchResult) {
        this.searchResult = searchResult;
    }
}
