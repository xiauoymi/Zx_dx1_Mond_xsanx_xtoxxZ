package com.monsanto.barter.ar.web.faces.validator;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.validation.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: IVERT
 * Date: 2/3/14
 * Time: 3:03 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class BeanValidator <T> extends ArBaseJSF {

    @Autowired
    private ValidatorFactory validatorFactory;


    public List<String> validate(List<Class> groups, T object) {
        List<String> violationMessages = new ArrayList<String>();
        if (!groups.isEmpty()) {
            Set<ConstraintViolation<T>> violations = validateWithGroups(groups, object);
            checkForViolations(violationMessages, violations);
        }
        return violationMessages;
    }

    public List<String> validate(T object) {
        List<String> violationMessages = new ArrayList<String>();
        Set<ConstraintViolation<T>> violations = getValidator().validate(object);
        checkForViolations(violationMessages, violations);
        return violationMessages;
    }

    public List<String> validate(T object, Class... groups) {
        List<String> violationMessages = new ArrayList<String>();
        Set<ConstraintViolation<T>> violations = getValidator().validate(object, groups);
        checkForViolations(violationMessages, violations);
        return violationMessages;
    }

    public List<String> validate(T object, String fieldKey) {
        List<String> violationMessages = new ArrayList<String>();
        Set<ConstraintViolation<T>> violations = validateIfNotNull(object);
        checkForViolations(violationMessages, violations, fieldKey);
        return violationMessages;
    }

    private Set<ConstraintViolation<T>> validateIfNotNull(T object) {
        if (object != null) {
            return getValidator().validate(object);
        }
        return new HashSet<ConstraintViolation<T>>();
    }

    private void checkForViolations(List<String> violationMessages, Set<ConstraintViolation<T>> violations) {
        checkForViolations(violationMessages, violations, null);
    }

    private void checkForViolations(List<String> violationMessages, Set<ConstraintViolation<T>> violations, String fieldKey) {
        if (!violations.isEmpty()) {
            for (ConstraintViolation<T> violation : violations){
                addConstraintViolatedMessage(violation, violationMessages, fieldKey);
            }
        }
    }

    private Set<ConstraintViolation<T>> validateWithGroups(List<Class> groups, T object) {
        return getValidator().validate(object, groups.toArray(new Class[groups.size()]));
    }

    private void addConstraintViolatedMessage(ConstraintViolation<T> violation, List<String> violationMessages, String fieldKey) {
        if (fieldKey != null){
            violationMessages.add(getMessageBundle(fieldKey) + ": " + violation.getMessage());
        } else if (!hasPropertyForI18N(violation)){
            violationMessages.add(violation.getMessage());
        } else {
            String key = violation.getRootBeanClass().getName() + "." + violation.getPropertyPath().toString();
            violationMessages.add(getMessageBundle(key) + ": " + violation.getMessage());
        }
    }

    private boolean hasPropertyForI18N(ConstraintViolation<T> violation) {
        return !violation.getPropertyPath().toString().isEmpty();
    }

    protected Validator getValidator() {
        return validatorFactory.getValidator();
    }


}
