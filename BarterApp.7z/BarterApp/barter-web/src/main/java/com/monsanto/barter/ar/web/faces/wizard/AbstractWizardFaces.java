package com.monsanto.barter.ar.web.faces.wizard;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.primefaces.event.FlowEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: GAVELO
 * Date: 12/26/13
 * Time: 11:44 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractWizardFaces extends ArBaseJSF {

    private final Log logger = LogFactory.getLog(this.getClass());

    private WizardStep actualStep;

    private List<String> sapMessages = new ArrayList<String>();

    public AbstractWizardFaces() {
    }

    public String onFlowProcess(FlowEvent event) {
        logger.info("Current wizard step:" + event.getOldStep());
        logger.info("Next step:" + event.getNewStep());

        WizardStep oldStep = getStep(event.getOldStep());
        WizardStep nextStep = getStep(event.getNewStep());

        try {
            boolean isBack = nextStep.getIndex() < oldStep.getIndex();
            int nextStepIndex = nextStep.getIndex();
            String nextStepKey;
            if (isBack) {
                nextStepKey = handleBack(oldStep, nextStepIndex);
            } else {
                nextStepKey = handleNext(oldStep, nextStepIndex, event);
            }
            if (nextStepKey != null){
                return nextStepKey;
            }
            actualStep = nextStep;
            return event.getNewStep();
        } catch (Exception e) {
            addMessage(e);
            logger.error(e.getMessage(),e);
            return event.getOldStep();
        }
    }

    private String handleBack(WizardStep oldStep, int nextStepIndex){
        boolean shouldBeOmitted;
        //going backward and setting values on entity
        oldStep.setValuesFromComponents();
        for(int i=nextStepIndex;i>=0;i--){
            WizardStep wizNextStep = getStep(i);
            shouldBeOmitted = wizNextStep.shouldBeOmitted();
            if (shouldBeOmitted) {
                wizNextStep.clearData();
            }
            if (!shouldBeOmitted || i==0) {
                actualStep = wizNextStep;
                return wizNextStep.getKey();
            }
        }
        return null;
    }

    protected String handleNext(WizardStep oldStep, int nextStepIndex, FlowEvent event){
        boolean shouldBeOmitted = false;
        int currentStepIndex = oldStep.getIndex();
        oldStep.setValuesFromComponents();
        if (!oldStep.validate()) {
            actualStep = oldStep;
            return event.getOldStep();
        }
        //prepare the data processed on the step we are leaving to be used on the following steps
        oldStep.prepareDataForFollowingSteps();

        for( int i=currentStepIndex+1; i<nextStepIndex+1; i++ ){
            WizardStep wizNextStep = getStep(i);
            wizNextStep.begin();
            shouldBeOmitted = shouldBeOmitted && wizNextStep.shouldBeOmitted();
            if (shouldBeOmitted) {
                wizNextStep.prepareDataForFollowingSteps();
            }

            if (wizNextStep.getIndex() == nextStepIndex) {
                actualStep = wizNextStep;
                return wizNextStep.getKey();
            } else {
                if (!wizNextStep.validate()) {
                    actualStep = wizNextStep;
                    return actualStep.getKey();
                }
            }

            if ((!shouldBeOmitted && nextStepIndex == currentStepIndex) || i+1>=getStepCount()) {
                actualStep = wizNextStep;
                return wizNextStep.getKey();
            }
        }
        return null;
    }

    protected abstract int getStepCount();

    protected abstract WizardStep getStep(int i);

    protected abstract WizardStep getStep(String oldStep);

    public WizardStep getActualStep() {
        return actualStep;
    }

    public void setActualStep(WizardStep actualStep) {
        this.actualStep = actualStep;
    }

    public void preSave(){
        sapMessages.clear();
        getActualStep().setValuesFromComponents();
        addCallbackParam("isValid", getActualStep().validate());
    }

    public List<String> getSapMessages() {
        return sapMessages;
    }
}
