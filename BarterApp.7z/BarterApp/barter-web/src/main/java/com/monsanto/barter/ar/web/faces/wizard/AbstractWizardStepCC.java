package com.monsanto.barter.ar.web.faces.wizard;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;


import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: HNEIR
 * Date: 12/27/13
 * Time: 4:11 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractWizardStepCC <T> extends ArBaseJSF implements WizardStep, Comparable<AbstractWizardStepCC> {

    private int index;
    private String key;
    private T entity;
    protected Mode mode;

    private List<Class> groups = new ArrayList<Class>();

    public void begin() {}

    public AbstractWizardStepCC initializeStepCC(int index, String key, T entity, Mode mode){
        this.index = index;
        this.key = key;
        this.entity = entity;
        this.initializeValidators();
        this.mode = mode;
        return this;
    }

    @Override
    public void clearData() {}

    @Override
    public boolean validate() {
        List<String> violationMessages = getValidator().validate(groups, getEntity());
        if (violationMessages.isEmpty()){
            return true;
        }
        for (String violationMessage : violationMessages){
            addMessage(violationMessage);
        }
        return false;
    }

    protected BeanValidator getValidator() {
        return getService(BeanValidator.class);
    }

    @Override
    public void setValuesFromComponents() {}

    @Override
    public void prepareDataForFollowingSteps() {}

    @Override
    public boolean shouldBeOmitted() {
        return false;
    }

    @Override
    public int getIndex() {
        return index;
    }

    @Override
    public String getKey() {
        return key;
    }

    public int compareTo(AbstractWizardStepCC o) {
        if (this.getIndex() < o.getIndex()) {
            return -1;
        } else if (this.getIndex() > o.getIndex()) {
            return 1;
        } else {
            return 0;
        }
    }

    protected abstract void initializeValidators();

    public List<Class> getGroups() {
        return groups;
    }

    public void setGroups(List<Class> groups) {
        this.groups = groups;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public T getEntity() {
        return entity;
    }

    public void setEntity(T entity) {
        this.entity = entity;
    }
}
