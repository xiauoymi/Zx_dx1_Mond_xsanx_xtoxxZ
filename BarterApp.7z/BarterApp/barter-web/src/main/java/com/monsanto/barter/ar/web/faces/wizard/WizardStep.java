package com.monsanto.barter.ar.web.faces.wizard;

/**
 * Created by IntelliJ IDEA.
 * User: AFREI
 * Date: 23/05/13
 * Time: 11:33
  */
public interface WizardStep {


    void begin();
    void clearData();
    void setValuesFromComponents();
    boolean validate();
    void prepareDataForFollowingSteps();
    boolean shouldBeOmitted();
    int getIndex();
    String getKey();
}
