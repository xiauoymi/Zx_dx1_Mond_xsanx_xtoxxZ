package com.monsanto.barter.ar.web.filters;

import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.web.filters.BaseMonitoringFilter;

/**
 * @author JPBENI
 */
public class BarterArMonitoringFilter extends BaseMonitoringFilter {
    @Override
    public boolean loggedUserCanToggleMonitoring() {
        UserDecorator loggedUser = GlobalBarterSecurityHelper.getLoggedInUser();
        //Only super and administrator users can toggle monitoring
        return loggedUser.isSuper() || loggedUser.isAdministrator();
    }
}
