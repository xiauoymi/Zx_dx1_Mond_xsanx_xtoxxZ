package com.monsanto.barter.ar.web.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Handles all the exceptions thrown in the pages and redirects to the error page.
 * @author JPBENI
 */
public class ExceptionFilter extends OncePerRequestFilter {
    private static final Logger LOG = LoggerFactory.getLogger(ExceptionFilter.class);
    public static final String GENERIC_ERROR = "generic.error";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(request, response);
        } catch (Exception ex) {
            LOG.error("Unexpected error: ", ex);
            if (getFacesContext() != null) {
                getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, GENERIC_ERROR, GENERIC_ERROR));
            }else {
                response.sendRedirect(response.encodeRedirectURL(getContextPath() + "/ar/pages/error/error.jsf"));
            }
        }
    }

    protected FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    protected String getContextPath() {
        return getServletContext().getContextPath();
    }
}
