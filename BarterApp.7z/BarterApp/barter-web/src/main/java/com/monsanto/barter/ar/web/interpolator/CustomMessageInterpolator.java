package com.monsanto.barter.ar.web.interpolator;

import com.monsanto.barter.ar.web.faces.beans.ArBaseJSF;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import org.apache.bval.jsr303.DefaultMessageInterpolator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.MessageInterpolator;
import java.util.Locale;

/**
 * Created by JASANC5 on 7/21/2014.
 */
@Component
public class CustomMessageInterpolator implements MessageInterpolator {

    private final MessageInterpolator delegate;

    @Autowired
    private CountryHolder countryHolder;

    public CustomMessageInterpolator(){
        this.delegate = new DefaultMessageInterpolator();
    }

    @Override
    public String interpolate(String template, Context ctx) {
            Locale locale = countryHolder.getCountry().getLocale();
            return this.delegate.interpolate(template, ctx, locale);
    }

    @Override
    public String interpolate(String template, Context ctx, Locale locale) {
        Locale forcedLocale = countryHolder.getCountry().getLocale();
        return this.delegate.interpolate(template, ctx, forcedLocale);
    }


}
