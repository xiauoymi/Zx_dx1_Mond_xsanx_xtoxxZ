package com.monsanto.barter.ar.web.mvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.Lot;
import com.monsanto.barter.ar.business.entity.RemoteRequest;
import com.monsanto.barter.ar.business.service.EmailService;
import com.monsanto.barter.ar.business.service.LotService;
import com.monsanto.barter.ar.web.mvc.beans.QualityItemBean;
import com.monsanto.barter.ar.web.mvc.beans.ServiceResponse;
import com.monsanto.barter.ar.web.mvc.beans.UpdateDocumentsServiceRequest;
import com.monsanto.barter.ar.web.mvc.beans.WagonBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.BillOfLadingTrainBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.DocumentBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.enumerated.Operation;
import com.monsanto.barter.ar.web.mvc.utils.LotExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author JPBENI
 */
@Controller
public class DocumentServicesController {
    private static final Logger LOG = LoggerFactory.getLogger(DocumentServicesController.class);
    public static final String DUMMY_DATE = "20151212";

    @Autowired
    private LotService lotService;

    @Autowired
    private TransactionTemplate tx;

    @Autowired
    private LotExecutor lotExecutor;

    @Autowired
    private EmailService emailService;

    private ObjectMapper objectMapper;

    @PostConstruct
    public void init() {
        objectMapper = new ObjectMapper();
        //TODO: if debug, enable pretty-printing of json messages
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public String dummy() {
        return "OK";
    }

    @RequestMapping(value = "/documents", method = {RequestMethod.POST, RequestMethod.PUT}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ServiceResponse documentsRawRq(@RequestBody final String requestBody) throws IOException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Incoming message: \n" + requestBody + "\n End");
            System.out.println("Incoming message: \n" + requestBody + "\n End");
            emailService.sendMail(new String[]{"ezequiel.alonso@monsanto.com", "fernando.villa@monsanto.com",
                            "nicolas.cantaro@monsanto.com"},
                    "json, env: " + EnvironmentHelper.getFunction(), requestBody);
        }
        UpdateDocumentsServiceRequest request = null;
        try {
            request = objectMapper.readValue(requestBody.getBytes(), UpdateDocumentsServiceRequest.class);
        } catch (Exception e) {
            LOG.error("WS Error", e);
            return new ServiceResponse("500", e.getMessage());
        }
        ServiceResponse response = documents(request);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Outgoing message: \n"+objectMapper.writeValueAsString(response)+"\n End");
            System.out.println("Outgoing message: \n" + objectMapper.writeValueAsString(response) + "\n End");
        }
        return response;
    }

//    @RequestMapping(value = "/documents", method = {RequestMethod.POST, RequestMethod.PUT}, consumes = {MediaType.APPLICATION_JSON_VALUE})
//    @ResponseBody
    public ServiceResponse documents(@RequestBody final UpdateDocumentsServiceRequest request) {
        ServiceResponse response;
        try {
            Lot lot = tx.execute(new TransactionCallback<Lot>() {
                @Override
                public Lot doInTransaction(TransactionStatus txStatus) {
                    try {
                        Lot lot = lotService.findLot(request.getTransactionId());
                        if (lot != null && lot.isPending()) { //if the lot exists and it is pending
                            if (lot.getNextSequence() == request.getSequence()) {
                                CharArrayWriter writer = new CharArrayWriter();
                                objectMapper.writeValue(writer, request);
                                RemoteRequest remoteRequest = new RemoteRequest(lot, request.getSequence(),
                                        writer.toCharArray());
                                lot.addRequest(remoteRequest);
                                if (request.getFirstDocument() + request.getDocuments().size() >= request.getSize()) {
                                    lot.complete();
                                }
                                lotService.update(lot);
                            } else {
                                LOG.warn("A message was discarded due to a sequence failure: {}", request);
                            }
                        } else {
                            LOG.warn("A message was discarded due to a missing/cancelled Lot: {}", request);
                        }
                        return lot;
                    } catch (Exception ex) {
                        throw new BarterException("There was an error saving the remote request:", ex);
                    }
                }
            });
            if (lot.isComplete()) {
                lotExecutor.executePendingLots();
            }
            response = new ServiceResponse("200", "OK");
        } catch (Exception e) {
            LOG.error("WS Error", e);
            return new ServiceResponse("500", e.getMessage());

        }
        return response;
    }

    @RequestMapping(value="/documents", method = RequestMethod.GET)
    @ResponseBody
    public UpdateDocumentsServiceRequest testDocuments() {

        UpdateDocumentsServiceRequest testRequest = new UpdateDocumentsServiceRequest();

        List<DocumentBean> documents = new ArrayList<DocumentBean>();
        BillOfLadingTrainBean billOfLadingTrain = new BillOfLadingTrainBean();
        billOfLadingTrain.setOperation(Operation.CREATE);
        billOfLadingTrain.setCreatedDate(DUMMY_DATE);
        billOfLadingTrain.setLastUpdateDate(DUMMY_DATE);
        billOfLadingTrain.setExternalId("sapId");

        billOfLadingTrain.setCeeNumber("1234");
        billOfLadingTrain.setGenerationDate(DUMMY_DATE);
        billOfLadingTrain.setDueDate(DUMMY_DATE);
        billOfLadingTrain.setHolder("30503508725");
        billOfLadingTrain.setMediator("30503508725");
        billOfLadingTrain.setCommercialSender("30503508725");
        billOfLadingTrain.setCarrier("30507950848");
        billOfLadingTrain.setBroker("30507950848");
        billOfLadingTrain.setAgent("30707386076");
        billOfLadingTrain.setAddressee("30507950848");
        billOfLadingTrain.setDestination("30507950848");
        billOfLadingTrain.setExporter("30503508725");
        billOfLadingTrain.setDirect(false);
        billOfLadingTrain.setCropType("000000000010014667");
        billOfLadingTrain.setCropSubType("0004");
        billOfLadingTrain.setCampaign("1314");
        billOfLadingTrain.setContractNumber("12345678912345678900");
        billOfLadingTrain.setObservations("notes");
        billOfLadingTrain.setLoadWeighedAtDestination(false);
        billOfLadingTrain.setLaTijereta(false);
        billOfLadingTrain.setSpecifiesQuality(true);
        billOfLadingTrain.setSatisfiedWithQuality(true);
        billOfLadingTrain.setConditionallySatisfiedWithQuality(false);
        billOfLadingTrain.setOriginNumber("123456");
        billOfLadingTrain.setOriginAddress("origin address");
        billOfLadingTrain.setOriginZipCode("C1000AAA");
        billOfLadingTrain.setOriginCity("17974");
        billOfLadingTrain.setDestinationNumber("987654");
        billOfLadingTrain.setDestinationAddress("destination address");
        billOfLadingTrain.setDestinationZipCode("C2000BBB");
        billOfLadingTrain.setDestinationCity("17974");
        billOfLadingTrain.setTransportPayerCommercial("30503508725");
        billOfLadingTrain.setTransportDistanceKilometers(1500);
        billOfLadingTrain.setDownloadArrivalDateTime(DUMMY_DATE);
        billOfLadingTrain.setDownloadObservations("more notes");
        billOfLadingTrain.setDownloadChangeDestination("30555555551");
        billOfLadingTrain.setDownloadChangeAddressee("30555555551");
        billOfLadingTrain.setDownloadChangePlantNumber("112233");
        billOfLadingTrain.setDownloadChangeDate(DUMMY_DATE);
        billOfLadingTrain.setDownloadChangeTransferOrderedBy("me");
        billOfLadingTrain.setDownloadChangeAddress("download change address");
        billOfLadingTrain.setDownloadChangeZipCode("C3000CCC");
        billOfLadingTrain.setDownloadChangeCity("17974");
        billOfLadingTrain.setOkBroker(true);
        billOfLadingTrain.setOkQuality(false);
        billOfLadingTrain.setOkPos(true);
        billOfLadingTrain.setOkYield(false);

        billOfLadingTrain.setLaidDate(DUMMY_DATE);
        billOfLadingTrain.setLoadEndDate(DUMMY_DATE);
        billOfLadingTrain.setOperativeNumber(777L);
        billOfLadingTrain.setExchangeTo("some company");
        billOfLadingTrain.setTransshipmentTo("another company");
        billOfLadingTrain.setExchangeToDate(DUMMY_DATE);
        billOfLadingTrain.setTransshipmentToDate(DUMMY_DATE);
        billOfLadingTrain.setExchangeToPlace("somewhere");
        billOfLadingTrain.setTransshipmentToPlace("somewhere else");
        billOfLadingTrain.setOrderNumber(100);
        billOfLadingTrain.setOrderNumber(10);
        billOfLadingTrain.setGuideNumber(1);
        billOfLadingTrain.setTotalWeightDispatched(150000);
        billOfLadingTrain.setDownloadNetDeclared(150000);

        WagonBean wagon = new WagonBean();
        wagon.setWagonNumber(1);
        wagon.setGrossWeight(1500);
        wagon.setTare(200);
        wagon.setGrossWeightOrigin(1700);
        wagon.setTareOrigin(200);
        wagon.setQuality("X");
        wagon.setDownloadDateTime(new Date());
        wagon.setObservations("wagon notes");

        QualityItemBean item1 = new QualityItemBean();
        item1.setAttribute("HD");
        item1.setKilograms(100);
        item1.setPercentage(new BigDecimal("10.1"));

        QualityItemBean item2 = new QualityItemBean();
        item2.setAttribute("MCV");
        item2.setKilograms(50);
        item2.setPercentage(new BigDecimal("0.5"));

        wagon.setQualityItems(item1, item2);

        billOfLadingTrain.setWagons(wagon);
        documents.add(billOfLadingTrain);
/*        ConditioningBean bean = new ConditioningBean();
        bean.setCreatedDate(new Date());
        bean.setLastUpdateDate(new Date());
        bean.setInvoiceType("1");
        bean.setContractNumber("123456");
        bean.setGrower("20264602409");
        bean.setPort("WH31");
        bean.setTax(12.0F);
        bean.setCurrency("USD");

        ConditioningItemBean itemBean = new ConditioningItemBean();
        itemBean.setItem(10);
        itemBean.setQuantity(12.0F);
        itemBean.setBaseUnit("111");
        itemBean.setPricePerUnit(100.0F);
        DocumentIdentifierBean documentIdentifierBean = new DocumentIdentifierBean();
        documentIdentifierBean.setDocumentType("ADD");
        documentIdentifierBean.setNumber("1515");
        itemBean.setDocument(documentIdentifierBean);
        ConditioningItemBean[] items = new ConditioningItemBean[1];
        items[0] = itemBean;

        bean.setItems(items);

        documents.add(bean);*/

/*
        AddendaBean addBean = new AddendaBean();
        addBean.setOperation(Operation.CREATE);
        PartialLiquidationBean liquidation = new PartialLiquidationBean();
        LiquidationUnloadBean liquidationUnloadBean = new LiquidationUnloadBean();
        DocumentIdentifierBean documentIdentifierBean = new DocumentIdentifierBean();
        liquidationUnloadBean.setDocumentIdentifierBean(documentIdentifierBean);
        LiquidationUnloadBean liquidationUnloadBean2 = new LiquidationUnloadBean();
        LiquidationUnloadBean[] unloads = new LiquidationUnloadBean[2];
        unloads[0] = liquidationUnloadBean;
        unloads[1] = liquidationUnloadBean2;
        liquidation.setUnloads(unloads);
        documents.add(liquidation);

        AddendaBean addBean = new AddendaBean();
        addBean.setCreatedDate(new Date());
        addBean.setLastUpdateDate(new Date());
        addBean.setExternalId("sapId");

        addBean.setGenerationDate(new Date());
        addBean.setCity("17974");
        addBean.setDepositaryName("John DOE");
        addBean.setBrokerName("Jane DOE");
        addBean.setSender("20299972071");
        addBean.setNotes("some notes");
        addBean.setLaTijereta(true);
        addBean.setReceptor("30503508725");
        addBean.setCropType("000000000010014667");
        addBean.setWeightToTransfer(1520L);

        addBean.setOkBroker(true);
        addBean.setOkQuality(false);
        addBean.setOkPos(true);
        addBean.setOkYield(false);
        documents.add(addBean);

        BillOfLadingTrainBean billOfLadingTrain = new BillOfLadingTrainBean();
        billOfLadingTrain.setOperation(Operation.CREATE);
        billOfLadingTrain.setCreatedDate(new Date());
        billOfLadingTrain.setLastUpdateDate(new Date());
        billOfLadingTrain.setExternalId("sapId");

        billOfLadingTrain.setCeeNumber("1234");
        billOfLadingTrain.setGenerationDate(new Date());
        billOfLadingTrain.setDueDate(new Date());
        billOfLadingTrain.setHolder("30503508725");
        billOfLadingTrain.setMediator("30503508725");
        billOfLadingTrain.setCommercialSender("30503508725");
        billOfLadingTrain.setCarrier("30507950848");
        billOfLadingTrain.setBroker("30507950848");
        billOfLadingTrain.setAgent("30707386076");
        billOfLadingTrain.setAddressee("30507950848");
        billOfLadingTrain.setDestination("30507950848");
        billOfLadingTrain.setExporter("30503508725");
        billOfLadingTrain.setDirect(false);
        billOfLadingTrain.setCropType("000000000010014667");
        billOfLadingTrain.setCropSubType("0004");
        billOfLadingTrain.setCampaign("1314");
        billOfLadingTrain.setContractNumber("12345678912345678900");
        billOfLadingTrain.setObservations("notes");
        billOfLadingTrain.setLoadWeighedAtDestination(false);
        billOfLadingTrain.setLaTijereta(false);
        billOfLadingTrain.setSpecifiesQuality(true);
        billOfLadingTrain.setSatisfiedWithQuality(true);
        billOfLadingTrain.setConditionallySatisfiedWithQuality(false);
        billOfLadingTrain.setOriginNumber("123456");
        billOfLadingTrain.setOriginAddress("origin address");
        billOfLadingTrain.setOriginZipCode("C1000AAA");
        billOfLadingTrain.setOriginCity("17974");
        billOfLadingTrain.setDestinationNumber("987654");
        billOfLadingTrain.setDestinationAddress("destination address");
        billOfLadingTrain.setDestinationZipCode("C2000BBB");
        billOfLadingTrain.setDestinationCity("17974");
        billOfLadingTrain.setTransportPayerCommercial("30503508725");
        billOfLadingTrain.setTransportDistanceKilometers(1500);
        billOfLadingTrain.setDownloadArrivalDateTime(new Date());
        billOfLadingTrain.setDownloadObservations("more notes");
        billOfLadingTrain.setDownloadChangeDestination("30555555551");
        billOfLadingTrain.setDownloadChangeAddressee("30555555551");
        billOfLadingTrain.setDownloadChangePlantNumber("112233");
        billOfLadingTrain.setDownloadChangeDate(new Date());
        billOfLadingTrain.setDownloadChangeTransferOrderedBy("me");
        billOfLadingTrain.setDownloadChangeAddress("download change address");
        billOfLadingTrain.setDownloadChangeZipCode("C3000CCC");
        billOfLadingTrain.setDownloadChangeCity("17974");
        billOfLadingTrain.setOkBroker(true);
        billOfLadingTrain.setOkQuality(false);
        billOfLadingTrain.setOkPos(true);
        billOfLadingTrain.setOkYield(false);

        billOfLadingTrain.setLaidDate(new Date());
        billOfLadingTrain.setLoadEndDate(new Date());
        billOfLadingTrain.setOperativeNumber(777L);
        billOfLadingTrain.setExchangeTo("some company");
        billOfLadingTrain.setTransshipmentTo("another company");
        billOfLadingTrain.setExchangeToDate(new Date());
        billOfLadingTrain.setTransshipmentToDate(new Date());
        billOfLadingTrain.setExchangeToPlace("somewhere");
        billOfLadingTrain.setTransshipmentToPlace("somewhere else");
        billOfLadingTrain.setOrderNumber(100);
        billOfLadingTrain.setOrderNumber(10);
        billOfLadingTrain.setGuideNumber(1);
        billOfLadingTrain.setTotalWeightDispatched(150000);
        billOfLadingTrain.setDownloadNetDeclared(150000);

        WagonBean wagon = new WagonBean();
        wagon.setWagonNumber(1);
        wagon.setGrossWeight(1500);
        wagon.setTare(200);
        wagon.setGrossWeightOrigin(1700);
        wagon.setTareOrigin(200);
        wagon.setQuality("X");
        wagon.setDownloadDateTime(new Date());
        wagon.setObservations("wagon notes");

        QualityItemBean item1 = new QualityItemBean();
        item1.setAttribute("HD");
        item1.setKilograms(100);
        item1.setPercentage(new BigDecimal(10.1));

        QualityItemBean item2 = new QualityItemBean();
        item2.setAttribute("MCV");
        item2.setKilograms(50);
        item2.setPercentage(new BigDecimal(0.5));

        wagon.setQualityItems(item1, item2);

        billOfLadingTrain.setWagons(wagon);
        documents.add(billOfLadingTrain);

        BillOfLadingTruckBean billOfLadingTruckBean = new BillOfLadingTruckBean();
        billOfLadingTruckBean.setOperation(Operation.CREATE);
        billOfLadingTruckBean.setCreatedDate(new Date());
        billOfLadingTruckBean.setLastUpdateDate(new Date());
        billOfLadingTruckBean.setExternalId("sapIdTruck");

        billOfLadingTruckBean.setCeeNumber("1234");
        billOfLadingTruckBean.setGenerationDate(new Date());
        billOfLadingTruckBean.setDueDate(new Date());
        billOfLadingTruckBean.setHolder("30555555551");
        billOfLadingTruckBean.setMediator("30555555551");
        billOfLadingTruckBean.setCommercialSender("30555555551");
        billOfLadingTruckBean.setCarrier("30555555551");
        billOfLadingTruckBean.setBroker("30555555551");
        billOfLadingTruckBean.setAgent("30707386076");
        billOfLadingTruckBean.setAddressee("30555555551");
        billOfLadingTruckBean.setDestination("30555555551");
        billOfLadingTruckBean.setExporter("30555555551");
        billOfLadingTruckBean.setDirect(false);
        billOfLadingTruckBean.setCropType("000000000010014667");
        billOfLadingTruckBean.setCropSubType("0004");
        billOfLadingTruckBean.setCampaign("1314");
        billOfLadingTruckBean.setContractNumber("12345678912345678900");
        billOfLadingTruckBean.setObservations("notes");
        billOfLadingTruckBean.setLoadWeighedAtDestination(false);
        billOfLadingTruckBean.setLaTijereta(false);
        billOfLadingTruckBean.setSpecifiesQuality(true);
        billOfLadingTruckBean.setSatisfiedWithQuality(true);
        billOfLadingTruckBean.setConditionallySatisfiedWithQuality(false);
        billOfLadingTruckBean.setOriginNumber("123456");
        billOfLadingTruckBean.setOriginAddress("origin address");
        billOfLadingTruckBean.setOriginZipCode("C1000AAA");
        billOfLadingTruckBean.setOriginCity("17974");
        billOfLadingTruckBean.setDestinationNumber("987654");
        billOfLadingTruckBean.setDestinationAddress("destination address");
        billOfLadingTruckBean.setDestinationZipCode("C2000BBB");
        billOfLadingTruckBean.setDestinationCity("17974");
        billOfLadingTruckBean.setTransportPayerCommercial("123456");
        billOfLadingTruckBean.setTransportDistanceKilometers(1500);
        billOfLadingTruckBean.setDownloadArrivalDateTime(new Date());
        billOfLadingTruckBean.setDownloadObservations("more notes");
        billOfLadingTruckBean.setDownloadChangeDestination("30555555551");
        billOfLadingTruckBean.setDownloadChangeAddressee("30555555551");
        billOfLadingTruckBean.setDownloadChangePlantNumber("112233");
        billOfLadingTruckBean.setDownloadChangeDate(new Date());
        billOfLadingTruckBean.setDownloadChangeTransferOrderedBy("me");
        billOfLadingTruckBean.setDownloadChangeAddress("download change address");
        billOfLadingTruckBean.setDownloadChangeZipCode("C3000CCC");
        billOfLadingTruckBean.setDownloadChangeCity("17974");
        billOfLadingTruckBean.setOkBroker(true);
        billOfLadingTruckBean.setOkQuality(false);
        billOfLadingTruckBean.setOkPos(true);
        billOfLadingTruckBean.setOkYield(false);

        billOfLadingTruckBean.setGrossWeight(1500);
        billOfLadingTruckBean.setDownloadTaraWeight(200);
        billOfLadingTruckBean.setDownloadGrossWeight(1700);
        billOfLadingTruckBean.setTaraWeight(200);
        billOfLadingTruckBean.setCtgNumber("1115555888666444");
        billOfLadingTruckBean.setDriver("driverId");
        billOfLadingTruckBean.setEstimatedWeight(1560);
        billOfLadingTruckBean.setTransportTruck("AAA000");
        billOfLadingTruckBean.setTransportTruckTrailer("BBB111");
        billOfLadingTruckBean.setTransportFeeReference(new BigDecimal(10));
        billOfLadingTruckBean.setTransportFee(new BigDecimal(5));
        billOfLadingTruckBean.setTransportPayed(true);
        billOfLadingTruckBean.setTransportToBePayed(false);
        billOfLadingTruckBean.setDownloadDischargeDateTime(new Date());
        billOfLadingTruckBean.setCropQuality("X");
        billOfLadingTruckBean.setDownloadOrderNumber("1");
        billOfLadingTruckBean.setDischargeQualityObservations("even more notes");

        item1 = new QualityItemBean();
        item1.setAttribute("HD");
        item1.setKilograms(100);
        item1.setPercentage(new BigDecimal(10.1));

        item2 = new QualityItemBean();
        item2.setAttribute("MCV");
        item2.setKilograms(50);
        item2.setPercentage(new BigDecimal(0.5));

        billOfLadingTruckBean.setQualityItems(item1, item2);
        documents.add(billOfLadingTruckBean);*/

        testRequest.setDocuments(documents);

        testRequest.setTransactionId(UUID.randomUUID().toString());
        testRequest.setSize(0);
        testRequest.setFirstDocument(0);
        testRequest.setSequence(0);



        return testRequest;
    }
}
