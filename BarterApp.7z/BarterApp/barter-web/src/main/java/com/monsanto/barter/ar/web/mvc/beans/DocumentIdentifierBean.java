package com.monsanto.barter.ar.web.mvc.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentIdentifierBean {

    /** Document number */
    @JsonProperty
    private String number;

    /** RT, ADD, BOL */
    @JsonProperty
    private String documentType;

    public DocumentIdentifierBean() {
    }

    public DocumentIdentifierBean(String number, String documentType) {
        this.number = number;
        this.documentType = documentType;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
}
