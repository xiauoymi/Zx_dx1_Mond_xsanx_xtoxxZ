package com.monsanto.barter.ar.web.mvc.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author VNBARR
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName("liquidationUnload")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LiquidationUnloadBean {

    /** Document number */
    @JsonProperty
    private String number;

    /** RT, ADD, BOL */
    @JsonProperty
    private String documentType;

    @JsonProperty
    private Float weight;

    public LiquidationUnloadBean() {
    }

    public LiquidationUnloadBean(String number, String documentType, Float weight) {
        this.number = number;
        this.documentType = documentType;
        this.weight = weight;
    }


    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

}
