package com.monsanto.barter.ar.web.mvc.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

import java.math.BigDecimal;

/**
 * @author VNBARR
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName("qualityItem")
@JsonIgnoreProperties(ignoreUnknown = true)
public class QualityItemBean {

    /** Enum, can be:  HD, MY, MCV, MV, DAN, OLR, INS,
     CHA, QUB, Z62, MOH, REV, ME, PH */
    @JsonProperty
    private String attribute;

    @JsonProperty
    private BigDecimal percentage;

    @JsonProperty
    private Integer kilograms;

    public QualityItemBean() {
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public BigDecimal getPercentage() {
        return percentage;
    }

    public void setPercentage(BigDecimal percentage) {
        this.percentage = percentage;
    }

    public Integer getKilograms() {
        return kilograms;
    }

    public void setKilograms(Integer kilograms) {
        this.kilograms = kilograms;
    }
}
