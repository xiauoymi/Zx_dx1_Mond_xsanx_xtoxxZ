package com.monsanto.barter.ar.web.mvc.beans;

/**
 * @author JPBENI
 */
public class ServiceResponse {
    private String status;
    private String statusMessage;

    public ServiceResponse() {
    }

    public ServiceResponse(String status, String statusMessage) {
        this.status = status;
        this.statusMessage = statusMessage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
