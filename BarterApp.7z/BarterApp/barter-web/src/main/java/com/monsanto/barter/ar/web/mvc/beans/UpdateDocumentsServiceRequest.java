package com.monsanto.barter.ar.web.mvc.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.monsanto.barter.ar.web.mvc.documentBeans.DocumentBean;

import java.util.List;

/**
 * @author JPBENI
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName("serviceRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateDocumentsServiceRequest {
    @JsonProperty
    private String transactionId;

    @JsonProperty
    private Integer sequence;

    @JsonProperty
    private Integer firstDocument;

    @JsonProperty
    private Integer size;

    @JsonProperty
    private List<DocumentBean> documents;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Integer getFirstDocument() {
        return firstDocument;
    }

    public void setFirstDocument(Integer firstDocument) {
        this.firstDocument = firstDocument;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public List<DocumentBean> getDocuments() {
        return documents;
    }

    public void setDocuments(List<DocumentBean> documents) {
        this.documents = documents;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("{transactionId: " + transactionId);
        builder.append(", sequence: " + sequence);
        builder.append(", firstDocument: " + firstDocument);
        builder.append(", size: " + size + "}");
        return builder.toString();
    }
}
