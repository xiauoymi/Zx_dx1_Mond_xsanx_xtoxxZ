package com.monsanto.barter.ar.web.mvc.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

import java.util.Date;

/**
 * @author VNBARR
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName("wagon")
@JsonIgnoreProperties(ignoreUnknown = true)
public class WagonBean {

    @JsonProperty
    private Integer wagonNumber;

    @JsonProperty
    private Integer grossWeight;

    @JsonProperty
    private Integer tare;

    @JsonProperty
    private Integer grossWeightOrigin;

    @JsonProperty
    private Integer tareOrigin;

    @JsonProperty
    private String quality;

    @JsonProperty
    private Date downloadDateTime;

    @JsonProperty
    private String observations;

    @JsonProperty
    private QualityItemBean[] qualityItems;

    public WagonBean() {
    }

    public Integer getWagonNumber() {
        return wagonNumber;
    }

    public void setWagonNumber(Integer wagonNumber) {
        this.wagonNumber = wagonNumber;
    }

    public Integer getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Integer grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Integer getTare() {
        return tare;
    }

    public void setTare(Integer tare) {
        this.tare = tare;
    }

    public Integer getGrossWeightOrigin() {
        return grossWeightOrigin;
    }

    public void setGrossWeightOrigin(Integer grossWeightOrigin) {
        this.grossWeightOrigin = grossWeightOrigin;
    }

    public Integer getTareOrigin() {
        return tareOrigin;
    }

    public void setTareOrigin(Integer tareOrigin) {
        this.tareOrigin = tareOrigin;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Date getDownloadDateTime() {
        return downloadDateTime;
    }

    public void setDownloadDateTime(Date downloadDateTime) {
        this.downloadDateTime = downloadDateTime;
    }

    public QualityItemBean[] getQualityItems() {
        return qualityItems;
    }

    public void setQualityItems(QualityItemBean... qualityItems) {
        this.qualityItems = qualityItems;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }
}
