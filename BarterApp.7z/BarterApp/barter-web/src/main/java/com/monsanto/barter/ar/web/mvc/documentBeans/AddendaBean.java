package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.Adenda;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddendaBean extends DocumentBean <Adenda> {

    @JsonProperty
    private String number;
    
    @JsonProperty
    private String generationDate;

    /** City Afip Id */
    @JsonProperty
    private String city;

    @JsonProperty
    private String depositaryName;

    @JsonProperty
    private String brokerName;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String sender;

    @JsonProperty
    private String notes;

    @JsonProperty
    private boolean laTijereta;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String receptor;

    /** Material Number */
    @JsonProperty
    private String cropType;

    @JsonProperty
    private Long weightToTransfer;

    @JsonProperty
    private Boolean okBroker;

    @JsonProperty
    private Boolean okPos;

    @JsonProperty
    private Boolean okQuality;

    @JsonProperty
    private Boolean okYield;

    @JsonProperty
    private String sapCreationDate;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Boolean getOkBroker() {
        return okBroker;
    }

    public void setOkBroker(Boolean okBroker) {
        this.okBroker = okBroker;
    }

    public Boolean getOkPos() {
        return okPos;
    }

    public void setOkPos(Boolean okPos) {
        this.okPos = okPos;
    }

    public Boolean getOkQuality() {
        return okQuality;
    }

    public void setOkQuality(Boolean okQuality) {
        this.okQuality = okQuality;
    }

    public Boolean getOkYield() {
        return okYield;
    }

    public void setOkYield(Boolean okYield) {
        this.okYield = okYield;
    }

    public String getGenerationDate() {
        return generationDate;
    }

    public void setGenerationDate(String generationDate) {
        this.generationDate = generationDate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDepositaryName() {
        return depositaryName;
    }

    public void setDepositaryName(String depositaryName) {
        this.depositaryName = depositaryName;
    }

    public String getBrokerName() {
        return brokerName;
    }

    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public boolean isLaTijereta() {
        return laTijereta;
    }

    public void setLaTijereta(boolean laTijereta) {
        this.laTijereta = laTijereta;
    }

    public String getReceptor() {
        return receptor;
    }

    public void setReceptor(String receptor) {
        this.receptor = receptor;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public Long getWeightToTransfer() {
        return weightToTransfer;
    }

    public void setWeightToTransfer(Long weightToTransfer) {
        this.weightToTransfer = weightToTransfer;
    }

    public String getSapCreationDate() {
        return sapCreationDate;
    }

    public void setSapCreationDate(String sapCreationDate) {
        this.sapCreationDate = sapCreationDate;
    }
}
