package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.BillOfLading;


/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class BillOfLadingBean <T extends BillOfLading> extends DocumentBean<T> {

    @JsonProperty
    private String number;

    @JsonProperty
    private String ceeNumber;

    @JsonProperty
    private String generationDate;

    @JsonProperty
    private String dueDate;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String holder;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String mediator;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String commercialSender;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String carrier;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String broker;

    /** VENDOR_ID */
    @JsonProperty
    private String agent;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String addressee;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String destination;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String exporter;

    @JsonProperty
    private Boolean direct;

    /** Material Number */
    @JsonProperty
    private String cropType;

    /** Cereal Type ID */
    @JsonProperty
    private String cropSubType;

    @JsonProperty
    private String campaign;

    @JsonProperty
    private String contractNumber;

    @JsonProperty
    private String observations;

    @JsonProperty
    private Boolean loadWeighedAtDestination;

    @JsonProperty
    private Boolean laTijereta;

    @JsonProperty
    private Boolean specifiesQuality;

    @JsonProperty
    private Boolean satisfiedWithQuality;

    @JsonProperty
    private Boolean conditionallySatisfiedWithQuality;

    @JsonProperty
    private String originNumber;

    @JsonProperty
    private String originAddress;

    @JsonProperty
    private String originZipCode;

    /** City Afip ID */
    @JsonProperty
    private String originCity;

    @JsonProperty
    private String destinationNumber;

    @JsonProperty
    private String destinationAddress;

    @JsonProperty
    private String destinationZipCode;

    /** City Afip ID */
    @JsonProperty
    private String destinationCity;

    @JsonProperty
    private String transportPayerCommercial;

    @JsonProperty
    private Integer transportDistanceKilometers;

    @JsonProperty
    private String downloadArrivalDateTime;

    @JsonProperty
    private String downloadObservations;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String downloadChangeDestination;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String downloadChangeAddressee;

    @JsonProperty
    private String downloadChangePlantNumber;

    @JsonProperty
    private String downloadChangeDate;

    @JsonProperty
    private String downloadChangeTransferOrderedBy;

    @JsonProperty
    private String downloadChangeAddress;

    @JsonProperty
    private String downloadChangeZipCode;

    /** City Afip ID */
    @JsonProperty
    private String downloadChangeCity;

    @JsonProperty
    private Boolean okBroker;

    @JsonProperty
    private Boolean okPos;

    @JsonProperty
    private Boolean okQuality;

    @JsonProperty
    private Boolean okYield;

    @JsonProperty
    private Integer grossWeight;

    @JsonProperty
    private Integer taraWeight;

    @JsonProperty
    private Integer downloadGrossWeight;

    @JsonProperty
    private Integer downloadTaraWeight;

    @JsonProperty
    private String sapCreationDate;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Boolean getOkBroker() {
        return okBroker;
    }

    public void setOkBroker(Boolean okBroker) {
        this.okBroker = okBroker;
    }

    public Boolean getOkPos() {
        return okPos;
    }

    public void setOkPos(Boolean okPos) {
        this.okPos = okPos;
    }

    public Boolean getOkQuality() {
        return okQuality;
    }

    public void setOkQuality(Boolean okQuality) {
        this.okQuality = okQuality;
    }

    public Boolean getOkYield() {
        return okYield;
    }

    public void setOkYield(Boolean okYield) {
        this.okYield = okYield;
    }

    public String getCeeNumber() {
        return ceeNumber;
    }

    public void setCeeNumber(String ceeNumber) {
        this.ceeNumber = ceeNumber;
    }

    public String getGenerationDate() {
        return generationDate;
    }

    public void setGenerationDate(String generationDate) {
        this.generationDate = generationDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getHolder() {
        return holder;
    }

    public void setHolder(String holder) {
        this.holder = holder;
    }

    public String getMediator() {
        return mediator;
    }

    public void setMediator(String mediator) {
        this.mediator = mediator;
    }

    public String getCommercialSender() {
        return commercialSender;
    }

    public void setCommercialSender(String commercialSender) {
        this.commercialSender = commercialSender;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getBroker() {
        return broker;
    }

    public void setBroker(String broker) {
        this.broker = broker;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getAddressee() {
        return addressee;
    }

    public void setAddressee(String addressee) {
        this.addressee = addressee;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getExporter() {
        return exporter;
    }

    public void setExporter(String exporter) {
        this.exporter = exporter;
    }

    public Boolean isDirect() {
        return direct;
    }

    public void setDirect(Boolean direct) {
        this.direct = direct;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public String getCropSubType() {
        return cropSubType;
    }

    public void setCropSubType(String cropSubType) {
        this.cropSubType = cropSubType;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public Boolean isLoadWeighedAtDestination() {
        return loadWeighedAtDestination;
    }

    public void setLoadWeighedAtDestination(Boolean loadWeighedAtDestination) {
        this.loadWeighedAtDestination = loadWeighedAtDestination;
    }

    public Boolean isLaTijereta() {
        return laTijereta;
    }

    public void setLaTijereta(Boolean laTijereta) {
        this.laTijereta = laTijereta;
    }

    public Boolean isSpecifiesQuality() {
        return specifiesQuality;
    }

    public void setSpecifiesQuality(Boolean specifiesQuality) {
        this.specifiesQuality = specifiesQuality;
    }

    public Boolean isSatisfiedWithQuality() {
        return satisfiedWithQuality;
    }

    public void setSatisfiedWithQuality(Boolean satisfiedWithQuality) {
        this.satisfiedWithQuality = satisfiedWithQuality;
    }

    public Boolean isConditionallySatisfiedWithQuality() {
        return conditionallySatisfiedWithQuality;
    }

    public void setConditionallySatisfiedWithQuality(Boolean conditionallySatisfiedWithQuality) {
        this.conditionallySatisfiedWithQuality = conditionallySatisfiedWithQuality;
    }

    public String getOriginNumber() {
        return originNumber;
    }

    public void setOriginNumber(String originNumber) {
        this.originNumber = originNumber;
    }

    public String getOriginAddress() {
        return originAddress;
    }

    public void setOriginAddress(String originAddress) {
        this.originAddress = originAddress;
    }

    public String getOriginZipCode() {
        return originZipCode;
    }

    public void setOriginZipCode(String originZipCode) {
        this.originZipCode = originZipCode;
    }

    public String getOriginCity() {
        return originCity;
    }

    public void setOriginCity(String originCity) {
        this.originCity = originCity;
    }

    public String getDestinationNumber() {
        return destinationNumber;
    }

    public void setDestinationNumber(String destinationNumber) {
        this.destinationNumber = destinationNumber;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public String getDestinationZipCode() {
        return destinationZipCode;
    }

    public void setDestinationZipCode(String destinationZipCode) {
        this.destinationZipCode = destinationZipCode;
    }

    public String getDestinationCity() {
        return destinationCity;
    }

    public void setDestinationCity(String destinationCity) {
        this.destinationCity = destinationCity;
    }

    public String getTransportPayerCommercial() {
        return transportPayerCommercial;
    }

    public void setTransportPayerCommercial(String transportPayerCommercial) {
        this.transportPayerCommercial = transportPayerCommercial;
    }

    public Integer getTransportDistanceKilometers() {
        return transportDistanceKilometers;
    }

    public void setTransportDistanceKilometers(Integer transportDistanceKilometers) {
        this.transportDistanceKilometers = transportDistanceKilometers;
    }

    public String getDownloadArrivalDateTime() {
        return downloadArrivalDateTime;
    }

    public void setDownloadArrivalDateTime(String downloadArrivalDateTime) {
        this.downloadArrivalDateTime = downloadArrivalDateTime;
    }

    public String getDownloadObservations() {
        return downloadObservations;
    }

    public void setDownloadObservations(String downloadObservations) {
        this.downloadObservations = downloadObservations;
    }

    public String getDownloadChangeDestination() {
        return downloadChangeDestination;
    }

    public void setDownloadChangeDestination(String downloadChangeDestination) {
        this.downloadChangeDestination = downloadChangeDestination;
    }

    public String getDownloadChangeAddressee() {
        return downloadChangeAddressee;
    }

    public void setDownloadChangeAddressee(String downloadChangeAddressee) {
        this.downloadChangeAddressee = downloadChangeAddressee;
    }

    public String getDownloadChangePlantNumber() {
        return downloadChangePlantNumber;
    }

    public void setDownloadChangePlantNumber(String downloadChangePlantNumber) {
        this.downloadChangePlantNumber = downloadChangePlantNumber;
    }

    public String getDownloadChangeDate() {
        return downloadChangeDate;
    }

    public void setDownloadChangeDate(String downloadChangeDate) {
        this.downloadChangeDate = downloadChangeDate;
    }

    public String getDownloadChangeTransferOrderedBy() {
        return downloadChangeTransferOrderedBy;
    }

    public void setDownloadChangeTransferOrderedBy(String downloadChangeTransferOrderedBy) {
        this.downloadChangeTransferOrderedBy = downloadChangeTransferOrderedBy;
    }

    public String getDownloadChangeAddress() {
        return downloadChangeAddress;
    }

    public void setDownloadChangeAddress(String downloadChangeAddress) {
        this.downloadChangeAddress = downloadChangeAddress;
    }

    public String getDownloadChangeZipCode() {
        return downloadChangeZipCode;
    }

    public void setDownloadChangeZipCode(String downloadChangeZipCode) {
        this.downloadChangeZipCode = downloadChangeZipCode;
    }

    public String getDownloadChangeCity() {
        return downloadChangeCity;
    }

    public void setDownloadChangeCity(String downloadChangeCity) {
        this.downloadChangeCity = downloadChangeCity;
    }

    public Boolean getDirect() {
        return direct;
    }

    public Boolean getLoadWeighedAtDestination() {
        return loadWeighedAtDestination;
    }

    public Boolean getLaTijereta() {
        return laTijereta;
    }

    public Boolean getSpecifiesQuality() {
        return specifiesQuality;
    }

    public Boolean getSatisfiedWithQuality() {
        return satisfiedWithQuality;
    }

    public Boolean getConditionallySatisfiedWithQuality() {
        return conditionallySatisfiedWithQuality;
    }

    public Integer getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Integer grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Integer getTaraWeight() {
        return taraWeight;
    }

    public void setTaraWeight(Integer taraWeight) {
        this.taraWeight = taraWeight;
    }

    public Integer getDownloadGrossWeight() {
        return downloadGrossWeight;
    }

    public void setDownloadGrossWeight(Integer downloadGrossWeight) {
        this.downloadGrossWeight = downloadGrossWeight;
    }

    public Integer getDownloadTaraWeight() {
        return downloadTaraWeight;
    }

    public void setDownloadTaraWeight(Integer downloadTaraWeight) {
        this.downloadTaraWeight = downloadTaraWeight;
    }

    public String getSapCreationDate() {
        return sapCreationDate;
    }

    public void setSapCreationDate(String sapCreationDate) {
        this.sapCreationDate = sapCreationDate;
    }
}
