package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.BillOfLadingTrain;
import com.monsanto.barter.ar.web.mvc.beans.WagonBean;


/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillOfLadingTrainBean extends BillOfLadingBean <BillOfLadingTrain> {

    @JsonProperty
    private String laidDate;

    @JsonProperty
    private String loadEndDate;

    @JsonProperty
    private Long operativeNumber;

    @JsonProperty
    private String exchangeTo;

    @JsonProperty
    private String transshipmentTo;

    @JsonProperty
    private String exchangeToDate;

    @JsonProperty
    private String exchangeToPlace;

    @JsonProperty
    private String transshipmentToDate;

    @JsonProperty
    private String transshipmentToPlace;

    @JsonProperty
    private Integer orderNumber;

    @JsonProperty
    private Integer guideNumber;

    @JsonProperty
    private Integer totalWeightDispatched;

    @JsonProperty
    private Integer downloadNetDeclared;

    @JsonProperty
    private Integer dispatchedWagons;

    @JsonProperty
    private WagonBean[] wagons;

    public String getLaidDate() {
        return laidDate;
    }

    public void setLaidDate(String laidDate) {
        this.laidDate = laidDate;
    }

    public String getLoadEndDate() {
        return loadEndDate;
    }

    public void setLoadEndDate(String loadEndDate) {
        this.loadEndDate = loadEndDate;
    }

    public Long getOperativeNumber() {
        return operativeNumber;
    }

    public void setOperativeNumber(Long operativeNumber) {
        this.operativeNumber = operativeNumber;
    }

    public String getExchangeTo() {
        return exchangeTo;
    }

    public void setExchangeTo(String exchangeTo) {
        this.exchangeTo = exchangeTo;
    }

    public String getTransshipmentTo() {
        return transshipmentTo;
    }

    public void setTransshipmentTo(String transshipmentTo) {
        this.transshipmentTo = transshipmentTo;
    }

    public String getExchangeToDate() {
        return exchangeToDate;
    }

    public void setExchangeToDate(String exchangeToDate) {
        this.exchangeToDate = exchangeToDate;
    }

    public String getExchangeToPlace() {
        return exchangeToPlace;
    }

    public void setExchangeToPlace(String exchangeToPlace) {
        this.exchangeToPlace = exchangeToPlace;
    }

    public String getTransshipmentToDate() {
        return transshipmentToDate;
    }

    public void setTransshipmentToDate(String transshipmentToDate) {
        this.transshipmentToDate = transshipmentToDate;
    }

    public String getTransshipmentToPlace() {
        return transshipmentToPlace;
    }

    public void setTransshipmentToPlace(String transshipmentToPlace) {
        this.transshipmentToPlace = transshipmentToPlace;
    }

    public Integer getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getGuideNumber() {
        return guideNumber;
    }

    public void setGuideNumber(Integer guideNumber) {
        this.guideNumber = guideNumber;
    }

    public Integer getTotalWeightDispatched() {
        return totalWeightDispatched;
    }

    public void setTotalWeightDispatched(Integer totalWeightDispatched) {
        this.totalWeightDispatched = totalWeightDispatched;
    }

    public Integer getDownloadNetDeclared() {
        return downloadNetDeclared;
    }

    public void setDownloadNetDeclared(Integer downloadNetDeclared) {
        this.downloadNetDeclared = downloadNetDeclared;
    }

    public WagonBean[] getWagons() {
        return wagons;
    }

    public void setWagons(WagonBean... wagons) {
        this.wagons = wagons;
    }

    public Integer getDispatchedWagons() {
        return dispatchedWagons;
    }

    public void setDispatchedWagons(Integer dispatchedWagons) {
        this.dispatchedWagons = dispatchedWagons;
    }

}
