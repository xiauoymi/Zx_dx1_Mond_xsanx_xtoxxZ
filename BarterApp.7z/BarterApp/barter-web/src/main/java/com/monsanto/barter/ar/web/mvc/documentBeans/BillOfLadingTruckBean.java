package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.BillOfLadingTruck;
import com.monsanto.barter.ar.web.mvc.beans.QualityItemBean;

import java.math.BigDecimal;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillOfLadingTruckBean extends BillOfLadingBean <BillOfLadingTruck> {

    @JsonProperty
    private String ctgNumber;

    /** CUSTOMER_ID */
    @JsonProperty
    private String driver;

    @JsonProperty
    private Integer estimatedWeight;

    @JsonProperty
    private String transportTruck;

    @JsonProperty
    private String transportTruckTrailer;

    @JsonProperty
    private BigDecimal transportFeeReference;

    @JsonProperty
    private BigDecimal transportFee;

    @JsonProperty
    private Boolean transportPayed;

    @JsonProperty
    private Boolean transportToBePayed;

    @JsonProperty
    private String downloadDischargeDateTime;

    @JsonProperty
    private String cropQuality;

    @JsonProperty
    private String downloadOrderNumber;

    @JsonProperty
    private String dischargeQualityObservations;

    @JsonProperty
    private String qualityDetails;

    @JsonProperty
    private QualityItemBean[] qualityItems;

    public String getCtgNumber() {
        return ctgNumber;
    }

    public void setCtgNumber(String ctgNumber) {
        this.ctgNumber = ctgNumber;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public Integer getEstimatedWeight() {
        return estimatedWeight;
    }

    public void setEstimatedWeight(Integer estimatedWeight) {
        this.estimatedWeight = estimatedWeight;
    }

    public String getTransportTruck() {
        return transportTruck;
    }

    public void setTransportTruck(String transportTruck) {
        this.transportTruck = transportTruck;
    }

    public String getTransportTruckTrailer() {
        return transportTruckTrailer;
    }

    public void setTransportTruckTrailer(String transportTruckTrailer) {
        this.transportTruckTrailer = transportTruckTrailer;
    }

    public BigDecimal getTransportFeeReference() {
        return transportFeeReference;
    }

    public void setTransportFeeReference(BigDecimal transportFeeReference) {
        this.transportFeeReference = transportFeeReference;
    }

    public BigDecimal getTransportFee() {
        return transportFee;
    }

    public void setTransportFee(BigDecimal transportFee) {
        this.transportFee = transportFee;
    }

    public Boolean isTransportPayed() {
        return transportPayed;
    }

    public void setTransportPayed(Boolean transportPayed) {
        this.transportPayed = transportPayed;
    }

    public Boolean isTransportToBePayed() {
        return transportToBePayed;
    }

    public void setTransportToBePayed(Boolean transportToBePayed) {
        this.transportToBePayed = transportToBePayed;
    }

    public String getDownloadDischargeDateTime() {
        return downloadDischargeDateTime;
    }

    public void setDownloadDischargeDateTime(String downloadDischargeDateTime) {
        this.downloadDischargeDateTime = downloadDischargeDateTime;
    }

    public String getCropQuality() {
        return cropQuality;
    }

    public void setCropQuality(String cropQuality) {
        this.cropQuality = cropQuality;
    }

    public String getDownloadOrderNumber() {
        return downloadOrderNumber;
    }

    public void setDownloadOrderNumber(String downloadOrderNumber) {
        this.downloadOrderNumber = downloadOrderNumber;
    }

    public String getDischargeQualityObservations() {
        return dischargeQualityObservations;
    }

    public void setDischargeQualityObservations(String dischargeQualityObservations) {
        this.dischargeQualityObservations = dischargeQualityObservations;
    }

    public QualityItemBean[] getQualityItems() {
        return qualityItems;
    }

    public void setQualityItems(QualityItemBean... qualityItems) {
        this.qualityItems = qualityItems;
    }

    public Boolean getTransportPayed() {
        return transportPayed;
    }

    public Boolean getTransportToBePayed() {
        return transportToBePayed;
    }

    public String getQualityDetails() {
        return qualityDetails;
    }

    public void setQualityDetails(String qualityDetails) {
        this.qualityDetails = qualityDetails;
    }

}
