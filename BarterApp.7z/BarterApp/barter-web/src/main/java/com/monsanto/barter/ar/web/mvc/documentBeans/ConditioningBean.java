package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author jpbeni
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConditioningBean extends DocumentBean {

    @JsonProperty
    private String invoiceType;

    @JsonProperty
    private String contractNumber;

    @JsonProperty
    private String contractType;

    @JsonProperty
    private String grower;

    @JsonProperty
    private String port;

    @JsonProperty
    private Float tax;

    @JsonProperty
    private String currency;

    @JsonProperty
    private String optionalField1;

    @JsonProperty
    private String optionalField2;

    @JsonProperty
    private ConditioningItemBean[] items;

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getGrower() {
        return grower;
    }

    public void setGrower(String grower) {
        this.grower = grower;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public Float getTax() {
        return tax;
    }

    public void setTax(Float tax) {
        this.tax = tax;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOptionalField1() {
        return optionalField1;
    }

    public void setOptionalField1(String optionalField1) {
        this.optionalField1 = optionalField1;
    }

    public String getOptionalField2() {
        return optionalField2;
    }

    public void setOptionalField2(String optionalField2) {
        this.optionalField2 = optionalField2;
    }

    public ConditioningItemBean[] getItems() {
        return items;
    }

    public void setItems(ConditioningItemBean... items) {
        this.items = items;
    }

}
