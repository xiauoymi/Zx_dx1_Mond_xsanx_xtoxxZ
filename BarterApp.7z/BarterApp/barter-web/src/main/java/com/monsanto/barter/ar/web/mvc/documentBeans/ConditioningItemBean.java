package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.monsanto.barter.ar.business.entity.ConditioningItem;

/**
 * @author jpbeni
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName(value = "conditioningItem")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConditioningItemBean extends DocumentBean<ConditioningItem>{

    @JsonProperty
    private Integer item;

    /** Document number */
    @JsonProperty
    private String number;

    /** RT, ADD, BOL */
    @JsonProperty
    private String documentType;

    @JsonProperty
    private Float quantity;

    @JsonProperty
    private String baseUnit;

    @JsonProperty
    private Float pricePerUnit;

    public ConditioningItemBean() {
    }

    public Integer getItem() {
        return item;
    }

    public void setItem(Integer item) {
        this.item = item;
    }

    public Float getQuantity() {
        return quantity;
    }

    public void setQuantity(Float quantity) {
        this.quantity = quantity;
    }

    public String getBaseUnit() {
        return baseUnit;
    }

    public void setBaseUnit(String baseUnit) {
        this.baseUnit = baseUnit;
    }

    public Float getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(Float pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
}
