package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.Delivery;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeliveryBean extends DocumentBean <Delivery> {

    /** Reference Document Number */
    @JsonProperty
    private String formNumber;

    /** Reference Document Number */
    @JsonProperty
    private String cac;

    /** Due Date */
    @JsonProperty
    private String dueDate;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String depositor;

    /** Material Number */
    @JsonProperty
    private String cropType;

    /**  */
    @JsonProperty
    private Float zarandeo;

    @JsonProperty
    private Float dryingFrom;

    @JsonProperty
    private Float dryingTo;

    @JsonProperty
    private Float dryingFee;

    @JsonProperty
    private Float excessFee;

    @JsonProperty
    private Float otherDeliveryExpenses;

    /** Origin Storage Location, The Warehouse (WH##) code of the port */
    @JsonProperty
    private String originPort;

    /** Delivery Storage Location, The Warehouse (WH##) code of the port */
    @JsonProperty
    private String deliveryPort;

    @JsonProperty
    private String deliveryDate;

    /** Standard quality */
    @JsonProperty
    private Float qualityDegree;

    @JsonProperty
    private Float proteinContent;

    @JsonProperty
    private Float qualityFactor;

    @JsonProperty
    private Float grossWeight;

    @JsonProperty
    private Float dryingRate;

    @JsonProperty
    private Float zarandeoRate;

    @JsonProperty
    private Float otherRate;

    @JsonProperty
    private Float liquidation;

    @JsonProperty // the externalId will be set here
    private String optionalField1;

    @JsonProperty
    private String createdDate;

    @JsonProperty // the SAP last modification date will be set here
    private String optionalField2;

    @JsonProperty
    private UnloadBean[] unloads;

    public String getFormNumber() {
        return formNumber;
    }

    public void setFormNumber(String formNumber) {
        this.formNumber = formNumber;
    }

    public String getCac() {
        return cac;
    }

    public void setCac(String cac) {
        this.cac = cac;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getDepositor() {
        return depositor;
    }

    public void setDepositor(String depositor) {
        this.depositor = depositor;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public Float getZarandeo() {
        return zarandeo;
    }

    public void setZarandeo(Float zarandeo) {
        this.zarandeo = zarandeo;
    }

    public Float getDryingFrom() {
        return dryingFrom;
    }

    public void setDryingFrom(Float dryingFrom) {
        this.dryingFrom = dryingFrom;
    }

    public Float getDryingTo() {
        return dryingTo;
    }

    public void setDryingTo(Float dryingTo) {
        this.dryingTo = dryingTo;
    }

    public Float getDryingFee() {
        return dryingFee;
    }

    public void setDryingFee(Float dryingFee) {
        this.dryingFee = dryingFee;
    }

    public Float getExcessFee() {
        return excessFee;
    }

    public void setExcessFee(Float excessFee) {
        this.excessFee = excessFee;
    }

    public Float getOtherDeliveryExpenses() {
        return otherDeliveryExpenses;
    }

    public void setOtherDeliveryExpenses(Float otherDeliveryExpenses) {
        this.otherDeliveryExpenses = otherDeliveryExpenses;
    }

    public String getOriginPort() {
        return originPort;
    }

    public void setOriginPort(String originPort) {
        this.originPort = originPort;
    }

    public String getDeliveryPort() {
        return deliveryPort;
    }

    public void setDeliveryPort(String deliveryPort) {
        this.deliveryPort = deliveryPort;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Float getQualityDegree() {
        return qualityDegree;
    }

    public void setQualityDegree(Float qualityDegree) {
        this.qualityDegree = qualityDegree;
    }

    public Float getProteinContent() {
        return proteinContent;
    }

    public void setProteinContent(Float proteinContent) {
        this.proteinContent = proteinContent;
    }

    public Float getQualityFactor() {
        return qualityFactor;
    }

    public void setQualityFactor(Float qualityFactor) {
        this.qualityFactor = qualityFactor;
    }

    public Float getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Float grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Float getDryingRate() {
        return dryingRate;
    }

    public void setDryingRate(Float dryingRate) {
        this.dryingRate = dryingRate;
    }

    public Float getZarandeoRate() {
        return zarandeoRate;
    }

    public void setZarandeoRate(Float zarandeoRate) {
        this.zarandeoRate = zarandeoRate;
    }

    public Float getOtherRate() {
        return otherRate;
    }

    public void setOtherRate(Float otherRate) {
        this.otherRate = otherRate;
    }

    public Float getLiquidation() {
        return liquidation;
    }

    public void setLiquidation(Float liquidation) {
        this.liquidation = liquidation;
    }

    public String getOptionalField1() {
        return optionalField1;
    }

    public void setOptionalField1(String optionalField1) {
        this.optionalField1 = optionalField1;
    }

    public UnloadBean[] getUnloads() {
        return unloads;
    }

    public void setUnloads(UnloadBean... unloads) {
        this.unloads = unloads;
    }

    @Override
    public String getCreatedDate() {
        return createdDate;
    }

    @Override
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getOptionalField2() {
        return optionalField2;
    }

    public void setOptionalField2(String optionalField2) {
        this.optionalField2 = optionalField2;
    }
}
