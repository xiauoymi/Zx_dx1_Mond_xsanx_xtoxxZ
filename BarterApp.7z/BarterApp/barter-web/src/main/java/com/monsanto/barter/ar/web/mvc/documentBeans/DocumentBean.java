package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.monsanto.barter.ar.business.entity.BaseEntity;
import com.monsanto.barter.ar.web.mvc.documentBeans.enumerated.Operation;

import static com.fasterxml.jackson.annotation.JsonSubTypes.Type;

/**
 * @author JPBENI
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonSubTypes({
        @Type(value = GrowerContractBean.class, name = "growerContract"),
        @Type(value = DeliveryBean.class, name = "delivery"),
        @Type(value = LiquidationBean.class, name = "liquidation"),
        @Type(value = FinalLiquidationBean.class, name = "finalLiquidation"),
        @Type(value = PartialLiquidationBean.class, name = "partialLiquidation"),
        @Type(value = ConditioningBean.class, name="conditioning"),
        @Type(value = AddendaBean.class, name="addenda"),
        @Type(value = RTBean.class, name="RT"),
        @Type(value = BillOfLadingBean.class, name="billOfLading"),
        @Type(value = BillOfLadingTrainBean.class, name="billOfLadingTrain"),
        @Type(value = BillOfLadingTruckBean.class, name="billOfLadingTruck")
})
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class DocumentBean <E extends BaseEntity> {

    @JsonProperty
    private String createdDate;

    @JsonProperty
    private String lastUpdateDate;

    /** External (SAP) reference id, required, must be unique. */
    @JsonProperty("documentId")
    private String externalId;

    @JsonProperty
    private Operation operation;

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }
}
