package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.FinalLiquidation;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FinalLiquidationBean extends LiquidationBean <FinalLiquidation> {

    @JsonProperty
    private String brokerInvolved;

    @JsonProperty
    private String originalLiquidationId;

    @JsonProperty
    private Float grossWeight;

    public String getBrokerInvolved() {
        return brokerInvolved;
    }

    public void setBrokerInvolved(String brokerInvolved) {
        this.brokerInvolved = brokerInvolved;
    }

    public String getOriginalLiquidationId() {
        return originalLiquidationId;
    }

    public void setOriginalLiquidationId(String originalLiquidationId) {
        this.originalLiquidationId = originalLiquidationId;
    }

    public Float getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Float grossWeight) {
        this.grossWeight = grossWeight;
    }

}
