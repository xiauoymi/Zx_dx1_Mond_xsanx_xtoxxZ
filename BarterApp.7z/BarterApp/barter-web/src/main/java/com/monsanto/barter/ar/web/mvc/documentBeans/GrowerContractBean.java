package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.GrowerContract;

/**
 * @author JPBENI
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GrowerContractBean extends DocumentBean <GrowerContract>{

    /** SAP Contract Type, required. */
    @JsonProperty
    private String growerContractType;

    /** Reference (download) SAP id for the GrowerContract, required. */
    @JsonProperty
    private String sapDocumentId;

    /** Id for the invoice, required. */
    @JsonProperty
    private String invoiceSapId;

    /** Reference (download) SAP id for the invoice, required. */
    @JsonProperty
    private String invoiceSapDocumentId;

    /** POS ID (CUSTOMER ID), optional. */
    @JsonProperty
    private String customerPos;

    /** Grower ID (CUSTOMER ID), required. */
    @JsonProperty
    private String grower;

    /** Delivery date, required. */
    @JsonProperty
    private String deliveryDate;

    /** Quantity of units sold in the contract, required and greater than zero. */
    @JsonProperty
    private Double quantity;

    /** The Warehouse (WH##) code of the port, required. */
    @JsonProperty
    private String port;

    /** Material number */
    @JsonProperty
    private String cropType;

    /** Cumulative Order Quantity in Sales Units */
    @JsonProperty
    private Double orderQuantity;

    /** Tax Rate (condition amount or percentage) */
    @JsonProperty
    private Float tax;

    /** Price per Tn (condition amount or percentage) */
    @JsonProperty
    private Float priceByTonel;

    /** Base Unit of Measure */
    @JsonProperty
    private String baseUnit;

    /** Net Value in Document Currency */
    @JsonProperty
    private Double netValue;

    public String getGrowerContractType() {
        return growerContractType;
    }

    public void setGrowerContractType(String growerContractType) {
        this.growerContractType = growerContractType;
    }

    public String getSapDocumentId() {
        return sapDocumentId;
    }

    public void setSapDocumentId(String sapDocumentId) {
        this.sapDocumentId = sapDocumentId;
    }

    public String getInvoiceSapId() {
        return invoiceSapId;
    }

    public void setInvoiceSapId(String invoiceSapId) {
        this.invoiceSapId = invoiceSapId;
    }

    public String getInvoiceSapDocumentId() {
        return invoiceSapDocumentId;
    }

    public void setInvoiceSapDocumentId(String invoiceSapDocumentId) {
        this.invoiceSapDocumentId = invoiceSapDocumentId;
    }

    public String getCustomerPos() {
        return customerPos;
    }

    public void setCustomerPos(String customerPos) {
        this.customerPos = customerPos;
    }

    public String getGrower() {
        return grower;
    }

    public void setGrower(String grower) {
        this.grower = grower;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public Double getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(Double orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public Float getTax() {
        return tax;
    }

    public void setTax(Float tax) {
        this.tax = tax;
    }

    public Float getPriceByTonel() {
        return priceByTonel;
    }

    public void setPriceByTonel(Float priceByTonel) {
        this.priceByTonel = priceByTonel;
    }

    public String getBaseUnit() {
        return baseUnit;
    }

    public void setBaseUnit(String baseUnit) {
        this.baseUnit = baseUnit;
    }

    public Double getNetValue() {
        return netValue;
    }

    public void setNetValue(Double netValue) {
        this.netValue = netValue;
    }

}
