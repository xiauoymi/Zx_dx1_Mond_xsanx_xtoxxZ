package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.Liquidation;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class LiquidationBean <T extends Liquidation> extends DocumentBean <T> {

    @JsonProperty
    private String coe;

    @JsonProperty
    private String documentType;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String seller;

    @JsonProperty
    private Float amountIVA;

    @JsonProperty
    private Float operationPrice;

    /** Material number */
    @JsonProperty
    private String cropType;

    /** The Warehouse (WH##) code of the port, required. */
    @JsonProperty
    private String port;

    @JsonProperty
    private Float qualityFactor;

    @JsonProperty
    private Float priceByTonel;

    @JsonProperty
    private Float subtotal;

    @JsonProperty
    private Float total;

    @JsonProperty
    private Float aliquotIVA;

    @JsonProperty
    private Float netAmount;

    @JsonProperty
    private Float usdAmount;

    @JsonProperty
    private String document;

    @JsonProperty
    private String localization;

    @JsonProperty
    private String payment;

    @JsonProperty
    private String paymentDate;

    /** POS ID (CUSTOMER ID), optional. */
    @JsonProperty
    private String pos;

    @JsonProperty
    private String commercialOperation;

    @JsonProperty
    private String proteicContent;

    @JsonProperty
    private String operationType;

    @JsonProperty
    private String qualityGrade;

    @JsonProperty
    private Float subtotalAdj;

    @JsonProperty
    private Float amountIVAAdj;

    @JsonProperty
    private String voucher;

    @JsonProperty
    private String procMerc;

    /** Reference to grower contract unique sap id */
    @JsonProperty
    private String growerContract;

    @JsonProperty
    private String harvest;

    @JsonProperty
    private String optionalField1;

    @JsonProperty
    private String optionalField2;

    public String getCoe() {
        return coe;
    }

    public void setCoe(String coe) {
        this.coe = coe;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public Float getAmountIVA() {
        return amountIVA;
    }

    public void setAmountIVA(Float amountIVA) {
        this.amountIVA = amountIVA;
    }

    public Float getOperationPrice() {
        return operationPrice;
    }

    public void setOperationPrice(Float operationPrice) {
        this.operationPrice = operationPrice;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public Float getQualityFactor() {
        return qualityFactor;
    }

    public void setQualityFactor(Float qualityFactor) {
        this.qualityFactor = qualityFactor;
    }

    public Float getPriceByTonel() {
        return priceByTonel;
    }

    public void setPriceByTonel(Float priceByTonel) {
        this.priceByTonel = priceByTonel;
    }

    public Float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Float subtotal) {
        this.subtotal = subtotal;
    }

    public Float getTotal() {
        return total;
    }

    public void setTotal(Float total) {
        this.total = total;
    }

    public Float getAliquotIVA() {
        return aliquotIVA;
    }

    public void setAliquotIVA(Float aliquotIVA) {
        this.aliquotIVA = aliquotIVA;
    }

    public Float getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(Float netAmount) {
        this.netAmount = netAmount;
    }

    public Float getUsdAmount() {
        return usdAmount;
    }

    public void setUsdAmount(Float usdAmount) {
        this.usdAmount = usdAmount;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getLocalization() {
        return localization;
    }

    public void setLocalization(String localization) {
        this.localization = localization;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public String getCommercialOperation() {
        return commercialOperation;
    }

    public void setCommercialOperation(String commercialOperation) {
        this.commercialOperation = commercialOperation;
    }

    public String getProteicContent() {
        return proteicContent;
    }

    public void setProteicContent(String proteicContent) {
        this.proteicContent = proteicContent;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getQualityGrade() {
        return qualityGrade;
    }

    public void setQualityGrade(String qualityGrade) {
        this.qualityGrade = qualityGrade;
    }

    public Float getSubtotalAdj() {
        return subtotalAdj;
    }

    public void setSubtotalAdj(Float subtotalAdj) {
        this.subtotalAdj = subtotalAdj;
    }

    public Float getAmountIVAAdj() {
        return amountIVAAdj;
    }

    public void setAmountIVAAdj(Float amountIVAAdj) {
        this.amountIVAAdj = amountIVAAdj;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public String getProcMerc() {
        return procMerc;
    }

    public void setProcMerc(String procMerc) {
        this.procMerc = procMerc;
    }

    public String getGrowerContract() {
        return growerContract;
    }

    public void setGrowerContract(String growerContract) {
        this.growerContract = growerContract;
    }

    public String getHarvest() {
        return harvest;
    }

    public void setHarvest(String harvest) {
        this.harvest = harvest;
    }

    public String getOptionalField1() {
        return optionalField1;
    }

    public void setOptionalField1(String optionalField1) {
        this.optionalField1 = optionalField1;
    }

    public String getOptionalField2() {
        return optionalField2;
    }

    public void setOptionalField2(String optionalField2) {
        this.optionalField2 = optionalField2;
    }
}
