package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.PartialLiquidation;
import com.monsanto.barter.ar.web.mvc.beans.LiquidationUnloadBean;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PartialLiquidationBean extends LiquidationBean <PartialLiquidation> {

    @JsonProperty
    private LiquidationUnloadBean[] unloads;

    public LiquidationUnloadBean[] getUnloads() {
        return unloads;
    }

    public void setUnloads(LiquidationUnloadBean... unloads) {
        this.unloads = unloads;
    }

}
