package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.monsanto.barter.ar.business.entity.GrainTransfer;

import java.math.BigDecimal;

/**
 * @author VNBARR
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RTBean extends DocumentBean <GrainTransfer> {

    @JsonProperty
    private String number;

    @JsonProperty
    private BigDecimal price;

    @JsonProperty
    private String generationDate;

    @JsonProperty
    private String dueDate;

    @JsonProperty
    private Long depositaryCACNumber;

    @JsonProperty
    private String depositaryCuitNumber;

    @JsonProperty
    private String depositaryName;

    @JsonProperty
    private String depositaryActivity;

    /** Id from BAR_RSP_VAT */
    @JsonProperty
    private String depositaryRspVat;

    @JsonProperty
    private String depositaryAddress;

    /** City Afip Id */
    @JsonProperty
    private String depositaryCity;

    @JsonProperty
    private Long depositaryONCCAOpNumber;

    @JsonProperty
    private Long ONCCAPlantNumber;

    @JsonProperty
    private boolean laTijereta;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String depositor;

    /** Id from BAR_RSP_VAT */
    @JsonProperty
    private String depositorRspVat;

    @JsonProperty
    private String depositorAddress;

    /** City Afip Id */
    @JsonProperty
    private String depositorCity;

    /** CUSTOMER_ID  */
    @JsonProperty
    private String receptor;

    /** Id from BAR_RSP_VAT */
    @JsonProperty
    private String receptorRspVat;

    @JsonProperty
    private String receptorActivity;

    @JsonProperty
    private String receptorAddress;

    /** City Afip Id */
    @JsonProperty
    private String receptorCity;

    @JsonProperty
    private Long receptorONCCAOpNumber;

    @JsonProperty
    private String detailDate;

    @JsonProperty
    private String detailC1116A;

    /** Material Number */
    @JsonProperty
    private String cropType;

    @JsonProperty
    private Long detailCode;

    @JsonProperty
    private Long detailWeightToTransfer;

    @JsonProperty
    private Boolean okBroker;

    @JsonProperty
    private Boolean okPos;

    @JsonProperty
    private Boolean okQuality;

    @JsonProperty
    private Boolean okYield;

    @JsonProperty
    private String sapCreationDate;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Boolean getOkBroker() {
        return okBroker;
    }

    public void setOkBroker(Boolean okBroker) {
        this.okBroker = okBroker;
    }

    public Boolean getOkPos() {
        return okPos;
    }

    public void setOkPos(Boolean okPos) {
        this.okPos = okPos;
    }

    public Boolean getOkQuality() {
        return okQuality;
    }

    public void setOkQuality(Boolean okQuality) {
        this.okQuality = okQuality;
    }

    public Boolean getOkYield() {
        return okYield;
    }

    public void setOkYield(Boolean okYield) {
        this.okYield = okYield;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getGenerationDate() {
        return generationDate;
    }

    public void setGenerationDate(String generationDate) {
        this.generationDate = generationDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Long getDepositaryCACNumber() {
        return depositaryCACNumber;
    }

    public void setDepositaryCACNumber(Long depositaryCACNumber) {
        this.depositaryCACNumber = depositaryCACNumber;
    }

    public String getDepositaryCuitNumber() {
        return depositaryCuitNumber;
    }

    public void setDepositaryCuitNumber(String depositaryCuitNumber) {
        this.depositaryCuitNumber = depositaryCuitNumber;
    }

    public String getDepositaryName() {
        return depositaryName;
    }

    public void setDepositaryName(String depositaryName) {
        this.depositaryName = depositaryName;
    }

    public String getDepositaryActivity() {
        return depositaryActivity;
    }

    public void setDepositaryActivity(String depositaryActivity) {
        this.depositaryActivity = depositaryActivity;
    }

    public String getDepositaryRspVat() {
        return depositaryRspVat;
    }

    public void setDepositaryRspVat(String depositaryRspVat) {
        this.depositaryRspVat = depositaryRspVat;
    }

    public String getDepositaryAddress() {
        return depositaryAddress;
    }

    public void setDepositaryAddress(String depositaryAddress) {
        this.depositaryAddress = depositaryAddress;
    }

    public String getDepositaryCity() {
        return depositaryCity;
    }

    public void setDepositaryCity(String depositaryCity) {
        this.depositaryCity = depositaryCity;
    }

    public Long getDepositaryONCCAOpNumber() {
        return depositaryONCCAOpNumber;
    }

    public void setDepositaryONCCAOpNumber(Long depositaryONCCAOpNumber) {
        this.depositaryONCCAOpNumber = depositaryONCCAOpNumber;
    }

    public Long getONCCAPlantNumber() {
        return ONCCAPlantNumber;
    }

    public void setONCCAPlantNumber(Long ONCCAPlantNumber) {
        this.ONCCAPlantNumber = ONCCAPlantNumber;
    }

    public boolean isLaTijereta() {
        return laTijereta;
    }

    public void setLaTijereta(boolean laTijereta) {
        this.laTijereta = laTijereta;
    }

    public String getDepositor() {
        return depositor;
    }

    public void setDepositor(String depositor) {
        this.depositor = depositor;
    }

    public String getDepositorRspVat() {
        return depositorRspVat;
    }

    public void setDepositorRspVat(String depositorRspVat) {
        this.depositorRspVat = depositorRspVat;
    }

    public String getDepositorAddress() {
        return depositorAddress;
    }

    public void setDepositorAddress(String depositorAddress) {
        this.depositorAddress = depositorAddress;
    }

    public String getDepositorCity() {
        return depositorCity;
    }

    public void setDepositorCity(String depositorCity) {
        this.depositorCity = depositorCity;
    }

    public String getReceptor() {
        return receptor;
    }

    public void setReceptor(String receptor) {
        this.receptor = receptor;
    }

    public String getReceptorRspVat() {
        return receptorRspVat;
    }

    public void setReceptorRspVat(String receptorRspVat) {
        this.receptorRspVat = receptorRspVat;
    }

    public String getReceptorActivity() {
        return receptorActivity;
    }

    public void setReceptorActivity(String receptorActivity) {
        this.receptorActivity = receptorActivity;
    }

    public String getReceptorAddress() {
        return receptorAddress;
    }

    public void setReceptorAddress(String receptorAddress) {
        this.receptorAddress = receptorAddress;
    }

    public String getReceptorCity() {
        return receptorCity;
    }

    public void setReceptorCity(String receptorCity) {
        this.receptorCity = receptorCity;
    }

    public Long getReceptorONCCAOpNumber() {
        return receptorONCCAOpNumber;
    }

    public void setReceptorONCCAOpNumber(Long receptorONCCAOpNumber) {
        this.receptorONCCAOpNumber = receptorONCCAOpNumber;
    }

    public String getDetailDate() {
        return detailDate;
    }

    public void setDetailDate(String detailDate) {
        this.detailDate = detailDate;
    }

    public String getDetailC1116A() {
        return detailC1116A;
    }

    public void setDetailC1116A(String detailC1116A) {
        this.detailC1116A = detailC1116A;
    }

    public String getCropType() {
        return cropType;
    }

    public void setCropType(String cropType) {
        this.cropType = cropType;
    }

    public Long getDetailCode() {
        return detailCode;
    }

    public void setDetailCode(Long detailCode) {
        this.detailCode = detailCode;
    }

    public Long getDetailWeightToTransfer() {
        return detailWeightToTransfer;
    }

    public void setDetailWeightToTransfer(Long detailWeightToTransfer) {
        this.detailWeightToTransfer = detailWeightToTransfer;
    }

    public String getSapCreationDate() {
        return sapCreationDate;
    }

    public void setSapCreationDate(String sapCreationDate) {
        this.sapCreationDate = sapCreationDate;
    }
}
