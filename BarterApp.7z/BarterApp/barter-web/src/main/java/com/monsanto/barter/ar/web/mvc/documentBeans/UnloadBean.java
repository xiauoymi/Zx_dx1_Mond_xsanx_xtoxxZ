package com.monsanto.barter.ar.web.mvc.documentBeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.monsanto.barter.ar.business.entity.Unload;

/**
 * @author VNBARR
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "class")
@JsonTypeName(value = "unload")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UnloadBean extends DocumentBean <Unload> {

    @JsonProperty
    private Integer item;

    @JsonProperty
    private String unloadDate;

    /** Document number */
    @JsonProperty
    private String number;

    /** RT, ADD, BOL */
    @JsonProperty
    private String documentType;

    @JsonProperty
    private Double grossWeight;

    @JsonProperty
    private Float zarandeoWeight;

    @JsonProperty
    private Float zarandeoRate;

    @JsonProperty
    private Float zarandeoAmount;

    @JsonProperty
    private Float dryingWetPercentage;

    @JsonProperty
    private Float dryingWeight;

    @JsonProperty
    private Float dryingRate;

    @JsonProperty
    private Float dryingAmount;

    /** Reference to SAP unique code for delivery */
    @JsonProperty
    private String deliverySapId;

    public String getUnloadDate() {
        return unloadDate;
    }

    public void setUnloadDate(String unloadDate) {
        this.unloadDate = unloadDate;
    }

    public Double getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Double grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Float getZarandeoWeight() {
        return zarandeoWeight;
    }

    public void setZarandeoWeight(Float zarandeoWeight) {
        this.zarandeoWeight = zarandeoWeight;
    }

    public Float getZarandeoRate() {
        return zarandeoRate;
    }

    public void setZarandeoRate(Float zarandeoRate) {
        this.zarandeoRate = zarandeoRate;
    }

    public Float getZarandeoAmount() {
        return zarandeoAmount;
    }

    public void setZarandeoAmount(Float zarandeoAmount) {
        this.zarandeoAmount = zarandeoAmount;
    }

    public Float getDryingWetPercentage() {
        return dryingWetPercentage;
    }

    public void setDryingWetPercentage(Float dryingWetPercentage) {
        this.dryingWetPercentage = dryingWetPercentage;
    }

    public Float getDryingWeight() {
        return dryingWeight;
    }

    public void setDryingWeight(Float dryingWeight) {
        this.dryingWeight = dryingWeight;
    }

    public Float getDryingRate() {
        return dryingRate;
    }

    public void setDryingRate(Float dryingRate) {
        this.dryingRate = dryingRate;
    }

    public Float getDryingAmount() {
        return dryingAmount;
    }

    public void setDryingAmount(Float dryingAmount) {
        this.dryingAmount = dryingAmount;
    }

    public String getDeliverySapId() {
        return deliverySapId;
    }

    public void setDeliverySapId(String deliverySapId) {
        this.deliverySapId = deliverySapId;
    }

    public Integer getItem() {
        return item;
    }

    public void setItem(Integer item) {
        this.item = item;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
}
