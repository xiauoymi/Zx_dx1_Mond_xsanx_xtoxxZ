package com.monsanto.barter.ar.web.mvc.documentBeans.enumerated;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Represents the operation for Document from SAP in barter.
 * @author jasanc5
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum Operation {
    CREATE("c"),
    UPDATE("m"), // is defined as modification in SAP
    DELETE("d");

    private String name;

    private Operation(final String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}