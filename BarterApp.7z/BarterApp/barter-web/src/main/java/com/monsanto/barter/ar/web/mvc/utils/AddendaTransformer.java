package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.enumerated.AdendaState;
import com.monsanto.barter.ar.business.service.CityAfipLasService;
import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.web.mvc.documentBeans.AddendaBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class AddendaTransformer extends EntityTransformer<Adenda, AddendaBean> {

    private static final Logger LOG = LoggerFactory.getLogger(AddendaTransformer.class);

    @Autowired
    CityAfipLasService cityAfipLasService;

    @Autowired
    CustomerLasService customerLasService;

    @Autowired
    MaterialLasService materialLasService;

    @Override
    public Adenda createEntity() {
        return new Adenda();
    }

    @Override
    public void updateEntity(Adenda entity, AddendaBean bean) {
        try {
            entity.setState(AdendaState.MIGRATED_FROM_SAP);
            entity.setCreatedDate(dateStringToDate(bean.getCreatedDate()));
            entity.setLastUpdateDate(dateStringToDate(bean.getLastUpdateDate()));
            entity.setIdSap(bean.getNumber());
            entity.setSapAudit(createSapAudit(bean.getSapCreationDate(), null));
            if (bean.getGenerationDate()!=null){
                entity.setGenerationDate(dateStringToDate(bean.getGenerationDate()));
            }
            if (bean.getCity() != null) {
                entity.setCity(cityAfipLasService.get(bean.getCity()));
            }
            entity.setDepositaryName(bean.getDepositaryName());
            entity.setBrokerName(bean.getBrokerName());
            if (bean.getSender() != null) {
                entity.setSender(customerLasService.get(bean.getSender()));
            }
            entity.setNotes(bean.getNotes());
            entity.setLaTijereta(bean.isLaTijereta());
            if (bean.getReceptor() != null) {
                entity.setReceptor(customerLasService.get(bean.getReceptor()));
            }
            if (bean.getCropType() != null) {
                entity.setCropType(materialLasService.getByNumber(bean.getCropType()));
            }
            entity.setWeightToTransfer(bean.getWeightToTransfer());
            if (bean.getOkBroker()!= null){
                entity.setOkBroker(bean.getOkBroker());
            } else{
                entity.setOkBroker(false);
            }

            if (bean.getOkYield()!= null){
                entity.setOkYield(bean.getOkYield());
            } else{
                entity.setOkYield(false);
            }

            if (bean.getOkPos()!= null){
                entity.setOkPos(bean.getOkPos());
            } else{
                entity.setOkPos(false);
            }

            if (bean.getOkQuality()!= null){
                entity.setOkQuality(bean.getOkQuality());
            } else{
                entity.setOkQuality(false);
            }
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Addenda: ", e);
        }

    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
