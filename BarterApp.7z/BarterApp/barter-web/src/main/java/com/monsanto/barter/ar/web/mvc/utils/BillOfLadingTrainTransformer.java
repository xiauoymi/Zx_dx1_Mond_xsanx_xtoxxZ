package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import com.monsanto.barter.ar.business.entity.BillOfLadingTrain;
import com.monsanto.barter.ar.business.entity.Wagon;
import com.monsanto.barter.ar.web.mvc.beans.QualityItemBean;
import com.monsanto.barter.ar.web.mvc.beans.WagonBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.BillOfLadingTrainBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class BillOfLadingTrainTransformer extends BillOfLadingTransformer<BillOfLadingTrain, BillOfLadingTrainBean> {
    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingTrainTransformer.class);
    @Override
    public BillOfLadingTrain createEntity() {
        return new BillOfLadingTrain();
    }

    @Override
    public void updateEntity(BillOfLadingTrain billOfLadingTrain,BillOfLadingTrainBean bean) {
        try {
            transformToBillOfLadingEntity(billOfLadingTrain,bean);
            billOfLadingTrain.setLaidDate(dateStringToDate(bean.getLaidDate()));
            billOfLadingTrain.setLoadEndDate(dateStringToDate(bean.getLoadEndDate()));
            billOfLadingTrain.setOperativeNumber(bean.getOperativeNumber());
            billOfLadingTrain.setDispatchedWagons(bean.getDispatchedWagons());
            billOfLadingTrain.setExchangeTo(bean.getExchangeTo());
            billOfLadingTrain.setTransshipmentTo(bean.getTransshipmentTo());
            billOfLadingTrain.setExchangeToDate(dateStringToDate(bean.getExchangeToDate()));
            billOfLadingTrain.setExchangeToPlace(bean.getExchangeToPlace());
            billOfLadingTrain.setTransshipmentToDate(dateStringToDate(bean.getTransshipmentToDate()));
            billOfLadingTrain.setTransshipmentToPlace(bean.getTransshipmentToPlace());
            billOfLadingTrain.setOrderNumber(bean.getOrderNumber());
            billOfLadingTrain.setGuideNumber(bean.getGuideNumber());
            billOfLadingTrain.setTotalWeightDispatched(bean.getTotalWeightDispatched());
            billOfLadingTrain.setDownloadNetDeclared(bean.getDownloadNetDeclared());
            List<Wagon> wagons = new ArrayList<Wagon>();
            if (bean.getWagons()!=null){
                for (WagonBean aWagon: bean.getWagons()) {
                    wagons.add(convertWagon(billOfLadingTrain,aWagon));
                }
            }
            billOfLadingTrain.setWagons(wagons);
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming BillOfLadingTrain: ", e);
        }
    }

    private Wagon convertWagon(BillOfLadingTrain billOfLadingTrain, WagonBean wagonBean) {
        Wagon wagon = new Wagon();
        wagon.setBillOfLadingTrain(billOfLadingTrain);
        wagon.setWagonNumber(wagonBean.getWagonNumber());
        wagon.setGrossWeight(wagonBean.getGrossWeight());
        wagon.setTare(wagonBean.getTare());
        wagon.setGrossWeightOrigin(wagonBean.getGrossWeightOrigin());
        wagon.setTareOrigin(wagonBean.getTareOrigin());
        wagon.setQuality(wagonBean.getQuality());
        wagon.setDownloadDateTime(wagonBean.getDownloadDateTime());
        wagon.setQualityItems(convertQualityItems(wagon,wagonBean.getQualityItems()));
        wagon.setObservations(wagonBean.getObservations());
        return wagon;
    }

    private List<BillOfLadingQualityItem> convertQualityItems(Wagon wagon, QualityItemBean[] items) {
        List<BillOfLadingQualityItem> qualityItems = new ArrayList<BillOfLadingQualityItem>();
        if (items != null){
            for (QualityItemBean itemBean : items){
                BillOfLadingQualityItem qualityItem = convertQualityItem(itemBean);
                qualityItem.setWagon(wagon);
                qualityItems.add(qualityItem);
            }
        }
        return qualityItems;
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
