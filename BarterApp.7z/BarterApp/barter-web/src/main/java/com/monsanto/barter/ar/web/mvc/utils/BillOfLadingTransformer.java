package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.business.entity.BillOfLading;
import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import com.monsanto.barter.ar.business.entity.enumerated.BillOfLadingState;
import com.monsanto.barter.ar.business.entity.enumerated.QualityAttributes;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.mvc.beans.QualityItemBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.BillOfLadingBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author VNBARR
 */
public abstract class BillOfLadingTransformer<BOL extends BillOfLading, B extends BillOfLadingBean> extends EntityTransformer<BOL, B>  {

    @Autowired
    private CityAfipLasService cityAfipLasService;

    @Autowired
    private CustomerLasService customerLasService;

    @Autowired
    private MaterialLasService materialLasService;

    @Autowired
    private CerealTypeService cerealTypeService;

    @Autowired
    private VendorService vendorService;

    public BOL transformToBillOfLadingEntity(BOL bol, B bean){
        bol.setBillOfLadingState(BillOfLadingState.MIGRATED_FROM_SAP);
        bol.setLastUpdateDate(dateStringToDate(bean.getLastUpdateDate()));
        bol.setCeeNumber(bean.getCeeNumber());
        bol.setGenerationDate(dateStringToDate(bean.getGenerationDate()));
        bol.setNumber(bean.getNumber());
        bol.setDueDate(dateStringToDate(bean.getDueDate()));
        bol.setHolderIdentifier(bean.getHolder());
        bol.setSapAudit(createSapAudit(bean.getSapCreationDate(), null));
        if (bean.getHolder() != null) {
            bol.setHolder(customerLasService.get(bean.getHolder()));
        }
        bol.setMediatorCommercialIdentifier(bean.getMediator());
        if (bean.getMediator()!= null) {
            bol.setMediator(customerLasService.get(bean.getMediator()));
        }
        bol.setCommercialSenderIdentifier(bean.getCommercialSender());
        if (bean.getCommercialSender() != null) {
            bol.setCommercialSender(customerLasService.get(bean.getCommercialSender()));
        }
        bol.setCarrierIdentifier(bean.getCarrier());
        if(bean.getCarrier()!=null) {
            bol.setCarrier(customerLasService.get(bean.getCarrier()));
        }
        bol.setBrokerIdentifier(bean.getBroker());
        if (bean.getBroker()!= null) {
            bol.setBroker(customerLasService.get(bean.getBroker()));
        }
        bol.setAgentIdentifier(bean.getAgent());
        if (bean.getAgent()!=null){
            bol.setAgent(vendorService.getVendor(bean.getAgent()));
        }

        bol.setAddresseeIdentifier(bean.getAddressee());
        if(bean.getAddressee()!=null) {
            bol.setAddressee(customerLasService.get(bean.getAddressee()));
        }
        bol.setDestinationIdentifier(bean.getDestination());
        if(bean.getDestination()!=null) {
            bol.setDestination(customerLasService.get(bean.getDestination()));
        }
        bol.setExporterIdentifier(bean.getExporter());
        if(bean.getExporter()!=null) {
            bol.setExporter(customerLasService.get(bean.getExporter()));
        }
        if (bean.isDirect()!=null){
            bol.setDirect(bean.isDirect());
        } else{
            bol.setDirect(false);
        }
        if (bean.getCropType()!=null) {
            bol.setCropType(materialLasService.getByNumber(bean.getCropType()));
        }
        if(bean.getCropSubType()!=null) {
            bol.setCropSubType(cerealTypeService.get(bean.getCropSubType()));
        }
        bol.setCampaign(bean.getCampaign());
        bol.setObservations(bean.getObservations());
        if (bean.isLoadWeighedAtDestination() != null){
            bol.setLoadWeighedAtDestination(bean.isLoadWeighedAtDestination());
        }else{
            bol.setLoadWeighedAtDestination(false);
        }

        if (bean.isLaTijereta()!= null){
            bol.setLaTijereta(bean.isLaTijereta());
        }
        else {
            bol.setLaTijereta(false);
        }

        if (bean.isSpecifiesQuality()!=null){
            bol.setSpecifiesQuality(bean.isSpecifiesQuality());
        }else{
            bol.setSpecifiesQuality(false);
        }

        if (bean.isSatisfiedWithQuality()!=null){
            bol.setSatisfiedWithQuality(bean.isSatisfiedWithQuality());
        }else{
            bol.setSatisfiedWithQuality(false);
        }

        if (bean.isConditionallySatisfiedWithQuality()!=null){
            bol.setConditionallySatisfiedWithQuality(bean.isConditionallySatisfiedWithQuality());
        }else{
            bol.setConditionallySatisfiedWithQuality(false);
        }

        bol.setOriginNumber(bean.getOriginNumber());
        bol.setOriginAddress(bean.getOriginAddress());
        bol.setOriginZipCode(bean.getOriginZipCode());
        if (bean.getOriginCity()!=null) {
            bol.setOriginCity(cityAfipLasService.get(bean.getOriginCity()));
        }
        //bol.setBalance();
        bol.setDestinationAddress(bean.getDestinationAddress());
        bol.setDestinationNumber(bean.getDestinationNumber());
        bol.setDestinationZipCode(bean.getDestinationZipCode());
        if(bean.getDestinationCity()!=null) {
            bol.setDestinationCity(cityAfipLasService.get(bean.getDestinationCity()));
        }
        bol.setTransportDistanceKilometers(bean.getTransportDistanceKilometers());
        bol.setTransportPayerCommercial(bean.getTransportPayerCommercial());
        bol.setDownloadArrivalDateTime(dateStringToDate(bean.getDownloadArrivalDateTime()));
        bol.setDownloadObservations(bean.getDownloadObservations());
        bol.setDownloadChangeDestinationCommercialIdentifier(bean.getDownloadChangeDestination());
        if(bean.getDownloadChangeDestination()!=null) {
            bol.setDownloadChangeDestination(customerLasService.get(bean.getDownloadChangeDestination()));
        }
        bol.setDownloadChangeAddresseeCommercialIdentifier(bean.getDownloadChangeAddressee());
        if(bean.getDownloadChangeAddressee()!=null) {
            bol.setDownloadChangeAddressee(customerLasService.get(bean.getDownloadChangeAddressee()));
        }
        bol.setDownloadChangeAddress(bean.getDownloadChangeAddress());
        bol.setDownloadChangeDate(dateStringToDate(bean.getDownloadChangeDate()));
        bol.setDownloadChangePlantNumber(bean.getDownloadChangePlantNumber());
        bol.setDownloadChangeTransferOrderedBy(bean.getDownloadChangeTransferOrderedBy());
        bol.setDownloadChangeZipCode(bean.getDownloadChangeZipCode());
        if(bean.getDownloadChangeCity()!=null) {
            bol.setDownloadChangeCity(cityAfipLasService.get(bean.getDownloadChangeCity()));
        }
        bol.setGrossWeight(bean.getGrossWeight());
        bol.setTaraWeight(bean.getTaraWeight());
        bol.setDownloadGrossWeight(bean.getDownloadGrossWeight());
        bol.setDownloadTaraWeight(bean.getDownloadTaraWeight());
        bol.setContractNumber(bol.getContractNumber());
        if (bean.getOkBroker()!= null){
            bol.setOkBroker(bean.getOkBroker());
        } else{
            bol.setOkBroker(false);
        }

        if (bean.getOkYield()!= null){
            bol.setOkYield(bean.getOkYield());
        } else{
            bol.setOkYield(false);
        }

        if (bean.getOkPos()!= null){
            bol.setOkPos(bean.getOkPos());
        } else{
            bol.setOkPos(false);
        }

        if (bean.getOkQuality()!= null){
            bol.setOkQuality(bean.getOkQuality());
        } else{
            bol.setOkQuality(false);
        }

        return bol;
    }

    public BillOfLadingQualityItem convertQualityItem(QualityItemBean itemBean) {
       BillOfLadingQualityItem qualityItem = new BillOfLadingQualityItem();
       qualityItem.setAttribute(QualityAttributes.valueOf(itemBean.getAttribute()));
       qualityItem.setKilograms(itemBean.getKilograms());
       qualityItem.setPercentage(itemBean.getPercentage());
       return  qualityItem;
    }


    public CustomerLasService getCustomerLasService() {
        return customerLasService;
    }
}
