package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.BillOfLadingQualityItem;
import com.monsanto.barter.ar.business.entity.BillOfLadingTruck;
import com.monsanto.barter.ar.web.mvc.beans.QualityItemBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.BillOfLadingTruckBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class BillOfLadingTruckTransformer extends BillOfLadingTransformer<BillOfLadingTruck, BillOfLadingTruckBean> {
    private static final Logger LOG = LoggerFactory.getLogger(BillOfLadingTruckTransformer.class);
    @Override
    public BillOfLadingTruck createEntity() {
        return new BillOfLadingTruck();
    }

    private List<BillOfLadingQualityItem> convertQualityItems(BillOfLadingTruck bol, QualityItemBean[] items) {
        List<BillOfLadingQualityItem> qualityItems = new ArrayList<BillOfLadingQualityItem>();
        if (items!=null){
            for (QualityItemBean itemBean:items){
                BillOfLadingQualityItem qualityItem = convertQualityItem(itemBean);
                qualityItem.setBillOfLadingTruck(bol);
                qualityItems.add(qualityItem);
            }
        }

        return qualityItems;
    }

    @Override
    public void updateEntity(BillOfLadingTruck entity, BillOfLadingTruckBean bean) {
        try {
            transformToBillOfLadingEntity(entity,bean);
            entity.setCtgNumber(bean.getCtgNumber());
            entity.setDriverIdentifier(bean.getDriver());
            if (bean.getDriver()!=null) {
                entity.setDriver(getCustomerLasService().get(bean.getDriver()));
            }
            entity.setEstimatedWeight(bean.getEstimatedWeight());
            entity.setTransportTruck(bean.getTransportTruck());
            entity.setTransportTruckTrailer(bean.getTransportTruckTrailer());
            entity.setTransportFeeReference(bean.getTransportFeeReference());
            entity.setTransportFee(bean.getTransportFee());
            if (bean.isTransportPayed()!=null){
                entity.setTransportPayed(bean.isTransportPayed());
            }else{
                entity.setTransportPayed(false);
            }
            if (bean.isTransportToBePayed()!=null){
                entity.setTransportToBePayed(bean.isTransportToBePayed());
            }else{
                entity.setTransportToBePayed(false);
            }
            entity.setDownloadDischargeDateTime(dateStringToDate(bean.getDownloadDischargeDateTime()));
            entity.setCropQuality(bean.getCropQuality());
            entity.setDownloadOrderNumber(bean.getDownloadOrderNumber());
            entity.setDischargeQualityObservations(bean.getDischargeQualityObservations());

            entity.setQualityItems(convertQualityItems(entity, bean.getQualityItems()));
            entity.setQualityDetails(bean.getQualityDetails());
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming BillOfLadingTruck: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
