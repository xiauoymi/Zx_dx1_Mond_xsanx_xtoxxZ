package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.ConditioningItem;
import com.monsanto.barter.ar.web.mvc.documentBeans.ConditioningItemBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 12/18/2014
 */
@Component
public class ConditioningItemTransformer extends EntityTransformer<ConditioningItem, ConditioningItemBean> {
    private static final Logger LOG = LoggerFactory.getLogger(ConditioningItemTransformer.class);
    @Override
    protected ConditioningItem createEntity() {
        return new ConditioningItem();
    }

    @Override
    public void updateEntity(ConditioningItem entity, ConditioningItemBean bean) {
        try{
            entity.setItem(bean.getItem());
            entity.setPricePerUnit(bean.getPricePerUnit());
            entity.setBaseUnit(bean.getBaseUnit());
            entity.setQuantity(bean.getQuantity());
            entity.setDocumentIdentifier(transformDocumentIdentifier(bean.getNumber(), bean.getDocumentType()));
        }catch(Exception e){
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Conditioning Item: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}