package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.Conditioning;
import com.monsanto.barter.ar.business.entity.ConditioningItem;
import com.monsanto.barter.ar.business.entity.GrowerContract;
import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.SapInvoiceTypeService;
import com.monsanto.barter.ar.web.mvc.documentBeans.ConditioningBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.ConditioningItemBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author JASANC5 on 12/17/2014
 */
@Component
public class ConditioningTransformer extends EntityTransformer<Conditioning, ConditioningBean>{
    private static final Logger LOG = LoggerFactory.getLogger(ConditioningTransformer.class);
    @Autowired
    SapInvoiceTypeService sapInvoiceTypeService;
    @Autowired
    GrowerContractService growerContractService;
    @Autowired
    CustomerLasService customerLasService;
    @Autowired
    PortService portService;
    @Autowired
    ConditioningItemTransformer conditioningItemTransformer;

    @Override
    protected Conditioning createEntity() {
        return new Conditioning();
    }

    @Override
    public void updateEntity(Conditioning entity, ConditioningBean bean) {
        try{
            entity.setSapAudit(createSapAudit(bean.getOptionalField1(), bean.getOptionalField2()));
            entity.setInvoiceNumber(bean.getExternalId());
            if(bean.getInvoiceType()!=null){
                entity.setInvoiceType(sapInvoiceTypeService.getBySapId(bean.getInvoiceType()));
            }
            if(bean.getContractNumber()!=null) {
                GrowerContract growerContract = growerContractService.findBySAPId(bean.getContractNumber());
                entity.setContract(growerContract);
            }
            if(bean.getGrower()!=null){
                entity.setGrower(customerLasService.get(bean.getGrower()));
            }
            if(bean.getPort()!=null){
                entity.setPort(portService.getByStorageLocation(bean.getPort()));
            }
            entity.setTax(bean.getTax());
            entity.setCurrency(bean.getCurrency());
            entity.setItems(transformConditioningItems(entity, bean));
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Conditioning: ", e);
        }

    }

    private List<ConditioningItem> transformConditioningItems(Conditioning conditioning, ConditioningBean bean) {
        List<ConditioningItem> items = new ArrayList<ConditioningItem>();
        if (bean.getItems()!= null){
            for (ConditioningItemBean conditioningItemBean: bean.getItems()){
                ConditioningItem item = conditioningItemTransformer.transformToEntity(conditioningItemBean);
                item.setConditioning(conditioning);
                items.add(item);
            }
        }
        return items;
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}