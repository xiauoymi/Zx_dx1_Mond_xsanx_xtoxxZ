package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.Delivery;
import com.monsanto.barter.ar.business.entity.Unload;
import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.web.mvc.documentBeans.DeliveryBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.UnloadBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class DeliveryTransformer extends EntityTransformer<Delivery,DeliveryBean> {
    private static final Logger LOG = LoggerFactory.getLogger(DeliveryTransformer.class);

    @Autowired
    private CustomerLasService customerLasService;

    @Autowired
    private MaterialLasService materialLasService;

    @Autowired
    private PortService portService;

    @Autowired
    private UnloadTransformer unloadTransformer;

    @Override
    public Delivery createEntity() {
        return new Delivery();
    }

    private List<Unload> transformUnloads(Delivery delivery, DeliveryBean bean) {
        List<Unload> unloads = new ArrayList<Unload>();
        if (bean.getUnloads()!=null){
            for (UnloadBean unloadBean: bean.getUnloads()){
                Unload unload = unloadTransformer.transformToEntity(unloadBean);
                unload.setDelivery(delivery);
                unloads.add(unload);
            }
        }

        return unloads;
    }

    @Override
    public void updateEntity(Delivery entity, DeliveryBean bean) {
        try {
            entity.setDepositary(customerLasService.getMonsantoCustomer());
            entity.setCode(bean.getOptionalField1()); // This should have been filled with the documentId
            entity.setSapAudit(createSapAudit(bean.getCreatedDate(), bean.getOptionalField2()));
            entity.setFormNumber(bean.getFormNumber());
            entity.setCac(bean.getCac());
            entity.setDueDate(dateStringToDate(bean.getDueDate()));
            if (bean.getDepositor()!=null) {
                entity.setDepositor(customerLasService.get(bean.getDepositor()));
            }
            if(bean.getCropType()!=null) {
                entity.setCropType(materialLasService.getByNumber(bean.getCropType()));
            }
            entity.setZarandeo(bean.getZarandeo());
            entity.setDryingFrom(bean.getDryingFrom());
            entity.setDryingTo(bean.getDryingTo());
            entity.setDryingFee(bean.getDryingFee());
            entity.setExcessFee(bean.getExcessFee());
            entity.setOtherDeliveryExpenses(bean.getOtherDeliveryExpenses());
            if(bean.getOriginPort()!=null) {
                entity.setOriginPort(portService.getByStorageLocation(bean.getOriginPort()));
            }
            if(bean.getDeliveryPort()!=null) {
                entity.setDeliveryPort(portService.getByStorageLocation(bean.getDeliveryPort()));
            }
            entity.setDeliveryDate(dateStringToDate(bean.getDeliveryDate()));
            entity.setQualityDegree(bean.getQualityDegree());
            entity.setUnloads(transformUnloads(entity, bean));
            entity.setProteinContent(bean.getProteinContent());
            entity.setQualityFactor(bean.getQualityFactor());
            entity.setGrossWeight(bean.getGrossWeight());
            entity.setDryingRate(bean.getDryingRate());
            entity.setZarandeoRate(bean.getZarandeoRate());
            entity.setOtherRate(bean.getOtherRate());
            entity.setLiquidation(bean.getLiquidation());
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Delivery: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
