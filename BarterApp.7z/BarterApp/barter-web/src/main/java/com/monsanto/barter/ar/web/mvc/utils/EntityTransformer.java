package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.BaseEntity;
import com.monsanto.barter.ar.business.entity.DocumentIdentifier;
import com.monsanto.barter.ar.business.entity.SapAudit;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.AdendaService;
import com.monsanto.barter.ar.business.service.BillOfLadingService;
import com.monsanto.barter.ar.business.service.GrainTransferService;
import com.monsanto.barter.ar.business.service.SapDocumentService;
import com.monsanto.barter.ar.web.mvc.beans.DocumentIdentifierBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.DocumentBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author JASANC5 on 11/14/2014
 */
public abstract class EntityTransformer<E extends  BaseEntity, B extends DocumentBean> {

    private static final Logger LOG = LoggerFactory.getLogger(EntityTransformer.class);

    @Autowired
    private AdendaService adendaService;
    @Autowired
    private GrainTransferService grainTransferService;
    @Autowired
    private BillOfLadingService billOfLadingService;
    private static final String DATE_FORMAT = "yyyyMMdd";
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT);


    public E transformToEntity(B bean){
        E entity = createEntity();
        updateEntity(entity,bean);
        return entity;
    }

    /**
     * It returns barter document id (id corresponding to RT, ADD, BOL entities in Barter)
     * by document type and sap code
     * @param documentType
     * @param documentId
     * @return
     */
    public Long getDocumentIdByDocumentIdentifier(DocumentType documentType, String documentId) {
        if(documentType.equals(DocumentType.ADD)){
            return adendaService.getAdendaIdByDocumentIdentifier(documentId);
        }
        else if(documentType.equals(DocumentType.RT)){
            return grainTransferService.getRTIdByDocumentIdentifier(documentId);

        }
        else if(documentType.equals(DocumentType.BILL_OF_LADING)){
            return billOfLadingService.getBOLIdByDocumentIdentifier(documentId);
        }
        else{
            return null;
        }
    }

    public DocumentIdentifier transformDocumentIdentifier(DocumentIdentifierBean documentIdentifierBean) {
        DocumentIdentifier documentIdentifier = new DocumentIdentifier();
        DocumentType documentType = DocumentType.valueOf(documentIdentifierBean.getDocumentType());
        documentIdentifier.setType(documentType);
        String number = documentIdentifierBean.getNumber();
        documentIdentifier.setNumber(number);
        documentIdentifier.setReferenceDocId(getDocumentIdByDocumentIdentifier(documentType, number));
        return documentIdentifier;
    }

    public DocumentIdentifier transformDocumentIdentifier(String number, String sapCode) {
        DocumentIdentifier documentIdentifier = new DocumentIdentifier();
        DocumentType documentType = DocumentType.getDocumentTypeBySapCode(sapCode);
        documentIdentifier.setType(documentType);
        documentIdentifier.setNumber(number);
        documentIdentifier.setReferenceDocId(getDocumentIdByDocumentIdentifier(documentType, number));
        return documentIdentifier;
    }

    protected abstract E createEntity();
    public abstract void updateEntity(E entity, B bean);
    public abstract boolean validateEntity();

    public Date dateStringToDate(String dateString) {
        if (dateString == null){
            return null;
        }
        try {
            return DATE_FORMATTER.parse(dateString);
        } catch (ParseException e) {
            throw new BarterException("An error occurred parsing date: ", e);
        }
    }

    protected BaseEntity getBySAPIdIfItExists(String sapId, SapDocumentService service) {
        try {
            return service.findBySAPId(sapId);
        } catch (Exception e) {
            LOG.warn("The document with SAP id: " + sapId + " was not found. It is assume that this happen because it is older");
            return null;
        }
    }

    protected SapAudit createSapAudit(String creationDate, String lastModificationDate){
        SapAudit sapAudit = new SapAudit();
        sapAudit.setSapCreationDate(dateStringToDate(creationDate));
        sapAudit.setSapLastModificationDate(dateStringToDate(lastModificationDate));
        return sapAudit;
    }

}
