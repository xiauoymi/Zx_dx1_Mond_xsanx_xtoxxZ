package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.FinalLiquidation;
import com.monsanto.barter.ar.business.entity.PartialLiquidation;
import com.monsanto.barter.ar.business.entity.enumerated.LiquidationType;
import com.monsanto.barter.ar.business.service.LiquidationService;
import com.monsanto.barter.ar.web.mvc.documentBeans.FinalLiquidationBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class FinalLiquidationTransformer extends LiquidationTransformer<FinalLiquidation, FinalLiquidationBean> {
    private static final Logger LOG = LoggerFactory.getLogger(FinalLiquidationTransformer.class);

    @Autowired
    private LiquidationService liquidationService;

    @Override
    public FinalLiquidation createEntity() {
        return new FinalLiquidation();
    }

    @Override
    public void updateEntity(FinalLiquidation entity, FinalLiquidationBean bean) {
        try {
        transformToLiquidationEntity(entity, bean);
        entity.setType(LiquidationType.FINAL);
        entity.setBrokerInvolved(bean.getBrokerInvolved());
        if (bean.getOriginalLiquidationId()!=null){
            entity.setOriginalLiquidation((PartialLiquidation) getBySAPIdIfItExists(bean.getOriginalLiquidationId(), liquidationService));
        }
        entity.setGrossWeight(bean.getGrossWeight());
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Final Liquidation: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
