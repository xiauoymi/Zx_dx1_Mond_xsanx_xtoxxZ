package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.GrowerContract;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.mvc.documentBeans.GrowerContractBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class GrowerContractTransformer extends EntityTransformer<GrowerContract, GrowerContractBean> {
    private static final Logger LOG = LoggerFactory.getLogger(GrowerContractTransformer.class);

    @Autowired
    PointOfSaleService pointOfSaleService;

    @Autowired
    CustomerLasService  customerLasService;

    @Autowired
    PortService portService;

    @Autowired
    MaterialLasService materialLasService;

    @Autowired
    GrowerContractTypeService growerContractTypeService;


    @Override
    public GrowerContract createEntity() {
        return new GrowerContract();
    }

    @Override
    public void updateEntity(GrowerContract entity, GrowerContractBean bean) {
        entity.setCreatedDate(dateStringToDate(bean.getCreatedDate()));
        try {
            entity.setLastUpdateDate(dateStringToDate(bean.getLastUpdateDate()));
            entity.setNumber(bean.getExternalId());
            if (bean.getGrowerContractType()!=null) {
                entity.setContractType(growerContractTypeService.getBySapId(bean.getGrowerContractType()));
            }
            entity.setInvoiceSapId(bean.getInvoiceSapId());
            entity.setSapId(bean.getSapDocumentId());
            if (bean.getCustomerPos()!=null) {
                PointOfSale pos = pointOfSaleService.getPosByCustomerId(bean.getCustomerPos());
                entity.setCustomerPos(pos.getCustomer());
            }
            if (bean.getGrower()!=null) {
                entity.setGrower(customerLasService.get(bean.getGrower()));
            }
            entity.setDueDate(dateStringToDate(bean.getDeliveryDate()));
            entity.setQuantity(bean.getQuantity());
            if (bean.getPort()!=null) {
                entity.setPort(portService.getByStorageLocation(bean.getPort()));
            }
            if (bean.getCropType()!=null) {
                entity.setCropType(materialLasService.getByNumber(bean.getCropType()));
            }
            entity.setOrderQuantity(bean.getOrderQuantity());
            entity.setTax(bean.getTax());
            entity.setPriceByTonel(bean.getPriceByTonel());
            entity.setBaseUnit(bean.getBaseUnit());
            entity.setNetValue(bean.getNetValue());
        } catch(Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming Grower Contract: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
