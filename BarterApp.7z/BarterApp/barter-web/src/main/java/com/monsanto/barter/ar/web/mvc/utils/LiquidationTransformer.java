package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.business.entity.GrowerContract;
import com.monsanto.barter.ar.business.entity.Liquidation;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.mvc.documentBeans.LiquidationBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author JASANC5 on 11/14/2014
 */
public abstract class LiquidationTransformer<L extends Liquidation, B extends LiquidationBean> extends EntityTransformer<L, B> {

    @Autowired
    SapInvoiceTypeService sapInvoiceTypeService;
    @Autowired
    GrowerContractService growerContractService;
    @Autowired
    CustomerLasService customerLasService;
    @Autowired
    MaterialLasService materialLasService;
    @Autowired
    PortService portService;
    @Autowired
    PointOfSaleService pointOfSaleService;

    public L transformToLiquidationEntity(L liquidation, B bean){
        liquidation.setCreatedDate(dateStringToDate(bean.getCreatedDate())); // replace this two
        liquidation.setLastUpdateDate(dateStringToDate(bean.getLastUpdateDate()));
        liquidation.setInvoice(bean.getOptionalField1());
        liquidation.setCoe(bean.getCoe());
        if(bean.getDocumentType()!=null){
            liquidation.setDocumentType(sapInvoiceTypeService.getBySapId(bean.getDocumentType()));
        }

        if(bean.getSeller()!=null){
            liquidation.setGrower(customerLasService.get(bean.getSeller()));
        }
        liquidation.setAmountIVA(bean.getAmountIVA());
        liquidation.setOperationPrice(bean.getOperationPrice());
        if(bean.getCropType()!=null){
            liquidation.setCropType(materialLasService.getByNumber(bean.getCropType()));
        }
        if(bean.getPort()!=null){
            liquidation.setPort(portService.getByStorageLocation(bean.getPort()));
        }
        liquidation.setQualityFactor(bean.getQualityFactor());
        liquidation.setPriceByTonel(bean.getPriceByTonel());
        liquidation.setSubtotal(bean.getSubtotal());
        liquidation.setTotal(bean.getTotal());
        liquidation.setAliquotIVA(bean.getAliquotIVA());
        liquidation.setNetAmount(bean.getNetAmount());
        liquidation.setUsdAmount(bean.getUsdAmount());
        liquidation.setDocument(bean.getDocument());
        liquidation.setLocalization(bean.getLocalization());
        liquidation.setPayment(bean.getPayment());
        liquidation.setPaymentDate(dateStringToDate(bean.getPaymentDate()));
        if(bean.getPos()!=null){
            PointOfSale pos = pointOfSaleService.getPosByCustomerId(bean.getPos());
            liquidation.setCustomerPos(pos.getCustomer());
        }
        liquidation.setCommercialOperation(bean.getCommercialOperation());
        liquidation.setProteicContent(bean.getProteicContent());
        liquidation.setOperationType(bean.getOperationType());
        liquidation.setQualityGrade(bean.getQualityGrade());
        liquidation.setSubtotalAdj(bean.getSubtotalAdj());
        liquidation.setAmountIVAAdj(bean.getAmountIVAAdj());
        liquidation.setVoucher(bean.getVoucher());
        liquidation.setProcMerc(bean.getProcMerc());
        liquidation.setHarvest(bean.getHarvest());

        if(bean.getGrowerContract()!= null){
            GrowerContract growerContract = (GrowerContract) getBySAPIdIfItExists(bean.getGrowerContract(), growerContractService);
            liquidation.setContract(growerContract);
            growerContract.getLiquidations().add(liquidation);
            growerContract.calculateBalances();
        }

        return liquidation;
    }


}
