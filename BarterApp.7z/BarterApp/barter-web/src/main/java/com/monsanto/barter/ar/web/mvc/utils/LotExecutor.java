package com.monsanto.barter.ar.web.mvc.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.monsanto.barter.ar.business.entity.BaseEntity;
import com.monsanto.barter.ar.business.entity.Lot;
import com.monsanto.barter.ar.business.entity.RemoteRequest;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.mvc.beans.UpdateDocumentsServiceRequest;
import com.monsanto.barter.ar.web.mvc.documentBeans.*;
import com.monsanto.barter.ar.web.mvc.documentBeans.enumerated.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.annotation.PostConstruct;
import java.io.CharArrayReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author jpbeni
 */
@Component
@EnableAsync
public class LotExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(LotExecutor.class);

    private Map<Class, SapDocumentService> serviceMap = new HashMap<Class, SapDocumentService>();
    private Map<Class, EntityTransformer> transformerMap = new HashMap<Class, EntityTransformer>();

    @Autowired
    private BillOfLadingService bolService;
    @Autowired
    private AdendaService adendaService;
    @Autowired
    private GrainTransferService rtService;
    @Autowired
    private GrowerContractService growerContractService;
    @Autowired
    private DeliveryService deliveryService;
    @Autowired
    private LiquidationService liquidationService;
    @Autowired
    private LotService lotService;
    @Autowired
    private ConditioningService conditioningService;

    @Autowired
    private DeliveryTransformer deliveryTransformer;
    @Autowired
    private GrowerContractTransformer growerContractTransformer;
    @Autowired
    private PartialLiquidationTransformer partialLiquidationTransformer;
    @Autowired
    private FinalLiquidationTransformer finalLiquidationTransformer;
    @Autowired
    private BillOfLadingTrainTransformer billOfLadingTrainTransformer;
    @Autowired
    private BillOfLadingTruckTransformer billOfLadingTruckTransformer;
    @Autowired
    private AddendaTransformer addendaTransformer;
    @Autowired
    private RTTransformer rtTransformer;
    @Autowired
    private RemoteService remoteService;
    @Autowired
    private ConditioningTransformer conditioningTransformer;

    @Autowired
    private TransactionTemplate tx;

    private ObjectMapper objectMapper;

    @PostConstruct
    public void init() {
        objectMapper = new ObjectMapper();
        serviceMap.put(DeliveryBean.class, deliveryService);
        serviceMap.put(PartialLiquidationBean.class, liquidationService);
        serviceMap.put(FinalLiquidationBean.class, liquidationService);
        serviceMap.put(BillOfLadingTrainBean.class, bolService);
        serviceMap.put(BillOfLadingTruckBean.class, bolService);
        serviceMap.put(AddendaBean.class, adendaService);
        serviceMap.put(RTBean.class, rtService);
        serviceMap.put(GrowerContractBean.class, growerContractService);
        serviceMap.put(ConditioningBean.class, conditioningService);

        transformerMap.put(DeliveryBean.class, deliveryTransformer);
        transformerMap.put(GrowerContractBean.class, growerContractTransformer);
        transformerMap.put(PartialLiquidationBean.class, partialLiquidationTransformer);
        transformerMap.put(FinalLiquidationBean.class, finalLiquidationTransformer);
        transformerMap.put(BillOfLadingTrainBean.class, billOfLadingTrainTransformer);
        transformerMap.put(BillOfLadingTruckBean.class, billOfLadingTruckTransformer);
        transformerMap.put(AddendaBean.class, addendaTransformer);
        transformerMap.put(RTBean.class, rtTransformer);
        transformerMap.put(ConditioningBean.class, conditioningTransformer);
    }

    /**
     * Asynchronously executes all the pending lots in the database.
     * Every lot is executed and set complete in a sepparate transaction, which performs as an atomic operation.
     * This operation is SYNCHRONIZED to maintain thread safety, but given it is executed ASYNCHRONOUSLY, it does not
     * pose a performance risk.
     * Given this operation is executed ASYNCHRONOUSLY, its completion without errors does not guarantee the Lots were
     * actually processed without them.
     * Any Lot executed with errors will be resetted and requested again, and the execution of the next lots will be
     * halted.
     */
    @Async
    public void executePendingLots() {
        synchronized (LotExecutor.class) {
            boolean doContinue = true;
            //Iterate all the pending and complete lots, halting if any of them is not processed.
            Iterator<String> lotIterator = lotService.findPendingAndCompleteLots().iterator();
            while (lotIterator.hasNext() && doContinue) {
                String lotId = lotIterator.next();
                doContinue = processLot(lotId);
            }
        }
    }

    /**
     * Process the lot with the given transaction id.
     * @param transactionId the transaction id of the Lot to process, never null.
     * @return true if the Lot was processed, false otherwise
     */
    private boolean processLot(final String transactionId) {
        Boolean processed = tx.execute(new TransactionCallback<Boolean>() {
            @Override
            public Boolean doInTransaction(TransactionStatus status) {
                try {
                    Lot lot = lotService.findLot(transactionId);
                    if (!lot.isComplete()) { //if the lot is not complete
                        return false; //return false so it gets reset
                    } else {//otherwise
                        for (RemoteRequest remoteRequest : lot.getRequests()) { //iterate its requests
                            UpdateDocumentsServiceRequest request = objectMapper.readValue(
                                    new CharArrayReader(remoteRequest.getSerializedMessage()),
                                    UpdateDocumentsServiceRequest.class);
                            processRequest(request); //processing them each
                        }
                        lot.process();// mark the lot as processed and update it
                        lotService.update(lot);
                        return true; //continue processing
                    }
                } catch (Exception ex) { //on any exception, log it and rollback
                     LOG.error("An error occurred processing a lot: ", ex);
                    status.setRollbackOnly();
                    return false;// return false so it gets reset
                }
            }
        });

        if (!processed) { //if the lot was not processed
            processed = tx.execute(new TransactionCallback<Boolean>() {
                @Override
                public Boolean doInTransaction(TransactionStatus status) {
                    try {
                        Lot lot = lotService.findLot(transactionId);
                        lot.reset(); //reset it
                        lotService.update(lot);
                        remoteService.documentUpdateRequest(lot); //request it again
                        return false;//halt the processing
                    } catch (Exception ex) {//on any exception, log it and rollback
                        LOG.error("An error occurred resetting a lot: ", ex);
                        status.setRollbackOnly();
                        return false;//halt the processing
                    }
                }
            });
        }

        return processed;
    }

    /**
     * Process all the Create, Update and Delete operations in the given request.
     * @param request the {@link UpdateDocumentsServiceRequest} to process, never null.
     */
    @SuppressWarnings("unchecked")
    private void processRequest(UpdateDocumentsServiceRequest request) {
        for (DocumentBean doc : request.getDocuments()) {
            BaseEntity entity;
            EntityTransformer entityTransformer = transformerMap.get(doc.getClass());
            SapDocumentService service = serviceMap.get(doc.getClass());
            if (entityTransformer == null || service == null) {
                throw new UnsupportedOperationException("The document class is not supported: '" + doc.getClass() + "'");
            }
            if (doc.getOperation().equals(Operation.CREATE)) {
                entity = entityTransformer.transformToEntity(doc);
                service.save(entity);
            } else if (doc.getOperation().equals(Operation.UPDATE)) {
                entity = getBySAPId(doc, service);
                if(entity != null){ // if it is not in the database, the document is old and we should not consider it
                    entityTransformer.updateEntity(entity, doc);
                    service.update(entity);
                }
            } else if (doc.getOperation().equals(Operation.DELETE)) {
                entity = getBySAPId(doc, service);
                service.delete(entity);
            } else {
                throw new UnsupportedOperationException("The operation is not supported: '" + doc.getOperation() + "'");
            }
        }
    }

    private BaseEntity getBySAPId(DocumentBean doc, SapDocumentService service) {
        BaseEntity baseEntity = null;
        try {
            baseEntity = service.findBySAPId(doc.getExternalId());
        } catch (Exception e) {
            LOG.warn("The document " + doc.getClass().getSimpleName() + " with SapId: " + doc.getExternalId() +
                    " does not exist in the database", e);
        }
        return baseEntity;
    }
}
