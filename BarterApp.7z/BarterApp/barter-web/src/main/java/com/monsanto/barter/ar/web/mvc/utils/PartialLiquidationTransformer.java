package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.LiquidationUnload;
import com.monsanto.barter.ar.business.entity.PartialLiquidation;
import com.monsanto.barter.ar.business.entity.enumerated.LiquidationType;
import com.monsanto.barter.ar.web.mvc.beans.LiquidationUnloadBean;
import com.monsanto.barter.ar.web.mvc.documentBeans.PartialLiquidationBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class PartialLiquidationTransformer extends LiquidationTransformer<PartialLiquidation, PartialLiquidationBean> {
    private static final Logger LOG = LoggerFactory.getLogger(PartialLiquidationTransformer.class);

    @Override
    public PartialLiquidation createEntity() {
        return new PartialLiquidation();
    }

    private LiquidationUnload transformUnload(LiquidationUnloadBean unloadBean, PartialLiquidation liquidation) {
        LiquidationUnload liquidationUnload = new LiquidationUnload();
        liquidationUnload.setWeight(unloadBean.getWeight());
        liquidationUnload.setDocumentIdentifier(transformDocumentIdentifier(unloadBean.getNumber(), unloadBean.getDocumentType()));
        liquidationUnload.setPartialLiquidation(liquidation);
        return liquidationUnload;
    }

    @Override
    public void updateEntity(PartialLiquidation entity, PartialLiquidationBean bean) {
        try {
            transformToLiquidationEntity(entity, bean);
            entity.setType(LiquidationType.PARTIAL);
            List<LiquidationUnload> liquidationUnloads = new ArrayList<LiquidationUnload>();
            if (bean.getUnloads()!=null){
                for (LiquidationUnloadBean unloadBean : bean.getUnloads()) {
                    liquidationUnloads.add(transformUnload(unloadBean, entity));
                }
            }

            entity.setLiquidationUnloads(liquidationUnloads);
    } catch(Exception e) {
        LOG.error(e.getMessage());
        throw new BarterException("An error occurred transforming Partial Liquidation: ", e);
    }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
