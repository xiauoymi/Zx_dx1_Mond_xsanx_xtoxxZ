package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.enumerated.RTState;
import com.monsanto.barter.ar.business.service.CityAfipLasService;
import com.monsanto.barter.ar.business.service.CustomerLasService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.mvc.documentBeans.RTBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class RTTransformer extends EntityTransformer<GrainTransfer, RTBean> {
    private static final Logger LOG = LoggerFactory.getLogger(RTTransformer.class);

    @Autowired
    RspVatService rspVatService;

    @Autowired
    CityAfipLasService cityAfipLasService;

    @Autowired
    CustomerLasService customerLasService;

    @Autowired
    MaterialLasService materialLasService;

    @Override
    public GrainTransfer createEntity() {
        return new GrainTransfer();
    }

    @Override
    public void updateEntity(GrainTransfer entity, RTBean bean) {
        try {
            entity.setState(RTState.MIGRATED_FROM_SAP);
            entity.setNumber(bean.getNumber());
            entity.setPrice(bean.getPrice());
            entity.setGenerationDate(dateStringToDate(bean.getGenerationDate()));
            entity.setDueDate(dateStringToDate(bean.getDueDate()));
            entity.setDepositaryCACNumber(bean.getDepositaryCACNumber());
            entity.setDepositaryCuitNumber(bean.getDepositaryCuitNumber());
            entity.setDepositaryName(bean.getDepositaryName());
            entity.setDepositaryActivity(bean.getDepositaryActivity());
            entity.setSapAudit(createSapAudit(bean.getSapCreationDate(), bean.getLastUpdateDate()));
            if (bean.getDepositaryRspVat() != null) {
                entity.setDepositaryRspVat(rspVatService.get(bean.getDepositaryRspVat()));
            }
            entity.setDepositaryAddress(bean.getDepositaryAddress());
            if (bean.getDepositaryCity() != null) {
                entity.setDepositaryCity(cityAfipLasService.get(bean.getDepositaryCity()));
            }
            entity.setDepositaryONCCAOpNumber(bean.getDepositaryONCCAOpNumber());
            entity.setONCCAPlantNumber(bean.getONCCAPlantNumber());
            entity.setLaTijereta(bean.isLaTijereta());
            if (bean.getDepositor() != null) {
                entity.setDepositor(customerLasService.get(bean.getDepositor()));
            }
            if (bean.getDepositorRspVat() != null) {
                entity.setDepositorRspVat(rspVatService.get(bean.getDepositorRspVat()));
            }
            entity.setDepositorAddress(bean.getDepositorAddress());
            if (bean.getDepositorCity() != null) {
                entity.setDepositorCity(cityAfipLasService.get(bean.getDepositorCity()));
            }
            if (bean.getReceptor() != null) {
                entity.setReceptor(customerLasService.get(bean.getReceptor()));
            }
            if (bean.getReceptorRspVat() != null) {
                entity.setReceptorRspVat(rspVatService.get(bean.getReceptorRspVat()));
            }
            entity.setReceptorActivity(bean.getReceptorActivity());
            entity.setReceptorAddress(bean.getReceptorAddress());
            if (bean.getReceptorCity() != null) {
                entity.setReceptorCity(cityAfipLasService.get(bean.getReceptorCity()));
            }
            entity.setReceptorONCCAOpNumber(bean.getReceptorONCCAOpNumber());
            entity.setDetailDate(dateStringToDate(bean.getDetailDate()));
            entity.setDetailC1116A(bean.getDetailC1116A());
            if (bean.getCropType() != null) {
                entity.setDetailCropType(materialLasService.getByNumber(bean.getCropType()));
            }
            entity.setDetailCode(bean.getDetailCode());
            entity.setDetailWeightToTransfer(bean.getDetailWeightToTransfer());
            if (bean.getOkBroker()!= null){
                entity.setOkBroker(bean.getOkBroker());
            } else{
                entity.setOkBroker(false);
            }

            if (bean.getOkYield()!= null){
                entity.setOkYield(bean.getOkYield());
            } else{
                entity.setOkYield(false);
            }

            if (bean.getOkPos()!= null){
                entity.setOkPos(bean.getOkPos());
            } else{
                entity.setOkPos(false);
            }

            if (bean.getOkQuality()!= null){
                entity.setOkQuality(bean.getOkQuality());
            } else{
                entity.setOkQuality(false);
            }

        } catch (Exception e) {
            LOG.error(e.getMessage());
            throw new BarterException("An error occurred transforming RT: ", e);
        }
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}