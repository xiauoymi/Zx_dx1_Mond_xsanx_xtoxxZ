package com.monsanto.barter.ar.web.mvc.utils;

import com.monsanto.barter.ar.business.entity.Unload;
import com.monsanto.barter.ar.web.mvc.documentBeans.UnloadBean;
import org.springframework.stereotype.Component;

/**
 * @author JASANC5 on 11/14/2014
 */
@Component
public class UnloadTransformer extends EntityTransformer<Unload,UnloadBean> {

    @Override
    public Unload createEntity() {
        return new Unload();
    }

    @Override
    public void updateEntity(Unload entity, UnloadBean bean) {
        entity.setItem((bean.getItem()));
        entity.setUnloadDate(dateStringToDate(bean.getUnloadDate()));
        entity.setDocumentIdentifier(transformDocumentIdentifier(bean.getNumber(), bean.getDocumentType()));
        entity.setGrossWeight(bean.getGrossWeight());
        entity.setZarandeoWeight(bean.getZarandeoWeight());
        entity.setZarandeoRate(bean.getZarandeoRate());
        entity.setZarandeoAmount(bean.getZarandeoAmount());
        entity.setDryingWetPercentage(bean.getDryingWetPercentage());
        entity.setDryingWeight(bean.getDryingWeight());
        entity.setDryingRate(bean.getDryingRate());
        entity.setDryingAmount(bean.getDryingAmount());
    }

    @Override
    public boolean validateEntity() {
        return false;
    }
}
