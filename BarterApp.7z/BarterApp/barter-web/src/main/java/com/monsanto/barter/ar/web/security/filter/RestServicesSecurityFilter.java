package com.monsanto.barter.ar.web.security.filter;

import com.monsanto.barter.ar.web.security.util.LocalServiceAuthenticationUtil;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author JPBENI
 */
public class RestServicesSecurityFilter implements Filter {
    private LocalServiceAuthenticationUtil serviceAuthenticationUtil;

    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String user = ((HttpServletRequest)req).getHeader("username");
        String pass = ((HttpServletRequest)req).getHeader("password");
        if (serviceAuthenticationUtil.isValid(user, pass)) {
            //login user
            chain.doFilter(req, resp);
        }
        else {
            ((HttpServletResponse) resp).sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }

    public void init(FilterConfig config) throws ServletException {
        this.serviceAuthenticationUtil = new LocalServiceAuthenticationUtil();
    }

}
