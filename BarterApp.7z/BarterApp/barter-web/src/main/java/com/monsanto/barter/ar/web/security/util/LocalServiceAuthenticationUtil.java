package com.monsanto.barter.ar.web.security.util;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.barter.ar.architecture.business.exception.BarterException;
import com.monsanto.barter.ar.soa.util.BarterArPropertiesReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author JPBENI
 */
public class LocalServiceAuthenticationUtil {
    private static final Logger LOG = LoggerFactory.getLogger(LocalServiceAuthenticationUtil.class);

    public static final String USERNAME_KEY = "barterUser";
    public static final String ENV_VARIABLE = "MONCRYPTJV";
    public static final String APP_FOLDER_NAME = "appFolderName";
    public static final String ENCRYPTED_PASSWORD_FILE = "encryptedPasswordFile";
    public static final String KEY_FILE = "keyFile";
    private String userName;
    private String password;
    private BarterArPropertiesReader reader;

    public LocalServiceAuthenticationUtil() {
        try {
            LOG.info("Loading credentials...");
            this.reader = new BarterArPropertiesReader();
            String appName = getEnvironmentSpecificProperty(APP_FOLDER_NAME);
            String inEncryptedValueFileName = getEnvironmentSpecificProperty(ENCRYPTED_PASSWORD_FILE);
            String inKeyFileName = getEnvironmentSpecificProperty(KEY_FILE);
            this.password = EncryptionUtils.GetDecryptedStringFromExternalStorage(ENV_VARIABLE, appName,
                    inEncryptedValueFileName, inKeyFileName);
            this.userName = getEnvironmentSpecificProperty(USERNAME_KEY);
        } catch (Exception ex) {
            LOG.error("There was an error loading credentials: ", ex);
            throw new BarterException("There was an unexpected error loading credentials: ", ex);
        }
        LOG.info("Credentials loaded successfully.");
    }

    public boolean isValid(final String userName, final String password) {
        if (this.userName.equals(userName) && this.password.equals(password)) {
            return true;
        }
        LOG.debug("Invalid WAM credentials: usr={}, pass={}", userName, password);
        return false;
    }

    private String getEnvironmentSpecificProperty(String property) {
        return this.reader.getEnvironmentSpecificProperty(property);
    }
}
