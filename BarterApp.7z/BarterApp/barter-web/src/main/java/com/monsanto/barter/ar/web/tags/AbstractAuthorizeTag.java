package com.monsanto.barter.ar.web.tags;

import java.util.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Sets;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.util.StringUtils;


/**
 * <p>
 * A base class for an &lt;authorize&gt; tag used to make Spring Security based authorization decisions.
 * </p>
 *
 * <p>
 * This class is independent of tag rendering technology (JSP, Facelets). It treats tag attributes as simple strings
 * (with the notable exception of the "access" attribute, which is always expected to contain a Spring EL expression).
 * Therefore subclasses are expected to extract tag attribute values from the specific rendering technology, evaluate
 * them as expressions if necessary, and use the result to set the String-based attributes of this class.
 * </p>
 *
 * @author Francois Beausoleil
 * @author Luke Taylor
 * @author Rossen Stoyanchev
 *
 * @since 2.2.0
 */
public abstract class AbstractAuthorizeTag {

    public static final String REGEX_PREFIX = "regex:";
    private String access;
    private String url;
    private String method;
    private String ifAllGranted;
    private String ifAnyGranted;
    private String ifNotGranted;
    protected static final String ROLE_SUPER= "ROLE_SUPER";
    private static final GrantedAuthority GRANT_SUPER = new GrantedAuthorityImpl(ROLE_SUPER);

    /**
     * This method allows subclasses to provide a way to access the ServletRequest according to the rendering
     * technology.
     * @return The servlet request
     */
    protected abstract ServletRequest getRequest();

    /**
     * This method allows subclasses to provide a way to access the ServletResponse according to the rendering
     * technology.
     * @return The servlet response
     */
    protected abstract ServletResponse getResponse();

    /**
     * This method allows subclasses to provide a way to access the ServletContext according to the rendering
     * technology.
     * @return The servlet context
     */
    protected abstract ServletContext getServletContext();

    /**
     * Make an authorization decision by considering all &lt;authorize&gt; tag attributes. The following are valid
     * combinations of attributes:
     * <ul>
     * <li>access</li>
     * <li>url, method</li>
     * <li>ifAllGranted, ifAnyGranted, ifNotGranted</li>
     * </ul>
     * The above combinations are mutually exclusive and evaluated in the given order.
     *
     * @return the result of the authorization decision
     */
    public boolean authorize() {
        boolean isAuthorized;


        if (isSuperAuthorized()){
            return true;
        }
        if (StringUtils.hasText(getUrl())) {
            isAuthorized = authorizeUsingUrlCheck();
        } else {
            isAuthorized = authorizeUsingGrantedAuthorities();
        }

        return isAuthorized;
    }

    private boolean isSuperAuthorized() {
        final Collection<GrantedAuthority> granted = getPrincipalAuthorities();
        return granted.contains(GRANT_SUPER);

    }

    /**
     * Make an authorization decision by considering ifAllGranted, ifAnyGranted, and ifNotGranted. All 3 or any
     * combination can be provided. All provided attributes must evaluate to true.
     *
     * @return the result of the authorization decision
     */
    public boolean authorizeUsingGrantedAuthorities() {
        String ifAllGrantedText = getIfAllGranted();
        String ifAnyGrantedText = getIfAnyGranted();
        String ifNotGrantedText = getIfNotGranted();

        Set<GrantedAuthority> requiredAllGranted = parseAuthoritiesString(ifAllGrantedText);
        Set<GrantedAuthority> requiredAnyGranted = parseAuthoritiesString(ifAnyGrantedText);
        Set<String> requiredMatchAnyGranted = parseRegexesString(ifAnyGrantedText);
        Set<GrantedAuthority> requiredNotGranted = parseAuthoritiesString(ifNotGrantedText);

        final Collection<GrantedAuthority> granted = getPrincipalAuthorities();

        return checkAllGranted(requiredAllGranted, granted)
                || checkAnyGranted(requiredAnyGranted, granted)
                || checkMatchAnyGranted(requiredMatchAnyGranted, granted)
                || checkNotGranted(requiredNotGranted, granted);
    }

    private boolean checkNotGranted(Set<GrantedAuthority> requiredNotGranted, Collection<GrantedAuthority> granted) {
        return !requiredNotGranted.isEmpty() && grantedAuthoritiesDoNotContainAnyOfTheSpecifiedAuthorities(requiredNotGranted, granted);
    }

    private boolean checkMatchAnyGranted(Set<String> requiredMatchAnyGranted, Collection<GrantedAuthority> granted) {
        return !requiredMatchAnyGranted.isEmpty() && grantedAuthoritiesContainsAnyAuthorityThatMatchesAnyOfTheRegexes(requiredMatchAnyGranted, granted);
    }

    private boolean checkAnyGranted(Set<GrantedAuthority> requiredAnyGranted, Collection<GrantedAuthority> granted) {
        return !requiredAnyGranted.isEmpty() && grantedAuthoritiesContainAnyRequiredAuthority(requiredAnyGranted, granted);
    }

    private boolean checkAllGranted(Set<GrantedAuthority> requiredAllGranted, Collection<GrantedAuthority> granted) {
        return !requiredAllGranted.isEmpty() && containsAll(granted, requiredAllGranted);
    }

    private boolean containsAll(Collection<GrantedAuthority> granted, Set<GrantedAuthority> requiredAllGranted) {
        boolean allGranted = false;
        for(GrantedAuthority requiredGrantedAuthority : requiredAllGranted){
            allGranted = false;
            for(GrantedAuthority grantedAuthority : granted){
                if (grantedAuthority.getAuthority().equals(requiredGrantedAuthority.getAuthority())){
                    allGranted = true;
                    break;
                }
            }
            if (!allGranted){
                return false;
            }
        }
        return allGranted;
    }

    private boolean grantedAuthoritiesContainsAnyAuthorityThatMatchesAnyOfTheRegexes(Set<String> requiredRegexes, Collection<GrantedAuthority> granted) {
        return !grantedAuthoritiesMatchingTheRegexes(requiredRegexes, granted).isEmpty();
    }

    private Collection<GrantedAuthority> grantedAuthoritiesMatchingTheRegexes(final Set<String> regexes, Collection<GrantedAuthority> granted) {
        return Collections2.filter(granted, new Predicate<GrantedAuthority>() {
            @Override
            public boolean apply(GrantedAuthority granted) {
                return grantedAuthorityMatchesAnyOfTheRegexes(granted, regexes);
            }
        });
    }

    private boolean grantedAuthorityMatchesAnyOfTheRegexes(GrantedAuthority granted, Set<String> requiredRegexes) {
        for (String regEx : requiredRegexes) {
            if (granted.getAuthority().matches(regEx)) {
                return true;
            }
        }

        return false;
    }

    private boolean grantedAuthoritiesDoNotContainAnyOfTheSpecifiedAuthorities(Set<GrantedAuthority> requiredNotGranted, Collection<GrantedAuthority> granted) {
        return retainAll(granted, requiredNotGranted).isEmpty();
    }

    private boolean grantedAuthoritiesContainAnyRequiredAuthority(Set<GrantedAuthority> required, Collection<GrantedAuthority> granted) {
        return !retainAll(granted, required).isEmpty();
    }

    private Set<String> parseRegexesString(String regexes) {
        Set<String> regexesSet = Sets.newHashSet();

        if (regexes != null) {
            String[] elements = StringUtils.tokenizeToStringArray(regexes, ",");
            for (String element : elements) {
                if (element.startsWith(REGEX_PREFIX)) {
                    regexesSet.add(element.substring(REGEX_PREFIX.length()));
                }
            }
        }
        return regexesSet;
    }


    /**
     * Make an authorization decision based on the URL and HTTP method attributes. True is returned if the user is
     * allowed to access the given URL as defined.
     *
     * @return the result of the authorization decision
     */
    public boolean authorizeUsingUrlCheck() {
        return false;//getPrivilegeEvaluator().isAllowed(contextPath, getUrl(), getMethod(), currentUser);
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        if (method != null) {
            this.method = method.toUpperCase();
        } else {
            this.method = null;
        }
    }

    public String getIfAllGranted() {
        return ifAllGranted;
    }

    public void setIfAllGranted(String ifAllGranted) {
        this.ifAllGranted = ifAllGranted;
    }

    public String getIfAnyGranted() {
        return ifAnyGranted;
    }

    public void setIfAnyGranted(String ifAnyGranted) {
        this.ifAnyGranted = ifAnyGranted;
    }

    public String getIfNotGranted() {
        return ifNotGranted;
    }

    public void setIfNotGranted(String ifNotGranted) {
        this.ifNotGranted = ifNotGranted;
    }

	/*------------- Private helper methods  -----------------*/

    private Collection<GrantedAuthority> getPrincipalAuthorities() {
        Authentication currentUser = GlobalBarterSecurityHelper.getLoggedInUser();

        if (null == currentUser) {
            return Collections.emptyList();
        }

        return (Collection<GrantedAuthority>)currentUser.getAuthorities();
    }

    private Set<GrantedAuthority> parseAuthoritiesString(String authorizationsString) {
        final Set<GrantedAuthority> requiredAuthorities = new HashSet<GrantedAuthority>();

        if(authorizationsString != null){
            requiredAuthorities.addAll(Arrays.asList(commaSeparatedStringToAuthorityArray(authorizationsString)) );
        }

        return requiredAuthorities;
    }

    private Set<GrantedAuthority> retainAll(final Collection<GrantedAuthority> granted,
                                            final Set<GrantedAuthority> required) {
        Set<String> grantedRoles = authoritiesToRoles(granted);
        Set<String> requiredRoles = authoritiesToRoles(required);
        grantedRoles.retainAll(requiredRoles);

        return rolesToAuthorities(grantedRoles, granted);
    }

    private Set<String> authoritiesToRoles(Collection<GrantedAuthority> c) {
        Set<String> target = new HashSet<String>();
        for (GrantedAuthority authority : c) {
            if (null == authority.getAuthority()) {
                throw new IllegalArgumentException(
                        "Cannot process GrantedAuthority objects which return null from getAuthority() - attempting to process "
                                + authority.toString());
            }
            target.add(authority.getAuthority());
        }
        return target;
    }

    private Set<GrantedAuthority> rolesToAuthorities(Set<String> grantedRoles, Collection<GrantedAuthority> granted) {
        Set<GrantedAuthority> target = new HashSet<GrantedAuthority>();
        for (String role : grantedRoles) {
            for (GrantedAuthority authority : granted) {
                if (authority.getAuthority().equals(role)) {
                    target.add(authority);
                    break;
                }
            }
        }
        return target;
    }

    private static GrantedAuthority[] commaSeparatedStringToAuthorityArray(String rawAuthorityString) {
        String[] authorityStrings = StringUtils.tokenizeToStringArray(rawAuthorityString, ",");

        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        for (String authorityString : authorityStrings) {
            if (!authorityString.startsWith(REGEX_PREFIX)) {
                authorities.add(new GrantedAuthorityImpl(authorityString));
            }
        }

        return authorities.toArray(new GrantedAuthority[authorities.size()]);
    }

//	private WebInvocationPrivilegeEvaluator getPrivilegeEvaluator() throws IOException {
//		ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
//		Map<String, WebInvocationPrivilegeEvaluator> wipes = ctx.getBeansOfType(WebInvocationPrivilegeEvaluator.class);
//
//		if (wipes.size() == 0) {
//			throw new IOException(
//					"No visible WebInvocationPrivilegeEvaluator instance could be found in the application "
//							+ "context. There must be at least one in order to support the use of URL access checks in 'authorize' tags.");
//		}
//
//		return (WebInvocationPrivilegeEvaluator) wipes.values().toArray()[0];
//	}
}
