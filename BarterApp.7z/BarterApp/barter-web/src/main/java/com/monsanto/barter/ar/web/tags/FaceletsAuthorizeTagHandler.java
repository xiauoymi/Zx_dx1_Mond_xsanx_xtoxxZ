package com.monsanto.barter.ar.web.tags;

import java.io.IOException;

import javax.faces.component.UIComponent;
import javax.faces.view.facelets.FaceletContext;
import javax.faces.view.facelets.TagAttribute;
import javax.faces.view.facelets.TagConfig;
import javax.faces.view.facelets.TagHandler;

import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import org.springframework.security.core.context.SecurityContextHolder;

public class FaceletsAuthorizeTagHandler extends TagHandler {

    private final TagAttribute access;
    private final TagAttribute url;
    private final TagAttribute method;
    private final TagAttribute ifAllGranted;
    private final TagAttribute ifAnyGranted;
    private final TagAttribute ifNotGranted;
    private final TagAttribute var;

    /**
     * @see TagHandler#TagHandler(TagConfig)
     */
    public FaceletsAuthorizeTagHandler(TagConfig config) {
        super(config);
        this.access = this.getAttribute("access");
        this.url = this.getAttribute("url");
        this.method = this.getAttribute("method");
        this.ifAllGranted = this.getAttribute("ifAllGranted");
        this.ifAnyGranted = this.getAttribute("ifAnyGranted");
        this.ifNotGranted = this.getAttribute("ifNotGranted");
        this.var = this.getAttribute("var");
    }

    /**
     * @see TagHandler#apply(FaceletContext, UIComponent)
     */
    public void apply(FaceletContext faceletContext, UIComponent parent) throws IOException {
        if (GlobalBarterSecurityHelper.getLoggedInUser() == null) {
            return;
        }

        FaceletsAuthorizeTag authorizeTag = new FaceletsAuthorizeTag(faceletContext, access, url, method, ifAllGranted,
                ifAnyGranted, ifNotGranted);

        boolean isAuthorized = authorizeTag.authorize();

        if (isAuthorized) {
            this.nextHandler.apply(faceletContext, parent);
        }

        if (this.var != null) {
            faceletContext.setAttribute(var.getValue(faceletContext), Boolean.valueOf(isAuthorized));
        }
    }

}
