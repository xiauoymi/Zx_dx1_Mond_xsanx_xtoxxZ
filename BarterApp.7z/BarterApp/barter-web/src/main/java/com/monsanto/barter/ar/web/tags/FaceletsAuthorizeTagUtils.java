package com.monsanto.barter.ar.web.tags;

import java.io.IOException;


/**
 * This class provides static methods that are registered as EL functions and available for use in Unified EL
 * expressions in standard Facelets views (JSF 2 or higher).
 *
 * @author Rossen Stoyanchev
 * @since 2.2.0
 */
public final class FaceletsAuthorizeTagUtils {

    private FaceletsAuthorizeTagUtils() { } //not called. Added to avoid Sonar Violation

    /**
     * Returns true if the user has all of of the given authorities.
     *
     * @param authorities a comma-separated list of user authorities.
     */
    public static boolean areAllGranted(String authorities) throws IOException {
        FaceletsAuthorizeTag authorizeTag = new FaceletsAuthorizeTag();
        authorizeTag.setIfAllGranted(authorities);
        return authorizeTag.authorizeUsingGrantedAuthorities();
    }

    /**
     * Returns true if the user has any of the given authorities.
     *
     * @param authorities a comma-separated list of user authorities.
     */
    public static boolean areAnyGranted(String authorities) throws IOException {
        FaceletsAuthorizeTag authorizeTag = new FaceletsAuthorizeTag();
        authorizeTag.setIfAnyGranted(authorities);
        return authorizeTag.authorizeUsingGrantedAuthorities();
    }

    /**
     * Returns true if the user does not have any of the given authorities.
     *
     * @param authorities a comma-separated list of user authorities.
     */
    public static boolean areNotGranted(String authorities) throws IOException {
        FaceletsAuthorizeTag authorizeTag = new FaceletsAuthorizeTag();
        authorizeTag.setIfNotGranted(authorities);
        return authorizeTag.authorizeUsingGrantedAuthorities();
    }

    /**
     * Returns true if the user is allowed to access the given URL and HTTP method combination. The HTTP method is
     * optional and case insensitive.
     */
    public static boolean isAllowed(String url, String method) throws IOException {
        FaceletsAuthorizeTag authorizeTag = new FaceletsAuthorizeTag();
        authorizeTag.setUrl(url);
        authorizeTag.setMethod(method);
        return authorizeTag.authorizeUsingUrlCheck();
    }

}
