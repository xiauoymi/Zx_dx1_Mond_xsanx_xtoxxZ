/**
 * 
 */
package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.dao.SQLText;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.StatusList;

/**
 * Converter for the enumeration Active / Inactive
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 28/11/2011
 * 
 */
public class ActiveInactiveConverter extends BaseConverter {

    /**
     * Default constructor of the class.
     */
    public ActiveInactiveConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Character getAsObject(FacesContext context, UIComponent component, String value) {

        Character charValue;

        if (StatusList.ACTIVE.getName().equals(value)) {
            charValue = StatusList.ACTIVE.getFlag();
        } else if (StatusList.INACTIVE.getName().equals(value)) {
            charValue = StatusList.INACTIVE.getFlag();
        } else {
            if (SQLText.hasValue(value)) {
                charValue = value.charAt(0);
            } else {
                charValue = 0;
            }
        }
        return charValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        Character charValue = (Character) value;
        String stringValue = null;

        StatusList activeInactive = StatusList.getByFlag(charValue);

        if (activeInactive != null) {
            stringValue =  MessageUtil.getMessage(context.getViewRoot().getLocale(), activeInactive.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
