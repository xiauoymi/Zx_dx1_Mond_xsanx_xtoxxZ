package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.BarterTypeList;

/**
 * JSF Converter for the BarterTypeList.
 * 
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * @since 28/02/2012
 */
public class BarterTypeConverter extends BaseConverter {
    
    /**
     * No-arg constructor.
     * 
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public BarterTypeConverter() {

        super();
    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Character getAsObject(final FacesContext context, final UIComponent component, final String value) {
        
        if (super.hasValue(value)) {
            final BarterTypeList type = BarterTypeList.getByName(value);
            
            if (type != null) {
                return type.getCod(); 
            }
            return value.charAt(0);
        }
        
        return Character.valueOf((char) 0);
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(final FacesContext context, final UIComponent component, final Object value) {
        
        final BarterTypeList type = BarterTypeList.getByCod((Character) value);
        if (type != null && type.getName() != null) {
            return getMessage(type.getName()); 
        }
        
        return "";
    }

}
