package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.dao.SQLText;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.CampaignSituationList;

/**
 * Converter for the enumeration CampaignSituationList
 * 
 * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
 * @since 16/12/2011
 */
public class CampaignSituationConverter extends BaseConverter {

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Character charValue;

        if (CampaignSituationList.ACTIVE_CD.getName().equals(value)) {
            charValue = CampaignSituationList.ACTIVE_CD.getCodSituation();
        } else if (CampaignSituationList.INACTIVE_CD.getName().equals(value)) {
            charValue = CampaignSituationList.INACTIVE_CD.getCodSituation();
        } else {
            if (SQLText.hasValue(value)) {
                charValue = value.charAt(0);
            } else {
                charValue = 0;
            }
        }
        return charValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        Character charValue = (Character) value;
        String stringValue = null;

        CampaignSituationList campaignSituation = CampaignSituationList.getByCodSituation(charValue);

        if (campaignSituation != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), campaignSituation.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
