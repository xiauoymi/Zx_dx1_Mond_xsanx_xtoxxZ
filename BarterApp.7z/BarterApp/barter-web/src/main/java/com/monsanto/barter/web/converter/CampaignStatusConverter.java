package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.dao.SQLText;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.CampaignStatusList;

/**
 * Converter for the enumeration CampaignStatusList
 * 
 * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
 * @since 16/12/2011
 */
public class CampaignStatusConverter extends BaseConverter {

    /**
     * Construct default
     * 
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public CampaignStatusConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Character charValue;

        if (CampaignStatusList.DRAFT_CD.getName().equals(value)) {
            charValue = CampaignStatusList.DRAFT_CD.getCodStatus();
        } else if (CampaignStatusList.RETURNED_CD.getName().equals(value)) {
            charValue = CampaignStatusList.RETURNED_CD.getCodStatus();
        } else if (CampaignStatusList.VALIDATED_CD.getName().equals(value)) {
            charValue = CampaignStatusList.VALIDATED_CD.getCodStatus();
        } else if (CampaignStatusList.WAITING_FOR_VALIDATION_CD.getName().equals(value)) {
            charValue = CampaignStatusList.WAITING_FOR_VALIDATION_CD.getCodStatus();
        } else if (CampaignStatusList.INACTIVATED_CD.getName().equals(value)) {
            charValue = CampaignStatusList.INACTIVATED_CD.getCodStatus();
        } else {
            if (SQLText.hasValue(value)) {
                charValue = value.charAt(0);
            } else {
                charValue = 0;
            }
        }
        return charValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        Character charValue = (Character) value;
        String stringValue = null;

        CampaignStatusList campaignStatus = CampaignStatusList.getByCodStatus(charValue);

        if (campaignStatus != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), campaignStatus.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
