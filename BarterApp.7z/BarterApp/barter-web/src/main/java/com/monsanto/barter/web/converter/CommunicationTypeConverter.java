package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.CommunicationTypeList;

/**
 * JSF Converter for the CommunicationTypeList.
 * 
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * @since 07/03/2012
 */
public class CommunicationTypeConverter extends BaseConverter {
    
    /**
     * No-arg constructor.
     * 
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public CommunicationTypeConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Character getAsObject(final FacesContext context, final UIComponent component, final String value) {

        if (super.hasValue(value)) {
            final CommunicationTypeList type = CommunicationTypeList.getByName(value);

            if (type != null) {
                return type.getCod();
            }
            return value.charAt(0);
        }

        return Character.valueOf((char) 0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(final FacesContext context, final UIComponent component, final Object value) {

        final CommunicationTypeList type = CommunicationTypeList.getByCod((Character) value);
        if (type != null && type.getName() != null) {
            return getMessage(type.getName());
        }

        return "";
    }

}
