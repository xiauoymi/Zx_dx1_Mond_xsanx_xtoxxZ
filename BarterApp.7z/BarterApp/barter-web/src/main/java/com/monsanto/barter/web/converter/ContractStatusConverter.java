package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.ContractStatusList;


/**
 * Converter for the enumeration ContractStatusList
 * 
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 23/12/2011
 */
public class ContractStatusConverter extends BaseConverter {
    
    /**
     * Default constructor.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public ContractStatusConverter() {

        super();
    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Character getAsObject(FacesContext context, UIComponent component, String value) {
        
        Character charCode;

        if (super.hasValue(value)) {
            ContractStatusList contractStatus = ContractStatusList.getByName(value);
            if (contractStatus != null) {
                charCode = contractStatus.getCode(); 
            } else {                
                charCode = value.charAt(0);
            }
        } else {
            charCode = 0;
        }
        return charCode;
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        
        Character charCode = (Character) value;
        String stringName = "";
        
        ContractStatusList contractStatus = ContractStatusList.getByCode(charCode);
        if (contractStatus != null) {
            stringName = MessageUtil.getMessage(getCurrentLocale(), contractStatus.getName()); 
        }
        
        return stringName;
    }

}
