package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.ContractTypeList;


/**
 * Converter for the enumeration ContractTypeList
 * 
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 26/12/2011
 */
public class ContractTypeConverter extends BaseConverter {

    /**
     * Default constructor.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public ContractTypeConverter() {

        super();
    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        String stringCode;
        if (super.hasValue(value)) {
            ContractTypeList contractType = ContractTypeList.getByName(value);
            if (contractType != null) {
                stringCode = contractType.getCode(); 
            } else {                
                stringCode = value;
            }
        } else {
            stringCode = "";
        }
        return stringCode;
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringCode = (String) value;
        String stringName = "";
        
        ContractTypeList contractType = ContractTypeList.getByCode(stringCode);
        if (contractType != null) {
            stringName = MessageUtil.getMessage(getCurrentLocale(), contractType.getName()); 
        }
        
        return stringName;
    }

}
