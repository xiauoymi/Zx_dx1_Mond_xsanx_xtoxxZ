package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.web.jsf.BaseConverter;

/**
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 19/12/2011
 */
public class LongShortHistoryConverter extends BaseConverter {

    private static final String NULL = "null";

    /**
     * Default constructor of the class.
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public LongShortHistoryConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        return value;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringValue = "";
        String valueAux = (String) value;
        String[] arrValue = valueAux.split("-");

        String key = "changed.from.to";

        if (arrValue != null && arrValue.length > 0) {

            String oldValue = arrValue[0];
            String newValue = arrValue[1];

            if (hasValue(oldValue) && !NULL.equals(oldValue)) {

                if (hasValue(newValue) && !NULL.equals(newValue)) {

                    key = "changed.from.to";
                    stringValue = getMessage(key, oldValue, newValue);
                } else {
                    key = "operation.history.delete";
                    stringValue = getMessage(key);
                }
            } else {

                if (hasValue(newValue) && !NULL.equals(newValue)) {
                    key = "operation.history.new";
                    stringValue = getMessage(key);
                }
            }

        }

        return stringValue;
    }

}
