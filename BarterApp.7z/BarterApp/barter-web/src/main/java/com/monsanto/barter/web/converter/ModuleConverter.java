package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.ModuleList;
import org.apache.log4j.Logger;


/**
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 01/12/2011
 */
public class ModuleConverter extends BaseConverter {

    private static final Logger LOG = Logger.getLogger(ModuleConverter.class);

    /**
     * Default constructor class
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public ModuleConverter() {

        super();
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Integer integerValue;

        try {
            integerValue = Integer.valueOf(value);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            integerValue = Integer.MIN_VALUE;
        }

        return integerValue;
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringValue = null;
        ModuleList moduleList = ModuleList.getByModuleCd((Integer) value);
        if (moduleList != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), moduleList.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
