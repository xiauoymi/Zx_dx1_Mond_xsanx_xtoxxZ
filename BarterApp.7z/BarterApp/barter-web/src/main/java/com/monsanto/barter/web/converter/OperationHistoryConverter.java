package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.OperationHistoryList;
import org.apache.log4j.Logger;


/**
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 01/12/2011
 */
public class OperationHistoryConverter extends BaseConverter {

    private static final Logger LOG = Logger.getLogger(OperationHistoryConverter.class);

    /**
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public OperationHistoryConverter() {

        super();
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Character charValue;

        try {
            charValue = Character.valueOf(value.charAt(0));
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            charValue = Character.MIN_VALUE;
        }

        return charValue;
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringValue = null;
        OperationHistoryList operationHistoryList = OperationHistoryList.getByCode((Character) value);
        if (operationHistoryList != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), operationHistoryList.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
