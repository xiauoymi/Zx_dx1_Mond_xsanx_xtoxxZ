/**
 * 
 */
package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.PermissionList;

/**
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 30/11/2011
 * 
 */
public class PermissionConverter extends BaseConverter {

    /**
     * Default constructor of the class.
     */
    public PermissionConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Integer integerValue;

        try {
            integerValue = Integer.valueOf(value);
        } catch (Exception e) {
            integerValue = Integer.MIN_VALUE;
        }

        return integerValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringValue = null;
        PermissionList permissionList = PermissionList.getByPermissionCd((Integer) value);
        if (permissionList != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), permissionList.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
