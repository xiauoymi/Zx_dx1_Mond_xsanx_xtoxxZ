package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.PermissionTypeList;
import org.apache.log4j.Logger;

/**
 * Permission type converter.
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 01/12/2011
 */
public class PermissionTypeConverter extends BaseConverter {

    private static final Logger LOG = Logger.getLogger(PermissionTypeConverter.class);

    /**
     * Default constructor class
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public PermissionTypeConverter() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {

        Integer integerValue;

        try {
            integerValue = Integer.valueOf(value);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            integerValue = Integer.MIN_VALUE;
        }

        return integerValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext,
     * javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {

        String stringValue = null;
        PermissionTypeList permissionTypeList = PermissionTypeList.getByPermissionTypeCd((Integer) value);
        if (permissionTypeList != null) {
            stringValue = MessageUtil.getMessage(getCurrentLocale(), permissionTypeList.getName());
        } else {
            stringValue = "";
        }
        return stringValue;
    }

}
