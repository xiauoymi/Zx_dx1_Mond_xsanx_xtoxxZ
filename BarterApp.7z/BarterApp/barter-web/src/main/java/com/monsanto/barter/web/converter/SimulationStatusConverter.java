package com.monsanto.barter.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.web.jsf.BaseConverter;
import com.monsanto.barter.business.entity.list.SimulationStatusList;

/**
 * JSF Converter for the SimulationStatusList.
 * 
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * @since 20/01/2012
 */
public class SimulationStatusConverter extends BaseConverter {
    
    /**
     * No-arg constructor.
     * 
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public SimulationStatusConverter() {

        super();
    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    @Override
    public String getAsObject(final FacesContext context, final UIComponent component, final String value) {
        
        if (super.hasValue(value)) {
            final SimulationStatusList status = SimulationStatusList.getByDescription(value);
            
            if (status != null) {
                return status.getCod(); 
            }
            return value;
        }
        
        return "";
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public String getAsString(final FacesContext context, final UIComponent component, final Object value) {
        
        final SimulationStatusList status = SimulationStatusList.getByCod((String) value);
        if (status != null && status.getDescription() != null) {
            return getMessage(status.getDescription()); 
        }
        
        return "";
    }

}
