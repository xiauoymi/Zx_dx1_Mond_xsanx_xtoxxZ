package com.monsanto.barter.web.faces;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.el.ELContext;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.component.ActionSource;
import javax.faces.component.UIComponent;
import javax.faces.component.UIGraphic;
import javax.faces.component.UIInput;
import javax.faces.component.UIPanel;
import javax.faces.component.UISelectItems;
import javax.faces.component.UISelectOne;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlCommandLink;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlOutputLabel;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.component.html.HtmlPanelGroup;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.component.html.HtmlSelectOneListbox;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.component.html.HtmlSelectOneRadio;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionListener;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.richfaces.component.UIColumn;
import org.richfaces.component.UIDataTable;
// import org.richfaces.component.html.HtmlColumn;
// import org.richfaces.component.html.HtmlDataTable;
// import org.richfaces.component.html.HtmlSpacer;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.sun.faces.taglib.jsf_core.SetPropertyActionListenerImpl;

/**
 * Parent class for all Managed Bean who need to use dynamic fields.
 *
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 20/01/2012
 */
public abstract class DynamicFieldsFaces extends BaseJSF {

    /** */
    private static final long serialVersionUID = -3050945775963256012L;

    protected static final String ATTR_BORDER = "border";

    protected static final String ATTR_CELLSPACING = "cellspacing";

    protected static final String ATTR_CELLPADDING = "cellpadding";

    protected static final String ATTR_COLUMNS = "columns";

    protected static final String ATTR_DISABLED = "disabled";

    protected static final String ATTR_IMMEDIATE = "immediate";

    protected static final String ATTR_RENDERED = "rendered";

    protected static final String ATTR_ROWS = "rows";

    protected static final String ATTR_VAR = "var";

    protected static final String ATTR_WIDTH = "width";

    private static final String STR_EXPRESSION_ENDSWITH = "}";

    protected transient UIPanel dynamicPanel;

    private static Map<String, Integer> idNames;

    /**
     * Default constructor of the class.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public DynamicFieldsFaces() {

        super();
        dynamicPanel = new UIPanel();
    }

    /**
     * @return the dynamicPanel
     */
    public UIPanel getDynamicPanel() {

        return dynamicPanel;
    }

    /**
     * @param dynamicPanel - the dynamicPanel to set
     */
    public void setDynamicPanel(UIPanel dynamicPanel) {

        this.dynamicPanel = dynamicPanel;
    }

    /**
     * Creates a panelGrid ({@link HtmlPanelGrid}) and adds to the dynamic panel ({@link UIPanel}).
     *
     * @param id panel grid id
     * @param columns columns of the panel grid
     * @return {@link HtmlPanelGrid} created
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlPanelGrid createPanelGrid(String id, int columns) {

        return createPanelGrid(getDynamicPanel(), id, columns);
    }

    /**
     * Creates a panelGrid ({@link HtmlPanelGrid}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id panel grid id
     * @return {@link HtmlPanelGrid} created
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlPanelGrid createPanelGrid(UIComponent parent, String id) {

        final HtmlPanelGrid panelGrid = new HtmlPanelGrid();
        if (hasValue(id)) {
            panelGrid.setId(buildComponentId(panelGrid, id));
        } else {
            panelGrid.setId(buildComponentId(panelGrid, "panelGrid"));
        }
        parent.getChildren().add(panelGrid);

        return panelGrid;
    }

    /**
     * Creates a panelGrid ({@link HtmlPanelGrid}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id panel grid id
     * @param columns columns of the panel grid
     * @return {@link HtmlPanelGrid} created
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlPanelGrid createPanelGrid(UIComponent parent, String id, int columns) {

        final HtmlPanelGrid panelGrid = createPanelGrid(parent, id);
        setAttribute(panelGrid, ATTR_COLUMNS, Integer.valueOf(columns));

        return panelGrid;
    }

    /**
     * Creates a panelGroup ({@link HtmlPanelGroup}) and adds to the dynamic panel ({@link UIPanel}).
     *
     * @param id panel group id
     * @return {@link HtmlPanelGroup}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlPanelGroup createPanelGroup(String id) {

        return createPanelGroup(getDynamicPanel(), id);
    }

    /**
     * Creates a panelGroup ({@link HtmlPanelGroup}) and adds to the parent panel ({@link UIPanel}).
     *
     * @param parentPanel parent panel
     * @param id panel group id
     * @return {@link HtmlPanelGroup}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlPanelGroup createPanelGroup(UIPanel parentPanel, String id) {

        final HtmlPanelGroup panelGroup = new HtmlPanelGroup();
        if (hasValue(id)) {
            panelGroup.setId(buildComponentId(panelGroup, id));
        } else {
            panelGroup.setId(buildComponentId(panelGroup, "panelGroup"));
        }
        parentPanel.getChildren().add(panelGroup);

        return panelGroup;
    }

    /**
     * Creates a spacer ({@link HtmlSpacer}) and adds to the parent
     *
     * @param parent parent component
     * @param width width
     * @param height height
     * @return {@link HtmlSpacer}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */

    /*
    protected HtmlSpacer createSpacer(UIComponent parent, String width, String height) {

        final HtmlSpacer spacer = new HtmlSpacer();
        spacer.setId(buildComponentId(spacer, "spacer"));
        spacer.setWidth(width);
        spacer.setHeight(height);
        parent.getChildren().add(spacer);

        return spacer;
    } */

    /**
     * Creates a label ({@link HtmlOutputLabel}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id label id
     * @param value label value
     * @param expectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link HtmlOutputLabel}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlOutputLabel createLabel(UIComponent parent, String id, String value, Class<?> expectedType) {

        final HtmlOutputLabel label = new HtmlOutputLabel();
        if (hasValue(id)) {
            label.setId(buildComponentId(label, id));
        } else {
            if (hasValue(value)) {
                label.setId(buildComponentId(label, value));
            } else {
                label.setId(buildComponentId(label, "label"));
            }
        }
        if (hasValue(value) && value.endsWith(STR_EXPRESSION_ENDSWITH)) {

            setValueExpression(label, value, expectedType);
        } else {
            label.setValue(value);
        }
        parent.getChildren().add(label);

        return label;
    }

    /**
     * Creates a inputText ({@link HtmlInputText}) and adds to the parent component ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id inputText id
     * @param value attribute of the managed bean that will receive the value of the component
     * @return {@link HtmlInputText}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlInputText createInputText(UIComponent parent, String id, String value) {

        final HtmlInputText inputText = new HtmlInputText();
        if (hasValue(id)) {
            inputText.setId(buildComponentId(inputText, id));
        } else {
            inputText.setId(buildComponentId(inputText, "inputText"));
        }
        inputText.setValue(value);
        parent.getChildren().add(inputText);

        return inputText;
    }

    /**
     * Creates a inputHidden ({@link HtmlInputHidden}) and adds to the parent component ({@link UIComponent})
     * @param parent parent component
     * @param id inputHidden id
     * @param value attribute of the managed bean that will receive the value of the component
     * @param expectedType The type the result of the expression will be coerced to after evaluation.
     * @return
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlInputHidden createInputHidden(UIComponent parent, String id, String value, Class<?> expectedType) {

        final HtmlInputHidden inputHidden = new HtmlInputHidden();
        if (hasValue(id)) {
            inputHidden.setId(buildComponentId(inputHidden, id));
        } else {
            inputHidden.setId(buildComponentId(inputHidden, "inputHidden"));
        }
        if (hasValue(value) && value.endsWith(STR_EXPRESSION_ENDSWITH)) {

            setValueExpression(inputHidden, value, expectedType);
        } else {
            inputHidden.setValue(value);
        }

        return inputHidden;
    }

    protected void updateCounter(HtmlInputHidden contador, String value, Class<?> expectedType) {
        Double counter = Double.valueOf(contador.getValue().toString());
        counter += (Double)getValue(value, expectedType);
        contador.setValue(counter);
    }

    /**
     * Creates a selectOneMenu ({@link HtmlSelectOneMenu}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id selectOneMenu id
     * @param value attribute of the managed bean that will receive the value of the component
     * @param expectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link HtmlSelectOneMenu}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlSelectOneMenu createSelectOneMenu(UIComponent parent, String id, String value, Class<?> expectedType) {

        final HtmlSelectOneMenu selectOneMenu = new HtmlSelectOneMenu();
        if (hasValue(id)) {
            selectOneMenu.setId(buildComponentId(selectOneMenu, id));
        } else {
            selectOneMenu.setId(buildComponentId(selectOneMenu, "selectOneMenu"));
        }
        if (hasValue(value) && value.endsWith(STR_EXPRESSION_ENDSWITH)) {

            setValueExpression(selectOneMenu, value, expectedType);
        } else {
            selectOneMenu.setValue(value);
        }

        createSelectItems(parent, selectOneMenu);

        return selectOneMenu;
    }

    /**
     * Creates a selectOneMenu ({@link HtmlSelectOneListbox}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id selectOneListbox id
     * @param value attribute of the managed bean that will receive the value of the component
     * @return {@link HtmlSelectOneListbox}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlSelectOneListbox createSelectOneListbox(UIComponent parent, String id, String value) {

        final HtmlSelectOneListbox selectOneListbox = new HtmlSelectOneListbox();
        if (hasValue(id)) {
            selectOneListbox.setId(buildComponentId(selectOneListbox, id));
        } else {
            selectOneListbox.setId(buildComponentId(selectOneListbox, "selectOneListbox"));
        }
        selectOneListbox.setValue(value);

        createSelectItems(parent, selectOneListbox);

        return selectOneListbox;
    }

    /**
     * Creates a selectOneMenu ({@link HtmlSelectOneRadio}) and adds to the parent panel ({@link UIComponent}).
     *
     * @param parent parent component
     * @param id selectOneRadio id
     * @param value attribute of the managed bean that will receive the value of the component
     * @return {@link HtmlSelectOneRadio}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlSelectOneRadio createSelectOneRadio(UIComponent parent, String id, String value) {

        final HtmlSelectOneRadio selectOneRadio = new HtmlSelectOneRadio();

        if (hasValue(id)) {
            selectOneRadio.setId(buildComponentId(selectOneRadio, id));
        } else {
            selectOneRadio.setId(buildComponentId(selectOneRadio, "radio"));
        }
        if (hasValue(value) && value.endsWith(STR_EXPRESSION_ENDSWITH)) {

            setValueExpression(selectOneRadio, value);
        } else {
            selectOneRadio.setValue(value);
        }

        createSelectItems(parent, selectOneRadio);

        return selectOneRadio;
    }

    /**
     * Add to a component that inherits of the UISelectOne a selectItem
     *
     * @param selectOne {@link UISelectOne}
     * @param label selectItem label
     * @param value selectItem value
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void addSelectItem(final UISelectOne selectOne, String label, Object value) {

        if (selectOne.getChildren() != null
                && !selectOne.getChildren().isEmpty()
                && selectOne.getChildren().get(0) instanceof UISelectItems) {

            final UISelectItems selectItems = (UISelectItems) selectOne.getChildren().get(0);

            if (selectItems.getValue() instanceof ArrayList<?>) {

                @SuppressWarnings("unchecked")
                List<SelectItem> items = (List<SelectItem>) selectItems.getValue();
                final SelectItem selectItem = new SelectItem(value, label);
                items.add(selectItem);
            }
        }
    }

    /**
     * Creates a selectBooleanCheckbox ({@link HtmlSelectBooleanCheckbox}) and adds to the parent panel (
     * {@link UIComponent} ).
     *
     * @param parent parent component
     * @param id selectBooleanCheckbox id
     * @param label selectBooleanCheckbox label
     * @param value attribute of the managed bean that will receive the value of the component
     * @return {@link HtmlSelectBooleanCheckbox}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlSelectBooleanCheckbox createSelectBooleanCheckbox(UIComponent parent, String id, String label,
                                                                    String value) {

        final HtmlSelectBooleanCheckbox selectBooleanCheckbox = new HtmlSelectBooleanCheckbox();
        if (hasValue(id)) {
            selectBooleanCheckbox.setId(buildComponentId(selectBooleanCheckbox, id));
        } else {
            selectBooleanCheckbox.setId(buildComponentId(selectBooleanCheckbox, "checkbox"));
        }
        selectBooleanCheckbox.setLabel(label);
        selectBooleanCheckbox.setValue(value);
        parent.getChildren().add(selectBooleanCheckbox);

        return selectBooleanCheckbox;
    }

    /**
     * Creates a commandButton ({@link HtmlCommandButton}) and adds to the parent panel ({@link UIComponent})
     *
     * @param parent parent component
     * @param id commandButton id
     * @param action MethodExpression of the appication action to be invoked
     * @param value commandButton value
     * @return {@link HtmlCommandButton}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlCommandButton createCommandButton(UIComponent parent, String id, String action, String value) {

        final HtmlCommandButton commandButton = new HtmlCommandButton();
        if (hasValue(id)) {
            commandButton.setId(buildComponentId(commandButton, id));
        } else {
            commandButton.setId(buildComponentId(commandButton, value));
        }
        commandButton.setValue(value);
        commandButton.setActionExpression(getMethodExpression(action));
        parent.getChildren().add(commandButton);

        return commandButton;
    }

    /**
     * Creates a commandLink ({@link HtmlCommandLink}) and adds to the parent panel ({@link UIComponent})
     *
     * @param parent parent component
     * @param id commandLink id
     * @param value ValueExpression to be stored as the value of the target attribute.
     * @param valueExpectedType The type the result of the expression will be coerced to after evaluation.
     * @param target ValueExpression that is the destination of the value attribute.
     * @param targetExpectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link HtmlCommandLink}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlCommandLink createCommandLink(UIComponent parent, String id, String value,
                                                Class<?> valueExpectedType, String target, Class<?> targetExpectedType) {

        final HtmlCommandLink commandLink = new HtmlCommandLink();
        if (hasValue(id)) {
            commandLink.setId(buildComponentId(commandLink, id));
        } else {
            commandLink.setId(buildComponentId(commandLink, "link"));
        }
        setPropertyActionListener(commandLink, value, valueExpectedType, target, targetExpectedType);
        parent.getChildren().add(commandLink);

        return commandLink;
    }

    /**
     * Creates a commandLink ({@link HtmlCommandLink}) with graphicImage and adds to the parent panel (
     * {@link UIComponent})
     *
     * @param parent parent component
     * @param id commandLink id
     * @param image image path
     * @param imageAlt value of the alt property.
     * @param value ValueExpression to be stored as the value of the target attribute.
     * @param valueExpectedType The type the result of the expression will be coerced to after evaluation.
     * @param target ValueExpression that is the destination of the value attribute.
     * @param targetExpectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link HtmlCommandLink}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlCommandLink createCommandLink(UIComponent parent, String id, String image, String imageAlt,
                                                String value, Class<?> valueExpectedType, String target, Class<?> targetExpectedType) {

        final HtmlCommandLink commandLink = createCommandLink(parent, id, value, valueExpectedType, target,
                targetExpectedType);
        createGraphicImage(commandLink, image, imageAlt);

        return commandLink;
    }

    /**
     * Creates a graphicImage ({@link HtmlGraphicImage}) and adds to the parent component ({@link UIComponent})
     *
     * @param parent parent component
     * @param value image path
     * @param alt value of the alt property.
     * @return {@link HtmlGraphicImage}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected HtmlGraphicImage createGraphicImage(UIComponent parent, String value, String alt) {

        final HtmlGraphicImage graphicImage = new HtmlGraphicImage();
        graphicImage.setId(buildComponentId(graphicImage, "image"));
        graphicImage.setValue(value);
        graphicImage.setAlt(alt);

        addComponentItem(parent, graphicImage);

        return graphicImage;
    }

    /**
     * Add to a component ({@link UIComponent}) a other component ({@link UIComponent})
     *
     * @param parent parent component
     * @param component component
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void addComponentItem(UIComponent parent, UIComponent component) {

        parent.getChildren().add(component);
    }

    /**
     * Creates a dataTable ({@link HtmlDataTable}) and adds to the parent panel ({@link UIPanel}).
     *
     * @param parent parent panel
     * @param id selectBooleanCheckbox id
     * @param value attribute of the managed bean that will receive the value of the component
     * @param var Set the request-scope attribute under which the data object for the current row wil be exposed when
     *        iterating.
     * @return {@link HtmlDataTable}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    /*
    protected HtmlDataTable createRichHtmlDataTable(UIComponent parent, String id, Object value, String var) {

        final HtmlDataTable dataTable = new HtmlDataTable();
        if (hasValue(id)) {
            dataTable.setId(buildComponentId(dataTable, id));
        } else {
            if (hasValue(var)) {
                dataTable.setId(buildComponentId(dataTable, var));
            } else {
                dataTable.setId(buildComponentId(dataTable, "table"));
            }
        }
        dataTable.setValue(value);
        dataTable.setVar(var);
        dataTable.setWidth("100%");
        parent.getChildren().add(dataTable);

        return dataTable;
    }
    */

    /**
     * Creates a dataTable ({@link HtmlDataTable}) and adds to the parent panel ({@link UIPanel}).
     *
     * @param parent parent panel
     * @param id selectBooleanCheckbox id
     * @param value attribute of the managed bean that will receive the value of the component
     * @param var Set the request-scope attribute under which the data object for the current row wil be exposed when
     *        iterating.
     * @return {@link HtmlDataTable}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected UIDataTable createRichHtmlDataTable(UIComponent parent, String id, Object value, String var) {

        final Application app = FacesContext.getCurrentInstance().getApplication();
        final UIDataTable dataTable = (UIDataTable) app.createComponent(UIDataTable.COMPONENT_TYPE);
        if (hasValue(id)) {
            dataTable.setId(buildComponentId(dataTable, id));
        } else {
            if (hasValue(var)) {
                dataTable.setId(buildComponentId(dataTable, var));
            } else {
                dataTable.setId(buildComponentId(dataTable, "table"));
            }
        }
        dataTable.setValue(value);
        dataTable.setVar(var);
        // TODO not implemented in the richfaces 4 component.
        // dataTable.setWidth("100%");
        parent.getChildren().add(dataTable);

        return dataTable;
    }

    /*
    * FacesContext.getCurrentInstance().getApplication();
                UIDataTable dataTable =
    * */


    /**
     * Creates a column ({@link HtmlColumn})
     *
     * @param dataTable parent dataTable ({@link HtmlDataTable}) or that inherits from {@link UIComponent}
     * @param width column width
     * @return {@link HtmlColumn}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected UIColumn createRichColumn(UIComponent dataTable, String width) {

        return createRichColumn(dataTable, null, width);
    }

    /**
     * Creates a column ({@link HtmlColumn})
     *
     * @param dataTable parent dataTable ({@link HtmlDataTable}) or that inherits from {@link UIComponent}
     * @param label column label
     * @param width column width
     * @return {@link HtmlColumn}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected UIColumn createRichColumn(UIComponent dataTable, String label, String width) {
        final Application app = FacesContext.getCurrentInstance().getApplication();
        final UIColumn htmlColumn = (UIColumn) app.createComponent(UIColumn.COMPONENT_TYPE);

        if (hasValue(label)) {

            htmlColumn.setId(buildComponentId(htmlColumn, label));
            htmlColumn.setHeader(createLabel(htmlColumn, null, label, null));
        } else {
            htmlColumn.setId(buildComponentId(htmlColumn, "column"));
        }
        htmlColumn.setWidth(width);
        dataTable.getChildren().add(htmlColumn);

        return htmlColumn;
    }

    /**
     * Add to a column a component that inherits from {@link UIColumn}
     *
     * @param column {@link UIColumn}
     * @param input {@link UIInput}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void addRichColumnItem(final UIColumn column, UIInput input) {

        column.getChildren().add(input);
    }

    /**
     * Creates a column ({@link HtmlColumn})
     *
     * @param parent parent component
     * @return {@link HtmlColumn}
     * @param width width
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected javax.faces.component.html.HtmlColumn createColumn(UIComponent parent, String width) {

        final javax.faces.component.html.HtmlColumn columnExt = new javax.faces.component.html.HtmlColumn();
        columnExt.setId(buildComponentId(columnExt, "columnExt"));
        final HtmlPanelGrid panelGrid = createPanelGrid(columnExt, null, 1);
        panelGrid.setCellpadding("0");
        panelGrid.setCellspacing("0");
        panelGrid.setBorder(0);
        panelGrid.setWidth(width);
        columnExt.getChildren().add(panelGrid);

        final javax.faces.component.html.HtmlColumn columnInt = new javax.faces.component.html.HtmlColumn();
        columnInt.setId(buildComponentId(columnInt, "columnInt"));
        panelGrid.getChildren().add(columnInt);
        parent.getChildren().add(columnExt);

        return columnInt;
    }

    /**
     * Add to a column a component that inherits from {@link javax.faces.component.UIColumn}
     *
     * @param column {@link javax.faces.component.UIColumn}
     * @param input {@link UIInput}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void addColumnItem(final javax.faces.component.UIColumn column, UIInput input) {

        column.getChildren().add(input);
    }

    /**
     * Creates a selectItems ({@link UISelectItems}) and adds to the ({@link UISelectOne}).
     *
     * @param parentPanel parent panel
     * @param selectOne {@link UISelectOne}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void createSelectItems(UIComponent parentPanel, final UISelectOne selectOne) {

        final UISelectItems selectItems = new UISelectItems();
        selectItems.setId(buildComponentId(selectItems, "selectItems"));
        selectItems.setValue(new ArrayList<SelectItem>());
        selectOne.getChildren().add(selectItems);

        parentPanel.getChildren().add(selectOne);
    }

    /**
     * Sets the attribute of a UIPanel or a component that inherits from UIComponent
     *
     * @param component {@link UIPanel} or a component that inherits from {@link UIComponent}
     * @param attribute attribute name
     * @param value attribute value
     */
    protected void setAttribute(UIComponent component, String attribute, Object value) {

        component.getAttributes().put(attribute, value);
    }

    /**
     * Register the {@link ActionListener} instance to component ({@link UIComponent})
     *
     * @param component {@link UIComponent}
     * @param value ValueExpression to be stored as the value of the target attribute.
     * @param valueExpectedType The type the result of the expression will be coerced to after evaluation.
     * @param target ValueExpression that is the destination of the value attribute.
     * @param targetExpectedType The type the result of the expression will be coerced to after evaluation.
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void setPropertyActionListener(UIComponent component, String value, Class<?> valueExpectedType,
                                             String target, Class<?> targetExpectedType) {

        setPropertyActionListener(component,
                createPropertyActionListener(value, valueExpectedType, target, targetExpectedType));
    }

    /**
     * Register the {@link ActionListener} instance to component ({@link UIComponent})
     *
     * @param component {@link UIComponent}
     * @param listener {@link ActionListener}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected void setPropertyActionListener(UIComponent component, ActionListener listener) {

        ((ActionSource) component).addActionListener(listener);
    }

    /**
     * Creates a {@link ActionListener}
     *
     * @param value ValueExpression to be stored as the value of the target attribute.
     * @param valueExpectedType The type the result of the expression will be coerced to after evaluation.
     * @param target ValueExpression that is the destination of the value attribute.
     * @param targetExpectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link SetPropertyActionListenerImpl}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected ActionListener createPropertyActionListener(String value, Class<?> valueExpectedType, String target,
                                                          Class<?> targetExpectedType) {

        ActionListener actionListener = new SetPropertyActionListenerImpl(
                getValueExpression(target, targetExpectedType), getValueExpression(value, valueExpectedType));

        return actionListener;
    }

    /**
     * Gets dynamic panel by form id
     *
     * @param formId form id
     * @param dynamicPanelId dynamic panel id
     * @return Dynamic panel ({@link UIPanel})
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected UIPanel getDynamicPanelByFormIdAndPanelId(String formId, String dynamicPanelId) {

        UIPanel dynamicPanelResult = null;

        final UIComponent form = FacesContext.getCurrentInstance().getViewRoot().findComponent(formId);

        for (final UIComponent component : form.getChildren()) {

            if (component instanceof UIPanel && dynamicPanelId.equals(component.getId())) {

                dynamicPanelResult = (UIPanel) component;
                break;
            }
        }
        return dynamicPanelResult;
    }

    /**
     * Gets the dynamic field value
     *
     * @param component a component that inherits from {@link UIInput}
     * @return dynamic field value
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    protected String getDynamicFieldValue(final UIComponent component) {

        String value = null;

        if (component instanceof UIInput) {

            value = (String) ((UIInput) component).getValue();
        }
        return value;
    }

    /**
     * Sets the {@link ValueExpression} to {@link UIComponent}. <br /><tt>run the setValueExpression(component, value,
     * expectedType), setting String.class in expected class</tt>
     *
     * @param component {@link UIComponent}
     * @param value The expression to parse
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void setValueExpression(UIComponent component, Object value) {

        setValueExpression(component, value, String.class);
    }

    /**
     * Sets the {@link ValueExpression} to {@link UIComponent}
     *
     * @param component {@link UIComponent}
     * @param value The expression to parse
     * @param expectedType The type the result of the expression will be coerced to after evaluation.
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void setValueExpression(UIComponent component, Object value, Class<?> expectedType) {
        if (hasValue(value) && (value instanceof String) && value.toString().endsWith(STR_EXPRESSION_ENDSWITH)) {
            ValueExpression expression = getValueExpression(value.toString(), expectedType);
            component.setValueExpression("value", expression);
        }
    }

    @SuppressWarnings("unchecked")
    private <T> T getValue(String expression, Class<?> expectedType) {

        return (T) getValueExpression(expression, expectedType).getValue(FacesContext.getCurrentInstance().getELContext());
    }

    /**
     * Gets value expression
     *
     * @param expression The expression to parse
     * @param expectedType The type the result of the expression will be coerced to after evaluation.
     * @return {@link ValueExpression}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private ValueExpression getValueExpression(String expression, Class<?> expectedType) {

        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext context = facesContext.getELContext();

        return facesContext.getApplication().getExpressionFactory()
                .createValueExpression(context, expression, expectedType);
    }

    /**
     * Gets method expression
     *
     * @param expression expression of the appication action to be invoked
     * @return {@link MethodExpression}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private MethodExpression getMethodExpression(String expression) {

        return getMethodExpression(expression, null);
    }

    /**
     * Gets method expression with returning
     *
     * @param expression expression of the appication action to be invoked
     * @param expectedReturnType expected return type
     * @return {@link MethodExpression}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private MethodExpression getMethodExpression(String expression, Class<?> expectedReturnType) {

        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELContext context = facesContext.getELContext();

        return facesContext.getApplication().getExpressionFactory()
                .createMethodExpression(context, expression, expectedReturnType, new Class<?>[0]);
    }

    /**
     * @return the idNames
     */
    public Map<String, Integer> getIdNames() {

        if (idNames == null) {

            idNames = new HashMap<String, Integer>();
        }
        return idNames;
    }

    private String buildComponentId(UIComponent component, String name) {

        String key = "";

        if (component instanceof HtmlOutputLabel) {
            key = "lbl";
        } else if (component instanceof HtmlInputText) {
            key = "txt";
        } else if (component instanceof HtmlSelectBooleanCheckbox) {
            key = "chk";
        } else if (component instanceof HtmlSelectOneRadio) {
            key = "rdb";
        } else if (component instanceof HtmlSelectOneMenu) {
            key = "cbo";
        } else if (component instanceof HtmlSelectOneListbox) {
            key = "lst";
        } else if (component instanceof UIPanel) {
            key = "pnl";
        } else if (component instanceof UIDataTable) {
            key = "tbl";
        } else if (component instanceof javax.faces.component.UIColumn) {
            key = "col";
        } else if (component instanceof HtmlCommandButton) {
            key = "btn";
        } else if (component instanceof HtmlCommandLink) {
            key = "lnk";
        } else if (component instanceof UIGraphic) {
            key = "img";
        }

        String id = buildIdName(key, name);

        if (getIdNames().containsKey(id)) {
            getIdNames().put(id, getIdNames().get(id) + 1);
        } else {
            getIdNames().put(id, 1);
        }
        return id.concat(getIdNames().get(id).toString());
    }

    private String buildIdName(String prefix, String name) {

        return String.format("%s%s", prefix, preBuildIdName(name));
    }

    private String preBuildIdName(String name) {

        return StringUtils.capitalize(replaceSpecial(name.replaceAll(" ", "")));
    }

    private String replaceSpecial(String text) {

        return Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
    }
}
