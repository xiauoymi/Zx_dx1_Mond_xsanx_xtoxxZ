package com.monsanto.barter.web.faces.admin;


import com.monsanto.barter.architecture.util.DetailedHealthMessage;
import com.monsanto.barter.architecture.util.HealthChecker;
import com.monsanto.commercial.lyceum.core.web.health.HealthCheckStatus;
import com.monsanto.commercial.lyceum.core.web.health.config.generated.HealthCheckConfig;
import org.springframework.stereotype.Component;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.jar.Manifest;

import static org.apache.commons.io.IOUtils.closeQuietly;

@ManagedBean(name="healthCheckFaces")
@Component
@ApplicationScoped
public class HealthCheckFaces {

    private static final String manifestFile = "/version.txt";
    private static final String healthCheckConfigFile = "/health/HealthCheckConfig.xml";
    private static final String contextPath = "com.monsanto.commercial.lyceum.core.web.health.config.generated";
    private static final String HEALTH_CHECK_PAGE = "healthCheck";

    private HealthCheckStatus healthCheckStatus;
    private HealthChecker healthChecker;

    private String version = "none";
    private String buildDate = "none";

    public HealthCheckFaces() throws IOException, JAXBException {
        InputStream manifestInputStream = null;
        try {
            /**
             * There is no single way of retrieving this file for all the supported servers, so we are only supporting
             * this for Application Servers because the DataSource information would not be available elsewhere anyway.
             */
            manifestInputStream =
                    ((HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest())
                            .getSession().getServletContext().getResourceAsStream(manifestFile);

            if (manifestInputStream != null) {
                Manifest manifest = new Manifest(manifestInputStream);

                version = manifest.getMainAttributes().getValue("Implementation-Version");
                buildDate = manifest.getMainAttributes().getValue("Built-Date");
            }
        } finally {
            closeQuietly(manifestInputStream);
        }

        InputStream healthCheckConfigInputStream = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(contextPath);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            healthCheckConfigInputStream = this.getClass().getResourceAsStream(healthCheckConfigFile);
            JAXBElement <HealthCheckConfig> elm =
                    (JAXBElement<HealthCheckConfig>) unmarshaller.unmarshal(healthCheckConfigInputStream);
            healthChecker = new HealthChecker(elm.getValue());
        } finally {
            closeQuietly(healthCheckConfigInputStream);
        }
    }

    public String begin() {
        healthChecker.runAllHealthChecks();
        healthCheckStatus = healthChecker.getHealthCheckStatus();
        return HEALTH_CHECK_PAGE;
    }

    public String getHostName() {
        return healthCheckStatus.getHostName();
    }

    public String getHealthMessage() {
        return healthCheckStatus.getOverallHealthMsg();
    }

    public String getVersion() {
        return version;
    }

    public String getBuildDate() {
        return buildDate;
    }

    public List<DetailedHealthMessage> getDetailHealthMessage(){
        List<DetailedHealthMessage> detailedHealthMessageList = new ArrayList<DetailedHealthMessage>();
        if(!healthCheckStatus.getDetailedHealthMsgs().entrySet().isEmpty()){
           for(Map.Entry<String, String> entry: healthCheckStatus.getDetailedHealthMsgs().entrySet()){
               detailedHealthMessageList.add(new DetailedHealthMessage(entry.getKey(), entry.getValue()));
           }
           return detailedHealthMessageList;
        }
        return detailedHealthMessageList;
    }
}
