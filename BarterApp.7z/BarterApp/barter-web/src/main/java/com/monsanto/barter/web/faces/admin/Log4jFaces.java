package com.monsanto.barter.web.faces.admin;

import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.util.ManagedLogger;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import java.util.*;

@ManagedBean(name="log4jFaces")
@SessionScoped
public class Log4jFaces extends BaseJSF {

    private static final Logger LOG = Logger.getLogger(Log4jFaces.class);

    public static final String LOG4J_ADMIN_LIST = "log4jAdmin_list";
    public static final String LOG4J_ADMIN_FORM = "log4jAdmin_form";
    private ManagedLogger currentLogger;
    private DataTable dataTable;
    private String searchName=null;
    private DataModel<ManagedLogger> list;

    public String begin() {
        // TODO: Validate user's grants and roles
        searchName = null;
        list = new ListDataModel<ManagedLogger>(getManagedLoggerList());
        return LOG4J_ADMIN_LIST;
    }

    @SuppressWarnings("unchecked")
    public List<Logger> getLoggerList() {
        List<Logger> currentLoggers = Collections.<Logger>list(LogManager.getCurrentLoggers());
        currentLoggers.add(getRootLogger());

        Collections.sort(currentLoggers, new Comparator<Logger>() {

            @Override
            public int compare(Logger o1, Logger o2) {
                String o1Name = o1.getName();
                String o2Name = o2.getName();

                return o1Name.compareTo(o2Name);
            }
        });

        return currentLoggers;
    }

    public List<ManagedLogger> getManagedLoggerList() {
        List<ManagedLogger> managedLoggerList = new ArrayList<ManagedLogger>();
        for (Logger logger : getLoggerList()) {
            if(searchName!=null && !searchName.isEmpty()) {
                if(logger.getName().contains(searchName)) {
                    ManagedLogger e = new ManagedLogger(logger,  logger.getEffectiveLevel().toString());
                    managedLoggerList.add(e);
                }
            } else {
                ManagedLogger e = new ManagedLogger(logger,  logger.getEffectiveLevel().toString());
                managedLoggerList.add(e);
            }
        }
        return managedLoggerList;
    }

    public Logger getRootLogger() {
        return LogManager.getRootLogger();
    }

    public ManagedLogger getCurrentLogger() {
        return currentLogger;
    }

    public void setCurrentLogger(ManagedLogger currentLogger) {
        this.currentLogger = currentLogger;
    }

    public void setDataTable(DataTable dataTable) {
        this.dataTable = dataTable;
    }

    public DataTable getDataTable() {
        return dataTable;
    }

     public String search() {
        // find out the currently selected logger.
        list = new ListDataModel<ManagedLogger>(getManagedLoggerList());

        return LOG4J_ADMIN_LIST;
    }

    public String getSearchName() {
        return searchName;
    }

    public void setSearchName(String searchName) {
        this.searchName = searchName;
    }

    public String prependUpdate() {
        currentLogger = list.getRowData();
        return LOG4J_ADMIN_FORM;
    }

    public String back() {
        currentLogger = null;
        return LOG4J_ADMIN_LIST;
    }

    public DataModel<ManagedLogger> getList() {
        return list;
    }

    public void setList(DataModel<ManagedLogger> list) {
        this.list = list;
    }

    public String save(){
		try {
            Level level = Level.toLevel(currentLogger.getLevel());
            Logger logger = currentLogger.getLogger();
            logger.setLevel(level);
            this.setMessages(new MessageVO("record.successfully.changed", MessageTypeList.INFO, logger.getName()));
		} catch (Exception e) {
            LOG.error(e.getMessage(), e);
			this.setMessages(e.getMessage());
			return null;
		}

        return LOG4J_ADMIN_FORM;
    }
}