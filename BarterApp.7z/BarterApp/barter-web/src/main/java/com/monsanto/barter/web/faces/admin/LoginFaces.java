package com.monsanto.barter.web.faces.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpSession;

import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.list.StatusList;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.business.util.IBarterConstants;
import org.apache.log4j.Logger;

/**
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 10/01/2012
 */
public class LoginFaces extends BaseJSF {

    private static final Logger LOG = Logger.getLogger(LoginFaces.class);

    /** */
    private static final long serialVersionUID = -8209594631467413788L;

    private User user;

    private List<SelectItem> itemsLogin;

    /**
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public LoginFaces() {

        super();

        initForm();
    }

    public String login() {

        if (hasValue(this.user.getId())) {

            IUserService userService = getService(IUserService.class);
            try {

                com.monsanto.barter.business.entity.table.User userEntity = new com.monsanto.barter.business.entity.table.User();
                userEntity.setUserIdMonsanto(this.user.getId());

                com.monsanto.barter.business.entity.table.User userVO = userService
                    .findByIdMonsantoWithPermission(userEntity);

                if (userVO != null) {
                    user.setId(userVO.getId());
                    user.setName(userVO.getName());
                    user.setEmail(userVO.getEmail());
                    user.setLanguageCd(userVO.getLanguageCd());

                    for (com.monsanto.barter.business.entity.table.Permission permission : userVO.getPermissions()) {
                        user.getPermissions().add(new Permission(permission.getPermissionCd()));
                    }

                    if (userVO.getGroup() != null) {
                        for (com.monsanto.barter.business.entity.table.Permission permission : userVO.getGroup()
                            .getPermissions()) {
                            user.getPermissions().add(new Permission(permission.getPermissionCd()));
                        }
                    }

                    HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext()
                        .getSession(true);
                    session.setAttribute(MessageUtil.getMessage(IBarterConstants.SECURITY_USER), user);
                    SecurityUtil.setLoggedInUser(user);

                } else {
                    FacesContext.getCurrentInstance().getExternalContext().redirect("login_error.jsf");
                    return ERROR;
                }

            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
                showHtmlException(e);
            }
        }

        return SUCCESS;
    }

    private void initForm() {

        this.user = new User();
        loadUsers();
    }

    private void loadUsers() {

        IUserService userService = getService(IUserService.class);

        UserFilter userFilter = new UserFilter();
        com.monsanto.barter.business.entity.table.User usu = new com.monsanto.barter.business.entity.table.User();
        usu.setStatus(StatusList.ACTIVE.getFlag());
        userFilter.setUser(usu);

        List<com.monsanto.barter.business.entity.table.User> userList = userService.search(userFilter);

        if (!userList.isEmpty()) {

            for (com.monsanto.barter.business.entity.table.User userVO : userList) {

                getItemsLogin().add(new SelectItem(userVO.getUserIdMonsanto(), userVO.getName()));
            }
        }
        // Usuario nao existente na base para testes da pagina de erro
        getItemsLogin().add(new SelectItem("Usuario NE", "Usuario NE"));
    }

    /**
     * @return the user
     */
    public User getUser() {

        return user;
    }

    /**
     * @param user - the user to set
     */
    public void setUser(User user) {

        this.user = user;
    }

    /**
     * @return the itemsLogin
     */
    public List<SelectItem> getItemsLogin() {

        if (itemsLogin == null) {

            itemsLogin = new ArrayList<SelectItem>();
        }

        return itemsLogin;
    }

    /**
     * @param itemsLogin - the itemsLogin to set
     */
    public void setItemsLogin(List<SelectItem> itemsLogin) {

        this.itemsLogin = itemsLogin;
    }

}
