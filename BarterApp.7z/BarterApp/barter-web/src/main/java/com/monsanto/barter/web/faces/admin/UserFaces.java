/**
 * 
 */
package com.monsanto.barter.web.faces.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.util.SecurityUtil;
import org.apache.commons.lang.StringUtils;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.PermissionBusiness;
import com.monsanto.barter.business.entity.filter.GroupFilter;
import com.monsanto.barter.business.entity.filter.PermissionFilter;
import com.monsanto.barter.business.entity.filter.RegionalFilter;
import com.monsanto.barter.business.entity.filter.UnitFilter;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.list.LanguageList;
import com.monsanto.barter.business.entity.list.ModuleList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.list.PermissionTypeList;
import com.monsanto.barter.business.entity.list.StatusList;
import com.monsanto.barter.business.entity.list.YesNoList;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.Permission;
import com.monsanto.barter.business.entity.table.Regional;
import com.monsanto.barter.business.entity.table.SaleDistrict;
import com.monsanto.barter.business.entity.table.Unit;
import com.monsanto.barter.business.entity.table.User;
import com.monsanto.barter.business.service.IGroupService;
import com.monsanto.barter.business.service.IPermissionService;
import com.monsanto.barter.business.service.IRegionalService;
import com.monsanto.barter.business.service.ISaleDistrictService;
import com.monsanto.barter.business.service.IUnitService;
import com.monsanto.barter.business.service.IUserService;

/**
 * Managed Bean for registration and user research
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 21/11/2011
 * 
 */

@ManagedBean(name="userFaces")
@SessionScoped
public class UserFaces extends BaseJSF {

    /** */
    private static final long serialVersionUID = 7089408196301707411L;

    private String tab;

    private UserFilter userFilter;

    private User userVO;

    private String groupId;

    private String unitId;

    private String regionalId;

    private String saleDistrictId;

    private String module;

    private Integer moduleId;

    private String permissionType;

    private Integer permissionTypeId;

    private boolean enableRegionalCombo;

    private boolean enableSaleDistrictCombo;

    private boolean tableShow;

    private List<User> users;

    private List<PermissionBusiness> permissions;

    private List<SelectItem> itemsUnit;

    private List<SelectItem> itemsRegional;

    private List<SelectItem> itemsSaleDistrict;

    private List<SelectItem> itemsGroup;

    private List<SelectItem> itemsLanguages;

    private List<SelectItem> itemsCountries;

    private List<SelectItem> itemsStatus;

    private List<SelectItem> itemsModules;

    private List<SelectItem> itemsPermissionTypes;


    /**
     * Default constructor of the class.
     */
    public UserFaces() {

        super();

        Boolean param = getParameterBoolean("isSearching");
        if (param != null) {
            setSearching(param.booleanValue());
        }

        initForm();
        this.userFilter = new UserFilter();

    }

    public String begin(){
        initForm();
        setSearching(true);
        this.setUserFilter(new UserFilter());
        userFilter.setCountryCd(getCountry().getCountrySAPCd());
        return SUCCESS;
    }

    /**
     * Search users by filter
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String searchUser() {
        IUserService userService = getService(IUserService.class);

        try {
            userFilter.setCountryCd(getCountry().getCountrySAPCd());
            users = userService.search(userFilter);

            tableShow = (!users.isEmpty());

            setSearching(true);

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(userService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SUCCESS;
    }

    /**
     * Prepares to register a new user
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String newUser() {

        showUsersTab();

        initForm();

        /*
         * Informa que a tela nao esta em modo de inclusao.
         */
        setNewer(true);

        return NEW;
    }

    /**
     * Editing a user
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String editUser() {

        IUserService userService = getService(IUserService.class);

        try {

            this.userVO = userService.findByIdWithPermissionAndHistory(userVO);

            if (hasValue(userVO.getUnit())) {
                this.unitId = userVO.getUnit().getId();
                loadRegionals(userVO.getUnit());
            }

            if (hasValue(userVO.getRegional())) {
                this.regionalId = userVO.getRegional().getId();
                loadSaleDistricts(userVO.getRegional());
            }

            if (hasValue(userVO.getSaleDistrict())) {
                this.saleDistrictId = userVO.getSaleDistrict().getId().toString();
            }

            if (hasValue(userVO.getGroup())) {
                this.groupId = userVO.getGroup().getId().toString();
            }

            loadPermissions(null, null);

            /*
             * Informa que a tela nao esta em modo de inclusao.
             */
            setNewer(false);
            /*
             * Informa que a tela nao esta em modo de pesquisa por usar cboUnitListener compartilhado entre pesquisa e
             * cadastro
             */
            setSearching(false);

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(userService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return CHANGE;
    }

    /**
     * Detail a user
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String detailUser() {

        String navigation = editUser();

        setDetail(false);

        return navigation;
    }

    /**
     * Register a new user
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String saveUser() {

        IUserService userService = getService(IUserService.class);
        ISaleDistrictService saleDistrictService = getService(ISaleDistrictService.class);
        IPermissionService permissionService = getService(IPermissionService.class);

        IGroupService groupService = null;
        String navigation = NOT_NAVIGATE;

        try {

            if (hasValue(saleDistrictId)) {

                SaleDistrict saleDistrictVO = saleDistrictService.findById(new SaleDistrict(Long
                    .valueOf(saleDistrictId)));
                userVO.setSaleDistrict(saleDistrictVO);
            } else {
                userVO.setSaleDistrict(null);
            }

            if (hasValue(groupId)) {

                groupService = getService(IGroupService.class);
                Group groupVO = groupService.findById(new Group(Long.valueOf(groupId)));
                userVO.setGroup(groupVO);
            } else {
                userVO.setGroup(null);
            }

            // obtem as permissoes que foram selecionadas para o usuario (e as de grupo, se houver)
            List<Permission> checkedPermissions = permissionService.getCheckedPermissions(getPermissions());

            // ontem as permissoes que nao foram selecionadas pelo usuário
            List<Permission> uncheckedPermissions = permissionService.getUncheckedPermissions(getPermissions());

            userVO.setPermissions(userService.validatePermissions(userVO.getPermissions(), checkedPermissions,
                uncheckedPermissions));

            // define o flag que indica que o registro foi atualizado na web
            userVO.setUpdateWeb(YesNoList.YES.getFlag());

            // setting country and language using countryHolder configuration
            userVO.setLanguageCd(getCountry().getCodLanguage());
            userVO.setCountryCd(getCountry().getCountrySAPCd());

            if (isNewer()) {
                userService.save(userVO);
                unitId = StringUtils.EMPTY;
                userFilter.setRegionalId(StringUtils.EMPTY);
                userFilter.setGroupId(StringUtils.EMPTY);
                userFilter.getUser().setName(StringUtils.EMPTY);
                userFilter.getUser().setId(StringUtils.EMPTY);
                userFilter.getUser().setStatus(null);
            } else {
                userService.update(userVO);
            }

            if (userService.isOk()) {
                initForm();
                this.tableShow = true;
                users = userService.search(userFilter);
                setTableShow(!users.isEmpty());
                navigation = SHOW_FILTER;
                setSearching(true);
            }

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(userService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return navigation;
    }

    /**
     * Cancel the registration of a new user
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String cancelUser() {

        IUserService userService = getService(IUserService.class);

        try {
            setSearching(true);
            if (isNewer()) {
                return SHOW_FILTER;
            } else {
                initForm();
                this.tableShow = true;
                users = userService.search(userFilter);
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SHOW_FILTER;
    }

    /**
     * Show users tab
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public final String showUsersTab() {

        this.tab = "tabUser";

        return NOT_NAVIGATE;
    }

    /**
     * Show permissions tab
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String showPermissionsTab() {

        this.tab = "tabPermissions";

        return NOT_NAVIGATE;
    }

    /**
     * Show history tab
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String showHistoryTab() {

        this.tab = "tabHistory";

        return NOT_NAVIGATE;
    }

    /**
     * Combo group listener
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void cboGroupListener() {

        if (hasValue(groupId)) {
            loadPermissions(null, null);
        }
    }

    /**
     * Combo unit listener
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void cboUnitListener() {

        regionalId = StringUtils.EMPTY;
        saleDistrictId = StringUtils.EMPTY;

        Unit unitPk = null;

        if (isSearching()) {

            unitPk = new Unit(userFilter.getUnitId());
        } else {
            unitPk = new Unit(unitId);
        }

        if (hasValue(unitPk.getId())) {

            try {

                IUnitService unitService = getService(IUnitService.class);
                Unit unitVO = unitService.findById(unitPk);

                if (!isSearching()) {

                    userVO.setUnit(unitVO);
                }

                loadRegionals(unitVO);

            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
                showHtmlException(e);
            }
        } else {
            if (!isSearching()) {

                this.userVO.setUnit(null);
                this.userVO.setRegional(null);
                this.userVO.setSaleDistrict(null);
                this.regionalId = null;
                this.saleDistrictId = null;
            }
            this.itemsRegional = new ArrayList<SelectItem>();
            userFilter.setRegionalId(null);
        }
        this.itemsSaleDistrict = new ArrayList<SelectItem>();
    }

    /**
     * Combo regional listener
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void cboRegionalListener() {

        saleDistrictId = StringUtils.EMPTY;

        Regional regionalPk = null;

        if (isSearching()) {

            regionalPk = new Regional(userFilter.getRegionalId());
        } else {

            regionalPk = new Regional(regionalId);
        }

        if (hasValue(regionalPk.getId())) {

            try {

                IRegionalService regionalService = getService(IRegionalService.class);
                Regional regionalVO = regionalService.findById(new Regional(regionalId));

                if (!isSearching()) {

                    userVO.setRegional(regionalVO);
                }

                loadSaleDistricts(regionalVO);

            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
                showHtmlException(e);
            }
        } else {
            if (!isSearching()) {

                this.userVO.setRegional(null);
                this.userVO.setSaleDistrict(null);
                this.saleDistrictId = null;
            }
            this.itemsSaleDistrict = new ArrayList<SelectItem>();
        }
    }

    /**
     * Combo module listener
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void cboModuleListener() {

        if (hasValue(module)) {

            this.moduleId = Integer.valueOf(getModule());
        } else {
            this.moduleId = null;
        }

        loadPermissions(getModuleId(), getPermissionTypeId());
    }

    /**
     * combo permission type listener
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void cboPermissionTypeListener() {

        if (hasValue(permissionType)) {

            this.permissionTypeId = Integer.valueOf(getPermissionType());
        } else {
            this.permissionTypeId = null;
        }
        loadPermissions(getModuleId(), getPermissionTypeId());
    }

    /**
     * Initializes the page clears all objects.
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void initForm() {
        permissions = null;
        this.userVO = new User();
        this.userVO.setBarterUser(StatusList.ACTIVE.getFlag());
        this.userVO.setUpdateWeb(YesNoList.YES.getFlag());
        this.userVO.setPermissions(new ArrayList<Permission>());
        this.groupId = null;
        this.unitId = null;
        this.regionalId = null;
        this.saleDistrictId = null;
        this.enableRegionalCombo = false;
        this.enableSaleDistrictCombo = false;
        this.tableShow = false;
        this.setMessages("");

        // Limpa os itens dos combos
        initListItems();

        // Carrega os itens das unidades
        loadUnits();

        // Carrega os itens dos grupos
        loadGroups();

        // Exibe a aba de cadastro/edicao de usuario
        showUsersTab();

        // Carrega as permissoes
        loadPermissions(null, null);

        loadCountries();
    }

    /**
     * Initializes lists
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void initListItems() {

        users = new ArrayList<User>();
        itemsRegional = new ArrayList<SelectItem>();
        itemsSaleDistrict = new ArrayList<SelectItem>();
        itemsGroup = new ArrayList<SelectItem>();
        itemsLanguages = new ArrayList<SelectItem>();
        itemsStatus = new ArrayList<SelectItem>();
    }

    /**
     * Loads the unit comboBox
     * 
     * @return Items comboBox
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadUnits() {

        itemsUnit = new ArrayList<SelectItem>();

        //IUnitService unitService = SpringUtil.getService(IUnitService.class);
        IUnitService unitService = getService(IUnitService.class);

        UnitFilter filter = new UnitFilter();
        filter.getUnit().setCountryCd( getCountry().getCountrySAPCd() );
        List<Unit> units = unitService.search(filter);


        for (Unit unit : units) {
            itemsUnit.add(new SelectItem(unit.getId(), unit.getName()));
        }
    }

    /**
     * Loads the regional comboBox
     * 
     * @param unit Unit Id
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadRegionals(Unit unit) {

        if (hasValue(unit)) {

            IRegionalService regionalService = getService(IRegionalService.class);

            UnitFilter filter = new UnitFilter();
            filter.setUnit(unit);
            List<Regional> regionals = regionalService.search(filter);

            if (regionals != null) {

                itemsRegional = new ArrayList<SelectItem>();
                for (Regional regional : regionals) {

                    itemsRegional.add(new SelectItem(regional.getId(), regional.getName()));
                }

                // habilita o combobox
                this.enableRegionalCombo = true;
            } else {
                this.enableRegionalCombo = false;
            }
        }
    }

    /**
     * Loads the sale districts comboBox
     * 
     * @param regional {@link Regional}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadSaleDistricts(Regional regional) {

        if (hasValue(regional)) {

            ISaleDistrictService saleDistrictService = getService(ISaleDistrictService.class);

            RegionalFilter filter = new RegionalFilter();
            filter.setRegional(regional);
            List<SaleDistrict> saleDistricts = saleDistrictService.search(filter);

            if (saleDistricts != null) {

                itemsSaleDistrict = new ArrayList<SelectItem>();
                for (SaleDistrict saleDistrict : saleDistricts) {

                    itemsSaleDistrict.add(new SelectItem(saleDistrict.getId(), saleDistrict.getName()));
                }

                // habilita o combobox
                this.enableSaleDistrictCombo = true;
            } else {
                this.enableSaleDistrictCombo = false;
            }
        }
    }

    /**
     * Loads the group comboBox
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadGroups() {

        itemsGroup = new ArrayList<SelectItem>();

        IGroupService groupService = getService(IGroupService.class);

        List<Group> groups = groupService.search(new GroupFilter());
        for (Group group : groups) {
            itemsGroup.add(new SelectItem(group.getId(), group.getName()));
        }
    }

    /**
     * Loads the language comboBox
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadLanguages() {

        itemsLanguages = new ArrayList<SelectItem>();
        for (LanguageList languageList : LanguageList.values()) {
            itemsLanguages.add(new SelectItem(languageList.getCodLanguage(), getMessage(languageList.getName())));
        }
    }

    private void loadCountries() {

        itemsCountries = new ArrayList<SelectItem>();
            for ( Country country : Country.values() ) {
                itemsCountries .add(new SelectItem(country.getCountryISOCd(), getMessage(country.getCountryName())));
            }

        }





    /**
     * Loads the status comboBox
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadStatus() {

        itemsStatus = new ArrayList<SelectItem>();
        for (StatusList statusList : StatusList.values()) {
            itemsStatus.add(new SelectItem(statusList.getFlag(), getMessage(statusList.getName())));
        }
    }

    /**
     * Loads the permissions. Check the permissions contained in the lists of group permissions and user permissions.
     * 
     * @param moduleId Module id
     * @param permissionTypeId Permission Type id
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadPermissions(Integer moduleId, Integer permissionTypeId) {

        IPermissionService permissionService = getService(IPermissionService.class);
        IGroupService groupService = getService(IGroupService.class);


        List<PermissionBusiness> allPermissions = null;
        List<Permission> groupPermissions = null;
        List<Permission> userPermissions = null;

        Long groupIdToLong = null;
        try {
            groupIdToLong = Long.valueOf(this.groupId);
        } catch (Exception e) {
            groupIdToLong = null;
        }

        Group groupVO = groupService.findByIdComplete(new Group(groupIdToLong));
        userVO.setGroup(groupVO);

        if (groupVO != null) {
            groupPermissions = groupVO.getPermissions();
        } else {
            groupPermissions = new ArrayList<Permission>();
        }

        if (userVO.getPermissions() != null) {
            userPermissions = userVO.getPermissions();
        } else {
            userPermissions = new ArrayList<Permission>();
        }

        permissions = permissionService.applyPermissions(getPermissions(), groupPermissions, userPermissions);

        List<Permission> checkedPermissions = permissionService.getCheckedPermissions(getPermissions());

        if (checkedPermissions != null) {

            for (Permission checkedPermission : checkedPermissions) {

                if (!userPermissions.contains(checkedPermission)) {
                    userPermissions.add(checkedPermission);
                }
            }
        }

        List<Permission> uncheckedPermissions = permissionService.getUncheckedPermissions(getPermissions());

        if (uncheckedPermissions != null) {

            for (Permission uncheckedPermission : uncheckedPermissions) {

                if (userPermissions.contains(uncheckedPermission)) {
                    userPermissions.remove(uncheckedPermission);
                }
            }
        }

        allPermissions = permissionService.search(new PermissionFilter(null, moduleId, permissionTypeId));

        permissions = permissionService.applyPermissions(allPermissions, groupPermissions, userPermissions);
    }

    /**
     * Loads the modules comboBox
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadModules() {

        itemsModules = new ArrayList<SelectItem>();
        for (ModuleList moduleList : ModuleList.values()) {
            itemsModules.add(new SelectItem(moduleList.getModuleCd(), getMessage(moduleList.getName())));
        }
    }

    /**
     * Loads the permission type comboBox
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadPermissionTypes() {

        itemsPermissionTypes = new ArrayList<SelectItem>();
        for (PermissionTypeList permissionTypeList : PermissionTypeList.values()) {
            itemsPermissionTypes.add(new SelectItem(permissionTypeList.getPermissionTypeCd(),
                getMessage(permissionTypeList.getName())));
        }
    }

    /**
     * Gets the quantity of users
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public int getQtUsers() {

        int count = 0;
        if (this.users != null) {
            count = this.users.size();
        }
        return count;
    }

    /**
     * Gets the quantity of permissions
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public int getQtPermissions() {

        int count = 0;
        if (this.permissions != null) {
            count = this.permissions.size();
        }
        return count;
    }

    /**
     * Gets the quantity of user history
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public int getQtUserHistory() {

        int count = 0;
        if (this.userVO != null && this.userVO.getHistories() != null) {
            count = this.userVO.getHistories().size();
        }
        return count;
    }

    /**
     * @return the tab
     */
    public String getTab() {

        return tab;
    }

    /**
     * @param tab the tab to set
     */
    public void setTab(String tab) {

        this.tab = tab;
    }

    /**
     * @return the userFilter
     */
    public UserFilter getUserFilter() {

        return userFilter;
    }

    /**
     * @param userFilter the userFilter to set
     */
    public void setUserFilter(UserFilter userFilter) {

        this.userFilter = userFilter;
    }

    /**
     * @return the userVO
     */
    public User getUserVO() {

        return userVO;
    }

    /**
     * @param userVO the userVO to set
     */
    public void setUserVO(User userVO) {

        this.userVO = userVO;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {

        return groupId;
    }

    /**
     * @param groupId - the groupId to set
     */
    public void setGroupId(String groupId) {

        this.groupId = groupId;
    }

    /**
     * @return the unitId
     */
    public String getUnitId() {

        return unitId;
    }

    /**
     * @param unitId the unitId to set
     */
    public void setUnitId(String unitId) {

        this.unitId = unitId;
    }

    /**
     * @return the regionalId
     */
    public String getRegionalId() {

        return regionalId;
    }

    /**
     * @param regionalId the regionalId to set
     */
    public void setRegionalId(String regionalId) {

        this.regionalId = regionalId;
    }

    /**
     * @return the saleDistrictId
     */
    public String getSaleDistrictId() {

        return saleDistrictId;
    }

    /**
     * @param saleDistrictId the saleDistrictId to set
     */
    public void setSaleDistrictId(String saleDistrictId) {

        this.saleDistrictId = saleDistrictId;
    }

    /**
     * @return the module
     */
    public String getModule() {

        return module;
    }

    /**
     * @param module - the module to set
     */
    public void setModule(String module) {

        this.module = module;
    }

    /**
     * @return the moduleId
     */
    public Integer getModuleId() {

        return moduleId;
    }

    /**
     * @param moduleId - the moduleId to set
     */
    public void setModuleId(Integer moduleId) {

        this.moduleId = moduleId;
    }

    /**
     * @return the permissionType
     */
    public String getPermissionType() {

        return permissionType;
    }

    /**
     * @param permissionType - the permissionType to set
     */
    public void setPermissionType(String permissionType) {

        this.permissionType = permissionType;
    }

    /**
     * @return the permissionTypeId
     */
    public Integer getPermissionTypeId() {

        return permissionTypeId;
    }

    /**
     * @param permissionTypeId - the permissionTypeId to set
     */
    public void setPermissionTypeId(Integer permissionTypeId) {

        this.permissionTypeId = permissionTypeId;
    }

    /**
     * @return the itemsGroup
     */
    public List<SelectItem> getItemsGroup() {

        return itemsGroup;
    }

    /**
     * @param itemsGroup - the itemsGroup to set
     */
    public void setItemsGroup(List<SelectItem> itemsGroup) {

        this.itemsGroup = itemsGroup;
    }

    /**
     * @return the enableRegionalCombo
     */
    public boolean isEnableRegionalCombo() {

        return enableRegionalCombo;
    }

    /**
     * @param enableRegionalCombo the enableRegionalCombo to set
     */
    public void setEnableRegionalCombo(boolean enableRegionalCombo) {

        this.enableRegionalCombo = enableRegionalCombo;
    }

    /**
     * @return the enableSaleDistrictCombo
     */
    public boolean isEnableSaleDistrictCombo() {

        return enableSaleDistrictCombo;
    }

    /**
     * @param enableSaleDistrictCombo the enableSaleDistrictCombo to set
     */
    public void setEnableSaleDistrictCombo(boolean enableSaleDistrictCombo) {

        this.enableSaleDistrictCombo = enableSaleDistrictCombo;
    }

    /**
     * @return the tableShow
     */
    public boolean isTableShow() {

        return tableShow;
    }

    /**
     * @param tableShow the tableShow to set
     */
    public void setTableShow(boolean tableShow) {

        this.tableShow = tableShow;
    }

    /**
     * @return the users
     */
    public List<User> getUsers() {

        return users;
    }

    /**
     * @param users the users to set
     */
    public void setUsers(List<User> users) {

        this.users = users;
    }

    /**
     * @return the permissions
     */
    public List<PermissionBusiness> getPermissions() {

        return permissions;
    }

    /**
     * @param permissions - the permissions to set
     */
    public void setPermissions(List<PermissionBusiness> permissions) {

        this.permissions = permissions;
    }

    /**
     * @return the itemsUnit
     */
    public List<SelectItem> getItemsUnit() {

        return itemsUnit;
    }

    /**
     * @param itemsUnit the itemsUnit to set
     */
    public void setItemsUnit(List<SelectItem> itemsUnit) {

        this.itemsUnit = itemsUnit;
    }

    /**
     * @return the itemsRegional
     */
    public List<SelectItem> getItemsRegional() {

        return itemsRegional;
    }

    /**
     * @param itemsRegional the itemsRegional to set
     */
    public void setItemsRegional(List<SelectItem> itemsRegional) {

        this.itemsRegional = itemsRegional;
    }

    /**
     * @return the itemsSaleDistrict
     */
    public List<SelectItem> getItemsSaleDistrict() {

        return itemsSaleDistrict;
    }

    /**
     * @param itemsSaleDistrict the itemsSaleDistrict to set
     */
    public void setItemsSaleDistrict(List<SelectItem> itemsSaleDistrict) {

        this.itemsSaleDistrict = itemsSaleDistrict;
    }

    /**
     * @return the itemsLanguages
     */
    public List<SelectItem> getItemsLanguages() {

        // Carrega os idiomas
        loadLanguages();

        return itemsLanguages;
    }

    /**
     * @param itemsLanguages the itemsLanguages to set
     */
    public void setItemsLanguages(List<SelectItem> itemsLanguages) {

        this.itemsLanguages = itemsLanguages;
    }

    /**
     * @return the itemsStatus
     */
    public List<SelectItem> getItemsStatus() {

        // Carrega os status
        loadStatus();

        return itemsStatus;
    }

    /**
     * @param itemsStatus the itemsStatus to set
     */
    public void setItemsStatus(List<SelectItem> itemsStatus) {

        this.itemsStatus = itemsStatus;
    }

    /**
     * @return the itemsModules
     */
    public List<SelectItem> getItemsModules() {

        loadModules();

        return itemsModules;
    }

    /**
     * @param itemsModules the itemsModules to set
     */
    public void setItemsModules(List<SelectItem> itemsModules) {

        this.itemsModules = itemsModules;
    }

    /**
     * @return the itemsPermissionTypes
     */
    public List<SelectItem> getItemsPermissionTypes() {

        loadPermissionTypes();

        return itemsPermissionTypes;
    }

    /**
     * @param itemsPermissionTypes the itemsPermissionTypes to set
     */
    public void setItemsPermissionTypes(List<SelectItem> itemsPermissionTypes) {

        this.itemsPermissionTypes = itemsPermissionTypes;
    }

    /**
     * Checks if the authenticated user has access permission for the function userNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
        public boolean isEnableSaveBtn() {

        return access(PermissionList.NEW_USER_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    public List<SelectItem> getItemsCountries() {
        return itemsCountries;
    }

}
