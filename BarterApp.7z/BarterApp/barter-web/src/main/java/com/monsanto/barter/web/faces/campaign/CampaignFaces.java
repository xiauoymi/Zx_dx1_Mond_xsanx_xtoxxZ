package com.monsanto.barter.web.faces.campaign;

import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.service.AttachmentService;
import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.CampaignBrandBusiness;
import com.monsanto.barter.business.entity.business.CampaignDivisionUnitBusiness;
import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.CampaignSituationList;
import com.monsanto.barter.business.entity.list.CampaignStatusList;
import com.monsanto.barter.business.entity.list.DocumentTypeList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.service.impl.CampaignService;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.fileupload.FileUpload;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.trim;

// import org.ajax4jsf.component.html.HtmlAjaxCommandButton;

/**
 * Class responsible for controlling the pages of Campaign feature.
 *
 * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
 * @since 13/12/2011
 */
public class CampaignFaces extends BaseJSF {

    protected static final Logger LOG = Logger.getLogger(CampaignFaces.class);

    private static final String HIFEN = "-";

    private static final String CBO_DIVISIONS = "cboDivisions";

    private static final String CBO_DIVISION_BRANDS = "cboDivisionBrands";

    private static final String CBO_BRANDS = "cboBrands";

    private static final String CBO_UNITS = "cboUnits";

    private static final String CBO_BARTER_TYPES = "cboBarterTypes";

    private static final String TXT_VOLUME_UNIT = "volumeUnit";

    private static final String CBO_UNIT_ALL = "combo.unit.all";

    private static final long serialVersionUID = 3364467355763026261L;

    private Campaign campaign;

    private CampaignFilter campaignFilter;

    private Trading trading;

    private Commodity commodity;

    private CampaignBrandBusiness brand;

    private CampaignDivisionUnitBusiness divisionUnit;

    private BarterType barterType;

    private String divisionId;

    private String tradingId;

    private String commodityId;

    private String brandId;

    private String divisionBrandId;

    private String unitBrandId;

    private String unitId;

    private String barterTypeId;

    private String tab;

    private BigDecimal discountBrand;

    private BigDecimal volumeUnit;

    private BigDecimal volumeUnitAvaliable;

    private BigDecimal valueMaxBarter;

    private BigDecimal valueBarterConsumed;

    private BigDecimal valueBarterAvaliable;

    private BigDecimal valueMaxDiscount;

    private BigDecimal valueDiscountConsumed;

    private BigDecimal valueDiscountAvaliable;

    private Character languageLoggedInUser;

    private boolean enableSaveBtn;

    private boolean tableShow;

    private boolean buttonValidate;

    private boolean buttonSendValidate;

    private boolean buttonReturn;

    private boolean buttonInactivate;

    private boolean noEditable;

    private boolean executeSearch;

    private List<Campaign> campaignList;

    private List<SelectItem> statusCampaign;

    private List<SelectItem> divisionsCampaign;

    private List<SelectItem> countryCampaign;

    private List<SelectItem> currencyCampaign;

    private List<SelectItem> tradingsCampaign;

    private List<SelectItem> commoditiesCampaign;

    private List<SelectItem> brandsCampaign;

    private List<SelectItem> unitsCampaign;

    private List<SelectItem> barterTypeCampaign;

    private List<CampaignBrandBusiness> brandsCampaignList;

    private List<CampaignDivisionUnitBusiness> divisionUnitsCampaignList;

    private List<CampaignBrand> brandsCampaignDelete;

    private List<CampaignDivisionUnit> divisionUnitsCampaignDelete;

    private boolean editValidated = false;

    private boolean unitEdit;

    private List<SelectItem> whitepapers;

    //Attachaments
    private BarAttachment attachmentSelected;
    private boolean filesAttachedSuccessfully;
    private List<FileUpload> campaignFileUploadHandlers = new ArrayList<FileUpload>();
    private List<BarAttachment> attachments = new ArrayList<BarAttachment>();

    private boolean renderAttachmentPopup;
    private Campaign campaignSelected;


    /**
     * Construct default
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public CampaignFaces() {

        super();
        //campaignFilter = new CampaignFilter();
        //init();
    }

    /**
     * Initializes the page clears all objects.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void init() {

        this.campaignFilter = new CampaignFilter();
        this.campaign = new Campaign();
        this.setNewer(Boolean.TRUE);
        this.tableShow = Boolean.FALSE;
        this.buttonReturn = Boolean.TRUE;
        this.buttonSendValidate = Boolean.TRUE;
        this.buttonValidate = Boolean.TRUE;
        this.buttonInactivate = Boolean.TRUE;
        this.noEditable = Boolean.FALSE;
        this.campaign.setStatusCd(CampaignStatusList.DRAFT_CD.getCodStatus());
        this.campaign.setSituationCd(CampaignSituationList.ACTIVE_CD.getCodSituation());
        this.trading = new Trading();
        this.commodity = new Commodity();
        this.barterType = new BarterType();
        this.divisionUnit = new CampaignDivisionUnitBusiness();
        this.brand = new CampaignBrandBusiness();
        this.divisionId = null;
        this.divisionBrandId = null;
        this.tradingId = null;
        this.commodityId = null;
        this.brandId = null;
        this.unitBrandId = null;
        this.unitId = null;
        this.barterTypeId = null;
        this.discountBrand = null;
        this.volumeUnit = null;
        this.volumeUnitAvaliable = null;
        this.valueBarterConsumed = null;
        this.valueBarterAvaliable = null;
        this.valueDiscountConsumed = null;
        this.valueDiscountAvaliable = null;
        this.valueMaxBarter = BigDecimal.ZERO;
        this.valueMaxDiscount = BigDecimal.ZERO;
        this.campaignSelected = null;
        languageLoggedInUser = SecurityUtil.getLoggedInUser().getLanguageCd();

        // Initializes lists
        initListItems();

        // Initialize variables
        initializeVariables();

        // Loads status
        loadStatus();

        // Loads divisions
        loadDivisions();

        // Load coutries
        loadCountries();

        // Load currencies
        loadCurrencies();

        // Load units
        loadUnits();

        loadWhitepapers();

        // Displays trading tab
        showTradingTab();

        String countryCd = getCountryCd();
        loadTradings(countryCd);
        loadCommodities(countryCd);
        loadBarterTypes(countryCd);
    }

    public String begin(){
        init();
        return SUCCESS;
    }

    /**
     * Method responsible for initializing the lists
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void initListItems() {

        this.campaignList = new ArrayList<Campaign>();
        this.statusCampaign = new ArrayList<SelectItem>();
        this.divisionsCampaign = new ArrayList<SelectItem>();
        this.countryCampaign = new ArrayList<SelectItem>();
        this.currencyCampaign = new ArrayList<SelectItem>();
        this.tradingsCampaign = new ArrayList<SelectItem>();
        this.barterTypeCampaign = new ArrayList<SelectItem>();
        this.commoditiesCampaign = new ArrayList<SelectItem>();
        this.brandsCampaign = new ArrayList<SelectItem>();
        this.unitsCampaign = new ArrayList<SelectItem>();
        this.brandsCampaignList = new ArrayList<CampaignBrandBusiness>();
        this.divisionUnitsCampaignList = new ArrayList<CampaignDivisionUnitBusiness>();
        this.brandsCampaignDelete = new ArrayList<CampaignBrand>();
        this.divisionUnitsCampaignDelete = new ArrayList<CampaignDivisionUnit>();
        this.whitepapers = new ArrayList<SelectItem>();
    }

    /**
     * Method responsible for i
     *
     * @author Jader Augusto do nit of variables. Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void initializeVariables() {

        this.campaign.setCountry(new Country(new CountryId()));
        this.campaign.getCountry().getId().setCountryCd(getCountryCd());
        this.campaign.setCurrency(new Currency(new CurrencyId()));
        this.campaign.setAuthor(new User());
        this.campaign.setTradings(new ArrayList<Trading>());
        this.campaign.setBarterTypes(new ArrayList<BarterType>());
        this.campaign.setCommodities(new ArrayList<Commodity>());
        if ( isBarterParaguay() ){
            this.campaign.setWhitePaper( new WhitePaper());
        }
        this.campaignFilter.getCampaign().setAuthor(new User());
        this.campaignFilter.getCampaign().getAuthor().setLanguageCd(getLanguage());
        this.campaignFilter.getCampaign().setCountry(new Country(new CountryId()));
        this.campaignFilter.getCampaign().getCountry().getId().setCountryCd(getCountryCd());
    }

    /**
     * Method responsible for language of screen.
     *
     * @return the language for consultation in base.
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private Character getLanguage() {

        if (super.isNewer()) {
            return languageLoggedInUser;
        } else {
            return this.campaign.getCountry().getId().getLanguageCd();
        }
    }

    private String getCountryCd(){
        if(super.isNewer()){
            return SecurityUtil.getLoggedInUser().getCountyCd();
        }else{
            return this.campaign.getCountry().getId().getCountryCd();
        }
    }

    /**
     * Method that returns the User logged
     *
     * @return the user logged
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private String getUserLoggedId() {

        return SecurityUtil.getLoggedInUser().getId();
    }

    /**
     * Method responsible for save the campaign
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String saveCampaign() {

        String navigation = NOT_NAVIGATE;
        ICampaignService campaignService = getService(ICampaignService.class);

        try {

            completingCampaign();

            if (isNewer()) {
                campaignService.save(campaign);
                this.executeSearch = Boolean.FALSE;
            } else {
                campaignService.update(campaign, this.brandsCampaignDelete, this.divisionUnitsCampaignDelete);
                this.executeSearch = Boolean.TRUE;
            }

            if (campaignService.isOk()) {
                init();
                navigation = SHOW_FILTER;

                if (executeSearch) {
                    searchCampaign();
                }

                this.setMessages(campaignService.getMessages());
            } else {
                this.setMessages(campaignService.getMessages());
                for (final MessageVO message : campaignService.getMessages()) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        this.brandsCampaignDelete = new ArrayList<CampaignBrand>();
                        this.divisionUnitsCampaignDelete = new ArrayList<CampaignDivisionUnit>();
                        loadCampaignEditScreen(campaignService);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return navigation;
    }

    /**
     * Method responsible for completing the campaign data
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void completingCampaign() {

        this.campaign.setCampaignBrands(convertToCampaignBrand());
        List<CampaignDivisionUnit> divUnits = convertToCampaignDivisionUnit();
        List<CampaignDivisionUnit> currentUnits = campaign.getCampaignDivisionUnits();
        if (CollectionUtils.isEmpty(currentUnits)) {
            campaign.setCampaignDivisionUnits(divUnits);
        } else {

            updateCurrentDivisionUnits(divUnits, currentUnits);

            List<CampaignDivisionUnit> toBeRemoved = new ArrayList<CampaignDivisionUnit>();
            for (CampaignDivisionUnit c : currentUnits) {
                int indAux = divUnits.indexOf(c);
                if (indAux < 0) {
                    toBeRemoved.add(c);
                }
            }
            currentUnits.removeAll(toBeRemoved);
        }

        this.campaign.getAuthor().setId(getUserLoggedId());

        this.campaign.setMaxBilledAmt(this.valueMaxBarter);
        this.campaign.setMaxDiscount(this.valueMaxDiscount);
        this.campaign.setBarterAvailBal(this.valueBarterAvaliable);
        this.campaign.setDiscountAvailBal(this.valueDiscountAvaliable);
        this.campaign.getCountry().getId().setLanguageCd(getLanguage());
        this.campaign.getCurrency().getId().setLanguageCd(getLanguage());
    }

    private void updateCurrentDivisionUnits(List<CampaignDivisionUnit> divUnits, List<CampaignDivisionUnit> currentUnits) {
        for (CampaignDivisionUnit u : divUnits) {

            // check by primary key only
            if (u.getId() != null){
                int index = currentUnits.indexOf(u);
                if (index > -1){
                    CampaignDivisionUnit current = currentUnits.get(index);
                    setProps(current, u);
                }

                // check by division + unit
            } else {
                CampaignDivisionUnit existingObj = existsIn(currentUnits, u);
                if (existingObj != null){
                    setProps(existingObj, u);
                    u.setId(existingObj.getId());
                } else {
                    currentUnits.add(u);
                }
            }
        }
    }

    /**
     * Look for an object with the same Division and Unit in the set of objects passed *
     */
    private CampaignDivisionUnit existsIn(List<CampaignDivisionUnit> currentUnits, CampaignDivisionUnit u) {
        for (CampaignDivisionUnit cun : currentUnits) {
            if (cun.getDivision().equals(u.getDivision()) &&
                    cun.getUnitId().equals(u.getUnitId())) {
                return cun;
            }
        }
        return null;
    }

    /**
     * Fill <code>u</code> properties into <code>current</code>
     *
     * @param current
     * @param u
     * @author luciano.costa
     */
    private void setProps(CampaignDivisionUnit current, CampaignDivisionUnit u) {
        current.getDivision().setId(u.getDivision().getId());
        current.getDivision().setDesc(u.getDivision().getDesc());
        current.setUnitId(u.getUnitId());
        current.setVolumeAmt(u.getVolumeAmt());
        current.setVolumeAvail(u.getVolumeAvail());
    }

    /**
     * Method responsible for calling the search method from the business layer.
     *
     * @return A string defining the page navigation
     */
    public String
    searchCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);

        try {

            completingCampaignFilter();

            this.campaignList = campaignService.searchByDivision(this.campaignFilter);
            tableShow = (!campaignList.isEmpty());

            // Get messages from the business layer.
            this.setMessages(campaignService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return SUCCESS;
    }

    /**
     * Method responsible for filling the remaining data of the campaign
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void completingCampaignFilter() {

        this.campaignFilter.setDivisionId(null);
        this.campaignFilter.setLanguageCd(null);

        if (hasValue(this.divisionId)) {
            this.campaignFilter.setDivisionId(getCodigoDescricao(this.divisionId)[0]);
            this.campaignFilter.setLanguageCd(getLanguage());
        }
    }

    /**
     * Method responsible for updating the values ​​of the screen campaign
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void updateValuesBarter() {

        ICampaignService campaignService = getService(ICampaignService.class);
        Boolean isValid = null;

        isValid = campaignService.isValidValueBarter(valueMaxBarter, divisionUnitsCampaignList);

        if (!isValid) {
            this.setMessages(campaignService.getMessages());
        }

        BigDecimal differenceOfAmount;
        if(campaign.getMaxBilledAmt() != null) {
            differenceOfAmount = valueMaxBarter.subtract(campaign.getMaxBilledAmt());
        } else {
            differenceOfAmount = valueMaxBarter;
        }

        if(campaign.getBarterAvailBal() == null) {
            campaign.setBarterAvailBal(BigDecimal.ZERO);
        }

        this.valueBarterAvaliable = campaign.getBarterAvailBal().add(differenceOfAmount);

        if (isNewer()) {
            valueBarterConsumed = new BigDecimal(0);
        }
    }

    /**
     * Method responsible for updating the values ​​discount of the screen campaign
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void updateValuesDiscount() {

        BigDecimal differenceOfAmount;

        if(campaign.getMaxDiscountIncentive() != null) {
            differenceOfAmount = valueMaxDiscount.subtract(campaign.getMaxDiscount());
        } else {
            differenceOfAmount = valueMaxDiscount;
        }

        if(campaign.getDiscountAvailBal() == null) {
            campaign.setDiscountAvailBal(BigDecimal.ZERO);
        }

        this.valueDiscountAvaliable = campaign.getDiscountAvailBal().add(differenceOfAmount);

        if (isNewer()) {
            this.valueDiscountConsumed = new BigDecimal(0);
        }
    }

    /**
     * Method responsible for carrying out the operation of the campaign Validate
     *
     * @return A string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String validateCampaign() {

        String navigation = NOT_NAVIGATE;
        ICampaignService campaignService = getService(ICampaignService.class);

        campaignService.validateCampaign(this.campaign);
        final List<MessageVO> list = new ArrayList<MessageVO>(campaignService.getMessages());
        if(campaignService.isOk()){
            searchCampaign();
            navigation = SHOW_FILTER;
        } else {
            loadCampaignEditScreen(campaignService);
        }
        this.setMessages(list);

        return navigation;
    }

    /**
     * Method responsible for return the campaign
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String returnCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);

        campaignService.returnCampaign(this.campaign);

        if (campaignService.isOk()) {
            searchCampaign();
            this.setMessages(campaignService.getMessages());

            return SHOW_FILTER;
        } else {
            this.setMessages(campaignService.getMessages());
            loadCampaignEditScreen(campaignService);
            return NOT_NAVIGATE;
        }

    }

    /**
     * Method responsible for sending the campaign to validating
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String submitForValidation() {

        String navigation = NOT_NAVIGATE;
        ICampaignService campaignService = getService(ICampaignService.class);

        completingCampaign();
        if (isNewer()) {
            this.executeSearch = Boolean.FALSE;
        }else{
            this.executeSearch = Boolean.TRUE;
        }

        campaignService.submitForValidation(this.campaign, this.brandsCampaignDelete, this.divisionUnitsCampaignDelete);

        if (campaignService.isOk()) {
            if (isNewer()) {
                init();
                campaign = new Campaign();
            }

            if(this.executeSearch){
                searchCampaign();
            }

            navigation = SHOW_FILTER;
        }

        this.setMessages(campaignService.getMessages());
        for (final MessageVO message : campaignService.getMessages()) {
            if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                this.brandsCampaignDelete = new ArrayList<CampaignBrand>();
                this.divisionUnitsCampaignDelete = new ArrayList<CampaignDivisionUnit>();
                loadCampaignEditScreen(campaignService);
                break;
            }
        }

        return navigation;
    }

    /**
     * Method responsible for sending the campaign to validating
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String inactivateCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);

        campaignService.inactivateCampaign(this.campaign);

        if (campaignService.isOk()) {
            searchCampaign();
            this.setMessages(campaignService.getMessages());

            return SHOW_FILTER;
        } else {
            this.setMessages(campaignService.getMessages());
            loadCampaignEditScreen(campaignService);
            return NOT_NAVIGATE;
        }
    }

    /**
     * Method that converts a list to CampaignBrandBusiness a list CampaignBrand
     *
     * @return list of CampaignBrand
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<CampaignBrand> convertToCampaignBrand() {

        List<CampaignBrand> list = new ArrayList<CampaignBrand>();
        CampaignBrand campBrand = null;

        for (CampaignBrandBusiness cbb : this.brandsCampaignList) {
            campBrand = new CampaignBrand();
            campBrand.setCampaign(new Campaign());

            campBrand.setId(hasValue(cbb.getId()) ? cbb.getId() : null);

            if (hasValue(cbb.getIdUnit())) {
                campBrand.setUnitId(cbb.getIdUnit());
            }

            campBrand.setBrandCd(cbb.getIdBrand());
            campBrand.setCampaign(this.campaign);
            campBrand.setDivisionCd(cbb.getIdDivision());
            campBrand.setBrandDiscountPct(cbb.getDiscount());
            list.add(campBrand);
        }

        return list;
    }

    /**
     * Method that converts a list to CampaignBrand a list CampaignBrandBusiness
     *
     * @return list of CampaignBrandBusiness
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<CampaignBrandBusiness> convertToCampaignBrandBusiness() {

        IDivisionService divisionService = getService(IDivisionService.class);
        DivisionFilter divisionFilter = null;
        List<Division> division = null;

        List<CampaignBrandBusiness> list = new ArrayList<CampaignBrandBusiness>();
        CampaignBrandBusiness campBrandBuss = null;

        for (CampaignBrand cb : this.campaign.getCampaignBrands()) {
            divisionFilter = new DivisionFilter();
            divisionFilter.getDivision().setId(new DivisionId(cb.getDivisionCd(), getLanguage()));
            division = divisionService.search(divisionFilter);

            campBrandBuss = new CampaignBrandBusiness();
            campBrandBuss.setId(cb.getId());
            campBrandBuss.setIdDivision(cb.getDivisionCd());
            campBrandBuss.setDescDivision(division.get(0).getDesc());
            campBrandBuss.setIdBrand(cb.getBrandCd());
            campBrandBuss.setDesc(cb.getBrandCd());
            campBrandBuss.setIdUnit(hasValue(cb.getUnitId()) ? cb.getUnitId() : null);
            campBrandBuss.setDescUnit(hasValue(cb.getUnitId()) ? cb.getUnitId() : getMessage(CBO_UNIT_ALL));
            campBrandBuss.setDiscount(cb.getBrandDiscountPct());
            list.add(campBrandBuss);
        }

        return list;
    }

    /**
     * Method that converts a list to CampaignDivisionUnit a list CampaignDivisionUnitBusiness
     *
     * @return list of CampaignDivisionUnitBusiness
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<CampaignDivisionUnitBusiness> convertToCampaignDivisionUnitBusiness() {

        List<CampaignDivisionUnitBusiness> list = new ArrayList<CampaignDivisionUnitBusiness>();
        CampaignDivisionUnitBusiness campDivUnitBuss = null;

        for (CampaignDivisionUnit cdu : this.campaign.getCampaignDivisionUnits()) {
            campDivUnitBuss = new CampaignDivisionUnitBusiness();
            campDivUnitBuss.setId(cdu.getId());
            campDivUnitBuss.setDivisionId(cdu.getDivision().getId().getDivisionCd());
            campDivUnitBuss.setDescDivision(cdu.getDivision().getDesc());
            campDivUnitBuss.setUnitId(hasValue(cdu.getUnitId()) ? cdu.getUnitId(): null);
            campDivUnitBuss.setDescUnit(hasValue(cdu.getUnitId()) ? cdu.getUnitId() : getMessage(CBO_UNIT_ALL));
            campDivUnitBuss.setVolume(cdu.getVolumeAmt());
            campDivUnitBuss.setVolumeAvail(cdu.getVolumeAvail());
            list.add(campDivUnitBuss);
        }

        return list;
    }

    /**
     * Method that converts a list to CampaignDivisionUnitBusiness a list CampaignDivisionUnit
     *
     * @return list of CampaignDivisionUnit
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<CampaignDivisionUnit> convertToCampaignDivisionUnit() {

        List<CampaignDivisionUnit> list = new ArrayList<CampaignDivisionUnit>();
        CampaignDivisionUnit campDivUnit = null;

        for (CampaignDivisionUnitBusiness cdub : this.divisionUnitsCampaignList) {
            campDivUnit = new CampaignDivisionUnit();
            campDivUnit.setCampaign(new Campaign());
            campDivUnit.setDivision(new Division(new DivisionId()));

            campDivUnit.setId(hasValue(cdub.getId()) ? cdub.getId() : null);

            if (hasValue(cdub.getUnitId())) {
                campDivUnit.setUnitId( cdub.getUnitId());
            }

            campDivUnit.getDivision().getId().setDivisionCd(cdub.getDivisionId());
            campDivUnit.getDivision().getId().setLanguageCd(getLanguage());
            campDivUnit.getDivision().setDesc(cdub.getDescDivision());
            campDivUnit.setCampaign(this.campaign);
            campDivUnit.setVolumeAmt(cdub.getVolume());
            campDivUnit.setVolumeAvail(cdub.getVolumeAvail());

            list.add(campDivUnit);
        }

        return list;
    }

    /**
     * Change event of the combo of country.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     *//*
    public void cboCountryChanged() {

        String countryId = this.campaign.getCountry().getId().getCountryCd();
        this.clearFields();

        if (super.hasValue(countryId)) {
            loadTradings(countryId);
            loadCommodities(countryId);
            loadBarterTypes(countryId);
        } else {
            this.tradingsCampaign.clear();
            this.commoditiesCampaign.clear();
            this.barterTypeCampaign.clear();
            this.barterTypeId = null;
            this.tradingId = null;
            this.commodityId = null;
        }
    }*/

    /**
     * Change event of the combo of division.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void cboDivisionChanged() {

        String idDivision = this.divisionBrandId;
        this.brandsCampaign.clear();
        String[] codDesc = null;

        if (super.hasValue(idDivision)) {
            codDesc = getCodigoDescricao(idDivision);
            loadBrands(codDesc[0]);
        } else {
            this.divisionBrandId = null;
            this.brandId = null;
        }
    }

    /**
     * Method responsible for clear list of tradings and commodities
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void clearFields() {

        this.campaign.getTradings().clear();
        this.campaign.getCommodities().clear();
        this.campaign.getBarterTypes().clear();
    }

    /**
     * Method responsible for displaying the Trading tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showTradingTab() {

        this.tab = "tabTrading";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the Commodities tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showCommoditiesTab() {

        this.tab = "tabCommodities";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the Commodities tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showBrandTab() {

        this.tab = "tabBrands";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the BarterType tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showBarterTypeTab() {

        this.tab = "tabBarterTypes";

        return NOT_NAVIGATE;
    }


    /**
     * Method responsible for fetching the Status that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadStatus() {

        this.statusCampaign.add(new SelectItem(null, getMessage(ALL)));
        final List<SelectItem> statusList = new ArrayList<SelectItem>();

        for (final CampaignStatusList status : CampaignStatusList.values()) {
            statusList.add(new SelectItem(status.getCodStatus(), super.getMessage(status.getName())));
        }

        sortSelectItem(statusList);
        this.statusCampaign.addAll(statusList);
    }

    /**
     * Method responsible for adding Trading
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void addTrading() {

        ICampaignService campaignService = getService(ICampaignService.class);
        Trading tradingToAdd = new Trading(new TradingId());
        String[] codDesc = null;

        if (hasValue(this.tradingId)) {
            codDesc = getCodigoDescricao(this.tradingId);

            tradingToAdd.getId().setTradingCd(codDesc[0]);
            tradingToAdd.getId().setCountryCd(this.getCampaign().getCountry().getId().getCountryCd());
            tradingToAdd.setDescTrading(codDesc[1]);

            if (campaignService.canAdd(this.campaign.getTradings(), tradingToAdd)) {
                this.campaign.getTradings().add(tradingToAdd);

                this.tradingId = null;
            }
        }

        this.setMessages(campaignService.getMessages());

        showTradingTab();
    }

    /**
     * Method responsible for delete Trading
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String deleteTrading() {

        if (hasValue(trading)) {
            this.campaign.getTradings().remove(trading);
        }

        return showTradingTab();
    }

    /**
     * Method responsible for adding a Barter Type
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void addBarterType() {

        ICampaignService campaignService = getService(ICampaignService.class);
        BarterType barterTypeToAdd = new BarterType(new BarterTypeId());
        String[] codDesc = null;

        if (hasValue(this.barterTypeId)) {
            codDesc = getCodigoDescricao(this.barterTypeId);

            barterTypeToAdd.getId().setBarterTypeId(codDesc[0]);
            barterTypeToAdd.getId().setCountryCd(this.getCampaign().getCountry().getId().getCountryCd());
            barterTypeToAdd.setDescBarterType(codDesc[1]);

            if (campaignService.canAdd(this.campaign.getBarterTypes(), barterTypeToAdd)) {
                this.campaign.getBarterTypes().add(barterTypeToAdd);

                this.barterTypeId = null;
            }
        }

        this.setMessages(campaignService.getMessages());
        showBarterTypeTab();
    }

    /**
     * Method responsible for delete Trading
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String deleteBarterType() {

        if (hasValue(barterType)) {
            this.campaign.getBarterTypes().remove(barterType);
        }

        return showBarterTypeTab();
    }


    /**
     * Method responsible for adding Commodity
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String deleteCommodity() {

        if (hasValue(commodity)) {
            this.campaign.getCommodities().remove(commodity);
        }

        return showCommoditiesTab();
    }

    /**
     * Method responsible for delete Commodity
     *
     * @return event of page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String deleteBrand() {

        if (hasValue(brand)) {
            if (hasValue(brand.getId())) {
                this.brandsCampaignDelete.add(new CampaignBrand(brand.getId()));
            }

            this.brandsCampaignList.remove(brand);
        }

        return showBrandTab();
    }

    /**
     * Method responsible for delete Unit
     *
     * @return event of page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String deleteUnit() {

        if (hasValue(divisionUnit)) {
            if (hasValue(divisionUnit.getId())) {
                this.divisionUnitsCampaignDelete.add(new CampaignDivisionUnit(divisionUnit.getId()));
            }

            this.divisionUnitsCampaignList.remove(divisionUnit);
        }

        return showUnitTab();
    }


    public String editUnit() {

        unitEdit=true;

        unitId=divisionUnit.getUnitId();
        divisionId=divisionUnit.getDivisionId().concat(HIFEN).concat(divisionUnit.getDescDivision());
        volumeUnit=divisionUnit.getVolume();

        return showUnitTab();

    }

    public void clear(ActionEvent ae) {

        unitId=null;
        divisionId=null;
        volumeUnit=null;

        unitEdit=false;

    }

    public void updateUnit(ActionEvent ae){

        unitEdit=false;

        ICampaignService campaignService = getService(ICampaignService.class);
        CampaignDivisionUnitBusiness cdub = divisionUnit;
        //((HtmlAjaxCommandButton) ae.getComponent()).setFocus(CBO_DIVISIONS);
        String[] codDesc = null;


        String divisionIdOld = cdub.getDivisionId();
        String descriptionOld = cdub.getDescDivision();
        String unitIdOld = cdub.getUnitId();
        String descUnitOld = cdub.getDescUnit();
        BigDecimal volumeOld = cdub.getVolume();
        BigDecimal volumeAvailableOld = cdub.getVolumeAvail();


        if (hasValue(this.divisionId)) {
            codDesc = getCodigoDescricao(this.divisionId);
            cdub.setDivisionId(codDesc[0]);
            cdub.setDescDivision(codDesc[1]);
        }

        if (hasValue(this.unitId)) {
            cdub.setUnitId(this.unitId);
            cdub.setDescUnit(this.unitId);
        } else {
            cdub.setDescUnit(getMessage(CBO_UNIT_ALL));
        }

        if (hasValue(this.volumeUnit)) {
            cdub.setVolume(this.volumeUnit);
        }

        if ( campaignService.validatesDivisionAndUnitToUnit(cdub, this.divisionUnitsCampaignList)
                && campaignService.canUpdateUnit(this.valueMaxBarter, this.divisionUnitsCampaignList)) {

            if ( campaign.getId() == null ){
                cdub.setVolumeAvail(cdub.getVolume());
            } else {
                cdub.setVolumeAvail(campaignService.getUnitVolumeAvail( campaign, cdub.getUnitId(),cdub.getVolume()));
            }

            if ( cdub.getVolumeAvail().compareTo( BigDecimal.ZERO) > 0  ){
                //this.divisionUnitsCampaignList.add(cdub);
            } else {
                campaignService.getMessages().add(new MessageVO("disapproval.reason.campaign.limit.for.unit.has.already.consumed", MessageTypeList.ERROR));
            }

        } else {
            if (!campaignService.getMessages().isEmpty()) {
                String idMessage = campaignService.getMessages().get(0).getId();
                if (CampaignService.CAMPAIGN_INVALID_ADD.equalsIgnoreCase(idMessage)) {
                    //((HtmlAjaxCommandButton) ae.getComponent()).setFocus(CBO_UNITS);
                } else if (CampaignService.CAMPAIGN_INVALID_VALUE_BARTER.equalsIgnoreCase(idMessage)) {
                    //((HtmlAjaxCommandButton) ae.getComponent()).setFocus(TXT_VOLUME_UNIT);
                }
            }
        }


        this.setMessages(campaignService.getMessages());

        if ( campaignService.getMessages() != null && !campaignService.getMessages().isEmpty() ) {

            unitEdit=true;

            cdub.setDivisionId(divisionIdOld);
            cdub.setDescDivision(descriptionOld);
            cdub.setUnitId(unitIdOld);
            cdub.setDescUnit(descUnitOld);
            cdub.setVolume(volumeOld);
            cdub.setVolumeAvail(volumeAvailableOld);

        } else {

            unitEdit=false;

            this.divisionId = null;
            this.unitId = null;
            this.volumeUnit = null;

        }

        showUnitTab();

    }

    /**
     * Method responsible for breaking down the code and description of a string
     *
     * @param id string to be broken
     * @return code of description
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private String[] getCodigoDescricao(String id) {

        String[] codDesc = null;

        if (hasValue(id)) {
            codDesc = id.trim().split(HIFEN);
        }

        return codDesc;
    }

    /**
     * Method responsible for adding Commodity
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void addCommodity() {

        ICampaignService campaignService = getService(ICampaignService.class);
        Commodity commodityToAdd = new Commodity(new CommodityId());
        String[] codDesc = null;

        if (hasValue(this.commodityId)) {
            codDesc = getCodigoDescricao(this.commodityId);

            commodityToAdd.getId().setCommodityId(codDesc[0]);
            commodityToAdd.getId().setCountryCd(this.getCampaign().getCountry().getId().getCountryCd());
            commodityToAdd.setDescCommodity(codDesc[1]);

            if (campaignService.canAdd(this.campaign.getCommodities(), commodityToAdd)) {
                this.campaign.getCommodities().add(commodityToAdd);

                this.commodityId = null;
            }
        }

        this.setMessages(campaignService.getMessages());

        showCommoditiesTab();
    }

    /**
     * Method responsible for adding Unit
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void addUnit() {

        ICampaignService campaignService = getService(ICampaignService.class);
        CampaignDivisionUnitBusiness cdub = new CampaignDivisionUnitBusiness();

        String[] codDesc = null;

        if (hasValue(this.divisionId)) {
            codDesc = getCodigoDescricao(this.divisionId);
            cdub.setDivisionId(codDesc[0]);
            cdub.setDescDivision(codDesc[1]);
        }

        if (hasValue(this.unitId)) {
            cdub.setUnitId(this.unitId);
            cdub.setDescUnit(this.unitId);
        } else {
            cdub.setDescUnit(getMessage(CBO_UNIT_ALL));
        }

        if (hasValue(this.volumeUnit)) {
            cdub.setVolume(this.volumeUnit);
        }

        if (campaignService.canAdd(this.divisionUnitsCampaignList, cdub)
                && campaignService.validatesDivisionAndUnitToUnit(cdub, this.divisionUnitsCampaignList)
                && campaignService.canAddUnit(this.valueMaxBarter, cdub.getVolume(), this.divisionUnitsCampaignList)) {
            cdub.setVolumeAvail(cdub.getVolume());
            this.divisionUnitsCampaignList.add(cdub);

            this.divisionId = null;
            this.unitId = null;
            this.volumeUnit = null;
        } else {
            if (!campaignService.getMessages().isEmpty()) {
                String idMessage = campaignService.getMessages().get(0).getId();
            }
        }

        this.setMessages(campaignService.getMessages());

        showUnitTab();
    }

    /**
     * Method responsible for adding Brand
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void addBrand() {

        ICampaignService campaignService = getService(ICampaignService.class);
        CampaignBrandBusiness cbb = new CampaignBrandBusiness();

        String[] codDesc = null;

        if (hasValue(this.brandId)) {
            cbb.setIdBrand(this.brandId);
            cbb.setDesc(this.brandId);
            cbb.setDiscount(discountBrand);
        }

        if (hasValue(this.divisionBrandId)) {
            codDesc = getCodigoDescricao(this.divisionBrandId);
            cbb.setIdDivision(codDesc[0]);
            cbb.setDescDivision(codDesc[1]);
        }

        if (hasValue(this.unitBrandId)) {
            cbb.setIdUnit(unitBrandId);
            cbb.setDescUnit(unitBrandId);
        } else {
            cbb.setDescUnit(getMessage(CBO_UNIT_ALL));
        }

        if (campaignService.canAdd(this.brandsCampaignList, cbb)
                && campaignService.validatesDivisionAndUnitToBrand(cbb, this.brandsCampaignList)
                && campaignService.isValidDiscountBrand(cbb,campaign)) {
            this.brandsCampaignList.add(cbb);

            this.brandId = null;
            this.discountBrand = null;
            this.divisionBrandId = null;
            this.unitBrandId = null;
        } else {
            if (!campaignService.getMessages().isEmpty()) {
                String idMessage = campaignService.getMessages().get(0).getId();
            }
        }

        this.setMessages(campaignService.getMessages());

        showBrandTab();

    }

    /**
     * Method responsible for fetching the Country that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadCountries() {

        ICountryService countryService = getService(ICountryService.class);
        final List<SelectItem> countryList = new ArrayList<SelectItem>();

        CountryFilter countryFilter = new CountryFilter();

        countryFilter.getCountry().setId(new CountryId());
        countryFilter.getCountry().getId().setLanguageCd(getLanguage());

        List<Country> countries = countryService.search(countryFilter);

        for (final Country country : countries) {
            countryList.add(new SelectItem(country.getId().getCountryCd(), country.getShortDesc()));
        }

        sortSelectItem(countryList);
        this.countryCampaign.addAll(countryList);
    }

    /**
     * Method responsible for fetching the Currency that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadCurrencies() {

        ICurrencyService currencyService = getService(ICurrencyService.class);
        final List<SelectItem> currencyList = new ArrayList<SelectItem>();

        CurrencyFilter currencyFilter = new CurrencyFilter();

        currencyFilter.getCurrency().setId(new CurrencyId());
        currencyFilter.getCurrency().getId().setLanguageCd(getLanguage());

        List<Currency> currencies = currencyService.search(currencyFilter);

        for (final Currency currency : currencies) {
            currencyList.add(new SelectItem(currency.getId().getCurrencyCd(), currency.getDescCurrencyLong()));
        }

        sortSelectItem(currencyList);
        this.currencyCampaign.addAll(currencyList);
    }

    /**
     * Method responsible for fetching the Division that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadDivisions() {

        IDivisionService divisionService = getService(IDivisionService.class);
        final List<SelectItem> divisionList = new ArrayList<SelectItem>();

        DivisionFilter divisionFilter = new DivisionFilter();

        divisionFilter.getDivision().setId(new DivisionId());
        divisionFilter.getDivision().getId().setLanguageCd(getLanguage());

        List<Division> divisions = divisionService.search(divisionFilter);

        for (final Division division : divisions) {
            divisionList.add(new SelectItem(division.getId().getDivisionCd().concat(HIFEN).concat(division.getDesc()),
                    division.getDesc()));
        }

        sortSelectItem(divisionList);
        this.divisionsCampaign.addAll(divisionList);
    }

    /**
     * Method responsible for fetching the Trading that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadTradings(String countryCd) {

        ITradingService tradingService = getService(ITradingService.class);

        this.tradingsCampaign = new ArrayList<SelectItem>();

        TradingFilter tradingFilter = new TradingFilter();
        tradingFilter.setTrading(new Trading(new TradingId()));
        tradingFilter.getTrading().getId().setCountryCd(countryCd);

        List<Trading> tradings = tradingService.search(tradingFilter);

        for (final Trading loadedTrading : tradings) {
            this.tradingsCampaign.add(new SelectItem(loadedTrading.getId().getTradingCd().trim().concat(HIFEN)
                    .concat(loadedTrading.getDescTrading()), loadedTrading.getDescTrading()));
        }

        sortSelectItem(this.tradingsCampaign);
    }

    /**
     * Method responsible for fetching the Commodity that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadCommodities(String countryCd) {

        ICommodityService commodityService = getService(ICommodityService.class);
        this.commoditiesCampaign = new ArrayList<SelectItem>();

        CommodityFilter commodityFilter = new CommodityFilter();
        commodityFilter.setCommodity(new Commodity(new CommodityId()));
        commodityFilter.getCommodity().getId().setCountryCd(countryCd);

        List<Commodity> commodities = commodityService.search(commodityFilter);


        for (final Commodity loadedCommodity : commodities) {
            this.commoditiesCampaign.add(new SelectItem(loadedCommodity.getId().getCommodityId().trim().concat(HIFEN)
                    .concat(loadedCommodity.getDescCommodity()), loadedCommodity.getDescCommodity()));
        }

        sortSelectItem(this.commoditiesCampaign);
    }

    /**
     * Method responsible for fetching the Unit that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadUnits() {

        ISalesOrgCustomerService salesOrgCustomerService = getService(ISalesOrgCustomerService.class);

        final List<SelectItem> unitsList = new ArrayList<SelectItem>();

        List<String> unitsIdList = salesOrgCustomerService.getAllUnitId();


        for (final String loadedUnitId : unitsIdList ) {
            unitsList.add(new SelectItem(loadedUnitId,loadedUnitId));
        }

        sortSelectItem(unitsList);
        this.unitsCampaign.clear();
        this.unitsCampaign.addAll(unitsList);

    }

    /**
     * Method responsible for fetching the Brand that will populate the interface component
     *
     * @param idDivision id of division
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadBrands(String idDivision) {

        IProductService productService = getService(IProductService.class);
        this.brandsCampaign = new ArrayList<SelectItem>();

        ProductFilter productFilter = new ProductFilter();
        productFilter.getProduct().setDivisionCd(idDivision);

        List<String> products = productService.searchDistinct(productFilter);

        for (final String product : products) {
            this.brandsCampaign.add(new SelectItem(product));
        }

        sortSelectItem(this.brandsCampaign);
    }


    /**
     * Method responsible for fetching the Barter Types that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadBarterTypes(String countryCd) {

        IBarterTypeService barterTypeService = getService(IBarterTypeService.class);
        this.barterTypeCampaign = new ArrayList<SelectItem>();

        BarterTypeFilter barterTypeFilter = new BarterTypeFilter();
        barterTypeFilter.setBarterType(new BarterType(new BarterTypeId()));
        barterTypeFilter.getBarterType().getId().setCountryCd(countryCd);
        List<BarterType> barterTypes = barterTypeService.search(barterTypeFilter);


        for (final BarterType loadedBarterType : barterTypes) {
            this.barterTypeCampaign.add(new SelectItem(loadedBarterType.getId().getBarterTypeId().trim().concat(HIFEN)
                    .concat(loadedBarterType.getDescBarterType()), loadedBarterType.getDescBarterType()));
        }

        sortSelectItem(this.barterTypeCampaign);
    }


    public void loadWhitepapers() {

        whitepapers.clear();

        IWhitePaperService whitePaperService = getService(IWhitePaperService.class);
        List<WhitePaper> whitePapersList = whitePaperService.findAll();

        for (final WhitePaper whitePaper: whitePapersList) {
            whitepapers.add(new SelectItem(whitePaper.getId(), whitePaper.getName()));
        }

        sortSelectItem(whitepapers);

    }


    /**
     * Method responsible for loading screen new campaign
     *
     * @return string definig the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String newCampaign() {

        init();
        //this.campaign = new Campaign();
        setNewer(true);
        return NEW;
    }

    /**
     * Method responsible for loading the edit screen campaign
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String
    editCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);
        this.noEditable = Boolean.TRUE;

        try {
            setNewer(false);
            loadCampaignEditScreen(campaignService);

            if (campaign.getAuthor().getId().equalsIgnoreCase(getUserLoggedId())
                    && (campaign.getStatusCd().equals(CampaignStatusList.DRAFT_CD.getCodStatus()) || campaign.getStatusCd()
                    .equals(CampaignStatusList.RETURNED_CD.getCodStatus()))) {
                this.noEditable = Boolean.FALSE;
            }

            editValidated = campaign.getStatusCd().equals(CampaignStatusList.VALIDATED_CD.getCodStatus() ) && access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());

            this.setMessages(campaignService.getMessages());
            this.tab = "tabTrading";
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }

        return CHANGE;
    }

    private void loadCampaignEditScreen(final ICampaignService campaignService) {

        campaignService.getMessages().clear();
        this.campaign = campaignService.findByIdComplete(this.campaign);
        populateCampaign();
        enabledDisabledButtons();

        loadTradings(this.campaign.getCountry().getId().getCountryCd());
        loadCommodities(this.campaign.getCountry().getId().getCountryCd());
        loadBarterTypes(this.campaign.getCountry().getId().getCountryCd());
    }

    /**
     * Method responsible for enabling and disabling buttons Sent to validation, validate and Return
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void enabledDisabledButtons() {

        ICampaignService campaignService = getService(ICampaignService.class);

        this.buttonSendValidate = campaignService.canSendValidation(this.campaign) && access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());

        this.buttonReturn = campaignService.canReturn(this.campaign)
                && access(PermissionList.RETURN_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());

        this.buttonValidate = campaignService.canValidate(this.campaign)
                && access(PermissionList.VALIDATE_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());

        this.buttonInactivate = campaignService.canInactivate(this.campaign)
                && access(PermissionList.INACTIVATE_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Method responsible for loading the remaining data to fill the campaign
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void populateCampaign() {

        this.setBrandsCampaignList(convertToCampaignBrandBusiness());
        this.setDivisionUnitsCampaignList(convertToCampaignDivisionUnitBusiness());
        this.valueMaxBarter = this.campaign.getMaxBilledAmt();
        this.valueBarterAvaliable = this.campaign.getBarterAvailBal();
        this.valueBarterConsumed = this.campaign.getMaxBilledAmt().subtract(this.campaign.getBarterAvailBal());
        this.valueMaxDiscount = this.campaign.getMaxDiscount();
        this.valueDiscountAvaliable = this.campaign.getDiscountAvailBal();
        this.valueDiscountConsumed = this.campaign.getMaxDiscount().subtract(this.campaign.getDiscountAvailBal());
    }

    /**
     * Method responsible for canceling the registration of a campaign
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String cancelCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);

        try {
            this.divisionBrandId = null;
            this.brandsCampaignDelete = new ArrayList<CampaignBrand>();
            this.divisionUnitsCampaignDelete = new ArrayList<CampaignDivisionUnit>();
            if (isNewer()) {
                return SHOW_RESULT;
            } else {
                campaignList = campaignService.searchByDivision(campaignFilter);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SHOW_RESULT;
    }


    /**
     * Method responsible for generating file upload lines
     *
     * @author Sanjeev Kumar
     */

    public String prepareFileUploadForm() {
        LOG.debug("In CampaignFileUploadForm");
        renderAttachmentPopup = false;
        filesAttachedSuccessfully = false;

        try {
            campaignFileUploadHandlers.clear();
            attachments.clear();
            final Campaign campaignFilter = new Campaign();
            campaignFilter.setId(campaignSelected.getId());
            final ICampaignService campaignService = getService(ICampaignService.class);
            campaign = campaignService.findByIdComplete(campaignFilter);
            attachments.addAll(campaign.getAttachments());
            //By default 5 files to upload
            for (int i = 0; i < 5; i++) {
                addCampaignFileUploadHandler();
            }

            renderAttachmentPopup = true;
            return SUCCESS;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }
    }

    /**
     * Method responsible for attaching files to campaign
     *
     * @author Sanjeev Kumar
     */
    public void attachFiles() {
        LOG.debug("In attachFiles ");
        try {
            final ICampaignService campaignService = getService(ICampaignService.class);
            if (isValidAttachments()) {
                for (FileUpload fileUploadHandler : campaignFileUploadHandlers) {
                    if (fileUploadHandler.getFile() != null) {
                        BarAttachment attachment = new BarAttachment(fileUploadHandler.getFile(), fileUploadHandler.getUploadDocumentNumber(), fileUploadHandler.getUploadDocumentType());
                        attachments.add(attachment);
                    }
                }
                campaign.setAttachments(attachments);
                campaignService.saveAttachments(campaign);
                if (campaignService.isOk()) {
                    filesAttachedSuccessfully = true;
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for deleting the attachment
     *
     * @author Pragathi
     */
    public void deleteAttachment() {
        try {
            final ICampaignService campaignService = getService(ICampaignService.class);
            AttachmentService attachmentService = getService(AttachmentService.class);
            campaign.getAttachments().remove(attachmentSelected);
            campaignService.saveAttachments(campaign);
            attachmentService.delete(attachmentSelected.getId());

            setMessages(campaignService);

            if (campaignService.isOk()) {
                attachments.remove(attachmentSelected);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    public StreamedContent getFile() {
        return new DefaultStreamedContent(new ByteArrayInputStream(attachmentSelected.getFile().getFileContent()),
                attachmentSelected.getFile().getMimeType(), attachmentSelected.getFile().getFileName());
    }

    /**
     * Check the validity of the file uploaded
     *
     * @author Pragathi
     */
    private boolean isValidAttachments() {
        boolean valid = true;
        boolean validDocument = true;

        for (FileUpload fileUploadHandler : campaignFileUploadHandlers) {
            fileUploadHandler.getUploadErrorMessages().clear();

            validDocument = true;
            if (fileUploadHandler.getFile() != null || fileUploadHandler.getUploadDocumentType() != null || StringUtils.isNotEmpty(fileUploadHandler.getUploadDocumentNumber())) {

                validDocument = isDocumentValid(fileUploadHandler) && !checkDocumentExistence(fileUploadHandler);

                validDocument = isFileUploaded(fileUploadHandler) && fileSizeIsValid(fileUploadHandler) && validDocument;

                valid = validDocument ? valid : validDocument;
            }
        }

        return valid;
    }

    /**
     * Method responsible for checking the validity of the document
     *
     * @author Sanjeev Kumar
     */

    private boolean isDocumentValid(FileUpload fileUploadHandler) {
        boolean valid = true;
        List uploadErrorMessages = fileUploadHandler.getUploadErrorMessages();

        String documentNumber = trim(fileUploadHandler.getUploadDocumentNumber());
        if (org.apache.commons.lang3.StringUtils.isBlank(documentNumber)) {
            uploadErrorMessages.add(getMessage("attachfiledialog.error.uploadDocumentNumber.required"));
            valid = false;
        }

        if (fileUploadHandler.getUploadDocumentType() == null) {
            uploadErrorMessages.add(getMessage("attachfiledialog.error.uploadDocumentType.required"));
            valid = false;
        }
        return valid;
    }

    /**
     * Method responsible for checking the document existence
     *
     * @author Sanjeev Kumar
     */

    private boolean checkDocumentExistence(FileUpload fileUploadHandler) {
        boolean exists = false;
        for (BarAttachment attachment : campaign.getAttachments()) {
            if (attachment.getDocumentNumber().equals(fileUploadHandler.getUploadDocumentNumber().trim()) && attachment.getDocumentType() == fileUploadHandler.getUploadDocumentType()) {
                fileUploadHandler.getUploadErrorMessages().add(getMessage("attachfiledialog.error.uploadDocumentType.exist"));
                exists = true;
            }
        }
        return exists;
    }

    /**
     * checks if the file has been uploaded
     *
     * @author Sanjeev Kumar
     */

    private boolean isFileUploaded(FileUpload fileUploadHandler) {
        boolean valid = true;
        if (fileUploadHandler.getFile() == null) {
            fileUploadHandler.getUploadErrorMessages().add(getMessage("attachfiledialog.error.file.required"));
            valid = false;
        }
        return valid;
    }

    /**
     * checks the file size
     *
     * @author Sanjeev Kumar
     */

    private boolean fileSizeIsValid(FileUpload fileUploadHandler) {
        File file = fileUploadHandler.getFile();
        long length = file.getFileSize();
        boolean valid = true;

        if (length > 5242880) {
            valid = false;
            fileUploadHandler.getUploadErrorMessages().add(getMessage("fileUpload.invalidSize.error"));
        }
        return valid;
    }

    /**
     * Method responsible for reporting the amount of campaigns returned from the query
     *
     * @return amount of campaigns
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public int getQtd() {

        int count = 0;
        if (this.campaignList != null) {
            count = this.campaignList.size();
        }
        return count;
    }

    /**
     * Method responsible for reporting the amount of campaigns history returned from the query
     *
     * @return amount of campaigns history
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public int getQtCampaignHistory() {

        int count = 0;
        if (this.campaign != null && this.campaign.getHistories() != null) {
            count = this.campaign.getHistories().size();
        }
        return count;
    }

    /**
     * Method responsible for displaying the units tab
     *
     * @return string definig the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showUnitTab() {

        this.tab = "tabUnit";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the history tab
     *
     * @return string definig the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showHistoryTab() {

        this.tab = "tabHistory";

        return NOT_NAVIGATE;
    }

    /**
     * @return the statusCampaign
     */
    public List<SelectItem> getStatusCampaign() {

        return statusCampaign;
    }

    /**
     * @param statusCampaign - the statusCampaign to set
     */
    public void setStatusCampaign(List<SelectItem> statusCampaign) {

        this.statusCampaign = statusCampaign;
    }

    /**
     * @return the campaignFilter
     */
    public CampaignFilter getCampaignFilter() {

        return campaignFilter;
    }

    /**
     * @param campaignFilter - the campaignFilter to set
     */
    public void setCampaignFilter(CampaignFilter campaignFilter) {

        this.campaignFilter = campaignFilter;
    }

    /**
     * @return the campaignList
     */
    public List<Campaign> getCampaignList() {

        return campaignList;
    }

    /**
     * @param campaignList - the campaignList to set
     */
    public void setCampaignList(List<Campaign> campaignList) {

        this.campaignList = campaignList;
    }

    /**
     * @return the campaign
     */
    public Campaign getCampaign() {

        return campaign;
    }

    /**
     * @param campaign - the campaign to set
     */
    public void setCampaign(Campaign campaign) {

        this.campaign = campaign;
    }

    /**
     * @return the divisionsCampaign
     */
    public List<SelectItem> getDivisionsCampaign() {

        return divisionsCampaign;
    }

    /**
     * @param divisionsCampaign - the divisionsCampaign to set
     */
    public void setDivisionsCampaign(List<SelectItem> divisionsCampaign) {

        this.divisionsCampaign = divisionsCampaign;
    }

    /**
     * @return the divisionId
     */
    public String getDivisionId() {

        return divisionId;
    }

    /**
     * @param divisionId - the divisionId to set
     */
    public void setDivisionId(String divisionId) {

        this.divisionId = divisionId;
    }

    /**
     * @return the countryCampaign
     */
    public List<SelectItem> getCountryCampaign() {

        return countryCampaign;
    }

    /**
     * @param countryCampaign - the countryCampaign to set
     */
    public void setCountryCampaign(List<SelectItem> countryCampaign) {

        this.countryCampaign = countryCampaign;
    }

    /**
     * @return the currencyCampaign
     */
    public List<SelectItem> getCurrencyCampaign() {

        return currencyCampaign;
    }

    /**
     * @param currencyCampaign - the currencyCampaign to set
     */
    public void setCurrencyCampaign(List<SelectItem> currencyCampaign) {

        this.currencyCampaign = currencyCampaign;
    }

    /**
     * @return the tradingId
     */
    public String getTradingId() {

        return tradingId;
    }

    /**
     * @param tradingId - the tradingId to set
     */
    public void setTradingId(String tradingId) {

        this.tradingId = tradingId;
    }

    /**
     * @return the tradingCampaign
     */
    public List<SelectItem> getTradingsCampaign() {

        return tradingsCampaign;
    }

    /**
     * @param tradingsCampaign - the tradingCampaign to set
     */
    public void setTradingsCampaign(List<SelectItem> tradingsCampaign) {

        this.tradingsCampaign = tradingsCampaign;
    }

    /**
     * @return the commoditiesCampaign
     */
    public List<SelectItem> getCommoditiesCampaign() {

        return commoditiesCampaign;
    }

    /**
     * @param commoditiesCampaign - the commoditiesCampaign to set
     */
    public void setCommoditiesCampaign(List<SelectItem> commoditiesCampaign) {

        this.commoditiesCampaign = commoditiesCampaign;
    }

    /**
     * @return the trading
     */
    public Trading getTrading() {

        return trading;
    }

    /**
     * @param trading - the trading to set
     */
    public void setTrading(Trading trading) {

        this.trading = trading;
    }

    /**
     * @return the commodity
     */
    public Commodity getCommodity() {

        return commodity;
    }

    /**
     * @param commodity - the commodity to set
     */
    public void setCommodity(Commodity commodity) {

        this.commodity = commodity;
    }

    /**
     * @return the brandsCampaign
     */
    public List<SelectItem> getBrandsCampaign() {

        return brandsCampaign;
    }

    /**
     * @param brandsCampaign - the brandsCampaign to set
     */
    public void setBrandsCampaign(List<SelectItem> brandsCampaign) {

        this.brandsCampaign = brandsCampaign;
    }

    /**
     * @return the commodityId
     */
    public String getCommodityId() {

        return commodityId;
    }

    /**
     * @param commodityId - the commodityId to set
     */
    public void setCommodityId(String commodityId) {

        this.commodityId = commodityId;
    }

    /**
     * @return the brandId
     */
    public String getBrandId() {

        return brandId;
    }

    /**
     * @param brandId - the brandId to set
     */
    public void setBrandId(String brandId) {

        this.brandId = brandId;
    }

    /**
     * @return the unitsCampaign
     */
    public List<SelectItem> getUnitsCampaign() {

        return unitsCampaign;
    }

    /**
     * @param unitsCampaign - the unitsCampaign to set
     */
    public void setUnitsCampaign(List<SelectItem> unitsCampaign) {

        this.unitsCampaign = unitsCampaign;
    }

    /**
     * @return the unitId
     */
    public String getUnitId() {

        return unitId;
    }

    /**
     * @param unitId - the unitId to set
     */
    public void setUnitId(String unitId) {

        this.unitId = unitId;
    }

    /**
     * @return the tab
     */
    public String getTab() {

        return tab;
    }

    /**
     * @param tab - the tab to set
     */
    public void setTab(String tab) {

        this.tab = tab;
    }

    /**
     * @return the brandsCampaignList
     */
    public List<CampaignBrandBusiness> getBrandsCampaignList() {

        return brandsCampaignList;
    }

    /**
     * @param brandsCampaignList - the brandsCampaignList to set
     */
    public void setBrandsCampaignList(List<CampaignBrandBusiness> brandsCampaignList) {

        this.brandsCampaignList = brandsCampaignList;
    }

    /**
     * @return the divisionUnitsCampaignList
     */
    public List<CampaignDivisionUnitBusiness> getDivisionUnitsCampaignList() {

        return divisionUnitsCampaignList;
    }

    /**
     * @param divisionUnitsCampaignList - the divisionUnitsCampaignList to set
     */
    public void setDivisionUnitsCampaignList(List<CampaignDivisionUnitBusiness> divisionUnitsCampaignList) {

        this.divisionUnitsCampaignList = divisionUnitsCampaignList;
    }

    /**
     * @return the brand
     */
    public CampaignBrandBusiness getBrand() {

        return brand;
    }

    /**
     * @param brand - the brand to set
     */
    public void setBrand(CampaignBrandBusiness brand) {

        this.brand = brand;
    }

    /**
     * @return the divisionUnit
     */
    public CampaignDivisionUnitBusiness getDivisionUnit() {

        return divisionUnit;
    }

    /**
     * @param divisionUnit - the divisionUnit to set
     */
    public void setDivisionUnit(CampaignDivisionUnitBusiness divisionUnit) {

        this.divisionUnit = divisionUnit;
    }

    /**
     * @return the tableShow
     */
    public boolean isTableShow() {

        return tableShow;
    }

    /**
     * @param tableShow - the tableShow to set
     */
    public void setTableShow(boolean tableShow) {

        this.tableShow = tableShow;
    }

    /**
     * @return the buttonValidate
     */
    public boolean isButtonValidate() {

        return buttonValidate;
    }

    /**
     * @param buttonValidate - the buttonValidate to set
     */
    public void setButtonValidate(boolean buttonValidate) {

        this.buttonValidate = buttonValidate;
    }

    /**
     * @return the buttonSendValidate
     */
    public boolean isButtonSendValidate() {

        return buttonSendValidate;
    }

    /**
     * @param buttonSendValidate - the buttonSendValidate to set
     */
    public void setButtonSendValidate(boolean buttonSendValidate) {

        this.buttonSendValidate = buttonSendValidate;
    }

    /**
     * @return the buttonReturn
     */
    public boolean isButtonReturn() {

        return buttonReturn;
    }

    /**
     * @param buttonReturn - the buttonReturn to set
     */
    public void setButtonReturn(boolean buttonReturn) {

        this.buttonReturn = buttonReturn;
    }

    /**
     * @return the noEditable
     */
    public boolean isNoEditable() {

        return noEditable;
    }

    /**
     * @param noEditable - the noEditable to set
     */
    public void setNoEditable(boolean noEditable) {

        this.noEditable = noEditable;
    }

    /**
     * @return the valueMaxBarter
     */
    public BigDecimal getValueMaxBarter() {

        return valueMaxBarter;
    }

    /**
     * @param valueMaxBarter - the valueMaxBarter to set
     */
    public void setValueMaxBarter(BigDecimal valueMaxBarter) {

        this.valueMaxBarter = valueMaxBarter;
    }

    /**
     * @return the valueBarterConsumed
     */
    public BigDecimal getValueBarterConsumed() {

        return valueBarterConsumed;
    }

    /**
     * @param valueBarterConsumed - the valueBarterConsumed to set
     */
    public void setValueBarterConsumed(BigDecimal valueBarterConsumed) {

        this.valueBarterConsumed = valueBarterConsumed;
    }

    /**
     * @return the valueBarterAvaliable
     */
    public BigDecimal getValueBarterAvaliable() {

        return valueBarterAvaliable;
    }

    /**
     * @param valueBarterAvaliable - the valueBarterAvaliable to set
     */
    public void setValueBarterAvaliable(BigDecimal valueBarterAvaliable) {

        this.valueBarterAvaliable = valueBarterAvaliable;
    }

    /**
     * @return the valueMaxDiscount
     */
    public BigDecimal getValueMaxDiscount() {

        return valueMaxDiscount;
    }

    /**
     * @param valueMaxDiscount - the valueMaxDiscount to set
     */
    public void setValueMaxDiscount(BigDecimal valueMaxDiscount) {

        this.valueMaxDiscount = valueMaxDiscount;
    }

    /**
     * @return the valueDiscountConsumed
     */
    public BigDecimal getValueDiscountConsumed() {

        return valueDiscountConsumed;
    }

    /**
     * @param valueDiscountConsumed - the valueDiscountConsumed to set
     */
    public void setValueDiscountConsumed(BigDecimal valueDiscountConsumed) {

        this.valueDiscountConsumed = valueDiscountConsumed;
    }

    /**
     * @return the valueDiscountAvaliable
     */
    public BigDecimal getValueDiscountAvaliable() {

        return valueDiscountAvaliable;
    }

    /**
     * @param valueDiscountAvaliable - the valueDiscountAvaliable to set
     */
    public void setValueDiscountAvaliable(BigDecimal valueDiscountAvaliable) {

        this.valueDiscountAvaliable = valueDiscountAvaliable;
    }

    /**
     * @return the discountBrand
     */
    public BigDecimal getDiscountBrand() {

        return discountBrand;
    }

    /**
     * @param discountBrand - the discountBrand to set
     */
    public void setDiscountBrand(BigDecimal discountBrand) {

        this.discountBrand = discountBrand;
    }

    /**
     * @return the volumeUnit
     */
    public BigDecimal getVolumeUnit() {

        return volumeUnit;
    }

    /**
     * @param volumeUnit - the volumeUnit to set
     */
    public void setVolumeUnit(BigDecimal volumeUnit) {

        this.volumeUnit = volumeUnit;
    }

    /**
     * @return the divisionBrandId
     */
    public String getDivisionBrandId() {

        return divisionBrandId;
    }

    /**
     * @param divisionBrandId - the divisionBrandId to set
     */
    public void setDivisionBrandId(String divisionBrandId) {

        this.divisionBrandId = divisionBrandId;
    }

    /**
     * @return the unitBrandId
     */
    public String getUnitBrandId() {

        return unitBrandId;
    }

    /**
     * @param unitBrandId - the unitBrandId to set
     */
    public void setUnitBrandId(String unitBrandId) {

        this.unitBrandId = unitBrandId;
    }

    /**
     * @return the volumeUnitAvaliable
     */
    public BigDecimal getVolumeUnitAvaliable() {

        return volumeUnitAvaliable;
    }

    /**
     * @param volumeUnitAvaliable - the volumeUnitAvaliable to set
     */
    public void setVolumeUnitAvaliable(BigDecimal volumeUnitAvaliable) {

        this.volumeUnitAvaliable = volumeUnitAvaliable;
    }

    /**
     * @return the brandsCampaignDelete
     */
    public List<CampaignBrand> getBrandsCampaignDelete() {

        return brandsCampaignDelete;
    }

    /**
     * @param brandsCampaignDelete - the brandsCampaignDelete to set
     */
    public void setBrandsCampaignDelete(List<CampaignBrand> brandsCampaignDelete) {

        this.brandsCampaignDelete = brandsCampaignDelete;
    }

    /**
     * @return the divisionUnitsCampaignDelete
     */
    public List<CampaignDivisionUnit> getDivisionUnitsCampaignDelete() {

        return divisionUnitsCampaignDelete;
    }

    /**
     * @param divisionUnitsCampaignDelete - the divisionUnitsCampaignDelete to set
     */
    public void setDivisionUnitsCampaignDelete(List<CampaignDivisionUnit> divisionUnitsCampaignDelete) {

        this.divisionUnitsCampaignDelete = divisionUnitsCampaignDelete;
    }

    /**
     * @return the buttonInactivate
     */
    public boolean isButtonInactivate() {

        return buttonInactivate;
    }

    /**
     * @param buttonInactivate - the buttonInactivate to set
     */
    public void setButtonInactivate(boolean buttonInactivate) {

        this.buttonInactivate = buttonInactivate;
    }

    /**
     * @return the executeSearch
     */
    public boolean isExecuteSearch() {

        return executeSearch;
    }

    /**
     * @param executeSearch - the executeSearch to set
     */
    public void setExecuteSearch(boolean executeSearch) {

        this.executeSearch = executeSearch;
    }

    /**
     * @return the enableSaveBtn
     */
    public boolean isEnableSaveBtn() {

        enableSaveBtn = access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());

        return enableSaveBtn && !this.isNoEditable();
    }

    /**
     * @param enableSaveBtn - the enableSaveBtn to set
     */
    public void setEnableSaveBtn(boolean enableSaveBtn) {

        this.enableSaveBtn = enableSaveBtn;
    }

    /**
     * Checks if the authenticated user has access permission for the function campaignNew
     *
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCampaignNew() {

        return access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    public BarterType getBarterType() {
        return barterType;
    }

    public void setBarterType(BarterType barterType) {
        this.barterType = barterType;
    }

    public String getBarterTypeId() {
        return barterTypeId;
    }

    public void setBarterTypeId(String barterTypeId) {
        this.barterTypeId = barterTypeId;
    }

    public List<SelectItem> getBarterTypeCampaign() {
        return barterTypeCampaign;
    }

    public void setBarterTypeCampaign(List<SelectItem> barterTypeCampaign) {
        this.barterTypeCampaign = barterTypeCampaign;
    }


    public boolean isEditValidated() {
        return editValidated;
    }

    public void setEditValidated(boolean editValidated) {
        this.editValidated = editValidated;
    }

    public boolean isUnitEdit() {
        return unitEdit;
    }

    public void setUnitEdit(boolean unitEdit) {
        this.unitEdit = unitEdit;
    }

    public List<SelectItem> getWhitepapers() {
        return whitepapers;
    }

    public void setWhitepapers(List<SelectItem> whitepapers) {
        this.whitepapers = whitepapers;
    }

    public BarAttachment getAttachmentSelected() {
        return attachmentSelected;
    }

    public void setAttachmentSelected(BarAttachment attachmentSelected) {
        this.attachmentSelected = attachmentSelected;
    }

    public boolean isFilesAttachedSuccessfully() {
        return filesAttachedSuccessfully;
    }

    public void setFilesAttachedSuccessfully(boolean filesAttachedSuccessfully) {
        this.filesAttachedSuccessfully = filesAttachedSuccessfully;
    }

    public List<FileUpload> getCampaignFileUploadHandlers() {
        return campaignFileUploadHandlers;
    }

    public void setCampaignFileUploadHandlers(List<FileUpload> campaignFileUploadHandlers) {
        this.campaignFileUploadHandlers = campaignFileUploadHandlers;
    }

    public void setRenderAttachmentPopup(boolean renderAttachmentPopup) {
        this.renderAttachmentPopup = renderAttachmentPopup;
    }

    public Campaign getCampaignSelected() {
        return campaignSelected;
    }

    public void setCampaignSelected(Campaign campaignSelected) {
        this.campaignSelected = campaignSelected;
    }

    public void addCampaignFileUploadHandler() {
        campaignFileUploadHandlers.add(new FileUpload());
    }

    public boolean isRenderAttachmentPopup() {
        return renderAttachmentPopup;
    }

    public DocumentTypeList[] getUploadDocumentTypes() {
        return DocumentTypeList.values();
    }

    public List<BarAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<BarAttachment> attachments) {
        this.attachments = attachments;
    }


    public void initView(){

        String campaignId = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("campaignId");
        String viewState = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("javax.faces.ViewState");

        if (campaignId != null && viewState == null ){
            init();
            ICampaignService campaignService = getService(ICampaignService.class);
            this.campaign=campaignService.findByIdComplete( new Campaign(Long.parseLong(campaignId)));
            editCampaign();
        }

    }

}