package com.monsanto.barter.web.faces.communication;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.filter.QuotationFilter;
import com.monsanto.barter.business.service.IQuotationService;
import org.apache.log4j.Logger;
import org.apache.myfaces.custom.fileupload.UploadedFile;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.filter.CommunicationFilter;
import com.monsanto.barter.business.entity.list.CommunicationTypeList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.table.Communication;
import com.monsanto.barter.business.service.ICommunicationService;
import com.monsanto.barter.business.util.FileNameDecorator;

/**
 * Class responsible for controlling the pages of Communication feature.
 * 
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * 
 */
@ManagedBean
@SessionScoped
public class CommunicationFaces extends BaseJSF {

    /**
     * Serial ID
     */

    protected static final Logger LOG = Logger.getLogger(CommunicationFaces.class);

    private static final long serialVersionUID = -7453024248250296294L;

    private List<Communication> communicationList;

    private List<QuotationBusiness> quotationList;

    private boolean flgRenderPeriodRegister;

    private boolean flgRenderPeriodSearch;

    private CommunicationFilter filter;

    private Communication communication;

    private int listSize;

    private int quotationListSize;

    private UploadedFile file;

    private boolean flgNew;

    private boolean enableSaveBtn;

    public String begin(){
        init();
        return SUCCESS;
    }

    private void init() {
        filter = new CommunicationFilter();

        flgNew = true;
        communication = new Communication();
        communicationList = null;
        quotationList = null;
    }

    public String newCommunication(){
        init();
        return SUCCESS;
    }

    /**
     * No-arg constructor.
     * 
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public CommunicationFaces() {

        super();

        filter = new CommunicationFilter();

        flgNew = true;
        communication = new Communication();
        communicationList = null;
        quotationList = null;
    }

    /**
     * Method responsible for refreshing the components that are dependent of the Type field in the Search page.
     * 
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void typeSearchValueChanged(final ValueChangeEvent event) {

        flgRenderPeriodSearch = false;

        listSize = 0;
        if (communicationList != null) {
            communicationList.clear();
        }

        if ( quotationList != null ){
            quotationList.clear();
        }

        filter.setPeriodBegin(null);
        filter.setPeriodEnd(null);

        if (event != null && Character.valueOf(CommunicationTypeList.CAMPAIGN.getCod()).equals(event.getNewValue())) {
            flgRenderPeriodSearch = true;
        }
    }

    /**
     * Method responsible for refreshing the components that are dependent of the Type field in the Register page.
     * 
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void typeRegisterValueChanged(final ValueChangeEvent event) {

        flgRenderPeriodRegister = false;

        if (event != null && Character.valueOf(CommunicationTypeList.CAMPAIGN.getCod()).equals(event.getNewValue())) {
            flgRenderPeriodRegister = true;
        }
    }

    /**
     * Method responsible for calling the Search method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnSearch() {

        try {

            if ( CommunicationTypeList.QUOTE.getCod().equals( filter.getType() ) )
            {

                communicationList = null;

                if ( quotationList != null ){
                    quotationList.clear();
                }

                final IQuotationService quotationService = getService(IQuotationService.class);

                final QuotationFilter quotationFilter = new QuotationFilter();

                quotationList = quotationService.searchBusinessObjects(quotationFilter);

                quotationListSize = quotationList.size();

            } else {

                quotationList = null;

                listSize = 0;
                if (communicationList != null) {
                    communicationList.clear();
                }

                final ICommunicationService communicationService = getService(ICommunicationService.class);

                communicationList = communicationService.search(filter);
                if (!communicationList.isEmpty()){
                    FileNameDecorator.decorateFileName(communicationList);
                }
                setMessages(communicationService.getMessages());
                listSize = communicationList.size();

            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }


    /**
     * Method responsible for initialize the Communication edit page.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnEdit() {

        try {
            flgNew = false;
            final ICommunicationService communicationService = getService(ICommunicationService.class);

            communication = communicationService.findByIdComplete(communication);

            if (Character.valueOf(CommunicationTypeList.CAMPAIGN.getCod()).equals(communication.getType())) {
                flgRenderPeriodRegister = true;
            } else {
                flgRenderPeriodRegister = false;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return CHANGE;
    }

    /**
     * Method responsible for calling the Delete method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnDelete() {

        try {
            final ICommunicationService communicationService = getService(ICommunicationService.class);

            communicationService.delete(communication);
            if (communicationService.isOk()) {
                communicationList = communicationService.search(filter);
            }
            setMessages(communicationService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for starting the download of the selected attachment.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String download() {

        try {
            final ICommunicationService communicationService = getService(ICommunicationService.class);
            final Communication communicationResult = communicationService.findById(this.communication);
            FileNameDecorator.decorateFileName(communicationResult);
            downloadFile(communicationResult.getFileName(), communicationResult.getFile());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for calling the Save method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnSave() {

        try {
            final ICommunicationService communicationService = getService(ICommunicationService.class);

            if (flgNew) {
                communication.setFileName(null);
                communication.setFile(null);
            }

            if (file != null) {
                InputStream stream = null;
                try {
                    stream = file.getInputStream();
                    final byte[] buffer = new byte[(int) file.getSize()];
                    final int result = stream.read(buffer);

                    if (result > 0) {
                        final String[] filePatch = file.getName().split("\\" + File.separator);
                        final String fileName = filePatch[filePatch.length - 1];

                        communication.setFileName(fileName);
                        communication.setFile(buffer);
                    } else {
                        throw new IOException(getMessage("error.upload"));
                    }
                } catch (IOException e) {
                    LOG.error(e.getMessage(), e);
                    showHtmlException(e);
                } finally {
                    if (stream != null) {
                        stream.close();
                    }
                }
            }

            if (!flgRenderPeriodRegister) {
                communication.setPeriodBegin(null);
                communication.setPeriodEnd(null);
            }

            if (flgNew) {
                communicationService.save(communication);
            } else {
                communicationService.update(communication);
                communicationList = communicationService.search(filter);
            }

            if (communicationService.isOk()) {
                communication = new Communication();
            }

            setMessages(communicationService.getMessages());

            if (communicationService.isOk()) {
                return BACK;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for cancel the changes on a communication and return to the search page.
     * 
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnCancel() {

        final ICommunicationService communicationService = getService(ICommunicationService.class);

        if (isNewer()) {
            return BACK;
        } else {
            communicationList = communicationService.search(filter);
        }


        return BACK;
    }

    public String redirectUrl() {

        try {
            ((HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse())
                .sendRedirect(communication.getUrl());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return NOT_NAVIGATE;
    }

    /**
     * Method that returns a SelectItem list of Types for the register page.
     * 
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public List<SelectItem> getTypeListRegister() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        returns.addAll(createTypeList());

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Types for the search page.
     * 
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public List<SelectItem> getTypeListSearch() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(ALL)));

        returns.addAll(createTypeList());

        return returns;
    }

    /**
     * Method that creates a SelectItem list of Types.
     * 
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> createTypeList() {

        final List<SelectItem> items = new ArrayList<SelectItem>();

        for (final CommunicationTypeList type : CommunicationTypeList.values()) {
            items.add(new SelectItem(type.getCod(), getMessage(type.getName())));
        }

        return sortSelectItem(items);
    }

    /**
     * @return the flgRenderPeriodRegister
     */
    public boolean isFlgRenderPeriodRegister() {

        return flgRenderPeriodRegister;
    }

    /**
     * @return the flgRenderPeriodSearch
     */
    public boolean isFlgRenderPeriodSearch() {

        return flgRenderPeriodSearch;
    }

    /**
     * @return the communicationList
     */
    public List<Communication> getCommunicationList() {

        return communicationList;
    }

    /**
     * @return the filter
     */
    public CommunicationFilter getFilter() {

        return filter;
    }

    /**
     * @return the communication
     */
    public Communication getCommunication() {

        return communication;
    }

    /**
     * @param communication the communication to set
     */
    public void setCommunication(Communication communication) {

        this.communication = communication;
    }

    /**
     * @return the listSize
     */
    public int getListSize() {

        return listSize;
    }

    /**
     * @return the file
     */
    public UploadedFile getFile() {

        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(UploadedFile file) {

        this.file = file;
    }

    /**
     * @return the flgNew
     */
    public boolean isFlgNew() {

        return flgNew;
    }

    /**
     * Gets the quantity of user history
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public int getQtCommunicationHistory() {

        int count = 0;
        if (this.communication != null && this.communication.getHistories() != null) {
            count = this.communication.getHistories().size();
        }
        return count;
    }

    /**
     * @return the enableSaveBtn
     */
    public boolean isEnableSaveBtn() {

        enableSaveBtn = access(PermissionList.NEW_COMMUNICATION_SCREEN_PERMISSION_CD.getPermissionCd());

        return enableSaveBtn;
    }

    /**
     * @param enableSaveBtn - the enableSaveBtn to set
     */
    public void setEnableSaveBtn(boolean enableSaveBtn) {

        this.enableSaveBtn = enableSaveBtn;
    }

    /**
     * Checks if the authenticated user has access permission for the function communicationNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCommunicationNew() {

        return access(PermissionList.NEW_COMMUNICATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    public List<QuotationBusiness> getQuotationList() {
        return quotationList;
    }

    public void setQuotationList(List<QuotationBusiness> quotationList) {
        this.quotationList = quotationList;
    }

    public int getQuotationListSize() {
        return quotationListSize;
    }

    public void setQuotationListSize(int quotationListSize) {
        this.quotationListSize = quotationListSize;
    }
}