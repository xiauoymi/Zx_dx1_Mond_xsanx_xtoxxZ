package com.monsanto.barter.web.faces.customer;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;

import java.util.*;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import com.monsanto.barter.business.entity.filter.DivisionFilter;
import com.monsanto.barter.business.entity.table.Division;
import com.monsanto.barter.business.entity.table.id.DivisionId;
import com.monsanto.barter.business.service.IDivisionService;
import org.apache.commons.lang.StringUtils;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.CustomerBusiness;
import com.monsanto.barter.business.entity.filter.CustomerFilter;
import com.monsanto.barter.business.service.ICustomerService;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.List;

/**
 * Class responsible for controlling the pop-up of customers.
 * 
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 30/11/2011
 * 
 */
@ManagedBean(name="customerFaces")
@SessionScoped
public class CustomerFaces extends BaseJSF {

    private static final Logger LOG = Logger.getLogger(CustomerFaces.class);

    private static final long serialVersionUID = 3364467355763026261L;

    private CustomerFilter customerFilter;

    private List<CustomerBusiness> customerList;

    private List<SelectItem> listSelectRadio;

    private User loggedUser;

    private Map<String,String> divisions;
    /**
     * Constructor default.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public CustomerFaces() {

        super();
        init();
    }

    private void init() {
        this.customerFilter = new CustomerFilter();
        this.customerList = new ArrayList<CustomerBusiness>();
        this.listSelectRadio = new ArrayList<SelectItem>();
        loggedUser = SecurityUtil.getLoggedInUser();
        loadDivisions();
    }

    private void loadDivisions(){

        divisions = new HashMap<String, String>();

        IDivisionService divisionService = getService(IDivisionService .class);

        DivisionFilter divisionFilter = new DivisionFilter();
        divisionFilter.setDivision( new Division( new DivisionId()));

        for ( Division division : divisionService.search( divisionFilter )){

            if ( division.getId().getLanguageCd().equals(loggedUser.getLanguageCd())){
                divisions.put(division.getId().getDivisionCd(),division.getDesc());
            }
        }

    }

    /**
     * Method responsible for calling the search method from the business layer.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void search() {

        ICustomerService customerService = getService(ICustomerService.class);

        try {
            customerFilter = ((SimulationFaces) getFaces("simulationFaces")).getCustomerFilter();
            customerFilter.setCountryCd(loggedUser.getCountyCd());
            this.customerList = customerService.search(this.customerFilter);

            addDivisions();

            this.setMessages(customerService.getMessages());
            
            this.listSelectRadio = new ArrayList<SelectItem>();
            
            for (CustomerBusiness customer : this.customerList) {
                this.listSelectRadio.add(new SelectItem(customer.getRealSapCd().trim()+"-"+customer.getDistrChannelCd()+"-"+customer.getUnitId()+"-"+customer.getRegionalId(), StringUtils.EMPTY));
            }
            
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    private void addDivisions(){

        for ( CustomerBusiness customer : this.customerList ){
            customer.setDivision(divisions.get(customer.getDivisionCd()));
        }

    }


    
    /**
     * Method responsible for the action to cancel selection of customer.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cancelSelectionCustomer() {

        init();
        this.customerFilter.setName(null);
        this.customerFilter.setSapCd(null);
        this.customerFilter.setCpfCnpj(null);
        this.customerList.clear();
    }
    
    /**
     * Method returns number of records in the list of customers
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public int getQtdCustomers() {

        int count = 0;
        if (this.customerList != null) {
            count = this.customerList.size();
        }
        return count;
    }
    
    /**
     * @return the customerList
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public List<CustomerBusiness> getCustomers() {

        return customerList;
    }
    
    /**
     * @return the listSelectRadio
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public List<SelectItem> getListSelectRadio() {

        return this.listSelectRadio;
    }

    public CustomerFilter getCustomerFilter() {
        return customerFilter;
    }

    public void setCustomerFilter(CustomerFilter customerFilter) {
        this.customerFilter = customerFilter;
    }
}