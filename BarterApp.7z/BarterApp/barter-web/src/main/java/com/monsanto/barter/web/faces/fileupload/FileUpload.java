package com.monsanto.barter.web.faces.fileupload;

import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.list.DocumentTypeList;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class FileUpload extends BaseJSF {
    private final Logger log = LoggerFactory.getLogger(FileUpload.class);

    private File file;

    private DocumentTypeList uploadDocumentType;

    private String uploadDocumentNumber;

    private List<String> uploadErrorMessages = new ArrayList<String>();

    public void handleFileUpload(FileUploadEvent event) {
        UploadedFile uploadedFile = event.getFile();
        file = new File(uploadedFile.getFileName(), uploadedFile.getContentType(), uploadedFile.getSize(),
                uploadedFile.getContents());
        log.debug("Uploaded ({}) successfully!", uploadedFile.getFileName());
    }

    public void clear() {
        this.file = null;
    }

    public File getFile() {
        return file;
    }

    public DocumentTypeList getUploadDocumentType() {
        return uploadDocumentType;
    }

    public void setUploadDocumentType(DocumentTypeList uploadDocumentType) {
        this.uploadDocumentType = uploadDocumentType;
    }

    public String getUploadDocumentNumber() {
        return uploadDocumentNumber;
    }

    public void setUploadDocumentNumber(String uploadDocumentNumber) {
        this.uploadDocumentNumber = uploadDocumentNumber;
    }

    public List<String> getUploadErrorMessages() {
        return uploadErrorMessages;
    }

    public void setUploadErrorMessages(List<String> uploadErrorMessages) {
        this.uploadErrorMessages = uploadErrorMessages;
    }
}