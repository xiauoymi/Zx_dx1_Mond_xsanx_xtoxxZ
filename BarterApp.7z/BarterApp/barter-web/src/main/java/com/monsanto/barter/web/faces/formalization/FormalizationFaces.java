/**
 * 
 */
package com.monsanto.barter.web.faces.formalization;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.filter.FormalizationTermFilter;
import com.monsanto.barter.business.entity.list.LanguageList;
import com.monsanto.barter.business.entity.list.TagList;
import com.monsanto.barter.business.entity.table.FormalizationTerm;
import com.monsanto.barter.business.service.IFormalizationTermService;
import org.apache.log4j.Logger;

/**
 * Managed Bean for Term of Formalization
 * 
 * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
 * @since 17/01/2012
 * 
 */
@ManagedBean(name = "formalizationTermFaces")
@SessionScoped
public class FormalizationFaces extends BaseJSF {

    private static final Logger LOG = Logger.getLogger(FormalizationFaces.class);

    private static final long serialVersionUID = 2235636784378859274L;

    private FormalizationTerm formalizationVO;

    private boolean btnSave;

    private boolean btnEdit;

    private boolean btnExit;

    private String languageId;

    private String tagId;

    private String flagSave;

    private String tagSelected;

    private String textareaSelected;

    private String leftValue;

    private String topValue;

    private List<SelectItem> itemsLanguage;

    private Map<String, TagList> itemsTag;

    /**
     * Default constructor of the class.
     */
    public FormalizationFaces() {

        super();
    }

    public String begin(){

        refreshPage();

        return SUCCESS;
    }

    private void refreshPage() {
        IFormalizationTermService formalizationTermService = getService(IFormalizationTermService.class);

        try {
            initForm();
            if (hasValue(languageId)) {
                try {

                    FormalizationTermFilter formalizationTermFilter = new FormalizationTermFilter();
                    formalizationTermFilter.setLanguage(languageId);
                    this.formalizationVO = formalizationTermService.searchByLanguage(formalizationTermFilter);

                } catch (Exception e) {
                    LOG.error(e.getMessage(), e);
                    showHtmlException(e);
                }
            }

            initButtons();
            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(formalizationTermService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    private void initButtons() {

        if (this.formalizationVO == null) {
            this.formalizationVO = new FormalizationTerm();
            this.formalizationVO.setLanguage(languageId);
        }
        this.btnSave = false;
        this.btnEdit = true;
        this.btnExit = false;
    }

    private void initForm() {

        Character c = SecurityUtil.getLoggedInUser().getLanguageCd();
        if (c != null) {
            languageId = c.toString();
        }
        if (itemsLanguage == null || itemsLanguage.isEmpty()) {
            itemsLanguage = new ArrayList<SelectItem>();
            itemsLanguage.add(new SelectItem(LanguageList.ENGLISH.getCodLanguage(), getMessage(LanguageList.ENGLISH
                .getName())));
            itemsLanguage.add(new SelectItem(LanguageList.PORTUGUESE.getCodLanguage(),
                getMessage(LanguageList.PORTUGUESE.getName())));
            itemsLanguage.add(new SelectItem(LanguageList.SPANISH.getCodLanguage(), getMessage(LanguageList.SPANISH
                .getName())));
        }
        if (itemsTag == null || itemsTag.isEmpty()) {
            itemsTag = new LinkedHashMap<String, TagList>();
            itemsTag.put(TagList.NAME_CLI.getName(), TagList.NAME_CLI);
            itemsTag.put(TagList.NUM_CPFCNPJ.getName(), TagList.NUM_CPFCNPJ);
            itemsTag.put(TagList.ADDRESS.getName(), TagList.ADDRESS);
            itemsTag.put(TagList.CITY.getName(), TagList.CITY);
            itemsTag.put(TagList.UF.getName(), TagList.UF);
            itemsTag.put(TagList.COMMODITIES.getName(), TagList.COMMODITIES);
            itemsTag.put(TagList.CROP_YEAR.getName(), TagList.CROP_YEAR);
            itemsTag.put(TagList.AMOUNT_BAG.getName(), TagList.AMOUNT_BAG);
            itemsTag.put(TagList.AMOUNT_KG.getName(), TagList.AMOUNT_KG);
            itemsTag.put(TagList.WAREHOUSE.getName(), TagList.WAREHOUSE);
            itemsTag.put(TagList.PLACE_DELIVERY.getName(), TagList.PLACE_DELIVERY);
            itemsTag.put(TagList.DT_DELIVERY.getName(), TagList.DT_DELIVERY);
            itemsTag.put(TagList.DT_FROM.getName(), TagList.DT_FROM);
            itemsTag.put(TagList.DT_TO.getName(), TagList.DT_TO);
            itemsTag.put(TagList.CHANGE_ADDRESS.getName(), TagList.CHANGE_ADDRESS);
            itemsTag.put(TagList.EMAIL.getName(), TagList.EMAIL);
            itemsTag.put(TagList.DT_CURRENT.getName(), TagList.DT_CURRENT);
            this.tagId = TagList.NAME_CLI.getCode();
        }
        this.topValue = "200";
        this.leftValue = "350";
    }

    /**
     * Change screen fields to enable
     * 
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public void edit() {

        this.btnSave = true;
        this.btnEdit = false;
        this.btnExit = true;

    }

    /**
     * Register a Formalization Term
     * 
     * @return Outcome of navigation
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public void save() {

        IFormalizationTermService formalizationTermService = getService(IFormalizationTermService.class);

        try {

            formalizationTermService.save(formalizationVO);

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(formalizationTermService.getMessages());
            this.btnSave = false;
            this.btnEdit = true;
            this.btnExit = false;

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Cancel
     * 
     * @return Outcome of navigation
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public String exit() {

        return HOME;
    }

    /**
     * change the language of the Formalization Term
     * 
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public void cboLanguageListener() {

        IFormalizationTermService formalizationTermService = getService(IFormalizationTermService.class);

        this.languageId = this.formalizationVO.getLanguage();
        if (hasValue(languageId)) {
            try {

                FormalizationTermFilter formalizationTermFilter = new FormalizationTermFilter();
                formalizationTermFilter.setLanguage(languageId);
                this.formalizationVO = formalizationTermService.searchByLanguage(formalizationTermFilter);
                if (this.formalizationVO == null) {
                    this.formalizationVO = new FormalizationTerm();
                    this.formalizationVO.setLanguage(languageId);
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
                showHtmlException(e);
            }
        }

//        return SUCCESS;
    }

    public FormalizationTerm getFormalizationVO() {

        return formalizationVO;
    }

    public void setFormalizationVO(FormalizationTerm formalizationVO) {

        this.formalizationVO = formalizationVO;
    }

    public boolean isBtnSave() {

        return btnSave;
    }

    public void setBtnSave(boolean btnSave) {

        this.btnSave = btnSave;
    }

    public boolean isBtnEdit() {

        return btnEdit;
    }

    public void setBtnEdit(boolean btnEdit) {

        this.btnEdit = btnEdit;
    }

    public boolean isBtnExit() {

        return btnExit;
    }

    public void setBtnExit(boolean btnExit) {

        this.btnExit = btnExit;
    }

    public String getLanguageId() {

        return languageId;
    }

    public void setLanguageId(String languageId) {

        this.languageId = languageId;
    }

    public List<SelectItem> getItemsLanguage() {

        return itemsLanguage;
    }

    public void setItemsLanguage(List<SelectItem> itemsLanguage) {

        this.itemsLanguage = itemsLanguage;
    }

    public String getFlagSave() {

        return flagSave;
    }

    public void setFlagSave(String flagSave) {

        this.flagSave = flagSave;
    }

    public String getTagId() {

        return tagId;
    }

    public void setTagId(String tagId) {

        this.tagId = tagId;
    }

    public List<TagList> getItemsTag() {

        return new ArrayList<TagList>(itemsTag.values());
    }

    public void setItemsTag(Map<String, TagList> itemsTag) {

        this.itemsTag = itemsTag;
    }

    public String getTagSelected() {

        return tagSelected;
    }

    public void setTagSelected(String tagSelected) {

        this.tagSelected = tagSelected;
    }

    public String getLeftValue() {

        return leftValue;
    }

    public void setLeftValue(String leftValue) {

        this.leftValue = leftValue;
    }

    public String getTopValue() {

        return topValue;
    }

    public void setTopValue(String topValue) {

        this.topValue = topValue;
    }

    public String getTextareaSelected() {

        return textareaSelected;
    }

    public void setTextareaSelected(String textareaSelected) {

        this.textareaSelected = textareaSelected;
    }

}
