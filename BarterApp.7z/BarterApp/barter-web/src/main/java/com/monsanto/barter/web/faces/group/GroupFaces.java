package com.monsanto.barter.web.faces.group;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.PermissionBusiness;
import com.monsanto.barter.business.entity.filter.GroupFilter;
import com.monsanto.barter.business.entity.filter.PermissionFilter;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.list.GroupPermanentList;
import com.monsanto.barter.business.entity.list.ModuleList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.list.PermissionTypeList;
import com.monsanto.barter.business.entity.list.StatusList;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.Permission;
import com.monsanto.barter.business.entity.table.User;
import com.monsanto.barter.business.service.IGroupService;
import com.monsanto.barter.business.service.IPermissionService;
import com.monsanto.barter.business.service.IUserService;
import org.apache.log4j.Logger;


/**
 *
 * Managed Bean for registration and group research
 *
 * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
 * @since 01/12/2011
 */
@ManagedBean(name="groupFaces")
@SessionScoped
public class GroupFaces extends BaseJSF {

    protected static final Logger LOG = Logger.getLogger(GroupFaces.class);

    private static final long serialVersionUID = 3364467355763026261L;

    private Group group;

    private GroupFilter groupFilter;

    private User userVO;

    private UserFilter userFilter;

    private String module;

    private Integer moduleId;

    private String permissionType;

    private Integer permissionTypeId;

    private String groupId;

    private String tab;

    private boolean tableShow;

    private boolean deletedGroup = Boolean.FALSE;

    private boolean enableSaveBtn;

    private List<Group> groupList;

    private List<User> userGroupList;

    private List<User> userListSelected;

    private List<PermissionBusiness> permissions;

    private List<SelectItem> itemsUser;

    private List<SelectItem> itemsModules;

    private List<SelectItem> itemsPermissionTypes;

    private List<SelectItem> statusGroup;

    private List<String> idUserSelectedList;

    /**
     * Default constructor of the class.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public GroupFaces() {

        super();
       init();

    }

    /**
     * Initializes the page clears all objects.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    @PostConstruct
    public final void init() {
        this.group = new Group();
        this.group.setActiveFl(StatusList.ACTIVE.getFlag());
        this.groupFilter = new GroupFilter();
        this.userVO = new User();
        this.userFilter = new UserFilter();
        this.userFilter.setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());
        this.userFilter.getUser().setBarterUser(StatusList.ACTIVE.getFlag());
        this.module = null;
        this.moduleId = null;
        this.permissionType = null;
        this.permissionTypeId = null;
        this.groupId = null;
        this.tableShow = Boolean.FALSE;
        this.deletedGroup = Boolean.FALSE;
        this.setMessages("");

        // Initializes lists
        initListItems();

        // Loads permissions
        loadPermissions(null, null);

        // Load Status
        loadStatus();

        // Displays the tab group
        showGroupTab();

    }

    public String begin(){
        init();
        return SUCCESS;
    }

    /**
     * Method responsible for initializing the lists
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void initListItems() {

        this.groupList = new ArrayList<Group>();
        this.userGroupList = new ArrayList<User>();
        this.userListSelected = new ArrayList<User>();
        this.idUserSelectedList = new ArrayList<String>();
        this.permissions = new ArrayList<PermissionBusiness>();
        this.itemsUser = new ArrayList<SelectItem>();
        this.itemsModules = new ArrayList<SelectItem>();
        this.itemsPermissionTypes = new ArrayList<SelectItem>();
        this.statusGroup = new ArrayList<SelectItem>();

//        this.newCheckedPermissions = new ArrayList<Permission>();        
//        this.checkedPermissions = new ArrayList<Permission>();

    }

    /**
     * Method responsible for canceling the operation and display the search screen
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String cancelGroup() {

        IGroupService groupService = getService(IGroupService.class);

        try {

            if(isNewer()){
                return SHOW_FILTER;
            }else{
                groupList = groupService.search(groupFilter);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SHOW_FILTER;
    }

    /**
     * Method responsible for loading the edit screen group
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String editGroup() {

        IGroupService groupService = getService(IGroupService.class);
        try {

            this.group = groupService.findByIdComplete(this.group);
            this.deletedGroup = GroupPermanentList.canNotBeDeteledGroup(this.group.getId());
            this.userGroupList = findUserByGroup();

            loadUsers(this.userGroupList);
            populateUsersSelected(this.userGroupList);
            loadPermissions(null, null);

            setNewer(false);
            showGroupTab();
            this.setMessages(groupService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }

        return CHANGE;
    }

    /**
     * Method responsible for seeking all users associated with this group
     *
     * @return list of users in the group
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private List<User> findUserByGroup() {

        IUserService userService = getService(IUserService.class);

        UserFilter filter = new UserFilter();
        filter.setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());
        filter.setGroupId(this.group.getId().toString());

        return userService.search(filter);
    }

    /**
     * Method responsible for populating the picklist with users associated with the group
     *
     * @param users list of users
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void populateUsersSelected(List<User> users) {

        this.idUserSelectedList = new ArrayList<String>();

        for (User user : users) {
            this.idUserSelectedList.add(user.getId());
        }
    }

    /**
     * Method responsible for fetching the database users based on the selected ids
     *
     * @return list of users selected
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<User> findUsersSelected() {

        IUserService userService = getService(IUserService.class);
        List<User> userList = new ArrayList<User>();
        User user = null;

        for (String idUser : getIdUserSelectedList()) {
            user = new User();
            user.setId(idUser);
            user = userService.findById(user);

            userList.add(user);
            this.userGroupList.remove(user);
        }

        return userList;
    }

    /**
     * Method responsible for loading all the system permissions. These data will be obtained from Resource Bundle
     * according to the language of the logged in user.
     *
     * @param moduleIdInt
     * @param permissionTypeIdInt
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public List<Permission> newCheckedPermissions;
    public List<Permission> checkedPermissions;

    public void loadPermissions(Integer moduleIdInt, Integer permissionTypeIdInt) {

        IPermissionService permissionService = getService(IPermissionService.class);

        IGroupService groupService = getService(IGroupService.class);

        permissions = new ArrayList<PermissionBusiness>();
        List<PermissionBusiness> allPermissions = null;
        List<Permission> groupPermissions = null;
        List<Permission> userPermissions = null;

        Group groupVO = groupService.findByIdComplete(this.group);

        if (groupVO != null) {
            groupPermissions = groupVO.getPermissions();
        } else {
            groupPermissions = new ArrayList<Permission>();
        }

        permissions = permissionService.applyPermissions(getPermissions(), groupPermissions, userPermissions);

        checkedPermissions = permissionService.getCheckedGroupPermissions(getPermissions());

        if (checkedPermissions != null) {
            if(newCheckedPermissions == null) {
                newCheckedPermissions = new ArrayList<Permission>();
            }
            for (Permission checkedPermission : checkedPermissions) {

                if (!groupPermissions.contains(checkedPermission)) {
                    groupPermissions.add(checkedPermission);
                    newCheckedPermissions.add(checkedPermission);
                }
            }
        }

        List<Permission> uncheckedPermissions = permissionService.getUncheckedPermissions(getPermissions());

        if (uncheckedPermissions != null) {

            for (Permission uncheckedPermission : uncheckedPermissions) {

                if (groupPermissions.contains(uncheckedPermission)) {
                    groupPermissions.remove(uncheckedPermission);
                }
            }
        }

        allPermissions = permissionService.search(new PermissionFilter(null, moduleIdInt, permissionTypeIdInt));

        permissions = permissionService.applyPermissions(allPermissions, groupPermissions, userPermissions);

        if (newCheckedPermissions != null) {
            permissions = permissionService.addNewPermissions(permissions, newCheckedPermissions, moduleIdInt);
        }

    }

    /**
     * Method responsible for loading the status group list
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadStatus() {

        final List<SelectItem> statusList = new ArrayList<SelectItem>();

        for (final StatusList status : StatusList.values()) {
            statusList.add(new SelectItem(status.getFlag(), getMessage(status.getName())));
        }

        sortSelectItem(statusList);
        this.statusGroup.addAll(statusList);
    }

    /**
     * Method responsible for loading the drop-down list of permission types. These data will be obtained from Resource
     * Bundle according to the language of the logged in user.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void loadPermissionTypes() {

        itemsPermissionTypes = new ArrayList<SelectItem>();
        itemsPermissionTypes.add(new SelectItem(null, getMessage(ALL)));

        for (PermissionTypeList permissionTypeList : PermissionTypeList.values()) {
            itemsPermissionTypes.add(new SelectItem(permissionTypeList.getPermissionTypeCd(),
                    getMessage(permissionTypeList.getName())));
        }
    }

    /**
     * Method responsible for displaying the screen Register Group
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String newGroup() {

        // this.group = new Group();
        init();
        setNewer(true);

        return NEW;
    }

    /**
     * Method responsible for confirming the inclusion or amendment of group information in the database.
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String saveGroup() {

        String navigation = NOT_NAVIGATE;
        IPermissionService permissionService = getService(IPermissionService.class);
        IGroupService groupService = getService(IGroupService.class);

        try {

            // Get the permissions that have been selected for the Grupo
            checkedPermissions = permissionService.getCheckedGroupPermissions(getPermissions());

            for (Permission newPermission : newCheckedPermissions) {

                PermissionBusiness newCheckedPermission = (PermissionBusiness) newPermission;

                if ((moduleId != null) && (!newCheckedPermission.getModuleCd().equals(moduleId))) {
                    newCheckedPermission.setReadOnly(true);
                    checkedPermissions.add(newCheckedPermission);
                }
            }

            // It contains the permissions that were not selected by the user
            List<Permission> uncheckedGroupPermissions = permissionService.getUncheckedPermissions(getPermissions());

            group.setPermissions(groupService.validatePermissions(group.getPermissions(),checkedPermissions,uncheckedGroupPermissions));

            if (isNewer()) {
                this.userListSelected = findUsersSelected();
                groupService.save(group, userListSelected);
            } else {
                if (groupService.validate(group, idUserSelectedList)) {
                    this.userListSelected = findUsersSelected();
                    groupService.update(group, userGroupList, userListSelected);
                }
            }

            if (groupService.isOk()) {
                searchGroup();
                navigation = SHOW_FILTER;
            } else {
                showGroupTab();
            }

            this.setMessages(groupService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return navigation;
    }

    /**
     * Method responsible for researching the filter groups as received.
     *
     * @return string defining the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String searchGroup() {

        IGroupService groupService = getService(IGroupService.class);

        try {

            groupList = groupService.search(groupFilter);
            tableShow = (!groupList.isEmpty());

            // Get messages from the business layer.
            this.setMessages(groupService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SUCCESS;
    }

    /**
     * Method responsible for fetching available for users that may be associated with the group.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void searchAvailableUsers() {

        IUserService userService = getService(IUserService.class);
        List<User> userList = null;

        try {
            this.userFilter.setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());
            this.userFilter.getUser().setStatus(StatusList.ACTIVE.getFlag());

            if (!isNewer()) {
                this.userFilter.getUser().setGroup(this.group);
            }

            userList = userService.searchAvaliable(userFilter);

            loadUsers(userList);

            this.userFilter = new UserFilter();
            this.userFilter.setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for displaying the Groups tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showGroupTab() {

        this.tab = "tabGroup";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the History tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showHistoryTab() {

        this.tab = "tabHistory";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the Permissions tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showPermissionsTab() {

        this.tab = "tabPermissions";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the Users tab
     *
     * @return the name of the active tab on page
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String showUsersTab() {

        this.tab = "tabUsers";

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for fetching the User that will populate the interface component
     *
     * @param userList list of users
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void loadUsers(List<User> userList) {

        itemsUser = new ArrayList<SelectItem>();

        for (User user : userList) {
            itemsUser.add(new SelectItem(user.getId(), user.getName()));
        }
    }

    /**
     * Method responsible for fetching the Module that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void cboModuleListener() {

        if (hasValue(module)) {

            this.moduleId = Integer.valueOf(getModule());
        } else {
            this.moduleId = null;
        }

        loadPermissions(getModuleId(), getPermissionTypeId());
    }

    /**
     * Method responsible for fetching the Permission that will populate the interface component
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public void cboPermissionTypeListener() {

        if (hasValue(permissionType)) {

            this.permissionTypeId = Integer.valueOf(getPermissionType());
        } else {
            this.permissionTypeId = null;
        }

        loadPermissions(getModuleId(), getPermissionTypeId());
    }

    /**
     * Method responsible for loading the drop-down list of modules. These data will be obtained from Resource Bundle
     * according to the language of the logged in user.
     *
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void loadModules() {

        itemsModules = new ArrayList<SelectItem>();
        itemsModules.add(new SelectItem(null, getMessage(ALL)));

        for (ModuleList moduleList : ModuleList.values()) {
            itemsModules.add(new SelectItem(moduleList.getModuleCd(), getMessage(moduleList.getName())));
        }
    }

    /**
     * Gets the quantity of group search
     *
     * @return the quantity of group search
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public int getQtd() {

        int count = 0;
        if (this.groupList != null) {
            count = this.groupList.size();
        }
        return count;
    }

    /**
     * Gets the quantity of user history
     *
     * @return quantity of user history
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public int getQtGroupHistory() {

        int count = 0;
        if (this.group != null && this.group.getHistories() != null) {
            count = this.group.getHistories().size();
        }
        return count;
    }

    /**
     * Gets the quantity of permissions
     *
     * @return the quantity of permissions
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public int getQtPermissions() {

        int count = 0;
        if (this.permissions != null) {
            count = this.permissions.size();
        }
        return count;
    }

    /**
     * @return the itemsModules
     */
    public List<SelectItem> getItemsModules() {

        loadModules();

        return itemsModules;
    }

    /**
     * @return the itemsPermissionTypes
     */
    public List<SelectItem> getItemsPermissionTypes() {

        loadPermissionTypes();

        return itemsPermissionTypes;
    }

    /**
     * @return the group
     */
    public Group getGroup() {

        return group;
    }

    /**
     * @param group - the group to set
     */
    public void setGroup(Group group) {

        this.group = group;
    }

    /**
     * @return the groupFilter
     */
    public GroupFilter getGroupFilter() {

        return groupFilter;
    }

    /**
     * @param groupFilter - the groupFilter to set
     */
    public void setGroupFilter(GroupFilter groupFilter) {

        this.groupFilter = groupFilter;
    }

    /**
     * @return the userVO
     */
    public User getUserVO() {

        return userVO;
    }

    /**
     * @param userVO - the userVO to set
     */
    public void setUserVO(User userVO) {

        this.userVO = userVO;
    }

    /**
     * @return the userFilter
     */
    public UserFilter getUserFilter() {

        return userFilter;
    }

    /**
     * @param userFilter - the userFilter to set
     */
    public void setUserFilter(UserFilter userFilter) {

        this.userFilter = userFilter;
    }

    /**
     * @return the module
     */
    public String getModule() {

        return module;
    }

    /**
     * @param module - the module to set
     */
    public void setModule(String module) {

        this.module = module;
    }

    /**
     * @return the moduleId
     */
    public Integer getModuleId() {

        return moduleId;
    }

    /**
     * @param moduleId - the moduleId to set
     */
    public void setModuleId(Integer moduleId) {

        this.moduleId = moduleId;
    }

    /**
     * @return the permissionType
     */
    public String getPermissionType() {

        return permissionType;
    }

    /**
     * @param permissionType - the permissionType to set
     */
    public void setPermissionType(String permissionType) {

        this.permissionType = permissionType;
    }

    /**
     * @return the permissionTypeId
     */
    public Integer getPermissionTypeId() {

        return permissionTypeId;
    }

    /**
     * @param permissionTypeId - the permissionTypeId to set
     */
    public void setPermissionTypeId(Integer permissionTypeId) {

        this.permissionTypeId = permissionTypeId;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {

        return groupId;
    }

    /**
     * @param groupId - the groupId to set
     */
    public void setGroupId(String groupId) {

        this.groupId = groupId;
    }

    /**
     * @return the tab
     */
    public String getTab() {

        return tab;
    }

    /**
     * @param tab - the tab to set
     */
    public void setTab(String tab) {

        this.tab = tab;
    }

    /**
     * @return the groupList
     */
    public List<Group> getGroupList() {

        return groupList;
    }

    /**
     * @param groupList - the groupList to set
     */
    public void setGroupList(List<Group> groupList) {

        this.groupList = groupList;
    }

    /**
     * @return the userGroupList
     */
    public List<User> getUserGroupList() {

        return userGroupList;
    }

    /**
     * @param userGroupList - the userGroupList to set
     */
    public void setUserGroupList(List<User> userGroupList) {

        this.userGroupList = userGroupList;
    }

    /**
     * @return the userListSelected
     */
    public List<User> getUserListSelected() {

        return userListSelected;
    }

    /**
     * @param userListSelected - the userListSelected to set
     */
    public void setUserListSelected(List<User> userListSelected) {

        this.userListSelected = userListSelected;
    }

    /**
     * @return the idUserSelectedList
     */
    public List<String> getIdUserSelectedList() {

        return idUserSelectedList;
    }

    /**
     * @param idUserSelectedList - the idUserSelectedList to set
     */
    public void setIdUserSelectedList(List<String> idUserSelectedList) {

        this.idUserSelectedList = idUserSelectedList;
    }

    /**
     * @return the permissions
     */
    public List<PermissionBusiness> getPermissions() {

        return permissions;
    }

    /**
     * @param permissions - the permissions to set
     */
    public void setPermissions(List<PermissionBusiness> permissions) {

        this.permissions = permissions;
    }

    /**
     * @return the tableShow
     */
    public boolean isTableShow() {

        return tableShow;
    }

    /**
     * @param tableShow - the tableShow to set
     */
    public void setTableShow(boolean tableShow) {

        this.tableShow = tableShow;
    }

    /**
     * @return the deletedGroup
     */
    public boolean isDeletedGroup() {

        return deletedGroup;
    }

    /**
     * @param deletedGroup - the deletedGroup to set
     */
    public void setDeletedGroup(boolean deletedGroup) {

        this.deletedGroup = deletedGroup;
    }

    /**
     * @return the itemsUser
     */
    public List<SelectItem> getItemsUser() {

        return itemsUser;
    }

    /**
     * @param itemsUser - the itemsUser to set
     */
    public void setItemsUser(List<SelectItem> itemsUser) {

        this.itemsUser = itemsUser;
    }

    /**
     * @param itemsModules - the itemsModules to set
     */
    public void setItemsModules(List<SelectItem> itemsModules) {

        this.itemsModules = itemsModules;
    }

    /**
     * @param itemsPermissionTypes - the itemsPermissionTypes to set
     */
    public void setItemsPermissionTypes(List<SelectItem> itemsPermissionTypes) {

        this.itemsPermissionTypes = itemsPermissionTypes;
    }

    /**
     * @return the statusGroup
     */
    public List<SelectItem> getStatusGroup() {

        return statusGroup;
    }

    /**
     * @param statusGroup - the statusGroup to set
     */
    public void setStatusGroup(List<SelectItem> statusGroup) {

        this.statusGroup = statusGroup;
    }

    public List<Permission> getNewCheckedPermissions() {

        return newCheckedPermissions;
    }

    public void setNewCheckedPermissions(List<Permission> newCheckedPermissions) {

        this.newCheckedPermissions = newCheckedPermissions;
    }

    public List<Permission> getCheckedPermissions() {

        return checkedPermissions;
    }

    public void setCheckedPermissions(List<Permission> checkedPermissions) {

        this.checkedPermissions = checkedPermissions;
    }

    /**
     * @return the enableSaveBtn
     */
    public boolean isEnableSaveBtn() {

        enableSaveBtn = access(PermissionList.NEW_GROUP_SCREEN_PERMISSION_CD.getPermissionCd());
        return enableSaveBtn;
    }

    /**
     * @param enableSaveBtn - the enableSaveBtn to set
     */
    public void setEnableSaveBtn(boolean enableSaveBtn) {

        this.enableSaveBtn = enableSaveBtn;
    }

    /**
     * Checks if the authenticated user has access permission for the function groupNew
     *
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessGroupNew() {

        return access(PermissionList.NEW_GROUP_SCREEN_PERMISSION_CD.getPermissionCd());
    }
}