package com.monsanto.barter.web.faces.longshort;

import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.list.LongShortCropStatusList;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.entity.table.LongShortCrop;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.service.ICountryService;
import com.monsanto.barter.business.service.ILongShortCropService;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: GAVELO
 * Date: 8/21/13
 * Time: 12:00 PM
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name = "longShortCropFaces")
@SessionScoped
public class CropFaces extends BaseJSF {

    private static final long serialVersionUID = 1566722162960498594L;


    private LongShortCrop longShortCrop;
    private List<LongShortCrop> longShortCropList;
    private List<SelectItem> countries;


    public CropFaces() {
        longShortCropList = new ArrayList<LongShortCrop>();
        initForm();
    }

    public String begin(){
        longShortCropList = new ArrayList<LongShortCrop>();
        initForm();
        return SUCCESS;
    }

    public LongShortCrop getLongShortCrop() {
        return longShortCrop;
    }

    public void setLongShortCrop(LongShortCrop longShortCrop) {
        this.longShortCrop = longShortCrop;
    }

    public List<LongShortCrop> getLongShortCropList() {
        return longShortCropList;
    }

    public int getQtdLongShorts() {

        int count = 0;

        if (this.longShortCropList != null) {
            count = this.longShortCropList.size();
        }

        return count;
    }

    public String includeLongShortCrop() {

        longShortCrop.getCountry().getId().setLanguageCd(getLanguage());

        ILongShortCropService longShortCropService = getService(ILongShortCropService.class);
        longShortCropService.save(longShortCrop);
        setMessages(longShortCropService.getMessages());
        if ( longShortCropService.getMessages().isEmpty() ){
            initForm();
        }

        return SUCCESS;
    }

    public String editCrop() {
        setDetail(true);
        return CHANGE;
    }

    public String cancelEdit() {
        initForm();
        setDetail(false);
        return NOT_NAVIGATE;
    }

    public String closeCrop() {
        setDetail(false);
        longShortCrop.setStatusCd(LongShortCropStatusList.CLOSED.getCd());
        ILongShortCropService longShortCropService = getService(ILongShortCropService.class);
        longShortCropService.save(longShortCrop);
        this.initForm();
        return SUCCESS;
    }

    private void initForm() {
        setDetail(false);
        longShortCrop = new LongShortCrop();
        longShortCrop.setCountry(new Country());
        longShortCrop.getCountry().setId(new CountryId());
        longShortCrop.setStatusCd(LongShortCropStatusList.OPEN.getCd());
        ILongShortCropService longShortCropService = getService(ILongShortCropService.class);
        longShortCropList=longShortCropService.getAll();
        loadCountries();


    }

    public final void loadCountries() {

        ICountryService countryService = getService(ICountryService.class);
        final List<SelectItem> countryList = new ArrayList<SelectItem>();

        CountryFilter countryFilter = new CountryFilter();

        countryFilter.getCountry().setId(new CountryId());
        countryFilter.getCountry().getId().setLanguageCd(getLanguage());

        List<Country> loadedCountries = countryService.search(countryFilter);

        for (final Country country : loadedCountries) {
            countryList.add(new SelectItem(country.getId().getCountryCd(), country.getShortDesc()));
        }

        sortSelectItem(countryList);
        this.countries = new ArrayList<SelectItem>();
        this.countries.addAll(countryList);

    }

    public void cboCountryChanged(ActionEvent event) {
        longShortCrop.getCountry().getId().setLanguageCd(getLanguage());
    }

    public List<SelectItem> getCountries() {
        return countries;
    }

    public void setCountries(List<SelectItem> countries) {
        this.countries = countries;
    }

    private Character getLanguage() {
        return SecurityUtil.getLoggedInUser().getLanguageCd();
    }

}