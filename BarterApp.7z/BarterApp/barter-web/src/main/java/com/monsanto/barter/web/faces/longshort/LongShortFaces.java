package com.monsanto.barter.web.faces.longshort;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIPanel;
import javax.faces.component.html.HtmlOutputLabel;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.convert.NumberConverter;
import javax.faces.model.SelectItem;

import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.LongShortCropStatusList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.service.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.UIDataTable;
import org.richfaces.component.UIColumn;

import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.LongShortBusiness;
import com.monsanto.barter.business.entity.business.PositionLongShortBusiness;
import com.monsanto.barter.business.entity.list.LongShortPositionList;
import com.monsanto.barter.business.entity.table.id.CommodityId;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.entity.table.id.LongShortId;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.DynamicFieldsFaces;

/**
 * Managed Bean for registration and LongShort research
 *
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 19/12/2011
 */
@ManagedBean(name = "longShortFaces" )
@SessionScoped
public class LongShortFaces extends DynamicFieldsFaces {

    protected static final Logger LOG = Logger.getLogger(LongShortFaces.class);

    private static final String LONG_SHORT_INCLUDED_ERROR = "long.short.included.error";

    /** */
    private static final long serialVersionUID = -8997003688052530743L;

    private static final String STR_STYLE_BOLD_14PX = "font-weight:bold;font-size:14px";

    private static final String STR_5PX = "5px;";

    private static final String STR_50PX = "50px;";

    private static final String STR_920PX = "920px;";

    private static final String STR_100_PORCENT = "100%";

    private String tab;

    private LongShortBusiness longShort;

    private LongShortFilter filter;

    private PositionLongShortFilter positionLongShortFilter;

    private CommodityId commodityId;

    private String sexoId;

    private BigDecimal currentLimit;

    private BigDecimal currentPosition;

    private BigDecimal expositionLongShort;

    private String longShortPosition;

    private List<LongShortBusiness> longShorts;

    private List<SelectItem> itemsCommodity;

    private List<SelectItem> listCountry;

    private List<SelectItem> listCity;

    private List<SelectItem> listCountryAvaliable;

    private List<SelectItem> listCommodityAvaliable;

    private List<SelectItem> listPositionLongShort;

    private boolean flgKgLimitation;

    private boolean flgTabHistory;

    private boolean flgCancelConfirm;

    private List<SelectItem> listCrops;

    private Long cropId;

    public String beginSearch(){

        commonBegin();

        return SUCCESS;
    }

    public String beginPosition(){

        commonBegin();
        loadCities();

        return SUCCESS;

    }

    private void commonBegin() {
        this.listCountry = new ArrayList<SelectItem>();
        this.listCity = new ArrayList<SelectItem>();
        this.listCountryAvaliable = new ArrayList<SelectItem>();
        this.listCommodityAvaliable = new ArrayList<SelectItem>();
        this.itemsCommodity = new ArrayList<SelectItem>();
        flgCancelConfirm = false;

        loadCountries();
        loadCrops();

        initializeLists();
        initForm();
    }


    /**
     * Load the list of countries to component 'cboCountry'
     *
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void loadCountries() {

        ICountryService countryService = getService(ICountryService.class);

        try {
            Country country = new Country(new CountryId());
            country.getId().setLanguageCd(SecurityUtil.getLoggedInUser().getLanguageCd());
            CountryFilter countryFilter = new CountryFilter(country);

            List<Country> countryList = countryService.search(countryFilter);

            for (Country item : countryList) {
                listCountry.add(new SelectItem(item.getId().getCountryCd(), item.getShortDesc()));
            }
            this.setMessages(countryService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of city to component 'cboCity'
     *
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void loadCities() {

        ICityService cityService = getService(ICityService.class);

        try {

            CityFilter cityFilter = new CityFilter();
            cityFilter.setLanguageCd(SecurityUtil.getLoggedInUser().getLanguageCd());
            List<City> cityList = cityService.searchAvaliable(cityFilter);

            for (City city : cityList) {
                listCity.add(new SelectItem(city.getId().getCityCd(), city.getDescCity()));
            }
            this.setMessages(cityService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of countries available to component 'cboCoutry'
     *
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void loadCountriesAvaliable() {

        ICommodityService commodityService = getService(ICommodityService.class);
        ICountryService countryService = getService(ICountryService.class);

        try {

            List<Commodity> commodityList = commodityService.searchAvaliable();
            Set<String> countries = new TreeSet<String>();
            List<Country> countryList = null;

            Country country = null;

            for (Commodity commodity : commodityList) {
                countries.add(commodity.getId().getCountryCd());
            }
            for (String countryId : countries) {
                country = new Country(new CountryId(countryId, SecurityUtil.getLoggedInUser().getLanguageCd()));
                CountryFilter countryFilter = new CountryFilter(country);
                countryList = countryService.search(countryFilter);

                listCountryAvaliable.add(new SelectItem(countryId, countryList.get(0).getShortDesc()));
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of commodity available to component 'cboCommodity'
     *
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void loadCommodityAvaliable(String countryId) {

        ICommodityService commodityService = getService(ICommodityService.class);

        try {

            List<Commodity> commodityList = commodityService.searchAvaliable();

            for (Commodity commodity : commodityList) {
                if (commodity.getId().getCountryCd().equals(countryId)) {
                    listCommodityAvaliable.add(new SelectItem(commodity.getId().getCommodityId().trim(), commodity
                            .getDescCommodity()));
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }


    public void loadCrops() {

        ILongShortCropService longShortCropService = getService(ILongShortCropService.class);

        try {

            LongShortCropFilter longShortCropFilter = new LongShortCropFilter();
            longShortCropFilter.setState(LongShortCropStatusList.OPEN.getCd());

            List<LongShortCrop> longShortCropList = longShortCropService.search(longShortCropFilter);


            listCrops = new ArrayList<SelectItem>();

            for ( LongShortCrop crop: longShortCropList ) {
                listCrops.add(new SelectItem(crop.getId(), crop.getName()));
            }

            this.setMessages(longShortCropService);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Change event of the combo of country.
     *

     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void cboCountryAvaliableChanged() {

        String countryId = this.positionLongShortFilter.getCountryCd();

        if (hasValue(countryId)) {
            this.loadCommodityAvaliable(countryId);
        } else {
            this.listCommodityAvaliable.clear();
        }
    }

    /**
     * Change event of the combo of country.
     *
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void cboCountryChanged() {

        String countryId = this.commodityId.getCountryCd();

        /*
        * if (!super.hasValue(countryId)) { countryId =
        * this.tradingContractFilter.getTradingContract().getCountry().getId().getCountryCd(); }
        */

        if (hasValue(countryId)) {
            this.loadCommodity(countryId);
        } else {
            this.itemsCommodity.clear();
        }
    }

    /**
     * Load the list of goods to component 'cboCommodity'
     *
     * @param countryCd
     * @author Diego Duarte (diego.duarte@cpmbraxis.com)
     */
    public void loadCommodity(String countryCd) {

        ICommodityService commodityService = getService(ICommodityService.class);

        try {
            Commodity commodity = new Commodity(new CommodityId());
            commodity.getId().setCountryCd(countryCd);
            CommodityFilter commodityFilter = new CommodityFilter(commodity);

            List<Commodity> commodityList = commodityService.search(commodityFilter);

            this.itemsCommodity = new ArrayList<SelectItem>();

            for (Commodity item : commodityList) {
                itemsCommodity.add(new SelectItem(item.getId().getCommodityId().trim(), item.getDescCommodity()));
            }
            this.setMessages(commodityService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Search all LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String searchLongShort() {

        ILongShortService longShortService = getService(ILongShortService.class);

        try {

            longShorts = longShortService.getAll();

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(longShortService);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SUCCESS;
    }

    /**
     * Search position Long/Short
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String searchPositionViewLongShort() {

        List<MessageVO> messages = buildDynamicFields("formViewLongShortConsumption", "pnlDynamicPanel");

        this.setMessages(messages);

        return "positionView";
    }

    /**
     * Prepares to register a new LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String newLongShort() {

        /*
         * Informa que a tela esta em modo de inclusao.
         */
        setNewer(true);

        return NEW;
    }

    /**
     * Editing a LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String editLongShort() {

        ILongShortService longShortService = getService(ILongShortService.class);

        try {

            longShortService.checksLongShortPendingConfirmation(getLongShorts(), super.isDetail());

            if (longShortService.isOk()) {

                loadCommodity(commodityId.getCountryCd());
                loadLongShort(longShortService, longShort);

                setNewer(false);
                setDetail(true);
                setFlgKgLimitation(false);
                setFlgTabHistory(false);

            } else {
                longShort = new LongShortBusiness(new LongShortId());
            }

            showGeneralTab();

            /*
             * Obter mensagens da camada de negocio.
             */
            this.setMessages(longShortService);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return CHANGE;
    }

    /**
     * Detail a LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String detailLongShort() {

        ILongShortService longShortService = getService(ILongShortService.class);

        longShortService.checksLongShortPendingConfirmation(getLongShorts(), super.isDetail());
        setDetail(false);

        if (longShortService.isOk()) {
            setNewer(true);
            setDetail(true);
            setFlgKgLimitation(true);
            setFlgTabHistory(false);

            loadCommodity(commodityId.getCountryCd());
            loadLongShort(longShortService, longShort);
        } else {
            longShort = new LongShortBusiness(new LongShortId());
        }

        /*
         * Obter mensagens da camada de negocio.
         */
        this.setMessages(longShortService);

        return CHANGE;
    }

    /**
     * Include a LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String includeLongShort() {

        ICommodityService commodityService = getService(ICommodityService.class);
        itemsCommodity = new ArrayList<SelectItem>();

        try {

            if (longShort.isChanged()) {
                longShorts.remove(longShort);
            } else {

                for (LongShortBusiness longShortBusiness : longShorts) {
                    if (longShortBusiness.getId().getCommodityId()
                            .equals(StringUtils.rightPad(this.commodityId.getCommodityId(),
                                    IBarterConstants.COMMODITY_ID_STRING_SIZE))) {
                        List<MessageVO> messages = new ArrayList<MessageVO>();
                        messages.add(new MessageVO(LONG_SHORT_INCLUDED_ERROR, MessageTypeList.ERROR));
                        setMessages(messages);
                        longShort = new LongShortBusiness(new LongShortId());
                        commodityId = new CommodityId();
                        return NOT_NAVIGATE;
                    }
                }

                longShort.setInserted(true);

                if (hasValue(commodityId)) {
                    flgCancelConfirm = true;
                    this.commodityId.setCommodityId(StringUtils.rightPad(this.commodityId.getCommodityId(),
                            IBarterConstants.COMMODITY_ID_STRING_SIZE));
                    this.commodityId.setCountryCd(StringUtils.rightPad(this.commodityId.getCountryCd(), 3));

                    Commodity commodity = commodityService.findById(new Commodity(this.commodityId));

                    for (SelectItem country : listCountry) {
                        if (country.getValue().equals(this.commodityId.getCountryCd())) {
                            longShort.setDescCountry(country.getLabel());
                            break;
                        }
                    }

                    longShort.getId().setCommodityId(commodity.getId().getCommodityId());
                    longShort.getId().setCountryCd(commodity.getId().getCountryCd());
                    longShort.setName(commodity.getDescCommodity());

                } else {
                    longShort.setId(null);
                    longShort.setName(null);
                }
            }

            longShorts.add(longShort);

            initForm();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Register/Editing a LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String saveLongShort() {

        ILongShortService longShortService = getService(ILongShortService.class);

        try {
            longShortService.save(getLongShorts(), getLongShort());

            if (longShortService.isOk()) {
                initForm();
                initializeLists();

                this.setMessages(longShortService.getMessages());
            } else {
                final List<MessageVO> messages = new ArrayList<MessageVO>(longShortService.getMessages());
                for (final MessageVO message : messages) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        initializeLists();
                        longShortService.getMessages().clear();
                        longShort.setChanged(false);
                        loadLongShort(longShortService, longShort);
                        break;
                    }
                }
                this.setMessages(messages);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Cancel the registration of a new LongShort
     *
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String cancelLongShort() {

        initForm();
        initializeLists();
        setFlgKgLimitation(false);
        flgCancelConfirm = false;
        itemsCommodity = new ArrayList<SelectItem>();

        return NOT_NAVIGATE;
    }

    /**
     * Initializes the page clears all objects.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void initForm() {

        ILongShortService longShortService = getService(ILongShortService.class);

        try {

            this.longShort = new LongShortBusiness(new LongShortId());
            this.filter = new LongShortFilter();
            this.positionLongShortFilter = new PositionLongShortFilter();
            this.commodityId = new CommodityId();
            this.listCommodityAvaliable = new ArrayList<SelectItem>();
            loadCountriesAvaliable();
            showGeneralTab();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        /*
         * Informa que a tela esta em modo de inclusao.
         */
        setNewer(true);
        setDetail(false);
        setFlgTabHistory(true);

        /*
         * Obter mensagens da camada de negocio.
         */
        this.setMessages(longShortService);
    }

    /**
     * Initializes the page lists.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void initializeLists() {

        ILongShortService longShortService = getService(ILongShortService.class);

        try {
            this.longShorts = longShortService.getAll();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * @param longShortService
     * @param longShort
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadLongShort(ILongShortService longShortService, LongShortBusiness longShort) {

        if (longShort.isUnmodified()) {
            this.longShort = new LongShortBusiness(longShortService.findByIdWithHistory(longShort));
            this.longShort.setChanged(true);
        }

        if (hasValue(longShort.getId())) {
            this.commodityId.setCommodityId(this.longShort.getId().getCommodityId().trim());
            this.commodityId.setCountryCd(this.longShort.getId().getCountryCd());
        }
    }

    /**
     * Load posisition Long Short.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void loadPositionLongShort() {

        listPositionLongShort = new ArrayList<SelectItem>();
        for (LongShortPositionList positionList : LongShortPositionList.values()) {
            listPositionLongShort.add(new SelectItem(positionList, positionList.getDescPosition()));
        }
    }

    /**
     * Build dynamic fields for view position Long/Short
     *
     * @param formId form id (xhtml)
     * @param dynamicPanelId dynamic panel id (xhtml)
     * @return {@link List} of {@link MessageVO} containing the validation messages of services
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private List<MessageVO> buildDynamicFields(String formId, String dynamicPanelId) {

        List<MessageVO> messages = new ArrayList<MessageVO>();

        ILongShortService longShortService = getService(ILongShortService.class);
        ISimulationService simulationService = getService(ISimulationService.class);
        ITradingContractService tradingContractService = getService(ITradingContractService.class);
        ILongShortCropService longShortCropService = getService(ILongShortCropService.class);

        List<PositionLongShortBusiness> longPositionList = null;
        Map<String, List<PositionLongShortBusiness>> mapLongPositionList = null;
        BigDecimal longVolumeTotal = BigDecimal.ZERO;

        List<PositionLongShortBusiness> shortPositionList = null;
        Map<String, List<PositionLongShortBusiness>> mapShortPositionList = null;
        BigDecimal shortVolumeTotal = BigDecimal.ZERO;

        try {

            String paddedCommodityId = StringUtils.rightPad(positionLongShortFilter.getCommodityId(),
                    IBarterConstants.COMMODITY_ID_STRING_SIZE);
            positionLongShortFilter.setCommodityId(paddedCommodityId);

            LongShortId pk = new LongShortId();

            pk.setCommodityId(positionLongShortFilter.getCommodityId());
            pk.setCountryCd(positionLongShortFilter.getCountryCd());
            LongShort longShortResult = longShortService.findById(new LongShort(pk));

            if ( ! longShortService.isOk() ){
                messages.addAll( longShortService.getMessages() );
                return messages ;
            }

            LongShortCrop longShortCrop = new LongShortCrop();
            longShortCrop.setId(cropId);
            longShortCrop = longShortCropService.findById(longShortCrop);

            if ( ! longShortCropService.isOk() ){
                messages.addAll( longShortCropService.getMessages() );
                return messages ;
            }

            positionLongShortFilter.setDateFrom(longShortCrop.getDateFrom());
            positionLongShortFilter.setDateTo(longShortCrop.getDateTo());

            LongShortBalance balance = longShortService.getByLongShortAndCrop(longShortResult,longShortCrop);

            fillPositionLongShort(balance);

            UIPanel dynaPanel = getDynamicPanelByFormIdAndPanelId(formId, dynamicPanelId);
            setDynamicPanel(dynaPanel);

            if (dynaPanel != null && dynaPanel.getChildren() != null) {
                dynaPanel.getChildren().clear();
            }

            if (hasValue(positionLongShortFilter.getPosition())) {

                if (LongShortPositionList.LONG.equals(positionLongShortFilter.getPosition())) {

                    longPositionList = simulationService.search(positionLongShortFilter);
                    mapLongPositionList = longShortService.groupByCity(longPositionList);
                    longVolumeTotal = longShortService.sumVolumeTotalPositionLongShort(longPositionList);
                    buildViewConsumptionLongShort(dynaPanel, mapLongPositionList, longVolumeTotal,
                            LongShortPositionList.LONG);
                }

                if (LongShortPositionList.SHORT.equals(positionLongShortFilter.getPosition())) {

                    shortPositionList = tradingContractService.search(positionLongShortFilter);
                    mapShortPositionList = longShortService.groupByCity(shortPositionList);
                    shortVolumeTotal = longShortService.sumVolumeTotalPositionLongShort(shortPositionList);
                    buildViewConsumptionLongShort(dynaPanel, mapShortPositionList, shortVolumeTotal,
                            LongShortPositionList.SHORT);
                }
            } else {

                longPositionList = simulationService.search(positionLongShortFilter);
                mapLongPositionList = longShortService.groupByCity(longPositionList);
                longVolumeTotal = longShortService.sumVolumeTotalPositionLongShort(longPositionList);
                buildViewConsumptionLongShort(dynaPanel, mapLongPositionList, longVolumeTotal,
                        LongShortPositionList.LONG);
                shortPositionList = tradingContractService.search(positionLongShortFilter);
                mapShortPositionList = longShortService.groupByCity(shortPositionList);
                shortVolumeTotal = longShortService.sumVolumeTotalPositionLongShort(shortPositionList);
                buildViewConsumptionLongShort(dynaPanel, mapShortPositionList, shortVolumeTotal,
                        LongShortPositionList.SHORT);
            }

            positionLongShortFilter.setCommodityId(paddedCommodityId.trim());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        if (longPositionList != null) {
            messages.addAll(simulationService.getMessages());
        } else {
            messages.addAll(tradingContractService.getMessages());
        }
        return messages;
    }

    /**
     * Fill position {@link LongShort}
     *
     * @param longShortBalance {@link LongShortBalance}
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void fillPositionLongShort(LongShortBalance longShortBalance) {

        boolean isLongShortBalanceNotNull = longShortBalance != null;

        LongShortPositionList positionList = isLongShortBalanceNotNull ? LongShortPositionList.getByPositionType(longShortBalance.getPositionType()) : null;

        // Corrective Mantis 0276236
        this.currentLimit = (isLongShortBalanceNotNull && longShortBalance.getLongShort().getKgLimitation() != null) ? longShortBalance.getLongShort().getKgLimitation()
                : BigDecimal.ZERO;

        this.currentPosition = (isLongShortBalanceNotNull && longShortBalance.getPositionValue() != null) ? longShortBalance
                .getPositionValue() : BigDecimal.ZERO;

        this.expositionLongShort = (isLongShortBalanceNotNull && longShortBalance.getExposureValue() != null) ? longShortBalance
                .getExposureValue() : BigDecimal.ZERO;

        this.longShortPosition = positionList != null ? positionList.getDescPosition() : "";
    }

    /**
     * Consumption view of LongShort
     *
     * @param mapLongShortPositionList
     * @param volumeTotalLongShort
     * @param dynaPanel
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void buildViewConsumptionLongShort(UIPanel dynaPanel,
                                               Map<String, List<PositionLongShortBusiness>> mapLongShortPositionList, BigDecimal volumeTotalLongShort,
                                               LongShortPositionList position) {

        if (mapLongShortPositionList != null && !mapLongShortPositionList.isEmpty()) {

            NumberConverter numConverter = new NumberConverter();
            numConverter.setLocale(getCurrrentLocale());
            numConverter.setMinFractionDigits(2);
            numConverter.setMaxFractionDigits(2);

            HtmlOutputLabel lblLong = createLabel(dynaPanel, "lblLongShort", position.getDescPosition(), null);
            lblLong.setStyle(STR_STYLE_BOLD_14PX);

            HtmlPanelGrid pnlGeral = createPanelGrid(dynaPanel, "pnlViewConsumptionLongShort", 2);
            pnlGeral.setCellpadding("1");
            pnlGeral.setCellspacing("0");
            pnlGeral.setBorder(0);
            pnlGeral.setWidth(STR_100_PORCENT);

            for (Entry<String, List<PositionLongShortBusiness>> entry : mapLongShortPositionList.entrySet()) {

                createColumn(pnlGeral, STR_50PX);
                javax.faces.component.html.HtmlColumn col2 = createColumn(pnlGeral, STR_920PX);
                HtmlOutputLabel lblLong1 = createLabel(col2, "lblCity", entry.getKey(), null);
                lblLong1.setStyle(STR_STYLE_BOLD_14PX);

                createColumn(pnlGeral, STR_50PX);
                javax.faces.component.html.HtmlColumn col3 = createColumn(pnlGeral, STR_920PX);



/*
                HtmlDataTable dataTable = createRichHtmlDataTable(col3, "tbLongCity", entry.getValue(), "longCity");
                dataTable.setWidth(STR_100_PORCENT);
                HtmlColumn tCol1 = createRichColumn(dataTable,
                    isLongPositionList(position) ? getMessage("long.short.position.label.num.simulation")
                        : getMessage("long.short.position.label.num.contract"), "10%");
                tCol1.setStyle("text-align: center;");
                createLabel(tCol1, "lblNumSimulationOrContract", "#{longCity.numSimulationOrContract}", String.class);
                HtmlColumn tCol2 = createRichColumn(dataTable, getMessage("long.short.position.label.create.date"),
                    "8%");
                tCol2.setStyle("text-align: center;");
                createLabel(tCol2, "lblDataCriacao", "#{longCity.createDate}", Date.class);
                HtmlColumn tCol3 = createRichColumn(dataTable,
                    isLongPositionList(position) ? getMessage("long.short.position.label.customer")
                        : getMessage("long.short.position.label.trading"), "22%");
                createLabel(tCol3, "lblCliente", "#{longCity.descCustomerOrTrading}", String.class);
                HtmlColumn tCol4 = createRichColumn(dataTable, getMessage("long.short.label.city"), "17%");
                createLabel(tCol4, "lblCidade", "#{longCity.descCity}", String.class);
                HtmlColumn tCol5 = createRichColumn(dataTable,
                    isLongPositionList(position) ? getMessage("long.short.position.label.rtv")
                        : getMessage("long.short.position.label.user"), "17%");
                createLabel(tCol5, "lblRTV", "#{longCity.userName}", String.class);
                HtmlColumn tCol6 = createRichColumn(dataTable, getMessage("long.short.position.label.commodities"),
                    "14%");
                createLabel(tCol6, "lblCommodities", "#{longCity.descCommodity}", String.class);
                HtmlColumn tCol7 = createRichColumn(dataTable, getMessage("long.short.position.label.volume"), "12%");
                tCol7.setStyle("text-align: right;");
                HtmlOutputLabel lblVolume = createLabel(tCol7, "lblVolume", "#{longCity.volumeKg}", BigDecimal.class);
*/

                UIDataTable dataTable = createRichHtmlDataTable(col3, "tbLongCity", entry.getValue(), "longCity");

                UIColumn tCol1 = createRichColumn(dataTable,
                        isLongPositionList(position) ? getMessage("long.short.position.label.num.simulation")
                                : getMessage("long.short.position.label.num.contract"), "10%");
                tCol1.setStyle("text-align: center;");
                createLabel(tCol1, "lblNumSimulationOrContract", "#{longCity.numSimulationOrContract}", String.class);
                UIColumn tCol2 = createRichColumn(dataTable, getMessage("long.short.position.label.create.date"),
                        "8%");
                tCol2.setStyle("text-align: center;");
                createLabel(tCol2, "lblDataCriacao", "#{longCity.createDate}", Date.class);
                UIColumn tCol3 = createRichColumn(dataTable,
                        isLongPositionList(position) ? getMessage("long.short.position.label.customer")
                                : getMessage("long.short.position.label.trading"), "22%");
                createLabel(tCol3, "lblCliente", "#{longCity.descCustomerOrTrading}", String.class);
                UIColumn tCol4 = createRichColumn(dataTable, getMessage("long.short.label.city"), "17%");
                createLabel(tCol4, "lblCidade", "#{longCity.descCity}", String.class);
                UIColumn tCol5 = createRichColumn(dataTable,
                        isLongPositionList(position) ? getMessage("long.short.position.label.rtv")
                                : getMessage("long.short.position.label.user"), "17%");
                createLabel(tCol5, "lblRTV", "#{longCity.userName}", String.class);
                UIColumn tCol6 = createRichColumn(dataTable, getMessage("long.short.position.label.commodities"),
                        "14%");
                createLabel(tCol6, "lblCommodities", "#{longCity.descCommodity}", String.class);
                UIColumn tCol7 = createRichColumn(dataTable, getMessage("long.short.position.label.volume"), "12%");
                tCol7.setStyle("text-align: right;");
                HtmlOutputLabel lblVolume = createLabel(tCol7, "lblVolume", "#{longCity.volumeKg}", BigDecimal.class);



                lblVolume.setConverter(numConverter);

                createColumn(pnlGeral, STR_50PX);
                javax.faces.component.html.HtmlColumn col4 = createColumn(pnlGeral, STR_920PX);
            }

            createColumn(pnlGeral, STR_50PX);
            javax.faces.component.html.HtmlColumn col6 = createColumn(pnlGeral, STR_920PX);

            HtmlOutputLabel lblVolumeTotal = createLabel(col6, "volumeTotal", getMessage("long.short.position.label.volume.total"), null);
            lblVolumeTotal.setStyle(STR_STYLE_BOLD_14PX);
            // Corrective Mantis 0276236
            HtmlOutputLabel lblVolumeTotalValue = createLabel(col6, "volumeTotalValue", StringUtils.EMPTY, null);
            lblVolumeTotalValue.setValue(volumeTotalLongShort);
            lblVolumeTotalValue.setConverter(numConverter);
            lblVolumeTotalValue.setStyle(STR_STYLE_BOLD_14PX);
        }
    }

    /**
     * Checks if the position is Long.
     *
     * @param position {@link LongShortPositionList}
     * @return <tt>TRUE</tt> if Long, <tt>FALSE</tt> otherwise.
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private boolean isLongPositionList(LongShortPositionList position) {

        return LongShortPositionList.LONG.equals(position);
    }

    /**
     * Show General Tab
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void showGeneralTab() {

        this.tab = "tabGeneral";
    }

    /**
     * Show History Tab
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void showHistoryTab() {

        this.tab = "tabHistory";
    }

    /**
     * Loads the commodities.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    /*
     * private void loadCommodities() {
     * 
     * ICommodityService commodityService = getService(ICommodityService.class); itemsCommodity = new
     * ArrayList<SelectItem>();
     * 
     * try {
     * 
     * List<Commodity> commodities = commodityService.search(new CommodityFilter());
     * 
     * for (Commodity commodity : commodities) {
     * 
     * itemsCommodity.add(new SelectItem(commodity.getId(), commodity.getDescCommodity())); } } catch (Exception e) {
     * showException(e); } }
     */

    /**
     * Gets the quantity of LongShort history
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public int getQtLongShortHistory() {

        int count = 0;
        if (this.longShort != null && this.longShort.getHistories() != null) {
            count = this.longShort.getHistories().size();
        }
        return count;
    }

    /**
     * Gets the quantity of registers
     *
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public int getQtdLongShorts() {

        int count = 0;
        if (this.longShorts != null) {
            count = this.longShorts.size();
        }
        return count;
    }

    /**
     * @return the tab
     */
    public String getTab() {

        return tab;
    }

    /**
     * @param tab - the tab to set
     */
    public void setTab(String tab) {

        this.tab = tab;
    }

    /**
     * @return the longShort
     */
    public LongShortBusiness getLongShort() {

        return longShort;
    }

    /**
     * @param longShort - the longShort to set
     */
    public void setLongShort(LongShortBusiness longShort) {

        this.longShort = longShort;
    }

    /**
     * @return the filter
     */
    public LongShortFilter getFilter() {

        return filter;
    }

    /**
     * @param filter - the filter to set
     */
    public void setFilter(LongShortFilter filter) {

        this.filter = filter;
    }

    /**
     * @return the positionLongShortFilter
     */
    public PositionLongShortFilter getPositionLongShortFilter() {

        return positionLongShortFilter;
    }

    /**
     * @param positionLongShortFilter - the positionLongShortFilter to set
     */
    public void setPositionLongShortFilter(PositionLongShortFilter positionLongShortFilter) {

        this.positionLongShortFilter = positionLongShortFilter;
    }

    /**
     * @return the currentLimit
     */
    public BigDecimal getCurrentLimit() {

        return currentLimit;
    }

    /**
     * @return the currentPosition
     */
    public BigDecimal getCurrentPosition() {

        return currentPosition;
    }

    /**
     * @return the expositionLongShort
     */
    public BigDecimal getExpositionLongShort() {

        return expositionLongShort;
    }

    /**
     * @return the longShorts
     */
    public List<LongShortBusiness> getLongShorts() {

        return longShorts;
    }

    /**
     * @param longShorts - the longShorts to set
     */
    public void setLongShorts(List<LongShortBusiness> longShorts) {

        this.longShorts = longShorts;
    }

    /**
     * @return the itemsCommodity
     */
    public List<SelectItem> getItemsCommodity() {

        return itemsCommodity;
    }

    /**
     * @param itemsCommodity - the itemsCommodity to set
     */
    public void setItemsCommodity(List<SelectItem> itemsCommodity) {

        this.itemsCommodity = itemsCommodity;
    }

    /**
     * @return the listCountry
     */
    public List<SelectItem> getListCountry() {

        return listCountry;
    }

    /**
     * @param listCountry - the listCountry to set
     */
    public void setListCountry(List<SelectItem> listCountry) {

        this.listCountry = listCountry;
    }

    /**
     * @return the listCity
     */
    public List<SelectItem> getListCity() {

        return listCity;
    }

    /**
     * @param listCity - the listCity to set
     */
    public void setListCity(List<SelectItem> listCity) {

        this.listCity = listCity;
    }

    /**
     * @return the listCountryAvaliable
     */
    public List<SelectItem> getListCountryAvaliable() {

        return listCountryAvaliable;
    }

    /**
     * @param listCountryAvaliable - the listCountryAvaliable to set
     */
    public void setListCountryAvaliable(List<SelectItem> listCountryAvaliable) {

        this.listCountryAvaliable = listCountryAvaliable;
    }

    /**
     * @return the listCommodityAvaliable
     */
    public List<SelectItem> getListCommodityAvaliable() {

        return listCommodityAvaliable;
    }

    /**
     * @param listCommodityAvaliable - the listCommodityAvaliable to set
     */
    public void setListCommodityAvaliable(List<SelectItem> listCommodityAvaliable) {

        this.listCommodityAvaliable = listCommodityAvaliable;
    }

    /**
     * @return the listPositionLongShort
     */
    public List<SelectItem> getListPositionLongShort() {

        loadPositionLongShort();

        return listPositionLongShort;
    }

    /**
     * @param listPositionLongShort - the listPositionLongShort to set
     */
    public void setListPositionLongShort(List<SelectItem> listPositionLongShort) {

        this.listPositionLongShort = listPositionLongShort;
    }

    /**
     * @return the flgKgLimitation
     */
    public boolean isFlgKgLimitation() {

        return flgKgLimitation;
    }

    /**
     * @param flgKgLimitation - the flgKgLimitation to set
     */
    public void setFlgKgLimitation(boolean flgKgLimitation) {

        this.flgKgLimitation = flgKgLimitation;
    }

    /**
     * @return the commodityId
     */
    public CommodityId getCommodityId() {

        return commodityId;
    }

    /**
     * @param commodityId - the commodityId to set
     */
    public void setCommodityId(CommodityId commodityId) {

        this.commodityId = commodityId;
    }

    /**
     * @return the flgTabHistory
     */
    public boolean isFlgTabHistory() {

        return flgTabHistory;
    }

    /**
     * @param flgTabHistory - the flgTabHistory to set
     */
    public void setFlgTabHistory(boolean flgTabHistory) {

        this.flgTabHistory = flgTabHistory;
    }

    /**
     * @return the flgCancelConfirm
     */
    public boolean isFlgCancelConfirm() {

        return flgCancelConfirm;
    }

    /**
     * @param flgCancelConfirm - the flgCancelConfirm to set
     */
    public void setFlgCancelConfirm(boolean flgCancelConfirm) {

        this.flgCancelConfirm = flgCancelConfirm;
    }

    /**
     * @return the sexoId
     */
    public String getSexoId() {

        return sexoId;
    }

    /**
     * @param sexoId - the sexoId to set
     */
    public void setSexoId(String sexoId) {

        this.sexoId = sexoId;
    }

    /**
     * @return the longShortPosition
     */
    public String getLongShortPosition() {

        return longShortPosition;
    }

    public List<SelectItem> getListCrops() {
        return listCrops;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }
}
