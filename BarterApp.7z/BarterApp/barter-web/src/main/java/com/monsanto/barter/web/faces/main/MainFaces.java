package com.monsanto.barter.web.faces.main;

import java.io.IOException;
import java.util.Locale;

import javax.faces.context.FacesContext;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.list.PermissionList;

/**
 * Faces Bean that controls the main menu and handles the application-wide features.
 * 
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * @since 07/12/2011
 */
public class MainFaces extends BaseJSF {

    /**
     * Serial ID
     */
    private static final long serialVersionUID = 5358921270182389900L;

    private static final Locale LOCALE_ENGLISH = Locale.ENGLISH;

    private static final Locale LOCALE_SPANISH = new Locale("es");

    private static final Locale LOCALE_PORTUGUESE = new Locale("pt", "br");

    /**
     * Default constructor class
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public MainFaces() {

        super();
    }

    /**
     * Set the Locale to be used in localizing the response being created for this view.
     * 
     * @param locale The new localization Locale
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    private void setChangeLocale(final Locale locale) {


        FacesContext context = FacesContext.getCurrentInstance();

        context.getViewRoot().setLocale(locale);
        context.getApplication().setDefaultLocale(locale);
    }

    /**
     * Sets the language as english
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String setEnglishLanguage() {

        setChangeLocale(LOCALE_ENGLISH);
        return NOT_NAVIGATE;
    }

    /**
     * Sets the language as spanish
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String setSpanishLanguage() {

        setChangeLocale(LOCALE_SPANISH);
        return NOT_NAVIGATE;
    }

    /**
     * Sets the language as portuguese
     * 
     * @return Outcome of navigation
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public String setPortugueseLanguage() {

        setChangeLocale(LOCALE_PORTUGUESE);
        return NOT_NAVIGATE;
    }

    public void exit() throws IOException {

        logout();
        FacesContext.getCurrentInstance().getExternalContext().redirect(getProperty("url.login.page-"+getCountry().getCountryISOCd()));
    }

    /**
     * Checks if the authenticated user has access permission for the module administration
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessAdministration() {

        return isCanAccessGroup() || isCanAccessUser() || isCanAccessFormalization();
    }

    /**
     * Checks if the authenticated user has access permission for the module group
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessGroup() {

        return isCanAccessGroupSearch() || isCanAccessGroupNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function groupSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessGroupSearch() {

        return access(PermissionList.SEARCH_GROUP_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function groupNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessGroupNew() {

        return access(PermissionList.NEW_GROUP_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the module group
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessUser() {

        return isCanAccessUserSearch() || isCanAccessUserNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function userSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessUserSearch() {

        return access(PermissionList.SEARCH_USER_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function userNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessUserNew() {

        return access(PermissionList.NEW_USER_SCREEN_PERMISSION_CD.getPermissionCd());
    }
    
    /**
     * Check if the authenticated user has access permission for the module Term of Formalization
     * 
     * @return TRUE is you have permission, FALSE otherwise
     * @author Felipe Oliveira Gutierrez (felipe.gutierrez@cpmbraxis.com)
     */
    public boolean isCanAccessFormalization() {

        return access(PermissionList.FORMALIZATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the module campaign
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCampaign() {

        return isCanAccessCampaignBarter() || isCanAccessCommunication();
    }

    /**
     * Checks if the authenticated user has access permission for the module campaign barter
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCampaignBarter() {

        return isCanAccessCampaignSearch() || isCanAccessCampaignNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function campaignSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCampaignSearch() {

        return access(PermissionList.SEARCH_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function campaignNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCampaignNew() {

        return access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the module communication
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCommunication() {

        return isCanAccessCommunicationSearch() || isCanAccessCommunicationNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function communicationSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCommunicationSearch() {

        return access(PermissionList.SEARCH_COMMUNICATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function communicationNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessCommunicationNew() {

        return access(PermissionList.NEW_COMMUNICATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the module orders
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessOrders() {

        return isCanAccesssSimulation();
    }

    /**
     * Checks if the authenticated user has access permission for the module simulation
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccesssSimulation() {

        return isCanAccessSimulationSearch() || isCanAccessSimulationNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function simulationSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessSimulationSearch() {

        return access(PermissionList.SEARCH_SIMULATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function simulationNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessSimulationNew() {
        
        return access(PermissionList.REGISTER_NEW_SIMULATION_FCPA_SCREEN_PERMISSION_CD.getPermissionCd());
    }
    
    /**
     * Checks if the authenticated user has access permission for the function simulationExistingSale
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessSimulationExistingSale() {
        
        return access(PermissionList.REGISTER_EXISTING_SIMULATION_FCPA_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the module longShort
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessLongShort() {

        return access(PermissionList.LONG_SHORT_SCREEN_PERMISSION_CD.getPermissionCd());
    }
    
    /**
     * Checks if the authenticated user has access permission for the function of search and new longShort
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessViewLongShortSearch() {

        return access(PermissionList.LONG_SHORT_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function of longShort consumption
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public boolean isCanAccessCrops() {

        return access(PermissionList.LONG_SHORT_CROP_SCREEN_PERMISSION_CD.getPermissionCd());
    }


    public boolean isCanAccessViewLongShortConsumption() {

        return access(PermissionList.LONG_SHORT_VIEW_CONSUMPTION_SCREEN_PERMISSION_CD.getPermissionCd());
    }


    /**
     * Checks if the authenticated user has access permission for the module trading contract
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessTradingContract() {
        
        return isCanAccessTradingContractSearch() || isCanAccessTradingContractNew();
    }

    /**
     * Checks if the authenticated user has access permission for the function tradingContractSearch
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessTradingContractSearch() {

        return access(PermissionList.SEARCH_TRADING_CONTRACT_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Checks if the authenticated user has access permission for the function tradingContractNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessTradingContractNew() {
        
        return access(PermissionList.NEW_TRADING_CONTRACT_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    public boolean isCanAccessSimulationList(){
        return access(PermissionList.SEARCH_LIST_SIMULATION_SCREEN_PERMISSION_CD.getPermissionCd());
    }




    public boolean isCanAccessWhitepaper(){
        return access(PermissionList.CREATE_WHITEPAPER_SCREEN_PERMISSION_CD.getPermissionCd());
    }
    public boolean isCanAccessWhitepaperNew(){
        return access(PermissionList.CREATE_WHITEPAPER_SCREEN_PERMISSION_CD.getPermissionCd());
    }
    public boolean isCanAccessWhitepaperSearch(){
        return access(PermissionList.SEARCH_LIST_WHITEPAPER_SCREEN_PERMISSION_CD.getPermissionCd());
    }
}