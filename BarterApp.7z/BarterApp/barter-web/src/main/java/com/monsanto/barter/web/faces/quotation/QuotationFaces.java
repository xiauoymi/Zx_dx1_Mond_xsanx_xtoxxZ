package com.monsanto.barter.web.faces.quotation;

import java.util.List;

import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.filter.QuotationFilter;
import com.monsanto.barter.business.service.IQuotationService;
import org.apache.log4j.Logger;


import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * Class responsible for controlling the pop-up of quotes.
 * 
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 09/01/2012
 */
@ManagedBean(name="quotationFaces")
@SessionScoped
public class QuotationFaces extends BaseJSF {

    private static final Logger LOG = Logger.getLogger(QuotationFaces.class);

    private static final long serialVersionUID = 1566722162960498594L;

    // List of quotes
    private List<QuotationBusiness> quotationList;

    // Objects
    private QuotationBusiness quotationBusiness;

    private QuotationFilter quotationFilter;

    /**
     * Default constructor.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public QuotationFaces() {

        super();
        quotationBusiness = new QuotationBusiness();
    }

    /**
     * Method responsible for calling the search method of quotes from the business layer.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void search() {

        try {
            if (super.hasValue(this.quotationFilter)) {
                IQuotationService quotationService = getService(IQuotationService.class);
                this.quotationList = quotationService.searchBusinessObjects(this.quotationFilter);
                if (!quotationService.isOk()) {
                    this.setMessages(quotationService.getMessages());
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method returns number of records in the list of quotes
     * 
     * @return List size.
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public int getQtdQuotes() {

        int count = 0;
        if (this.quotationList != null) {
            count = this.quotationList.size();
        }
        return count;
    }

    /**
     * @return the quotationList
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public List<QuotationBusiness> getQuotes() {

        return quotationList;
    }

    /**
     * @return the quotationFilter
     */
    public QuotationFilter getQuotationFilter() {

        return quotationFilter;
    }

    /**
     * @param quotationFilter - the quotationFilter to set
     */
    public void setQuotationFilter(QuotationFilter quotationFilter) {

        this.quotationFilter = quotationFilter;
    }

    /**
     * @return the quotationBusiness
     */
    public QuotationBusiness getQuotationBusiness() {

        return quotationBusiness;
    }

    /**
     * @param quotationBusiness - the quotationBusiness to set
     */
    public void setQuotationBusiness(QuotationBusiness quotationBusiness) {

        this.quotationBusiness = quotationBusiness;
    }
}
