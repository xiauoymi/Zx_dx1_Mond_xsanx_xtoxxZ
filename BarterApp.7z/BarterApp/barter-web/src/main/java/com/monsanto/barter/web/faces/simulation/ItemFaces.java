package com.monsanto.barter.web.faces.simulation;

import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.ProductMaterialBusiness;
import com.monsanto.barter.business.entity.business.SalesPriceSimulate;
import com.monsanto.barter.business.entity.filter.CampaignBrandFilter;
import com.monsanto.barter.business.entity.filter.CampaignDivisionUnitFilter;
import com.monsanto.barter.business.entity.filter.DivisionFilter;
import com.monsanto.barter.business.entity.filter.ProductFilter;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.DivisionId;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.business.webservice.service.IWSSalesPriceSimulateService;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang.StringUtils;

// import javax.faces.event.ActionEvent;

/**
 * Class responsible for controlling the pop-up of include items in simulation.
 *
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 28/01/2012
 */


@ManagedBean(name = "itemFaces")
@SessionScoped
public class ItemFaces extends BaseJSF {

    private static final long serialVersionUID = -5919273713091731902L;

    // Items for select
    private List<SelectItem> divisionList;

    private List<SelectItem> brandList;

    private List<SelectItem> productList;

    private SimulationItem simulationItem;

    private Simulation simulation;

    private Character languageLoggedInUser;

    private boolean divisionChemicals;

    private boolean edit;

    private List<MessageVO> errorMessages;

    private List<CampaignBrand> divisions;


    /**
     * Constructor default.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public ItemFaces() {

        super();
        errorMessages = new ArrayList<MessageVO>();
        this.divisionList = new ArrayList<SelectItem>();
        this.brandList = new ArrayList<SelectItem>();
        this.productList = new ArrayList<SelectItem>();
        this.initializeSimulationItem();

        this.languageLoggedInUser = SecurityUtil.getLoggedInUser().getLanguageCd();
    }

    /**
     * Method responsible for init of simulationItem variable.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public final void initializeSimulationItem() {

        this.simulationItem = new SimulationItem();
        this.simulationItem.setDivision(new Division(new DivisionId()));
        this.simulationItem.getDivision().getId().setLanguageCd(this.languageLoggedInUser);
        this.simulationItem.setProduct(new Product());
        setRedist();
    }

    /**
     * Load the list of divisions to component 'drpDivision'
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void loadDivisions() {

        this.divisionChemicals = false;
        this.initializeSimulationItem();

        this.divisionList = new ArrayList<SelectItem>();

        IDivisionService divisionService = getService((IDivisionService.class));

        if(isBarterParaguay()) {
            searchDivisions();


            List<Division> divisionItems = new ArrayList<Division>();

            for (CampaignBrand campaignBrand : divisions) {
                Division division = new Division();
                DivisionId divisionId = new DivisionId();
                divisionId.setLanguageCd(languageLoggedInUser);

                divisionId.setDivisionCd(campaignBrand.getDivisionCd());
                division.setId(divisionId);
                Division divisionDesc = divisionService.findById(division);

                if (!divisionItems.contains(divisionDesc)) {
                    divisionItems.add(divisionDesc);
                }
            }

            for (Division divisionItem : divisionItems) {
                this.divisionList.add(new SelectItem(divisionItem.getId().getDivisionCd(),
                        divisionItem.getDesc()));
            }
        } else {

            DivisionFilter divisionFilter = new DivisionFilter();
            divisionFilter.getDivision().setId(new DivisionId());
            divisionFilter.getDivision().getId().setLanguageCd(this.languageLoggedInUser);

            List<Division> divisions = divisionService.search(divisionFilter);

            for (final Division division : divisions) {
                this.divisionList.add(new SelectItem(division.getId().getDivisionCd(), division.getDesc()));
            }
        }

        sortSelectItem(this.divisionList);
    }

    /**
     * Search the divisions filtering by Campaign
     */
    private void searchDivisions() {

        ICampaignBrandService campaignBrandService = getService(ICampaignBrandService.class);
        CampaignBrandFilter campaignBrandFilter = new CampaignBrandFilter();

        campaignBrandFilter.setCampaignBrand(new CampaignBrand());
        campaignBrandFilter.getCampaignBrand().setCampaign(simulation.getCampaign());

        divisions = campaignBrandService.search(campaignBrandFilter);
    }

    /**
     * Load the division of items previously selected
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void loadDivision() {

        IDivisionService divisionService = getService(IDivisionService.class);
        this.divisionChemicals = false;

        this.divisionList = new ArrayList<SelectItem>();

        if (!hasValue(divisions)) {
            searchDivisions();
        }

        Division division = divisionService.findById(this.simulationItem.getDivision());
        String divisionCd = division.getId().getDivisionCd();
        this.divisionList.add(new SelectItem(divisionCd, division.getDesc()));

        this.loadBrands(divisionCd);
        if (IBarterConstants.DIVISION_CHEMICALS.equals(divisionCd)) {
            this.divisionChemicals = true;
        }
        this.productList.clear();
    }

    /**
     * Load the list of brands to component 'drpBrand'
     *
     * @param divisionCd - Code of division
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadBrands(String divisionCd) {

        IProductService productService = getService(IProductService.class);
        this.brandList = new ArrayList<SelectItem>();

        ProductFilter productFilter = new ProductFilter();
        productFilter.getProduct().setDivisionCd(divisionCd);

        List<String> brands = productService.searchDistinct(productFilter);
        HashSet<String> brandsFiltered = new HashSet<String>();

        if(isBarterParaguay()) {
            //Adds campaign Brands
            for (int i = 0; i < brands.size(); i++) {
                String brand = brands.get(i);
                for (CampaignBrand campaignBrand : divisions) {
                    if (campaignBrand.getBrandCd().equals(brand)) {
                        brandsFiltered.add(brand);
                    }
                }
            }
            for (String brand : brandsFiltered){
                this.brandList.add(new SelectItem(brand));
            }
        } else {
            for (String brand : brands){
                this.brandList.add(new SelectItem(brand));
            }
        }

        sortSelectItem(this.brandList);
    }

    /**
     * Load the list of products to component 'drpProduct'
     *
     * @param brandCd - Code of brand
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void loadProducts(final String brandCd) {

        final IProductService productService = getService(IProductService.class);
        this.productList = new ArrayList<SelectItem>();

        final ProductFilter productFilter = new ProductFilter();
        productFilter.getProduct().setDivisionCd(simulationItem.getDivision().getId().getDivisionCd());
        productFilter.getProduct().setBrandCd(brandCd);

        if (isBarterBrazil()){
            final List<Product> products = productService.search(productFilter);

            for (final Product product : products) {
                this.productList.add(new SelectItem(product.getMaterialNbr().trim(), product.getEnteredMaterialCd()));
            }
        } else {
            final List<ProductMaterialBusiness> productMaterials = productService.searchProductMaterial(productFilter);

            for (final ProductMaterialBusiness productMaterial : productMaterials) {
                this.productList.add(new SelectItem(productMaterial.getMaterialNbr().trim(),
                        productMaterial.getMaterialDescription()));
            }
        }

        sortSelectItem(this.productList);
    }

    /**
     * Change event of the drop down list of division.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void drpDivisionChanged() {

        errorMessages.clear();
        final String divisionCd = this.simulationItem.getDivision().getId().getDivisionCd();
        this.simulationItem.getProduct().setBrandCd(null);
        this.simulationItem.getProduct().setMaterialNbr(null);
        this.simulationItem.getProduct().setWeightUnit(null);
        this.simulationItem.setItemAmount(null);
        this.simulationItem.setFinalPrice(null);
        this.simulationItem.setTotalAmount(null);

        final boolean oldChemicalsFlag = divisionChemicals;
        this.divisionChemicals = false;

        if (super.hasValue(divisionCd)) {
            this.loadBrands(divisionCd);
            if (IBarterConstants.DIVISION_CHEMICALS.equals(divisionCd)) {
                this.divisionChemicals = true;
            }
        } else {
            this.brandList.clear();
        }
        this.productList.clear();

        if (oldChemicalsFlag != divisionChemicals) {
            if (divisionChemicals) {
                simulationItem.setCashPct(null);
                simulationItem.setPenPct(null);
                simulationItem.setGuPct(null);
            } else {
                simulationItem.setLvPct(null);
            }
        }

    }

    /**
     * Change event of the drop down list of brand.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void
    drpBrandChanged() {

        errorMessages.clear();
        final String brandCd = this.simulationItem.getProduct().getBrandCd();
        this.simulationItem.getProduct().setMaterialNbr(null);
        this.simulationItem.getProduct().setWeightUnit(null);
        this.simulationItem.setItemAmount(null);
        this.simulationItem.setFinalPrice(null);
        this.simulationItem.setTotalAmount(null);

        if (super.hasValue(brandCd)) {
            this.loadProducts(brandCd);
        } else {
            this.productList.clear();
        }
    }

    /**
     * Change event of the drop down list of product.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void drpProductChanged() throws Exception {

        final String materialNbr = this.simulationItem.getProduct().getMaterialNbr();
        errorMessages.clear();
        if (super.hasValue(materialNbr)) {
            final IProductService productService = getService(IProductService.class);
            final ISimulationItemService simulationItemService = getService(ISimulationItemService.class);
            final IWSSalesPriceSimulateService priceSimulationService = getService(IWSSalesPriceSimulateService.class);

            final Product product = new Product();
            product.setMaterialNbr(StringUtils.rightPad(materialNbr, IBarterConstants.MATERIAL_NBR_STRING_SIZE));
            simulationItem.setProduct(productService.findById(product));
            this.simulationItem.setSimulation(this.simulation);

            //For Paraguay, the price and weight unit should be obtained directly from SAP
            if (isBarterParaguay()) {
                try {
                    SalesPriceSimulate salesPriceSimulate = priceSimulationService.getProductInformation(simulation, simulationItem);

                    if (hasValue(errorMessages)) {
                        errorMessages.addAll(salesPriceSimulate.getErrors());
                    }

                    if (hasValue(salesPriceSimulate.getProductPrice())
                            && salesPriceSimulate.getProductPrice().compareTo(BigDecimal.ZERO) != 0) {
                        simulationItem.setItemAmount(salesPriceSimulate.getProductPrice());
                    }
                    else {
                        simulationItem.setItemAmount(null);
                        errorMessages.add(new MessageVO("simulation.item.chemical.price.not.found", MessageTypeList.ERROR));
                    }

                    if (hasValue(salesPriceSimulate.getWeightUnit())) {
                        simulationItem.getProduct().setWeightUnit(salesPriceSimulate.getWeightUnit());
                    } else {
                        simulationItem.getProduct().setWeightUnit(null);
                        errorMessages.add(new MessageVO("simulation.item.chemical.price.from.sap.weightunit.not.found", MessageTypeList.ERROR));
                    }
                } catch (Exception e){

                }
            } else {
                this.simulationItem.setItemAmount(simulationItemService.calculateItemAmount(this.simulationItem));
            }

            this.simulationItem.setFinalPrice(simulationItemService.calculateFinalPrice(this.simulationItem));
            this.simulationItem.setTotalAmount(simulationItemService.calculateTotalAmount(this.simulationItem));

            errorMessages.addAll(simulationItemService.getMessages());
        } else {
            this.simulationItem.setItemAmount(null);
            simulationItem.getProduct().setWeightUnit(null);
            this.simulationItem.setFinalPrice(null);
            this.simulationItem.setTotalAmount(null);
        }
    }

    /**
     * Event of change input text of quantity.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void txtQuantityChanged() {

        ISimulationItemService simulationItemService = getService(ISimulationItemService.class);
        this.simulationItem.setTotalAmount(simulationItemService.calculateTotalAmount(this.simulationItem));
    }

    /**
     * Event of change input text of percents.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void txtPercentsChanged() {

        ISimulationItemService simulationItemService = getService(ISimulationItemService.class);
        if(isBarterParaguay()){
            boolean noMessage = true;
            for(MessageVO messageVO:errorMessages){
                if(messageVO.getId().equals("simulation.item.discount.above.max.discount")){
                    noMessage = false;
                }
            }
            if(simulation.getCampaign().getMaxDiscountIncentive()!=null &&
                simulationItem.getSumOfDiscounts().compareTo(simulation.getCampaign().getMaxDiscountIncentive()) > 0){
                if(noMessage) {
                    errorMessages.add(new MessageVO("simulation.item.discount.above.max.discount", MessageTypeList.ERROR));
                }
            } else {
                if(!noMessage) {
                    for(MessageVO messageVO:errorMessages){
                        if(messageVO.getId().equals("simulation.item.discount.above.max.discount")){
                            errorMessages.remove(messageVO);
                        }
                    }
                }
            }
        } else if(isBarterBrazil()) {
            errorMessages.clear();
        }

        this.simulationItem.setFinalPrice(simulationItemService.calculateFinalPrice(this.simulationItem));
        this.simulationItem.setTotalAmount(simulationItemService.calculateTotalAmount(this.simulationItem));
    }




    /*
     * (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseJSF#getMessages()
     */
    public String getMessages() {

        super.setMessages(errorMessages);
        return super.getMessages();
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.architecture.web.jsf.BaseJSF#setMessages(java.util.List)
     */
    @Override
    public void setMessages(final List<MessageVO> messages) {

        errorMessages.addAll(messages);
    }

    /**
     * Clear the message list.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void clearMessages() {

        errorMessages.clear();
    }

    /**
     * Verifies if there's an value error on the item popup.
     *
     * @return true if there's no value error on the popup, false otherwise
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public boolean isOk() {

        return (simulationItem.getItemAmount() != null && !BigDecimal.ZERO.equals(simulationItem.getItemAmount())) && errorMessages.isEmpty();

    }

    /**
     * @return the divisionList
     */
    public List<SelectItem> getDivisionList() {

        return divisionList;
    }

    /**
     * @param divisionList - the divisionList to set
     */
    public void setDivisionList(List<SelectItem> divisionList) {

        this.divisionList = divisionList;
    }

    /**
     * @return the brandList
     */
    public List<SelectItem> getBrandList() {

        return brandList;
    }

    /**
     * @param brandList - the brandList to set
     */
    public void setBrandList(List<SelectItem> brandList) {

        this.brandList = brandList;
    }

    /**
     * @return the productList
     */
    public List<SelectItem> getProductList() {

        return productList;
    }

    /**
     * @param productList - the productList to set
     */
    public void setProductList(List<SelectItem> productList) {

        this.productList = productList;
    }

    /**
     * @return the simulationItem
     */
    public SimulationItem getSimulationItem() {

        return simulationItem;
    }

    /**
     * @param simulationItem - the simulationItem to set
     */
    public void setSimulationItem(SimulationItem simulationItem) {

        this.simulationItem = simulationItem;
        setRedist();
    }

    private void setRedist(){

        if ( isBarterParaguay() && simulationItem != null & simulation != null ){
            simulationItem.setRedistPct( simulation.getCampaign().getIncentive());
        }

    }

    /**
     * @return the divisionChemicals
     */
    public boolean isDivisionChemicals() {

        return divisionChemicals;
    }

    /**
     * @return the edit
     */
    public boolean isEdit() {

        return this.edit;
    }

    /**
     * @param edit - the edit to set
     */
    public void setEdit(boolean edit) {

        this.edit = edit;
    }

    /**
     * @return the simulation
     */
    public Simulation getSimulation() {

        return this.simulation;
    }

    /**
     * @param simulation - the simulation to set
     */
    public void setSimulation(Simulation simulation) {

        this.simulation = simulation;
        setRedist();
    }

    public List<CampaignBrand> getDivisions() {
        return divisions;
    }

    public void setDivisions(List<CampaignBrand> divisions) {
        this.divisions = divisions;
    }
}