package com.monsanto.barter.web.faces.simulation;


import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.service.AttachmentService;
import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseReportJSF;
import com.monsanto.barter.business.entity.business.*;
import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.*;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.business.webservice.service.IWSSalesPriceSimulateService;
import com.monsanto.barter.web.faces.customer.CustomerFaces;
import com.monsanto.barter.web.faces.fileupload.FileUpload;
import com.monsanto.barter.web.faces.quotation.QuotationFaces;
import com.monsanto.barter.web.faces.tradingcontract.TradingContractFaces;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Workbook;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.richfaces.component.UICalendar;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.ArrayDataModel;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.trim;


/**
 * Class responsible for controlling the pages of Simulation feature.
 *
 * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
 * @since 13/12/2011
 */
@ManagedBean(name = "simulationFaces")
@SessionScoped
public class SimulationFaces extends BaseReportJSF {

    protected static final Logger LOG = Logger.getLogger(SimulationFaces.class);
    private static final long serialVersionUID = -5151970594569644110L;
    private static final String ITEM_FACES_NAME = "itemFaces";
    private static final String USD_CD = "USD";

    // SIMULATION ATTRIBUTES
    private final com.monsanto.barter.architecture.security.data.User loggedUser;
    private boolean renderRtv;
    private List<SelectItem> campaignList;
    private List<InvoiceSimulation> invoiceList;

    // SIMULATION SEARCH ATTRIBUTES
    private boolean commodity;
    private SimulationFilter filter;
    private CustomerFilter customerFilter;
    private UserFilter userFilter;
    private List<SelectItem> statusList;
    private List<SimulationBusiness> simulationList;
    private SimulationBusiness simulationSelected;
    private Simulation simulation = new Simulation();
    private FormalizationTermBusiness formalizationTermBusiness;
    private FormalizationTerm template;

    // SIMULATION REGISTER ATTRIBUTES
    private boolean fromContract;
    private List<SelectItem> quoteTypeList;
    private List<SelectItem> fcpaList;
    private List<SelectItem> mktCampaignList;
    private List<SelectItem> barterTypeList;
    private List<SelectItem> cropList;
    private List<SelectItem> tradingList;
    private List<SelectItem> currencyList;
    private List<SelectItem> paymentConditionList;
    private List<SelectItem> commodityList;
    private List<SelectItem> incotermsList;
    private List<SelectItem> regionList;
    private List<SelectItem> cityList;
    private List<SelectItem> itemsSimulation;
    private List<SelectItem> disapprovalReasonList;
    private List<SelectItem> returnReasonList;
    private QuotationBusiness quotationBusiness;
    private SimulationItem simulationItem;
    private BigDecimal usdRate;
    private UnitMeasurementList unitMeasurement;
    private String selectedCustomer;
    private String selectedContract;
    private String mktCampaignDesc;
    private String tradingDesc;
    private String commodityDesc;
    private Integer codeOthersDisapprovalReason = DisapprovalReasonList.OTHERS.getCode();
    private Integer codeOthersReturnReason = ReturnReasonList.OTHERS.getCode();
    private List<SimulationItem> deletedItems;
    private List<MessageVO> sendApprovalMessages;
    private boolean newSale;
    private boolean reopen;
    private boolean quoteFieldsDisabled;
    private boolean renderDiffDelivLocationCheckBox;
    private boolean renderDiffDelivLocationField;
    private boolean renderIncentive;
    private boolean renderContractFields;
    private boolean renderUsdRate;
    private boolean renderedPanelQuotation;
    private boolean renderedPanelItem;
    private boolean renderedPanelTermsFormalization;
    private boolean divisionChemicals;
    private boolean renderPanelSignature;
    private boolean renderPopupFormalizationPrint;
    private boolean renderPrintButton;
    private boolean renderApproveButton;
    private boolean renderVerifySaleOrderButton;
    private boolean renderReturnButton;
    private boolean renderDisapproveButton;
    private boolean renderedTxtMotive;
    private boolean barterTypeTerms;
    private boolean barterTypeWithExistingContract;
    private boolean barterTypeMonsantoManagesContract;
    private boolean barterTypeGrainAvailable;
    private boolean contractSelected;
    private OutputStream streamPDFFile;
    private List<FileUpload> fileUploadHandlers = new ArrayList<FileUpload>();
    private List<BarAttachment> attachments = new ArrayList<BarAttachment>();
    private BarAttachment attachmentSelected;
    private boolean filesAttachedSuccessfully;
    private boolean renderAttachmentPopup;

    private BarterContract simulationContractSelected;

    private List<BarterContract> contractsToDelete;

    private List<FileUpload> contractFileUploadHandlers = new ArrayList<FileUpload>();

    private List<BarContractAttachment> contractAttachments;

    private BarContractAttachment contractAttachmentSelected;

    private boolean simulationSearchList;

    private BigDecimal totalBarterTons;

    private BigDecimal totalBarterAmount;

    private List<Long> editContractsIds;

    private DataModel<BarterContract> barterContracts;

    private List<SelectItem> whitePapers;

    private WhitePaper whitePaperSelected;

    private Boolean contractNumberChecked;

    //Export Functionality Constants
    private static final int MAX_COLUMNS_SIZE = 10;
    private static final String exportFileName = "ListadoAprobacionBarter";

    private void log(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        LOG.debug("SimulationBean " + methodName + ": " + object);
    }

    /**
     * No-arg constructor.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public SimulationFaces() {
        super();
        log("constructor");
        loggedUser = SecurityUtil.getLoggedInUser();


        // newSale = false;
        init();
        loadSimulationSearchScreen();
        fromContract = true;
    }

    public String newSale() {
        log("newSale");
        init();
        simulation = new Simulation();
        simulation.setReopenFlg(YesNoList.NO.getFlag());
        simulation.setCampaign(new Campaign());
        setDetail(false);

        newSale = true;
        /*fromContract = false;*/
        fcpaList = loadFCPAList();

        final TradingContractFaces tradingContractFaces = getFaces("tradingContractFaces");
        tradingContractFaces.getTradingContractList().clear();
        loadSimulationNumbers();
        return NEW;
    }

    public void search(boolean fromContract) {
        this.search();
        this.fromContract = true;
    }

    public String notFromContract() {
        log("notFromContract");
        init();
        if (simulationList != null) {
            log("notFromContact pre=" + simulationList.size());
            simulationList.clear();
            log("cleaning up the filter");
            filter = new SimulationFilter();
            log("notFromContact post=" + simulationList.size());
        } else {
            log("empty list");
        }
        /*newSale = false;*/
        fromContract = false;
        loadSimulationSearchScreen();
        loadSimulationNumbers();

        return SUCCESS;
    }

    public String search() {
        log("search");
        init();
        if (simulationList != null) {
            simulationList.clear();
        }
        newSale = false;
        fromContract = false;
        loadSimulationSearchScreen();
        loadSimulationNumbers();
        this.setMessages("");
        return SUCCESS;
    }

    public final void init() {
        log("init");

        renderContractFields = true;
        divisionChemicals = false;
        formalizationTermBusiness = new FormalizationTermBusiness();
        contractSelected = false;

        renderRtv = false;
        campaignList = null;
        invoiceList = null;
        commodity = false;
        filter = null;
        customerFilter = null;
        userFilter = null;
        statusList = null;
        simulationList = null;
        simulationSelected = null;
        simulation = new Simulation();
        template = null;
        fromContract = false;
        quoteTypeList = null;
        fcpaList = null;
        mktCampaignList = null;
        barterTypeList = null;
        cropList = null;
        tradingList = null;
        currencyList = null;
        paymentConditionList = null;
        commodityList = null;
        incotermsList = null;
        regionList = null;
        cityList = null;
        itemsSimulation = null;
        disapprovalReasonList = null;
        returnReasonList = null;
        quotationBusiness = null;
        simulationItem = null;
        usdRate = null;
        unitMeasurement = null;
        selectedCustomer = null;
        selectedContract = null;
        mktCampaignDesc = null;
        tradingDesc = null;
        commodityDesc = null;
        codeOthersDisapprovalReason = DisapprovalReasonList.OTHERS.getCode();
        codeOthersReturnReason = ReturnReasonList.OTHERS.getCode();
        deletedItems = null;
        sendApprovalMessages = null;
        newSale = false;
        reopen = false;
        quoteFieldsDisabled = false;
        renderDiffDelivLocationCheckBox = false;
        renderDiffDelivLocationField = false;
        renderIncentive = false;
        renderUsdRate = false;
        renderedPanelQuotation = false;
        renderedPanelItem = false;
        renderedPanelTermsFormalization = false;
        renderPanelSignature = false;
        renderPopupFormalizationPrint = false;
        renderPrintButton = false;
        renderApproveButton = false;
        renderVerifySaleOrderButton = false;
        renderReturnButton = false;
        renderDisapproveButton = false;
        renderedTxtMotive = false;
        barterTypeTerms = false;
        barterTypeWithExistingContract = false;
        barterTypeMonsantoManagesContract = false;
        barterTypeGrainAvailable = false;
        streamPDFFile = null;
        paymentConditionList = loadPaymentConditionListSearch();
        simulationSearchList = false;
        editContractsIds = new ArrayList<Long>();
        barterContracts = new ArrayDataModel<BarterContract>();
        whitePapers = new ArrayList<SelectItem>();
        whitePaperSelected = new WhitePaper();
        contractNumberChecked = false;

        verifyUserTypeNew();
        this.toggleFieldsRequired();
    }

    /**
     * Method responsible for loading the search screen components.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void loadSimulationSearchScreen() {

        super.setDetail(false);

        if (isNewer() && !reopen) {
            filter = new SimulationFilter();
            userFilter = new UserFilter();
            customerFilter = new CustomerFilter();

            verifyUserType();
        } else {
            final ISimulationService simulationService = getService(ISimulationService.class);
            if (simulationSearchList) {
                super.setDetail(false);
                simulationList = simulationService.searchByFilter(filter);
                for (SimulationBusiness simulation : simulationList) {
                    simulation.setCurrencyCd(USD_CD);
                    calculateListTotalAmounts(simulation);
                }
            } else {
                simulationList = simulationService.search(filter);
            }
        }

        campaignList = loadCampaignListSearch();
        statusList = loadStatusList();

        paymentConditionList = loadPaymentConditionListSearch();
        loadWhitepaperList();
    }

    private void loadWhitepaperList() {
        IWhitePaperService whitePaperService = getService(IWhitePaperService.class);

        List<WhitePaper> whitePapers = whitePaperService.findAll();

        for (WhitePaper whitePaper : whitePapers) {
            this.whitePapers.add(new SelectItem(whitePaper.getId(), whitePaper.getName()));
        }

        sortSelectItem(this.whitePapers);
    }

    /**
     * Updates UI whitepaper values when the whitepaper drop down changes
     *
     * @author Sebastian Kapcitzky
     */
    public void drpWhitepaperChanged(){
        IWhitePaperService whitePaperService = getService(IWhitePaperService.class);

        WhitepaperFilter filter = new WhitepaperFilter();
        filter.setId(this.filter.getWhitepaperId());
        this.whitePaperSelected = whitePaperService.search(filter).get(0);
    }

    /**
     * Method that verify the user type, to define the filters to load the possible values of some fields.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public final void verifyUserType() {

        final IUserService userService = getService(IUserService.class);
        final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

        renderRtv = true;
        commodity = false;
        if (user.getSaleDistrict() != null) {
            renderRtv = false;
            filter.setRtvId(user.getId());
            // EDT 0529774 BR Barter - sales structure adjustments
            // customerFilter.setUnitId(user.getUnit().getId());
        } else if (user.getRegional() != null) {
            filter.setRegionalId(user.getRegional().getId());
            userFilter.setRegionalId(user.getRegional().getId());
        } else if (user.getUnit() != null) {
            filter.setUnitId(user.getUnit().getId());
            // EDT 0529774 BR Barter - sales structure adjustments
            //customerFilter.setUnitId(user.getUnit().getId());
            userFilter.setUnitId(user.getUnit().getId());
        } else {
            commodity = true;
        }
    }

    /**
     * Method that verify the user type, to define the customer filter for the Register page.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void verifyUserTypeNew() {

        final IUserService userService = getService(IUserService.class);
        final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

        renderRtv = true;
        commodity = false;
        customerFilter = new CustomerFilter();
        if (user.getSaleDistrict() != null) {
            renderRtv = false;
            // EDT 0529774 BR Barter - sales structure adjustments
            //customerFilter.setUnitId(user.getUnit().getId());
        } else if (user.getUnit() != null) {
            // EDT 0529774 BR Barter - sales structure adjustments
            //customerFilter.setUnitId(user.getUnit().getId());
        } else {
            commodity = true;
            if (newSale) {
                final List<MessageVO> message = new ArrayList<MessageVO>();
                message.add(new MessageVO("simulation.sales.structure.required.new.simulation", MessageTypeList.ERROR));
                setMessages(message);
            }
        }
    }

    /**
     * Load a SelectItem list of campaigns to show on the search page.
     *
     * @return the created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCampaignListSearch() {

        final ICampaignService campaignService = getService(ICampaignService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(ALL)));

        final CampaignFilter campaignFilter = new CampaignFilter();
        campaignFilter.getCampaign().setCountry(new com.monsanto.barter.business.entity.table.Country(new CountryId()));
        campaignFilter.getCampaign().getCountry().getId().setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());

        final List<Campaign> campaigns = campaignService.search(campaignFilter);
        for (final Campaign campaign : campaigns) {
            returns.add(new SelectItem(campaign.getId(), campaign.getName()));
        }

        returns.addAll(items);

        return returns;
    }

    /**
     * Load a SelectItem list of campaigns to show on the register page.
     *
     * @return the created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCampaignListRegister() {

        final ICampaignService campaignService = getService(ICampaignService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(SELECT)));

        final CampaignFilter campaignFilter = new CampaignFilter();
        campaignFilter.getCampaign().setSituationCd(CampaignSituationList.ACTIVE_CD.getCodSituation());
        campaignFilter.getCampaign().setStatusCd(CampaignStatusList.VALIDATED_CD.getCodStatus());
        campaignFilter.setActiveDate(new Date());
        campaignFilter.getCampaign().setCountry(new com.monsanto.barter.business.entity.table.Country(new CountryId()));
        campaignFilter.getCampaign().getCountry().getId().setCountryCd(SecurityUtil.getLoggedInUser().getCountyCd());
        final List<Campaign> campaigns = campaignService.search(campaignFilter);

        for (final Campaign campaign : campaigns) {
            returns.add(new SelectItem(campaign.getId(), campaign.getName().concat(IBarterConstants.HYPHEN)
                    .concat(campaign.getCropBaseYear())));
        }

        returns.addAll(items);

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Statuses to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadStatusList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(ALL)));

        if (fromContract) {
            items.add(new SelectItem(SimulationStatusList.APPROVED.getCod(), getMessage(SimulationStatusList.APPROVED
                    .getDescription())));
            items.add(new SelectItem(SimulationStatusList.WAITING_APPROVAL.getCod(),
                    getMessage(SimulationStatusList.WAITING_APPROVAL.getDescription())));
        } else {
            for (final SimulationStatusList type : SimulationStatusList.values()) {
                if (hasValue(type.getDescription())) {
                    items.add(new SelectItem(type.getCod(), getMessage(type.getDescription())));
                }
            }
        }

        returns.addAll(sortSelectItem(items));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Quote Types to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadQuoteTypesList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();

        for (final QuoteTypeList type : QuoteTypeList.values()) {
            returns.add(new SelectItem(Character.valueOf(type.getCod()), getMessage(type.getName())));
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Barter Types to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadBarterTypesList() {

        final ICampaignBarterTypeService campaignBarterTypeService = getService(ICampaignBarterTypeService.class);

        final CampaignBarterTypeFilter campaignBarterTypeFilter = new CampaignBarterTypeFilter();
        campaignBarterTypeFilter.setCampaignId(simulation.getCampaign().getId());

        // Only load allowed barter types for the selected campaign.
        final List<CampaignBarterType> campaignBarterTypes = campaignBarterTypeService.search(campaignBarterTypeFilter);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(SELECT)));

        for (final CampaignBarterType campaignBarterType : campaignBarterTypes) {

            final Character barterCod = campaignBarterType.getId().getBarterType().getId().getBarterTypeId().charAt(0);

            BarterTypeList barterTypeListResult = BarterTypeList.getByCod(barterCod);

            if (newSale || !newSale && !(barterTypeListResult == BarterTypeList.TERMS)) {
                items.add(new SelectItem(barterCod, getMessage(barterTypeListResult.getName())));
            }

        }

        returns.addAll(sortSelectItem(items));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of FCPA options to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadFCPAList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();

        for (final FCPAList option : FCPAList.values()) {
            returns.add(new SelectItem(Character.valueOf(option.getCod()), getMessage(option.getDescription())));
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of MktCampaigns to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadMktCampaignList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final IMktCampaignService mktCampaignService = getService(IMktCampaignService.class);

        returns.add(new SelectItem(null, getMessage(SELECT)));

        final MktCampaignFilter mktCampaignFilter = new MktCampaignFilter();
        mktCampaignFilter.setActiveDate(new Date());
        final List<MktCampaign> campaigns = mktCampaignService.search(mktCampaignFilter);

        for (final MktCampaign campaign : campaigns) {
            if (hasValue(campaign.getId().getCustGroup5())) {
                returns.add(new SelectItem(campaign.getId().getCustGroup5().trim(), campaign.getId().getCustGroup5()
                        .concat(IBarterConstants.HYPHEN).concat(campaign.getCampaignDesc())));
            }
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Crops to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCropList() {

        final ICropService cropService = getService(ICropService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final CropFilter cropFilter = new CropFilter();
        cropFilter.setLanguageCd(loggedUser.getLanguageCd());
        final List<Crop> crops = cropService.search(cropFilter);

        for (final Crop crop : crops) {
            returns.add(new SelectItem(crop.getId(), crop.getCropDesc()));
        }

        return returns;
    }

    /**
     * Evaluates the contract Number / Cesion inputted and recovers the Cesion's amount if the Cesion exists, if not
     *@author Sebastian Kapcitzky
     */
    public void checkContractNumber(){
        ISimulationService simulationService = getService(ISimulationService.class);
        simulationService.evaluateCesionExistence(simulation, simulationContractSelected);

        setContractNumberChecked(true);
        setMessages(simulationService.getMessages());
    }


    /**
     * Method that returns a SelectItem list of Tradings to display on the page.
     *
     * @return The created list
     */
    private List<SelectItem> loadTradingList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final ITradingService tradingService = getService(ITradingService.class);
        List<Trading> tradings = new ArrayList<Trading>();
        List<CampaignTrading> campaignTradings = new ArrayList<CampaignTrading>();

        if (hasValue(simulation.getBarterType())) {
            if (BarterTypeList.GRAIN_AVAILABLE.getCod().equals(simulation.getBarterType())) {

                if (isBarterParaguay()) {
                    filterCampaignTradings(returns);
                } else {
                    final TradingFilter tradingFilter = new TradingFilter();
                    tradingFilter.getTrading().setId(new TradingId());
                    tradingFilter.getTrading().getId().setCountryCd(simulation.getCampaign().getCountry().getId().getCountryCd());
                    tradings = tradingService.search(tradingFilter);
                    for (final Trading trading : tradings) {
                        returns.add(new SelectItem(trading.getId().getTradingCd().trim(), trading.getDescTrading()));
                    }
                }

            } else if (BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod().equals(simulation.getBarterType())) {
                renderContractFields = false;

                simulation.getIncoterms().getId().setIncotermsCd(null);
                simulation.setQuantityKg(null);
                simulation.setTotalContractGrossPrice(null);
                simulation.setTotalContractNetPrice(null);
                simulation.setNegotiationDate(null);
                if (newSale) {
                    simulation.setDeliveryDate(null);
                }
            } else {
                filterCampaignTradings(returns);
            }
        }

        return returns;
    }

    /**
     * Support method to fill the Trading dropdown with Campaign filtered Tradings
     * @author Sebastian Kapcitzky
     * @param selectItemList a list of Tradings
     */
    private void filterCampaignTradings(List<SelectItem> selectItemList) {

        final ICampaignTradingService campaignTradingService = getService(ICampaignTradingService.class);
        CampaignTradingFilter campaignTradingFilter = new CampaignTradingFilter();
        List<CampaignTrading> campaignTradings = new ArrayList<CampaignTrading>();

        campaignTradingFilter.setCampaignId(simulation.getCampaign().getId());
        campaignTradingFilter.setCountryCd(simulation.getCampaign().getCountry().getId().getCountryCd());
        campaignTradings = campaignTradingService.search(campaignTradingFilter);

        for (final CampaignTrading campaignTrading : campaignTradings) {
            final Trading trading = campaignTrading.getId().getTrading();
            selectItemList.add(new SelectItem(trading.getId().getTradingCd().trim(), trading.getDescTrading()));
        }
    }


    private List<SelectItem> loadTradingListForCampaign() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final ICampaignTradingService campaignTradingService = getService(ICampaignTradingService.class);

        final CampaignTradingFilter campaignTradingFilter = new CampaignTradingFilter();
        campaignTradingFilter.setCampaignId(simulation.getCampaign().getId());
        final List<CampaignTrading> tradings = campaignTradingService.search(campaignTradingFilter);

        for (final CampaignTrading campaignTrading : tradings) {
            final Trading trading = campaignTrading.getId().getTrading();
            returns.add(new SelectItem(trading.getId().getTradingCd().trim(), trading.getDescTrading()));
        }

        return returns;

    }

    /**
     * Method that returns a SelectItem list of Currencies to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCurrencyList() {

        final ICurrencyService currencyService = getService(ICurrencyService.class);

        List<SelectItem> returns = new ArrayList<SelectItem>();

        final CurrencyFilter currencyFilter = new CurrencyFilter();

        // only USD is allowed for barter PY
        if (isBarterParaguay()) {
            currencyFilter.getCurrency().getId().setLanguageCd(Country.PARAGUAY.getCodLanguage());
            currencyFilter.getCurrency().getId().setCurrencyCd(USD_CD);
        } else {
            currencyFilter.getCurrency().getId().setLanguageCd(loggedUser.getLanguageCd());
        }

        final List<Currency> currencies = currencyService.search(currencyFilter);

        for (final Currency currency : currencies) {
            returns.add(new SelectItem(currency.getId().getCurrencyCd(), currency.getDescCurrencyLong()));
        }

        returns = super.sortSelectItem(returns);

        returns.add(0, new SelectItem(null, getMessage(SELECT)));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Payment Conditions to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem>
    loadPaymentConditionList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(SELECT)));

        if (hasValue(simulation.getBarterType())) {
            if (BarterTypeList.GRAIN_AVAILABLE.getCod().equals(simulation.getBarterType())) {
                items.add(new SelectItem(PaymentConditionList.COMMODITIES_NEGOTIATED.getCod()));
            } else if (BarterTypeList.FUTURE_WITH_EXISTING_CONTRACT.getCod().equals(simulation.getBarterType())) {
                items.add(new SelectItem(PaymentConditionList.COMMODITIES.getCod()));
                items.add(new SelectItem(PaymentConditionList.BARTER_B.getCod()));
                sortSelectItem(items);
            } else if (BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod().equals(simulation.getBarterType())) {
                items.add(new SelectItem(PaymentConditionList.COMMODITIES.getCod()));
            } else if (BarterTypeList.TERMS.getCod().equals(simulation.getBarterType())) {
                items.add(new SelectItem(PaymentConditionList.BARTER_B.getCod()));
            }
        }

        returns.addAll(items);

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Payment Conditions to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadPaymentConditionListSearch() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        returns.add(new SelectItem(null, getMessage(SELECT)));

        for (final PaymentConditionList value : PaymentConditionList.values()) {
            items.add(new SelectItem(value.getCod()));
        }

        returns.addAll(sortSelectItem(items));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Disapproval Reason to display on the page.
     *
     * @return The created list
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private List<SelectItem> loadDisapprovalReasonList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        for (final DisapprovalReasonList value : DisapprovalReasonList.values()) {
            if (!value.getCode().equals(DisapprovalReasonList.OTHERS.getCode())) {

                items.add(new SelectItem(value.getCode(), super.getMessage(value.getName())));
            }
        }

        returns.addAll(sortSelectItem(items));
        returns.add(new SelectItem(DisapprovalReasonList.OTHERS.getCode(), super.getMessage(DisapprovalReasonList.OTHERS.getName())));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Return Reason to display on the page.
     *
     * @return The created list
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private List<SelectItem> loadReturnReasonList() {

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        final List<SelectItem> items = new ArrayList<SelectItem>();

        for (final ReturnReasonList value : ReturnReasonList.values()) {
            if (!value.getCode().equals(ReturnReasonList.OTHERS.getCode())) {

                items.add(new SelectItem(value.getCode(), super.getMessage(value.getName())));
            }
        }

        returns.addAll(sortSelectItem(items));
        returns.add(new SelectItem(ReturnReasonList.OTHERS.getCode(), super.getMessage(ReturnReasonList.OTHERS.getName())));

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Commodities to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCommodityList() {

        final ICampaignCommodityService campaignCommodityService = getService(ICampaignCommodityService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final CampaignCommodityFilter campaignCommodityFilter = new CampaignCommodityFilter();
        campaignCommodityFilter.setCampaignId(simulation.getCampaign().getId());
        final List<CampaignCommodity> commodities = campaignCommodityService.search(campaignCommodityFilter);

        for (final CampaignCommodity campaignCommodity : commodities) {
            final Commodity commodityResult = campaignCommodity.getId().getCommodity();
            returns.add(new SelectItem(commodityResult.getId().getCommodityId().trim(), commodityResult.getDescCommodity()));
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Incoterms to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadIncotermsList() {

        final IIncotermsService incotermsService = getService(IIncotermsService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final IncotermsFilter incotermsFilter = new IncotermsFilter();
        incotermsFilter.setLanguageCd(loggedUser.getLanguageCd());
        final List<Incoterms> incoterms = incotermsService.search(incotermsFilter);

        for (final Incoterms item : incoterms) {
            returns.add(new SelectItem(item.getId().getIncotermsCd()));
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Regions to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadRegionList() {

        final IRegionService regionService = getService(IRegionService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        final RegionFilter regionFilter = new RegionFilter();
        regionFilter.setLanguageCd(loggedUser.getLanguageCd());
        final List<Region> regions = regionService.search(regionFilter);

        for (final Region region : regions) {
            returns.add(new SelectItem(region.getId().getRegionCd()));
        }

        return returns;
    }

    /**
     * Method that returns a SelectItem list of Cities to display on the page.
     *
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private List<SelectItem> loadCityList() {

        final ICityService cityService = getService(ICityService.class);

        final List<SelectItem> returns = new ArrayList<SelectItem>();
        returns.add(new SelectItem(null, getMessage(SELECT)));

        if (hasValue(simulation.getCity().getId().getRegionCd())) {
            final CityFilter cityFilter = new CityFilter();
            cityFilter.setLanguageCd(loggedUser.getLanguageCd());
            cityFilter.setRegionCd(simulation.getCity().getId().getRegionCd());

            final List<City> cities = cityService.search(cityFilter);
            for (final City city : cities) {
                returns.add(new SelectItem(city.getId().getCityCd(), city.getDescCity()));
            }
        }

        return returns;
    }

    public List<String> loadRtvListNames(final String suggestion) {
        if (suggestion == null) {
            return new ArrayList<String>();
        }

        final IUserService userService = getService(IUserService.class);

        userFilter.getUser().setName((String) suggestion);

        List<String> users = userService.searchNames(userFilter);

        return users;
    }


    /**
     * Method that loads a user list based on the current value defined on the RTV field.
     *
     * @param suggestion - Filter of the field
     * @return a users list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public List<User> loadRtvList(final String suggestion) {

        if (suggestion == null) {
            return new ArrayList<User>();
        }

        final IUserService userService = getService(IUserService.class);

        userFilter.getUser().setName((String) suggestion);

        List<User> users = userService.search(userFilter);

        return users;
    }

    /**
     * Method that loads a customer list based on the current value defined on the Customer field.
     *
     * @param suggestion - Filter of the field
     * @return a list of customer names
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public List<String> loadCustomerList(final String suggestion) {

        if (suggestion == null) {
            return new ArrayList<String>();
        }

        final ICustomerService customerService = getService(ICustomerService.class);

        customerFilter.setName((String) suggestion);

        return customerService.searchNames(customerFilter);
    }

    /**
     * Method that loads a representative/agent list based on the current value defined on the Representative/Agent
     * field.
     *
     * @param suggestion - Filter of the field
     * @return The created list
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public List<PartnerYa> loadPartnerYaList(final Object suggestion) {
        final int MINIMUN_SIZE_TO_START_SEARCH = 3;

        simulation.getAgent().setCustomerCd(null);

        if (suggestion == null) {
            return new ArrayList<PartnerYa>();
        }

        final String value = (String) suggestion;
        if (value.length() >= MINIMUN_SIZE_TO_START_SEARCH) {
            final IPartnerYaService partnerYaService = getService(IPartnerYaService.class);

            final PartnerYaFilter partnerYaFilter = new PartnerYaFilter();
            partnerYaFilter.setCustomerNameTx(value);

            return partnerYaService.search(partnerYaFilter);
        } else {
            return new ArrayList<PartnerYa>();
        }
    }

    /**
     * Method responsible for calling the Search method from the business layer.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void btnSearch() {
        log("btnSearch::start");
        try {
            if (simulationList != null) {
                log("btnSearch::listCleanUp");
                simulationList.clear();
            }
            final ISimulationService simulationService = getService(ISimulationService.class);
            if (this.fromContract) {
                filter.setBarterType(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod());
                filter.setNoContractAssociated(Boolean.TRUE);
            }
            if (isBarterParaguay() && simulationSearchList) {
                simulationList = simulationService.searchByFilter(filter);
                for (SimulationBusiness simulation : simulationList) {
                    simulation.setCurrencyCd(USD_CD);
                    calculateListTotalAmounts(simulation);
                }
            } else {
                simulationList = simulationService.search(filter);
            }
            log("btnSearch::simulationList " + simulationList);

            setMessages(simulationService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);

        }
    }

    /**
     * Calculates the Tons and Amounts Totals regarding to the simulation
     *
     * @author Sebastian Kapcitzky
     */
    private void calculateTotalAmounts() {

        if (!hasValue((simulation.getQuantityKg()))) {
            simulation.setQuantityKg(BigDecimal.ZERO);
        }
        if (!hasValue((simulation.getTotalContractGrossPrice()))) {
            simulation.setTotalContractGrossPrice(BigDecimal.ZERO);
        }
        if (!hasValue((simulation.getTotalBarterAmount()))) {
            this.setTotalBarterAmount(BigDecimal.ZERO);
        }
        if (!hasValue((simulation.getTotalBarterTons()))) {
            this.setTotalBarterTons(BigDecimal.ZERO);
        }

        for (BarterContract barterContract : simulation.getBarterContracts()) {
            //Calculates totals of only approved contracts (BarterContractStatusList.APPROVED)
            if (barterContract.getLegalApproval()){
                setTotalBarterTons(getTotalBarterTons().add(barterContract.getQtyKg()));
                setTotalBarterAmount(getTotalBarterAmount().add(barterContract.getTotalCntrctGrossPrice()));
            }
        }
    }

    /**
     * Calculates the Tons and Amounts Totals regarding to each simulation in the Simulation List Result page
     *
     * @author Sebastian Kapcitzky
     * @param simulation
     */
    private void calculateListTotalAmounts(SimulationBusiness simulation) {

        if (!hasValue((simulation.getQuantityKg()))) {
            simulation.setQuantityKg(BigDecimal.ZERO);
        }
        if (!hasValue((simulation.getTotalContractGrossPrice()))) {
            simulation.setTotalContractGrossPrice(BigDecimal.ZERO);
        }
        if (!hasValue((this.simulation.getTotalBarterAmount()))) {
            simulation.setTotalBarterAmount(BigDecimal.ZERO);
        }
        if (!hasValue((this.simulation.getTotalBarterTons()))) {
            simulation.setTotalBarterTons(BigDecimal.ZERO);
        }

        for (BarterContract barterContract : simulation.getBarterContracts()) {
            //Calculates totals of only approved contracts (BarterContractStatusList.APPROVED)
            if (barterContract.getLegalApproval()) {
                simulation.setTotalBarterTons(simulation.getTotalBarterTons().add(barterContract.getQtyKg()));
                simulation.setTotalBarterAmount(simulation.getTotalBarterAmount().add(barterContract.getTotalCntrctGrossPrice()));
            }
        }
    }

    /**
     * Method responsible for generating file upload lines
     *
     * @author Sanjeev Kumar
     */

    public String prepareFileUploadForm() {
        LOG.debug("In FileUploadForm");
        renderAttachmentPopup = false;
        filesAttachedSuccessfully = false;

        try {
            fileUploadHandlers.clear();
            attachments.clear();
            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            final ISimulationService simulationService = getService(ISimulationService.class);
            simulation = simulationService.findByIdComplete(simulationFilter);
            attachments.addAll(simulation.getAttachments());
            //By default 5 files to upload
            for (int i = 0; i < 5; i++) {
                addFileUploadHandler();
            }
            setMessages(simulationService);

            renderAttachmentPopup = true;
            return SUCCESS;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }
    }

    /**
     * Method responsible for attaching files to simulation
     *
     * @author Sanjeev Kumar
     */
    public void attachFiles() {
        log("In attachFiles ");
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            if (isValidAttachments()) {
                for (FileUpload fileUploadHandler : fileUploadHandlers) {
                    if (fileUploadHandler.getFile() != null) {
                        BarAttachment attachment = new BarAttachment(fileUploadHandler.getFile(), fileUploadHandler.getUploadDocumentNumber(), fileUploadHandler.getUploadDocumentType());
                        attachments.add(attachment);
                    }
                }

                simulation.setAttachments(attachments);
                simulationService.saveReopenSimulation(simulation);
                setMessages(simulationService);

                if (simulationService.isOk()) {
                    filesAttachedSuccessfully = true;
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for deleting the attachment
     *
     * @author Pragathi
     */
    public void deleteAttachment() {
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            AttachmentService attachmentService = getService(AttachmentService.class);
            simulation.getAttachments().remove(attachmentSelected);
            simulationService.saveReopenSimulation(simulation);
            attachmentService.delete(attachmentSelected.getId());

            setMessages(simulationService);

            if (simulationService.isOk()) {
                attachments.remove(attachmentSelected);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    public StreamedContent getFile() {
        return new DefaultStreamedContent(new ByteArrayInputStream(attachmentSelected.getFile().getFileContent()),
                attachmentSelected.getFile().getMimeType(), attachmentSelected.getFile().getFileName());
    }

    /**
     * Check the validity of the file uploaded
     *
     * @author Pragathi
     */
    private boolean isValidAttachments() {
        boolean valid = true;
        boolean validDocument = true;

        for (FileUpload fileUploadHandler : fileUploadHandlers) {
            fileUploadHandler.getUploadErrorMessages().clear();

            validDocument = true;
            if (fileUploadHandler.getFile() != null || fileUploadHandler.getUploadDocumentType() != null || StringUtils.isNotEmpty(fileUploadHandler.getUploadDocumentNumber())) {

                validDocument = isDocumentValid(fileUploadHandler) && !checkDocumentExistence(fileUploadHandler);

                validDocument = isFileUploaded(fileUploadHandler) && fileSizeIsValid(fileUploadHandler) && validDocument;

                valid = validDocument ? valid : validDocument;
            }
        }

        return valid;
    }

    /**
     * Method responsible for checking the validity of the document
     *
     * @author Sanjeev Kumar
     */

    private boolean isDocumentValid(FileUpload fileUploadHandler) {
        boolean valid = true;
        List uploadErrorMessages = fileUploadHandler.getUploadErrorMessages();

        String documentNumber = trim(fileUploadHandler.getUploadDocumentNumber());
        if (org.apache.commons.lang3.StringUtils.isBlank(documentNumber)) {
            uploadErrorMessages.add(getMessage("attachfiledialog.error.uploadDocumentNumber.required"));
            valid = false;
        }

        if (fileUploadHandler.getUploadDocumentType() == null) {
            uploadErrorMessages.add(getMessage("attachfiledialog.error.uploadDocumentType.required"));
            valid = false;
        }
        return valid;
    }

    /**
     * Method responsible for checking the document existence
     *
     * @author Sanjeev Kumar
     */

    private boolean checkDocumentExistence(FileUpload fileUploadHandler) {
        boolean exists = false;
        for (BarAttachment attachment : simulation.getAttachments()) {
            if (attachment.getDocumentNumber().equals(fileUploadHandler.getUploadDocumentNumber().trim()) && attachment.getDocumentType() == fileUploadHandler.getUploadDocumentType()) {
                fileUploadHandler.getUploadErrorMessages().add(getMessage("attachfiledialog.error.uploadDocumentType.exist"));
                exists = true;
            }
        }
        return exists;
    }

    /**
     * checks if the file has been uploaded
     *
     * @author Sanjeev Kumar
     */

    private boolean isFileUploaded(FileUpload fileUploadHandler) {
        boolean valid = true;
        if (fileUploadHandler.getFile() == null) {
            fileUploadHandler.getUploadErrorMessages().add(getMessage("attachfiledialog.error.file.required"));
            valid = false;
        }
        return valid;
    }

    /**
     * checks the file size
     *
     * @author Sanjeev Kumar
     */

    private boolean fileSizeIsValid(FileUpload fileUploadHandler) {
        File file = fileUploadHandler.getFile();
        long length = file.getFileSize();
        boolean valid = true;

        if (length > 5242880) {
            valid = false;
            fileUploadHandler.getUploadErrorMessages().add(getMessage("fileUpload.invalidSize.error"));
        }
        return valid;
    }

    /**
     * Method that verifies if the chosen FCPA option is valid and redirects to the next page in the simulation
     * register.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnContinueFcpa() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            if (simulationService.validateFCPA(simulation)) {
                campaignList = loadCampaignListRegister();
                return SUCCESS;
            }

            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method that verifies if a campaign was chosen and redirects to the next page in the simulation register.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnContinueCampaign() {

        setNewer(true);
        setDetail(false);

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            if (simulationService.validateCampaign(simulation)) {
                fillInitialSimulationValues();

                return SUCCESS;
            }

            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Fills the simulation object will the initial values of some attributes, and load the lists used on the screen.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void fillInitialSimulationValues() {

        final ICampaignService campaignService = getService(ICampaignService.class);
        final IUserService userService = getService(IUserService.class);

        // Initializing simulation object attributes.
        if (!hasValue(simulation.getCrop())) {
            simulation.setCrop(new Crop());
        }
        if (!hasValue(simulation.getQuotation())) {
            simulation.setQuotation(new Quotation(new QuotationId()));
        }
        if (!hasValue(simulation.getHistories())) {
            simulation.setHistories(new ArrayList<SimulationHistory>());
        }
        if (!hasValue(simulation.getItems())) {
            simulation.setItems(new ArrayList<SimulationItem>());
        }
        if (!hasValue(simulation.getBarterContracts())) {
            simulation.setBarterContracts(new ArrayList<BarterContract>());
        }
        if (!hasValue(simulation.getCity())) {
            simulation.setCity(new City(new CityId()));
        }
        if (!hasValue(simulation.getAgent())) {
            simulation.setAgent(new PartnerYa());
        }
        if (!hasValue(simulation.getCurrency())) {

            simulation.setCurrency(new Currency(new CurrencyId()));

            // Force USD for barter PY
            if (isBarterParaguay()) {
                simulation.getCurrency().getId().setCurrencyCd(USD_CD);
            }

        }
        if (!hasValue(simulation.getIncoterms())) {
            simulation.setIncoterms(new Incoterms(new IncotermsId()));
        }

        if (!isDetail()) {
            simulation.setOrderDate(new Date());
        }
        if (isNewer() && newSale && !reopen) {
            simulation.setCampaign(campaignService.findByIdComplete(simulation.getCampaign()));
            simulation.setStatusCd(SimulationStatusList.DRAFT.getCod());
            simulation.setDifDeliveryPlace(YesNoList.NO.getFlag());
            simulation.setItemsGrossValue(BigDecimal.ZERO);

            final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

            simulation.setUser(user);
            simulation.setCreateUser(user);
            // EDT 0529774 BR Barter - sales structure adjustments
            // simulation.setUnit(user.getUnit());
            // simulation.setRegional(user.getRegional());
            simulation.getIncoterms().getId().setLanguageCd(loggedUser.getLanguageCd());
            simulation.getCurrency().getId().setLanguageCd(loggedUser.getLanguageCd());
            simulation.getCity().getId().setLanguageCd(loggedUser.getLanguageCd());
            simulation.getCity().getId().setCountryCd(simulation.getCampaign().getCountry().getId().getCountryCd());
            simulation.setItemsNetValue(BigDecimal.ZERO);
        } else {
            if (!hasValue(simulation.getIncoterms().getId().getLanguageCd())) {
                simulation.getIncoterms().getId().setLanguageCd(loggedUser.getLanguageCd());
            }
            if (!hasValue(simulation.getCurrency().getId().getLanguageCd())) {
                simulation.getCurrency().getId().setLanguageCd(loggedUser.getLanguageCd());
            }
            if (!hasValue(simulation.getCity().getId().getLanguageCd())) {
                simulation.getCity().getId().setLanguageCd(loggedUser.getLanguageCd());
                simulation.getCity().getId().setCountryCd(simulation.getCampaign().getCountry().getId().getCountryCd());
            }

            quoteFieldsDisabled = QuoteTypeList.QUOTE.getCod().equals(simulation.getQuotationFlg());
            renderDiffDelivLocationCheckBox = IBarterConstants.CROP_CODE_ZQUI.equalsIgnoreCase(simulation.getCrop()
                    .getCropCd());
            renderDiffDelivLocationField = YesNoList.YES.getFlag().equals(simulation.getDifDeliveryPlace());
            renderContractFields = !BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod().equals(
                    simulation.getBarterType());

            if (!simulation.getItems().isEmpty()
                    && IBarterConstants.DIVISION_CHEMICALS.equals(simulation.getItems().get(0).getDivision().getId()
                    .getDivisionCd())) {
                divisionChemicals = true;
            } else {
                divisionChemicals = false;
            }

            if (hasValue(simulation.getCommodityId())) {
                final ICommodityService commodityService = getService(ICommodityService.class);
                final Commodity commodityFilter = new Commodity(new CommodityId(
                        simulation.getCommodityId(), simulation.getCampaign().getCountry().getId().getCountryCd()));
                final Commodity commodityResult = commodityService.findById(commodityFilter);
                unitMeasurement = UnitMeasurementList.getByCode(commodityResult.getUnitOfMeasure());
            } else {
                unitMeasurement = null;
            }

            renderUsdRate = false;
            usdRate = null;
            loadUsdRate(simulation.getCurrency().getId().getCurrencyCd());
        }

        if (hasValue(simulation.getCampaign().getIncentive())
                && simulation.getCampaign().getIncentive().doubleValue() > 0) {
            renderIncentive = true;
        }

        if (isDetail()) {
            loadDetailFields();
        } else if (reopen && hasValue(simulation.getCustGroup5())) {
                final IMktCampaignService mktCampaignService = getService(IMktCampaignService.class);

                final MktCampaignFilter mktCampaignFilter = new MktCampaignFilter();
                mktCampaignFilter.setCustGroup5(simulation.getCustGroup5());
                mktCampaignFilter.setActiveDate(new Date());

                final List<MktCampaign> mktCampaignListResults = mktCampaignService.search(mktCampaignFilter);
                if (!mktCampaignListResults.isEmpty()) {
                    final MktCampaign mktCampaign = mktCampaignListResults.get(0);

                    if (hasValue(mktCampaign.getId().getCustGroup5())) {
                        mktCampaignDesc = mktCampaign.getId().getCustGroup5().concat(IBarterConstants.HYPHEN)
                                .concat(mktCampaign.getCampaignDesc());
                    }
                }
            }

        // Initializing drop menu lists.
        mktCampaignList = loadMktCampaignList();
        barterTypeList = loadBarterTypesList();
        currencyList = loadCurrencyList();
        commodityList = loadCommodityList();
        incotermsList = loadIncotermsList();
        regionList = loadRegionList();
        cityList = loadCityList();
        tradingList = loadTradingList();
        quoteTypeList = loadQuoteTypesList();
        disapprovalReasonList = loadDisapprovalReasonList();
        returnReasonList = loadReturnReasonList();

        if (hasValue(simulation.getCustGroup5())) {
            simulation.setCustGroup5(simulation.getCustGroup5().trim());
        }
        if (hasValue(simulation.getCommodityId())) {
            simulation.setCommodityId(simulation.getCommodityId().trim());
        }

        if (newSale) {
            cropList = loadCropList();
            paymentConditionList = loadPaymentConditionList();
        }


        final TradingContractFaces tradingContractFaces = getFaces("tradingContractFaces");

        if (super.hasValue(tradingContractFaces)) {
            tradingContractFaces.setCampaign(simulation.getCampaign());
        }

        this.toggleFieldsRequired();
    }

    /**
     * Removes a Simulation item from the list.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String removeSimulationItem() {

        if ((!isNewer() || (isNewer() && !newSale)) && hasValue(simulationItem.getId())) {
            deletedItems.add(simulationItem);
        }

        final Integer index = getParameterInteger("itemIndex");

        simulation.getItems().remove(index.intValue());
        updateTotalItemsValues();

        return NOT_NAVIGATE;
    }

    /**
     * Opens the item popup to edit an item.
     *
     * @return A string that defines the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String editSimulationItem() {

        final ISimulationService simulationService = getService(ISimulationService.class);
        if (simulationService.validateRequiredSimulationFieldsForItemsFilled(simulation)) {
            final ItemFaces itemFaces = getFaces(ITEM_FACES_NAME);
            itemFaces.clearMessages();
            if (itemFaces != null) {
                itemFaces.setEdit(true);
                itemFaces.setSimulation(simulation);
                itemFaces.setSimulationItem(simulationItem.copyToSimulationItem(new SimulationItem()));
                itemFaces.loadDivision();
                simulationItem.getProduct().setMaterialNbr(simulationItem.getProduct().getMaterialNbr().trim());
                itemFaces.loadProducts(simulationItem.getProduct().getBrandCd());
                renderedPanelItem = true;
            }
        } else {
            setMessages(simulationService.getMessages());
        }

        return CHANGE;
    }

    public void cleanParams() {
        this.customerFilter.setName("");
        this.customerFilter.setSapCd("");
        this.customerFilter.setCpfCnpj("");

        final CustomerFaces customerFaces = getFaces("customerFaces");

        if (super.hasValue(customerFaces)) {
            customerFaces.cancelSelectionCustomer();
        }
    }

    /**
     * Confirms the Customer selection and load it from the database.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void confirmSelectionCustomer() {

        try {

            final ICustomerService customerService = getService(ICustomerService.class);
            final IUnitService unitService = getService(IUnitService.class);
            final IRegionalService regionalService = getService(IRegionalService.class);


            final Customer selectedCustomerFilter = new Customer();

            String[] customerData = selectedCustomer.split("-");

            final String sapCd = customerData[0];
            final String distrChannelCd = customerData[1];
            final String unitId = customerData[2];
            final String regionalId = customerData[3];

            selectedCustomerFilter.setSapCd(sapCd);

            simulation.setCustomer(customerService.findByIdComplete(selectedCustomerFilter));
            simulation.setDistrChannelCd(distrChannelCd);


            // EDT 0529774 BR Barter - sales structure adjustments
            simulation.setUnitId(unitId);

            // EDT 0529774 BR Barter - sales structure adjustments
            Regional regionalFilter = new Regional();
            regionalFilter.setId(regionalId);
            simulation.setRegional(regionalService.findById(regionalFilter));

            cleanParams();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }


    public void confirmSelectionContract() {

        try {

            final ITradingContractService tradingContractService = getService(ITradingContractService.class);

            TradingContract id = new TradingContract();
            id.setContractId(Long.valueOf(selectedContract));

            TradingContract contract = tradingContractService.findById(id);

            simulation.setContract(contract);

            simulation.setCommodityId(contract.getCommodityId());
            simulation.setContractNbr(contract.getNbrContract());
            simulation.setTradingCd(contract.getTradingCd());
            simulation.setCurrency(contract.getCurrency());
            simulation.setSackNetPrice(contract.getSackNetPrice());
            simulation.setQuotationFlg(contract.getQuotationFL());
            simulation.setSackGrossPrice(contract.getSackGrossPrice());
            simulation.setQuantityKg(contract.getVolumeKG());
            simulation.setIncoterms(contract.getIncoterms());
            simulation.setDescDeliveryPlace(contract.getDeliveryPlace());
            simulation.setDeliveryDate(contract.getDeliveryDate());
            simulation.setCity(contract.getCity());
            simulation.setPaymentDate(contract.getPaymentDate());
            simulation.setNegotiationDate(contract.getNegotiationDate());


            cityList = loadCityList();
            tradingList = loadTradingListForCampaign();

            calculateTotalContractGrossPrice(simulation);

            calculateTotalContractNetPrice( simulation );


            final TradingContractFaces tradingContractFaces = getFaces("tradingContractFaces");

            if (super.hasValue(tradingContractFaces)) {
                tradingContractFaces.cancelSelectionContract();
            }

            contractSelected = true;

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }



    private void calculateTotalContractGrossPrice( Simulation simulation ){

        BigDecimal unitToKg = BigDecimal.valueOf(60L);

        if ( isBarterParaguay() ){
                simulation.setTotalContractGrossPrice( simulation.getSackGrossPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                    .setScale(2, RoundingMode.HALF_EVEN));
        } else {
                simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice()
                    .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                    .setScale(2, RoundingMode.HALF_EVEN));
        }

    }


    private void calculateTotalContractNetPrice(Simulation simulation){

        BigDecimal unitToKg = BigDecimal.valueOf(60L);

        if ( isBarterParaguay() ){

            simulation.setTotalContractNetPrice(simulation.getSackNetPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                    .setScale(2, RoundingMode.HALF_EVEN));

        } else {

            simulation.setTotalContractNetPrice(simulation.getSackNetPrice()
                    .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                    .setScale(2, RoundingMode.HALF_EVEN));

        }

    }



    /**
     * Method responsible for refreshing the components that are dependent of the Crop field in the Register page.
     *
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void cropValueChanged(final ValueChangeEvent event) {

        if (event != null) {
            if (PhaseId.UPDATE_MODEL_VALUES.equals(event.getPhaseId())) {
                clearSimulationItemsList();

                renderDiffDelivLocationCheckBox = false;
                renderDiffDelivLocationField = false;
                simulation.setDifDeliveryPlace(YesNoList.NO.getFlag());
                simulation.setDescDiffDeliveryPlace(null);

                if (event.getNewValue() != null) {
                    final ICropService cropService = getService(ICropService.class);
                    final Crop crop = new Crop();
                    crop.setId((Long) event.getNewValue());

                    simulation.setCrop(cropService.findById(crop));
                    if (IBarterConstants.CROP_CODE_ZQUI.equalsIgnoreCase(simulation.getCrop().getCropCd())) {
                        renderDiffDelivLocationCheckBox = true;
                    }
                }
            } else {
                event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
                event.queue();
            }
        }
    }

    /**
     * Method responsible for writing the Different Delivery Location checkbox value on the simulation object.
     *
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void diffDelivLocationCheckValueChanged(final ValueChangeEvent event) {

        if (event != null) {
            if (PhaseId.UPDATE_MODEL_VALUES.equals(event.getPhaseId())) {
                simulation.setDescDiffDeliveryPlace(null);

                final boolean diffDelivlocationChecked = event.getNewValue() != null
                        && ((Boolean) event.getNewValue()).booleanValue();

                simulation.setDifDeliveryPlace(diffDelivlocationChecked ? YesNoList.YES.getFlag() : YesNoList.NO
                        .getFlag());
            } else {
                event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
                event.queue();
            }
        }
    }

    /**
     * Method responsible for refreshing the components that are dependent of the Differentiated Delivery Location
     * checkbox in the Register page.
     *
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void barterTypeValueChanged(final ValueChangeEvent event) {

        if (event != null) {
            if (PhaseId.UPDATE_MODEL_VALUES.equals(event.getPhaseId())) {
                renderContractFields = true;

                if (!isContractSelected()) {
                    simulation.setTradingCd(null);
                    tradingList = loadTradingList();
                }
                if (newSale) {
                    simulation.setPaymentCondition(null);
                }

                if (QuoteTypeList.QUOTE.getCod().equals(simulation.getQuotationFlg())) {
                    simulation.setQuotationFlg(null);
                    simulation.getQuotation().getId().setQuotationId(null);
                    quoteFieldsDisabled = false;
                }

                simulation.setBarterType((Character) event.getNewValue());

                this.toggleFieldsRequired();

                paymentConditionList = loadPaymentConditionList();

                if(paymentConditionList.size()==2) {
                    simulation.setPaymentCondition(paymentConditionList.get(1).getValue().toString());
                    resetIncoterms(simulation.getPaymentCondition());
                }
            } else {
                event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
                event.queue();
            }
        }
    }

    public void paymentConditionValueChanged(final ValueChangeEvent event) {
        if (event != null) {

            resetIncoterms(event.getNewValue());

        }
    }
    private void resetIncoterms(Object paymentCondition) {
        if (PaymentConditionList.COMMODITIES_NEGOTIATED.getCod().equals(paymentCondition) || PaymentConditionList.BARTER_B.getCod().equals(paymentCondition)) {
            simulation.getIncoterms().getId().setIncotermsCd(null);
        }
    }

    /**
     * Method responsible for toggle the fields required according with barter type selected and payment condition selected.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void toggleFieldsRequired() {

        this.barterTypeTerms = Boolean.FALSE;
        this.barterTypeWithExistingContract = Boolean.FALSE;
        this.barterTypeMonsantoManagesContract = Boolean.FALSE;
        this.barterTypeGrainAvailable = Boolean.FALSE;

        if (super.hasValue(this.simulation)) {
            if (BarterTypeList.TERMS.getCod().equals(simulation.getBarterType())) {
                this.barterTypeTerms = Boolean.TRUE;
            } else if (BarterTypeList.FUTURE_WITH_EXISTING_CONTRACT.getCod().equals(simulation.getBarterType())) {
                this.barterTypeWithExistingContract = Boolean.TRUE;
            } else if (BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod().equals(simulation.getBarterType())) {
                this.barterTypeMonsantoManagesContract = Boolean.TRUE;
            } else if (BarterTypeList.GRAIN_AVAILABLE.getCod().equals(simulation.getBarterType())) {
                this.barterTypeGrainAvailable = Boolean.TRUE;
            }
        }
    }

    /**
     * Method responsible for refreshing the components that are dependent of the Currency field in the Register page.
     *
     * @param event - Faces value change event
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void currencyValueChanged(final ValueChangeEvent event) {

        if (event != null) {
            if (PhaseId.UPDATE_MODEL_VALUES.equals(event.getPhaseId())) {
                clearSimulationItemsList();

                renderUsdRate = false;
                usdRate = null;

                if (QuoteTypeList.QUOTE.getCod().equals(simulation.getQuotationFlg())) {
                    quoteFieldsDisabled = false;
                    simulation.getQuotation().getId().setQuotationId(null);
                    simulation.setQuotationFlg(null);
                }

                if (hasValue(event.getNewValue())) {
                    loadUsdRate(event.getNewValue().toString());
                } else {
                    calculateConvertedValue();
                }
            } else {
                event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
                event.queue();
            }
        }
    }

    /**
     * Loads the current USD Rate if the chosen Currency is Real.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void loadUsdRate(final String targetCurrencyCode) {

        final String formattedCurrencyCode = targetCurrencyCode;

        if (IBarterConstants.CURRENCY_CODE_DOLLAR.equals(formattedCurrencyCode)) {
            final IPtaxService ptaxService = getService(IPtaxService.class);
            usdRate = ptaxService.convertQuotationOriginToTarget(IBarterConstants.CURRENCY_CODE_DOLLAR,
                    IBarterConstants.CURRENCY_CODE_REAL);
            renderUsdRate = true;
        }
        calculateConvertedValue();
    }

    /**
     * Calculates the Converted Value field.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void calculateConvertedValue() {

        if (hasValue(simulation.getTotalContractNetPrice()) && hasValue(usdRate)) {
            simulation.setConvertedValue(usdRate.multiply(simulation.getTotalContractNetPrice()));
        } else {
            simulation.setConvertedValue(simulation.getTotalContractNetPrice());
        }
        updateTotalItemsValues();
    }

    /**
     * Method that verifies if the Quotation radio button was selected to open the pop-up.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void rbQuotationChanged() {

        if (hasValue(simulation.getQuotationFlg())) {
            if (QuoteTypeList.QUOTE.getCod().equals(simulation.getQuotationFlg().charValue())) {
                openPopUp();
            } else if (QuoteTypeList.MANUAL_PRICE.getCod().equals(simulation.getQuotationFlg().charValue())) {
                quoteFieldsDisabled = false;

                simulation.getQuotation().getId().setQuotationId(null);
            }
        }
    }

    /**
     * Method that loads the Cities list based on the Region field value.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void cboRegionChanged() {

        cityList = loadCityList();
    }

    /**
     * Change event of the combo box of motive of Return or Disapproval.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboMotiveChanged() {
        Integer reasonCode = super.hasValue(simulation.getReturnReasonCode()) ? simulation.getReturnReasonCode() : simulation.getDisapprovalReasonCode();
        if (ReturnReasonList.OTHERS.getCode().equals(reasonCode) || DisapprovalReasonList.OTHERS.getCode().equals(reasonCode)) {
            renderedTxtMotive = true;
        } else {
            renderedTxtMotive = false;
        }
    }

    /**
     * Event of change input text of payment date.
     *
     * @param event
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cldPaymentDateChanged(final ValueChangeEvent event) {

        //clearSimulationItemsList();
        simulation.setPaymentDate((Date) event.getNewValue());
        recalculateItemPrice(event);

    }


    private void recalculateItemPrice(final ValueChangeEvent event) {

        final ISimulationItemService simulationItemService = getService(ISimulationItemService.class);

        for (final SimulationItem item : simulation.getItems()) {

            SimulationItem clone = new SimulationItem();
            item.copyToSimulationItem(clone);

            setItemAmount(clone, simulationItemService);
            clone.setFinalPrice(simulationItemService.calculateFinalPrice(clone));
            clone.setTotalAmount(simulationItemService.calculateTotalAmount(clone));

            if (!simulationItemService.isOk()) {
                simulation.setPaymentDate((Date) event.getOldValue());
                UICalendar calendar = (UICalendar) event.getSource();
                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                calendar.setSubmittedValue(df.format((Date) event.getOldValue()));
                setMessages(simulationItemService.getMessages());
                return;
            }
        }


        for (final SimulationItem item : simulation.getItems()) {
            setItemAmount(item, simulationItemService);
            item.setFinalPrice(simulationItemService.calculateFinalPrice(item));
            item.setTotalAmount(simulationItemService.calculateTotalAmount(item));
        }

        updateTotalItemsValues();

    }

    /**
     * This method contains the country logic to set the item amount.
     *
     * @param simulationItem
     * @param simulationItemService
     * @author Sebastian Kapcitzky
     */
    private void setItemAmount(SimulationItem simulationItem, ISimulationItemService simulationItemService) {

        final IWSSalesPriceSimulateService priceSimulationService = getService(IWSSalesPriceSimulateService.class);

        if (isBarterParaguay()) {
            SalesPriceSimulate salesPriceSimulate = null;
            try {
                salesPriceSimulate = priceSimulationService
                        .getProductInformation(simulation, simulationItem);
            } catch (Exception e) {
                setMessages(new MessageVO("simulation.item.chemical.price.not.found", MessageTypeList.ERROR));
                LOG.error("Communication error, product information could not be retrieved", e);
            }

            if (hasValue(salesPriceSimulate.getProductPrice())) {
                simulationItem.setItemAmount(salesPriceSimulate.getProductPrice());
            }
            if (hasValue(salesPriceSimulate.getWeightUnit())) {
                simulationItem.getProduct().setWeightUnit(salesPriceSimulate.getWeightUnit());
            }
        } else {
            this.simulationItem.setItemAmount(simulationItemService.calculateItemAmount(this.simulationItem));
        }
    }


    /**
     * Clears the Simulation Items list.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void clearSimulationItemsList() {

        if (!isNewer()) {
            for (final SimulationItem item : simulation.getItems()) {
                if (hasValue(item.getId())) {
                    deletedItems.add(item);
                }
            }
        }

        simulation.getItems().clear();
        updateTotalItemsValues();

    }

    /**
     * Method responsible for opening the Quotation pop-up.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void openPopUp() {

        final QuotationFaces quotationFaces = getFaces("quotationFaces");
        final QuotationFilter quotationFilter = new QuotationFilter();

        quotationFilter.setCommodityId(simulation.getCommodityId());
        quotationFilter.setCurrencyCd(simulation.getCurrency().getId().getCurrencyCd());
        if (hasValue(simulation.getTradingCd())) {
            quotationFilter.setTradingId(simulation.getTradingCd());
        }
        quotationFilter.setCountryCd(simulation.getCampaign().getCountry().getId().getCountryCd());
        quotationFilter.setFromSimulation(true);
        quotationFilter.setBarterType(simulation.getBarterType());

        if (BarterTypeList.TERMS.getCod().equals(simulation.getBarterType())) {
            quotationFilter.setTradingCodes(new ArrayList<String>());
            for (final SelectItem trading : tradingList) {
                if (hasValue(trading.getValue())) {
                    quotationFilter.getTradingCodes().add(trading.getValue().toString());
                }
            }
        }

        quotationFilter.setCityCd(simulation.getCity().getId().getCityCd());

        quotationFaces.setQuotationFilter(quotationFilter);
        quotationFaces.search();

        final String message = quotationFaces.getMessages();
        if (hasValue(message)) {
            setMessages(message);
        } else {
            renderedPanelQuotation = true;
        }
    }

    /**
     * Event on click of the command button of include one item.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnIncludeItem() {

        final ISimulationService simulationService = getService(ISimulationService.class);
        if (simulationService.validateRequiredSimulationFieldsForItemsFilled(simulation)) {
            final ItemFaces itemFaces = getFaces(ITEM_FACES_NAME);
            if (itemFaces != null) {
                itemFaces.setEdit(false);
                itemFaces.setSimulation(simulation);
                if (hasValue(simulation.getItems()) && !simulation.getItems().isEmpty()) {
                    itemFaces.initializeSimulationItem();
                    itemFaces.getSimulationItem().getDivision().getId()
                            .setDivisionCd(simulation.getItems().get(0).getDivision().getId().getDivisionCd());
                    itemFaces.getSimulationItem().getDivision().getId().setLanguageCd(loggedUser.getLanguageCd());
                    itemFaces.loadDivision();
                } else {
                    itemFaces.loadDivisions();
                }

                //For paraguay the value must be ZERO by default
                if(isBarterParaguay() && itemFaces.getSimulationItem().getBarterDiscountPct() == null){
                    itemFaces.getSimulationItem().setBarterDiscountPct(new BigDecimal(0));
                }
                renderedPanelItem = true;
            }
        } else {
            setMessages(simulationService.getMessages());
        }
    }

    /**
     * Cancels the simulation item inclusion and close the pop-up.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnCancelIncludeItem() {

        renderedPanelItem = false;
        if (simulationItem != null && simulationItem.getProduct() != null) {
            simulationItem.getProduct().setMaterialNbr(
                    simulationItem.getProduct().getMaterialNbr());
        }
        final ItemFaces itemFaces = getFaces(ITEM_FACES_NAME);
        if (itemFaces != null) {
            itemFaces.clearMessages();
        }
    }

    /**
     * Confirm the simulation item inclusion and close the pop-up.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnConfirmIncludeItem() {

        final ItemFaces itemFaces = super.getFaces(ITEM_FACES_NAME);
        if (itemFaces != null) {
            if (!itemFaces.isOk()) {
                return;
            }
            itemFaces.clearMessages();

            final ISimulationItemService simulationItemService = getService(ISimulationItemService.class);
            final SimulationItem item = itemFaces.getSimulationItem();
            item.setSimulation(simulation);

            simulationItemService.validate(item);
            itemFaces.setMessages(simulationItemService.getMessages());

            if (simulationItemService.isOk()) {
                final IProductService productService = getService(IProductService.class);

                final Product product = new Product();
                product.setMaterialNbr(item.getProduct().getMaterialNbr());
                item.setProduct(productService.findById(product));
                item.setFinalPrice(simulationItemService.calculateFinalPrice(item));
                item.setTotalAmount(simulationItemService.calculateTotalAmount(item));

                if (itemFaces.isEdit()) {
                    item.copyToSimulationItem(simulationItem);
                } else {
                    simulation.getItems().add(item);
                }
                renderedPanelItem = false;
                divisionChemicals = itemFaces.isDivisionChemicals();
                updateTotalItemsValues();
            }
        }
    }

    /**
     * Calculates the values that depends of the simulation items.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void updateTotalItemsValues() {

        if (hasValue(simulation.getItems())) {
            BigDecimal totalGrossItemsValue = BigDecimal.ZERO;
            BigDecimal totalNetItemsBCOBValue = BigDecimal.ZERO;
            BigDecimal totalNetItemsValue = BigDecimal.ZERO;

            for (final SimulationItem item : simulation.getItems()) {

                totalGrossItemsValue = totalGrossItemsValue.add(BigDecimal.valueOf(item.getItemQty()).multiply(
                        item.getItemAmount(), MathContext.DECIMAL128), MathContext.DECIMAL128);

                if ( isBarterParaguay() ){
                    totalNetItemsBCOBValue = totalNetItemsBCOBValue.add(BigDecimal.valueOf(item.getItemQty()).multiply(
                            item.getItemAmount(), MathContext.DECIMAL128), MathContext.DECIMAL128);
                } else {
                    totalNetItemsBCOBValue = totalNetItemsBCOBValue.add(BigDecimal.valueOf(item.getItemQty()).multiply(
                            item.getFinalPriceBCOB(), MathContext.DECIMAL128), MathContext.DECIMAL128);
                }

                totalNetItemsValue = totalNetItemsValue.add(item.getTotalAmount(), MathContext.DECIMAL128);

            }

            simulation.setItemsGrossValue(totalGrossItemsValue);
            simulation.setItemsNetBCOBValue(totalNetItemsBCOBValue);
            simulation.setItemsNetValue(totalNetItemsValue);
            simulation.setVolumeKg(null);

            if (!simulation.getPaymentCondition().equals(PaymentConditionList.BARTER_B.getCod())){
                if (isBarterParaguay()){
                    simulation.setVolumeKg(simulation.getItemsNetValue().divide(simulation.getSackNetPrice(),MathContext.DECIMAL128).
                            setScale(3, RoundingMode.HALF_EVEN));
                } else {
                    calculateVolumeBrazil();
                }
            }
        }
    }

    /**
     * Calculates the total volume for Brazil to show on screen
     */
    private void calculateVolumeBrazil() {
        if (hasValue(unitMeasurement)) {
            BigDecimal unitToKg = null;
            if (unitMeasurement.equals(UnitMeasurementList.ARROBA)) {
                unitToKg = BigDecimal.valueOf(IBarterConstants.ARROBA_WEIGHT);
            } else {
                unitToKg = BigDecimal.valueOf(IBarterConstants.SACK_WEIGHT);
            }

            if (hasValue(simulation.getSackNetPrice())
                    && BigDecimal.ZERO.compareTo(simulation.getSackNetPrice()) < 0) {
                final BigDecimal rate;
                if (hasValue(usdRate) && BigDecimal.ZERO.compareTo(usdRate) < 0) {
                    rate = usdRate;
                } else {
                    rate = BigDecimal.ONE;
                }

                if (YesNoList.YES.getFlag().equals(simulation.getExistingSaleFlg())) {
                    // Use the coverage value only if total invoice "converted" value is greater or equal to the
                    // actual coverage value. If not, use the total invoice "converted" value instead.
                    BigDecimal coverageValue = simulation.getCoverageValue().compareTo(simulation.getTotalInvoiceConvertedValue()) <= 0 ? simulation
                            .getCoverageValue() : simulation.getTotalInvoiceConvertedValue();
                    simulation.setVolumeKg(coverageValue.divide(simulation.getSackNetPrice().multiply(rate, MathContext.DECIMAL128),
                            MathContext.DECIMAL128).multiply(unitToKg, MathContext.DECIMAL128).setScale(3, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setVolumeKg(simulation.getItemsNetValue()
                            .divide(simulation.getSackNetPrice().multiply(rate, MathContext.DECIMAL128), MathContext.DECIMAL128)
                            .multiply(unitToKg, MathContext.DECIMAL128).setScale(3, RoundingMode.HALF_EVEN));
                }
            }
        }
    }

    /**
     * Method that selects the quotation on the pop-up.
     *
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String selectQuotation() {

        simulation.getQuotation().getId().setQuotationId(quotationBusiness.getQuotationId());
        simulation.getQuotation().getId().setTypeCd(quotationBusiness.getTypeCd());
        simulation.getQuotation().getId().setCountryCd(quotationBusiness.getCountryCd());
        simulation.setSackGrossPrice(quotationBusiness.getQuotationValue());
        calculateSackNetPrice();

        simulation.getCity().getId().setCityCd(quotationBusiness.getCityCd());
        simulation.getCity().getId().setRegionCd(quotationBusiness.getRegionCd());
        simulation.getCity().getId().setCountryCd(quotationBusiness.getCountryCd());

        if (!BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod().equals(simulation.getBarterType())) {
            simulation.setTradingCd(quotationBusiness.getTradingCd().trim());
        }

        cityList = loadCityList();

        renderedPanelQuotation = false;
        quoteFieldsDisabled = true;

        return NOT_NAVIGATE;
    }

    /**
     * Method that calculates the Sack Net Price value based on the Sack Gross Price and Incentive %.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void calculateSackNetPrice() {

        simulation.setSackNetPrice(null);
        simulation.setTotalContractGrossPrice(null);
        simulation.setTotalContractNetPrice(null);

        // Sack Net Price = Sack Gross Price * (1 + Incentive %)
        if (simulation.getSackGrossPrice() != null) {
            simulation.setSackNetPrice(simulation.getSackGrossPrice().multiply(
                    BigDecimal.ONE.add(simulation.getIncentivePct() != null ? simulation.getIncentivePct().divide(
                            IBarterConstants.ONE_HUNDRED_DECIMAL, MathContext.DECIMAL128) : BigDecimal.ZERO, MathContext.DECIMAL128), MathContext.DECIMAL128));
        }

        if (hasValue(unitMeasurement) && simulation.getQuantityKg() != null) {
            BigDecimal unitToKg = null;
            if (unitMeasurement.equals(UnitMeasurementList.ARROBA)) {
                unitToKg = BigDecimal.valueOf(IBarterConstants.ARROBA_WEIGHT);
            } else {
                unitToKg = BigDecimal.valueOf(IBarterConstants.SACK_WEIGHT);
            }

            if (simulation.getSackGrossPrice() != null) {

                if ( isBarterParaguay() ){
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                        .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                }
            }
            if (simulation.getSackNetPrice() != null) {

                if ( isBarterParaguay() ){
                    simulation.setTotalContractNetPrice(simulation.getSackNetPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                        .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractNetPrice(simulation.getSackNetPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                }

            }
        }

        calculateConvertedValue();
    }

    /**
     */
    public void calculateSackNetPriceFromNetPrice() {

        simulation.setTotalContractGrossPrice(null);
        simulation.setTotalContractNetPrice(null);

        // Sack Net Price = Sack Net Price (as input by user) * (1 + Incentive %)
        if (simulation.getSackNetPrice() != null) {
            simulation.setSackNetPrice(simulation.getSackNetPrice().multiply(
                    BigDecimal.ONE.add(simulation.getIncentivePct() != null ? simulation.getIncentivePct().divide(
                            BigDecimal.valueOf(100L), MathContext.DECIMAL128) : BigDecimal.ZERO, MathContext.DECIMAL128), MathContext.DECIMAL128));
        }

        if (hasValue(unitMeasurement) && simulation.getQuantityKg() != null) {
            BigDecimal unitToKg = null;
            if (unitMeasurement.equals(UnitMeasurementList.ARROBA)) {
                unitToKg = BigDecimal.valueOf(IBarterConstants.ARROBA_WEIGHT);
            } else {
                unitToKg = BigDecimal.valueOf(IBarterConstants.SACK_WEIGHT);
            }

            if (simulation.getSackGrossPrice() != null) {
                if ( isBarterParaguay() ){
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                        .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                }
            }
            if (simulation.getSackNetPrice() != null) {
                if ( isBarterParaguay() ){
                    simulation.setTotalContractNetPrice(simulation.getSackNetPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                        .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractNetPrice(simulation.getSackNetPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));

                }
            }
        }

        calculateConvertedValue();
    }

    /**
     */
    public void volumeKGChanged() {

        simulation.setTotalContractGrossPrice(null);
        simulation.setTotalContractNetPrice(null);

        if (hasValue(unitMeasurement) && simulation.getQuantityKg() != null) {
            BigDecimal unitToKg = null;
            if (unitMeasurement.equals(UnitMeasurementList.ARROBA)) {
                unitToKg = BigDecimal.valueOf(IBarterConstants.ARROBA_WEIGHT);
            } else {
                unitToKg = BigDecimal.valueOf(IBarterConstants.SACK_WEIGHT);
            }

            if (simulation.getSackGrossPrice() != null) {

                if ( isBarterParaguay() ){
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractGrossPrice(simulation.getSackGrossPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                }

            }
            if (simulation.getSackNetPrice() != null) {
                if ( isBarterParaguay() ){
                simulation.setTotalContractNetPrice(simulation.getSackNetPrice().multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                        .setScale(2, RoundingMode.HALF_EVEN));
                } else {
                    simulation.setTotalContractNetPrice(simulation.getSackNetPrice()
                            .divide(unitToKg, MathContext.DECIMAL128).multiply(simulation.getQuantityKg(), MathContext.DECIMAL128)
                            .setScale(2, RoundingMode.HALF_EVEN));
                }
            }
        }

        calculateConvertedValue();
    }

    /**
     * Recovers the unit of measure to the selected commodity.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void commoditySelected() {

        if (hasValue(simulation.getCommodityId())) {
            final ICommodityService commodityService = getService(ICommodityService.class);
            final Commodity commodityFilter = new Commodity(new CommodityId(
                    simulation.getCommodityId(), simulation.getCampaign().getCountry().getId()
                    .getCountryCd()));
            final Commodity selectedCommodity = commodityService.findById(commodityFilter);
            unitMeasurement = UnitMeasurementList.getByCode(selectedCommodity.getUnitOfMeasure());

            calculateSackNetPrice();
        } else {
            simulation.setTotalContractGrossPrice(null);
            simulation.setTotalContractNetPrice(null);
            unitMeasurement = null;
        }
    }

    /**
     * Method responsible for loading the simulations in the combo.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void loadSimulationNumbers() {

        itemsSimulation = new ArrayList<SelectItem>();

        ISimulationService simulationService = getService(ISimulationService.class);

        List<Simulation> simulations = simulationService.searchSimulationForExistingSale(loggedUser.getCountyCd());

        itemsSimulation.add(new SelectItem(null, getMessage(SELECT)));

        for (Simulation loadedSimulation : simulations) {
            itemsSimulation.add(new SelectItem(loadedSimulation.getSimulationNumber()));
        }

    }

    /**
     * Cancels the Quotation selection and close the pop-up.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void btnCancel() {

        renderedPanelQuotation = false;
        if (!hasValue(simulation.getQuotation())
                || !hasValue(simulation.getQuotation().getId())
                || !hasValue(simulation.getQuotation().getId().getQuotationId())) {
            simulation.setQuotationFlg(null);
        }
    }

    /**
     * Method responsible for calling the Save method from the business layer.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnSave() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            // This call was commented because of Mantis 279566
            //calculateSackNetPrice(null);

            if (isNewer()) {
                final IUserService userService = getService(IUserService.class);

                if (reopen) {
                    final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

                    simulation.setCreateUser(user);
                    simulationService.saveReopenSimulation(simulation);
                } else if (newSale) {
                    simulationService.save(simulation);
                } else {
                    final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

                    simulation.setCreateUser(user);
                    simulationService.saveExistingSaleSimulation(simulation);
                }
            } else if (newSale && !reopen && !simulationSearchList) {
                simulationService.update(simulation, deletedItems);
            } else {
                simulationService.update(simulation);
            }

            setMessages(simulationService);

            if (simulationService.isOk()) {
                loadSimulationSearchScreen();
            } else {
                for (final MessageVO message : simulationService.getMessages()) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        this.simulation = simulationService.findByIdComplete(simulation);

                        newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
                        reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());
                        fillInitialSimulationValues();
                        break;
                    }
                }
                return NOT_NAVIGATE;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }

        return CANCEL;
    }

    /**
     * Save functionality, calls the business layer and makes the data validations
     *
     * @return A string that defines the page navigation
     * @author Sebastian Kapcitzky
     */
    public String btnSaveContracts() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            if ((contractNumberChecked || !isContractEdition())) {
                simulationService.updateContracts(simulation, contractsToDelete);
            } else {
                setMessages(new MessageVO("simulation.list.detail.contract.number.no.checked", MessageTypeList.ERROR));
                return NOT_NAVIGATE;
            }
            setMessages(simulationService.getMessages());

            if (simulationService.isOk()) {
                editContractsIds.clear();
                contractsToDelete.clear();
                simulationContractSelected = null;
                setContractNumberChecked(false);
                //Refreshes the list result
                btnSearch();
                drpWhitepaperChanged();
                return SUCCESS;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            setContractNumberChecked(false);
            return NOT_NAVIGATE;
        }

        return CANCEL;
    }

    /**
     * Checks if the contract is beeing updated or is a new one
     * @author Sebastian Kapcitzky
     * @return true if the contract exists and the user is editing it
     */
    private boolean isContractEdition() {
        for (BarterContract contract : simulation.getBarterContracts()){
            if (!hasValue(contract.getId())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Updates Barter Contract legal approval
     *
     * @author Sebastian Kapcitzky
     */
    public void
    updateContractLegalApproval(){
        final ISimulationService simulationService = getService(ISimulationService.class);

        try{
            if (!isEditContract()) {
                simulationService.updateContractSelected(simulationContractSelected);
                setMessages(simulationService);
            }
            else if (isEditContract() && !contractNumberChecked){
                setMessages(new MessageVO("simulation.list.detail.contract.number.no.checked", MessageTypeList.ERROR));

            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return;
    }

    /**
     * Method responsible for sending the simulation to approval.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnSendApproval() {

        sendApprovalMessages = new ArrayList<MessageVO>();
        renderedPanelTermsFormalization = false;
        renderPanelSignature = false;
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            // This call was commented because of Mantis 279566
            //calculateSackNetPrice(null);

            if (reopen) {
                if (isNewer()) {
                    final IUserService userService = getService(IUserService.class);
                    final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

                    simulation.setCreateUser(user);
                }
                simulationService.sendApprovalReopenSimulation(simulation);
            } else if (isNewer() && newSale) {
                simulationService.sendApprovalNewSimulation(simulation);
            } else {
                if (deletedItems == null) {
                    deletedItems = new ArrayList<SimulationItem>();
                }
                if (isNewer()) {
                    final IUserService userService = getService(IUserService.class);
                    final User user = userService.findByIdWithPermissionAndHistory(new User(loggedUser.getId()));

                    simulation.setCreateUser(user);
                    if (simulation.getInvoices() != null) {
                        for (final InvoiceSimulation invoice : simulation.getInvoices()) {
                            invoice.setId(null);
                        }
                    }
                }
                simulationService.sendApprovalEditSimulation(simulation, deletedItems);
            }

            if (simulationService.isOk()) {
                sendApprovalMessages.addAll(simulationService.getMessages());
            } else {
                setMessages(simulationService);

                for (final MessageVO message : simulationService.getMessages()) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        this.simulation = simulationService.findByIdComplete(simulation);

                        newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
                        reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());
                        if ( !isBarterParaguay() ){
                        renderPrintButton = !BarterTypeList.TERMS.getCod().equals(this.simulation.getBarterType())
                                && newSale && !isEditable();
                        } else {
                            renderPrintButton = false;
                        }

                        fillInitialSimulationValues();
                        verifyValidateSimulationPermissions();
                        break;
                    }
                }

                if (!hasValue(simulation.getAgent())) {
                    simulation.setAgent(new PartnerYa());
                }
                return NOT_NAVIGATE;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }
        setMessages(sendApprovalMessages);
        sendApprovalMessages = null;

        loadSimulationSearchScreen();

        return CANCEL;
    }

    /**
     * Opens the signature popup.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnOpenPrintPopup() {

        sendApprovalMessages = new ArrayList<MessageVO>();
        if (  !isBarterParaguay() ) {
            if (newSale && !BarterTypeList.TERMS.getCod().equals(simulation.getBarterType())) {
                renderPopupFormalizationPrint = true;
                return NOT_NAVIGATE;
            }
        }

        return btnSendApproval();
    }

    /**
     * Closes the signature popup.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void btnCloseSignaturePopup() {
        renderedPanelTermsFormalization = false;
        renderPanelSignature = false;
        sendApprovalMessages = null;

        final List<MessageVO> message = new ArrayList<MessageVO>();
        message.add(new MessageVO("simulation.provide.formalization.term.signature", MessageTypeList.ERROR));
        setMessages(message);
    }

    /**
     * Closes the print popup and returns to the Search page.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void btnClosePrintPopup() {
        renderPopupFormalizationPrint = false;
        renderPanelSignature = true;
    }

    /**
     * Method responsible for starting the register page in edit mode.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnEdit() {

        setNewer(false);
        setDetail(false);

        if (deletedItems == null) {
            deletedItems = new ArrayList<SimulationItem>();
        } else {
            deletedItems.clear();
        }

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            this.simulation = simulationService.findByIdComplete(simulationFilter);

            setMessages(simulationService);
            if (!simulationService.isOk()) {
                return NOT_NAVIGATE;
            }

            newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
            reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());
            fillInitialSimulationValues();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }

        return CHANGE;
    }

    /**
     * Method responsible for starting the register page in reopen mode.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnReopen() {

        setNewer(true);
        setDetail(false);

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            this.simulation = simulationService.findByIdComplete(simulationFilter);

            if (simulationService.isOk() && simulationService.canReopen(this.simulation)) {
                    newSale = true;
                    reopen = true;
                    this.simulation.setReopenFlg(YesNoList.YES.getFlag());
                    this.simulation.setStatusCd(SimulationStatusList.REOPENED.getCod());
                    fillInitialSimulationValues();

                    return CHANGE;
                }

            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method that cancels the current simulation register.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnCancelSimulation() {

        loadSimulationSearchScreen();

        return CANCEL;
    }

    /**
     * Method responsible for calling the Delete method from the business layer.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnDelete() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            this.simulation = simulationService.findByIdComplete(simulationFilter);

            if (simulationService.isOk()) {
                simulationService.delete(this.simulation);
            }

            setMessages(simulationService);
            simulationList = simulationService.search(filter);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for starting the register page in detail mode.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnDetail() {

        setNewer(false);
        setDetail(true);

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            this.simulation = simulationService.findByIdComplete(simulationFilter);

            setMessages(simulationService);
            if (!simulationService.isOk()) {
                return NOT_NAVIGATE;
            }

            newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
            reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());

            if ( ! isBarterParaguay() ){
                renderPrintButton = !BarterTypeList.TERMS.getCod().equals(this.simulation.getBarterType())
                    && newSale && !isEditable();
            } else {
                renderPrintButton = false;
            }

            fillInitialSimulationValues();
            verifyValidateSimulationPermissions();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }

        return CHANGE;
    }

    /**
     * Method that verifies if the validate simulation buttons will be rendered.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void verifyValidateSimulationPermissions() {

        renderApproveButton = (SimulationStatusList.PENDING_APPROVAL.getCod().equals(simulation.getStatusCd())
                || SimulationStatusList.WAITING_APPROVAL.getCod().equals(simulation.getStatusCd()))
                && access(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd())
                && !simulation.getCreateUser().getId().equalsIgnoreCase(loggedUser.getId());
        renderReturnButton = (SimulationStatusList.PENDING_APPROVAL.getCod().equals(simulation.getStatusCd()))
                && access(PermissionList.RETURN_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        renderDisapproveButton = (SimulationStatusList.PENDING_APPROVAL.getCod().equals(simulation.getStatusCd())
                || SimulationStatusList.WAITING_APPROVAL.getCod().equals(simulation.getStatusCd()))
                && access(PermissionList.DISAPPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        renderVerifySaleOrderButton = (SimulationStatusList.WAITING_SO.getCod().equals(simulation.getStatusCd()))
                && access(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
    }

    /**
     * Method responsible for the action to open popup of print of terms of formalization.
     *
     * @return A string that defines the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String btnPrintTerms() {

        renderPopupFormalizationPrint = false;

        final IFormalizationTermService formalizationTermService = getService(IFormalizationTermService.class);

        final FormalizationTermFilter formalizationTermFilter = new FormalizationTermFilter();
        formalizationTermFilter.setLanguage(loggedUser.getLanguageCd().toString());
        formalizationTermFilter.setValidateRegisteredTemplate(true);

        template = formalizationTermService.searchByLanguage(formalizationTermFilter);

        if (formalizationTermService.isOk()) {
            renderedPanelTermsFormalization = true;
        } else {
            if (sendApprovalMessages == null) {
                setMessages(formalizationTermService);
            } else {
                sendApprovalMessages.addAll(formalizationTermService.getMessages());
                setMessages(sendApprovalMessages);
                sendApprovalMessages = null;

                loadSimulationSearchScreen();

                return CANCEL;
            }
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for the action of cancel of print of terms of formalization.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnCancelGenerateTermsFormalization() {

        renderedPanelTermsFormalization = false;
        renderPanelSignature = true;
        formalizationTermBusiness = new FormalizationTermBusiness();

    }

    /**
     * Generate terms formalization.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public void btnConfirmGenerateTermsFormalization(ActionEvent event) {
        streamPDFFile = null;
        try {
            final IFormalizationTermService formalizationTermService = getService(IFormalizationTermService.class);
            formalizationTermBusiness.setSimulation(simulation);

            final List<FormalizationTermBusiness> relFormalizationList = formalizationTermService.buildFormalizationTerm(
                    template, formalizationTermBusiness);

            if (formalizationTermService.isOk()) {
                renderedPanelTermsFormalization = false;
                renderPanelSignature = true;
                streamPDFFile = exportToOutputStream("termFormalizacao3.5.2.jasper", relFormalizationList);
                //exportReport("termFormalizacao3.5.2.jasper", relFormalizationList);
            }

            if (sendApprovalMessages == null) {
                setMessages(formalizationTermService.getMessages());
            } else {
                sendApprovalMessages.addAll(formalizationTermService.getMessages());
                setMessages(sendApprovalMessages);
                sendApprovalMessages = null;
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        formalizationTermBusiness = new FormalizationTermBusiness();

    }


    public void btnDownloadPDFTermsFormalization() {
        if (streamPDFFile != null) {
            downloadFile("termFormalizacao3.5.2.jasper", streamPDFFile);
        }

    }

    /**
     * Method that returns for page previous.
     *
     * @return A string that defines the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String btnGoBack() {

        String goPage = CANCEL;

        if ((fromContract || simulationSearchList) && isEditContract() || //Contract added or removed
                (simulationSearchList && !(barterContracts.getRowCount() == simulationList.size()))) {
            super.setDetail(false);
            //Updates total values in list
            for (SimulationBusiness simulation : simulationList) {
                if (simulation.getSimulationNumber().equals(this.simulation.getSimulationNumber())) {
                    simulation.setBarterContracts(this.simulation.getBarterContracts());
                }
                calculateListTotalAmounts(simulation);
                drpWhitepaperChanged();
            }
            goPage = BACK;
        } else {
            loadSimulationSearchScreen();
        }

        return goPage;
    }

    /**
     * Reloads the register page after printing the Formalization Term.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public void btnHiddenTermFormalization() {

        renderedPanelTermsFormalization = false;
        renderPanelSignature = true;
    }

    /**
     * Method responsible for starting the register page in visualization mode starting of trading contract page.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void visualizeSimulation() {

        super.setNewer(false);
        super.setDetail(true);
        final Boolean newSaleFlag = getParameterBoolean("isNewSale");
        if (newSaleFlag != null) {
            this.newSale = newSaleFlag;
        }

        final ISimulationService simulationService = getService(ISimulationService.class);
        final Simulation simulationFilter = new Simulation();
        simulationFilter.setSimulationNumber(this.simulationSelected.getSimulationNumber());
        this.simulation = simulationService.findByIdComplete(simulationFilter);
        fillInitialSimulationValues();
    }

    /**
     * Searchs the invoices for the selected Simulation.
     *
     * @author Alexandre Araujo e Silva (araujo.alexandre@cpmbraxis.com)
     */
    public void searchInvoices() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            final Simulation simulationResult = simulationService.findByIdComplete(this.simulation);

            if (simulationService.isOk()) {
                final InvoiceSimulationBusiness invoiceBusiness = simulationService.searchInvoices(simulationResult);
                if (hasValue(invoiceBusiness)) {
                    invoiceList = invoiceBusiness.getInvoices();
                    this.simulation.setCoverageValue(invoiceBusiness.getCoverageValue());
                    this.simulation.setCoverageGrossValue(invoiceBusiness.getCoverageGrossValue());

                    if (invoiceList != null) {
                        BigDecimal totalInvoice = BigDecimal.ZERO;
                        BigDecimal totalConvertedInvoice = BigDecimal.ZERO;
                        for (final InvoiceSimulation invoice : invoiceList) {
                            totalInvoice = totalInvoice.add(invoice.getAmountLocalCurrency(), MathContext.DECIMAL128);
                            totalConvertedInvoice = totalConvertedInvoice.add(invoice.getConvertedValue(), MathContext.DECIMAL128);
                        }

                        this.simulation.setTotalInvoiceValue(totalInvoice);
                        this.simulation.setTotalInvoiceConvertedValue(totalConvertedInvoice);
                    }
                }
            }

            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method that loads the choosen simulation and redirects to the next page in the simulation register.
     *
     * @return A string that defines the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnContinueInvoice() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation returnedSimulation = simulationService.findByIdComplete(simulation);
            if (simulationService.isOk()) {
                returnedSimulation.setCoverageValue(simulation.getCoverageValue());
                returnedSimulation.setCoverageGrossValue(simulation.getCoverageGrossValue());
                returnedSimulation.setTotalInvoiceValue(simulation.getTotalInvoiceValue());
                returnedSimulation.setTotalInvoiceConvertedValue(simulation.getTotalInvoiceConvertedValue());
                simulation = returnedSimulation;
                simulation.setStatusCd(SimulationStatusList.DRAFT.getCod());
                simulation.setExistingSaleFlg(YesNoList.YES.getFlag());
                simulation.setBarterType(null);
                simulation.setInvoices(invoiceList);

                fillInitialSimulationValues();

                return SUCCESS;
            }

            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for the action to give back or disapprove the simulation.
     *
     * @return A string that defines the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String returnDisapproveSimulation() {

        String goPage = NOT_NAVIGATE;
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            simulationService.validateIncludeReason(simulation);

            if (simulationService.isOk()) {

                if (super.hasValue(simulation.getReturnReasonCode())) {

                    simulationService.returnSimulation(simulation);
                } else if (super.hasValue(simulation.getDisapprovalReasonCode())) {
                    simulationService.disapproveSimulation(simulation);
                }

                if (simulationService.isOk()) {
                    renderedTxtMotive = false;
                    loadSimulationSearchScreen();
                    goPage = CANCEL;
                } else {
                    for (final MessageVO message : simulationService.getMessages()) {
                        if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                            this.simulation = simulationService.findByIdComplete(simulation);

                            newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
                            reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());
                            if ( !isBarterParaguay() ){
                                renderPrintButton = !BarterTypeList.TERMS.getCod().equals(this.simulation.getBarterType())
                                    && newSale && !isEditable();
                            } else {
                                renderPrintButton = false;
                            }

                            fillInitialSimulationValues();
                            verifyValidateSimulationPermissions();
                            break;
                        }
                    }
                }
            }
            setMessages(simulationService);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return goPage;
    }

    /**
     * Method responsible for loading the values of some fields in the Detail page.
     *
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private void loadDetailFields() {

        final IMktCampaignService mktCampaignService = getService(IMktCampaignService.class);
        final ITradingService tradingService = getService(ITradingService.class);
        final ICommodityService commodityService = getService(ICommodityService.class);

        // Loading MKT Campaign description.
        if (hasValue(simulation.getCustGroup5())) {
            final MktCampaignFilter mktCampaignFilter = new MktCampaignFilter();
            mktCampaignFilter.setCustGroup5(simulation.getCustGroup5());
            mktCampaignFilter.setActiveDate(new Date());

            final List<MktCampaign> mktCampaignListResults = mktCampaignService.search(mktCampaignFilter);
            if (!mktCampaignListResults.isEmpty()) {
                final MktCampaign mktCampaign = mktCampaignListResults.get(0);

                if (hasValue(mktCampaign.getId().getCustGroup5())) {
                    mktCampaignDesc = mktCampaign.getId().getCustGroup5().concat(IBarterConstants.HYPHEN)
                            .concat(mktCampaign.getCampaignDesc());
                }
            }
        }

        // Loading Trading description.
        final Trading trading = tradingService.findById(new Trading(new TradingId(simulation.getTradingCd(), simulation.getCampaign().getCountry().getId().getCountryCd())));

        if (hasValue(trading)) {
            tradingDesc = trading.getDescTrading();
        }

        // Loading Commodity description.
        final Commodity commodityResult = commodityService.findById(new Commodity(new CommodityId(
                simulation.getCommodityId(), simulation.getCampaign().getCountry().getId().getCountryCd())));

        if (hasValue(commodityResult)) {
            commodityDesc = commodityResult.getDescCommodity();
        }
    }

    /**
     * Sends the simulation to approval on SAP.
     *
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnApprove() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            if (!simulation.getPaymentCondition().equals(PaymentConditionList.BARTER_B.getCod()) && isBarterParaguay()){
                if (simulation.getBarterContracts().isEmpty()){
                    setMessages(new MessageVO("simulation.barter.no.contract", MessageTypeList.ERROR));
                    return NOT_NAVIGATE;
                } else{
                    BigDecimal totalBarterContractsAmount = BigDecimal.ZERO;
                    for (BarterContract barterContract : simulation.getBarterContracts()){
                        if (barterContract.getLegalApproval()){
                            totalBarterContractsAmount = totalBarterContractsAmount.add(barterContract.getTotalCntrctGrossPrice());
                        }
                    }
                    if (totalBarterContractsAmount.compareTo(simulation.getItemsNetValue()) == 1) {
                        setMessages(new MessageVO("simulation.barter.contract.not.approved", MessageTypeList.ERROR));
                        return NOT_NAVIGATE;
                    }
                }
            }

            simulationService.approveSimulation(simulation);
            setMessages(simulationService);
            if (simulationService.isOk()) {
                loadSimulationSearchScreen();
                return CANCEL;
            } else {
                for (final MessageVO message : simulationService.getMessages()) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        this.simulation = simulationService.findByIdComplete(simulation);

                        newSale = !YesNoList.YES.getFlag().equals(this.simulation.getExistingSaleFlg());
                        reopen = YesNoList.YES.getFlag().equals(this.simulation.getReopenFlg());

                        if ( ! isBarterParaguay() ){
                            renderPrintButton = !BarterTypeList.TERMS.getCod().equals(this.simulation.getBarterType())
                                && newSale && !isEditable();
                        } else {
                                renderPrintButton = false;
                        }


                        fillInitialSimulationValues();
                        verifyValidateSimulationPermissions();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }

    /**
     * Verifies if the simulation already received a sale order number.
     *
     * @return A string defining the page navigation
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    public String btnVerifySaleOrder() {

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            simulationService.verifySaleOrder(simulation);
            setMessages(simulationService);

            for (final MessageVO message : simulationService.getMessages()) {
                if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                    this.simulation = simulationService.findByIdComplete(simulation);
                    fillInitialSimulationValues();
                    break;
                }
            }

            verifyValidateSimulationPermissions();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return NOT_NAVIGATE;
    }


    /**
     * Checks if the authenticated user has access permission for the Detailed Simulation List screen
     *
     * @return A string defining the page navigation
     * @author Sebastian Kapcitzky
     */
    public String simulationSearchList() {
        log("simulationSearchList");
        init();
        fromContract = false;
        simulationSearchList = true;
        loadSimulationSearchScreen();
        loadSimulationNumbers();

        return SUCCESS;
    }

    /**
     * Checks if the authenticated user has access permission for the Detailed Simulation Edit screen
     *
     * @return A string defining the page navigation
     * @author Sebastian Kapcitzky
     */
    public String btnShowDetails() {
        fromContract = false;
        simulationSearchList = true;
        super.setDetail(true);
        editContractsIds = new ArrayList<Long>();
        contractsToDelete = new ArrayList<BarterContract>();
        simulationContractSelected = null;

        setNewer(false);

        try {
            final ISimulationService simulationService = getService(ISimulationService.class);

            final Simulation simulationFilter = new Simulation();
            simulationFilter.setSimulationNumber(simulationSelected.getSimulationNumber());
            this.simulation = simulationService.findByIdComplete(simulationFilter);

            setMessages(simulationService);
            if (!simulationService.isOk()) {
                return NOT_NAVIGATE;
            }

            //Initializes the contract list in case there is no contracts
            if (!hasValue(simulation.getBarterContracts())) {
                simulation.setBarterContracts(new ArrayList<BarterContract>());
            } else {
                tradingList = loadTradingListForCampaign();
                //paymentConditionList = loadPaymentConditionList();
                commodityList = loadCommodityList();
                calculateTotalAmounts();
            }

            barterContracts = new ListDataModel<BarterContract>(simulation.getBarterContracts());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }

        return SUCCESS;
    }

    /**
     * Event on click of the command button of include a new contract
     *
     * @author Sebastian Kapcitzky
     */
    public String btnIncludeContract() {
        if (!hasValue(simulationContractSelected)){
                BarterContract contract = new BarterContract();
                contract.setPaymentCondition(simulation.getPaymentCondition());
                simulation.getBarterContracts().add(contract);
                simulationContractSelected = contract;
            if (!hasValue(tradingList) || tradingList.isEmpty()) {
                tradingList = loadTradingListForCampaign();
            }
            if (!hasValue(commodityList) || commodityList.isEmpty()) {
                commodityList = loadCommodityList();
            }
            return SUCCESS;
        } else {
            setMessages(new MessageVO("simulation.list.detail.edit.error", MessageTypeList.ERROR));
            return NOT_NAVIGATE;
    }
    }

    /**
     * Method responsible for generating file upload lines
     *
     * @author Sanjeev Kumar
     */

    public String prepareContractFileUploadForm() {
        LOG.debug("In ContractFileUploadForm");
        renderAttachmentPopup = false;
        filesAttachedSuccessfully = false;

        try {
            contractFileUploadHandlers.clear();

            //By default 5 files to upload
            for (int i = 0; i < 5; i++) {
                addContractFileUploadHandler();
            }

            if(isDetail()) {
                contractAttachments = simulationContractSelected.getAttachments();
            }else {
                final ISimulationService simulationService = getService(ISimulationService.class);
                contractAttachments = simulationService.findBarterContractById(simulationContractSelected).getAttachments();
                setMessages(simulationService);
            }

            renderAttachmentPopup = true;
            return SUCCESS;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }
    }

    /**
     * Method responsible for attaching files to contract
     *
     * @author Sanjeev Kumar
     */
    public void attachContractFiles() {
        log("In attachFiles ");
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            if (isValidAttachments()) {
                for (FileUpload fileUploadHandler : contractFileUploadHandlers) {
                    if (fileUploadHandler.getFile() != null) {
                        BarContractAttachment attachment = new BarContractAttachment(fileUploadHandler.getFile());
                        contractAttachments.add(attachment);
                    }
                }

                //If the contract is already persisted then saving the attachments to the db
                if(hasValue(simulationContractSelected.getId())){
                    simulationService.updateContractAttachments(simulationContractSelected);
                    setMessages(simulationService);
                }

                if (simulationService.isOk()) {
                    filesAttachedSuccessfully = true;
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for deleting the attachment
     *
     * @author Pragathi
     */
    public void deleteContractAttachment() {
        try {
            final ISimulationService simulationService = getService(ISimulationService.class);
            simulationService.deleteContractAttachment(contractAttachmentSelected);

            setMessages(simulationService);

            if (simulationService.isOk()) {
                contractAttachments.remove(contractAttachmentSelected);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    public StreamedContent getContractFile() {
        return new DefaultStreamedContent(new ByteArrayInputStream(contractAttachmentSelected.getFile().getFileContent()),
                contractAttachmentSelected.getFile().getMimeType(), contractAttachmentSelected.getFile().getFileName());
    }

    public String addContractToRemove(){
        contractsToDelete.add(simulationContractSelected);
        simulation.getBarterContracts().remove(simulationContractSelected);
        calculateTotalAmounts();
        setSimulationContractSelected(null);

        return NOT_NAVIGATE;
    }

    public String editSimulationContract(){
        editContractsIds.add(simulationContractSelected.getId());
        if (simulationContractSelected.getCommodity() == null){
            simulationContractSelected.setCommodity(new Commodity());
            simulationContractSelected.getCommodity().setId(new CommodityId());
        }
        if (simulationContractSelected.getTrading() == null){
            simulationContractSelected.setTrading(new Trading());
            simulationContractSelected.getTrading().setId(new TradingId());
        }
        setSimulationContractSelected(null);
        return NOT_NAVIGATE;
    }


    public boolean isEditContract() {
        if (!editContractsIds.isEmpty() && barterContracts.isRowAvailable() &&
                editContractsIds.contains(barterContracts.getRowData().getId())) {
            return true;
        }
        return false;
    }

    /**
     * Verify if the simulation is editable.
     *
     * @return true if is editable, false otherwise
     * @author Rodrigo Dias Costa (rodrigo.dcosta@cpmbraxis.com)
     */
    private boolean isEditable() {

        return SimulationStatusList.DRAFT.getCod().equals(simulation.getStatusCd())
                || SimulationStatusList.REOPENED.getCod().equals(simulation.getStatusCd())
                || SimulationStatusList.RETURNED.getCod().equals(simulation.getStatusCd());
    }

    /**
     * Method responsible of fetching all the table data from the actual search and create a SpreadSheet to download.
     * @author Sebastian Kapcitzky
     */
    public void exportToSpreadSheet() {

        FacesContext fc = FacesContext.getCurrentInstance();
        ExternalContext ec = fc.getExternalContext();
        HSSFWorkbook workbook = new HSSFWorkbook();
        fillExportData(workbook);

        //Simulation Header Style
        addStyleToHeader(workbook);
        addBordersToCells(workbook);
        adjustColumnSize(workbook.getSheetAt(0));

        ec.responseReset();
        ec.setResponseContentType("application/vnd.ms-excel");
        ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + exportFileName +
                (new SimpleDateFormat("yyyy.MM.dd_HH.mm.ss").format(new Date())) + "\".xls");
        try {
            workbook.write(ec.getResponseOutputStream());
        } catch (IOException e) {
            setMessages(new MessageVO(getMessage("simulation.list.detail.export.error"), MessageTypeList.ERROR));
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        fc.responseComplete();
    }

    /**
     * Fills the data to be downloaded.
     * @author Sebastian Kapcitzky
     */
    private Workbook fillExportData(HSSFWorkbook workbook) {
        HSSFSheet sheet = workbook.createSheet(getMessage("menu.orders.simulation.list"));
        Header header = sheet.getHeader();
        header.setLeft(getMessage("menu.orders.simulation.list"));

        int rowIndex = 0;
        int simulationIndex = 1;

        HSSFCellStyle headerStyle = workbook.createCellStyle();
        Font fontHeader = workbook.createFont();
        fontHeader.setBoldweight(Font.BOLDWEIGHT_BOLD);
        headerStyle.setFont(fontHeader);

        HSSFCellStyle subHeaderStyle = workbook.createCellStyle();
        Font fontSubHeader = workbook.createFont();
        fontSubHeader.setItalic(true);
        headerStyle.setFont(fontSubHeader);

        //Sets the Headings of the Columns

        HSSFRow row = sheet.createRow(rowIndex++);

        HSSFCell cell0 = row.createCell(0);
        cell0.setCellValue("#");
        cell0.setCellStyle(headerStyle);

        HSSFCell cell1 = row.createCell(1);
        cell1.setCellValue(getMessage("simulation.list.result.simulation.number"));
        cell1.setCellStyle(headerStyle);

        HSSFCell cell2 = row.createCell(2);
        cell2.setCellValue(getMessage("simulation.list.result.campaign"));
        cell2.setCellStyle(headerStyle);

        HSSFCell cell3 = row.createCell(3);
        cell3.setCellValue(getMessage("simulation.list.result.total.tons"));
        cell3.setCellStyle(headerStyle);

        HSSFCell cell4 = row.createCell(4);
        cell4.setCellValue(getMessage("simulation.list.result.total.amount"));
        cell4.setCellStyle(headerStyle);

        HSSFCell cell5 = row.createCell(5);
        cell5.setCellValue(getMessage("simulation.list.result.total.barter.amount"));
        cell5.setCellStyle(headerStyle);

        HSSFCell cell6 = row.createCell(6);
        cell6.setCellValue(getMessage("simulation.list.result.currency"));
        cell6.setCellStyle(headerStyle);

        //Iterates the datatable
        for (SimulationBusiness simulation : this.simulationList){

            row = sheet.createRow(rowIndex++);
            int columnIndex = 0;

            row.createCell(columnIndex++).setCellValue(simulationIndex);
            row.createCell(columnIndex++).setCellValue(simulation.getSimulationNumber());
            row.createCell(columnIndex++).setCellValue(simulation.getQuantityKg().toString());
            row.createCell(columnIndex++).setCellValue(simulation.getTotalContractGrossPrice().toString());
            row.createCell(columnIndex++).setCellValue(simulation.getTotalBarterTons().toString());
            row.createCell(columnIndex++).setCellValue(simulation.getTotalBarterAmount().toString());
            row.createCell(columnIndex++).setCellValue(simulation.getCurrencyCd());

            //Barter Contracts
            if (!simulation.getBarterContracts().isEmpty()){
                //Headings

                row = sheet.createRow(rowIndex);

                row.createCell(0).setCellValue("");
                row.createCell(1).setCellValue("");

                HSSFCell cellContract0 = row.createCell(2);
                cellContract0.setCellValue(getMessage("simulation.list.detail.contract.number"));
                cellContract0.setCellStyle(subHeaderStyle);

                HSSFCell cellContract2 = row.createCell(3);
                cellContract2.setCellValue(getMessage("simulation.list.detail.tons"));
                cellContract2.setCellStyle(subHeaderStyle);

                HSSFCell cellContract4 = row.createCell(4);
                cellContract4.setCellValue(getMessage("simulation.list.detail.amount"));
                cellContract4.setCellStyle(subHeaderStyle);

                HSSFCell cellContract5 = row.createCell(5);
                cellContract5.setCellValue(getMessage("simulation.list.detail.commodity"));
                cellContract5.setCellStyle(subHeaderStyle);

                HSSFCell cellContract6 = row.createCell(6);
                cellContract6.setCellValue(getMessage("simulation.list.detail.delivered.quantity"));
                cellContract6.setCellStyle(subHeaderStyle);

                HSSFCell cellContract7 = row.createCell(7);
                cellContract7.setCellValue(getMessage("simulation.list.detail.trader"));
                cellContract7.setCellStyle(subHeaderStyle);

                HSSFCell cellContract8 = row.createCell(8);
                cellContract8.setCellValue(getMessage("simulation.list.detail.payment.condition"));
                cellContract8.setCellStyle(subHeaderStyle);

                HSSFCell cellContract9 = row.createCell(9);
                cellContract9.setCellValue(getMessage("simulation.list.detail.price.per.ton"));
                cellContract9.setCellStyle(subHeaderStyle);

                HSSFCell cellContract10 = row.createCell(10);
                cellContract10.setCellValue(getMessage("simulation.list.detail.legal.team.approval"));
                cellContract10.setCellStyle(subHeaderStyle);

                for (BarterContract contract : simulation.getBarterContracts()){
                    row = sheet.createRow(++rowIndex);
                    int contractColumnIndex = 0;

                    row.createCell(contractColumnIndex++).setCellValue("");
                    row.createCell(contractColumnIndex++).setCellValue("");
                    row.createCell(contractColumnIndex++).setCellValue(contract.getCntrctNbr().toString());
                    row.createCell(contractColumnIndex++).setCellValue(contract.getQtyKg().toString());
                    row.createCell(contractColumnIndex++).setCellValue(contract.getTotalCntrctGrossPrice().toString());
                    row.createCell(contractColumnIndex++).setCellValue(hasValue(contract.getCommodity()) ?
                            contract.getCommodity().getDescCommodity() : " ");
                    row.createCell(contractColumnIndex++).setCellValue(contract.getDeliveredQuantity().toString());
                    row.createCell(contractColumnIndex++).setCellValue(hasValue(contract.getTrading()) ?
                            contract.getTrading().getDescTrading() : " ");
                    row.createCell(contractColumnIndex++).setCellValue(contract.getPaymentCondition());
                    row.createCell(contractColumnIndex++).setCellValue(contract.getPricePerTon().toString());
                    row.createCell(contractColumnIndex++).setCellValue(contract.getLegalApproval() ?
                            getMessage(BarterContractStatusList.getByCod("OK").getDescription()) :
                            getMessage(BarterContractStatusList.getByCod("PA").getDescription()));
                }
                rowIndex++;
            }
            simulationIndex++;
        }

        return workbook;
    }

    private void addStyleToHeader(HSSFWorkbook wb){
        HSSFCellStyle cellStyle = wb.createCellStyle();
        HSSFSheet sheet = wb.getSheetAt(0);
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);

        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(HSSFColor.OLIVE_GREEN.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFRow header = sheet.getRow(0);
        for(int i=0; i < header.getPhysicalNumberOfCells();i++) {
            HSSFCell cell = header.getCell(i);
            cell.setCellStyle(cellStyle);
        }
    }


    private void addBordersToCells(HSSFWorkbook wb){
        HSSFSheet sheet = wb.getSheetAt(0);
        for(int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++){
            HSSFRow row = sheet.getRow(rowIndex);
            if (row != null) {
                for (Cell cell : row) {
                    if (hasValue(cell)){
                        HSSFCellStyle cellStyle = wb.createCellStyle();
                        cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
                        cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                        cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                        cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                        cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                        cell.setCellStyle(cellStyle);
                    }
                }
            }
        }
    }


    private void adjustColumnSize(HSSFSheet sheet){
        for(int i = 0; i <= MAX_COLUMNS_SIZE; i++){
            sheet.autoSizeColumn(i);
        }
    }


  /*  private void createFooter(HSSFWorkbook wb) {
        HSSFSheet sheet = wb.getSheetAt(0);
        int newRow = sheet.getLastRowNum() + 2;
        HSSFCellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        HSSFRow row = sheet.createRow(newRow);
        HSSFCell cell0 = row.createCell(0);
        HSSFCell cell1 = row.createCell(1);

        cell0.setCellValue(getMessageBundle("label.report.excel.total"));
        cell0.setCellStyle(cellStyle);

        cell1.setCellValue(searchResult.getRowCount() + " " +
                getMessageBundle("label.report.excel.registers"));
    }
*/
    /**
     * Returns the amount of rows returned on the search.
     *
     * @return size of the list
     */
    public Integer getListSize() {

        if (simulationList == null) {
            return Integer.valueOf(0);
        }

        return Integer.valueOf(simulationList.size());
    }

    /**
     * Returns the amount of rows in the Items list.
     *
     * @return size of the list
     */
    public Integer getItemListSize() {

        if (simulation == null || simulation.getItems() == null) {
            return Integer.valueOf(0);
        }

        return Integer.valueOf(simulation.getItems().size());
    }

    /**
     * Returns the amount of rows in the contract list
     *
     * @return size of the list
     */
    public Integer getContractListSize() {

        if (simulation == null || simulation.getBarterContracts() == null) {
            return Integer.valueOf(0);
        }

        return Integer.valueOf(simulation.getBarterContracts().size());
    }

    /**
     * Returns the amount of rows in the History list.
     *
     * @return size of the list
     */
    public Integer getHistoryListSize() {

        if (simulation == null || simulation.getHistories() == null) {
            return Integer.valueOf(0);
        }

        return Integer.valueOf(simulation.getHistories().size());
    }

    /**
     * Checks if the authenticated user has access permission for the function simulationNew
     *
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessSimulationNew() {

        return access(PermissionList.REGISTER_NEW_SIMULATION_FCPA_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    /**
     * @return the newSale
     */
    public boolean isNewSale() {

        return this.newSale;
    }

    /**
     * @return the renderDiffDelivLocationCheckBox
     */
    public boolean isRenderDiffDelivLocationCheckBox() {

        return this.renderDiffDelivLocationCheckBox;
    }

    /**
     * @return the quoteFieldsDisabled
     */
    public boolean isQuoteFieldsDisabled() {

        return this.quoteFieldsDisabled;
    }

    /**
     * @return the renderIncentive
     */
    public boolean isRenderIncentive() {

        return this.renderIncentive;
    }

    /**
     * @return the renderContractFields
     */
    public boolean isRenderContractFields() {

        return this.renderContractFields;
    }

    /**
     * @return the filter
     */
    public SimulationFilter getFilter() {

        return this.filter;
    }

    /**
     * @param filter - the filter to set
     */
    public void setFilter(SimulationFilter filter) {

        this.filter = filter;
    }

    /**
     * @return the renderRtv
     */
    public boolean isRenderRtv() {

        return this.renderRtv;
    }

    /**
     * @return the fromContract
     */
    public boolean isFromContract() {

        return this.fromContract;
    }

    /**
     * @return the campaignList
     */
    public List<SelectItem> getCampaignList() {

        return this.campaignList;
    }

    /**
     * @return the simulationList
     */
    public List<SimulationBusiness> getSimulationList() {
        return this.simulationList;
    }

    /**
     * @param simulationList - the simulationList to set
     */
    public void setSimulationList(List<SimulationBusiness> simulationList) {

        this.simulationList = simulationList;
    }

    /**
     * @return the simulationSelected
     */
    public SimulationBusiness getSimulationSelected() {

        return this.simulationSelected;
    }

    /**
     * @param simulationSelected - the simulationSelected to set
     */
    public void setSimulationSelected(SimulationBusiness simulationSelected) {

        this.simulationSelected = simulationSelected;
    }

    /**
     * @return the statusList
     */
    public List<SelectItem> getStatusList() {

        return this.statusList;
    }

    /**
     * @return the quoteTypeList
     */
    public List<SelectItem> getQuoteTypeList() {

        return this.quoteTypeList;
    }

    /**
     * @return the simulation
     */
    public Simulation getSimulation() {
        return this.simulation;
    }

    /**
     * @return the fcpaList
     */
    public List<SelectItem> getFcpaList() {

        return this.fcpaList;
    }

    /**
     * @return the mktCampaignList
     */
    public List<SelectItem> getMktCampaignList() {

        return this.mktCampaignList;
    }

    /**
     * @return the selectedCustomer
     */
    public String getSelectedCustomer() {

        return this.selectedCustomer;
    }

    /**
     * @param selectedCustomer - the selectedCustomer to set
     */
    public void setSelectedCustomer(String selectedCustomer) {

        this.selectedCustomer = selectedCustomer;
    }

    /**
     * @return the formalizationTermBusiness
     */
    public FormalizationTermBusiness getFormalizationTermBusiness() {

        return formalizationTermBusiness;
    }

    /**
     * @param formalizationTermBusiness - the formalizationTermBusiness to set
     */
    public void setFormalizationTermBusiness(FormalizationTermBusiness formalizationTermBusiness) {

        this.formalizationTermBusiness = formalizationTermBusiness;
    }

    /**
     * @return the barterTypeList
     */
    public List<SelectItem> getBarterTypeList() {

        return this.barterTypeList;
    }

    /**
     * @return the cropList
     */
    public List<SelectItem> getCropList() {

        return this.cropList;
    }

    /**
     * @return the tradingList
     */
    public List<SelectItem> getTradingList() {

        return this.tradingList;
    }

    /**
     * @return the currencyList
     */
    public List<SelectItem> getCurrencyList() {

        return this.currencyList;
    }

    /**
     * @return the paymentConditionList
     */
    public List<SelectItem> getPaymentConditionList() {

        return this.paymentConditionList;
    }

    /**
     * @return the usdRate
     */
    public BigDecimal getUsdRate() {

        return this.usdRate;
    }

    /**
     * @return the renderUsdRate
     */
    public boolean isRenderUsdRate() {

        return this.renderUsdRate;
    }

    /**
     * @return the commodityList
     */
    public List<SelectItem> getCommodityList() {

        return this.commodityList;
    }

    /**
     * @return the incotermsList
     */
    public List<SelectItem> getIncotermsList() {

        return this.incotermsList;
    }


    /**
     * @return the itemsSimulation
     */
    public List<SelectItem> getItemsSimulation() {

        return this.itemsSimulation;
    }

    /**
     * @return the renderedPanelQuotation
     */
    public boolean isRenderedPanelQuotation() {

        return this.renderedPanelQuotation;
    }

    /**
     * @return the renderedPanelItem
     */
    public boolean isRenderedPanelItem() {

        return this.renderedPanelItem;
    }

    /**
     * @return the quotationBusiness
     */
    public QuotationBusiness getQuotationBusiness() {

        return this.quotationBusiness;
    }

    /**
     * @param quotationBusiness - the quotationBusiness to set
     */
    public void setQuotationBusiness(QuotationBusiness quotationBusiness) {

        this.quotationBusiness = quotationBusiness;
    }

    /**
     * @return the simulationItem
     */
    public SimulationItem getSimulationItem() {

        return this.simulationItem;
    }

    /**
     * @param simulationItem - the simulationItem to set
     */
    public void setSimulationItem(SimulationItem simulationItem) {

        this.simulationItem = simulationItem;
    }

    /**
     * @return the regionList
     */
    public List<SelectItem> getRegionList() {

        return this.regionList;
    }

    /**
     * @return the cityList
     */
    public List<SelectItem> getCityList() {

        return this.cityList;
    }

    /**
     * @return the renderDiffDelivLocationField
     */
    public boolean isRenderDiffDelivLocationField() {

        return this.renderDiffDelivLocationField;
    }

    /**
     * @param renderDiffDelivLocationField - the renderDiffDelivLocationField to set
     */
    public void setRenderDiffDelivLocationField(boolean renderDiffDelivLocationField) {

        this.renderDiffDelivLocationField = renderDiffDelivLocationField;
    }

    /**
     * @return the divisionChemicals
     */
    public boolean isDivisionChemicals() {

        return this.divisionChemicals;
    }

    /**
     * @return the renderedPanelTermsFormalization
     */
    public boolean isRenderedPanelTermsFormalization() {

        return this.renderedPanelTermsFormalization;
    }

    /**
     * @return the renderPanelSignature
     */
    public boolean isRenderPanelSignature() {

        return this.renderPanelSignature;
    }

    /**
     * @return the renderPopupFormalizationPrint
     */
    public boolean isRenderPopupFormalizationPrint() {

        return this.renderPopupFormalizationPrint;
    }

    /**
     * @return the invoiceList
     */
    public List<InvoiceSimulation> getInvoiceList() {

        return invoiceList;
    }

    /**
     * @param invoiceList - the invoiceList to set
     */
    public void setInvoiceList(List<InvoiceSimulation> invoiceList) {

        this.invoiceList = invoiceList;
    }

    /**
     * @return the commodity
     */
    public boolean isCommodity() {

        return this.commodity;
    }

    /**
     * @return the reopen
     */
    public boolean isReopen() {

        return this.reopen;
    }

    /**
     * @return the mktCampaignDesc
     */
    public String getMktCampaignDesc() {

        return this.mktCampaignDesc;
    }

    /**
     * @return the tradingDesc
     */
    public String getTradingDesc() {

        return this.tradingDesc;
    }

    /**
     * @return the commodityDesc
     */
    public String getCommodityDesc() {

        return this.commodityDesc;
    }

    /**
     * @return the codeOthersDisapprovalReason
     */
    public Integer getCodeOthersDisapprovalReason() {

        return codeOthersDisapprovalReason;
    }

    /**
     * @return the codeOthersReturnReason
     */
    public Integer getCodeOthersReturnReason() {

        return codeOthersReturnReason;
    }

    /**
     * @return the renderPrintButton
     */
    public boolean isRenderPrintButton() {

        return this.renderPrintButton;
    }

    /**
     * @return the renderedTxtMotive
     */
    public boolean isRenderedTxtMotive() {

        return renderedTxtMotive;
    }

    /**
     * @return the disapprovalReasonList
     */
    public List<SelectItem> getDisapprovalReasonList() {

        return disapprovalReasonList;
    }

    /**
     * @return the returnReasonList
     */
    public List<SelectItem> getReturnReasonList() {

        return returnReasonList;
    }

    /**
     * @return the renderApproveButton
     */
    public boolean isRenderApproveButton() {

        return this.renderApproveButton;
    }

    /**
     * @return the renderReturnButton
     */
    public boolean isRenderReturnButton() {

        return this.renderReturnButton;
    }

    /**
     * @return the renderDisapproveButton
     */
    public boolean isRenderDisapproveButton() {

        return this.renderDisapproveButton;
    }

    /**
     * @return the renderVerifySaleOrderButton
     */
    public boolean isRenderVerifySaleOrderButton() {

        return this.renderVerifySaleOrderButton;
    }

    /**
     * @return the barterTypeTerms
     */
    public boolean isBarterTypeTerms() {

        return barterTypeTerms;
    }

    /**
     * @return the barterTypeWithExistingContract
     */
    public boolean isBarterTypeWithExistingContract() {

        return barterTypeWithExistingContract;
    }

    /**
     * @return the barterTypeMonsantoManagesContract
     */
    public boolean isBarterTypeMonsantoManagesContract() {

        return barterTypeMonsantoManagesContract;
    }

    /**
     * @return the barterTypeGrainAvailable
     */
    public boolean isBarterTypeGrainAvailable() {

        return barterTypeGrainAvailable;
    }

    /**
     * @return the customerFilter
     */
    public CustomerFilter getCustomerFilter() {

        return this.customerFilter;
    }

    public String getSelectedContract() {
        return selectedContract;
    }

    public void setSelectedContract(String selectedContract) {
        this.selectedContract = selectedContract;
    }

    public boolean isContractSelected() {
        return contractSelected;
    }

    public void setContractSelected(boolean contractSelected) {
        this.contractSelected = contractSelected;
    }

    public DocumentTypeList[] getUploadDocumentTypes() {
        return DocumentTypeList.values();
    }

    public List<FileUpload> getFileUploadHandlers() {
        return fileUploadHandlers;
    }

    public void setFileUploadHandlers(List<FileUpload> fileUploadHandlers) {
        this.fileUploadHandlers = fileUploadHandlers;
    }

    public void addFileUploadHandler() {
        fileUploadHandlers.add(new FileUpload());
    }

    public List<BarAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<BarAttachment> attachments) {
        this.attachments = attachments;
    }

    public BarAttachment getAttachmentSelected() {
        return attachmentSelected;
    }

    public void setAttachmentSelected(BarAttachment attachmentSelected) {
        this.attachmentSelected = attachmentSelected;
    }

    public boolean isFilesAttachedSuccessfully() {
        return filesAttachedSuccessfully;
    }

    public boolean isRenderAttachmentPopup() {
        return renderAttachmentPopup;
    }

    public List<FileUpload> getContractFileUploadHandlers() {
        return contractFileUploadHandlers;
    }

    public void setContractFileUploadHandlers(List<FileUpload> contractFileUploadHandlers) {
        this.contractFileUploadHandlers = contractFileUploadHandlers;
    }

    public void addContractFileUploadHandler() {
        contractFileUploadHandlers.add(new FileUpload());
    }

    public BarContractAttachment getContractAttachmentSelected() {
        return contractAttachmentSelected;
    }

    public void setContractAttachmentSelected(BarContractAttachment contractAttachmentSelected) {
        this.contractAttachmentSelected = contractAttachmentSelected;
    }

    public BarterContract getSimulationContractSelected() {
        return simulationContractSelected;
    }

    public void setSimulationContractSelected(BarterContract simulationContractSelected) {
        this.simulationContractSelected = simulationContractSelected;
    }

    public List<BarContractAttachment> getContractAttachments() {
        return contractAttachments;
    }

    public void setContractAttachments(List<BarContractAttachment> contractAttachments) {
        this.contractAttachments = contractAttachments;
    }

    public boolean isEnableLegalApproval() {
        return access(PermissionList.LEGAL_TEAM_APPROVAL_PERMISSION_CD.getPermissionCd());
    }

    public BigDecimal getTotalBarterAmount() {
        return totalBarterAmount;
    }

    public void setTotalBarterAmount(BigDecimal totalBarterAmount) {
        this.totalBarterAmount = totalBarterAmount;
    }

    public BigDecimal getTotalBarterTons() {
        return totalBarterTons;
    }

    public void setTotalBarterTons(BigDecimal totalBarterTons) {
        this.totalBarterTons = totalBarterTons;
    }

    public List<Long> getEditContractsIds() {
        return editContractsIds;
    }

    public void setEditContractsIds(List<Long> editContractsIds) {
        this.editContractsIds = editContractsIds;
    }

    public DataModel<BarterContract> getBarterContracts() {
        return barterContracts;
    }

    public void setBarterContracts(DataModel<BarterContract> barterContracts) {
        this.barterContracts = barterContracts;
    }

    public List<SelectItem> getWhitePapers() {
        return whitePapers;
    }

    public void setWhitePapers(List<SelectItem> whitePapers) {
        this.whitePapers = whitePapers;
    }

    public WhitePaper getWhitePaperSelected() {
        return whitePaperSelected;
    }

    public void setWhitePaperSelected(WhitePaper whitePaperSelected) {
        this.whitePaperSelected = whitePaperSelected;
    }

    public List<BarterContract> getContractsToDelete() {
        return contractsToDelete;
    }

    public void setContractsToDelete(List<BarterContract> contractsToDelete) {
        this.contractsToDelete = contractsToDelete;
    }

    public Boolean getContractNumberChecked() {
        return contractNumberChecked;
    }

    public void setContractNumberChecked(Boolean contractNumberChecked) {
        this.contractNumberChecked = contractNumberChecked;
    }

    public boolean isSimulationSearchList() {
        return simulationSearchList;
    }

    public void setSimulationSearchList(boolean simulationSearchList) {
        this.simulationSearchList = simulationSearchList;
    }

    public boolean isCreateBarterContracts() {
       return access(PermissionList.CREATE_BARTER_CONTRACT_PERMISSION_CD.getPermissionCd());
    }
}
