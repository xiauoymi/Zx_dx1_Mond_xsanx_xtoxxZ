package com.monsanto.barter.web.faces.tradingcontract;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import com.monsanto.barter.architecture.regionalization.*;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.service.*;
import org.apache.commons.lang.StringUtils;

import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.business.SimulationBusiness;
import com.monsanto.barter.business.entity.business.TradingContractBusiness;
import com.monsanto.barter.business.entity.filter.CityFilter;
import com.monsanto.barter.business.entity.filter.CommodityFilter;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.filter.CurrencyFilter;
import com.monsanto.barter.business.entity.filter.IncotermsFilter;
import com.monsanto.barter.business.entity.filter.QuotationFilter;
import com.monsanto.barter.business.entity.filter.RegionFilter;
import com.monsanto.barter.business.entity.filter.SimulationFilter;
import com.monsanto.barter.business.entity.filter.TradingContractFilter;
import com.monsanto.barter.business.entity.filter.TradingContractHistoryFilter;
import com.monsanto.barter.business.entity.filter.TradingFilter;
import com.monsanto.barter.business.entity.list.ActionList;
import com.monsanto.barter.business.entity.list.ContractStatusList;
import com.monsanto.barter.business.entity.list.ContractTypeList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.list.QuoteTypeList;
import com.monsanto.barter.business.entity.list.SimulationStatusList;
import com.monsanto.barter.business.entity.list.YesNoList;
import com.monsanto.barter.business.entity.table.id.CityId;
import com.monsanto.barter.business.entity.table.id.CommodityId;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.entity.table.id.CurrencyId;
import com.monsanto.barter.business.entity.table.id.IncotermsId;
import com.monsanto.barter.business.entity.table.id.TradingId;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.quotation.QuotationFaces;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import org.apache.log4j.Logger;

/**
 * Class responsible for controlling the pages of TradingContract feature.
 * 
 * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
 * @since 06/12/2011
 */
@ManagedBean(name="tradingContractFaces")
@SessionScoped
public class TradingContractFaces extends BaseJSF {

    protected static final Logger LOG = Logger.getLogger(TradingContractFaces.class);

    private static final long serialVersionUID = 3364467355763026261L;

    private static final String USD_CD = "USD";

    // Constants
    private static final String ID_TAB_HISTORY = "tabHistory";

    private static final String MANAGED_BEAN_SIMULATION = "simulationFaces";

    // Objects
    private TradingContractFilter tradingContractFilter;

    private TradingContract tradingContract;

    private TradingContractBusiness tradingContractBusiness;

    private SimulationBusiness simulationBusiness;

    private QuotationFilter quotationFilter;

    private QuotationBusiness quotationBusiness;

    // Lists
    private List<TradingContractBusiness> tradingContractList;

    private List<TradingContractHistory> historyList;

    private List<SimulationBusiness> simulationList;

    private List<SimulationBusiness> simulationBackupList;

    // Items for select
    private List<SelectItem> listCountry;

    private List<SelectItem> listTrading;

    private List<SelectItem> listTradingFromCampaign;

    private List<SelectItem> listCommodity;

    private List<SelectItem> listIncoterms;

    private List<SelectItem> listCurrency;

    private List<SelectItem> listRegion;

    private List<SelectItem> listCity;

    private List<SelectItem> listStatus;

    private List<SelectItem> listQuote;
    
    private List<SelectItem> listYesNo;

    private List<SelectItem> listContractType;

    // Flags
    private boolean enableSaveBtn;
    
    private boolean renderedDataTable;

    private boolean visualization;

    private boolean disabledCboRegion;

    private boolean disabledSackGrossPrice;

    private boolean disabledCboSquare;

    private boolean renderedPanel;
    
    private boolean renderUsdRate;
    
    private boolean renderedConvertedValue;
    
    private boolean renderedRbQuotation;

    // Others
    private String tab;

    private String messagePanel;

    private BigDecimal totalValueSimulations;
    
    private BigDecimal usdRate;
    
    private Character languageLoggedInUser;
    
    private Character statusDeleteLabel;
    
    private String contractTypeMG;

    private int index;

    private List<SelectItem> listSelectRadio;

    private Campaign campaign;


    /**
     * Default constructor.
     * 
     */
    public TradingContractFaces() {

        super();
        this.initializeVariables();

        this.loadCountries();
        this.loadIncoterms();
        this.loadCurrencies();
        this.loadQuotation();
        this.loadContractType();

        this.loadStatus();
        this.loadListYesNo();
        this.showFields(false);
        this.historyList.clear();
        this.tradingContract.setContractTypeCd(ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getCode());
        this.tradingContract.setStatusCd(ContractStatusList.NEW.getCode());
    }


    /**
     * Method for init navegation.
     * */
    public String begin(){
        this.tradingContractList.clear();
        return SUCCESS;
    }

    public String newTradingContact(){
        super.setNewer(true);
        this.visualization = false;
        this.initializeTradingContract();
        this.historyList.clear();
        this.listCity.clear();
        this.listRegion.clear();
        this.showFields(false);
        this.visualization = false;
        this.tradingContractList.clear();
        this.tradingContractFilter = new TradingContractFilter(new TradingContract());
        this.tradingContractFilter.getTradingContract().setCity(new City(new CityId()));
        this.tradingContract.setContractTypeCd(ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getCode());
        this.tradingContract.setStatusCd(ContractStatusList.NEW.getCode());
        this.renderedRbQuotation = false;
        return NEW;
    }




    /**
     * Method responsible for init of variables.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void initializeVariables() {

        this.tradingContractFilter = new TradingContractFilter(new TradingContract());
        this.tradingContractFilter.getTradingContract().setCity(new City(new CityId()));

        this.initializeTradingContract();

        this.quotationFilter = new QuotationFilter();
        this.quotationBusiness = new QuotationBusiness();

        this.tradingContractList = new ArrayList<TradingContractBusiness>();
        this.historyList = new ArrayList<TradingContractHistory>();
        this.simulationList = new ArrayList<SimulationBusiness>();
        this.simulationBackupList = new ArrayList<SimulationBusiness>();

        this.listCountry = new ArrayList<SelectItem>();
        this.listIncoterms = new ArrayList<SelectItem>();
        this.listCurrency = new ArrayList<SelectItem>();

        this.listCommodity = new ArrayList<SelectItem>();
        this.listTrading = new ArrayList<SelectItem>();
        this.listTradingFromCampaign = new ArrayList<SelectItem>();

        this.listRegion = new ArrayList<SelectItem>();
        this.listCity = new ArrayList<SelectItem>();
        this.listStatus = new ArrayList<SelectItem>();
        this.listYesNo = new ArrayList<SelectItem>();
        this.listQuote = new ArrayList<SelectItem>();
        this.listContractType = new ArrayList<SelectItem>();

        this.disabledSackGrossPrice = true;
        this.disabledCboSquare = true;
        this.languageLoggedInUser = SecurityUtil.getLoggedInUser().getLanguageCd();

        this.statusDeleteLabel = ContractStatusList.DELETE.getCode();
        this.contractTypeMG = ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getCode();
    }

    /**
     * Method responsible for init of tradingContract variable.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void initializeTradingContract() {

        this.tradingContract = new TradingContract();
        this.tradingContract.setIncoterms(new Incoterms(new IncotermsId()));
        this.tradingContract.setCurrency(new Currency(new CurrencyId()));
        this.tradingContract.setCity(new City(new CityId()));

        if ( isBarterParaguay() ){
            this.tradingContract.getCurrency().getId().setCurrencyCd(USD_CD);
        }

    }



    private void loadContractType() {

        this.listContractType.add(new SelectItem(ContractTypeList.AVAILABLE_GRAIN.getCode(), super.getMessage(ContractTypeList.AVAILABLE_GRAIN.getName() ) ));
        this.listContractType.add(new SelectItem(ContractTypeList.EXISTING_CONTRACT_CD.getCode(), super.getMessage( ContractTypeList.EXISTING_CONTRACT_CD.getName())));

        if ( access( PermissionList.CREATE_MONSTANTO_MANAGED_CONTRACT_PERMISSION_CD.getPermissionCd() ) ){
            this.listContractType.add(new SelectItem(ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getCode(), super.getMessage( ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getName())));
        }
    }

    /**
     * Load the list of countries to component 'cboCountry'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadCountries() {

        ICountryService countryService = getService(ICountryService.class);

        try {
            Country country = new Country(new CountryId());
            country.getId().setLanguageCd(this.getLanguage());
            CountryFilter countryFilter = new CountryFilter(country);

            List<Country> countryList = countryService.search(countryFilter);

            for (Country item : countryList) {
                this.listCountry.add(new SelectItem(item.getId().getCountryCd(), item.getShortDesc()));
            }
            this.listCountry = super.sortSelectItem(this.listCountry);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of incoterms to component 'cboIncoterms'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadIncoterms() {

        IIncotermsService incotermsService = getService(IIncotermsService.class);

        try {
            IncotermsFilter incotermsFilter = new IncotermsFilter();
            incotermsFilter.setLanguageCd(this.getLanguage());

            List<Incoterms> incotermsList = incotermsService.search(incotermsFilter);

            for (Incoterms item : incotermsList) {
                this.listIncoterms.add(new SelectItem(item.getId().getIncotermsCd().trim(), item.getId().getIncotermsCd()));
            }
            this.listIncoterms = super.sortSelectItem(this.listIncoterms);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of currencies to component 'cboCurrency'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadCurrencies() {

        ICurrencyService currencyService = getService(ICurrencyService.class);

        try {

            Currency currency = new Currency(new CurrencyId());

            if ( isBarterParaguay() ){
                currency.getId().setLanguageCd( com.monsanto.barter.architecture.regionalization.Country.PARAGUAY.getCodLanguage() );
                currency.getId().setCurrencyCd( USD_CD );

            } else {
                currency.getId().setLanguageCd(this.getLanguage());
            }

            CurrencyFilter currencyFilter = new CurrencyFilter(currency);

            List<Currency> currencyList = currencyService.search(currencyFilter);

            for (Currency item : currencyList) {
                this.listCurrency.add(new SelectItem(item.getId().getCurrencyCd(), item.getDescCurrencyLong()));
            }

            this.listCurrency = super.sortSelectItem(this.listCurrency);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of status to component 'cboStatus'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadStatus() {

        for (ContractStatusList item : ContractStatusList.values()) {
            this.listStatus.add(new SelectItem(item.getCode(), super.getMessage(item.getName())));
        }
        this.listStatus = super.sortSelectItem(this.listStatus);
    }

    /**
     * Load the list of options to component 'cboApproved'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadListYesNo() {

        for (YesNoList item : YesNoList.values()) {
            this.listYesNo.add(new SelectItem(item.getFlag(), super.getMessage(item.getName())));
        }
    }
    
    /**
     * Load the list of quotes to component 'rbQuotation'
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadQuotation() {

        for (QuoteTypeList item : QuoteTypeList.values()) {
            this.listQuote.add(new SelectItem(item.getCod(), super.getMessage(item.getName())));
        }
    }

    /**
     * Data load of screen of visualization or edition
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void viewEdit() {

        String countryCd = this.tradingContract.getCity().getId().getCountryCd();
        String currencyCd = this.tradingContract.getCurrency().getId().getCurrencyCd();        

        this.loadTrading(countryCd);
        this.loadCommodity(countryCd);

        if (QuoteTypeList.QUOTE.getCod().equals(this.tradingContract.getQuotationFL())) {
            this.showFields(false);
        } else if (QuoteTypeList.MANUAL_PRICE.getCod().equals(this.tradingContract.getQuotationFL())) {
            this.showFields(true);
        }

        if (super.hasValue(currencyCd) && IBarterConstants.CURRENCY_CODE_DOLLAR.trim().equalsIgnoreCase(currencyCd.trim())) {

            final IPtaxService ptaxService = getService(IPtaxService.class);                    
            this.usdRate = ptaxService.convertQuotationOriginToTarget(IBarterConstants.CURRENCY_CODE_DOLLAR,
                IBarterConstants.CURRENCY_CODE_REAL);
            this.tradingContract.setConvertedValue(this.tradingContract.getContractValue().multiply(this.usdRate, MathContext.DECIMAL128));
            this.renderUsdRate = true;
            this.renderedConvertedValue = true;
        }
        
        this.loadRegions(countryCd);
        this.loadCities(tradingContract.getCity().getId().getRegionCd());

        this.searchSimulations();
        this.totalValueSimulations = this.calculateTotalSimulations();

        this.quotationFilter.setCommodityId(this.tradingContract.getCommodityId());
        this.quotationFilter.setCountryCd(countryCd);
        this.quotationFilter.setCurrencyCd(this.tradingContract.getCurrency().getId().getCurrencyCd());
        this.quotationFilter.setTradingId(this.tradingContract.getTradingCd());

        this.searchHistory();
    }

    /**
     * Load the list of goods to component 'cboCommodity'
     * 
     * @param countryCd - Id of country
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadCommodity(String countryCd) {

        ICommodityService commodityService = getService(ICommodityService.class);

        try {
            Commodity commodity = new Commodity(new CommodityId());
            commodity.getId().setCountryCd(countryCd);
            CommodityFilter filter = new CommodityFilter(commodity);

            List<Commodity> commodityList = commodityService.search(filter);

            this.listCommodity = new ArrayList<SelectItem>();

            for (Commodity item : commodityList) {
                this.listCommodity.add(new SelectItem(item.getId().getCommodityId().trim(), item.getDescCommodity()));
            }
            this.listCommodity = super.sortSelectItem(this.listCommodity);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of trading to component 'cboTrading'
     * 
     * @param countryCd - Id of country
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadTrading(String countryCd) {

        ITradingService tradingService = getService(ITradingService.class);

        try {

            Trading trading = new Trading(new TradingId());
            trading.getId().setCountryCd(countryCd);
            TradingFilter filter = new TradingFilter(trading);

            List<Trading> tradingList = tradingService.search(filter);

            this.listTrading = new ArrayList<SelectItem>();

            for (Trading item : tradingList) {
                this.listTrading.add(new SelectItem(item.getId().getTradingCd().trim(), item.getDescTrading()));
            }
            this.listTrading = super.sortSelectItem(this.listTrading);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    private void loadTradingFromCampaign() {

        ICampaignService campaignService = getService(ICampaignService.class);

        campaign = campaignService.findByIdComplete(campaign);

            List<Trading> tradingList = campaign.getTradings();

            this.listTradingFromCampaign = new ArrayList<SelectItem>();

            for (Trading item : tradingList) {
                this.listTradingFromCampaign.add(new SelectItem(item.getId().getTradingCd().trim(), item.getDescTrading()));
            }

            this.listTradingFromCampaign = super.sortSelectItem(this.listTradingFromCampaign);

    }

    /**
     * Load the list of regions to component 'cboRegion'
     * 
     * @param countryCd - Id of country
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadRegions(String countryCd) {

        IRegionService regionService = getService(IRegionService.class);

        try {
            RegionFilter regionFilter = new RegionFilter();
            regionFilter.setLanguageCd(this.getLanguage());
            regionFilter.setCountryCd(countryCd);

            List<Region> regionList = regionService.search(regionFilter);

            this.listRegion = new ArrayList<SelectItem>();

            for (Region item : regionList) {
                this.listRegion.add(new SelectItem(item.getId().getRegionCd(), item.getId().getRegionCd()));
            }
            this.listRegion = super.sortSelectItem(this.listRegion);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Load the list of cities to component 'cboSquare'
     * 
     * @param regionCd - Id of region
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void loadCities(String regionCd) {

        ICityService cityService = getService(ICityService.class);

        try {
            CityFilter filter = new CityFilter();
            filter.setLanguageCd(this.getLanguage());
            filter.setRegionCd(regionCd);

            List<City> cityList = cityService.search(filter);

            this.listCity = new ArrayList<SelectItem>();

            for (City item : cityList) {
                this.listCity.add(new SelectItem(item.getId().getCityCd(), item.getDescCity()));
            }
            this.listCity = super.sortSelectItem(this.listCity);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Search method of simulations by TradingContract ID
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void searchSimulations() {

        ISimulationService simulationService = getService(ISimulationService.class);
        SimulationFilter simulationFilter = new SimulationFilter();
        simulationFilter.setContractId(this.tradingContract.getContractId());
        this.simulationList = simulationService.search(simulationFilter);
        this.simulationBackupList = new ArrayList<SimulationBusiness>();
        this.simulationBackupList.addAll(this.simulationList);
        this.setMessages(simulationService.getMessages());
    }

    private void searchHistory(){

        if (this.historyList.isEmpty()) {
            ITradingContractHistoryService contractHistoryService = getService(ITradingContractHistoryService.class);

            TradingContractHistoryFilter filter = new TradingContractHistoryFilter();
            filter.setContractId(this.tradingContract.getContractId());

            this.historyList = contractHistoryService.search(filter);
        }
    }

    /**
     * Method responsible for display of fields.
     * 
     * @param enableField - Boolean of enable or disable
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void showFields(boolean enableField) {

        this.disabledCboRegion = !enableField;
        this.disabledSackGrossPrice = !enableField;
        this.disabledCboSquare = !enableField;
    }

    /**
     * Method responsible for language of screen.
     * 
     * @return the language for consultation in base.
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private Character getLanguage() {

        if (super.isNewer()) {
            return languageLoggedInUser;
        } else {
            return this.tradingContract.getCity().getId().getLanguageCd();
        }
    }

    /**
     * Method responsible for clear fields of sack gross price, contract value and quotation.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void clearFields() {

        this.tradingContract.setSackGrossPrice(null);
        this.tradingContract.setSackNetPrice(null);
        this.tradingContract.setContractValue(null);
        this.tradingContract.setConvertedValue(null);
        this.tradingContract.setQuotationFL(null);
        this.tradingContract.setBalanceContract(null);
        this.listRegion.clear();
        this.listCity.clear();
        this.tradingContract.getCity().getId().setRegionCd(null);
        this.showFields(false);
    }

    /**
     * Method calculates the total value of simulations related to the contract
     * 
     * @return Total value
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private BigDecimal calculateTotalSimulations() {

        BigDecimal totalValue = BigDecimal.ZERO;
        for (SimulationBusiness simulation : this.simulationList) {
            totalValue = totalValue.add(simulation.getSimulationValue(), MathContext.DECIMAL128);
        }

        return totalValue;
    }

    /**
     * Method responsible for calling the calculateContractValue method and calculateBalance method of the business
     * layer.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void calculateContractValueAndBalance() {

        try {
            ITradingContractService tradingContractService = getService(ITradingContractService.class);
            BigDecimal contractValue = tradingContractService.calculateContractValue(this.tradingContract);
            this.tradingContract.setContractValue(contractValue);
            if (super.hasValue(contractValue)) {
                
                String currencyCd = this.tradingContract.getCurrency().getId().getCurrencyCd();        
                if (super.hasValue(currencyCd) && IBarterConstants.CURRENCY_CODE_DOLLAR.trim().equalsIgnoreCase(currencyCd.trim())) {

                    this.tradingContract.setConvertedValue(contractValue.multiply(usdRate, MathContext.DECIMAL128));
                }
            } else {
                this.tradingContract.setConvertedValue(null);
            }
            this.tradingContract.setBalanceContract(tradingContractService.calculateBalance(this.simulationList,
                this.tradingContract));
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible in open pop-up of quotation.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void openPopUp() {

        try {

            QuotationFaces quotationFaces = getFaces("quotationFaces");
            if (quotationFaces != null) {
                quotationFaces.setQuotationFilter(this.quotationFilter);
                quotationFaces.search();
                String messagesError = quotationFaces.getMessages();
                if (super.hasValue(messagesError)) {
                    super.setMessages(messagesError);
                    this.tradingContract.setQuotationFL(null);
                } else {
                    this.renderedPanel = true;
                }
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method add spaces in String in fields char type in base data.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void addRightPad() {

        this.tradingContract.getIncoterms().getId()
            .setIncotermsCd(this.tradingContract.getIncoterms().getId().getIncotermsCd());
        this.tradingContract.setCommodityId(this.tradingContract.getCommodityId());
        this.tradingContract.setTradingCd(this.tradingContract.getTradingCd());
    }

    /**
     * Trim in fields with type char id
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    private void addTrim() {

        this.tradingContract.getIncoterms().getId()
            .setIncotermsCd(this.tradingContract.getIncoterms().getId().getIncotermsCd().trim());
        this.tradingContract.setCommodityId(this.tradingContract.getCommodityId().trim());
        this.tradingContract.setTradingCd(this.tradingContract.getTradingCd().trim());
    }

    /**
     * Method responsible for the action to select quote.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String selectQuotation() {

        try {
            this.tradingContract.setQuotationId(this.quotationBusiness.getQuotationId());
            this.tradingContract.setSackGrossPrice(this.quotationBusiness.getQuotationValue());
            this.tradingContract.setSackNetPrice(this.quotationBusiness.getQuotationValue());

            tradingContract.getCity().getId().setRegionCd(this.quotationBusiness.getRegionCd());
            this.loadRegions(this.tradingContract.getCity().getId().getCountryCd());
            this.loadCities(this.tradingContract.getCity().getId().getRegionCd());

            this.tradingContract.getCity().getId().setCityCd(this.quotationBusiness.getCityCd());
            this.tradingContract.getCity().setDescCity(this.quotationBusiness.getDescCity());

            if (!super.hasValue(this.quotationFilter.getTradingId())) {
                this.tradingContract.setTradingCd(this.quotationBusiness.getTradingCd().trim());
            }

            this.renderedPanel = false;
            this.calculateContractValueAndBalance();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for displaying the History tab
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void showHistoryTab() {

        if (this.historyList.isEmpty()) {
            ITradingContractHistoryService contractHistoryService = getService(ITradingContractHistoryService.class);

            TradingContractHistoryFilter filter = new TradingContractHistoryFilter();
            filter.setContractId(this.tradingContract.getContractId());

            this.historyList = contractHistoryService.search(filter);
        }

        this.tab = ID_TAB_HISTORY;
    }

    /**
     * Change event of the combo box of country.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboCountryChanged() {

        String countryId = this.tradingContract.getCity().getId().getCountryCd();
        if (!super.hasValue(countryId)) {
            countryId = this.tradingContractFilter.getTradingContract().getCity().getId().getCountryCd();
        }
        this.clearFields();
        if (super.hasValue(countryId)) {
            this.loadTrading(countryId);
            this.loadCommodity(countryId);
        } else {
            this.listTrading.clear();
            this.listCommodity.clear();
        }
        
        this.tradingContract.setTradingCd(null);
        this.tradingContract.setCommodityId(null);
        this.quotationFilter.setTradingId(null);
        this.quotationFilter.setCommodityId(null);
        this.quotationFilter.setCountryCd(countryId);
        checkRenderedRbQuotation();
    }

    /**
     * Event of change radio button of quotation.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void rbQuotationChanged() {

        Character option = this.tradingContract.getQuotationFL();
        if (super.hasValue(option)) {

            if (QuoteTypeList.QUOTE.getCod().equals(option)) {
                this.showFields(false);
                this.listRegion.clear();
                this.openPopUp();
            } else if (QuoteTypeList.MANUAL_PRICE.getCod().equals(option)) {
                this.tradingContract.setQuotationId(null);
                this.showFields(true);
                this.loadRegions(this.tradingContract.getCity().getId().getCountryCd());               
            }
            this.calculateContractValueAndBalance();
        }
    }

    /**
     * Event of change input text of quotation.
     * 

     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void txtGrossPriceChanged() {
    	
    	this.getTradingContract().setSackNetPrice(this.getTradingContract().getSackGrossPrice());

        this.txtNetPriceChanged();
    }

    /**
     * Event of change input text of quotation.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void txtNetPriceChanged() {

        this.calculateContractValueAndBalance();
    }

    /**
     * Event of change input text of volume in kg.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void txtVolumeKgChanged() {

        this.calculateContractValueAndBalance();
    }

    /**
     * Change event of the combo box of region.
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboRegionChanged() {

        if (super.hasValue(this.tradingContract.getCity().getId().getRegionCd())) {
            this.loadCities(this.tradingContract.getCity().getId().getRegionCd());
        } else {
            this.listCity.clear();
        }
        this.tradingContract.getCity().getId().setCityCd(null);
    }

    /**
     * Change event of the combo box of commodity
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboCommodityChanged() {

        this.quotationFilter.setCommodityId(this.tradingContract.getCommodityId());
        checkRenderedRbQuotation();
        this.clearFields();
    }


    public void cboContractTypeChanged() {


    }



    /**
     * Change event of the combo box of currency
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboCurrencyChanged() {

        this.clearFields();
        this.renderUsdRate = false;
        this.renderedConvertedValue = false;
        String currencyCd = this.tradingContract.getCurrency().getId().getCurrencyCd();        
        checkRenderedRbQuotation();
        if (super.hasValue(currencyCd) && IBarterConstants.CURRENCY_CODE_DOLLAR.trim().equalsIgnoreCase(currencyCd.trim())) {

            final IPtaxService ptaxService = getService(IPtaxService.class);                    
            this.usdRate = ptaxService.convertQuotationOriginToTarget(IBarterConstants.CURRENCY_CODE_DOLLAR,
                IBarterConstants.CURRENCY_CODE_REAL);
            this.renderUsdRate = true;
            this.renderedConvertedValue = true;
        } 

        this.quotationFilter.setCurrencyCd(currencyCd);
    }
    
    /**
     * 
     * 
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    private void checkRenderedRbQuotation(){
        this.renderedRbQuotation = super.hasValue(this.tradingContract.getCity().getId().getCountryCd())
            && super.hasValue(this.tradingContract.getCommodityId())
            && super.hasValue(this.tradingContract.getCurrency().getId().getCurrencyCd()); 
    }

    /**
     * Change event of the combo box of trading
     *
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cboTradingChanged() {

        this.quotationFilter.setTradingId(this.tradingContract.getTradingCd());
    }

    /**
     * Method responsible for calling the search method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String search() {

        ITradingContractService tradingContractService = getService(ITradingContractService.class);

        try {

            this.tradingContractFilter.getTradingContract().getCity().getId().setLanguageCd(this.getLanguage());            
            this.tradingContractList = tradingContractService.searchBusinessObjects(this.tradingContractFilter);
            this.setMessages(tradingContractService.getMessages());
            this.renderedDataTable = !tradingContractList.isEmpty();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }
        return SUCCESS;
    }




    public void searchFromPopup() {

        ITradingContractService tradingContractService = getService(ITradingContractService.class);

        try {

            this.tradingContractFilter.getTradingContract().getCity().getId().setLanguageCd(this.getLanguage());
            this.tradingContractFilter.getTradingContract().getCity().getId().setCountryCd( campaign.getCountry().getId().getCountryCd() );
            this.tradingContractFilter.getStatus().add(ContractStatusList.UPDATE.getCode());
            this.tradingContractFilter.getStatus().add(ContractStatusList.NEW.getCode());

            this.tradingContractList = tradingContractService.searchBusinessObjects(this.tradingContractFilter);
            this.setMessages(tradingContractService.getMessages());
            this.renderedDataTable = !tradingContractList.isEmpty();

            populateRadioList();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

    }




    private void populateRadioList() {

        listSelectRadio = new ArrayList<SelectItem>();

        for ( TradingContractBusiness contractBusiness : tradingContractList ){
            listSelectRadio.add( new SelectItem(contractBusiness.getContractId().toString(),StringUtils.EMPTY));
        }

    }


    public void cancelSelectionContract() {

        tradingContractList.clear();
       listSelectRadio.clear();

    }

    /**
     * Method responsible for calling the update method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String update() {

        ITradingContractService tradingContractService = getService(ITradingContractService.class);

        try {
            TradingContract tradingContractFilterForUpdate = new TradingContract();
            tradingContractFilterForUpdate.setContractId(this.tradingContractBusiness.getContractId());
            this.tradingContractBusiness.setApprovedFl(Boolean.FALSE);
            this.tradingContract = tradingContractService.findByIdComplete(tradingContractFilterForUpdate);
            this.renderedRbQuotation = true;
            this.tab = null;
            super.setNewer(false);
            this.viewEdit();
            this.addTrim();
            this.setMessages(tradingContractService.getMessages());

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }
        return CHANGE;
    }

    /**
     * Method responsible for calling the delete method of the business layer.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String delete() {

        ITradingContractService tradingContractService = getService(ITradingContractService.class);

        try {
            this.tradingContract.setContractId(this.tradingContractBusiness.getContractId());
            this.tradingContract = tradingContractService.findByIdComplete(this.tradingContract);
            tradingContractService.validateDelete(this.tradingContract);

            this.setMessages(tradingContractService.getMessages());
            if (tradingContractService.isOk()) {

                if (!tradingContractService.getMessages().isEmpty()
                    && tradingContractService.getMessages().get(0).getType().equals(MessageTypeList.WARN)) {
                    this.renderedPanel = true;
                    this.messagePanel = getMessages();
                } else {
                    this.tradingContractList = tradingContractService.searchBusinessObjects(this.tradingContractFilter);
                }

            }
            return NOT_NAVIGATE;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }
    }

    /**
     * Method responsible for the action to visualize contract.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String visualizeContract() {

        this.visualization = true;
        return this.update();
    }

    /**
     * Method responsible for calling the save method from the business layer.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String confirm() {

        String goPage = null;
        ITradingContractService tradingContractService = getService(ITradingContractService.class);

        try {
            this.calculateContractValueAndBalance();
            
            this.addRightPad();
            
            if (super.isNewer()) {
                // Add language
                this.tradingContract.getIncoterms().getId().setLanguageCd(this.getLanguage());
                this.tradingContract.getCurrency().getId().setLanguageCd(this.getLanguage());
                this.tradingContract.getCity().getId().setLanguageCd(this.getLanguage());

                if (!super.hasValue(this.tradingContract.getApprovedFl())) {
                    this.tradingContract.setApprovedFl(YesNoList.NO.getFlag());
                }
                
                tradingContractService.save(this.tradingContract);
            } else {
                if (!super.hasValue(this.tradingContractBusiness)) {
                    
                    this.tradingContractBusiness = new TradingContractBusiness();
                }
                this.tradingContractBusiness.setTradingContract(this.tradingContract);
                if (!this.simulationBackupList.isEmpty()) {
                    this.tradingContractBusiness.setSimulationBusinessList(this.simulationBackupList);
                }
                tradingContractService.update(this.tradingContractBusiness);
            }

            goPage = SHOW_RESULT;

            this.setMessages(tradingContractService.getMessages());
            this.addTrim();

            if (tradingContractService.isOk()) {
                this.initializeTradingContract();
                this.historyList.clear();
                if (!super.isNewer()) {
                    this.tradingContractList = tradingContractService.searchBusinessObjects(this.tradingContractFilter);
                }
            } else {
                for (final MessageVO message : tradingContractService.getMessages()) {
                    if (IBarterConstants.MSG_CONCURRENCE_ERROR.equals(message.getId())) {
                        tradingContractService.getMessages().clear();
                        this.tradingContract = tradingContractService.findByIdComplete(this.tradingContract);
                        break;
                    }
                }
                goPage = NOT_NAVIGATE;
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            goPage = NOT_NAVIGATE;
        }

        return goPage;
    }

    /**
     * Method responsible for calling the save method from the business layer in action of approve the contract.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String approve() {
        
        String goPage = null;
        
        this.tradingContract.setApprovedFl(YesNoList.YES.getFlag());  
        if (!super.isNewer()) {
            this.tradingContractBusiness = new TradingContractBusiness();
            this.tradingContractBusiness.setApprovedFl(Boolean.TRUE);
        }
        
        goPage = this.confirm();
        
        if (NOT_NAVIGATE.equalsIgnoreCase(goPage)) {
            this.tradingContract.setApprovedFl(YesNoList.NO.getFlag());
            if (this.tradingContractBusiness != null) {
            	this.tradingContractBusiness.setApprovedFl(Boolean.FALSE);
			}
        }
        
        return goPage;
    }
    
    /**
     * Method responsible for the action to cancel.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String cancel() {
        try {
            super.setNewer(true);
            this.visualization = false;
            this.initializeTradingContract();

            this.historyList.clear();
            this.listCity.clear();
            this.listRegion.clear();

            if (super.hasValue(this.tradingContractFilter)
                && super.hasValue(this.tradingContractFilter.getTradingContract())
                && super.hasValue(this.tradingContractFilter.getTradingContract().getCity())
                && super.hasValue(this.tradingContractFilter.getTradingContract().getCity().getId())) {

                String countryId = this.tradingContractFilter.getTradingContract().getCity().getId().getCountryCd();

                if (super.hasValue(countryId)) {
                    this.loadTrading(countryId);
                    this.loadCommodity(countryId);
                } else {
                    this.listTrading.clear();
                    this.listCommodity.clear();
                }
            }

            if (!super.isNewer()) {
                
                this.search();
            }
            super.setNewer(true);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return SHOW_RESULT;
    }

    /**
     * Method responsible for the action to open popup of simulations search.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnSimulationAdd() {

        try {
            
            SimulationFaces simulationFaces = super.getFaces(MANAGED_BEAN_SIMULATION);
            simulationFaces.search(true);

            if (hasValue(simulationFaces)) {
                if (!this.simulationList.isEmpty() && hasValue(simulationFaces.getFilter())) {
                        String[] simulationsNumbers = new String[this.simulationList.size()];
                        for (int i = 0; i < simulationsNumbers.length; i++) {
                            simulationsNumbers[i] = this.simulationList.get(i).getSimulationNumber();
                        }
                        simulationFaces.getFilter().setSimulationsNumbers(simulationsNumbers);
                    }
                if (super.hasValue(simulationFaces.getFilter()) && !super.hasValue(simulationFaces.getFilter().getStatusList())) {
                    String[] statusList = {SimulationStatusList.APPROVED.getCod(), SimulationStatusList.WAITING_APPROVAL.getCod()};
                    simulationFaces.getFilter().setStatusList(statusList);
                }
            }
            
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for the action to include simulations.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void includeSelectedSimulations() {

        try {
            SimulationFaces simulationFaces = super.getFaces(MANAGED_BEAN_SIMULATION);
            if (super.hasValue(simulationFaces)) {

                if (super.hasValue(simulationFaces.getSimulationList())) {
                    List<SimulationBusiness> simulationsSelectedList = new ArrayList<SimulationBusiness>();

                    for (SimulationBusiness simulation : simulationFaces.getSimulationList()) {
                        if (simulation.isChecked()) {
                            simulationsSelectedList.add(simulation);
                        }
                    }

                    ITradingContractService tradingContractService = getService(ITradingContractService.class);
                    List<SimulationBusiness> list = tradingContractService.validateBalance(simulationsSelectedList,
                        this.simulationList, this.tradingContract);
                    this.simulationList.addAll(list);
                    this.simulationBackupList.addAll(list);
                    this.totalValueSimulations = this.calculateTotalSimulations();
                    this.setMessages(tradingContractService.getMessages());
                }

                simulationFaces.setSimulationList(null);
                simulationFaces.setFilter(new SimulationFilter());
                simulationFaces.verifyUserType();
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for the action to cancel selection of simulations.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cancelIncludeSimulations() {

        try {
            SimulationFaces simulationFaces = super.getFaces(MANAGED_BEAN_SIMULATION);
            if (super.hasValue(simulationFaces)) {
                simulationFaces.setSimulationList(null);
                simulationFaces.setFilter(new SimulationFilter());
                simulationFaces.verifyUserType();
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for the action of remove simulation.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String btnSimulationRemove() {

        try {
            SimulationBusiness simulation = new SimulationBusiness();
            String simulationNumber = this.simulationBusiness.getSimulationNumber();
            for (SimulationBusiness simulationBusinessItem : this.simulationBackupList) {
                if (simulationBusinessItem.getSimulationNumber().equals(simulationNumber)) {
                    simulation = simulationBusinessItem;
                    break;
                }
            }
            if (simulation.isChecked()) {
                this.simulationBackupList.remove(simulation);
            } else {
                simulation.setActionFlg(ActionList.DELETE);
            }

            this.simulationList.remove(this.index);

            this.totalValueSimulations = this.calculateTotalSimulations();
            ITradingContractService tradingContractService = getService(ITradingContractService.class);
            this.tradingContract.setBalanceContract(tradingContractService.calculateBalance(this.simulationList,
                this.tradingContract));
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
        return NOT_NAVIGATE;
    }
    
    /**
     * Method responsible for the action to visualize simulation.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String visualizeSimulation() {

        SimulationFaces simulationFaces = getFaces(MANAGED_BEAN_SIMULATION);
        if (super.hasValue(simulationFaces)) {
            simulationFaces.setSimulationSelected(new SimulationBusiness());
            simulationFaces.getSimulationSelected().setSimulationNumber(this.simulationBusiness.getSimulationNumber());
            simulationFaces.visualizeSimulation();
        }
        this.getTradingContractList().clear();
        return SUCCESS;
    }
    
    /**
     * Event of change input text of payment date.
     * 
     * @param event
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void cldDeliveryDateChanged(ValueChangeEvent event) {
        
        if (event != null && hasValue(event.getNewValue())) {
            
            Date deliveryDate = (Date) event.getNewValue();
            tradingContract.setDeliveryDate(deliveryDate);
            
            final ITradingContractService tradingContractService = getService(ITradingContractService.class);
            tradingContractService.validateDeliveryDate(tradingContract);
            setMessages(tradingContractService);
        }
    }

    /**
     * Method responsible for the action of confirm exclusion of contract.
     * 
     * @return A string defining the page navigation
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public String btnConfirmDelete() {

        ITradingContractService contractService = getService(ITradingContractService.class);

        try {
            this.renderedPanel = false;
            contractService.delete(this.tradingContract);

            this.setMessages(contractService.getMessages());

            if (contractService.isOk()) {
                this.tradingContractList = contractService.searchBusinessObjects(this.tradingContractFilter);
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return ERROR;
        }

        return NOT_NAVIGATE;
    }

    /**
     * Method responsible for the action of cancel exclusion of contract.
     * 
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public void btnCancel() {

        this.renderedPanel = false;
        
        if (!QuoteTypeList.QUOTE.getCod().equals(this.tradingContract.getQuotationFL())) {
            this.clearFields();
        }        
    }

    /**
     * Method returns number of records in the list of contracts
     * 
     * @return List size.
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public int getQtdContracts() {

        int count = 0;
        if (this.tradingContractList != null) {
            count = this.tradingContractList.size();
        }
        return count;
    }

    /**
     * Method returns number of records in the list of simulation
     * 
     * @return List size.
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public int getQtdSimulations() {

        int count = 0;

        if (this.simulationList != null) {
            count = this.simulationList.size();
        }
        return count;
    }

    /**
     * Method returns number of records in the list of history
     * 
     * @return List size.
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public int getQtdHistory() {

        int count = 0;
        if (this.historyList != null) {
            count = this.historyList.size();
        }
        return count;
    }

    /**
     * @return the tradingContractFilter
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public TradingContractFilter getTradingContractFilter() {

        return tradingContractFilter;
    }

    /**
     * @param tradingContractFilter the tradingContractFilter to set
     */
    public void setTradingContractFilter(TradingContractFilter tradingContractFilter) {

        this.tradingContractFilter = tradingContractFilter;
    }

    /**
     * @return the tradingContractList
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public List<TradingContractBusiness> getTradingContracts() {

        return tradingContractList;
    }

    /**
     * @return the tradingContract
     * @author Jonatas O. Menezes (jonatas.menezes@cpmbraxis.com)
     */
    public TradingContract getTradingContract() {

        return tradingContract;
    }

    /**
     * @param tradingContract the tradingContract to set
     */
    public void setTradingContract(TradingContract tradingContract) {

        this.tradingContract = tradingContract;
    }

    /**
     * @return the listCountry
     */
    public List<SelectItem> getListCountry() {

        return listCountry;
    }

    /**
     * @return the listTrading
     */
    public List<SelectItem> getListTrading() {

        return listTrading;
    }

    /**
     * @return the listCommodity
     */
    public List<SelectItem> getListCommodity() {

        return listCommodity;
    }

    /**
     * @return the renderedDataTable
     */
    public boolean isRenderedDataTable() {

        return renderedDataTable;
    }

    /**
     * @return the listIncoterms
     */
    public List<SelectItem> getListIncoterms() {

        return listIncoterms;
    }

    /**
     * @return the listCurrency
     */
    public List<SelectItem> getListCurrency() {

        return listCurrency;
    }

    /**
     * @return the visualization
     */
    public boolean isVisualization() {

        return visualization;
    }

    /**
     * @return the disabledCboRegion
     */
    public boolean isDisabledCboRegion() {

        return disabledCboRegion;
    }

    /**
     * @return the disabledSackGrossPrice
     */
    public boolean isDisabledSackGrossPrice() {

        return disabledSackGrossPrice;
    }

    /**
     * @return the disabledCboPraca
     */
    public boolean isDisabledCboSquare() {

        return disabledCboSquare;
    }

    /**
     * @return the listRegion
     */
    public List<SelectItem> getListRegion() {

        return listRegion;
    }

    /**
     * @return the listCity
     */
    public List<SelectItem> getListCity() {

        return listCity;
    }

    /**
     * @return the historyList
     */
    public List<TradingContractHistory> getHistoryList() {

        return historyList;
    }

    /**
     * @return the tab
     */
    public String getTab() {

        return tab;
    }

    /**
     * @param tab - the tab to set
     */
    public void setTab(String tab) {

        this.tab = tab;
    }

    /**
     * @return the messagePanel
     */
    public String getMessagePanel() {

        return messagePanel;
    }

    /**
     * @return the renderedPanel
     */
    public boolean isRenderedPanel() {

        return renderedPanel;
    }

    /**
     * @return the listStatus
     */
    public List<SelectItem> getListStatus() {

        return listStatus;
    }

    /**
     * @return the totalValueSimulations
     */
    public BigDecimal getTotalValueSimulations() {

        return totalValueSimulations;
    }

    /**
     * @return the tradingContractBusiness
     */
    public TradingContractBusiness getTradingContractBusiness() {

        return tradingContractBusiness;
    }

    /**
     * @param tradingContractBusiness - the tradingContractBusiness to set
     */
    public void setTradingContractBusiness(TradingContractBusiness tradingContractBusiness) {

        this.tradingContractBusiness = tradingContractBusiness;
    }

    /**
     * @return the simulationList
     */
    public List<SimulationBusiness> getSimulationList() {

        return simulationList;
    }

    /**
     * @return the listQuote
     */
    public List<SelectItem> getListQuote() {

        return listQuote;
    }

    /**
     * @return the simulationBusiness
     */
    public SimulationBusiness getSimulationBusiness() {

        return simulationBusiness;
    }

    /**
     * @param simulationBusiness - the simulationBusiness to set
     */
    public void setSimulationBusiness(SimulationBusiness simulationBusiness) {

        this.simulationBusiness = simulationBusiness;
    }

    /**
     * @return the quotationFilter
     */
    public QuotationFilter getQuotationFilter() {

        return quotationFilter;
    }

    /**
     * @param quotationFilter - the quotationFilter to set
     */
    public void setQuotationFilter(QuotationFilter quotationFilter) {

        this.quotationFilter = quotationFilter;
    }

    /**
     * @return the quotationBusiness
     */
    public QuotationBusiness getQuotationBusiness() {

        return quotationBusiness;
    }

    /**
     * @param quotationBusiness - the quotationBusiness to set
     */
    public void setQuotationBusiness(QuotationBusiness quotationBusiness) {

        this.quotationBusiness = quotationBusiness;
    }

    /**
     * @param index - the index to set
     */
    public void setIndex(int index) {

        this.index = index;
    }

    /**
     * @return the listYesNo
     */
    public List<SelectItem> getListYesNo() {

        return listYesNo;
    }

    /**
     * @return the statusDeleteLabel
     */
    public Character getStatusDeleteLabel() {

        return statusDeleteLabel;
    }

    /**
     * @return the renderUsdRate
     */
    public boolean isRenderUsdRate() {

        return renderUsdRate;
    }

    /**
     * @return the usdRate
     */
    public BigDecimal getUsdRate() {

        return usdRate;
    }

    /**
     * @return the renderedConvertedValue
     */
    public boolean isRenderedConvertedValue() {

        return renderedConvertedValue;
    }

    /**
     * @return the contractTypeMG
     */
    public String getContractTypeMG() {

        return contractTypeMG;
    }

    /**
     * @return the enableSaveBtn
     */
    public boolean isEnableSaveBtn() {

        enableSaveBtn = access(PermissionList.NEW_TRADING_CONTRACT_SCREEN_PERMISSION_CD.getPermissionCd());

        return enableSaveBtn && !this.isVisualization();
    }

    /**
     * Checks if the authenticated user has access permission for the function tradingContractNew
     * 
     * @return TRUE if you have permission, FALSE otherwise
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public boolean isCanAccessTradingContractNew() {
        
        return access(PermissionList.NEW_TRADING_CONTRACT_SCREEN_PERMISSION_CD.getPermissionCd());
    }

    
    /**
     * @return the renderedRbQuotation
     */
    public boolean isRenderedRbQuotation() {
    
        return renderedRbQuotation;
    }

    public List<SelectItem> getListSelectRadio() {
        return listSelectRadio;
    }

    public void setListSelectRadio(List<SelectItem> listSelectRadio) {
        this.listSelectRadio = listSelectRadio;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign=campaign;
        loadTradingFromCampaign();
        loadCommodityFromCampaign();
    }

    private void loadCommodityFromCampaign() {

        this.listCommodity = new ArrayList<SelectItem>();

        for (Commodity item : campaign.getCommodities() ) {
            this.listCommodity.add(new SelectItem(item.getId().getCommodityId().trim(), item.getDescCommodity()));
        }

        this.listCommodity = super.sortSelectItem(this.listCommodity);

    }

    public List<SelectItem> getListTradingFromCampaign() {
        return listTradingFromCampaign;
    }

    public void setListTradingFromCampaign(List<SelectItem> listTradingFromCampaign) {
        this.listTradingFromCampaign = listTradingFromCampaign;
    }

    public List<TradingContractBusiness> getTradingContractList() {
        return tradingContractList;
    }

    public void setTradingContractList(List<TradingContractBusiness> tradingContractList) {
        this.tradingContractList = tradingContractList;
    }

    public List<SelectItem> getListContractType() {
        return listContractType;
    }

    public void setListContractType(List<SelectItem> listContractType) {
        this.listContractType = listContractType;
    }
}