
package com.monsanto.barter.web.faces.whitepapers;

import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.service.AttachmentService;
import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseReportJSF;
import com.monsanto.barter.business.entity.filter.WhitepaperFilter;
import com.monsanto.barter.business.entity.table.WhitePaper;
import com.monsanto.barter.business.entity.table.WhitepaperAttachment;
import com.monsanto.barter.business.service.IWhitePaperService;
import com.monsanto.barter.web.faces.fileupload.FileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: GAVELO
 * Date: 9/19/14
 * Time: 4:27 PM
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name = "whitepaperFaces")
@SessionScoped
public class WhitepaperFaces extends BaseReportJSF {

    private static final Logger LOG = Logger.getLogger(WhitepaperFaces.class);

    private WhitepaperFilter whitepaperFilter;
    private List<WhitePaper> whitepaperList = new ArrayList<WhitePaper>();
    private WhitePaper whitepaper;
    private boolean tableShow;
    private boolean enableSaveBtn;
    private boolean noEditable;
    private List<FileUpload> fileUploadHandlers = new ArrayList<FileUpload>();
    private List<WhitepaperAttachment> attachments = new ArrayList<WhitepaperAttachment>();
    private WhitepaperAttachment attachmentSelected;
    private boolean filesAttachedSuccessfully;
    private boolean renderAttachmentPopup;


    public WhitepaperFaces() {
        this.whitepaperFilter = new WhitepaperFilter();
    }

    public String searchWhitepaper(){

        IWhitePaperService whitePaperService = getService(IWhitePaperService .class);

        try {

            whitepaperList = whitePaperService.search(whitepaperFilter);
            tableShow = (!whitepaperList.isEmpty());

            // Get messages from the business layer.
            this.setMessages(whitePaperService.getMessages());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return SUCCESS;
    }


    public String editWhitepaper(){

        setNewer(false);
        return SUCCESS;

    }


    /**
     * Method responsible for loading screen new campaign
     *
     * @return string definig the page navigation
     * @author Jader Augusto do Monte Santos (jader.santos@cpmbraxis.com)
     */
    public String newWhitepaper() {
        this.whitepaper = new WhitePaper();
        setNewer(true);
        return NEW;
    }

    public String saveWhitepaper(){

        String navigation = NOT_NAVIGATE;

        IWhitePaperService whitePaperService = getService(IWhitePaperService .class);

        try {
            if (isNewer()) {
                whitepaper.setCreateBy(SecurityUtil.getLoggedInUser().getName());
                whitepaper.setCreatedDate(new Date());
            }
            whitepaper.setLastUpdatedBy(SecurityUtil.getLoggedInUser().getName());
            whitepaper.setLastUpdate(new Date());

            whitePaperService.save(whitepaper);
            // Get messages from the business layer.
            this.setMessages(whitePaperService.getMessages());

            if ( whitePaperService.isOk() ){
                setMessages(new MessageVO("whitepaper.new.success", MessageTypeList.INFO));
                navigation = SUCCESS;
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }

        return navigation;



    }

    public String cancelWhitepaper(){

        return SUCCESS;

    }


    public String beginSearch(){
        whitepaperList.clear();
        return SUCCESS;
    }


    public void addContractFileUploadHandler() {
        fileUploadHandlers.add(new FileUpload());
    }

    /**
     * Method responsible for generating file upload lines
     *
     * @author Sanjeev Kumar
     */

    public String prepareFileUploadForm() {
        LOG.debug("In FileUploadForm");
        renderAttachmentPopup = false;
        filesAttachedSuccessfully = false;

        try {
            fileUploadHandlers.clear();
            attachments.clear();
            final WhitepaperFilter whitepaperFilter = new WhitepaperFilter();
            whitepaperFilter.setName(whitepaper.getName());
            final IWhitePaperService whitePaperService = getService(IWhitePaperService.class);
            whitepaper = whitePaperService.search(whitepaperFilter).get(0);
            attachments.addAll(whitepaper.getAttachments());
            //By default 5 files to upload
            for (int i = 0; i < 5; i++) {
                addFileUploadHandler();
            }
            setMessages(whitePaperService.getMessages());

            renderAttachmentPopup = true;
            return SUCCESS;
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
            return NOT_NAVIGATE;
        }
    }

    public void addFileUploadHandler() {
        fileUploadHandlers.add(new FileUpload());
    }

    /**
     * Method responsible for attaching files to simulation
     *
     * @author Sanjeev Kumar
     */
    public void attachFiles() {
        try {
            final IWhitePaperService whitePaperService = getService(IWhitePaperService.class);
            if (isValidAttachments()) {
                for (FileUpload fileUploadHandler : fileUploadHandlers) {
                    if (fileUploadHandler.getFile() != null) {
                        WhitepaperAttachment attachment = new WhitepaperAttachment(fileUploadHandler.getFile());
                        attachments.add(attachment);
                    }
                }

                whitepaper.setAttachments(attachments);
                whitePaperService.save(whitepaper);
                setMessages(whitePaperService);

                if (whitePaperService.isOk()) {
                    filesAttachedSuccessfully = true;
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    /**
     * Method responsible for deleting the attachment
     *
     * @author Pragathi
     */
    public void deleteAttachment() {
        try {
            final IWhitePaperService whitePaperService = getService(IWhitePaperService.class);
            AttachmentService attachmentService = getService(AttachmentService.class);
            whitepaper.getAttachments().remove(attachmentSelected);
            whitePaperService.save(whitepaper);
            attachmentService.delete(attachmentSelected.getId());

            setMessages(whitePaperService);

            if (whitePaperService.isOk()) {
                attachments.remove(attachmentSelected);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            showHtmlException(e);
        }
    }

    public StreamedContent getFile() {
        return new DefaultStreamedContent(new ByteArrayInputStream(attachmentSelected.getFile().getFileContent()),
                attachmentSelected.getFile().getMimeType(), attachmentSelected.getFile().getFileName());
    }

    /**
     * Check the validity of the file uploaded
     *
     * @author Pragathi
     */
    private boolean isValidAttachments() {
        boolean valid = true;
        boolean validDocument = true;

        for (FileUpload fileUploadHandler : fileUploadHandlers) {
            fileUploadHandler.getUploadErrorMessages().clear();

            validDocument = true;
            if (fileUploadHandler.getFile() != null || fileUploadHandler.getUploadDocumentType() != null || StringUtils.isNotEmpty(fileUploadHandler.getUploadDocumentNumber())) {

                validDocument = isFileUploaded(fileUploadHandler) && fileSizeIsValid(fileUploadHandler) && validDocument;

                valid = validDocument ? valid : validDocument;
            }
        }

        return valid;
    }

    /**
     * checks if the file has been uploaded
     *
     * @author Sanjeev Kumar
     */

    private boolean isFileUploaded(FileUpload fileUploadHandler) {
        boolean valid = true;
        if (fileUploadHandler.getFile() == null) {
            fileUploadHandler.getUploadErrorMessages().add(getMessage("attachfiledialog.error.file.required"));
            valid = false;
        }
        return valid;
    }

    /**
     * checks the file size
     *
     * @author Sanjeev Kumar
     */

    private boolean fileSizeIsValid(FileUpload fileUploadHandler) {
        File file = fileUploadHandler.getFile();
        long length = file.getFileSize();
        boolean valid = true;

        if (length > 5242880) {
            valid = false;
            fileUploadHandler.getUploadErrorMessages().add(getMessage("fileUpload.invalidSize.error"));
        }
        return valid;
    }

    public WhitepaperFilter getWhitepaperFilter() {
        return whitepaperFilter;
    }

    public void setWhitepaperFilter(WhitepaperFilter whitepaperFilter) {
        this.whitepaperFilter = whitepaperFilter;
    }

    public List<WhitePaper> getWhitepaperList() {
        return whitepaperList;
    }

    public void setWhitepaperList(List<WhitePaper> whitepaperList) {
        this.whitepaperList = whitepaperList;
    }

    public WhitePaper getWhitepaper() {
        return whitepaper;
    }

    public void setWhitepaper(WhitePaper whitePaper) {
        this.whitepaper = whitePaper;
    }

    public boolean isTableShow() {
        return tableShow;
    }

    public void setTableShow(boolean tableShow) {
        this.tableShow = tableShow;
    }

    public int getWhitepaperCount(){

        if ( whitepaperList != null ){
            return whitepaperList.size();
        }

        return 0;

    }

    /**
     * @return the noEditable
     */
    public boolean isNoEditable() {

        return noEditable;
    }

    /**
     * @param noEditable - the noEditable to set
     */
    public void setNoEditable(boolean noEditable) {

        this.noEditable = noEditable;
    }

    /**
     * @return the enableSaveBtn
     */
    public boolean isEnableSaveBtn() {

        //enableSaveBtn = access(PermissionList.NEW_CAMPAIGN_SCREEN_PERMISSION_CD.getPermissionCd());
        enableSaveBtn = true;

        return enableSaveBtn && !this.isNoEditable();
    }

    /**
     * @param enableSaveBtn - the enableSaveBtn to set
     */
    public void setEnableSaveBtn(boolean enableSaveBtn) {

        this.enableSaveBtn = enableSaveBtn;
    }

    public List<FileUpload> getFileUploadHandlers() {
        return fileUploadHandlers;
    }

    public void setFileUploadHandlers(List<FileUpload> fileUploadHandlers) {
        this.fileUploadHandlers = fileUploadHandlers;
    }

    public List<WhitepaperAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<WhitepaperAttachment> attachments) {
        this.attachments = attachments;
    }

    public WhitepaperAttachment getAttachmentSelected() {
        return attachmentSelected;
    }

    public void setAttachmentSelected(WhitepaperAttachment attachmentSelected) {
        this.attachmentSelected = attachmentSelected;
    }

    public boolean isFilesAttachedSuccessfully() {
        return filesAttachedSuccessfully;
    }

    public void setFilesAttachedSuccessfully(boolean filesAttachedSuccessfully) {
        this.filesAttachedSuccessfully = filesAttachedSuccessfully;
    }

    public boolean isRenderAttachmentPopup() {
        return renderAttachmentPopup;
    }

    public void setRenderAttachmentPopup(boolean renderAttachmentPopup) {
        this.renderAttachmentPopup = renderAttachmentPopup;
    }
}

