package com.monsanto.barter.web.filters;

import com.monsanto.barter.architecture.security.helper.SecurityHelper;
import com.monsanto.barter.business.entity.table.User;
import com.monsanto.barter.business.service.IUserService;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.FilterConfig;

/**
 * @author JPBENI
 */
public class BarterBrMonitoringFilter extends BaseMonitoringFilter {

    private static Long IT_SUPPORT_GROUP = 10L;

    SecurityHelper securityHelper = new SecurityHelper();

    private IUserService userService;

    @Override
    public boolean loggedUserCanToggleMonitoring() {
        String loggedUser = getSecurityHelper().getLoggedInUser();
        User userEntity = new User();
        userEntity.setUserIdMonsanto(loggedUser);

        User userVO = getUserService()
                .findByIdMonsantoWithPermission(userEntity);
        if (userVO != null && userVO.getGroup() != null) {
            Long userGroup = userVO.getGroup().getId();
            if(userGroup.equals(IT_SUPPORT_GROUP)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void init(FilterConfig cfg) {
        ApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(cfg.getServletContext());
        this.userService = ctx.getBean(IUserService.class);
    }

    public IUserService getUserService() {
        return userService;
    }

    public SecurityHelper getSecurityHelper() {
        return securityHelper;
    }
}
