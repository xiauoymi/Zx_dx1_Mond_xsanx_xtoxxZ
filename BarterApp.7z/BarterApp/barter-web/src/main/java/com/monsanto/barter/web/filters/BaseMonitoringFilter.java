package com.monsanto.barter.web.filters;

import net.bull.javamelody.MonitoringFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.context.FacesContext;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

/**
 * @author JPBENI
 */
public abstract class BaseMonitoringFilter extends MonitoringFilter {
    private static final Logger LOG = LoggerFactory.getLogger(BaseMonitoringFilter.class);
    private static boolean monitoringEnabled = false;

    public abstract boolean loggedUserCanToggleMonitoring();

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        if (loggedUserCanToggleMonitoring()) {
            checkForMonitoringEnablingArgument(request);
        }

        if (monitoringEnabled) {
            super.doFilter(request, response, chain);
        } else {
            chain.doFilter(request, response);
        }
    }

    /**
     * Enables or disables monitoring filter based on an URL argument with the form:
     * <p/>
     * <pre>
     *     http://URL/some...path?monitoring[=disabled]
     * </pre>
     * <p/>
     */
    private void checkForMonitoringEnablingArgument(ServletRequest request) {
        final String monitoringDisableParameter = request.getParameter("monitoring");
        if (monitoringDisableParameter != null) {
            LOG.info("Has URL enable/disable argument: " + !monitoringDisableParameter.isEmpty());
            if (monitoringDisableParameter.equals("disabled")) {
                LOG.warn("Globally disabling monitoring...");
                monitoringEnabled = false;
            } else {
                LOG.warn("Globally enabling monitoring...");
                monitoringEnabled = true;
            }
        }
    }

    protected FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

}
