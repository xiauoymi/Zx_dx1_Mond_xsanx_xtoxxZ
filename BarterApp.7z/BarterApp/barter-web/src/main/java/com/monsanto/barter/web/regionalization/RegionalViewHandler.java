package com.monsanto.barter.web.regionalization;

import com.monsanto.barter.architecture.exception.DisconnectedUserException;
import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.sun.faces.application.view.MultiViewHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.faces.context.FacesContext;
import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: DRIAL
 * Date: 28/10/13
 * Time: 16:25
 * To change this template use File | Settings | File Templates.
 */
public class RegionalViewHandler extends MultiViewHandler {
    @Autowired
    private CountryHolder countryHolder;

    public void setCountryHolder(CountryHolder countryHolder) {
        this.countryHolder = countryHolder;
    }

    public Locale calculateLocale(FacesContext context) {
        try {
            if (countryHolder != null) {
                Country country = countryHolder.getCountry();
                //If the country is Argentina, we don't need the loggedInUser logic here.
                if (!country.equals(Country.ARGENTINA))
                {
                    User loggedInUser = SecurityUtil.getLoggedInUser();
                    loggedInUser.setLanguageCd(country.getCodLanguage());
                    loggedInUser.setCountyCd(country.getCountrySAPCd());
                }


            } else {
                SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
            }

            return countryHolder.getCountry().getLocale();

        } catch (DisconnectedUserException e ) {
            return super.calculateLocale(context);
        }
        catch (Exception e){
            return super.calculateLocale(context);
        }
    }
}
