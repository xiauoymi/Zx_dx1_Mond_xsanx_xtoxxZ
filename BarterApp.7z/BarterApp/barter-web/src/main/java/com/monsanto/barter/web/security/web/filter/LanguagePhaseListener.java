package com.monsanto.barter.web.security.web.filter;

import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.apache.log4j.Logger;

import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.list.LanguageList;

/**
 *
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 10/01/2012
 */
public class LanguagePhaseListener implements PhaseListener {

    /** */
    private static final long serialVersionUID = 220932008471654418L;

    private static final Logger LOG = Logger.getLogger(LanguagePhaseListener.class);

    /**
     * Default constructor of the class.
     *
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public LanguagePhaseListener() {

        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
     */
    @Override
    public void afterPhase(PhaseEvent event) {}

    /*
     * (non-Javadoc)
     * 
     * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
     */
    @Override
    public void beforePhase(PhaseEvent event) {
        try {

            if (SecurityUtil.getLoggedInUser() != null && SecurityUtil.getLoggedInUser().getLanguageCd() != null) {

                event.getFacesContext().getViewRoot()
                        .setLocale(LanguageList.getByCodLanguage(SecurityUtil.getLoggedInUser().getLanguageCd()).getLocale());
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.faces.event.PhaseListener#getPhaseId()
     */
    @Override
    public PhaseId getPhaseId() {

        return PhaseId.RENDER_RESPONSE;
    }

}
