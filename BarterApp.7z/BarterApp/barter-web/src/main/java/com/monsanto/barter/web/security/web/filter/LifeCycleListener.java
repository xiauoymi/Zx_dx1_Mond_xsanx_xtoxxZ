package com.monsanto.barter.web.security.web.filter;

import org.apache.log4j.Logger;

import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

/**
 * Created with IntelliJ IDEA.
 * User: DRIAL
 * Date: 14/11/13
 * Time: 19:18
 **/
public class LifeCycleListener implements PhaseListener {

    protected static final Logger LOG = Logger.getLogger(LifeCycleListener.class);

    public PhaseId getPhaseId() {
        return PhaseId.ANY_PHASE;
    }


    public void beforePhase(PhaseEvent event) {
        // LOG.info("BEFORE PHASE + " + event.getFacesContext().getViewRoot());
        // LOG.info("BEFORE PHASE usr + " + SecurityUtil.getLoggedInUser().getName());

        if (event.getFacesContext().getViewRoot()!=null) {
            LOG.info("BEFORE PHASE viewID+ " + event.getFacesContext().getViewRoot().getViewId());
        }
        LOG.debug("START PHASE " + event.getPhaseId());
    }

    public void afterPhase(PhaseEvent event) {
        // LOG.info("AFTER PHASE + " + event.getFacesContext().getViewRoot());
        // LOG.info("AFTER PHASE usr + " + SecurityUtil.getLoggedInUser().getName());
        if (event.getFacesContext().getViewRoot()!=null) {
            LOG.info("AFTER PHASE viewID+ " + event.getFacesContext().getViewRoot().getViewId());
        }
        LOG.debug("END PHASE " + event.getPhaseId());
    }
}
