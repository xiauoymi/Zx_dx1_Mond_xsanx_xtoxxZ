package com.monsanto.barter.web.security.web.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.barter.architecture.regionalization.CountryHolder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.security.helper.SecurityHelper;
import com.monsanto.barter.architecture.util.MessageUtil;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.filter.BaseFilter;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.business.util.IBarterConstants;
import org.springframework.web.context.ServletContextAware;

/**
 * HTTP filter that controls access to application resources.
 *
 * @author Maycon Willian Oliveira
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @version 1.0
 * @since version 2011
 */
public class SecurityFilter extends BaseFilter implements BeanNameAware, EnvironmentAware, ServletContextAware, InitializingBean, DisposableBean {

    private static final String DEVELOPMENT_LOGIN_PAGE = "login.jsf";

    private static final Logger LOG = Logger.getLogger(SecurityFilter.class);

    private static final String STR_BAR = "/";

    //TODO Remove the log4jAdmin and health related pages and secure them appropriately
    private static final List<String> PAGES_ACCESS_FREE = Arrays.asList(DEVELOPMENT_LOGIN_PAGE, "sandbox.jsf", "home.jsf", "home-ar.jsf", "permission_error.jsf",
            "log4jAdmin_list.jsf", "log4jAdmin_form.jsf", "healthCheck.jsf", "bill-of-lading-wizard.jsf", "login_error.jsf", "country_login_error.jsf",
            "error.jsf","profile-form.jsf","profile-list.jsf","user-registration-list.jsf","user-registration-form.jsf","user-registration-info.jsf", "user-registration-profile.jsf");

    private SecurityHelper securityHelper;

    @Autowired
    private IUserService userService;



    @Autowired
    private  CountryHolder countryHolder;

    /**
     * Indicates whether the application is in simulation mode.
     */
    private boolean isLocalEnvironment;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        super.init(filterConfig);

        isLocalEnvironment = SecurityUtil.isLocalEnvironment();
        LOG.debug("local environment = " + isLocalEnvironment);

        securityHelper = new SecurityHelper();
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException,
            ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        getCountryHolder().resolveCountry(request.getServerName());

        if (!isLocalModeAndGoToLoginPage(httpRequest)) {
            if (isGoingToDevelopmentLoginPage(httpRequest)) {
                redirectToPermissionError(httpRequest, httpResponse);
            }

            final String loggedInUser = getLoggedInUser();
            getSecurityHelper().logContextInfo(httpRequest);

            if (getSecurityUser(httpRequest) == null) {
                try {
                    if (loggedInUser != null) {
                        setUpUser(httpRequest, httpResponse);
                        if(getSecurityUser(httpRequest) == null){
                            redirectToLoginError(httpRequest, httpResponse);
                            return;
                        }
                    }
                } catch (Exception e) {
                    LOG.error("Exception raised in UserAuthenticationFilter", e);
                }
            } else {
                SecurityUtil.setLoggedInUser(getSecurityUser(httpRequest));
            }

            // Check that user COUNTRY_CD match URL COUNTRY_CD.
            if ( ! getSecurityUser(httpRequest).getCountyCd().equals(getCountryHolder().getCountry().getCountrySAPCd())
                    && !httpRequest.getRequestURI().contains("country_login_error")){
                redirectToLoginError(httpRequest, httpResponse);
                return;
            }

            if (canAccessPage(getSecurityUser(httpRequest), httpRequest.getServletPath())) {
                filterChain.doFilter(request, response);
            } else {
                redirectToPermissionError(httpRequest, httpResponse);
            }
        } else {
            if (!isLocalEnvironment) {
                redirectToPermissionError(httpRequest, httpResponse);
            } else {
                filterChain.doFilter(request, response);
            }
        }
    }

    private void redirectToPermissionError(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException {
        httpResponse.sendRedirect(httpRequest.getContextPath() + "/pages/admin/permission_error.jsf");
    }

    private void redirectToLoginError(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException {
        StringBuilder sbPageRedirect = new StringBuilder();
        sbPageRedirect.append(httpRequest.getContextPath()).append("/pages/admin/country_login_error.jsf");
        httpResponse.sendRedirect(sbPageRedirect.toString());
    }

    /**
     * Returns the logged in user
     * @param request {@link HttpServletRequest}
     * @return {@link User}
     */
    public User getSecurityUser(HttpServletRequest request) {
        return (User) request.getSession().getAttribute(MessageUtil.getMessage(IBarterConstants.SECURITY_USER));
    }

    /**
     * Returns the logged in user id
     * @return Logged in user id
     */
    protected String getLoggedInUser() {
        return getSecurityHelper().getLoggedInUser();
    }

    /**
     * Sets the user in the session and in the SecurityUtil (case the user is not in the session).
     * @param request {@link HttpServletRequest}
     */
    private void setUpUser(HttpServletRequest request, HttpServletResponse httpResponse) throws IOException {
        LOG.info("Inside setupUser...");
        String loggedInUser = getLoggedInUser();

        LOG.debug("Setting up user \"" + loggedInUser + "\"");

        if (!isUserInSession(request)) {
            LOG.info("Data is not available in session ...");
            com.monsanto.barter.business.entity.table.User userEntity = new com.monsanto.barter.business.entity.table.User();
            userEntity.setUserIdMonsanto(loggedInUser);

            com.monsanto.barter.business.entity.table.User userVO = getService()
                    .findByIdMonsantoWithPermission(userEntity);

            if (userVO != null) {
                User user = new User(userVO.getId());
                user.setName(userVO.getName());
                user.setEmail(userVO.getEmail());
                user.setLanguageCd(userVO.getLanguageCd());
                user.setCountyCd( userVO.getCountryCd());

                for (com.monsanto.barter.business.entity.table.Permission permission : userVO.getPermissions()) {
                    user.getPermissions().add(new Permission(permission.getPermissionCd()));
                }

                if (userVO.getGroup() != null) {
                    for (com.monsanto.barter.business.entity.table.Permission permission : userVO.getGroup()
                            .getPermissions()) {
                        user.getPermissions().add(new Permission(permission.getPermissionCd()));
                    }
                }
                request.getSession().setAttribute(MessageUtil.getMessage(IBarterConstants.SECURITY_USER), user);
                SecurityUtil.setLoggedInUser(user);
            } else {
                LOG.warn("User " + loggedInUser + " not found in database.");
                //redirectToLoginError(request, httpResponse);
            }
        }
    }

    protected IUserService getService() {
        return userService;
    }

    /**
     * Check if the logged in user is in the session
     *
     * @param request {@link HttpServletRequest}
     * @return <tt>TRUE</tt> if is in the session, <tt>FALSE</tt> otherwise.
     */
    private boolean isUserInSession(HttpServletRequest request) {
        User userFromSession = getSecurityUser(request);
        String loggedInUser = getLoggedInUser();
        return (null != userFromSession && !StringUtils.isEmpty(loggedInUser));
    }

    /**
     * Checks if this in simulation mode and going to the login page
     *
     * @param request {@link HttpServletRequest}
     * @return <tt>TRUE</tt> if in simulation mode and are going to login page, <tt>FALSE</tt> otherwise
     */
    private boolean isLocalModeAndGoToLoginPage(HttpServletRequest request) {
        return (isLocalEnvironment && isGoingToDevelopmentLoginPage(request));
    }

    private boolean isGoingToDevelopmentLoginPage(HttpServletRequest request) {
        return request.getServletPath().lastIndexOf(DEVELOPMENT_LOGIN_PAGE) > -1;
    }

    /**
     * Checks if the authenticated user has access permission for the function
     *
     * @param functionId Function id
     * @return <tt>TRUE</tt> if you have permission, <tt>FALSE</tt> otherwise
     */
    protected boolean access(User user, int functionId) {
        boolean canAccess = false;

        if (user != null) {
            for (Permission permission : user.getPermissions()) {
                if (permission.getId().equals(Integer.valueOf(functionId))) {
                    canAccess = true;
                    break;
                }
            }
        }
        return canAccess;
    }

    /**
     * Checks if the authenticated user has access permission for the page
     *
     * @param user logged in user
     * @param page page
     * @return <tt>TRUE</tt> if you have permission, <tt>FALSE</tt> otherwise
     */
    protected boolean canAccessPage(User user, String page) {
        String obtainedPage = page;
        if (obtainedPage.length() > obtainedPage.lastIndexOf(STR_BAR) + 1) {
            obtainedPage = obtainedPage.substring(obtainedPage.lastIndexOf(STR_BAR) + 1, obtainedPage.length());
        }

        boolean canAccess = PAGES_ACCESS_FREE.contains(obtainedPage);

        if (!canAccess) {
            for (PermissionList permission : PermissionList.getByPage(obtainedPage)) {
                if (access(user, permission.getPermissionCd())) {
                    return true;
                }
            }
        }

        return canAccess;
    }

    /**
     * Returns the {@link SecurityHelper}
     * @return the securityHelper
     */
    public SecurityHelper getSecurityHelper() {
        return securityHelper;
    }

    /**
     * @param securityHelper - the securityHelper to set
     */
    public void setSecurityHelper(SecurityHelper securityHelper) {
        this.securityHelper = securityHelper;
    }

    @Override
    public void setBeanName(String name) {
        try {
            this.init(null);
        } catch (ServletException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    @Override
    public void setEnvironment(Environment environment) {
    }

    @Override
    public void afterPropertiesSet() {}

    @Override
    public void setServletContext(ServletContext servletContext) {
    }

    public CountryHolder getCountryHolder() {
        return countryHolder;
    }
}
