package com.monsanto.barter.web.security.web.filter;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.GlobalBarterUser;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.GlobalBarterUserService;
import com.monsanto.barter.ar.web.faces.beans.user.InactiveUserException;
import com.monsanto.barter.ar.web.faces.beans.user.UserNotFoundException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.ServletContextAware;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class SecurityFilterAr implements BeanNameAware, EnvironmentAware, ServletContextAware, InitializingBean, DisposableBean, Filter {
    private static final Logger LOG = Logger.getLogger(SecurityFilterAr.class);

    public static final String USER = "user";

    @Autowired
    private GlobalBarterUserService service;

    @Override
    public void doFilter(ServletRequest servletRequest , ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
        LOG.debug("doFilter");
        HttpServletRequest request= (HttpServletRequest) servletRequest;
        HttpServletResponse response= (HttpServletResponse) servletResponse;
        if (request.getSession().getAttribute(USER) == null) {
            validateAuthentication(request, response);
            UserDecorator userDecorator = getUserPrincipal();
            SecurityContextHolder.getContext().setAuthentication(userDecorator);
            request.getSession().setAttribute("user", userDecorator.getName());
        }
        chain.doFilter(request, response);
    }

    private void validateAuthentication(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        if(authentication !=null && !authentication.isAuthenticated()){
            LOG.debug("User not Authenticated");
            authentication.setAuthenticated(false);
            request.getSession().invalidate();
            response.sendRedirect(GlobalBarterSecurityHelper.getLogoutUrl());
        }
    }

    private UserDecorator getUserPrincipal() {
        UserDecorator userDecorator = null;
        String username = GlobalBarterSecurityHelper.getLoggedUserName();
        LOG.debug("Searching for user: " + username);
        GlobalBarterUser globalBarterUser = service.findByUsername(username);
        if (globalBarterUser != null && globalBarterUser.getStatus() == StatusEnum.ACTIVE) {
            userDecorator = service.getAuthenticatedUserBy(username);
            userDecorator.setAuthenticated(true);
        } else {
            if (globalBarterUser == null) {
                LOG.debug("User not found: " + username);
                throw new UserNotFoundException("User not found: " + username);
            } else {
                LOG.debug("User is inactive: " + username);
                throw new InactiveUserException("User is inactive: " + username);
            }
        }
        return userDecorator;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}

    @Override
    public void afterPropertiesSet() {}

    @Override
    public void setBeanName(String name) {}

    @Override
    public void setEnvironment(Environment environment) {}

    @Override
    public void setServletContext(ServletContext servletContext) {}

}
