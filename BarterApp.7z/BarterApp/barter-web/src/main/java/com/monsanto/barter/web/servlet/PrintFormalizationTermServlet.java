package com.monsanto.barter.web.servlet;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

import org.apache.log4j.Logger;

import com.monsanto.barter.business.entity.business.FormalizationTermBusiness;

public class PrintFormalizationTermServlet extends HttpServlet {

    private static final Logger LOG = Logger.getLogger(PrintFormalizationTermServlet.class);

    private static final long serialVersionUID = -1459789808206200466L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doGet(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // set header as pdf
        response.setContentType("application/pdf");

        // set input and output stream
        ServletOutputStream servletOutputStream = response.getOutputStream();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        FileInputStream fis;
        BufferedInputStream bufferedInputStream;

        try {
            //String reportLocation = context.getRealPath("WEB-INF");  
            File fileReport = new File(getServletContext().getRealPath(
                "WEB-INF/rel/termFormalizacao3.5.2.jasper"));            
            //fis = new FileInputStream(reportLocation + "/rel/termFormalizacao3.5.2.jasper");  
            fis = new FileInputStream(fileReport);  
            try {
                bufferedInputStream = new BufferedInputStream(fis);

                // fetch data from database
                HttpServletRequest httpRequest = (HttpServletRequest) request;
                HttpSession session = httpRequest.getSession(false);
                @SuppressWarnings("unchecked")
                final List<FormalizationTermBusiness> relFormalizationList = (List<FormalizationTermBusiness>)session.getAttribute("PrintFormalizationTermData");
                // fill it
                JRBeanCollectionDataSource jrbcds = new JRBeanCollectionDataSource(relFormalizationList);
                JasperReport jasperReport = (JasperReport) JRLoader.loadObject(bufferedInputStream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<Object, Object>(),
                    jrbcds);

                // export to pdf
                JasperExportManager.exportReportToPdfStream(jasperPrint, baos);
                response.setContentLength(baos.size());
                baos.writeTo(servletOutputStream);

            } finally {
                // close it
                fis.close();
            }
            bufferedInputStream.close();

        } catch (Exception ex) {

            LOG.error(ex.getMessage(), ex);

        } finally {
            servletOutputStream.flush();
            servletOutputStream.close();
            baos.close();
        }
    }

}
