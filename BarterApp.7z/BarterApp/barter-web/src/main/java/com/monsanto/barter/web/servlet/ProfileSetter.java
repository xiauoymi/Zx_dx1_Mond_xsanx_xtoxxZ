package com.monsanto.barter.web.servlet;

import com.monsanto.barter.ar.soa.util.BarterArPropertiesReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * @author IVERT
 */
public class ProfileSetter implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    Logger logger = LoggerFactory.getLogger(ProfileSetter.class);

    public ProfileSetter() {}

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        String lsiFunction = System.getProperty("lsi.function");
        configurableApplicationContext.getEnvironment().setActiveProfiles(lsiFunction);
        boolean useDummyServices = false;
        try {
            BarterArPropertiesReader propertiesReader = new BarterArPropertiesReader();
            String dummyServicesProperty = propertiesReader.getEnvironmentSpecificProperty("dummyServices");
            if (dummyServicesProperty != null &&
                    (dummyServicesProperty.equals("true") || dummyServicesProperty.equals("enabled"))) {
                useDummyServices = true;
            }
        } catch (Exception ex) {
            if (lsiFunction.equals("win") || lsiFunction.equals("dev") || lsiFunction.equals("it")) {
                logger.error("Failed to evaluate the dummyServices configuration variable.");
            }
        }

        if (lsiFunction.equals("win") || lsiFunction.equals("dev") || lsiFunction.equals("it")) {
            if (useDummyServices){
                configurableApplicationContext.getEnvironment().addActiveProfile("dummyServices");
                logger.warn("*** DUMMY SERVICES MODE ENABLED ***");
            } else {
                configurableApplicationContext.getEnvironment().addActiveProfile("liveServices");
                logger.info("Live services mode enabled.");
            }
        } else {
            if (useDummyServices) {
                logger.warn("Dummy services are only available for 'win', 'dev' and 'it' environments.");
            }
            configurableApplicationContext.getEnvironment().addActiveProfile("liveServices");
        }
    }
}
