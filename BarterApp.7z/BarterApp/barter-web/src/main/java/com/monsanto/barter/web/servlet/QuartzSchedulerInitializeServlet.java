package com.monsanto.barter.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

/**
 * @author guido.trueb
 * 
 */
public class QuartzSchedulerInitializeServlet extends HttpServlet {

    // private static final Logger LOG = Logger.getLogger(QuartzSchedulerInitializeServlet.class);

    private static final long serialVersionUID = 892801190093348050L;

    @Override
    public void init() throws ServletException {

        super.init();

        // try {
        // CampaignDueDateScheduler.getInstance().initializeScheduler();
        // } catch (Exception e) {
        // LOG.error(e.getMessage(), e);
        // }
    }

    @Override
    public void destroy() {

        // try {
        // CampaignDueDateScheduler.getInstance().shutdownScheduler();
        // } catch (Exception e) {
        // LOG.error(e.getMessage(), e);
        // }

        super.destroy();
    }
}
