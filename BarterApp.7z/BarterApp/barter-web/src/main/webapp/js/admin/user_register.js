function validateUserRegisterForm(msg1, msg2, msg3, msg4, msg5) {
	
	var returns = true;
	clearErrorMessages();

	if (executeValidation) {

		returns = validateRequiredField(returns, "formUser:txtUserNome", msg1);
		returns = validateRequiredField(returns, "formUser:txtUserIdMonsanto", msg5);
		returns = validateRequiredField(returns, "formUser:txtNome", msg2);
		returns = validateRequiredField(returns, "formUser:cboLanguage", msg3);
		returns = validateRequiredField(returns, "formUser:cboStatus", msg4);
	}

	executeValidation = false;
	return returns;
}