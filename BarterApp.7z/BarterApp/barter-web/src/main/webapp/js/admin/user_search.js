function validateUserSearchForm(msg1) {

	var returns = false;
	clearErrorMessages();

	if (executeValidation) {

		var ids = [ "formFiltro:cboUnit", "formFiltro:cboRegional",
				"formFiltro:cboGroup", "formFiltro:txtName",
				"formFiltro:txtId", "formFiltro:cboStatus" ];

		returns = validateRequiredFieldAtLeastOne(returns, ids, msg1);
	}
	return returns;
}