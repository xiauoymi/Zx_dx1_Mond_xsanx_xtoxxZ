function validateCommunicationRegisterForm(msg1, msg2, msg3, msg4, msg5, msg6, msg7, validatePeriod, validateFile) {

	var returns = true;
	clearErrorMessages();

	if (executeValidation) {
		returns = validateRequiredField(returns, "registerForm:drpType", msg1);
		returns = validateRequiredField(returns, "registerForm:txtName", msg2);

		if (validatePeriod) {
			var validDates = true;
			validDates = validateRequiredField(validDates, "registerForm:cldPeriodBeginInputDate", msg3);
			if (validDates) {
				validDates = validateInitialPeriod(validDates, "registerForm:cldPeriodBeginInputDate", msg6);
				
				if(validDates){
					validDates = validateRequiredField(validDates, "registerForm:cldPeriodEndInputDate", msg3);
				}
				
				if(validDates){
					validDates = validateDateRange(validDates, "registerForm:cldPeriodBeginInputDate", "registerForm:cldPeriodEndInputDate", msg4);
				}
			}
			returns = returns && validDates;
		}

		if (validateFile) {
			returns = validateRequiredField(returns, "registerForm:uploadFile", msg5);
			if(returns){
				returns = validateSizeFile(returns, "registerForm:uploadFile", msg7);
			}
		}
	}
	
	return returns;
}

function validateCommunicationSearchForm(msg, validatePeriod) {
	
	var returns = true;
	clearErrorMessages();
	
	if (executeValidation && validatePeriod) {
		returns = validateDateRange(returns, "formSearch:cldPeriodBeginInputDate", "formSearch:cldPeriodEndInputDate", msg);
	}
	
	return returns;
}

function validateSizeFile(returns, field, msg){
	var returns = true;
	clearErrorMessages();
	
	if(navigator.appName!='Microsoft Internet Explorer'){
		var file = document.getElementById(field);
		
		if(file.files[0].size > 10485760){
			showErrorMessage(msg);
			returns = false;
		}
	}else{
		// TODO: inserir código do IE
	}
	
	return returns;
}