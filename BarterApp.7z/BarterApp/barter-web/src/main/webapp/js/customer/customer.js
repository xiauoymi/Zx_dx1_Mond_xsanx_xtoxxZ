function validateSelectionCustomer(msg) {
	flag = false;
	clearErrorMessagesByErrorSpanId("popUpErrorSpanCustomer");
	jQuery('span[id*="txtMessagesCustomer"]').text('');
	
	jQuery('input[name*="rbCustomer"]').each(function(index) {
		if (jQuery(this).is(':checked') == true) {
			flag = true;
			return false;
		}
	});

	if (!flag) {
		showErrorMessage(msg, "popUpErrorSpanCustomer");
	}
	return flag;
}

function validateCustomerSearchForm(msg1) {
	returns = false;
	clearErrorMessagesByErrorSpanId("popUpErrorSpanCustomer");
	
	var fieldIds = [ "formCustomerSearch:txtName",
	 				"formCustomerSearch:txtSapCd",
	 				"formCustomerSearch:txtCpfCnpj",
                    "formCustomerSearch:distrChannelCd" ];

	returns = validateRequiredFieldAtLeastOneByErrorSpanId(returns, fieldIds, msg1, "popUpErrorSpanCustomer");

	return returns;
}