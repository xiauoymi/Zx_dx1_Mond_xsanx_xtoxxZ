
		jQuery(function() {
			jQuery("input").keydown(function(event) {
	            if (event.keyCode == 13 || event.wich == 13) {
	                return false;
	            }
	        });
	    });
		function disableAllButtons() {
			if (disableButtons) {
				jQuery(':submit,:button').each(function() {
					jQuery(this).attr("disabled", "true");
				});
			}
			disableButtons = true;
		}
		function enableAllButtons() {
			if (disableButtons) {
				jQuery(':submit,:button').each(function() {
					jQuery(this).attr("disabled", "");
				});
			}
			disableButtons = true;
		}

var executeValidation = false;
var focusSetted = false;
var disableButtons = true;

/*** 
 * Descri��o.: formata um campo do formul�rio de 
 * acordo com a m�scara informada... 
 * Par�metros: - objForm (o Objeto Form) 
 * - strField (string contendo o nome 
 * do textbox) 
 * - sMask (mascara que define o 
 * formato que o dado ser� apresentado, 
 * usando o algarismo "9" para 
 * definir n�meros e o s�mbolo "!" para 
 * qualquer caracter... 
 * - evtKeyPress (evento) 
 * Uso.......: <input type="textbox" 
 * name="xxx"..... 
 * onkeypress="return txtBoxFormat(document.rcfDownload, 'str_cep', '99999-999', event);"> 
 * Observa��o: As m�scaras podem ser representadas como os exemplos abaixo: 
 * CEP -> 99.999-999 
 * CPF -> 999.999.999-99 
 * CNPJ -> 99.999.999/9999-99 
 * Data -> 99/99/9999 
 * Tel Resid -> (99) 999-9999 
 * Tel Cel -> (99) 9999-9999 
 * Processo -> 99.999999999/999-99 
 * C/C -> 999999-! 
 * E por a� vai... 
 ***/
function txtBoxFormat(objForm, strField, sMask, evtKeyPress) {
      var i, nCount, sValue, fldLen, mskLen,bolMask, sCod, nTecla;

      if(document.all) { // Internet Explorer
        nTecla = evtKeyPress.keyCode; }
      else if(document.layers) { // Nestcape
        nTecla = evtKeyPress.which;
      }

      sValue = objForm[strField].value;

      // Limpa todos os caracteres de formata��o que
      // j� estiverem no campo.
      sValue = sValue.toString().replace( "-", "" );
      sValue = sValue.toString().replace( "-", "" );
      sValue = sValue.toString().replace( ".", "" );
      sValue = sValue.toString().replace( ".", "" );
      sValue = sValue.toString().replace( "/", "" );
      sValue = sValue.toString().replace( "/", "" );
      sValue = sValue.toString().replace( "(", "" );
      sValue = sValue.toString().replace( "(", "" );
      sValue = sValue.toString().replace( ")", "" );
      sValue = sValue.toString().replace( ")", "" );
      sValue = sValue.toString().replace( " ", "" );
      sValue = sValue.toString().replace( " ", "" );
      fldLen = sValue.length;
      mskLen = sMask.length;

      i = 0;
      nCount = 0;
      sCod = "";
      mskLen = fldLen;

      while (i <= mskLen) {
        bolMask = ((sMask.charAt(i) == "-") || (sMask.charAt(i) == ".") || (sMask.charAt(i) == "/"));
        bolMask = bolMask || ((sMask.charAt(i) == "(") || (sMask.charAt(i) == ")") || (sMask.charAt(i) == " "));

        if (bolMask) {
          sCod += sMask.charAt(i);
          mskLen++; }
        else {
          sCod += sValue.charAt(nCount);
          nCount++;
        }

        i++;
      }

      objForm[strField].value = sCod;

      if (nTecla != 8) { // backspace
        if (sMask.charAt(i-1) == "9") { // apenas n�meros...
          return ((nTecla > 47) && (nTecla < 58)); } // n�meros de 0 a 9
        else { // qualquer caracter...
          return true;
        } 
      } else {
        return true;
      }
}

function validateRequiredField(returns, fieldId, errorMsg) {
	return validateRequiredFieldByErrorSpanId(returns, fieldId, errorMsg, "errorSpan");
}

function validateRequiredFieldByErrorSpanId(returns, fieldId, errorMsg, errorSpanId) {

	var field = document.getElementById(fieldId);
	
	if (field && trim(field.value) == "") {
		showErrorMessage(errorMsg, errorSpanId);
		setFocusField(field);
		returns = false;
	}
	
	return returns;
}

function validateRequiredFieldAtLeastOne(returns, fieldId, errorMsg) {
	return validateRequiredFieldAtLeastOneByErrorSpanId(returns, fieldId, errorMsg, "errorSpan");
}

function validateRequiredFieldAtLeastOneByErrorSpanId(returns, fieldId, errorMsg, errorSpanId) {

	for ( var i = 0; i < fieldId.length; i++) {
		var field = document.getElementById(fieldId[i]);
		if (field && trim(field.value) != "") {
			returns = true;
		}
	}
	if(!returns) {
		showErrorMessage(errorMsg, errorSpanId);
	}

	return returns;
}

function validateMonetaryRequiredField(returns, fieldId, errorMsg, maskZero) {
	return validateMonetaryRequiredFieldByErrorSpanId(returns, fieldId, errorMsg, maskZero, "errorSpan");
}

function validateMonetaryRequiredFieldByErrorSpanId(returns, fieldId, errorMsg, maskZero, errorSpanId) {

	var field = document.getElementById(fieldId);

	if (field && (field.value == null || trim(field.value) == "" || trim(field.value) == maskZero)) {
		showErrorMessage(errorMsg, errorSpanId);
		setFocusField(field);
		returns = false;
	}

	return returns;
}

function validateInputRadioRequiredField(returns, fieldName, errorMsg) {
	return validateInputRadioRequiredFieldByErrorSpanId(returns, fieldName, errorMsg, "errorSpan");
}

function validateInputRadioRequiredFieldByErrorSpanId(returns, fieldName, errorMsg, errorSpanId) {

	var field = document.getElementsByName(fieldName);
	var i;
	var checked = false;
	var firstOption = null;
	for (i=0;i<field.length;i++){ 
		if (i == 0) {
			firstOption = field[i];
		}
		if (field[i].type == "radio" && field[i].checked) {
			checked = true;
			break;
		}
   	}
	
	if (!checked) {
		showErrorMessage(errorMsg, errorSpanId);
		if (firstOption) {
			setFocusField(firstOption);
		}
		returns = false;
	}

	return returns;
}

function clearErrorMessages() {

	var errorSpan = document.getElementById("errorSpan");
	errorSpan.style.display = "none";
	errorSpan.innerHTML = "";
	
	var serverErrorSpan = document.getElementById("serverErrorSpan");
	if (serverErrorSpan) {
		serverErrorSpan.style.display = "none";
		serverErrorSpan.innerHTML = "";
	}
	
	var popUpErrorSpan = document.getElementById("popUpErrorSpan");
	if (popUpErrorSpan) {
		popUpErrorSpan.style.display = "none";
		popUpErrorSpan.innerHTML = "";
	}

	focusSetted = false;
}

function clearErrorMessagesByErrorSpanId(errorSpanId) {
	var errorSpan = document.getElementById(errorSpanId);
	if (errorSpan) {
		errorSpan.style.display = "none";
		errorSpan.innerHTML = "";
	}
}

function showErrorMessage(errorMsg, errorSpanId) {

	var errorSpan = document.getElementById(errorSpanId);

	errorSpan.innerHTML += "<p style=\"margin-left: 10px;\"> "
			+ "<img src=\"../../img/error_alert.gif\" width=\"16\" height=\"16\" align=\"absmiddle\"/> "
			+ errorMsg
			+ "</p> ";
	
	errorSpan.style.display = "block";
}

function validateDateRange(returns, fieldId1, fieldId2, errorMsg) {
	return validateDateRangeByErrorSpanId(returns, fieldId1, fieldId2, errorMsg, "errorSpan");
}

function validateDateRangeByErrorSpanId(returns, fieldId1, fieldId2, errorMsg, errorSpanId) {

	var field1 = document.getElementById(fieldId1);
	var field2 = document.getElementById(fieldId2);
	
	var beginDate = new Date(field1.value.substring(6, 10) + "/" + field1.value.substring(3, 5) + "/" + field1.value.substring(0, 2)); 
	var endDate = new Date(field2.value.substring(6, 10) + "/" + field2.value.substring(3, 5) + "/" + field2.value.substring(0, 2));
	
	if (beginDate.getTime() >= endDate.getTime()){		
		showErrorMessage(errorMsg, errorSpanId);
		setFocusField(field2);
		returns = false;
	}	
	
	return returns;
}

function validateDateRangeGreaterEqualsByErrorSpanId(returns, fieldId1, fieldId2, errorMsg, errorSpanId, onlyGreater) {
	
	var field1 = document.getElementById(fieldId1);
	var field2 = document.getElementById(fieldId2);
	
	var beginDate = new Date(field1.value.substring(6, 10) + "/" + field1.value.substring(3, 5) + "/" + field1.value.substring(0, 2)); 
	var endDate = new Date(field2.value.substring(6, 10) + "/" + field2.value.substring(3, 5) + "/" + field2.value.substring(0, 2));
	
	if ((onlyGreater && beginDate.getTime() >= endDate.getTime())
			|| (!onlyGreater && beginDate.getTime() > endDate.getTime())){		
		showErrorMessage(errorMsg, errorSpanId);
		setFocusField(field2);
		returns = false;
	}	
	
	return returns;
}

function validateMonetaryValue(returns, fieldId, errorMsg) {
	return validateMonetaryValueByErrorSpanId(returns, fieldId, errorMsg, "errorSpan");
}

function validateMonetaryValueByErrorSpanId(returns, fieldId, errorMsg, errorSpanId) {

	var field = document.getElementById(fieldId);
	
	if (trim(field.value) != "") {
		var regex = new RegExp(/^\d*[0-9](\.\d*[0-9])*(\,\d*[0-9])?$/);
		if (!regex.test(field.value)) {
			showErrorMessage(errorMsg, errorSpanId);
			setFocusField(field);
			returns = false;
		}
	}
	return returns;
}

function validateDate(returns, fieldId, errorMsg) {
	return validateDateByErrorSpanId(returns, fieldId, errorMsg, "errorSpan");
}

function validateDateByErrorSpanId(returns, fieldId, errorMsg, errorSpanId) {

	var field = document.getElementById(fieldId);
	if (field && trim(field.value) != "") {
		var er = new RegExp(/^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/(19|20)?\d{4}$/);
		if (!er.test(field.value)) {
			showErrorMessage(errorMsg, errorSpanId);
			returns = false;
		} else if(field.value.split("/")[1] == "02"){
			if ((field.value.split("/")[2] % 4) == 0){
				if (field.value.split("/")[0] > 29) {
					showErrorMessage(errorMsg, errorSpanId);
					returns = false;
				}
			}
			else {
				if (field.value.split("/")[0] > 28 ) {
					showErrorMessage(errorMsg, errorSpanId);
					returns = false;
				}
			}
		}
	}
	return returns;
}

function validateDateField(field) {

	if (trim(field.value) != "") {
		var er = new RegExp(/^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/(19|20)?\d{4}$/);
		if (!er.test(field.value)) {
			field.value = "";
		} else if(field.value.split("/")[1] == "02"){
			if ((field.value.split("/")[2] % 4) == 0){
				if (field.value.split("/")[0] > 29) {
					field.value="";
				}
			}
			else {
				if (field.value.split("/")[0] > 28 ) {
					field.value="";
				}
			}
		}
	}
}


function trim(str) {
	if (str != null) {
		return str.replace(/^\s+|\s+$/, "");
	}
	return "";
}

function setFocusField(field) {
	if (!focusSetted) {
		focusSetted = true;
		if(!field.disabled){
			field.focus();
		}	
	}
}

function validateInitialPeriod(returns, fieldId1, errorMsg) {
	return validateInitialPeriodByErrorSpanId(returns, fieldId1, errorMsg, "errorSpan");
}

function validateInitialPeriodByErrorSpanId(returns, fieldId1, errorMsg, errorSpanId) {

	var field1 = document.getElementById(fieldId1);

	var beginDate = new Date(field1.value.substring(6, 10) + "/"
			+ field1.value.substring(3, 5) + "/" + field1.value.substring(0, 2));
	var dateAux = new Date();
	var endDate = new Date(dateAux.getFullYear(), dateAux.getMonth(), dateAux
			.getDate(), 0, 0, 0, 0);

	if (beginDate.getTime() < endDate.getTime()) {
		showErrorMessage(errorMsg, errorSpanId);
		setFocusField(field1);
		returns = false;
	}

	return returns;
}

function maxLengthTextArea(field, limit) {

	if (field && field.value.length > limit) {
		field.value = field.value.substring(0, limit);
	}
}
