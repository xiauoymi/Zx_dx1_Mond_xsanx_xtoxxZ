
function validateGroupRegisterForm(msg1, msg2) {

	var returns = true;
	clearErrorMessages();

	if (executeValidation) {
		returns = validateRequiredField(returns,
				"formCadastroGroup:txtname", msg1);
		
		returns = validateRequiredField(returns,
				"formCadastroGroup:cboStatusGroup", msg2);
	}
	
	executeValidation = false;
	return returns;
}
