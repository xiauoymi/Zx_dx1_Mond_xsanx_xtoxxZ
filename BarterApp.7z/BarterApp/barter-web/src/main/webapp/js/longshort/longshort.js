function validateLongShortRegisterForm(msg1, msg2, msg3) {
	
	var returns = true;
	clearErrorMessages();
	
	if (executeValidation) {
		executeValidation = false;
		returns = validateRequiredField(returns, "formLongShort:cboCountry", msg1);
		returns = validateRequiredField(returns, "formLongShort:cboComodity", msg2);
		returns = validateRequiredField(returns, "formLongShort:txtKgLimitation", msg3);
	}
	
	return returns;
}

function validateLongShortViewConsumptionForm(msg1, msg2) {

	var returns = true;
	clearErrorMessages();
	
	if (executeValidation) {
		executeValidation = false;
		returns = validateRequiredField(returns, "formViewLongShortConsumption:cboCountry", msg1);
		returns = validateRequiredField(returns, "formViewLongShortConsumption:cboCommodity", msg2);
	}
	
	return returns;
}

function cboCountryAvailableChanged(event){
    var status = event.status;
    switch (status){
        case 'begin':
            disableAllButtons()  ;
        case 'complete':
            enableAllButtons()  ;
    }
}