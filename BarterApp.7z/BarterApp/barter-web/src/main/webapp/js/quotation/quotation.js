function validateOpenPopUp(msg1, msg2, form, isSimulation, msg3, msg4) {
	returns = true;
	clearErrorMessages();
	
	// Get quotation.
	var fieldRbQuotation = document.getElementsByName(form + ":rbQuotation");
	var i; 
	for (i=0;i<fieldRbQuotation.length;i++){ 
		if (fieldRbQuotation[i].type == "radio" && fieldRbQuotation[i].checked) {
			
			// If is quotation.
			if (fieldRbQuotation[i].value == "S") {
				if (isSimulation) {
					returns = validateRequiredField(returns, form + ":drpBarterType", msg3);
					
					var barterType = document.getElementById(form + ":drpBarterType").value;
					if (barterType == '2') {
						returns = validateRequiredField(returns, form + ":drpTrading", msg4);
					}
				}

				// Validation commodity.
				returns = validateRequiredField(returns, form + ":cboCommodity", msg1);
				
				// Validation currency.
				returns = validateRequiredField(returns, form + ":cboCurrency", msg2);
				
				break;
			}
			
		}
   	}
	return returns;
}
