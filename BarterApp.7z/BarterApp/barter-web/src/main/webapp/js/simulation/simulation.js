function validateSimulationSearchForm(a, b, c, d, e) {
    var f = false;
    clearErrorMessages();
    if (executeValidation) {
        var g = ["formSearch:drpStatus", "formSearch:cldDateBeginInputDate", "formSearch:cldDateEndInputDate", "formSearch:txtRTV", "formSearch:drpCampaign", "formSearch:txtCustomer", "formSearch:drpPaymentCondition"];
        f = validateRequiredFieldAtLeastOneByErrorSpanId(f, g, a, e);
        f = validateDateByErrorSpanId(f, "formSearch:cldDateBeginInputDate", b, e);
        f = validateDateByErrorSpanId(f, "formSearch:cldDateEndInputDate", c, e);
        f = validateDateRangeGreaterEqualsByErrorSpanId(f, "formSearch:cldDateBeginInputDate", "formSearch:cldDateEndInputDate", d, e, false)
    } else {
        return true
    }
    return f
}
function validateSimulationFCPAForm(a) {
    var b = true;
    clearErrorMessages();
    b = validateInputRadioRequiredField(b, "fcpaForm:rbtFcpa", a);
    return b
}
function validateSimulationCampaignForm(a) {
    var b = true;
    clearErrorMessages();
    b = validateRequiredField(b, "campaignForm:drpCampaign", a);
    return b
}
function validateSimulationRegisterForm(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y) {
    var z = true;
    clearErrorMessages();
    if (executeValidation) {
        executeValidation = false;

        var B = document.getElementById("registerForm:drpBarterType").value;
        var C = document.getElementById("registerForm:chkDiffDelivLocation");
        var D = document.getElementById("registerForm:drpRegion").value;
        if (x && !y) {
            z = validateRequiredField(z, "registerForm:txtCustomer", a)
        }
        z = validateRequiredField(z, "registerForm:drpBarterType", b);
        if (x && !y) {
            z = validateRequiredField(z, "registerForm:drpCrop", d)
        }
        if (C && C.checked && !y) {
            z = validateRequiredField(z, "registerForm:txtDiffDelivLocation", e)
        }
        if (B != "3" && B != "4") {
            z = validateRequiredField(z, "registerForm:drpTrading", f)
        }
        if (B == "3") {
            z = validateRequiredField(z, "registerForm:drpRegion", w)
        }
        if (B == "3" || D != null && D != "") {
            z = validateRequiredField(z, "registerForm:drpLocalWarehouse", g)
        }
        if (!y) {
            z = validateRequiredField(z, "registerForm:cboCurrency", h)
        }
        if (x) {
            z = validateRequiredField(z, "registerForm:drpPaymentCondit", i)
        }
        if (!x || B != "4") {
            z = validateRequiredField(z, "registerForm:cboCommodity", j)
        }
        if (x && !y && isReqField(document.getElementById("registerForm:txtIncentive"))) {
            z = validateRequiredField(z, "registerForm:txtIncentive", k)
        }
        if (B != "3") {
            z = validateRequiredField(z, "registerForm:drpIncoterms", l)
        }
        if (!x || B != "4") {
            z = validateRequiredField(z, "registerForm:txtSackGrossPrice", m)
        }
        if (B != "4" && document.getElementById("registerForm:rbQuotation") != null) {
            z = validateInputRadioRequiredField(z, "registerForm:rbQuotation", n)
        }
        if (!x || B != "4") {
            z = validateRequiredField(z, "registerForm:txtKgQtd", o)
        }
        if (B != "3") {
            if (B == "4") {
                var E = document.getElementById("registerForm:cldDelivDateInputDate");
                if (E && trim(E.value) == "") {
                    validateDate(z, "registerForm:cldDelivDateInputDate", q)
                }
            } else if (validateRequiredField(z, "registerForm:cldDelivDateInputDate", p)) {
                z = validateDate(z, "registerForm:cldDelivDateInputDate", q)
            } else {
                z = false
            }
        }
        if (x && !y) {
            if (validateRequiredField(z, "registerForm:cldPaymentDateInputDate", r) && validateDate(z, "registerForm:cldPaymentDateInputDate", s)) {
                z = validateInitialPeriod(z, "registerForm:cldPaymentDateInputDate", t)
            } else {
                z = false
            }
        }
        if (B == "2") {
            if (validateRequiredField(z, "registerForm:cldNegotDateInputDate", u)) {
                z = validateDate(z, "registerForm:cldNegotDateInputDate", v)
            } else {
                z = false
            }
        }
    }

    return z
}

function isReqField(field){
    if(field.className == "valueOptional"){
        return false;
    }
    return true;
}

function validateSearchSimulationForm(a) {
    flag = false;
    clearErrorMessages();
    jQuery('input[name*="chkSimulation"]').each(function (a) {
        if (jQuery(this).is(":checked") == true) {
            flag = true;
            return false
        }
    });
    if (!flag) {
        showErrorMessage(a, "popUpErrorSpan")
    }
    return flag
}
function validateSimulationItemForm(a, b, c, d, e, f, g) {
    returns = true;
    clearErrorMessages();
    returns = validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:drpDivision", a, "popUpErrorSpan");
    returns = validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:drpBrand", b, "popUpErrorSpan");
    returns = validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:drpProduct", c, "popUpErrorSpan");
    returns = validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:txtQuantity", d, "popUpErrorSpan");
    if (validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:cldDeliveryDateInputDate", e, "popUpErrorSpan")) {
        returns = validateDateByErrorSpanId(returns, "formSimulationItem:cldDeliveryDateInputDate", g, "popUpErrorSpan")
    } else {
        returns = false
    }
    returns = validateRequiredFieldByErrorSpanId(returns, "formSimulationItem:txtDiscountBarter", f, "popUpErrorSpan");
    return returns
}
function validateOpenPopUpItem(a, b, c, d, e) {
    returns = true;
    clearErrorMessages();
    returns = validateRequiredField(returns, "registerForm:drpCrop", c);
    returns = validateRequiredField(returns, "registerForm:cboCurrency", d);
    returns = validateRequiredField(returns, "registerForm:cldPaymentDateInputDate", a);
    returns = validateRequiredField(returns, "registerForm:drpPaymentCondit", e);
    if (returns) {
        returns = validateDate(returns, "registerForm:cldPaymentDateInputDate", b)
    }
    return returns
}
function validateTermsFormalizationForm(a, b, c, d, e, f, g, h, i) {
    var j = true;
    clearErrorMessagesByErrorSpanId("errorTermSpan");
    j = validateRequiredFieldByErrorSpanId(j, "formTermsFormalization:txtWarehouse", a, "errorTermSpan");
    var k = true;
    k = validateRequiredFieldByErrorSpanId(k, "formTermsFormalization:cldTermDateFromInputDate", b, "errorTermSpan");
    if (k) {
        k = validateDateByErrorSpanId(k, "formTermsFormalization:cldTermDateFromInputDate", c, "errorTermSpan")
    }
    if (k) {
        k = validateInitialPeriodByErrorSpanId(k, "formTermsFormalization:cldTermDateFromInputDate", d, "errorTermSpan")
    }
    k = validateRequiredFieldByErrorSpanId(k, "formTermsFormalization:cldTermDateToInputDate", e, "errorTermSpan");
    if (k) {
        k = validateDateByErrorSpanId(k, "formTermsFormalization:cldTermDateToInputDate", f, "errorTermSpan")
    }
    if (k) {
        k = validateDateRangeByErrorSpanId(k, "formTermsFormalization:cldTermDateFromInputDate", "formTermsFormalization:cldTermDateToInputDate", g, "errorTermSpan")
    }
    j = j && k;
    j = validateRequiredFieldByErrorSpanId(j, "formTermsFormalization:txtChangeAddress", h, "errorTermSpan");
    j = validateRequiredFieldByErrorSpanId(j, "formTermsFormalization:txtMail", i, "errorTermSpan");
    return j
}
function showSignatureMessage(a) {
    showErrorMessage(a, "errorSpan")
}
function validateFormFiltroInvoice(a) {
    var b = true;
    clearErrorMessages();
    if (executeValidation) {
        executeValidation = false;
        b = validateRequiredField(b, "formFiltroInvoice:cboSimulation", a)
    }
    return b
}
function validateIncludeReason(a, b, c, d, e, f) {
    var g = true;
    clearErrorMessagesByErrorSpanId(c);
    g = validateRequiredFieldByErrorSpanId(g, a, e, c);
    if (g) {
        var h = document.getElementById(a);
        if (trim(h.value) == d) {
            g = validateRequiredFieldByErrorSpanId(g, b, f, c)
        }
    }
    return g
}
function submitCropValue(a, b) {
    var c = document.getElementById("registerForm:drpCrop");
    var d = document.getElementById("registerForm:hdnCrop");
    if (b && c.value != d.value && d.value != null && d.value != "") {
        if (confirm(a)) {
            d.value = c.value;
            c.form.submit()
        } else {
            c.value = d.value
        }
    } else {
        d.value = c.value;
        c.form.submit()
    }
}
function submitCurrencyValue(a, b) {
    var c = document.getElementById("registerForm:cboCurrency");
    var d = document.getElementById("registerForm:hdnCurrency");
    if (b && c.value != d.value && d.value != null && d.value != "") {
        if (confirm(a)) {
            d.value = c.value;
            c.form.submit()
        } else {
            c.value = d.value
        }
    } else {
        d.value = c.value;
        c.form.submit()
    }
}
function submitPaymentDateValue(a, b) {
    var c = document.getElementById("registerForm:cldPaymentDateInputDate");
    var d = document.getElementById("registerForm:hdnPaymentDate");
    if (b && c.value != d.value && d.value != null && d.value != "") {
        if (confirm(a)) {
            d.value = c.value;
            c.form.submit()
        } else {
            c.value = d.value
        }
    } else {
        d.value = c.value;
        c.form.submit()
    }
}

function clearCustomerForm(){

    document.getElementById('formCustomerSearch:txtName').value = '';
    document.getElementById('formCustomerSearch:txtSapCd').value = '';
    document.getElementById('formCustomerSearch:txtCpfCnpj').value = '';
    document.getElementById('formCustomerSearch:txtCpfCnpj').value = '';
    var distrChannelCdField = document.getElementById('formCustomerSearch:distrChannelCd');
    if (distrChannelCdField) { distrChannelCdField.value = ''; }


}