var returns = true;

function validateTradingContractRegisterForm(msg1, msg2, msg3, msg4, msg5, msg6, msg7,
		msg8, msg9, msg10, msg11, msg12, msg13, msg14, msg15, msg16, msg17, msg18, msg19) {
	
	returns = true;
	clearErrorMessages();

	// Execute validation
	if (executeValidation) {
		
		// Validation contract number.
		returns = validateRequiredField(returns, "formRegisterTradingContract:txtNbrContract", msg1);
		// Validation country.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cboCountry", msg2);
		// Validation trading.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cboTrading", msg3);
		// Validation commodity.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cboCommodity", msg4);
		// Validation negotiation date.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cldNegotiationDateInputDate", msg5);
				
		// Validation currency.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cboCurrency", msg6);
		// Validation payment date.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cldPaymentDateInputDate", msg7);
		
		if (returns) {
			returns = validateDate(returns, "formRegisterTradingContract:cldPaymentDateInputDate", msg8);
		}
						
		// Validation quotation.
		if (validateInputRadioRequiredField(true, "formRegisterTradingContract:rbQuotation", msg9)) {
			
			// Get quotation.
			var fieldRbQuotation = document.getElementsByName("formRegisterTradingContract:rbQuotation");
			var i; 
			for (i=0;i<fieldRbQuotation.length;i++){ 
				if (fieldRbQuotation[i].type == "radio" && fieldRbQuotation[i].checked) {
					
					// If quotation is price manual.
					if (fieldRbQuotation[i].value == "N") {
						
						// Validation required gross price.
						if (validateMonetaryRequiredField(true, "formRegisterTradingContract:txtGrossPrice", msg10, "0,00")) {
							// Validation if is number.
							returns = validateMonetaryValue(returns, "formRegisterTradingContract:txtGrossPrice", msg17);
						} else {
							returns = false;
						}
						
						// Validation region.
						returns = validateRequiredField(returns, "formRegisterTradingContract:cboRegion", msg11);
						
						// Validation square.
						returns = validateRequiredField(returns, "formRegisterTradingContract:cboSquare", msg12);
						
						break;
					}
					
				}
		   	}
			
		} else {
			returns = false;
		}
		
		// Validation incoterms.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cboIncoterms", msg13);
		
		// Volume validation in kilograms.
		if (validateMonetaryRequiredField(true, "formRegisterTradingContract:txtVolumeKg", msg14, "0,000")) {
			// Validation if is number.
			returns = validateMonetaryValue(returns, "formRegisterTradingContract:txtVolumeKg", msg15);
		} else {
			returns = false;
		}
		
		// Validation delivery date.
		returns = validateRequiredField(returns, "formRegisterTradingContract:cldDeliveryDateInputDate", msg15);
		
		if (returns) {
			returns = validateDate(returns, "formRegisterTradingContract:cldDeliverDateInputDate", msg19)
		}
		
		// Validation base year harverst.
		returns = validateRequiredField(returns, "formRegisterTradingContract:txtBaseYearHarvest", msg16);
	}
	
	executeValidation = false;
	return returns;	
}


function validateSelectionContract(msg) {
	flag = false;
	clearErrorMessagesByErrorSpanId("popUpErrorSpanContract");
	jQuery('span[id*="txtMessagesContract"]').text('');

	jQuery('input[name*="rbContract"]').each(function(index) {
		if (jQuery(this).is(':checked') == true) {
			flag = true;
			return false;
		}
	});

	if (!flag) {
		showErrorMessage(msg, "popUpErrorSpanContract");
	}
	return flag;
}
