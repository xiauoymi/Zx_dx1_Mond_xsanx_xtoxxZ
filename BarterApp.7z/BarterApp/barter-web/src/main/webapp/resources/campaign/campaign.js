var executeValidationAddBrand = false;
var executeValidationAddUnit = false;
var executeValidationAddTrading = false;
var executeValidationAddCommodity = false;
var executeValidationAddBarterType = false;
var setFocus = false;

function validateCampaignRegisterForm(msg1, msg2, msg3, msg4, msg5, msg6, msg7,
		msg8, msg9, msg10, msg11, msg12, msg13, msg14, msg15, msg16, msg17,
		msg18, msg19, msg20, msg21, msg22, msg23, msg24, msg25, msg26, msg27) {

	var returns = true;
	clearErrorMessages();

	if (executeValidation) {
		returns = validateRequiredField(returns,
				"formCadastroCampaign:cboCountry", msg1);
		returns = validateRequiredField(returns,
				"formCadastroCampaign:cmpgnName", msg2);
		returns = validateRequiredField(returns,
				"formCadastroCampaign:cmpgnCode", msg3);

		var validDates = true;
		validDates = validateRequiredField(validDates,
				"formCadastroCampaign:campaignPeriodFromInputDate", msg4);
		
		if (validDates) {
			validDates = validateDate(validDates,
					"formCadastroCampaign:campaignPeriodFromInputDate", msg5);
		}

		if (validDates) {
			validDates = validateInitialPeriod(validDates,
					"formCadastroCampaign:campaignPeriodFromInputDate", msg6);
		}

		validDates = validateRequiredField(validDates,
				"formCadastroCampaign:campaignPeriodToInputDate", msg7);
		
		if (validDates) {
			validDates = validateDate(validDates,
					"formCadastroCampaign:campaignPeriodToInputDate", msg8);
		}
		
		if (validDates) {
			validDates = validateDateRange(validDates,
					"formCadastroCampaign:campaignPeriodFromInputDate",
					"formCadastroCampaign:campaignPeriodToInputDate", msg9);
		}
		returns = returns && validDates;
		returns = validateRequiredField(returns,
				"formCadastroCampaign:cropBaseYear", msg10);

		returns = validateRequiredField(returns,
				"formCadastroCampaign:campaignMaxPaymentInputDate", msg11);
		
		if (returns) {
			returns = validateDate(returns,
					"formCadastroCampaign:campaignMaxPaymentInputDate", msg12);
		}

		returns = validateRequiredField(returns,
				"formCadastroCampaign:cboCurrency", msg13);

		returns = hasValue(returns, "formCadastroCampaign:cmpgnMaxBilled",
				msg14);

		returns = validateMonetaryValue(returns,
				"formCadastroCampaign:cmpgnMaxBilled", msg24);

		returns = hasValueDiscount(returns, "formCadastroCampaign:cmpgnMaxDiscount",
				msg15);

		returns = validateMonetaryValue(returns,
				"formCadastroCampaign:cmpgnMaxDiscount", msg25);
	}

	if (executeValidationAddBrand) {
		returns = validateAddBrand(returns,
				"formCadastroCampaign:cboDivisionBrands",
				"formCadastroCampaign:cboBrands",
				"formCadastroCampaign:brandDiscount",
				"formCadastroCampaign:cboUnitBrands", msg18, msg16, msg17,
				msg26, msg19);

		if (returns) {
			returns = validateMonetaryValue(returns,
					"formCadastroCampaign:brandDiscount", msg23);
		}
	}

	if (executeValidationAddUnit) {
		returns = validateAddUnit(returns, "formCadastroCampaign:cboDivisions",
				"formCadastroCampaign:volumeUnit", "formCadastroCampaign:cboUnits", msg18, msg20, msg19);

		if (returns) {
			returns = validateMonetaryValue(returns,
					"formCadastroCampaign:volumeUnit", msg23);
		}
	}

	if (executeValidationAddTrading) {
		returns = validateAddTradindAndCommodity(returns,
				"formCadastroCampaign:cboTrading", msg21);
	}

	if (executeValidationAddCommodity) {
		returns = validateAddTradindAndCommodity(returns,
				"formCadastroCampaign:cboCommodities", msg22);
	}

    if (executeValidationAddBarterType) {
		returns = validateAddBarterType(returns,
				"formCadastroCampaign:cboBarterTypes", msg27);
	}

	executeValidation = false;
	executeValidationAddBrand = false;
	executeValidationAddUnit = false;
	executeValidationAddTrading = false;
	executeValidationAddCommodity = false;
    executeValidationAddBarterType = false;

	return returns;
}

function validateCampaignSearchForm(msg1, msg2) {
	
	var returns = true;
	clearErrorMessages();
	
	if (executeValidation) {
		returns = validateDate(returns,
				"formFiltro:cldPeriodBeginInputDate", msg1);
		
		returns = validateDate(returns,
				"formFiltro:cldPeriodEndInputDate", msg2);
		
		executeValidation = false;
	}
	
	return returns;
}

function hasValue(returns, fieldId1, errorMsg) {

	var field = document.getElementById(fieldId1);
	setFocus = false;

	if (field
			&& (field.value == null || trim(field.value) == "" || trim(field.value) == "0,00")) {
		showErrorMessage(errorMsg, "errorSpan");
		if (returns) {
			setFocusCampaign(field);
		}
		returns = false;
	}

	return returns;
}

function hasValueDiscount(returns, fieldId1, errorMsg) {

	var field = document.getElementById(fieldId1);
	setFocus = false;

	if (field
			&& (field.value == null || trim(field.value) == "")) {
		showErrorMessage(errorMsg, "errorSpan");
		if (returns) {
			setFocusCampaign(field);
		}
		returns = false;
	}

	return returns;
}

function validateAddTradindAndCommodity(returns, field1, msg) {
	var field = document.getElementById(field1);
	setFocus = false;

	if (field && (field.value == null || trim(field.value) == "")) {
		returns = false;
		setFocusCampaign(field);
		showErrorMessage(msg, "errorSpan");
	}

	return returns;
}

function validateAddBrand(returns, field1, field2, field3, field4, msg1, msg2, msg3, msg4, msg5) {

	var division = document.getElementById(field1);
	var brand = document.getElementById(field2);
	var discount = document.getElementById(field3);
	var unit = document.getElementById(field4);
	
	setFocus = false;

	if (division && (division.value == null || trim(division.value) == "")) {
		returns = false;
		setFocusCampaign(division);
		showErrorMessage(msg1, "errorSpan");
	}

	if (brand && (brand.value == null || trim(brand.value) == "")) {
		returns = false;
		setFocusCampaign(brand);
		showErrorMessage(msg2, "errorSpan");
	}

	if (discount
			&& (discount.value == null || trim(discount.value) == "")) {
		returns = false;
		setFocusCampaign(discount);
		showErrorMessage(msg3, "errorSpan");
	}

	if (discount && (discount.value.length >= 6)) {
		returns = false;
		setFocusCampaign(discount);
		showErrorMessage(msg4, "errorSpan");
	}

	if (unit && (unit.value == null || trim(unit.value) == "")) {
		returns = false;
		setFocusCampaign(unit);
		showErrorMessage(msg5, "errorSpan");
	}
	
	return returns;
}

function validateAddUnit(returns, field1, field2, field3, msg1, msg2, msg3) {
	var division = document.getElementById(field1);
	var volume = document.getElementById(field2);
	var unit = document.getElementById(field3);
	setFocus = false;

	if (division && (division.value == null || trim(division.value) == "")) {
		returns = false;
		setFocusCampaign(division);
		showErrorMessage(msg1, "errorSpan");
	}

	if (unit && (unit.value == null || trim(unit.value) == "")) {
		returns = false;
		setFocusCampaign(unit);
		showErrorMessage(msg3, "errorSpan");
	}

	if (volume && (volume.value == null || trim(volume.value) == "" || trim(volume.value) == "0,00")) {
		returns = false;
		setFocusCampaign(volume);
		showErrorMessage(msg2, "errorSpan");
	}

	return returns;
}

function validateAddBarterType(returns, field1, msg) {
	var field = document.getElementById(field1);
	setFocus = false;

	if (field && (field.value == null || trim(field.value) == "")) {
		returns = false;
		setFocusCampaign(field);
		showErrorMessage(msg, "errorSpan");
	}

	return returns;
}


function setFocusCampaign(field) {
	if (!setFocus) {
		setFocus = true;
		field.focus();
	}
}