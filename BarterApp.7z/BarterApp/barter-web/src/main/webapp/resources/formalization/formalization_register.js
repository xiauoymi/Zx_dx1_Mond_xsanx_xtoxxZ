function validateFormalizationTermRegisterForm(msg1, msg2, msg3, msg4, msg5,
		msg6, msg7, msg8, msg9, msg10, msg11) {

	var returns = true;
	clearErrorMessages();

	if (executeValidation) {

		returns = validateRequiredField(returns,
				"formFormalizationTerm:cboLanguage", msg1);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:distributorText", msg2);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:monsantoText", msg3);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:productText", msg4);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:cropText", msg5);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:quantityText", msg6);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:storeHouseText", msg7);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:deliveryDateText", msg8);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:addressText", msg9);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:deadLineText", msg10);
		returns = validateRequiredField(returns,
				"formFormalizationTerm:contractBodyText", msg11);
	}

	executeValidation = false;
	return returns;
}

function printFormalizationRegister(msg) {
	if (confirm(msg)) {
		features = "height=700,width=700,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes";
		winId = window.open('formalization_print.jsf', 'none', features);
	}
	return false;
}

function openPrinter() {
	window.print();
}

var textarea = null;
var textAreaId = null;
var textAreaCursor = null;

function onpenTagPopup(value) {
	if (value != null) {
		textAreaId = value;
		textarea = document.getElementById("formFormalizationTerm:" + value);
		textAreaCursor = getCaret(textarea);
	}
}

function closeTagPopup(value) {
	if (textarea != null) {
		
		firstValue = textarea.value.substring(0, textAreaCursor);
		secondValue = textarea.value.substring(textAreaCursor);
		newValue = firstValue + value + secondValue;

		if (textAreaId != null && 'distributorText' == textAreaId) {
			i = 249;
		} else if (textAreaId != null && 'distributorText' == textAreaId) {
			i = 249;
		} else if (textAreaId != null && 'monsantoText' == textAreaId) {
			i = 249;
		} else if (textAreaId != null && 'productText' == textAreaId) {
			i = 99;
		} else if (textAreaId != null && 'cropText' == textAreaId) {
			i = 99;
		} else if (textAreaId != null && 'quantityText' == textAreaId) {
			i = 149;
		} else if (textAreaId != null && 'storeHouseText' == textAreaId) {
			i = 149;
		} else if (textAreaId != null && 'deliveryDateText' == textAreaId) {
			i = 99;
		} else if (textAreaId != null && 'addressText' == textAreaId) {
			i = 249;
		} else if (textAreaId != null && 'deadLineText' == textAreaId) {
			i = 99;
		} else if (textAreaId != null && 'contractBodyText' == textAreaId) {
			i = 3999;
		}
		newValue = newValue.substring(0, i);
		textarea.value = newValue;
		textarea.focus();
	}
}

function getCaret(el) {
	if (el.selectionStart) {
		// IE 9, Firefox 8, Chrome 15
		return el.selectionStart;
	} else if (document.selection) {
		// IE 7, IE 8
		el.focus();
		var r = document.selection.createRange();
		if (r == null) {
			return 0;
		}
		var re = el.createTextRange(),
		rc = re.duplicate();
		re.moveToBookmark(r.getBookmark());
		rc.setEndPoint('EndToStart', re);
		return rc.text.length;
	}
	return 0;
}