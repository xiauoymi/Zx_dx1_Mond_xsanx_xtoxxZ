function disableAllButtons() {
    if (disableButtons) {
        jQuery(":submit,:button").each(function () {
            jQuery(this).attr("disabled", "true")
        })
    }
    disableButtons = true
}
function enableAllButtons() {
    if (disableButtons) {
        jQuery(":submit,:button").each(function () {
            jQuery(this).attr("disabled", false)
        })
    }
    disableButtons = true
}
function txtBoxFormat(a, b, c, d) {
    var e, f, g, h, i, j, k, l;
    if (document.all) {
        l = d.keyCode
    } else if (document.layers) {
        l = d.which
    }
    g = a[b].value;
    g = g.toString().replace("-", "");
    g = g.toString().replace("-", "");
    g = g.toString().replace(".", "");
    g = g.toString().replace(".", "");
    g = g.toString().replace("/", "");
    g = g.toString().replace("/", "");
    g = g.toString().replace("(", "");
    g = g.toString().replace("(", "");
    g = g.toString().replace(")", "");
    g = g.toString().replace(")", "");
    g = g.toString().replace(" ", "");
    g = g.toString().replace(" ", "");
    h = g.length;
    i = c.length;
    e = 0;
    f = 0;
    k = "";
    i = h;
    while (e <= i) {
        j = c.charAt(e) == "-" || c.charAt(e) == "." || c.charAt(e) == "/";
        j = j || c.charAt(e) == "(" || c.charAt(e) == ")" || c.charAt(e) == " ";
        if (j) {
            k += c.charAt(e);
            i++
        } else {
            k += g.charAt(f);
            f++
        }
        e++
    }
    a[b].value = k;
    if (l != 8) {
        if (c.charAt(e - 1) == "9") {
            return l > 47 && l < 58
        } else {
            return true
        }
    } else {
        return true
    }
}
function validateRequiredField(a, b, c) {
    return validateRequiredFieldByErrorSpanId(a, b, c, "errorSpan")
}
function validateRequiredFieldByErrorSpanId(a, b, c, d) {
    var e = document.getElementById(b);
    if (e && trim(e.value) == "") {
        showErrorMessage(c, d);
        setFocusField(e);
        a = false
    }
    return a
}
function validateRequiredFieldAtLeastOne(a, b, c) {
    return validateRequiredFieldAtLeastOneByErrorSpanId(a, b, c, "errorSpan")
}
function validateRequiredFieldAtLeastOneByErrorSpanId(a, b, c, d) {
    for (var e = 0; e < b.length; e++) {
        var f = document.getElementById(b[e]);
        if (f && trim(f.value) != "") {
            a = true
        }
    }
    if (!a) {
        showErrorMessage(c, d)
    }
    return a
}
function validateMonetaryRequiredField(a, b, c, d) {
    return validateMonetaryRequiredFieldByErrorSpanId(a, b, c, d, "errorSpan")
}
function validateMonetaryRequiredFieldByErrorSpanId(a, b, c, d, e) {
    var f = document.getElementById(b);
    if (f && (f.value == null || trim(f.value) == "" || trim(f.value) == d)) {
        showErrorMessage(c, e);
        setFocusField(f);
        a = false
    }
    return a
}
function validateInputRadioRequiredField(a, b, c) {
    return validateInputRadioRequiredFieldByErrorSpanId(a, b, c, "errorSpan")
}
function validateInputRadioRequiredFieldByErrorSpanId(a, b, c, d) {
    var e = document.getElementsByName(b);
    var f;
    var g = false;
    var h = null;
    for (f = 0; f < e.length; f++) {
        if (f == 0) {
            h = e[f]
        }
        if (e[f].type == "radio" && e[f].checked) {
            g = true;
            break
        }
    }
    if (!g) {
        showErrorMessage(c, d);
        if (h) {
            setFocusField(h)
        }
        a = false
    }
    return a
}
function clearErrorMessages() {
    var a = document.getElementById("errorSpan");
    a.style.display = "none";
    a.innerHTML = "";
    var b = document.getElementById("serverErrorSpan");
    if (b) {
        b.style.display = "none";
        b.innerHTML = ""
    }
    var c = document.getElementById("popUpErrorSpan");
    if (c) {
        c.style.display = "none";
        c.innerHTML = ""
    }
    focusSetted = false
}
function clearErrorMessagesByErrorSpanId(a) {
    var b = document.getElementById(a);
    if (b) {
        b.style.display = "none";
        b.innerHTML = ""
    }
}
function showErrorMessage(a, b) {
    var c = document.getElementById(b);
    c.innerHTML += '<p style="margin-left: 10px;"> ' + '<img src="../../img/error_alert.gif" width="16" height="16" align="absmiddle"/> ' + a + "</p> ";
    c.style.display = "block"
}
function validateDateRange(a, b, c, d) {
    return validateDateRangeByErrorSpanId(a, b, c, d, "errorSpan")
}
function validateDateRangeByErrorSpanId(a, b, c, d, e) {
    var f = document.getElementById(b);
    var g = document.getElementById(c);
    var h = new Date(f.value.substring(6, 10) + "/" + f.value.substring(3, 5) + "/" + f.value.substring(0, 2));
    var i = new Date(g.value.substring(6, 10) + "/" + g.value.substring(3, 5) + "/" + g.value.substring(0, 2));
    if (h.getTime() >= i.getTime()) {
        showErrorMessage(d, e);
        setFocusField(g);
        a = false
    }
    return a
}
function validateDateRangeGreaterEqualsByErrorSpanId(a, b, c, d, e, f) {
    var g = document.getElementById(b);
    var h = document.getElementById(c);
    var i = new Date(g.value.substring(6, 10) + "/" + g.value.substring(3, 5) + "/" + g.value.substring(0, 2));
    var j = new Date(h.value.substring(6, 10) + "/" + h.value.substring(3, 5) + "/" + h.value.substring(0, 2));
    if (f && i.getTime() >= j.getTime() || !f && i.getTime() > j.getTime()) {
        showErrorMessage(d, e);
        setFocusField(h);
        a = false
    }
    return a
}
function validateMonetaryValue(a, b, c) {
    return validateMonetaryValueByErrorSpanId(a, b, c, "errorSpan")
}
function validateMonetaryValueByErrorSpanId(a, b, c, d) {
    var e = document.getElementById(b);
    if (trim(e.value) != "") {
        var f = new RegExp(/^\d*[0-9](\.\d*[0-9])*(\,\d*[0-9])?$/);
        if (!f.test(e.value)) {
            showErrorMessage(c, d);
            setFocusField(e);
            a = false
        }
    }
    return a
}
function validateDate(a, b, c) {
    return validateDateByErrorSpanId(a, b, c, "errorSpan")
}
function validateDateByErrorSpanId(a, b, c, d) {
    var e = document.getElementById(b);
    if (e && trim(e.value) != "") {
        var f = new RegExp(/^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/(19|20)?\d{4}$/);
        if (!f.test(e.value)) {
            showErrorMessage(c, d);
            a = false
        } else if (e.value.split("/")[1] == "02") {
            if (e.value.split("/")[2] % 4 == 0) {
                if (e.value.split("/")[0] > 29) {
                    showErrorMessage(c, d);
                    a = false
                }
            } else {
                if (e.value.split("/")[0] > 28) {
                    showErrorMessage(c, d);
                    a = false
                }
            }
        }
    }
    return a
}
function validateDateField(a) {
    if (trim(a.value) != "") {
        var b = new RegExp(/^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/(19|20)?\d{4}$/);
        if (!b.test(a.value)) {
            a.value = ""
        } else if (a.value.split("/")[1] == "02") {
            if (a.value.split("/")[2] % 4 == 0) {
                if (a.value.split("/")[0] > 29) {
                    a.value = ""
                }
            } else {
                if (a.value.split("/")[0] > 28) {
                    a.value = ""
                }
            }
        }
    }
}
function trim(a) {
    if (a != null) {
        return a.replace(/^\s+|\s+$/, "")
    }
    return""
}
function setFocusField(a) {
    if (!focusSetted) {
        focusSetted = true;
        if (!a.disabled) {
            a.focus()
        }
    }
}
function validateInitialPeriod(a, b, c) {
    return validateInitialPeriodByErrorSpanId(a, b, c, "errorSpan")
}
function validateInitialPeriodByErrorSpanId(a, b, c, d) {
    var e = document.getElementById(b);
    var f = new Date(e.value.substring(6, 10) + "/" + e.value.substring(3, 5) + "/" + e.value.substring(0, 2));
    var g = new Date;
    var h = new Date(g.getFullYear(), g.getMonth(), g.getDate(), 0, 0, 0, 0);
    if (f.getTime() < h.getTime()) {
        showErrorMessage(c, d);
        setFocusField(e);
        a = false
    }
    return a
}
function maxLengthTextArea(a, b) {
    if (a && a.value.length > b) {
        a.value = a.value.substring(0, b)
    }
}
jQuery(function () {
    jQuery("input").keydown(function (a) {
        if (a.keyCode == 13 || a.wich == 13) {
            return false
        }
    })
});
var executeValidation = false;
var focusSetted = false;
var disableButtons = true


