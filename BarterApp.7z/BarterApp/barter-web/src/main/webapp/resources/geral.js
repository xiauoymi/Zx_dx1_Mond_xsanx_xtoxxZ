function global_mask(mascara, valor){
	if(mascara == '###.###.###-##|##.###.###/####-##'){
		if(valor.length>14){
			return global_mask('##.###.###/####-##', valor);
		}else{
			return global_mask('###.###.###-##', valor);
		}
	}
	
	tvalor = "";
	ret = "";
	caracter = "#";
	separador = "|";
	mascara_utilizar = "";
	valor = removeEspacos(valor);
	if (valor == "")return valor;
	temp = mascara.split(separador);
	dif = 1000;
	
	valorm = valor;
	//tirando mascara do valor j� existente
	for (var i=0;i<valor.length;i++){
		if (!isNaN(valor.substr(i,1))){
			tvalor = tvalor + valor.substr(i,1);
		}
	}
	
	valor = tvalor;
	//formatar mascara dinamica
	for (var i = 0; i<temp.length;i++){
		mult = "";
		validar = 0;
		for (var j=0;j<temp[i].length;j++){
			if (temp[i].substr(j,1) == "]"){
				temp[i] = temp[i].substr(j+1);
				break;
			}
			if (validar == 1)mult = mult + temp[i].substr(j,1);
			if (temp[i].substr(j,1) == "[")validar = 1;
		}
		for (var j=0;j<valor.length;j++){
			temp[i] = mult + temp[i];
		}
	}
	
	//verificar qual mascara utilizar
	if (temp.length == 1){
		mascara_utilizar = temp[0];
		mascara_limpa = "";
		for (j=0;j<mascara_utilizar.length;j++){
			if (mascara_utilizar.substr(j,1) == caracter){
				mascara_limpa = mascara_limpa + caracter;
			}
		}
		tam = mascara_limpa.length;
	}else{
		//limpar caracteres diferente do caracter da m�scara
		for (var i=0;i<temp.length;i++){
			mascara_limpa = "";
			for (j=0;j<temp[i].length;j++){
				if (temp[i].substr(j,1) == caracter){
					mascara_limpa = mascara_limpa + caracter;
				}
			}
			if (valor.length > mascara_limpa.length){
				if (dif > (valor.length - mascara_limpa.length)){
					dif = valor.length - mascara_limpa.length;
					mascara_utilizar = temp[i];
					tam = mascara_limpa.length;
				}
			}else if (valor.length < mascara_limpa.length){
				if (dif > (mascara_limpa.length - valor.length)){
					dif = mascara_limpa.length - valor.length;
					mascara_utilizar = temp[i];
					tam = mascara_limpa.length;
				}
			}else{
				mascara_utilizar = temp[i];
				tam = mascara_limpa.length;
				break;
			}
		}
	}
	
	//validar tamanho da mascara de acordo com o tamanho do valor
	if (valor.length > tam){
		valor = valor.substr(0,tam);
	}else if (valor.length < tam){
		masct = "";
		j = valor.length;
		for (i = mascara_utilizar.length-1;i>=0;i--){
			if (j == 0) break;
			if (mascara_utilizar.substr(i,1) == caracter){
				j--;
			}
			masct = mascara_utilizar.substr(i,1) + masct;
		}
		mascara_utilizar = masct;
	}
	
	//mascarar
	j = mascara_utilizar.length -1;
	for (i = valor.length - 1;i>=0;i--){
		if (mascara_utilizar.substr(j,1) != caracter){
			ret = mascara_utilizar.substr(j,1) + ret;
			j--;
		}
		ret = valor.substr(i,1) + ret;
		j--;
	}
	return ret;
}

function removeEspacos(valor){
	var valorSemEspacos="";

	if (valor != undefined) {
		for (var i = 0; i<30;i++){
			if(valor.substr(i,1)==" "){
			}else{
			valorSemEspacos = valorSemEspacos + valor.substr(i,1);
			}
		}
	}
	return valorSemEspacos;
}

function valor(obj, decimalSeparator, thousandSeparator){
	var vlr = '';
	vlr = obj.value;
    if(vlr === '') {
        return;
    }
	if (vlr.indexOf(decimalSeparator) == -1){
		vlr = vlr + '00';
	}
	else {
		if (vlr.split(decimalSeparator)[1].length == 0)
			vlr = vlr + '00';
		else if (vlr.split(decimalSeparator)[vlr.split(decimalSeparator).length-1].length == 1)
			vlr = vlr + '0';
	}
	vlr = JustNumber(ZeroLess(vlr));
	obj.value = ToMoney(vlr, decimalSeparator, thousandSeparator);
}

function ZeroLess(What) {
	var
	 i = 0,
	 WhatClean = '',
	 pvJa = false;

	 if (What.length > 3)
	 {
	   for (i = 0; i <= (What.length -1); i++) {
	     if ((What.charAt(i) != '0') || (pvJa))
	     {
	      pvJa = true;
	      WhatClean += What.charAt(i);
	     }
	   }
	 } else {
	   WhatClean = What;
	 }

	 return WhatClean;
}

function JustNumberIfNeeded(/*boolean*/Needed,What) {
    if(Needed)
        return JustNumber(What);

    return What;
}

function JustNumber(What) {
var
 WhatClean = '';

 for (var i = 0; (i <= (What.length - 1)); i++) {
	for (var j = 0; ((j <= 9) && (true)); j++) {
	 if (What.charAt(i) == '' + j) {
		WhatClean += What.charAt(i);
		break;
	 }
	}
 }
 return WhatClean;
}

function ToMoney(What, decimalSeparator, thousandSeparator) {
	var
	 i = 0,
	 j = 0,
	 vMod = 0,
	 vWhatMoney = '';

	 if (What.length > 5)
	 {
	   vMod = (What.length - 2) % 3;
	   if (vMod == 0) j = 0;
	   if (vMod == 1) j = 2;
	   if (vMod == 2) j = 1;
	   for (i = 0; (i <= (What.length - 3)); i++) {
	     if (j == 3) {
	       vWhatMoney += thousandSeparator;
	       j = 0;
	     }
	     vWhatMoney += What.charAt(i);
	     j++;
	   }
	   vWhatMoney = vWhatMoney + decimalSeparator + SubStr(What, (What.length - 2), (What.length - 1));
	 }
	 else
	 {
	   if (What.length == 5)
	     vWhatMoney = SubStr(What, 0, 2) + decimalSeparator + SubStr(What, 3, 4);
	   if (What.length == 4)
	     vWhatMoney = SubStr(What, 0, 1) + decimalSeparator + SubStr(What, 2, 3);
	   if (What.length == 3)
	     vWhatMoney = What.charAt(0) + decimalSeparator + SubStr(What, 1, 2);
	   if (What.length == 2)
	     vWhatMoney = '0' + decimalSeparator + What;
	   if (What.length == 1)
	     vWhatMoney = '0' + decimalSeparator + '0' + What;
	 }

	 return vWhatMoney;
}

function SubStr(vpText, vpFrom, vpUntil) {
	var vpResult = '';

	 for (var i = vpFrom; (i <= vpUntil); i++) {
	   vpResult += vpText.charAt(i);
	 }
	 return vpResult;
}

function inputNumberOnBlur(field, convertEmptyToZero, decimalSeparator, thousandSeparator) {
	if(convertEmptyToZero && field.value == '') {
		field.value = 0; 
	}
	valor(field, decimalSeparator, thousandSeparator);
}
/*
 * It handles decimal inputs with scale equals to 3 or 2, and also whole number inputs.  
 * If numberOfDecimals == 0, then the number will be formatted as a whole number.
 * */
function handleNumericInput(/*object*/field, numberOfDecimals, decimalSeparator, pattern, /*string, optional*/maxValue){
	var What = field.value + "";
	What = (JustNumber(What) + "");
	if(numberOfDecimals == 3){
		if(What != "" && What.length < 4){
			field.value = What + decimalSeparator + "000";		
		} else {
			if(maxValue){
				checkMaxValue(What, field, pattern, maxValue);
			} else {
				field.value = global_mask(pattern, What);
			}
		}
	} else if(numberOfDecimals == 2){
		if(What != "" && What.length < 3){
			field.value = What + decimalSeparator + "00";		
		} else {
			if(maxValue){
				checkMaxValue(What, field, pattern, maxValue);
			} else {
				field.value = global_mask(pattern, What);
			}
		}
	} else if(numberOfDecimals == 0){
		if(maxValue){
			checkMaxValue(What, field, pattern, maxValue);
		} else {
			field.value = global_mask(pattern, What);
		}
		
	}	
}
//private function called from handleNumericInput function
function checkMaxValue(/*input value*/ What, field, /*string*/ pattern, /*string*/ maxValue){
	var maxValsize = maxValue.length;
	if(What != "" && What.length <= maxValsize){
		field.value = global_mask(pattern, What);
	} else if(What != "" && What.length > maxValsize){
		if(maxValue == ""){
			field.value = global_mask(pattern, What);
		}  else {
			//if a number greater then the max is passed, then go back to max value
			field.value = global_mask(pattern, maxValue); //ex: max value: 999.999
		}
					
	}
}

function cancelEvent(event) {
    if (event.preventDefault) {
        event.preventDefault();
    } else {
        event.returnValue = false;
    }
    if (event.stopPropagation) {
        event.stopPropagation();
    } else if (window.event) {
        window.event.cancelBubble = true;
   }
}

function getKeyPressed(keyPressEvent) {
    return keyPressEvent.which || keyPressEvent.charCode || keyPressEvent.keyCode || 0;
}

function onEnterDoClick(keyPressEvent, elementId) {
    if (getKeyPressed(keyPressEvent) == 13) {
        cancelEvent(keyPressEvent);
        document.getElementById(elementId).click();
    }
}

function onNoDigitNorDashDoNoop(keyPressEvent) {
    var key = getKeyPressed(keyPressEvent);
    switch (key) {
    case 8:  //backspace
    case 9:  //tab
    case 13: //enter
    case 27: //escape
    case 45: //minus
        break;
    default:
        if (key < 48 || key > 57) { // not 0-9
            cancelEvent(keyPressEvent);
        }
    }
}

function setInputValue(id,value){
    var input = "input[id$='"+id+"']";
    $(input)[0].value =value;

}

function setTextareaValue(id,value){
    var input = "textarea[id$='"+id+"']";
    $(input)[0].value =value;

}

resetDataTableSort = function (id) {
	$(id + ' th.ui-sortable-column span.ui-sortable-column-icon').removeClass('ui-icon-triangle-1-s ui-icon-triangle-1-n');
	$(id + ' th.ui-sortable-column.defaultSortedColumn span.ui-sortable-column-icon').addClass('ui-icon-triangle-1-n');
};


expandSlider = function (id, timer){
    var curHeight = $('#'+id).height();
    var scroolHeight = $('#'+id).prop("scrollHeight");
    if(curHeight==15)
    {
        $('#'+id).animate({height: scroolHeight+'px'}, timer);
    }
    else
    {
        $('#'+id).animate({height:'15px'}, timer);
    }
    return false;
}

function getContextPath(){
    var pathArray = window.location.pathname.split( '/' );
    return pathArray[1];
}

function setFieldAsRequired(id, required){
    var label = "label[id$='"+id+"']";
    if(required){
        $(label)[0].innerHTML = '*';
    } else {
        $(label)[0].innerHTML = '';
    }
}

