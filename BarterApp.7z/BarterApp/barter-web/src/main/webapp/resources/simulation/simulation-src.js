function validateSimulationSearchForm(msg1, msg2, msg3, msg4, errorSpanId) {

	var returns = false;
	clearErrorMessages();

	if (executeValidation) {
		var fieldIds = [ "formSearch:drpStatus",
				"formSearch:cldDateBeginInputDate",
				"formSearch:cldDateEndInputDate", "formSearch:txtRTV",
				"formSearch:drpCampaign", "formSearch:txtCustomer", "formSearch:drpPaymentCondition" ];

		returns = validateRequiredFieldAtLeastOneByErrorSpanId(returns,
				fieldIds, msg1, errorSpanId);
		returns = validateDateByErrorSpanId(returns,
				"formSearch:cldDateBeginInputDate", msg2, errorSpanId);
		returns = validateDateByErrorSpanId(returns,
				"formSearch:cldDateEndInputDate", msg3, errorSpanId);
		returns = validateDateRangeGreaterEqualsByErrorSpanId(returns, "formSearch:cldDateBeginInputDate",
				"formSearch:cldDateEndInputDate", msg4, errorSpanId, false);
	} else {
		return true;
	}
	return returns;
}

function validateSimulationFCPAForm(msg) {

	var returns = true;
	clearErrorMessages();

	returns = validateInputRadioRequiredField(returns, "fcpaForm:rbtFcpa", msg);

	return returns;
}

function validateSimulationCampaignForm(msg) {

	var returns = true;
	clearErrorMessages();

	returns = validateRequiredField(returns, "campaignForm:drpCampaign", msg);

	return returns;
}

function validateSimulationRegisterForm(msg1, msg2, msg3, msg4, msg5, msg6,
		msg7, msg8, msg9, msg10, msg11, msg12, msg13, msg14, msg15, msg16,
		msg17, msg18, msg19, msg20, msg21, msg22, msg23, newSale, reopen) {

	var returns = true;
	clearErrorMessages();

	if (executeValidation) {
		executeValidation = false;
		
		var hiddenSubmit = document.getElementById("registerForm:hdnSubmitForm");
		if (hiddenSubmit.value != '') {			
			return false;
		}
		document.getElementById("registerForm:hdnSubmitForm").value = 'S';

		// Needed values.
		var barterType = document.getElementById("registerForm:drpBarterType").value;
		var diffDelivLocCheck = document.getElementById("registerForm:chkDiffDelivLocation");
		var region = document.getElementById("registerForm:drpRegion").value;

		if (newSale && !reopen) {
			returns = validateRequiredField(returns, "registerForm:txtCustomer", msg1);
		}
		
		returns = validateRequiredField(returns, "registerForm:drpBarterType", msg2);
		
		if (newSale && !reopen) {
			returns = validateRequiredField(returns, "registerForm:drpCrop", msg4);
		}
		if (diffDelivLocCheck && diffDelivLocCheck.checked && !reopen) {
			returns = validateRequiredField(returns, "registerForm:txtDiffDelivLocation", msg5);
		}
		if (barterType != '3' && barterType != '4') {
			returns = validateRequiredField(returns, "registerForm:drpTrading", msg6);
		}
		if (barterType == '3') {
			returns = validateRequiredField(returns, "registerForm:drpRegion", msg23);
		}
		if (barterType == '3' || (region != null && region != "")) {
			returns = validateRequiredField(returns, "registerForm:drpLocalWarehouse", msg7);
		}
		if (!reopen) {
			returns = validateRequiredField(returns, "registerForm:cboCurrency", msg8);
		}
		if (newSale) {
			returns = validateRequiredField(returns, "registerForm:drpPaymentCondit", msg9);
		}
		if (!newSale || barterType != '4') {
			returns = validateRequiredField(returns, "registerForm:cboCommodity", msg10);
		}
		if (newSale && !reopen) {
			returns = validateRequiredField(returns, "registerForm:txtIncentive", msg11);
		}
		if (barterType != '3') {
			returns = validateRequiredField(returns, "registerForm:drpIncoterms", msg12);
		}
		if (!newSale || barterType != '4') {
			returns = validateRequiredField(returns, "registerForm:txtSackGrossPrice", msg13);
		}
		if (barterType != '4') {
			returns = validateInputRadioRequiredField(returns, "registerForm:rbQuotation", msg14);
		}
		if (!newSale || barterType != '4') {
			returns = validateRequiredField(returns, "registerForm:txtKgQtd", msg15);
		}
		if (barterType != '3') {
			if (barterType == '4') {
				var delivDateField = document.getElementById("registerForm:cldDelivDateInputDate");
				if (delivDateField && trim(delivDateField.value) == "") {
					validateDate(returns, "registerForm:cldDelivDateInputDate", msg17);
				}
			} else if (validateRequiredField(returns, "registerForm:cldDelivDateInputDate", msg16)) {
				returns = validateDate(returns, "registerForm:cldDelivDateInputDate", msg17);
			} else {
				returns = false;
			}
		}
		if (newSale && !reopen) {
			if (validateRequiredField(returns, "registerForm:cldPaymentDateInputDate", msg18)
					&& validateDate(returns, "registerForm:cldPaymentDateInputDate", msg19)) {
				returns = validateInitialPeriod(returns, "registerForm:cldPaymentDateInputDate", msg20);
			} else {
				returns = false;
			}
		}
		if (barterType == '2') {
			if (validateRequiredField(returns, "registerForm:cldNegotDateInputDate", msg21)) {
				returns = validateDate(returns, "registerForm:cldNegotDateInputDate", msg22);
			} else {
				returns = false;
			}
		}
	}
	if(!returns){
		document.getElementById("registerForm:hdnSubmitForm").value = '';
	}
	return returns;
}

function validateSearchSimulationForm(msg) {

	flag = false;
	clearErrorMessages();

	jQuery('input[name*="chkSimulation"]').each(function(index) {
		if (jQuery(this).is(':checked') == true) {
			flag = true;
			return false;
		}
	});

	if (!flag) {
		showErrorMessage(msg, "popUpErrorSpan");
	}
	return flag;
}

function validateSimulationItemForm(msg1, msg2, msg3, msg4, msg5, msg6, msg7) {
	returns = true;
	clearErrorMessages();

	returns = validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:drpDivision", msg1, "popUpErrorSpan");
	returns = validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:drpBrand", msg2, "popUpErrorSpan");
	returns = validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:drpProduct", msg3, "popUpErrorSpan");
	returns = validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:txtQuantity", msg4, "popUpErrorSpan");

	if (validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:cldDeliveryDateInputDate", msg5,
			"popUpErrorSpan")) {
		returns = validateDateByErrorSpanId(returns,
				"formSimulationItem:cldDeliveryDateInputDate", msg7,
				"popUpErrorSpan");
	} else {
		returns = false;
	}

	returns = validateRequiredFieldByErrorSpanId(returns,
			"formSimulationItem:txtDiscountBarter", msg6, "popUpErrorSpan");

	return returns;
}

function validateOpenPopUpItem(msg1, msg2, msg3, msg4) {

	returns = true;
	clearErrorMessages();

	returns = validateRequiredField(returns, "registerForm:drpCrop", msg3);
	returns = validateRequiredField(returns, "registerForm:cboCurrency", msg4);
	returns = validateRequiredField(returns, "registerForm:cldPaymentDateInputDate", msg1);

	if (returns) {
		returns = validateDate(returns, "registerForm:cldPaymentDateInputDate", msg2);
	}

	return returns;
}

function validateTermsFormalizationForm(msg1, msg2, msg3, msg4, msg5, msg6,
		msg7, msg8, msg9) {

	var returns = true;
	clearErrorMessagesByErrorSpanId("errorTermSpan");

	returns = validateRequiredFieldByErrorSpanId(returns,
			"formTermsFormalization:txtWarehouse", msg1, "errorTermSpan");

	var validDates = true;
	validDates = validateRequiredFieldByErrorSpanId(validDates,
			"formTermsFormalization:cldTermDateFromInputDate", msg2,
			"errorTermSpan");

	if (validDates) {
		validDates = validateDateByErrorSpanId(validDates,
				"formTermsFormalization:cldTermDateFromInputDate", msg3,
				"errorTermSpan");
	}

	if (validDates) {
		validDates = validateInitialPeriodByErrorSpanId(validDates,
				"formTermsFormalization:cldTermDateFromInputDate", msg4,
				"errorTermSpan");
	}

	validDates = validateRequiredFieldByErrorSpanId(validDates,
			"formTermsFormalization:cldTermDateToInputDate", msg5, "errorTermSpan");

	if (validDates) {
		validDates = validateDateByErrorSpanId(validDates,
				"formTermsFormalization:cldTermDateToInputDate", msg6,
				"errorTermSpan");
	}

	if (validDates) {
		validDates = validateDateRangeByErrorSpanId(validDates,
				"formTermsFormalization:cldTermDateFromInputDate",
				"formTermsFormalization:cldTermDateToInputDate", msg7,
				"errorTermSpan");
	}
	returns = returns && validDates;
	returns = validateRequiredFieldByErrorSpanId(returns,
			"formTermsFormalization:txtChangeAddress", msg8, "errorTermSpan");
	returns = validateRequiredFieldByErrorSpanId(returns,
			"formTermsFormalization:txtMail", msg9, "errorTermSpan");

	return returns;
}

function showSignatureMessage(msg) {

	showErrorMessage(msg, "errorSpan");
}

function validateFormFiltroInvoice(msg) {
	
	var returns = true;
	clearErrorMessages();
	
	if (executeValidation) {
		executeValidation = false;
		returns = validateRequiredField(returns, "formFiltroInvoice:cboSimulation", msg);
	}
	
	return returns;
	
}

function validateIncludeReason(fieldCboMotiveId, fieldTxtMotiveId, errorSpanId, codeOthersReason, msg1, msg2) {
	
	var returns = true;
	clearErrorMessagesByErrorSpanId(errorSpanId);
	
	// Validation selectOneMenu of reason
	returns = validateRequiredFieldByErrorSpanId(returns, fieldCboMotiveId, msg1, errorSpanId);
		
	if (returns) {
		
		var field = document.getElementById(fieldCboMotiveId);
		if (trim(field.value) == codeOthersReason) {
			// Validation inputText of reason
			returns = validateRequiredFieldByErrorSpanId(returns, fieldTxtMotiveId, msg2, errorSpanId);
		}
	}

	return returns;	
}

function submitCropValue(msg, hasProduct) {
	var cropField = document.getElementById("registerForm:drpCrop");
	var hiddenCropField = document.getElementById("registerForm:hdnCrop");
	
	if (hasProduct && cropField.value != hiddenCropField.value && hiddenCropField.value != null && hiddenCropField.value != '') {
		if (confirm(msg)) {
			hiddenCropField.value = cropField.value;
			cropField.form.submit();
		} else {
			cropField.value = hiddenCropField.value;
		}
	} else {
		hiddenCropField.value = cropField.value;
		cropField.form.submit();
	}
}

function submitCurrencyValue(msg, hasProduct) {
	var currencyField = document.getElementById("registerForm:cboCurrency");
	var hiddenCurrencyField = document.getElementById("registerForm:hdnCurrency");
	
	if (hasProduct && currencyField.value != hiddenCurrencyField.value
			&& hiddenCurrencyField.value != null && hiddenCurrencyField.value != '') {
		if (confirm(msg)) {
			hiddenCurrencyField.value = currencyField.value;
			currencyField.form.submit();
		} else {
			currencyField.value = hiddenCurrencyField.value;
		}
	} else {
		hiddenCurrencyField.value = currencyField.value;
		currencyField.form.submit();
	}
}

function submitPaymentDateValue(msg, hasProduct) {
	var field = document.getElementById("registerForm:cldPaymentDateInputDate");
	var hiddenField = document.getElementById("registerForm:hdnPaymentDate");
	
	if (hasProduct && field.value != hiddenField.value
			&& hiddenField.value != null && hiddenField.value != '') {
		if (confirm(msg)) {
			hiddenField.value = field.value;
			field.form.submit();
		} else {
			field.value = hiddenField.value;
		}
	} else {
		hiddenField.value = field.value;
		field.form.submit();
	}
}
