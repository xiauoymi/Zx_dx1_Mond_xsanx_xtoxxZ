package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.lowagie.text.DocumentException;
import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.AdendaState;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.ParticipantType;
import com.monsanto.barter.ar.business.entity.enumerated.UserTypeEnum;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.RemoteServiceResponse;
import com.monsanto.barter.ar.web.faces.beans.growerdocuments.composite.GrowerDocumentsCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.AbstractWizardStepCC;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.InitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.TransferSectionCC;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.event.AbortProcessingException;
import java.util.*;

import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author GIRIA
 */
@SuppressWarnings("unchecked")
public class AddDetail_UT {
    private static final String SUCCESS = "success";
    private static final List<String> messages = new LinkedList<String>();
    public static final String EXCEPTHROW = "excepthrow";

    private TransactionTemplateMocker txTemplateMocker;

    public class AddDetailForTest extends AddDetail {
        @Override
        public BeanFactory getBeanFactory() {
            return beanFactoryMock;
        }
        @Override
        protected RequestContext getRequestContext() {
            return super.getRequestContext();
        }
        @Override
        protected void createSections() {
            super.createSections();
        }
        @Override
        protected BeanValidator getValidator() {
            return beanvalidator;
        }
        @Override
        public <T> T getFacesBean(String beanId, Class<T> requiredType) {
            return (T) addSearchFormFacesBean;
        }
        @Override
        protected void addMessageNoError(String message) {
            messages.add(message);
        }
        @Override
        protected void addMessage(String message) {
            messages.add(message);
        }
        @Override
        public TransactionTemplate getTransactionTemplate() {
            return txTemplateMocker;
        }
        @Override
        public String getMessageBundle(String key) {
            return key;
        }
        @Override
        public UserDecorator getLoggedUser() {
            return user;
        }
    }

    @Mock
    private AdendaService adendaService;
    @Mock
    private RemoteService remoteService;
    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    @Mock
    private EmailService emailService;
    @Mock
    private CustomerCC holder;
    @Mock
    private BeanValidator beanvalidator;
    @Mock
    private RequestContext requestContext;
    @Mock
    private AddSearchFormFacesBean addSearchFormFacesBean;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private UserDecorator user;

    @Mock
    private GrowerDocumentsCC growerDocumentsCC;

    private AddDetailForTest addDetailForTest;
    private Adenda adenda;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        txTemplateMocker = new TransactionTemplateMocker();

        messages.clear();

        addDetailForTest = new AddDetailForTest();
        addDetailForTest.setIdEntity(1L);
        addDetailForTest.setSections(new ArrayList<AbstractWizardStepCC>());

        createValidAdenda();
        addDetailForTest.setEntity(adenda);

        InitialDataSectionCC initialDataSectionCC = createInitialDataSectionCC();

        MaterialLasService materialLasService = mock(MaterialLasService.class);

        TransferSectionCC transferSectionCC = createTransferSectionCC();

        beanFactoryMock = mock(BeanFactory.class);

        when(adendaService.get(anyLong())).thenReturn(adenda);
        when(beanFactoryMock.getBean(InitialDataSectionCC.class)).thenReturn(initialDataSectionCC);
        when(beanFactoryMock.getBean(TransferSectionCC.class)).thenReturn(transferSectionCC);
        when(beanFactoryMock.getBean(AdendaService.class)).thenReturn(adendaService);
        when(beanFactoryMock.getBean(RemoteService.class)).thenReturn(remoteService);
        when(beanFactoryMock.getBean(UnsuccessfulRemoteInvocationService.class)).thenReturn(unsuccessfulInvocationService);
        when(beanFactoryMock.getBean(EmailService.class)).thenReturn(emailService);
        when(beanFactoryMock.getBean(GrowerDocumentsCC.class)).thenReturn(growerDocumentsCC);

        when(materialLasService.findAll()).thenReturn(new ArrayList<MaterialLas>());
        transferSectionCC.setMaterialLasService(materialLasService);

        setField(addDetailForTest, "adendaService", adendaService);
        setField(addDetailForTest, "remoteService", remoteService);
        setField(addDetailForTest, "unsuccessfulInvocationService", unsuccessfulInvocationService);
        setField(addDetailForTest, "emailService", emailService);

        addDetailForTest.createSections();
    }

    private InitialDataSectionCC createInitialDataSectionCC() {
        InitialDataSectionCC section = new InitialDataSectionCC();

        CustomerCC customerCC = mock(CustomerCC.class);
        LocationCC locationCC = mock(LocationCC.class);

        CustomerLas customerLas = new CustomerLas();
        customerLas.setLastUpdatedBy("mockAddDetail");

        CityAfipLas cityAfipLas = new CityAfipLas();
        cityAfipLas.setCreatedBy("mockAddDetail");

        when(customerCC.getSelectedCustomer()).thenReturn(customerLas);
        when(locationCC.getCitySelected()).thenReturn(cityAfipLas);

        section.setSenderCC(customerCC);
        section.setEmissionPlace(locationCC);
        section.setEntity(adenda);
        return section;
    }

    private TransferSectionCC createTransferSectionCC() {
        TransferSectionCC section = new TransferSectionCC();

        CustomerCC customerCC = mock(CustomerCC.class);

        CustomerLas customerLas = new CustomerLas();
        customerLas.setLastUpdatedBy("mockAddDetail");

        when(customerCC.getSelectedCustomer()).thenReturn(customerLas);

        section.setReceptor(customerCC);
        section.setEntity(adenda);
        return section;
    }

    @Test
    public void testView(){
        addDetailForTest.view();
        assertEquals(addDetailForTest.getMode(), Mode.VIEW);
    }

    @Test
    public void testEdit(){
        when(remoteService.getDocumentStatus(DocumentType.ADD, adenda.getIdSap())).thenReturn(new RemoteServiceResponse("200", asList("OK")));
        addDetailForTest.edit();
        assertEquals(addDetailForTest.getMode(), Mode.UPDATE);
    }

    @Test
    public void testEditWhenSapIdIsNull(){
        adenda.setIdSap(null);
        addDetailForTest.edit();
        assertEquals(addDetailForTest.getMode(), Mode.UPDATE);
    }

    @Test
    public void testEditTurnsIntoViewWhenSapResponseNotFound(){
        when(remoteService.getDocumentStatus(DocumentType.ADD, adenda.getIdSap())).thenReturn(new RemoteServiceResponse("404", asList("SAP_RESPONSE_NOT_FOUND")));
        addDetailForTest.edit();
        assertEquals(addDetailForTest.getMode(), Mode.VIEW);
        assertThat(messages.size(), is(1));
    }

    @Test
    public void testEditTurnsIntoViewWhenInvokingSapServicesFails(){
        when(remoteService.getDocumentStatus(DocumentType.ADD, adenda.getIdSap())).thenThrow(new RemoteServiceException(EXCEPTHROW));
        addDetailForTest.edit();
        assertEquals(addDetailForTest.getMode(), Mode.VIEW);
        assertThat(messages.size(), is(1));
    }

    @Test
    public void testCancel(){
        addDetailForTest.cancel();
        assertNull(addDetailForTest.getIdEntity());
    }

    @Test
    public void testBack(){
        addDetailForTest.back();
        assertNull(addDetailForTest.getEntity());
    }

    @Test
    public void testPreSave(){
        addDetailForTest.preSave();
        assertEquals(addDetailForTest.getInitialDataSectionCC().getAddInput().getSender().getLastUpdatedBy(),
                "mockAddDetail");
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new AddDetail());
    }

    @Test
    public void testSaveAction() {
        adenda.setSentToSAP();
        when(remoteService.getDocumentStatus(DocumentType.ADD, adenda.getIdSap())).thenReturn(new RemoteServiceResponse("200", asList("OK")));
        assertEquals(addDetailForTest.save(), SUCCESS);
        verify(remoteService).update(adenda);
        verify(adendaService).update(adenda);
        verify(unsuccessfulInvocationService).clearPendingInvocations(adenda);
        assertThat(messages.size(), is(1));
    }

    @Test
    public void testSaveWithoutSentToSap() {
        assertEquals(addDetailForTest.save(), SUCCESS);
        verify(remoteService).create(adenda);
        verify(adendaService, times(2)).update(adenda);
        verify(unsuccessfulInvocationService).clearPendingInvocations(adenda);
        assertThat(messages.size(), is(1));
    }

    @Test
    public void testSaveActionWhenAdendaWasNotSentToSap() {
        adenda.getState();
        adenda.setState(AdendaState.INGRESED);
        assertEquals(addDetailForTest.save(), SUCCESS);
        verify(remoteService).create(adenda);
        verify(unsuccessfulInvocationService).clearPendingInvocations(adenda);
        assertThat(messages.size(), is(1));
    }

    @Test
    public void testSaveActionFailure() {
        when(adendaService.update(adenda)).thenThrow(new BusinessException(EXCEPTHROW));
        assertEquals(addDetailForTest.save(), null);
        assertThat(messages.size(), is(1));
        assertThat(messages.contains(EXCEPTHROW), is(true));
    }

    @Test
    public void testSaveActionSAPFailure() {
        adenda.setSentToSAP();
        when(remoteService.getDocumentStatus(DocumentType.ADD, adenda.getIdSap()))
                .thenReturn(new RemoteServiceResponse("200", asList("OK")));
        doThrow(new RemoteServiceException(EXCEPTHROW)).when(remoteService).update(adenda);
        assertEquals(addDetailForTest.save(), null);
        assertThat(addDetailForTest.getSapMessages().size(), is(1));
        verify(adendaService).update(adenda);
        verify(unsuccessfulInvocationService).clearPendingInvocations(adenda);
    }

    @Test
    public void testSaveWithErrors(){
        String testEmail = "no.reply@monsanto.com";
        when(user.getEmail()).thenReturn(testEmail);
        when(adendaService.save(adenda)).thenReturn(adenda);
        assertThat(addDetailForTest.saveWithErrors(), is(SUCCESS));
        verify(adendaService).update(adenda);
        verify(unsuccessfulInvocationService).save(any(AddendaUnsuccessfulRemoteInvocation.class));
        verify(emailService).sendRetryStartMessage(anyString(), anyList(), eq(testEmail));
    }

    @Test
    public void testSaveWithErrorsWhenSaveAdendaFails(){
        doThrow(new BusinessException(EXCEPTHROW)).when(adendaService).update(adenda);
        assertNull(addDetailForTest.saveWithErrors());
        verify(unsuccessfulInvocationService,never()).save(any(AddendaUnsuccessfulRemoteInvocation.class));
        assertThat(messages.get(0), is(EXCEPTHROW));
    }

    @Test
    public void generatePdf(){
        try {
            addDetailForTest.generatePdf();
        }catch(AbortProcessingException e){
            fail();
            e.printStackTrace();
        }
    }

    @Test
    public void generatePdfThrowsAbortProcessingExceptionWhenPdfGenerationFails() throws DocumentException {
        Throwable error = new DocumentException("something went wrong");
        when(adendaService.getPdf(Matchers.<Adenda>any())).thenThrow(error);
        try {
            addDetailForTest.generatePdf();
            fail();
        } catch (AbortProcessingException e) {
            assertThat(e.getCause(), is(error));
            assertThat(messages.size(), is(1));
        }
    }

    private void createValidAdenda(){
        String idSap = "234";
        Date generationDate = new GregorianCalendar().getTime();
        String depositaryName = "Dep Name.";
        String brokerName = "Brok Name.";

        String notes = "The notes";

        Long weigthToTrsf = 3499L;

        CityAfipLas city = Mockito.mock(CityAfipLas.class);
        when(city.getDescription()).thenReturn("GENERAL ARENALES");
        when(city.getId()).thenReturn("6357");
        when(city.getCountyAfipLas()).thenReturn(null);

        CustomerLas sender = Mockito.mock(CustomerLas.class);
        when(sender.getDocument()).thenReturn("20-28951789-6");
        when(sender.getDescription()).thenReturn("ACA");

        CustomerLas receptor = Mockito.mock(CustomerLas.class);
        when(receptor.getDocument()).thenReturn("20-28951789-6");
        when(receptor.getDescription()).thenReturn("ACA");

        MaterialLas cropType = Mockito.mock(MaterialLas.class);
        when(cropType.getDescription()).thenReturn("Soja");

        adenda = new Adenda(idSap, generationDate, city, depositaryName, brokerName, sender, notes, receptor, cropType,
                weigthToTrsf, true);
    }

    @Test
    public void userWithoutPermissionsCantSeeGrowerDocuments(){
        addDetailForTest.view();
        assertFalse(addDetailForTest.isGrowerPortalDocumentEnable());
    }

    @Test
    public void growerUserProfileCanSeeGrowerDocuments(){
        addDetailForTest.view();
        UserDecorator user = (UserDecorator) ReflectionTestUtils.getField(addDetailForTest, "user");
        user.getCurrentUser().setParticipantType(ParticipantType.GROWER);
        user.getCurrentUser().setType(UserTypeEnum.PARTICIPANT);
        assertTrue(addDetailForTest.isGrowerPortalDocumentEnable());
    }

}
