package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.AddendaUnsuccessfulRemoteInvocation;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.Attachment;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.AdendaState;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.WizardStep;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.InitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.addinput.composite.TransferSectionCC;
import com.monsanto.barter.ar.web.faces.composite.FileUploadCC;

import com.monsanto.barter.web.test.TransactionTemplateMocker;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

public class AddInputWizard_UT {
    public static final String SOMETHING_WENT_WRONG = "something went wrong";
    public static final String SOMETHING_WENT_WRONG_REMOTE_SERVICE = "something went wrong with remote service";
    public static final String SUCCESS = "success";
    private AddInputWizard wizard;
    private List<String> messages;

    private TransactionTemplateMocker txTemplateMocker;

    @Mock
    private UserDecorator user;
    @Mock
    private FacesContext context;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private RequestContext requestContextMock;
    @Mock
    private HttpServletResponse response;
    @Mock
    private InitialDataSectionCC initialDataSectionCC;
    @Mock
    private TransferSectionCC transferSectionCC;
    @Mock(extraInterfaces = DocumentUploadService.class)
    private AdendaService adendaService;
    @Mock
    private RemoteService remoteService;
    @Mock
    private FileUploadCC fileUploadHandler;
    @Mock
    private Adenda addInput;
    @Mock
    private BeanValidator beanValidator;
    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    @Mock
    private EmailService emailService;

    private DocumentsUploader<Adenda> documentsUploader;

    @Before
    public void setUp() {
        initMocks(this);
        txTemplateMocker = new TransactionTemplateMocker();
        messages = new LinkedList<String>();
        wizard = new AddInputWizard () {
            @Override
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected AddInputWizard getNewAddInputWizard() {
                return this;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }

            @Override
            public String getMessageBundle(String key) {
                return key;
            }

            @Override
            public TransactionTemplate getTransactionTemplate() {
                return txTemplateMocker;
            }

            @Override
            protected void addMessage(String message) {
                messages.add(message);
            }

            @Override
            public UserDecorator getLoggedUser() {
                return user;
            }
        };
        setField(wizard, "adendaService", adendaService);
        setField(wizard, "beanValidator", beanValidator);
        setField(wizard, "remoteService", remoteService);
        setField(wizard, "emailService", emailService);

        setField(wizard, "addInput", addInput);
        documentsUploader = new DocumentsUploader<Adenda>();
        setField(wizard,"documentsUploader", documentsUploader);
        setField(wizard, "unsuccessfulInvocationService", unsuccessfulInvocationService);
    }

    @Test
    public void begin() {
        int initialDataStepIndex = 0;
        int transferStepIndex = 1;

        String initialDataStepKey = "initialDataSectionCC";
        String transferStepKey = "transferSectionCC";

        when(beanFactoryMock.getBean(InitialDataSectionCC.class)).thenReturn(initialDataSectionCC);
        when(beanFactoryMock.getBean(TransferSectionCC.class)).thenReturn(transferSectionCC);

        when(initialDataSectionCC.initializeStepCC(eq(initialDataStepIndex), eq(initialDataStepKey), any(Adenda.class), eq(Mode.CREATE)))
                .thenReturn(initialDataSectionCC);
        when(transferSectionCC.initializeStepCC(eq(transferStepIndex), eq(transferStepKey), any(Adenda.class), eq(Mode.CREATE)))
                .thenReturn(transferSectionCC);

        when(initialDataSectionCC.getKey()).thenReturn(initialDataStepKey);
        when(transferSectionCC.getKey()).thenReturn(transferStepKey);

        assertThat(wizard.begin(), is(SUCCESS));

        assertThat(wizard.getInitialDataSectionCC(), is(initialDataSectionCC));
        assertThat(wizard.getTransferSectionCC(), is(transferSectionCC));

        assertThat(wizard.getStepCount(), is(2));

        assertThat(wizard.getStep(initialDataStepIndex), is((WizardStep)initialDataSectionCC));
        assertThat(wizard.getStep(transferStepIndex), is((WizardStep)transferSectionCC));

        assertThat(wizard.getStep(initialDataStepKey), is((WizardStep)initialDataSectionCC));
        assertThat(wizard.getStep(transferStepKey), is((WizardStep)transferSectionCC));
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(wizard);
    }

    @Test
    public void testCancel() throws IOException {
        ExternalContext e = mock(ExternalContext.class);
        when(e.getApplicationMap()).thenReturn(new HashMap<String, Object>());
        when(context.getExternalContext()).thenReturn(e);

        String result = wizard.addInputWizardCancelAction();

        assertEquals("cancel", result);
    }

    @Test
    public void saveAddInput() {
        when(adendaService.save(addInput)).thenReturn(addInput);
        when(adendaService.update(addInput)).thenReturn(addInput);

        assertThat(wizard.saveAddInput(), is(""));

        verify(remoteService).create(addInput);
        verify(adendaService).save(addInput);
    }

    @Test
    public void saveAddInput_localFailure() {
        doThrow(new BusinessException(SOMETHING_WENT_WRONG)).when(adendaService).save(addInput);

        assertThat(wizard.saveAddInput(), is(""));
        assertThat(messages.get(0), is(SOMETHING_WENT_WRONG));
    }

    @Test
    public void saveAddInput_sapFailure() {
        when(adendaService.save(addInput)).thenReturn(addInput);
        doThrow(new BusinessException(SOMETHING_WENT_WRONG)).when(remoteService).create(addInput);
        assertThat(wizard.saveAddInput(), is(""));
        assertThat(messages.get(0), is(SOMETHING_WENT_WRONG));
    }

    @Test
    public void testSaveWithErrors() {
        String testEmail = "no.reply@monsanto.com";
        when(user.getEmail()).thenReturn(testEmail);
        when(adendaService.save(addInput)).thenReturn(addInput);
        assertThat(wizard.saveWithErrors(), is(""));
        verify(adendaService).save(addInput);
        verify(unsuccessfulInvocationService).save(any(AddendaUnsuccessfulRemoteInvocation.class));
        verify(emailService).sendRetryStartMessage(anyString(), anyList(), eq(testEmail));
    }

    @Test
    public void testSaveWithErrorsWhenSaveAdendaFails(){
        doThrow(new BusinessException(SOMETHING_WENT_WRONG)).when(adendaService).save(addInput);
        assertThat(wizard.saveWithErrors(), is(""));
        verify(unsuccessfulInvocationService,never()).save(any(AddendaUnsuccessfulRemoteInvocation.class));
        assertThat(messages.get(0), is(SOMETHING_WENT_WRONG));
    }


    @Test
    public void saveAddInputSapFailureWithRemoteServiceException() {
        when(adendaService.save(addInput)).thenReturn(addInput);
        doThrow(new RemoteServiceException(SOMETHING_WENT_WRONG_REMOTE_SERVICE)).when(remoteService).create(addInput);

        assertThat(wizard.saveAddInput(), is(""));
        assertThat(wizard.getSapMessages().get(0), is(SOMETHING_WENT_WRONG_REMOTE_SERVICE));
        verify(addInput).setState(AdendaState.INGRESED);
    }

    @Test
    public void testAttachFilesWhenDocumentUploaderIsEmpty() {
        ExternalContext e = mock(ExternalContext.class);
        when(e.getApplicationMap()).thenReturn(new HashMap<String, Object>());
        when(context.getExternalContext()).thenReturn(e);

        String attachResult = wizard.attachFiles();

        assertThat(attachResult, is(SUCCESS));
    }

    @Test
    public void testAttachFilesWithAttachments() {
        List<Attachment> attachments = new ArrayList<Attachment>();
        Attachment attachment = mock(Attachment.class);
        attachments.add(attachment);
        documentsUploader.setAttachments(attachments);

        when(wizard.getDocumentsUploader().getAttachments()).thenReturn(attachments);

        ExternalContext e = mock(ExternalContext.class);
        when(e.getApplicationMap()).thenReturn(new HashMap<String, Object>());
        when(context.getExternalContext()).thenReturn(e);

        String attachResult = wizard.attachFiles();

        verify(adendaService).update(addInput);
        verify(addInput).addAttachment(attachment);

        assertThat(attachResult,is(SUCCESS));
    }
}