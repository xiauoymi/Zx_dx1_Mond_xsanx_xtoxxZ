package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.google.common.collect.Maps;
import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AddReportView;
import com.monsanto.barter.ar.business.service.dto.AddView;
import com.monsanto.barter.ar.web.faces.beans.addinput.datamodel.AdendaReportDataModel;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static junit.framework.Assert.*;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 2/25/14
 * Time: 3:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddReportFormFacesBean_UT {

    AdendaReportFormFacesBean adendaReportFormFacesBean;

    @Mock
    private ReportService reportService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    BeanFactory beanFactoryMock;

    @Mock
    RequestContext requestContextMock;

    @Mock
    private FacesContext context;

    @Mock
    private HttpServletResponse response;

    @Mock
    private Adenda addInput;

    @Mock
    private AddView addView;

    @Mock
    private AdendaReportDataModel searchResult;

    List<String> messages;

    private MaterialLas materialLas;

    private List<MaterialLas> materialLasList;

    private long materialLasId = 1L;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);


        materialLas = new MaterialLas();
        ReflectionTestUtils.setField(materialLas, "id", materialLasId);
        materialLasList = Arrays.asList(materialLas);
        messages = new ArrayList<String>();

        adendaReportFormFacesBean = new AdendaReportFormFacesBean() {
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
              public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }
        };

        setField(adendaReportFormFacesBean, "reportService", reportService);
    }

    @Test
    public void testClassInstance() {
        adendaReportFormFacesBean = new AdendaReportFormFacesBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.setIgnoredFields("adendaStates");
        tester.testInstance(adendaReportFormFacesBean);
    }

   @Test
    public void testBegin() {
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);

        String navigation = adendaReportFormFacesBean.begin();
        assertNotNull(adendaReportFormFacesBean.getMaterialLasList());
        assertTrue(adendaReportFormFacesBean.getMaterialLasList().size() == 1);
        assertEquals(AdendaReportFormFacesBean.PAGE_REPORT_FORM,navigation);
    }


    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        adendaReportFormFacesBean.begin();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
    }


    @Test
    public void testClear(){
        AddReportFilter filter = new AddReportFilter();
        filter.setDescription("description");
        adendaReportFormFacesBean.setFilter(filter);
        adendaReportFormFacesBean.clear();
        assertFalse(("description").equals(adendaReportFormFacesBean.getFilter().getDescription()));
    }

    @Test
    public void testDefaultSearch(){

        List<AddReportView> addReportViews = new ArrayList<AddReportView>();

        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);

        adendaReportFormFacesBean.begin();
        String navigation = adendaReportFormFacesBean.report();
        assertTrue(adendaReportFormFacesBean.getSearchResult().getRowCount() == 0);
        assertEquals(AdendaReportFormFacesBean.PAGE_REPORT_RESULT, navigation);
    }


    @Test
    public void testSearchInvalidDates(){
        List<AddView> addViews = new ArrayList<AddView>();

        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        adendaReportFormFacesBean.begin();
        Date date = getDateWithoutTime();
        adendaReportFormFacesBean.getFilter().setGenerationDateFrom(date);
        adendaReportFormFacesBean.getFilter().setGenerationDateTo(DateUtils.addWeeks(date, -2));

        String navigation = adendaReportFormFacesBean.report();
        assertEquals(adendaReportFormFacesBean.getSearchResult(),null);
        assertEquals(null, navigation);
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains("label.search.error.dateError"), is(true));
    }

    @Test
    public void postProcessXLS() {
        AddReportFilter filter = new AddReportFilter();
        Map<ReportMetadata, Long> reportMetadata = Maps.newHashMap();

        HSSFWorkbook document = buildWorkbook();

        when(searchResult.getRowCount()).thenReturn(3);
        adendaReportFormFacesBean.setSearchResult(searchResult);
        adendaReportFormFacesBean.setFilter(filter);
        adendaReportFormFacesBean.postProcessXLS(document);
    }

    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 15; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }

    private Date getDateWithoutTime() {
        Date date = new Date();
        date = DateUtils.setHours(date,0);
        date = DateUtils.setMinutes(date,0);
        date = DateUtils.setSeconds(date,0);
        date = DateUtils.setMilliseconds(date,0);
        return date;
    }
}
