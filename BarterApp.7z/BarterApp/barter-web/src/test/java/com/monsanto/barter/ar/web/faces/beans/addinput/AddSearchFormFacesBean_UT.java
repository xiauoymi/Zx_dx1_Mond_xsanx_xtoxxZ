package com.monsanto.barter.ar.web.faces.beans.addinput;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AddView;
import com.monsanto.barter.ar.business.service.dto.AttachmentView;
import com.monsanto.barter.ar.web.faces.beans.addinput.datamodel.AdendaDataModel;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import junit.framework.Assert;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.context.RequestContext;
import org.primefaces.event.ToggleEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import static java.util.Arrays.asList;
import static junit.framework.Assert.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 2/25/14
 * Time: 3:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddSearchFormFacesBean_UT {
    private AddSearchFormFacesBean addSearchFormFacesBean;

    @Mock
    private AdendaService adendaService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private RequestContext requestContextMock;

    @Mock
    private FacesContext context;

    @Mock
    private HttpServletResponse response;

    @Mock
    private AttachmentService attachmentService;

    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;

    @Mock
    private Adenda addInput;

    @Mock
    private AddView addView;

    @Mock
    private AdendaDataModel searchResult;

    @Mock
    private RemoteService remoteService;

    private List<String> messages;

    private List<MaterialLas> materialLasList;

    private TransactionTemplateMocker transactionTemplate;

    @Before
    public void setUp() {
        initMocks(this);

        MaterialLas materialLas = new MaterialLas();
        long materialLasId = 1L;
        ReflectionTestUtils.setField(materialLas, "id", materialLasId);
        materialLasList = asList(materialLas);
        messages = new ArrayList<String>();

        transactionTemplate = new TransactionTemplateMocker();

        addSearchFormFacesBean = new AddSearchFormFacesBean() {
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }

            @Override
            public TransactionTemplate getTransactionTemplate() {
                return transactionTemplate;
            }
        };

        when(beanFactoryMock.getBean(AdendaService.class)).thenReturn(adendaService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(RemoteService.class)).thenReturn(remoteService);
        when(beanFactoryMock.getBean(UnsuccessfulRemoteInvocationService.class)).thenReturn(unsuccessfulInvocationService);

        setField(addSearchFormFacesBean, "addView", addView);
        setField(addSearchFormFacesBean, "attachmentService", attachmentService);
        setField(addSearchFormFacesBean, "adendaService", adendaService);
        setField(addSearchFormFacesBean, "remoteService", remoteService);
        setField(addSearchFormFacesBean, "unsuccessfulInvocationService", unsuccessfulInvocationService);
        setField(addSearchFormFacesBean, "documentsUploader", new DocumentsUploader<Adenda>());
        setField(addSearchFormFacesBean, "searchResult", searchResult);
    }

    @Test
    public void testClassInstance() {
        addSearchFormFacesBean = new AddSearchFormFacesBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(addSearchFormFacesBean);
    }

    @Test
    public void testBegin() {
        when(materialLasService.findAll()).thenReturn(materialLasList);

        String navigation = addSearchFormFacesBean.begin();
        assertNotNull(addSearchFormFacesBean.getMaterialLasList());
        assertTrue(addSearchFormFacesBean.getMaterialLasList().size() == 1);
        assertEquals(AddSearchFormFacesBean.PAGE_SEARCH_FORM, navigation);
    }

    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        addSearchFormFacesBean.begin();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
    }

    @Test
    public void testClear(){
        AddFilter filter = new AddFilter();
        filter.setDescription("description");
        addSearchFormFacesBean.setFilter(filter);
        addSearchFormFacesBean.clear();
        assertFalse(("description").equals(addSearchFormFacesBean.getFilter().getDescription()));
    }

    @Test
    public void testDefaultSearch(){
        when(materialLasService.findAll()).thenReturn(materialLasList);

        addSearchFormFacesBean.begin();
        String navigation = addSearchFormFacesBean.search();
        assertTrue(addSearchFormFacesBean.getSearchResult().getRowCount() == 0);
        assertEquals(AddSearchFormFacesBean.PAGE_SEARCH_RESULT, navigation);
    }

    @Test
    public void testSearchInvalidDates(){
        when(materialLasService.findAll()).thenReturn(materialLasList);
        addSearchFormFacesBean.begin();
        Date date = getDateWithoutTime();
        addSearchFormFacesBean.getFilter().setGenerationDateFrom(date);
        addSearchFormFacesBean.getFilter().setGenerationDateTo(DateUtils.addWeeks(date, -2));

        String navigation = addSearchFormFacesBean.search();
        assertEquals(null, navigation);
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains("label.search.error.dateError"), is(true));
    }

    @Test
    public void testDelete(){
        Adenda adenda = new Adenda();

        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(adendaService.get(1L)).thenReturn(adenda);

        AddView view = new AddView(1L, "564", new Date(), "Soja");

        addSearchFormFacesBean.begin();
        addSearchFormFacesBean.setAddView(view);
        addSearchFormFacesBean.deleteAdenda();

        verify(adendaService).delete(adenda);
        verify(remoteService).delete(adenda);
        verify(unsuccessfulInvocationService).clearPendingInvocations(adenda);
    }

    @Test
    public void testDeleteFailure(){
        String error = "error";
        Adenda adenda = new Adenda();

        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(adendaService.get(1L)).thenReturn(adenda);

        AddView view = new AddView(1L, "564", new Date(), "Soja");
        doThrow(new BusinessException(error)).when(adendaService).delete(adenda);

        addSearchFormFacesBean.begin();
        addSearchFormFacesBean.setAddView(view);
        addSearchFormFacesBean.deleteAdenda();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
        assertThat(transactionTemplate.isExecutionRollbacked(), is(true));
    }

    @Test
    public void downloadFile() throws Exception {
        Long attachmentId = 1L;
        Adenda adenda = new Adenda();
        String mimeType = "application/octet-stream";
        String fileName = "file.zzz";
        byte[] fileContents = new byte[]{'a', 'b', 'c', 'd'};
        File file = new File(fileName, mimeType, 4L, fileContents);

        Attachment attachment = new Attachment(file,"234", DocumentType.ADD);
        ServletOutputStream outputStream = mock(ServletOutputStream.class);

        addSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        when(attachmentService.get(attachmentId)).thenReturn(attachment);
        when(adendaService.get(1L)).thenReturn(adenda);
        when(response.getOutputStream()).thenReturn(outputStream);

        addSearchFormFacesBean.downloadFile();

        verify(response).setContentType(mimeType);
        verify(response).setHeader("Content-Disposition", "attachment;filename=" + fileName);
        verify(outputStream).write(fileContents);
        verify(outputStream).flush();
        verify(outputStream).close();
        verify(context).responseComplete();
    }

    @Test
    public void downloadFile_failNoFile() throws Exception {
        Long attachmentId = 1L;
        when(attachmentService.get(attachmentId)).thenReturn(null);

        addSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        addSearchFormFacesBean.downloadFile();
    }

    @Test
    public void downloadFile_IOfailure() throws Exception {
        String errorMessage = "something went wrong";
        Long attachmentId = 1L;
        String mimeType = "application/octet-stream";
        String fileName = "file.zzz";
        byte[] fileContents = new byte[]{'a', 'b', 'c', 'd'};

        File file = new File(fileName, mimeType, 4L, fileContents);
        Attachment attachment = new Attachment(file,"234", DocumentType.ADD);

        when(attachmentService.get(attachmentId)).thenReturn(attachment);
        when(response.getOutputStream()).thenThrow(new IOException(errorMessage));

        addSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        addSearchFormFacesBean.downloadFile();

        assertThat(messages.get(0), is(errorMessage));
    }

    @Test
    public void deleteAttachment() {
        Long attachmentId = 1L;
        addSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        when(addView.getId()).thenReturn(1L);
        addSearchFormFacesBean.deleteAttachment();
    }

    @Test
    public void selectRow(){
        AddView addView1 = new AddView(1L,"123",new Date(),"");
        when(searchResult.getRowData()).thenReturn(addView1);
        addSearchFormFacesBean.selectedRow();
        Assert.assertTrue(addSearchFormFacesBean.getAddView().getId().equals(1L));
    }

    @Test
    public void setAttachmentToDelete(){
        AddView addView1 = new AddView(1L,"123",new Date(),"");
        when(searchResult.getRowData()).thenReturn(addView1);
        addSearchFormFacesBean.setAttachmentToDelete();
        Assert.assertTrue(addSearchFormFacesBean.getAddView().getId().equals(1L));
    }

    @Test
    public void getUploadDocumentTypes(){
        DocumentType[] uploadDocumentTypes = addSearchFormFacesBean.getUploadDocumentTypes();
        Assert.assertTrue(uploadDocumentTypes.length == 3);
    }

    private Date getDateWithoutTime() {
        Date date = new Date();
        date = DateUtils.setHours(date,0);
        date = DateUtils.setMinutes(date,0);
        date = DateUtils.setSeconds(date,0);
        date = DateUtils.setMilliseconds(date,0);
        return date;
    }

    @Test
    public void testPostProcessXLS(){
        AddFilter filter = new AddFilter();

        HSSFWorkbook document = buildWorkbook();

        when(searchResult.getRowCount()).thenReturn(3);
        addSearchFormFacesBean.setFilter(filter);
        addSearchFormFacesBean.postProcessXLS(document);
        //TODO: THIS DOESN'T TEST ANYTHING
    }

    @Test
    public void getAttachmentsFirstTime() {
        final long ADD_ID = 1L;
        AddView addView = new AddView(ADD_ID, "123", new Date(), "");
        AttachmentView attachmentView = new AttachmentView(1L, DocumentType.ADD, "1234");
        ToggleEvent event = mock(ToggleEvent.class);
        when(event.getData()).thenReturn(addView);
        when(adendaService.getAttachments(ADD_ID)).thenReturn(asList(attachmentView));
        addSearchFormFacesBean.onRowToggle(event);
        assertThat(addView.getListAttachmentView().size(), is(1));
        assertThat(addView.getListAttachmentView().contains(attachmentView), is(true));
    }

    @Test
    public void getAttachmentsFromView() {
        final long ADD_ID = 1L;
        AttachmentView attachmentView = new AttachmentView(1L, DocumentType.ADD, "1234");
        AddView addView = new AddView(ADD_ID, "123", new Date(), "");
        addView.setListAttachmentView(asList(attachmentView));
        ToggleEvent event = mock(ToggleEvent.class);
        when(event.getData()).thenReturn(addView);
        addSearchFormFacesBean.onRowToggle(event);
        assertThat(addView.getListAttachmentView().size(), is(1));
        assertThat(addView.getListAttachmentView().contains(attachmentView), is(true));
        verifyZeroInteractions(adendaService);
    }

    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 12; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }
}
