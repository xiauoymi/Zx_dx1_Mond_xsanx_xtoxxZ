package com.monsanto.barter.ar.web.faces.beans.addinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.adenda.AddInitialData;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class InitialDataSectionCC_UT {



    private class TestInitialDataSectionCC extends InitialDataSectionCC {
        protected BeanValidator getValidator() {
            return mockedValidator;
        }

        protected void addMessage(String message) {
            messages.add(message);
        }

    }

    @Mock
    BeanValidator mockedValidator;
    @Mock
    CustomerCC senderCC;
    @Mock
    LocationCC emissionPlace;

    InitialDataSectionCC step;

    List<String> messages;

    private Adenda adenda;

    @Before
    public void setUp() {
        initMocks(this);
        step = new TestInitialDataSectionCC();
        messages = new LinkedList<String>();

        adenda = new Adenda();
        step.setSenderCC(senderCC);
        step.setEmissionPlace(emissionPlace);

        step.setEntity(adenda);
    }

    @Test
    public void initialize() {
        int index = 0;
        String key = "key";
        step.initializeStepCC(index, key, adenda, Mode.CREATE);
        step.begin();
        assertThat(step.getGroups().contains(AddInitialData.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
        assertThat(step.getAddInput(), is(adenda));
    }

    @Test
    public void validateSenderWithoutViolations() {
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        CustomerLas sender = new CustomerLas();
        adenda.setSender(sender);

        when(mockedValidator.validate(sender, InitialDataSectionCC.SENDER_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(adenda, AddInitialData.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(true));
    }

    @Test
    public void validateSenderWithViolations() {
        String error = "error";
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        customerViolations.add(InitialDataSectionCC.SENDER_KEY + ": " + error);
        CustomerLas sender = new CustomerLas();
        adenda.setSender(sender);

        when(mockedValidator.validate(sender, InitialDataSectionCC.SENDER_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(adenda, AddInitialData.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(InitialDataSectionCC.SENDER_KEY + ": " + error), is(true));
    }

    @Test
    public void testSetValuesFromComponent(){
        String documentNumber = "document";
        CustomerLas spied = spy(new CustomerLas());
        doReturn(documentNumber).when(spied).getDocument();
        CityAfipLas cityAfipLas = new CityAfipLas();

        when(senderCC.getSelectedCustomer()).thenReturn(spied);
//        step.getSenderCC().setDocumentNumber(documentNumber);
        when(emissionPlace.getCitySelected()).thenReturn(cityAfipLas);
//        step.getEmissionPlace().setCity(cityAfipLas);
        Assert.assertNull(adenda.getSender());
        Assert.assertNull(adenda.getCity());

        step.setValuesFromComponents();

        Assert.assertEquals(spied, adenda.getSender());
        Assert.assertEquals(cityAfipLas, adenda.getCity());
    }

}
