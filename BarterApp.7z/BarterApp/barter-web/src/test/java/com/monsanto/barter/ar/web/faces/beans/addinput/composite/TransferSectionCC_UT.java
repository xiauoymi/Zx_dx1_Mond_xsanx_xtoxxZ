package com.monsanto.barter.ar.web.faces.beans.addinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.adenda.AddTransfer;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

@SuppressWarnings("unchecked")
public class TransferSectionCC_UT {

    private class TestTransferSectionCC extends TransferSectionCC {
        protected BeanValidator getValidator() {
            return mockedValidator;
        }

        protected void addMessage(String message) {
            messages.add(message);
        }

    }

    @Mock
    private BeanValidator mockedValidator;
    @Mock
    private CustomerCC receptorCC;
    @Mock
    private MaterialLasService materialLasService;

    TestTransferSectionCC step;

    List<String> messages;

    private Adenda adenda;


    @Before
    public void setUp() {
        initMocks(this);
        step = new TestTransferSectionCC();
        messages = new LinkedList<String>();

        adenda = new Adenda();
        step.setReceptor(receptorCC);
        step.setIdMaterialLas(1l);

        step.setEntity(adenda);
        step.setMaterialLasService(materialLasService);
    }

    @Test
    public void initialize() {
        int index = 2;
        String key = "key";

        step.initializeStepCC(index, key, adenda, Mode.CREATE);
        step.begin();

        assertThat(step.getGroups().contains(AddTransfer.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
        assertThat(step.getAddInput(), is(adenda));
    }

    @Test
    public void validateReceptorWithoutViolations() {
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        CustomerLas receptor = new CustomerLas();
        adenda.setReceptor(receptor);

        when(mockedValidator.validate(receptor, TransferSectionCC.RECEPTOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(adenda, AddTransfer.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(true));
    }

    @Test
    public void validateReceptorWithViolations() {
        String error = "error";
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        customerViolations.add(TransferSectionCC.RECEPTOR_KEY + ": " + error);
        CustomerLas receptor = new CustomerLas();
        adenda.setReceptor(receptor);

        when(mockedValidator.validate(receptor, TransferSectionCC.RECEPTOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(adenda, AddTransfer.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(TransferSectionCC.RECEPTOR_KEY + ": " + error), is(true));
    }

    @Test
    public void testSetValuesFromComponent(){
        String documentNumber = "document";
        CustomerLas spiedCustomer = spy(new CustomerLas());
        doReturn(documentNumber).when(spiedCustomer).getDocument();
        MaterialLas spied = spy(new MaterialLas());
        doReturn(1l).when(spied).getId();
        List<MaterialLas> materialLasList = new ArrayList<MaterialLas>();
        materialLasList.add(spied);
        step.setMaterialLasList(materialLasList);
        Long idCropType = 1l;
        when(receptorCC.getSelectedCustomer()).thenReturn(spiedCustomer);
        step.getReceptor().setCustomer(spiedCustomer);

        step.getReceptor().setDocumentNumber(documentNumber);
        step.setIdMaterialLas(idCropType);
        Assert.assertNull(adenda.getSender());
        Assert.assertNull(adenda.getCropType());

        step.setValuesFromComponents();

        Assert.assertEquals(spiedCustomer, adenda.getReceptor());
        Assert.assertEquals(idCropType, adenda.getCropType().getId());
    }

}
