package com.monsanto.barter.ar.web.faces.beans.addinput.datamodel;

import com.monsanto.barter.ar.business.service.AddFilter;
import com.monsanto.barter.ar.business.service.AdendaService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.AddView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author LABAEZ
 */
public class AdendaDatamodel_UT {

    @Mock
    private AdendaService service;

    private AddFilter filter;
    private AdendaDataModel dataModel;
    private List<AddView> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new AddFilter();
        page = new ArrayList<AddView>();
        dataModel = new AdendaDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void load() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<AddView> recordset = new Recordset<AddView>(new ArrayList<AddView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<AddView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void load_descending() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.DESCENDING;
        Map<String,String> filters = null;
        Recordset<AddView> recordset = new Recordset<AddView>(new ArrayList<AddView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<AddView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void getRowData() {
        AddView addView = new AddView(1L, null, null, null);
        page.add(addView);

        assertThat(dataModel.getRowData("1"), is(addView));
    }

    @Test
    public void getRowData_noMatches() {
        AddView addView = new AddView(1L, null, null, null);
        page.add(addView);

        assertThat(dataModel.getRowData("2"), is(nullValue()));
    }

    @Test
    public void getRowKey() {
        AddView addView = new AddView(1L, null, null, null);
        assertThat(dataModel.getRowKey(addView), is((Object)"1"));
    }
}