package com.monsanto.barter.ar.web.faces.beans.addinput.datamodel;

import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AddReportView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author LABAEZ
 */
public class AdendaReportDatamodel_UT {

    @Mock
    private ReportService service;

    private AddReportFilter filter;
    private AdendaReportDataModel dataModel;
    private List<AddReportView> page;

    private final static String SORT_FIELD = "sortField";
    private final static String FIXED_SORT_FIELD = "fixedSortField";

    @Before
    public void setUp() {
        initMocks(this);
        filter = new AddReportFilter();
        page = new ArrayList<AddReportView>();
        dataModel = new AdendaReportDataModel(service, filter);
        setField(dataModel, "page", page);
    }



    @Test
    public void load() {
        int first = 0;
        int pageSize = 0;
        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<AddReportView> recordset = new Recordset<AddReportView>(new ArrayList<AddReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<AddReportView> results = dataModel.load(first, pageSize, SORT_FIELD, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(SORT_FIELD));
    }

    @Test
    public void testLoadWithFixedSortFieldAndDefaultOrder(){
        int first = 0;
        int pageSize = 0;

        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<AddReportView> recordset = new Recordset<AddReportView>(new ArrayList<AddReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);
        dataModel.setFixedSortField(FIXED_SORT_FIELD);
        List<AddReportView> results = dataModel.load(first, pageSize, SORT_FIELD, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(FIXED_SORT_FIELD));
    }

    @Test
    public void testLoadWithFixedSortFieldAndDescendingOrder(){
        int first = 0;
        int pageSize = 0;

        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<AddReportView> recordset = new Recordset<AddReportView>(new ArrayList<AddReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);
        dataModel.setFixedSortField(FIXED_SORT_FIELD);
        dataModel.setFixedSortOrder(Paging.SortOrder.DESC);
        List<AddReportView> results = dataModel.load(first, pageSize, SORT_FIELD, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(FIXED_SORT_FIELD));
    }

    @Test
    public void load_descending() {
        int first = 0;
        int pageSize = 0;
        SortOrder sortOrder = SortOrder.DESCENDING;
        Map<String,String> filters = null;
        Recordset<AddReportView> recordset = new Recordset<AddReportView>(new ArrayList<AddReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<AddReportView> results = dataModel.load(first, pageSize, SORT_FIELD, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(SORT_FIELD));
    }

    @Test
    public void getRowData() {
        AddReportView addReportView = new AddReportView();
        setField(addReportView, "id", 12L);
        page.add(addReportView);

        assertThat(dataModel.getRowData("12"), is(addReportView));
    }

    @Test
    public void getRowData_noMatches() {
        AddReportView addReportView = new AddReportView();
        setField(addReportView, "id", 14L);
        page.add(addReportView);

        assertThat(dataModel.getRowData("2"), is(nullValue()));
    }

    @Test
    public void getRowKey() {
        AddReportView addReportView = new AddReportView();
        setField(addReportView, "id", 14L);

        assertThat(dataModel.getRowKey(addReportView), is((Object)"14"));
    }

}