package com.monsanto.barter.ar.web.faces.beans.delivery;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.BaseDocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.dto.FileDTO;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.reflection.Whitebox;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.BeanFactory;

import javax.faces.event.AbortProcessingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DeliveryDetail_UT {

    public static final String SUCCESS = "success";
    @Mock
    private DeliveryService deliveryService;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private BeanValidator beanValidator;

    private List<String> messages;

    private DeliveryDetail deliveryDetail;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        messages = new ArrayList<String>();
        deliveryDetail = new DeliveryDetail(){
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }
        };

        when(beanFactoryMock.getBean(DeliveryService.class)).thenReturn(deliveryService);
        Delivery delivery = new Delivery();
        when(deliveryService.get(anyLong())).thenReturn(delivery);
    }

    @Test
    public void testClassInstance(){
        deliveryDetail = new DeliveryDetail();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(deliveryDetail);
    }

    @Test
    public void testView() throws Exception {
        when(deliveryService.get(anyLong())).thenReturn(new Delivery());
        deliveryDetail.setId(1L);
        String result = deliveryDetail.view();
        assertThat(deliveryDetail.getDelivery()).isNotNull();
        assertThat(SUCCESS).isEqualTo(result);
    }

    @Test
    public void testBack() throws Exception {
        deliveryDetail.setId(1L);
        deliveryDetail.view();
        String result = deliveryDetail.back();
        Object number = Whitebox.getInternalState(deliveryDetail, "id");
        assertThat(number).isNull();
        assertThat(deliveryDetail.getDelivery()).isNull();
        assertThat(SUCCESS).isEqualTo(result);
    }

    @Test
    public void generatePdfThenFileDTONotNull(){
        deliveryDetail.init();
        when(deliveryService.getPDF(any(Delivery.class), any(GrowerPortalDocumentType.class))).thenReturn(new FileDTO());
        deliveryDetail.generatePDF();
        assertThat(deliveryDetail.getPdf()).isNotNull();
    }

    @Test
    public void generatePdfThrowsError(){
        deliveryDetail.init();
        when(deliveryService.getPDF(any(Delivery.class), any(GrowerPortalDocumentType.class))).thenThrow(new BusinessException("error"));

        try{
            deliveryDetail.generatePDF();
        } catch (AbortProcessingException e){
            assertNotNull(messages);
            assertThat(messages.get(0)).isEqualTo("error");
        }
    }

    @Test
    public void getPdfFileThenReturnsStream(){
        FileDTO pdf = new FileDTO("filename.pdf","application/pdf",200L,null);
        deliveryDetail.setPdf(pdf);
        StreamedContent content = deliveryDetail.getPdfFile();
        assertNotNull(content);
    }




}