package com.monsanto.barter.ar.web.faces.beans.delivery;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.filter.DeliveryFilter;
import com.monsanto.barter.ar.business.service.DeliveryService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.delivery.datamodel.DeliveryDataModel;
import org.apache.commons.lang.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.springframework.beans.factory.BeanFactory;

import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class DeliverySearchFormFacesBean_UT {

    private static final String PAGE_SEARCH_FORM = "success";
    private static final String PAGE_SEARCH_RESULT = "search-result";
    public static final long CROP_ID = 1L;

    private DeliverySearchFormFacesBean facesBean;

    @Mock
    private BeanFactory beanFactory;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private DeliveryService deliveryService;

    @Mock
    private PortService portService;

    @Mock
    private MaterialLas crop;

    @Mock
    private DeliveryDataModel searchResult;

    private List<String> messages;

    @Before
    public void setUp(){
        initMocks(this);
        messages = new ArrayList<String>();

        List<MaterialLas> materialLasArrayList = new ArrayList<MaterialLas>();
        materialLasArrayList.add(crop);
        when(materialLasService.findAll()).thenReturn(materialLasArrayList);

        when(beanFactory.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactory.getBean(DeliveryService.class)).thenReturn(deliveryService);
        when(beanFactory.getBean(PortService.class)).thenReturn(portService);

        facesBean = new DeliverySearchFormFacesBean(){
            @Override
            public BeanFactory getBeanFactory() {
                return beanFactory;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

        };
    }

    @Test
    public void testClassInstance(){
        facesBean = new DeliverySearchFormFacesBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(facesBean);
    }

    @Test
    public void begin(){
        String result = facesBean.begin();
        Object deliveryService = Whitebox.getInternalState(facesBean, "service");
        Object materialLasService = Whitebox.getInternalState(facesBean, "materialLasService");
        assertThat(deliveryService).isNotNull();
        assertThat(materialLasService).isNotNull();
        assertThat(facesBean.getMaterialLasList()).isNotEmpty();
        assertThat(result).isEqualTo(PAGE_SEARCH_FORM);
    }

    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        facesBean.begin();
        Assert.assertThat(messages.isEmpty(), is(false));
        Assert.assertThat(messages.contains(error), is(true));
    }

    @Test
    public void clear(){
        facesBean.begin();
        facesBean.getFilter().setDepositor("Juan");

        String result = facesBean.clear();

        assertThat(facesBean.getFilter().getDepositor()).isNull();
        assertThat(result).isEqualTo(PAGE_SEARCH_FORM);
    }

    @Test
    public void search(){
        facesBean.begin();
        when(crop.getId()).thenReturn(CROP_ID);
        facesBean.getFilter().setCropTypeId(CROP_ID);
        String result = facesBean.search();
        assertThat(facesBean.getSearchResult()).isNotNull();
        assertThat(facesBean.getSearchResult().getRowCount()).isEqualTo(0);
        assertThat(result).isEqualTo(PAGE_SEARCH_RESULT);
    }

    @Test
    public void searchWithInvalidDates(){
        facesBean.begin();
        when(crop.getId()).thenReturn(CROP_ID);
        DeliveryFilter filter = facesBean.getFilter();
        filter.setCropTypeId(CROP_ID);
        Date date = new Date();
        filter.setCreationDateFrom(date);
        filter.setCreationDateTo(DateUtils.addWeeks(date, -2));
        String result = facesBean.search();
        assertThat(facesBean.getSearchResult()).isNull();
        assertEquals(null, result);
        Assert.assertThat(messages.isEmpty(), is(false));
        Assert.assertThat(messages.contains("label.search.error.dateError"), is(true));
    }

    @Test
    public void postProcessXLS() {
        setupDeliveryFilter();
        HSSFWorkbook document = buildWorkbook();
        facesBean.setSearchResult(searchResult);
        when(searchResult.getRowCount()).thenReturn(3);

        facesBean.postProcessXLS(document);
    }

    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 15; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }

    private void setupDeliveryFilter(){
        DeliveryFilter filter = new DeliveryFilter();
        filter.setCac("CAC1");
        facesBean.setFilter(filter);
    }

    @Test
    public void autocompletePortDestinationsWithNoResults(){
        String non_exist_port = "NON_EXIST_PORT";
        when(crop.getId()).thenReturn(CROP_ID);
        when(portService.search(non_exist_port)).thenReturn(new ArrayList<PortDestinationDTO>());
        facesBean.begin();
        List<PortDestinationDTO> result = facesBean.autocomplete(non_exist_port);
        junit.framework.Assert.assertTrue(result.isEmpty());
    }

}