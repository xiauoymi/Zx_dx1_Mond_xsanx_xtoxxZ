package com.monsanto.barter.ar.web.faces.beans.growercontract;

import com.monsanto.barter.ar.business.entity.FinalLiquidation;
import com.monsanto.barter.ar.business.entity.GrowerContract;
import com.monsanto.barter.ar.business.entity.Liquidation;
import com.monsanto.barter.ar.business.entity.enumerated.GrowerPortalDocumentType;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.dto.LiquidationView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.util.reflection.Whitebox;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class GrowerContractDetail_UT {

    public static final String SUCCESS = "success";
    private GrowerContractService growerContractService;

    private GrowerContractDetail growerContractDetail;

    @Before
    public void setUp(){
        growerContractService = mock(GrowerContractService.class);
        GrowerContract growerContract = new GrowerContract();
        when(growerContractService.get(anyLong())).thenReturn(growerContract);
        growerContractDetail = new GrowerContractDetail(){

            @Override
            public <T> T getService(Class<T> requiredType) {
                return (T) growerContractService;
            }
        };
    }

    @Test
    public void testView() throws Exception {
        growerContractDetail.setId(1L);

        String result = growerContractDetail.view();

        assertThat(growerContractDetail.getGrowerContract()).isNotNull();
        assertThat(SUCCESS).isEqualTo(result);
    }

    @Test
    public void testBack() throws Exception {
        growerContractDetail.setId(1L);
        growerContractDetail.view();

        String result = growerContractDetail.back();

        Object number = Whitebox.getInternalState(growerContractDetail, "id");
        assertThat(number).isNull();
        assertThat(growerContractDetail.getGrowerContract()).isNull();
        assertThat(SUCCESS).isEqualTo(result);
    }

    @Test
    public void getLiquidationListReturnsAList(){
        GrowerContract growerContract = new GrowerContract();
        FinalLiquidation liquidation = new FinalLiquidation();
        Set<Liquidation> liquidations = new HashSet<Liquidation>();
        liquidations.add(liquidation);
        growerContract.setLiquidations(liquidations);
        Whitebox.setInternalState(growerContractDetail, "growerContract", growerContract);
        List<LiquidationView> liquidationList = growerContractDetail.getLiquidationList();
        assertThat(liquidationList).isNotNull();
        assertThat(liquidationList.size()).isEqualTo(1);
    }

    @Test
    public void getLiquidationListNullThenReturnsAnEmptyList(){
        GrowerContract growerContract = new GrowerContract();
        Whitebox.setInternalState(growerContractDetail, "growerContract", growerContract);
        List<LiquidationView> liquidationList = growerContractDetail.getLiquidationList();
        assertThat(liquidationList).isNotNull();
        assertThat(liquidationList.size()).isEqualTo(0);
    }

    @Test
    public void testGetDocType(){
        assertThat(growerContractDetail.getDocType()).isEqualTo(GrowerPortalDocumentType.GROWER_CONTRACT);
    }

    @Test
    public void testGetSapId(){
        GrowerContract growerContract = new GrowerContract();
        growerContract.setNumber("1");
        Whitebox.setInternalState(growerContractDetail, "growerContract", growerContract);
        assertThat(growerContractDetail.getSAPId()).isEqualTo("1");
    }
}