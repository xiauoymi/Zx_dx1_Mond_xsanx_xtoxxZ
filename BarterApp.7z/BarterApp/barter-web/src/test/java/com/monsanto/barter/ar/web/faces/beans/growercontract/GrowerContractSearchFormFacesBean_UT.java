package com.monsanto.barter.ar.web.faces.beans.growercontract;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.beans.growercontract.datamodel.GrowerContractDataModel;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.springframework.beans.factory.BeanFactory;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class GrowerContractSearchFormFacesBean_UT {

    private static final String PAGE_SEARCH_FORM = "success";
    private static final String PAGE_SEARCH_RESULT = "search-result";
    public static final long CROP_ID = 1L;

    private GrowerContractSearchFormFacesBean facesBean;

    @Mock
    private BeanFactory beanFactory;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private GrowerContractService growerContractService;

    @Mock
    private MaterialLas crop;

    private List<String> messages;
    @Mock
    private GrowerContractDataModel searchResult;
    @Mock
    private PortService portService;

    @Before
    public void setUp(){
        initMocks(this);
        messages = new ArrayList<String>();

        List<MaterialLas> materialLasArrayList = new ArrayList<MaterialLas>();
        when(crop.getId()).thenReturn(CROP_ID);
        when(crop.getPrimaryKey()).thenReturn(CROP_ID);
        materialLasArrayList.add(crop);
        when(materialLasService.findAll()).thenReturn(materialLasArrayList);

        when(beanFactory.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactory.getBean(GrowerContractService.class)).thenReturn(growerContractService);
        when(beanFactory.getBean(PortService.class)).thenReturn(portService);

        facesBean = new GrowerContractSearchFormFacesBean(){
            @Override
            public BeanFactory getBeanFactory() {
                return beanFactory;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }
        };
    }

    @Test
    public void begin(){
        String result = facesBean.begin();
        Object growerContractService = Whitebox.getInternalState(facesBean, "service");
        Object materialLasService = Whitebox.getInternalState(facesBean, "materialLasService");
        assertThat(growerContractService).isNotNull();
        assertThat(materialLasService).isNotNull();
        assertThat(facesBean.getMaterialLasList()).isNotEmpty();
        assertThat(result).isEqualTo(PAGE_SEARCH_FORM);
    }

    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        facesBean.begin();
        Assert.assertThat(messages.isEmpty(), is(false));
        Assert.assertThat(messages.contains(error), is(true));
    }

    @Test
    public void clear(){
        facesBean.begin();
        facesBean.getFilter().setGrower("Juan");

        String result = facesBean.clear();

        assertThat(facesBean.getFilter().getGrower()).isNull();
        assertThat(result).isEqualTo(PAGE_SEARCH_FORM);
    }

    @Test
    public void search(){
        facesBean.begin();
        facesBean.getFilter().setCropId(CROP_ID);

        String result = facesBean.search();

        assertThat(facesBean.getFilter().getCrop().getId()).isEqualTo(CROP_ID);
        assertThat(facesBean.getSearchResult()).isNotNull();
        assertThat(facesBean.getSearchResult().getRowCount()).isEqualTo(0);
        assertThat(result).isEqualTo(PAGE_SEARCH_RESULT);
    }
    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 12; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }
    @Test
    public void export(){
        facesBean.begin();
        HSSFWorkbook document = buildWorkbook();
        when(searchResult.getRowCount()).thenReturn(3);
        facesBean.setSearchResult(searchResult);
        facesBean.postProcessXLS(document);
    }

    @Test
    public void autocompletePortDestinationsWithNoResults(){
        String non_exist_port = "NON_EXIST_PORT";
        when(crop.getId()).thenReturn(CROP_ID);
        when(portService.search(non_exist_port)).thenReturn(new ArrayList<PortDestinationDTO>());
        facesBean.begin();
        List<PortDestinationDTO> result = facesBean.portAutocomplete(non_exist_port);
        junit.framework.Assert.assertTrue(result.isEmpty());
    }

}