package com.monsanto.barter.ar.web.faces.beans.growercontract.datamodel;


import com.monsanto.barter.ar.business.filter.GrowerContractFilter;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.GrowerContractView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

public class GrowerContractDataModel_UT {

    @Mock
private GrowerContractService service;

private GrowerContractFilter filter;
private GrowerContractDataModel dataModel;
private List<GrowerContractView> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new GrowerContractFilter();
        page = new ArrayList<GrowerContractView>();
        dataModel = new GrowerContractDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void load() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<GrowerContractView> recordset = new Recordset<GrowerContractView>(new ArrayList<GrowerContractView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<GrowerContractView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void load_descending() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.DESCENDING;
        Map<String,String> filters = null;
        Recordset<GrowerContractView> recordset = new Recordset<GrowerContractView>(new ArrayList<GrowerContractView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<GrowerContractView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void getRowData() {
        GrowerContractView growerContractView = new GrowerContractView(1L);
        page.add(growerContractView);

        assertThat(dataModel.getRowData(1L), is(growerContractView));
    }

    @Test
    public void getRowDataLong() {
        GrowerContractView growerContractView = new GrowerContractView(1L);
        page.add(growerContractView);

        assertThat(dataModel.getRowData(1L), is(growerContractView));
    }

    @Test
    public void getRowData_noMatches() {
        GrowerContractView growerContractView = new GrowerContractView(1L);
        page.add(growerContractView);

        assertThat(dataModel.getRowData(2l), is(nullValue()));
    }

    @Test
    public void getRowKey() {
        GrowerContractView growerContractView = new GrowerContractView(1L);
        assertThat(dataModel.getRowKey(growerContractView), is((Object)1L));
    }

}