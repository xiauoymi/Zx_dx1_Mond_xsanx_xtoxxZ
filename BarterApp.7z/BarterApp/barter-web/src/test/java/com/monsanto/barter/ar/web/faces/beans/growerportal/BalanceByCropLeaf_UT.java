package com.monsanto.barter.ar.web.faces.beans.growerportal;

import org.junit.Before;
import org.mockito.MockitoAnnotations;
import org.primefaces.model.TreeNode;
import com.monsanto.barter.GetterAndSetterTester;
import org.junit.Test;
import org.mockito.Mock;

/**
 * @author VNBARR
 */
public class BalanceByCropLeaf_UT {
    @Mock
    private TreeNode materialNode;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testClassInstance(){
        GetterAndSetterTester tester = new GetterAndSetterTester();
        //TreeNode materialNode, Long cropTypeId,String cropTypeDescription, Double fixedValue, Double notFixedValue,
        //Double inProcess, Double appliedInCrop, Double okYield, Double pendingToApply
        tester.testInstance(new BalanceByCropLeaf(materialNode,1L,"MAIZ",1D,2D,10D,20D,3D,4D,5D,6D));
    }

}
