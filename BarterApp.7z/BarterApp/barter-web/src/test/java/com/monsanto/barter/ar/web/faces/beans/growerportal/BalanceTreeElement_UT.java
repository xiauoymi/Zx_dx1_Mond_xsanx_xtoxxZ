package com.monsanto.barter.ar.web.faces.beans.growerportal;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;
import org.junit.Test;

import static com.thoughtworks.selenium.SeleneseTestBase.*;

/**
 * @author VNBARR
 */
public class BalanceTreeElement_UT {

    public static final String A_FIJAR = "A FIJAR";

    @Test
    public void testClassInstance(){
        GetterAndSetterTester tester = new GetterAndSetterTester();
        //String label, GrowerPortalBalanceType balanceType, Long cropTypeId, Double partial, Double total, String cereal
        tester.testInstance(getBalanceTree(A_FIJAR, GrowerPortalBalanceType.TO_FIX));
    }

    private BalanceTreeElement getBalanceTree(String label, GrowerPortalBalanceType balanceType) {
        return new BalanceTreeElement(label, balanceType,555L,1D,2D, "MAIZ");
    }

    @Test
    public void compareToReturnsZeroWhenEquals(){
        BalanceTreeElement aBalance = getBalanceTree(A_FIJAR, GrowerPortalBalanceType.TO_FIX);
        BalanceTreeElement anotherBalance = getBalanceTree(A_FIJAR, GrowerPortalBalanceType.TO_FIX);

        assertEquals(0,aBalance.compareTo(anotherBalance));
    }

    @Test
    public void compareToReturnsDifferentFromZeroWhenNotEquals(){
        BalanceTreeElement aBalance = getBalanceTree(A_FIJAR, GrowerPortalBalanceType.TO_FIX);
        BalanceTreeElement anotherBalance = getBalanceTree("A PRECIO", GrowerPortalBalanceType.TO_FIX);

        assertNotEquals(0, aBalance.compareTo(anotherBalance));
    }

    @Test
    public void viewAccountReturnsTrueWhenContracts(){
        BalanceTreeElement aBalance = getBalanceTree(A_FIJAR, GrowerPortalBalanceType.TO_FIX);
        assertTrue(aBalance.isViewAccount());
    }

    @Test
    public void viewAccountReturnsFalseWhenUnloads(){
        BalanceTreeElement aBalance = getBalanceTree("Aplicado a Cereal in advance", GrowerPortalBalanceType.APPLIED_IN_CROP);
        assertFalse(aBalance.isViewAccount());
    }
}
