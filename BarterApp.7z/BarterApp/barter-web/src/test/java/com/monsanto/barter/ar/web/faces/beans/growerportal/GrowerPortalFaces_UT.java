package com.monsanto.barter.ar.web.faces.beans.growerportal;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.service.GrowerContractService;
import com.monsanto.barter.ar.business.service.GrowerPortalBalancesFilter;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.UnloadService;
import com.monsanto.barter.ar.business.service.dto.GrowerContractView;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalanceType;
import com.monsanto.barter.ar.business.service.dto.GrowerPortalBalancesView;
import com.monsanto.barter.ar.business.service.dto.UnloadView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.model.TreeNode;
import org.springframework.beans.factory.BeanFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.thoughtworks.selenium.SeleneseTestBase.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * @author VNBARR
 */
public class GrowerPortalFaces_UT {

    private GrowerPortalFaces growerPortalFaces;
    @Mock
    private GrowerContractService growerContractService;
    @Mock
    private MaterialLasService materialService;
    @Mock
    private UnloadService unloadService;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private TreeNode mockTreeNode;

    @Before
    public void setUp(){
        initMocks(this);
        this.growerPortalFaces = new GrowerPortalFaces(){
            @Override
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }
        };
        when(beanFactoryMock.getBean(GrowerContractService.class)).thenReturn(growerContractService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialService);
        when(beanFactoryMock.getBean(UnloadService.class)).thenReturn(unloadService);
    }

    @Test
    public void testClassInstance() {
        this.growerPortalFaces = new GrowerPortalFaces();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(growerPortalFaces);
    }

    @Test
    public void beginSetUpsElements(){
        String navigation = this.growerPortalFaces.begin();
        assertEquals("success",navigation);
        assertNotNull(this.growerPortalFaces.getContractsRoot());
        assertNull(this.growerPortalFaces.getContractViews());
        assertNull(this.growerPortalFaces.getUnloads());
    }

    private GrowerPortalBalancesView getGrowerPortalBalance() {
        //Long cropTypeId, String cropTypeDescription, Double addInProcessBalanceTns,Double bolInProcessBalanceTns,Double rtInProcessBalanceTns,
        //Double addCertificatedBalanceTns,Double bolCertificatedBalanceTns,Double rtCertificatedBalanceTns,Double addYieldBalanceTns,Double bolYieldBalanceTns
        //  ,Double rtYieldBalanceTns, Double contractPriceBalanceTn,Double contractPriceBalanceUSD,Double contractToFixBalanceTn,Double contractToFixBalanceUSD
        return new GrowerPortalBalancesView(55L,"MAIZ",10D,20D,30D,40D,50D,60D,70D,80D,90D,100D,110D,120D,130D,140D,150D,160D);
    }

    @Test
    public void beginWithDataSetUpsElements(){
        List<GrowerPortalBalancesView> list = new ArrayList<GrowerPortalBalancesView>();
        list.add(getGrowerPortalBalance());
        when(materialService.getContractsAndDocumentsBalancesGroupByCropType(null)).thenReturn(list);
        String navigation = this.growerPortalFaces.begin();
        assertEquals("success",navigation);
        assertNotNull(this.growerPortalFaces.getContractsRoot());
        assertNull(this.growerPortalFaces.getContractViews());
        assertNull(this.growerPortalFaces.getUnloads());
        assertEquals(1060D,this.growerPortalFaces.getTotalTns());
    }


    @Test
    public void viewDocDetailWhenIsLeafIsFalse(){
        this.growerPortalFaces.setSelectedNode(mockTreeNode);
        when(mockTreeNode.isLeaf()).thenReturn(false);
        this.growerPortalFaces.viewDocDetail();
        assertNull(this.growerPortalFaces.getContractViews());
        assertNull(this.growerPortalFaces.getUnloads());
    }

    @Test
    public void viewDocDetailWhenIsUnloadLeaf(){
        this.growerPortalFaces.begin();
        BalanceTreeElement selectedData = new BalanceTreeElement("Aplicado a Cereal in advance", GrowerPortalBalanceType.APPLIED_IN_CROP,2L, null,1000D,  "MAIZ");
        when(mockTreeNode.getData()).thenReturn(selectedData);
        when(mockTreeNode.isLeaf()).thenReturn(true);
        List<UnloadView> list = new ArrayList<UnloadView>();
        list.add(new UnloadView("1245","RT",2l, new Date(),100f));
        when(unloadService.getUnloadsByGrowerPortalBalanceFilter(any(GrowerPortalBalancesFilter.class))).thenReturn(list);
        this.growerPortalFaces.setSelectedNode(mockTreeNode);

        this.growerPortalFaces.viewDocDetail();
        assertNull(this.growerPortalFaces.getContractViews());
        assertNotNull(this.growerPortalFaces.getUnloads());

    }

    @Test
    public void viewDocDetailWhenIsContractLeaf(){
        this.growerPortalFaces.begin();
        BalanceTreeElement selectedData = new BalanceTreeElement("A precio", GrowerPortalBalanceType.PRICE,2L, 2D,1000D,  "MAIZ");
        when(mockTreeNode.getData()).thenReturn(selectedData);
        when(mockTreeNode.isLeaf()).thenReturn(true);
        List<GrowerContractView> list = new ArrayList<GrowerContractView>();
        list.add(new GrowerContractView(1L));
        when(growerContractService.findContractsByGrowerPortalBalanceFilter(any(GrowerPortalBalancesFilter.class))).thenReturn(list);

        this.growerPortalFaces.setSelectedNode(mockTreeNode);
        this.growerPortalFaces.viewDocDetail();
        assertNotNull(this.growerPortalFaces.getContractViews());
        assertEquals(list,this.growerPortalFaces.getContractViews());
        assertNull(this.growerPortalFaces.getUnloads());
    }

}
