package com.monsanto.barter.ar.web.faces.beans.main;

import com.monsanto.barter.ar.business.entity.GlobalBarterInterventorCompany;
import com.monsanto.barter.ar.business.entity.Vendor;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.UserTypeEnum;
import com.monsanto.barter.ar.business.service.VendorService;
import org.junit.Before;
import org.junit.Test;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by JASANC5 on 7/17/2014.
 */
public class PrincipalFaces_UT {

    public static final String SUCCESS = "success";
    public static final String HECTOR = "Hector";
    public static final String N_A = "N/A";
    public static final String HECTOR_SRL = "Hector SRL";
    public static final String REQUEST_CONTEXT_PATH = "REQUEST_CONTEXT_PATH";
    public static final String HECTOR_S_CSS = "Hector's css ";
    public static final String RULES = "rules";
    public static final String NEIRA = "Neira";

    private PrincipalFaces principalFaces;

    private UserDecorator userDecorator;

    private VendorService vendorService;

    private FacesContext facesContext;

    @Before
    public void setUp(){
        userDecorator = mock(UserDecorator.class);
        vendorService = mock(VendorService.class);
        facesContext = mock(FacesContext.class);
        principalFaces = new PrincipalFaces(){

            @Override
            protected void logout() { }

            @Override
            public UserDecorator getLoggedUser() {
                return userDecorator;
            }

            @Override
            public <T> T getService(Class<T> requiredType) {
                return (T) vendorService;
            }

            @Override
            public String getApplicationProperty(String key) {
                return HECTOR_S_CSS + REQUEST_CONTEXT_PATH;
            }

            @Override
            protected FacesContext getFacesContext() {
                return facesContext;
            }
        };
    }

    @Test
    public void getCustomerNameWithoutCompany(){
        String result = principalFaces.getCustomerCompany();

        assertThat(result).isEqualTo(N_A);
    }

    @Test
    public void getCustomerNameWithCompany(){
        GlobalBarterInterventorCompany company = new GlobalBarterInterventorCompany();
        when(userDecorator.getInterventorCompany()).thenReturn(company);
        Vendor vendor = mock(Vendor.class);
        when(vendor.getName()).thenReturn(HECTOR_SRL);
        when(vendorService.getVendor(anyString())).thenReturn(vendor);

        String result = principalFaces.getCustomerCompany();

        assertThat(result).isEqualTo(HECTOR_SRL);
    }

    @Test
    public void exit(){
        String result = principalFaces.exit();

        assertThat(result).isEqualTo(SUCCESS);
    }

    @Test
    public void getUserRole(){
        when(userDecorator.getType()).thenReturn(UserTypeEnum.ADMINISTRATOR);

        String result = principalFaces.getUserRole();

        assertThat(result).isEqualTo(UserTypeEnum.ADMINISTRATOR.toString());
    }

    @Test
    public void getUserFullName(){
        when(userDecorator.getName()).thenReturn(HECTOR);
        when(userDecorator.getLastName()).thenReturn(NEIRA);

        String result = principalFaces.getUserFullName();

        assertThat(result).isEqualTo(HECTOR + " " + NEIRA);
    }

    @Test
    public void getCSSPath(){
        when(userDecorator.getName()).thenReturn(HECTOR);
        when(userDecorator.getLastName()).thenReturn(NEIRA);
        ExternalContext externalContext = mock(ExternalContext.class);
        when(externalContext.getRequestContextPath()).thenReturn(RULES);
        when(facesContext.getExternalContext()).thenReturn(externalContext);

        String result = principalFaces.getCSSPath();

        assertThat(result).isEqualTo(HECTOR_S_CSS + RULES);
    }

}
