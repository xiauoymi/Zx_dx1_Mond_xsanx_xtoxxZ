package com.monsanto.barter.ar.web.faces.beans.pointOfSale;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.PointOfSaleFilter;
import com.monsanto.barter.ar.business.service.PointOfSaleService;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.BeanFactory;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.junit.Assert.assertEquals;

import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by VNBARR on 9/8/2014.
 */
public class PointOfSaleSearchFormBean_UT {

    public static final String SUCCESS = "success";
    private PointOfSaleSearchFormBean pointOfSaleSearchBean;
    @Mock
    private BeanFactory beanFactoryMock;
    private List<String> messages;
    @Mock
    private PointOfSaleService pointOfSaleService;

    @Mock
    private PointOfSale pointOfSale;

    @Before
    public void setUp() {
        initMocks(this);

        messages = new ArrayList<String>();

        pointOfSaleSearchBean = new PointOfSaleSearchFormBean(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }


        };
        when(beanFactoryMock.getBean(PointOfSaleService.class)).thenReturn(pointOfSaleService);
    }

    @Test
    public void testClassInstance() {
        pointOfSaleSearchBean = new PointOfSaleSearchFormBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(pointOfSaleSearchBean);
    }

    @Test
    public void beginSetupsFields() {
        String navigation = pointOfSaleSearchBean.begin();
        assertNotNull(pointOfSaleSearchBean.getPointOfSaleFilter());
        assertEquals("success", navigation);
    }

    @Test
    public void searchWithResults(){
        pointOfSaleSearchBean.begin();
        pointOfSaleSearchBean.setPointOfSaleFilter(new PointOfSaleFilter("","",null));
        String navigation = pointOfSaleSearchBean.search();
        assertNotNull(pointOfSaleSearchBean.getSearchResult());
        assertEquals(SUCCESS, navigation);
    }

    @Test
    public void clearSetsFieldsToNull(){
        pointOfSaleSearchBean.begin();
        String navigation = pointOfSaleSearchBean.clear();
        assertEquals("success",navigation);
        assertNull(pointOfSaleSearchBean.getSearchResult());
    }

    @Test
    public void setNotNullStatus(){
        pointOfSaleSearchBean.setPointOfSaleFilter(new PointOfSaleFilter());
        pointOfSaleSearchBean.setStatus(0);
        assertEquals(StatusEnum.INACTIVE,pointOfSaleSearchBean.getPointOfSaleFilter().getStatus());
    }

}
