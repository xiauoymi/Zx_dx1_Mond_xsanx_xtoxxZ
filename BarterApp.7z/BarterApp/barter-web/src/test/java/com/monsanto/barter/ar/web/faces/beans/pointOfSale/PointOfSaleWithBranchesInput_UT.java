package com.monsanto.barter.ar.web.faces.beans.pointOfSale;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.CustomerLas;
import com.monsanto.barter.ar.business.entity.PointOfSale;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.service.PointOfSaleService;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.PointOfSaleCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.component.row.Row;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import javax.faces.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by VNBARR on 9/11/2014.
 */
public class PointOfSaleWithBranchesInput_UT {

    private static final String BUENOS_AIRES = "BUENOS AIRES";
    private static final String SUCCESS = "success";
    private PointOfSaleWithBranchesInput pointOfSaleWithBranchesInput;
    @Mock
    private BeanFactory beanFactoryMock;
    private List<String> messages;
    @Mock
    private PointOfSaleService pointOfSaleService;
    @Mock
    private PointOfSaleCC pointOfSaleCCMock;
    @Mock
    private PointOfSale pointOfSale;
    @Mock
    private PointOfSale parentPointOfSale;
    @Mock
    private CustomerLas customerLas;
    @Mock
    private CustomerCC customerCCMock;
    @Mock
    private ActionEvent actionEvent;
    @Mock
    private javax.faces.component.UIComponent row;
    @Mock
    private BeanValidator<PointOfSale> beanValidator;

    @Before
    public void setUp() {
        initMocks(this);

        messages = new ArrayList<String>();

        pointOfSaleWithBranchesInput = new PointOfSaleWithBranchesInput(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }


        };
        when(beanFactoryMock.getBean(PointOfSaleService.class)).thenReturn(pointOfSaleService);
        when(beanFactoryMock.getBean(PointOfSaleCC.class)).thenReturn(pointOfSaleCCMock);
        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCCMock);
        ReflectionTestUtils.setField(pointOfSaleWithBranchesInput,"pointOfSaleCC",pointOfSaleCCMock);
        ReflectionTestUtils.setField(pointOfSaleWithBranchesInput,"pointOfSaleService",pointOfSaleService);
        ReflectionTestUtils.setField(pointOfSaleWithBranchesInput,"customerCC",customerCCMock);
        ReflectionTestUtils.setField(pointOfSaleCCMock,"customerCC",customerCCMock);
        ReflectionTestUtils.setField(pointOfSaleWithBranchesInput,"beanValidator",beanValidator);
        when(customerLas.getDescription()).thenReturn("MONSANTO");
    }

    @Test
    public void testInstance(){
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new PointOfSaleWithBranchesInput());
    }

    @Test
    public void beginInitalizesFields(){
        pointOfSaleWithBranchesInput.begin();
        assertFalse(pointOfSaleWithBranchesInput.isReadOnly());
        assertNull(pointOfSaleWithBranchesInput.getCustomerCC().getCustomer());
        assertNull(pointOfSaleWithBranchesInput.getParentPointOfSaleId());
    }

    @Test
    public void clearSetsFieldsToNull(){
        pointOfSaleWithBranchesInput.clear();
        assertNull(pointOfSaleWithBranchesInput.getBranches());

    }

    @Test
    public void getCustomerCityReturnsRightCityWhenCustomerSelected(){
        when(customerLas.getCity()).thenReturn(BUENOS_AIRES);
        when(customerCCMock.getSelectedCustomer()).thenReturn(customerLas);
        assertEquals(BUENOS_AIRES, pointOfSaleWithBranchesInput.getCustomerCity());
    }

    @Test
    public void getCustomerCityReturnsEmptyWhenNoCustomerSelected(){
        when(customerCCMock.getSelectedCustomer()).thenReturn(null);
        assertEquals("", pointOfSaleWithBranchesInput.getCustomerCity());
    }

    @Test
    public void cancelSetsFieldsToNull(){
        String result = pointOfSaleWithBranchesInput.cancel();
        assertNull(pointOfSaleWithBranchesInput.getBranches());

        assertEquals(SUCCESS,result);
    }

    @Test
    public void posIsActive(){
        pointOfSaleWithBranchesInput.setParentPointOfSale(pointOfSale);
        when(pointOfSale.getStatus()).thenReturn(StatusEnum.ACTIVE);
        assertTrue(pointOfSaleWithBranchesInput.isActivePOS());
    }

    @Test
    public void posIsInactive(){
        pointOfSaleWithBranchesInput.setParentPointOfSale(pointOfSale);
        when(pointOfSale.getStatus()).thenReturn(StatusEnum.INACTIVE);
        assertFalse(pointOfSaleWithBranchesInput.isActivePOS());
    }

    @Test
    public void viewPointOfSaleWithoutErrors(){
        String navigation = pointOfSaleWithBranchesInput.viewPointOfSale();
        assertEquals(SUCCESS,navigation);
        assertTrue(pointOfSaleWithBranchesInput.isReadOnly());
    }

   @Test
    public void editPointOfSaleWithoutErrors(){
       String navigation = pointOfSaleWithBranchesInput.editPointOfSale();
       assertEquals(SUCCESS,navigation);
       assertFalse(pointOfSaleWithBranchesInput.isReadOnly());
    }

    @Test
    public void editPointOfSaleWithErrorLoadingBranches(){
        when(pointOfSaleService.searchBranchesByParent(parentPointOfSale)).thenThrow(new BusinessException("error"));
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        pointOfSaleWithBranchesInput.editPointOfSale();
        assertTrue(messages.contains("label.input.pointOfSale.loadBranches.error"));
    }

    @Test
    public void selectBranchEventSetsCorrectPos(){
        HashMap<String, Object> attributesMap = new HashMap<String, Object>();
        attributesMap.put("branch",pointOfSale);
        when(actionEvent.getComponent()).thenReturn(row);
        when(row.getAttributes()).thenReturn(attributesMap);
        pointOfSaleWithBranchesInput.selectBranch(actionEvent);
        assertEquals(pointOfSale,pointOfSaleWithBranchesInput.getSelectedBranchPointOfSale());
    }

    @Test
    public void preSaveWithNoErrors(){
        List<String> validationMessages = new ArrayList<String>();
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        when(beanValidator.validate(parentPointOfSale)).thenReturn(validationMessages);
        pointOfSaleWithBranchesInput.preSave();
        assertTrue(messages.isEmpty());
    }


    @Test
    public void preSaveWithErrors(){
        List<String> validationMessages = new ArrayList<String>();
        validationMessages.add("error1");
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        when(beanValidator.validate(parentPointOfSale)).thenReturn(validationMessages);
        pointOfSaleWithBranchesInput.preSave();
        assertTrue(messages.contains("error1"));
    }



    @Test
    public void saveNewPointOfSaleWithNoErrors(){
        when(parentPointOfSale.getId()).thenReturn(null);
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        when(parentPointOfSale.getCustomer()).thenReturn(customerLas);
        pointOfSaleWithBranchesInput.save();
        verify(pointOfSaleService).save(parentPointOfSale);
        assertTrue(messages.contains(("label.input.pointOfSale.creation.ok") + parentPointOfSale.getCustomer().getDescription()));
    }

    @Test
    public void editPointOfSaleWithNoErrors(){
        when(parentPointOfSale.getId()).thenReturn(1L);
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        when(parentPointOfSale.getCustomer()).thenReturn(customerLas);
        pointOfSaleWithBranchesInput.save();
        verify(pointOfSaleService).update(parentPointOfSale);
        assertTrue(messages.contains(("label.input.pointOfSale.update.ok") + parentPointOfSale.getCustomer().getDescription()));
    }

    @Test
    public void whenSaveThrowsExceptionItAddsError(){
        when(parentPointOfSale.getId()).thenReturn(null);
        when(parentPointOfSale.getCustomer()).thenReturn(customerLas);
        pointOfSaleWithBranchesInput.setParentPointOfSale(parentPointOfSale);
        when(pointOfSaleService.save(parentPointOfSale)).thenThrow(new BusinessException("error"));
        pointOfSaleWithBranchesInput.save();
        assertTrue(messages.contains(("label.input.pointOfSale.creation.error") + parentPointOfSale.getCustomer().getDescription()));
    }

    @Test
    public void activePointOfSale(){
        PointOfSale point = new PointOfSale();
        pointOfSaleWithBranchesInput.setParentPointOfSale(point);
        pointOfSaleWithBranchesInput.setActivePOS(true);
        assertEquals(StatusEnum.ACTIVE,point.getStatus());
    }

    @Test
    public void inactivePointOfSale(){
        PointOfSale point = new PointOfSale();
        pointOfSaleWithBranchesInput.setParentPointOfSale(point);
        pointOfSaleWithBranchesInput.setActivePOS(false);
        assertEquals(StatusEnum.INACTIVE,point.getStatus());
    }

}
