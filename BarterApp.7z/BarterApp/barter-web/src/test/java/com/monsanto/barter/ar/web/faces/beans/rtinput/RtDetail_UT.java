package com.monsanto.barter.ar.web.faces.beans.rtinput;


import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.architecture.business.exception.RemoteServiceException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.entity.enumerated.ParticipantType;
import com.monsanto.barter.ar.business.entity.enumerated.UserTypeEnum;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.RemoteServiceResponse;
import com.monsanto.barter.ar.web.faces.beans.growerdocuments.composite.GrowerDocumentsCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorySectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtInitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtTransferSectionCC;
import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.regionalization.CountryHolder;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.primefaces.context.RequestContext;
import org.primefaces.model.StreamedContent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.ReflectionTestUtils.setField;

public class RtDetail_UT {

    public static final String EXCEPTHROW_MESSAGE = "excepthrow";
    @Mock
    private UserDecorator user;

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private RequestContext requestContext;

    @Mock
    private FacesContext context;

    @Mock
    private BeanValidator beanvalidator;

    @Mock
    private GrainTransferService grainTransferService;

    @Mock
    private RtSearchFormFacesBean rtSearchFormFacesBean;

    @Mock
    private RemoteService remoteService;

    @Mock
    private RspVatService rspVatService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;

    @Mock
    private EmailService emailService;

    private TransactionTemplateMocker transactionTemplate;

    private GrainTransfer grainTransfer;

    List<String> messages;

    private static final String SUCCESS = "success";
    @Mock
    private GrowerDocumentsCC growerDocumentsCC;

    public class RtDetailForTest extends RtDetail {
        @Override
        protected FacesContext getFacesContext() {
            return context;
        }

        @Override
        public BeanFactory getBeanFactory() {
            return beanFactoryMock;
        }

        @Override
        protected RequestContext getRequestContext() {
            return requestContext;
        }

        @Override
        protected BeanValidator getValidator() {
            return beanvalidator;
        }

        @Override
        protected void addMessageNoError(String message){
            messages.add(message);
        }

        @Override
        protected void addMessage(String message){
            messages.add(message);
        }

        @Override @SuppressWarnings("unchecked")
        public <T> T getFacesBean(String beanId, Class<T> requiredType) {
            return (T) rtSearchFormFacesBean;
        }

        @Override
        public TransactionTemplate getTransactionTemplate() {
            return transactionTemplate;
        }

        @Override
        public String getMessageBundle(String key) {
            return key;
        }

        @Override
        public UserDecorator getLoggedUser() {
            return user;
        }
    }

    private RtDetailForTest rtDetailForTest;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        transactionTemplate = new TransactionTemplateMocker();
        rtDetailForTest = new RtDetailForTest();
        grainTransfer = createValidGrainTransfer();
        messages = new ArrayList<String>();
        rspVatService =  mock(RspVatService.class);

        //Services for loading info inside sections
        List<RspVat> rspList = new LinkedList<RspVat>();
        RspVat mockRspVat = mock(RspVat.class);
        when(mockRspVat.getId()).thenReturn("keyRsp1");
        when(mockRspVat.getPrimaryKey()).thenReturn("keyRsp1");
        rspList.add(mockRspVat);
        when(rspVatService.findAll()).thenReturn(rspList);

        createSections();

        when(beanFactoryMock.getBean(GrainTransferService.class)).thenReturn(grainTransferService);
        when(beanFactoryMock.getBean(RemoteService.class)).thenReturn(remoteService);
        when(beanFactoryMock.getBean(UnsuccessfulRemoteInvocationService.class))
                .thenReturn(unsuccessfulInvocationService);
        when(beanFactoryMock.getBean(EmailService.class)).thenReturn(emailService);
        when(beanFactoryMock.getBean(GrowerDocumentsCC.class)).thenReturn(growerDocumentsCC);


        when(grainTransferService.get(anyLong())).thenReturn(grainTransfer);
        setField(rtDetailForTest, "unsuccessfulInvocationService", unsuccessfulInvocationService);
        setField(rtDetailForTest, "remoteService", remoteService);
        setField(rtDetailForTest, "rtService", grainTransferService);
        setField(rtDetailForTest, "emailService", emailService);

        rtDetailForTest.setIdEntity(1L);
        rtDetailForTest.setEntity(grainTransfer);
    }

    private void createSections() {
        RtInitialDataSectionCC rtInitialDataSectionCC =  new RtInitialDataSectionCC();
        DepositorySectionCC depositorySectionCC = new DepositorySectionCC();
        depositorySectionCC.setDepLocation(new LocationCC());
        depositorySectionCC.setRspVatService(rspVatService);

        DepositorSectionCC depositorSectionCC = new DepositorSectionCC();
        depositorSectionCC.setDepositorCC(new CustomerCC());
        depositorSectionCC.setDepositorCity(new LocationCC());
        depositorSectionCC.setRspVatService(rspVatService);

        RtTransferSectionCC rtTransferSectionCC = new RtTransferSectionCC();
        rtTransferSectionCC.setReceptorCC(new CustomerCC());
        rtTransferSectionCC.setReceptorCity(new LocationCC());

        ArrayList<MaterialLas> materialLasList = new ArrayList<MaterialLas>();
        materialLasList.add(new MaterialLas());
        rtTransferSectionCC.setMaterialLasList(materialLasList);
        rtTransferSectionCC.setIdMaterialLas(null);
        //Services for loading info inside sections
        rtTransferSectionCC.setMaterialLasService(materialLasService);
        rtTransferSectionCC.setRspVatService(rspVatService);

        MaterialLasService materialLasService = mock(MaterialLasService.class);
        beanFactoryMock = mock(BeanFactory.class);
        when(materialLasService.findAll()).thenReturn(new ArrayList<MaterialLas>());
        when(beanFactoryMock.getBean(RtInitialDataSectionCC.class)).thenReturn(rtInitialDataSectionCC);
        when(beanFactoryMock.getBean(DepositorySectionCC.class)).thenReturn(depositorySectionCC);
        when(beanFactoryMock.getBean(DepositorSectionCC.class)).thenReturn(depositorSectionCC);
        when(beanFactoryMock.getBean(RtTransferSectionCC.class)).thenReturn(rtTransferSectionCC);
    }

    private GrainTransfer createValidGrainTransfer() {
        Date generationDate = new GregorianCalendar().getTime();
        RspVat depositaryRspVat = new RspVat();

        CityAfipLas city = Mockito.mock(CityAfipLas.class);
        Mockito.when(city.getDescription()).thenReturn("GENERAL ARENALES");
        Mockito.when(city.getId()).thenReturn("6357");
        Mockito.when(city.getCountyAfipLas()).thenReturn(null);

        CustomerLas depositor = Mockito.mock(CustomerLas.class);
        Mockito.when(depositor.getDocument()).thenReturn("20-28951789-6");
        Mockito.when(depositor.getDescription()).thenReturn("ACA");

        CustomerLas receptor = Mockito.mock(CustomerLas.class);
        Mockito.when(receptor.getDocument()).thenReturn("20-28951789-6");
        Mockito.when(receptor.getDescription()).thenReturn("ACA");

        MaterialLas cropType = Mockito.mock(MaterialLas.class);
        Mockito.when(cropType.getDescription()).thenReturn("Soja");

        return new GrainTransfer("989", new BigDecimal("243"), generationDate, generationDate, 1L, "20-28951789-6",
                "depositaryName", "depositaryActivity",depositaryRspVat, "depositaryAddress", city, 1L,1L, depositor,
                depositaryRspVat, "depositorAddress", city, receptor, depositaryRspVat,  "receptorActivity",
                "receptorAddress",city, 1L, generationDate, "1123", cropType, 321L, 243L);
    }

    @Test
    public void testEditAction(){
        when(remoteService.getDocumentStatus(DocumentType.RT, grainTransfer.getNumber())).thenReturn(new RemoteServiceResponse("200", Arrays.asList("OK")));
        rtDetailForTest.edit();
        assertEquals(rtDetailForTest.getMode(), Mode.UPDATE);
    }

    @Test
    public void  testCancelAction(){
        assertEquals(rtDetailForTest.cancel(), SUCCESS);
    }

    @Test
    public void testBackAction() {
        assertEquals(rtDetailForTest.back(), SUCCESS);
    }

    @Test
    public void testViewAction() {
        assertEquals(rtDetailForTest.view(), SUCCESS);
    }

    @Test
    public void testClassInstance() {
        RtDetail rtDetail = new RtDetail();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(rtDetail);
    }

    @Test
    public void testSave(){
        when(remoteService.getDocumentStatus(DocumentType.RT, grainTransfer.getIdSap()))
                .thenReturn(new RemoteServiceResponse("200", asList("OK")));
        grainTransfer.setSentToSAP();
        String navigation = rtDetailForTest.save();
        verify(grainTransferService).update(grainTransfer);
        verify(remoteService).update(grainTransfer);
        assertTrue(messages.contains("Se ha actualizado correctamente la RT."));
        assertTrue(messages.size() == 1);
        assertTrue(navigation.equals(SUCCESS));
    }

    @Test
    public void testSaveWithoutSentToSap(){
        String navigation = rtDetailForTest.save();
        verify(grainTransferService).update(grainTransfer);
        verify(remoteService).create(grainTransfer);
        assertTrue(messages.contains("Se ha actualizado correctamente la RT."));
        assertTrue(messages.size() == 1);
        assertTrue(navigation.equals(SUCCESS));
    }

    @Test
    public void testSaveWithErrors(){
        String testEmail = "no.reply@monsanto.com";
        when(user.getEmail()).thenReturn(testEmail);
        String navigation = rtDetailForTest.saveWithErrors();
        verify(grainTransferService).update(grainTransfer);
        verify(emailService).sendRetryStartMessage(anyString(), anyList(), eq(testEmail));
        assertTrue(messages.contains("Se ha actualizado correctamente la RT."));
        assertTrue(messages.size() == 1);
        assertTrue(navigation.equals(SUCCESS));
    }

    @Test
    public void testFailedSaveWithBusinessException(){
        doThrow(new BusinessException(EXCEPTHROW_MESSAGE)).when(grainTransferService).update(grainTransfer);
        String navigation = rtDetailForTest.save();
        Assert.assertNull(navigation);
    }

    @Test
    public void testFailedSaveWithErrorsWithBusinessException(){
        doThrow(new BusinessException(EXCEPTHROW_MESSAGE)).when(grainTransferService).update(grainTransfer);
        String navigation = rtDetailForTest.saveWithErrors();
        Assert.assertNull(navigation);
    }

    @Test
    public void testFailedSaveWithSAPFailure(){
        grainTransfer.setSentToSAP();
        when(remoteService.getDocumentStatus(DocumentType.RT, grainTransfer.getIdSap()))
                .thenReturn(new RemoteServiceResponse("200", asList("OK")));
        doThrow(new RemoteServiceException(EXCEPTHROW_MESSAGE)).when(remoteService).update(grainTransfer);
        assertEquals(rtDetailForTest.save(), null);
        assertThat(rtDetailForTest.getSapMessages().size(), is(1));
        verify(grainTransferService).update(grainTransfer);
        verify(unsuccessfulInvocationService).clearPendingInvocations(grainTransfer);
    }

    @Test
    public void generatePdfThrowsAbortProcessingExceptionWhenPdfGenerationFails(){
        BusinessException error = new BusinessException("something went wrong");
        when(grainTransferService.getPdf(rtDetailForTest.getIdEntity())).thenThrow(error);
        try{
            rtDetailForTest.generatePdf();
            fail();
        } catch (AbortProcessingException e){
            assertEquals(e.getCause(), error);
        }
    }


    @Test
    public void generatePdf(){
        Country country = Country.ARGENTINA;
        CountryHolder countryHolder = mock(CountryHolder.class);
        when(countryHolder.getCountry()).thenReturn(country);
        when(beanFactoryMock.getBean(CountryHolder.class)).thenReturn(countryHolder);
        try{
            rtDetailForTest.generatePdf();
        } catch (AbortProcessingException e){
            fail();
            e.printStackTrace();
        }
    }

    @Test
    public void testGetFile(){
        StreamedContent a = rtDetailForTest.getFile();
        assertNotNull(a);
    }

    @Test
    public void userWithoutPermissionsCantSeeGrowerDocuments(){
        rtDetailForTest.view();
        UserDecorator user = (UserDecorator) ReflectionTestUtils.getField(rtDetailForTest,"user");
        user.getCurrentUser().setParticipantType(ParticipantType.AGENT);
        assertFalse(rtDetailForTest.isGrowerPortalDocumentEnable());
    }

    @Test
    public void growerUserProfileCanSeeGrowerDocuments(){
        rtDetailForTest.view();
        UserDecorator user = (UserDecorator) ReflectionTestUtils.getField(rtDetailForTest,"user");
        user.getCurrentUser().setParticipantType(ParticipantType.GROWER);
        user.getCurrentUser().setType(UserTypeEnum.PARTICIPANT);
        assertTrue(rtDetailForTest.isGrowerPortalDocumentEnable());
    }
}
