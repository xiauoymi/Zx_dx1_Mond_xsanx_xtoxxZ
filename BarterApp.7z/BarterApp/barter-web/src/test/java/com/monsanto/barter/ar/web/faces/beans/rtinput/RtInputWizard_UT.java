package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.wizard.WizardStep;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.DepositorySectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtInitialDataSectionCC;
import com.monsanto.barter.ar.web.faces.beans.rtinput.composite.RtTransferSectionCC;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@SuppressWarnings("unchecked")
public class RtInputWizard_UT {
    private RtInputWizard wizard;
    private List<String> messages;

    @Mock
    private FacesContext context;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private RequestContext requestContextMock;
    @Mock
    private HttpServletResponse response;
    @Mock
    private UserDecorator user;

    @Mock
    private RtInitialDataSectionCC rtInitialDataSectionCC;
    @Mock
    private DepositorySectionCC depositorySectionCC;
    @Mock
    private DepositorSectionCC depositorSectionCC;
    @Mock
    private RtTransferSectionCC rtTransferSectionCC;
    @Mock
    private BeanValidator beanValidator;
    @Mock(extraInterfaces = DocumentUploadService.class)
    private GrainTransferService grainTransferService;
    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    @Mock
    private EmailService emailService;
    @Mock
    private GrainTransfer rtInput;
    @Mock
    private RemoteService remoteService;

    private TransactionTemplateMocker transactionTemplate;

    @Before
    public void setUp() {
        initMocks(this);

        messages = new LinkedList<String>();

        transactionTemplate = new TransactionTemplateMocker();

        wizard = new RtInputWizard () {
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected RtInputWizard getNewRtInputWizard() {
                return this;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }

            @Override
            public String getMessageBundle(String key) {
                return key;
            }

            public TransactionTemplate getTransactionTemplate() {
                return transactionTemplate;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected BeanValidator getValidator() {
                return beanValidator;
            }

            @Override
            public UserDecorator getLoggedUser() {
                return user;
            }
        };

        setField(wizard, "rtService", grainTransferService);
        setField(wizard, "rtInput", rtInput);
        setField(wizard, "remoteService", remoteService);
        setField(wizard, "unsuccessfulInvocationService", unsuccessfulInvocationService);
        setField(wizard, "emailService", emailService);

        setField(wizard, "beanValidator", beanValidator);
        setField(wizard, "documentsUploader", new DocumentsUploader<GrainTransfer>());
    }

    @Test
    public void begin() {
        int rtInitialDataStepIndex = 1;
        int depositoryStepIndex = 2;
        int depositorStepIndex = 3;
        int rtTransferStepIndex = 0;

        String rtInitialDataStepKey = "rtInitialDataSectionCC";
        String depositoryStepKey = "depositorySectionCC";
        String depositorStepKey = "depositorSectionCC";
        String rtTransferStepKey = "rtTransferSectionCC";

        when(beanFactoryMock.getBean(RtInitialDataSectionCC.class)).thenReturn(rtInitialDataSectionCC);
        when(beanFactoryMock.getBean(DepositorySectionCC.class)).thenReturn(depositorySectionCC);
        when(beanFactoryMock.getBean(DepositorSectionCC.class)).thenReturn(depositorSectionCC);
        when(beanFactoryMock.getBean(RtTransferSectionCC.class)).thenReturn(rtTransferSectionCC);

        when(rtInitialDataSectionCC.initializeStepCC(eq(rtInitialDataStepIndex), eq(rtInitialDataStepKey), any(GrainTransfer.class), eq(Mode.CREATE)))
                .thenReturn(rtInitialDataSectionCC);
        when(depositorySectionCC.initializeStepCC(eq(depositoryStepIndex), eq(depositoryStepKey), any(GrainTransfer.class), eq(Mode.CREATE)))
                .thenReturn(depositorySectionCC);
        when(depositorSectionCC.initializeStepCC(eq(depositorStepIndex), eq(depositorStepKey), any(GrainTransfer.class), eq(Mode.CREATE)))
                .thenReturn(depositorSectionCC);
        when(rtTransferSectionCC.initializeStepCC(eq(rtTransferStepIndex), eq(rtTransferStepKey), any(GrainTransfer.class), eq(Mode.CREATE)))
                .thenReturn(rtTransferSectionCC);

        when(rtInitialDataSectionCC.getKey()).thenReturn(rtInitialDataStepKey);
        when(depositorySectionCC.getKey()).thenReturn(depositoryStepKey);
        when(depositorSectionCC.getKey()).thenReturn(depositorStepKey);
        when(rtTransferSectionCC.getKey()).thenReturn(rtTransferStepKey);

        assertThat(wizard.begin(), is("success"));

        assertThat(wizard.getRtInitialDataSectionCC(), is(rtInitialDataSectionCC));
        assertThat(wizard.getDepositorySectionCC(), is(depositorySectionCC));
        assertThat(wizard.getDepositorSectionCC(), is(depositorSectionCC));
        assertThat(wizard.getRtTransferSectionCC(), is(rtTransferSectionCC));

        assertThat(wizard.getStepCount(), is(4));

        assertThat(wizard.getStep(rtInitialDataStepIndex), is((WizardStep)rtInitialDataSectionCC));
        assertThat(wizard.getStep(depositoryStepIndex), is((WizardStep)depositorySectionCC));
        assertThat(wizard.getStep(depositorStepIndex), is((WizardStep)depositorSectionCC));
        assertThat(wizard.getStep(rtTransferStepIndex), is((WizardStep)rtTransferSectionCC));

        assertThat(wizard.getStep(rtInitialDataStepKey), is((WizardStep)rtInitialDataSectionCC));
        assertThat(wizard.getStep(depositoryStepKey), is((WizardStep)depositorySectionCC));
        assertThat(wizard.getStep(depositorStepKey), is((WizardStep)depositorSectionCC));
        assertThat(wizard.getStep(rtTransferStepKey), is((WizardStep)rtTransferSectionCC));
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(wizard);
    }

    @Test
    public void testCancel() throws IOException {
        ExternalContext e = mock(ExternalContext.class);
        when(e.getApplicationMap()).thenReturn(new HashMap<String, Object>());
        when(context.getExternalContext()).thenReturn(e);

        String result = wizard.rtInputCancelAction();

        Assert.assertEquals("cancel", result);
    }

    @Test
    public void testSaveRtInput() {
        when(grainTransferService.save(rtInput)).thenReturn(rtInput);

        assertThat(wizard.saveRtInput(), is(""));

        verify(grainTransferService).save(rtInput);
    }

    @Test
    public void testSaveWithErrors() {
        String testEmail = "no.reply@monsanto.com";
        when(user.getEmail()).thenReturn(testEmail);
        when(grainTransferService.save(rtInput)).thenReturn(rtInput);
        assertThat(wizard.saveRtInputWithErrors(), is(""));
        verify(grainTransferService).save(rtInput);
        verify(unsuccessfulInvocationService).save(any(AddendaUnsuccessfulRemoteInvocation.class));
        verify(emailService).sendRetryStartMessage(anyString(), anyList(), eq(testEmail));
    }

    @Test
    public void saveAddInput_failure() {
        String errorMessage = "something went wrong";
        doThrow(new BusinessException(errorMessage)).when(grainTransferService).save(rtInput);

        assertThat(wizard.saveRtInput(), is(""));

        assertThat(messages.get(0), is(errorMessage));
    }
}