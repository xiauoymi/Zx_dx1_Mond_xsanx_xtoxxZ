package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.google.common.collect.Maps;
import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Adenda;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AddReportView;
import com.monsanto.barter.ar.business.service.dto.AddView;
import com.monsanto.barter.ar.business.service.dto.RtReportView;
import com.monsanto.barter.ar.web.faces.beans.addinput.AdendaReportFormFacesBean;
import com.monsanto.barter.ar.web.faces.beans.addinput.datamodel.AdendaReportDataModel;
import com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel.RtReportDataModel;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.primefaces.context.RequestContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static junit.framework.Assert.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created with IntelliJ IDEA.
 * User: LABAEZ
 * Date: 2/25/14
 * Time: 3:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class RtReportFormFacesBean_UT {

    RtReportFormFacesBean rtReportFormFacesBean;

    @Mock
    private ReportService reportService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    BeanFactory beanFactoryMock;

    @Mock
    RequestContext requestContextMock;

    @Mock
    private FacesContext context;

    @Mock
    private HttpServletResponse response;

    @Mock
    private GrainTransfer grainTransfer;

    @Mock
    private RtReportView rtReportView;

    @Mock
    private RtReportDataModel searchResult;

    List<String> messages;

    private MaterialLas materialLas;

    private List<MaterialLas> materialLasList;

    private long materialLasId = 1L;

   @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);


        materialLas = new MaterialLas();
        ReflectionTestUtils.setField(materialLas, "id", materialLasId);
        materialLasList = Arrays.asList(materialLas);
        messages = new ArrayList<String>();

       rtReportFormFacesBean = new RtReportFormFacesBean() {
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
              public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }
        };

        setField(rtReportFormFacesBean, "reportService", reportService);
    }


    @Test
    public void testClassInstance() {
        rtReportFormFacesBean = new RtReportFormFacesBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.setIgnoredFields("rtStates");
        tester.testInstance(rtReportFormFacesBean);
    }



   @Test
    public void testBegin() {
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);

        String navigation = rtReportFormFacesBean.begin();
        assertNotNull(rtReportFormFacesBean.getMaterialLasList());
        assertTrue(rtReportFormFacesBean.getMaterialLasList().size() == 1);
        assertEquals(RtReportFormFacesBean.PAGE_REPORT_FORM,navigation);
    }


    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        rtReportFormFacesBean.begin();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
    }



    @Test
    public void testClear(){
        RtReportFilter filter = new RtReportFilter();
        filter.setDescription("description");
        rtReportFormFacesBean.setFilter(filter);
        rtReportFormFacesBean.clear();
        assertFalse(("description").equals(rtReportFormFacesBean.getFilter().getDescription()));
    }


    @Test
    public void testDefaultSearch(){
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);

        rtReportFormFacesBean.begin();
        String navigation = rtReportFormFacesBean.report();
        assertTrue(rtReportFormFacesBean.getSearchResult().getRowCount() == 0);
        assertEquals(RtReportFormFacesBean.PAGE_REPORT_RESULT, navigation);
    }



    @Test
    public void testSearchInvalidDates(){
        when(beanFactoryMock.getBean(ReportService.class)).thenReturn(reportService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        rtReportFormFacesBean.begin();
        Date date = getDateWithoutTime();
        rtReportFormFacesBean.getFilter().setGenerationDateFrom(date);
        rtReportFormFacesBean.getFilter().setGenerationDateTo(DateUtils.addWeeks(date, -2));

        String navigation = rtReportFormFacesBean.report();
        assertEquals(rtReportFormFacesBean.getSearchResult(),null);
        assertEquals(null, navigation);
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains("label.search.error.dateError"), is(true));
    }


    @Test
    public void postProcessXLS() {
        RtReportFilter filter = new RtReportFilter();
        HSSFWorkbook document = buildWorkbook();

        when(searchResult.getRowCount()).thenReturn(3);
        rtReportFormFacesBean.setSearchResult(searchResult);
        rtReportFormFacesBean.setFilter(filter);
        rtReportFormFacesBean.postProcessXLS(document);
    }


    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 13; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }



    private Date getDateWithoutTime() {
        Date date = new Date();
        date = DateUtils.setHours(date,0);
        date = DateUtils.setMinutes(date,0);
        date = DateUtils.setSeconds(date,0);
        date = DateUtils.setMilliseconds(date,0);
        return date;
    }
}
