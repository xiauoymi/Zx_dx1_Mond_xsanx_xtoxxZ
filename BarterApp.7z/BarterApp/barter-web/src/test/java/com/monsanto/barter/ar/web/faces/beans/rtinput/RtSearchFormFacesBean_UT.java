package com.monsanto.barter.ar.web.faces.beans.rtinput;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.Attachment;
import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.AttachmentView;
import com.monsanto.barter.ar.business.service.dto.RtView;
import com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel.RtDataModel;
import com.monsanto.barter.ar.web.faces.composite.DocumentsUploader;
import com.monsanto.barter.ar.web.faces.composite.FileUploadCC;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import junit.framework.Assert;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.primefaces.context.RequestContext;
import org.primefaces.event.ToggleEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.transaction.support.TransactionTemplate;

import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static java.util.Arrays.asList;
import static junit.framework.Assert.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author LABAEZ
 */
public class RtSearchFormFacesBean_UT {

    RtSearchFormFacesBean rtSearchFormFacesBean;

    @Mock(extraInterfaces = DocumentUploadService.class)
    private GrainTransferService grainTransferService;
    @Mock
    private MaterialLasService materialLasService;
    @Mock
    private RemoteService remoteService;
    @Mock
    private BeanFactory beanFactoryMock;
    @Mock
    private RequestContext requestContextMock;
    @Mock
    private FacesContext context;
    @Mock
    private AttachmentService attachmentService;
    @Mock
    private UnsuccessfulRemoteInvocationService unsuccessfulInvocationService;
    @Mock
    private HttpServletResponse response;
    @Mock
    private FileUploadCC fileUploadHandler;
    @Mock
    private RtView rtView;
    @Mock
    private GrainTransfer grainTransferInput;
    @Mock
    private RtDataModel searchResult;

    @Mock
    private BeanValidator beanValidator;

    private TransactionTemplateMocker transactionTemplate;

    private List<String> messages;

    private List<MaterialLas> materialLasList;

    @Before
    public void setUp() {
        initMocks(this);

        transactionTemplate = new TransactionTemplateMocker();
        MaterialLas materialLas = new MaterialLas();
        setField(materialLas, "id", 1L);
        materialLasList = asList(materialLas);
        messages = new ArrayList<String>();

        rtSearchFormFacesBean = new RtSearchFormFacesBean() {
            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected RequestContext getRequestContext() {
                return requestContextMock;
            }

            @Override
            protected FacesContext getFacesContext() {
                return context;
            }

            @Override
            public String getMessageBundle(String key){
               return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected HttpServletResponse getResponse() {
                return response;
            }

            @Override
            public TransactionTemplate getTransactionTemplate() {
                return transactionTemplate;
            }
        };

        when(beanFactoryMock.getBean(GrainTransferService.class)).thenReturn(grainTransferService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(RemoteService.class)).thenReturn(remoteService);
        when(beanFactoryMock.getBean(UnsuccessfulRemoteInvocationService.class)).thenReturn(unsuccessfulInvocationService);

        setField(rtSearchFormFacesBean, "rtView", rtView);
        setField(rtSearchFormFacesBean, "attachmentService", attachmentService);
        setField(rtSearchFormFacesBean, "grainTransferService", grainTransferService);
        setField(rtSearchFormFacesBean, "remoteService", remoteService);
        setField(rtSearchFormFacesBean, "unsuccessfulInvocationService", unsuccessfulInvocationService);
        setField(rtSearchFormFacesBean, "beanValidator", beanValidator);
        setField(rtSearchFormFacesBean, "documentsUploader", new DocumentsUploader<GrainTransfer>());
        setField(rtSearchFormFacesBean, "searchResult", searchResult);
    }

    @Test
    public void testClassInstance() {
        rtSearchFormFacesBean = new RtSearchFormFacesBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(rtSearchFormFacesBean);
    }

    @Test
    public void testBegin() {
        when(materialLasService.findAll()).thenReturn(materialLasList);
        String navigation = rtSearchFormFacesBean.begin();
        assertNotNull(rtSearchFormFacesBean.getMaterialLasList());
        assertTrue(rtSearchFormFacesBean.getMaterialLasList().size() == 1);
        assertEquals(RtSearchFormFacesBean.PAGE_SEARCH_FORM, navigation);
    }

    @Test
    public void testBeginFailLoadCombos() {
        String error = "error";
        doThrow(new BusinessException(error)).when(materialLasService).findAll();

        rtSearchFormFacesBean.begin();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
    }

    @Test
    public void testClear(){
        RtFilter filter = new RtFilter();
        filter.setDescription("description");
        rtSearchFormFacesBean.setFilter(filter);
        rtSearchFormFacesBean.clear();
        assertFalse(("description").equals(rtSearchFormFacesBean.getFilter().getDescription()));
    }

    @Test
    public void testDefaultSearch(){
        when(materialLasService.findAll()).thenReturn(materialLasList);

        rtSearchFormFacesBean.begin();
        String navigation = rtSearchFormFacesBean.search();
        assertTrue(rtSearchFormFacesBean.getSearchResult() != null);
        assertEquals(RtSearchFormFacesBean.PAGE_SEARCH_RESULT, navigation);
    }

    @Test
    public void testSearchInvalidDates(){
        when(materialLasService.findAll()).thenReturn(materialLasList);
        rtSearchFormFacesBean.begin();
        Date date = getDateWithoutTime();
        rtSearchFormFacesBean.getFilter().setGenerationDateFrom(date);
        rtSearchFormFacesBean.getFilter().setGenerationDateTo(DateUtils.addWeeks(date, -2));

        String navigation = rtSearchFormFacesBean.search();
        assertEquals(null, navigation);
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains("label.search.error.dateError"), is(true));
    }

    @Test
    public void testDelete(){
        GrainTransfer grainTransfer = new GrainTransfer();

        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(grainTransferService.get(1L)).thenReturn(grainTransfer);

        RtView view = new RtView(1L, "564", new Date(), "Soja", null, null);

        rtSearchFormFacesBean.begin();
        rtSearchFormFacesBean.setRtView(view);
        rtSearchFormFacesBean.deleteGrainTransfer();

        verify(grainTransferService).delete(grainTransfer);
        verify(unsuccessfulInvocationService).clearPendingInvocations(grainTransfer);
        verify(remoteService).delete(grainTransfer);
    }

    @Test
    public void testDeleteFailure(){
        String error = "error";
        GrainTransfer grainTransfer = new GrainTransfer();

        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(grainTransferService.get(1L)).thenReturn(grainTransfer);

        RtView view = new RtView(1L, "564", new Date(), "Soja", null, null);
        doThrow(new BusinessException(error)).when(grainTransferService).delete(grainTransfer);

        rtSearchFormFacesBean.begin();
        rtSearchFormFacesBean.setRtView(view);
        rtSearchFormFacesBean.deleteGrainTransfer();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
    }

    @Test
    public void downloadFile() throws Exception {
        Long attachmentId = 1L;
        GrainTransfer grainTransfer = new GrainTransfer();
        String mimeType = "application/octet-stream";
        String fileName = "file.zzz";
        byte[] fileContents = new byte[]{'a', 'b', 'c', 'd'};
        File file = new File(fileName, mimeType, 4L, fileContents);

        Attachment attachment = new Attachment(file,"234", DocumentType.ADD);
        ServletOutputStream outputStream = mock(ServletOutputStream.class);

        rtSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        when(attachmentService.get(attachmentId)).thenReturn(attachment);
        when(grainTransferService.get(1L)).thenReturn(grainTransfer);
        when(response.getOutputStream()).thenReturn(outputStream);

        rtSearchFormFacesBean.downloadFile();

        verify(response).setContentType(mimeType);
        verify(response).setHeader("Content-Disposition", "attachment;filename=" + fileName);
        verify(outputStream).write(fileContents);
        verify(outputStream).flush();
        verify(outputStream).close();
        verify(context).responseComplete();
    }

    @Test
    public void downloadFile_failNoFile() throws Exception {
        Long attachmentId = 1L;
        when(attachmentService.get(attachmentId)).thenReturn(null);

        rtSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        rtSearchFormFacesBean.downloadFile();
    }

    @Test
    public void downloadFile_IOfailure() throws Exception {
        String errorMessage = "something went wrong";
        Long attachmentId = 1L;
        String mimeType = "application/octet-stream";
        String fileName = "file.zzz";
        byte[] fileContents = new byte[]{'a', 'b', 'c', 'd'};

        File file = new File(fileName, mimeType, 4L, fileContents);
        Attachment attachment = new Attachment(file,"234", DocumentType.ADD);

        when(attachmentService.get(attachmentId)).thenReturn(attachment);
        when(response.getOutputStream()).thenThrow(new IOException(errorMessage));

        rtSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        rtSearchFormFacesBean.downloadFile();

        assertThat(messages.get(0), is(errorMessage));
    }

    @Test
    public void deleteAttachment() {
        Long attachmentId = 1L;
        rtSearchFormFacesBean.setIdAttachmentToDelete(attachmentId);
        when(rtView.getId()).thenReturn(1L);
        rtSearchFormFacesBean.deleteAttachment();
    }

    @Test
    public void selectRow(){
        RtView rtView1 = new RtView(1L, "123", new Date(), "", "participant", "participantDescription");
        when(searchResult.getRowData()).thenReturn(rtView1);
        rtSearchFormFacesBean.selectedRow();
        Assert.assertTrue(rtSearchFormFacesBean.getRtView().getId().equals(1L));
    }

    @Test
    public void setAttachmentToDelete(){
        RtView rtView1 = new RtView(1L, "123", new Date(), "", "participant", "participantDescription");
        when(searchResult.getRowData()).thenReturn(rtView1);
        rtSearchFormFacesBean.setAttachmentToDelete();
        Assert.assertTrue(rtSearchFormFacesBean.getRtView().getId().equals(1L));
    }

    private Date getDateWithoutTime() {
        Date date = new Date();
        date = DateUtils.setHours(date,0);
        date = DateUtils.setMinutes(date,0);
        date = DateUtils.setSeconds(date,0);
        date = DateUtils.setMilliseconds(date,0);
        return date;
    }

    @Test
    public void getAttachmentsFirstTime() {
        final long RT_ID = 1L;
        RtView rtView = new RtView(RT_ID, "123", new Date(), "", "participant", "participantDescription");
        AttachmentView attachmentView = new AttachmentView(1L, DocumentType.RT, "1234");
        ToggleEvent event = mock(ToggleEvent.class);
        when(event.getData()).thenReturn(rtView);
        when(grainTransferService.getAttachments(RT_ID)).thenReturn(asList(attachmentView));
        rtSearchFormFacesBean.onRowToggle(event);
        assertThat(rtView.getListAttachmentView().size(), is(1));
        assertThat(rtView.getListAttachmentView().contains(attachmentView), is(true));
    }

    @Test
    public void getAttachmentsFromView() {
        final long RT_ID = 1L;
        AttachmentView attachmentView = new AttachmentView(1L, DocumentType.RT, "1234");
        RtView rtView = new RtView(RT_ID, "123", new Date(), "", "participant", "participantDescription");
        rtView.setListAttachmentView(asList(attachmentView));
        ToggleEvent event = mock(ToggleEvent.class);
        when(event.getData()).thenReturn(rtView);
        rtSearchFormFacesBean.onRowToggle(event);
        assertThat(rtView.getListAttachmentView().size(), is(1));
        assertThat(rtView.getListAttachmentView().contains(attachmentView), is(true));
        verifyZeroInteractions(grainTransferService);
    }

    @Test
    public void testPostProcessXLS(){
        RtFilter filter = new RtFilter();

        HSSFWorkbook document = buildWorkbook();

        when(searchResult.getRowCount()).thenReturn(3);
        rtSearchFormFacesBean.setFilter(filter);
        rtSearchFormFacesBean.postProcessXLS(document);
    }

    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 12; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }

}
