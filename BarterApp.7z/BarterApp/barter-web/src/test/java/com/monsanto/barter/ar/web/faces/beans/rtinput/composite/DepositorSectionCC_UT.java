package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtDepositor;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class DepositorSectionCC_UT {

    private class TestDepositorSectionCC extends DepositorSectionCC {
        protected BeanValidator getValidator() {
            return mockedValidator;
        }

        protected void addMessage(String message) {
            messages.add(message);
        }

    }

    @Mock
    private BeanValidator mockedValidator;
    @Mock
    private RspVatService rspVatService;
    @Mock
    private CustomerCC depositorCC;
    @Mock
    private LocationCC depositorCityCC;


    private TestDepositorSectionCC step;

    private List<String> messages;

    private GrainTransfer grainTransfer;


    @Before
    public void setUp() {
        initMocks(this);
        step = new TestDepositorSectionCC();
        messages = new LinkedList<String>();

        grainTransfer = new GrainTransfer();
        step.setDepositorCC(depositorCC);
        step.setDepositorCity(depositorCityCC);
        step.setIdRspVat("inscripto");

        step.setEntity(grainTransfer);
        step.setRspVatService(rspVatService);
    }

    @Test
    public void initialize() {
        int index = 3;
        String key = "key";

        step.initializeStepCC(index, key, grainTransfer, Mode.CREATE);
        step.begin();

        assertThat(step.getGroups().contains(RtDepositor.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
        assertThat(step.getRtInput(), is(grainTransfer));
    }

    @Test
    public void validateReceptorWithoutViolations() {
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        CustomerLas depositor = new CustomerLas();
        grainTransfer.setDepositor(depositor);

        when(mockedValidator.validate(depositor, DepositorSectionCC.DEPOSITOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(grainTransfer, RtDepositor.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(true));
    }

    @Test
    public void validateReceptorWithViolations() {
        String error = "error";
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        customerViolations.add(DepositorSectionCC.DEPOSITOR_KEY + ": " + error);
        CustomerLas depositor = new CustomerLas();
        grainTransfer.setDepositor(depositor);

        when(mockedValidator.validate(depositor, DepositorSectionCC.DEPOSITOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(grainTransfer, RtDepositor.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(DepositorSectionCC.DEPOSITOR_KEY + ": " + error), is(true));
    }

    @Test
    public void testSetValuesFromComponent(){
        String idRspVat = "inscripto";
        RspVat rspVatSpied = spy(new RspVat());
        doReturn(idRspVat).when(rspVatSpied).getId();
        List<RspVat> rspVats = new ArrayList<RspVat>();
        rspVats.add(rspVatSpied);
        step.setRspVatList(rspVats);

        CustomerLas depositor = new CustomerLas();

        CityAfipLas cityAfipLas = new CityAfipLas();

        when(depositorCityCC.getCitySelected()).thenReturn(cityAfipLas);
        when(depositorCC.getSelectedCustomer()).thenReturn(depositor);
        step.setIdRspVat(idRspVat);
        Assert.assertNull(grainTransfer.getReceptor());
        Assert.assertNull(grainTransfer.getDetailCropType());

        step.setValuesFromComponents();

        Assert.assertEquals(depositor, grainTransfer.getDepositor());
        Assert.assertEquals(cityAfipLas, grainTransfer.getDepositorCity());
        Assert.assertEquals(idRspVat, grainTransfer.getDepositorRspVat().getId());
    }

}
