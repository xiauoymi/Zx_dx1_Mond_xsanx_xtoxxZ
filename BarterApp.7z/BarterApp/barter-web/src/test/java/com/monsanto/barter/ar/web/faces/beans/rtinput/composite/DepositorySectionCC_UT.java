package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtDepository;
import com.monsanto.barter.ar.business.entity.CityAfipLas;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.business.entity.RspVat;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: GIRIA
 * Date: 2/11/14
 * Time: 11:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class DepositorySectionCC_UT {

    public static final String CITY_DESCRIPTION ="MAR DEL PLATA";

    private class TestDepositorySectionCC extends DepositorySectionCC {
        protected BeanValidator getValidator() {
            return mockedValidator;
        }

        protected void addMessage(String message) {
            messages.add(message);
        }

    }

    BeanValidator mockedValidator;

    TestDepositorySectionCC step;

    List<String> messages;

    private RspVatService rspVatService;

    private LocationCC depLocation;

    private GrainTransfer rt;

    RspVat  mockRspVat;

    @Before
    public void setUp() {
        step = new TestDepositorySectionCC();
        mockedValidator = mock(BeanValidator.class);
        rspVatService = mock(RspVatService.class);
        messages = new LinkedList<String>();

        depLocation = new LocationCC();

        List<RspVat> rspList = new LinkedList<RspVat>();
        mockRspVat = mock(RspVat.class);
        rspList.add(mockRspVat);

        when(mockRspVat.getId()).thenReturn("keyRsp1");
        when(mockRspVat.getPrimaryKey()).thenReturn("keyRsp1");
        when(rspVatService.findAll()).thenReturn(rspList);

        rt = new GrainTransfer();
        step.setEntity(rt);
        step.setDepLocation(depLocation);
        step.setRspVatService(rspVatService);
        step.setMode(Mode.CREATE);

    }

    @Test
    public void initialize() {
        int index = 2;
        String key = "key";

        step.initializeStepCC(index, key, rt, Mode.CREATE);
        step.begin();

        assertThat(step.getGroups().contains(RtDepository.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
        assertThat(step.getRtInput(), is(rt));
    }

    @Test
    public void initializeStepWithDepositaryRspVatCompletesRspVatIvaId(){
        step.setRspVatIvaId("keyRsp1");
        rt.setId(1l);
        CityAfipLas city = new CityAfipLas();
        rt.setDepositaryCity(city);
        rt.setDepositaryRspVat(mockRspVat);

        depLocation.setCity(city);
        depLocation.setCityDescription(CITY_DESCRIPTION);

        step.initializeStepCC(2, "key", rt, Mode.CREATE);
        step.begin();

        assertEquals(step.getRspVatIvaId(),step.getRtInput().getDepositaryRspVat().getId());
        assertThat(step.getRtInput().getDepositaryRspVat(), is(mockRspVat));

    }

    @Test
    public void testSetValuesFromComponent(){
        step.setRspVatIvaId("keyRsp1");

        step.initializeStepCC(2, "key", rt, Mode.CREATE);
        step.begin();
        step.setValuesFromComponents();

        assertThat(step.getRtInput().getDepositaryRspVat(), is(mockRspVat));

    }

    @Test
    public void testSetValuesFromComponentWhenCityDepLocationIsSet(){
        step.setRspVatIvaId("keyRsp1");
        depLocation.setCity(new CityAfipLas());
        depLocation.setCityDescription(CITY_DESCRIPTION);
        step.initializeStepCC(2, "key", rt, Mode.CREATE);
        step.begin();
        step.setValuesFromComponents();

        assertThat(step.getRtInput().getDepositaryRspVat(), is(mockRspVat));
        assertEquals(step.getRtInput().getDepositaryCity(), depLocation.getCitySelected());
    }

    @Test
    public void testErrorMessagesOnBeginWhenLoadComboThrowsBusinessException(){
        String throwExcep = "throwExcep";
        when(rspVatService.findAll()).thenThrow(new BusinessException(throwExcep));
        step.begin();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(throwExcep), is(true));

    }

}
