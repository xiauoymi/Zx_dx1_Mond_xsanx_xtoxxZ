package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtInitialData;
import com.monsanto.barter.ar.business.entity.GrainTransfer;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created with IntelliJ IDEA.
 * User: GIRIA
 * Date: 2/11/14
 * Time: 10:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class RtInitialDataSectionCC_UT {

    GrainTransfer rt;

    RtInitialDataSectionCC step;

    List<String> messages;

    @Before
    public void setUp() {
        step = new RtInitialDataSectionCC();
        messages = new LinkedList<String>();

        rt = new GrainTransfer();

        step.setEntity(rt);
    }

    @Test
    public void initialize() {
        int index = 0;
        String key = "key";
        step.initializeStepCC(index, key, rt, Mode.CREATE);
        step.begin();
        assertThat(step.getGroups().contains(RtInitialData.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
    }

}
