package com.monsanto.barter.ar.web.faces.beans.rtinput.composite;

import com.monsanto.barter.ar.business.constraints.groups.graintransfer.RtTransfer;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.service.MaterialLasService;
import com.monsanto.barter.ar.business.service.RspVatService;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.composite.LocationCC;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class RtTransferSectionCC_UT {

    private class TestRtTransferSectionCC extends RtTransferSectionCC {
        protected BeanValidator getValidator() {
            return mockedValidator;
        }

        protected void addMessage(String message) {
            messages.add(message);
        }

    }
    @Mock
    BeanValidator mockedValidator;
    @Mock
    private MaterialLasService materialLasService;
    @Mock
    private RspVatService rspVatService;
    @Mock
    private CustomerCC receptorCC;
    @Mock
    private LocationCC receptorCityCC;

    private TestRtTransferSectionCC step;
    private List<String> messages;
    private GrainTransfer grainTransfer;

    @Before
    public void setUp() {
        initMocks(this);
        step = new TestRtTransferSectionCC();
        messages = new LinkedList<String>();

        grainTransfer = new GrainTransfer();
        step.setReceptorCC(receptorCC);
        step.setReceptorCity(receptorCityCC);
        step.setIdMaterialLas(1l);

        step.setEntity(grainTransfer);
        step.setMaterialLasService(materialLasService);
        step.setRspVatService(rspVatService);
    }

    @Test
    public void initialize() {
        int index = 4;
        String key = "key";

        step.initializeStepCC(index, key, grainTransfer, Mode.CREATE);
        step.begin();

        assertThat(step.getGroups().contains(RtTransfer.class), is(true));
        assertThat(step.getGroups().size(), is(1));
        assertThat(step.getIndex(), is(index));
        assertThat(step.getKey(), is(key));
        assertThat(step.getRtInput(), is(grainTransfer));
    }

    @Test
    public void validateReceptorWithoutViolations() {
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        CustomerLas receptor = new CustomerLas();
        grainTransfer.setReceptor(receptor);

        when(mockedValidator.validate(receptor, RtTransferSectionCC.RECEPTOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(grainTransfer, RtTransfer.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(true));
    }

    @Test
    public void validateReceptorWithViolations() {
        String error = "error";
        List<String> violations = new ArrayList<String>();
        List<String> customerViolations = new ArrayList<String>();
        customerViolations.add(RtTransferSectionCC.RECEPTOR_KEY + ": " + error);
        CustomerLas receptor = new CustomerLas();
        grainTransfer.setReceptor(receptor);

        when(mockedValidator.validate(receptor, RtTransferSectionCC.RECEPTOR_KEY)).thenReturn(customerViolations);
        when(mockedValidator.validate(grainTransfer, RtTransfer.class)).thenReturn(violations);

        step.validate();

        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(RtTransferSectionCC.RECEPTOR_KEY + ": " + error), is(true));
    }

    @Test
    public void testSetValuesFromComponent(){
        Long idCropType = 1l;
        MaterialLas spied = spy(new MaterialLas());
        doReturn(idCropType).when(spied).getId();
        List<MaterialLas> materials = new ArrayList<MaterialLas>();
        materials.add(spied);
        step.setMaterialLasList(materials);

        String idRspVat = "inscripto";
        RspVat rspVatSpied = spy(new RspVat());
        doReturn(idRspVat).when(rspVatSpied).getId();
        List<RspVat> rspVats = new ArrayList<RspVat>();
        rspVats.add(rspVatSpied);
        step.setRspVatList(rspVats);

        String documentNumber = "document";
        CustomerLas spiedCustomer = spy(new CustomerLas());
        doReturn(documentNumber).when(spiedCustomer).getDocument();

        CityAfipLas cityAfipLas = new CityAfipLas();

        when(receptorCityCC.getCitySelected()).thenReturn(cityAfipLas);
        when(receptorCC.getSelectedCustomer()).thenReturn(spiedCustomer);
        step.setIdMaterialLas(idCropType);
        step.setIdRspVat(idRspVat);
        Assert.assertNull(grainTransfer.getReceptor());
        Assert.assertNull(grainTransfer.getDetailCropType());

        step.setValuesFromComponents();

        Assert.assertEquals(spiedCustomer, grainTransfer.getReceptor());
        Assert.assertEquals(cityAfipLas, grainTransfer.getReceptorCity());
        Assert.assertEquals(idCropType, grainTransfer.getDetailCropType().getId());
        Assert.assertEquals(idRspVat, grainTransfer.getReceptorRspVat().getId());
    }

}
