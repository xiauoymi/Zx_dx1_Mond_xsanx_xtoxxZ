package com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel;

import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.RtView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author JPBENI
 */
public class RtDatamodel_UT {

    @Mock
    private GrainTransferService service;

    private RtFilter filter;
    private RtDataModel dataModel;
    private List<RtView> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new RtFilter();
        page = new ArrayList<RtView>();
        dataModel = new RtDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void load() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.ASCENDING;
        Recordset<RtView> recordset = new Recordset<RtView>(new ArrayList<RtView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<RtView> results = dataModel.load(first, pageSize, sortField, sortOrder, null);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void load_descending() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.DESCENDING;
        Recordset<RtView> recordset = new Recordset<RtView>(new ArrayList<RtView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<RtView> results = dataModel.load(first, pageSize, sortField, sortOrder, null);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void getRowData() {
        RtView rtView = new RtView(1L, null, null, null, null, null);
        page.add(rtView);

        assertThat(dataModel.getRowData("1"), is(rtView));
    }

    @Test
    public void getRowData_noMatches() {
        RtView rtView = new RtView(1L, null, null, null, null, null);
        page.add(rtView);

        assertThat(dataModel.getRowData("2"), is(nullValue()));
    }

    @Test
    public void getRowKey() {
        RtView rtView = new RtView(1L, null, null, null, null, null);
        assertThat(dataModel.getRowKey(rtView), is((Object)"1"));
    }
}