package com.monsanto.barter.ar.web.faces.beans.rtinput.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.ReportService;
import com.monsanto.barter.ar.business.service.RtReportFilter;
import com.monsanto.barter.ar.business.service.dto.RtReportView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * @author GIRIA
 */
public class RtReportDataModel_UT {

    @Mock
    private ReportService service;

    private RtReportFilter filter;
    private RtReportDataModel dataModel;
    private List<RtReportView> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new RtReportFilter();
        page = new ArrayList<RtReportView>();
        dataModel = new RtReportDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void load() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<RtReportView> recordset = new Recordset<RtReportView>(new ArrayList<RtReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<RtReportView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.ASC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void load_descending() {
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.DESCENDING;
        Map<String,String> filters = null;
        Recordset<RtReportView> recordset = new Recordset<RtReportView>(new ArrayList<RtReportView>(), 1L);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.search(eq(filter), pagingCaptor.capture()))
                .thenReturn(recordset);

        List<RtReportView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(Paging.SortOrder.DESC));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void testGetRowDataNoMatches(){
        RtReportView rtReportView = new RtReportView(123L, null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);

        String rowKey = (String) dataModel.getRowKey(rtReportView);
        assertNull(dataModel.getRowData(rowKey));
    }


    @Test
    public void getRowData() {
        RtReportView rtReportView = new RtReportView();
        setField(rtReportView, "id", 12L);
        page.add(rtReportView);
        assertThat(dataModel.getRowData("12"), is(rtReportView));
    }

}
