package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.business.service.dto.TurnOperationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.Mockito.*;

/**
 * Created by VNBARR on 7/31/2014.
 */
public class TurnAssignmentCancellation_UT {

    private TurnAssignmentCancellation turnAssignmentCancellation;
    private static final Long ID = 1L;
    private static final String CUIT="30707053204";

    private static final String SUCCESS = "success";

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private BeanValidator beanValidator;

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private ContractService contractService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private TerminalService terminalService;

    @Mock
    private TurnService turnsService;

    @Mock
    private CustomerCC customerCC;

    @Mock
    private CityAfipLas city;

    @Mock
    private Terminal terminal;

    @Mock
    private MaterialLas cropType;

    private List<String> messages;

    @Mock
    private PointOfSale userPOS;

    @Mock
    private CustomerLas customerPOS;

    @Mock
    private CustomerLas userGrower;

    @Mock
    private CustomerLas exporter;

    @Mock
    private CustomerLas broker;

    @Mock
    private Port port;

    @Mock
    private SelectEvent event;

    @Mock
    private TurnDataModel turnsFromAssignment;

    @Mock
    private RequestContext requestContext;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        messages = new ArrayList<String>();

        turnAssignmentCancellation = new TurnAssignmentCancellation(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }

            public RequestContext getRequestContext() {
                return requestContext;
            }

        };

        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCC);
        when(beanFactoryMock.getBean(TerminalService.class)).thenReturn(terminalService);
        when(beanFactoryMock.getBean(TurnService.class)).thenReturn(turnsService);
        when(beanFactoryMock.getBean(ContractService.class)).thenReturn(contractService);
        when(terminalService.get(ID)).thenReturn(terminal);
        when(port.getStorageLocationDescription()).thenReturn("PORT_DESCRIPTION");
        when(port.getCityAfipLas()).thenReturn(city);
        when(port.getId()).thenReturn(ID);
        when(terminal.getPort()).thenReturn(port);
        when(cropType.getId()).thenReturn(ID);
        when(userPOS.getCustomer()).thenReturn(customerPOS);

    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new TurnAssignmentCancellation());
    }

    @Test
    public void cancelTurnsInitializesComponents() {

        turnAssignmentCancellation.setTurnRequestId(ID);
        turnAssignmentCancellation.setExporterContractId(ID);
        turnAssignmentCancellation.setTurnDate(new Date());
        TurnRequestDTO newTurnRequest = getTurnRequest();
        ContractView exporterContract = getContract();
        when(turnRequestService.getDTO(ID)).thenReturn(newTurnRequest);
        when(contractService.getContractViewForAssignment(ID)).thenReturn((exporterContract));

        String navigation = turnAssignmentCancellation.cancelTurns();

        Assert.assertNotNull(turnAssignmentCancellation.getTurnRequestDTO());
        Assert.assertNotNull(turnAssignmentCancellation.getExporterContractDTO());
        Assert.assertNotNull((turnAssignmentCancellation.getTurnsToCancel()));

        Assert.assertFalse(turnAssignmentCancellation.isViewMode());
        Assert.assertTrue(turnAssignmentCancellation.isEditMode());
        Assert.assertEquals(SUCCESS, navigation);
    }

    @Test
    public void getTurnsSelectedAddTurnsToCancel(){

        TurnDTO turnSelected = new TurnDTO(1l,null, null, null,null,null, null, null, null, null, null, null, true);
        turnSelected.setSelected(true);

        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnSelected);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);

        turnAssignmentCancellation.getTurnsSelectedToCancel();

        verify(requestContext).addCallbackParam("isValid", true);
        Assert.assertEquals(turnAssignmentCancellation.getConfirmationMessage(), "label.cancellation.confirmMessageCancel");
        //Assert.assertEquals(turnAssignmentCancellation.getMailObservations(), "");
        Assert.assertEquals(turnAssignmentCancellation.getTurnsToCancel().size(), 1);

    }

    @Test
    public void getTurnsSelectedAddTurnsToCancelAndSetAvailable(){


        TurnDTO turnSelected = new TurnDTO(1l,null, null, null,null,null, null, null, null, null, null, null, true);
        turnSelected.setSelected(true);

        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnSelected);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);
        turnAssignmentCancellation.getTurnsSelectedToAvailable();

        verify(requestContext).addCallbackParam("isValid", true);
        Assert.assertEquals(turnAssignmentCancellation.getConfirmationMessage(), "label.cancellation.confirmMessageAvailable");
        //Assert.assertEquals(turnAssignmentCancellation.getMailObservations(), "");
        Assert.assertEquals(turnAssignmentCancellation.getTurnsToCancel().size(), 1);

    }

    @Test
    public void getTurnsSelectedIsInvalid(){
        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.getTurnsSelectedToCancel();
        verify(requestContext).addCallbackParam("isValid", false);
        Assert.assertEquals(turnAssignmentCancellation.getConfirmationMessage(), "");
        Assert.assertEquals(turnAssignmentCancellation.getTurnsToCancel().size(), 0);
        Assert.assertNotNull(messages);
        Assert.assertEquals(messages.get(0), "label.search.turn.turnsCancellation.emptyList");

    }

    @Test
    public void confirmCancelTurnsSuccessAndCancel(){


        TurnDTO turnSelected = new TurnDTO(1l,null, null, null,null,null, null, null, null, null, null, null, true);
        turnSelected.setSelected(true);

        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnSelected);

        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.getTurnsSelectedToCancel();

        turnAssignmentCancellation.setTurnRequestDTO(getTurnRequest());

        ReflectionTestUtils.setField(turnAssignmentCancellation, "turnService", turnsService);
        ReflectionTestUtils.setField(turnAssignmentCancellation, "turnRequestService", turnRequestService);
        turnAssignmentCancellation.confirmCancelTurns();

        Assert.assertNotNull(messages);
        Assert.assertEquals(messages.get(0), "label.search.turn.turnsCancellation.success");
        verify(requestContext).addCallbackParam("cancelled", true);

    }

    @Test
    public void confirmCancelTurnsThrowsBusinessException(){

        TurnDTO turnSelected = new TurnDTO(1l,null, null, null,null,null, null, null, null, null, null, null, true);
        turnSelected.setSelected(true);

        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnSelected);

        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.getTurnsSelectedToCancel();

        turnAssignmentCancellation.setTurnRequestDTO(getTurnRequest());
        HashSet<TurnDTO> turnsToCancel = new HashSet<TurnDTO>();
        turnAssignmentCancellation.setTurnsToCancel(turnsToCancel);
        ReflectionTestUtils.setField(turnAssignmentCancellation, "turnService", turnsService);
        ReflectionTestUtils.setField(turnAssignmentCancellation, "turnRequestService", turnRequestService);
        doThrow(new BusinessException("error")).when(turnsService).suspendTurns(turnAssignmentCancellation.getTurnRequestDTO(),
                turnsToCancel, turnAssignmentCancellation.getTurnOperationDTO());

        turnAssignmentCancellation.confirmCancelTurns();

        Assert.assertNotNull(messages);
        Assert.assertEquals(messages.get(0), "label.search.turn.turnsCancellation.error");
        verify(requestContext).addCallbackParam("cancelled", false);

    }

    @Test
    public void getTurnsToCancelListReturnList(){

        TurnDTO turnSelected = new TurnDTO(1l,null, null, null,null,null, null, null, null, null, null, null, true);
        turnSelected.setSelected(true);

        Set<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnSelected);
        turnAssignmentCancellation.setTurnOperationDTO(new TurnOperationDTO());
        turnAssignmentCancellation.setTurnsFromAssignment(turnsFromAssignment);
        when(turnsFromAssignment.getSelected()).thenReturn(turnList);
        turnAssignmentCancellation.getTurnsSelectedToAvailable();
        List<TurnDTO> turns = turnAssignmentCancellation.getTurnsToCancelList();

        Assert.assertNotNull(turns);
        Assert.assertEquals(turns.size(), 1);
    }

    @Test
    public void cancelMethodTest(){
        String navigation = turnAssignmentCancellation.cancel();
        Assert.assertTrue(turnAssignmentCancellation.isViewMode());
        Assert.assertFalse(turnAssignmentCancellation.isEditMode());
        Assert.assertEquals(SUCCESS, navigation);
    }

    public TurnRequestDTO getTurnRequest() {
        TurnRequestDTO turnRequest = new TurnRequestDTO(ID, null,null, new Date(), new Date(), userGrower.getDescription(), "123456",
                null, "Observaciones", ID, userPOS.getCustomer().getDescription(), null,
                "PORT_DESCRIPTION", null, userPOS.getEmail(), userGrower.getDocument(), terminal.getName(),
                40L, false,0L);

        return turnRequest;
    }

    public ContractView getContract(){

        ContractView contract = new ContractView();
        contract.setContractId(ID);
        contract.setNumber("123456");
        contract.setExporterDescription(exporter.getDescription());
        contract.setBrokerDescription(broker.getDescription());

        return contract;
    }

}
