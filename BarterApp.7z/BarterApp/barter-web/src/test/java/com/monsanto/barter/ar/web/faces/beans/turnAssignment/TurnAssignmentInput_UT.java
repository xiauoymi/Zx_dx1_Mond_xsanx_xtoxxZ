package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.service.ContractFilter;
import com.monsanto.barter.ar.business.service.PortService;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.TurnService;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.TurnAssignment;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite.AssignmentContractSearch;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite.AssignmentTurnRequestSearchCC;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.primefaces.component.outputpanel.OutputPanel;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import javax.faces.event.ActionEvent;
import java.io.Serializable;
import java.util.*;

import static com.thoughtworks.selenium.SeleneseTestBase.assertEquals;
import static com.thoughtworks.selenium.SeleneseTestBase.assertFalse;
import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by JASANC5 on 8/15/2014.
 */
public class TurnAssignmentInput_UT {


    private TurnAssignmentInput turnAssignmentInput;

    private static final String SUCCESS = "success";
    private static final String ERROR = "error";

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private AssignmentTurnRequestSearchCC assignmentTurnRequestSearchCC;


    @Mock
    private AssignmentContractSearch assignmentContractSearch;

    @Mock
    private TurnService turnService;

    @Mock
    TurnRequest turnRequest;

    @Mock
    private Port port;

    @Mock
    private PortService portService;

    @Mock
    private CustomerLas customer;

   // private List<String> messages;
    @Mock
    private PointOfSale userPos;

    @Mock
    TurnRequestDTO turnRequestDTO;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

      //  messages = new ArrayList<String>();

        turnAssignmentInput = new TurnAssignmentInput(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

         /*   @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }
*/
        };

        when(beanFactoryMock.getBean(TurnService.class)).thenReturn(turnService);
        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(AssignmentContractSearch.class)).thenReturn(assignmentContractSearch);
        when(beanFactoryMock.getBean(AssignmentTurnRequestSearchCC.class)).thenReturn(assignmentTurnRequestSearchCC);
        when(beanFactoryMock.getBean(PortService.class)).thenReturn(portService);
        when(portService.get(Mockito.any(Serializable.class))).thenReturn(port);
        when(turnRequestDTO.getCropTypeId()).thenReturn(1L);
        when(turnRequestDTO.getSuggestedPortDestinationId()).thenReturn(1L);

        turnAssignmentInput.begin();
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new TurnAssignmentInput());
    }


    @Test
    public void testBegin(){
        String response = turnAssignmentInput.begin();
        assertNull(turnAssignmentInput.getTurnRequest());
        assertEquals(SUCCESS, response);
    }

    @Test
    public void testSelectedRequestToAttendAvailable(){
        Long turnRequestId = 1L;
        when(turnRequestDTO.getId()).thenReturn(turnRequestId);
        when(turnRequestDTO.isValidForAttend()).thenReturn(true);
        SelectEvent event = mock(SelectEvent.class);
        when(event.getObject()).thenReturn(turnRequestDTO);
        setUpTurnRequest();
        when(turnRequestService.getDTO(turnRequestId)).thenReturn(turnRequestDTO);
        turnAssignmentInput.selectedRequestToAttend(event);
        assertTrue(turnAssignmentInput.getMessages().isEmpty());
    }

    private void setUpTurnRequest() {
        MaterialLas materialLas = mock(MaterialLas.class);
        when(materialLas.getId()).thenReturn(2L);

        Date date = new Date();
        Terminal terminal = mock(Terminal.class);
        when(terminal.getPort()).thenReturn(mock(Port.class));
      /*  when(turnRequest.getGrower()).thenReturn(customer);
        when(turnRequest.getCropType()).thenReturn(materialLas);
        when(turnRequest.getDestination()).thenReturn(port);
        when(turnRequest.getTurnRequestDate()).thenReturn(date);
        when(userPos.getCustomer()).thenReturn(customer);
        when(turnRequest.getUserPOS()).thenReturn(userPos);
 */   }

    @Test
    public void testSelectedRequestToAttendUnavailable(){
        Long turnRequestId = 1l;
        when(turnRequestDTO.getId()).thenReturn(turnRequestId);
        when(turnRequest.isAvailableForAssign()).thenReturn(false);
        SelectEvent event = mock(SelectEvent.class);
        when(event.getObject()).thenReturn(turnRequestDTO);
        setUpTurnRequest();
        when(turnRequestService.getDTO(turnRequestId)).thenReturn(turnRequestDTO);
        turnAssignmentInput.selectedRequestToAttend(event);
        assertFalse(turnAssignmentInput.getMessages().isEmpty());
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.request.completedOrUnavailable");
    }

    @Test
    public void testSelectedRequestToAttendWithException(){
        SelectEvent event = mock(SelectEvent.class);
        when(event.getObject()).thenThrow(new BusinessException("error"));
        turnAssignmentInput.selectedRequestToAttend(event);
        assertFalse(turnAssignmentInput.getMessages().isEmpty());
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.load.error");
    }


    @Test
    public void testPreSaveWithEmptyContractList(){
        Long turnRequestId = 1L;
        List<ContractView> contractViewList = new ArrayList<ContractView>();
        when(assignmentContractSearch.getContractListSelection()).thenReturn(contractViewList);
        when(turnRequestDTO.getId()).thenReturn(turnRequestId);
        when(turnRequestDTO.isValidForAttend()).thenReturn(false);
        ReflectionTestUtils.setField(turnAssignmentInput,"turnRequestDTO",turnRequestDTO);

        when(turnRequest.isAvailableForAssign()).thenReturn(true);
        when(turnRequestService.getDTO(turnRequestId)).thenReturn(turnRequestDTO);

        turnAssignmentInput.preSave();
        assertFalse(turnAssignmentInput.getMessages().isEmpty());
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.request.completedOrUnavailable");


    }

    @Test
    public void testPreSaveWithContractWithoutTurns(){
        final String CONTRACT_NUMBER = "1";
        List<ContractView> contractViewList = new ArrayList<ContractView>();
        when(assignmentContractSearch.getContractListSelection()).thenReturn(contractViewList);
        when(turnRequest.isAvailableForAssign()).thenReturn(false);
        Long turnRequestId = 1L;
        when(turnRequestDTO.getId()).thenReturn(turnRequestId);
        when(turnRequestDTO.isValidForAttend()).thenReturn(true);
        ReflectionTestUtils.setField(turnAssignmentInput,"turnRequestDTO",turnRequestDTO);
        when(turnRequestService.getDTO(turnRequestId)).thenReturn(turnRequestDTO);
        ContractView contractView = new ContractView();
        contractView.setContractId(1l);
        contractView.setTurnsToAssign(2l);
        contractView.setAvailableTurns(1l);
        contractView.setNumber(CONTRACT_NUMBER);
        contractViewList.add(contractView);
        turnAssignmentInput.preSave();
        assertFalse(turnAssignmentInput.getMessages().isEmpty());
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.error.exceededContractQuantity" + CONTRACT_NUMBER);
    }

    @Test
    public void testPreSaveValid(){
        final String CONTRACT_NUMBER = "1";
        List<ContractView> contractViewList = new ArrayList<ContractView>();
        when(assignmentContractSearch.getContractListSelection()).thenReturn(contractViewList);
        when(turnRequest.isAvailableForAssign()).thenReturn(false);
        turnAssignmentInput.setTurnRequest(turnRequest);

        when(turnRequest.getTurnRemnantQuantity()).thenReturn(2l);
        ContractView contractView = new ContractView();
        contractView.setContractId(1l);
        contractView.setTurnsToAssign(2l);
        contractView.setAvailableTurns(1l);
        contractView.setNumber(CONTRACT_NUMBER);
        contractViewList.add(contractView);
        contractView.setAvailableTurns(10l);
        contractView.setTurnsToAssign(1l);
        Long turnRequestId = 1L;
        when(turnRequestDTO.getId()).thenReturn(turnRequestId);
        when(turnRequestDTO.isValidForAttend()).thenReturn(true);
        when(turnRequestDTO.getTurnRemnantQuantity()).thenReturn(turnRequestId);
        ReflectionTestUtils.setField(turnAssignmentInput,"turnRequestDTO",turnRequestDTO);
        when(turnRequestService.getDTO(turnRequestId)).thenReturn(turnRequestDTO);

        List<Turn> turnList = new ArrayList<Turn>();
        turnList.add(new Turn());
        when(assignmentContractSearch.getFilter()).thenReturn(new ContractFilter());
        when(turnService.getTurnToAssignByContractIdTerminalAndDate(contractView.getContractId(),contractView.getTerminalId() , null, contractView.getTurnsToAssign())).
                thenReturn(turnList);
        Set<Turn> turnsSet = new HashSet<Turn>();
        when(turnRequest.getTurns()).thenReturn(turnsSet);
        when(turnRequestService.get(turnRequestId)).thenReturn(turnRequest);
        when(turnRequest.isAvailableForAssign()).thenReturn(true);

        turnAssignmentInput.preSave();

        Assert.assertNull(turnAssignmentInput.getMessages());


    }


    @Test
    public void testSave(){
        String response = turnAssignmentInput.save();
        assertFalse(turnAssignmentInput.getMessages().isEmpty());
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.created");
        assertEquals(SUCCESS, response);
    }

    @Test
    public void testExceptionSaving(){
        TurnAssignment assignment = null;
        when(turnRequestService.sendMailTurnAssignment(assignment)).thenThrow(new BusinessException(null));

        String response = turnAssignmentInput.save();assertFalse(turnAssignmentInput.getMessages().isEmpty());
        Assert.assertEquals(turnAssignmentInput.getMessages().size(),1);
        assertEquals(turnAssignmentInput.getMessages().get(0).getDetail(),"label.input.turnAssignment.sendMail.error");
        assertEquals(ERROR, response);
    }

}
