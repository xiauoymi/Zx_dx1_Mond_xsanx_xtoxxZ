package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.TurnCancellationReason;
import com.monsanto.barter.ar.business.entity.enumerated.TurnOperationType;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.TurnDTO;
import com.monsanto.barter.ar.business.service.dto.TurnOperationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.turn.datamodel.TurnDataModel;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;

import java.util.*;

import static com.thoughtworks.selenium.SeleneseTestBase.assertEquals;
import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;
import static org.mockito.Mockito.when;

/**
 * Created by VNBARR on 10/15/2014.
 */
public class TurnAssignmentReturn_UT {

    private TurnAssignmentReturn turnAssignmentReturn;
    private static final Long ID = 1L;

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private BeanValidator beanValidator;

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private ContractService contractService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private TerminalService terminalService;

    @Mock
    private TurnService turnsService;

    @Mock
    private CustomerCC customerCC;

    @Mock
    private CityAfipLas city;

    @Mock
    private Terminal terminal;

    @Mock
    private MaterialLas cropType;

    private List<String> messages;

    @Mock
    private PointOfSale userPOS;

    @Mock
    private CustomerLas customerPOS;

    @Mock
    private TurnRequestDTO turnRequestDTO;

    @Mock
    private Port port;

    @Mock
    private SelectEvent event;

    @Mock
    private TurnDataModel turnsFromAssignment;

    @Mock
    private RequestContext requestContext;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        messages = new ArrayList<String>();

        turnAssignmentReturn = new TurnAssignmentReturn(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }

            public RequestContext getRequestContext() {
                return requestContext;
            }

        };

        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCC);
        when(beanFactoryMock.getBean(TerminalService.class)).thenReturn(terminalService);
        when(beanFactoryMock.getBean(TurnService.class)).thenReturn(turnsService);
        when(beanFactoryMock.getBean(ContractService.class)).thenReturn(contractService);
        when(terminalService.get(ID)).thenReturn(terminal);
        when(port.getStorageLocationDescription()).thenReturn("PORT_DESCRIPTION");
        when(port.getCityAfipLas()).thenReturn(city);
        when(port.getId()).thenReturn(ID);
        when(terminal.getPort()).thenReturn(port);
        when(cropType.getId()).thenReturn(ID);
        when(userPOS.getCustomer()).thenReturn(customerPOS);

    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new TurnAssignmentReturn());
    }

    @Test
    public void preTurnReturnWithErrors(){
        TurnDTO turnDTO = new TurnDTO(1l,null,null,null,null);

        HashSet<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnDTO);

        when(turnRequestService.getDTO(1L)).thenReturn(turnRequestDTO);
        turnAssignmentReturn.setTurnRequestId(1L);
        turnAssignmentReturn.viewTurnAssignment();
        turnAssignmentReturn.setTurnsFromAssignment(turnsFromAssignment);
        when(turnAssignmentReturn.getTurnsFromAssignment().getSelected()).thenReturn(turnList);

        TurnOperationDTO operationDTO = new TurnOperationDTO();
        operationDTO.setTurnCancellationReason(TurnCancellationReason.OTHER);
        turnAssignmentReturn.setTurnOperationDTO(operationDTO);

        turnAssignmentReturn.preSave();
        assertEquals(2, turnAssignmentReturn.getErrorMessages().size());
        assertTrue(turnAssignmentReturn.getErrorMessages().contains("label.search.turn.turnsReturn.emptyDate"));
        assertTrue(turnAssignmentReturn.getErrorMessages().contains("label.search.turn.turnsReturn.emptyObservation"));


        Date newDate = GregorianCalendar.getInstance().getTime();
        newDate = DateUtils.addDays(newDate,5);
        operationDTO.setAnnouncementDate(newDate);

        StringBuilder reason = new StringBuilder();
        for(int i=0; i<15;i++){
            reason.append("longString");
        }
        operationDTO.setReason(reason.toString());


        turnAssignmentReturn.preSave();
        assertEquals(2,turnAssignmentReturn.getErrorMessages().size());
        assertTrue(turnAssignmentReturn.getErrorMessages().contains("label.search.turn.turnsReturn.wrongAnnouncementDate"));
        assertTrue(turnAssignmentReturn.getErrorMessages().contains("label.search.turn.turnsReturn.observationsMaxCharacters"));
    }

    @Test
    public void testTurnsSelectedToReturn(){
        TurnDTO turnDTO = new TurnDTO(1l,null,null,null,null);

        HashSet<TurnDTO> turnList = new HashSet<TurnDTO>();
        turnList.add(turnDTO);

        when(turnRequestService.getDTO(1L)).thenReturn(turnRequestDTO);
        turnAssignmentReturn.setTurnRequestId(1L);
        turnAssignmentReturn.viewTurnAssignment();
        turnAssignmentReturn.setTurnsFromAssignment(turnsFromAssignment);
        when(turnAssignmentReturn.getTurnsFromAssignment().getSelected()).thenReturn(turnList);

        turnAssignmentReturn.getTurnsSelectedToReturn();
        assertEquals(TurnOperationType.RETURN,turnAssignmentReturn.getTurnOperationDTO().getType());
        assertEquals(turnList,turnAssignmentReturn.getTurnsToCancel());
        assertEquals(TurnAssignmentReturn.LABEL_RETURN_CONFIRM_MESSAGE,turnAssignmentReturn.getConfirmationMessage());
    }
}
