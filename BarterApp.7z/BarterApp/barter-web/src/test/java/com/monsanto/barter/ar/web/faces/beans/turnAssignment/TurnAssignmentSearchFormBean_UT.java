package com.monsanto.barter.ar.web.faces.beans.turnAssignment;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.TurnAssignmentDTO;
import com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel.TurnAssignmentDataModel;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by JASANC5 on 8/1/2014.
 */
public class TurnAssignmentSearchFormBean_UT {



    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private TurnAssignmentDataModel searchResult;

    private TurnAssignmentSearchFormBean turnAssignmentSearchFormBean;

    private final String SUCCESS = "success";

    private TransactionTemplateMocker transactionTemplate;
    private ArrayList<String> messages;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private CustomerCC customerCC;

    private List<MaterialLas> materialLasList;

    @Before
    public void setUp() {
        initMocks(this);

        long materialLasId = 1L;
        MaterialLas materialLas = new MaterialLas();
        ReflectionTestUtils.setField(materialLas, "id", materialLasId);
        materialLasList = Arrays.asList(materialLas);

        messages = new ArrayList<String>();

        transactionTemplate = new TransactionTemplateMocker();

        turnAssignmentSearchFormBean = new TurnAssignmentSearchFormBean(){

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public TransactionTemplate getTransactionTemplate() {
                return transactionTemplate;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }


        };

        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCC);

    }

    @Test
    public void testClassInstance() {
        turnAssignmentSearchFormBean = new TurnAssignmentSearchFormBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.setIgnoredFields("turnRequestStatuses");
        tester.testInstance(turnAssignmentSearchFormBean);
    }

    @Test
    public void beginMethodInitializesAttributes() {
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        String navigation = turnAssignmentSearchFormBean.begin();
        assertNotNull(turnAssignmentSearchFormBean.getTurnAssignmentFilter());
        assertNotNull(turnAssignmentSearchFormBean.getMaterialLasList());
        assertTrue(turnAssignmentSearchFormBean.getMaterialLasList().size() == 1);
        assertEquals(SUCCESS, navigation);
    }

    @Test
    public void searchByTurnAssignmentMethodInitializesSearchResult() {
        setupTurnAssignmentFilter();
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        //when(beanFactoryMock.getBean(TurnAssignmentService.class)).thenReturn(turnAssignmentService);
        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCC);

        turnAssignmentSearchFormBean.setMaterialLasList(materialLasList);
        String navigation = turnAssignmentSearchFormBean.search();
        assertNotNull(turnAssignmentSearchFormBean.getSearchResult());
        assertTrue(turnAssignmentSearchFormBean.getSearchResult().getRowCount() == 0);
        assertEquals(TurnAssignmentSearchFormBean.PAGE_SEARCH_RESULT, navigation);
    }


    @Test
    public void testClear(){
        setupTurnAssignmentFilter();
        turnAssignmentSearchFormBean.clear();
        assertFalse(("123456").equals(turnAssignmentSearchFormBean.getTurnAssignmentFilter().getExporterContractNumber()));
    }

    private void setupTurnAssignmentFilter(){
        TurnAssignmentFilter filter = new TurnAssignmentFilter();
        filter.setTurnRequestNumber(123456L);
        turnAssignmentSearchFormBean.setTurnAssignmentFilter(filter);
    }

    @Test
    public void selectRow(){
        TurnAssignmentDTO turnAssignmentDTO = new TurnAssignmentDTO(null, "", 1L, "", null, "", "", "", null,"","","",null,null,null);
        turnAssignmentSearchFormBean.setSearchResult(searchResult);
        when(turnAssignmentSearchFormBean.getSearchResult().getRowData()).thenReturn(turnAssignmentDTO);
        turnAssignmentSearchFormBean.selectedRow();
        Assert.assertNotNull(turnAssignmentSearchFormBean.getTurnAssignmentId());
        Assert.assertNotNull(turnAssignmentSearchFormBean.getTurnAssignmentId().equals(1L));
    }


/*    @Test
    public void autocompletePortDestinationsWithNoResults(){
        String non_exist_port = "NON_EXIST_PORT";
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(portDestinationService.search(non_exist_port)).thenReturn(new ArrayList<PortDestinationDTO>());
        turnRequestSearchFormBean.begin();
        List<PortDestinationDTO> result = turnRequestSearchFormBean.autocomplete(non_exist_port);
        Assert.assertTrue(result.isEmpty());
    }*/
}
