package com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.Port;
import com.monsanto.barter.ar.business.entity.Terminal;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TerminalDTO;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractDataModel;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static com.thoughtworks.selenium.SeleneseTestBase.assertNotEquals;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 22/08/14
 * Time: 13:08
 * To change this template use File | Settings | File Templates.
 */
public class AssignmentContractSearch_UT {

    private AssignmentContractSearch assignmentContractSearch;

    @Mock
    private ContractService contractService;

    @Mock
    private TurnService turnService;

    @Mock
    private PortService portService;

    @Mock
    private TerminalService terminalService;

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private ContractDataModel mockSearchResult;

    @Mock
    MaterialLasService materialLasService;

    @Mock
    private Terminal terminal;

    private List<String> messages;

    private ContractFilter contractFilter;

    private final long PORT_DESTINATION_ID=1L;

    private final long TERMINAL_ID=2L;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        messages = new ArrayList<String>();

        assignmentContractSearch = new AssignmentContractSearch(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

        };
        ReflectionTestUtils.setField(assignmentContractSearch, "portService", portService);
        ReflectionTestUtils.setField(assignmentContractSearch, "terminalService", terminalService);
        ReflectionTestUtils.setField(assignmentContractSearch, "materialLasService", materialLasService);
        when(materialLasService.get(Mockito.any(Long.class))).thenReturn(mock(MaterialLas.class));

        contractFilter = new ContractFilter();
    }

    @Test
    public void testClassInstance() {
        assignmentContractSearch = new AssignmentContractSearch();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(assignmentContractSearch);
    }

    @Test
    public void testBegin(){
        assignmentContractSearch.begin(contractFilter);

        assertEquals(contractFilter,assignmentContractSearch.getFilter());
        assertNotNull(assignmentContractSearch.getSearchResult());
        assertEquals(0l, assignmentContractSearch.getTerminalId().longValue());
        assertNull(assignmentContractSearch.getPortDestination());
    }

    @Test
    public void testBeginWithPortAndTerminalFilters(){
        List<TerminalDTO> terminals = mock(ArrayList.class);

        Port port = mock(Port.class);
        when(port.getId()).thenReturn(PORT_DESTINATION_ID);

        contractFilter.setPort(port);
        contractFilter.setIncludeStockingCenters(false);
        when(terminalService.findAllByPortDestination(PORT_DESTINATION_ID)).thenReturn(terminals);

        when(terminal.getId()).thenReturn(TERMINAL_ID);
        contractFilter.setTerminal(terminal);

        assignmentContractSearch.begin(contractFilter);

        assertEquals(contractFilter,assignmentContractSearch.getFilter());

        assertNotNull(assignmentContractSearch.getSearchResult());
        assertEquals(PORT_DESTINATION_ID,assignmentContractSearch.getPortDestination().getId().longValue());
        assertEquals(terminals,assignmentContractSearch.getTerminals());

    }

    @Test
    public void testHandleItemSelect(){
        List<TerminalDTO> terminals =  mock(ArrayList.class);

        PortDestinationDTO portDestinationDTO = mock(PortDestinationDTO.class);
        SelectEvent selectEvent = mock(SelectEvent.class);

        when(selectEvent.getObject()).thenReturn(portDestinationDTO);
        when(portDestinationDTO.getId()).thenReturn(PORT_DESTINATION_ID);
        when(terminalService.findAllByPortDestination(PORT_DESTINATION_ID)).thenReturn(terminals);

        assignmentContractSearch.handleItemSelect(selectEvent);

        assertEquals(portDestinationDTO,assignmentContractSearch.getPortDestination());
        assertEquals(terminals,assignmentContractSearch.getTerminals());
    }

    @Test
    public void testAutocomplete(){
        final String QUERY = "query";
        List<PortDestinationDTO> results = new ArrayList<PortDestinationDTO>();

        when(portService.search(QUERY)).thenReturn(results);

        List autocompleteResult = assignmentContractSearch.autocomplete(QUERY);

        assertEquals(results, autocompleteResult);
    }

    @Test
    public void testSearch(){
        contractFilter.setDeliveryDateFrom(new Date());
        contractFilter.setDeliveryDateTo(new Date());
        contractFilter.setTurnDate(new Date());

        assignmentContractSearch.begin(contractFilter);

        assignmentContractSearch.setTerminalId(null);
        assignmentContractSearch.setPortDestination(null);

        assignmentContractSearch.search();

        assertNotNull(assignmentContractSearch.getSearchResult());
    }

    @Test
    public void testSearchWithInvalidFilter(){
        Calendar calendar=Calendar.getInstance();

        calendar.set(2014,Calendar.AUGUST,22);
        contractFilter.setDeliveryDateFrom(calendar.getTime());

        calendar.set(2013,Calendar.AUGUST,22);
        contractFilter.setDeliveryDateTo(calendar.getTime());

        assignmentContractSearch.begin(contractFilter);
        assignmentContractSearch.search();
        assertThat(messages.contains("label.search.error.dateError"), is(true));

        contractFilter.setDeliveryDateFrom(new Date());
        contractFilter.setDeliveryDateTo(new Date());

        assignmentContractSearch.search();
        assertThat(messages.contains("label.search.error.dateError"), is(true));
    }

    @Test
    public void testSearchWithValidPortFilter(){
        final long CROP_TYPE_ID=0L;

        contractFilter.setCropTypeId(CROP_TYPE_ID);
        contractFilter.setTurnDate(new Date());

        assignmentContractSearch.begin(contractFilter);

        PortDestinationDTO portDestinationDTO = new PortDestinationDTO();
        portDestinationDTO.setId(PORT_DESTINATION_ID);
        Port port = mock(Port.class);

        when(portService.get(PORT_DESTINATION_ID)).thenReturn(port);
        assignmentContractSearch.setPortDestination(portDestinationDTO);

        assignmentContractSearch.setTerminalId(null);

        assignmentContractSearch.search();

        assertNotNull(assignmentContractSearch.getSearchResult());
    }

    @Test
    public void testSearchWithValidTerminalFilter(){
        /*List<Terminal> terminals = new ArrayList<Terminal>();

        when(terminal.getId()).thenReturn(TERMINAL_ID);
        terminals.add(terminal);
        ReflectionTestUtils.setField(assignmentContractSearch, "terminals", terminals);

        contractFilter.setTurnDate(new Date());

        assignmentContractSearch.begin(contractFilter);
        assignmentContractSearch.setTerminalId(TERMINAL_ID);

        assignmentContractSearch.search();

        assertNotNull(assignmentContractSearch.getSearchResult()); */
    }

    @Test
    public void getSelectedContractsReturnsContractsWithNonZeroTurnsToAssigned(){
        List<ContractView> contractList = new ArrayList<ContractView>();
        contractList.add(new ContractView());
        ContractView contractView = new ContractView();
        contractView.setTurnsToAssign(10l);
        contractList.add(contractView);
        Iterator<ContractView> iterator = contractList.iterator();
        when(mockSearchResult.iterator()).thenReturn(iterator);
        ReflectionTestUtils.setField(assignmentContractSearch, "searchResult", mockSearchResult);
        List<ContractView> selectedContracts = assignmentContractSearch.getContractListSelection();
        assertEquals(1,selectedContracts.size());
        assertTrue(selectedContracts.get(0).getTurnsToAssign() != null);
        assertTrue(selectedContracts.get(0).getTurnsToAssign() != 0);
    }

    @Test
    public void testClear(){
        testBeginWithPortAndTerminalFilters();

        assignmentContractSearch.clear();

        assertNotEquals(contractFilter, assignmentContractSearch.getFilter());
        assertNull(assignmentContractSearch.getPortDestination());
        assertNull(assignmentContractSearch.getTerminals());
        assertNull(assignmentContractSearch.getTerminalId());
    }

}
