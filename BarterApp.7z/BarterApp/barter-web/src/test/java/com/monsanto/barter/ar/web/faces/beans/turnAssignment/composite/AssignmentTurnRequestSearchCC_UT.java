package com.monsanto.barter.ar.web.faces.beans.turnAssignment.composite;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertNull;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created with IntelliJ IDEA.
 * User: JASANC5
 * Date: 25/08/14
 * Time: 10:18
 * To change this template use File | Settings | File Templates.
 */
public class AssignmentTurnRequestSearchCC_UT {

    private static final Long ID = 1L;
    private static final String CUIT="30707053204";

    private AssignmentTurnRequestSearchCC assignmentTurnRequestSearchCC;

    @Mock
    private CityAfipLas city;

    @Mock
    private Port port;

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private PortService portService;


    @Mock
    private MaterialLasService materialLasService;

    @Mock
    BeanFactory beanFactoryMock;

    private List<String> messages;

    private List<MaterialLas> materialLasList;

    private final String SUCCESS = "success";
    private static final String ERROR = "error";

    @Before
    public void setUp() {
        initMocks(this);

        MaterialLas materialLas = new MaterialLas();
        ReflectionTestUtils.setField(materialLas, "id", ID);
        materialLasList = Arrays.asList(materialLas);

        when(port.getId()).thenReturn(1L);
        when(port.getStorageLocationDescription()).thenReturn("Port Description");
        messages = new ArrayList<String>();

        assignmentTurnRequestSearchCC = new AssignmentTurnRequestSearchCC(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }
        };

    }


    @Test
    public void testClassInstance() {
        assignmentTurnRequestSearchCC = new AssignmentTurnRequestSearchCC();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.setIgnoredFields("turnRequestStatuses");
        tester.testInstance(assignmentTurnRequestSearchCC);
    }

    @Test
    public void beginMethodInitializesAttributes(){
        ReflectionTestUtils.setField(assignmentTurnRequestSearchCC, "materialLasService", materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        TurnRequestFilter turnRequestFilter = new TurnRequestFilter();
        String navigation = assignmentTurnRequestSearchCC.begin(turnRequestFilter);
        assertNotNull(assignmentTurnRequestSearchCC.getTurnRequestFilter());
        assertNotNull(assignmentTurnRequestSearchCC.getMaterialLasList());
        assertTrue(assignmentTurnRequestSearchCC.getMaterialLasList().size() == 1);
        assertNull(assignmentTurnRequestSearchCC.getPortDestination());
        assertNotNull(assignmentTurnRequestSearchCC.getSearchResult());
        assertTrue(assignmentTurnRequestSearchCC.getSearchResult().getRowCount() == 0);
        assertEquals(SUCCESS, navigation);

    }

    @Test
    public void loadCombosThrowsBusinessException(){
        ReflectionTestUtils.setField(assignmentTurnRequestSearchCC, "materialLasService", materialLasService);
        when(materialLasService.findAll()).thenThrow(new BusinessException(ERROR));
        TurnRequestFilter turnRequestFilter = new TurnRequestFilter();
       assignmentTurnRequestSearchCC.begin(turnRequestFilter);
        assertThat(messages.isEmpty(), is(false));
    }

    @Test
    public void testAutocomplete(){
        final String QUERY = "query";
        List<PortDestinationDTO> results = new ArrayList<PortDestinationDTO>();

        ReflectionTestUtils.setField(assignmentTurnRequestSearchCC, "portService", portService);
        when(portService.search(QUERY)).thenReturn(results);

        List autocompleteResult = assignmentTurnRequestSearchCC.autocomplete(QUERY);

        assertEquals(results, autocompleteResult);
    }

    @Test
    public void testClear(){
        setupTurnRequestFilterWithoutCropTypeAndPortDestination();
        assignmentTurnRequestSearchCC.clear();
        assertFalse(("123456").equals(assignmentTurnRequestSearchCC.getTurnRequestFilter().getContractNumber()));
    }

    @Test
    public void searchByTurnRequestMethodInitializesSearchResultWithCropTypeAndPortDestination() {
        setupTurnRequestFilterWithCropTypeAndPortDestination();
        ReflectionTestUtils.setField(assignmentTurnRequestSearchCC, "portService", portService);
        assignmentTurnRequestSearchCC.setMaterialLasList(materialLasList);
        assignmentTurnRequestSearchCC.setPortDestination(getPortDestinationDTO());
        when(portService.get(ID)).thenReturn(port);
        assignmentTurnRequestSearchCC.search();
        assertNotNull(assignmentTurnRequestSearchCC.getSearchResult());
        assertTrue(assignmentTurnRequestSearchCC.getSearchResult().getRowCount() == 0);
    }

    @Test
    public void searchByTurnRequestMethodInitializesSearchResultWithoutCropTypeAndPortDestination() {
        setupTurnRequestFilterWithoutCropTypeAndPortDestination();
        assignmentTurnRequestSearchCC.setMaterialLasList(materialLasList);
        assignmentTurnRequestSearchCC.search();
        assertNotNull(assignmentTurnRequestSearchCC.getSearchResult());
        assertTrue(assignmentTurnRequestSearchCC.getSearchResult().getRowCount() == 0);
    }

    private void setupTurnRequestFilterWithCropTypeAndPortDestination(){
        TurnRequestFilter filter = new TurnRequestFilter();
        filter.setContractNumber("123456");
        filter.setCropTypeId(1L);
        assignmentTurnRequestSearchCC.setTurnRequestFilter(filter);
    }

    private void setupTurnRequestFilterWithoutCropTypeAndPortDestination(){
        TurnRequestFilter filter = new TurnRequestFilter();
        filter.setContractNumber("123456");
        assignmentTurnRequestSearchCC.setTurnRequestFilter(filter);
    }



    private PortDestinationDTO getPortDestinationDTO() {
        PortDestinationDTO newPortDestinationDTO = new PortDestinationDTO();
        newPortDestinationDTO.setId(ID);
        return newPortDestinationDTO;
    }

}
