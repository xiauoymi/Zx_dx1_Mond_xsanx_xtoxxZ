package com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel;

import com.monsanto.barter.ar.business.service.ContractFilter;
import com.monsanto.barter.ar.business.service.ContractService;
import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.dto.ContractView;
import com.monsanto.barter.ar.web.faces.beans.contract.datamodel.ContractDataModel;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 29/08/14
 * Time: 10:52
 * To change this template use File | Settings | File Templates.
 */
public class AssignmentContractDataModel_UT {

    private ContractFilter filter;

    private List<ContractView> page;

    private AssignmentContractDataModel dataModel;

    @Mock
    private ContractService service;

    @Before
    public void setUp() {
        initMocks(this);

        page = new ArrayList<ContractView>();

        filter = new ContractFilter();
        dataModel = new AssignmentContractDataModel(service, filter);

        setField(dataModel, "page", page);
    }

    @Test
    public void testLoadPage(){
        int first = 0;
        int pageSize = 0;
        String sortField = "sortField";
        SortOrder sortOrder = SortOrder.ASCENDING;
        Map<String,String> filters = null;
        Recordset<ContractView> recordset = new Recordset<ContractView>(new ArrayList<ContractView>(), 1L);
        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);

        when(service.searchForAssignment(eq(filter), pagingCaptor.capture())).thenReturn(recordset);

        List<ContractView> results = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(results, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));
    }

}
