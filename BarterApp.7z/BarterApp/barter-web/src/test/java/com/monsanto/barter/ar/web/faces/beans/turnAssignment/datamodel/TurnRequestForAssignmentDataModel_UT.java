package com.monsanto.barter.ar.web.faces.beans.turnAssignment.datamodel;

import com.monsanto.barter.ar.business.service.Paging;
import com.monsanto.barter.ar.business.service.Recordset;
import com.monsanto.barter.ar.business.service.TurnRequestFilter;
import com.monsanto.barter.ar.business.service.TurnRequestService;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created by JASANC5 on 8/1/2014.
 */
public class TurnRequestForAssignmentDataModel_UT {

    public static final Long EXISTING_DTO_ID = 1L;
    @Mock
    private TurnRequestService service;

    private TurnRequestFilter filter;
    private TurnRequestForAssignmentDataModel dataModel;
    private List<TurnRequestDTO> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new TurnRequestFilter();
        page = new ArrayList<TurnRequestDTO>();
        dataModel = new TurnRequestForAssignmentDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void loadWithAscendingSortField(){
        SortOrder sortOrder = SortOrder.ASCENDING;
        prepareLoadWithSortFieldTest(sortOrder, Paging.SortOrder.ASC);
    }

    @Test
    public void loadWithDescendingSortField(){
        SortOrder sortOrder = SortOrder.DESCENDING;
        prepareLoadWithSortFieldTest(sortOrder,Paging.SortOrder.DESC);
    }

    private void prepareLoadWithSortFieldTest(SortOrder sortOrder,Paging.SortOrder expectedSortOrder) {
        int first = 0;
        int pageSize = 0;
        String sortField = "id";
        Map<String,String> filters = null;
        Recordset<TurnRequestDTO> recordset = new Recordset<TurnRequestDTO>(new ArrayList<TurnRequestDTO>(), EXISTING_DTO_ID);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.searchFromAssignment(eq(filter), pagingCaptor.capture())).thenReturn(recordset);

        List<TurnRequestDTO> loadResult = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(loadResult, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(expectedSortOrder));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void getRowDataMatches() {
        TurnRequestDTO turnRequestDTO = new TurnRequestDTO();
        turnRequestDTO.setId(EXISTING_DTO_ID);
        page.add(turnRequestDTO);
        assertThat(dataModel.getRowData(EXISTING_DTO_ID.toString()), is(turnRequestDTO));
    }

    @Test
    public void getRowDataNoMatches() {
        TurnRequestDTO turnRequestDTO = new TurnRequestDTO();
        turnRequestDTO.setId(EXISTING_DTO_ID);
        page.add(turnRequestDTO);
        assertThat(dataModel.getRowData("2"), is(nullValue()));
    }


    @Test
    public void testGetFilter(){
        TurnRequestFilter turnRequestFilter = dataModel.getFilter();
        assertNotNull(turnRequestFilter);
    }
}
