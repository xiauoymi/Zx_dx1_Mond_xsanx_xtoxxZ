package com.monsanto.barter.ar.web.faces.beans.turnRequest;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.constraints.groups.turnRequest.TurnsAvailability;
import com.monsanto.barter.ar.business.entity.*;
import com.monsanto.barter.ar.business.entity.enumerated.TurnRequestStatus;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.ar.web.faces.mode.Mode;
import com.monsanto.barter.ar.web.faces.validator.BeanValidator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static com.thoughtworks.selenium.SeleneseTestBase.assertEquals;
import static junit.framework.Assert.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

/**
 * Created by VNBARR on 7/31/2014.
 */
public class TurnRequestInput_UT {

    private TurnRequestInput turnRequestInput;
    private static final Long ID = 1L;
    private static final String CUIT="30707053204";

    private static final String SUCCESS = "success";
    private static final String ERROR = "error";

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private BeanValidator beanValidator;

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private TerminalService terminalService;

    @Mock
    private TurnService turnsService;

    @Mock
    private CustomerCC customerCC;

    @Mock
    private CityAfipLas city;

    @Mock
    private MaterialLas cropType;

    private List<String> messages;

    @Mock
    private PointOfSale userPOS;

    @Mock
    private CustomerLas customerPOS;

    @Mock
    private CustomerLas userGrower;

    @Mock
    private Port port;

    @Mock
    private SelectEvent event;

    @Mock
    private PortService portService;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        messages = new ArrayList<String>();

        turnRequestInput = new TurnRequestInput(){

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }

            @Override
            protected BeanValidator getValidator() {
                return beanValidator;
            }

        };

        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(CustomerCC.class)).thenReturn(customerCC);
        when(beanFactoryMock.getBean(TerminalService.class)).thenReturn(terminalService);
        when(beanFactoryMock.getBean(TurnService.class)).thenReturn(turnsService);
        when(port.getStorageLocationDescription()).thenReturn("PORT_DESCRIPTION");
        when(port.getCityAfipLas()).thenReturn(city);
        when(port.getId()).thenReturn(ID);
        when(cropType.getId()).thenReturn(ID);
        when(cropType.getPrimaryKey()).thenReturn(ID);
        when(userPOS.getCustomer()).thenReturn(customerPOS);
        when(beanFactoryMock.getBean(PortService.class)).thenReturn(portService);
        when(portService.get(Mockito.any(Long.class))).thenReturn(mock(Port.class));

    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new TurnRequestInput());
    }


    @Test
    public void beginClearsFields(){
        String navigation = turnRequestInput.begin();
        assertNull(turnRequestInput.getTurnRequestId());
// FIXME POS
//        assertNotNull(turnRequestInput.getUserPOSDTO());
        assertEquals(turnRequestInput.getMode(), Mode.CREATE);
        assertEquals(navigation,SUCCESS);
    }

    @Test
    public void cancelClearsFields(){
        String navigation = turnRequestInput.cancel();
        assertNull(turnRequestInput.getTurnRequestId());
        assertNull(turnRequestInput.getTurnRequest());
        assertEquals(turnRequestInput.getMode(), Mode.CREATE);
        assertEquals(navigation,SUCCESS);
    }

    @Test
    public void viewTurnRequestInitializesComponents() {

        turnRequestInput.setTurnRequestId(ID);
        TurnRequestWithoutContract newTurnRequest = getTurnRequest();

        when(turnRequestService.get(ID)).thenReturn(newTurnRequest);

        String navigation = turnRequestInput.viewTurnRequest();

        assertNotNull(turnRequestInput.getTurnRequest());
        assertEquals(turnRequestInput.getPortId(), newTurnRequest.getDestination().getId());
        assertEquals(turnRequestInput.getCropTypeId(),ID);
        assertTrue(turnRequestInput.isReadOnly());

        assertEquals(SUCCESS, navigation);
    }

    @Test
    public void viewTurnRequestShowsErrorWhenNonExistingId() {

        turnRequestInput.setTurnRequestId(ID);
        when(turnRequestService.get(ID)).thenThrow(new BusinessException("Invalid Id"));

        turnRequestInput.viewTurnRequest();

        assertNull(turnRequestInput.getTurnRequest());
        assertTrue(messages.contains("label.load.turnRequest.error"));
    }

    @Test
    public void retrieveCropTypesWhenErrorOccursAddsErrorMessage(){
        when(materialLasService.findAll()).thenThrow(new BusinessException(ERROR));
        turnRequestInput.begin();
        turnRequestInput.retrieveCropTypes();
        assertThat(messages.isEmpty(), is(false));
    }




    public TurnRequestWithoutContract getTurnRequest() {
        TurnRequestWithoutContract turnRequest = new TurnRequestWithoutContract();
        turnRequest.setCropType(cropType);
        turnRequest.setObservations("OBSERVACIONES");
        turnRequest.setEmailNotification("test@monsanto.com");
        turnRequest.setContractNumber("123456");
        //FIXME POS
        turnRequest.setUserPOS(userPOS);
        turnRequest.setGrower(userGrower);
        turnRequest.setDestination(port);
        turnRequest.setTurnQuantity(40L);
        turnRequest.setTurnRequestDate(new Date());
        return turnRequest;
    }

    @Test
    public void preSaveWithValidationErrors(){
        turnRequestInput.begin();

        TurnRequest turnRequest = getTurnRequest();
        ReflectionTestUtils.setField(turnRequestInput, "turnRequest", turnRequest);

        List<String> validationMessages = new ArrayList<String>();
        validationMessages.add("ERROR");

        when(beanValidator.validate(turnRequest)).thenReturn(validationMessages);

        turnRequestInput.preSave();

        assertThat(messages.contains("ERROR"), is(true));

    }


    @Test
    public void preSaveWithValidationErrorsOnContractExpirationDate(){
        turnRequestInput.begin();

        TurnRequest turnRequest = getTurnRequest();
        turnRequest.setObservations(" ");
        ReflectionTestUtils.setField(turnRequestInput, "turnRequest", turnRequest);
        turnRequestInput.preSave();

        assertThat(messages.contains("turnRequest.contractExpirationDate.observations"), is(true));

    }

    @Test
    public void preSaveWithoutValidationErrors(){
        turnRequestInput.begin();
        TurnRequestWithoutContract turnRequest = getTurnRequest();
        turnRequestInput.setTurnRequest(turnRequest);
        List<String> validationMessages = new ArrayList<String>();
        when(beanValidator.validate(turnRequest)).thenReturn(validationMessages);
        turnRequestInput.preSave();

        assertTrue(messages.isEmpty());
    }


    @Test
    public void saveNewTurnRequest() {
        TurnRequest newTurnRequest = getTurnRequest();
        turnRequestInput.begin();
        String navigation = turnRequestInput.save();

        verify(turnRequestService).save(newTurnRequest);
        assertThat(messages.isEmpty(), is(false));

        assertEquals(SUCCESS, navigation);
    }

    @Test
    public void updateTurnRequest() {

        turnRequestInput.begin();

        turnRequestInput.setTurnRequestId(ID);
        TurnRequestWithoutContract newTurnRequest = getTurnRequest();
        newTurnRequest.setId(ID);
        turnRequestInput.setTurnRequest(newTurnRequest);

        String navigation = turnRequestInput.save();

        verify(turnRequestService).update(newTurnRequest);
        assertThat(messages.contains("label.input.turnRequest.updated" + ID), is(true));

        assertEquals(SUCCESS, navigation);
    }


    @Test
    public void whenSaveThrowsExceptionThenNavigationError(){
        turnRequestInput.begin();

        TurnRequestWithoutContract newTurnRequest = getTurnRequest();
        turnRequestInput.setTurnRequest(newTurnRequest);

        when(turnRequestService.save(newTurnRequest)).thenThrow(new BusinessException(ERROR));

        String navigation = turnRequestInput.save();

        assertEquals(ERROR,navigation);
        assertThat(messages.contains("label.input.turnRequest.creation.error"), is(true));
    }




    @Test
    public void checkDestinationsAvailabilityWithEmptyFields(){
        turnRequestInput.begin();
        List<String> validationMessages = new ArrayList<String>();
        validationMessages.add("ERROR");
        TurnRequestWithoutContract turnRequest = getTurnRequest();
        turnRequest.setCropType(null);
        turnRequestInput.setTurnRequest(turnRequest);
        when(beanValidator.validate(turnRequest, TurnsAvailability.class)).thenReturn(validationMessages);

        turnRequestInput.loadPortDestinationsIfAvailable();

        assertNull(turnRequestInput.getAvailablePorts());

    }


    @Test
    public void checkPortsAvailabilityWhenAvailableTurnsLoadsPortList(){

        turnRequestInput.begin();
        TurnRequestWithoutContract turnRequest = getTurnRequest();
        turnRequestInput.setTurnRequest(turnRequest);
        turnRequestInput.setCropTypeId(turnRequest.getCropTypeId());
        List<PortDestinationDTO> ports = new ArrayList<PortDestinationDTO>();
        ports.add(new PortDestinationDTO(1L,"RAMALLO","30123456789"));
        ports.add(new PortDestinationDTO(2L,"BAHIA BLANCA","30123456789"));
        List<MaterialLas> materials = new ArrayList<MaterialLas>();
        materials.add(cropType);
        turnRequestInput.setMaterialLasList(materials);
        when(turnsService.getPortsForAvailableTurns(turnRequest.getTurnRequestDate(),turnRequest.getCropTypeId())).thenReturn(ports);

        turnRequestInput.loadPortDestinationsIfAvailable();

        assertEquals(ports.size(),turnRequestInput.getAvailablePorts().size());
    }


   @Test
    public void testGetTurnRemnantsQuantity(){

        turnRequestInput.setTurnRequestId(ID);
        TurnRequest newTurnRequest = getTurnRequest();

        when(turnRequestService.get(ID)).thenReturn(newTurnRequest);

        turnRequestInput.viewTurnRequest();

        assertEquals(40L, turnRequestInput.getTurnRemnantsQuantity());

        Set<Turn> turns= new HashSet<Turn>();
        turns.add(new Turn());
        newTurnRequest.setTurns(turns);

        assertEquals(39L, turnRequestInput.getTurnRemnantsQuantity());
    }


    @Test
    public void testGetTurnsList(){

        turnRequestInput.setTurnRequestId(ID);
        TurnRequest newTurnRequest = getTurnRequest();

        Set<Turn> turns= new HashSet<Turn>();

        Calendar myCalendar = GregorianCalendar.getInstance();
        myCalendar.set(2014,Calendar.SEPTEMBER,16);

        Turn turn1 = new Turn();
        turn1.setTurnDate(myCalendar.getTime());
        turn1.setId(1l);
        turns.add(turn1);

        Turn turn2 = new Turn();
        turn2.setTurnDate(myCalendar.getTime());
        turn2.setId(2l);
        turns.add(turn2);


        Calendar myCalendar2 = GregorianCalendar.getInstance();
        myCalendar2.set(2014,Calendar.SEPTEMBER,17);

        Turn turn3 = new Turn();
        turn3.setTurnDate(myCalendar2.getTime());
        turn3.setId(3l);
        turns.add(turn3);

        newTurnRequest.setTurns(turns);

        when(turnRequestService.get(ID)).thenReturn(newTurnRequest);

        turnRequestInput.viewTurnRequest();


    }

    @Test
    public void testPostProcessXLS(){
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();

        turnRequestInput.setTurnRequestId(ID);

        TurnRequestWithoutContract newTurnRequest = mock(TurnRequestWithoutContract.class);
        when(newTurnRequest.getId()).thenReturn(1l);

        when(newTurnRequest.getCreatedDate()).thenReturn(new Date());
        when(newTurnRequest.getStatus()).thenReturn(TurnRequestStatus.ASSIGNED);
        when(newTurnRequest.getContractNumber()).thenReturn("123456");
        when(newTurnRequest.getContractExpirationDate()).thenReturn(new Date());
        when(newTurnRequest.isLaTijereta()).thenReturn(true);
        when(newTurnRequest.getTurnQuantity()).thenReturn(1l);
        when(newTurnRequest.getTurnRequestDate()).thenReturn(new Date());

        when(newTurnRequest.getDestination()).thenReturn(port);

        when(userGrower.getDescription()).thenReturn("growerDesc");
        when(newTurnRequest.getGrower()).thenReturn(userGrower);

        when(userPOS.getCustomer()).thenReturn(userGrower);
        when(newTurnRequest.getUserPOS()).thenReturn(userPOS);

        when(cropType.getCommercialText()).thenReturn("cropType");
        when(newTurnRequest.getCropType()).thenReturn(cropType);

        when(turnRequestService.get(ID)).thenReturn(newTurnRequest);

        turnRequestInput.viewTurnRequest();

        turnRequestInput.postProcessXLS(document);

    }

    @Test
    public void handlePointOfSaleSelectFillsMail(){
        turnRequestInput.begin();
        SelectEvent selectEvent = mock(SelectEvent.class);
        PointOfSaleDTO posDto = new PointOfSaleDTO(1L, "", "", null, "", "test@mail.com");
        when(selectEvent.getObject()).thenReturn(posDto);
        turnRequestInput.handlePointOfSaleSelect(selectEvent);
        assertEquals(posDto.getEmail(),turnRequestInput.getTurnRequest().getEmailNotification());
        assertEquals(posDto,turnRequestInput.getUserPOSDTO());
    }

}
