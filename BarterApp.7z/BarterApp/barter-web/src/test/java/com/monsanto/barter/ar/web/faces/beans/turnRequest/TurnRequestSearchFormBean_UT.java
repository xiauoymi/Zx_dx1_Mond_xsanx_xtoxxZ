package com.monsanto.barter.ar.web.faces.beans.turnRequest;

import com.google.common.collect.Maps;
import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.architecture.business.exception.BusinessException;
import com.monsanto.barter.ar.business.entity.MaterialLas;
import com.monsanto.barter.ar.business.entity.TurnRequest;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.PointOfSaleDTO;
import com.monsanto.barter.ar.business.service.dto.PortDestinationDTO;
import com.monsanto.barter.ar.business.service.dto.TurnRequestDTO;
import com.monsanto.barter.ar.web.faces.beans.turnRequest.datamodel.TurnRequestDataModel;
import com.monsanto.barter.ar.web.faces.composite.CustomerCC;
import com.monsanto.barter.web.test.TransactionTemplateMocker;
import junit.framework.Assert;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by JASANC5 on 8/1/2014.
 */
public class TurnRequestSearchFormBean_UT {

    @Mock
    private TurnRequestService turnRequestService;

    @Mock
    private BeanFactory beanFactoryMock;

    @Mock
    private TurnRequestDataModel searchResult;

    private TurnRequestSearchFormBean turnRequestSearchFormBean;

    private final String SUCCESS = "success";

    private TransactionTemplateMocker transactionTemplate;
    private ArrayList<String> messages;

    @Mock
    private MaterialLasService materialLasService;

    @Mock
    private PortService portService;

    @Mock
    private PointOfSaleDTO pointOfSaleDTO;

    private List<MaterialLas> materialLasList;

    @Before
    public void setUp() {
        initMocks(this);

        long materialLasId = 1L;
        MaterialLas materialLas = new MaterialLas();
        ReflectionTestUtils.setField(materialLas, "id", materialLasId);
        materialLasList = Arrays.asList(materialLas);

        messages = new ArrayList<String>();

        transactionTemplate = new TransactionTemplateMocker();

        turnRequestSearchFormBean = new TurnRequestSearchFormBean(){

            @Override
            protected void addMessage(Throwable throwable) {
                messages.add(throwable.getMessage());
            }

            @Override
            protected void addMessage(String message){
                messages.add(message);
            }

            public BeanFactory getBeanFactory() {
                return beanFactoryMock;
            }

            @Override
            public TransactionTemplate getTransactionTemplate() {
                return transactionTemplate;
            }

            @Override
            public String getMessageBundle(String key){
                return key;
            }

            @Override
            protected void addMessageNoError(String message){
                messages.add(message);
            }



        };

        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(PortService.class)).thenReturn(portService);
        when(beanFactoryMock.getBean(PointOfSaleDTO.class)).thenReturn(pointOfSaleDTO);

    }

    @Test
    public void testClassInstance() {
        turnRequestSearchFormBean = new TurnRequestSearchFormBean();
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.setIgnoredFields("turnRequestStatuses");
        tester.testInstance(turnRequestSearchFormBean);
    }

    @Test
    public void beginMethodInitializesAttributes() {
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        String navigation = turnRequestSearchFormBean.begin();
        assertNotNull(turnRequestSearchFormBean.getTurnRequestFilter());
        assertNotNull(turnRequestSearchFormBean.getMaterialLasList());
        assertTrue(turnRequestSearchFormBean.getMaterialLasList().size() == 1);
        assertEquals(SUCCESS, navigation);
    }

    @Test
    public void searchByTurnRequestMethodInitializesSearchResult() {
        setupTurnrequestFilter();
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        when(beanFactoryMock.getBean(PointOfSaleDTO.class)).thenReturn(pointOfSaleDTO);
        turnRequestSearchFormBean.setMaterialLasList(materialLasList);
        String navigation = turnRequestSearchFormBean.search();
        assertNotNull(turnRequestSearchFormBean.getSearchResult());
        assertTrue(turnRequestSearchFormBean.getSearchResult().getRowCount() == 0);
        assertEquals(TurnRequestSearchFormBean.PAGE_SEARCH_RESULT, navigation);
    }

    @Test
    public void testClear(){
        setupTurnrequestFilter();
        turnRequestSearchFormBean.clear();
        assertFalse(("123456").equals(turnRequestSearchFormBean.getTurnRequestFilter().getContractNumber()));
    }

    @Test
    public void postProcessXLS() {
        setupTurnrequestFilter();
        Map<ReportMetadata, Long> reportMetadata = Maps.newHashMap();

        HSSFWorkbook document = buildWorkbook();
        turnRequestSearchFormBean.setSearchResult(searchResult);
        when(searchResult.getRowCount()).thenReturn(3);

        turnRequestSearchFormBean.postProcessXLS(document);
    }

    private HSSFWorkbook buildWorkbook() {
        HSSFWorkbook document = new HSSFWorkbook();
        HSSFSheet sheet = document.createSheet();
        for (int rowNum = 0; rowNum <3; rowNum++) {
            HSSFRow row_0 = sheet.createRow(rowNum);
            for (int column = 0; column <= 15; column++) {
                row_0.createCell(0).setCellValue(rowNum + "_" + column);
            }
        }
        return document;
    }


    private void setupTurnrequestFilter(){
        TurnRequestFilter filter = new TurnRequestFilter();
        filter.setContractNumber("123456");
        turnRequestSearchFormBean.setTurnRequestFilter(filter);
    }

    @Test
    public void selectRow(){
        TurnRequestDTO turnRequestDTO = new TurnRequestDTO();
        turnRequestDTO.setId(1L);
        turnRequestSearchFormBean.setSearchResult(searchResult);
        when(turnRequestSearchFormBean.getSearchResult().getRowData()).thenReturn(turnRequestDTO);
        turnRequestSearchFormBean.selectedRow();
        Assert.assertNotNull(turnRequestSearchFormBean.getTurnRequestId());
        Assert.assertNotNull(turnRequestSearchFormBean.getTurnRequestId().equals(1L));
    }

    @Test
    public void cancelTurnRequest(){

        TurnRequest turnRequest = new TurnRequest();
        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        turnRequestSearchFormBean.setTurnRequestId(1L);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        turnRequestSearchFormBean.begin();
        when(turnRequestService.get(1L)).thenReturn(turnRequest);
        setupTurnrequestFilter();
        when(beanFactoryMock.getBean(PointOfSaleDTO.class)).thenReturn(pointOfSaleDTO);

        turnRequestSearchFormBean.cancelTurnRequest();

        assertThat(messages.isEmpty(), is(false));
        verify(turnRequestService).delete(turnRequest);

    }

    @Test
    public void cancelTurnRequestThrowsBusinessException(){
        String error = "error";

        TurnRequest turnRequest = new TurnRequest();
        when(beanFactoryMock.getBean(TurnRequestService.class)).thenReturn(turnRequestService);
        turnRequestSearchFormBean.setCancelReason("cancel reason");
        turnRequestSearchFormBean.setTurnRequestId(1L);
        doThrow(new BusinessException(error)).when(turnRequestService).delete(turnRequest);
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        turnRequestSearchFormBean.begin();
        when(turnRequestService.get(1L)).thenReturn(turnRequest);
        turnRequestSearchFormBean.cancelTurnRequest();
        assertThat(messages.isEmpty(), is(false));
        assertThat(messages.contains(error), is(true));
        assertThat(transactionTemplate.isExecutionRollbacked(), is(true));

    }

    @Test
    public void autocompletePortDestinationsWithNoResults(){
        String non_exist_port = "NON_EXIST_PORT";
        when(beanFactoryMock.getBean(MaterialLasService.class)).thenReturn(materialLasService);
        when(materialLasService.findAll()).thenReturn(materialLasList);
        when(portService.search(non_exist_port)).thenReturn(new ArrayList<PortDestinationDTO>());
        turnRequestSearchFormBean.begin();
        List<PortDestinationDTO> result = turnRequestSearchFormBean.autocomplete(non_exist_port);
        Assert.assertTrue(result.isEmpty());
    }
}
