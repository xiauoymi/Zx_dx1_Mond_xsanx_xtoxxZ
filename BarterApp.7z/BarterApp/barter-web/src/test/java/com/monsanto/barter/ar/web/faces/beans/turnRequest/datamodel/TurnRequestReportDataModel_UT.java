package com.monsanto.barter.ar.web.faces.beans.turnRequest.datamodel;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.service.*;
import com.monsanto.barter.ar.business.service.dto.TurnRequestReportDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.primefaces.model.SortOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created with IntelliJ IDEA.
 * User: PSAND
 * Date: 17/10/14
 * Time: 11:09
 * To change this template use File | Settings | File Templates.
 */
public class TurnRequestReportDataModel_UT {
    public static final Long EXISTING_DTO_ID = 1L;
    @Mock
    private TurnRequestService service;

    private TurnRequestFilter filter;
    private TurnRequestReportDataModel dataModel;
    private List<TurnRequestReportDTO> page;

    @Before
    public void setUp() {
        initMocks(this);
        filter = new TurnRequestFilter();
        page = new ArrayList<TurnRequestReportDTO>();
        dataModel = new TurnRequestReportDataModel(service, filter);
        setField(dataModel, "page", page);
    }

    @Test
    public void loadWithAscendingSortField(){
        SortOrder sortOrder = SortOrder.ASCENDING;
        prepareLoadWithSortFieldTest(sortOrder, Paging.SortOrder.ASC);
    }

    @Test
    public void loadWithDescendingSortField(){
        SortOrder sortOrder = SortOrder.DESCENDING;
        prepareLoadWithSortFieldTest(sortOrder,Paging.SortOrder.DESC);
    }

    private void prepareLoadWithSortFieldTest(SortOrder sortOrder,Paging.SortOrder expectedSortOrder) {
        int first = 0;
        int pageSize = 0;
        String sortField = "id";
        Map<String,String> filters = null;
        Recordset<TurnRequestReportDTO> recordset = new Recordset<TurnRequestReportDTO>(new ArrayList<TurnRequestReportDTO>(), EXISTING_DTO_ID);

        ArgumentCaptor<Paging> pagingCaptor = ArgumentCaptor.forClass(Paging.class);
        when(service.searchForExport(eq(filter), pagingCaptor.capture())).thenReturn(recordset);

        List<TurnRequestReportDTO> loadResult = dataModel.load(first, pageSize, sortField, sortOrder, filters);

        assertThat(loadResult, is(recordset.getRecords()));
        assertThat(dataModel.getRowCount(), is(1));

        Paging paging = pagingCaptor.getValue();
        assertThat(paging.getFirst(), is((long)first));
        assertThat(paging.getPageSize(), is(pageSize));
        assertThat(paging.getSortOrder(), is(expectedSortOrder));
        assertThat(paging.getSortField(), is(sortField));
    }

    @Test
    public void getRowKeyMatches() {
        TurnRequestReportDTO turnRequestReportDTO = new TurnRequestReportDTO();
        turnRequestReportDTO.setId(EXISTING_DTO_ID);
        assertThat(dataModel.getRowKey(turnRequestReportDTO), is((Object) EXISTING_DTO_ID.toString()));
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        tester.testInstance(new TurnRequestReportDataModel(service, filter));
    }
}
