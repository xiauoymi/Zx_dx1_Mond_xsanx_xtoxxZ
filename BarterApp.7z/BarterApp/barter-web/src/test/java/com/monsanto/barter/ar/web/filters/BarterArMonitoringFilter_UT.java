package com.monsanto.barter.ar.web.filters;

import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * @author JPBENI
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({GlobalBarterSecurityHelper.class})
public class BarterArMonitoringFilter_UT {
    @Mock
    public UserDecorator userDecorator;

    public BarterArMonitoringFilter filter;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        filter = new BarterArMonitoringFilter();
        mockStatic(GlobalBarterSecurityHelper.class);
        when(GlobalBarterSecurityHelper.getLoggedInUser()).thenReturn(userDecorator);
    }

    @Test
    public void testSuperUserCanToggleMonitoring() {
        when(userDecorator.isSuper()).thenReturn(true);
        when(userDecorator.isAdministrator()).thenReturn(false);
        assertThat(filter.loggedUserCanToggleMonitoring(), is(true));
    }

    @Test
    public void testAdminUserCanToggleMonitoring() {
        when(userDecorator.isSuper()).thenReturn(false);
        when(userDecorator.isAdministrator()).thenReturn(true);
        assertThat(filter.loggedUserCanToggleMonitoring(), is(true));
    }

    @Test
    public void testNonAdminNorSuperUsersCannotToggleMonitoring() {
        when(userDecorator.isSuper()).thenReturn(false);
        when(userDecorator.isAdministrator()).thenReturn(false);
        assertThat(filter.loggedUserCanToggleMonitoring(), is(false));
    }
}
