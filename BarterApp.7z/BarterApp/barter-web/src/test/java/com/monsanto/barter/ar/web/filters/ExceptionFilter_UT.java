package com.monsanto.barter.ar.web.filters;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static junit.framework.Assert.fail;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doThrow;

/**
 * @author JPBENI
 */
public class ExceptionFilter_UT {

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    private FacesContext mockedFacesContext;
    private String contextPath = "http://localhost:8080/barter";
    private ExceptionFilter filter;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    public ExceptionFilter newFilterWithFacesContext() {
        mockedFacesContext = mock(FacesContext.class);
        return new ExceptionFilter() {
            protected FacesContext getFacesContext() {
                return mockedFacesContext;
            }

            protected String getContextPath() {
                return null;
            }
        };
    }

    public ExceptionFilter newFilterWithoutFacesContext() {
        return new ExceptionFilter() {
            protected FacesContext getFacesContext() {
                return null;
            }

            protected String getContextPath() {
                return contextPath;
            }
        };
    }

    @Test
    public void doFilterInternal() throws Exception{
        filter = newFilterWithFacesContext();
        filterChain.doFilter(request, response);
        try {
            filter.doFilterInternal(request, response, filterChain);
        } catch (Exception ex) {
            fail("No exceptions should be thrown.");
        }
    }

    @Test
    public void doFilterInternalFailWithFacesContext() throws Exception{
        ArgumentCaptor<FacesMessage> messageCaptor = ArgumentCaptor.forClass(FacesMessage.class);
        filter = newFilterWithFacesContext();
        Exception exception = new RuntimeException("something.went.terribly.wrong");
        doThrow(exception).when(filterChain).doFilter(request, response);
        try {
            filter.doFilterInternal(request, response, filterChain);
        } catch (Exception ex) {
            fail("No exceptions should be thrown.");
        }
        verify(mockedFacesContext).addMessage(isNull(String.class), messageCaptor.capture());
        FacesMessage message = messageCaptor.getValue();
        assertThat(message.getDetail(), is("generic.error"));
        assertThat(message.getSeverity(), is(FacesMessage.SEVERITY_FATAL));
    }

    @Test
    public void doFilterInternalFailWithoutFacesContext() throws Exception{
        String redirectUrl = "http://localhost:8080/barter/redirectUrl";
        filter = newFilterWithoutFacesContext();
        Exception exception = new RuntimeException("something.went.terribly.wrong");
        doThrow(exception).when(filterChain).doFilter(request, response);
        when(response.encodeRedirectURL(startsWith(contextPath))).thenReturn(redirectUrl);
        try {
            filter.doFilterInternal(request, response, filterChain);
        } catch (Exception ex) {
            fail("No exceptions should be thrown.");
        }
        verify(response).sendRedirect(redirectUrl);
    }
}
