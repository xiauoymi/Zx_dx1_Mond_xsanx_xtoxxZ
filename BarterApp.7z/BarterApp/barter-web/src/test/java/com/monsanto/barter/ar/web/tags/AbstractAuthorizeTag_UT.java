package com.monsanto.barter.ar.web.tags;

import com.google.common.collect.Lists;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.util.Collection;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AbstractAuthorizeTag_UT {
    private AbstractAuthorizeTag abstractAuthorizeTag;
    private UserDecorator userDecorator;

    @Before
    public void setUp() {
        this.abstractAuthorizeTag = newAbstractAuthorizeTag();

        SecurityContext securityContext = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);
        userDecorator = mock(UserDecorator.class);

        SecurityContextHolder.setContext(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(userDecorator);
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityOneDoesNotGrantAccess_WhenGrantedAuthorityTwo() {
        // @Given any granted text containing authority one and a principal containing authority two
        this.abstractAuthorizeTag.setIfAnyGranted("one");
        // GrantedAuthority[] grantedAuthorities = makeGrantedAuthoritiesArray("two");

        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");

        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityOneAndTwoDoesNotGrantAccess_WhenGrantedAuthorityTwo() {
        // @Given any granted text containing authority one and a principal containing authority two
        this.abstractAuthorizeTag.setIfAnyGranted("one, two");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityMenuMainDoesNotGrantAccess_WhenGrantedAuthorityMenuMainFeatureCreate() {
        // @Given any granted text containing authority menu.main and a principal containing authority menu.main.feature.create
        this.abstractAuthorizeTag.setIfAnyGranted("menu.main");

        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.create");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityOneGrantsAccess_WhenGrantedAuthorityOne() {
        // @Given any granted text containing authority one and a principal containing authority one
        this.abstractAuthorizeTag.setIfAnyGranted("one");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("one");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthoritySelectBillingGrantsAccess_WhenGrantedAuthoritySelectBilling() {
        // @Given any granted text containing authority menu.main.feature.billing.feature.action.select and a principal containing authority menu.main.feature.billing.feature.action.select
        this.abstractAuthorizeTag.setIfAnyGranted("menu.main.feature.billing.feature.action.select");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.billing.feature.action.select");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityWithWildCardThatMatchesOneGrantsAccess_WhenGrantedAuthorityOne() {
        // @Given match any granted text containing a regex that matches any authority statring with on and a granted authority one
        this.abstractAuthorizeTag.setIfAnyGranted("regex:on.*");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("one");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityWithDotsAndWildCardThatMatchesMenuBillingGrantsAccess_WhenGrantedAuthorityMenuBillingSelectAction() {
        // @Given match any granted text containing a regex that matches any authority statring with menu.billing. and a granted authority menu.billing.feature.create.feature.action.edit
        this.abstractAuthorizeTag.setIfAnyGranted("regex:menu\\.billing\\..*");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.billing.feature.create.feature.action.edit");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAnyGrantedAuthorityWithDotsAndWildCardThatMatchesMenuPaymentDoesNotGrantsAccess_WhenGrantedAuthorityMenuBillingSelectAction() {
        // @Given match any granted text containing a regex that matches any authority statring with menu.billing. and a granted authority menu.billing.feature.create.feature.action.edit
        this.abstractAuthorizeTag.setIfAnyGranted(AbstractAuthorizeTag.REGEX_PREFIX + "menu\\.payment\\..*");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.billing.feature.create.feature.action.edit");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAllGrantedAuthorityOneDoesNotGrantAccess_WhenGrantedAuthorityTwo() {
        // @Given all granted text containing authority one and a principal containing authority two
        this.abstractAuthorizeTag.setIfAllGranted("one");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAllGrantedAuthorityOneAndTwoDoesNotGrantAccess_WhenGrantedAuthorityTwo() {
        // @Given all granted text containing authority one and two, and a principal containing authority two
        this.abstractAuthorizeTag.setIfAllGranted("one, two");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAllGrantedAuthorityMenuMainDoesNotGrantAccess_WhenGrantedAuthorityMenuMainFeatureCreate() {
        // @Given all granted text containing authority menu.main and a principal containing authority menu.main.feature.create
        this.abstractAuthorizeTag.setIfAllGranted("menu.main");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.create");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAllGrantedAuthorityOneGrantsAccess_WhenGrantedAuthorityOne() {
        // @Given all granted text containing authority one and a principal containing authority one
        this.abstractAuthorizeTag.setIfAllGranted("one, two");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("one", "two", "three");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithAllGrantedAuthoritySelectBillingGrantsAccess_WhenGrantedAuthoritySelectBilling() {
        // @Given all granted text containing authority menu.main.feature.billing.feature.action.select and a principal containing authority menu.main.feature.billing.feature.action.select
        this.abstractAuthorizeTag.setIfAllGranted("menu.main.feature.billing.feature.action.select");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.billing.feature.action.select");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithNotGrantedAuthorityOneGrantsAccess_WhenGrantedAuthorityTwo() {
        // @Given not granted text containing authority one and a principal containing authority two
        this.abstractAuthorizeTag.setIfNotGranted("one");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithNotGrantedAuthorityOneAndTwoDoesNotGrantAccess_WhenGrantedAuthorityTwo() {
        // @Given not granted text containing authority one and two, and a principal containing authority two
        this.abstractAuthorizeTag.setIfNotGranted("one, two");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("two");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithNotGrantedAuthorityMenuMainGrantsAccess_WhenGrantedAuthorityMenuMainFeatureCreate() {
        // @Given not granted text containing authority menu.main and a principal containing authority menu.main.feature.create
        this.abstractAuthorizeTag.setIfNotGranted("menu.main");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.create");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is granted
        assertThat(isAuthorized).isTrue();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithNotGrantedAuthorityOneDoesNotGrantsAccess_WhenGrantedAuthorityOne() {
        // @Given all granted text containing authority one and a principal containing authority one
        this.abstractAuthorizeTag.setIfNotGranted("one, two");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("one", "two", "three");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeUsingGrantedAuthoritiesWithNotGrantedAuthoritySelectBillingDoesNotGrantsAccess_WhenGrantedAuthoritySelectBilling() {
        // @Given not granted text containing authority menu.main.feature.billing.feature.action.select and a principal containing authority menu.main.feature.billing.feature.action.select
        this.abstractAuthorizeTag.setIfNotGranted("menu.main.feature.billing.feature.action.select");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray("menu.main.feature.billing.feature.action.select");
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isFalse();
    }

    @Test
    public void testAuthorizeGrantsAccess_WhenUserIsSuperUser() {
        // @Given a super user
        this.abstractAuthorizeTag.setIfAnyGranted("menu.main.feature.billing.feature.action.select");
        this.abstractAuthorizeTag.setIfAllGranted("menu.main.feature.billing.feature.action.edit");
        Collection<GrantedAuthority> grantedAuthorities = makeGrantedAuthoritiesArray(AbstractAuthorizeTag.ROLE_SUPER);
        when(userDecorator.getAuthorities()).thenReturn(grantedAuthorities);

        // @When authorizing using granted authorities
        boolean isAuthorized = this.abstractAuthorizeTag.authorize();

        // @Then authorization is denied
        assertThat(isAuthorized).isTrue();
    }

    private Collection<GrantedAuthority> makeGrantedAuthoritiesArray(String... roles) {
        List<GrantedAuthority> grantedAuthorityList = Lists.newArrayList();

        for (String role : roles) {
            GrantedAuthority grantedAuthority = new GrantedAuthorityImpl(role);
            grantedAuthorityList.add(grantedAuthority);
        }

        return grantedAuthorityList;
    }

    private AbstractAuthorizeTag newAbstractAuthorizeTag() {
        return new AbstractAuthorizeTag() {
            @Override
            protected ServletRequest getRequest() {
                return null;  //To change body of implemented methods use File | Settings | File Templates.
            }

            @Override
            protected ServletResponse getResponse() {
                return null;  //To change body of implemented methods use File | Settings | File Templates.
            }

            @Override
            protected ServletContext getServletContext() {
                return null;  //To change body of implemented methods use File | Settings | File Templates.
            }
        };
    }

    @After
    public void clearContext() {
        SecurityContextHolder.clearContext();
    }
}

