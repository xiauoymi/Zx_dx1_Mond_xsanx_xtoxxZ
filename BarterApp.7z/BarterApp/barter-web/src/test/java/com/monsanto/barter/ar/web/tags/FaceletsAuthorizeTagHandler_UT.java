package com.monsanto.barter.ar.web.tags;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.business.entity.GlobalBarterUser;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.Times;
import org.mockito.verification.VerificationMode;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import weblogic.security.Security;

import javax.faces.view.Location;
import javax.faces.view.facelets.*;

// import com.sun.faces.facelets.compiler.

import java.io.IOException;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.powermock.api.mockito.PowerMockito.mock;

@RunWith(PowerMockRunner.class)
@PrepareForTest({GlobalBarterSecurityHelper.class, FaceletsAuthorizeTag.class})
public class FaceletsAuthorizeTagHandler_UT {
    private TagConfig tagConfig;

    @Before
    public void setup() {
        tagConfig = new TagConfig() {
            @Override
            public Tag getTag() {
                Location location = new Location("tag", 1, 3);
                TagAttributes tagAttributes = new TagAttributes() {
                    @Override
                    public TagAttribute[] getAll() {
                        return new TagAttribute[0];
                    }

                    @Override
                    public TagAttribute get(String localName) {
                        return null;
                    }

                    @Override
                    public TagAttribute get(String ns, String localName) {
                        return null;
                    }

                    @Override
                    public TagAttribute[] getAll(String namespace) {
                        return new TagAttribute[0];  //To change body of implemented methods use File | Settings | File Templates.
                    }

                    @Override
                    public String[] getNamespaces() {
                        return new String[0];
                    }
                };
                return new Tag(location, "", "", "", tagAttributes);

            }

            @Override
            public FaceletHandler getNextHandler() {
                return null;
            }

            @Override
            public String getTagId() {
                return null;
            }
        };    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        FaceletsAuthorizeTagHandler entity = new FaceletsAuthorizeTagHandler(tagConfig);
        tester.testInstance(entity);
    }

    @Test
    public void testInstanceWithSuperClass() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        FaceletsAuthorizeTagHandler entity = new FaceletsAuthorizeTagHandler(tagConfig);
        tester.testInstanceWithSuperClass(entity);
    }

    @Test
    public void applyWhenUserIsNull() throws Exception {
        PowerMockito.mockStatic(GlobalBarterSecurityHelper.class);
        PowerMockito.when(GlobalBarterSecurityHelper.getLoggedInUser()).thenReturn(null);
        FaceletsAuthorizeTagHandler entity = new FaceletsAuthorizeTagHandler(tagConfig);
        PowerMockito.whenNew(FaceletsAuthorizeTag.class).withArguments(anyObject(), anyObject(), anyObject(),
                anyObject(), anyObject(), anyObject(), anyObject()).thenReturn(null);

        entity.apply(null, null);

        PowerMockito.verifyNew(FaceletsAuthorizeTag.class, new Times(0));
    }

    @Test
    public void applyWhenUserIsNotNull() throws Exception {
        PowerMockito.mockStatic(GlobalBarterSecurityHelper.class);
        UserDecorator userDecorator = mock(UserDecorator.class);
        PowerMockito.when(GlobalBarterSecurityHelper.getLoggedInUser()).thenReturn(userDecorator);
        FaceletsAuthorizeTagHandler entity = new FaceletsAuthorizeTagHandler(tagConfig);
        PowerMockito.whenNew(FaceletsAuthorizeTag.class).withArguments(anyObject(), anyObject(), anyObject(),
                anyObject(), anyObject(), anyObject(), anyObject()).thenReturn(null);

        entity.apply(null, null);

        PowerMockito.verifyNew(FaceletsAuthorizeTag.class, new Times(1));
    }

}
