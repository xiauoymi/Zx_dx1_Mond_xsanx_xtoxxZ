package com.monsanto.barter.ar.web.tags;

import com.monsanto.barter.GetterAndSetterTester;
import com.monsanto.barter.ar.web.faces.beans.addinput.AddDetail;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.IOException;

public class FaceletsAuthorizeTagUtils_UT {
    @Test
    public void testAreAllGranted() {
        try {
            assertNotNull(FaceletsAuthorizeTagUtils.areAllGranted(""));
        } catch (IOException e) {
            fail();
        }
    }

    @Test
    public void testAreAnyGranted() {
        try {
            assertNotNull(FaceletsAuthorizeTagUtils.areAnyGranted(""));
        } catch (IOException e) {
            fail();
        }
    }

    @Test
    public void testAreNotGranted() {
        try {
            assertNotNull(FaceletsAuthorizeTagUtils.areNotGranted(""));
        } catch (IOException e) {
            fail();
        }
    }

    @Test
    public void testIsAllowed() {
        try {
            assertNotNull(FaceletsAuthorizeTagUtils.isAllowed("", ""));
        } catch (IOException e) {
            fail();
        }
    }
}
