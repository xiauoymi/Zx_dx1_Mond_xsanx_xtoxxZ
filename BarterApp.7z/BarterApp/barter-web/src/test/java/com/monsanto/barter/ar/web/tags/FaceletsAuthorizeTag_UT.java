package com.monsanto.barter.ar.web.tags;

import com.monsanto.barter.GetterAndSetterTester;
import com.sun.faces.facelets.tag.TagAttributeImpl;
import org.apache.myfaces.test.el.MockExpressionFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.el.ELContext;
import javax.faces.context.FacesContext;
import javax.faces.view.Location;
import javax.faces.view.facelets.FaceletContext;

import static org.mockito.Mockito.when;
import static org.junit.Assert.*;

public class FaceletsAuthorizeTag_UT {
    @Mock
    FaceletContext faceletContext;

    @Mock
    private FacesContext facesContext;

    @Mock
    private ELContext elContext;

/*
    private FacesContext ctx = null;
*/

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        FaceletsAuthorizeTag entity = new FaceletsAuthorizeTag();
        tester.testInstance(entity);
    }

    @Test
    public void testInstanceWithSuperClass() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        FaceletsAuthorizeTag entity = new FaceletsAuthorizeTag();
        tester.testInstanceWithSuperClass(entity);
    }

    @Test
    public void testXXX() {
        TagAttributeImpl tagAttribute = new TagAttributeImpl(new Location("", 1, 1), "", "", "", "");
        when(faceletContext.getExpressionFactory()).thenReturn(new MockExpressionFactory());
        when(faceletContext.getFacesContext()).thenReturn(facesContext);
        when(facesContext.getELContext()).thenReturn(elContext);

        FaceletsAuthorizeTag faceletsAuthorizeTag = new FaceletsAuthorizeTag(faceletContext, tagAttribute, tagAttribute, tagAttribute, tagAttribute, tagAttribute, tagAttribute);
        assertNotNull(faceletsAuthorizeTag);
        // faceletsAuthorizeTag.getRequest();
        // faceletsAuthorizeTag.getResponse();
        // faceletsAuthorizeTag.getServletContext();
    }
}
