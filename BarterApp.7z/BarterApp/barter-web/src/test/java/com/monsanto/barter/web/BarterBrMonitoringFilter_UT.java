package com.monsanto.barter.web;

import com.monsanto.barter.architecture.security.helper.SecurityHelper;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.User;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.web.filters.BarterBrMonitoringFilter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by RECRUZ on 10/8/2014.
 */
@RunWith(PowerMockRunner.class)
public class BarterBrMonitoringFilter_UT {

    @Mock
    public SecurityHelper securityHelper ;

    @Mock
    public IUserService userService;

    public BarterBrMonitoringFilter filter;

    String APPLICATION_USER = "APPLICATION_USER";
    Long IT_SUPPORT_GROUP = 10L;
    Long COMMODITIES_APPROVERS = 6L;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        filter = new BarterBrMonitoringFilter() {

            @Override
            public SecurityHelper getSecurityHelper() {
                return securityHelper;
            }

            @Override
            public IUserService getUserService() {
                return userService;
            }
        };
    }

    @Test
    public void testItSupportCanToggleMonitoring() {
        User userEntity= new User();
        userEntity.setUserIdMonsanto(APPLICATION_USER);
        Group group = new Group();
        group.setId(IT_SUPPORT_GROUP);
        userEntity.setGroup(group);
        when(securityHelper.getLoggedInUser()).thenReturn(APPLICATION_USER);
        when(userService.findByIdMonsantoWithPermission(userEntity)).thenReturn(userEntity);
        assertThat(filter.loggedUserCanToggleMonitoring(), is(true));
    }

    @Test
    public void testNonItSupportsCannotToggleMonitoring() {
        User userEntity= new User();
        userEntity.setUserIdMonsanto(APPLICATION_USER);
        Group group = new Group();
        group.setId(COMMODITIES_APPROVERS);
        userEntity.setGroup(group);
        when(securityHelper.getLoggedInUser()).thenReturn(APPLICATION_USER);
        when(userService.findByIdMonsantoWithPermission(userEntity)).thenReturn(userEntity);
        assertThat(filter.loggedUserCanToggleMonitoring(), is(false));
    }
}
