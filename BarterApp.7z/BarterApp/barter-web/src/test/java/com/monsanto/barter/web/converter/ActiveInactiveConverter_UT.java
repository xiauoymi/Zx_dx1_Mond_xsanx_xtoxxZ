package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;


/**
 * Created by IntelliJ IDEA.
 * User: ntarduc
 * Date: 10/17/12
 * Time: 12:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActiveInactiveConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String ACTIVE = "Active";
    private static final String INACTIVE = "Inactive";
    private static final String YES  = "Y";
    private static final String ACTIVE_S  = "S";
    private static final String ACTIVE_N  = "N";
    private static final Character Y  = 'S';
    private static final Character N  = 'N';
    private static final Character X  = 'X';

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getAsObjectValidTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        Character charValue = activeInactiveConverter.getAsObject(ctx, new UICommand(), ACTIVE_S);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Y));
    }

    @Test
	public void getAsObjectValidNotTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        Character charValue = activeInactiveConverter.getAsObject(ctx, new UICommand(), ACTIVE_N);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(N));
    }

    @Test
	public void getAsObjectNotValidTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        Character charValue = activeInactiveConverter.getAsObject(ctx, new UICommand(), YES);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.toString().equals(YES));
    }

    @Test
	public void getAsStringValidActiveTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        String value = activeInactiveConverter.getAsString(ctx, new UICommand(), Y);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(ACTIVE));
    }

    @Test
	public void getAsStringValidInactiveTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        String value = activeInactiveConverter.getAsString(ctx, new UICommand(), N);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(INACTIVE));
    }

    @Test
	public void getAsStringNotValidTest() {
        ActiveInactiveConverter activeInactiveConverter = new ActiveInactiveConverter();
        String value = activeInactiveConverter.getAsString(ctx, new UICommand(), X);
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
