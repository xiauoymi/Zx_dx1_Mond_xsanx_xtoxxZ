package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: ntarduc
 * Date: 10/17/12
 * Time: 12:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class BarterTypeConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String YES  = "Y";
    private static final String AVAILABLE_GRAIN = "Available Grain";
    private static final String FUTURE_WITH_EXISTING_CONTRACT  = "Future with existing contract";
    private static final String FUTURE_MONSANTO_MANAGES_CONTRACT  = "Future Monsanto manages contract";
    private static final String TERMS  = "Terms";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidAvailableGrainAsObjectTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        Character charValue = barterTypeConverter.getAsObject(ctx, new UICommand(), "barter.type.grain.available");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('1')));
    }

    @Test
	public void getValidFutureWithExistingContractAsObjectTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        Character charValue = barterTypeConverter.getAsObject(ctx, new UICommand(), "barter.type.future.existing.contract");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('2')));
    }

    @Test
	public void getValidFutureMonsantoManagesContractAsObjectTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        Character charValue = barterTypeConverter.getAsObject(ctx, new UICommand(), "barter.type.future.monsanto.manages.contract");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('3')));
    }

    @Test
	public void getValidTermsAsObjectTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        Character charValue = barterTypeConverter.getAsObject(ctx, new UICommand(), "barter.type.terms");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('4')));
    }

    @Test
	public void getAsObjectNotValidTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        Character charValue = barterTypeConverter.getAsObject(ctx, new UICommand(), YES);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.toString().equals(YES));
    }

    @Test
	public void getAsStringValidAvailableGrainTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        String value = barterTypeConverter.getAsString(ctx, new UICommand(), new Character('1'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(AVAILABLE_GRAIN));
    }

    @Test
	public void getAsStringValidFutureWithExistingContractTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        String value = barterTypeConverter.getAsString(ctx, new UICommand(), new Character('2'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(FUTURE_WITH_EXISTING_CONTRACT));
    }

    @Test
	public void getAsStringValidFutureMonsantoManagesContractTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        String value = barterTypeConverter.getAsString(ctx, new UICommand(), new Character('3'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(FUTURE_MONSANTO_MANAGES_CONTRACT));
    }

    @Test
	public void getAsStringValidTermsTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        String value = barterTypeConverter.getAsString(ctx, new UICommand(), new Character('4'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(TERMS));
    }

    @Test
	public void getAsStringNotValidTest() {
        BarterTypeConverter barterTypeConverter = new BarterTypeConverter();
        String value = barterTypeConverter.getAsString(ctx, new UICommand(), new Character('5'));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
