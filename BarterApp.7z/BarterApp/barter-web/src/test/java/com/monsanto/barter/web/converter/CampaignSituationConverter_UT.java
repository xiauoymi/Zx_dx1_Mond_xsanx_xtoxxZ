package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CampaignSituationConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String YES  = "Y";
    private static final String CAMPAIGN_ACTIVE = "campaign.situation.active";
    private static final String CAMPAIGN_INACTIVE  = "campaign.situation.inactive";
    private static final Character ACTIVE_CD_COD = 'A';
    private static final Character INACTIVE_CD_COD = 'I';


    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidCampaignActiveAsObjectTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        Character charValue = (Character) campaignSituationConverter.getAsObject(ctx, new UICommand(), CAMPAIGN_ACTIVE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(ACTIVE_CD_COD));
    }

    @Test
	public void getValidCampaignInactiveAsObjectTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        Character charValue = (Character) campaignSituationConverter.getAsObject(ctx, new UICommand(), CAMPAIGN_INACTIVE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(INACTIVE_CD_COD));
    }

    @Test
	public void getValidCampaignActiveAsObjectNotValidTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        Character charValue = (Character) campaignSituationConverter.getAsObject(ctx, new UICommand(), CAMPAIGN_ACTIVE);
        Assert.assertNotNull(charValue);
        Assert.assertFalse(charValue.equals(Character.valueOf('0')));
    }

    @Test
	public void getValidCampaignInactiveAsObjectNotValidTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        Character charValue = (Character) campaignSituationConverter.getAsObject(ctx, new UICommand(), CAMPAIGN_INACTIVE);
        Assert.assertNotNull(charValue);
        Assert.assertFalse(charValue.equals(Character.valueOf('0')));
    }

    @Test
	public void getAsObjectNotValidTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        Character charValue = (Character) campaignSituationConverter.getAsObject(ctx, new UICommand(), YES);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.toString().equals(YES));
    }

    @Test
	public void getAsStringValidAvailableGrainTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        String value = campaignSituationConverter.getAsString(ctx, new UICommand(), ACTIVE_CD_COD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals("Active"));
    }

    @Test
	public void getAsStringValidFutureWithExistingContractTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        String value = campaignSituationConverter.getAsString(ctx, new UICommand(), INACTIVE_CD_COD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals("Inactive"));
    }

    @Test
	public void getAsStringNotValidTest() {
        CampaignSituationConverter campaignSituationConverter = new CampaignSituationConverter();
        String value = campaignSituationConverter.getAsString(ctx, new UICommand(), new Character('5'));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
