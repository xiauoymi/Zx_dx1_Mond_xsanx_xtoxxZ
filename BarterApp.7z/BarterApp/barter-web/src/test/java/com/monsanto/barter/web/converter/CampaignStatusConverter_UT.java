package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CampaignStatusConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String DRAFT_CD = "campaign.status.draft";
    private static final String WAITING_FOR_VALIDATION_CD  = "campaign.status.waiting.validation";
    private static final String VALIDATED_CD = "campaign.status.validated";
    private static final String RETURNED_CD  = "campaign.status.returned";
    private static final String INACTIVATED_CD  = "campaign.status.inactivated";
    private static final String DRAFT = "Draft";
    private static final String PENDING_VALIDATION = "Pending Validation";
    private static final String VALIDATED = "Validated";
    private static final String RETURNED = "Returned";
    private static final String INACTIVATED = "Inactivated";


    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidCampaignDraftAsObjectTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), DRAFT_CD);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('D')));
    }

    @Test
    public void getValidCampaignWaitingForValidationAsObjectTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), WAITING_FOR_VALIDATION_CD);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('W')));
    }

    @Test
    public void getValidCampaignValidatedCDAsObjectTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), VALIDATED_CD);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('V')));
    }

    @Test
    public void getValidCampaignReturnedCDAsObjectTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), RETURNED_CD);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('R')));
    }

    @Test
    public void getValidCampaignInactivatedAsObjectTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), INACTIVATED_CD);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('I')));
    }

    @Test
	public void getAsObjectNotValidTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        Character charValue = (Character) campaignStatusConverter.getAsObject(ctx, new UICommand(), "A");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('A')));
    }

    @Test
	public void getValidCampaignDraftAsStringTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('D'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(DRAFT));
    }

    @Test
	public void getValidCampaignWaitingForValidationAsStringTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('W'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(PENDING_VALIDATION));
    }

    @Test
	public void getValidCampaignValidatedCDAsStringTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('V'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(VALIDATED));
    }

    @Test
	public void getValidCampaignReturnedCDAsStringTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('R'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(RETURNED));
    }

    @Test
	public void getValidCampaignInactiveCDAsStringTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('I'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(INACTIVATED));
    }

    @Test
	public void getAsStringNotValidTest() {
        CampaignStatusConverter campaignStatusConverter = new CampaignStatusConverter();
        String value = campaignStatusConverter.getAsString(ctx, new UICommand(), new Character('5'));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
