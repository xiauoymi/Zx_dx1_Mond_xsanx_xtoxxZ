package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 10:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommunicationTypeConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String BULLETIN = "communication.type.bulletin";
    private static final String CAMPAIGN  = "communication.type.campaign";
    private static final String GUIDE = "communication.type.guide";
    private static final String INFORMATIONAL  = "communication.type.informational";
    private static final String QUOTE  = "communication.type.quote";
    private static final String BULLETIN_PROPERTY = "Bullentins";
    private static final String CAMPAIGN_PROPERTY = "Campaign";
    private static final String GUIDE_PROPERTY = "Guides";
    private static final String INFORMATIONAL_PROPERTY = "Informational";
    private static final String QUOTE_PROPERTY = "Quotes";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidCampaignBulletinAsObjectTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), BULLETIN);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('B')));
    }

    @Test
    public void getValidCampaignCampaignAsObjectTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), CAMPAIGN);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('C')));
    }

    @Test
    public void getValidCampaignGuideAsObjectTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), GUIDE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('G')));
    }

    @Test
    public void getValidCampaignInformationalAsObjectTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), INFORMATIONAL);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('I')));
    }

    @Test
    public void getValidCampaignQuoteAsObjectTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), QUOTE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('Q')));
    }

    @Test
	public void getAsObjectNotValidTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        Character charValue = communicationTypeConverter.getAsObject(ctx, new UICommand(), "A");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('A')));
    }

    @Test
	public void getValidCampaignBulletinAsStringTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), Character.valueOf('B'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(BULLETIN_PROPERTY));
    }

    @Test
	public void getValidCampaignCampaignAsStringTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), Character.valueOf('C'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(CAMPAIGN_PROPERTY));
    }

    @Test
	public void getValidCampaignGuideAsStringTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), Character.valueOf('G'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(GUIDE_PROPERTY));
    }

    @Test
	public void getValidCampaignInformationalAsStringTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), Character.valueOf('I'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(INFORMATIONAL_PROPERTY));
    }

    @Test
	public void getValidCampaignQuoteAsStringTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), Character.valueOf('Q'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(QUOTE_PROPERTY));
    }

    @Test
	public void getAsStringNotValidTest() {
        CommunicationTypeConverter communicationTypeConverter = new CommunicationTypeConverter();
        String value = communicationTypeConverter.getAsString(ctx, new UICommand(), new Character('5'));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
