package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ContractStatusConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String NEW = "contract.status.new";
    private static final String UPDATE  = "contract.status.update";
    private static final String DELETE = "contract.status.delete";
    private static final String CLOSED  = "contract.status.closed";
    private static final String NEW_PROPERTY = "New";
    private static final String UPDATE_PROPERTY = "Updated";
    private static final String DELETE_PROPERTY = "Deleted";
    private static final String CLOSED_PROPERTY = "Closed";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidCampaignNewAsObjectTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        Character charValue = contractStatusConverter.getAsObject(ctx, new UICommand(), NEW);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('N')));
    }

    @Test
    public void getValidCampaignUpdatedAsObjectTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        Character charValue = contractStatusConverter.getAsObject(ctx, new UICommand(), UPDATE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('U')));
    }

    @Test
    public void getValidCampaignDeleteAsObjectTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        Character charValue = contractStatusConverter.getAsObject(ctx, new UICommand(), DELETE);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('D')));
    }

    @Test
    public void getValidCampaignClosedAsObjectTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        Character charValue = contractStatusConverter.getAsObject(ctx, new UICommand(), CLOSED);
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('C')));
    }

    @Test
	public void getAsObjectNotValidTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        Character charValue = contractStatusConverter.getAsObject(ctx, new UICommand(), "A");
        Assert.assertNotNull(charValue);
        Assert.assertTrue(charValue.equals(Character.valueOf('A')));
    }

    @Test
	public void getValidCampaignNewAsStringTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        String value = contractStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('N'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(NEW_PROPERTY));
    }

    @Test
	public void getValidCampaignUpdatedAsStringTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        String value = contractStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('U'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(UPDATE_PROPERTY));
    }

    @Test
	public void getValidCampaignDeletedAsStringTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        String value = contractStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('D'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(DELETE_PROPERTY));
    }

    @Test
	public void getValidCampaignClosedAsStringTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        String value = contractStatusConverter.getAsString(ctx, new UICommand(), Character.valueOf('C'));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(CLOSED_PROPERTY));
    }

    @Test
	public void getAsStringNotValidTest() {
        ContractStatusConverter contractStatusConverter = new ContractStatusConverter();
        String value = contractStatusConverter.getAsString(ctx, new UICommand(), new Character('5'));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}

