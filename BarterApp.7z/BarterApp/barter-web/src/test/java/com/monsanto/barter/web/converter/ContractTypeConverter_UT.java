package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ContractTypeConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String MONSANTO_MANAGES_CONTRACT_CD = "contract.type.monsanto.manages.contract";
    private static final String EXISTING_CONTRACT_CD  = "contract.type.existing.contract";
    private static final String AVAILABLE_GRAIN = "contract.type.available.grain";
    private static final String MONSANTO_MANAGES_CONTRACT_CD_PROPERTY = "Monsanto manages Contract";
    private static final String EXISTING_CONTRACT_CD_PROPERTY = "Existing Contract";
    private static final String AVAILABLE_GRAIN_PROPERTY = "Available grain";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidCampaignMonsantoManagesContractAsObjectTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = (String) contractTypeConverter.getAsObject(ctx, new UICommand(), MONSANTO_MANAGES_CONTRACT_CD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals("MG"));
    }

    @Test
    public void getValidCampaignExistingContractAsObjectTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = (String) contractTypeConverter.getAsObject(ctx, new UICommand(), EXISTING_CONTRACT_CD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals("EC"));
    }

    @Test
    public void getValidCampaignAvailableGrainAsObjectTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = (String) contractTypeConverter.getAsObject(ctx, new UICommand(), AVAILABLE_GRAIN);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals("AG"));
    }

    @Test
	public void getAsObjectNotValidTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = (String) contractTypeConverter.getAsObject(ctx, new UICommand(), "A");
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals("A"));
    }

    @Test
	public void getValidCampaignMonsantoManagesContractAsStringTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = contractTypeConverter.getAsString(ctx, new UICommand(), "MG");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(MONSANTO_MANAGES_CONTRACT_CD_PROPERTY));
    }

    @Test
	public void getValidCampaignExistingContractAsStringTest() {
       ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = contractTypeConverter.getAsString(ctx, new UICommand(), "EC");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(EXISTING_CONTRACT_CD_PROPERTY));
    }

    @Test
	public void getValidCampaignAvailableGrainAsStringTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = contractTypeConverter.getAsString(ctx, new UICommand(), "AG");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(AVAILABLE_GRAIN_PROPERTY));
    }

    @Test
	public void getAsStringNotValidTest() {
        ContractTypeConverter contractTypeConverter = new ContractTypeConverter();
        String value = contractTypeConverter.getAsString(ctx, new UICommand(), "AA");
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}
