package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class LongShortHistoryConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String CHANGED = "Changed from 0 to 1.";
    private static final String EXCLUSION  = "Exclusion";
    private static final String NEW = "New";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidLongShortAsObjectTest() {
        LongShortHistoryConverter longShortHistoryConverter = new LongShortHistoryConverter();
        String value = (String) longShortHistoryConverter.getAsObject(ctx, new UICommand(), "0-1");
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals("0-1"));
    }

    @Test
	public void getNotValidLongShortAsObjectTest() {
        LongShortHistoryConverter longShortHistoryConverter = new LongShortHistoryConverter();
        String value = (String) longShortHistoryConverter.getAsObject(ctx, new UICommand(), "0-1");
        Assert.assertNotNull(value);
        Assert.assertFalse(value.equals("1-1"));
    }

    @Test
	public void getValidLongShortHistoryConverterChangedAsStringTest() {
        LongShortHistoryConverter longShortHistoryConverter = new LongShortHistoryConverter();
        String value = longShortHistoryConverter.getAsString(ctx, new UICommand(), "0-1");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(CHANGED));
    }

    @Test
	public void getValidLongShortHistoryConverterExclusionAsStringTest() {
        LongShortHistoryConverter longShortHistoryConverter = new LongShortHistoryConverter();
        String value = longShortHistoryConverter.getAsString(ctx, new UICommand(), "0-null");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(EXCLUSION));
    }

    @Test
	public void getValidLongShortHistoryConverterNewAsStringTest() {
        LongShortHistoryConverter longShortHistoryConverter = new LongShortHistoryConverter();
        String value = longShortHistoryConverter.getAsString(ctx, new UICommand(), "null-0");
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(NEW));
    }
}

