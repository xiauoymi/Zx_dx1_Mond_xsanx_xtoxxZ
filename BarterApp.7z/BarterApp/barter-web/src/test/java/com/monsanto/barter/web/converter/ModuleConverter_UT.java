package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ModuleConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String ADMINISTRATION_MODULE_CD_PROPERTY = "Administration";
    private static final String COMMUNICATION_MODULE_CD_PROPERTY  = "Communication";
    private static final String CAMPAIGN_MODULE_CD_PROPERTY = "Campaign";
    private static final String ORDER_MODULE_CD_PROPERTY = "Order";
    private static final String LONG_SHORT_MODULE_CD_PROPERTY = "Long/Short";
    private static final String TRADING_CONTRACTS_MODULE_CD_PROPERTY = "Trading Contracts";
    private static final String COMMERCIAL_MODULE_CD_PROPERTY = "commercial";
    private static final String LEGAL_MODULE_CD_PROPERTY = "legal";


    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidModuleConverterAdministrationAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "1");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(1));
    }

    @Test
    public void getValidModuleConverterCommunicationAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "2");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(2));
    }

    @Test
    public void getValidModuleConverterCampaignAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "3");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(3));
    }

    @Test
	public void getValidModuleConverterOrderAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "4");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(4));
    }

    @Test
    public void getValidModuleConverterLongShortAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "5");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(5));
    }

    @Test
    public void getValidModuleConverterTradingContractsAsObjectTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "6");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf(6));
    }

    @Test
	public void getAsObjectNotValidTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        Integer value = (Integer) moduleConverter.getAsObject(ctx, new UICommand(), "00");
        Assert.assertNotNull(value);
    }

    @Test
	public void getValidModuleConverterAdministrationAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(1));
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(ADMINISTRATION_MODULE_CD_PROPERTY));
    }

    @Test
	public void getValidModuleConverterCommunicationAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(2));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(COMMUNICATION_MODULE_CD_PROPERTY));
    }

    @Test
	public void getValidModuleConverterCampaignAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(3));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(CAMPAIGN_MODULE_CD_PROPERTY));
    }

    @Test
	public void getValidModuleConverterOrderModuleAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(4));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(ORDER_MODULE_CD_PROPERTY));
    }

    @Test
	public void getValidModuleConverterLongShortAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(5));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(LONG_SHORT_MODULE_CD_PROPERTY));
    }

    @Test
	public void getValidModuleConverterTradingContractAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(6));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(TRADING_CONTRACTS_MODULE_CD_PROPERTY));
    }


    @Test
    public void getValidModuleConverterCommercialAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(8));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(COMMERCIAL_MODULE_CD_PROPERTY));
    }

    @Test
    public void getValidModuleConverterLegalAsStringTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(9));
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(LEGAL_MODULE_CD_PROPERTY));
    }


    @Test
	public void getAsStringNotValidTest() {
        ModuleConverter moduleConverter = new ModuleConverter();
        String value = moduleConverter.getAsString(ctx, new UICommand(), Integer.valueOf(11));
        assertThat(value).isNotNull();
        assertThat(value).isEmpty();
    }
}