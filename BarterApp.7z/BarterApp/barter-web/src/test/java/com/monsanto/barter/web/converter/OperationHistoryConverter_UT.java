package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class OperationHistoryConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final Character SENT_APPROVAL_OPERATION_HIST_CD = 'A';
    private static final Character APPROVED_OPERATION_HIST_CD  = 'B';
    private static final Character RETURNED_OPERATION_HIST_CD = 'C';
    private static final Character DISAPPROVED_OPERATION_HIST_CD = 'D';
    private static final Character REOPENED_OPERATION_HIST_CD = 'E';

    private static final String SENT_APPROVAL_OPERATION_HIST_CD_PROPERTY  = "Sent for approval";
    private static final String APPROVED_OPERATION_HIST_CD_PROPERTY = "Approved";
    private static final String RETURNED_OPERATION_HIST_CD_PROPERTY = "Returned";
    private static final String DISAPPROVED_OPERATION_HIST_CD_PROPERTY = "Disapproved";
    private static final String REOPENED_OPERATION_HIST_CD_PROPERTY = "Reopened";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidOperationHistoryConverterAAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "A");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(new Character('A'));
    }

    @Test
	public void getValidOperationHistoryConverterBAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "B");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(new Character('B'));
    }

    @Test
	public void getValidOperationHistoryConverterCAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "C");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(new Character('C'));
    }

    @Test
	public void getValidOperationHistoryConverterDAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "D");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(new Character('D'));
    }

    @Test
	public void getValidOperationHistoryConverterEAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "E");
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(new Character('E'));
    }

    @Test
	public void getNotValidOperationHistoryConverterAsObjectTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        Character value = (Character) operationHistoryConverter.getAsObject(ctx, new UICommand(), "X");
        Assert.assertNotNull(value);
        assertThat(value).isNotEqualTo(new Character('Y'));
    }

    @Test
	public void getValidOperationHistoryConverterAAsStringTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), SENT_APPROVAL_OPERATION_HIST_CD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(SENT_APPROVAL_OPERATION_HIST_CD_PROPERTY));
    }

    @Test
	public void getValidOperationHistoryConverterBAsStringTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), APPROVED_OPERATION_HIST_CD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(APPROVED_OPERATION_HIST_CD_PROPERTY));
    }

    @Test
	public void getValidOperationHistoryConverterCAsStringTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), RETURNED_OPERATION_HIST_CD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(RETURNED_OPERATION_HIST_CD_PROPERTY));
    }

    @Test
	public void getValidOperationHistoryConverterDAsStringTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), DISAPPROVED_OPERATION_HIST_CD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(DISAPPROVED_OPERATION_HIST_CD_PROPERTY));
    }

    @Test
	public void getValidOperationHistoryConverterEAsStringTest() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), REOPENED_OPERATION_HIST_CD);
        Assert.assertNotNull(value);
        assertThat(value).isNotEmpty();
        Assert.assertTrue(value.equals(REOPENED_OPERATION_HIST_CD_PROPERTY));
    }

    @Test
	public void getNotValidAsString() {
        OperationHistoryConverter operationHistoryConverter = new OperationHistoryConverter();
        String value = operationHistoryConverter.getAsString(ctx, new UICommand(), new Character('X'));
        assertThat(value).isEmpty();
    }
}