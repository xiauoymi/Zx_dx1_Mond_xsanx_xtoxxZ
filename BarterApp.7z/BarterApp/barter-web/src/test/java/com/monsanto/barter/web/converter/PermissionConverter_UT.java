package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class PermissionConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String NEW_USER_SCREEN_PERMISSION_CD = "1";
    private static final String SEARCH_USER_SCREEN_PERMISSION_CD  = "2";
    private static final String NEW_GROUP_SCREEN_PERMISSION_CD = "3";
    private static final String SEARCH_GROUP_SCREEN_PERMISSION_CD = "4";
    private static final String NEW_COMMUNICATION_SCREEN_PERMISSION_CD = "5";

    private static final String NEW_USER_SCREEN_PERMISSION_CD_PROPERTY  = "User Register";
    private static final String SEARCH_USER_SCREEN_PERMISSION_CD_PROPERTY = "User Search";
    private static final String LONG_SHORT_SCREEN_PERMISSION_CD_PROPERTY = "Search/Register of Long/Short";
    private static final String NEW_GROUP_SCREEN_PERMISSION_CD_PROPERTY = "Group Register";
    private static final String NEW_COMMUNICATION_SCREEN_PERMISSION_CD_PROPERTY = "Communication Register";

    private static final Integer NEW_USER_SCREEN_PERMISSION_COD = Integer.valueOf(1);
    private static final Integer SEARCH_USER_SCREEN_PERMISSION_COD  = Integer.valueOf(2);
    private static final Integer LONG_SHORT_SCREEN_PERMISSION_COD = Integer.valueOf(12);
    private static final Integer NEW_GROUP_SCREEN_PERMISSION_COD = Integer.valueOf(3);
    private static final Integer NEW_COMMUNICATION_SCREEN_PERMISSION_COD = Integer.valueOf(5);

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidPermissionConverterAAsObjectTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        Integer value = (Integer) permissionConverter.getAsObject(ctx, new UICommand(), NEW_USER_SCREEN_PERMISSION_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("1"));
    }

    @Test
	public void getValidPermissionConverterBAsObjectTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        Integer value = (Integer) permissionConverter.getAsObject(ctx, new UICommand(), SEARCH_USER_SCREEN_PERMISSION_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("2"));
    }

    @Test
	public void getValidPermissionConverterCAsObjectTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        Integer value = (Integer) permissionConverter.getAsObject(ctx, new UICommand(), NEW_GROUP_SCREEN_PERMISSION_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("3"));
    }

    @Test
	public void getValidPermissionConverterDAsObjectTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        Integer value = (Integer) permissionConverter.getAsObject(ctx, new UICommand(), SEARCH_GROUP_SCREEN_PERMISSION_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("4"));
    }

    @Test
	public void getValidPermissionConverterEAsObjectTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        Integer value = (Integer) permissionConverter.getAsObject(ctx, new UICommand(), NEW_COMMUNICATION_SCREEN_PERMISSION_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("5"));
    }

    @Test
	public void getValidPermissionConverterPermission1AsStringTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), NEW_USER_SCREEN_PERMISSION_COD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(NEW_USER_SCREEN_PERMISSION_CD_PROPERTY));
    }

    @Test
	public void getValidPermissionConverterPermission2AsStringTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), SEARCH_USER_SCREEN_PERMISSION_COD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(SEARCH_USER_SCREEN_PERMISSION_CD_PROPERTY));
    }

    @Test
	public void getValidPermissionConverterPermission3AsStringTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), LONG_SHORT_SCREEN_PERMISSION_COD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(LONG_SHORT_SCREEN_PERMISSION_CD_PROPERTY));
    }

    @Test
	public void getValidPermissionConverterPermission4AsStringTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), NEW_GROUP_SCREEN_PERMISSION_COD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(NEW_GROUP_SCREEN_PERMISSION_CD_PROPERTY));
    }

    @Test
	public void getValidPermissionConverterPermission5AsStringTest() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), NEW_COMMUNICATION_SCREEN_PERMISSION_COD);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(NEW_COMMUNICATION_SCREEN_PERMISSION_CD_PROPERTY));
    }

    @Test
	public void getNotValidAsString() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), new Integer(10000));
        assertThat(value).isEmpty();
    }
}