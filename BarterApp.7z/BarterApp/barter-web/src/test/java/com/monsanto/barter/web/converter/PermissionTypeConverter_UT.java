package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class PermissionTypeConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String SCREEN_PERMISSION_TYPE_CD = "1";
    private static final String BUTTON_PERMISSION_TYPE_CD  = "2";
    private static final Integer SCREEN_PERMISSION_TYPE_CD_PROPERTY  = Integer.valueOf(1);
    private static final Integer BUTTON_PERMISSION_TYPE_CD_PROPERTY = Integer.valueOf(2);
    private static final String SCREEN_PERMISSION_TYPE_COD = "Screen";
    private static final String BUTTON_PERMISSION_TYPE_COD  = "Button";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidPermissionTypeConverter1AsObjectTest() {
        PermissionTypeConverter permissionTypeConverter = new PermissionTypeConverter();
        Integer value = (Integer) permissionTypeConverter.getAsObject(ctx, new UICommand(), SCREEN_PERMISSION_TYPE_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("1"));
    }

    @Test
	public void getValidPermissionTypeConverter2AsObjectTest() {
        PermissionTypeConverter permissionTypeConverter = new PermissionTypeConverter();
        Integer value = (Integer) permissionTypeConverter.getAsObject(ctx, new UICommand(), BUTTON_PERMISSION_TYPE_CD);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(Integer.valueOf("2"));
    }

    @Test
	public void getValidPermissionConverterPermission1AsStringTest() {
        PermissionTypeConverter permissionTypeConverter = new PermissionTypeConverter();
        String value = permissionTypeConverter.getAsString(ctx, new UICommand(), SCREEN_PERMISSION_TYPE_CD_PROPERTY);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(SCREEN_PERMISSION_TYPE_COD));
    }

    @Test
	public void getValidPermissionConverterPermission2AsStringTest() {
        PermissionTypeConverter permissionTypeConverter = new PermissionTypeConverter();
        String value = permissionTypeConverter.getAsString(ctx, new UICommand(), BUTTON_PERMISSION_TYPE_CD_PROPERTY);
        Assert.assertNotNull(value);
        Assert.assertTrue(value.equals(BUTTON_PERMISSION_TYPE_COD));
    }

    @Test
	public void getNotValidAsString() {
        PermissionConverter permissionConverter = new PermissionConverter();
        String value = permissionConverter.getAsString(ctx, new UICommand(), new Integer(10000));
        assertThat(value).isEmpty();
    }
}