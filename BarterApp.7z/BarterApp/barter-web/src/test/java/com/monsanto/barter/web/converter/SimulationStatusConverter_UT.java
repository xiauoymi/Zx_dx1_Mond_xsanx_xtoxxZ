package com.monsanto.barter.web.converter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/18/12
 * Time: 12:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class SimulationStatusConverter_UT extends JsfTestCase {

    private FacesContext ctx = null;
    private static final String WAITING_APPROVAL = "WA";
    private static final String WAITING_SO  = "WS";
    private static final String APPROVED = "OK";
    private static final String RETURNED  = "RE";
    private static final String PENDING_APPROVAL = "PA";
    private static final String DRAFT  = "DF";
    private static final String REOPENED = "RO";
    private static final String NOT_APPROVED  = "NA";
    private static final String NOT_CONVERTED_BARTER  = "NC";
    private static final String DELIVERED = "DL";
    private static final String CLOSED  = "CL";

    private static final String WAITING_APPROVAL_PROPERTY = "simulation.status.waiting.approval";
    private static final String WAITING_SO_PROPERTY  = "simulation.status.waiting.sale.order";
    private static final String APPROVED_PROPERTY = "simulation.status.approved";
    private static final String RETURNED_PROPERTY  = "simulation.status.returned";
    private static final String PENDING_APPROVAL_PROPERTY = "simulation.status.pending.approval";
    private static final String DRAFT_PROPERTY  = "simulation.status.draft";
    private static final String REOPENED_PROPERTY = "simulation.status.reopened";
    private static final String NOT_APPROVED_PROPERTY  = "simulation.status.not.approved";
    private static final String NOT_CONVERTED_BARTER_PROPERTY  = "NC";
    private static final String DELIVERED_PROPERTY = "DL";
    private static final String CLOSED_PROPERTY  = "CL";

    private static final String WAITING_APPROVAL_PROPERTY_LABEL = "Waiting for approval";
    private static final String WAITING_SO_PROPERTY_LABEL  = "Waiting sales order";
    private static final String APPROVED_PROPERTY_LABEL = "Approved";
    private static final String RETURNED_PROPERTY_LABEL  = "Returned";
    private static final String PENDING_APPROVAL_PROPERTY_LABEL = "Approval pending";
    private static final String DRAFT_PROPERTY_LABEL  = "Draft";
    private static final String REOPENED_PROPERTY_LABEL = "Reopened";
    private static final String NOT_APPROVED_PROPERTY_LABEL  = "Disapproved";
    private static final String NOT_CONVERTED_BARTER_PROPERTY_LABEL  = "NC";
    private static final String DELIVERED_PROPERTY_LABEL = "DL";
    private static final String CLOSED_PROPERTY_LABEL  = "CL";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ctx = FacesContext.getCurrentInstance();
    }

    @Test
	public void getValidSimulationStatusConverterWAAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), WAITING_APPROVAL_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(WAITING_APPROVAL);
    }

    @Test
	public void getValidSimulationStatusConverterWSAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), WAITING_SO_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(WAITING_SO);
    }

    @Test
	public void getValidSimulationStatusConverterAPAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), APPROVED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(APPROVED);
    }

    @Test
	public void getValidSimulationStatusConverterRPAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), RETURNED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(RETURNED);
    }

    @Test
	public void getValidSimulationStatusConverterPAAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), PENDING_APPROVAL_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(PENDING_APPROVAL);
    }

    @Test
	public void getValidSimulationStatusConverterRAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), REOPENED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(REOPENED);
    }

    @Test
	public void getValidSimulationStatusConverterDAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), DRAFT_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(DRAFT);
    }

    @Test
	public void getValidSimulationStatusConverterNAAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), NOT_APPROVED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(NOT_APPROVED);
    }

    @Test
	public void getValidSimulationStatusConverterNCBAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), NOT_CONVERTED_BARTER_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(NOT_CONVERTED_BARTER);
    }

    @Test
	public void getValidSimulationStatusConverterDELAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), DELIVERED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(DELIVERED);
    }

    @Test
	public void getValidSimulationStatusConverterCLOAsObjectTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsObject(ctx, new UICommand(), CLOSED_PROPERTY);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(CLOSED);
    }

    @Test
	public void getValidSimulationStatusConverterWAAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), WAITING_APPROVAL);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(WAITING_APPROVAL_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterWSAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), WAITING_SO);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(WAITING_SO_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterAPPAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), APPROVED);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(APPROVED_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterRAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), RETURNED);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(RETURNED_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterDRAFTAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), DRAFT);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(DRAFT_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterPAAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), PENDING_APPROVAL);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(PENDING_APPROVAL_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterRPAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), REOPENED);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(REOPENED_PROPERTY_LABEL);
    }

    @Test
	public void getValidSimulationStatusConverterNOTAPPAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), NOT_APPROVED);
        Assert.assertNotNull(value);
        assertThat(value).isEqualTo(NOT_APPROVED_PROPERTY_LABEL);

    }
    @Test
	public void getValidSimulationStatusConverterNOTCONAsStringTest() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), NOT_CONVERTED_BARTER);
        Assert.assertNotNull(value);
        assertThat(value).isEmpty();
    }

    @Test
	public void getNotValidAsString() {
        SimulationStatusConverter simulationStatusConverter = new SimulationStatusConverter();
        String value = simulationStatusConverter.getAsString(ctx, new UICommand(), "XX");
        assertThat(value).isEmpty();
    }
}