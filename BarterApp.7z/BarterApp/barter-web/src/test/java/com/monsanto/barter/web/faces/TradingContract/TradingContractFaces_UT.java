package com.monsanto.barter.web.faces.TradingContract;

import com.monsanto.barter.architecture.regionalization.*;
import com.monsanto.barter.architecture.security.data.*;
import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.entity.BaseEntity;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.business.SimulationBusiness;
import com.monsanto.barter.business.entity.business.TradingContractBusiness;
import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.ContractStatusList;
import com.monsanto.barter.business.entity.list.ContractTypeList;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.list.QuoteTypeList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.entity.table.id.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.campaign.CampaignFaces;
import com.monsanto.barter.web.faces.quotation.QuotationFaces;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import com.monsanto.barter.web.faces.tradingcontract.TradingContractFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import com.monsanto.barter.web.test.SilentObjectCreator;

import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.beans.factory.BeanFactory;

import javax.el.ELContext;
import javax.el.ELResolver;
import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

import static org.mockito.Matchers.any;
import static org.powermock.api.mockito.PowerMockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Test class for the FormalizationFaces class.
 * 
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class TradingContractFaces_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";
    public static final String ANY_CODE = "any.code";
    public static final String COUNTRY_CD = "BRL";
    public static final BigDecimal BALANCE_EXPECTED = new BigDecimal(5);
    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String TAB_HISTORY = "tabHistory";
    public static final String SUCCESS = "success";
    public static final String CHANGE = "change";
    private static final String SHOW_RESULT = "showResult";
    private TradingContractFaces tested;


    public static class TradingContractFacesForTest extends TradingContractFaces {

        private User loggedInUser = new User();

        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICountryService.class)) {
                ICountryService countryService = mock(ICountryService.class);
                ArrayList<Country> countries = new ArrayList<Country>();
                Country country = new Country(new CountryId());
                country.getId().setCountryCd("BRL");
                country.setShortDesc("BRAZIL");
                countries.add(country);
                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                return (T)countryService;
            }

            if (requiredType.equals(IIncotermsService.class)) {
                IIncotermsService incotermsService = mock(IIncotermsService.class);
                ArrayList<Incoterms> incotermses = new ArrayList<Incoterms>();
                Incoterms incoterms = new Incoterms(new IncotermsId());
                incoterms.getId().setIncotermsCd("any.code");
                incotermses.add(incoterms);
                when(incotermsService.search(Matchers.<IncotermsFilter>any())).thenReturn(incotermses);
                return (T)incotermsService;
            }

            if (requiredType.equals(ICurrencyService.class)) {
                ICurrencyService currencyService = mock(ICurrencyService.class);
                ArrayList<Currency> currencies = new ArrayList<Currency>();
                Currency currency = new Currency(new CurrencyId());
                currency.getId().setCurrencyCd(IBarterConstants.CURRENCY_CODE_DOLLAR);
                currency.setDescCurrencyLong("any.currency");
                currencies.add(currency);
                when(currencyService.search(Matchers.<CurrencyFilter>any())).thenReturn(currencies);
                return (T)currencyService;
            }

            if (requiredType.equals(ICurrencyService.class)) {
                ICurrencyService currencyService = mock(ICurrencyService.class);
                ArrayList<Currency> currencies = new ArrayList<Currency>();
                Currency currency = new Currency(new CurrencyId());
                currency.getId().setCurrencyCd(IBarterConstants.CURRENCY_CODE_DOLLAR);
                currency.setDescCurrencyLong("any.currency");
                currencies.add(currency);
                when(currencyService.search(Matchers.<CurrencyFilter>any())).thenReturn(currencies);
                return (T)currencyService;
            }

            if (requiredType.equals(IRegionService.class)) {
                IRegionService regionService = mock(IRegionService.class);
                ArrayList<Region> regions = new ArrayList<Region>();
                Region region = new Region(new RegionId());
                region.getId().setRegionCd(ANY_CODE);

                regions.add(region);
                when(regionService.search(Matchers.<RegionFilter>any())).thenReturn(regions);
                return (T)regionService;
            }

            if (requiredType.equals(ICityService.class)) {
                ICityService cityService = mock(ICityService.class);
                ArrayList<City> cities = new ArrayList<City>();
                City city = new City(new CityId());
                city.getId().setRegionCd(ANY_CODE);
                city.setDescCity(ANY_CODE);

                cities.add(city);
                when(cityService.search(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)cityService;
            }

            if (requiredType.equals(ITradingContractService.class)) {
                ITradingContractService tradingContractService = mock(ITradingContractService.class);

                when(tradingContractService.calculateContractValue(Matchers.<TradingContract>any())).thenReturn(new BigDecimal(10));
                when(tradingContractService.calculateBalance(Matchers.<List<SimulationBusiness>>any(), Matchers.<TradingContract>any())).thenReturn(BALANCE_EXPECTED);

                ArrayList<TradingContractBusiness> tradingContracts = new ArrayList<TradingContractBusiness>();
                TradingContractBusiness tradingContract = new TradingContractBusiness();
                tradingContract.setContractId(new Long(1));
                tradingContracts.add(tradingContract);
                when(tradingContractService.searchBusinessObjects(Matchers.<TradingContractFilter>any())).thenReturn(tradingContracts);

                TradingContract contract = new TradingContract();
                contract.setContractId(new Long(1));
                City city = new City(new CityId());
                city.getId().setCityCd(ANY_CODE);
                city.getId().setCountryCd(COUNTRY_CD);
                city.getId().setRegionCd(ANY_CODE);
                contract.setCity(city);
                Currency currency = new Currency(new CurrencyId());
                currency.getId().setCurrencyCd(IBarterConstants.CURRENCY_CODE_DOLLAR);
                contract.setCurrency(currency);
                contract.setQuotationFL(QuoteTypeList.QUOTE.getCod());
                contract.setContractValue(new BigDecimal(10));
                Incoterms incoterms = new Incoterms(new IncotermsId());
                incoterms.getId().setIncotermsCd(ANY_CODE);
                contract.setIncoterms(incoterms);
                contract.setCommodityId(ANY_CODE);
                contract.setTradingCd(ANY_CODE);
                when(tradingContractService.findByIdComplete(Matchers.<TradingContract>any())).thenReturn(contract);

                return (T)tradingContractService;
            }
            if (requiredType.equals(IPtaxService.class)) {
                IPtaxService ptaxService = mock(IPtaxService.class);

                when(ptaxService.convertQuotationOriginToTarget(IBarterConstants.CURRENCY_CODE_DOLLAR,
                IBarterConstants.CURRENCY_CODE_REAL)).thenReturn(new BigDecimal(2));
                return (T)ptaxService;
            }

            if (requiredType.equals(ITradingContractHistoryService.class)) {
                ITradingContractHistoryService tradingContractHistoryService = mock(ITradingContractHistoryService.class);
                ArrayList<TradingContractHistory> tradingContractHistories = new ArrayList<TradingContractHistory>();
                TradingContractHistory tradingContractHistory = new TradingContractHistory();

                tradingContractHistories.add(tradingContractHistory);
                when(tradingContractHistoryService.search(Matchers.<TradingContractHistoryFilter>any())).thenReturn(tradingContractHistories);

                return (T)tradingContractHistoryService;
            }
            if (requiredType.equals(ITradingService.class)) {
                ITradingService tradingService = mock(ITradingService.class);

                ArrayList<Trading> tradings = new ArrayList<Trading>();
                Trading trading = new Trading(new TradingId());
                trading.getId().setCountryCd(COUNTRY_CD);
                trading.getId().setTradingCd(ANY_CODE);
                tradings.add(trading);
                when(tradingService.search(Matchers.<TradingFilter>any())).thenReturn(tradings);

                return (T)tradingService;
            }
            if (requiredType.equals(ICommodityService.class)) {
                ICommodityService commodityService = mock(ICommodityService.class);

                ArrayList<Commodity> commodities = new ArrayList<Commodity>();
                Commodity commodity = new Commodity(new CommodityId());
                commodity.setDescCommodity("commodity.description");
                commodity.getId().setCommodityId(ANY_CODE);
                commodities.add(commodity);
                when(commodityService.search(Matchers.<CommodityFilter>any())).thenReturn(commodities);

                return (T)commodityService;
            }

            if (requiredType.equals(ISimulationService.class)) {
                ISimulationService simulationService = mock(ISimulationService.class);
                ArrayList<SimulationBusiness> simulationBusinesses = new ArrayList<SimulationBusiness>();
                SimulationBusiness simulationBusiness = new SimulationBusiness();
                simulationBusiness.setSimulationNumber("123456");
                simulationBusiness.setSimulationValue(new BigDecimal(10));
                simulationBusinesses.add(simulationBusiness);
                when(simulationService.search(Matchers.<SimulationFilter>any())).thenReturn(simulationBusinesses);

                return (T)simulationService;
            }
            if (requiredType.equals(ICampaignService.class)) {
                ICampaignService campaignService = mock(ICampaignService.class);
                Campaign campaign =  new Campaign();
                campaign.setCountry(new Country(new CountryId()));
                campaign.getCountry().getId().setCountryCd(COUNTRY_CD);
                campaign.getCountry().getId().setCountryCd(ANY_CODE);
                campaign.setTradings(new ArrayList<Trading>());
                campaign.setCommodities(new ArrayList<Commodity>());
                Commodity commodity = new Commodity();
                commodity.setId(new CommodityId("commid","br"));
                campaign.getCommodities().add(commodity) ;

                when(campaignService.findByIdComplete(Matchers.<Campaign>any())).thenReturn(campaign);
                return (T)campaignService;
            }


            return super.getService(requiredType);
        }


        public <T extends BaseJSF> T getFaces(String requiredFaces) {
            if(requiredFaces.equals("quotationFaces"))
            {
                QuotationFaces quotationFaces = mock(QuotationFaces.class);
                return (T)quotationFaces;
            }
            if(requiredFaces.equals("simulationFaces"))
            {
                SimulationFaces simulationFaces = mock(SimulationFaces.class);
                when(simulationFaces.getSimulationSelected()).thenReturn(new SimulationBusiness());
                return (T)simulationFaces;
            }
            return null;
        }

        @Override
        public com.monsanto.barter.architecture.regionalization.Country getCountry() {
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    };


    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public TradingContractFaces_UT() {

    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }


    private TradingContractFacesForTest initializeTradingContractFaces() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();
        TradingContractBusiness tradingContractBusiness = new TradingContractBusiness();
        tradingContractBusiness.setContractId(new Long(1));
        tradingContractFacesForTest.setTradingContractBusiness(tradingContractBusiness);
        TradingContract tradingContract = new TradingContract();
        tradingContract.setCity(createCityForTest());
        tradingContractFacesForTest.setTradingContract(tradingContract);
        Currency currency = new Currency(new CurrencyId());
        currency.getId().setCurrencyCd(IBarterConstants.CURRENCY_CODE_DOLLAR);
        tradingContractFacesForTest.getTradingContract().setCurrency(currency);
        tradingContractFacesForTest.update();
        tradingContractFacesForTest.setNewer(true);
        tradingContractFacesForTest.getQuotationFilter().setTradingId(ANY_CODE);
        return tradingContractFacesForTest;
    }


    private City createCityForTest() {
        City city = new City(new CityId());
        city.getId().setCityCd(ANY_CODE);
        city.getId().setCountryCd(COUNTRY_CD);
        city.getId().setRegionCd(ANY_CODE);
        return city;
    }

    private void initializeCity(TradingContractFacesForTest tradingContractFacesForTest) {
        City city = createCityForTest();
        tradingContractFacesForTest.getTradingContract().setCity(city);
    }

    @Test
    public void testInitForm() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        assertFalse(tradingContractFacesForTest.getListCountry().isEmpty());
        assertFalse(tradingContractFacesForTest.getListCurrency().isEmpty());
        assertFalse(tradingContractFacesForTest.getListIncoterms().isEmpty());
        assertFalse(tradingContractFacesForTest.getListQuote().isEmpty());
        assertFalse(tradingContractFacesForTest.getListYesNo().isEmpty());
        assertEquals(ContractTypeList.MONSANTO_MANAGES_CONTRACT_CD.getCode(), tradingContractFacesForTest.getTradingContract().getContractTypeCd());
        assertEquals(ContractStatusList.NEW.getCode(), tradingContractFacesForTest.getTradingContract().getStatusCd());
    }

    @Test
    public void testSelectQuotation() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();
        QuotationBusiness quotationBusiness = new QuotationBusiness();
        quotationBusiness.setQuotationId(ANY_CODE);
        quotationBusiness.setQuotationValue(new BigDecimal(10));
        quotationBusiness.setRegionCd(ANY_CODE);
        quotationBusiness.setCityCd(ANY_CODE);
        quotationBusiness.setDescCity(ANY_CODE);
        quotationBusiness.setTradingCd(ANY_CODE);
        tradingContractFacesForTest.setQuotationBusiness(quotationBusiness);
        TradingContract tradingContract = new TradingContract();
        City city = createCityForTest();
        tradingContract.setCity(city);
        Currency currency = new Currency(new CurrencyId());
        currency.getId().setCurrencyCd(IBarterConstants.CURRENCY_CODE_DOLLAR);
        tradingContract.setCurrency(currency);
        tradingContractFacesForTest.setTradingContract(tradingContract);
        tradingContractFacesForTest.getQuotationFilter().setTradingId(ANY_CODE);
        tradingContractFacesForTest.cboCurrencyChanged();
        String result = tradingContractFacesForTest.selectQuotation();

        assertNull(tradingContractFacesForTest.getMessages());
        assertEquals(BALANCE_EXPECTED, tradingContractFacesForTest.getTradingContract().getBalanceContract());
        assertEquals(NOT_NAVIGATE, result);
    }



    @Test
    public void testShowHistoryTab() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        tradingContractFacesForTest.showHistoryTab();

        assertNull(tradingContractFacesForTest.getMessages());
        assertEquals(TAB_HISTORY, tradingContractFacesForTest.getTab());
    }

    @Test
    public void testCboCountryChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        assertTrue(tradingContractFacesForTest.getListTrading().isEmpty());

        initializeCity(tradingContractFacesForTest);

        tradingContractFacesForTest.cboCountryChanged();

        assertFalse(tradingContractFacesForTest.getListTrading().isEmpty());

        assertNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testRbQuotationChangedWithQuoteCode() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();
        tradingContractFacesForTest.getTradingContract().setQuotationFL(QuoteTypeList.QUOTE.getCod());

        tradingContractFacesForTest.rbQuotationChanged();

        assertNull(tradingContractFacesForTest.getMessages());
        assertTrue(tradingContractFacesForTest.isRenderedPanel());
    }

    @Test
    public void testTxtGrossPriceChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        tradingContractFacesForTest.txtGrossPriceChanged();

        assertNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testTxtNetPriceChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        tradingContractFacesForTest.txtNetPriceChanged();

        assertNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testTxtVolumeKgChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        tradingContractFacesForTest.txtVolumeKgChanged();

        assertNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testCboRegionChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        assertTrue(tradingContractFacesForTest.getListCity().isEmpty());

        initializeCity(tradingContractFacesForTest);

        tradingContractFacesForTest.cboRegionChanged();

        assertFalse(tradingContractFacesForTest.getListCity().isEmpty());

        assertNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testCboCommodityChanged() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        initializeCity(tradingContractFacesForTest);
        tradingContractFacesForTest.getTradingContract().setCommodityId(ANY_CODE);
        tradingContractFacesForTest.getTradingContract().setCurrency(new Currency(new CurrencyId()));
        tradingContractFacesForTest.getTradingContract().getCurrency().getId().setCurrencyCd(ANY_CODE);

        tradingContractFacesForTest.cboCommodityChanged();

        assertNull(tradingContractFacesForTest.getMessages());

        assertTrue(tradingContractFacesForTest.isRenderedRbQuotation());
    }

    @Test
    public void testCboCurrencyChanged() {
      TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

      tradingContractFacesForTest.cboCurrencyChanged();

      assertNotNull(tradingContractFacesForTest.getUsdRate());
    }

    @Test
    public void testCboTradingChanged(){
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        tradingContractFacesForTest.cboTradingChanged();

        assertNull(tradingContractFacesForTest.getMessages());
    }


    @Test
    public void testSearch() {
        TradingContractFacesForTest tradingContractFacesForTest = new TradingContractFacesForTest();

        String result = tradingContractFacesForTest.search();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertTrue(tradingContractFacesForTest.getMessages().isEmpty());
        assertTrue(tradingContractFacesForTest.isRenderedDataTable());
        assertEquals(SUCCESS, result);
    }

    @Test
    public void testUpdate() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        String result = tradingContractFacesForTest.update();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertTrue(tradingContractFacesForTest.getMessages().isEmpty());
        assertEquals(CHANGE, result);
    }

    @Test
    public void testDelete() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        String result = tradingContractFacesForTest.delete();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertTrue(tradingContractFacesForTest.getMessages().isEmpty());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testVisualizeContract() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        tradingContractFacesForTest.visualizeContract();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertTrue(tradingContractFacesForTest.isVisualization());
    }

    @Test
    public void testConfirm() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        tradingContractFacesForTest.update();
        String result = tradingContractFacesForTest.confirm();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testApprove() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        String result = tradingContractFacesForTest.approve();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testCancel() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        String result = tradingContractFacesForTest.cancel();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertEquals(SHOW_RESULT, result);

    }

    @Test
    public void testBtnSimulationAdd() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
        SimulationBusiness simulationBusiness = new SimulationBusiness();
        simulationBusiness.setSimulationNumber("123456");
        tradingContractFacesForTest.setSimulationBusiness(simulationBusiness);
        tradingContractFacesForTest.update();

        String result = tradingContractFacesForTest.btnSimulationRemove();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testVisualizeSimulation() {
        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
        SimulationBusiness simulationBusiness = new SimulationBusiness();
        simulationBusiness.setSimulationNumber("123456");
        tradingContractFacesForTest.setSimulationBusiness(simulationBusiness);

        String result = tradingContractFacesForTest.visualizeSimulation();

        assertNotNull(tradingContractFacesForTest.getMessages());
        assertEquals(SUCCESS, result);
    }

    @Test
    public void testCldDeliveryDateChanged() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
       ValueChangeEvent valueChangeEvent= mock(ValueChangeEvent.class);
       when(valueChangeEvent.getNewValue()).thenReturn(new Date());

       tradingContractFacesForTest.cldDeliveryDateChanged(valueChangeEvent);

       assertNotNull(tradingContractFacesForTest.getMessages());
    }

    @Test
    public void testBtnConfirmDelete() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
       String result = tradingContractFacesForTest.btnConfirmDelete();

       assertNotNull(tradingContractFacesForTest.getMessages());
       assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testBtnCancel() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
       tradingContractFacesForTest.getTradingContract().setQuotationFL(QuoteTypeList.MANUAL_PRICE.getCod());

       tradingContractFacesForTest.btnCancel();

       assertNotNull(tradingContractFacesForTest.getMessages());
       assertFalse(tradingContractFacesForTest.isRenderedPanel());
    }

    @Test
    public void testGetQtdContracts() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();
       assertEquals(0, tradingContractFacesForTest.getQtdContracts());

       tradingContractFacesForTest.search();

       assertNotNull(tradingContractFacesForTest.getMessages());
       assertEquals(1, tradingContractFacesForTest.getQtdContracts());
    }

    @Test
    public void testGetQtdSimulations() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

       int result =  tradingContractFacesForTest.getQtdSimulations();

       assertNotNull(tradingContractFacesForTest.getMessages());
       assertEquals(1,result );
    }

    @Test
    public void testGetQtdHistory() {
       TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

       int result =  tradingContractFacesForTest.getQtdHistory();

       assertNotNull(tradingContractFacesForTest.getMessages());
       assertEquals(1,result );
    }
    
    /**
     * @see TradingContractFaces#includeSelectedSimulations
     */
    @Test
    public void testIncludeSelectedSimulations() {
    	setupMockServices();
    	tested.includeSelectedSimulations();
    }
    
    /**
     * @throws Exception 
     * @see TradingContractFaces#btnSimulationAdd
     */
    @Test
    public void test_btnSimulationAdd() throws Exception {
    	setupMockServices();
    	
    	tested.btnSimulationAdd();
    	
    	SimulationBusiness simulationBusiness = new SimulationBusiness();
		Whitebox.setInternalState(tested, "simulationList", Arrays.asList(new SimulationBusiness[]{simulationBusiness}));
    	
    	tested.btnSimulationAdd();
    	
    	SimulationFaces simulationFacesMock = Whitebox.<SimulationFaces> invokeMethod(tested, "getFaces", "simulationFaces");
    	when(simulationFacesMock.getFilter()).thenReturn(new SimulationFilter());
    	tested.btnSimulationAdd();
    }
    
    /**
     * @throws Exception 
     * @see TradingContractFaces#cancelIncludeSimulations
     */
    @Test
    public void test_cancelIncludeSimulations() throws Exception {
    	setupMockServices();
    	
    	tested.cancelIncludeSimulations();
    }
    
    /**
     * Just for increasing coverage. Please don't tell 
     * your Mom what we are doing here!
     * 
     * @throws Exception
     */
    @Test
    public void test_OneLineCoverage() throws Exception {
    	setupMockServices();
    	
    	tested.getTradingContractFilter();
    	tested.setTradingContractFilter(null);
    	tested.getTradingContracts();
    	tested.getListCommodity();
    	tested.isDisabledCboRegion();
    	tested.isDisabledSackGrossPrice();
    	tested.isDisabledCboSquare();
    	tested.getListRegion();
    	tested.getHistoryList();
    	tested.setTab(null);
    	tested.getMessagePanel();
    	tested.getListStatus();
    	tested.getTradingContractBusiness();
    	tested.getSimulationList();
    	tested.getSimulationBusiness();
    	tested.setQuotationFilter(null);
    	tested.getQuotationBusiness();
    	tested.setIndex(0);
    	tested.getStatusDeleteLabel();
    	tested.isRenderUsdRate();
    	tested.isRenderedConvertedValue();
    	tested.isCanAccessTradingContractNew();
    }
	
	/**
	 * Setup method constructor allows to inject services through beanFactory mock.
	 */
	private void setupMockServices() {
		
		tested = SilentObjectCreator.create(TradingContractFaces.class);//avoid default constructor
		
		SimulationFaces simulationFacesMock = mock(SimulationFaces.class);
    	List<SimulationBusiness> simulationBusinesses = new ArrayList<SimulationBusiness>();
    	SimulationBusiness simulationBusiness = new SimulationBusiness();
    	simulationBusiness.setChecked(true);
    	simulationBusinesses.add(simulationBusiness);
    	when(simulationFacesMock.getSimulationList()).thenReturn(simulationBusinesses);
    	
    	FacesContext facesContextMock = FacesContext.getCurrentInstance();
    	ELResolver elResolver = facesContextMock.getELContext().getELResolver();
    	elResolver.setValue(facesContextMock.getELContext(), null, "simulationFaces", simulationFacesMock);
		
    	ITradingContractService tradingContractServiceMock = mock(ITradingContractService.class);
    	List<SimulationBusiness> list1 = new ArrayList<SimulationBusiness>();
		when(tradingContractServiceMock.validateBalance(Matchers.anyListOf(SimulationBusiness.class), Matchers.anyListOf(SimulationBusiness.class), 
						Matchers.any(TradingContract.class))).thenReturn(list1);
		
		List<SimulationBusiness> list2 = new ArrayList<SimulationBusiness>();
		Whitebox.setInternalState(tested, "simulationList", list2);
		List<SimulationBusiness> list3 = new ArrayList<SimulationBusiness>();
		Whitebox.setInternalState(tested, "simulationBackupList", list3);
		
		//
		BeanFactory beanFactoryMock = mock(BeanFactory.class);
		when(beanFactoryMock.getBean(ITradingContractService.class)).thenReturn(tradingContractServiceMock);
		Whitebox.setInternalState(tested, beanFactoryMock);// inject beanFactory

	}


    @Test
    public void testSetCampaign(){

        TradingContractFacesForTest tradingContractFacesForTest = initializeTradingContractFaces();

        Campaign campaign = new Campaign();
        campaign.setCommodities( new ArrayList<Commodity>());

        Commodity commodity = new Commodity();
        commodity.setCurrencyCd("BR");
        commodity.setDescCommodity("commodity");
        commodity.setId(new CommodityId("commid","br"));

        campaign.getCommodities().add(commodity);

        campaign.setTradings(new ArrayList<Trading>());

        Trading trading = new Trading();
        trading.setDescTrading("tdesc");
        trading.setId(new TradingId("trading","br"));


        campaign.getTradings().add(trading);

        tradingContractFacesForTest.setCampaign(campaign);

        tradingContractFacesForTest.searchFromPopup();

        assertEquals(1,tradingContractFacesForTest.getListCommodity().size());
        assertEquals(1,tradingContractFacesForTest.getListTrading().size());

    }


}
