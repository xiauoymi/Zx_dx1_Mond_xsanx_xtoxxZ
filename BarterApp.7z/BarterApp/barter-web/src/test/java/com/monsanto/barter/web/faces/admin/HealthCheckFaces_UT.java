package com.monsanto.barter.web.faces.admin;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import com.monsanto.barter.architecture.util.DetailedHealthMessage;
import com.monsanto.barter.architecture.util.HealthChecker;
import com.monsanto.commercial.lyceum.core.web.health.HealthCheckStatus;
import com.monsanto.commercial.lyceum.core.web.health.config.generated.HealthCheckConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

@RunWith(PowerMockRunner.class)
@PrepareForTest(value = {FacesContext.class, HealthChecker.class, HealthCheckFaces.class})
public class HealthCheckFaces_UT {

    private static String testInputContents = "Manifest-Version: 1.0\n" +
            "Ant-Version: Apache Ant 1.6.5\n" +
            "Created-By: R28.2.3-13-149708-1.6.0_31-20120327-1523-windows-ia32 (Oracle Corporation)\n" +
            "Implementation-Title: Barter Web\n" +
            "Implementation-Version: 1.0.0-SNAPSHOT\n" +
            "Built-By: TESTUSER\n" +
            "Built-Date: 2013-01-01, 00:00:00 AM\n" +
            "Built-Reason: Test Build.";

    private HealthCheckStatus mockedHealthCheckStatus;
    private HealthChecker mockedHealthChecker;

    public HealthCheckFaces buildFacesBean() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(testInputContents.getBytes());

        FacesContext mockedFacesContext = mock(FacesContext.class);
        ExternalContext mockedExternalContext = mock(ExternalContext.class);
        HttpServletRequest mockedHttpServletRequest = mock(HttpServletRequest.class);
        HttpSession mockedHttpSession = mock(HttpSession.class);
        ServletContext mockedServletContext = mock(ServletContext.class);
        mockStatic(FacesContext.class);
        mockStatic(HealthChecker.class);
        mockedHealthChecker = mock(HealthChecker.class);
        mockedHealthCheckStatus = mock(HealthCheckStatus.class);

        when(FacesContext.getCurrentInstance()).thenReturn(mockedFacesContext);
        when(mockedFacesContext.getExternalContext()).thenReturn(mockedExternalContext);
        when(mockedExternalContext.getRequest()).thenReturn(mockedHttpServletRequest);
        when(mockedHttpServletRequest.getSession()).thenReturn(mockedHttpSession);
        when(mockedHttpSession.getServletContext()).thenReturn(mockedServletContext);
        when(mockedServletContext.getResourceAsStream("/version.txt")).thenReturn(inputStream);

        whenNew(HealthChecker.class).withParameterTypes(HealthCheckConfig.class).withArguments(any()).thenReturn(mockedHealthChecker);

        return new HealthCheckFaces();
    }

    @Test
    public void begin() throws Exception {
        final String testItem = "testItem";
        final String testStatus = "testStatus";
        final String testHost = "testHost";
        final String overallHealthTestMessage = "OverallHealthTestMessage";
        HealthCheckFaces faces = buildFacesBean();
        when(mockedHealthChecker.getHealthCheckStatus()).thenReturn(mockedHealthCheckStatus);
        HashMap<String, String> healthMessages = new HashMap<String, String>();
        healthMessages.put(testItem, testStatus);
        when(mockedHealthCheckStatus.getDetailedHealthMsgs()).thenReturn(healthMessages);
        when(mockedHealthCheckStatus.getHostName()).thenReturn(testHost);
        when(mockedHealthCheckStatus.getOverallHealthMsg()).thenReturn(overallHealthTestMessage);
        String response = faces.begin();
        assertThat(response, is("healthCheck"));
        assertThat(faces.getBuildDate(), is("2013-01-01, 00:00:00 AM"));
        assertThat(faces.getVersion(), is("1.0.0-SNAPSHOT"));
        assertThat(faces.getHostName(), is(testHost));
        assertThat(faces.getHealthMessage(), is(overallHealthTestMessage));
        List<DetailedHealthMessage> messages = faces.getDetailHealthMessage();
        assertThat(messages.size(), is(1));
        assertThat(messages.get(0).getHealthCheckItem(), is(testItem));
        assertThat(messages.get(0).getStatus(), is(testStatus));
    }

    @Test
    public void beginWithoutEnvironment() throws Exception {
        FacesContext mockedFacesContext = mock(FacesContext.class);
        ExternalContext mockedExternalContext = mock(ExternalContext.class);
        HttpServletRequest mockedHttpServletRequest = mock(HttpServletRequest.class);
        HttpSession mockedHttpSession = mock(HttpSession.class);
        ServletContext mockedServletContext = mock(ServletContext.class);
        mockStatic(FacesContext.class);

        when(FacesContext.getCurrentInstance()).thenReturn(mockedFacesContext);
        when(mockedFacesContext.getExternalContext()).thenReturn(mockedExternalContext);
        when(mockedExternalContext.getRequest()).thenReturn(mockedHttpServletRequest);
        when(mockedHttpServletRequest.getSession()).thenReturn(mockedHttpSession);
        when(mockedHttpSession.getServletContext()).thenReturn(mockedServletContext);
        when(mockedServletContext.getResourceAsStream("/version.txt")).thenReturn(null);

        HealthCheckFaces faces = new HealthCheckFaces();
        String response = faces.begin();
        assertThat(response, is("healthCheck"));
        assertThat(faces.getBuildDate(), is("none"));
        assertThat(faces.getVersion(), is("none"));
        assertThat(faces.getHostName(), is(notNullValue()));
        assertThat(faces.getHealthMessage(), is(notNullValue()));
        assertThat(faces.getDetailHealthMessage(), is(notNullValue()));
    }
}
