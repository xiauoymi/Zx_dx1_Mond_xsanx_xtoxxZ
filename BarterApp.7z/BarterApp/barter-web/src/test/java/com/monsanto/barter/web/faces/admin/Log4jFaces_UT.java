package com.monsanto.barter.web.faces.admin;

import com.monsanto.barter.architecture.util.ManagedLogger;
import com.monsanto.barter.web.test.JsfTestCase;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.primefaces.component.datatable.DataTable;

import javax.faces.model.ArrayDataModel;
import javax.faces.model.DataModel;

import static com.monsanto.barter.web.faces.admin.Log4jFaces.LOG4J_ADMIN_FORM;
import static com.monsanto.barter.web.faces.admin.Log4jFaces.LOG4J_ADMIN_LIST;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

public class Log4jFaces_UT extends JsfTestCase {

    private Log4jFaces log4jFaces;

    @Before
	public void setUp() throws Exception {
		super.setUp();
        log4jFaces = new Log4jFaces();
	}

    @Test
	public void list_screen_begin_and_search_test_without_parameters() {
		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.begin());

		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.search());

		assertTrue("Should have found at least one register", log4jFaces.getList().getRowCount() > 1);
	}

    @Test
	public void list_screen_begin_and_search_test_with_parameters_should_return_one_result() {
		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.begin());

        log4jFaces.setSearchName("root");

		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.search());

		assertTrue("Should have found at least one register", log4jFaces.getList().getRowCount() == 1);
	}

    @Test
    public void list_screen_prependDeleteOrUpdate_test() {
		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.begin());
        log4jFaces.getList().setRowIndex(0);

        assertEquals("Should have redirected to the edit page", LOG4J_ADMIN_FORM, log4jFaces.prependUpdate());
    }

	@Test
	public void form_screen_save_test() {
		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.begin());

        log4jFaces.setSearchName("root");

        assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.search());

        log4jFaces.getList().setRowIndex(0);

        assertEquals("Should have redirected to the edit page", LOG4J_ADMIN_FORM, log4jFaces.prependUpdate());

        assertNotNull("Should have value different than null", log4jFaces.getCurrentLogger());

        assertEquals("root", log4jFaces.getCurrentLogger().getName());

        log4jFaces.getCurrentLogger().setLevel("ERROR");

        assertEquals("Should have redirected to the edit page", LOG4J_ADMIN_FORM, log4jFaces.save());
        assertEquals("Should have level ERROR.", "ERROR", log4jFaces.getCurrentLogger().getLevel());
    }

    @Test
    public void form_screen_back_test() {
		assertEquals("Should have redirected to the list page", LOG4J_ADMIN_LIST, log4jFaces.begin());
        log4jFaces.getList().setRowIndex(0);

        assertEquals("Should have redirected to the edit page", LOG4J_ADMIN_FORM,
                log4jFaces.prependUpdate());

        assertEquals("Should have redirected to list page",LOG4J_ADMIN_LIST, log4jFaces.back() );
    }

    @Test
    public void form_screen_save_test_failure() {
        log4jFaces.setSearchName("root");
        assertEquals(null, log4jFaces.save());
    }

    @Test
    public void testSetters(){
        DataModel<ManagedLogger> list = new ArrayDataModel<ManagedLogger>();
        log4jFaces.setList(list);
        log4jFaces.setSearchName("TEST_SEARCH");
        DataTable dataTable = new DataTable();
        log4jFaces.setDataTable(dataTable);
        ManagedLogger managedLogger = new ManagedLogger();
        log4jFaces.setCurrentLogger(managedLogger);

        Assert.assertEquals(list, log4jFaces.getList());
        Assert.assertEquals("TEST_SEARCH", log4jFaces.getSearchName());
        Assert.assertEquals(dataTable, log4jFaces.getDataTable());
        Assert.assertEquals(managedLogger, log4jFaces.getCurrentLogger());
    }

}
