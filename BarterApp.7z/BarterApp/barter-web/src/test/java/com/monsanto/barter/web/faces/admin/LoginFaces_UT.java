package com.monsanto.barter.web.faces.admin;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.Permission;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.ArrayList;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.matches;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/24/12
 * Time: 2:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class LoginFaces_UT extends JsfTestCase {

    public static final String SUCCESS = "success";

    @Before
	public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
	public void loadUsersTest() {
        LoginFaces loginFaces = new LoginFacesIUserService();
        User user = new User();
        user.setId("User 1");
        loginFaces.setUser(user);
        loginFaces.login();
        Assert.assertNotNull(loginFaces.getUser());
        assertThat(loginFaces.getUser().getId()).isEqualTo("User 1");
    }

    @Test
	public void getUserTest() {
        LoginFaces loginFaces = new LoginFacesIUserService();
        loginFaces.setUser(new User());
        loginFaces.getUser().setId("User 1");
        loginFaces.getUser();
        Assert.assertNotNull(loginFaces.getUser());
        assertThat(loginFaces.getUser().getId()).isEqualTo("User 1");
    }

    @Test
	public void getSetItemsLoginTest() {
        LoginFaces loginFaces = new LoginFacesIUserService();
        loginFaces.getItemsLogin();
        Assert.assertNotNull(loginFaces.getItemsLogin());
        assertThat(loginFaces.getItemsLogin().isEmpty());
    }

    @Test
    public void testLogin() {
         LoginFaces loginFaces = new LoginFacesIUserService();
        User user = new User();
        user.setId("USER.TEST");
        loginFaces.setUser(user);

         String result = loginFaces.login();

         assertThat(result).isEqualToIgnoringCase(SUCCESS);
    }

    public static class LoginFacesIUserService extends LoginFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IUserService.class)) {
                IUserService userService = mock(IUserService.class);
                com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
                userVO.setUserIdMonsanto("USER.TEST");
                ArrayList<Permission> permissions = new ArrayList<Permission>();
                Permission permission = new Permission();
                permission.setPermissionCd(1);
                permissions.add(permission);
                userVO.setPermissions(permissions);
                userVO.setId("User 1");
                Group group = new Group();
                group.setPermissions(permissions);
                userVO.setGroup(group);
                when(userService.findByIdMonsantoWithPermission(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(userVO);
                ArrayList<com.monsanto.barter.business.entity.table.User> users = new ArrayList<com.monsanto.barter.business.entity.table.User>();
                users.add(userVO);
                when(userService.search(Matchers.<UserFilter>any())).thenReturn(users);
                return (T)userService;
            }
            return super.getService(requiredType);
        }
    }
}

