package com.monsanto.barter.web.faces.admin;

import com.monsanto.barter.architecture.regionalization.*;
import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.PermissionBusiness;
import com.monsanto.barter.business.entity.filter.GroupFilter;
import com.monsanto.barter.business.entity.filter.PermissionFilter;
import com.monsanto.barter.business.entity.filter.UnitFilter;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import javax.faces.component.UICommand;
import javax.faces.event.ActionEvent;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/24/12
 * Time: 3:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserFaces_UT extends JsfTestCase {

    public static final String NEW = "new";
    public static final String CHANGE = "change";
    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String SHOW_FILTER = "showFilter";
    public static final String ANY_CODE = "AnyCode";

    @Before
	public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
	public void searchUserTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.searchUser();
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
    }

    @Test
	public void newUserTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String message = userFaces.newUser();
        Assert.assertNotNull(message);
        assertThat(message).isEqualTo(NEW);
    }

    @Test
	public void editUserTest() {
        UserFaces userFaces = new UserFacesIUserService();

        String message = userFaces.editUser();
        Assert.assertNotNull(message);
        assertThat(message).isEqualTo(CHANGE);
    }

    @Test
	public void saveUserTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setSaleDistrictId("1");
        userFaces.setGroupId("1");

        String notNavigate = userFaces.saveUser();

        Assert.assertNotNull(notNavigate);
        assertThat(notNavigate).isEqualTo(NOT_NAVIGATE);
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
        assertThat(userFaces.getMessages()).isEmpty();
        assertThat(userFaces.getUserVO().getUpdateWeb()).isEqualTo('S');
        assertThat(userFaces.getUserVO().getBarterUser()).isEqualTo('S');
        assertThat( userFaces.getUserVO().getCountryCd()).isEqualTo(Country.PARAGUAY.getCountrySAPCd());
    }

    @Test
	public void detailUserTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String navigation = userFaces.detailUser();
        Assert.assertNotNull(navigation);
        assertThat(navigation).isEqualTo(CHANGE);
    }

    @Test
	public void cancelUserNewerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String navigation = userFaces.cancelUser();
        Assert.assertNotNull(navigation);
        assertThat(navigation).isEqualTo(SHOW_FILTER);
    }

    @Test
	public void cancelUserNotNewerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setNewer(false);
        String navigation = userFaces.cancelUser();
        Assert.assertNotNull(navigation);
        assertThat(navigation).isEqualTo(SHOW_FILTER);
    }

    @Test
	public void showUsersTabTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String notNavigate = userFaces.showUsersTab();
        Assert.assertNotNull(notNavigate);
        assertThat(notNavigate).isEqualTo(NOT_NAVIGATE);
    }

    @Test
	public void showPermissionsTabTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String notNavigate = userFaces.showPermissionsTab();
        Assert.assertNotNull(notNavigate);
        assertThat(notNavigate).isEqualTo(NOT_NAVIGATE);
    }

    @Test
	public void showHistoryTabTest() {
        UserFaces userFaces = new UserFacesIUserService();
        String notNavigate = userFaces.showHistoryTab();
        Assert.assertNotNull(notNavigate);
        assertThat(notNavigate).isEqualTo(NOT_NAVIGATE);
    }

    @Test
	public void cboGroupListenerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setGroupId("1");
        userFaces.cboGroupListener();
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
        assertThat(userFaces.getMessages()).isEmpty();
        assertThat(userFaces.getUserVO().getUpdateWeb()).isEqualTo('S');
        assertThat(userFaces.getUserVO().getBarterUser()).isEqualTo('S');
    }

    @Test
	public void cboUnitListenerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.cboUnitListener();
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
        assertThat(userFaces.getMessages()).isEmpty();
        assertThat(userFaces.getUserVO().getUpdateWeb()).isEqualTo('S');
        assertThat(userFaces.getUserVO().getBarterUser()).isEqualTo('S');
    }
    @Test
	public void cboRegionalListenerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setRegionalId("1");
        userFaces.cboRegionalListener();
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
        assertThat(userFaces.getMessages()).isEmpty();
        assertThat(userFaces.getUserVO().getUpdateWeb()).isEqualTo('S');
        assertThat(userFaces.getUserVO().getBarterUser()).isEqualTo('S');
    }

    @Test
	public void cboModuleListenerTest() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setModule("1");
        userFaces.cboModuleListener();
        assertThat(userFaces.getMessages()).isEmpty();
    }
    @Test
	public void cboPermissionTypeListenerTestWithPermissionType() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setPermissionType("1");
        userFaces.cboPermissionTypeListener();
        assertThat(userFaces.getMessages()).isEmpty();
    }
    @Test
	public void cboPermissionTypeListenerTestWithoutPermissionType() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.cboPermissionTypeListener();
        assertThat(userFaces.getMessages()).isEmpty();
    }

    @Test
	public void cboUnitListenerTestWithUnitId() {
        UserFaces userFaces = new UserFacesIUserService();
        userFaces.setUnitId("1");
        userFaces.cboUnitListener();
        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertTrue(userFaces.getItemsUnit().size() == 1);
        Assert.assertTrue(userFaces.getItemsGroup().size() == 1);
        assertThat(userFaces.getMessages()).isEmpty();
        assertThat(userFaces.getUserVO().getUpdateWeb()).isEqualTo('S');
        assertThat(userFaces.getUserVO().getBarterUser()).isEqualTo('S');
    }

    @Test
	public void getQtUsersTest() {
        UserFaces userFaces = new UserFacesIUserService();
        List users = new ArrayList<User>();
        com.monsanto.barter.business.entity.table.User userEntity = new com.monsanto.barter.business.entity.table.User();
        userEntity.setId("User 1");
        com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
        userVO.setId("User VO");
        users.add(userVO);
        userFaces.setUsers(users);
        int qtUsers = userFaces.getQtUsers();
        Assert.assertTrue(userFaces.getUsers().size() == qtUsers);
    }

    @Test
	public void getQtPermissionsTest() {
        UserFaces userFaces = new UserFacesIUserService();
        List<PermissionBusiness> allPermissions = new ArrayList<PermissionBusiness>();
        PermissionBusiness permissionBusiness = new PermissionBusiness();
        permissionBusiness.setModuleCd(Integer.valueOf("1"));
        permissionBusiness.setPermissionCd(Integer.valueOf("1"));
        permissionBusiness.setPermissionTypeCd(Integer.valueOf("1"));
        allPermissions.add(permissionBusiness);
        userFaces.setPermissions(allPermissions);
        int qtPermissions = userFaces.getQtPermissions();
        Assert.assertTrue(userFaces.getPermissions().size() == qtPermissions);
    }

    @Test
	public void getQtUserHistoryTest() {
        UserFaces userFaces = new UserFacesIUserService();
        List<UserHistory> histories = new ArrayList<UserHistory>();
        UserHistory userHistory = new UserHistory();
        userHistory.setId(1L);
        histories.add(userHistory);
        com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
        userVO.setId("User VO");
        userVO.setHistories(histories);
        userFaces.setUserVO(userVO);
        int qtUserHistory = userFaces.getQtUserHistory();
        Assert.assertTrue(userFaces.getUserVO().getHistories().size() == qtUserHistory);
    }

    @Test
    public void testGetSetTab() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setTab(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getTab());
    }
    @Test
    public void testGetSetGroupId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setGroupId(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getGroupId());
    }
    @Test
    public void testGetSetUnitId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setUnitId(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getUnitId());
    }
    @Test
    public void testGetSetRegionalId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setRegionalId(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getRegionalId());
    }
    @Test
    public void testGetSetSaleDistrictId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setSaleDistrictId(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getSaleDistrictId());
    }
    @Test
    public void testGetSetModule() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setModule(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getModule());
    }
    @Test
    public void testGetSetModuleId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setModuleId(new Integer(0));

         Assert.assertEquals(new Integer(0), userFaces.getModuleId());
    }
    @Test
    public void testGetSetPermissionTypeId() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setPermissionTypeId(new Integer(0));

         Assert.assertEquals(new Integer(0), userFaces.getPermissionTypeId());
    }

    @Test
    public void testGetSetItemsGroup() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsGroup = new ArrayList<SelectItem>();
        itemsGroup.add(new SelectItem());

        userFaces.setItemsGroup(itemsGroup);

        Assert.assertNotNull(userFaces.getItemsGroup());
        Assert.assertFalse(userFaces.getItemsGroup().isEmpty());
        Assert.assertEquals(1, userFaces.getItemsGroup().size());
    }
    @Test
    public void testGetSetItemsUnit() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsUnit = new ArrayList<SelectItem>();
        itemsUnit.add(new SelectItem());

        userFaces.setItemsUnit(itemsUnit);

        Assert.assertNotNull(userFaces.getItemsUnit());
        Assert.assertFalse(userFaces.getItemsUnit().isEmpty());
        Assert.assertEquals(1, userFaces.getItemsUnit().size());
    }
    @Test
    public void testGetSetItemsRegional() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsRegional = new ArrayList<SelectItem>();
        itemsRegional.add(new SelectItem());

        userFaces.setItemsRegional(itemsRegional);

        Assert.assertNotNull(userFaces.getItemsRegional());
        Assert.assertFalse(userFaces.getItemsRegional().isEmpty());
        Assert.assertEquals(1, userFaces.getItemsRegional().size());
    }
    @Test
    public void testGetSetItemsSaleDistrict() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsSaleDistrict = new ArrayList<SelectItem>();
        itemsSaleDistrict.add(new SelectItem());

        userFaces.setItemsSaleDistrict(itemsSaleDistrict);

        Assert.assertNotNull(userFaces.getItemsSaleDistrict());
        Assert.assertFalse(userFaces.getItemsSaleDistrict().isEmpty());
        Assert.assertEquals(1, userFaces.getItemsSaleDistrict().size());
    }
    @Test
    public void testGetSetItemsLanguages() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsLanguages = new ArrayList<SelectItem>();
        itemsLanguages.add(new SelectItem());

        userFaces.setItemsLanguages(itemsLanguages);

        Assert.assertNotNull(userFaces.getItemsLanguages());
        Assert.assertFalse(userFaces.getItemsLanguages().isEmpty());
        Assert.assertEquals(3, userFaces.getItemsLanguages().size());
    }
    @Test
    public void testGetSetItemsStatus() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsStatus = new ArrayList<SelectItem>();
        itemsStatus.add(new SelectItem());

        userFaces.setItemsStatus(itemsStatus);

        Assert.assertNotNull(userFaces.getItemsStatus());
        Assert.assertFalse(userFaces.getItemsStatus().isEmpty());
        Assert.assertEquals(2, userFaces.getItemsStatus().size());
    }
    @Test
    public void testGetSetItemsModules() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsModules = new ArrayList<SelectItem>();
        itemsModules.add(new SelectItem());

        userFaces.setItemsModules(itemsModules);

        Assert.assertNotNull(userFaces.getItemsModules());
        Assert.assertFalse(userFaces.getItemsModules().isEmpty());
        Assert.assertEquals(10, userFaces.getItemsModules().size());
    }
    @Test
    public void testGetSetItemsPermissionTypes() {
         UserFaces userFaces = new UserFacesIUserService();
        ArrayList<SelectItem> itemsPermissionType = new ArrayList<SelectItem>();
        itemsPermissionType.add(new SelectItem());

        userFaces.setItemsPermissionTypes(itemsPermissionType);

        Assert.assertNotNull(userFaces.getItemsPermissionTypes());
        Assert.assertFalse(userFaces.getItemsPermissionTypes().isEmpty());
        Assert.assertEquals(2, userFaces.getItemsPermissionTypes().size());
    }
    

    @Test
    public void testGetSetPermissionType() {
         UserFaces userFaces = new UserFacesIUserService();
         userFaces.setPermissionType(ANY_CODE);

         Assert.assertEquals(ANY_CODE, userFaces.getPermissionType());
    }

    @Test
    public void testGetSetUserFilter() {
         UserFaces userFaces = new UserFacesIUserService();

        UserFilter userFilter = new UserFilter();
        userFilter.setGroupId(ANY_CODE);

        userFaces.setUserFilter(userFilter);

        Assert.assertEquals(ANY_CODE, userFaces.getUserFilter().getGroupId());
    }

    @Test
    public void testIsSetEnableRegionalCombo() {
        UserFaces userFaces = new UserFacesIUserService();

        userFaces.setEnableRegionalCombo(false);

        Assert.assertFalse(userFaces.isEnableRegionalCombo());
    }
    @Test
    public void testIsEnableSaveBtn() {
        UserFaces userFaces = new UserFacesIUserService();

        Assert.assertFalse(userFaces.isEnableSaveBtn());
    }
    @Test
    public void testIsSetEnableSaleDistrictCombo() {
        UserFaces userFaces = new UserFacesIUserService();

        userFaces.setEnableSaleDistrictCombo(false);

        Assert.assertFalse(userFaces.isEnableSaleDistrictCombo());
    }
    public void testIsSetTableShow() {
        UserFaces userFaces = new UserFacesIUserService();

        userFaces.setTableShow(false);

        Assert.assertFalse(userFaces.isTableShow());
    }

    public static class UserFacesIUserService extends UserFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IUserService.class)) {
                IUserService userService = mock(IUserService.class);
                List users = new ArrayList<User>();
                com.monsanto.barter.business.entity.table.User userEntity = new com.monsanto.barter.business.entity.table.User();
                userEntity.setId("User 1");
                com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
                userVO.setId("User VO");
                Unit unit = new Unit();
                unit.setId(ANY_CODE);
                userVO.setUnit(unit);
                userVO.setRegional(new Regional());
                userVO.getRegional().setId(ANY_CODE);
                userVO.setSaleDistrict(new SaleDistrict());
                userVO.getSaleDistrict().setId(new Long(1L));
                userVO.setGroup(new Group());
                userVO.getGroup().setId(new Long(1L));
                users.add(userVO);
                when(userService.findByIdMonsantoWithPermission(userEntity)).thenReturn(userVO);
                when(userService.findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(userVO);
                when(userService.search(Matchers.<UserFilter>any())).thenReturn(users);
                Mockito.doNothing().when(userService).save(userVO);
                Mockito.doNothing().when(userService).update(userVO);
                return (T)userService;
            }
            if (requiredType.equals(IUnitService.class)) {
                IUnitService unitService = mock(IUnitService.class);
                Unit unit = new com.monsanto.barter.business.entity.table.Unit();
                unit.setId("Unit 1");
                List<Unit> units = new ArrayList<Unit>();
                units.add(unit);
                when(unitService.search(Matchers.<UnitFilter>any())).thenReturn(units);
                when(unitService.findById(unit)).thenReturn(unit);
                return (T)unitService;
            }
            if (requiredType.equals(IGroupService.class)) {
                IGroupService groupService = mock(IGroupService.class);
                Group group = new Group();
                group.setId(1L);
                List<com.monsanto.barter.business.entity.table.Group> groups = new ArrayList<com.monsanto.barter.business.entity.table.Group>();
                groups.add(group);
                when(groupService.search(Matchers.<GroupFilter>any())).thenReturn(groups);
                when(groupService.findByIdComplete(group)).thenReturn(group);
                when(groupService.findById(group)).thenReturn(group);
                return (T)groupService;
            }
            if (requiredType.equals(IRegionalService.class)) {
                IRegionalService groupService = mock(IRegionalService.class);
                Regional regional = new Regional();
                regional.setId("Regional 1");
                List<Regional> regionals = new ArrayList<Regional>();
                regionals.add(regional);
                when(groupService.search(Matchers.<UnitFilter>any())).thenReturn(regionals);
                return (T)groupService;
            }
            if (requiredType.equals(IPermissionService.class)) {
                IPermissionService permissionService = mock(IPermissionService.class);
                List<PermissionBusiness> allPermissions = new ArrayList<PermissionBusiness>();
                PermissionBusiness permissionBusiness = new PermissionBusiness();
                permissionBusiness.setModuleCd(Integer.valueOf("1"));
                permissionBusiness.setPermissionCd(Integer.valueOf("1"));
                permissionBusiness.setPermissionTypeCd(Integer.valueOf("1"));
                allPermissions.add(permissionBusiness);
                Group group = new Group();
                group.setId(1L);
                List<com.monsanto.barter.business.entity.table.Group> groups = new ArrayList<com.monsanto.barter.business.entity.table.Group>();
                groups.add(group);
                when(permissionService.search(Matchers.<PermissionFilter>any())).thenReturn(allPermissions);
                return (T)permissionService;
            }
            if (requiredType.equals(ISaleDistrictService.class)) {
                ISaleDistrictService saleDistrictService = mock(ISaleDistrictService.class);
                SaleDistrict saleDistrict = new SaleDistrict();
                saleDistrict.setId(1L);
                when(saleDistrictService.findById(Matchers.<SaleDistrict>any())).thenReturn(saleDistrict);
                return (T)saleDistrictService;
            }

            return super.getService(requiredType);
        }

        @Override
        public Country getCountry() {
            return Country.PARAGUAY;
        }
    }
}