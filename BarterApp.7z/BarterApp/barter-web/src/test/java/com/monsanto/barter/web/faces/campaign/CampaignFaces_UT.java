package com.monsanto.barter.web.faces.campaign;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.faces.component.UICommand;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

// import org.ajax4jsf.component.html.HtmlAjaxCommandButton;
import com.monsanto.barter.architecture.regionalization.*;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.reflect.Whitebox;
import org.richfaces.component.UICommandButton;
import org.springframework.beans.factory.BeanFactory;

import com.monsanto.barter.architecture.entity.BaseEntity;
import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.CampaignBrandBusiness;
import com.monsanto.barter.business.entity.business.CampaignDivisionUnitBusiness;
import com.monsanto.barter.business.entity.filter.BarterTypeFilter;
import com.monsanto.barter.business.entity.filter.CampaignFilter;
import com.monsanto.barter.business.entity.filter.CommodityFilter;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.filter.CurrencyFilter;
import com.monsanto.barter.business.entity.filter.DivisionFilter;
import com.monsanto.barter.business.entity.filter.ProductFilter;
import com.monsanto.barter.business.entity.filter.TradingFilter;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.list.StatusList;
import com.monsanto.barter.business.entity.table.id.BarterTypeId;
import com.monsanto.barter.business.entity.table.id.CommodityId;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.entity.table.id.CurrencyId;
import com.monsanto.barter.business.entity.table.id.DivisionId;
import com.monsanto.barter.business.entity.table.id.TradingId;
import com.monsanto.barter.business.service.impl.CampaignService;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.test.SilentObjectCreator;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 9/26/12
 * Time: 1:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class CampaignFaces_UT extends JsfTestCase {

    private static final String NOT_NAVIGATE = "notNavigate";
    public static final String USER_TEST = "USER.TEST";
    public static final String COUNTRY_CD = "BRL";
    public static final String ANY_CODE= "ANY_CODE";
    public static final String NEW = "new";
    public static final String CHANGE = "change";

    private static final String BARTER_TYPE_ID = "1";
    private static final String COUNTRY_ID = "BR";
    private CampaignFaces tested;

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        loggedInUser.setId(USER_TEST);
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
    public void searchCampaignTest() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        campaignFaces.init();

        campaignFaces.searchCampaign();
        Assert.assertTrue(campaignFaces.getCampaignList().size() == 1);
    }

    @Test
    public void updateValuesBarterTestNoValid() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.updateValuesBarter();
        Assert.assertTrue(("".equals(campaignFaces.getMessages())));
    }

    @Test
    public void loadDivisionsTest() {
        CampaignFaces campaignFaces = new CampaignFacesIDivisionService();
        campaignFaces.init();
        campaignFaces.loadDivisions();
        Assert.assertTrue(campaignFaces.getDivisionsCampaign().size() == 2);
    }

    @Test
    public void loadCurrenciesTest() {
        CampaignFaces campaignFaces = new CampaignFacesICurrencyService();
        campaignFaces.init();
        campaignFaces.loadCurrencies();
        Assert.assertTrue(campaignFaces.getCurrencyCampaign().size() == 2);
    }

    @Test
    public void loadCountriesTest() {
        CampaignFaces campaignFaces = new CampaignFacesICountryService();
        campaignFaces.init();
        campaignFaces.loadCountries();
        Assert.assertTrue(campaignFaces.getCountryCampaign().size() == 2);
    }

    @Test
    public void loadTradingsTest() {
        CampaignFaces campaignFaces = new CampaignFacesITradingService();
        campaignFaces.loadTradings("BR");
        Assert.assertTrue(campaignFaces.getTradingsCampaign().size() == 1);
    }

    @Test
    public void loadCommoditiesTest() {
        CampaignFaces campaignFaces = new CampaignFacesICommodityService();
        campaignFaces.loadCommodities("BR");
        Assert.assertTrue(campaignFaces.getCommoditiesCampaign().size() == 1);
    }

    @Test
    public void loadUnitsTest() {
        CampaignFaces campaignFaces = new CampaignFacesISalesOrgCustomerService();
        campaignFaces.init();
        campaignFaces.loadUnits();
        Assert.assertTrue(campaignFaces.getUnitsCampaign().size() == 2);
    }

    @Test
    public void loadBrandsTest() {
        CampaignFaces campaignFaces = new CampaignFacesIProductService();
        campaignFaces.loadBrands("17");
        Assert.assertTrue(campaignFaces.getBrandsCampaign().size() == 1);
    }

    @Test
    public void testSaveCampaignIsNotNewer() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        Assert.assertTrue(campaignFaces.begin().equals("success"));
        String result = campaignFaces.saveCampaign();

        Assert.assertNotNull(result);

    }

    /**
     * @see CampaignFaces#saveCampaign()
     * @throws Exception
     */
    @Test
    public void testSaveCampaignIsNewer() throws Exception {

        setupMockServices();

        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        List<MessageVO> messages = new ArrayList<MessageVO>();
        messages.add(new MessageVO(IBarterConstants.MSG_CONCURRENCE_ERROR, MessageTypeList.INFO));

        tested = PowerMockito.spy(tested);
        PowerMockito.doNothing().when(tested, "completingCampaign");
        PowerMockito.doNothing().when(tested, "init");
        PowerMockito.doNothing().when(tested, "loadDivisions");
        PowerMockito.doReturn("").when(tested, "searchCampaign");
        PowerMockito.doNothing().when(tested, "populateCampaign");
        PowerMockito.doNothing().when(tested, "loadTradings", anyString());
        PowerMockito.doNothing().when(tested, "loadCommodities", anyString());


        String result = tested.saveCampaign();
        Assert.assertNotNull(result);
        Assert.assertEquals(NOT_NAVIGATE, result);

        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(messages);
        when(getServiceMock(ICampaignService.class).findByIdComplete(any(Campaign.class))).thenReturn(campaign);
        result = tested.saveCampaign();

        messages.clear();
        messages.add(new MessageVO(IBarterConstants.EMPTY_KEY, MessageTypeList.INFO));
        result = tested.saveCampaign();

        when(getServiceMock(ICampaignService.class).isOk()).thenReturn(true);
        result = tested.saveCampaign();


        Whitebox.setInternalState(tested, "newer", true);
        result = tested.saveCampaign();
        Assert.assertNotNull(result);
        Assert.assertEquals("showFilter", result);
    }

    /**
     * @see CampaignFaces#completingCampaign()
     * @throws Exception
     */
    @Test
    public void testCompletingCampaign() throws Exception {
        setupMockServices();
        tested = PowerMockito.spy(tested);

        Campaign campaign = new Campaign();
        campaign.setAuthor(new com.monsanto.barter.business.entity.table.User());
        campaign.setCountry(new Country(new CountryId()));
        campaign.setCurrency(new Currency(new CurrencyId()));
        tested.setCampaign(campaign);
        CampaignDivisionUnit campaignDivisionUnit = new CampaignDivisionUnit();
        CampaignDivisionUnitBusiness campaignDivisionUnitBusiness = new CampaignDivisionUnitBusiness();
        List<CampaignDivisionUnit> campaignDivisionUnits = Arrays.asList(new CampaignDivisionUnit[]{campaignDivisionUnit });
        List<CampaignDivisionUnit> divUnits = PowerMockito.spy(new ArrayList<CampaignDivisionUnit>());


        Whitebox.setInternalState(tested, "newer", true);
        Whitebox.setInternalState(tested, "divisionUnitsCampaignList", Arrays.asList(new CampaignDivisionUnitBusiness[]{campaignDivisionUnitBusiness }));
        PowerMockito.doReturn(campaignDivisionUnits).when(tested, "convertToCampaignBrand");

        tested.completingCampaign();

        Assert.assertEquals(USER_TEST, tested.getCampaign().getAuthor().getId());

        ArrayList<CampaignDivisionUnit> currentUnits = PowerMockito.spy(new ArrayList<CampaignDivisionUnit>());
        currentUnits.add(new CampaignDivisionUnit());
        campaign.setCampaignDivisionUnits(currentUnits);
        PowerMockito.doReturn(divUnits).when(tested, "convertToCampaignDivisionUnit");
        when(currentUnits.removeAll(anyListOf(CampaignDivisionUnit.class))).thenReturn(true);
        tested.completingCampaign();

        when(divUnits.indexOf(any(CampaignDivisionUnit.class))).thenReturn(0);
        tested.completingCampaign();
    }

    @Test
    public void testUpdateValuesDiscount() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setNewer(true);
        campaignFaces.setCampaign(new Campaign());
        campaignFaces.init();
        campaignFaces.updateValuesDiscount();

        Assert.assertEquals(BigDecimal.ZERO, campaignFaces.getValueDiscountConsumed());
    }

    @Test
    public void testValidateCampaign() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setNewer(true);

        String result = campaignFaces.validateCampaign();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testReturnCampaign() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        String result = campaignFaces.returnCampaign();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    /**
     * @see CampaignFaces#submitForValidation
     * @throws Exception
     */
    @Test
    public void testSubmitForValidation() throws Exception {
        setupMockServices();

        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        List<MessageVO> messages = new ArrayList<MessageVO>();
        messages.add(new MessageVO(IBarterConstants.MSG_CONCURRENCE_ERROR, MessageTypeList.INFO));

        tested = PowerMockito.spy(tested);
        PowerMockito.doNothing().when(tested, "completingCampaign");
        PowerMockito.doNothing().when(tested, "init");
        PowerMockito.doNothing().when(tested, "loadDivisions");
        PowerMockito.doReturn("").when(tested, "searchCampaign");
        PowerMockito.doNothing().when(tested, "populateCampaign");
        PowerMockito.doNothing().when(tested, "loadTradings", anyString());
        PowerMockito.doNothing().when(tested, "loadCommodities", anyString());


        String result = tested.submitForValidation();
        Assert.assertNotNull(result);
        Assert.assertEquals(NOT_NAVIGATE, result);

        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(messages);
        when(getServiceMock(ICampaignService.class).findByIdComplete(any(Campaign.class))).thenReturn(campaign);
        result = tested.submitForValidation();

        messages.clear();
        messages.add(new MessageVO(IBarterConstants.EMPTY_KEY, MessageTypeList.INFO));
        result = tested.submitForValidation();

        when(getServiceMock(ICampaignService.class).isOk()).thenReturn(true);
        result = tested.submitForValidation();


        Whitebox.setInternalState(tested, "newer", true);
        result = tested.submitForValidation();
        Assert.assertEquals("showFilter", result);
    }

    @Test
    public void testInactivateCampaign() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        String result = campaignFaces.inactivateCampaign();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testConvertToCampaignBrand() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<CampaignBrandBusiness> brandsCampaignList = new ArrayList<CampaignBrandBusiness>();
        CampaignBrandBusiness campaignBrandBusiness = new CampaignBrandBusiness();
        campaignBrandBusiness.setDesc(ANY_CODE);
        campaignBrandBusiness.setIdUnit(ANY_CODE);
        brandsCampaignList.add(campaignBrandBusiness);
        campaignFaces.setBrandsCampaignList(brandsCampaignList);

        List<CampaignBrand> result = campaignFaces.convertToCampaignBrand();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(ANY_CODE, result.get(0).getUnitId());
    }

    @Test
    public void testConvertToCampaignBrandBusiness() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesIDivisionService();
        ArrayList<CampaignBrand> brandsCampaignList = new ArrayList<CampaignBrand>();
        CampaignBrandBusiness campaignBrand = new CampaignBrandBusiness();
        campaignBrand.setDesc(ANY_CODE);
        campaignBrand.setUnitId(ANY_CODE);
        brandsCampaignList.add(campaignBrand);
        campaignFaces.setCampaign(new Campaign());
        campaignFaces.getCampaign().setCampaignBrands(brandsCampaignList);

        List<CampaignBrandBusiness> result = campaignFaces.convertToCampaignBrandBusiness();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(ANY_CODE, result.get(0).getIdUnit());
    }

    @Test
    public void testConvertToCampaignDivisionUnitBusiness() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesIDivisionService();
        ArrayList<CampaignDivisionUnit> campaignDivisionUnitsList = new ArrayList<CampaignDivisionUnit>();
        CampaignDivisionUnit campaignDivisionUnit = new CampaignDivisionUnit();
        campaignDivisionUnit.setId(new Long(1L));
        campaignDivisionUnit.setDivision(new Division(new DivisionId()));
        campaignDivisionUnit.getDivision().getId().setDivisionCd(ANY_CODE);
        campaignDivisionUnit.setUnitId(ANY_CODE);
        campaignDivisionUnitsList.add(campaignDivisionUnit);

        campaignFaces.setCampaign(new Campaign());
        campaignFaces.getCampaign().setCampaignDivisionUnits(campaignDivisionUnitsList);

        List<CampaignDivisionUnitBusiness> result = campaignFaces.convertToCampaignDivisionUnitBusiness();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(ANY_CODE, result.get(0).getUnitId());
    }//convertToCampaignDivisionUnit

    @Test
    public void testConvertToCampaignDivisionUnit() throws Exception {
        CampaignFaces campaignFaces = new CampaignFacesIDivisionService();
        ArrayList<CampaignDivisionUnitBusiness> campaignDivisionUnitsBusinessList = new ArrayList<CampaignDivisionUnitBusiness>();
        CampaignDivisionUnitBusiness divisionUnitBusiness = new CampaignDivisionUnitBusiness();
        divisionUnitBusiness.setId(new Long(1L));
        divisionUnitBusiness.setDivision(new Division(new DivisionId()));
        divisionUnitBusiness.getDivision().getId().setDivisionCd(ANY_CODE);
        divisionUnitBusiness.setUnitId(ANY_CODE);
        campaignDivisionUnitsBusinessList.add(divisionUnitBusiness);

        campaignFaces.setCampaign(new Campaign());
        campaignFaces.setDivisionUnitsCampaignList(campaignDivisionUnitsBusinessList);

        List<CampaignDivisionUnit> result = campaignFaces.convertToCampaignDivisionUnit();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
        Assert.assertEquals(ANY_CODE, result.get(0).getUnitId());
    }

   /* @Test
    public void testCboCountryChangedWithCountryCd() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setCampaign(new Campaign());
        campaignFaces.getCampaign().setTradings(new ArrayList<Trading>());
        campaignFaces.getCampaign().setCommodities(new ArrayList<Commodity>());
        campaignFaces.getCampaign().setCountry(new Country(new CountryId()));
        campaignFaces.getCampaign().getCountry().getId().setCountryCd(COUNTRY_CD);

        campaignFaces.getCampaign().setBarterTypes( new ArrayList<BarterType>());
        BarterType barterType = new BarterType(BARTER_TYPE_ID);
        barterType.getId().setCountryCd(COUNTRY_ID);
        campaignFaces.getCampaign().getBarterTypes().add(barterType);

        campaignFaces.cboCountryChanged();

        Assert.assertNotNull(campaignFaces.getCampaign().getTradings());
    }

    @Test
    public void testCboCountryChangedWithoutCountryCd() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setCampaign(new Campaign());
        campaignFaces.getCampaign().setTradings(new ArrayList<Trading>());
        campaignFaces.getCampaign().setCommodities(new ArrayList<Commodity>());
        campaignFaces.getCampaign().setCountry(new Country(new CountryId()));

        campaignFaces.getCampaign().setBarterTypes( new ArrayList<BarterType>());
        BarterType barterType = new BarterType(BARTER_TYPE_ID);
        barterType.getId().setCountryCd(COUNTRY_ID);
        campaignFaces.getCampaign().getBarterTypes().add(barterType);

        campaignFaces.cboCountryChanged();

        Assert.assertNotNull(campaignFaces.getCampaign().getTradings());
    }*/

    @Test
    public void testCboDivisionChanged() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();

        campaignFaces.cboDivisionChanged();

        Assert.assertNull(campaignFaces.getDivisionBrandId());
    }

    @Test
    public void testShowCommoditiesTab() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        campaignFaces.showCommoditiesTab();

        Assert.assertEquals("tabCommodities", campaignFaces.getTab());
    }

    @Test
    public void testShowBrandTab() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        campaignFaces.showBrandTab();

        Assert.assertEquals("tabBrands", campaignFaces.getTab());
    }

    @Test
    public void testAddTrading() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setTradingId("1-2");
        campaignFaces.setCampaign(new Campaign());
        campaignFaces.getCampaign().setTradings(new ArrayList<Trading>());
        campaignFaces.getCampaign().setCountry(new Country(new CountryId()));

        campaignFaces.addTrading();

        Assert.assertNotNull(campaignFaces.getCampaign().getTradings());
        Assert.assertFalse(campaignFaces.getCampaign().getTradings().isEmpty());
        Assert.assertEquals(1, campaignFaces.getCampaign().getTradings().size());
    }

    @Test
    public void testDeleteTrading() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setTrading(new Trading());

        campaignFaces.deleteTrading();

        Assert.assertEquals("tabTrading", campaignFaces.getTab());
    }

    @Test
    public void testDeleteCommoditiy() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setCommodity(new Commodity());

        campaignFaces.deleteCommodity();

        Assert.assertEquals("tabCommodities", campaignFaces.getTab());
    }


    @Test
    public void testShowHistoryTab() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        campaignFaces.showHistoryTab();

        Assert.assertEquals("tabHistory", campaignFaces.getTab());
    }

    @Test
    public void testDeleteBrand() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setBrand(new CampaignBrandBusiness());
        campaignFaces.getBrand().setId(new Long(1L));

        campaignFaces.deleteBrand();

        Assert.assertEquals("tabBrands", campaignFaces.getTab());
    }


    @Test
    public void testDeleteUnit() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setDivisionUnit(new CampaignDivisionUnitBusiness());
        campaignFaces.getDivisionUnit().setId(new Long(1L));

        campaignFaces.deleteUnit();

        Assert.assertEquals("tabUnit", campaignFaces.getTab());
    }

    @Test
    public void testAddCommodity() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setDivisionUnit(new CampaignDivisionUnitBusiness());
        campaignFaces.getDivisionUnit().setId(new Long(1L));
        campaignFaces.setCommodityId("1-2");

        campaignFaces.addCommodity();

        Assert.assertEquals("tabCommodities", campaignFaces.getTab());
    }

    /**
     *
     */
    @Test
    public void testAddUnit() {
        // ActionEvent ae = new ActionEvent(new HtmlAjaxCommandButton());
        //ActionEvent ae = new ActionEvent(new UICommandButton());
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setDivisionUnit(new CampaignDivisionUnitBusiness());
        campaignFaces.getDivisionUnit().setId(new Long(1L));
        campaignFaces.setDivisionId("1-2");
        campaignFaces.setUnitId("1-2");
        campaignFaces.setVolumeUnit(new BigDecimal(10));

        campaignFaces.addUnit();

        Assert.assertEquals("tabUnit", campaignFaces.getTab());


        setupMockServices();

        MessageVO message = new MessageVO(CampaignService.CAMPAIGN_INVALID_ADD, MessageTypeList.INFO);

        when(getServiceMock(ICampaignService.class).canAdd(anyListOf(BaseEntity.class), any(BaseEntity.class))).
                thenReturn(false);
        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message}));
        tested.addUnit();

        when(getServiceMock(ICampaignService.class).canAdd(anyListOf(BaseEntity.class), any(BaseEntity.class))).
                thenReturn(true);
        when(getServiceMock(ICampaignService.class).validatesDivisionAndUnitToUnit(any(CampaignDivisionUnitBusiness.class),
                anyListOf(CampaignDivisionUnitBusiness.class))).thenReturn(true);
        when(getServiceMock(ICampaignService.class).canAddUnit(any(BigDecimal.class), any(BigDecimal.class),
                anyListOf(CampaignDivisionUnitBusiness.class))).thenReturn(false);
        message = new MessageVO(CampaignService.CAMPAIGN_INVALID_VALUE_BARTER, MessageTypeList.INFO);
        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message}));
        tested.addUnit();

        message = new MessageVO("1");
        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message}));
        tested.addUnit();

        when(getServiceMock(ICampaignService.class).canAddUnit(any(BigDecimal.class), any(BigDecimal.class),
                anyListOf(CampaignDivisionUnitBusiness.class))).thenReturn(true);
        Whitebox.setInternalState(tested, "divisionUnitsCampaignList", new ArrayList<CampaignDivisionUnitBusiness>());
        tested.addUnit();



    }

    /**
     *
     */
    @Test
    public void testAddBrand() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.init();
        campaignFaces.setDivisionUnit(new CampaignDivisionUnitBusiness());
        campaignFaces.getDivisionUnit().setId(new Long(1L));
        campaignFaces.setDivisionId("1-2");
        campaignFaces.setUnitId("1-2");
        campaignFaces.setBrandId("1-2");
        campaignFaces.setDivisionBrandId("1-2");
        campaignFaces.setUnitBrandId("1-2");
        campaignFaces.setVolumeUnit(new BigDecimal(10));
        campaignFaces.setBrandsCampaignList(new ArrayList<CampaignBrandBusiness>());
        campaignFaces.setDiscountBrand(new BigDecimal(20));
        // ActionEvent ae = new ActionEvent(new HtmlAjaxCommandButton());
        //ActionEvent ae = new ActionEvent(new UICommandButton());

        campaignFaces.addBrand();

        Assert.assertEquals("tabBrands", campaignFaces.getTab());
        Assert.assertFalse(campaignFaces.getBrandsCampaignList().isEmpty());
        Assert.assertEquals(1, campaignFaces.getBrandsCampaignList().size());


        setupMockServices();

        tested.addBrand();

        MessageVO message = new MessageVO(CampaignService.CAMPAIGN_INVALID_ADD, MessageTypeList.INFO);
        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message }));
        tested.addBrand();

        message = new MessageVO(CampaignService.CAMPAIGN_INVALID_VALUE_BARTER, MessageTypeList.INFO);
        when(getServiceMock(ICampaignService.class).getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message }));
        when(getServiceMock(ICampaignService.class).canAdd(anyListOf(BaseEntity.class), any(BaseEntity.class))).thenReturn(false);
        tested.addBrand();


    }

    @Test
    public void testNewCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        String result=campaignFaces.newCampaign();

        Assert.assertEquals(NEW, result);
        Assert.assertTrue(campaignFaces.isNewer());
    }

    @Test
    public void testEditCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        String result=campaignFaces.editCampaign();

        Assert.assertEquals(CHANGE, result);
    }

    @Test
    public void testPopulateCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        Campaign campaign = new Campaign();
        campaign.setCode("Campaign 1");
        campaign.setCountry(new Country(new CountryId()));
        campaign.getCountry().getId().setCountryCd(COUNTRY_CD);
        com.monsanto.barter.business.entity.table.User author = new com.monsanto.barter.business.entity.table.User();
        author.setId(USER_TEST);
        campaign.setAuthor(author);
        campaign.setStatusCd(StatusList.ACTIVE.getFlag());
        campaignFaces.setCampaign(campaign);

        campaignFaces.populateCampaign();
    }

    @Test
    public void testCancelCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        String result=campaignFaces.cancelCampaign();

        Assert.assertEquals("showResult", result);
    }

    @Test
    public void testGetQtd() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        int result=campaignFaces.getQtd();

        Assert.assertEquals(0, result);
    }

    @Test
    public void testGetQtCampaignHistory() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        int result=campaignFaces.getQtCampaignHistory();

        Assert.assertEquals(0, result);
    }

    @Test
    public void testGetSetStatusCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> statusCampaign = new ArrayList<SelectItem>();
        statusCampaign.add(new SelectItem());
        campaignFaces.setStatusCampaign(statusCampaign);

        List<SelectItem> result=campaignFaces.getStatusCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetCampaignFilter() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        CampaignFilter campaignFilter = new CampaignFilter();
        campaignFilter.setDivisionId(ANY_CODE);
        campaignFaces.setCampaignFilter(campaignFilter);

        CampaignFilter result=campaignFaces.getCampaignFilter();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result.getDivisionId());
    }

    @Test
    public void testGetSetCampaignList() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<Campaign> campaigns = new ArrayList<Campaign>();
        campaigns.add(new Campaign());
        campaignFaces.setCampaignList(campaigns);

        List<Campaign> result=campaignFaces.getCampaignList();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetBrandCampaignList() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<CampaignBrandBusiness> campaigns = new ArrayList<CampaignBrandBusiness>();
        campaigns.add(new CampaignBrandBusiness());
        campaignFaces.setBrandsCampaignList(campaigns);

        List<CampaignBrandBusiness> result=campaignFaces.getBrandsCampaignList();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetDivisionUnitCampaignList() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<CampaignDivisionUnitBusiness> divisionUnitBusinesses = new ArrayList<CampaignDivisionUnitBusiness>();
        divisionUnitBusinesses.add(new CampaignDivisionUnitBusiness());
        campaignFaces.setDivisionUnitsCampaignList(divisionUnitBusinesses);

        List<CampaignDivisionUnitBusiness> result=campaignFaces.getDivisionUnitsCampaignList();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetBrandsCampaignDelete() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<CampaignBrand> campaignBrands = new ArrayList<CampaignBrand>();
        campaignBrands.add(new CampaignBrand());
        campaignFaces.setBrandsCampaignDelete(campaignBrands);

        List<CampaignBrand> result=campaignFaces.getBrandsCampaignDelete();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetDivisionUnitsCampaignDelete() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<CampaignDivisionUnit> divisionUnits = new ArrayList<CampaignDivisionUnit>();
        divisionUnits.add(new CampaignDivisionUnit());
        campaignFaces.setDivisionUnitsCampaignDelete(divisionUnits);

        List<CampaignDivisionUnit> result=campaignFaces.getDivisionUnitsCampaignDelete();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetDivisionCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> divisionsCampaign = new ArrayList<SelectItem>();
        divisionsCampaign.add(new SelectItem());
        campaignFaces.setDivisionsCampaign(divisionsCampaign);

        List<SelectItem> result=campaignFaces.getDivisionsCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetCountryCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> CountriesCampaign = new ArrayList<SelectItem>();
        CountriesCampaign.add(new SelectItem());
        campaignFaces.setCountryCampaign(CountriesCampaign);

        List<SelectItem> result=campaignFaces.getCountryCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetCurrencyCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> currenciesCampaign = new ArrayList<SelectItem>();
        currenciesCampaign.add(new SelectItem());
        campaignFaces.setCurrencyCampaign(currenciesCampaign);

        List<SelectItem> result=campaignFaces.getCurrencyCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetTradingCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> tradingsCampaign = new ArrayList<SelectItem>();
        tradingsCampaign.add(new SelectItem());
        campaignFaces.setTradingsCampaign(tradingsCampaign);

        List<SelectItem> result=campaignFaces.getTradingsCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetCommoditiesCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> commoditiesCampaign = new ArrayList<SelectItem>();
        commoditiesCampaign.add(new SelectItem());
        campaignFaces.setCommoditiesCampaign(commoditiesCampaign);

        List<SelectItem> result=campaignFaces.getCommoditiesCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetBrandsCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> brandsCampaign = new ArrayList<SelectItem>();
        brandsCampaign.add(new SelectItem());
        campaignFaces.setBrandsCampaign(brandsCampaign);

        List<SelectItem> result=campaignFaces.getBrandsCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }
    @Test
    public void testGetSetUnitsCampaign() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        ArrayList<SelectItem> unitsCampaign = new ArrayList<SelectItem>();
        unitsCampaign.add(new SelectItem());
        campaignFaces.setUnitsCampaign(unitsCampaign);

        List<SelectItem> result=campaignFaces.getUnitsCampaign();

        Assert.assertNotNull(result);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetUnitId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setUnitId(ANY_CODE);

        String result=campaignFaces.getUnitId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }

    @Test
    public void testGetSetTab() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setTab(ANY_CODE);

        String result=campaignFaces.getTab();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }

    @Test
    public void testGetSetTradingId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setTradingId(ANY_CODE);

        String result=campaignFaces.getTradingId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }

    @Test
    public void testGetSetCommodityId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setCommodityId(ANY_CODE);

        String result=campaignFaces.getCommodityId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }
    @Test
    public void testGetSetBrandId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setBrandId(ANY_CODE);

        String result=campaignFaces.getBrandId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }
    @Test
    public void testGetSetDivisionBrandId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setDivisionBrandId(ANY_CODE);

        String result=campaignFaces.getDivisionBrandId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }
    @Test
    public void testGetSetUnitBrandId() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setUnitBrandId(ANY_CODE);

        String result=campaignFaces.getUnitBrandId();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result);
    }

    @Test
    public void testGetSetTrading() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        Trading trading = new Trading();
        trading.setDescTrading(ANY_CODE);
        campaignFaces.setTrading(trading);

        Trading result=campaignFaces.getTrading();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result.getDescTrading());
    }

    @Test
    public void testGetSetCommodity() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        Commodity commodity = new Commodity();
        commodity.setDescCommodity(ANY_CODE);
        campaignFaces.setCommodity(commodity);

        Commodity result=campaignFaces.getCommodity();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result.getDescCommodity());
    }


    @Test
    public void testIsSetTableShow() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setTableShow(false);

        boolean result=campaignFaces.isTableShow();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }

    @Test
    public void testIsSetButtonValidate() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setButtonValidate(false);

        boolean result=campaignFaces.isButtonValidate();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }

    @Test
    public void testIsSetButtonSendValidate() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setButtonSendValidate(false);

        boolean result=campaignFaces.isButtonSendValidate();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetButtonReturn() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setButtonReturn(false);

        boolean result=campaignFaces.isButtonReturn();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetNoEditable() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setNoEditable(false);

        boolean result=campaignFaces.isNoEditable();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetButtonInactivate() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setButtonInactivate(false);

        boolean result=campaignFaces.isButtonInactivate();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetExecuteSearch() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setExecuteSearch(false);

        boolean result=campaignFaces.isExecuteSearch();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetEnableSaveBtn() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setEnableSaveBtn(false);

        boolean result=campaignFaces.isEnableSaveBtn();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }
    @Test
    public void testIsSetCanAccessCampaignNew() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();

        boolean result=campaignFaces.isCanAccessCampaignNew();

        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }

    @Test
    public void testGetSetValueMaxBarter() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setValueMaxBarter(new BigDecimal(0));

        BigDecimal result=campaignFaces.getValueMaxBarter();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetValueBarterConsumed() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setValueBarterConsumed(new BigDecimal(0));

        BigDecimal result=campaignFaces.getValueBarterConsumed();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetValueBarterAvaliable() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setValueBarterAvaliable(new BigDecimal(0));

        BigDecimal result=campaignFaces.getValueBarterAvaliable();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetValueMaxDiscount() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setValueMaxDiscount(new BigDecimal(0));

        BigDecimal result=campaignFaces.getValueMaxDiscount();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetValueDiscountAvaliable() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setValueDiscountAvaliable(new BigDecimal(0));

        BigDecimal result=campaignFaces.getValueDiscountAvaliable();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetDiscountBrand() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setDiscountBrand(new BigDecimal(0));

        BigDecimal result=campaignFaces.getDiscountBrand();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetVolumeUnit() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setVolumeUnit(new BigDecimal(0));

        BigDecimal result=campaignFaces.getVolumeUnit();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }
    @Test
    public void testGetSetVolumeUnitAvaliable() {
        CampaignFaces campaignFaces = new CampaignFacesICampaignService();
        campaignFaces.setVolumeUnitAvaliable(new BigDecimal(0));

        BigDecimal result=campaignFaces.getVolumeUnitAvaliable();

        Assert.assertNotNull(result);
        Assert.assertEquals(BigDecimal.ZERO, result);
    }

    /**
     *
     */
    @Test
    public void test_addBarterType() {
        setupMockServices();

        tested.addBarterType();
    }

    /**
     * @see CampaignFaces#enabledDisabledButtons
     */
    @Test
    public void test_enabledDisabledButtons() {
        setupMockServices();

        User user = new User();
        Permission permission1 = new Permission(PermissionList.RETURN_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());
        user.setPermissions(Arrays.asList(new Permission[]{permission1}));
        tested.setUser(user);

        tested.enabledDisabledButtons();

        when(getServiceMock(ICampaignService.class).canReturn(any(Campaign.class))).thenReturn(true);
        when(getServiceMock(ICampaignService.class).canValidate(any(Campaign.class))).thenReturn(true);
        when(getServiceMock(ICampaignService.class).canInactivate(any(Campaign.class))).thenReturn(true);
        tested.enabledDisabledButtons();

        Permission permission2 = new Permission(PermissionList.VALIDATE_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());
        user.setPermissions(Arrays.asList(new Permission[]{permission2}));
        tested.enabledDisabledButtons();

        Permission permission3 = new Permission(PermissionList.INACTIVATE_CAMPAIGN_BUTTON_PERMISSION_CD.getPermissionCd());
        user.setPermissions(Arrays.asList(new Permission[]{permission3}));
        tested.enabledDisabledButtons();
    }

    /**
     * @see com.monsanto.barter.web.faces.campaign.CampaignFaces#loadBarterTypes(String)
     */
    @Test
    public void test_loadBarterTypes() {
        setupMockServices();


        tested.loadBarterTypes(null);
    }

    /**
     * @see CampaignFaces#populateCampaign
     */
    @Test
    public void test_populateCampaign() throws Exception {
        setupMockServices();

        tested = PowerMockito.spy(tested);
        PowerMockito.doReturn(null).when(tested, "convertToCampaignBrandBusiness");
        PowerMockito.doReturn(null).when(tested, "convertToCampaignDivisionUnitBusiness");

        Campaign campaign = new Campaign();
        campaign.setMaxBilledAmt(new BigDecimal(0));
        campaign.setBarterAvailBal(new BigDecimal(0));
        campaign.setMaxDiscount(new BigDecimal(0));
        campaign.setDiscountAvailBal(new BigDecimal(0));
        tested.setCampaign(campaign);

        tested.populateCampaign();
    }

    /**
     * @see CampaignFaces#deleteBarterType
     */
    @Test
    public void test_deleteBarterType() throws Exception {
        setupMockServices();

        tested.deleteBarterType();

        BarterType barterType = new BarterType();
        Whitebox.setInternalState(tested, "barterType", barterType);
        tested.deleteBarterType();
    }

    /**
     * @see CampaignFaces#completingCampaignFilter
     */
    @Test
    public void test_completingCampaignFilter() throws Exception {
        setupMockServices();
        Whitebox.setInternalState(tested, "campaignFilter", new CampaignFilter());
        Whitebox.setInternalState(tested, "divisionId", "1-1");
        Whitebox.setInternalState(tested, "newer", false);
        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        tested.setCampaign(campaign );

        tested.completingCampaignFilter();

    }

    /**
     * @see CampaignFaces#existsIn
     */
    @Test
    public void testPrivateMethod_existsIn() throws Exception {
        setupMockServices();

        CampaignDivisionUnit campaignDivisionUnit = new CampaignDivisionUnit();
        campaignDivisionUnit.setDivision(new Division());
        campaignDivisionUnit.setUnitId("1");
        List<CampaignDivisionUnit> currentUnits = Arrays.asList(new CampaignDivisionUnit[]{campaignDivisionUnit});
        CampaignDivisionUnit u = new CampaignDivisionUnit();

        Whitebox.invokeMethod(tested, "existsIn", currentUnits, u);

        u.setDivision(new Division());
        Whitebox.invokeMethod(tested, "existsIn", currentUnits, u);

        u.setUnitId("1");
        Whitebox.invokeMethod(tested, "existsIn", currentUnits, u);
    }

    /**
     * @see CampaignFaces#updateCurrentDivisionUnits(List, List)
     */
    @Test
    public void testPrivateMethod_updateCurrentDivisionUnits() throws Exception {
        setupMockServices();

        List<CampaignDivisionUnit> divUnits = new ArrayList<CampaignDivisionUnit>();
        List<CampaignDivisionUnit> currentUnits = new ArrayList<CampaignDivisionUnit>();

        Whitebox.invokeMethod(tested, "updateCurrentDivisionUnits", divUnits, currentUnits);

        divUnits.add(new CampaignDivisionUnit(null));
        Whitebox.invokeMethod(tested, "updateCurrentDivisionUnits", divUnits, currentUnits);


        divUnits.clear();
        CampaignDivisionUnit campaignDivisionUnit1 = new CampaignDivisionUnit(0L);
        campaignDivisionUnit1.setDivision(new Division());
        divUnits.add(campaignDivisionUnit1);
        Whitebox.invokeMethod(tested, "updateCurrentDivisionUnits", divUnits, currentUnits);

        CampaignDivisionUnit campaignDivisionUnit2 = new CampaignDivisionUnit(0L);
        campaignDivisionUnit2.setDivision(new Division());
        currentUnits.add(campaignDivisionUnit2);
        Whitebox.invokeMethod(tested, "updateCurrentDivisionUnits", divUnits, currentUnits);
    }

    /**
     * Setup method constructor allows to inject services through beanFactory mock.
     */
    private void setupMockServices() {

        tested = SilentObjectCreator.create(CampaignFaces.class);//avoid default constructor

        ICampaignService campaignServiceMock = mock(ICampaignService.class);
        when(campaignServiceMock.canAdd(Matchers.anyListOf(BaseEntity.class),
                Matchers.any(BaseEntity.class))).thenReturn(true);
        Campaign campaignMock = new Campaign();
        Country countryMock = new Country();
        CountryId countryIdMock = new CountryId();
        countryIdMock.setCountryCd("");
        countryMock.setId(countryIdMock);
        campaignMock.setCountry(countryMock);
        List<BarterType> barterTypes = new ArrayList<BarterType>();
        campaignMock.setBarterTypes(barterTypes);

        Whitebox.setInternalState(tested, "barterTypeId", "1-1");
        Whitebox.setInternalState(tested, "campaign", campaignMock);

        IBarterTypeService barterTypeServiceMock = mock(IBarterTypeService.class);
        List<BarterType> list = new ArrayList<BarterType>();
        BarterType barterType = new BarterType();
        BarterTypeId barterTypeId = new BarterTypeId();
        barterTypeId.setBarterTypeId("");
        barterType.setId(barterTypeId);
        barterType.setDescBarterType("");
        list.add(barterType);
        when(barterTypeServiceMock.search(Matchers.any(BarterTypeFilter.class))).thenReturn(list);

        BeanFactory beanFactoryMock = mock(BeanFactory.class);
        when(beanFactoryMock.getBean(ICampaignService.class)).thenReturn(campaignServiceMock);
        when(beanFactoryMock.getBean(IBarterTypeService.class)).thenReturn(barterTypeServiceMock);
        Whitebox.setInternalState(tested, beanFactoryMock);//inject beanFactory

    }

    private <T> T getServiceMock(Class<T> clazz) {
        T t = null;
        try {
            t = Whitebox.<T> invokeMethod(tested, "getService",
                    new Class[] { Class.class }, clazz);
            if (t == null) {
                T mock = mock(clazz);
                BeanFactory beanFactoryMock = Whitebox.<BeanFactory> getInternalState(tested, "beanFactory");
                when(beanFactoryMock.getBean(clazz)).thenReturn(mock);
                t = getServiceMock(clazz);
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        return t;
    }


    public static class CampaignFacesICampaignService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICampaignService.class)) {
                ICampaignService campaignService = mock(ICampaignService.class);
                List<Campaign> campaigns = new ArrayList<Campaign>();
                Campaign campaign = new Campaign();
                campaign.setCode("Campaign 1");
                campaign.setCountry(new Country(new CountryId()));
                campaign.getCountry().getId().setCountryCd(COUNTRY_CD);
                com.monsanto.barter.business.entity.table.User author = new com.monsanto.barter.business.entity.table.User();
                author.setId(USER_TEST);
                campaign.setAuthor(author);
                campaign.setStatusCd(StatusList.ACTIVE.getFlag());
                campaign.setBarterTypes( new ArrayList<BarterType>());
                BarterType barterType = new BarterType(BARTER_TYPE_ID);
                barterType.getId().setCountryCd(COUNTRY_ID);
                campaign.getBarterTypes().add(barterType);
                campaigns.add(campaign);
                List<CampaignDivisionUnitBusiness> campaignDivisionUnitBusinessList = new ArrayList<CampaignDivisionUnitBusiness>();
                CampaignDivisionUnitBusiness campaignDivisionUnitBusiness = new  CampaignDivisionUnitBusiness();
                campaignDivisionUnitBusiness.setVolume(new BigDecimal("1"));
                campaignDivisionUnitBusinessList.add(campaignDivisionUnitBusiness);
                when(campaignService.searchByDivision(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                when(campaignService.isValidValueBarter(Matchers.<BigDecimal>anyObject(), eq(campaignDivisionUnitBusinessList))).thenReturn(Boolean.FALSE);
                when(campaignService.findById(Matchers.<Campaign>any())).thenReturn(campaign);
                when(campaignService.findByIdComplete(Matchers.<Campaign>any())).thenReturn(campaign);
                when(campaignService.canAdd(Matchers.<List<BaseEntity>>any(), Matchers.<BaseEntity>any())).thenReturn(true);
                when(campaignService.validatesDivisionAndUnitToBrand(Matchers.<CampaignBrandBusiness>any(), Matchers.<List<CampaignBrandBusiness>>any())).thenReturn(true);
                when(campaignService.isValidDiscountBrand(Matchers.<CampaignBrandBusiness>any(),Matchers.<Campaign>any())).thenReturn(true);
                return (T)campaignService;
            }

            if (requiredType.equals(IWhitePaperService.class)) {

                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                when(whitePaperService.findAll()).thenReturn(new ArrayList<WhitePaper>());
                return (T) whitePaperService;

            }


            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadCurrencies(){}

        @Override
        public void populateCampaign() {}

        @Override
        public void loadTradings(String countryCd) {}

        @Override
        public void loadCommodities(String countryCd) {}

        @Override
        public void loadBarterTypes(String countryCd) {}

        public com.monsanto.barter.architecture.regionalization.Country getCountry(){
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    }

    public static class CampaignFacesICurrencyService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICurrencyService.class)) {
                ICurrencyService currencyService = mock(ICurrencyService.class);
                List<Currency> currencies = new ArrayList<Currency>();
                Currency curr1 = new Currency();
                CurrencyId currencyId = new CurrencyId();
                currencyId.setCurrencyCd("e");
                curr1.setId(currencyId);
                curr1.setDescCurrencyLong("Pesos Mexicanos");
                currencies.add(curr1);
                when(currencyService.search(Matchers.<CurrencyFilter>any())).thenReturn(currencies);
                return (T)currencyService;
            }

            if (requiredType.equals(IWhitePaperService.class)) {

                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                when(whitePaperService.findAll()).thenReturn(new ArrayList<WhitePaper>());
                return (T) whitePaperService;

            }

            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadTradings(String countryCd){}

        @Override
        public void loadCommodities(String countryCd){}

        @Override
        public void loadBarterTypes(String countryCd) {}

        public com.monsanto.barter.architecture.regionalization.Country getCountry(){
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    }

    public static class CampaignFacesIDivisionService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IDivisionService.class)) {
                IDivisionService divisionService = mock(IDivisionService.class);
                List<Division> divisions = new ArrayList<Division>();
                Division d1 = new Division();
                d1.setId(new DivisionId("1", 'e'));
                d1.setDesc("Division 1");
                divisions.add(d1);
                when(divisionService.search(Matchers.<DivisionFilter>any())).thenReturn(divisions);
                return (T)divisionService;
            }
            if (requiredType.equals(IWhitePaperService.class)) {

                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                when(whitePaperService.findAll()).thenReturn(new ArrayList<WhitePaper>());
                return (T) whitePaperService;

            }

            return super.getService(requiredType);
        }

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadCurrencies(){}

        @Override
        public void loadTradings(String countryCd){}

        @Override
        public void loadCommodities(String countryCd){}

        @Override
        public void loadBarterTypes(String countryCd) {}

        public com.monsanto.barter.architecture.regionalization.Country getCountry(){
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    }


    public static class CampaignFacesICountryService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICountryService.class)) {
                ICountryService countryService = mock(ICountryService.class);
                List<Country> countries = new ArrayList<Country>();
                Country ctry1 = new Country();
                ctry1.setId(new CountryId("1", 'e'));
                countries.add(ctry1);
                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                return (T)countryService;
            }
            if (requiredType.equals(IWhitePaperService.class)) {

                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                when(whitePaperService.findAll()).thenReturn(new ArrayList<WhitePaper>());
                return (T) whitePaperService;

            }
            return super.getService(requiredType);
        }

        @Override
        public void loadCurrencies(){}

        @Override
        public void loadDivisions(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadTradings(String countryCd){}

        @Override
        public void loadCommodities(String countryCd){}

        @Override
        public void loadBarterTypes(String countryCd) {}

        public com.monsanto.barter.architecture.regionalization.Country getCountry(){
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }

    }

    public static class CampaignFacesISalesOrgCustomerService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ISalesOrgCustomerService.class)) {
                ISalesOrgCustomerService salesOrgCustomerService = mock(ISalesOrgCustomerService.class);
                List<String> units = new ArrayList<String>();
                units.add("unit 1");
                units.add("unit 2");
                when(salesOrgCustomerService.getAllUnitId()).thenReturn(units);
                return (T)salesOrgCustomerService;
            }
            if (requiredType.equals(IWhitePaperService.class)) {

                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                when(whitePaperService.findAll()).thenReturn(new ArrayList<WhitePaper>());
                return (T) whitePaperService;

            }
            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadCurrencies(){}

        @Override
        public void loadTradings(String countryCd){}

        @Override
        public void loadCommodities(String countryCd){}

        @Override
        public void loadBarterTypes(String countryCd) {}

        public com.monsanto.barter.architecture.regionalization.Country getCountry(){
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    }

    public static class CampaignFacesITradingService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ITradingService.class)) {
                ITradingService tradingService = mock(ITradingService.class);
                List<Trading> tradings = new ArrayList<Trading>();
                Trading t1 = new Trading();
                TradingId tradingId = new TradingId();
                tradingId.setTradingCd("0001836441");
                t1.setId(tradingId);
                t1.getId().setCountryCd("BR");
                t1.setDescTrading("ADM");
                tradings.add(t1);
                when(tradingService.search(Matchers.<TradingFilter>any())).thenReturn(tradings);
                return (T)tradingService;
            }
            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadCurrencies(){}
    }

    public static class CampaignFacesIProductService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IProductService.class)) {
                IProductService productService = mock(IProductService.class);
                List<String> products = new ArrayList<String>();
                String product1 = new String("Product 1");
                products.add(product1);
                when(productService.searchDistinct(Matchers.<ProductFilter>any())).thenReturn(products);
                return (T)productService;
            }
            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadCurrencies(){}
    }

    public static class CampaignFacesICommodityService extends CampaignFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICommodityService.class)) {
                ICommodityService commodityService = mock(ICommodityService.class);
                List<Commodity> commodities = new ArrayList<Commodity>();
                Commodity c1 = new Commodity();
                CommodityId commodityId = new CommodityId();
                commodityId.setCountryCd("BR");
                c1.setId(commodityId);
                c1.getId().setCommodityId("BR");
                c1.setDescCommodity("BR Trading");
                commodities.add(c1);
                when(commodityService.search(Matchers.<CommodityFilter>any())).thenReturn(commodities);
                return (T)commodityService;
            }
            return super.getService(requiredType);
        }

        @Override
        public void loadDivisions(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadUnits(){}

        @Override
        public void loadCurrencies(){}
    }
}
