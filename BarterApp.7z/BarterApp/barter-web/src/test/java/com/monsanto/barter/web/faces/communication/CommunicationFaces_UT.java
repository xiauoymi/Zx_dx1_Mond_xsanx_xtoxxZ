package com.monsanto.barter.web.faces.communication;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.filter.CommunicationFilter;
import com.monsanto.barter.business.entity.filter.QuotationFilter;
import com.monsanto.barter.business.entity.list.CommunicationTypeList;
import com.monsanto.barter.business.entity.table.Communication;
import com.monsanto.barter.business.service.ICommunicationService;
import com.monsanto.barter.business.service.IQuotationService;
import com.monsanto.barter.web.test.SilentObjectCreator;

import org.apache.myfaces.custom.fileupload.UploadedFile;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.reflect.Whitebox;
import org.springframework.beans.factory.BeanFactory;

import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/1/12
 * Time: 3:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommunicationFaces_UT extends JsfTestCase {

    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String BACK = "back";
    public static final String ANY_CODE = "AnyCode";
	private CommunicationFaces tested;

    private static class CommunicationFacesICommunicationService extends CommunicationFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICommunicationService.class)) {
                ICommunicationService communicationService = mock(ICommunicationService.class);
                Communication communication = new Communication();
                communication.setId(1L);
                communication.setType(new Character('C'));
                List<Communication> communicationList = new ArrayList<Communication>();
                communicationList.add(communication);
                when(communicationService.findByIdComplete(Matchers.<Communication>any())).thenReturn(communication);
                when(communicationService.search(Matchers.<CommunicationFilter>any())).thenReturn(communicationList);
                when(communicationService.findById(Matchers.<Communication>any())).thenReturn(communication);

                return (T)communicationService;
            }
            return super.getService(requiredType);
        }

        protected synchronized void downloadFile(final String fileName, final byte[] fileData) {

        }
    }

    @Before
	public void setUp() throws Exception {
		super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
	public void btnEditTest() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        String retorno = communicationFaces.btnEdit();
        Assert.assertTrue("change".equals(retorno) );
    }

    /**
     * @throws Exception 
     * @see {@link CommunicationFaces#btnSearch()}()
     */
    @Test
	public void btnSearchTest() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        Whitebox.setInternalState( communicationFaces , "communicationList" ,  new ArrayList<Communication>() );
        Whitebox.setInternalState( communicationFaces ,"quotationList" , new ArrayList<QuotationBusiness>() );
        communicationFaces.btnSearch();
        Assert.assertTrue(communicationFaces.getCommunicationList().size() == 1);
        
        
        setupMockServices(); 
     // invoke test (branch 1T)
        tested.btnSearch();
    }

    @Test
	public void btnCancelTest() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        String back = communicationFaces.btnCancel();
        Assert.assertTrue("back".equals(back) );
    }

    @Test
	public void getTypeListRegisterTest () {
       CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
       List<SelectItem> list = communicationFaces.getTypeListRegister();
       Assert.assertFalse(list.isEmpty());
    }

    @Test
	public void getTypeListSearchTest () {
       CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
       List<SelectItem> list = communicationFaces.getTypeListSearch();
       Assert.assertFalse(list.isEmpty());
    }

    @Test
	public void isCanAccessCommunicationNewTest () {
       CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
       boolean access = communicationFaces.isCanAccessCommunicationNew();
       Assert.assertFalse(access);
    }

    @Test
    public void testTypeSearchValueChanged() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        ValueChangeEvent valueChangeEvent= PowerMockito.mock(ValueChangeEvent.class);
        when(valueChangeEvent.getNewValue()).thenReturn(CommunicationTypeList.CAMPAIGN.getCod());

        communicationFaces.typeSearchValueChanged(valueChangeEvent);

        Assert.assertNull(communicationFaces.getFilter().getPeriodBegin());
        Assert.assertNull(communicationFaces.getFilter().getPeriodEnd());
    }

    @Test
    public void testTypeSearchValueChanged1() {

        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        Whitebox.setInternalState( communicationFaces , "communicationList" ,  new ArrayList<Communication>() );
        Whitebox.setInternalState( communicationFaces ,"quotationList" , new ArrayList<QuotationBusiness>() );

        ValueChangeEvent valueChangeEvent= PowerMockito.mock(ValueChangeEvent.class);
        when(valueChangeEvent.getNewValue()).thenReturn(CommunicationTypeList.CAMPAIGN.getCod());

        communicationFaces.typeSearchValueChanged(valueChangeEvent);

        Assert.assertNull(communicationFaces.getFilter().getPeriodBegin());
        Assert.assertNull(communicationFaces.getFilter().getPeriodEnd());
    }

    @Test
    public void testTypeRegisterValueChanged() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        ValueChangeEvent valueChangeEvent= PowerMockito.mock(ValueChangeEvent.class);
        when(valueChangeEvent.getNewValue()).thenReturn(CommunicationTypeList.CAMPAIGN.getCod());

        communicationFaces.typeRegisterValueChanged(valueChangeEvent);

        Assert.assertTrue(communicationFaces.isFlgRenderPeriodRegister());
    }

    @Test
    public void testBtnDelete() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        Whitebox.setInternalState( communicationFaces , "communicationList" ,  new ArrayList<Communication>() );
        Whitebox.setInternalState( communicationFaces ,"quotationList" , new ArrayList<QuotationBusiness>() );

        String result = communicationFaces.btnDelete();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testDownload() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        String result = communicationFaces.download();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testBtnSave() throws IOException {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        UploadedFile file = mock(UploadedFile.class);
        communicationFaces.setFile(file);

        InputStream stream = mock(InputStream.class);
        when(file.getInputStream()).thenReturn(stream);
        when(stream.read((byte[]) any())).thenReturn(1);
        when(file.getName()).thenReturn("TEST.csv");

        String result = communicationFaces.btnSave();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testBtnCancel() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        String result = communicationFaces.btnCancel();

        Assert.assertEquals(BACK, result);
    }

    @Test
    public void testRedirectURL() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        String result = communicationFaces.redirectUrl();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testIsFlgRenderPeriodRegister() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertFalse(communicationFaces.isFlgRenderPeriodRegister());
    }
    @Test
    public void testIsFlgRenderPeriodSearch() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertFalse(communicationFaces.isFlgRenderPeriodSearch());
    }
    @Test
    public void testIsFlgNew() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertTrue(communicationFaces.isFlgNew());
    }
    @Test
    public void testIsEnableSaveBtn() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        communicationFaces.setEnableSaveBtn(false);

        Assert.assertFalse(communicationFaces.isEnableSaveBtn());
    }
    @Test
    public void testGetFilter() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertNotNull(communicationFaces.getFilter());
    }
    @Test
    public void testGetCommunication() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertNotNull(communicationFaces.getCommunication());
    }
    @Test
    public void testGetListSize() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        Assert.assertNotNull(communicationFaces.getListSize());
    }

    @Test
    public void testSetGetFile() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();
        UploadedFile uploadedFile = mock(UploadedFile.class);
        when(uploadedFile.getName()).thenReturn(ANY_CODE);

        communicationFaces.setFile(uploadedFile);

        Assert.assertEquals(ANY_CODE, communicationFaces.getFile().getName());
    }

    @Test
    public void testGetQtCommunicationHistory() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        int result = communicationFaces.getQtCommunicationHistory();

        Assert.assertEquals(0, result);
    }


    @Test
    public void testSetQuotationList() {
        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        ArrayList<QuotationBusiness> list = new ArrayList<QuotationBusiness>();

        communicationFaces.setQuotationList(list);

        Assert.assertEquals(list, communicationFaces.getQuotationList());

    }

    @Test
    public void testGetQuotationListSize() {

        CommunicationFaces communicationFaces = new CommunicationFacesICommunicationService();

        final int size = 10;

        communicationFaces.setQuotationListSize(size);

        Assert.assertEquals(size, communicationFaces.getQuotationListSize());

    }


    /**
	 * Setup method constructor allows to inject services through beanFactory mock.
	 */
	private void setupMockServices() {
		
		tested = SilentObjectCreator.create(CommunicationFaces.class);//avoid default constructor
		
		CommunicationFilter communicationFilterMock = mock(CommunicationFilter.class);
		Whitebox.setInternalState(tested, communicationFilterMock);
        when(communicationFilterMock.getType()).thenReturn('Q');
        
        IQuotationService quotationService = mock(IQuotationService.class);
        List<QuotationBusiness> quotationBusinesses = new ArrayList<QuotationBusiness>();
		when(quotationService.searchBusinessObjects(Matchers.any(QuotationFilter.class))).thenReturn(quotationBusinesses);
				
        BeanFactory beanFactoryMock = mock(BeanFactory.class);
        when(beanFactoryMock.getBean(IQuotationService.class)).thenReturn(quotationService);
    	Whitebox.setInternalState(tested, beanFactoryMock);//inject beanFactory
        
	}


}
