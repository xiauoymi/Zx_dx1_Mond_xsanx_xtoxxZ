package com.monsanto.barter.web.faces.customer;

import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.CustomerBusiness;
import com.monsanto.barter.business.entity.filter.CampaignFilter;
import com.monsanto.barter.business.entity.filter.CustomerFilter;
import com.monsanto.barter.business.entity.table.Campaign;
import com.monsanto.barter.business.entity.table.WhitePaper;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.monsanto.barter.architecture.security.data.User;
import org.mockito.Matchers;
import javax.el.ELContext;
import javax.faces.context.FacesContext;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MGORO
 * Date: 9/7/12
 * Time: 10:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class CustomerFaces_UT extends JsfTestCase {

    private class SimulationFacesForTesting extends SimulationFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IUserService.class)) {
                IUserService userService = mock(IUserService.class);
                com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
                when(userService.findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(user);
                return (T)userService;
            } else if (requiredType.equals(ICampaignService.class)) {
                ICampaignService campaignService = mock(ICampaignService.class);
                Campaign c1 = new Campaign();
                c1.setId(1L);
                c1.setName("c1");
                List<Campaign> campaigns = new ArrayList<Campaign>();
                campaigns.add(c1);
                when(campaignService.search(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                return (T)campaignService;
            } else if(requiredType.equals(ISimulationService.class)){
                ISimulationService simulationService = mock(ISimulationService.class);
                return (T)simulationService;

            } else if(requiredType.equals(IWhitePaperService.class)){
                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                WhitePaper whitePaper = new WhitePaper();
                whitePaper.setName("Whitepaper 1");
                whitePaper.setAmount(BigDecimal.valueOf(1000L));
                return (T) whitePaperService;
            }
            return super.getService(requiredType);
        }
    }

    private class CustomerFacesForTesting extends CustomerFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICustomerService.class)) {
                ICustomerService customerService = mock(ICustomerService.class);
                List<CustomerBusiness> customers = new ArrayList<CustomerBusiness>();
                CustomerBusiness c1 = new CustomerBusiness();
                c1.setRealSapCd("1234");
                customers.add(c1);
                CustomerBusiness c2 = new CustomerBusiness();
                c2.setRealSapCd("2345");
                customers.add(c2);
                when(customerService.search(Matchers.<CustomerFilter>any())).thenReturn(customers);
                return (T)customerService;
            }
            if(requiredType.equals(IWhitePaperService.class)){
                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                WhitePaper whitePaper = new WhitePaper();
                whitePaper.setName("Whitepaper 1");
                whitePaper.setAmount(BigDecimal.valueOf(1000L));
                return (T) whitePaperService;
            }
            if(requiredType.equals(IDivisionService.class)){
                IDivisionService divisionService = mock(IDivisionService.class);
                return (T) divisionService;
            }
            return super.getService(requiredType);
        }
    }

    @Before
	public void setUp() throws Exception {
        super.setUp();

        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
        ELContext ctx = FacesContext.getCurrentInstance().getELContext();
        ctx.getELResolver().setValue(ctx, null, "simulationFaces", new SimulationFacesForTesting());
    }

    @Test
	public void searchTest() {
        CustomerFaces customerFaces = new CustomerFacesForTesting();

        customerFaces.search();

        Assert.assertTrue(customerFaces.getListSelectRadio().size() == 2);
    }

    @Test
    public void testCancelSelectionCustomer() {
        CustomerFaces customerFaces = new CustomerFacesForTesting();

        customerFaces.cancelSelectionCustomer();

        Assert.assertNotNull(customerFaces.getCustomers());
        Assert.assertTrue(customerFaces.getCustomers().isEmpty());
    }

    @Test
    public void testGetQtdCustomers() {
        CustomerFaces customerFaces = new CustomerFacesForTesting();

        int result = customerFaces.getQtdCustomers();

        Assert.assertEquals(0, result);
    }
    @Test
    public void testGetCustomers() {
        CustomerFaces customerFaces = new CustomerFacesForTesting();

        List<CustomerBusiness> result = customerFaces.getCustomers();

        Assert.assertNotNull(result);
        Assert.assertTrue(result.isEmpty());
    }

    @Test
    public void testSearchFailure(){

        CustomerFaces customerFaces = new CustomerFaces() {
               @Override
               public <T> T getService(Class<T> requiredType) {
                   if (requiredType.equals(ICustomerService.class)) {
                       ICustomerService customerService = mock(ICustomerService.class);
                       when(customerService.search(Matchers.<CustomerFilter>any())).thenThrow(new RuntimeException("Test Failures"));
                       return (T)customerService;
                   }
                   if(requiredType.equals(IDivisionService.class)){
                       IDivisionService divisionService = mock(IDivisionService.class);
                       return (T) divisionService;
                   }
                   return super.getService(requiredType);
               }
        };

        customerFaces.search();
        assertNotNull(customerFaces.getMessages());
    }

    @Test
    public void testFilter(){
        CustomerFaces customerFaces = new CustomerFacesForTesting();
        CustomerFilter filter = new CustomerFilter();
        customerFaces.setCustomerFilter(filter);

        assertEquals(filter, customerFaces.getCustomerFilter());
    }


}
