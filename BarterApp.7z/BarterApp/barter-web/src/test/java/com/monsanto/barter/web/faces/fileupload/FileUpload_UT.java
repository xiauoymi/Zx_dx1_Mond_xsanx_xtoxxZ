package com.monsanto.barter.web.faces.fileupload;

import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.entity.enumerated.DocumentType;
import com.monsanto.barter.business.entity.list.DocumentTypeList;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: skuma14
 * Date: 5/23/14
 * Time: 1:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileUpload_UT extends JsfTestCase {

    private static final String FILE_NAME = "fileName.jpg";
    private static final byte[] CONTENTS = new byte[]{1, 2, 3, 4, 5, 6};
    private static final String MIME_TYPE = "image/jpeg";

    private FileUpload fileUpload ;

    private UploadedFile uploadedFile;

    @Before
    public void setUp() throws Exception{
        super.setUp();
        fileUpload  = new FileUpload();
        uploadedFile = new UploadedFile() {
            @Override
            public String getFileName() {
                return FILE_NAME;
            }

            @Override
            public InputStream getInputstream() throws IOException {
                return new ByteArrayInputStream(getContents());
            }

            @Override
            public long getSize() {
                return getContents().length;
            }

            @Override
            public byte[] getContents() {
                return CONTENTS;
            }

            @Override
            public String getContentType() {
                return MIME_TYPE;
            }
        };
    }

    @Test
    public void handleUpload() {
        FileUploadEvent event = mock(FileUploadEvent.class);

        when(event.getFile()).thenReturn(uploadedFile);

        fileUpload.handleFileUpload(event);

        File file = fileUpload.getFile();

        assertThat(file, is(notNullValue()));
        assertThat(file.getFileName(), is(FILE_NAME));
        assertThat(file.getFileContent(), is(CONTENTS));
        assertThat(file.getFileSize(), is(CONTENTS.length + 0L));
        assertThat(file.getMimeType(), is(MIME_TYPE));
    }

    @Test
    public void clear() {
        FileUploadEvent event = mock(FileUploadEvent.class);

        when(event.getFile()).thenReturn(uploadedFile);

        fileUpload.handleFileUpload(event);

        assertThat(fileUpload.getFile(), is(notNullValue()));

        fileUpload.clear();

        assertThat(fileUpload.getFile(), is(nullValue()));
    }

    @Test
    public void  documents(){
        fileUpload.setUploadDocumentNumber("12345");
        fileUpload.setUploadDocumentType(DocumentTypeList.APPROVAL);
        fileUpload.setUploadErrorMessages(new ArrayList<String>());
        assertEquals(fileUpload.getUploadDocumentNumber(), "12345");
        assertEquals(fileUpload.getUploadDocumentType(),DocumentTypeList.APPROVAL);
        assertEquals(0, fileUpload.getUploadErrorMessages().size());
    }
}
