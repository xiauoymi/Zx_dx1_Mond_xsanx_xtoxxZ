package com.monsanto.barter.web.faces.formalization;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.filter.FormalizationTermFilter;
import com.monsanto.barter.business.entity.list.TagList;
import com.monsanto.barter.business.entity.table.FormalizationTerm;
import com.monsanto.barter.business.service.IFormalizationTermService;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.omg.CORBA.Any;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.faces.component.UICommand;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.powermock.api.mockito.PowerMockito.mock;

/**
 * Test class for the FormalizationFaces class.
 * 
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class FormalizationFaces_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";
    public static final String ANY_CODE = "AnyCode";


    public static class FormalizationFacesForTest extends FormalizationFaces{

        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(IFormalizationTermService.class)) {
                IFormalizationTermService formalizationTermService = mock(IFormalizationTermService.class);

                return (T)formalizationTermService;
            }
            return super.getService(requiredType);
        }
    };

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public FormalizationFaces_UT() {

    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    @Test
    public void testEdit() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.edit();

        assertTrue(formalizationFaces.isBtnSave());
        assertFalse(formalizationFaces.isBtnEdit());
        assertTrue(formalizationFaces.isBtnExit());
    }

    @Test
    public void testSaveWithValidValues() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.save();

        assertFalse(formalizationFaces.isBtnSave());
        assertTrue(formalizationFaces.isBtnEdit());
        assertFalse(formalizationFaces.isBtnExit());
        assertTrue(formalizationFaces.getMessages().isEmpty());
    }

    @Test
    public void testExit() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.begin();
        String result = formalizationFaces.exit();

        assertEquals(HOME, result);
        assertTrue(formalizationFaces.getMessages().isEmpty());
    }

    @Test
    public void testCboLanguageListener() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.begin();
        FormalizationTerm formalizationVO = new FormalizationTerm();
        formalizationVO.setLanguage(LANGUAGE);
        formalizationFaces.setFormalizationVO(formalizationVO);
        formalizationFaces.cboLanguageListener();

        assertTrue(formalizationFaces.getMessages().isEmpty());
        assertEquals(LANGUAGE, formalizationFaces.getFormalizationVO().getLanguage());
    }

    @Test
    public void testInitForm() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.begin();

        assertTrue(formalizationFaces.getMessages().isEmpty());
        assertFalse(formalizationFaces.getItemsTag().isEmpty());
    }

    @Test
    public void testisSetBtnSave() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setBtnSave(false);

        assertFalse(formalizationFaces.isBtnSave());
    }
    @Test
    public void testisSetBtnEdit() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setBtnEdit(false);

        assertFalse(formalizationFaces.isBtnEdit());
    }
    @Test
    public void testisSetBtnExit() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setBtnExit(false);

        assertFalse(formalizationFaces.isBtnExit());
    }

    @Test
    public void testSetGetLanguageId() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setLanguageId(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getLanguageId());
    }

    @Test
    public void testSetGetFlagSave() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setFlagSave(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getFlagSave());
    }
    @Test
    public void testSetGetTagId() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setTagId(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getTagId());
    }
    @Test
    public void testSetGetTagSelected() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setTagSelected(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getTagSelected());
    }
    @Test
    public void testSetGetLeftValue() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setLeftValue(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getLeftValue());
    }
    @Test
    public void testSetGetTopValue() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setTopValue(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getTopValue());
    }
    @Test
    public void testSetGetTextareaSelected() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        formalizationFaces.setTextareaSelected(ANY_CODE);

        assertEquals(ANY_CODE, formalizationFaces.getTextareaSelected());
    }

    @Test
    public void testGetSetItemsLanguage() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        ArrayList<SelectItem> itemsLanguage = new ArrayList<SelectItem>();
        itemsLanguage.add(new SelectItem());
        formalizationFaces.setItemsLanguage(itemsLanguage);

        List<SelectItem> result = formalizationFaces.getItemsLanguage();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    @Test
    public void testGetSetItemsTag() {
        FormalizationFacesForTest formalizationFaces = new FormalizationFacesForTest();
        Map<String, TagList> tagLists = new HashMap<String, TagList>();
        tagLists.put(ANY_CODE, TagList.AMOUNT_BAG);
        formalizationFaces.setItemsTag(tagLists);

        List<TagList> result = formalizationFaces.getItemsTag();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
}
