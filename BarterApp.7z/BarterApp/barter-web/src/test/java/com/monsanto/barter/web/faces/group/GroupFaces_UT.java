package com.monsanto.barter.web.faces.group;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyListOf;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.faces.component.UICommand;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.powermock.reflect.Whitebox;
import org.springframework.beans.factory.BeanFactory;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.PermissionBusiness;
import com.monsanto.barter.business.entity.filter.GroupFilter;
import com.monsanto.barter.business.entity.filter.UserFilter;
import com.monsanto.barter.business.entity.list.PermissionTypeList;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.Permission;
import com.monsanto.barter.business.service.IGroupService;
import com.monsanto.barter.business.service.IPermissionService;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.web.test.SilentObjectCreator;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/4/12
 * Time: 10:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class GroupFaces_UT extends JsfTestCase {

    protected static final String SHOW_FILTER = "showFilter";
    protected static final String ERROR = "error";
    public static final String NEW = "new";
    public static final String NOT_NAVIGATE = "notNavigate";
	private GroupFaces tested;

    @Before
	public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
	public void searchGroupTest() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        groupFaces.searchGroup();
        Assert.assertTrue(groupFaces.getGroupList().size() == 1);
    }

    @Test
	public void loadStatusTest() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        groupFaces.loadStatus();
        Assert.assertFalse(groupFaces.getStatusGroup().size() == 0);
    }

    @Test
	public void loadPermissionTypesTest() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        groupFaces.loadPermissionTypes();
        Assert.assertFalse(groupFaces.getItemsPermissionTypes().size() == 0);
    }

    @Test
	public void cancelGroupTest() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        String retorno = groupFaces.cancelGroup();
        Assert.assertTrue(retorno.equals(SHOW_FILTER));
    }

    @Test
	public void cancelGroupNotValidTest() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        String retorno = groupFaces.cancelGroup();
        Assert.assertFalse(retorno.equals(ERROR));
    }

    @Test
	public void cancelGroupTestIsNotNewer() {
        GroupFaces groupFaces = new GroupFacesIGroupService();
        groupFaces.setNewer(false);
        String retorno = groupFaces.cancelGroup();
        Assert.assertTrue(retorno.equals(SHOW_FILTER));
    }

    @Test
    public void testEditGroup() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       String result =groupFaces.editGroup();

       Assert.assertFalse(result.equals(ERROR));
    }

    @Test
    public void testPopulateUsersSelected() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        ArrayList<com.monsanto.barter.business.entity.table.User> users = new ArrayList<com.monsanto.barter.business.entity.table.User>();
        com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
        user.setId("USER.TEST");
        users.add(user);
        groupFaces.populateUsersSelected(users);

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
    }

    @Test
    public void testLoadPermissions() {
        GroupFaces groupFaces = new GroupFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {
                if (requiredType.equals(IGroupService.class)) {
                    IGroupService groupService = mock(IGroupService.class);
                    List<Group> groupList = new ArrayList<Group>();
                    Group group = new Group();
                    group.setId(1L);
                    groupList.add(group);
                    ArrayList<Permission> permissions = new ArrayList<Permission>();
                    Permission permission = new Permission();
                    permission.setPermissionCd(2);
                    permissions.add(permission);
                    group.setPermissions(permissions);
                    when(groupService.search(Matchers.<GroupFilter>any())).thenReturn(groupList);
                    when(groupService.findByIdComplete(Matchers.<Group>any())).thenReturn(group);
                    return (T)groupService;
                }

                if (requiredType.equals(IPermissionService.class)) {
                    IPermissionService permissionService = mock(IPermissionService.class);
                    ArrayList<Permission> permissions = new ArrayList<Permission>();
                    Permission permission = new Permission();
                    permission.setPermissionCd(1);

                    permissions.add(permission);
                    when(permissionService.getCheckedGroupPermissions(Matchers.<List<PermissionBusiness>>any())).thenReturn(permissions);
                    when(permissionService.getUncheckedPermissions(Matchers.<List<PermissionBusiness>>any())).thenReturn(permissions);
                    return (T)permissionService;
                }
                return super.getService(requiredType);
            }
        };

        groupFaces.loadPermissions(1, PermissionTypeList.SCREEN_PERMISSION_TYPE_CD.getPermissionTypeCd());

        Assert.assertNotNull(groupFaces.getMessages());
        Assert.assertTrue(groupFaces.getMessages().isEmpty());
    }

    @Test
    public void testNewGroup() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       String result = groupFaces.newGroup();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(NEW, result);
    }

    @Test
    public void testSaveGroup() {
        GroupFaces groupFaces = new GroupFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {
                if (requiredType.equals(IGroupService.class)) {
                    IGroupService groupService = mock(IGroupService.class);
                    List<Group> groupList = new ArrayList<Group>();
                    Group group = new Group();
                    group.setId(1L);
                    groupList.add(group);
                    ArrayList<Permission> permissions = new ArrayList<Permission>();
                    Permission permission = new Permission();
                    permission.setPermissionCd(2);
                    permissions.add(permission);
                    group.setPermissions(permissions);
                    when(groupService.search(Matchers.<GroupFilter>any())).thenReturn(groupList);
                    when(groupService.findByIdComplete(Matchers.<Group>any())).thenReturn(group);
                    return (T)groupService;
                }

                if (requiredType.equals(IPermissionService.class)) {
                    IPermissionService permissionService = mock(IPermissionService.class);
                    ArrayList<Permission> permissions = new ArrayList<Permission>();
                    Permission permission = new Permission();
                    permission.setPermissionCd(1);
                    permission.setModuleCd(1);

                    permissions.add(permission);
                    when(permissionService.getCheckedGroupPermissions(Matchers.<List<PermissionBusiness>>any())).thenReturn(new ArrayList<Permission>());
                    return (T)permissionService;
                }
                if (requiredType.equals(IUserService.class)) {
                    IUserService userService = mock(IUserService.class);

                    return (T)userService;
                }

                return super.getService(requiredType);
            }
        };

       String result = groupFaces.saveGroup();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(NOT_NAVIGATE, result);
       
       
       //branch test
       setupMockServices();
       
       Permission permission = new PermissionBusiness();
       permission.setModuleCd(1);
       List<Permission> permissions = new ArrayList<Permission>();
       permissions.add(permission);
       Group group = new Group();
       com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();

       IPermissionService permissionServiceMock = getServiceMock(IPermissionService.class);
       IGroupService groupServiceMock = getServiceMock(IGroupService.class);
       
       Whitebox.setInternalState(tested, "moduleId", 1);
       Whitebox.setInternalState(tested, "newCheckedPermissions", Arrays.asList(new Permission[]{permission}));
       Whitebox.setInternalState(tested, "group", group );
       Whitebox.setInternalState(tested, "idUserSelectedList", Arrays.asList(new String[]{"1"}));
       Whitebox.setInternalState(tested, "userGroupList", Arrays.asList(new com.monsanto.barter.business.entity.table.User[]{}));
       
       when(permissionServiceMock.getCheckedGroupPermissions(anyListOf(PermissionBusiness.class))).thenReturn(permissions );
       when(groupServiceMock.validate(any(Group.class), anyList())).thenReturn(true);
       when(groupServiceMock.isOk()).thenReturn(true);
       when(getServiceMock(IUserService.class).findById(any(com.monsanto.barter.business.entity.table.User.class))).thenReturn(user);
       tested.saveGroup();
       
       Whitebox.setInternalState(tested, "moduleId", 0);
       when(groupServiceMock.validate(any(Group.class), anyList())).thenReturn(false);
       tested.saveGroup();
       
    }

    @Test
    public void testSearchAvailableUsers() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       groupFaces.searchAvailableUsers();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());

    }

    @Test
    public void testShowHistoryTab() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       String result = groupFaces.showHistoryTab();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals("tabHistory", groupFaces.getTab());
       Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testShowPermissionsTab() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       String result = groupFaces.showPermissionsTab();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals("tabPermissions", groupFaces.getTab());
       Assert.assertEquals(NOT_NAVIGATE, result);
    }
    @Test
    public void testCboModuleListener() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       groupFaces.cboModuleListener();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
    }

    @Test
    public void testCboPermissionTypeListener() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       groupFaces.cboPermissionTypeListener();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
    }

    @Test
    public void testGetQtd() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       int result = groupFaces.getQtd();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(0, result);
    }

    @Test
    public void testGetQtGroupHistory() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       int result = groupFaces.getQtGroupHistory();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(0, result);
    }

    @Test
    public void testGetQtPermissions() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       int result = groupFaces.getQtPermissions();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(0, result);
    }

    @Test
    public void testGetItemsModules() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       List<SelectItem> result = groupFaces.getItemsModules();

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(11, result.size());
    }

    @Test
    public void testGetSetGroup() {
       GroupFaces groupFaces = new GroupFacesIGroupService();
       Group group = new Group();
       group.setId(new Long(1L));

       groupFaces.setGroup(group);

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(group.getId(), groupFaces.getGroup().getId());
    }

    @Test
    public void testGetSetGroupFilter() {
       GroupFaces groupFaces = new GroupFacesIGroupService();
       GroupFilter groupFilter = new GroupFilter();
       Group group = new Group();
       group.setId(new Long(1));
       groupFilter.setGroup(group);

       groupFaces.setGroupFilter(groupFilter);

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(group.getId(), groupFaces.getGroupFilter().getGroup().getId());
    }

    @Test
    public void testGetSetUserVO() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
       userVO.setId("USER.TEST");
       groupFaces.setUserVO(userVO);

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(userVO.getId(), groupFaces.getUserVO().getId());
    }

    @Test
    public void testGetSetUserFilter() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

       com.monsanto.barter.business.entity.table.User userVO = new com.monsanto.barter.business.entity.table.User();
       userVO.setId("USER.TEST");
       groupFaces.setUserFilter(new UserFilter());
       groupFaces.getUserFilter().setUser(userVO);

       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(userVO.getId(), groupFaces.getUserFilter().getUser().getId());
    }

    @Test
    public void testGetSetModule() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        String module = "Module";
        groupFaces.setModule(module);


       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(module, groupFaces.getModule());
    }

    @Test
    public void testGetSetModuleId() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        Integer module = 1;
        groupFaces.setModuleId(module);


       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(module, groupFaces.getModuleId());
    }

    @Test
    public void testGetSetPermissionType() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        String permissionType = "Module";
        groupFaces.setPermissionType(permissionType);


       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(permissionType, groupFaces.getPermissionType());
    }


    @Test
    public void testGetSetPermissionTypeId() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        Integer permissionTypeId = 1;
        groupFaces.setPermissionTypeId(permissionTypeId);


       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals(permissionTypeId, groupFaces.getPermissionTypeId());
    }

    @Test
    public void testGetSetGroupId() {
       GroupFaces groupFaces = new GroupFacesIGroupService();

        String groupId = "1";
        groupFaces.setGroupId(groupId);


       Assert.assertNotNull(groupFaces.getMessages());
       Assert.assertTrue(groupFaces.getMessages().isEmpty());
       Assert.assertEquals( groupId, groupFaces.getGroupId());
    }


    public static class GroupFacesIGroupService extends GroupFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IGroupService.class)) {
                IGroupService groupService = mock(IGroupService.class);
                List<Group> groupList = new ArrayList<Group>();
                Group group = new Group();
                group.setId(1L);
                groupList.add(group);
                when(groupService.search(Matchers.<GroupFilter>any())).thenReturn(groupList);
                when(groupService.findByIdComplete(Matchers.<Group>any())).thenReturn(group);
                return (T)groupService;
            }
            if (requiredType.equals(IUserService.class)) {
                IUserService userService = mock(IUserService.class);

                ArrayList<com.monsanto.barter.business.entity.table.User> users = new ArrayList<com.monsanto.barter.business.entity.table.User>();
                com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
                user.setId("USER.TEST");
                users.add(user);

                when(userService.search(Matchers.<UserFilter>any())).thenReturn(users);

                return (T)userService;
            }
            return super.getService(requiredType);
        }

        @Override
        public void loadPermissions(Integer integer, Integer integer2){}

        @Override
        public Locale getCurrrentLocale() {
            return new Locale("pt");
        }

        @Override
        public String getMessage(String key, Object... arguments) {
            return SUCCESS;
        }
    }

    /**
     * Just for increasing coverage.
     */
    @Test
    public void test_OneLineCoverage() throws Exception {
    	setupMockServices();
    	
    	tested.setTab(null);
    	tested.setGroupList(null);
    	tested.getUserGroupList();
    	tested.setUserGroupList(null);
    	tested.getUserListSelected();
    	tested.setUserListSelected(null);
    	tested.setPermissions(null);
    	tested.isTableShow();
    	tested.isDeletedGroup();
    	tested.setDeletedGroup(false);
    	tested.getItemsUser();
    	tested.setItemsUser(null);
    	tested.setItemsModules(null);
    	tested.setItemsPermissionTypes(null);
    	tested.setStatusGroup(null);
    	tested.getNewCheckedPermissions();
    	tested.setNewCheckedPermissions(null);
    	tested.isEnableSaveBtn();
    	tested.setEnableSaveBtn(false);
    	tested.isCanAccessGroupNew();
    }
    
    /**
	 * Setup method constructor allows to inject services through beanFactory mock.
	 */
	private void setupMockServices() {
		
		tested=SilentObjectCreator.create(GroupFaces.class);//avoid default constructor
		
		Whitebox.setInternalState(tested, mock(BeanFactory.class));
	}
	
	private <T> T getServiceMock(Class<T> clazz) {
		T t = null;
		try {
			t = Whitebox.<T> invokeMethod(tested, "getService",
					new Class[] { Class.class }, clazz);
			if (t == null) {
				T mock = mock(clazz);
				BeanFactory beanFactoryMock = Whitebox.<BeanFactory> getInternalState(tested, "beanFactory");
				when(beanFactoryMock.getBean(clazz)).thenReturn(mock);
				t = getServiceMock(clazz);
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return t;
	}
	
}
