package com.monsanto.barter.web.faces.longshort;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.list.LongShortCropStatusList;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.entity.table.LongShortCrop;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.service.ICountryService;
import com.monsanto.barter.business.service.ILongShortCropService;
import com.monsanto.barter.web.test.JsfTestCase;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: GAVELO
 * Date: 9/23/13
 * Time: 11:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class CropFaces_UT extends JsfTestCase {


    private static final String COUNTRY_ID = "BRL";
    private static final String NOT_NAVIGATE = "notNavigate";
    private static final Character LANG = 'e';
    private static final String CHANGE ="change";
    private static final String SUCCESS ="success" ;


    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd(LANG);
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
    public void testInitFaces() {

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        Assert.assertNull(cropFaces.getMessages());
        Assert.assertNotNull(cropFaces.getCountries());
        Assert.assertEquals(1, cropFaces.getCountries().size());
        Assert.assertNotNull(cropFaces.getLongShortCropList());
        Assert.assertEquals(1, cropFaces.getLongShortCropList().size());

    }

    @Test
    public void testBeginFaces() {

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        cropFaces.begin();

        Assert.assertNull(cropFaces.getMessages());
        Assert.assertNotNull(cropFaces.getCountries());
        Assert.assertEquals(1, cropFaces.getCountries().size());
        Assert.assertNotNull(cropFaces.getLongShortCropList());
        Assert.assertEquals(1, cropFaces.getLongShortCropList().size());

    }


    @Test
    public void testGetQtdLongShorts() {

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        Assert.assertEquals(2, cropFaces.getQtdLongShorts());

    }


    @Test
    public void testIncludeLongShortCrop() {

        final ILongShortCropService longShortCropService = mock(ILongShortCropService.class);

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        LongShortCrop lsCrop = new LongShortCrop();
        lsCrop.setCountry(new Country());
        lsCrop.getCountry().setId(new CountryId());
        cropFaces.setLongShortCrop(lsCrop);

        String result = cropFaces.includeLongShortCrop();

        Assert.assertEquals(SUCCESS, result);
        verify(longShortCropService).save(lsCrop);

    }


    @Test
    public void testEditCrop() {

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        String result = cropFaces.editCrop();

        Assert.assertEquals(CHANGE, result);
        Assert.assertTrue(cropFaces.isDetail());

    }


    @Test
    public void testCancelEdit() {

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        String result = cropFaces.cancelEdit();

        Assert.assertEquals(NOT_NAVIGATE, result);
        Assert.assertFalse(cropFaces.isDetail());

    }


    @Test
    public void testCloseCrop() {

        final ILongShortCropService longShortCropService = mock(ILongShortCropService.class);

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        LongShortCrop lsCrop = new LongShortCrop();
        lsCrop.setCountry(new Country());
        lsCrop.getCountry().setId(new CountryId());
        cropFaces.setLongShortCrop(lsCrop);

        String result = cropFaces.closeCrop();

        Assert.assertEquals(SUCCESS, result);
        verify(longShortCropService).save(lsCrop);
        Assert.assertEquals(LongShortCropStatusList.CLOSED.getCd(), lsCrop.getStatusCd());
        Assert.assertEquals(LongShortCropStatusList.OPEN.getCd(), cropFaces.getLongShortCrop().getStatusCd());

    }


    @Test
    public void testCboCountryChanged() {

        final ILongShortCropService longShortCropService = mock(ILongShortCropService.class);

        CropFaces cropFaces = new CropFaces() {

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortCropService.class)) {
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList.add(new LongShortCrop());
                    longshortCropList.add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T) longShortCropService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService = mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T) countryService;
                }


                return super.getService(requiredType);

            }


        };

        LongShortCrop lsCrop = new LongShortCrop();
        lsCrop.setCountry(new Country());
        lsCrop.getCountry().setId(new CountryId());
        cropFaces.setLongShortCrop(lsCrop);

        cropFaces.cboCountryChanged(null);

        Assert.assertEquals(LANG, lsCrop.getCountry().getId().getLanguageCd());


    }


}
