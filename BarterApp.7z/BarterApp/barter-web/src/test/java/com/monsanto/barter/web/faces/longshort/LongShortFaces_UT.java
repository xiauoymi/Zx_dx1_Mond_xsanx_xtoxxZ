package com.monsanto.barter.web.faces.longshort;

import static org.junit.Assert.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.mockito.Matchers.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.el.ELResolver;
import javax.faces.component.UICommand;
import javax.faces.component.UIComponent;
import javax.faces.component.UIPanel;
import javax.faces.component.UISelectItems;
import javax.faces.component.UISelectOne;
import javax.faces.component.UIViewRoot;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlCommandLink;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlPanelGroup;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.component.html.HtmlSelectOneListbox;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.component.html.HtmlSelectOneRadio;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import com.monsanto.barter.business.service.*;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.powermock.reflect.Whitebox;
import org.richfaces.component.UIColumn;
import org.richfaces.component.UIDataTable;
import org.springframework.beans.factory.BeanFactory;

import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.LongShortBusiness;
import com.monsanto.barter.business.entity.business.PositionLongShortBusiness;
import com.monsanto.barter.business.entity.filter.CityFilter;
import com.monsanto.barter.business.entity.filter.CommodityFilter;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.filter.LongShortFilter;
import com.monsanto.barter.business.entity.filter.PositionLongShortFilter;
import com.monsanto.barter.business.entity.list.LongShortPositionList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.CityId;
import com.monsanto.barter.business.entity.table.id.CommodityId;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.entity.table.id.LongShortId;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.test.SilentObjectCreator;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: 10/3/12
 * Time: 11:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class LongShortFaces_UT extends JsfTestCase {

    private static final String COUNTRY_ID = "BRL";
    public static final String ANY_CODE = "ANY_CODE";
    public static final String NEW = "new";
    public static final String CHANGE = "change";
    public static final String NOT_NAVIGATE = "notNavigate";
	private LongShortFaces tested;

    @Before
	public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
	public void loadCountriesTest() {
        LongShortFaces longShortFaces = new LongShortFacesICityService();
        longShortFaces.beginPosition();
        longShortFaces.loadCities();
        Assert.assertTrue(longShortFaces.getListCity().size() == 2);
    }

    @Test
	public void loadCommodityAvailableValidTest() {
        LongShortFaces longShortFaces = new LongShortFacesICommodityAvailableService();
        longShortFaces.beginSearch();
        longShortFaces.loadCommodityAvaliable("Brazil");
        Assert.assertTrue(longShortFaces.getListCommodityAvaliable().size() == 1);
    }

    @Test
	public void loadCommodityAvailableNotValidTest() {
        LongShortFaces longShortFaces = new LongShortFacesICommodityAvailableService();
        longShortFaces.beginSearch();
        longShortFaces.loadCommodityAvaliable("Argentina");
        Assert.assertTrue(longShortFaces.getListCommodityAvaliable().size() == 0);
    }

    @Test
	public void loadCommodityValidTest() {
        LongShortFaces longShortFaces = new LongShortFacesICommodityAvailableService();
        longShortFaces.beginSearch();
        longShortFaces.loadCommodity("Brazil");
        Assert.assertTrue(longShortFaces.getItemsCommodity().size() == 1);
    }

    @Test
	public void searchLongShortTest() {
        LongShortFaces longShortFaces = new LongShortFacesICityService();
        longShortFaces.beginSearch();
        String result = longShortFaces.searchLongShort();
        Assert.assertEquals("success", result);
    }

    @Test
	public void testLoadCountries() {
        LongShortFaces longShortFaces = new LongShortFaces(){
           @Override
        public <T> T getService(Class<T> requiredType) {


            if (requiredType.equals(ICityService.class)) {
                ICityService citiService = mock(ICityService.class);
                List<City> cities = new ArrayList<City>();
                City city = new City();
                CityId cityId = new CityId();
                cityId.setCityCd("BRA");
                city.setDescCity("Brazil");
                city.setId(cityId);
                cities.add(city);
                when(citiService.searchAvaliable(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)citiService;
            }

            if (requiredType.equals(ILongShortService.class)) {
                ILongShortService longShortService = mock(ILongShortService.class);
                List<LongShortBusiness> longShortBusinessList = new ArrayList<LongShortBusiness>();
                longShortBusinessList.add(new LongShortBusiness());
                when(longShortService.getAll()).thenReturn(longShortBusinessList);
                return (T)longShortService;
            }

            if (requiredType.equals(ICountryService.class)) {
                ICountryService countryService=mock(ICountryService.class);
                ArrayList<Country> countries = new ArrayList<Country>();
                Country country = new Country(new CountryId());
                country.getId().setCountryCd(COUNTRY_ID);
                country.getId().setLanguageCd('P');
                countries.add(country);
                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                return (T)countryService;
            }

               if (requiredType.equals(ILongShortCropService.class)) {
                   ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                   List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                   longshortCropList .add(new LongShortCrop());
                   when(longShortCropService.getAll()).thenReturn(longshortCropList);
                   return (T)longShortCropService;
               }


            return super.getService(requiredType);
        }

        @Override
        public void loadCountriesAvaliable(){}
        };
        longShortFaces.beginSearch();

        longShortFaces.loadCountries();

        Assert.assertNotNull(longShortFaces.getMessages());
        Assert.assertEquals("", longShortFaces.getMessages());
        Assert.assertNotNull(longShortFaces.getListCountry());
        Assert.assertFalse(longShortFaces.getListCountry().isEmpty());
    }

    @Test
	public void testLoadCountriesAvailable() {
        LongShortFaces longShortFaces = new LongShortFaces(){
           @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICityService.class)) {
                ICityService citiService = mock(ICityService.class);
                List<City> cities = new ArrayList<City>();
                City city = new City();
                CityId cityId = new CityId();
                cityId.setCityCd("BRA");
                city.setDescCity("Brazil");
                city.setId(cityId);
                cities.add(city);
                when(citiService.searchAvaliable(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)citiService;
            }
                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    List<LongShortBusiness> longShortBusinessList = new ArrayList<LongShortBusiness>();
                    longShortBusinessList.add(new LongShortBusiness());
                    when(longShortService.getAll()).thenReturn(longShortBusinessList);
                    return (T)longShortService;
                }

                if (requiredType.equals(ICountryService.class)) {
                    ICountryService countryService=mock(ICountryService.class);
                    ArrayList<Country> countries = new ArrayList<Country>();
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_ID);
                    country.getId().setLanguageCd('P');
                    countries.add(country);
                    when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                    return (T)countryService;
            }

                if (requiredType.equals(ICommodityService.class)) {
                    ICommodityService commodityService=mock(ICommodityService.class);
                    ArrayList<Commodity> commodities = new ArrayList<Commodity>();
                    Commodity commodity = new Commodity(new CommodityId());
                    commodity.getId().setCommodityId(ANY_CODE);
                    commodity.getId().setCountryCd(COUNTRY_ID);
                    commodities.add(commodity);
                    when(commodityService.searchAvaliable()).thenReturn(commodities);
                    return (T)commodityService;
                }

               if (requiredType.equals(ILongShortCropService.class)) {
                   ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                   List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                   longshortCropList .add(new LongShortCrop());
                   when(longShortCropService.getAll()).thenReturn(longshortCropList);
                   return (T)longShortCropService;
               }


               return super.getService(requiredType);
           }


        };
        longShortFaces.beginSearch();

        longShortFaces.loadCountriesAvaliable();

        Assert.assertNotNull(longShortFaces.getMessages());
        Assert.assertEquals("", longShortFaces.getMessages());
        Assert.assertNotNull(longShortFaces.getListCountryAvaliable());
        Assert.assertFalse(longShortFaces.getListCountryAvaliable().isEmpty());

    }

    @Test
    public void testCboCountryAvaliableChangedWithoutCountryCdFilter() {
        LongShortFacesICityService longShortFacesICityService = new LongShortFacesICityService();
        longShortFacesICityService.beginSearch();
        longShortFacesICityService.cboCountryAvaliableChanged();

        Assert.assertNotNull(longShortFacesICityService.getListCommodityAvaliable());
        Assert.assertTrue(longShortFacesICityService.getListCommodityAvaliable().isEmpty());
    }

    @Test
    public void testCboCountryAvaliableChangedWithCountryCdFilter() {
        LongShortFaces longShortFacesICityService = new LongShortFaces(){
        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICityService.class)) {
                ICityService citiService = mock(ICityService.class);
                List<City> cities = new ArrayList<City>();
                City city = new City();
                CityId cityId = new CityId();
                cityId.setCityCd("BRA");
                city.setDescCity("Brazil");
                city.setId(cityId);
                cities.add(city);
                when(citiService.searchAvaliable(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)citiService;
            }else{
                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    List<LongShortBusiness> longShortBusinessList = new ArrayList<LongShortBusiness>();
                    longShortBusinessList.add(new LongShortBusiness());
                    when(longShortService.getAll()).thenReturn(longShortBusinessList);
                    return (T)longShortService;
                }else
                {
                    if (requiredType.equals(ICountryService.class)) {
                        ICountryService countryService=mock(ICountryService.class);
                        ArrayList<Country> countries = new ArrayList<Country>();
                        Country country = new Country(new CountryId());
                        country.getId().setCountryCd(COUNTRY_ID);
                        country.getId().setLanguageCd('P');
                        countries.add(country);
                        when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                        return (T)countryService;
                    }else
                    {
                        if (requiredType.equals(ICommodityService.class)) {
                            ICommodityService commodityService=mock(ICommodityService.class);
                            ArrayList<Commodity> commodities = new ArrayList<Commodity>();
                            Commodity commodity = new Commodity(new CommodityId());
                            commodity.getId().setCommodityId(ANY_CODE);
                            commodity.getId().setCountryCd(COUNTRY_ID);
                            commodities.add(commodity);
                            when(commodityService.searchAvaliable()).thenReturn(commodities);
                            return (T)commodityService;
                        }
                    }
                }
            }

            if (requiredType.equals(ILongShortCropService.class)) {
                ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                longshortCropList .add(new LongShortCrop());
                when(longShortCropService.getAll()).thenReturn(longshortCropList);
                return (T)longShortCropService;
            }

               return super.getService(requiredType);
           }
        };
        longShortFacesICityService.beginSearch();
        longShortFacesICityService.getPositionLongShortFilter().setCountryCd(COUNTRY_ID);

        longShortFacesICityService.cboCountryAvaliableChanged();

        Assert.assertNotNull(longShortFacesICityService.getListCommodityAvaliable());
        Assert.assertFalse(longShortFacesICityService.getListCommodityAvaliable().isEmpty());
    }

    @Test
    public void testCboCountryChangedWithoutCountryCdInCommodity() {
        LongShortFacesICityService longShortFacesICityService = new LongShortFacesICityService();
        longShortFacesICityService.beginSearch();

        longShortFacesICityService.cboCountryChanged();

        Assert.assertNotNull(longShortFacesICityService.getItemsCommodity());
        Assert.assertTrue(longShortFacesICityService.getItemsCommodity().isEmpty());
    }

    @Test
    public void testCboCountryChangedWithCountryCdInCommodity() {
        LongShortFacesICommodityAvailableService longShortFacesICommodityAvailableService = new LongShortFacesICommodityAvailableService();
        longShortFacesICommodityAvailableService.beginSearch();
        longShortFacesICommodityAvailableService.getCommodityId().setCountryCd(COUNTRY_ID);

        longShortFacesICommodityAvailableService.cboCountryChanged();

        Assert.assertNotNull(longShortFacesICommodityAvailableService.getItemsCommodity());
        Assert.assertFalse(longShortFacesICommodityAvailableService.getItemsCommodity().isEmpty());
    }

    @Test
    public void testSearchPositionViewLongShort() {
        LongShortFaces longShortFaces = new LongShortFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    Map<String, List<PositionLongShortBusiness>> map = new TreeMap<String, List<PositionLongShortBusiness>>();
                    map.put("BRL", new ArrayList<PositionLongShortBusiness>());
                    map.get("BRL").add(new PositionLongShortBusiness());
                    when(longShortService.groupByCity(Matchers.<List<PositionLongShortBusiness>>any())).thenReturn(map);
                    when(longShortService.isOk()).thenReturn(true);
                    return (T)longShortService;
                }else
                {
                    if (requiredType.equals(ISimulationService.class)) {
                        ISimulationService simulationService = mock(ISimulationService.class);
                        return (T)simulationService;
                    }else
                    {
                           if (requiredType.equals(ITradingContractService.class)) {
                                    ITradingContractService tradingContractService = mock(ITradingContractService.class);
                                    return (T)tradingContractService;
                           }else
                           {
                               if (requiredType.equals(ICountryService.class)) {
                                ICountryService countryService=mock(ICountryService.class);
                                ArrayList<Country> countries = new ArrayList<Country>();
                                Country country = new Country(new CountryId());
                                country.getId().setCountryCd(COUNTRY_ID);
                                country.getId().setLanguageCd('P');
                                countries.add(country);
                                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                                return (T)countryService;
                                }else
                               {
                                   if (requiredType.equals(ICityService.class)) {
                                        ICityService cityService = mock(ICityService.class);
                                        return (T)cityService;
                                   }

                               }
                           }
                    }
                }

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList .add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    when(longShortCropService.findById((LongShortCrop) any())).thenReturn(new LongShortCrop());
                    when(longShortCropService.isOk()).thenReturn(true);
                    return (T)longShortCropService;
                }

                return super.getService(requiredType);
            }
            @Override
            public void loadCountriesAvaliable(){}

            @Override
            public void loadCountries(){}

            @Override
            protected UIPanel getDynamicPanelByFormIdAndPanelId(String formId, String dynamicPanelId) {
                return new UIPanel();
            }

        };
        FacesContext.getCurrentInstance().getApplication().addComponent(UIDataTable.COMPONENT_TYPE, "org.richfaces.component.UIDataTable");
        FacesContext.getCurrentInstance().getApplication().addComponent(UIColumn.COMPONENT_TYPE, "org.richfaces.component.UIColumn");

        longShortFaces.beginSearch();

        longShortFaces.getPositionLongShortFilter().setCommodityId(ANY_CODE);
        String result = longShortFaces.searchPositionViewLongShort();

        Assert.assertNotNull(result);
        Assert.assertEquals("positionView", result);
    }

    @Test
    public void testNewLongShort() {
        LongShortFacesICityService longShortFacesICityService = new LongShortFacesICityService();

        String result = longShortFacesICityService.newLongShort();

        Assert.assertEquals(NEW, result);
    }

    @Test
    public void testEditLongShort() {
        LongShortFaces longShortFaces = new LongShortFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    when(longShortService.isOk()).thenReturn(true);
                    LongShort longShort = new LongShort();
                    longShort.setId(new LongShortId());
                    longShort.getId().setCommodityId(ANY_CODE);
                    longShort.getId().setCountryCd(COUNTRY_ID);
                    when(longShortService.findByIdWithHistory(Matchers.<LongShort>any())).thenReturn(longShort);
                    return (T)longShortService;
                }

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList .add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T)longShortCropService;
                }

                return super.getService(requiredType);
            }
            @Override
            public void loadCommodity(String countryCd) {}

            @Override
            public void loadCountries() {}

            @Override
            public void loadCountriesAvaliable(){}

            @Override
            public void loadCities() {}

        };

        Assert.assertEquals("success", longShortFaces.beginPosition());
        String result = longShortFaces.editLongShort();

        Assert.assertEquals("change", result);
    }

    @Test
    public void testDetailLongShort() {
          LongShortFaces longShortFaces = new LongShortFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    when(longShortService.isOk()).thenReturn(true);
                    LongShort longShort = new LongShort();
                    longShort.setId(new LongShortId());
                    longShort.getId().setCommodityId(ANY_CODE);
                    longShort.getId().setCountryCd(COUNTRY_ID);
                    when(longShortService.findByIdWithHistory(Matchers.<LongShort>any())).thenReturn(longShort);
                    return (T)longShortService;
                }

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList .add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T)longShortCropService;
                }


                return super.getService(requiredType);
            }
            @Override
            public void loadCommodity(String countryCd) {}

            @Override
            public void loadCountries() {}

            @Override
            public void loadCountriesAvaliable(){}

            @Override
            public void loadCities() {}

        };
        longShortFaces.beginSearch();

        String result = longShortFaces.detailLongShort();

        Assert.assertEquals("change", result);
    }
    @Test
    public void testIncludeLongShort() throws Exception {
          LongShortFaces longShortFaces = new LongShortFaces(){

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    when(longShortService.isOk()).thenReturn(true);
                    LongShort longShort = new LongShort();
                    longShort.setId(new LongShortId());
                    longShort.getId().setCommodityId(ANY_CODE);
                    longShort.getId().setCountryCd(COUNTRY_ID);
                    when(longShortService.findByIdWithHistory(Matchers.<LongShort>any())).thenReturn(longShort);
                    return (T)longShortService;
                }else
                {
                    if (requiredType.equals(ICommodityService .class)) {
                        ICommodityService commodityService=mock(ICommodityService.class);
                        Commodity commodity = new Commodity(new CommodityId());
                        commodity.getId().setCommodityId(ANY_CODE);
                        when(commodityService.findById(Matchers.<Commodity>any())).thenReturn(commodity);
                        return (T)commodityService;
                    }
                }


                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList .add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T)longShortCropService;
                }



                return super.getService(requiredType);
            }
            @Override
            public void loadCommodity(String countryCd) {}

            @Override
            public void loadCountries() {}

            @Override
            public void loadCountriesAvaliable(){}

            @Override
            public void loadCities() {}

        };
        Assert.assertEquals("success", longShortFaces.beginPosition());
        String result = longShortFaces.includeLongShort();

        Assert.assertEquals("notNavigate", result);
        
        setupMockServices();
        
        getServiceMock(ILongShortService.class);
        getServiceMock(ICommodityService.class);
        
        
        LongShortBusiness longShortBusiness = mock(LongShortBusiness.class);   
		Whitebox.setInternalState(tested, "longShort", longShortBusiness);
		LongShortId longShortId = new LongShortId();
		longShortId.setCommodityId("1");
		List<LongShortBusiness> longShortBusinesses = new ArrayList<LongShortBusiness>();
		longShortBusinesses.add(new LongShortBusiness(longShortId));
		Whitebox.setInternalState(tested, "longShorts", longShortBusinesses);
		Whitebox.setInternalState(tested, "commodityId", new CommodityId("1", ""));
        tested.includeLongShort();
        
		when(longShortBusiness.isChanged()).thenReturn(true);
		Whitebox.setInternalState(tested, "longShort", longShortBusiness);
        tested.includeLongShort();
        
    }
    @Test
    public void testSaveLongShort() {
          LongShortFaces longShortFaces = new LongShortFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ILongShortService.class)) {
                    ILongShortService longShortService = mock(ILongShortService.class);
                    when(longShortService.isOk()).thenReturn(true);
                    LongShort longShort = new LongShort();
                    longShort.setId(new LongShortId());
                    longShort.getId().setCommodityId(ANY_CODE);
                    longShort.getId().setCountryCd(COUNTRY_ID);
                    when(longShortService.findByIdWithHistory(Matchers.<LongShort>any())).thenReturn(longShort);
                    return (T)longShortService;
                }else
                {
                    if (requiredType.equals(ICommodityService .class)) {
                        ICommodityService commodityService=mock(ICommodityService.class);
                        return (T)commodityService;
                    }
                }

                if (requiredType.equals(ILongShortCropService.class)) {
                    ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                    List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                    longshortCropList .add(new LongShortCrop());
                    when(longShortCropService.getAll()).thenReturn(longshortCropList);
                    return (T)longShortCropService;
                }

                return super.getService(requiredType);
            }
            @Override
            public void loadCommodity(String countryCd) {}

            @Override
            public void loadCountries() {}

            @Override
            public void loadCountriesAvaliable(){}

            @Override
            public void loadCities() {}

        };

        String result = longShortFaces.saveLongShort();

        Assert.assertEquals("notNavigate", result);
        
        
        setupMockServices();
        
        getServiceMock(ICityService.class);
        MessageVO message = new MessageVO(IBarterConstants.MSG_CONCURRENCE_ERROR, MessageTypeList.INFO);
        List<MessageVO> messages = new ArrayList<MessageVO>();
        messages.add(message);
        
        ILongShortService longShortServiceMock = getServiceMock(ILongShortService.class);
        Whitebox.setInternalState(tested, "longShort", new LongShortBusiness());
        
        when(longShortServiceMock.isOk()).thenReturn(false);
		when(longShortServiceMock.getMessages()).thenReturn(messages);
        tested.saveLongShort();
    }

    @Test
    public void testCancelLongShort() {
        LongShortFacesICityService longShortFacesICityService = new LongShortFacesICityService();

        String result =longShortFacesICityService.cancelLongShort();

        Assert.assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testShowHistoryTab() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        longShortFaces.showHistoryTab();

        Assert.assertEquals("tabHistory", longShortFaces.getTab());
    }

    @Test
    public void testGetQtLongShortHistory() {
       LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

       int result = longShortFaces.getQtLongShortHistory();

       Assert.assertEquals(0, result);
    }

    @Test
    public void testGetQtdLongShorts() {
       LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
       longShortFaces.beginSearch();

       int result = longShortFaces.getQtdLongShorts();

       Assert.assertEquals(1, result);
    }

    @Test
    public void testGetSetTab() throws Exception {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        longShortFaces.setTab(ANY_CODE);

        Assert.assertEquals(ANY_CODE, longShortFaces.getTab());
    }

    @Test
    public void testGetSetLongShort() throws Exception {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        LongShortBusiness longShort = new LongShortBusiness();
        longShort.setDescCountry(COUNTRY_ID);
        longShortFaces.setLongShort(longShort);

        Assert.assertEquals(COUNTRY_ID, longShortFaces.getLongShort().getDescCountry());
    }


    @Test
    public void testGetSetLongShortFilter() throws Exception {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        LongShortFilter longShort = new LongShortFilter();
        longShort.setCountryCd(COUNTRY_ID);
        longShortFaces.setFilter(longShort);

        Assert.assertEquals(COUNTRY_ID, longShortFaces.getFilter().getCountryCd());
    }

    @Test
    public void testGetSetPositionLongShort() throws Exception {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        PositionLongShortFilter  longShort = new PositionLongShortFilter();
        longShort.setCountryCd(COUNTRY_ID);
        longShortFaces.setPositionLongShortFilter(longShort);

        Assert.assertEquals(COUNTRY_ID, longShortFaces.getPositionLongShortFilter().getCountryCd());
    }

    @Test
    public void testGetCurrentLimit() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        BigDecimal result = longShortFaces.getCurrentLimit();

        Assert.assertNull(result);
    }
    @Test
    public void testGetCurrentPosition() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        BigDecimal result = longShortFaces.getCurrentPosition();

        Assert.assertNull( result);
    }
    @Test
    public void testGetExpositionLongShort() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

        BigDecimal result = longShortFaces.getExpositionLongShort();

        Assert.assertNull( result);
    }

    @Test
    public void testGetSetLongShorts() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<LongShortBusiness> longShorts = new ArrayList<LongShortBusiness>();
        LongShortBusiness longShortBusiness = new LongShortBusiness();
        longShortBusiness.setDescCountry(COUNTRY_ID);
        longShorts.add(longShortBusiness);
        longShortFaces.setLongShorts(longShorts);

        List<LongShortBusiness> result = longShortFaces.getLongShorts();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetItemsCommodities() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> itemsCommodity = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        itemsCommodity.add(selectItem);
        longShortFaces.setItemsCommodity(itemsCommodity);

        List<SelectItem> result = longShortFaces.getItemsCommodity();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetListCountries() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> countries = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        countries.add(selectItem);
        longShortFaces.setListCountry(countries);

        List<SelectItem> result = longShortFaces.getListCountry();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetListCities() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> cities = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        cities.add(selectItem);
        longShortFaces.setListCity(cities);

        List<SelectItem> result = longShortFaces.getListCity();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetListCountryAvaliable() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> countries = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        countries.add(selectItem);
        longShortFaces.setListCountryAvaliable(countries);

        List<SelectItem> result = longShortFaces.getListCountryAvaliable();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetListCommodityAvaliable() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> commodities = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        commodities.add(selectItem);
        longShortFaces.setListCommodityAvaliable(commodities);

        List<SelectItem> result = longShortFaces.getListCommodityAvaliable();

        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
    }

    @Test
    public void testGetSetListPositionLongShort() {
        LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
        ArrayList<SelectItem> positionsLongShort = new ArrayList<SelectItem>();
        SelectItem selectItem = new SelectItem();
        positionsLongShort.add(selectItem);
        longShortFaces.setListPositionLongShort(positionsLongShort);

        List<SelectItem> result = longShortFaces.getListPositionLongShort();

        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.size());
    }

    @Test
    public void testIsSetFlgKgLimitation() throws Exception {
         LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

         longShortFaces.setFlgKgLimitation(true);

         Assert.assertTrue(longShortFaces.isFlgKgLimitation());
    }

    @Test
    public void testGetSetCommodityId() throws Exception {
         LongShortFacesICityService longShortFaces = new LongShortFacesICityService();
         CommodityId commodityId = new CommodityId();
         commodityId.setCountryCd(COUNTRY_ID);

        longShortFaces.setCommodityId(commodityId);

         Assert.assertEquals(COUNTRY_ID, longShortFaces.getCommodityId().getCountryCd());
    }

    @Test
    public void testIsSetFlgTabHistory() throws Exception {
         LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

         longShortFaces.setFlgTabHistory(true);

         Assert.assertTrue(longShortFaces.isFlgTabHistory());
    }

    @Test
    public void testIsSetFlgCancelConfirm() throws Exception {
         LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

         longShortFaces.setFlgCancelConfirm(true);

         Assert.assertTrue(longShortFaces.isFlgCancelConfirm());
    }

    @Test
    public void testGetSetSexoId() throws Exception {
         LongShortFacesICityService longShortFaces = new LongShortFacesICityService();

         longShortFaces.setSexoId(ANY_CODE);

         Assert.assertEquals(ANY_CODE, longShortFaces.getSexoId());
    }

    @Test
    public void testGetSetDynamicPanel() {
        LongShortFaces longShortFaces = new LongShortFacesICityService();
        UIPanel dynamicPanel = new UIPanel();
        dynamicPanel.setId(ANY_CODE);
        longShortFaces.setDynamicPanel(dynamicPanel);

        UIPanel result = longShortFaces.getDynamicPanel();

        Assert.assertNotNull(result);
        Assert.assertEquals(ANY_CODE, result.getId());
    }
    
    /**
     * @throws Exception
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createPanelGroup()
     */
	@Test
	public void testProtectedMethod_createPanelGroup() throws Exception {

		setupMockServices();

		// mocking
		UIPanel uiPanelMock = mock(UIPanel.class);
		Whitebox.setInternalState(tested, uiPanelMock);
		// invoke test (branch1.1)
		HtmlPanelGroup result = Whitebox.<HtmlPanelGroup> invokeMethod(tested,"createPanelGroup", "1");
		assertNotNull(result);
		
		// invoke test (branch1.2)
		result = Whitebox.<HtmlPanelGroup> invokeMethod(tested,"createPanelGroup", "");
		assertNotNull(result);
	}
	
	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createInputText()
     */
	@Test
	public void testProtectedMethod_createInputText() throws Exception {

		setupMockServices();

		// mocking
		 UIComponent uiComponentMock = mock(UIComponent.class);
		
		// invoke test (branch1.1)
		HtmlInputText result = Whitebox.<HtmlInputText> invokeMethod(tested,"createInputText", uiComponentMock, "1", "");
		assertNotNull(result);
		
		// invoke test (branch1.2)
		result = Whitebox.<HtmlInputText> invokeMethod(tested,"createInputText", uiComponentMock, "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createSelectOneMenu()
     */
	@Test
	public void testProtectedMethod_createSelectOneMenu() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T,2T)
		HtmlSelectOneMenu result = Whitebox.<HtmlSelectOneMenu> invokeMethod(
				tested, "createSelectOneMenu", uiComponentMock, "1", "}",
				Object.class);
		assertNotNull(result);

		// invoke test (branch 1F,2F)
		result = Whitebox.<HtmlSelectOneMenu> invokeMethod(tested,
				"createSelectOneMenu", uiComponentMock, "", "", Object.class);
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createSelectOneListbox()
     */
	@Test
	public void testProtectedMethod_createSelectOneListbox() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T,2T)
		HtmlSelectOneListbox result = Whitebox.<HtmlSelectOneListbox> invokeMethod(
				tested, "createSelectOneListbox", uiComponentMock, "1", "");
		assertNotNull(result);

		// invoke test (branch 1F,2F)
		result = Whitebox.<HtmlSelectOneListbox> invokeMethod(tested,
				"createSelectOneListbox", uiComponentMock, "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createSelectOneRadio()
     */
	@Test
	public void testProtectedMethod_createSelectOneRadio() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T,2T)
		HtmlSelectOneRadio result = Whitebox.<HtmlSelectOneRadio> invokeMethod(
				tested, "createSelectOneRadio", uiComponentMock, "1", "}");
		assertNotNull(result);

		// invoke test (branch 1F,2F)
		result = Whitebox.<HtmlSelectOneRadio> invokeMethod(tested,
				"createSelectOneRadio", uiComponentMock, "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createInputHidden()
     */
	@Test
	public void testProtectedMethod_createInputHidden() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T,2T)
		HtmlInputHidden result = Whitebox.<HtmlInputHidden> invokeMethod(
				tested, "createInputHidden", uiComponentMock, "a", "}", Object.class);
		assertNotNull(result);

		// invoke test (branch 1F,2F)
		result = Whitebox.<HtmlInputHidden> invokeMethod(tested,
				"createInputHidden", uiComponentMock, "", "", Object.class);
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createCommandButton()
     */
	@Test
	public void testProtectedMethod_createCommandButton() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T)
		HtmlCommandButton result = Whitebox.<HtmlCommandButton> invokeMethod(
				tested, "createCommandButton", uiComponentMock, "1", "", "");
		assertNotNull(result);

		// invoke test (branch 1F)
		result = Whitebox.<HtmlCommandButton> invokeMethod(tested,
				"createCommandButton", uiComponentMock, "", "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createCommandLink()
     */
	@Test
	public void testProtectedMethod_createCommandLink() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T,2T)
		HtmlCommandLink result = Whitebox.<HtmlCommandLink> invokeMethod(
				tested, "createCommandLink", uiComponentMock, "1", "", Object.class, "", Object.class);
		assertNotNull(result);

		// invoke test (branch 1F,2F)
		result = Whitebox.<HtmlCommandLink> invokeMethod(tested,
				"createCommandLink", uiComponentMock, "", "", Object.class, "", Object.class);
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#addSelectItem()
     */
	@Test
	public void testProtectedMethod_addSelectItem() throws Exception {
		setupMockServices();

		// mocking
		UISelectOne uiSelectOneMock = mock(UISelectOne.class);
		UISelectItems uiSelectItemsMock = mock(UISelectItems.class);
		List<SelectItem> selectItems = new ArrayList<SelectItem>();
		SelectItem selectItemMock = mock(SelectItem.class);
		selectItems.add(selectItemMock);
		when(uiSelectItemsMock.getValue()).thenReturn(selectItems);
		List<UIComponent> uiComponents = new ArrayList<UIComponent>();
		uiComponents.add(uiSelectItemsMock);
		when(uiSelectOneMock.getChildren()).thenReturn(uiComponents );

		// invoke test (branch 1T,2T)
		Whitebox.invokeMethod(tested, "addSelectItem", uiSelectOneMock , "", "");
	}

	/**
	 * @throws Exception
	 * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createCommandLink(UIComponent,
	 *      String, String, String, String, Class, String, Class)
	 */
	@Test
	public void testProtectedMethod_createCommandLink_overload() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		HtmlCommandLink result = Whitebox.<HtmlCommandLink> invokeMethod(
				tested, "createCommandLink", uiComponentMock, "", "", "", "", Object.class, "", Object.class);
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createSelectBooleanCheckbox()
     */
	@Test
	public void testProtectedMethod_createSelectBooleanCheckbox() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		// invoke test (branch 1T)
		HtmlSelectBooleanCheckbox result = Whitebox.<HtmlSelectBooleanCheckbox> invokeMethod(
				tested, "createSelectBooleanCheckbox", uiComponentMock, "1", "", "");
		assertNotNull(result);

		// invoke test (branch 1F)
		result = Whitebox.<HtmlSelectBooleanCheckbox> invokeMethod(tested,
				"createSelectBooleanCheckbox", uiComponentMock, "", "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#createGraphicImage()
     */
	@Test
	public void testProtectedMethod_createGraphicImage() throws Exception {
		setupMockServices();

		// mocking
		UIComponent uiComponentMock = mock(UIComponent.class);

		HtmlGraphicImage result = Whitebox.<HtmlGraphicImage> invokeMethod(
				tested, "createGraphicImage", uiComponentMock, "", "");
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#buildDynamicFields(String, String)
     */
	@Test
	public void testPrivateMethod_buildDynamicFields() throws Exception {
		setupMockServices();

		getServiceMock(ILongShortService.class);
		getServiceMock(ISimulationService.class);
		getServiceMock(ITradingContractService.class);
		PositionLongShortFilter longShortFilter = new PositionLongShortFilter();
		longShortFilter.setCommodityId("1");
		longShortFilter.setPosition(LongShortPositionList.LONG);
		Whitebox.setInternalState(tested, "positionLongShortFilter", longShortFilter);
		
		List<MessageVO> result = Whitebox.<List<MessageVO>> invokeMethod(
				tested, "buildDynamicFields", "1", "1");

		longShortFilter.setPosition(LongShortPositionList.SHORT);
		result = Whitebox.<List<MessageVO>> invokeMethod(
				tested, "buildDynamicFields", "1", "1");
		
		assertNotNull(result);
	}

	/**
     * @throws Exception 
     * @see com.monsanto.barter.web.faces.longshort.LongShortFaces#fillPositionLongShort
     */
	@Test
	public void testPrivateMethod_fillPositionLongShort() throws Exception {
		setupMockServices();

		LongShort longShort = new LongShort();
		longShort.setPositionType(LongShortPositionList.SHORT.getPositionType());

        LongShortBalance balance = new LongShortBalance();
        balance.setLongShort(longShort);
		
		Whitebox.invokeMethod(tested, "fillPositionLongShort", null);
		
		Whitebox.invokeMethod(tested, "fillPositionLongShort", balance);
		
		longShort.setKgLimitation(new BigDecimal(0));
		balance.setPositionValue(new BigDecimal(0));
		balance.setExposureValue(new BigDecimal(0));
		Whitebox.invokeMethod(tested, "fillPositionLongShort", balance );
	}
	
	/**
	 * Setup method constructor allows to inject services through beanFactory mock.
	 */
	private void setupMockServices() {
		
		tested = SilentObjectCreator.create(LongShortFaces.class);//avoid default constructor
		
		ICountryService countryServiceMock = mock(ICountryService.class);
        ArrayList<Country> countries = new ArrayList<Country>();
        Country country = new Country(new CountryId());
        country.getId().setCountryCd("BRL");
        country.setShortDesc("BRAZIL");
        countries.add(country);
        when(countryServiceMock.search(Matchers.<CountryFilter>any())).thenReturn(countries);
				
        BeanFactory beanFactoryMock = mock(BeanFactory.class);
        when(beanFactoryMock.getBean(ICountryService.class)).thenReturn(countryServiceMock);
    	Whitebox.setInternalState(tested, beanFactoryMock);//inject beanFactory
    	
    	FacesContext facesContextMock = FacesContext.getCurrentInstance();
    	UIViewRoot rootMock = mock(UIViewRoot.class);
    	when(rootMock.findComponent(anyString())).thenReturn(mock(UIComponent.class));
    	when(rootMock.getLocale()).thenReturn(Locale.getDefault());
		facesContextMock.setViewRoot(rootMock );
        
	}
	
	private <T> T getServiceMock(Class<T> clazz) {
		T t = null;
		try {
			t = Whitebox.<T> invokeMethod(tested, "getService",
					new Class[] { Class.class }, clazz);
			if (t == null) {
				T mock = mock(clazz);
				BeanFactory beanFactoryMock = Whitebox.<BeanFactory> getInternalState(tested, "beanFactory");
				when(beanFactoryMock.getBean(clazz)).thenReturn(mock);
				t = getServiceMock(clazz);
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return t;
	}
    

    public static class LongShortFacesICityService extends LongShortFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(ICityService.class)) {
                ICityService citiService = mock(ICityService.class);
                List<City> cities = new ArrayList<City>();
                City city = new City();
                CityId cityId = new CityId();
                cityId.setCityCd("BRA");
                city.setDescCity("Brazil");
                city.setId(cityId);
                cities.add(city);
                when(citiService.searchAvaliable(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)citiService;
            }

            if (requiredType.equals(ILongShortService.class)) {
                ILongShortService longShortService = mock(ILongShortService.class);
                List<LongShortBusiness> longShortBusinessList = new ArrayList<LongShortBusiness>();
                longShortBusinessList.add(new LongShortBusiness());
                when(longShortService.getAll()).thenReturn(longShortBusinessList);
                return (T)longShortService;
            }

            if (requiredType.equals(ILongShortCropService.class)) {
                ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                longshortCropList .add(new LongShortCrop());
                when(longShortCropService.getAll()).thenReturn(longshortCropList);
                return (T)longShortCropService;
            }

            return super.getService(requiredType);
        }

        @Override
        public void loadCountriesAvaliable(){}

        @Override
        public void loadCountries(){}
    }

    public static class LongShortFacesICommodityAvailableService extends LongShortFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICommodityService.class)) {
                ICommodityService commodityService = mock(ICommodityService.class);
                List<Commodity> commodities = new ArrayList<Commodity>();
                Commodity commodity = new Commodity();
                CommodityId commodityId = new CommodityId();
                commodityId.setCommodityId("Brazil");
                commodityId.setCountryCd("Brazil");
                commodity.setId(commodityId);
                commodity.setDescCommodity("Brazil Comm");
                commodities.add(commodity);

                when(commodityService.searchAvaliable()).thenReturn(commodities);
                when(commodityService.search(Matchers.<CommodityFilter>any())).thenReturn(commodities);
                return (T)commodityService;
            }

            if (requiredType.equals(ILongShortService.class)) {
                ILongShortService longShortService = mock(ILongShortService.class);
                return (T)longShortService;
            }

            if (requiredType.equals(ILongShortCropService.class)) {
                ILongShortCropService longShortCropService = mock(ILongShortCropService.class);
                List<LongShortCrop> longshortCropList = new ArrayList<LongShortCrop>();
                longshortCropList .add(new LongShortCrop());
                when(longShortCropService.getAll()).thenReturn(longshortCropList);
                return (T)longShortCropService;
            }

            return super.getService(requiredType);
        }

        @Override
        public void loadCountriesAvaliable(){}

        @Override
        public void loadCountries(){}

        @Override
        public void loadCities(){}
    }
}
