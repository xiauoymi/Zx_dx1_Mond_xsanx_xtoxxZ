package com.monsanto.barter.web.faces.main;

import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.SimulationBusiness;
import com.monsanto.barter.business.entity.filter.CountryFilter;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.entity.table.id.CountryId;
import com.monsanto.barter.business.service.ICountryService;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.faces.context.FacesContext;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Locale;

import static org.junit.Assert.*;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Test class for the FormalizationFaces class.
 * 
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class MainFaces_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";
    public static final String ANY_CODE = "any.code";
    public static final String COUNTRY_CD = "BRL";
    public static final BigDecimal BALANCE_EXPECTED = new BigDecimal(5);
    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String TAB_HISTORY = "tabHistory";
    public static final String SUCCESS = "success";
    public static final String CHANGE = "change";
    private static final String SHOW_RESULT = "showResult";

    private static final User user = new User();

    public static class MainFacesForTest extends MainFaces {

        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICountryService.class)) {
                ICountryService countryService = mock(ICountryService.class);
                ArrayList<Country> countries = new ArrayList<Country>();
                Country country = new Country(new CountryId());
                country.getId().setCountryCd("BRL");
                country.setShortDesc("BRAZIL");
                countries.add(country);
                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                return (T)countryService;
            }
            return super.getService(requiredType);
        }
        public <T extends BaseJSF> T getFaces(String requiredFaces) {
            if(requiredFaces.equals("simulationFaces"))
            {
                SimulationFaces simulationFaces = mock(SimulationFaces.class);
                when(simulationFaces.getSimulationSelected()).thenReturn(new SimulationBusiness());
                return (T)simulationFaces;
            }
            return null;
        }

        @Override
        public com.monsanto.barter.architecture.regionalization.Country getCountry() {
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }
    };

    public static class MainFacesWithCountryForTest extends MainFaces {

        private com.monsanto.barter.architecture.regionalization.Country country;

        @Override
        public com.monsanto.barter.architecture.regionalization.Country getCountry() {
            return country;
        }

        public void setCountry( com.monsanto.barter.architecture.regionalization.Country country){
            this.country = country;
        }
    }

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public MainFaces_UT() {

    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    @Test
    public void testConstructorForNewMainFaces() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testSetEnglishLanguage() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        String result = mainFaces.setEnglishLanguage();

        assertNull(mainFaces.getMessages());
        assertEquals(Locale.ENGLISH, FacesContext.getCurrentInstance().getViewRoot().getLocale());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testSetSpanishLanguage() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        String result = mainFaces.setSpanishLanguage();

        assertNull(mainFaces.getMessages());
        assertEquals( new Locale("es"), FacesContext.getCurrentInstance().getViewRoot().getLocale());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testSetPortugueseLanguage() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        String result = mainFaces.setPortugueseLanguage();

        assertNull(mainFaces.getMessages());
        assertEquals( new Locale("pt", "br"), FacesContext.getCurrentInstance().getViewRoot().getLocale());
        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testExit() throws Exception {
        MainFacesForTest mainFaces = new MainFacesForTest(){
            @Override
            protected String getProperty(String key) {
                   return "exit";
                }

        };

        mainFaces.exit();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessAdministration() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessAdministration();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessGroup() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessGroup();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessGroupSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessGroupSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessGroupNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessGroupNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessUser() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessUser();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessUserSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessUserSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessUserNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessUserNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessFormalization() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessFormalization();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCampaign() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCampaign();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCampaignBarter() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCampaignBarter();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCampaignSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCampaignSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCampaignNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCampaignNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCommunication() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCommunication();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCommunicationSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCommunicationSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCommunicationNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessCommunicationNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessOrders() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessOrders();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccesssSimulation() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccesssSimulation();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessSimulationSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessSimulationSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessSimulationNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessSimulationNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessSimulationExistingSale() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessSimulationExistingSale();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessLongShort() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessLongShort();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessViewLongShortSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessViewLongShortSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessViewLongShortConsumption() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessViewLongShortConsumption();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessTradingContract() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessTradingContract();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessTradingContractSearch() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessTradingContractSearch();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessTradingContractNew() {
        MainFacesForTest mainFaces = new MainFacesForTest();

        mainFaces.isCanAccessTradingContractNew();

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsCanAccessCrops() {
        MainFacesForTest mainFaces = new MainFacesForTest();
        mainFaces.setUser(user);

        assertFalse(mainFaces.isCanAccessCrops());

        user.getPermissions().add(new Permission(PermissionList.LONG_SHORT_CROP_SCREEN_PERMISSION_CD.getPermissionCd()));
        assertTrue(mainFaces.isCanAccessCrops());

        assertNull(mainFaces.getMessages());
    }

    @Test
    public void testIsBarterParaguay() {

        MainFacesWithCountryForTest mainFaces = new MainFacesWithCountryForTest();

        mainFaces.setCountry(com.monsanto.barter.architecture.regionalization.Country.PARAGUAY);

        assertTrue(mainFaces.isBarterParaguay());
        assertFalse(mainFaces.isBarterBrazil());
        assertFalse(mainFaces.isBarterArgentina());
        assertFalse(mainFaces.isBarterMexico());

    }

    @Test
    public void testIsBarterArgentina() {

        MainFacesWithCountryForTest mainFaces = new MainFacesWithCountryForTest();

        mainFaces.setCountry(com.monsanto.barter.architecture.regionalization.Country.ARGENTINA);

        assertFalse(mainFaces.isBarterParaguay());
        assertFalse(mainFaces.isBarterBrazil());
        assertTrue(mainFaces.isBarterArgentina());
        assertFalse(mainFaces.isBarterMexico());

    }

    @Test
    public void testIsBarterBrazil() {

        MainFacesWithCountryForTest mainFaces = new MainFacesWithCountryForTest();

        mainFaces.setCountry(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);

        assertFalse(mainFaces.isBarterParaguay());
        assertTrue(mainFaces.isBarterBrazil());
        assertFalse(mainFaces.isBarterArgentina());
        assertFalse(mainFaces.isBarterMexico());

    }


    @Test
    public void testIsBarterMexico() {

        MainFacesWithCountryForTest mainFaces = new MainFacesWithCountryForTest();

        mainFaces.setCountry(com.monsanto.barter.architecture.regionalization.Country.MEXICO);

        assertFalse(mainFaces.isBarterParaguay());
        assertFalse(mainFaces.isBarterBrazil());
        assertFalse(mainFaces.isBarterArgentina());
        assertTrue(mainFaces.isBarterMexico());

    }

}
