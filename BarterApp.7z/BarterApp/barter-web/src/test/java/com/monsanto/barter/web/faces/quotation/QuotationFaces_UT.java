package com.monsanto.barter.web.faces.quotation;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.business.SimulationBusiness;
import com.monsanto.barter.business.entity.business.TradingContractBusiness;
import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.ContractStatusList;
import com.monsanto.barter.business.entity.list.ContractTypeList;
import com.monsanto.barter.business.entity.list.QuoteTypeList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.simulation.SimulationFaces;
import com.monsanto.barter.web.faces.tradingcontract.TradingContractFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.faces.component.UICommand;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Test class for the FormalizationFaces class.
 * 
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class QuotationFaces_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String ANY_CODE = "any.code";
    public static final String COUNTRY_CD = "BRL";
    public static final BigDecimal BALANCE_EXPECTED = new BigDecimal(5);
    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String TAB_HISTORY = "tabHistory";
    public static final String SUCCESS = "success";
    public static final String CHANGE = "change";
    private static final String SHOW_RESULT = "showResult";


    public static class QuotationFacesForTest extends QuotationFaces {

        @Override
        public <T> T getService(Class<T> requiredType) {


            if (requiredType.equals(IQuotationService.class)) {
                IQuotationService quotationService = mock(IQuotationService.class);
                ArrayList<QuotationBusiness> quotationBusinesses = new ArrayList<QuotationBusiness>();
                when(quotationService.searchBusinessObjects(Matchers.<QuotationFilter>any())).thenReturn(quotationBusinesses);

                return (T)quotationService;
            }


            return super.getService(requiredType);
        }


        public <T extends BaseJSF> T getFaces(String requiredFaces) {
            if(requiredFaces.equals("quotationFaces"))
            {
                QuotationFaces quotationFaces = mock(QuotationFaces.class);
                return (T)quotationFaces;
            }
            if(requiredFaces.equals("simulationFaces"))
            {
                SimulationFaces simulationFaces = mock(SimulationFaces.class);
                when(simulationFaces.getSimulationSelected()).thenReturn(new SimulationBusiness());
                return (T)simulationFaces;
            }
            return null;
        }
    };

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public QuotationFaces_UT() {

    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    @Test
    public void testSearch() {
        QuotationFacesForTest quotationFacesForTest = new QuotationFacesForTest();
        QuotationFilter quotationFilter = new QuotationFilter();
        quotationFacesForTest.setQuotationFilter(quotationFilter);

        quotationFacesForTest.search();

        assertNotNull(quotationFacesForTest.getMessages());
        assertTrue(quotationFacesForTest.getMessages().isEmpty());
    }

    @Test
    public void testGetQtdQuotes() {
        QuotationFacesForTest quotationFacesForTest = new QuotationFacesForTest();
        QuotationFilter quotationFilter = new QuotationFilter();
        quotationFacesForTest.setQuotationFilter(quotationFilter);

        int result = quotationFacesForTest.getQtdQuotes();

        assertEquals(0, result);
    }

    @Test
    public void testGetQuotes() {
        QuotationFacesForTest quotationFacesForTest = new QuotationFacesForTest();
        QuotationFilter quotationFilter = new QuotationFilter();
        quotationFacesForTest.setQuotationFilter(quotationFilter);

        List<QuotationBusiness> result =  quotationFacesForTest.getQuotes();

        assertNull(result);
    }

    @Test
    public void testGetAndSetQuotationFilter() {
        QuotationFacesForTest quotationFacesForTest = new QuotationFacesForTest();
        QuotationFilter quotationFilter = new QuotationFilter();
        quotationFacesForTest.setQuotationFilter(quotationFilter);


        QuotationFilter newQuotation = quotationFacesForTest.getQuotationFilter();

        assertEquals(quotationFilter, newQuotation);
    }

    @Test
    public void testGetAndSetQuotationBusiness() {
        QuotationFacesForTest quotationFacesForTest = new QuotationFacesForTest();
        QuotationBusiness quotationBusiness = new QuotationBusiness();
        quotationFacesForTest.setQuotationBusiness(quotationBusiness);

        QuotationBusiness newQuotationBusiness = quotationFacesForTest.getQuotationBusiness();

        assertEquals(quotationBusiness, newQuotationBusiness);
    }


}
