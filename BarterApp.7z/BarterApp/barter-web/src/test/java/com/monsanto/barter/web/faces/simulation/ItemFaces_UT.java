package com.monsanto.barter.web.faces.simulation;

import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.regionalization.Country;
import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.business.SalesPriceSimulate;
import com.monsanto.barter.business.entity.filter.CampaignBrandFilter;
import com.monsanto.barter.business.entity.filter.DivisionFilter;
import com.monsanto.barter.business.entity.filter.ProductFilter;
import com.monsanto.barter.business.entity.list.BarterTypeList;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.id.DivisionId;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.webservice.service.IWSSalesPriceSimulateService;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.faces.model.SelectItem;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MGORO
 * Date: 9/7/12
 * Time: 9:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class ItemFaces_UT extends JsfTestCase {

    public static final String ANY_CODE = "AnyCode";

    @Before
    public void setUp() throws Exception {
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setLanguageCd('e');
        loggedInUser.setCountyCd(Country.PARAGUAY.getCountrySAPCd());
        SecurityUtil.setLoggedInUser(loggedInUser);
    }

    @Test
    public void loadDivisionsTest() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        Simulation simulation = new Simulation();
        simulation.setCampaign(new Campaign());
        itemFaces.setSimulation(simulation);
        itemFaces.loadDivisions();
        Assert.assertTrue(itemFaces.getDivisionList().size() == 1);
    }

    @Test
    public void testLoadDivision() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        Simulation simulation = new Simulation();
        simulation.setCampaign(new Campaign());
        itemFaces.setSimulation(simulation);
        itemFaces.loadDivisions();
        itemFaces.loadDivision();
        Assert.assertTrue(itemFaces.getDivisionList().size() == 1);
    }

    @Test
    public void testDrpDivisionChanged() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setDivision(new Division(new DivisionId()));
        simulationItem.getDivision().getId().setDivisionCd(ANY_CODE);
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationItem.getProduct().setBrandCd(ANY_CODE);
        itemFaces.setSimulationItem(simulationItem);

        itemFaces.drpDivisionChanged();

        Assert.assertTrue(itemFaces.getProductList().isEmpty());
    }

    @Test
    public void testDrpBrandChangedWithBrandCd() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        SecurityUtil.getLoggedInUser().setCountyCd("BR");
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setDivision(new Division(new DivisionId()));
        simulationItem.getDivision().getId().setDivisionCd(ANY_CODE);
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationItem.getProduct().setBrandCd(ANY_CODE);
        itemFaces.setSimulationItem(simulationItem);

        itemFaces.drpBrandChanged();

        Assert.assertFalse(itemFaces.getProductList().isEmpty());
    }

    @Test
    public void testDrpBrandChangedWithoutBrandCd() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        itemFaces.drpBrandChanged();

        Assert.assertTrue(itemFaces.getProductList().isEmpty());
    }

    @Test
    public void testDrpProductChangedWithMaterialNbr() throws Exception {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setDivision(new Division(new DivisionId()));
        simulationItem.getDivision().getId().setDivisionCd(ANY_CODE);
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr("10190782");
        simulationItem.getProduct().setBrandCd(ANY_CODE);
        itemFaces.setSimulationItem(simulationItem);

        //Test paraguay
        SecurityUtil.getLoggedInUser().setCountyCd("PY");
        itemFaces.drpProductChanged();

        //Test other countries
        SecurityUtil.getLoggedInUser().setCountyCd("BR");
        itemFaces.drpProductChanged();

        Assert.assertEquals(new BigDecimal(10), itemFaces.getSimulationItem().getItemAmount());
        Assert.assertEquals(new BigDecimal(5), itemFaces.getSimulationItem().getFinalPrice());
        Assert.assertEquals(new BigDecimal(30), itemFaces.getSimulationItem().getTotalAmount());
    }

    @Test
    public void testDrpProductChangedWithoutMaterialNbr() throws Exception {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setDivision(new Division(new DivisionId()));
        simulationItem.getDivision().getId().setDivisionCd(ANY_CODE);
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setBrandCd(ANY_CODE);
        itemFaces.setSimulationItem(simulationItem);

        itemFaces.drpProductChanged();

        Assert.assertNull(itemFaces.getSimulationItem().getItemAmount());
        Assert.assertNull(itemFaces.getSimulationItem().getFinalPrice());
        Assert.assertNull(itemFaces.getSimulationItem().getTotalAmount());
    }

    @Test
    public void testTxtQuantityChanged() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        itemFaces.txtQuantityChanged();

        Assert.assertEquals(new BigDecimal(30), itemFaces.getSimulationItem().getTotalAmount());
    }

    @Test
    public void testTxtPercentsChanged() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

         //Test paraguay
        SecurityUtil.getLoggedInUser().setCountyCd("PY");

        Simulation simulation = new Simulation();
        simulation.setCampaign(new Campaign());
        itemFaces.setSimulation(simulation);

        itemFaces.txtPercentsChanged();

        Assert.assertNotNull(itemFaces.getMessages());
        Assert.assertEquals(new BigDecimal(5), itemFaces.getSimulationItem().getFinalPrice());
        Assert.assertEquals(new BigDecimal(30), itemFaces.getSimulationItem().getTotalAmount());
    }

    @Test
    public void testSetGetMessages() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        ArrayList<MessageVO> messages = new ArrayList<MessageVO>();
        messages.add(new MessageVO());
        itemFaces.setMessages(messages);
        itemFaces.clearMessages();

        Assert.assertNotNull(itemFaces.getMessages());
        Assert.assertEquals("", itemFaces.getMessages());
    }

    @Test
    public void testIsOk() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        Assert.assertFalse(itemFaces.isOk());
    }

    @Test
    public void testSetGetDivisionList() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        ArrayList<SelectItem> divisionList = new ArrayList<SelectItem>();
        divisionList.add(new SelectItem());
        itemFaces.setDivisionList(divisionList);

        Assert.assertFalse(itemFaces.getDivisionList().isEmpty());
        Assert.assertEquals(1, itemFaces.getDivisionList().size());
    }

    @Test
    public void testSetGetBrandList() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        ArrayList<SelectItem> brandList = new ArrayList<SelectItem>();
        brandList.add(new SelectItem());
        itemFaces.setBrandList(brandList);

        Assert.assertFalse(itemFaces.getBrandList().isEmpty());
        Assert.assertEquals(1, itemFaces.getBrandList().size());
    }

    @Test
    public void testSetGetProductList() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        ArrayList<SelectItem> productList = new ArrayList<SelectItem>();
        productList.add(new SelectItem());
        itemFaces.setProductList(productList);

        Assert.assertFalse(itemFaces.getProductList().isEmpty());
        Assert.assertEquals(1, itemFaces.getProductList().size());
    }

    @Test
    public void testGetSetSimulationItem() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setFinalPrice(new BigDecimal(10));

        itemFaces.setSimulationItem(simulationItem);
        SimulationItem result = itemFaces.getSimulationItem();

        Assert.assertNotNull(result);
        Assert.assertEquals(new BigDecimal(10), result.getFinalPrice());
    }

    @Test
    public void testIsDivisionChemicalsByDefault() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        Assert.assertFalse(itemFaces.isDivisionChemicals());
    }

    @Test
    public void testIsSetEditByDefault() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        itemFaces.setEdit(true);

        Assert.assertTrue(itemFaces.isEdit());
    }

    @Test
    public void testGetSetSimulation() {
        ItemFaces itemFaces = new ItemFacesIDivisionService();

        Simulation simulation = new Simulation();
        simulation.setBarterType(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod());
        Campaign campaign = new Campaign();
        campaign.setIncentive(BigDecimal.ZERO);
        simulation.setCampaign(campaign);
        itemFaces.setSimulation(simulation);
        Simulation result = itemFaces.getSimulation();

        Assert.assertNotNull(result);
        Assert.assertEquals(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod(), result.getBarterType());

    }

    @Test
    public void loadProductsTest() {
        ItemFaces itemFaces = new ItemFacesIProductService();
        SecurityUtil.getLoggedInUser().setCountyCd("BR");
        itemFaces.loadProducts("17");
        Assert.assertTrue(itemFaces.getProductList().size() == 1);
    }

    private static class ItemFacesIDivisionService extends ItemFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IDivisionService.class)) {
                IDivisionService divisionService = mock(IDivisionService.class);
                List<Division> divisions = new ArrayList<Division>();
                Division d1 = new Division();
                d1.setId(new DivisionId("1", 'e'));
                d1.setDesc("Division1");
                d1.getId().setDivisionCd(ANY_CODE);
                divisions.add(d1);
                when(divisionService.search(Matchers.<DivisionFilter>any())).thenReturn(divisions);
                when(divisionService.findById(Matchers.<Division>any())).thenReturn(d1);
                return (T) divisionService;
            }
            if (requiredType.equals(IProductService.class)) {
                IProductService productService = mock(IProductService.class);
                List<Product> products = new ArrayList<Product>();
                Product prod1 = new Product();
                prod1.setMaterialNbr("Prod Material 1");
                prod1.setEnteredMaterialCd("Prod Entered Material 1");
                prod1.setWeightUnit("KG");
                products.add(prod1);
                when(productService.search(Matchers.<ProductFilter>any())).thenReturn(products);
                when(productService.findById(Matchers.<Product>any())).thenReturn(prod1);
                return (T) productService;
            }
            if (requiredType.equals(ICampaignBrandService.class)) {
                ICampaignBrandService campaignBrandService = mock(ICampaignBrandService.class);
                List<CampaignBrand> campaignBrands = new ArrayList<CampaignBrand>();
                CampaignBrand campaignBrand = new CampaignBrand();
                campaignBrand.setDivisionCd(ANY_CODE);
                campaignBrand.setBrandCd(ANY_CODE);
                campaignBrands.add(campaignBrand);
                when(campaignBrandService.search(Matchers.<CampaignBrandFilter>any())).thenReturn(campaignBrands);
                return (T) campaignBrandService;
            }
            if (requiredType.equals(ISimulationItemService.class)) {
                ISimulationItemService simulationItemService = mock(ISimulationItemService.class);

                when(simulationItemService.calculateItemAmount(Matchers.<SimulationItem>any())).thenReturn(new BigDecimal(10));
                when(simulationItemService.calculateFinalPrice(Matchers.<SimulationItem>any())).thenReturn(new BigDecimal(5));
                when(simulationItemService.calculateTotalAmount(Matchers.<SimulationItem>any())).thenReturn(new BigDecimal(30));
                return (T) simulationItemService;
            }
            if (requiredType.equals(IWSSalesPriceSimulateService.class)) {
                IWSSalesPriceSimulateService salesPriceSimulateService = mock(IWSSalesPriceSimulateService.class);
                SalesPriceSimulate salesPriceSimulate = new SalesPriceSimulate(new BigDecimal("100"), "KG");
                try {
                    when(salesPriceSimulateService.getProductInformation(Matchers.<Simulation>any(), Matchers.<SimulationItem>any())).thenReturn(salesPriceSimulate);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return (T) salesPriceSimulateService;
            }
            if(requiredType.equals(IWhitePaperService.class)){
                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                WhitePaper whitePaper = new WhitePaper();
                whitePaper.setName("Whitepaper 1");
                whitePaper.setAmount(BigDecimal.valueOf(1000L));
                return (T) whitePaperService;
            }
            return super.getService(requiredType);
        }

        @Override
        public Country getCountry() {
            if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.ARGENTINA.getCountrySAPCd()))
                return Country.ARGENTINA;
            else if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.BRAZIL.getCountrySAPCd()))
                return Country.BRAZIL;
            else if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.PARAGUAY.getCountrySAPCd()))
                return Country.PARAGUAY;
            return null;
        }
    }

    private static class ItemFacesIProductService extends ItemFaces {
        @Override
        public <T> T getService(Class<T> requiredType) {
            if (requiredType.equals(IProductService.class)) {
                IProductService productService = mock(IProductService.class);
                List<Product> products = new ArrayList<Product>();
                Product prod1 = new Product();
                prod1.setMaterialNbr("Prod Material 1");
                prod1.setEnteredMaterialCd("Prod Entered Material 1");
                products.add(prod1);
                when(productService.search(Matchers.<ProductFilter>any())).thenReturn(products);
                return (T) productService;
            }
            if(requiredType.equals(IWhitePaperService.class)){
                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                WhitePaper whitePaper = new WhitePaper();
                whitePaper.setName("Whitepaper 1");
                whitePaper.setAmount(BigDecimal.valueOf(1000L));
                return (T) whitePaperService;
            }
            return super.getService(requiredType);
        }
        @Override
        public Country getCountry() {
            if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.ARGENTINA.getCountrySAPCd()))
                return Country.ARGENTINA;
            else if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.BRAZIL.getCountrySAPCd()))
                return Country.BRAZIL;
            else if (SecurityUtil.getLoggedInUser().getCountyCd().equals(Country.PARAGUAY.getCountrySAPCd()))
                return Country.PARAGUAY;
            return null;
        }
    }
}
