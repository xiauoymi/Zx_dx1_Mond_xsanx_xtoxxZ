package com.monsanto.barter.web.faces.simulation;


import com.monsanto.barter.ar.business.entity.File;
import com.monsanto.barter.ar.business.service.AttachmentService;
import com.monsanto.barter.architecture.message.MessageTypeList;
import com.monsanto.barter.architecture.message.MessageVO;
import com.monsanto.barter.architecture.regionalization.*;
import com.monsanto.barter.architecture.security.data.Permission;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.architecture.web.jsf.BaseJSF;
import com.monsanto.barter.business.entity.business.FormalizationTermBusiness;
import com.monsanto.barter.business.entity.business.InvoiceSimulationBusiness;
import com.monsanto.barter.business.entity.business.QuotationBusiness;
import com.monsanto.barter.business.entity.business.SimulationBusiness;
import com.monsanto.barter.business.entity.filter.*;
import com.monsanto.barter.business.entity.list.*;
import com.monsanto.barter.business.entity.table.*;
import com.monsanto.barter.business.entity.table.Country;
import com.monsanto.barter.business.entity.table.id.*;
import com.monsanto.barter.business.service.*;
import com.monsanto.barter.business.util.IBarterConstants;
import com.monsanto.barter.web.faces.customer.CustomerFaces;
import com.monsanto.barter.web.faces.fileupload.FileUpload;
import com.monsanto.barter.web.faces.quotation.QuotationFaces;
import com.monsanto.barter.web.faces.tradingcontract.TradingContractFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import com.monsanto.barter.web.test.SilentObjectCreator;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.reflect.Whitebox;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.test.util.ReflectionTestUtils;

import javax.el.ELResolver;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ActionEvent;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doNothing;

/**
 * Test class for the FormalizationFaces class.
 *
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@SuppressWarnings({"serial","unchecked"})
public class SimulationFaces_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";
    public static final String ANY_CODE = "any.code";
    public static final String COUNTRY_CD = "BRL";
    public static final BigDecimal BALANCE_EXPECTED = new BigDecimal(5);
    public static final String TAB_HISTORY = "tabHistory";
    public static final String SUCCESS = "success";
    public static final String CHANGE = "change";
    private static final String SHOW_RESULT = "showResult";
    public static final String NOT_NAVIGATE = "notNavigate";
    public static final String CANCEL = "cancel";

    private SimulationFaces tested;

    public static class SimulationFacesForTest extends SimulationFaces {

        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(ICountryService.class)) {
                ICountryService countryService = mock(ICountryService.class);
                ArrayList<Country> countries = new ArrayList<Country>();
                Country country = new Country(new CountryId());
                country.getId().setCountryCd("BRL");
                country.setShortDesc("BRAZIL");
                countries.add(country);
                when(countryService.search(Matchers.<CountryFilter>any())).thenReturn(countries);
                return (T)countryService;
            }
            if (requiredType.equals(ICommodityService.class)) {
                ICommodityService commodityService = mock(ICommodityService.class);

                Commodity commodity = new Commodity();
                commodity.setUnitOfMeasure(ANY_CODE);
                when(commodityService.findById(Matchers.<Commodity>any())).thenReturn(commodity);
                return (T)commodityService;
            }

            if (requiredType.equals(ISimulationService.class)) {
                ISimulationService simulationService = mock(ISimulationService.class);
                ArrayList<Simulation> simulations = new ArrayList<Simulation>();
                Simulation simulation = new Simulation();
                simulation.setSimulationNumber("123456");
                simulations.add(simulation);

                when(simulationService.searchSimulationForExistingSale(SecurityUtil.getLoggedInUser().getCountyCd())).thenReturn(simulations);
                when(simulationService.validateCampaign(Matchers.<Simulation>any())).thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {
                        Object[] args = invocation.getArguments();
                        Campaign campaign = new Campaign();
                        campaign.setCountry(new Country(new CountryId()));
                        ((Simulation)args[0]).setCampaign(campaign);
                        return true;
                    }
                });//thenReturn(true);
                when(simulationService.validateFCPA(Matchers.<Simulation>any())).thenReturn(true);
                when(simulationService.validateRequiredSimulationFieldsForItemsFilled(Matchers.<Simulation>any())).thenReturn(true);

                return (T)simulationService;
            }

            if (requiredType.equals(IUserService.class)) {
                IUserService userService = mock(IUserService.class);
                ArrayList<com.monsanto.barter.business.entity.table.User> users = new ArrayList<com.monsanto.barter.business.entity.table.User>();
                com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
                SaleDistrict saleDistrict = new SaleDistrict();
                user.setSaleDistrict(saleDistrict);
                user.setId(USER_ID);
                Unit unit = new Unit();
                unit.setId(ANY_CODE);
                user.setUnit(unit);
                users.add(user);
                when(userService
                        .findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any()))
                        .thenReturn(user);
                when(userService
                        .findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any()))
                        .thenReturn(user);

                when(userService
                        .search(Matchers.<UserFilter>any()))
                        .thenReturn(users);
                return (T)userService;
            }
            if (requiredType.equals(ICampaignService.class)) {
                ICampaignService campaignService = mock(ICampaignService.class);
                ArrayList<Campaign> campaigns = new ArrayList<Campaign>();
                Campaign campaign = new Campaign();
                campaign.setId(new Long(1));
                campaign.setName(ANY_CODE);
                campaign.setCropBaseYear(ANY_CODE);
                campaigns.add(campaign);
                Country country = new Country(new CountryId());
                country.getId().setCountryCd(COUNTRY_CD);
                campaign.setCountry(country);
                campaign.setIncentive(new BigDecimal(10));
                when(campaignService.search(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                when(campaignService.findById(Matchers.<Campaign>any())).thenReturn(campaign);
                when(campaignService.findByIdComplete(Matchers.<Campaign>any())).thenReturn(campaign);
                return (T)campaignService;
            }

            if (requiredType.equals(ICustomerService.class)) {
                ICustomerService customerService = mock(ICustomerService.class);
                ArrayList<String> customersNames= new ArrayList<String>();
                customersNames.add("John");
                customersNames.add("Paul");
                when(customerService.searchNames(Matchers.<CustomerFilter>any())).thenReturn(customersNames);
                Customer customer = new Customer();

                when(customerService.findByIdComplete(Matchers.<Customer>any())).thenReturn(customer);
                return (T)customerService;
            }
            if (requiredType.equals(IMktCampaignService.class)) {
                IMktCampaignService mktCampaignService = mock(IMktCampaignService.class);
                ArrayList<MktCampaign> mktCampaigns = new ArrayList<MktCampaign>();
                MktCampaign mktCampaign = new MktCampaign();
                mktCampaign.setId(new MktCampaignId());
                mktCampaign.getId().setCustGroup5(ANY_CODE);
                mktCampaigns.add(mktCampaign);
                mktCampaign.setCampaignDesc(ANY_CODE);
                when(mktCampaignService.search(Matchers.<MktCampaignFilter>any())).thenReturn(mktCampaigns);
                return (T)mktCampaignService;
            }
            if (requiredType.equals(ICurrencyService.class)) {
                ICurrencyService currencyService = mock(ICurrencyService.class);
                ArrayList<Currency> currencies = new ArrayList<Currency>();
                Currency currency = new Currency(new CurrencyId());
                currency.getId().setCurrencyCd(ANY_CODE);
                currency.getId().setLanguageCd('P');
                currencies.add(currency);
                when(currencyService.search(Matchers.<CurrencyFilter>any())).thenReturn(currencies);
                return (T)currencyService;
            }
            if (requiredType.equals(IFormalizationTermService.class)) {
                IFormalizationTermService formalizationTermService = mock(IFormalizationTermService.class);
                ArrayList<Currency> currencies = new ArrayList<Currency>();

                when(formalizationTermService.searchByLanguage(Matchers.<FormalizationTermFilter>any())).thenReturn(new FormalizationTerm());
                return (T)formalizationTermService;
            }
            if (requiredType.equals(ICampaignCommodityService.class)) {
                ICampaignCommodityService campaignCommodityService = mock(ICampaignCommodityService.class);
                ArrayList<CampaignCommodity> campaignCommodities = new ArrayList<CampaignCommodity>();
                CampaignCommodity campaignCommodity = new CampaignCommodity();
                campaignCommodity.setId(new CampaignCommodityId());
                campaignCommodity.getId().setCommodity(new Commodity(new CommodityId()));
                campaignCommodity.getId().getCommodity().getId().setCommodityId(ANY_CODE);
                campaignCommodity.getId().getCommodity().setDescCommodity(ANY_CODE);
                campaignCommodities.add(campaignCommodity);
                when(campaignCommodityService.search(Matchers.<CampaignCommodityFilter>any())).thenReturn(campaignCommodities);
                return (T)campaignCommodityService;
            }
            if (requiredType.equals(IIncotermsService.class)) {
                IIncotermsService incotermsService = mock(IIncotermsService.class);
                ArrayList<Incoterms> incotermses = new ArrayList<Incoterms>();
                Incoterms incoterms = new Incoterms(new IncotermsId());
                incoterms.getId().setIncotermsCd(ANY_CODE);
                incotermses.add(incoterms);
                when(incotermsService.search(Matchers.<IncotermsFilter>any())).thenReturn(incotermses);
                return (T)incotermsService;
            }
            if (requiredType.equals(IRegionService.class)) {
                IRegionService regionService = mock(IRegionService.class);
                ArrayList<Region> regions = new ArrayList<Region>();
                Region region = new Region(new RegionId());
                region.getId().setCountryCd(COUNTRY_CD);
                region.getId().setRegionCd(ANY_CODE);
                regions.add(region);

                when(regionService.search(Matchers.<RegionFilter>any())).thenReturn(regions);
                return (T)regionService;
            }
            if (requiredType.equals(ICityService.class)) {
                ICityService cityService = mock(ICityService.class);
                ArrayList<City> cities = new ArrayList<City>();
                City city = new City(new CityId());
                city.getId().setCountryCd(COUNTRY_CD);
                city.getId().setRegionCd(ANY_CODE);
                city.getId().setCityCd(ANY_CODE);
                city.setDescCity(ANY_CODE);
                cities.add(city);
                when(cityService.search(Matchers.<CityFilter>any())).thenReturn(cities);
                return (T)cityService;
            }
            if (requiredType.equals(ITradingService.class)) {
                ITradingService tradingService = mock(ITradingService.class);
                ArrayList<Trading> tradings = new ArrayList<Trading>();
                Trading trading = new Trading(new TradingId());
                trading.getId().setCountryCd(COUNTRY_CD);
                trading.getId().setTradingCd(ANY_CODE);
                tradings.add(trading);
                when(tradingService.search(Matchers.<TradingFilter>any())).thenReturn(tradings);
                return (T)tradingService;
            }
            if (requiredType.equals(ICropService.class)) {
                ICropService tradingService = mock(ICropService.class);
                ArrayList<Crop> crops = new ArrayList<Crop>();
                Crop crop = new Crop();
                crop.setId(new Long(1));
                crop.setCropDesc(ANY_CODE);
                crops.add(crop);
                when(tradingService.search(Matchers.<CropFilter>any())).thenReturn(crops);
                return (T)tradingService;
            }
            if (requiredType.equals(IPartnerYaService.class)) {
                IPartnerYaService partnerYaService = mock(IPartnerYaService.class);
                ArrayList<PartnerYa> partnerYas = new ArrayList<PartnerYa>();
                PartnerYa partnerYa = new PartnerYa();

                partnerYas.add(partnerYa);
                when(partnerYaService.search(Matchers.<PartnerYaFilter>any())).thenReturn(partnerYas);
                return (T)partnerYaService;
            }

            if (requiredType.equals(ICampaignBarterTypeService.class)) {
                ICampaignBarterTypeService campaignBarterTypeService = mock(ICampaignBarterTypeService.class);

                List<CampaignBarterType> barterTypes = new ArrayList<CampaignBarterType>();
                CampaignBarterType campaignBarterType = new CampaignBarterType();
                campaignBarterType.setId( new CampaignBarterTypeId());
                campaignBarterType.getId().setBarterType( new BarterType("1"));
                campaignBarterType.getId().setCampaign( new Campaign());

                barterTypes.add(campaignBarterType);

                when(campaignBarterTypeService.search(Matchers.<CampaignBarterTypeFilter>any())).thenReturn(barterTypes);
                return (T)campaignBarterTypeService;
            }


            if (requiredType.equals(IUnitService.class)) {

                IUnitService unitService = mock(IUnitService.class);

                Unit unit = new Unit();
                when(unitService.findById(Matchers.<Unit>any())).thenReturn(unit);

                return (T)unitService;
            }


            if (requiredType.equals(IRegionalService.class)) {

                IRegionalService regionalService = mock(IRegionalService.class);

                Regional regional = new Regional();

                when(regionalService.findById(Matchers.<Regional>any())).thenReturn(regional);

                return (T)regionalService;
            }

            if (requiredType.equals(ICampaignTradingService.class)) {

            	ICampaignTradingService campaignTradingService = mock(ICampaignTradingService.class);

            	List<CampaignTrading> campaignTradings = new ArrayList<CampaignTrading>();
            	CampaignTrading campaignTrading = new CampaignTrading();
                campaignTrading.setId( new CampaignTradingId());
                campaignTrading.getId().setTrading( new Trading(new TradingId("")));

                campaignTradings.add(campaignTrading);

                when(campaignTradingService.search(Matchers.<CampaignTradingFilter>any())).thenReturn(campaignTradings);

                return (T)campaignTradingService;
            }

            if (requiredType.equals(ISimulationItemService.class)) {

                ISimulationItemService simulationItemService = mock(ISimulationItemService.class);

                return (T) simulationItemService ;

            }
            if(requiredType.equals(AttachmentService.class)){
                AttachmentService attachmentService = mock(AttachmentService.class);
                BarAttachment attachmentSelected = mock(BarAttachment.class);
                return (T) attachmentService;
            }

            if(requiredType.equals(IWhitePaperService.class)){
                IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                WhitePaper whitePaper = new WhitePaper();
                whitePaper.setName("Whitepaper 1");
                whitePaper.setAmount(BigDecimal.valueOf(1000L));
                return (T) whitePaperService;
            }

            return super.getService(requiredType);
        }

        @Override
        public <T extends BaseJSF> T getFaces(String requiredFaces) {
            if(requiredFaces.equals("itemFaces"))
            {
                ItemFaces itemFaces = mock(ItemFaces.class);
                return (T)itemFaces;
            }
            if(requiredFaces.equals("customerFaces"))
            {
                CustomerFaces customerFaces = mock(CustomerFaces.class);
                return (T)customerFaces;
            }

            return null;
        }

        @Override
        protected Boolean getParameterBoolean(String param) {
             if(param.equals("isNewSale"))
                 return null;
            return super.getParameterBoolean(param);
        }

        @Override
        public com.monsanto.barter.architecture.regionalization.Country getCountry() {
            return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
        }


    };

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public SimulationFaces_UT() {

    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        com.monsanto.barter.architecture.security.data.User loggedInUser = new com.monsanto.barter.architecture.security.data.User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('e');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    @Test
    public void testConstructorForNewSimulationFaces() {
        SimulationFacesForTest simulationFacesForTest = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                 if(param.equals("isNewSale"))
                     return true;
                return super.getParameterBoolean(param);
            }
        };

        assertNull(simulationFacesForTest.getMessages());
    }

    @Test
    public void testConstructorForNotNewSimulationFaces() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testVerifyUserType() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.verifyUserType();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testVerifyUserTypeWithRegional() {
        SimulationFaces simulationFaces = new SimulationFaces(){
        @Override
        public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    ArrayList<Simulation> simulations = new ArrayList<Simulation>();
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulations.add(simulation);
                    when(simulationService.searchSimulationForExistingSale(SecurityUtil.getLoggedInUser().getCountyCd())).thenReturn(simulations);
                    return (T)simulationService;
                }
                if (requiredType.equals(ICampaignService.class)) {
                    ICampaignService campaignService = mock(ICampaignService.class);
                    ArrayList<Campaign> campaigns = new ArrayList<Campaign>();
                    Campaign campaign = new Campaign();
                    campaign.setId(new Long(1));
                    campaign.setName(ANY_CODE);
                    campaigns.add(campaign);
                    Country country = new Country(new CountryId());
                    country.getId().setCountryCd(COUNTRY_CD);
                    campaign.setCountry(country);

                    when(campaignService.search(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                    when(campaignService.findById(Matchers.<Campaign>any())).thenReturn(campaign);
                    return (T)campaignService;
                }

                if (requiredType.equals(IUserService.class)) {
                    IUserService userService = mock(IUserService.class);
                    com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
                    Regional regional = new Regional();
                    regional.setId(ANY_CODE);
                    user.setRegional(regional);
                    user.setId(USER_ID);
                    Unit unit = new Unit();
                    unit.setId(ANY_CODE);
                    user.setUnit(unit);
                    when(userService
                            .findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any()))
                            .thenReturn(user);
                    return (T)userService;
                }
                if(requiredType.equals(IWhitePaperService.class)){
                    IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                    WhitePaper whitePaper = new WhitePaper();
                    whitePaper.setName("Whitepaper 1");
                    whitePaper.setAmount(BigDecimal.valueOf(1000L));
                    return (T) whitePaperService;
                }
                return (T) super.getService(requiredType);
            }

        };

        simulationFaces.verifyUserType();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testVerifyUserTypeWithUnit() {
        SimulationFaces simulationFaces = new SimulationFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    ArrayList<Simulation> simulations = new ArrayList<Simulation>();
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulations.add(simulation);
                    when(simulationService.searchSimulationForExistingSale(SecurityUtil.getLoggedInUser().getCountyCd())).thenReturn(simulations);
                    return (T)simulationService;
                }

                if (requiredType.equals(IUserService.class)) {
                    IUserService userService = mock(IUserService.class);
                    com.monsanto.barter.business.entity.table.User user = new com.monsanto.barter.business.entity.table.User();
                    user.setId(USER_ID);
                    Unit unit = new Unit();
                    unit.setId(ANY_CODE);
                    user.setUnit(unit);
                    when(userService
                            .findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any()))
                            .thenReturn(user);
                    return (T)userService;
                }

                if (requiredType.equals(ICampaignService.class)) {
                    ICampaignService campaignService = mock(ICampaignService.class);
                    ArrayList<Campaign> campaigns = new ArrayList<Campaign>();
                    Campaign campaign = new Campaign();
                    campaign.setId(new Long(1));
                    campaign.setName(ANY_CODE);
                    campaigns.add(campaign);
                    when(campaignService.search(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                    return (T)campaignService;
                }
                if(requiredType.equals(IWhitePaperService.class)){
                    IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                    WhitePaper whitePaper = new WhitePaper();
                    whitePaper.setName("Whitepaper 1");
                    whitePaper.setAmount(BigDecimal.valueOf(1000L));
                    return (T) whitePaperService;
                }
                return (T) super.getService(requiredType);
            }
        };

        simulationFaces.verifyUserType();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testLoadRtvList() {
        SimulationFaces simulationFaces = new SimulationFaces(){
            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    ArrayList<Simulation> simulations = new ArrayList<Simulation>();
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulations.add(simulation);
                    when(simulationService.searchSimulationForExistingSale(SecurityUtil.getLoggedInUser().getCountyCd())).thenReturn(simulations);
                    return (T)simulationService;
                }

                if (requiredType.equals(IUserService.class)) {
                    IUserService userService = mock(IUserService.class);
                    User user = new User();
                    ArrayList<User> users = new ArrayList<User>();
                    user.setId(USER_ID);
                    Unit unit = new Unit();
                    unit.setId(ANY_CODE);
                    user.setUnit(unit);
                    users.add(user);
                    when(userService
                            .findByIdWithPermissionAndHistory(Matchers.<com.monsanto.barter.business.entity.table.User>any()))
                            .thenReturn(user);
                    when(userService
                            .search(Matchers.<UserFilter>any()))
                            .thenReturn(users);
                    return (T)userService;
                }

                if (requiredType.equals(ICampaignService.class)) {
                    ICampaignService campaignService = mock(ICampaignService.class);
                    ArrayList<Campaign> campaigns = new ArrayList<Campaign>();
                    Campaign campaign = new Campaign();
                    campaign.setId(new Long(1));
                    campaign.setName(ANY_CODE);
                    campaigns.add(campaign);
                    campaign.setIncentive(new BigDecimal(10));
                    when(campaignService.search(Matchers.<CampaignFilter>any())).thenReturn(campaigns);
                    return (T)campaignService;
                }

                if(requiredType.equals(IWhitePaperService.class)){
                    IWhitePaperService whitePaperService = mock(IWhitePaperService.class);
                    WhitePaper whitePaper = new WhitePaper();
                    whitePaper.setName("Whitepaper 1");
                    whitePaper.setAmount(BigDecimal.valueOf(1000L));
                    return (T) whitePaperService;
                }

                return (T) super.getService(requiredType);
            }
        };


        List<User> result = simulationFaces.loadRtvList(ANY_CODE);

        assertNull(simulationFaces.getMessages());
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }
    @Test
    public void testLoadRtvListWithNullParameter() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        List<User> result = simulationFaces.loadRtvList(null);

        assertNull(simulationFaces.getMessages());
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLoadCustomerList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<String> result = simulationFaces.loadCustomerList(ANY_CODE);

        assertNull(simulationFaces.getMessages());
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(2, result.size());
    }

    @Test
    public void testLoadCustomerListWithNullParameters() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<String> result = simulationFaces.loadCustomerList(null);

        assertNull(simulationFaces.getMessages());
        assertNotNull(result);
        assertTrue(result.isEmpty());

    }

    @Test
    public void testBtnContinueCampaign() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        ReflectionTestUtils.setField(simulationFaces, "newSale", true);
        String result = simulationFaces.btnContinueCampaign();

        assertNull(simulationFaces.getMessages());
        assertEquals(SUCCESS, result);
    }

    @Test
    public void testLoadPartnerYaList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        simulationFaces.btnContinueCampaign();
        List<PartnerYa> result = simulationFaces.loadPartnerYaList(ANY_CODE);

        assertNull(simulationFaces.getMessages());
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }

    @Test
    public void testBtnSearch() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnSearch();

        assertNotNull(simulationFaces.getMessages());
        assertTrue(simulationFaces.getMessages().isEmpty());
    }

    @Test
    public void testBtnContinueFcpaCustomerNotRelevantToFCPA() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setFcpaCd(FCPAList.CUSTOMER_NOT_RELEVANT_TO_FCPA.getCod());

        String result = simulationFaces.btnContinueFcpa();

        assertNull(simulationFaces.getMessages());
        assertEquals(SUCCESS, result);
    }

    @Test
    public void testBtnContinueFcpaNegotiationNotAccordingToListAndNotApprovedByBCWG() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setFcpaCd(FCPAList.YES_NEGOTIATION_NOT_ACCORDING_TO_LIST_AND_NOT_APPROVED_BY_BCWG.getCod());

        String result = simulationFaces.btnContinueFcpa();

        assertNull(simulationFaces.getMessages());
        assertEquals(SUCCESS, result);
    }

    @Test
    public void testRemoveSimulationItem() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
            @Override
            protected Integer getParameterInteger(String param)
            {
                return 0;
            }
        };
        ArrayList<SimulationItem> items = new ArrayList<SimulationItem>();
        SimulationItem simulationItem = new SimulationItem();
        items.add(simulationItem);
        simulationFaces.getSimulation().setItems(items);

        assertEquals(1, simulationFaces.getSimulation().getItems().size());
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.removeSimulationItem();

        assertEquals(0, simulationFaces.getSimulation().getItems().size());

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testEditSimulationItem() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);

        simulationFaces.setSimulationItem(simulationItem);

        String result =simulationFaces.editSimulationItem();

        assertNull(simulationFaces.getMessages());
        assertEquals(CHANGE, result);
    }

    @Test
    public void testConfirmSelectionCustomer() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.setSelectedCustomer("123-11-123-1132");
        simulationFaces.confirmSelectionCustomer();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testCropValueChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());
        ValueChangeEvent valueChangeEvent= mock(ValueChangeEvent.class);
        when(valueChangeEvent.getPhaseId()).thenReturn(PhaseId.UPDATE_MODEL_VALUES);

        simulationFaces.cropValueChanged(valueChangeEvent);

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testDiffDelivLocationCheckValueChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());
        ValueChangeEvent valueChangeEvent= mock(ValueChangeEvent.class);
        when(valueChangeEvent.getPhaseId()).thenReturn(PhaseId.UPDATE_MODEL_VALUES);

        simulationFaces.diffDelivLocationCheckValueChanged(valueChangeEvent);

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testBarterTypeValueChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());
        ValueChangeEvent valueChangeEvent= mock(ValueChangeEvent.class);
        when(valueChangeEvent.getPhaseId()).thenReturn(PhaseId.UPDATE_MODEL_VALUES);

        simulationFaces.barterTypeValueChanged(valueChangeEvent);

        assertNull(simulationFaces.getMessages());
    }

    /**
     * @throws Exception
     * @see SimulationFaces#currencyValueChanged(ValueChangeEvent)
     */
    @Test
    public void testCurrencyValueChanged() {
        setupMockServices();

        ValueChangeEvent valueChangeEventMock = mock(ValueChangeEvent.class);

        //branch A
        tested.currencyValueChanged(null);

        //branch B
        tested.currencyValueChanged(valueChangeEventMock);

        //Branch C
        when(valueChangeEventMock.getPhaseId()).thenReturn(PhaseId.UPDATE_MODEL_VALUES);
        tested.currencyValueChanged(valueChangeEventMock);

        //Branch D
        when(valueChangeEventMock.getNewValue()).thenReturn("1");
        tested.currencyValueChanged(valueChangeEventMock);

        //Branch E
        Simulation simulationMock = tested.getSimulation();
        when(simulationMock.getQuotation()).thenReturn(new Quotation(new QuotationId()));
        when(simulationMock.getQuotationFlg()).thenReturn(QuoteTypeList.QUOTE.getCod());
        tested.currencyValueChanged(valueChangeEventMock);

        assertNull(tested.getMessages());
    }

    /**
     * @throws Exception
     */
    @Test
    public void testRbQuotationChanged() throws Exception {

        setupMockServices();

        Currency currency = new Currency(new CurrencyId());
        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));

        Simulation simulationMock = tested.getSimulation();

        when(simulationMock.getCity()).thenReturn(new City(new CityId()));


        //branch A
        when(simulationMock.getQuotationFlg()).thenReturn(null);
        tested.rbQuotationChanged();
        assertNull(tested.getMessages());

        //branch B
        when(simulationMock.getQuotationFlg()).thenReturn('x');
        tested.rbQuotationChanged();
        assertNotNull(tested.getMessages());

        //branch C
        when(simulationMock.getQuotationFlg()).thenReturn(QuoteTypeList.MANUAL_PRICE.getCod());
        when(simulationMock.getQuotation()).thenReturn(new Quotation(new QuotationId()));
        tested.rbQuotationChanged();
        assertNotNull(tested.getMessages());

        //branch D
        when(simulationMock.getCurrency()).thenReturn(currency);
        when(simulationMock.getCampaign()).thenReturn(campaign );
        when(simulationMock.getQuotationFlg()).thenReturn(QuoteTypeList.QUOTE.getCod());
        tested.rbQuotationChanged();
        assertNotNull(tested.getMessages());
    }


    @Test
    public void testCboRegionChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));

        simulationFaces.cboRegionChanged();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testCboMotiveChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));

        simulationFaces.cboMotiveChanged();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testCldPaymentDateChanged() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());
        ValueChangeEvent valueChangeEvent= mock(ValueChangeEvent.class);
        when(valueChangeEvent.getPhaseId()).thenReturn(PhaseId.UPDATE_MODEL_VALUES);

        simulationFaces.cldPaymentDateChanged(valueChangeEvent);

        assertNull(simulationFaces.getMessages());
    }

    /**
     */
    @Test
    public void testBtnIncludeItem() {
        setupMockServices();

        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setDivision(new Division(new DivisionId()));
        Simulation simulationMock = tested.getSimulation();

        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        when(simulationServiceMock.validateRequiredSimulationFieldsForItemsFilled(any(Simulation.class))).thenReturn(true);
        when(simulationMock.getItems()).thenReturn(Arrays.asList(new SimulationItem[]{simulationItem }));


        tested.btnIncludeItem();

        assertNull(tested.getMessages());
    }

    @Test
    public void testBtnCancelIncludeItem() {

        setupMockServices();

        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());

        simulationFaces.btnCancelIncludeItem();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testBtnConfirmIncludeItem() {

        setupMockServices();

        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());

        simulationFaces.btnConfirmIncludeItem();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testSelectQuotation() throws Exception {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCity(new City(new CityId()));
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setProduct(new Product());
        simulationItem.getProduct().setMaterialNbr(ANY_CODE);
        simulationFaces.setSimulationItem(simulationItem);
        simulationFaces.getSimulation().setItems(new ArrayList<SimulationItem>());
        QuotationBusiness quotationBusiness = new QuotationBusiness();
        quotationBusiness.setTradingCd(ANY_CODE);
        simulationFaces.setQuotationBusiness(quotationBusiness);
        simulationFaces.getSimulation().setQuotation(new Quotation(new QuotationId()));

        String result = simulationFaces.selectQuotation();

        assertNull(simulationFaces.getMessages());
        assertEquals(NOT_NAVIGATE, result);
    }

    /**
     */
    @Test
    public void testCalculateSackNetPrice() {
        setupMockServices();

        Simulation simulationMock = Whitebox.<Simulation>getInternalState(tested, "simulation");

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.ARROBA);
        when(simulationMock.getQuantityKg()).thenReturn(new BigDecimal(0));
        tested.calculateSackNetPrice();
        assertNull(tested.getMessages());

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.SACK);
        when(simulationMock.getSackGrossPrice()).thenReturn(new BigDecimal(0));
        when(simulationMock.getSackNetPrice()).thenReturn(null);
        tested.calculateSackNetPrice();
        assertNotNull(tested.getMessages());

        when(simulationMock.getIncentivePct()).thenReturn(new BigDecimal(1));
        tested.calculateSackNetPrice();

    }

    /**
     */
    @Test
    public void testCalculateSackNetPriceFromNetPrice() {
        setupMockServices();

        Simulation simulationMock = Whitebox.<Simulation>getInternalState(tested, "simulation");

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.ARROBA);
        when(simulationMock.getQuantityKg()).thenReturn(new BigDecimal(0));
        tested.calculateSackNetPriceFromNetPrice();
        assertNull(tested.getMessages());

        when(simulationMock.getIncentivePct()).thenReturn(new BigDecimal(1));
        tested.calculateSackNetPriceFromNetPrice();

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.SACK);
        when(simulationMock.getSackGrossPrice()).thenReturn(new BigDecimal(0));
        when(simulationMock.getSackNetPrice()).thenReturn(null);
        tested.calculateSackNetPriceFromNetPrice();
        assertNotNull(tested.getMessages());


    }

    /**
     */
    @Test
    public void testVolumeKGChanged() {
        setupMockServices();

        Simulation simulationMock = Whitebox.<Simulation>getInternalState(tested, "simulation");

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.ARROBA);
        when(simulationMock.getQuantityKg()).thenReturn(new BigDecimal(0));
        tested.volumeKGChanged();
        assertNull(tested.getMessages());

        when(simulationMock.getIncentivePct()).thenReturn(new BigDecimal(1));
        tested.volumeKGChanged();

        Whitebox.setInternalState(tested, "unitMeasurement", UnitMeasurementList.SACK);
        when(simulationMock.getSackGrossPrice()).thenReturn(new BigDecimal(0));
        when(simulationMock.getSackNetPrice()).thenReturn(null);
        tested.volumeKGChanged();
        assertNotNull(tested.getMessages());
    }

    @Test
    public void testCommoditySelected() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.getSimulation().setCommodityId("1");
        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        campaign.getCountry().getId().setCountryCd(COUNTRY_CD);
        simulationFaces.getSimulation().setCampaign(campaign);

        simulationFaces.commoditySelected();

        assertNull(simulationFaces.getMessages());
    }
    @Test
    public void testCommoditySelectedWithoutCommodityId() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        simulationFaces.commoditySelected();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testLoadSimulationNumbers() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.loadSimulationNumbers();

        assertNull(simulationFaces.getMessages());
        assertNotNull(simulationFaces.getItemsSimulation());
        assertFalse(simulationFaces.getItemsSimulation().isEmpty());
    }

    @Test
    public void testBtnCancel() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };
        simulationFaces.btnCancel();

        assertNull(simulationFaces.getMessages());
    }

    /**
     * @throws Exception
     * @see SimulationFaces#btnSave()
     */
    @Test
    public void testBtnSave() throws Exception {
        setupMockServices();

        Simulation simulationMock = tested.getSimulation();
        prepareSimulationMockForNotNewSale(simulationMock);

        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        Whitebox.setInternalState(tested, "newSale", true);
        tested.btnSave();

        assertEquals("", tested.getMessages());

        Whitebox.setInternalState(tested, "reopen", true);
        tested.btnSave();

        assertEquals("", tested.getMessages());

        Whitebox.setInternalState(tested, "newer", true);
        tested.btnSave();

        assertEquals("", tested.getMessages());

        Whitebox.setInternalState(tested, "newer", true);
        Whitebox.setInternalState(tested, "reopen", true);
        tested.btnSave();

        assertEquals("", tested.getMessages());

        Whitebox.setInternalState(tested, "newer", true);
        Whitebox.setInternalState(tested, "newSale", true);
        tested.btnSave();

        assertEquals("", tested.getMessages());

        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.NO.getFlag());
        when(simulationMock.getReopenFlg()).thenReturn(YesNoList.YES.getFlag());
        tested.btnSave();

        assertEquals("", tested.getMessages());

        when(simulationServiceMock.getMessages()).
                thenReturn(Arrays.asList(new MessageVO[]{new MessageVO(IBarterConstants.MSG_CONCURRENCE_ERROR)}));
        tested.btnSave();

        assertFalse(tested.getMessages().isEmpty());
    }

    /**
     * @see SimulationFaces#btnSendApproval()
     */
    @Test
    public void testBtnSendApproval() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        simulationFaces.btnSendApproval();

        assertNotNull(simulationFaces.getMessages());
        assertEquals("", simulationFaces.getMessages());

        setupMockServices();

        //mock conditions
        Whitebox.setInternalState(tested, "reopen", true);
        Whitebox.setInternalState(tested, "newer", true);
        //invoke
        String result = tested.btnSendApproval();
        assertEquals("notNavigate", result);

        //mock conditions
        Whitebox.setInternalState(tested, "reopen", false);
        Whitebox.setInternalState(tested, "newSale", true);
        //invoke
        result = tested.btnSendApproval();
        assertEquals("notNavigate", result);

        //mock conditions
        Whitebox.setInternalState(tested, "reopen", false);
        Whitebox.setInternalState(tested, "newer", true);
        Whitebox.setInternalState(tested, "newSale", false);
        //invoke
        result = tested.btnSendApproval();
        assertEquals("notNavigate", result);
    }
    @Test
    public void testBtnOpenPrintPopup() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        ReflectionTestUtils.setField(simulationFaces,"newSale",true);

        simulationFaces.btnOpenPrintPopup();

        assertNull(simulationFaces.getMessages());

    }
    @Test
    public void testBtnCloseSignaturePopup() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(String param) {
                if(param.equals("isNewSale"))
                    return true;
                return super.getParameterBoolean(param);
            }
        };

        simulationFaces.btnCloseSignaturePopup();

        assertNotNull(simulationFaces.getMessages());
        assertEquals("", simulationFaces.getMessages());
    }
    @Test
    public void testBtnClosePrintPopup() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnClosePrintPopup();

        assertNull(simulationFaces.getMessages());
    }

    @Test
    public void testBtnEdit() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationBusiness simulationSelected = new SimulationBusiness();
        simulationSelected.setSimulationNumber(ANY_CODE);

        simulationFaces.setSimulationSelected(simulationSelected);

        simulationFaces.btnEdit();

        assertNotNull(simulationFaces.getMessages());
        assertEquals("", simulationFaces.getMessages());
    }

    @Test
    public void testBtnCancelSimulation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnCancelSimulation();

        assertNull(simulationFaces.getMessages());
    }
    @Test
    public void testBtnDelete() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationBusiness simulationSelected = new SimulationBusiness();
        simulationSelected.setSimulationNumber(ANY_CODE);
        simulationFaces.setSimulationSelected(simulationSelected);

        simulationFaces.btnDelete();

        assertNotNull(simulationFaces.getMessages());
    }

    /**
     * @see SimulationFaces#btnDetail()
     */
    @Test
    public void testBtnDetail() {
        setupMockServices();

        Simulation simulationMock = tested.getSimulation();
        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        when(simulationServiceMock.isOk()).thenReturn(true);
        when(simulationServiceMock.findByIdComplete(any(Simulation.class))).thenReturn(simulationMock);

        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.YES.getFlag());
        when(simulationMock.getReopenFlg()).thenReturn(YesNoList.YES.getFlag());
        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.GRAIN_AVAILABLE.getCod());
        Whitebox.setInternalState(tested, "newSale", true);
        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.CLOSED.getCod());
        tested.btnDetail();

        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.NO.getFlag());
        when(simulationMock.getReopenFlg()).thenReturn(YesNoList.NO.getFlag());
        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.DRAFT.getCod());
        Whitebox.setInternalState(tested, "newSale", false);
        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.DRAFT.getCod());
        tested.btnDetail();

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.TERMS.getCod());
        tested.btnDetail();

        Whitebox.setInternalState(tested, "newSale", false);
        tested.btnDetail();

        assertNotNull(tested.getMessages());
    }
    @Test
    public void testBtnPrintTerms() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationBusiness simulationSelected = new SimulationBusiness();
        simulationSelected.setSimulationNumber(ANY_CODE);
        simulationFaces.setSimulationSelected(simulationSelected);

        simulationFaces.btnPrintTerms();

        assertNotNull(simulationFaces.getMessages());
    }

    @Test
    public void testBtnCancelGenerateTermsFormalization() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnCancelGenerateTermsFormalization();

        assertFalse(simulationFaces.isRenderedPanelTermsFormalization());
    }
    @Test
    public void testBtnConfirmGenerateTermsFormalization() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnConfirmGenerateTermsFormalization(new ActionEvent(new HtmlCommandButton() ));

        assertNotNull(simulationFaces.getFormalizationTermBusiness());
    }

    @Test
    @Ignore
    public void testBtnGoBackWithoutFrom() {

        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Whitebox.setInternalState(simulationFaces, "barterContracts", new ListDataModel<BarterContract>());
        Whitebox.setInternalState(simulationFaces, "simulationList", new ArrayList<SimulationBusiness>());


        String result = simulationFaces.btnGoBack();

        assertEquals("back", result);
    }
    @Test
    @Ignore
    public void testBtnGoBackWithFrom() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(final String param) {
                if(param.equals("isFromContract"))
                {
                    return true;
                }
                return super.getParameterBoolean(param);
            }
        };

        Whitebox.setInternalState(simulationFaces, "barterContracts", new ListDataModel<BarterContract>());
        Whitebox.setInternalState(simulationFaces, "simulationList", new ArrayList<SimulationBusiness>());

        String result = simulationFaces.btnGoBack();

        assertEquals("back", result);
    }

    @Test
    @Ignore
    public void testBtnHiddenTermFormalization() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.btnHiddenTermFormalization();

        assertFalse(simulationFaces.isRenderedPanelTermsFormalization());
        assertTrue(simulationFaces.isRenderPanelSignature());
    }

    @Test
    public void testVisualizeSimulation() throws Exception {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(final String param) {
                if(param.equals("isNewSale"))
                {
                    return true;
                }
                return super.getParameterBoolean(param);
            }

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulation.setCampaign(new Campaign());
                    simulation.getCampaign().setCountry(new Country(new CountryId()));
                    simulation.getCampaign().getCountry().getId().setCountryCd(COUNTRY_CD);
                    when(simulationService.findByIdComplete(Matchers.<Simulation>any())).thenReturn(simulation);
                    return (T)simulationService;
                }
                return super.getService(requiredType);
            }

            @Override
            public com.monsanto.barter.architecture.regionalization.Country getCountry() {
                return com.monsanto.barter.architecture.regionalization.Country.BRAZIL;
            }
        };
        SimulationBusiness simulation = new SimulationBusiness();
        simulation.setSimulationNumber("123456");
        simulationFaces.setSimulationSelected(simulation);
        simulationFaces.visualizeSimulation();

        assertTrue(simulationFaces.isNewSale());

    }

    /**
     * @throws Exception
     * @see SimulationFaces#searchInvoices()
     */
    @Test()
    public void testSearchInvoices() throws Exception {
        setupMockServices();

        InvoiceSimulation invoiceSimulation = new InvoiceSimulation();
        invoiceSimulation.setAmountLocalCurrency(new BigDecimal(0));
        invoiceSimulation.setConvertedValue(new BigDecimal(0));
        InvoiceSimulationBusiness invoiceSimulationBusiness = new InvoiceSimulationBusiness();

        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        tested.searchInvoices();
        assertNotNull(tested.getMessages());
        assertEquals("", tested.getMessages());

        when(simulationServiceMock.isOk()).thenReturn(true);
        tested.searchInvoices();
        assertNotNull(tested.getMessages());
        assertEquals("", tested.getMessages());

        when(simulationServiceMock.isOk()).thenReturn(true);
        when(simulationServiceMock.searchInvoices(any(Simulation.class))).thenReturn(invoiceSimulationBusiness);
        tested.searchInvoices();
        assertNotNull(tested.getMessages());
        assertEquals("", tested.getMessages());

        invoiceSimulationBusiness.setInvoices(Arrays.asList(new InvoiceSimulation[]{invoiceSimulation}));
        tested.searchInvoices();
        assertNotNull(tested.getMessages());
        assertEquals("", tested.getMessages());

    }

    @Test
    public void testBtnContinueInvoiceWithSimulation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(final String param) {
                if(param.equals("isNewSale"))
                {
                    return true;
                }
                return super.getParameterBoolean(param);
            }

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulation.setCampaign(new Campaign());
                    simulation.getCampaign().setCountry(new Country(new CountryId()));
                    simulation.getCampaign().getCountry().getId().setCountryCd(COUNTRY_CD);
                    when(simulationService.findByIdComplete(Matchers.<Simulation>any())).thenReturn(simulation);
                    when(simulationService.isOk()).thenReturn(true);
                    return (T)simulationService;
                }
                return super.getService(requiredType);
            }
        };

        String result = simulationFaces.btnContinueInvoice();

        assertEquals(SUCCESS, result);
    }
    @Test
    public void testBtnContinueInvoiceWithoutSimulation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        String result = simulationFaces.btnContinueInvoice();

        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testReturnDisapproveSimulationWithoutSimulation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        String result = simulationFaces.btnContinueInvoice();

        assertEquals(NOT_NAVIGATE, result);
    }

    /**
     * @throws Exception
     * @see SimulationFaces#returnDisapproveSimulation()
     */
    @Test
    public void testReturnDisapproveSimulationWithSimulation() throws Exception {
        setupMockServices();

        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        when(simulationServiceMock.isOk()).thenReturn(false);
        tested.returnDisapproveSimulation();

        when(simulationServiceMock.isOk()).thenReturn(true,false);
        Simulation simulationMock = tested.getSimulation();
        prepareSimulationMockForNotNewSale(simulationMock);
        tested.returnDisapproveSimulation();

//        assertEquals(CANCEL, result);
    }

    /**
     * @throws Exception
     * @see SimulationFaces#btnApprove()
     */
    @Test
    public void testBtnApproveWithError() throws Exception{
        setupMockServices();

        Simulation simulationMock = tested.getSimulation();
        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);

        when(simulationServiceMock.isOk()).thenReturn(false);
        MessageVO message = new MessageVO(IBarterConstants.MSG_CONCURRENCE_ERROR, MessageTypeList.INFO);
        when(simulationServiceMock.getMessages()).thenReturn(Arrays.asList(new MessageVO[]{message }));

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.TERMS.getCod());
        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.YES.getFlag());
        when(simulationMock.getReopenFlg()).thenReturn(YesNoList.YES.getFlag());
        prepareSimulationMockForNotNewSale(simulationMock);
        Whitebox.setInternalState(tested, "newSale", false);

        String result = tested.btnApprove();

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.GRAIN_AVAILABLE.getCod());
        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.NO.getFlag());
        when(simulationMock.getReopenFlg()).thenReturn(YesNoList.NO.getFlag());
        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.DRAFT.getCod());
        Whitebox.setInternalState(tested, "newSale", true);
        result = tested.btnApprove();

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.CLOSED.getCod());
        result = tested.btnApprove();

        Whitebox.setInternalState(tested, "newSale", false);
        result = tested.btnApprove();

        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testBtnApproveWithoutError() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(final String param) {
                if(param.equals("isNewSale"))
                {
                    return true;
                }
                return super.getParameterBoolean(param);
            }

            @Override
            public <T> T getService(Class<T> requiredType) {

                if (requiredType.equals(ISimulationService.class)) {
                    ISimulationService simulationService = mock(ISimulationService.class);
                    Simulation simulation = new Simulation();
                    simulation.setSimulationNumber("123456");
                    simulation.setPaymentCondition(PaymentConditionList.BARTER_B.getCod());
                    simulation.setCampaign(new Campaign());
                    simulation.getCampaign().setCountry(new Country(new CountryId()));
                    simulation.getCampaign().getCountry().getId().setCountryCd(COUNTRY_CD);
                    when(simulationService.findByIdComplete(Matchers.<Simulation>any())).thenReturn(simulation);
                    when(simulationService.isOk()).thenReturn(true);
                    return (T)simulationService;
                }
                return super.getService(requiredType);
            }
        };

        String result = simulationFaces.btnApprove();

        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testBtnVerifySaleOrder() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest(){
            @Override
            protected Boolean getParameterBoolean(final String param) {
                if(param.equals("isNewSale"))
                {
                    return true;
                }
                return super.getParameterBoolean(param);
            }
        };

        String result = simulationFaces.btnVerifySaleOrder();

        assertEquals(NOT_NAVIGATE, result);
    }

    @Test
    public void testGetListSize() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Integer result = simulationFaces.getListSize();

        assertEquals(new Integer(0), result);
    }
    @Test
    public void testGetItemListSize() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Integer result = simulationFaces.getItemListSize();

        assertEquals(new Integer(0), result);
    }
    @Test
    public void testGetHistoryListSize() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Integer result = simulationFaces.getHistoryListSize();

        assertEquals(new Integer(0), result);
    }
    @Test
    public void testIsCanAccessSimulationNew() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isCanAccessSimulationNew();

        assertFalse(result);
    }
    @Test
    public void testIsCommodity() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isCommodity();

        assertFalse(result);
    }
    @Test
    public void testIsReopen() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isReopen();

        assertFalse(result);
    }
    @Test
    public void testIsNewSale() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isNewSale();

        assertFalse(result);
    }
    @Test
    public void testIsRenderDiffDelivLocationCheckBox() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderDiffDelivLocationCheckBox();

        assertFalse(result);
    }
    @Test
    public void testIsQuoteFieldsDisabled() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isQuoteFieldsDisabled();

        assertFalse(result);
    }
    @Test
    public void testIsRenderIncentive() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderIncentive();

        assertFalse(result);
    }
    @Test
    public void testIsRenderContractFields() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderContractFields();

        assertTrue(result);
    }
    @Test
    public void testIsRenderRtv() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderRtv();

        assertFalse(result);
    }
    @Test
    public void testIsFromContract() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isFromContract();

        assertTrue(result);
    }
    @Test
    public void testIsRenderUsdRate() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderUsdRate();

        assertFalse(result);
    }
    @Test
    public void testIsSetRenderDiffDelivLocationField() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        simulationFaces.setRenderDiffDelivLocationField(false);
        boolean result = simulationFaces.isRenderDiffDelivLocationField();

        assertFalse(result);
    }
    @Test
    public void testIsDivisionChemicals() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isDivisionChemicals();

        assertFalse(result);
    }
    @Test
    public void testIsRenderedPanelTermsFormalization() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderedPanelTermsFormalization();

        assertFalse(result);
    }
    @Test
    public void testIsRenderPanelSignature() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderPanelSignature();

        assertFalse(result);
    }
    @Test
    public void testIsRenderPopupFormalizationPrint() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderPopupFormalizationPrint();

        assertFalse(result);
    }
    @Test
    public void testIsRenderedPanelQuotation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderedPanelQuotation();

        assertFalse(result);
    }
    @Test
    public void testIsRenderedPanelItem() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderedPanelItem();

        assertFalse(result);
    }
    @Test
    public void testIsRenderPrintButton() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderPrintButton();

        assertFalse(result);
    }
    @Test
    public void testIsRenderedTxtMotive() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result = simulationFaces.isRenderedTxtMotive();

        assertFalse(result);
    }

    @Test
    public void testGetMktCampaignDesc() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        String result = simulationFaces.getMktCampaignDesc();

        assertNull(result);
    }
    @Test
    public void testGetTradingDesc() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        String result = simulationFaces.getTradingDesc();

        assertNull(result);
    }
    @Test
    public void testGetCommodityDesc() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        String result = simulationFaces.getCommodityDesc();

        assertNull(result);
    }

    @Test
    public void testGetCodeOthersDisapprovalReason() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Integer result = simulationFaces.getCodeOthersDisapprovalReason();

        assertNotNull(result);
        assertEquals(DisapprovalReasonList.OTHERS.getCode(), result);
    }
    @Test
    public void testGetCodeOthersReturnReason() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        Integer result = simulationFaces.getCodeOthersReturnReason();

        assertNotNull(result);
        assertEquals(ReturnReasonList.OTHERS.getCode(), result);
    }

    @Test
    public void testQuotationBusiness() {

        setupMockServices();

        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        QuotationBusiness quotationBusiness = new QuotationBusiness();
        quotationBusiness.setCityCd(ANY_CODE);
        simulationFaces.setQuotationBusiness(quotationBusiness);

        QuotationBusiness result = simulationFaces.getQuotationBusiness();

        assertEquals(ANY_CODE, result.getCityCd());
    }
    @Test
    public void testGetSetSimulationItem() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setFinalPrice(new BigDecimal(10));
        simulationFaces.setSimulationItem(simulationItem);

        SimulationItem result = simulationFaces.getSimulationItem();

        assertEquals(new BigDecimal(10), result.getFinalPrice());

    }

    @Test
    public void testGetSetFilter() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationFilter filter = new SimulationFilter();
        filter.setCustomerName(ANY_CODE);
        simulationFaces.setFilter(filter);

        SimulationFilter result = simulationFaces.getFilter();

        assertEquals(ANY_CODE, result.getCustomerName());
    }

    @Test
    public void testGetCampaignList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getCampaignList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    @Test
    public void testGetRegionList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getRegionList();

        assertNull(result);
    }
    @Test
    public void testGetCityList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getCityList();

        assertNull(result);
    }
    @Test
    public void testGetStatusList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getStatusList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    @Test
    public void testGetDisapprovalReasonList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getDisapprovalReasonList();

        assertNull(result);
    }
    @Test
    public void testGetReturnReasonList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getReturnReasonList();

        assertNull(result);
    }
    @Test
    public void testIsRenderApproveButton() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isRenderApproveButton();

        assertFalse(result);
    }
    @Test
    public void testIsRenderReturnButton() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isRenderReturnButton();

        assertFalse(result);
    }
    @Test
    public void testIsRenderDisapproveButton() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isRenderDisapproveButton();

        assertFalse(result);
    }
    @Test
    public void testIsRenderVerifySaleOrderButton() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isRenderVerifySaleOrderButton();

        assertFalse(result);
    }
    @Test
    public void testIsBarterTypeTerms() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isBarterTypeTerms();

        assertFalse(result);
    }

    @Test
    public void testIsBarterTypeMonsantoManagesContract() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isBarterTypeMonsantoManagesContract();

        assertFalse(result);
    }
    @Test
    public void testIsBarterTypeWithExistingContract() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isBarterTypeWithExistingContract();

        assertFalse(result);
    }
    @Test
    public void testIsBarterTypeGrainAvailable() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        boolean result= simulationFaces.isBarterTypeGrainAvailable();

        assertFalse(result);
    }
    @Test
    public void testGetQuoteTypeList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getQuoteTypeList();

        assertNull(result);
    }
    @Test
    public void testGetFcpaList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getFcpaList();

        assertNull(result);
    }
    @Test
    public void testGetBarterTypeList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result=simulationFaces.getBarterTypeList();

        assertNull(result);
    }
    @Test
    public void testGetCropList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result=simulationFaces.getCropList();

        assertNull(result);
    }
    @Test
    public void testGetTradingList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result=simulationFaces.getTradingList();

        assertNull(result);
    }
    @Test
    public void testGetCurrencyList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result=simulationFaces.getCurrencyList();

        assertNull(result);
    }
    @Test
    public void testGetPaymentConditionList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result=simulationFaces.getPaymentConditionList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    @Test
    public void testGetMktCampaignList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getMktCampaignList();

        assertNull(result);
    }
    @Test
    public void testGetCommodityList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getCommodityList();

        assertNull(result);
    }
    @Test
    public void testGetIncotermsList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getIncotermsList();

        assertNull(result);
    }
    @Test
    public void testGetItemsSimulation() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        List<SelectItem> result= simulationFaces.getItemsSimulation();

        assertNull(result);
    }
    @Test
    public void testGetSimulationList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        ArrayList<SimulationBusiness> simulationList = new ArrayList<SimulationBusiness>();
        simulationList.add(new SimulationBusiness());
        simulationFaces.setSimulationList(simulationList);

        List<SimulationBusiness> result= simulationFaces.getSimulationList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }
    @Test
    public void testGetSetInvoiceList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        ArrayList<InvoiceSimulation> invoiceSimulations = new ArrayList<InvoiceSimulation>();
        invoiceSimulations.add(new InvoiceSimulation());
        simulationFaces.setInvoiceList(invoiceSimulations);

        List<InvoiceSimulation> result= simulationFaces.getInvoiceList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }

    @Test
    public void testGetSetSelectedCustomer() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        simulationFaces.setSelectedCustomer(ANY_CODE);

        assertEquals(ANY_CODE, simulationFaces.getSelectedCustomer());
    }
    @Test
    public void testGetSetFormalizationTermBusiness() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        FormalizationTermBusiness formalizationTermBusiness = new FormalizationTermBusiness();
        formalizationTermBusiness.setEmail(ANY_CODE);
        simulationFaces.setFormalizationTermBusiness(formalizationTermBusiness);

        assertEquals(ANY_CODE, simulationFaces.getFormalizationTermBusiness().getEmail());
    }

    @Test
    public void testGetSetSimulationList() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        ArrayList<SimulationBusiness> simulationList = new ArrayList<SimulationBusiness>();
        simulationList.add(new SimulationBusiness());
        simulationFaces.setSimulationList(simulationList);

        List<SimulationBusiness> result= simulationFaces.getSimulationList();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    @Test
    public void testGetSimulationSelected() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();
        SimulationBusiness simulationSelected = new SimulationBusiness();
        simulationSelected.setCustomerName(ANY_CODE);
        simulationFaces.setSimulationSelected(simulationSelected);

        SimulationBusiness result= simulationFaces.getSimulationSelected();

        assertNotNull(result);
        assertEquals(ANY_CODE, result.getCustomerName());
    }

    @Test
    public void testGetUsdRate() {
        SimulationFacesForTest simulationFaces = new SimulationFacesForTest();

        BigDecimal result = simulationFaces.getUsdRate();

        assertNull(result);
    }

    /**
     * @see com.monsanto.barter.web.faces.simulation.SimulationFaces#btnReopen()
     */
    @Test
    public void testBtnReopen() throws Exception {
        setupMockServices();

        ISimulationService simulationServiceMock = getServiceMock(ISimulationService.class);
        when(simulationServiceMock.isOk()).thenReturn(true);
//		when(simulationServiceMock.canReopen(any(Simulation.class))).thenReturn(true);

        String result = tested.btnReopen();
        assertNotNull(result);

    }

    /**
     * @see SimulationFaces#isEditable()
     */
    @Test
    public void testPrivateMethod_isEditable() throws Exception {
        setupMockServices();

        Simulation simulationMock = tested.getSimulation();

        Boolean result = Whitebox.<Boolean> invokeMethod(tested, "isEditable");
        assertFalse(result);

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.DRAFT.getCod());
        result = Whitebox.<Boolean> invokeMethod(tested, "isEditable");
        assertTrue(result);

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.REOPENED.getCod());
        result = Whitebox.<Boolean> invokeMethod(tested, "isEditable");
        assertTrue(result);

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.RETURNED.getCod());
        result = Whitebox.<Boolean> invokeMethod(tested, "isEditable");
        assertTrue(result);

    }

    /**
     * @see SimulationFaces#clearSimulationItemsList()
     */
    @Test
    public void testPrivateMethod_clearSimulationItemsList() throws Exception {
        setupMockServices();

        ArrayList<SimulationItem> simulationItems = new ArrayList<SimulationItem>();
        SimulationItem simulationItem = new SimulationItem();
        simulationItem.setId(1l);
        simulationItems.add(simulationItem);
        simulationItems.add(new SimulationItem());

        Whitebox.setInternalState(tested, "deletedItems", new ArrayList<SimulationItem>());
        Simulation simulationMock = tested.getSimulation();

        when(simulationMock.getItems()).thenReturn(simulationItems);

        //BRANCH A
        Whitebox.invokeMethod(tested, "clearSimulationItemsList");
        assertTrue(simulationMock.getItems().isEmpty());

        //BRANCH B
        Whitebox.setInternalState(tested, "newer", true);
        Whitebox.invokeMethod(tested, "clearSimulationItemsList");
        assertTrue(simulationMock.getItems().isEmpty());
    }

    /**
     * @see SimulationFaces#loadPaymentConditionList()
     */
    @Test
    public void testPrivateMethod_loadPaymentConditionList() throws Exception {
        setupMockServices();

        Simulation simulationMock = tested.getSimulation();

        when(simulationMock.getBarterType()).thenReturn(null);
        List<SelectItem>  result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.GRAIN_AVAILABLE.getCod());
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.FUTURE_WITH_EXISTING_CONTRACT.getCod());
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);

        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod());
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);


        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.TERMS.getCod());
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);


        when(simulationMock.getBarterType()).thenReturn('_');
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadPaymentConditionList");
        assertNotNull(result);

    }

    /**
     * @see SimulationFaces#loadTradingList()
     */
    @Test
    public void testPrivateMethod_loadTradingList() throws Exception {

        SimulationFacesForTest tested = new SimulationFacesForTest();

        //mocking
        Simulation simulationMock = mock(Simulation.class);
        Whitebox.setInternalState(tested, simulationMock);
        Campaign campaignMock = mock(Campaign.class);
        when(simulationMock.getCampaign()).thenReturn(campaignMock);
        when(campaignMock.getId()).thenReturn(1l);
        Country countryMock = mock(Country.class);
        when(campaignMock.getCountry()).thenReturn(countryMock);
        CountryId countryIdMock = mock(CountryId.class);
        when(countryMock.getId()).thenReturn(countryIdMock);
        when(countryIdMock.getCountryCd()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.PARAGUAY.getCountrySAPCd());
        //invoke test
        List<SelectItem> result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadTradingList");
        assertNotNull(result);
        assertTrue(!result.isEmpty());

        //mocking
        when(simulationMock.getBarterType()).thenReturn('1');
        ITradingService tradingServiceMock = mock(ITradingService.class);
        List<Trading> tradingList = new ArrayList<Trading>();
        Trading trading = mock(Trading.class);
        TradingId tradingId = mock(TradingId.class);
        when(tradingId.getTradingCd()).thenReturn("");
        when(trading.getId()).thenReturn(tradingId );
        tradingList.add(trading);
        when(tradingServiceMock.search(any(TradingFilter.class))).thenReturn(tradingList);
        //invoke test
        Whitebox.setInternalState(tested, simulationMock);
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadTradingList");
        assertNotNull(result);
        assertTrue(!result.isEmpty());

        //mocking
        when(simulationMock.getBarterType()).thenReturn('3');
        Incoterms incotermsMock = mock(Incoterms.class);
        IncotermsId incotermsIdMock = mock(IncotermsId.class);
        when(incotermsMock.getId()).thenReturn(incotermsIdMock);
        when(simulationMock.getIncoterms()).thenReturn(incotermsMock );
        //invoke test
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadTradingList");
        assertNotNull(result);
        assertTrue(!result.isEmpty());

        //mocking
        when(simulationMock.getBarterType()).thenReturn(null);
        ICampaignTradingService campaignTradingServiceMock = mock(ICampaignTradingService.class);
        List<CampaignTrading> campaignTradingsList = new ArrayList<CampaignTrading>();
        when(campaignTradingServiceMock.search(any(CampaignTradingFilter.class))).thenReturn(campaignTradingsList );
        //invoke test
        result = Whitebox.<List<SelectItem>> invokeMethod(tested, "loadTradingList");
        assertNotNull(result);
        assertTrue(!result.isEmpty());

    }

    /**
     * @throws Exception
     * @see SimulationFaces#loadCityList()
     */
    @Test
    public void testPrivateMethod_loadCityList() throws Exception {
        setupMockServices();

        CityId cityId = new CityId();

        Simulation simulationMock = tested.getSimulation();
        ICityService cityServiceMock = getServiceMock(ICityService.class);

        when(simulationMock.getCity()).thenReturn(new City(cityId));
        Whitebox.invokeMethod(tested, "loadCityList");

        cityId.setRegionCd("1");
        when(cityServiceMock.search(any(CityFilter.class))).thenReturn(Arrays.asList(new City[]{new City(cityId)}));
        Whitebox.invokeMethod(tested, "loadCityList");
    }

    /**
     * @throws Exception
     * @see SimulationFaces#verifyValidateSimulationPermissions()
     */
    @Test
    public void testPrivateMethod_verifyValidateSimulationPermissions() throws Exception{
        setupMockServices();

        com.monsanto.barter.architecture.security.data.User user = new com.monsanto.barter.architecture.security.data.User(USER_ID);
        Permission permission = new Permission();
        user.setPermissions(Arrays.asList(new Permission[]{permission}));
        tested.setUser(user);

        Simulation simulationMock = tested.getSimulation();


        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.PENDING_APPROVAL.getCod());
        permission.setId(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        when(simulationMock.getCreateUser()).thenReturn(new User("1"));
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

        permission.setId(PermissionList.RETURN_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.WAITING_APPROVAL.getCod());
        permission.setId(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        when(simulationMock.getCreateUser()).thenReturn(new User(USER_ID));
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

        permission.setId(PermissionList.DISAPPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

        when(simulationMock.getStatusCd()).thenReturn(SimulationStatusList.WAITING_SO.getCod());
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

        permission.setId(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
        Whitebox.invokeMethod(tested, "verifyValidateSimulationPermissions");

    }

    /**
     * @throws Exception
     * @see SimulationFaces#fillInitialSimulationValues()
     */
    @Test
    public void testPrivateMethod_fillInitialSimulationValues() throws Exception{
        setupMockServices();

        CityId cityId = new CityId();
        CurrencyId currencyId = new CurrencyId();
        IncotermsId incotermsId = new IncotermsId();
        SimulationItem simulationItem = new SimulationItem();
        Campaign campaign = new Campaign();
        MktCampaign mktCampaign = new MktCampaign();
        MktCampaignId mktCampaignId = new MktCampaignId();
        cityId.setLanguageCd('1');
        currencyId.setLanguageCd('1');
        incotermsId.setLanguageCd('1');
        simulationItem.setDivision(new Division(new DivisionId(IBarterConstants.DIVISION_CHEMICALS, '1')));
        simulationItem.setItemQty(1l);
        simulationItem.setItemAmount(new BigDecimal(0l));
        simulationItem.setFinalPriceBCOB(new BigDecimal(0l));
        simulationItem.setTotalAmount(new BigDecimal(0l));
        campaign.setCountry(new Country(new CountryId("1", '1')));
        campaign.setIncentive(new BigDecimal(1l));
        mktCampaign.setId(mktCampaignId);
        mktCampaign.setCampaignDesc("1");
        mktCampaignId.setCustGroup5("1");

        ICurrencyService currencyServiceMock = getServiceMock(ICurrencyService.class);
        ICommodityService commodityServiceMock = getServiceMock(ICommodityService.class);
        IIncotermsService incotermsServiceMock = getServiceMock(IIncotermsService.class);
        IMktCampaignService mktCampaignServiceMock = getServiceMock(IMktCampaignService.class);
        ICampaignCommodityService campaignCommodityServiceMock = getServiceMock(ICampaignCommodityService.class);
        ICampaignBarterTypeService campaignBarterTypeServiceMock = getServiceMock(ICampaignBarterTypeService.class);

        Whitebox.setInternalState(tested, "detail", false);
        Whitebox.setInternalState(tested, "reopen", true);

        Simulation simulationMock = tested.getSimulation();
        when(simulationMock.getCrop()).thenReturn(new Crop());
        when(simulationMock.getQuotation()).thenReturn(new Quotation(new QuotationId()));
        when(simulationMock.getHistories()).thenReturn(Arrays.asList(new SimulationHistory[]{new SimulationHistory()}));
        when(simulationMock.getItems()).thenReturn(Arrays.asList(new SimulationItem[]{simulationItem}));
        when(simulationMock.getCity()).thenReturn(new City(cityId));
        when(simulationMock.getAgent()).thenReturn(new PartnerYa());
        when(simulationMock.getCurrency()).thenReturn(new Currency(currencyId));
        when(simulationMock.getIncoterms()).thenReturn(new Incoterms(incotermsId));
        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod());
        when(simulationMock.getCommodityId()).thenReturn("1");
        when(simulationMock.getCampaign()).thenReturn(campaign);
        when(simulationMock.getCustGroup5()).thenReturn("1");
        when(simulationMock.getPaymentCondition()).thenReturn(PaymentConditionList.BARTER_B.getCod());
        when(commodityServiceMock.findById(any(Commodity.class))).thenReturn(new Commodity());
        when(mktCampaignServiceMock.search(any(MktCampaignFilter.class))).thenReturn(Arrays.asList(new MktCampaign[]{mktCampaign}));
        when(campaignBarterTypeServiceMock.search(any(CampaignBarterTypeFilter.class))).thenReturn(Arrays.asList(new CampaignBarterType[]{}));
        when(currencyServiceMock.search(any(CurrencyFilter.class))).thenReturn(Arrays.asList(new Currency[]{}));
        when(campaignCommodityServiceMock.search(any(CampaignCommodityFilter.class))).thenReturn(Arrays.asList(new CampaignCommodity[]{}));
        when(incotermsServiceMock.search(any(IncotermsFilter.class))).thenReturn(Arrays.asList(new Incoterms[]{}));
        when(getServiceMock(IRegionService.class).search(any(RegionFilter.class))).thenReturn(Arrays.asList(new Region[]{}));


        Whitebox.invokeMethod(tested, "fillInitialSimulationValues");
    }

    /**
     * @throws Exception
     * @see SimulationFaces#loadDetailFields()
     */
    @Test
    public void testPrivateMethod_loadDetailFields() throws Exception {
        setupMockServices();

        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        MktCampaign mktCampaign = new MktCampaign();
        MktCampaignId mktCampaignId = new MktCampaignId();
        mktCampaign.setCampaignDesc("");
        mktCampaign.setId(mktCampaignId);

        IMktCampaignService mktCampaignServiceMock = getServiceMock(IMktCampaignService.class);
        ITradingService tradingServiceMock = getServiceMock(ITradingService.class);
        ICommodityService commodityServiceMock = getServiceMock(ICommodityService.class);
        Simulation simulationMock = tested.getSimulation();

        when(tradingServiceMock.findById(any(Trading.class))).thenReturn(null);
        when(simulationMock.getTradingCd()).thenReturn("");
        when(simulationMock.getCampaign()).thenReturn(campaign);
        Whitebox.invokeMethod(tested, "loadDetailFields");

        when(tradingServiceMock.findById(any(Trading.class))).thenReturn(new Trading());
        when(commodityServiceMock.findById(any(Commodity.class))).thenReturn(new Commodity());
        when(simulationMock.getCustGroup5()).thenReturn("1");
        Whitebox.invokeMethod(tested, "loadDetailFields");

        when(mktCampaignServiceMock.search(any(MktCampaignFilter.class))).thenReturn(Arrays.asList(new MktCampaign[]{mktCampaign}));
        Whitebox.invokeMethod(tested, "loadDetailFields");

        mktCampaignId.setCustGroup5("1");
        Whitebox.invokeMethod(tested, "loadDetailFields");
    }

    /**
     * @throws Exception
     * @see SimulationFaces#openPopUp()
     */
    @Test
    public void testPrivateMethod_openPopUp() throws Exception {

        setupMockServices();

        Currency currency = new Currency(new CurrencyId());
        Campaign campaign = new Campaign();
        campaign.setCountry(new Country(new CountryId()));
        List<SelectItem> selectItems= Arrays.asList(new SelectItem[]{new SelectItem("1"), new SelectItem("")});

        Simulation simulationMock = tested.getSimulation();

        when(simulationMock.getCity()).thenReturn(new City(new CityId()));

        QuotationFaces quotationFacesMock = Whitebox.<QuotationFaces> invokeMethod(tested,
                "getFaces", new Class[]{String.class}, "quotationFaces");

        //mocking
        Whitebox.setInternalState(tested, "tradingList", selectItems);
        when(simulationMock.getCurrency()).thenReturn(currency);
        when(simulationMock.getCampaign()).thenReturn(campaign );
        //BRANCH A
        Whitebox.invokeMethod(tested, "openPopUp");
        assertTrue(Whitebox.<Boolean>getInternalState(tested, "renderedPanelQuotation"));

        //mocking
        when(simulationMock.getTradingCd()).thenReturn("1");
        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.TERMS.getCod());
        when(quotationFacesMock.getMessages()).thenReturn("1");
        //BRANCH B
        Whitebox.invokeMethod(tested, "openPopUp");
        assertEquals("1", tested.getMessages());
    }

    /**
     */
    @Test
    public void testMethod_btnConfirmIncludeItem() {
        setupMockServices();

        tested.btnConfirmIncludeItem();

        Simulation simulation = Whitebox.getInternalState(tested, "simulation");
        assertTrue(!simulation.getItems().isEmpty());
    }

    @Test
    public void attachFile() {
        setupMockServices();
        Simulation simulationMock = mock(Simulation.class);
        FileUpload fileUploadHandler = mock(FileUpload.class);
        File file = mock(File.class);
        when(fileUploadHandler.getFile()).thenReturn(file);
        when(file.getFileSize()).thenReturn(451L);
        when(fileUploadHandler.getFile()).thenReturn(file);
        when(fileUploadHandler.getUploadDocumentNumber()).thenReturn("1234");
        when(fileUploadHandler.getUploadDocumentType()).thenReturn(DocumentTypeList.NOTE_ORDER);
        when(simulationMock.getAttachments()).thenReturn(new ArrayList<BarAttachment>());
        tested.setFileUploadHandlers(new ArrayList<FileUpload>());
        tested.getFileUploadHandlers().add(fileUploadHandler);
        tested.setAttachments(new ArrayList<BarAttachment>());
        fileUploadHandler.setUploadDocumentNumber("1234");
        fileUploadHandler.setUploadDocumentType(DocumentTypeList.APPROVAL);
        tested.attachFiles();
    }

    @Test
    public void attachFileErrors() {
        setupMockServices();
        Simulation simulationMock = mock(Simulation.class);
        FileUpload fileUploadHandler = mock(FileUpload.class);
        File file = mock(File.class);
        when(fileUploadHandler.getFile()).thenReturn(file);
        when(file.getFileSize()).thenReturn(null);
        when(fileUploadHandler.getFile()).thenReturn(null);
        when(fileUploadHandler.getUploadDocumentNumber()).thenReturn("123");
        when(fileUploadHandler.getUploadDocumentType()).thenReturn(null);
        when(simulationMock.getAttachments()).thenReturn(new ArrayList<BarAttachment>());
        tested.setFileUploadHandlers(new ArrayList<FileUpload>());
        tested.getFileUploadHandlers().add(fileUploadHandler);
        tested.setAttachments(new ArrayList<BarAttachment>());
        tested.attachFiles();
    }
    @Test
    public void deleteAttachment() {
        setupMockServices();
        AttachmentService attachmentService = getServiceMock(AttachmentService.class);
        List<BarAttachment> attachments = new ArrayList<BarAttachment>();
        attachments.add(mock(BarAttachment.class));
        tested.setAttachments(attachments);
        tested.deleteAttachment();
    }

    @Test
    public void prepareFileUploadForm(){
        setupMockServices();
         List<BarAttachment> attachments = new ArrayList<BarAttachment>();
        attachments.add(mock(BarAttachment.class));
        tested.setAttachments(attachments);
        List<FileUpload> fileUpload = new ArrayList<FileUpload>();
        fileUpload.add(mock(FileUpload.class));
        tested.setFileUploadHandlers(fileUpload);
        String result = tested.prepareFileUploadForm();
        assertNotNull(result);
        assertEquals("success", result);

    }


    /**
     * Setup method constructor allows to inject services through beanFactory mock.
     */
    private void setupMockServices() {
        tested = SilentObjectCreator.create(SimulationFaces.class);//avoid default constructor

        Product productMock = mock(Product.class);
        ItemFaces itemFacesMock = mock(ItemFaces.class);
        Simulation simulationMock = mock(Simulation.class);
        BeanFactory beanFactoryMock = mock(BeanFactory.class);
        SimulationItem simulationItemMock = mock(SimulationItem.class);
        QuotationFaces quotationFacesMock = mock(QuotationFaces.class);
        SimulationBusiness simulationBusinessMock = mock(SimulationBusiness.class);
        TradingContractFaces tradingContractFacesMock = mock(TradingContractFaces.class);
        BarAttachment attachmentMock = mock(BarAttachment.class);

        List<MessageVO> messageVOList = new ArrayList<MessageVO>();
        List<InvoiceSimulation> invoiceSimulationsList = new ArrayList<InvoiceSimulation>();
        invoiceSimulationsList.add(mock(InvoiceSimulation.class));


        Whitebox.setInternalState(tested, simulationMock);
        Whitebox.setInternalState(tested, beanFactoryMock);
        Whitebox.setInternalState(tested, simulationBusinessMock);
        Whitebox.setInternalState(tested,"totalBarterTons", new BigDecimal(1));
        Whitebox.setInternalState(tested,"totalBarterAmount", new BigDecimal(1));
        Whitebox.setInternalState(tested, UnitMeasurementList.ARROBA);
        Whitebox.setInternalState(tested, SecurityUtil.getLoggedInUser());
        Whitebox.setInternalState(tested, attachmentMock);

        when(productMock.getMaterialNbr()).thenReturn("");
        when(itemFacesMock.isOk()).thenReturn(true);
        when(itemFacesMock.getSimulationItem()).thenReturn(simulationItemMock);
        when(simulationMock.getSackNetPrice()).thenReturn(new BigDecimal(1));
        when(simulationMock.getInvoices()).thenReturn(invoiceSimulationsList);
        when(simulationMock.getCoverageValue()).thenReturn(new BigDecimal(0));
        when(simulationMock.getItems()).thenReturn(new ArrayList<SimulationItem>());
        when(simulationMock.getExistingSaleFlg()).thenReturn(YesNoList.YES.getFlag());
        when(simulationMock.getTotalInvoiceConvertedValue()).thenReturn(new BigDecimal(0));
        when(simulationMock.getPaymentCondition()).thenReturn(PaymentConditionList.BARTER_B.getCod());
        when(getServiceMock(IUserService.class).findByIdWithPermissionAndHistory(any(User.class))).thenReturn(null);
        when(simulationItemMock.getItemQty()).thenReturn(0l);
        when(simulationItemMock.getProduct()).thenReturn(productMock);
        when(simulationItemMock.getItemAmount()).thenReturn(new BigDecimal(0));
        when(simulationItemMock.getTotalAmount()).thenReturn(new BigDecimal(0));
        when(simulationItemMock.getFinalPriceBCOB()).thenReturn(new BigDecimal(0));
        when(simulationItemMock.getDivision()).thenReturn(new Division(new DivisionId()));
        when(getServiceMock(IProductService.class).findById(any(Product.class))).thenReturn(null);
        when(getServiceMock(ISimulationService.class).getMessages()).thenReturn(messageVOList);
        when(getServiceMock(ISimulationService.class).findByIdComplete(any(Simulation.class))).thenReturn(simulationMock);
        when(getServiceMock(ISimulationItemService.class).isOk()).thenReturn(true);
        when(getServiceMock(ISimulationItemService.class).calculateFinalPrice(any(SimulationItem.class))).thenReturn(null);
        when(getServiceMock(ISimulationItemService.class).calculateTotalAmount(any(SimulationItem.class))).thenReturn(null);

        when(getServiceMock(CountryHolder.class).getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);

        doNothing().when( tradingContractFacesMock ).searchFromPopup();

        FacesContext facesContextMock = FacesContext.getCurrentInstance();
        ELResolver elResolver = facesContextMock.getELContext().getELResolver();
        elResolver.setValue(facesContextMock.getELContext(), null, "itemFaces", itemFacesMock);
        elResolver.setValue(facesContextMock.getELContext(), null, "quotationFaces", quotationFacesMock);
        elResolver.setValue(facesContextMock.getELContext(), null, "tradingContractFaces", tradingContractFacesMock);

        prepareSimulationMockForNotNewSale(simulationMock);
    }

    private void prepareSimulationMockForNotNewSale(Simulation simulationMock) {
        IncotermsId incotermId = new IncotermsId();
        incotermId.setIncotermsCd("");
        incotermId.setLanguageCd('e');
        Incoterms incoterms = new Incoterms(incotermId);
        when(simulationMock.getIncoterms()).thenReturn(incoterms);
        CurrencyId currencyId = new CurrencyId();
        currencyId.setCurrencyCd("");
        currencyId.setLanguageCd('e');
        Currency currency = new Currency(currencyId);
        when(simulationMock.getCurrency()).thenReturn(currency);
        CityId cityId = new CityId();
        cityId.setCityCd("");
        cityId.setLanguageCd('e');
        City city = new City(cityId);
        when(simulationMock.getCity()).thenReturn(city);
        Campaign campaign = new Campaign(1l);
        campaign.setIncentive(BigDecimal.ONE);
        CountryId countryId = new CountryId("",'e');
        Country country = new Country(countryId);
        campaign.setCountry(country);
        when(simulationMock.getCampaign()).thenReturn(campaign);
        Crop crop = new Crop("");
        when(simulationMock.getCrop()).thenReturn(crop);

        ICurrencyService currencyServiceMock = getServiceMock(ICurrencyService.class);
        ITradingService tradingService = getServiceMock(ITradingService.class);
        ICropService cropService = getServiceMock(ICropService.class);
        ICommodityService commodityServiceMock = getServiceMock(ICommodityService.class);
        IIncotermsService incotermsServiceMock = getServiceMock(IIncotermsService.class);
        IMktCampaignService mktCampaignServiceMock = getServiceMock(IMktCampaignService.class);
        ICampaignCommodityService campaignCommodityServiceMock = getServiceMock(ICampaignCommodityService.class);
        ICampaignBarterTypeService campaignBarterTypeServiceMock = getServiceMock(ICampaignBarterTypeService.class);
        ICampaignTradingService campaignTradingServiceMock = getServiceMock(ICampaignTradingService.class);

        when(simulationMock.getQuotation()).thenReturn(new Quotation(new QuotationId()));
        when(simulationMock.getHistories()).thenReturn(Arrays.asList(new SimulationHistory[]{new SimulationHistory()}));
        when(simulationMock.getItems()).thenReturn(new ArrayList<SimulationItem>());
        when(simulationMock.getCity()).thenReturn(new City(cityId));
        when(simulationMock.getAgent()).thenReturn(new PartnerYa());
        when(simulationMock.getBarterType()).thenReturn(BarterTypeList.FUTURE_MONSANTO_MANAGES_CONTRACT.getCod());
        when(simulationMock.getCommodityId()).thenReturn("");
        when(simulationMock.getCustGroup5()).thenReturn("1");
        when(commodityServiceMock.findById(any(Commodity.class))).thenReturn(new Commodity());
        when(mktCampaignServiceMock.search(any(MktCampaignFilter.class))).thenReturn(Arrays.asList(new MktCampaign[]{}));
        when(campaignBarterTypeServiceMock.search(any(CampaignBarterTypeFilter.class))).thenReturn(Arrays.asList(new CampaignBarterType[]{}));
        when(currencyServiceMock.search(any(CurrencyFilter.class))).thenReturn(Arrays.asList(new Currency[]{}));
        when(tradingService.search(any(TradingFilter.class))).thenReturn(new ArrayList<Trading>());
        when(cropService.search(any(CropFilter.class))).thenReturn(Arrays.asList(new Crop[]{}));
        when(campaignCommodityServiceMock.search(any(CampaignCommodityFilter.class))).thenReturn(Arrays.asList(new CampaignCommodity[]{}));
        when(incotermsServiceMock.search(any(IncotermsFilter.class))).thenReturn(Arrays.asList(new Incoterms[]{}));
        when(getServiceMock(IRegionService.class).search(any(RegionFilter.class))).thenReturn(Arrays.asList(new Region[]{}));
        when(campaignTradingServiceMock.search(any(CampaignTradingFilter.class))).thenReturn(new ArrayList<CampaignTrading>());
    }

    private <T> T getServiceMock(Class<T> clazz) {
        T t = null;
        try {
            t = Whitebox.<T> invokeMethod(tested, "getService",
                    new Class[] { Class.class }, clazz);
            if (t == null) {
                T mock = mock(clazz);
                BeanFactory beanFactoryMock = Whitebox.<BeanFactory> getInternalState(tested, "beanFactory");
                when(beanFactoryMock.getBean(clazz)).thenReturn(mock);
                t = getServiceMock(clazz);
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        return t;
    }

}
