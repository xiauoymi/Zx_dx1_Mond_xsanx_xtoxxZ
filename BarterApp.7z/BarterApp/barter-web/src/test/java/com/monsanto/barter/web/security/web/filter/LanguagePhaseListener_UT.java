package com.monsanto.barter.web.security.web.filter;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.service.IFormalizationTermService;
import com.monsanto.barter.web.faces.formalization.FormalizationFaces;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Test class for the FormalizationFaces class.
 *
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class LanguagePhaseListener_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";


    @SuppressWarnings("serial")
    public static class FormalizationFacesForTest extends FormalizationFaces {

        @Override
        @SuppressWarnings("unchecked")
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(IFormalizationTermService.class)) {
                IFormalizationTermService formalizationTermService = mock(IFormalizationTermService.class);

                return (T) formalizationTermService;
            }
            return super.getService(requiredType);
        }
    }

    ;

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public LanguagePhaseListener_UT() {

    }

    /* (non-Javadoc)
    * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
    */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('E');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    /**
     * @see LanguagePhaseListener#beforePhase(PhaseEvent)
     */
    @Test
    public void testBeforePhase() {
        LanguagePhaseListener languagePhaseListener = new LanguagePhaseListener();

        FacesContext context = mock(FacesContext.class);
        PhaseEvent event = mock(PhaseEvent.class);
        when(event.getFacesContext()).thenReturn(context);
        UIViewRoot uiViewRoot = mock(UIViewRoot.class);
        when(context.getViewRoot()).thenReturn(uiViewRoot);

        try {
            languagePhaseListener.beforePhase(event);
        } catch (Exception ex) {
            fail();
        }
    }

    @Test
    public void testBeforePhase1() {

        LanguagePhaseListener languagePhaseListener = new LanguagePhaseListener();

        FacesContext context = mock(FacesContext.class);
        PhaseEvent event = mock(PhaseEvent.class);
        when(event.getFacesContext()).thenReturn(context);
        UIViewRoot uiViewRoot = mock(UIViewRoot.class);
        when(context.getViewRoot()).thenReturn(uiViewRoot);

        SecurityUtil.setLoggedInUser((User)null);

        languagePhaseListener.beforePhase(event);

    }

    @Test
    public void testAfterPhase() {

        LanguagePhaseListener languagePhaseListener = new LanguagePhaseListener();
        languagePhaseListener.afterPhase(null);

    }

    @Test
    public void testGetPhaseId() {
        LanguagePhaseListener languagePhaseListener = new LanguagePhaseListener();

        PhaseId result = languagePhaseListener.getPhaseId();

        assertEquals(PhaseId.RENDER_RESPONSE, result);
    }
}
