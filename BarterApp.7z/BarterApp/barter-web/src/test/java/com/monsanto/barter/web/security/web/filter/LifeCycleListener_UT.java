package com.monsanto.barter.web.security.web.filter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;

import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created with IntelliJ IDEA.
 * User: GIRIA
 * Date: 4/16/14
 * Time: 3:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class LifeCycleListener_UT {
    @Mock
    FacesContext facesContextMock;

    @Mock
    PhaseEvent phaseEventMock;

    @Before
    public void setUp() {
        initMocks(this);
    }

    @Test
    public void testBeforePhaseWithViewRootNull(){
        when(facesContextMock.getViewRoot()).thenReturn(null);
        when(phaseEventMock.getFacesContext()).thenReturn(facesContextMock);
        LifeCycleListener lifeCycleListener = new LifeCycleListener();
        lifeCycleListener.beforePhase(phaseEventMock);
        Assert.assertNotNull(lifeCycleListener.getPhaseId());
    }

    @Test
    public void testBeforePhaseWithViewRootNotNull(){
        when(facesContextMock.getViewRoot()).thenReturn(new UIViewRoot());
        when(phaseEventMock.getFacesContext()).thenReturn(facesContextMock);
        LifeCycleListener lifeCycleListener = new LifeCycleListener();
        lifeCycleListener.beforePhase(phaseEventMock);
        Assert.assertNotNull(lifeCycleListener.getPhaseId());
    }

    @Test
    public void testAfterPhaseWithViewRootNull(){
        when(facesContextMock.getViewRoot()).thenReturn(null);
        when(phaseEventMock.getFacesContext()).thenReturn(facesContextMock);
        LifeCycleListener lifeCycleListener = new LifeCycleListener();
        lifeCycleListener.afterPhase(phaseEventMock);
        Assert.assertNotNull(lifeCycleListener.getPhaseId());
    }

    @Test
    public void testAfterPhaseWithViewRootNotNull(){
        when(facesContextMock.getViewRoot()).thenReturn(new UIViewRoot());
        when(phaseEventMock.getFacesContext()).thenReturn(facesContextMock);
        LifeCycleListener lifeCycleListener = new LifeCycleListener();
        lifeCycleListener.afterPhase(phaseEventMock);
        Assert.assertNotNull(lifeCycleListener.getPhaseId());
    }

}
