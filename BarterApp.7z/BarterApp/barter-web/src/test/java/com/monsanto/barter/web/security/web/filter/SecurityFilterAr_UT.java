package com.monsanto.barter.web.security.web.filter;

import com.monsanto.barter.ar.business.entity.GlobalBarterUser;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import com.monsanto.barter.ar.business.entity.enumerated.StatusEnum;
import com.monsanto.barter.ar.business.security.GlobalBarterSecurityHelper;
import com.monsanto.barter.ar.business.service.GlobalBarterUserService;
import com.monsanto.barter.ar.web.faces.beans.user.InactiveUserException;
import com.monsanto.barter.ar.web.faces.beans.user.UserNotFoundException;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.io.IOException;
import java.util.Enumeration;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;


@RunWith(PowerMockRunner.class)
@PrepareForTest({SecurityContextHolder.class, GlobalBarterSecurityHelper.class})
public class SecurityFilterAr_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    private SecurityFilterAr tested;

    @Mock
    GlobalBarterUserService service;

    private Object userAddedToRequest;

    public SecurityFilterAr_UT() {
    }

    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        initMocks(this);
    }

    @Test
    public void testMethodsThatWereMandatoryImplementedBecauseOfTheFrameworkButHaveNoLogic() throws ServletException {
        tested = new SecurityFilterAr();

        tested.init(null);
        tested.setBeanName("");
        tested.setEnvironment(null);
        tested.setServletContext(null);
        tested.afterPropertiesSet();
        tested.destroy();

    }

    @Test
    public void testDoFilter() throws IOException, ServletException {

        SecurityFilterAr securityFilter = new SecurityFilterAr();

        PowerMockito.mockStatic(GlobalBarterSecurityHelper.class);
        UserDecorator userDecorator = mock(UserDecorator.class);
        when(userDecorator.getName()).thenReturn(USER_ID);
        PowerMockito.when(GlobalBarterSecurityHelper.getLoggedUserName()).thenReturn(USER_ID);
        service = mock(GlobalBarterUserService.class);
        GlobalBarterUser globalBarterUser = new GlobalBarterUser();
        globalBarterUser.setStatus(StatusEnum.ACTIVE);
        when(service.findByUsername(anyString())).thenReturn(globalBarterUser);
        when(service.getAuthenticatedUserBy(anyString())).thenReturn(userDecorator);
        ReflectionTestUtils.setField(securityFilter, "service", service);
        PowerMockito.mockStatic(SecurityContextHolder.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(securityContext);

        FilterChain filterChain = mock(FilterChain.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        HttpSession session = getHttpSession();
        when(httpServletRequest.getSession()).thenReturn(session);

        securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

        assertThat(userAddedToRequest).isEqualTo(USER_ID);
    }

    @Test
    public void testDoFilterNonExistingUser() throws IOException, ServletException {

        SecurityFilterAr securityFilter = new SecurityFilterAr();

        PowerMockito.mockStatic(GlobalBarterSecurityHelper.class);
        UserDecorator userDecorator = mock(UserDecorator.class);
        when(userDecorator.getName()).thenReturn(USER_ID);
        PowerMockito.when(GlobalBarterSecurityHelper.getLoggedUserName()).thenReturn(USER_ID);
        service = mock(GlobalBarterUserService.class);
        GlobalBarterUser globalBarterUser = new GlobalBarterUser();
        globalBarterUser.setStatus(StatusEnum.ACTIVE);
        when(service.getAuthenticatedUserBy(anyString())).thenReturn(userDecorator);
        ReflectionTestUtils.setField(securityFilter, "service", service);

        FilterChain filterChain = mock(FilterChain.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        HttpSession session = getHttpSession();
        when(httpServletRequest.getSession()).thenReturn(session);

        try {
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
            fail();
        } catch (UserNotFoundException e) {
            assertThat(true).isTrue();
        }
    }

    @Test
    public void testDoFilterNonActiveUser() throws IOException, ServletException {

        SecurityFilterAr securityFilter = new SecurityFilterAr();

        PowerMockito.mockStatic(GlobalBarterSecurityHelper.class);
        UserDecorator userDecorator = mock(UserDecorator.class);
        when(userDecorator.getName()).thenReturn(USER_ID);
        PowerMockito.when(GlobalBarterSecurityHelper.getLoggedUserName()).thenReturn(USER_ID);
        service = mock(GlobalBarterUserService.class);
        GlobalBarterUser globalBarterUser = new GlobalBarterUser();
        globalBarterUser.setStatus(StatusEnum.INACTIVE);
        when(service.findByUsername(anyString())).thenReturn(globalBarterUser);
        when(service.getAuthenticatedUserBy(anyString())).thenReturn(userDecorator);
        ReflectionTestUtils.setField(securityFilter, "service", service);
        PowerMockito.mockStatic(SecurityContextHolder.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(securityContext);

        FilterChain filterChain = mock(FilterChain.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        HttpSession session = getHttpSession();
        when(httpServletRequest.getSession()).thenReturn(session);

        try {
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
            fail();
        } catch (InactiveUserException e) {
            assertThat(true).isTrue();
        }
    }

    public HttpSession getHttpSession() {
        return new HttpSession() {
            @Override
            public long getCreationTime() {
                return 0;
            }

            @Override
            public String getId() {
                return null;
            }

            @Override
            public long getLastAccessedTime() {
                return 0;
            }

            @Override
            public ServletContext getServletContext() {
                return null;
            }

            @Override
            public void setMaxInactiveInterval(int i) {

            }

            @Override
            public int getMaxInactiveInterval() {
                return 0;
            }

            @Override
            public HttpSessionContext getSessionContext() {
                return null;
            }

            @Override
            public Object getAttribute(String s) {
                return null;
            }

            @Override
            public Object getValue(String s) {
                return null;
            }

            @Override
            public Enumeration getAttributeNames() {
                return null;
            }

            @Override
            public String[] getValueNames() {
                return new String[0];
            }

            @Override
            public void setAttribute(String s, Object o) {
                userAddedToRequest = o;
            }

            @Override
            public void putValue(String s, Object o) {

            }

            @Override
            public void removeAttribute(String s) {

            }

            @Override
            public void removeValue(String s) {

            }

            @Override
            public void invalidate() {

            }

            @Override
            public boolean isNew() {
                return false;
            }
        };
    }

}
