package com.monsanto.barter.web.security.web.filter;

import static org.junit.Assert.*;
import static org.junit.Assert.fail;


import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.monsanto.barter.architecture.regionalization.CountryHolder;
import com.monsanto.barter.web.test.JsfTestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.monsanto.barter.architecture.security.data.User;
import com.monsanto.barter.architecture.security.helper.SecurityHelper;
import com.monsanto.barter.architecture.util.SecurityUtil;
import com.monsanto.barter.business.entity.list.PermissionList;
import com.monsanto.barter.business.entity.table.Group;
import com.monsanto.barter.business.entity.table.Permission;
import com.monsanto.barter.business.service.IFormalizationTermService;
import com.monsanto.barter.business.service.IUserService;
import com.monsanto.barter.web.faces.formalization.FormalizationFaces;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.*;

/**
 * Test class for the FormalizationFaces class.
 * 
 * @author Folger Fonseca V. (fefons@monsanto.com)
 * @since 29/10/2012
 */
@RunWith(PowerMockRunner.class)
public class SecurityFilter_UT extends JsfTestCase {

    public static final String USER_ID = "USER.TEST";
    public static final String HOME = "home";
    public static final String LANGUAGE = "P";
    private SecurityFilter tested;


    public static class FormalizationFacesForTest extends FormalizationFaces{

        @Override
        public <T> T getService(Class<T> requiredType) {

            if (requiredType.equals(IFormalizationTermService.class)) {
                IFormalizationTermService formalizationTermService = mock(IFormalizationTermService.class);

                return (T)formalizationTermService;
            }
            return super.getService(requiredType);
        }
    };

    /**
     * No-arg constructor.
     *
     * @author Folger Fonseca V. (fefons@monsanto.com)
     */
    public SecurityFilter_UT() {

    }
    
    /* (non-Javadoc)
     * @see com.monsanto.barter.business.test.AbstractDBTestClass#setUp()
     */
    @Before
    public void setUp() throws Exception {
        // User assigns logged in session.
        super.setUp();
        User loggedInUser = new User();
        loggedInUser.setId(USER_ID);
        loggedInUser.setLanguageCd('E');
        SecurityUtil.setLoggedInUser(loggedInUser);

    }

    @Test
    public void testInit() {
        SecurityFilter securityFilter= new SecurityFilter();

        FilterConfig fileConfig = mock(FilterConfig.class);
         try{
            securityFilter.init(fileConfig);
         }catch (ServletException ex){
            fail();
         }
    }

        @Test
    public void testSetSecurityHelper() {
        SecurityFilter securityFilter= new SecurityFilter();
        SecurityHelper securityHelper = new SecurityHelper();

        securityFilter.setSecurityHelper(securityHelper);

        assertNotNull(securityFilter.getSecurityHelper());
    }

    @Test
    public void testDoFilter() throws Exception{
       SecurityFilter securityFilter= new SecurityFilter(){
           @Override
            protected String getLoggedInUser() {
               return "USER.TEST";
           }
           @Override
            protected IUserService getService() {
               IUserService userService = mock(IUserService.class);
               com.monsanto.barter.business.entity.table.User user= new com.monsanto.barter.business.entity.table.User();
               user.setName("USER.TEST");
               user.setId("USER.TEST");
               ArrayList<Permission> permissions = new ArrayList<Permission>();
               Permission permission = new Permission();
               permission.setPermissionCd(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
               permissions.add(permission);
               user.setPermissions(permissions);
               Group group = new Group();
               group.setPermissions(permissions);
               user.setGroup(group);

               when(userService.findByIdMonsantoWithPermission(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(user);
                return userService;
           }

           @Override
           public CountryHolder getCountryHolder() {

               CountryHolder countryHolder = mock(CountryHolder.class);
               when(countryHolder.getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);
               return countryHolder;

           }

           @Override
           public User getSecurityUser(HttpServletRequest request) {

               User user = new User();
               user.setCountyCd(com.monsanto.barter.architecture.regionalization.Country.BRAZIL.getCountrySAPCd());
               return user;

           }
       };
        FilterConfig fileConfig = mock(FilterConfig.class);


        FilterChain filterChain = mock(FilterChain.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        when(httpServletRequest.getServletPath()).thenReturn("login.jsf");
        when(httpServletRequest.getServletPath()).thenReturn("barter-web");
        when(httpServletRequest.getRequestURI()).thenReturn("barter-web");
        when(httpServletRequest.getRequestURL()).thenReturn(new StringBuffer("barter-web"));
        when(httpServletRequest.getHeader(Matchers.<String>any())).thenReturn("barter-web");
        HttpSession session = mock(HttpSession.class);
        when(httpServletRequest.getSession()).thenReturn(session);
        try{
            securityFilter.init(fileConfig);
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
            when(httpServletRequest.getServletPath()).thenReturn("login.jsf");
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);

            when(httpServletRequest.getParameter("monitoring")).thenReturn("disabled");
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
            //assertFalse(MonitoringEnablingFilter.MONITORING_ENABLED); //TODO failing from maven

            when(httpServletRequest.getParameter("monitoring")).thenReturn("enabled");
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);


        }catch(Exception ex){

              fail();

        }

        assertNotNull(securityFilter.getLoggedInUser());
    }

   @Test
   public void testSetupUser() throws Exception{
      SecurityFilter securityFilter= new SecurityFilter(){
          @Override
           protected String getLoggedInUser() {
              return "USER.TEST";
          }

          @Override
           protected IUserService getService() {
              IUserService userService = mock(IUserService.class);
              com.monsanto.barter.business.entity.table.User user= new com.monsanto.barter.business.entity.table.User();
              user.setName("USER.TEST");
              user.setId("USER.TEST");
              ArrayList<Permission> permissions = new ArrayList<Permission>();
              Permission permission = new Permission();
              permission.setPermissionCd(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
              permissions.add(permission);
              user.setPermissions(permissions);
              Group group = new Group();
              group.setPermissions(permissions);
              user.setGroup(group);
              user.setCountryCd(com.monsanto.barter.architecture.regionalization.Country.BRAZIL.getCountrySAPCd());

              when(userService.findByIdMonsantoWithPermission(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(user);
               return userService;
          }

          @Override
          public CountryHolder getCountryHolder() {

              CountryHolder countryHolder = mock(CountryHolder.class);
              when(countryHolder.getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);
              return countryHolder;

          }
       };
       FilterConfig fileConfig = mock(FilterConfig.class);
       FilterChain filterChain = mock(FilterChain.class);

       HttpServletResponse httpServletResponse = new MockHttpServletResponse();
       MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
       httpServletRequest.setServletPath("login.jsf");
       httpServletRequest.setRequestURI("barter-web");
       try{
           securityFilter.init(fileConfig);
           securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
       }catch(Exception ex){

             fail();

       }

       assertNotNull(securityFilter.getLoggedInUser());
   }

    @Test
    public void testLocalEnvironment() throws Exception{
        SecurityFilter securityFilter= new SecurityFilter() {
            @Override
            public CountryHolder getCountryHolder() {

              CountryHolder countryHolder = mock(CountryHolder.class);
              when(countryHolder.getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);
              return countryHolder;

            }
        };

        FilterConfig fileConfig = mock(FilterConfig.class);
        FilterChain filterChain = mock(FilterChain.class);
        System.setProperty("lsi.function","win");

        HttpServletResponse httpServletResponse = new MockHttpServletResponse();
        MockHttpServletRequest httpServletRequest = new MockHttpServletRequest();
        httpServletRequest.setServletPath("login.jsf");
        httpServletRequest.setRequestURI("barter-web");
        try{
            securityFilter.init(fileConfig);
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
        }catch(Exception ex){
             fail();
        }

        verify(filterChain).doFilter(httpServletRequest,httpServletResponse);
        System.clearProperty("lsi.function");
    }

    @Test
    public void testInvalidUser() throws Exception{
        SecurityFilter securityFilter= new SecurityFilter(){
         @Override
          protected String getLoggedInUser() {
             return "USER.TEST";
         }

         @Override
          protected IUserService getService() {
             IUserService userService = mock(IUserService.class);
             return userService;
         }

         @Override
         public CountryHolder getCountryHolder() {
             CountryHolder countryHolder = mock(CountryHolder.class);
             when(countryHolder.getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);
             return countryHolder;

         }
        };
        FilterConfig fileConfig = mock(FilterConfig.class);
        FilterChain filterChain = mock(FilterChain.class);

        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        when(httpServletRequest.getContextPath()).thenReturn("barter-wer");
        when(httpServletRequest.getServletPath()).thenReturn("login.jsf");
        when(httpServletRequest.getRequestURI()).thenReturn("barter-web");
        when(httpServletRequest.getRequestURL()).thenReturn(new StringBuffer("barter-web"));
        when(httpServletRequest.getHeader(Matchers.<String>any())).thenReturn("barter-web");
        HttpSession session = mock(HttpSession.class);
        when(httpServletRequest.getSession()).thenReturn(session);

          try{
              securityFilter.init(fileConfig);
              securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
              Mockito.verify(httpServletResponse).sendRedirect("barter-wer/pages/admin/country_login_error.jsf");
          }catch(Exception ex){

                fail();

          }
      }


    @Test
    public void testInvalidUserCountry() throws Exception{
        SecurityFilter securityFilter= new SecurityFilter(){
            @Override
            protected String getLoggedInUser() {
                return "USER.TEST";
            }
            @Override
            protected IUserService getService() {
                IUserService userService = mock(IUserService.class);
                com.monsanto.barter.business.entity.table.User user= new com.monsanto.barter.business.entity.table.User();
                user.setName("USER.TEST");
                user.setId("USER.TEST");
                ArrayList<Permission> permissions = new ArrayList<Permission>();
                Permission permission = new Permission();
                permission.setPermissionCd(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd());
                permissions.add(permission);
                user.setPermissions(permissions);
                Group group = new Group();
                group.setPermissions(permissions);
                user.setGroup(group);

                when(userService.findByIdMonsantoWithPermission(Matchers.<com.monsanto.barter.business.entity.table.User>any())).thenReturn(user);
                return userService;
            }

            @Override
            public CountryHolder getCountryHolder() {

                CountryHolder countryHolder = mock(CountryHolder.class);
                when(countryHolder.getCountry()).thenReturn(com.monsanto.barter.architecture.regionalization.Country.BRAZIL);
                return countryHolder;

            }

            @Override
            public User getSecurityUser(HttpServletRequest request) {

                User user = new User();
                user.setCountyCd(com.monsanto.barter.architecture.regionalization.Country.PARAGUAY.getCountrySAPCd());
                return user;

            }
        };
        FilterConfig fileConfig = mock(FilterConfig.class);


        FilterChain filterChain = mock(FilterChain.class);
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        when(httpServletRequest.getContextPath()).thenReturn("barter-wer");
        when(httpServletRequest.getServletPath()).thenReturn("login.jsf");
        when(httpServletRequest.getServletPath()).thenReturn("barter-web");
        when(httpServletRequest.getRequestURI()).thenReturn("barter-web");
        when(httpServletRequest.getRequestURL()).thenReturn(new StringBuffer("barter-web"));
        when(httpServletRequest.getHeader(Matchers.<String>any())).thenReturn("barter-web");
        HttpSession session = mock(HttpSession.class);
        when(httpServletRequest.getSession()).thenReturn(session);

        try{

            securityFilter.init(fileConfig);
            securityFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
            Mockito.verify(httpServletResponse).sendRedirect("barter-wer/pages/admin/country_login_error.jsf");


        }catch(Exception ex){

            fail();

        }

        assertNotNull(securityFilter.getLoggedInUser());
    }




    /**
     * @throws Exception 
     * @see SecurityFilter#canAccessPage(User, String)
     */
	@Test
	public void testProtectedMethod_canAccessPage() throws Exception {
		setupMockServices();

		boolean result = false;
		
		//branch coverage 1T,2F
		result = Whitebox.<Boolean> invokeMethod(tested, "canAccessPage",
				new User(), "http://login.jsf");
		assertTrue(result);
		
		//branch coverage 1F,2.1.1T
		User user = new User();
		List<com.monsanto.barter.architecture.security.data.Permission> permissions = new ArrayList<com.monsanto.barter.architecture.security.data.Permission>();
		permissions.add(new com.monsanto.barter.architecture.security.data.Permission(PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPermissionCd()));
		user.setPermissions(permissions);
		result = Whitebox.<Boolean> invokeMethod(tested, "canAccessPage",
				user, PermissionList.APPROVE_SIMULATION_BUTTON_PERMISSION_CD.getPage());
		assertTrue(result);
	}
    
    /**
     * @throws Exception 
     * @see SecurityFilter#redirectToLoginError
     */
	@Test
	public void testProtectedMethod_redirectToLoginError() throws Exception {
		setupMockServices();

		HttpServletRequest httpServletRequestMock = mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponseMock = mock(HttpServletResponse.class);
		
		try {
			Whitebox.<Boolean> invokeMethod(tested, "redirectToLoginError",
					httpServletRequestMock, httpServletResponseMock);			
		} catch (Exception e) {
			fail();
		}
	}
    
    /**
	 * Setup method constructor allows to inject services through beanFactory mock.
	 */
	private void setupMockServices() {
		
		tested = new SecurityFilter();
	}
}
