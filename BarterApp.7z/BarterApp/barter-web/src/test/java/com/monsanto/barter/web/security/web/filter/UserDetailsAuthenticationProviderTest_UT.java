package com.monsanto.barter.web.security.web.filter;

import com.monsanto.barter.ar.business.entity.GlobalBarterUser;
import com.monsanto.barter.ar.business.entity.decorator.UserDecorator;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Created with IntelliJ IDEA.
 * User: IVERT
 * Date: 5/20/14
 * Time: 4:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserDetailsAuthenticationProviderTest_UT {

    @Test
    public void additionalAuthenticationChecksTrivialCall(){
        UserDetailsAuthenticationProvider userDetailsAuthenticationProvider = new UserDetailsAuthenticationProvider();
        userDetailsAuthenticationProvider.additionalAuthenticationChecks(null, null);
    }

    @Test
    public void retrieveUser(){
        UserDetailsAuthenticationProvider userDetailsAuthenticationProvider = new UserDetailsAuthenticationProvider();
        GlobalBarterUser b = new GlobalBarterUser();
        GlobalBarterUser a = new GlobalBarterUser();
        UserDecorator usernamePasswordAuthenticationToken = new UserDecorator(a, b);
        UserDetails result = userDetailsAuthenticationProvider.retrieveUser(null, usernamePasswordAuthenticationToken);

        Assert.assertTrue(usernamePasswordAuthenticationToken.equals(result));
    }
}
