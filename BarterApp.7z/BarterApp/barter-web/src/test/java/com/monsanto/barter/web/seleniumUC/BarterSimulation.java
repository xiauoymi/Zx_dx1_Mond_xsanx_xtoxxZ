package com.monsanto.barter.web.seleniumUC;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BarterSimulation {

    private WebDriver driver;
    private String baseUrl;
    private StringBuffer verificationErrors = new StringBuffer();

    @Before
    public void setUp() throws Exception {
        // driver = new FirefoxDriver();
        driver = new HtmlUnitDriver(true);

        baseUrl = "https://w3t.meuspedidos.monsanto.com/barter-web/pages/admin/home.jsf";
        // baseUrl = "http://localhost.meuspedidos.monsanto.com:8080/barter-jetty/pages/admin/home.jsf";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void testSimulacionWebdriver() throws Exception {
        doLogin(driver);
        int numberOfErrors = 0;
        for (int i=0;i<20;i++) {
            try {
                runSimulacion(driver);
                System.out.println("Successful run");
            } catch (Exception e) {
                numberOfErrors++;
                System.out.println("Failed run: "+e.getMessage());
            }
        }
        assertTrue(numberOfErrors==0);
    }

    private void doLogin(WebDriver driver) throws Exception {
        driver.get(baseUrl);
        driver.findElement(By.id("textfield")).clear();
        driver.findElement(By.id("textfield")).sendKeys("APDUAR_APQ_T");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("Berlop7");
        driver.findElement(By.cssSelector("button.positive")).click();
    }

    private void runSimulacion(WebDriver driver) throws Exception {
        driver.get(baseUrl);

        driver.findElement(By.xpath("//a[@id='navmenu-h']")).click(); // /li[4]/ul/li/ul/li[2]/a")).click();


        driver.findElement(By.id("fcpaForm:rbtFcpa:0")).click();
        driver.findElement(By.id("fcpaForm:btnContinueFcpa")).click();
        new Select(driver.findElement(By.id("campaignForm:drpCampaign"))).selectByVisibleText("Teste Performance PS - 2012/2012");
        driver.findElement(By.id("campaignForm:btnContinueCampaign")).click();
        driver.findElement(By.id("registerForm:btnPopUpCustomer")).click();
        driver.findElement(By.id("formCustomerSearch:txtName")).clear();
        driver.findElement(By.id("formCustomerSearch:txtName")).sendKeys("PCO");
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.id("formCustomerSearch:btnSearch")));
        driver.findElement(By.id("formCustomerSearch:btnSearch")).click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.id("formCustomerSearch:dataTableCustomers:rbCustomer:0")));
        driver.findElement(By.id("formCustomerSearch:dataTableCustomers:rbCustomer:0")).click();
        driver.findElement(By.id("formCustomerSearch:btnOk")).click();
        new Select(driver.findElement(By.id("registerForm:drpBarterType"))).selectByVisibleText("Futuro com Contrato Existente");
        new Select(driver.findElement(By.id("registerForm:drpCrop"))).selectByVisibleText("Sementes Safrinha");
        new Select(driver.findElement(By.id("registerForm:drpTrading"))).selectByVisibleText("BUNGE");
        new Select(driver.findElement(By.id("registerForm:drpRegion"))).selectByVisibleText("TO");
        new WebDriverWait(driver, 10).until(ExpectedConditions.textToBePresentInElement(By.id("registerForm:drpLocalWarehouse"), "Brejinho de Nazare"));
        new Select(driver.findElement(By.id("registerForm:drpLocalWarehouse"))).selectByVisibleText("Brejinho de Nazare");
        new Select(driver.findElement(By.id("registerForm:cboCurrency"))).selectByVisibleText("Real - Brasil");
        new Select(driver.findElement(By.id("registerForm:drpPaymentCondit"))).selectByVisibleText("BCOM");
        new Select(driver.findElement(By.id("registerForm:cboCommodity"))).selectByVisibleText("MILHO - COMMODITIES");
        driver.findElement(By.id("registerForm:txtIncentive")).clear();
        driver.findElement(By.id("registerForm:txtIncentive")).sendKeys("1,00");
        driver.findElement(By.id("registerForm:txtContractNumber")).clear();
        driver.findElement(By.id("registerForm:txtContractNumber")).sendKeys("CT_010203");
        new Select(driver.findElement(By.id("registerForm:drpIncoterms"))).selectByVisibleText("CIF");
        driver.findElement(By.id("registerForm:txtSackGrossPrice")).clear();
        driver.findElement(By.id("registerForm:txtSackGrossPrice")).sendKeys("0,15");
        driver.findElement(By.id("registerForm:txtSackGrossPrice")).clear();
        driver.findElement(By.id("registerForm:txtSackGrossPrice")).sendKeys("15,00");
        driver.findElement(By.id("registerForm:rbQuotation:1")).click();
        driver.findElement(By.id("registerForm:txtKgQtd")).clear();
        driver.findElement(By.id("registerForm:txtKgQtd")).sendKeys("10,00");
        driver.findElement(By.id("registerForm:cldDelivDatePopupButton")).click();
        driver.findElement(By.id("registerForm:cldDelivDateDayCell30")).click();
        driver.findElement(By.id("registerForm:cldPaymentDatePopupButton")).click();
        driver.findElement(By.id("registerForm:cldPaymentDateDayCell30")).click();
        driver.findElement(By.id("registerForm:cldNegotDatePopupButton")).click();
        driver.findElement(By.id("registerForm:cldNegotDateDayCell28")).click();
        driver.findElement(By.id("registerForm:btnIncludeItem")).click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.textToBePresentInElement(By.id("formSimulationItem:drpDivision"), "Sementes"));
        new Select(driver.findElement(By.id("formSimulationItem:drpDivision"))).selectByVisibleText("Sementes");
        new WebDriverWait(driver, 10).until(ExpectedConditions.textToBePresentInElement(By.id("formSimulationItem:drpBrand"), "DK0"));
        new Select(driver.findElement(By.id("formSimulationItem:drpBrand"))).selectByVisibleText("DK0");
        new WebDriverWait(driver, 10).until(ExpectedConditions.textToBePresentInElement(By.id("formSimulationItem:drpProduct"), "DKB330CRFNG"));
        new Select(driver.findElement(By.id("formSimulationItem:drpProduct"))).selectByVisibleText("DKB330CRFNG");
        driver.findElement(By.id("formSimulationItem:txtQuantity")).clear();
        driver.findElement(By.id("formSimulationItem:txtQuantity")).sendKeys("100");
        driver.findElement(By.id("formSimulationItem:cldDeliveryDatePopupButton")).click();
        driver.findElement(By.id("formSimulationItem:cldDeliveryDateDayCell30")).click();
        driver.findElement(By.id("formSimulationItem:txtCommittee")).clear();
        driver.findElement(By.id("formSimulationItem:txtCommittee")).sendKeys("0,00");
        driver.findElement(By.id("formSimulationItem:txtDiscountBarter")).clear();
        driver.findElement(By.id("formSimulationItem:txtDiscountBarter")).sendKeys("1,00");
        driver.findElement(By.id("formSimulationItem:btnIncludeItem")).click();
        driver.findElement(By.id("registerForm:btnSave")).click();
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

}
