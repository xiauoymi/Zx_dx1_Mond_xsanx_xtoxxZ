package com.monsanto.barter.web.test;

import java.util.Locale;

/**
 * Abstract class that defines the required methods to start web unit tests. <p>Use the default constructor of the
 * class to set the base url for the test context. Eg:<br /> <tt>setBaseUrl("http://localhost:8080/barter-web/pages/admin");</tt></p><p>Use also
 * for enable or disable javascript support: <br /><tt>setScriptingEnabled(false);</tt></p>.
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 22/12/2011
 */
public abstract class AbstractWebTestClass { //extends WebTester {

    protected static final Locale LOCALE_ENGLISH = Locale.ENGLISH;

    protected static final Locale LOCALE_SPANISH = new Locale("es");

    protected static final Locale LOCALE_PORTUGUESE = new Locale("pt", "br");

    /**
     * Default constructor of the class.
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public AbstractWebTestClass() {

        super();

//        // Set the test context
//        TestContext testContext = new TestContext();
//        testContext.setLocale(LOCALE_PORTUGUESE);
//        setTestContext(testContext);
//
//        // Disable Javascript support
//        setScriptingEnabled(false);
//
//        // Set the Testing Engine
//        setTestingEngineKey(TestingEngineRegistry.TESTING_ENGINE_HTMLUNIT);
    }

}
