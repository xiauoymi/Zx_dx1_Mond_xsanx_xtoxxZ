package com.monsanto.barter.web.test;


import org.apache.myfaces.test.base.junit4.AbstractJsfTestCase;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.StaticWebApplicationContext;

/**
 * Created with IntelliJ IDEA.
 * User: GAVELO
 * Date: 9/20/13
 * Time: 11:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class JsfTestCase extends AbstractJsfTestCase {

    private static final String TEST_CONTEXT_PATH = "spring-test.xml";

    @Override
    public void setUp() throws Exception {
        super.setUp();
        BeanFactory beanFactory = new StaticWebApplicationContext();
        servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,beanFactory);
    }

    @Override
    public void tearDown() throws Exception {
        super.tearDown();
    }
}
