package com.monsanto.barter.web.test;

import java.lang.reflect.Constructor;

import sun.reflect.ReflectionFactory;

/**
 * This Utility class is used for testing avoiding default constructor and
 * letting you inject mocks later.
 * 
 * @author CSOBR1
 * 
 */
public class SilentObjectCreator {
	public static <T> T create(Class<T> clazz) {
		return create(clazz, Object.class);
	}

	@SuppressWarnings({ "restriction", "unchecked" })
	public static <T> T create(Class<T> clazz, Class<? super T> parent) {
		try {
			ReflectionFactory rf = ReflectionFactory.getReflectionFactory();
			Constructor<? super T> objDef = parent.getDeclaredConstructor();
			Constructor<T> intConstr = rf.newConstructorForSerialization(clazz,
					objDef);
			return intConstr.newInstance();
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new IllegalStateException("Cannot create object", e);
		}
	}
}
