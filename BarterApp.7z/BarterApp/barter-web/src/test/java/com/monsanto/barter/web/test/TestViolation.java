package com.monsanto.barter.web.test;

import com.monsanto.barter.ar.business.entity.BillOfLading;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;
import java.util.Iterator;

/**
 * Test implementation of the ConstraintViolation API.
 * It only returns a message.
 * @author JPBENI
 */
public class TestViolation implements ConstraintViolation {

    private final String message;
    private final String property;
    private Object invalidValue;

    public TestViolation(final String message) {
        this.message = message;
        this.property = "";
    }

    public TestViolation(final String message, final String property) {
        this.message = message;
        this.property = property;
    }

    public TestViolation(final String message, final Object invalidValue) {
        this.message = message;
        this.invalidValue = invalidValue;
        this.property = "";
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public String getMessageTemplate() {
        return null;
    }

    @Override
    public BillOfLading getRootBean() {
        return null;
    }

    @Override
    public Class<Object> getRootBeanClass() {
        return Object.class;
    }

    @Override
    public Object getLeafBean() {
        return null;
    }

    @Override
    public Path getPropertyPath() {
        return new Path() {
            @Override
            public Iterator<Node> iterator() {
                return null;
            }

            @Override
            public String toString() {
                return property;
            }
        };
    }

    @Override
    public Object getInvalidValue() {
        return invalidValue;
    }

    @Override
    public ConstraintDescriptor<?> getConstraintDescriptor() {
        return null;
    }

}
