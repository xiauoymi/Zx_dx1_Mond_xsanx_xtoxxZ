package com.monsanto.barter.web.test;

import org.springframework.transaction.TransactionException;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * @author JPBENI
 */
public class TransactionTemplateMocker extends TransactionTemplate {
    private boolean executionRollbacked;
    @Override
    public <T> T execute(TransactionCallback<T> action) throws TransactionException {
        executionRollbacked = false;
        try {
            return action.doInTransaction(null);
        } catch (RuntimeException ex) {
            executionRollbacked = true;
            throw ex;
        } catch (Exception ex) {
            executionRollbacked = true;
            //Exceptions caught here are not propagated in the actual TransactionTemplate, but we are wrapping and
            //throwing them for testing purposes
            throw new RuntimeException(ex);
        }
    }

    /**
     * Returns the transaction status of the last callback execution.
     * @return true if the last execution was rollbacked, false otherwise.
     */
    public boolean isExecutionRollbacked() {
        return executionRollbacked;
    }
}
