/**
 * 
 */
package com.monsanto.barter.web.test;


import org.junit.Test;

/**
 * TODO Construcao da classe suspensa. Aguardando definicoes sobre os testes de unidade.
 * 
 * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
 * @since 29/11/2011
 * 
 */
public class UserFaces_UT extends AbstractWebTestClass {

    /**
     * 
     * @author Vitor Franco do Carmo (vitor.carmo@cpmbraxis.com)
     */
    public UserFaces_UT() {

        super();

//        setBaseUrl("http://localhost:8080/barter-web/pages/admin");
    }

    @Test
    public void searchUser() {

//        beginAt("user_search.jsf");
////        clickButton("formFiltro:btnSearch");
//        assertTextPresent("Unit");
    }
}
