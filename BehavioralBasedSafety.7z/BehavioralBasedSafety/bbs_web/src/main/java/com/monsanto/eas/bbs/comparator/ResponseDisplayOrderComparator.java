/*
 ResponseComparator was created on Feb 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.comparator;

import com.monsanto.eas.bbs.hibernate.LanguageBasedResponse;

import java.util.Comparator;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class ResponseDisplayOrderComparator implements Comparator<LanguageBasedResponse> {
  public int compare(LanguageBasedResponse o1, LanguageBasedResponse o2) {
    int order1 = o1.getId().getResponse().getDisplayOrder();
    int order2 = o2.getId().getResponse().getDisplayOrder();

    if (order1 > order2) {
      return 1;
    } else if (order1 < order2) {
      return -1;
    } else {
      return 0;
    }
  }
}