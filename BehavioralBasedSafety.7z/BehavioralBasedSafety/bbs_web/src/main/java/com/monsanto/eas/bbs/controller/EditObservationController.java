package com.monsanto.eas.bbs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 21/12/11
 * Time: 09:11 AM
 * To change this template use File | Settings | File Templates.
 */

@Controller
@RequestMapping("/editObservation")
public class EditObservationController extends SimpleFormController {

    public EditObservationController() {}

    @RequestMapping(method = RequestMethod.GET, value = "/editObservation")
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletRequestBindingException {
        String id = ServletRequestUtils.getStringParameter(request, "id");
        request.getSession().setAttribute("observationId", id);

        return new ModelAndView("observation/editObservation");
    }
}
