package com.monsanto.eas.bbs.controller;

import com.google.common.base.Splitter;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.service.UserService;
import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.List;

import static com.google.common.base.Strings.nullToEmpty;
import static com.google.common.collect.Lists.newArrayList;

public class ExcelReportParameters
{
    private static final Splitter SPLITTER = Splitter.on(",").omitEmptyStrings();

    private final String languageId;
    private final String languageDesc;
    private final String dateFormat;
    private final String dateFromStr;
    private final String dateToStr;
    private final String responseId;
    private final String responseDesc;
    private final String showDialogForResponse;
    private final String userId;
    private final String searchByCriteriaDescription;
    private final Iterable<String> countryIdList;
    private final Iterable<String> countryCodeList;
    private final Iterable<String> countryDescriptionList;
    private final Iterable<String> regionIdList;
    private final Iterable<String> regionDescriptionList;
    private final Iterable<String> plantIdList;
    private final Iterable<String> plantNameList;
    private final Iterable<String> categoryTypeIds;
    private final Language language;
    private final UserService userService;

    public ExcelReportParameters(HttpServletRequest request, UserService userService) {
        languageId = request.getParameter("languageId");
        languageDesc = request.getParameter("languageDesc");
        dateFormat = request.getParameter("dateFormat");
        dateFromStr = request.getParameter("dateFrom");
        dateToStr = request.getParameter("dateTo");
        responseId = request.getParameter("responseId");
        responseDesc = request.getParameter("responseDesc");
        showDialogForResponse = request.getParameter("showDialogForResponse");
        userId = request.getParameter("userId");
        searchByCriteriaDescription = request.getParameter("searchByDescription");
        countryIdList = split(request, "countryId");
        countryCodeList = split(request, "countryCode");
        countryDescriptionList = split(request, "countryDescription");
        regionIdList = split(request, "regionId");
        regionDescriptionList = split(request, "regionDescription");
        plantIdList = split(request, "plantId");
        plantNameList = split(request, "plantName1");
        categoryTypeIds = split(request, "categoryTypeIds");
        language = createLanguage();
        this.userService = userService;
    }
    
    private Iterable<String> split(HttpServletRequest request, String paramName) {
        return SPLITTER.split(nullToEmpty(request.getParameter(paramName)));
    }

    private Language createLanguage() {
        Language newLanguage = new Language();
        newLanguage.setId(new Long(languageId));
        newLanguage.setDescription(languageDesc);
        return newLanguage;
    }

    private BBSUser findUser() {
        BBSUser bbsUser = null;
        if (userId != null) {
            bbsUser = userService.findByUserID(userId);
        }
        return bbsUser;
    }

    public List<Country> getCountries() {
        List<Country> countries = newArrayList();
        final Iterator<String> countryCodeIterator = countryCodeList.iterator();
        final Iterator<String> countryDescriptionIterator = countryDescriptionList.iterator();
        for (String countryId : countryIdList) {
            Country country = new Country();
            country.setId(new Long(countryId));
            country.setCountryCode(countryCodeIterator.next());
            country.setDescription(countryDescriptionIterator.next());
            countries.add(country);
        }
        return countries;
    }

    public List<Region> getRegions() {
        List<Region> regions = newArrayList();
        final Iterator<String> regionDescriptionIterator = regionDescriptionList.iterator();
        for (String regionId : regionIdList) {
            Region region = new Region();
            region.setId(new Long(regionId));
            region.setDescription(regionDescriptionIterator.next());
            regions.add(region);
        }
        return regions;
    }

    public List<Plant> getPlants() {
        List<Plant> plants = newArrayList();
        final Iterator<String> plantNameIterator = plantNameList.iterator();
        for (String plantId : plantIdList) {
            Plant plant = new Plant();
            plant.setId(new Long(plantId));
            plant.setPlantName1(plantNameIterator.next());
            plants.add(plant);
        }
        return plants;
    }

    public List<LanguageCategoryType> getLanguageCategoryTypes() {
        List<LanguageCategoryType> languageCategoryTypeList = newArrayList();
        for (String currentCategorytypeId : categoryTypeIds) {
            LanguageCategoryType languageCategoryType = new LanguageCategoryType();
            languageCategoryType.setId(new LanguageCategoryTypePK());
            languageCategoryType.getId().setCategoryType(new CategoryType());
            languageCategoryType.getId().setLanguage(language);
            long categoryTypeId = Long.parseLong(currentCategorytypeId);
            languageCategoryType.getId().getCategoryType().setId(categoryTypeId);
            languageCategoryType.getId().getCategoryType().setDescription(com.monsanto.eas.bbs.util.report.enums.CategoryType.getById(categoryTypeId).getDescription());
            languageCategoryTypeList.add(languageCategoryType);
        }
        return languageCategoryTypeList;
    }

    public LanguageBasedResponse getLanguageBasedResponse() {
        LanguageBasedResponse languageBasedResponse = null;
        if (StringUtils.isNotBlank(responseId)) {
            languageBasedResponse = new LanguageBasedResponse();
            languageBasedResponse.setDescription(responseDesc);
            LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
            Response response = new Response();
            response.setId(new Long(responseId));
            response.setShowDialog(Boolean.valueOf(showDialogForResponse));
            pk.setResponse(response);
            languageBasedResponse.setId(pk);
        }
        return languageBasedResponse;
    }

    public ReportCriteria createReportCriteria() {
        ReportCriteria criteria = new ReportCriteria();
        criteria.setDateFormat(dateFormat);
        criteria.setLanguage(language);
        criteria.setLanguageCategoryTypeList(getLanguageCategoryTypes());
        criteria.setLanguageBasedResponse(getLanguageBasedResponse());
        criteria.setReportDateFrom(dateFromStr);
        criteria.setReportDateTo(dateToStr);
        setUser(criteria);
        setCountryList(criteria);
        setRegionList(criteria);
        setPlantList(criteria);
        return criteria;
    }

    private void setPlantList(ReportCriteria criteria) {
        if ("site".equals(searchByCriteriaDescription)) {
            criteria.setPlantList(getPlants());
            criteria.setSearchBySiteCriteria(true);
        }
    }

    private void setRegionList(ReportCriteria criteria) {
        if ("region".equals(searchByCriteriaDescription)) {
            criteria.setRegionList(getRegions());
            criteria.setSearchByRegionCriteria(true);
        }
    }

    private void setCountryList(ReportCriteria criteria) {
        if ("country".equals(searchByCriteriaDescription)) {
            criteria.setCountryList(getCountries());
            criteria.setSearchByCountryCriteria(true);
        }
    }

    private void setUser(ReportCriteria criteria) {
        BBSUser user = findUser();
        if (user != null) {
            criteria.setUser(user);
        }
    }
}
