package com.monsanto.eas.bbs.controller;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.bbs.util.opendocument.EnterpriseSession;
import com.monsanto.eas.bbs.util.opendocument.OpenDocumentConstants;
import com.monsanto.eas.bbs.util.opendocument.OpenDocumentPropertyFile;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Controller("openDocumentController")
public class OpenDocumentController {

    private static final int VALID_MINUTES = 120;
    private static final int VALID_NUM_OF_LOGONS = 100;
    private static final String CLIENT_COMPUTER_NAME = "";
    private static final String UNDEFINED_DOCUMENT_URL = "The document service URL is not defined for the environment : ";

    @Autowired
    private EnterpriseSession enterpriseSession;

    private static Log log = LogFactory.getLog(OpenDocumentController.class);

    private static OpenDocumentPropertyFile servPropFile = new OpenDocumentPropertyFile(OpenDocumentConstants.PROPERTIES_FILE_NAME);

    public OpenDocumentController(){}

    public OpenDocumentController(EnterpriseSession enterpriseSession){
        this.enterpriseSession = enterpriseSession;
    }

    @RequestMapping(method = {RequestMethod.GET}, value = {'/' + OpenDocumentConstants.EBO_REPORT_LINK})
    @SuppressWarnings("unchecked")
    public void openBOReport(HttpServletRequest request, HttpServletResponse response) throws IOException, EnvironmentHelperException, SDKException {

        log.info("Trying to log into the Crystal Enterprise server\n");

        IEnterpriseSession sess = enterpriseSession.connectToEBOCMSServer();
        final String token = sess.getLogonTokenMgr().createLogonToken(CLIENT_COMPUTER_NAME, VALID_MINUTES, VALID_NUM_OF_LOGONS);
        final String tokenEncode = URLEncoder.encode(token, "UTF-8");

        final String docUID = request.getParameter(OpenDocumentConstants.DOCUMENT_ID);
        if (StringUtils.isNullOrEmpty(docUID)) {
            log.error("Could not find the document UID for the EBO report\n");
            throw new OpenDocumentException("The document ID is not set in the request URL\n");
        }

        final String openDocumentServiceURL = servPropFile
                .getPropertyForSpecificEnvironment(OpenDocumentConstants.EBO_OPEN_DOCUMENT_URL);
        if (StringUtils.isNullOrEmpty(openDocumentServiceURL)) {
            log.error(UNDEFINED_DOCUMENT_URL + EnvironmentHelper.getPropertyPrefix());
            throw new OpenDocumentException(UNDEFINED_DOCUMENT_URL + EnvironmentHelper.getPropertyPrefix());
        }

        StringBuilder builder = new StringBuilder().append(openDocumentServiceURL).append(docUID)
                .append("&sIDType=CUID&token=").append(tokenEncode);
        response.sendRedirect(builder.toString());
        //  return builder.toString();
    }

    public void setEnterpriseSession(EnterpriseSession enterpriseSession) {
        this.enterpriseSession = enterpriseSession;
    }

    public static String getBO4ServiceLinkByEnvironment() {
        final String bo4Link = servPropFile
                .getPropertyForSpecificEnvironment(OpenDocumentConstants.EBO_SERVICE_URL);
        return bo4Link;
    }

}
