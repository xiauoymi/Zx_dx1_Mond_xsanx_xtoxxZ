package com.monsanto.eas.bbs.controller;

public class OpenDocumentException extends RuntimeException
{
    public OpenDocumentException() {
        super();
    }

    public OpenDocumentException(String message) {
        super(message);
    }

    public OpenDocumentException(String message, Throwable cause) {
        super(message, cause);
    }

    public OpenDocumentException(Throwable cause) {
        super(cause);
    }
}
