package com.monsanto.eas.bbs.controller;

import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.service.ObservationService;
import com.monsanto.eas.bbs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping(value = "/reportToExcel")
public class ReportExcelController extends AbstractController
{
    @Autowired
    private ObservationService observationService;

    @Autowired
    private UserService userService;

    public ReportExcelController() {
    }

    public ReportExcelController(ObservationService observationService) {
        this.observationService = observationService;
    }

    public ReportExcelController(ObservationService observationService, UserService userService) {
        this.observationService = observationService;
        this.userService = userService;
    }

    @RequestMapping(method = RequestMethod.POST)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
        ReportCriteria criteria = new ExcelReportParameters(request, userService).createReportCriteria();
        final List<Observation> observations = observationService.lookupObservations(criteria);
        ModelAndView modelAndView = new ModelAndView(new ReportExcelView(), new HashMap());
        modelAndView.addObject("observations", observations);
        modelAndView.addObject("reportCriteria", criteria);
        return modelAndView;
    }
}
