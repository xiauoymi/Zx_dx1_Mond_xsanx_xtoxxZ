package com.monsanto.eas.bbs.controller;

import com.google.common.base.Joiner;
import com.monsanto.eas.bbs.filter.BBSConstants;
import com.monsanto.eas.bbs.hibernate.CategoryObservation;
import com.monsanto.eas.bbs.hibernate.LanguageCategoryType;
import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.util.report.beans.Property;
import com.monsanto.eas.bbs.util.report.enums.Column;
import com.monsanto.eas.bbs.util.report.registries.ColumnsByCategoryType;
import com.monsanto.eas.bbs.util.report.registries.KeysByColumn;
import com.monsanto.eas.bbs.util.report.registries.PropertiesByColumn;
import org.apache.poi.hssf.usermodel.*;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static ch.lambdaj.Lambda.extract;
import static ch.lambdaj.Lambda.on;
import static com.monsanto.eas.bbs.util.ExcelUtils.addCell;
import static com.monsanto.eas.bbs.util.ExcelUtils.getCellStyle;

public class ReportExcelView extends AbstractExcelView {

    private static final int HEADER_COLOR = 0xc;
    private static final int INITIAL_CELL_NUMBER = 0;

    protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws IOException {

        List<Observation> observations = (List<Observation>) model.get("observations");
        ReportCriteria reportCriteria = (ReportCriteria) model.get("reportCriteria");
        HSSFSheet sheet = workbook.createSheet(BBSConstants.OBSERVATIONS);

        String dateFormat = reportCriteria.getDateFormat();
        dateFormat = dateFormat.replace('D', 'd');
        dateFormat = dateFormat.replace('Y', 'y');
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        int rowNum = 0;
        HSSFRow criteriaRow = sheet.createRow(rowNum);
        populateCriteriaHeaderRow(workbook, sheet, criteriaRow, request, reportCriteria);
        HSSFCellStyle headerCellStyle;

        rowNum++;
        HSSFRow criteriaDataRow = sheet.createRow(rowNum);
        populateCriteriaDataRow(reportCriteria, sheet, criteriaDataRow);

        headerCellStyle = getCellStyle(workbook, (short) 0x2);

        rowNum = rowNum + 2;
        HSSFRow headerRow = sheet.createRow(rowNum);

        ResourceBundle resourceBundle = getResourceBundle(request);

        SortedSet<Column> columns = new TreeSet<Column>();
        for (LanguageCategoryType languageCategoryType : reportCriteria.getLanguageCategoryTypeList()) {
            columns.addAll(ColumnsByCategoryType.getById(languageCategoryType.getId().getCategoryType().getId()));
        }

        int colIndex = 0;
        for (Column column : columns) {
            addCell(sheet, headerRow, headerCellStyle, resourceBundle.getString(KeysByColumn.get(column)), colIndex++);
        }

        for (Observation observation : observations) {
            for (CategoryObservation categoryObservation : observation.getCategoryObservations()) {
                rowNum++;
                colIndex = 0;
                HSSFRow dataRow = sheet.createRow(rowNum);
                for (Column column : columns) {
                    Property property = PropertiesByColumn.get(column);
                    Object value = property.getValueFor(categoryObservation);
                    String stringValue = (value == null)
                        ? null
                        : ((property.getType() == Date.class) ? sdf.format((Date) value) : value.toString())
                    ;
                    addCell(sheet, dataRow, null, stringValue, colIndex++);
                }
            }
        }

        for (colIndex = 0; colIndex < columns.size(); colIndex++) {
            sheet.autoSizeColumn((short) colIndex);
        }
    }

    private ResourceBundle getResourceBundle(HttpServletRequest request) {
        String locale = request.getParameter("locale");
        return ResourceBundle.getBundle("messages", new Locale(locale == null ? "en" : locale));
    }

    private void populateCriteriaDataRow(ReportCriteria reportCriteria, HSSFSheet sheet, HSSFRow criteriaDataRow) {
        int cellNumber = INITIAL_CELL_NUMBER;
        addCell(sheet, criteriaDataRow, null, reportCriteria.getLanguage().getDescription(), cellNumber++);
        addCell(sheet, criteriaDataRow, null, reportCriteria.getSearchCriteriaDescription(), cellNumber++);

        addCell(sheet, criteriaDataRow, null, reportCriteria.getReportDateFrom(), cellNumber++);
        addCell(sheet, criteriaDataRow, null, reportCriteria.getReportDateTo(), cellNumber++);

        String searchDescription = Joiner.on(", ").skipNulls().join(extract(reportCriteria.getLanguageCategoryTypeList(), on(LanguageCategoryType.class).getId().getCategoryType().getDescription()));
        addCell(sheet, criteriaDataRow, null, searchDescription, cellNumber++);
    }

    private void populateCriteriaHeaderRow(HSSFWorkbook workbook, HSSFSheet sheet, HSSFRow criteriaRow, HttpServletRequest request, ReportCriteria reportCriteria) {
        ResourceBundle resourceBundle = getResourceBundle(request);
        HSSFCellStyle headerCellStyle = getCellStyle(workbook, (short) HEADER_COLOR);
        int cellNumber = INITIAL_CELL_NUMBER;
        addCell(sheet, criteriaRow, headerCellStyle, resourceBundle.getString("language"), cellNumber++);
        addCell(sheet, criteriaRow, headerCellStyle, resourceBundle.getString(reportCriteria.getSearchCriteriaDescriptionHeader()), cellNumber++);
        addCell(sheet, criteriaRow, headerCellStyle, resourceBundle.getString("from"), cellNumber++);
        addCell(sheet, criteriaRow, headerCellStyle, resourceBundle.getString("to"), cellNumber++);
        addCell(sheet, criteriaRow, headerCellStyle, resourceBundle.getString("categoryType"), cellNumber++);
    }
}