/*
 AdminLinkController was created on Feb 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.controller.admin;

import com.monsanto.eas.bbs.controller.OpenDocumentController;
import com.monsanto.eas.bbs.filter.BBSConstants;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.util.opendocument.OpenDocumentConstants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Controller
@RequestMapping(value = "/admin")
public class AdminController extends AbstractController {

   @RequestMapping(method = RequestMethod.GET)
   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws IOException {
       HttpSession session = request.getSession();
       BBSUser bbsUser = (BBSUser) session.getAttribute(BBSConstants.BBS_USER);

      if (bbsUser.isESHAdmin() || bbsUser.isGlobalLead() || bbsUser.isEMEAAdmin()) {
         String view = request.getParameter(BBSConstants.VIEW);
         String bo4ServiceLink = OpenDocumentController.getBO4ServiceLinkByEnvironment();

         session.setAttribute("bo4ServiceLink", bo4ServiceLink);
         session.setAttribute("eboReportLink", OpenDocumentConstants.EBO_REPORT_LINK);
         return new ModelAndView("admin/" + view);
      } else {
         ((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN);
         return null;
      }
   }
}