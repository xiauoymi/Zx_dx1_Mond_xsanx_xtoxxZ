package com.monsanto.eas.bbs.controller.admin;

import com.google.common.base.CaseFormat;
import com.google.common.collect.Maps;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;

import java.util.Map;

import static com.monsanto.eas.bbs.util.ExcelUtils.addCell;

public enum LocaleBasedExcelColumnPairs
{
    ENGLISH    ( "en", Constants.ENGLISH_WOWK_AREA_INDEX,     Constants.ENGLISH_WORK_LOCATION_INDEX    ),
    FRENCH     ( "fr", Constants.FRENCH_WORK_AREA_INDEX,      Constants.FRENCH_WORK_LOCATION_INDEX     ),
    SPANISH    ( "es", Constants.SPANISH_WORK_AREA_INDEX,     Constants.SPANISH_WORK_LOCATION_INDEX    ),
    DUTCH      ( "nl", Constants.DUTCH_WORK_AREA_INDEX,       Constants.DUTCH_WORK_LOCATION_INDEX      ),
    PORTUGUESE ( "pt", Constants.PORTUGUESE_WORK_AREA_INDEX,  Constants.PORTUGUESE_WORK_LOCATION_INDEX ),
    TURKISH    ( "tr", Constants.TURKISH_WORK_AREA_INDEX,     Constants.TURKISH_WORK_LOCATION_INDEX    ),
    ITALIAN    ( "it", Constants.ITALIAN_WORK_AREA_INDEX,     Constants.ITALIAN_WORK_LOCATION_INDEX    ),
    ;

    private static final String WORK_AREA = " Work Area";
    private static final String WORK_LOCATION = " Work Location";

    private final String locale;
    private final int workAreaIndex;
    private final int workLocationIndex;
    private final String languageName;

    private LocaleBasedExcelColumnPairs(String locale, int workAreaIndex, int workLocationIndex) {
        this.locale = locale;
        this.workAreaIndex = workAreaIndex;
        this.workLocationIndex = workLocationIndex;
        this.languageName = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.toString());
    }

    private static final Map<String, LocaleBasedExcelColumnPairs> LOCALE_MAP = initLocaleMap();

    private static Map<String, LocaleBasedExcelColumnPairs> initLocaleMap() {
        Map<String, LocaleBasedExcelColumnPairs> localeMap = Maps.newHashMap();
        for (LocaleBasedExcelColumnPairs columnPair : values()) {
            localeMap.put(columnPair.getLocale(), columnPair);
        }
        return localeMap;
    }

    public static LocaleBasedExcelColumnPairs getByLanguage(Language language) {
        return LOCALE_MAP.get(language.getLocale().toLowerCase());
    }

    public static void createLanguageHeaders(HSSFSheet sheet, HSSFRow row, HSSFCellStyle headerCellStyle) {
        headerCellStyle.getWrapText();
        for (LocaleBasedExcelColumnPairs pair : values()) {
            addCell(sheet, row, headerCellStyle, pair.languageName + WORK_AREA, pair.workAreaIndex);
            addCell(sheet, row, headerCellStyle, pair.languageName + WORK_LOCATION, pair.workLocationIndex);
        }
    }

    public String getLocale() {
        return locale;
    }

    public void addHeaders(HSSFSheet sheet, HSSFRow row, HSSFCellStyle cellStyle) {
        addCell(sheet, row, cellStyle, languageName + WORK_AREA, workAreaIndex);
        addCell(sheet, row, cellStyle, languageName + WORK_LOCATION, workLocationIndex);
    }

    public void addAreaAndSubareaDescriptions(
        HSSFSheet sheet, HSSFRow row, LanguageBasedArea languageBasedArea, LanguageBasedArea languageBasedSubArea
    ){
        addCell(sheet, row, null, languageBasedArea.getDescription(), workAreaIndex);
        addCell(sheet, row, null, languageBasedSubArea.getDescription(), workLocationIndex);
    }

    private static final class Constants
    {
        private Constants() {}
        private static final int ENGLISH_WOWK_AREA_INDEX = 0;
        private static final int FRENCH_WORK_AREA_INDEX = 2;
        private static final int SPANISH_WORK_AREA_INDEX = 4;
        private static final int DUTCH_WORK_AREA_INDEX = 6;
        private static final int PORTUGUESE_WORK_AREA_INDEX = 8;
        private static final int TURKISH_WORK_AREA_INDEX = 10;
        private static final int ITALIAN_WORK_AREA_INDEX = 12;
        private static final int ENGLISH_WORK_LOCATION_INDEX = 1;
        private static final int FRENCH_WORK_LOCATION_INDEX = 3;
        private static final int SPANISH_WORK_LOCATION_INDEX = 5;
        private static final int DUTCH_WORK_LOCATION_INDEX = 7;
        private static final int PORTUGUESE_WORK_LOCATION_INDEX = 9;
        private static final int TURKISH_WORK_LOCATION_INDEX = 11;
        private static final int ITALIAN_WORK_LOCATION_INDEX = 13;
    }
}
