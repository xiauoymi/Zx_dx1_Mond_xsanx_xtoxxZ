package com.monsanto.eas.bbs.controller.admin;

import com.monsanto.eas.bbs.model.report.ExcelSheetProcessor;
import com.monsanto.eas.bbs.model.report.Property;
import com.monsanto.eas.bbs.model.report.Report;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static com.monsanto.eas.bbs.util.ExcelUtils.addCell;
import static com.monsanto.eas.bbs.util.ExcelUtils.getHeaderStyle;
import static java.lang.String.format;

public class ReportExcelView extends AbstractExcelView
{
    public static final String REPORT = "report";
    public static final String SHEET_PRE_PROCESSOR = "sheetPreProcessor";
    public static final String SHEET_POST_PROCESSOR = "sheetPostProcessor";

    protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
    {
        Report report = (Report) model.get(REPORT);

        if (report != null && !report.isEmpty())
        {
            HSSFSheet sheet = workbook.createSheet(report.getTitle());
            processSheet(SHEET_PRE_PROCESSOR, sheet, model);
            addHeader(sheet, report);
            addItems(sheet, report);
            addAdditionalFormatting(sheet, report);
            processSheet(SHEET_POST_PROCESSOR, sheet, model);
            setFileName(response, report);
        }
    }

    private void processSheet(String processorName, HSSFSheet sheet, Map model) {
        ExcelSheetProcessor processor = (ExcelSheetProcessor) model.get(processorName);
        if (processor != null) {
            processor.processSheet(sheet);
        }
    }

    private void addHeader(HSSFSheet sheet, Report report) {
        int colNumber = -1;
        HSSFCellStyle style = getHeaderStyle(sheet);
        HSSFRow headerRow = sheet.createRow(report.getHeaderRowIndex());
        for (Property property : report.getProperties()) {
            addCell(sheet, headerRow, style, property.getHeader(), ++colNumber);
        }
    }

    private void addItems(HSSFSheet sheet, Report report) {
        int rowNum = report.getHeaderRowIndex();
        for (Object item : report.getItems()) {
            int colNumber = -1;
            HSSFRow dataRow = sheet.createRow(++rowNum);
            for (Property property : report.getProperties()) {
                addCell(sheet, dataRow, null, property.valueFor(item), ++colNumber);
            }
        }
    }

    private void autoSizeColumns(HSSFSheet sheet, Report report) {
        for (Property property : report.getProperties()) {
            sheet.autoSizeColumn((short) (property.getOrder() - 1));
        }
    }

    private void addAdditionalFormatting(HSSFSheet sheet, Report report) {
        autoSizeColumns(sheet, report);
        int freezeRow = report.getHeaderRowIndex() + 1;
        sheet.createFreezePane(0, freezeRow, 0, freezeRow);
    }

    private void setFileName(HttpServletResponse response, Report report) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_'at'_hh-mm-a");
        response.setHeader(
            "Content-Disposition",
            format(
                "attachment; filename=\"%s_%s.xls\"",
                report.getTitle().replaceAll(" ", "_"),
                sdf.format(new Date())
            )
        );
    }

}