package com.monsanto.eas.bbs.controller.admin;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.model.SiteRptCriteria;
import com.monsanto.eas.bbs.service.UserService;
import com.monsanto.eas.bbs.service.report.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;

import static com.monsanto.eas.bbs.controller.admin.ReportExcelView.REPORT;

@Controller
@RequestMapping(value = "/siteBaseWorkAreaToExcel")
public class SiteBasedReportExcelController extends AbstractController
{
    @Autowired
    private UserService userService;

    @Autowired
    private ReportService reportService;

    @RequestMapping(method = RequestMethod.POST)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException
    {
        SiteRptCriteria criteria = buildReportCriteria(request);
        ModelAndView modelAndView = new ModelAndView(new ReportExcelView(), new HashMap());
        modelAndView.addObject(REPORT,
            reportService.lookupReport("workAreasAndWorkLocationsBySiteReport", criteria.getPlant()).setHeaderRowIndex(1)
        );
        WorkAreaReportUtil.addSheetProcessors(modelAndView);
        return modelAndView;
    }

    private SiteRptCriteria buildReportCriteria(HttpServletRequest request) throws ParseException {
        String languageId = request.getParameter("languageId");
        String languageDesc = request.getParameter("languageDesc");
        String plantId = request.getParameter("plantId");
        String plantName1 = request.getParameter("plantName1");
        String userId = request.getParameter("userId");

        Plant plant = new Plant();
        plant.setId(new Long(plantId));
        plant.setPlantName1(plantName1);
        Language language = new Language();
        language.setId(new Long(languageId));
        language.setDescription(languageDesc);

        BBSUser bbsUser = null;
        if (userId != null) {
            bbsUser = userService.findByUserID(userId);
        }

        final SiteRptCriteria rc = new SiteRptCriteria(language, plant);
        if (bbsUser != null) {
            rc.setUser(bbsUser);
        }

        return rc;
    }
}