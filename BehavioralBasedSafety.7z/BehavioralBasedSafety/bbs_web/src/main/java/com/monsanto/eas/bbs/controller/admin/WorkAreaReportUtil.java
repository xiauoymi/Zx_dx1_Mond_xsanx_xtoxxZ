package com.monsanto.eas.bbs.controller.admin;

import com.monsanto.eas.bbs.model.report.ExcelSheetProcessor;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.web.servlet.ModelAndView;

import static com.monsanto.eas.bbs.controller.admin.ReportExcelView.SHEET_POST_PROCESSOR;
import static com.monsanto.eas.bbs.controller.admin.ReportExcelView.SHEET_PRE_PROCESSOR;
import static com.monsanto.eas.bbs.util.ExcelUtils.addCell;
import static com.monsanto.eas.bbs.util.ExcelUtils.getHeaderStyle;

public final class WorkAreaReportUtil
{
    private static final int TOTAL_COLUMNS = 14;
    private static final int INITIAL_COLUMN = -2;

    private WorkAreaReportUtil() {}

    public static void addSheetProcessors(ModelAndView modelAndView) {
        modelAndView.addObject(SHEET_PRE_PROCESSOR, new ExcelSheetProcessor() {
            @Override
            public void processSheet(HSSFSheet sheet) {
                HSSFCellStyle style = getHeaderStyle(sheet);
                HSSFRow headerRow = sheet.createRow(0);
                String[] languageHeaders = new String[] {"English", "French", "Spanish", "Dutch", "Portuguese", "Turkish", "Italian"};
                int colNumber = INITIAL_COLUMN;
                for (String languageName : languageHeaders) {
                    colNumber += 2;
                    addCell(sheet, headerRow, style, languageName, colNumber);
                    sheet.addMergedRegion(new CellRangeAddress(0, 0, colNumber, colNumber + 1));
                }
            }
        });

        modelAndView.addObject(SHEET_POST_PROCESSOR, new ExcelSheetProcessor() {
            @Override
            public void processSheet(HSSFSheet sheet) {
                int maxWidth = sheet.getColumnWidth(0);
                for (int colIndex = 0; colIndex < TOTAL_COLUMNS; colIndex++) {
                    int currentWidth = sheet.getColumnWidth(colIndex);
                    if (currentWidth > maxWidth) {
                        maxWidth = currentWidth;
                    }
                }
                for (int colIndex = 0; colIndex < TOTAL_COLUMNS; colIndex++) {
                    sheet.setColumnWidth(colIndex, maxWidth);
                }
            }
        });
    }
}
