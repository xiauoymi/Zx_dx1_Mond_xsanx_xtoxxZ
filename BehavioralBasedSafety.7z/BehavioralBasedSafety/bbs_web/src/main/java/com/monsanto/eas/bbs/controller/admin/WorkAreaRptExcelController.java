package com.monsanto.eas.bbs.controller.admin;

import com.monsanto.eas.bbs.service.report.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

import static com.monsanto.eas.bbs.controller.admin.ReportExcelView.REPORT;

@Controller
@RequestMapping(value = "/workAreaToExcel")
public class WorkAreaRptExcelController extends AbstractController
{
    @Autowired
    private ReportService reportService;

    public WorkAreaRptExcelController() {
    }

    public WorkAreaRptExcelController(ReportService reportService) {
        this.reportService = reportService;
    }

    @RequestMapping(method = RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        ModelAndView modelAndView = new ModelAndView(new ReportExcelView(), new HashMap());
        modelAndView.addObject(REPORT,
            reportService.lookupReport("workAreasAndWorkLocationsReport", null).setHeaderRowIndex(1)
        );
        WorkAreaReportUtil.addSheetProcessors(modelAndView);
        return modelAndView;
    }

}