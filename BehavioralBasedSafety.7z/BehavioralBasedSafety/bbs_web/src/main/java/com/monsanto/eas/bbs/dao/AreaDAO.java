/*
 Area was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Transactional
public interface AreaDAO {

    void saveOrUpdateArea(Area area);

    //Area lookupArea(String areaDescription, Language language);

    //Area lookupSubArea(Area area, String subAreaDescription, Language language);

    Area lookupAreaById(Long id);

    List<Area> lookupAllParentAreas();

    List<Area> lookupSubAreas(Area area);

    void addPlantArea(Plant plant, Area area);

    void deletePlantArea(Plant plant, Area area);

}