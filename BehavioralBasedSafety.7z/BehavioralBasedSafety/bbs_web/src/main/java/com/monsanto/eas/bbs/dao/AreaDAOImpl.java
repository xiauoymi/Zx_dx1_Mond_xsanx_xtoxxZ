package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.PlantArea;
import com.monsanto.eas.bbs.hibernate.PlantAreaPk;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AreaDAOImpl extends HibernateDaoSupport implements AreaDAO {

    private static final String PARENT_AREA_ID = "parentArea.id";

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    public void saveOrUpdateArea(Area area) {
        getHibernateTemplate().saveOrUpdate(area);
    }

    public Area lookupAreaById(Long id) {
        Criteria areaCriteria = getCurrentSession().createCriteria(Area.class);
        areaCriteria.add(Restrictions.eq("id", id));
        return (Area) areaCriteria.uniqueResult();
    }

    public List<Area> lookupAllParentAreas() {
        Criteria criteria = getCurrentSession().createCriteria(Area.class);
        criteria.add(Restrictions.isNull(PARENT_AREA_ID));
        return criteria.list();
    }

    public List<Area> lookupSubAreas(Area area) {
        Criteria criteria = getCurrentSession().createCriteria(Area.class);
        criteria.add(Restrictions.eq("active", true));
        criteria.add(Restrictions.eq(PARENT_AREA_ID, area.getId()));
        return criteria.list();
    }

    public void addPlantArea(Plant plant, Area area) {
        saveOrUpdateArea(area);

        PlantArea plantArea = new PlantArea();
        PlantAreaPk pk = new PlantAreaPk();
        pk.setArea(area);
        pk.setPlant(plant);
        plantArea.setId(pk);
        getHibernateTemplate().saveOrUpdate(plantArea);
    }

    public void deletePlantArea(Plant plant, Area area) {
        PlantArea plantArea = new PlantArea();
        PlantAreaPk pk = new PlantAreaPk();
        pk.setArea(area);
        pk.setPlant(plant);
        plantArea.setId(pk);
        getHibernateTemplate().delete(plantArea);
    }

}