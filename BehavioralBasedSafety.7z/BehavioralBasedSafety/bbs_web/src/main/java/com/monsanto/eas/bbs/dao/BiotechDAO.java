package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 20/06/12
 * Time: 10:19 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface BiotechDAO {

    void addBiotechProgram(BiotechProgram biotechProgram);
    void addBiotechProjectPlatform(BiotechProjectPlatform biotechProjectPlatform);

    List<BiotechProgram> getAllBiotechPrograms();
    List<BiotechProjectPlatform> getAllBiotechProjects();

    List<BiotechProgram> lookupBiotechProgramsForPlant(Plant plant);

    List<BiotechProjectPlatform> lookupBiotechProjectsForProgram(BiotechProgram biotechProgram);
}
