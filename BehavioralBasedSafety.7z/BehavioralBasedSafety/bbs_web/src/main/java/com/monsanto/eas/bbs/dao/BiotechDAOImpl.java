package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 20/06/12
 * Time: 11:31 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class BiotechDAOImpl extends HibernateDaoSupport implements BiotechDAO {

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }


    public void addBiotechProgram(BiotechProgram biotechProgram) {
        getHibernateTemplate().saveOrUpdate(biotechProgram);
    }

    public void addBiotechProjectPlatform(BiotechProjectPlatform biotechProjectPlatform) {
        getHibernateTemplate().saveOrUpdate(biotechProjectPlatform);
    }

    public List<BiotechProgram> getAllBiotechPrograms() {
        DetachedCriteria criteria = DetachedCriteria.forClass(BiotechProgram.class);
        criteria.addOrder(Order.asc("plantCode"));
        return (List<BiotechProgram>) getHibernateTemplate().findByCriteria(criteria);
    }

    public List<BiotechProjectPlatform> getAllBiotechProjects() {
        DetachedCriteria criteria = DetachedCriteria.forClass(BiotechProjectPlatform.class);
        return (List<BiotechProjectPlatform>) getHibernateTemplate().findByCriteria(criteria);
    }

    public List<BiotechProgram> lookupBiotechProgramsForPlant(Plant plant) {
        Query query = getSessionFactory().getCurrentSession().createQuery("from BiotechProgram where plantCode = :pltCode order by program");
        query.setParameter("pltCode", plant.getPlantCode());
        List<BiotechProgram> biotechProgramListTmp = query.list();

        return biotechProgramListTmp;
    }

    public List<BiotechProjectPlatform> lookupBiotechProjectsForProgram(BiotechProgram biotechProgram) {
        Query query = getSessionFactory().getCurrentSession().createQuery("from BiotechProjectPlatform where biotechProgram.id = :programId order by projectDescription");
        query.setParameter("programId", biotechProgram.getId());
        List<BiotechProjectPlatform> biotechProjectPlatformList = query.list();

        return biotechProjectPlatformList;
    }
}
