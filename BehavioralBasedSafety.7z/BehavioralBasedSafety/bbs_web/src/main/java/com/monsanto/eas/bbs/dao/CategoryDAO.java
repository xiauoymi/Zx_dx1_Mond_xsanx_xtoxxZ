/*
 CategoryType was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Transactional
public interface CategoryDAO {

   void saveOrUpdateCategory(Category category);

   void deleteCategory(Category category);

   List<Category> lookupSubCategoriesForCategory(Category category);

   List<LanguageBasedCategory> lookupAllLanguageCategories();

   List<LanguageBasedCategory> lookupAllLanguageCategories(Language language);

   List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType, boolean onlyActiveCategories);

   List<LanguageBasedCategory> lookupAllSubCategoriesForACategory(Language language, Category parentCategory, boolean onlyActiveCategories);

   LanguageBasedCategory lookupLanguageBasedCategoryByDescriptionAndType(String catDescription, Language language, CategoryType categoryType);

   LanguageBasedCategory lookupLanguageBasedSubCategoryByDescriptionAndType(String catDescription,
                                                                            Category parentCategory,
                                                                            Language language,
                                                                            CategoryType categoryType);

   void saveLanguageBasedCategory(LanguageBasedCategory languageBasedCategory);


   void saveLanguageBarrierCategory(LanguageBarrierCategory languageBarrierCategory);

   LanguageBarrierCategory lookupLanguageBarrierByDescriptionAndCategory(String barrierDescription, Language language, Category category);

   List<LanguageBarrierCategory> lookupLanguageBarriers();

   List<LanguageBarrierCategory> lookupLanguageBarriers(Language language);


   List<LanguageCategoryType> lookupLanguageCategoryTypes(Language language);
   void saveOrUpdateLanguageCategoryType(LanguageCategoryType languageCategoryType);
}