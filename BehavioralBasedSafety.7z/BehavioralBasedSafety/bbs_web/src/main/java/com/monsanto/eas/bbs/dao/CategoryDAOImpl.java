/*
 CategoryTypeDAOImpl was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CategoryDAOImpl extends HibernateDaoSupport implements CategoryDAO {

   private static final String ACTIVE = "active";
   private static final String PARENT_CATEGORY_ID = "parentCategory.id";
   private static final String LOCALE = "locale";
   private static final String ID_LANGUAGE = "id.language";
   private static final String PARENT_CATEGORY = "parentCategory";
   private static final String CATEGORY_TYPE_ID = "categoryType.id";
   private static final String ID_CATEGORY = "id.category";
   private static final String DESCRIPTION = "description";

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

   public void saveOrUpdateCategory(Category category) {
      getHibernateTemplate().saveOrUpdate(category);
   }

   public void deleteCategory(Category category) {
      getHibernateTemplate().delete(category);
   }

   public List<Category> lookupSubCategoriesForCategory(Category category) {
      Criteria criteria = getCurrentSession().createCriteria(Category.class);
      criteria.add(Restrictions.eq(ACTIVE, true));
      criteria.add(Restrictions.eq(PARENT_CATEGORY_ID, category.getId()));
      return criteria.list();
   }

   public List<LanguageBasedCategory> lookupAllLanguageCategories() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq(LOCALE, "en"));
      Language language = (Language) DataAccessUtils.uniqueResult(getHibernateTemplate().findByCriteria(criteria));
      return lookupAllLanguageCategories(language);
   }

   public List<LanguageBasedCategory> lookupAllLanguageCategories(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      return criteria.list();
   }

   public List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType, boolean onlyActiveCategories) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Category.class);

      if (onlyActiveCategories) {
         areaCriteria.add(Restrictions.eq(ACTIVE, true));
      }

      areaCriteria.setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.isNull(PARENT_CATEGORY));
      areaCriteria.add(Restrictions.eq(CATEGORY_TYPE_ID, categoryType.getId()));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_CATEGORY, areaCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.list();
   }

   public List<LanguageBasedCategory> lookupAllSubCategoriesForACategory(Language language, Category parentCategory, boolean onlyActiveCategories) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq(PARENT_CATEGORY_ID, parentCategory.getId()));

      if (onlyActiveCategories) {
         categoryCriteria.add(Restrictions.eq(ACTIVE, true));
      }

      categoryCriteria.setProjection(Property.forName("id"));

      //join based on the language.L
      Criteria criteria = getSessionFactory().getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyIn(ID_CATEGORY, categoryCriteria));
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.list();
   }

   public LanguageBasedCategory lookupLanguageBasedCategoryByDescriptionAndType(String catDescription, Language language,
                                                                                CategoryType categoryType) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.isNull(PARENT_CATEGORY));
      categoryCriteria.add(Restrictions.eq(CATEGORY_TYPE_ID, categoryType.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_CATEGORY, categoryCriteria));
      criteria.add(Restrictions.eq(DESCRIPTION, catDescription).ignoreCase());
      LanguageBasedCategory lbc = (LanguageBasedCategory) criteria.uniqueResult();
      return lbc == null ? null : lbc;
   }

   public LanguageBasedCategory lookupLanguageBasedSubCategoryByDescriptionAndType(String catDescription,
                                                                                   Category parentCategory,
                                                                                   Language language,
                                                                                   CategoryType categoryType) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq(PARENT_CATEGORY_ID, parentCategory.getId()));
      categoryCriteria.add(Restrictions.eq(CATEGORY_TYPE_ID, categoryType.getId()))
              .setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_CATEGORY, categoryCriteria));
      criteria.add(Restrictions.eq(DESCRIPTION, catDescription).ignoreCase());
      LanguageBasedCategory lbc = (LanguageBasedCategory) criteria.uniqueResult();
      return lbc == null ? null : lbc;
   }

   public void saveLanguageBasedCategory(LanguageBasedCategory languageBasedCategory) {
      saveOrUpdateCategory(languageBasedCategory.getId().getCategory());
      getHibernateTemplate().saveOrUpdate(languageBasedCategory);
   }



   public void saveLanguageBarrierCategory(LanguageBarrierCategory languageBarrierCategory) {
      getHibernateTemplate().saveOrUpdate(languageBarrierCategory.getId().getBarrierCategory());
      getHibernateTemplate().saveOrUpdate(languageBarrierCategory);
   }

   public LanguageBarrierCategory lookupLanguageBarrierByDescriptionAndCategory(String barrierDescription,
                                                                                Language language, Category category) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq("id", category.getId())).setProjection(Property.forName("id"));

      DetachedCriteria barrierToCategoryCriteria = DetachedCriteria.forClass(BarrierCategory.class);
      barrierToCategoryCriteria.add(Subqueries.propertyEq("category", categoryCriteria))
              .setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBarrierCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn("id.barrierCategory", barrierToCategoryCriteria));
      criteria.add(Restrictions.eq(DESCRIPTION, barrierDescription).ignoreCase());

      LanguageBarrierCategory lbc = (LanguageBarrierCategory) criteria.uniqueResult();
      return lbc == null ? null : lbc;
   }

   public List<LanguageBarrierCategory> lookupLanguageBarriers() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq(LOCALE, "en"));
      Language language = (Language) DataAccessUtils.uniqueResult(getHibernateTemplate().findByCriteria(criteria));
      return lookupLanguageBarriers(language);
   }

   public List<LanguageBarrierCategory> lookupLanguageBarriers(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBarrierCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      return criteria.list();
   }



   public List<LanguageCategoryType> lookupLanguageCategoryTypes(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryTypeCriteria = DetachedCriteria.forClass(CategoryType.class);
      categoryTypeCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageCategoryType.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn("id.categoryType", categoryTypeCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.list();
   }

   public void saveOrUpdateLanguageCategoryType(LanguageCategoryType languageCategoryType) {
      getHibernateTemplate().saveOrUpdate(languageCategoryType);
   }

}
