package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.CategoryObservation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 4/01/12
 * Time: 05:13 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface CategoryObservationDAO {

    void deleteCategoryObservation(CategoryObservation categoryObservation);

    void deleteCategoryObservationInNAStatus(List<CategoryObservation> categoryObservations);
}
