package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.CategoryObservation;
import com.monsanto.eas.bbs.hibernate.GenericHibernateDAO;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 4/01/12
 * Time: 05:15 PM
 * To change this template use File | Settings | File Templates.
 */

@Repository
public class CategoryObservationDAOImpl extends GenericHibernateDAO<CategoryObservation, Long> implements CategoryObservationDAO {

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    public void deleteCategoryObservation(CategoryObservation categoryObservation) {
        getHibernateTemplate().delete(categoryObservation);
    }

    public void deleteCategoryObservationInNAStatus(List<CategoryObservation> categoryObservationsCollection) {

        for (CategoryObservation categoryObservation : categoryObservationsCollection) {
            if( categoryObservation.getResponse() != null ) {
                boolean responseIsDefaultOption = categoryObservation.getResponse().isDefaultOption();
                if ( responseIsDefaultOption ) {
                    deleteCategoryObservation(categoryObservation);
                }
            }
        }

    }
}
