package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Region;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 21, 2010
 * Time: 4:16:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface CountryDAO {

    void addCountry(Country country);

    void deleteCountry(Country country);

    void activateInactivateEnvironmentalTabByRegion(Region region, boolean activeFlag);

    void activateInactivateEnvironmentalTabByCountry(Country country, boolean activeFlag);

    Country lookupCountryByCountryCode(String countryCode);

    List<Country> lookupActiveCountries();

    List<Country> lookupActiveCountriesWithValidRegionID();

    List<Country> lookupActiveCountriesByRegionID(Long[] regionId);

    List<Country> lookupActiveCountriesByRegionIDAndByUserRole(String selectedRegionIds, BBSUser loggedInUser, String userOwnsRegionDesc);
}
