/*
 PlantDAOImpl was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Region;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author VRBEHTI
 * @version $Revision$
 */
@Repository
public class CountryDAOImpl extends HibernateDaoSupport implements CountryDAO {

    private static final String ACTIVE = "active";
    private static final String REGION_ID = "regionId";
    private static final String DESCRIPTION = "description";

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    public void addCountry(Country country) {
        getHibernateTemplate().save(country);
    }

    public void deleteCountry(Country country) {
        getHibernateTemplate().delete(country);
    }

    public void activateInactivateEnvironmentalTabByRegion(Region region, boolean activeFlag) {
        StringBuilder sqlQuery = new StringBuilder();
        sqlQuery.append("UPDATE BBS.country ")
                .append("SET show_condition_tab = '").append(activeFlag ? "Y" : "N").append("' ")
                .append("WHERE id IN ( SELECT id FROM BBS.country ")
                .append("              WHERE region_id = ").append(region.getId())
                .append(")");

        final SQLQuery query = this.getCurrentSession().createSQLQuery(sqlQuery.toString());
        query.executeUpdate();
    }

    public void activateInactivateEnvironmentalTabByCountry(Country country, boolean activeFlag) {
        country.setShowEnvironmentTab(activeFlag);
        getHibernateTemplate().saveOrUpdate(country);
    }


    public Country lookupCountryByCountryCode(String countryCode) {
        Query query = getCurrentSession().createQuery("from Country where countryCode = :countryCode");
        query.setParameter("countryCode", countryCode);

        return (Country) query.uniqueResult();
    }


    public List<Country> lookupActiveCountries() {
        DetachedCriteria criteria = DetachedCriteria.forClass(Country.class);
        criteria.add(Restrictions.eq(ACTIVE, true));
        return getHibernateTemplate().findByCriteria(criteria);
    }

    public List<Country> lookupActiveCountriesWithValidRegionID() {
        DetachedCriteria criteria = DetachedCriteria.forClass(Country.class);
        criteria.add(Restrictions.eq(ACTIVE, true));
        criteria.add(Restrictions.isNotNull(REGION_ID));
        criteria.addOrder(Order.asc(DESCRIPTION));
        return getHibernateTemplate().findByCriteria(criteria);
    }

    public List<Country> lookupActiveCountriesByRegionID(Long[] regionId) {
        DetachedCriteria criteria = DetachedCriteria.forClass(Country.class);
        criteria.add(Restrictions.eq(ACTIVE, true));
        criteria.add(Restrictions.isNotNull(REGION_ID));
        criteria.add(Restrictions.in(REGION_ID, regionId));
        criteria.addOrder(Order.asc(DESCRIPTION));
        return getHibernateTemplate().findByCriteria(criteria);
    }

    public List<Country> lookupActiveCountriesByRegionIDAndByUserRole(String regionId, BBSUser loggedInUser, String userOwnsRegionDesc) {

        Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
        Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
        Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

        //--If the user is a ESH Admin, based on EMEA region or
        //--If the user in not an ESH Admin, nor a EMEA Admin, nor a Global Lead, then selects only her own site
        StringBuilder activeCountriesByRegionIDAndByUserRoleQry = new StringBuilder("Select * From ( ")
                .append("Select * From BBS.Country ctr Where region_Id IN ( ").append(regionId).append(") ")
                .append(" AND ctr.active = 'Y' ")
                .append(" AND ctr.region_id is not null ");

        if (!userIsGlobalLead && !userIsEMEAAdmin && "EMEA".equals(userOwnsRegionDesc))
        {
            //---If Users own region is EMEA, then the user knows the region Id for this
            Long emeaRegionId = loggedInUser.getPlant().getCountry().getRegionId();

            if (userIsESHAdmin) {
                if (selectedRegionListContainsEMEARegion(regionId, emeaRegionId)) {
                    activeCountriesByRegionIDAndByUserRoleQry.append(" MINUS ")
                            .append(" Select * From BBS.Country ctr2 Where region_Id = ").append(String.valueOf(emeaRegionId))
                            .append(" AND ctr2.active = 'Y' ")
                            .append(" AND ctr2.id <>  ").append(loggedInUser.getPlant().getCountry().getId());
                }
            } else {
                activeCountriesByRegionIDAndByUserRoleQry.append(" AND ctr.id = ").append(loggedInUser.getPlant().getCountry().getId());
            }
        }

        activeCountriesByRegionIDAndByUserRoleQry.append(") order by description");

        return (List<Country>) this.getCurrentSession()
                .createSQLQuery(activeCountriesByRegionIDAndByUserRoleQry.toString())
                .addEntity(Country.class)
                .list();
    }

    private boolean selectedRegionListContainsEMEARegion(String regionId, final Long emeaRegionId) {
        boolean isEMEARegionPartOfTheRegionList = false;

        Pattern p = Pattern.compile("[,]*\\s*" + emeaRegionId + "\\s*[,]*");
        Matcher m = p.matcher(regionId);

        if (m.find()) {
            isEMEARegionPartOfTheRegionList = true;
        }

        return isEMEARegionPartOfTheRegionList;
    }

}