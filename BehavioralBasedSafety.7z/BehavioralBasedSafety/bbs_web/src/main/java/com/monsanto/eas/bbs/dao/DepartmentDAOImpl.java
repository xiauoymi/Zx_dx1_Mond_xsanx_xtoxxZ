/*
 DepartmentDAOImpl was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Department;
import com.monsanto.eas.bbs.hibernate.GenericHibernateDAO;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Repository
public class DepartmentDAOImpl extends GenericHibernateDAO<Department, Long> implements DepartmentDAO {

    private static final String ACTIVE = "active";

    @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   public Department lookupDepartmentByCode(Long code) {
      DetachedCriteria criteria = DetachedCriteria.forClass(Department.class)
              .add(Restrictions.eq(ACTIVE, true))
              .add(Restrictions.eq("code", code));
      List results = this.getHibernateTemplate().findByCriteria(criteria, 0, 1);
      return results.isEmpty() ? null : (Department) results.get(0);
   }

   public List<Department> lookupDepartmentsByCompanyFlag(boolean isCompany, boolean active) {
      DetachedCriteria criteria = DetachedCriteria.forClass(Department.class)
              .add(Restrictions.eq(ACTIVE, active))
              .add(Restrictions.eq("company", isCompany));
      criteria.addOrder(Order.asc("name"));
      return this.getHibernateTemplate().findByCriteria(criteria);
   }

   public List<Department> lookupAllDepartments() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Department.class)
              .add(Restrictions.eq(ACTIVE, true));
      return this.getHibernateTemplate().findByCriteria(criteria);
   }

    public Map<Long, Department> getMapOfAllDepartments() {
        Map<Long, Department> map = new HashMap<Long, Department>();
        List<Department> departments = lookupAllDepartments();
        for (Department department : departments) {
            map.put(department.getCode(), department);
        }
        return map;
    }

}