package com.monsanto.eas.bbs.dao;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Mar 16, 2010
 * Time: 4:05:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GenericDAO<T, ID extends Serializable> {
  void save(T entity);

  void delete(T entity);
}
