package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 11/10/13
 * Time: 12:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface LanguageBasedAreaDAO {

   void addLanguageBasedArea(LanguageBasedArea languageBasedArea);

   void saveLanguageBasedArea(LanguageBasedArea lba);

   LanguageBasedArea lookupLanguageBasedArea(String areaDescription, Language language);

   LanguageBasedArea lookupLanguageBasedArea(Area area, Language language);

   LanguageBasedArea lookupLanguageBasedSubArea(String subAreaDescription, Area area, Language language);

   List<LanguageBasedArea> lookupLanguageBasedAreas(Plant plant, Language language, boolean activeFlagForArea);

   List<LanguageBasedArea> lookupSubAreasForAnArea(Area area, Plant plant, Language language, boolean activeFlagForSubArea);

   List<LanguageBasedArea> lookupAvailableAreasForPlant(Plant plant, Language language);

   List<LanguageBasedArea> lookupAvailableSubAreasForPlant(Area parentArea, Plant plant, Language language);

   List<LanguageBasedArea> lookupAllSubAreasByAreaAndLanguage(Area area, Language language);

   List<LanguageBasedArea> lookupLanguageBasedAreasWithInactiveSubAreas(Language language);

   List<LanguageBasedArea> lookupAllAreas();

   List<LanguageBasedArea> lookupAllAreas(Language language);

   List<LanguageBasedArea> lookupAllParentAreasByLanguage(Language language);
}
