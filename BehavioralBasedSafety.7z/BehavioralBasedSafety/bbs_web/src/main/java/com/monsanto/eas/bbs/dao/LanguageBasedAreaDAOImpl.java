package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 11/10/13
 * Time: 12:57 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class LanguageBasedAreaDAOImpl extends HibernateDaoSupport implements LanguageBasedAreaDAO {

   private static final String PARENT_AREA = "parentArea";
   private static final String ID_LANGUAGE = "id.language";
   private static final String DESCRIPTION = "description";
   private static final String ID_AREA = "id.area";
   private static final String PARENT_AREA_ID = "parentArea.id";
   private static final String ACTIVE = "active";
   private static final String ID_PLANT_ID = "id.plant.id";
   private static final String ID_AREA_ID = "id.area.id";

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

   public void addLanguageBasedArea(LanguageBasedArea languageBasedArea) {
      getHibernateTemplate().saveOrUpdate(languageBasedArea);
   }

   public void saveLanguageBasedArea(LanguageBasedArea lba) {
      //saveOrUpdateArea(lba.getId().getArea());

      getHibernateTemplate().saveOrUpdate(lba.getId().getArea());

      getHibernateTemplate().saveOrUpdate(lba);
   }


   public LanguageBasedArea lookupLanguageBasedArea(String areaDescription, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.isNull(PARENT_AREA)).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Restrictions.eq(DESCRIPTION, areaDescription).ignoreCase());
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));

      LanguageBasedArea languageBasedArea = (LanguageBasedArea) criteria.uniqueResult();
      return languageBasedArea == null ? null : languageBasedArea;
   }

   public LanguageBasedArea lookupLanguageBasedArea(Area area, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq("id", area.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));

      LanguageBasedArea languageBasedArea = (LanguageBasedArea) criteria.uniqueResult();
      return languageBasedArea == null ? null : languageBasedArea;
   }

   public LanguageBasedArea lookupLanguageBasedSubArea(String subAreaDescription, Area area, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(PARENT_AREA_ID, area.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Restrictions.eq(DESCRIPTION, subAreaDescription).ignoreCase());
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      LanguageBasedArea languageBasedArea = (LanguageBasedArea) criteria.uniqueResult();
      return languageBasedArea == null ? null : languageBasedArea;
   }

   public List<LanguageBasedArea> lookupLanguageBasedAreas(Plant plant, Language language, boolean activeFlagForArea) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, activeFlagForArea)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.isNull(PARENT_AREA));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      if (plant == null) {
         criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      } else {
         DetachedCriteria plantAreaCriteria = DetachedCriteria.forClass(PlantArea.class);
         plantAreaCriteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
         plantAreaCriteria.add(Restrictions.eq(ID_PLANT_ID, plant.getId()));
         criteria.add(Subqueries.propertyIn(ID_AREA, plantAreaCriteria.setProjection(Property.forName(ID_AREA))));
         criteria.addOrder(Order.asc(ID_AREA_ID));
      }
      return criteria.list();
   }

   public List<LanguageBasedArea> lookupSubAreasForAnArea(Area parentArea, Plant plant, Language language, boolean activeFlagForSubArea) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, activeFlagForSubArea)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.eq(PARENT_AREA_ID, parentArea.getId()));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));

      if (plant == null) {
         criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      } else {
         DetachedCriteria plantAreaCriteria = DetachedCriteria.forClass(PlantArea.class);
         plantAreaCriteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
         plantAreaCriteria.add(Restrictions.eq(ID_PLANT_ID, plant.getId()));
         criteria.add(Subqueries.propertyIn(ID_AREA, plantAreaCriteria.setProjection(Property.forName(ID_AREA))));
      }
      return criteria.list();
   }

   public List<LanguageBasedArea> lookupAvailableAreasForPlant(Plant plant, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.isNull(PARENT_AREA));

      DetachedCriteria plantAreaCriteria = DetachedCriteria.forClass(PlantArea.class);
      plantAreaCriteria.add(Restrictions.eq(ID_PLANT_ID, plant.getId()));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      return criteria
              .add(Subqueries.propertyNotIn(ID_AREA, plantAreaCriteria.setProjection(Property.forName(ID_AREA)))).list();
   }

   public List<LanguageBasedArea> lookupAvailableSubAreasForPlant(Area parentArea, Plant plant, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria plantAreaCriteria = DetachedCriteria.forClass(PlantArea.class);
      plantAreaCriteria.add(Restrictions.eq(ID_PLANT_ID, plant.getId()));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.eq(PARENT_AREA_ID, parentArea.getId()));
      areaCriteria.add(Subqueries.propertyNotIn("id", plantAreaCriteria.setProjection(Property.forName(ID_AREA))));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria.setProjection(Property.forName("id"))));

      return criteria.list();
   }

   public List<LanguageBasedArea> lookupAllSubAreasByAreaAndLanguage(Area area, Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.eq(PARENT_AREA_ID, area.getId()));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      criteria.addOrder(Order.asc(ID_AREA_ID));

      return criteria.list();
   }

   public List<LanguageBasedArea> lookupLanguageBasedAreasWithInactiveSubAreas(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria test = DetachedCriteria.forClass(Area.class);
      test.add(Restrictions.eq(ACTIVE, false)).setProjection(Property.forName(PARENT_AREA_ID));
      test.add(Restrictions.isNotNull(PARENT_AREA));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.isNull(PARENT_AREA));
      areaCriteria.add(Subqueries.propertyIn("id", test));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      return criteria.list();
   }

   public List<LanguageBasedArea> lookupAllAreas() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq("locale", "en"));
      Language language = (Language) DataAccessUtils.uniqueResult(getHibernateTemplate().findByCriteria(criteria));
      return lookupAllAreas(language);
   }

   public List<LanguageBasedArea> lookupAllAreas(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      return criteria.list();
   }

   public List<LanguageBasedArea> lookupAllParentAreasByLanguage(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
      areaCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      areaCriteria.add(Restrictions.isNull(PARENT_AREA));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedArea.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));

      criteria.add(Subqueries.propertyIn(ID_AREA, areaCriteria));
      criteria.addOrder(Order.asc(ID_AREA_ID));

      return criteria.list();
   }

}
