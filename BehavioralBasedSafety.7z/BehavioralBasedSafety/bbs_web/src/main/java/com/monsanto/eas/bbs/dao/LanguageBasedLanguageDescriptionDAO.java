package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.LanguageBasedLanguageDescription;
import org.springframework.transaction.annotation.Transactional;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ERODRI5
 * @version $Revision$
 */
@Transactional
public interface LanguageBasedLanguageDescriptionDAO extends GenericDAO<LanguageBasedLanguageDescription,Long> {
}
