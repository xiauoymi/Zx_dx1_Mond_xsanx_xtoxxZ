/*
 LanguageBasedLanguageDescriptionDAOImpl was created on Mar 23, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.GenericHibernateDAO;
import com.monsanto.eas.bbs.hibernate.LanguageBasedLanguageDescription;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ERODRI5
 * @version $Revision$
 */
@Repository
public class LanguageBasedLanguageDescriptionDAOImpl extends GenericHibernateDAO<LanguageBasedLanguageDescription,Long> implements LanguageBasedLanguageDescriptionDAO {
   @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
    }
}
