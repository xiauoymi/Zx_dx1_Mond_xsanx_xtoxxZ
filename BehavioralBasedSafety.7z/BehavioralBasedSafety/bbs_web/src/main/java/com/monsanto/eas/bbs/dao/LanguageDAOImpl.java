/*
 LanguageDAOImpl was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Repository
public class LanguageDAOImpl extends HibernateDaoSupport implements LanguageDAO {

   private static final String ACTIVE = "active";
   private static final String ID_LANGUAGE = "id.language";
   private static final String CATEGORY = "category";
   private static final String ID_BARRIER_CATEGORY = "id.barrierCategory";
   private static final String DESCRIPTION = "description";

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

   public void addLanguage(Language language) {
      getHibernateTemplate().save(language);
   }

   public void deleteLanguage(Language language) {
      getHibernateTemplate().delete(language);
   }

   public Language lookupLanguageByLocale(String locale) {
      Language language = lookupLanguageByLocaleStr(locale);
      if (language == null && locale.length() > 2) {
         language = lookupLanguageByLocaleStr(locale.substring(0, 2));
      }
      return language;
   }

   private Language lookupLanguageByLocaleStr(String locale) {
      DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq("locale", locale));
      return (Language) DataAccessUtils.uniqueResult(getHibernateTemplate().findByCriteria(criteria));
   }

   public List<Language> findAll() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq(ACTIVE, true));
      return (List<Language>) getHibernateTemplate().findByCriteria(criteria);
   }



   public void saveOrUpdateLanguageBasedResponse(LanguageBasedResponse response) {
      getHibernateTemplate().saveOrUpdate(response);
   }

   public List<LanguageBasedResponse> lookupResponsesForALanguage(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria responseCriteria = DetachedCriteria.forClass(Response.class);
      responseCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));
      //join based on the language.
      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedResponse.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn("id.response", responseCriteria));

      return criteria.list();
   }



   public List<LanguageBarrierCategory> lookupInactiveBarriersForALanguageAndSubCategory(Language language, Category category) {
      return lookupBarriersForALanguageAndSubCategory(language, category, false);
   }

   public List<LanguageBarrierCategory> lookupActiveBarriersForALanguageAndSubCategory(Language language, Category category) {
      return lookupBarriersForALanguageAndSubCategory(language, category, true);
   }

   private List<LanguageBarrierCategory> lookupBarriersForALanguageAndSubCategory(Language language, Category category, boolean isActive) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq("id", category.getId())).setProjection(Property.forName("id"));

      DetachedCriteria barrierToCategoryCriteria = DetachedCriteria.forClass(BarrierCategory.class);
      barrierToCategoryCriteria.add(Subqueries.propertyEq(CATEGORY, categoryCriteria));
      barrierToCategoryCriteria.setProjection(Property.forName("id"));
      barrierToCategoryCriteria.add(Restrictions.eq(ACTIVE, isActive));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBarrierCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_BARRIER_CATEGORY, barrierToCategoryCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.list();
   }

   //--TODO remove this method to avoid duplicates
   public List<LanguageBarrierCategory> lookupActiveAndInactiveBarriersForALanguageAndSubCategory(Language language, Category category) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq("id", category.getId())).setProjection(Property.forName("id"));

      DetachedCriteria barrierToCategoryCriteria = DetachedCriteria.forClass(BarrierCategory.class);
      barrierToCategoryCriteria.add(Subqueries.propertyEq(CATEGORY, categoryCriteria));
      barrierToCategoryCriteria.setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBarrierCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.add(Subqueries.propertyIn(ID_BARRIER_CATEGORY, barrierToCategoryCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.list();
   }



   public List<LanguageBasedCategory> lookupCategoriesForALanguageByType(Language language, boolean isTypeBehavior) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria categoryTypeCriteria = DetachedCriteria.forClass(CategoryType.class);
      categoryTypeCriteria.add(Restrictions.eq("behavior", isTypeBehavior)).setProjection(Property.forName("id"));

      DetachedCriteria categoryCriteria = DetachedCriteria.forClass(Category.class);
      categoryCriteria.add(Restrictions.eq(ACTIVE, true));
      categoryCriteria.add(Restrictions.isNull("parentCategory"));
      categoryCriteria.add(Subqueries.propertyEq("categoryType", categoryTypeCriteria))
              .setProjection(Property.forName("id"));

      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedCategory.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.add(Subqueries.propertyIn("id.category", categoryCriteria)).list();
   }

   public List<LanguageBasedPersonnelType> lookupPersonnelTypesForALanguage(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria personnelTypeCriteria = DetachedCriteria.forClass(PersonnelType.class);
      personnelTypeCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));

      //join based on the language.
      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedPersonnelType.class);
      criteria.add(Subqueries.propertyEq(ID_LANGUAGE, languageCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.add(Subqueries.propertyIn("id.personnelType", personnelTypeCriteria)).list();
   }



   public void saveOrUpdateLanguageBasedLanguage(LanguageBasedLanguageDescription lbld) {
      getHibernateTemplate().saveOrUpdate(lbld);
   }

   public List<LanguageBasedLanguageDescription> lookupLanguagesForALanguage(Language language) {
      DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
      languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

      DetachedCriteria languageDescriptionCriteria = DetachedCriteria.forClass(Language.class);
      languageDescriptionCriteria.add(Restrictions.eq(ACTIVE, true)).setProjection(Property.forName("id"));

      //join based on the language.
      Criteria criteria = getCurrentSession().createCriteria(LanguageBasedLanguageDescription.class);
      criteria.add(Subqueries.propertyIn(ID_LANGUAGE, languageDescriptionCriteria));
      criteria.addOrder(Order.asc(DESCRIPTION));
      return criteria.add(Subqueries.propertyIn("id.languageDescription", languageCriteria)).list();
   }

}