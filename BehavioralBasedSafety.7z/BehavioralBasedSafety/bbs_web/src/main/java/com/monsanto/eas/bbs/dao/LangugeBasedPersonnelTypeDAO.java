package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelType;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Mar 18, 2010
 * Time: 4:49:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface LangugeBasedPersonnelTypeDAO extends GenericDAO<LanguageBasedPersonnelType,Long> {
}
