/*
 ObservationDAO was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Category;
import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Transactional
public interface ObservationDAO extends GenericDAO<Observation, Long> {

   void addObservation(Observation observation);

   void updateObservation(Observation observation);

   void deleteObservation(Observation observation);

   void inactivateObservation(Observation observation);

   Observation lookupObservation(Long observationId);

   List<Observation> lookupObservations(ReportCriteria reportCriteria);

   List<Observation> lookupAllObservationForSubSubCategory(Category category);

}