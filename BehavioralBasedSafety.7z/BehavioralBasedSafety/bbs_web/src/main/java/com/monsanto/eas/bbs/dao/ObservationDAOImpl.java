package com.monsanto.eas.bbs.dao;

import com.google.common.base.Joiner;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.util.report.queries.ObservationQuery;
import com.monsanto.eas.bbs.util.report.queries.ObservationQueryParameters;
import com.monsanto.eas.bbs.util.report.queries.ObservationQueryResult;
import com.monsanto.eas.bbs.util.report.registries.QueriesByCategoryType;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.stereotype.Repository;

import java.util.*;

import static ch.lambdaj.Lambda.extract;
import static ch.lambdaj.Lambda.on;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static com.google.common.collect.Sets.newTreeSet;

@Repository
public class ObservationDAOImpl extends GenericHibernateDAO<Observation, Long> implements ObservationDAO
{
    public ObservationDAOImpl() {}

    public ObservationDAOImpl(PlantDAO plantDAO, RegionDAO regionDAO, CountryDAO countryDAO) {
        this.plantDAO = plantDAO;
        this.regionDAO = regionDAO;
        this.countryDAO = countryDAO;
    }

    @Autowired
    private PlantDAO plantDAO;
    @Autowired
    private RegionDAO regionDAO;
    @Autowired
    private CountryDAO countryDAO;

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    public void addObservation(Observation observation) {
        observation.setActive(true);
        getHibernateTemplate().save(observation);
    }

    public void updateObservation(Observation observation) {
        observation.setActive(true);
        getHibernateTemplate().saveOrUpdate(observation);
    }

    public void deleteObservation(Observation observation) {
        getHibernateTemplate().delete(observation);
    }

    public void inactivateObservation(Observation observation) {
        Observation observationToInactivate = lookupObservation(
                observation.getId()); //lookup to retrieve any hibernate mapping for cascade
        observationToInactivate.setActive(false);
        getHibernateTemplate().saveOrUpdate(observationToInactivate);
    }

    public Observation lookupObservation(Long observationId) {
        DetachedCriteria criteria = DetachedCriteria.forClass(Observation.class)
                .add(Restrictions.eq("id", observationId))
                .add(Restrictions.eq("active", true))
                .setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
        List<Observation> list = getHibernateTemplate().findByCriteria(criteria);
        if (list.size() > 1) {
            throw new IncorrectResultSizeDataAccessException("Observation with id " + observationId + " is not unique.\n", 1, list.size());
        }
        return list.get(0);
    }

    private String getObservationCategoryTypeDescription(Observation obs) {
        return Joiner.on(", ").skipNulls().join(newHashSet(extract(obs.getCategoryObservations(), on(CategoryObservation.class).getCategory().getCategoryType().getDescription())));
    }

    private Observation getObservation(Map<Long, Observation> observationMap, ObservationQueryResult result) {

        if (observationMap.containsKey(result.getObservationId())) {
            return observationMap.get(result.getObservationId());
        }
        else {
            BBSUser enteredBy = new BBSUser();
            enteredBy.setId(result.getEnteredById());
            Plant plant = new Plant();
            plant.setId(result.getEnteredByPlantId());
            enteredBy.setPlant(plant);
            enteredBy.setUserId(result.getEnteredByUserId());
            enteredBy.setFirstName(result.getEnteredByFirstName());
            enteredBy.setLastName(result.getEnteredByLastName());
            BBSUser enteredFor = new BBSUser();
            enteredFor.setFirstName(result.getEnteredForFirstName());
            enteredFor.setLastName(result.getEnteredForLastName());
            Department department = new Department();
            department.setName(result.getDepartmentName());
            enteredFor.setDepartment(department);
            Date dateEntered = result.getDateEntered();
            String personnelTypeName = result.getPersonnelTypeDesc();
            SafetyGroup safetyGroup = new SafetyGroup();
            safetyGroup.setGroupText(result.getSafetyGroup());

            BiotechProgram biotechProgram = new BiotechProgram();
            biotechProgram.setProgram(result.getBiotechProgram());
            BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();
            biotechProjectPlatform.setBiotechProgram(biotechProgram);
            biotechProjectPlatform.setProjectDescription(result.getBiotechProject());

            Task task = new Task();
            task.setDescription(result.getTask());

            Plant obsPlant = new Plant();
            obsPlant.setId(result.getObservationPlantId());
            obsPlant.setPlantName1(result.getPlantName());

            safetyGroup.setPlant(obsPlant);
            String areaName = result.getArea();
            String subAreaName = result.getSubArea();

            String modUser = (null != result.getModUser()) ? result.getModUser() : (enteredBy.getFirstName() + " " + enteredBy.getLastName());

            return new Observation(result.getObservationId(), enteredBy, enteredFor, dateEntered,
                    safetyGroup, areaName, subAreaName, personnelTypeName, biotechProgram, biotechProjectPlatform, task, modUser, result.getModDate());
        }
    }

    private List<ObservationQueryResult> getResultsLookupObservationByCriteria(ReportCriteria reportCriteria) {
        Set<ObservationQueryResult> results = newTreeSet();
        ObservationQueryParameters queryParameters = getQueryParameters(reportCriteria);
        for (ObservationQuery query : QueriesByCategoryType.getByIds(reportCriteria.getCategoryTypeIds())) {
            results.addAll(query.getResults(this.getCurrentSession(), queryParameters));
        }
        return newArrayList(results);
    }

    private ObservationQueryParameters getQueryParameters(ReportCriteria reportCriteria) {

        final BBSUser loggedInUser = reportCriteria.getUser();
        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(loggedInUser);

        if (reportCriteria.isSearchByCountryCriteria()) {
            List<Plant> plantListByUserRole = plantDAO.lookupAllValidPlantsByCountryIdAndByUserRole(reportCriteria.getSelectedCountryIds(), loggedInUser, userOwnsRegionDesc);
            reportCriteria.setPlantList(plantListByUserRole);
        }
        else if (reportCriteria.isSearchByRegionCriteria()) {
            List<Country> activeCountriesByRegionByRole = countryDAO.lookupActiveCountriesByRegionIDAndByUserRole(reportCriteria.getSelectedRegionIds(), loggedInUser, userOwnsRegionDesc);
            reportCriteria.setCountryList(activeCountriesByRegionByRole);
            List<Plant> plantListByUserRole = plantDAO.lookupAllValidPlantsByCountryIdAndByUserRole(reportCriteria.getSelectedCountryIds(), loggedInUser, userOwnsRegionDesc);
            reportCriteria.setPlantList(plantListByUserRole);
        }

        String selectedPlantIds = reportCriteria.getSelectedPlantIds().length() > 0 ? reportCriteria.getSelectedPlantIds() : "0";

        String dateFormat = reportCriteria.getDateFormat();
        dateFormat = dateFormat.replace('D', 'd');
        dateFormat = dateFormat.replace('Y', 'y');

        ObservationQueryParameters parameters = new ObservationQueryParameters();
        parameters.setReportDateFrom(reportCriteria.getReportDateFrom());
        parameters.setReportDateTo(reportCriteria.getReportDateTo());
        parameters.setDateFormat(dateFormat);
        parameters.setLanguageId(reportCriteria.getLanguage().getId().toString());
        parameters.setSelectedPlantIds(selectedPlantIds);

        return parameters;
    }

    public List<Observation> lookupObservations(ReportCriteria reportCriteria) {
        Map<Long, Observation> observationMap = new HashMap<Long, Observation>();

        final BBSUser loggedInUser = reportCriteria.getUser();
        Long loggedInUserId = loggedInUser.getId();

        Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
        Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
        Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

        Plant loggedInUserPlant;

        if (loggedInUser.getPlant() != null) {
            loggedInUserPlant = loggedInUser.getPlant();
        } else {
            loggedInUserPlant = new Plant();
        }

        String loggedInUserRegion = regionDAO.lookupRegionDescriptionByPlantId(loggedInUserPlant.getId());

        Boolean showThisObservation = userIsGlobalLead || userIsEMEAAdmin || userIsESHAdmin;
        showThisObservation = showThisObservation || !regionDAO.isInEMEARegion(loggedInUserRegion);

        List<ObservationQueryResult> results = getResultsLookupObservationByCriteria(reportCriteria);

        for (ObservationQueryResult result : results) {
            Long obsId = result.getObservationId();

            Observation observation = getObservation(observationMap, result);

            if (loggedInUserId.equals(result.getEnteredById())) {
                showThisObservation = true;
            }

            Category category = new Category();
            CategoryType categoryType = new CategoryType();
            categoryType.setDescription(result.getCategoryTypeDesc());
            category.setCategoryType(categoryType);

            if (showThisObservation) {
                CategoryObservation categoryObservation = new CategoryObservation(
                    result.getCatObservationId(),
                    result.getFeedback(),
                    result.getComments(),
                    result.getCatObservation(),
                    result.getImmediateActions(),
                    result.getBarrier(),
                    result.getSubSubCat(),
                    result.getSubCat(),
                    result.getCategory(),
                    result.getResponse(),
                    result.getSafeBehaviorFeedback(),
                    result.getSafeBehaviorComments(),
                    result.getSafeBehaviorDescription()
                );
                categoryObservation.setObservation(observation);
                categoryObservation.setCategory(category);

                observation.getCategoryObservations().add(categoryObservation);
                observationMap.put(obsId, observation);
            }
        }

        List<Observation> observations = new ArrayList<Observation>();
        for (Observation obs : observationMap.values()) {
            obs.setCategoryTypeDescription(getObservationCategoryTypeDescription(obs));
            observations.add(obs);
        }

        return observations;
    }

    public List<Observation> lookupAllObservationForSubSubCategory(Category category) {
        DetachedCriteria criteria = DetachedCriteria.forClass(Observation.class)
                .add(Restrictions.eq("subSubCategory.id", category.getId()));
        return (List<Observation>) getHibernateTemplate().findByCriteria(criteria);
    }

}