package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.TempOrgUnit;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 12:47:46 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface OrgUnitDAO {

   void addOrgUnit(OrgUnit orgUnit);
   void deleteOrgUnit(OrgUnit orgUnit);

   void addOrgUnits();
   void addTempOrgUnit(TempOrgUnit tempOrgUnit);
   void assignOrgUnitParents();

   void clearTempOrgUnits();
   void updateOrgUnits();

   List<OrgUnit> findByCriteria(String orgUnitCode);
}
