package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.TempOrgUnit;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 12:46:48 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class OrgUnitDAOImpl extends HibernateDaoSupport implements OrgUnitDAO {

   private static final String ORG_UNIT_CODE_FILTER = "   bbs.temp_org_units.org_unit_code = bbs.org_units.org_unit_code ), ";

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   public void addOrgUnit(OrgUnit orgUnit) {
      getHibernateTemplate().save(orgUnit);
   }

   public void addOrgUnits() {
      final StringBuilder sql = new StringBuilder();
      sql.append("insert into bbs.org_units ");
      sql.append("   (id, description, active, parent_id, org_lvl, data_load_error, mod_user, mod_date, org_unit_code, parent_org_code) ");
      sql.append("select bbs.bbs_seq.nextval, description, active, parent_id, org_lvl, data_load_error, 'BATCH', sysdate, org_unit_code, parent_org_code ");
      sql.append("from bbs.temp_org_units ");
      sql.append("where org_unit_code in ( ");
      sql.append("select org_unit_code from bbs.temp_org_units minus select org_unit_code from bbs.org_units ");
      sql.append(") ");

      final SQLQuery query = this.getCurrentSession().createSQLQuery(sql.toString());
      query.executeUpdate();
   }

   public void addTempOrgUnit(TempOrgUnit tempOrgUnit) {
      getHibernateTemplate().save(tempOrgUnit);
   }

   public void deleteOrgUnit(OrgUnit orgUnit) {
      getHibernateTemplate().delete(orgUnit);
   }

   public void updateOrgUnits() {
      final StringBuilder sql = new StringBuilder();

      sql.append("update bbs.org_units set ");
      sql.append("description = ( ");
      sql.append("   select description from bbs.temp_org_units where ");
      sql.append(ORG_UNIT_CODE_FILTER);
      sql.append("active = ( ");
      sql.append("   select active from bbs.temp_org_units where ");
      sql.append(ORG_UNIT_CODE_FILTER);
      sql.append("org_lvl = ( ");
      sql.append("   select org_lvl from bbs.temp_org_units where ");
      sql.append(ORG_UNIT_CODE_FILTER);
      sql.append("data_load_error = ( ");
      sql.append("   select data_load_error from bbs.temp_org_units where ");
      sql.append(ORG_UNIT_CODE_FILTER);
      sql.append("parent_org_code = ( ");
      sql.append("   select parent_org_code from bbs.temp_org_units where ");
      sql.append(ORG_UNIT_CODE_FILTER);
      sql.append("mod_user = 'BATCH', ");
      sql.append("mod_date = sysdate ");
      sql.append("where exists ( ");
      sql.append("   select org_unit_code from bbs.temp_org_units where ");
      sql.append("   bbs.temp_org_units.org_unit_code = bbs.org_units.org_unit_code )");

      final SQLQuery updateOrgUnitQuery = this.getCurrentSession().createSQLQuery(sql.toString());
      updateOrgUnitQuery.executeUpdate();
   }

   public void assignOrgUnitParents(){
      final StringBuilder sql = new StringBuilder();

      sql.append("update bbs.org_units eou set " );
      sql.append("eou.parent_id = ( select id from bbs.org_units iou where iou.org_unit_code = eou.parent_org_code ) " );

      final SQLQuery updateOrgUnitQuery = this.getCurrentSession().createSQLQuery(sql.toString());
      updateOrgUnitQuery.executeUpdate();
   }

   public void clearTempOrgUnits() {
      final SQLQuery query = this.getCurrentSession().createSQLQuery("delete from bbs.temp_org_units");
      query.executeUpdate();
   }

   public List<OrgUnit> findByCriteria(String orgUnitCode) {
      DetachedCriteria criteria;
      criteria = DetachedCriteria.forClass(OrgUnit.class).add(Restrictions.like("orgCode", "%" + orgUnitCode + "%").ignoreCase());
      return getHibernateTemplate().findByCriteria(criteria);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

}
