/*
 PersonnelDAO was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelType;
import com.monsanto.eas.bbs.hibernate.PersonnelType;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Transactional
public interface PersonnelTypeDAO {

   void addPersonnelType(PersonnelType type);

   void deletePersonnelType(PersonnelType type);

   List<PersonnelType> lookupPersonnelType();

   void addLanguageBasedPersonnelType(LanguageBasedPersonnelType languageBasedPersonnelType);

   List<LanguageBasedPersonnelType> lookupLanguageBasedPersonnelTypesByLanguage();
}