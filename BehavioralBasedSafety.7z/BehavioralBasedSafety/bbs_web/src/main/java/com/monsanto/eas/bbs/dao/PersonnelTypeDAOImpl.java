/*
 PersonnelDAOImpl was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelType;
import com.monsanto.eas.bbs.hibernate.PersonnelType;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Repository
public class PersonnelTypeDAOImpl extends HibernateDaoSupport implements PersonnelTypeDAO {
    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    public void addPersonnelType(PersonnelType type) {
        getHibernateTemplate().save(type);
    }

    public void deletePersonnelType(PersonnelType type) {
        getHibernateTemplate().delete(type);
    }

    public List<PersonnelType> lookupPersonnelType() {
        return (List<PersonnelType>) getHibernateTemplate().loadAll(PersonnelType.class);
    }


    public void addLanguageBasedPersonnelType(LanguageBasedPersonnelType languageBasedPersonnelType) {
        getHibernateTemplate().saveOrUpdate(languageBasedPersonnelType);
    }

    public List<LanguageBasedPersonnelType> lookupLanguageBasedPersonnelTypesByLanguage() {
        Criteria languageCriteria = getCurrentSession().createCriteria(Language.class);
        languageCriteria.add(Restrictions.eq("locale", "en"));

        Language language = (Language) languageCriteria.uniqueResult();

        /*
        DetachedCriteria criteria = DetachedCriteria.forClass(Language.class).add(Restrictions.eq("locale", "en"));
        Language language = (Language) DataAccessUtils.uniqueResult(getHibernateTemplate().findByCriteria(criteria));
        */
        return lookupLanguageBasedPersonnelTypesByLanguage(language);
    }

    public List<LanguageBasedPersonnelType> lookupLanguageBasedPersonnelTypesByLanguage(Language language) {
        DetachedCriteria languageCriteria = DetachedCriteria.forClass(Language.class);
        languageCriteria.add(Restrictions.eq("id", language.getId())).setProjection(Property.forName("id"));

        Criteria criteria = getCurrentSession().createCriteria(LanguageBasedPersonnelType.class);
        criteria.add(Subqueries.propertyEq("id.language", languageCriteria));

        return criteria.list();
    }

}