/*
 PlantDAO was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempPlant;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Transactional
public interface PlantDAO {

    void addPlant(Plant plant);

    void deletePlant(Plant plant);

    void inactivatePlantsNotAssociatedWithSafetyGroup();

    void updatePlantWorkAreas();

    void addTempPlant(TempPlant plant);

    void updatePlants();

    void addPlants();

    void clearTempPlants();

    List<Plant> lookupAllPlants();

    Map<String, Plant> getMapOfAllPlants();

    List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea();

    List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser, String userOwnsRegionDesc);

    List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId);

    List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByRegionId(String regionId);

    List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String selectedCountryIds, BBSUser loggedInUser, String userOwnsRegionDesc);

    List<Plant> lookupAllPlantsAssociatedWithSafetyGroup();

    List<Plant> findByCriteria(String plantName1, String plantCode);


}