/*
 PlantDAOImpl was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempPlant;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Repository
public class PlantDAOImpl extends HibernateDaoSupport implements PlantDAO {

    private static final String ACTIVE = "active";
    private static final String PLANT_NAME = "plantName1";
    private static final String ORDER_BY_PLANT_NAME = "order by plt.plantName1";
    private static final String SELECT_EMEA_COUNTRY_IDS = "     Select id from BBS.country Where region_id NOT IN ( Select id FROM Region Where desctiption = 'EMEA')";
    private static final String SELECT_FROM = "Select * From ( ";
    private static final String PLANT_COUNTRY_ID_FILTER = " AND plt.country_id IN ( ";
    private static final String ORDER_BY_PLANT_NAME_1 = ") order by plant_Name_1";
    private static final String SAFETY_GROUP_PLANT = "sg.plant";
    private static final String PLANT_ID_FILTER = " AND plt.id = ";

    @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   //TODO: verify the logic for this method, currently used only for the EmployeeDataLoader and SafetyGroupDataLoader processes
   public List<Plant> lookupAllPlants() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Plant.class).add(Restrictions.eq(ACTIVE, true));
      criteria.addOrder(Order.asc(PLANT_NAME));
      return (List<Plant>) getHibernateTemplate().findByCriteria(criteria);
   }

    public Map<String, Plant> getMapOfAllPlants() {
        Map<String, Plant> map = new HashMap<String, Plant>();
        List<Plant> allPlants = lookupAllPlants();
        if (allPlants == null) {
            return map;
        }
        for (Plant plant : allPlants) {
            map.put(plant.getPlantCode(), plant);
        }
        return map;
    }

    private String buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaSql() {
        StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder("FROM Plant plt where exists ( ")
              .append("From SafetyGroup sg, ")
              .append("Plant pl, ")
              .append("PlantArea pa ")
              .append("Where ")
              .append("pl.active = true ")
              .append("and sg.active = true ")
              .append("and pl.id = sg.plant.id ")
              .append("and pl.id = pa.id.plant.id ")
              .append("and pl.plantCode = plt.plantCode ")
              .append(") ");
              //.append("order by plt.plantName1");

      return plantWithWorkAreaAssociationQry.toString();
   }

   private String buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaNativeSql() {
      StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder()
              .append("select * from bbs.Plant plt WHERE exists ( " )
              .append("    Select 1 from " )
              .append("       BBS.safety_group sg, " )
              .append("       BBS.plant pl, " )
              .append("       BBS.plant_area pa " )
              .append("    Where " )
              .append("        pl.active = 'Y' " )
              .append("    and sg.active = 'Y' " )
              .append("    and pl.id = sg.plant_code_id " )
              .append("    and pl.id = pa.plant_id " )
              .append("    and pl.plant_Code = plt.plant_Code " )
              .append(") ");

      return plantWithWorkAreaAssociationQry.toString();
   }


   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea() {
       StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder( buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaSql() )
              .append(ORDER_BY_PLANT_NAME);

      return (List<Plant>) getHibernateTemplate().find(plantWithWorkAreaAssociationQry.toString());
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser, String userOwnsRegionDesc) {
      Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
      Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
      Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

      StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder(SELECT_FROM)
              .append( buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaNativeSql() );

      if(!userIsGlobalLead && !userIsEMEAAdmin){

         //--If the user is a ESH Admin based on EMEA region or
         //--If the user in not an ESH Admin, nor a EMEA Admin, nor a Global Lead, then selects only her own site
         if( userIsESHAdmin ){

            plantWithWorkAreaAssociationQry.append(PLANT_COUNTRY_ID_FILTER)
                                           .append(SELECT_EMEA_COUNTRY_IDS)
                                           .append(" ) ");

            if( "EMEA".equals(userOwnsRegionDesc) ){
               plantWithWorkAreaAssociationQry.append(" UNION ")
                                              .append(" Select * From BBS.Plant plt2 where plt2.id = ").append( loggedInUser.getPlant().getId() );
            }

         } else {
            if ( "EMEA".equals(userOwnsRegionDesc) ) {
               plantWithWorkAreaAssociationQry.append(PLANT_ID_FILTER).append( loggedInUser.getPlant().getId() ) ;
            } else {
               plantWithWorkAreaAssociationQry.append(PLANT_COUNTRY_ID_FILTER)
                                              .append(SELECT_EMEA_COUNTRY_IDS)
                                              .append(" ) ");
            }
         }
      }

      plantWithWorkAreaAssociationQry.append(ORDER_BY_PLANT_NAME_1);

      return (List<Plant>) this.getCurrentSession()
              .createSQLQuery( plantWithWorkAreaAssociationQry.toString() )
              .addEntity(Plant.class)
              .list();
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId) {
      StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder( buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaSql() )
              .append(" AND plt.country IN ( ").append( countryId ).append( ") ")
              .append(ORDER_BY_PLANT_NAME);

      return (List<Plant>) getHibernateTemplate().find(plantWithWorkAreaAssociationQry.toString());
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByRegionId(String regionId) {
      StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder( buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaSql() )
              .append(" AND plt.country IN ( From Country Where regionId IN (").append( regionId ).append( ") )")
              .append(" order by plt.plantCode");

      return (List<Plant>) getHibernateTemplate().find(plantWithWorkAreaAssociationQry.toString());
   }


   public List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String selectedCountryIds, BBSUser loggedInUser, String userOwnsRegionDesc) {
      Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
      Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
      Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

      StringBuilder plantWithWorkAreaAssociationQry = new StringBuilder(SELECT_FROM)
              .append( buildAllPlantsAssociatedWithSafetyGroupAndWorkAreaNativeSql() )
              .append(PLANT_COUNTRY_ID_FILTER).append(selectedCountryIds).append( " ) ");

      if(!userIsGlobalLead && !userIsEMEAAdmin && "EMEA".equals(userOwnsRegionDesc)) {

         //--If the user is a ESH Admin, based on EMEA region or
         //--If the user in not an ESH Admin, nor a EMEA Admin, nor a Global Lead, then selects only her own site
        //---If Users own region is EMEA, then the user knows the region Id for this
          Long emeaRegionId = loggedInUser.getPlant().getCountry().getRegionId();

          if( userIsESHAdmin ){
              plantWithWorkAreaAssociationQry.append(" MINUS ")
                  .append(" Select * From BBS.Plant plt2 " )
                  .append("     where plt2.country_id IN ( " )
                  .append("           Select id from BBS.country Where region_id = ").append( emeaRegionId )
                  .append("     ) " )
                  .append(" AND plt2.id <>  ").append( loggedInUser.getPlant().getId() );
          } else {
              plantWithWorkAreaAssociationQry.append(PLANT_ID_FILTER).append( loggedInUser.getPlant().getId() ) ;
          }
      }

      plantWithWorkAreaAssociationQry.append(ORDER_BY_PLANT_NAME_1);

      return (List<Plant>) this.getCurrentSession()
              .createSQLQuery( plantWithWorkAreaAssociationQry.toString() )
              .addEntity(Plant.class)
              .list();
   }


   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroup() {
      /*
         Retrieves all those sites that are valid and have a correspondence with a valid safety group

         select * from bbs.plant pl where active='Y' and exists (
             select sg.plant_code_id from BBS.safety_group sg where pl.id = sg.plant_code_id and sg.active='Y')
         order by pl.plant_code;
      */

      DetachedCriteria plantCriteria = DetachedCriteria.forClass(Plant.class, "p").add(Restrictions.eq(ACTIVE, true));
      plantCriteria.addOrder(Order.asc(PLANT_NAME));

      DetachedCriteria safetyGroupCriteria = DetachedCriteria.forClass(SafetyGroup.class, "sg").add(Restrictions.eq(ACTIVE, true));
      safetyGroupCriteria.add(Property.forName("p.id").eqProperty(SAFETY_GROUP_PLANT));

      plantCriteria.add(Subqueries.exists(safetyGroupCriteria.setProjection(Projections.property(SAFETY_GROUP_PLANT))));
      return (List<Plant>) getHibernateTemplate().findByCriteria(plantCriteria);
   }

   public void addPlant(Plant plant) {
      getHibernateTemplate().save(plant);
   }

   public void deletePlant(Plant plant) {
      getHibernateTemplate().delete(plant);
   }

   public List<Plant> findByCriteria(String plantName, String plantCode) {
      List plants = null;
      DetachedCriteria criteria = null;
      if (plantName != null) {
         criteria = DetachedCriteria.forClass(Plant.class)
                 .add(Restrictions.like(PLANT_NAME, "%" + plantName + "%").ignoreCase());
      }
      if (plantCode != null) {
         criteria = DetachedCriteria.forClass(Plant.class)
                 .add(Restrictions.like("plantCode", "%" + plantCode + "%").ignoreCase());
      }
      if (criteria != null) {
         criteria.add(Restrictions.eq(ACTIVE, true));
         plants = getHibernateTemplate().findByCriteria(criteria);
      }
      return (List<Plant>) plants;
   }


   public void inactivatePlantsNotAssociatedWithSafetyGroup() {
      StringBuilder sqlQuery = new StringBuilder();
      sqlQuery.append("update bbs.plant set active = 'N' ")
              .append("where id not in ( ")
              .append("select distinct plant_code_id from bbs.safety_group where active = 'Y') ");

      final SQLQuery query = this.getCurrentSession().createSQLQuery(sqlQuery.toString());
      query.executeUpdate();
   }

   public void updatePlantWorkAreas() {
      final StringBuilder sql = new StringBuilder();
      sql.append("update bbs.plant set plant_name_1 = ( ");
      sql.append("      select description ");
      sql.append("      from bbs.work_area ");
      sql.append("      where bbs.work_area.plant_code = bbs.plant.plant_code ");
      sql.append(")  where exists ( ");
      sql.append("   select id ");
      sql.append("   from bbs.work_area ");
      sql.append("   where bbs.work_area.plant_code = bbs.plant.plant_code ");
      sql.append(")");
      final SQLQuery query = this.getCurrentSession().createSQLQuery(sql.toString());
      query.executeUpdate();
   }

   public void addTempPlant(TempPlant plant) {
      getHibernateTemplate().save(plant);
   }

   public void updatePlants() {
      final StringBuilder sql = new StringBuilder();
      sql.append("update bbs.plant p ")
              .append(" set ")
              .append(" plant_code   = (select plant_code from bbs.temp_plant where bbs.temp_plant.plant_code = p.plant_code), ")
              .append(" plant_name_1 = (select plant_name_1 from bbs.temp_plant where bbs.temp_plant.plant_code = p.plant_code), ")
              .append(" street       = (select street from bbs.temp_plant where bbs.temp_plant.plant_code = p.plant_code), ")
              .append(" country_id   = (select country_id from bbs.temp_plant where bbs.temp_plant.plant_code = p.plant_code), ")
              .append(" mod_user     = 'BATCH', ")
              .append(" mod_date     = sysdate, ")
              .append(" active       = 'Y' ")
              .append(" where exists (select tp.plant_code from bbs.temp_plant tp where tp.plant_code = p.plant_code) ");
      final SQLQuery query = this.getCurrentSession().createSQLQuery(sql.toString());
      query.executeUpdate();
   }

   public void addPlants() {
      final StringBuilder sql = new StringBuilder();
      sql.append("insert into bbs.plant ");
      sql.append("(id, plant_code, plant_name_1, street, country_id, active, mod_user, mod_date) ");
      sql.append("select bbs.bbs_seq.nextval, plant_code, plant_name_1, street, country_id, 'Y', 'BATCH', sysdate ");
      sql.append("   from bbs.temp_plant ");
      sql.append("   where plant_code in ( ");
      sql.append("      select plant_code from bbs.temp_plant minus select plant_code from bbs.plant ");
      sql.append(") ");

      final SQLQuery query = this.getCurrentSession().createSQLQuery(sql.toString());
      query.executeUpdate();
   }

   public void clearTempPlants() {
      final SQLQuery query = this.getCurrentSession().createSQLQuery("delete from bbs.temp_plant");
      query.executeUpdate();
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

}