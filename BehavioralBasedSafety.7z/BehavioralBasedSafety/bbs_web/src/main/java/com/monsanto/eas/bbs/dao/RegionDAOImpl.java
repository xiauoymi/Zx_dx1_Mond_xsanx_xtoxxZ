/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Region;
import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
@Transactional
@Repository
public class RegionDAOImpl extends HibernateDaoSupport implements RegionDAO {

   private static final String ACTIVE = "active";
   private static final String DESCRIPTION = "description";
   private Logger log = Logger.getLogger(RegionDAOImpl.class);

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   public String lookupRegionDescriptionByRegionId(Long id) {
      final SQLQuery query = getCurrentSession().createSQLQuery(lookupSql(id));
      return (String) query.uniqueResult();
   }

   public String lookupRegionDescriptionByPlantId(Long plantId) {

      StringBuilder sb = new StringBuilder();
      sb.append("select desctiption from bbs.region where id in ( ")
              .append("select region_id from bbs.country where id in ( ")
              .append("select country_id from bbs.Plant where id = ")
              .append(plantId)
              .append("))");

      final SQLQuery query = this.getCurrentSession().createSQLQuery(sb.toString());
      String obj = null;

      try {
         obj = (String) query.uniqueResult();
      } catch (NonUniqueResultException nonUnique) {
         obj = null;
         log.error(nonUnique.getMessage(), nonUnique);
      } catch (HibernateException hibernateException) {
         obj = null;
         log.error(hibernateException.getMessage(), hibernateException);
      }

      if (obj == null) {
         return "";
      }
      return obj;
   }

   public Boolean isInEMEARegion(String region) {
      return region.equals("EMEA");
   }

   public String lookupRegionDescriptionByBBSUser(BBSUser loggedInUser) {
      String userOwnsRegionDesc = "";
      Long regionId = null;

      try {
         regionId = loggedInUser.getPlant().getCountry().getRegionId();
      } catch (Exception e) {
         log.error(e.getMessage(), e);
      }

      if (regionId != null) {
         userOwnsRegionDesc = lookupRegionDescriptionByRegionId(regionId);
      }

      return userOwnsRegionDesc;
   }

   public List<Region> lookupAllRegions() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Region.class);
      criteria.add(Restrictions.eq(ACTIVE, true));
      criteria.addOrder(Order.asc(DESCRIPTION));

      return getHibernateTemplate().findByCriteria(criteria);
   }

   public List<Region> lookupAllRegionsByUserRole(BBSUser loggedInUser) {

      String userOwnRegionDesc = lookupRegionDescriptionByBBSUser(loggedInUser);

      DetachedCriteria criteria = DetachedCriteria.forClass(Region.class);
      criteria.add(Restrictions.eq(ACTIVE, true));

      Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
      Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
      Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

      if (!userIsGlobalLead && !userIsEMEAAdmin) {

         //--If the user is an ESH Admin, based on EMEA region or
         //--If the user in not an ESH Admin, nor a EMEA Admin, nor a Global Lead, then selects only her own site
         if ("EMEA".equals(userOwnRegionDesc)) {
            if (!userIsESHAdmin) {
               criteria.add(Restrictions.eq(DESCRIPTION, "EMEA"));
            }
         } else {
            criteria.add(Restrictions.ne(DESCRIPTION, "EMEA"));
         }

      }

      criteria.addOrder(Order.asc(DESCRIPTION));

      return getHibernateTemplate().findByCriteria(criteria);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }

   private String baseSql() {
      return "select desctiption from bbs.region where id = ";
   }

   private String lookupSql(final Long id) {
      final StringBuilder sb = new StringBuilder();
      sb.append(baseSql())
              .append(id);
      return sb.toString();
   }
}
