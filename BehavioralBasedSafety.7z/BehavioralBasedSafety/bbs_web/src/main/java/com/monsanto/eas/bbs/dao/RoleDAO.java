package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSRole;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 19, 2010
 * Time: 3:58:56 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface RoleDAO {
  List<BBSRole> lookUpAllRoles();

  void saveOrUpdateRole(BBSRole role);
}
