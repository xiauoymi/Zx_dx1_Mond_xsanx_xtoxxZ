package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSRole;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Feb 19, 2010 Time: 4:01:35 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class RoleDAOImpl extends HibernateDaoSupport implements RoleDAO {

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }

    public List<BBSRole> lookUpAllRoles() {
        DetachedCriteria criteria = DetachedCriteria.forClass(BBSRole.class)
                .add(Restrictions.eq("active", true));
        criteria.addOrder(Order.asc("description"));
        return (List<BBSRole>) getHibernateTemplate().findByCriteria(criteria);
    }

    public void saveOrUpdateRole(BBSRole role) {
        getHibernateTemplate().saveOrUpdate(role);
    }
}
