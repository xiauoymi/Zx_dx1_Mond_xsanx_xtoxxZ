/*
 SafetyGroupDAO was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;


import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempSafetyGroup;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Transactional
public interface SafetyGroupDAO {

    void addSafetyGroup(SafetyGroup safetyGroup);

    void deleteSafetyGroup(SafetyGroup safetyGroup);

    void addTempSafetyGroup(TempSafetyGroup tempSafetyGroup);

    void updateSafetyGroups();

    void addSafetyGroups();

    void clearTempSafetyGroups();

    List<SafetyGroup> lookupSafetyGroupsByPlant(Plant plant);

    List<SafetyGroup> lookupAll();

    Map<String, SafetyGroup> getMapOfAllSafetyGroups();
}