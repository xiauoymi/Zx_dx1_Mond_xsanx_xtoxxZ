package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempSafetyGroup;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SafetyGroupDAOImpl extends HibernateDaoSupport implements SafetyGroupDAO {

    private static final String ACTIVE = "active";
    private static final String LOCATION_CODE = "locationCode";
    private static final String PLANT_CODE = "plantCode";
    private static final String SAFETY_GROUP_CODE_FILTER = "   bbs.temp_safety_group.safety_group_code = bbs.safety_group.safety_group_code )";
    private static final String COMMA = ", ";

    @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   public List<SafetyGroup> lookupSafetyGroupsByPlant(Plant plant) {
      DetachedCriteria criteria = DetachedCriteria.forClass(SafetyGroup.class)
              .add(Restrictions.eq("plant.id", plant.getId()))
              .add(Restrictions.eq(ACTIVE, true))
              .add(Restrictions.isNotNull(LOCATION_CODE))
              .add(Restrictions.isNotNull(PLANT_CODE))
              .addOrder(Order.asc("groupText"));
      return (List<SafetyGroup>) getHibernateTemplate().findByCriteria(criteria);
   }

   public List<SafetyGroup> lookupAll() {
      final DetachedCriteria criteria = DetachedCriteria.forClass(SafetyGroup.class)
              .add(Restrictions.eq(ACTIVE, true))
              .add(Restrictions.isNotNull(LOCATION_CODE))
              .add(Restrictions.isNotNull(PLANT_CODE));
      return (List<SafetyGroup>) getHibernateTemplate().findByCriteria(criteria);
   }

    public Map<String, SafetyGroup> getMapOfAllSafetyGroups() {
        Map<String, SafetyGroup> map = new HashMap<String, SafetyGroup>();
        List<SafetyGroup> groups = lookupAll();
        for (SafetyGroup group : groups) {
            map.put(group.getLocationCode(), group);
        }
        return map;
    }

    public void addSafetyGroup(SafetyGroup safetyGroup) {
      getHibernateTemplate().saveOrUpdate(safetyGroup);
   }

   public void deleteSafetyGroup(SafetyGroup safetyGroup) {
      getHibernateTemplate().delete(safetyGroup);
   }

   public void addTempSafetyGroup(TempSafetyGroup tempSafetyGroup) {
      getHibernateTemplate().save(tempSafetyGroup);
   }

   public void addSafetyGroups() {
      final StringBuilder sql = new StringBuilder();
      sql.append("insert into bbs.safety_group ");
      sql.append("   (id, group_text, plant_code_id, active, mod_user, mod_date, data_load_error, safety_group_code, org_unit_id, location_code, plant_code, biotech_ind) ");
      sql.append("select bbs.bbs_seq.nextval, group_text, plant_code_id, active, 'BATCH', sysdate, data_load_error, safety_group_code, org_unit_id, location_code, plant_code, biotech_ind ");
      sql.append("from bbs.temp_safety_group ");
      sql.append("where safety_group_code in ( ");
      sql.append("select safety_group_code from bbs.temp_safety_group minus select safety_group_code from bbs.safety_group ");
      sql.append(") ");

      final SQLQuery query = this.getCurrentSession().createSQLQuery(sql.toString());
      query.executeUpdate();
   }

   public void updateSafetyGroups() {
      final StringBuilder sql = new StringBuilder();

      sql.append("update bbs.safety_group set ");
      sql.append("active = ( ");
      sql.append("   select active from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("group_text = ( ");
      sql.append("   select group_text from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("plant_code = ( ");
      sql.append("   select plant_code from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("plant_code_id = ( ");
      sql.append("   select pl.id from bbs.plant pl, bbs.temp_safety_group ");
      sql.append("   where pl.plant_code = bbs.temp_safety_group.plant_code and ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("location_code = ( ");
      sql.append("   select location_code from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("data_load_error = ( ");
      sql.append("   select data_load_error from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("org_unit_id = (");
      sql.append("   select org_unit_id from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("biotech_ind = ( ");
      sql.append("   select biotech_ind from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER).append(COMMA);
      sql.append("mod_user = 'BATCH', ");
      sql.append("mod_date = sysdate ");
      sql.append("where exists ( ");
      sql.append("   select id from bbs.temp_safety_group where ");
      sql.append(SAFETY_GROUP_CODE_FILTER);

      final SQLQuery updateLocationCodeQuery = this.getCurrentSession().createSQLQuery(sql.toString());
      updateLocationCodeQuery.executeUpdate();
   }

   public void clearTempSafetyGroups() {
      final SQLQuery query = this.getCurrentSession().createSQLQuery("delete from bbs.temp_safety_group");
      query.executeUpdate();
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }
}