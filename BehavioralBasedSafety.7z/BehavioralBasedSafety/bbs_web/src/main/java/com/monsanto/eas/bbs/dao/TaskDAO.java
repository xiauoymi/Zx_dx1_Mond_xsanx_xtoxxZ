package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Task;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/05/13
 * Time: 04:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface TaskDAO {

   List<Task> lookupAllTasks();
   Task lookupTaskByDescription(String description);
   void addNewTask(Task task);
}
