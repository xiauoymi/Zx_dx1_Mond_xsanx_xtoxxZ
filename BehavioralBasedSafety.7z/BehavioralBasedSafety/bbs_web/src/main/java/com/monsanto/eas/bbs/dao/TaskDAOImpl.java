package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Task;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/05/13
 * Time: 05:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class TaskDAOImpl extends HibernateDaoSupport implements TaskDAO {

   private static final String DESCRIPTION = "description";

   @Autowired
   public void setupSessionFactory(SessionFactory sessionFactory) {
      this.setSessionFactory(sessionFactory);
   }

   public List<Task> lookupAllTasks() {
      DetachedCriteria criteria = DetachedCriteria.forClass(Task.class);
      criteria.addOrder(Order.asc(DESCRIPTION));
      return (List<Task>) getHibernateTemplate().findByCriteria(criteria);
   }

   public Task lookupTaskByDescription(String description) {
      Criteria bbsUserCriteria = getCurrentSession().createCriteria(Task.class);
      bbsUserCriteria.add(Restrictions.eq(DESCRIPTION, description).ignoreCase());
      return (Task) bbsUserCriteria.uniqueResult();
   }

   public void addNewTask(Task task) {
      getHibernateTemplate().saveOrUpdate(task);
   }

   private Session getCurrentSession() {
      return getSessionFactory().getCurrentSession();
   }
}
