/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * UserDAO was created on Dec 18, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.TempBBSUser;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $HeadURL$ Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$ Last Change: $Author$     On: $Date$
 */
@Transactional
public interface UserDAO {

    void addUser(BBSUser user);

    void addTempUser(TempBBSUser tempUser);

    boolean deleteUser(BBSUser user);

    BBSUser findByUserId(String userId);

    List<BBSUser> lookupUserByCriteria(String userName);

    List<BBSUser> lookupAllUsers(boolean active);

    Map<String, BBSUser> getTempBBSUsersPendingForInsert();

    List<TempBBSUser> getTempBBSUsersWithNotExistingManager();

    void setDefaultValueForUsersWithInvalidManager();

    void inactivateBBSUsers();

    void updateBBSUsers();

    void clearTempUsers();

    List<BBSUser> lookupAllContractors(boolean active);

    List<BBSUser> lookupUserWithRoles();
}
