package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.TempBBSUser;
import org.hibernate.*;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.DistinctRootEntityResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UserDAOImpl extends HibernateDaoSupport implements UserDAO {

    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";
    private static final String ACTIVE = "active";
    private static final String PLANT = "plant";
    private static final String EMPLOYEE = "employee";
    private static final String DEPARTMENT = "department";
    private static final String ROLES = "roles";

    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        this.setSessionFactory(sessionFactory);
    }


    public void addUser(BBSUser user) {
        getHibernateTemplate().saveOrUpdate(user);
    }


    public void addTempUser(TempBBSUser tempUser) {
        getHibernateTemplate().saveOrUpdate(tempUser);
    }


    public boolean deleteUser(BBSUser user) {
        getHibernateTemplate().delete(user);
        if (findByUserId(user.getUserId()) != null) {
            return false;
        }
        return true;
    }

    public BBSUser findByUserId(String userId) {
        Criteria bbsUserCriteria = getCurrentSession().createCriteria(BBSUser.class);
        bbsUserCriteria.add(Restrictions.eq("userId", userId).ignoreCase());
        BBSUser bbsUser = (BBSUser) bbsUserCriteria.uniqueResult();

        //Initialize Lazy instance
        if(bbsUser != null){
            bbsUser.getPlant();
        }
        return bbsUser;
    }

    public List<BBSUser> lookupUserByCriteria(String userName) {
        Criteria criteria = getCurrentSession().createCriteria(BBSUser.class);
        criteria.add(Restrictions.or(Restrictions.like(FIRST_NAME, "%" + userName + "%").ignoreCase(),
                Restrictions.like(LAST_NAME, "%" + userName + "%").ignoreCase()));
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return criteria.list();
    }

    public List<BBSUser> lookupAllUsers(boolean active) {
        DetachedCriteria criteria = DetachedCriteria.forClass(BBSUser.class)
                .add(Restrictions.eq(ACTIVE, active));
        criteria.addOrder(Order.asc(FIRST_NAME));
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return this.getHibernateTemplate().findByCriteria(criteria);
    }

    public List<BBSUser> lookupAllContractors(boolean active) {
        DetachedCriteria criteria = DetachedCriteria.forClass(BBSUser.class)
            .add(Restrictions.eq(ACTIVE, active))
            .add(Restrictions.eq(EMPLOYEE, false))
            .setFetchMode(PLANT, FetchMode.JOIN)
            .setFetchMode(DEPARTMENT, FetchMode.JOIN)
            .setFetchMode(ROLES, FetchMode.JOIN)
        ;
        criteria.addOrder(Order.asc(FIRST_NAME));
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return this.getHibernateTemplate().findByCriteria(criteria);
    }

    public void inactivateBBSUsers() {
        StringBuilder sqlQuery = new StringBuilder();
        sqlQuery.append("update bbs.bbs_user set")
                .append("  active = 'N', ")
                .append("  mod_user = 'BATCH', ")
                .append("  mod_date = sysdate ");
        sqlQuery.append("where user_id in ( ");
        sqlQuery.append("  select user_id from ");
        sqlQuery.append("     bbs.bbs_user where is_employee = 'Y' ");
        sqlQuery.append("  minus ");
        sqlQuery.append("     select user_id from ");
        sqlQuery.append("     bbs.temp_bbs_user) ");

        final SQLQuery query = this.getCurrentSession()
                .createSQLQuery(sqlQuery.toString());
        query.executeUpdate();
    }

    public Map<String, BBSUser> getTempBBSUsersPendingForInsert() {
        Map<String, BBSUser> map = new HashMap<String, BBSUser>();
        Query query = this.getCurrentSession().createQuery("from TempBBSUser where userId not in ( select userId from BBSUser )");
        List<TempBBSUser> bbsUserList = query.list();

        BBSUser bbsUser;

        for (TempBBSUser tempBBSUser : bbsUserList) {
            bbsUser = tempBBSUser.getBBSUserFromTempBBSUser();

            map.put(bbsUser.getUserId(), bbsUser);
        }
        return map;
    }

    public List<TempBBSUser> getTempBBSUsersWithNotExistingManager() {
        Query query = this.getCurrentSession().createQuery("from TempBBSUser where manager not in ( select userId from TempBBSUser )");
        return query.list();
    }

    public void setDefaultValueForUsersWithInvalidManager() {
        StringBuilder sqlQuery = new StringBuilder();
        sqlQuery.append("update bbs.temp_bbs_user set ")
                .append("       mgr_user_id = null ")
                .append("where mgr_user_id not in ( select user_id from bbs_user.temp_bbs_user ) ");

        final SQLQuery query = this.getCurrentSession()
                .createSQLQuery(sqlQuery.toString());
        query.executeUpdate();
    }


    public void updateBBSUsers() {
        StringBuilder sqlQuery = new StringBuilder();
        sqlQuery.append("UPDATE bbs.bbs_user ba ");
        sqlQuery.append("  SET(first_name, last_name, middle_name, plant_id, location_code, department_id, is_employee, active, phone_nbr, cost_center, email_addr, mgr_user_id, company_code, business_area, mod_user, mod_date ) = ");
        sqlQuery.append("     (  SELECT first_name, last_name, middle_name, plant_id, location_code, department_id, 'Y', 'Y', phone_nbr, cost_center, email_addr, mgr_user_id, company_code, business_area, 'BATCH', sysdate ");
        sqlQuery.append("        FROM bbs.temp_bbs_user temp ");
        sqlQuery.append("        WHERE temp.user_id = upper(ba.user_id) ");
        sqlQuery.append("     ) ");
        sqlQuery.append("WHERE EXISTS ");
        sqlQuery.append("  ( SELECT user_id ");
        sqlQuery.append("    FROM bbs.temp_bbs_user ");
        sqlQuery.append("    WHERE bbs.temp_bbs_user.user_id = upper(ba.user_id) ");
        sqlQuery.append("  ) ");

        final SQLQuery query = this.getCurrentSession()
                .createSQLQuery(sqlQuery.toString());
        query.executeUpdate();
    }

    public void clearTempUsers() {
        final SQLQuery query = this.getCurrentSession().createSQLQuery("delete bbs.temp_bbs_user");
        query.executeUpdate();
    }

    public List<BBSUser> lookupUserWithRoles() {
        Criteria criteria = getCurrentSession().createCriteria(BBSUser.class);
        criteria.add(Restrictions.eq(ACTIVE, true));
        criteria.add(Restrictions.sizeGt(ROLES, 0));
        criteria.addOrder(Order.asc(LAST_NAME));
        criteria.setFetchMode(PLANT, FetchMode.JOIN);
        criteria.setResultTransformer(new DistinctRootEntityResultTransformer());
        return criteria.list();
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }
}
