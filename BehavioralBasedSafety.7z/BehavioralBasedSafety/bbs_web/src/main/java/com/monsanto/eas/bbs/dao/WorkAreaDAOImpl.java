/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.WorkArea;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
@Repository
public class WorkAreaDAOImpl extends HibernateDaoSupport implements WorkAreaDAO {

  private static final String PLANT_CODE = "plantCode";

  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    this.setSessionFactory(sessionFactory);
  }

  /**
   * Looks up all work areas.
   * @return list of work areas looked up
   */
  public List<WorkArea> lookupAll() {
    DetachedCriteria criteria = DetachedCriteria.forClass(WorkArea.class);
    criteria.addOrder(Order.desc(PLANT_CODE));
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
    return getHibernateTemplate().findByCriteria(criteria);
  }

  /**
   * Adds work area.
   * @param workArea the work area to add
   */
  public void addWorkArea(WorkArea workArea) {
    getHibernateTemplate().saveOrUpdate(workArea);
  }

  /**
   * Removes work area.
   * @param workArea the work area to remove
   */
  public void deleteWorkArea(WorkArea workArea) {
    getHibernateTemplate().delete(workArea);
  }

  /**
   * Removes all work areas from the table.
   */
  public void clearWorkAreas() {
    final Session session = this.getCurrentSession();
    //session.beginTransaction();
    final SQLQuery query = session.createSQLQuery("delete from bbs.work_area");
    //session.getTransaction().commit();
    query.executeUpdate();
  }

    /**
   * Looks up all Work areas & Work Locations.
   * @return list of work areas looked up
   */
  public List<WorkArea> lookupAllAreasWithLocations() {
    Criteria criteria = getCurrentSession().createCriteria(WorkArea.class);
    criteria.addOrder(Order.desc(PLANT_CODE));
    return criteria.list();  //To change body of implemented methods use File | Settings | File Templates.
  }

  private Session getCurrentSession() {
    return getSessionFactory().getCurrentSession();
  }

}