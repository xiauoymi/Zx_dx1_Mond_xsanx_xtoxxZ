/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dao.PersonnelTypeDAO;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.LanguageBasedAreaService;
import com.monsanto.eas.bbs.service.LanguageBasedAreaServiceImpl;
import com.monsanto.eas.bbs.service.LanguageService;
import com.monsanto.eas.bbs.service.LanguageServiceImpl;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class AddLanguageMain {
    private static final String LANGUAGE_DAO = "languageDao";
    private CategoryDAO categoryDao;
    private LanguageDAO languageDao;
    private PersonnelTypeDAO personnelDao;
    private LanguageService languageService;
    //private AreaService areaService;
    private LanguageBasedAreaService languageBasedAreaService;

    private static Logger logger = Logger.getLogger(AddLanguageMain.class);

    public AddLanguageMain() {
    }

    public void go(String description, Boolean active, String locale) {
        languageService.insertLanguage(description, active, locale);
        //areaService.addLanguageBasedAreas(locale);
        languageBasedAreaService.addLanguageBasedAreas(locale);
        addLanguageBarrierCat(locale);
        addLanguageCategory(locale);
        addLanguageCategoryType(locale);
        addLanguageDescription(locale);
        addLanguagePersonnelType(locale);
        addLanguageResponse(locale);
    }

    public void addLanguageBarrierCat(String locale) {
        Language language = languageDao.lookupLanguageByLocale(locale);
        List<LanguageBarrierCategory> list = categoryDao.lookupLanguageBarriers();

        logger.info("Adding language barrier cats.");

        for (LanguageBarrierCategory cat : list) {
            LanguageBarrierCategoryPK primaryKey = new LanguageBarrierCategoryPK();
            primaryKey.setBarrierCategory(cat.getId().getBarrierCategory());
            primaryKey.setLanguage(language);
            LanguageBarrierCategory obj = new LanguageBarrierCategory();
            obj.setId(primaryKey);
            obj.setDescription(cat.getDescription());
            categoryDao.saveLanguageBarrierCategory(obj);
        }
    }

    public void addLanguageCategory(String locale) {
        Language language = languageDao.lookupLanguageByLocale(locale);
        List<LanguageBasedCategory> list = categoryDao.lookupAllLanguageCategories();

        logger.info("Adding language categories.");

        for (LanguageBasedCategory cat : list) {
            LanguageBasedCategoryPK primaryKey = new LanguageBasedCategoryPK();
            primaryKey.setCategory(cat.getId().getCategory());
            primaryKey.setLanguage(language);
            LanguageBasedCategory obj = new LanguageBasedCategory();
            obj.setId(primaryKey);
            obj.setDescription(cat.getDescription());
            categoryDao.saveLanguageBasedCategory(obj);
        }
    }

    public void addLanguageCategoryType(String locale) {
        Language language = languageDao.lookupLanguageByLocale(locale);
        List<LanguageCategoryType> list = categoryDao.lookupLanguageCategoryTypes(languageDao.lookupLanguageByLocale("en"));

        logger.info("Adding language category types.");

        for (LanguageCategoryType cat : list) {
            LanguageCategoryTypePK primaryKey = new LanguageCategoryTypePK();
            primaryKey.setCategoryType(cat.getId().getCategoryType());
            primaryKey.setLanguage(language);
            LanguageCategoryType obj = new LanguageCategoryType();
            obj.setId(primaryKey);
            obj.setDescription(cat.getDescription());
            categoryDao.saveOrUpdateLanguageCategoryType(obj);
        }
    }

    public void addLanguageDescription(String locale) {
        final Language language = languageDao.lookupLanguageByLocale(locale);
        List<Language> list = languageDao.findAll();

        logger.info("Adding language based language.");

        for (Language lang : list) {
            LanguageBasedLanguageDescriptionPK primaryKey = new LanguageBasedLanguageDescriptionPK();
            primaryKey.setLanguageDescription(language);
            primaryKey.setLanguage(lang);
            LanguageBasedLanguageDescription obj = new LanguageBasedLanguageDescription();
            obj.setId(primaryKey);
            obj.setDescription(lang.getDescription());
            languageDao.saveOrUpdateLanguageBasedLanguage(obj);
        }
    }

    public void addLanguagePersonnelType(String locale) {
        final List<LanguageBasedPersonnelType> list = personnelDao.lookupLanguageBasedPersonnelTypesByLanguage();
        final Language language = languageDao.lookupLanguageByLocale(locale);

        logger.info("Adding language based personnel types.");

        for (LanguageBasedPersonnelType type : list) {
            LanguageBasedPersonnelTypePK primaryKey = new LanguageBasedPersonnelTypePK();
            primaryKey.setPersonnelType(type.getId().getPersonnelType());
            primaryKey.setLanguage(language);
            LanguageBasedPersonnelType obj = new LanguageBasedPersonnelType();
            obj.setId(primaryKey);
            obj.setDescription(type.getDescription());

            try {
                personnelDao.addLanguageBasedPersonnelType(obj);
            } catch (DataIntegrityViolationException e) {
                logger.error("Already been added: " + obj.getId().getLanguage().getId() + " (" + obj.getId().getLanguage().getLocale() + "), '" + obj.getDescription() + "'.", e);
            }
        }
    }

    public void addLanguageResponse(String locale) {
        Language language = languageDao.lookupLanguageByLocale(locale);
        final List<LanguageBasedResponse> list = languageDao.lookupResponsesForALanguage(languageDao.lookupLanguageByLocale("en"));

        logger.info("Adding language based responses.");

        for (LanguageBasedResponse response : list) {
            LanguageBasedResponsePK primaryKey = new LanguageBasedResponsePK();
            primaryKey.setResponse(response.getId().getResponse());
            primaryKey.setLanguage(language);
            LanguageBasedResponse obj = new LanguageBasedResponse();
            obj.setId(primaryKey);
            obj.setDescription(response.getDescription());
            languageDao.saveOrUpdateLanguageBasedResponse(obj);
        }
    }

    public void setLanguageDao(LanguageDAO languageDao) {
        this.languageDao = languageDao;
    }

    public void setCategoryDao(CategoryDAO categoryDao) {
        this.categoryDao = categoryDao;
    }

    public void setPersonnelDao(PersonnelTypeDAO personnelDao) {
        this.personnelDao = personnelDao;
    }

    public void setLanguageService(LanguageService languageService) {
        this.languageService = languageService;
    }

    /*
    public void setAreaService(AreaService areaService) {
        this.areaService = areaService;
    }
    */

    public void setLanguageBasedAreaService(LanguageBasedAreaService languageBasedAreaService) {
        this.languageBasedAreaService = languageBasedAreaService;
    }


    public static void main(String[] args) throws EncryptorException {
        String locale = "it";
        String description = "Italian";
        Boolean active = true;
        ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        BasicDataSource dataSource = (BasicDataSource) context.getBean("dataSource");

        logger.info("url = " + dataSource.getUrl());
        logger.info("username = " + dataSource.getUsername());

        dataSource.setPassword(EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "bbs", "CipherValue.hex", "KeyValue.hex"));
        AddLanguageMain alm = new AddLanguageMain();
        alm.setLanguageDao((LanguageDAO) context.getBean(LANGUAGE_DAO));
        alm.setCategoryDao((CategoryDAO) context.getBean("categoryTypeDao"));
        alm.setPersonnelDao((PersonnelTypeDAO) context.getBean("personnelDao"));

        LanguageService languageService = new LanguageServiceImpl((LanguageDAO) context.getBean(LANGUAGE_DAO));
        alm.setLanguageService(languageService);

        LanguageBasedAreaService languageBasedAreaService = new LanguageBasedAreaServiceImpl((LanguageBasedAreaDAO) context.getBean("languageBasedAreaDao"),
                (LanguageDAO) context.getBean(LANGUAGE_DAO));
        alm.setLanguageBasedAreaService(languageBasedAreaService);

        alm.go(description, active, locale);
    }
}