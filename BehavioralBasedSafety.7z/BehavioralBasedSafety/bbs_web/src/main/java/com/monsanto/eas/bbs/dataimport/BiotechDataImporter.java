package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 18/06/12
 * Time: 04:36 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BiotechDataImporter {

    List<BiotechTO> getBiotechInfo() throws IOException, ContentSetException;
}
