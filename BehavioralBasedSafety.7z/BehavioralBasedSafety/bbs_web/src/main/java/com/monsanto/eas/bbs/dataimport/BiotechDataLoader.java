package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.BiotechDAO;
import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 20/06/12
 * Time: 10:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class BiotechDataLoader {

    private BiotechDAO biotechDAO;
    private BiotechDataImporter biotechDataImporter;

    private static Logger logger = Logger.getLogger(BiotechDataLoader.class);

    public BiotechDataLoader(BiotechDataImporter biotechDataImporter, BiotechDAO biotechDAO) {
        this.biotechDataImporter = biotechDataImporter;
        this.biotechDAO = biotechDAO;
    }

    public void loadBiotechData() throws IOException, ContentSetException {
        List<BiotechTO> biotechList = biotechDataImporter.getBiotechInfo();
        logger.info("Total biotech records read from feed: " + biotechList.size());

        List<BiotechProgram> biotechProgramList = getDistinctProgramListFromBiotechInfo( biotechList );

        try{

            addBiotechPrograms(biotechProgramList);
            logger.info("added biotech program info.");

            addBiotechProjectPlatforms(biotechList);
            logger.info("added biotech project/platform info.");

        } catch (Exception e){
            logger.error("Error while inserting biotech info...\n" + e.getCause(), e);
        }
    }

    private void addBiotechPrograms(List<BiotechProgram> biotechProgramList) {
        Map<String, BiotechProgram> mapOfBiotechPrograms = getMapOfAllBiotechPrograms();

        for( BiotechProgram biotechProgram : biotechProgramList){
            if( ! mapOfBiotechPrograms.containsKey( biotechProgram.getPlantCode() + biotechProgram.getProgram().trim())){
                biotechDAO.addBiotechProgram(biotechProgram);
            }
        }
    }


    private void addBiotechProjectPlatforms(List<BiotechTO> biotechInfoList) {
        Map<String, BiotechProgram> mapOfBiotechPrograms = getMapOfAllBiotechPrograms();
        Map<String, BiotechProjectPlatform> mapOfBiotechProjectPlatform = getMapOfAllBiotechProjectPlatform();

        BiotechProjectPlatform biotechProjectPlatform = null;

        for( BiotechTO biotechTO : biotechInfoList ){

            if (
                mapOfBiotechPrograms.containsKey( biotechTO.getPlantCode() + biotechTO.getProgram().trim())
                && !mapOfBiotechProjectPlatform.containsKey( biotechTO.getPlantCode() + biotechTO.getProjectPlatform().trim() )
            ) {
                /**
                 * if this program has been added and there is not a projectPlatform entry, then add the new one
                 */

                biotechProjectPlatform = new BiotechProjectPlatform();
                biotechProjectPlatform.setBiotechProgram( mapOfBiotechPrograms.get(biotechTO.getPlantCode() + biotechTO.getProgram().trim()) );
                biotechProjectPlatform.setProjectDescription( biotechTO.getProjectPlatform() );

                biotechDAO.addBiotechProjectPlatform( biotechProjectPlatform );
            }
        }
    }


    private List<BiotechProgram> getDistinctProgramListFromBiotechInfo(List<BiotechTO> biotechList){
        final List<BiotechProgram> programBiotechList = new ArrayList<BiotechProgram>();

        BiotechProgram biotechProgram = null;

        for( BiotechTO biotechTO : biotechList){

            biotechProgram = new BiotechProgram();
            biotechProgram.setPlantCode(biotechTO.getPlantCode());
            biotechProgram.setProgram(biotechTO.getProgram());

            if(! programBiotechList.contains(biotechProgram) ){
                programBiotechList.add(biotechProgram);
            }
        }
        return programBiotechList;
    }


    private Map<String, BiotechProgram> getMapOfAllBiotechPrograms() {
        Map<String, BiotechProgram> map = new HashMap<String, BiotechProgram>();
        List<BiotechProgram> allBiotechPrograms = biotechDAO.getAllBiotechPrograms();

        /**
         * We could have the same program for different plants, so we need to create a key with: plantCode + programName
         */
        for (BiotechProgram biotechProgram : allBiotechPrograms) {
            map.put( biotechProgram.getPlantCode() + biotechProgram.getProgram().trim(), biotechProgram);
        }
        return map;
    }


    private Map<String, BiotechProjectPlatform> getMapOfAllBiotechProjectPlatform() {
        Map<String, BiotechProjectPlatform> map = new HashMap<String, BiotechProjectPlatform>();
        List<BiotechProjectPlatform> allBiotechProjectPlatform = biotechDAO.getAllBiotechProjects();

        /**
         * We could have the same project for different program, so we need to create a key with: plantCode + projectDescription
         */
        for (BiotechProjectPlatform biotechProjectPlatform : allBiotechProjectPlatform) {
            map.put( biotechProjectPlatform.getBiotechProgram().getPlantCode() + biotechProjectPlatform.getProjectDescription().trim(), biotechProjectPlatform );
        }
        return map;
    }

}
