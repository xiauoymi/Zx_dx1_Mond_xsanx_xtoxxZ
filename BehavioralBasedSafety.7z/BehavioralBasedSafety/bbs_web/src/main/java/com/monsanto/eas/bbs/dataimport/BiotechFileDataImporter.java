package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 20/06/12
 * Time: 10:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class BiotechFileDataImporter implements BiotechDataImporter{

    private static final int PROJECT_PLATFORM_START = 34;
    private static final int PROJECT_PLATFORM_END = 64;
    private SpreadSheet spreadSheet;

    public BiotechFileDataImporter(String filePath) {
        spreadSheet = new FixedLengthSpreadSheet(filePath);
    }

    public List<BiotechTO> getBiotechInfo() throws IOException, ContentSetException {
        final List<BiotechTO> biotechList = new ArrayList<BiotechTO>();
        BiotechTO biotechTO;

        final ContentSet contentSet = spreadSheet.getContentSet();
        while (contentSet.next()) {
            biotechTO = new BiotechTO();
            final String plantCode = contentSet.getString(0, 4);
            final String program = contentSet.getString(4, PROJECT_PLATFORM_START);
            final String projectPlatform = contentSet.getString(PROJECT_PLATFORM_START, PROJECT_PLATFORM_END);

            if(plantCode != null && plantCode.trim().equals("")){
                continue;
            }
            biotechTO.setPlantCode(plantCode);
            biotechTO.setProgram(program);
            biotechTO.setProjectPlatform(projectPlatform);

            biotechList.add(biotechTO);
        }
        return biotechList;
    }
}
