package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.BiotechDAO;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Properties;

public final class BiotechLoaderMain {

    private static Logger logger = Logger.getLogger(BiotechLoaderMain.class);
    private static final int TOTAL_SEC_X_MIN = 60;
    private static final int TOTAL_MSEC_X_SEC = 1000;
    public static final int TOTAL_SEC_X_HR = 3600;

    private BiotechLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException {
        final Properties filePaths = new Properties();
        String filePath = "bbs.feed.biotech";

        try {
            filePaths.load(PlantLoaderMain.class.getResourceAsStream("filepaths.properties"));
        }
        catch (Exception e) {
            logger.info("ERROR: --  Could not find properties file." + e.getMessage(), e);
            return;
        }

        filePath = filePaths.getProperty(filePath);

        //--- makes a reference to deprecated.hibernate.properties.bck
        ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        BiotechDAO biotechDAO = (BiotechDAO) context.getBean("biotechDao");

        BiotechDataImporter biotechDataImporter = new BiotechFileDataImporter(filePath);
        BiotechDataLoader biotechDataLoader = new BiotechDataLoader(biotechDataImporter, biotechDAO);

        long startTime = 0;
        String elapsedTimeStr = "";

        logger.info("Running biotech feed.");
        startTime = System.currentTimeMillis();

        biotechDataLoader.loadBiotechData();

        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of biotech feed is: " + elapsedTimeStr);
    }

    public static String getElapsedTimeHMS(long elapsedTime) {
        long totalElapsedTime = elapsedTime / TOTAL_MSEC_X_SEC;
        return String.format("%d:%02d:%02d", totalElapsedTime / TOTAL_SEC_X_HR, (totalElapsedTime % TOTAL_SEC_X_HR) / TOTAL_SEC_X_MIN, (totalElapsedTime % TOTAL_SEC_X_MIN));
    }

}
