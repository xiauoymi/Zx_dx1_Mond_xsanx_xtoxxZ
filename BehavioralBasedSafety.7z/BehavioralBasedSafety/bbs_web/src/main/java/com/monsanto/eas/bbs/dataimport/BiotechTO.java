package com.monsanto.eas.bbs.dataimport;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 22/06/12
 * Time: 09:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class BiotechTO {

    private Long id;
    private String plantCode;
    private String program;
    private String projectPlatform;

    public BiotechTO(){}

    public BiotechTO(final String plantCode, final String program, final String projectPlatform) {
        this.plantCode = plantCode;
        this.program = program;
        this.projectPlatform = projectPlatform;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getProjectPlatform() {
        return projectPlatform;
    }

    public void setProjectPlatform(String projectPlatform) {
        this.projectPlatform = projectPlatform;
    }
}
