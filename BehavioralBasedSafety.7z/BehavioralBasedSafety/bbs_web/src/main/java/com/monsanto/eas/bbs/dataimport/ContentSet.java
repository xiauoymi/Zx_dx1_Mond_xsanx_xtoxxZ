package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 2:11:57 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ContentSet {
  boolean next() throws IOException;

  String getString(int startIndex, int endIndex) throws ContentSetException;

  String getStringByFieldPosition(int position) throws ContentSetException;

  void close() throws IOException;
}
