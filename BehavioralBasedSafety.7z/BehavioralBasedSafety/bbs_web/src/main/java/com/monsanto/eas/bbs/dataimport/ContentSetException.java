package com.monsanto.eas.bbs.dataimport;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 3:21:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class ContentSetException extends Exception{

  public ContentSetException(String message) {
    super(message);
  }
}
