package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.TempBBSUser;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 11:13:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EmployeeDataImporter {
  List<TempBBSUser> getEmployees() throws IOException, ContentSetException;
  List<TempBBSUser> getTempBBSUsers() throws IOException, ContentSetException;
}
