package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.DepartmentDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.dao.UserDAO;
import com.monsanto.eas.bbs.hibernate.*;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Jan 17, 2010 Time: 11:16:00 PM To change this template use File |
 * Settings | File Templates.
 */
public class EmployeeDataLoader {
    private EmployeeDataImporter employeeDataImporter;
    private PlantDAO plantDAO;
    private UserDAO userDAO;
    private DepartmentDAO departmentDAO;
    private SafetyGroupDAO safetyGroupDAO;

    private static Logger logger = Logger.getLogger(EmployeeDataLoader.class);

    public EmployeeDataLoader(EmployeeDataImporter employeeDataImporter, PlantDAO plantDAO, UserDAO userDAO, DepartmentDAO departmentDAO, SafetyGroupDAO safetyGroupDAO) {
        this.employeeDataImporter = employeeDataImporter;
        this.plantDAO = plantDAO;
        this.userDAO = userDAO;
        this.departmentDAO = departmentDAO;
        this.safetyGroupDAO = safetyGroupDAO;
    }


    public void loadEmployeeData() throws IOException, ContentSetException {
        List<TempBBSUser> tempUsersList = employeeDataImporter.getTempBBSUsers();
        try {

            userDAO.clearTempUsers();

            newSaveOrUpdateTempBBSUsers(tempUsersList);
            logger.info("Add extra info temp collection - done ");

            List<TempBBSUser> notExistingManagersList = userDAO.getTempBBSUsersWithNotExistingManager();
            if (null != notExistingManagersList && notExistingManagersList.size() > 0) {
                for (TempBBSUser tempBBSUser : notExistingManagersList) {
                    logger.error("User with invalid manager - " + tempBBSUser.getUserId() + "  invalid manager id - " + tempBBSUser.getManager());
                }

                userDAO.setDefaultValueForUsersWithInvalidManager();
            }

            Map<String, BBSUser> bbsUsersMap = userDAO.getTempBBSUsersPendingForInsert();

            for (BBSUser bbsUser : bbsUsersMap.values()) {
                insertUpdateUsers(bbsUser, bbsUsersMap);
            }
            logger.info("New Users inserted - done ");

            userDAO.updateBBSUsers();
            logger.info("Existing users updated - done ");

            userDAO.inactivateBBSUsers();
            logger.info("Users inactivated - done ");

            userDAO.clearTempUsers();

        } catch (Exception e) {
            logger.error("Error while updating users\n", e);
            //userDAO.clearTempUsers();
        }
    }


    private boolean insertUpdateUsers(BBSUser bbsUser, Map<String, BBSUser> bbsUsersMap) {
        try {
            if (bbsUser.isAlreadyPersisted()) {
                return true;
            }
            BBSUser manager = null;
            if (null != bbsUser.getManager()) {
                manager = bbsUsersMap.get(bbsUser.getManager().getUserId());
            }

            if (manager != null && !manager.getUserId().equals("")) {

                if (!manager.isAlreadyPersisted()) {
                    insertUpdateUsers(manager, bbsUsersMap);
                }
                bbsUser.setManager(manager);

            }

            if (null == manager) {
                bbsUser.setManager(null);
            }

            //userDAO.addUser(bbsUser);
            logger.info("user inserted " + bbsUser.getUserId());
            bbsUser.setAlreadyPersisted(true);
        } catch (Exception e) {
            logger.error("Error while inserting users\n" + bbsUser.toString(), e);
        }
        return true;
    }

    private void newSaveOrUpdateTempBBSUsers(List<TempBBSUser> tempUsersList) {
        Map<String, Plant> mapOfPlantsByCode = plantDAO.getMapOfAllPlants();
        Map<String, SafetyGroup> mapOfSafetyGroupsByCode = safetyGroupDAO.getMapOfAllSafetyGroups();
        Map<Long, Department> mapOfDepartmentsByCode = departmentDAO.getMapOfAllDepartments();

        String userLocationCode;
        String safetyGroupPlantCode;
        SafetyGroup group;
        Plant plant;
        Department currentDepartment;

        for (TempBBSUser tempBBSUser : tempUsersList) {
            userLocationCode = tempBBSUser.getLocationCode();

            if (mapOfSafetyGroupsByCode.containsKey(userLocationCode)) {
                group = mapOfSafetyGroupsByCode.get(userLocationCode);
                safetyGroupPlantCode = group.getPlantCode();

                if (mapOfPlantsByCode.containsKey(safetyGroupPlantCode)) {
                    plant = mapOfPlantsByCode.get(safetyGroupPlantCode);
                    tempBBSUser.setPlant(plant);
                }

            } else {
                tempBBSUser.setPlant(null);
            }

            currentDepartment = tempBBSUser.getDepartment();
            if (currentDepartment != null) {
                Department existingDepartment = mapOfDepartmentsByCode.get(currentDepartment.getCode());
                if (existingDepartment != null) {
                    currentDepartment = existingDepartment;
                }
                else if (!currentDepartment.getName().trim().equals("")) {
                    currentDepartment = new Department(currentDepartment.getCode(), currentDepartment.getName());
                }
            }

            tempBBSUser.setDepartment(currentDepartment);
            userDAO.addTempUser(tempBBSUser);
        }
    }
}
