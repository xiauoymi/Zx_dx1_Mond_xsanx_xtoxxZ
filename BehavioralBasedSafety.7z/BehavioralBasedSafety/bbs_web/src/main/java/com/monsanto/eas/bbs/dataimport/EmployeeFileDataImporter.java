package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Department;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempBBSUser;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class EmployeeFileDataImporter implements EmployeeDataImporter {

    private static final String DEPARTMENT_ERROR_FOR_USER_ID = "Department error for UserId: ";

    private enum EMPLOYEE_DATA_FIELDS
    {
        PLANT_CODE(Constants.PLANT_CODE_POSITION),
        USER_ID(Constants.USER_ID_POSITION),
        LAST_NAME(Constants.LAST_NAME_POSITION),
        FIRST_NAME(Constants.FIRST_NAME_POSITION),
        DEPARTMENT_CODE(Constants.DEPARTMENT_CODE_POSITION),
        DEPARTMENT_DESC(Constants.DEPARTMENT_DESC_POSITION),
        COMPANY_CODE(Constants.COMPANY_CODE_POSITION),
        BUSINESS_AREA(Constants.BUSINESS_AREA_POSITION),
        COST_CENTER(Constants.COST_CENTER_POSITION),
        PHONE_NUMBER(Constants.PHONE_NUMBER_POSITION),
        MANAGER_USER_ID(Constants.MANAGER_USER_ID_POSITION);

        private final int position;

        EMPLOYEE_DATA_FIELDS(int position) {
            this.position = position;
        }

        public int position() {
            return position;
        }

        private static final class Constants
        {
            private Constants() {}
            private static final int PLANT_CODE_POSITION = 2;
            private static final int USER_ID_POSITION = 7;
            private static final int LAST_NAME_POSITION = 8;
            private static final int FIRST_NAME_POSITION = 9;
            private static final int DEPARTMENT_CODE_POSITION = 10;
            private static final int DEPARTMENT_DESC_POSITION = 11;
            private static final int COMPANY_CODE_POSITION = 12;
            private static final int BUSINESS_AREA_POSITION = 13;
            private static final int COST_CENTER_POSITION = 14;
            private static final int PHONE_NUMBER_POSITION = 15;
            private static final int MANAGER_USER_ID_POSITION = 17;
        }
    }

    private SpreadSheet spreadSheet;

    private static Logger logger = Logger.getLogger(EmployeeFileDataImporter.class);

    public EmployeeFileDataImporter(String filePath) {
        spreadSheet = new FixedLengthSpreadSheet(filePath);
    }

    public List<TempBBSUser> getEmployees() throws IOException, ContentSetException {
        List<TempBBSUser> tempUsers = new ArrayList<TempBBSUser>();
        ContentSet contentSet = spreadSheet.getContentSet();

        while (contentSet.next()) {

            TempBBSUser bbsUser = new TempBBSUser();

            String plantCode = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.PLANT_CODE.position() );
            final String locationCode = plantCode;
            String userId = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.USER_ID.position() );
            String lastName = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.LAST_NAME.position() );
            String firstName = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.FIRST_NAME.position() );
            Long departmentCode = null;

            try {
                departmentCode = Long.valueOf(contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.DEPARTMENT_CODE.position() ).trim());
            } catch (NumberFormatException e) {
                logger.error(DEPARTMENT_ERROR_FOR_USER_ID + userId);
            }
            String departmentDesc = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.DEPARTMENT_DESC.position() ).trim();

            bbsUser.setFirstName(firstName);
            bbsUser.setLastName(lastName);
            bbsUser.setUserId(userId);
            Plant plant = new Plant();
            plant.setPlantCode(plantCode);
            bbsUser.setPlant(plant);

            Department department = new Department();
            department.setCode(departmentCode);
            department.setName(departmentDesc);
            bbsUser.setDepartment(department);

            bbsUser.setLocationCode(locationCode);

            tempUsers.add(bbsUser);

        }
        return tempUsers;
    }

    public List<TempBBSUser> getTempBBSUsers() throws IOException, ContentSetException {
        List<TempBBSUser> tempUsers = new ArrayList<TempBBSUser>();
        ContentSet contentSet = spreadSheet.getContentSet();

        TempBBSUser bbsUser = null;
        TempBBSUser bbsUserManager = null;

        String userId;
        String plantCode = null;
        String locationCode = null;
        String lastName = null;
        String firstName = null;
        Long departmentCode = null;

        String companyCode = null;
        String businessArea = null;
        String costCenter = null;
        String phoneNumber = null;
        String managerUserId = null;
        String departmentDesc = null;

        Plant plant = null;
        Department department = null;

        //--To skip column header
        contentSet.next();

        while (contentSet.next()) {

            userId = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.USER_ID.position() );

            if (null == userId || "".equals(userId)) {
                continue;
            }

            bbsUser = new TempBBSUser();
            bbsUserManager = new TempBBSUser();

            plantCode = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.PLANT_CODE.position() );
            locationCode = plantCode;

            lastName = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.LAST_NAME.position() );
            firstName = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.FIRST_NAME.position() );

            companyCode = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.COMPANY_CODE.position() );
            businessArea = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.BUSINESS_AREA.position() );
            costCenter = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.COST_CENTER.position() );
            phoneNumber = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.PHONE_NUMBER.position() );
            managerUserId = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.MANAGER_USER_ID.position() );

            try {
                departmentCode = Long.valueOf(contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.DEPARTMENT_CODE.position() ).trim());
            } catch (NumberFormatException e) {
                logger.error(DEPARTMENT_ERROR_FOR_USER_ID + userId);
            }
            departmentDesc = contentSet.getStringByFieldPosition( EMPLOYEE_DATA_FIELDS.DEPARTMENT_DESC.position() ).trim();

            bbsUser.setFirstName(firstName);
            bbsUser.setLastName(lastName);
            bbsUser.setUserId(userId);
            //bbsUser.setEmployee(true);
            //bbsUser.setActive(true);
            plant = new Plant();
            plant.setPlantCode(plantCode);
            bbsUser.setPlant(plant);

            department = new Department();
            department.setCode(departmentCode);
            department.setName(departmentDesc);
            bbsUser.setDepartment(department);

            bbsUser.setLocationCode(locationCode);
            bbsUser.setCostCenter(costCenter);

            bbsUser.setCompanyCode(companyCode);
            bbsUser.setBusinessArea(businessArea);

            bbsUser.setPhoneNumber(phoneNumber);

            if (!managerUserId.equals(userId)) {
                bbsUserManager.setUserId(managerUserId);
                bbsUser.setManager(managerUserId);
            }
            //bbsUser.setManager(bbsUserManager);


            /*
            if (null != phoneNumber && !phoneNumber.equals("") && phoneNumber.length() > 19) {
                    System.out.println("pc: " + plantCode + "  lc: " + locationCode + "  ui: " + userId + "  ln: " + lastName + "  fn:" + firstName
                            + "  dc: " + departmentCode + "  dd: " + departmentDesc
                            + "  cc: " + companyCode + "  ba: " + businessArea + "  cc: " + costCenter + "  pn: " + phoneNumber + "  mi:" + managerUserId);

            }
            */

            tempUsers.add(bbsUser);
        }
        return tempUsers;
    }

}
