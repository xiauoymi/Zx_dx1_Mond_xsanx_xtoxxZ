package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.DepartmentDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.dao.UserDAO;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 9:40:29 PM
 * To change this template use File | Settings | File Templates.
 */

public final class EmployeeLoaderMain {

    private static Logger logger = Logger.getLogger(EmployeeLoaderMain.class);

    private EmployeeLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException {
        final Properties filepaths = new Properties();
        String filePath = "bbs.feed.hr";

        try {
            filepaths.load(PlantLoaderMain.class.getResourceAsStream("filepaths.properties"));
        } catch (IOException e) {
            logger.error("Could not find properties file.", e);
            return;
        }
        filePath = filepaths.getProperty(filePath);

        ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        PlantDAO plantDAO = (PlantDAO) context.getBean("plantDao");
        UserDAO userDAO = (UserDAO) context.getBean("userDao");
        DepartmentDAO departmentDAO = (DepartmentDAO) context.getBean("departmentDAO");
        SafetyGroupDAO safetyGroupDAO = (SafetyGroupDAO) context.getBean("safetyGroupDao");
        EmployeeDataImporter employeeDataImporter = new EmployeeFileDataImporter(filePath);
        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, departmentDAO, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();

        logger.info("Complete.");
    }
}