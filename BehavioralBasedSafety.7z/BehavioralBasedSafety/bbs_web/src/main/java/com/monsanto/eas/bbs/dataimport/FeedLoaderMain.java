/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.eas.bbs.dao.*;
import com.monsanto.eas.bbs.util.EmailBean;
import com.monsanto.eas.bbs.util.EmailBeanException;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public final class FeedLoaderMain {
    private static final String ENV_D_PARAM = "env";
    private static final String LSI_FUNCTION = "lsi.function";
    private static final String BATCH_JOB_PROPERTIES = "batch-job";

    public static final int TOTAL_SEC_X_HR = 3600;
    public static final int TOTAL_SEC_X_MIN = 60;
    private static final int TOTAL_MSEC_X_SEC = 1000;

    private static Logger logger = Logger.getLogger(FeedLoaderMain.class);

    private FeedLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException, EncryptorException,
            EmailBeanException {

        long startTotalTime = System.currentTimeMillis();
        Format formatter = new SimpleDateFormat("HH:mm:ss a");
        logger.info("Feed batch process started at: " + formatter.format(new Date()));

        final ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");

        FeedPaths paths = FeedPaths.getPaths();
        if (paths == null) {
            return;
        }
        if (!dataSourceSuccessfullyInitialized(context)) {
            return;
        }

        final PlantDAO plantDAO = (PlantDAO) context.getBean("plantDao");
        final OrgUnitDAO orgUnitDAO = (OrgUnitDAO) context.getBean("orgUnitDao");
        final SafetyGroupDAO safetyGroupDAO = (SafetyGroupDAO) context.getBean("safetyGroupDao");
        final WorkAreaDAO workAreaDAO = (WorkAreaDAO) context.getBean("workAreaDao");
        final DepartmentDAO departmentDAO = (DepartmentDAO) context.getBean("departmentDAO");
        final UserDAO userDAO = (UserDAO) context.getBean("userDao");
        final CountryDAO countryDAO = (CountryDAO) context.getBean("countryDao");
        final BiotechDAO biotechDAO = (BiotechDAO) context.getBean("biotechDao");

        final WorkAreaDataImporter workAreaDataImporter = new WorkAreaFileDataImporter(paths.getWorkAreaFeedPath());
        final WorkAreaDataLoader workAreaDataLoader = new WorkAreaDataLoader(workAreaDataImporter, workAreaDAO);

        final PlantDataImporter plantDataImporter = new PlantFileDataImporter(paths.getPlantFeedPath());
        final PlantDataLoader plantDataLoader = new PlantDataLoader(plantDataImporter, plantDAO, countryDAO);
        final EmailBean email = (EmailBean) context.getBean("plantDataEmailBean");

        final OrganizationUnitImporter organizationUnitImporter = new OrganizationUnitFileDataImporter(paths.getOrgUnitPath());
        final OrganizationUnitDataLoader organizationUnitDataLoader = new OrganizationUnitDataLoader(organizationUnitImporter, orgUnitDAO);

        final SafetyGroupDataImporter safetyGroupDataImporter = new SafetyGroupFileDataImporter(paths.getSafetyGroupFeedPath());
        final SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO,
                orgUnitDAO, safetyGroupDAO);

        final EmployeeDataImporter employeeDataImporter = new EmployeeFileDataImporter(paths.getHrFeedPath());
        final EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO,
                departmentDAO, safetyGroupDAO);

        final BiotechDataImporter biotechDataImporter = new BiotechFileDataImporter(paths.getBiotechFeedPath());
        final BiotechDataLoader biotechDataLoader = new BiotechDataLoader(biotechDataImporter, biotechDAO);

        long startTime = 0;
        String elapsedTimeStr = "";

        logger.info("Running plant feed.");
        startTime = System.currentTimeMillis();
        plantDataLoader.newLoadPlantData(email);
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of plant feed is: " + elapsedTimeStr);

        logger.info("Running work_area feed.");
        startTime = System.currentTimeMillis();
        workAreaDataLoader.loadWorkAreaData();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of work_area feed is: " + elapsedTimeStr);

        logger.info("Running plant description update.");
        startTime = System.currentTimeMillis();
        plantDAO.updatePlantWorkAreas();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of the plant description update is: " + elapsedTimeStr);

        logger.info("Running biotech feed.");
        startTime = System.currentTimeMillis();
        biotechDataLoader.loadBiotechData();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of biotech feed is: " + elapsedTimeStr);

        logger.info("Running org units feed.");
        startTime = System.currentTimeMillis();
        organizationUnitDataLoader.loadOrganizationUnits();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of org units feed is: " + elapsedTimeStr);

        logger.info("Running safety_group feed.");
        startTime = System.currentTimeMillis();
        safetyGroupDataLoader.loadSafetyGroupData();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of safety_group feed is: " + elapsedTimeStr);

        logger.info("Running employee feed.");
        startTime = System.currentTimeMillis();
        employeeDataLoader.loadEmployeeData();
        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTime);
        logger.info("Total elapsed time in execution of employee feed is: " + elapsedTimeStr);

        elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTotalTime);
        logger.info("Completed in: " + elapsedTimeStr);

        logger.info("Feed batch process finished at: " + formatter.format(new Date()));
    }

    private static boolean dataSourceSuccessfullyInitialized(ApplicationContext context) throws EncryptorException {
        boolean success = false;
        try {
            String databaseUrl = getDatabaseUrl();
            String username = getDatabaseUsername();
            logger.info("url = " + databaseUrl);
            logger.info("username = " + username);

            BasicDataSource dataSource = (BasicDataSource) context.getBean("dataSource");
            dataSource.setUrl(databaseUrl);
            dataSource.setUsername(username);
            dataSource.setPassword(EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "bbs", "CipherValue.hex", "KeyValue.hex"));
            success = true;
        }
        catch (Exception e) {
            logger.error("ERROR: --  No database URL/username found. Please pass a -Denv param with value dev,test or prod. " + e.getMessage(), e);
        }
        return success;
    }

    public static String getElapsedTimeHMS(long elapsedTime) {
        long totalElapsedTime = elapsedTime / TOTAL_MSEC_X_SEC;
        return String.format("%d:%02d:%02d", totalElapsedTime / TOTAL_SEC_X_HR, (totalElapsedTime % TOTAL_SEC_X_HR) / TOTAL_SEC_X_MIN, (totalElapsedTime % TOTAL_SEC_X_MIN));
    }

    private static String getDatabaseUrl() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".connection.url");
    }

    private static String getDatabaseUsername() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".username");
    }

    private static String getEnvironment() {
        String env = System.getProperty(ENV_D_PARAM);
        if (env == null) {
            env = System.getProperty(LSI_FUNCTION);
        }
        return env;
    }
}

