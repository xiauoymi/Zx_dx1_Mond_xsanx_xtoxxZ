package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Properties;

public final class FeedPaths
{
    private static final Logger LOG = Logger.getLogger(FeedLoaderMain.class);
    private static final String BBS_FEED_PROPERTIES_FILE = "bbs_feed.properties";
    private static final String BBS_FEED_PLANT_KEY = "bbs.feed.plant";
    private static final String BBS_FEED_WORK_AREA_KEY = "bbs.feed.work_area";
    private static final String BBS_FEED_SAFETY_GROUP_KEY = "bbs.feed.safety_group";
    private static final String BBS_FEED_HR_KEY = "bbs.feed.hr";
    private static final String BBS_FEED_BIOTECH_KEY = "bbs.feed.biotech";
    private static final String BBS_ORG_UNIT_KEY = "bbs.org.unit";

    private final String plantFeedPath;
    private final String workAreaFeedPath;
    private final String safetyGroupFeedPath;
    private final String hrFeedPath;
    private final String biotechFeedPath;
    private final String orgUnitPath;

    public static FeedPaths getPaths() {
        FeedPaths paths = null;
        try {
            paths = new FeedPaths();
        }
        catch (IOException ioe) {
            LOG.error("ERROR: --  Could not find properties file." + ioe.getMessage(), ioe);
        }
        return paths;
    }

    private FeedPaths() throws IOException {
        Properties feedPaths = new Properties();
        feedPaths.load(getClass().getResourceAsStream(BBS_FEED_PROPERTIES_FILE));
        plantFeedPath = feedPaths.getProperty(BBS_FEED_PLANT_KEY);
        workAreaFeedPath = feedPaths.getProperty(BBS_FEED_WORK_AREA_KEY);
        orgUnitPath = feedPaths.getProperty(BBS_ORG_UNIT_KEY);
        safetyGroupFeedPath = feedPaths.getProperty(BBS_FEED_SAFETY_GROUP_KEY);
        hrFeedPath = feedPaths.getProperty(BBS_FEED_HR_KEY);
        biotechFeedPath = feedPaths.getProperty(BBS_FEED_BIOTECH_KEY);
    }

    public String getPlantFeedPath() {
        return plantFeedPath;
    }

    public String getWorkAreaFeedPath() {
        return workAreaFeedPath;
    }

    public String getSafetyGroupFeedPath() {
        return safetyGroupFeedPath;
    }

    public String getHrFeedPath() {
        return hrFeedPath;
    }

    public String getBiotechFeedPath() {
        return biotechFeedPath;
    }

    public String getOrgUnitPath() {
        return orgUnitPath;
    }
}
