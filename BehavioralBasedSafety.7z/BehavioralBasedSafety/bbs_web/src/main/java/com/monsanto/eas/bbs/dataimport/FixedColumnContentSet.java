package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Jan 17, 2010 Time: 2:12:10 PM To change this template use File |
 * Settings | File Templates.
 */
public class FixedColumnContentSet implements ContentSet {
   private static final String LINE = "Line Is: ";
   private BufferedReader bufferedReader;
   private String lineRead;

   private static Logger logger = Logger.getLogger(FixedColumnContentSet.class);

   public FixedColumnContentSet(BufferedReader bufferedReader) {
      this.bufferedReader = bufferedReader;
   }

   public boolean next() throws IOException {
      lineRead = bufferedReader.readLine();
      return lineRead != null;
   }

   public String getString(int startIndex, int endIndex) throws ContentSetException {
      if (lineRead.length() < endIndex) {
         try {
            if (startIndex < lineRead.length()) {
               return lineRead.substring(startIndex, lineRead.length());
            }
            return "";
         } catch (Exception e) {
            logger.error(LINE + lineRead, e);
            return "";
         }
//      throw new ContentSetException("End index greater than lengh at :" + lineRead);
      } else {
         return lineRead.substring(startIndex, endIndex);
      }
   }

   public String getStringByFieldPosition(int position) throws ContentSetException {
      //String[] fields = null;
      try{
         //fields = lineRead.split("\t", -1);
         //return fields[position];
         return (lineRead.split("\t", -1))[position];

      } catch (Exception e) {
         logger.error(LINE + lineRead, e);
         return "";
      }
   }

   public void close() throws IOException {
      bufferedReader.close();
   }
}
