package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 4:31:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class FixedLengthSpreadSheet implements SpreadSheet {
   private String filePath;

   private static Logger logger = Logger.getLogger(FixedLengthSpreadSheet.class);

   public FixedLengthSpreadSheet(String filePath) {
      this.filePath = filePath;

      String path = System.getProperty("file.path");
      if (path != null && !path.equals("")) {
         this.filePath = path + filePath;
      }
      logger.info("filePath: " + this.filePath);
   }

   public ContentSet getContentSet() throws FileNotFoundException {
      ContentSet contentSet = null;
      try {
         contentSet = new FixedColumnContentSet(new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF8")));
      }
      catch (UnsupportedEncodingException e) {
         logger.error("Encoding not supported for file: " + this.filePath, e);
      }
      return contentSet;
   }
}
