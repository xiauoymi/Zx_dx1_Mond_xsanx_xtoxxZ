package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 31/10/12
 * Time: 01:07 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LanAreaDataImporter {
   Map<String, String> getLanguageBasedAreasDictionary() throws IOException, ContentSetException;
}
