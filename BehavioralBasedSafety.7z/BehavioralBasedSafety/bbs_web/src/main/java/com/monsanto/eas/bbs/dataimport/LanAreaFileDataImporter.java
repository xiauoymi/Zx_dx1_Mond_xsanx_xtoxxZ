package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 31/10/12
 * Time: 01:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class LanAreaFileDataImporter implements LanAreaDataImporter {

   private static final int LANG_BASED_DESCRIPTION_START = 59;
   private static final int LANG_BASED_DESCRIPTION_END = 120;
   private SpreadSheet spreadSheet;

   private static Logger logger = Logger.getLogger(LanAreaFileDataImporter.class);

   public LanAreaFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public Map<String, String> getLanguageBasedAreasDictionary() throws IOException, ContentSetException {
      final ContentSet contentSet = spreadSheet.getContentSet();

      Map<String, String> dictionary = new HashMap<String, String>();
      String langBasedDescription = null;
      String langBasedArea = null;

      while (contentSet.next()) {

         langBasedArea = contentSet.getString(0, LANG_BASED_DESCRIPTION_START).trim();

         if (!dictionary.containsKey(langBasedArea)) {
            langBasedDescription = contentSet.getString(LANG_BASED_DESCRIPTION_START, LANG_BASED_DESCRIPTION_END).trim();
            dictionary.put(langBasedArea, langBasedDescription);

            if (langBasedDescription != null && langBasedDescription.equals("")) {
               logger.info("There is not a translation for: " + langBasedArea);
            }
         }
      }

      return dictionary;
   }


}
