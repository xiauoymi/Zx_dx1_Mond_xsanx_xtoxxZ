package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 10:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class LanBarrierCatFileDataImporter implements LanBarrierCatDataImporter {

   private static final int LANG_BASED_DESCRIPTION_START = 79;
   private static final int LANG_BASED_DESCRIPTION_END = 170;
   private SpreadSheet spreadSheet;

   private static Logger logger = Logger.getLogger(LanBarrierCatFileDataImporter.class);

   public LanBarrierCatFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public Map<String, String> getLanguageBasedBarrierCatDictionary() throws IOException, ContentSetException {
      final ContentSet contentSet = spreadSheet.getContentSet();

      Map<String, String> dictionary = new HashMap<String, String>();
      String langBasedDescription = null;
      String langBasedBarrierCat = null;

      while (contentSet.next()) {

         langBasedBarrierCat = contentSet.getString(0, LANG_BASED_DESCRIPTION_START).trim();

         if (!dictionary.containsKey(langBasedBarrierCat)) {
            langBasedDescription = contentSet.getString(LANG_BASED_DESCRIPTION_START, LANG_BASED_DESCRIPTION_END).trim();
            dictionary.put(langBasedBarrierCat, langBasedDescription);

            if (langBasedDescription != null && langBasedDescription.equals("")) {
               logger.info("There is not a translation for: " + langBasedBarrierCat);
            }
         }
      }

      return dictionary;
   }
}
