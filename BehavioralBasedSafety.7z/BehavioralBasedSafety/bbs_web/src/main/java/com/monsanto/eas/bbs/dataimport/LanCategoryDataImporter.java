package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 11:22 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LanCategoryDataImporter {
   Map<String, String> getLanguageBasedCategoryDictionary() throws IOException, ContentSetException;
}
