package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 11:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class LanCategoryFileDataImporter implements LanCategoryDataImporter {

   private static final int LANG_BASED_DESCRIPTION_START = 79;
   private static final int LANG_BASED_DESCRIPTION_END = 160;
   private SpreadSheet spreadSheet;

   private static Logger logger = Logger.getLogger(LanCategoryFileDataImporter.class);

   public LanCategoryFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public Map<String, String> getLanguageBasedCategoryDictionary() throws IOException, ContentSetException {
      final ContentSet contentSet = spreadSheet.getContentSet();

      Map<String, String> dictionary = new HashMap<String, String>();
      String langBasedDescription = null;
      String langBasedCategory = null;

      while (contentSet.next()) {

         langBasedCategory = contentSet.getString(0, LANG_BASED_DESCRIPTION_START).trim();

         if (!dictionary.containsKey(langBasedCategory)) {
            langBasedDescription = contentSet.getString(LANG_BASED_DESCRIPTION_START, LANG_BASED_DESCRIPTION_END).trim();
            dictionary.put(langBasedCategory, langBasedDescription);

            if (langBasedDescription != null && langBasedDescription.equals("")) {
               logger.info("There is not a translation for: " + langBasedCategory);
            }
         }
      }

      return dictionary;
   }
}
