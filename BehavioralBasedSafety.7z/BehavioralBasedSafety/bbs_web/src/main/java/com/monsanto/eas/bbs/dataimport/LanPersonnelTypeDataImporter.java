package com.monsanto.eas.bbs.dataimport;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 01:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LanPersonnelTypeDataImporter {
   Map<String, String> getLanguageBasedPersonnelTypeDictionary() throws IOException, ContentSetException;
}
