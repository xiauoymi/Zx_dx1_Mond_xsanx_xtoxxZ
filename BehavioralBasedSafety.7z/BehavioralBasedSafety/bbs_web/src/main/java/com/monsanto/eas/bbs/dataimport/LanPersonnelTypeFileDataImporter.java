package com.monsanto.eas.bbs.dataimport;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 01:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class LanPersonnelTypeFileDataImporter implements LanPersonnelTypeDataImporter{

   private static final int LANG_BASED_DESCRIPTION_START = 39;
   private static final int LANG_BASED_DESCRIPTION_END = 90;
   private SpreadSheet spreadSheet;

   private static Logger logger = Logger.getLogger(LanPersonnelTypeFileDataImporter.class);

   public LanPersonnelTypeFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public Map<String, String> getLanguageBasedPersonnelTypeDictionary() throws IOException, ContentSetException {
      final ContentSet contentSet = spreadSheet.getContentSet();

      Map<String, String> dictionary = new HashMap<String, String>();
      String langBasedDescription = null;
      String langBasedPersonnelType = null;

      while (contentSet.next()) {

         langBasedPersonnelType = contentSet.getString(0, LANG_BASED_DESCRIPTION_START).trim();

         if (!dictionary.containsKey(langBasedPersonnelType)) {
            langBasedDescription = contentSet.getString(LANG_BASED_DESCRIPTION_START, LANG_BASED_DESCRIPTION_END).trim();
            dictionary.put(langBasedPersonnelType, langBasedDescription);

            if (langBasedDescription != null && langBasedDescription.equals("")) {
               logger.info("There is not a translation for: " + langBasedPersonnelType);
            }
         }
      }

      return dictionary;
   }

}
