package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dao.PersonnelTypeDAO;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.service.*;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 31/10/12
 * Time: 06:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class LanguageDataLoader {

    private LanAreaDataImporter lanAreaDataImporter;
    private LanBarrierCatDataImporter lanBarrierCatDataImporter;
    private LanCategoryDataImporter lanCategoryDataImporter;
    private LanCategoryTypeDataImporter lanCategoryTypeDataImporter;
    private LanLanguageDataImporter lanLanguageDataImporter;
    private LanPersonnelTypeDataImporter lanPersonnelTypeDataImporter;
    private LanLanguageResponseDataImporter lanLanguageResponseDataImporter;

    private LanguageDAO languageDao;

    private LanguageService languageService;
    //private AreaService areaService;
    private LanguageBasedAreaService languageBasedAreaService;
    private CategoryService categoryService;
    private PersonnelTypeService personnelTypeService;


    private static Logger logger = Logger.getLogger(LanguageDataLoader.class);

    public LanguageDataLoader(LanguageDAO languageDao) {
        this.languageDao = languageDao;
        this.languageService = new LanguageServiceImpl(languageDao);
    }

    public LanguageDataLoader(CategoryDAO categoryDao, LanguageBasedAreaDAO languageBasedAreaDAO,
                              LanguageDAO languageDao, PersonnelTypeDAO personnelDao) {

        this.languageDao = languageDao;
        this.languageService = new LanguageServiceImpl(languageDao);
        //this.areaService = new AreaServiceImpl(languageDao);
        this.languageBasedAreaService = new LanguageBasedAreaServiceImpl(languageBasedAreaDAO, languageDao);
        this.categoryService = new CategoryServiceImpl(categoryDao, languageDao);
        this.personnelTypeService = new PersonnelTypeServiceImpl(personnelDao);
    }

    public void setLanAreaDataImporter(LanAreaDataImporter lanAreaDataImporter) {
        this.lanAreaDataImporter = lanAreaDataImporter;
    }

    public void setLanBarrierCatDataImporter(LanBarrierCatDataImporter lanBarrierCatDataImporter) {
        this.lanBarrierCatDataImporter = lanBarrierCatDataImporter;
    }

    public void setLanCategoryDataImporter(LanCategoryDataImporter lanCategoryDataImporter) {
        this.lanCategoryDataImporter = lanCategoryDataImporter;
    }

    public void setLanCategoryTypeDataImporter(LanCategoryTypeDataImporter lanCategoryTypeDataImporter) {
        this.lanCategoryTypeDataImporter = lanCategoryTypeDataImporter;
    }

    public void setLanLanguageDataImporter(LanLanguageDataImporter lanLanguageDataImporter) {
        this.lanLanguageDataImporter = lanLanguageDataImporter;
    }

    public void setLanPersonnelTypeDataImporter(LanPersonnelTypeDataImporter lanPersonnelTypeDataImporter) {
        this.lanPersonnelTypeDataImporter = lanPersonnelTypeDataImporter;
    }

    public void setLanLanguageResponseDataImporter(LanLanguageResponseDataImporter lanLanguageResponseDataImporter) {
        this.lanLanguageResponseDataImporter = lanLanguageResponseDataImporter;
    }


    public void loadLanguageBasedData(String locale) throws IOException, ContentSetException {

        Language language = languageDao.lookupLanguageByLocale(locale);

        addLanguagesBasedAreas(language);
        addLanguageBarrierCat(language);
        addLanguageCategory(language);
        addLanguageCategoryType(language);
        addLanguageDescription(language);
        addLanguagePersonnelType(language);
        addLanguageResponse(language);

    }

    public void addNewLanguage(String languageDesc, String locale) {
        languageService.insertLanguage(languageDesc, true, locale);
        logger.info("Adding new language: " + languageDesc + "  -- completed ");
    }

    private void addLanguagesBasedAreas(Language language) {
        try {
            Map<String, String> langBasedDescriptionDictionary = lanAreaDataImporter.getLanguageBasedAreasDictionary();
            //areaService.addLanguageBasedAreas(language, langBasedDescriptionDictionary);
            languageBasedAreaService.addLanguageBasedAreas(language, langBasedDescriptionDictionary);
            logger.info("Adding language based areas. -- completed ");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguageBarrierCat(Language language) {
        try {
            Map<String, String> langBasedBarrierCatDictionary = lanBarrierCatDataImporter.getLanguageBasedBarrierCatDictionary();
            categoryService.addLanguageBarrierCat(language, langBasedBarrierCatDictionary);
            logger.info("Adding language barrier cats. -- completed ");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguageCategory(Language language) {
        try {
            Map<String, String> langBasedCategoryDictionary = lanCategoryDataImporter.getLanguageBasedCategoryDictionary();
            categoryService.addLanguageBasedCategory(language, langBasedCategoryDictionary);
            logger.info("Adding language categories. -- completed");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguageCategoryType(Language language) {
        try {
            Map<String, String> langBasedCategoryTypeDictionary = lanCategoryTypeDataImporter.getLanguageBasedCategoryTypeDictionary();
            categoryService.addLanguageBasedCategoryType(language, langBasedCategoryTypeDictionary);
            logger.info("Adding language category types. -- completed");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguageDescription(Language language) {
        try {
            Map<String, String> langBasedLanguageDescDictionary = lanLanguageDataImporter.getLanguageBasedLanguageDescriptionDictionary();
            languageService.addLanguageDescription(language, langBasedLanguageDescDictionary);
            logger.info("Adding language based language. -- completed");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguagePersonnelType(Language language) {
        try {
            Map<String, String> langBasedPersonnelTypeDictionary = lanPersonnelTypeDataImporter.getLanguageBasedPersonnelTypeDictionary();
            personnelTypeService.addLanguagePersonnelType(language, langBasedPersonnelTypeDictionary);
            logger.info("Adding language based personnel types. -- completed");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

    private void addLanguageResponse(Language language) {
        try {
            Map<String, String> langBasedLanguageResponseDictionary = lanLanguageResponseDataImporter.getLanguageBasedLanguageResponseDictionary();
            languageService.addLanguageResponse(language, langBasedLanguageResponseDictionary);
            logger.info("Adding language based responses. -- completed");
        }
        catch (IOException ioe) {
            logger.error(ioe.getMessage(), ioe);
        }
        catch (ContentSetException cse) {
            logger.error(cse.getMessage(), cse);
        }
    }

}
