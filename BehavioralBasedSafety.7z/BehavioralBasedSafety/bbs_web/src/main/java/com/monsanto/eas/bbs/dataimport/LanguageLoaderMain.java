/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dao.PersonnelTypeDAO;
import com.monsanto.eas.bbs.util.EmailBeanException;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;


/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class LanguageLoaderMain {
    private static final String ENV_D_PARAM = "env";
    private static final String LSI_FUNCTION = "lsi.function";
    private static final String BATCH_JOB_PROPERTIES = "batch-job";

    public static final int TOTAL_SEC_X_HR = 3600;
    public static final int TOTAL_SEC_X_MIN = 60;
    private static final int TOTAL_MSEC_X_SEC = 1000;

    private static Logger logger = Logger.getLogger(LanguageLoaderMain.class);
    private CategoryDAO categoryDao;
    private LanguageDAO languageDao;
    private PersonnelTypeDAO personnelDao;
    //private AreaDAO areaDAO;
    private LanguageBasedAreaDAO languageBasedAreaDAO;

    public LanguageLoaderMain() throws EncryptorException {
        initContext();
    }

    public static void main(String[] args) throws IOException, ContentSetException, EmailBeanException, EncryptorException {

        String localeCode = null;
        String languageDescription = null;

        if (args.length == 0 || args.length % 2 != 0) {
            logger.error("Language & locale description parameters needed");
            System.exit(0);
        }

        LanguageLoaderMain languageLoaderMain = new LanguageLoaderMain();


        ///---Variable to keep the total elapsed time of the execution of the feed process
        long startTotalTime = System.currentTimeMillis();
        Format formatter = new SimpleDateFormat("HH:mm:ss a");

        logger.info("Language feed batch process started at: " + formatter.format(new Date()));

        //----1. Insert the list of languages
        for (int i = 0; i < args.length; i += 2) {
            languageDescription = args[i];
            localeCode = args[i + 1];

            if (localeCode.length() > 2 && !localeCode.contains("-")) {
                logger.error("Locale code " + localeCode + " is malformed");
                System.exit(0);
            }

            languageLoaderMain.addNewLanguage(languageDescription, localeCode);
        }

        //----2. Per each inserted language, insert the remaining language based info.
        for (int i = 0; i < args.length; i += 2) {
            localeCode = args[i + 1];

            languageLoaderMain.feedLanguageProcess(localeCode);
        }

        String elapsedTimeStr = getElapsedTimeHMS(System.currentTimeMillis() - startTotalTime);
        logger.info("Completed in: " + elapsedTimeStr);

        logger.info("Language based feed process finished at: " + formatter.format(new Date()));
    }

    private void initContext() throws EncryptorException {
        String databaseUrl = null;
        String username = null;

        try {
            databaseUrl = getDatabaseUrl();
            username = getDatabaseUsername();
        }
        catch (Exception e) {
            logger.error("ERROR: --  No database URL/username found. Please pass a -Denv param with value dev,test or prod. " + e.getMessage(), e);
            return;
        }

        final ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        BasicDataSource dataSource = (BasicDataSource) context.getBean("dataSource");

        logger.info("url = " + databaseUrl);
        logger.info("username = " + username);

        dataSource.setUrl(databaseUrl);
        dataSource.setUsername(username);
        dataSource.setPassword(EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "bbs", "CipherValue.hex", "KeyValue.hex"));

        categoryDao = (CategoryDAO) context.getBean("categoryTypeDao");
        languageDao = (LanguageDAO) context.getBean("languageDao");
        personnelDao = (PersonnelTypeDAO) context.getBean("personnelDao");
        //areaDAO = (AreaDAO) context.getBean("areaDao");
        languageBasedAreaDAO = (LanguageBasedAreaDAO) context.getBean("languageBasedAreaDao");
    }


    private void addNewLanguage(String languageDescription, String localeCode) throws IOException, ContentSetException {
        LanguageDataLoader languageDataLoader = new LanguageDataLoader(languageDao);
        languageDataLoader.addNewLanguage(languageDescription, localeCode);
    }

    private void feedLanguageProcess(String localeCode) throws IOException, ContentSetException, EmailBeanException {

        String lanAreaPath = "lan_area_" + localeCode + ".txt";
        String lanBarrierCatPath = "lan_barrier_cat_" + localeCode + ".txt";
        String lanCategoryPath = "lan_category_" + localeCode + ".txt";
        String lanCategoryTypePath = "lan_category_type_" + localeCode + ".txt";
        String lanLanPath = "lan_lan_" + localeCode + ".txt";
        String lanPersonnelTypePath = "lan_personnel_type_" + localeCode + ".txt";
        String lanResponsePath = "lan_response_" + localeCode + ".txt";

        final LanAreaDataImporter lanAreaDataImporter = new LanAreaFileDataImporter(lanAreaPath);
        final LanBarrierCatDataImporter lanBarrierCatDataImporter = new LanBarrierCatFileDataImporter(lanBarrierCatPath);
        final LanCategoryDataImporter lanCategoryDataImporter = new LanCategoryFileDataImporter(lanCategoryPath);
        final LanCategoryTypeDataImporter lanCategoryTypeDataImporter = new LanCategoryTypeFileDataImporter(lanCategoryTypePath);
        final LanLanguageDataImporter lanLanguageDataImporter = new LanLanguageFileDataImporter(lanLanPath);
        final LanPersonnelTypeDataImporter lanPersonnelTypeDataImporter = new LanPersonnelTypeFileDataImporter(lanPersonnelTypePath);
        final LanLanguageResponseDataImporter lanLanguageResponseDataImporter = new LanLanguageResponseFileDataImporter(lanResponsePath);

        final LanguageDataLoader languageDataLoader = new LanguageDataLoader(categoryDao, languageBasedAreaDAO, languageDao, personnelDao);
        languageDataLoader.setLanAreaDataImporter(lanAreaDataImporter);
        languageDataLoader.setLanBarrierCatDataImporter(lanBarrierCatDataImporter);
        languageDataLoader.setLanCategoryDataImporter(lanCategoryDataImporter);
        languageDataLoader.setLanCategoryTypeDataImporter(lanCategoryTypeDataImporter);
        languageDataLoader.setLanLanguageDataImporter(lanLanguageDataImporter);
        languageDataLoader.setLanPersonnelTypeDataImporter(lanPersonnelTypeDataImporter);
        languageDataLoader.setLanLanguageResponseDataImporter(lanLanguageResponseDataImporter);

        logger.info("Running Language based feed.");

        languageDataLoader.loadLanguageBasedData(localeCode);
    }


    public static String getElapsedTimeHMS(long elapsedTime) {
        long totalElapsedTime = elapsedTime / TOTAL_MSEC_X_SEC;

        return String.format("%d:%02d:%02d", totalElapsedTime / TOTAL_SEC_X_HR, (totalElapsedTime % TOTAL_SEC_X_HR) / TOTAL_SEC_X_MIN, (totalElapsedTime % TOTAL_SEC_X_MIN));
    }

    private static String getDatabaseUrl() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".connection.url");
    }

    private static String getDatabaseUsername() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".username");
    }

    private static String getEnvironment() {
        String env = System.getProperty(ENV_D_PARAM);
        if (env == null) {
            env = System.getProperty(LSI_FUNCTION);
        }
        return env;
    }
}

