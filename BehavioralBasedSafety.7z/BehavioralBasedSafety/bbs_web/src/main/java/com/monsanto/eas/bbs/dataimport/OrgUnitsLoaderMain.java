package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 9:40:29 PM
 * To change this template use File | Settings | File Templates.
 */

public final class OrgUnitsLoaderMain {

    private OrgUnitsLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException {
        ApplicationContext context = new ClassPathXmlApplicationContext(
                "dao-config.xml");
        OrgUnitDAO orgUnitDAO = (OrgUnitDAO) context.getBean("orgUnitDao");
        OrganizationUnitImporter organizationUnitImporter = new OrganizationUnitFileDataImporter("com/monsanto/eas/bbs/dataimport/complete_org_units.txt");
        OrganizationUnitDataLoader organizationUnitDataLoader = new OrganizationUnitDataLoader(organizationUnitImporter, orgUnitDAO);
        organizationUnitDataLoader.loadOrganizationUnits();
    }
}