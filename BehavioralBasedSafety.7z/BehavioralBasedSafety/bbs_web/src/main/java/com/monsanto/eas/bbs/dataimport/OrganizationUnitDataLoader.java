package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.TempOrgUnit;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 12:59:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrganizationUnitDataLoader {
   private OrganizationUnitImporter dataImporter;
   private OrgUnitDAO orgUnitDAO;

   private static Logger logger = Logger.getLogger(OrganizationUnitDataLoader.class);

   public OrganizationUnitDataLoader(OrganizationUnitImporter dataImporter, OrgUnitDAO orgUnitDAO) {
      this.dataImporter = dataImporter;
      this.orgUnitDAO = orgUnitDAO;
   }

   public void loadOrganizationUnits() throws IOException, ContentSetException {
      List<OrgUnit> orgUnits = dataImporter.getOrgUnits();

      logger.info("Org Units read from feed: " + orgUnits.size());

      try {
         orgUnitDAO.clearTempOrgUnits();
         logger.info("cleared temp org units.");

         addTempOrgUnits(orgUnits);
         orgUnitDAO.updateOrgUnits();
         orgUnitDAO.addOrgUnits();
         logger.info("added new org units.");
         orgUnitDAO.assignOrgUnitParents();
         logger.info("assigned parents to org units");
      }
      catch (Exception e) {
         logger.error("Error while updating org units\n" + e.getCause(), e);
         orgUnitDAO.clearTempOrgUnits();
      }

   }

   private void addTempOrgUnits(List<OrgUnit> orgUnitsList) {
      TempOrgUnit tempOrgUnit = null;

      for (OrgUnit orgUnit : orgUnitsList) {

         tempOrgUnit = new TempOrgUnit();
         tempOrgUnit.setOrgDescription(orgUnit.getOrgDescription());
         tempOrgUnit.setActive(orgUnit.isActive());
         tempOrgUnit.setOrgLevel(orgUnit.getOrgLevel());
         tempOrgUnit.setOrgCode(orgUnit.getOrgCode());
         tempOrgUnit.setParentOrgCode(orgUnit.getParentOrgCode());
         tempOrgUnit.setDataLoadError(orgUnit.getDataLoadError());

         orgUnitDAO.addTempOrgUnit(tempOrgUnit);
      }
   }

}
