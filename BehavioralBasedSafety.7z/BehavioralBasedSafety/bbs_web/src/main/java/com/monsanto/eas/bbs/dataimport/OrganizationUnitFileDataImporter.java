package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.OrgUnit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OrganizationUnitFileDataImporter implements OrganizationUnitImporter
{
   private static final int PARENT_ORG_UNIT_CODE_START = 48;
   private static final int ORG_LEVEL_START = 53;
   private static final int ORG_LEVEL_END = 55;
   private static final int ORG_UNIT_CODE_START = 3;
   private static final int ORG_UNIT_DESCRIPTION_START = 8;
   private SpreadSheet spreadSheet;

   public OrganizationUnitFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public List<OrgUnit> getOrgUnits() throws IOException, ContentSetException {
      List<OrgUnit> orgUnits = new ArrayList();
      OrgUnit orgUnit;
      ContentSet contentSet = spreadSheet.getContentSet();

      while (contentSet.next()) {

         String orgUnitCode = contentSet.getString(ORG_UNIT_CODE_START, ORG_UNIT_DESCRIPTION_START);
         String orgUnitDescription = contentSet.getString(ORG_UNIT_DESCRIPTION_START, PARENT_ORG_UNIT_CODE_START).trim();
         String parentOrgUnitCode = contentSet.getString(PARENT_ORG_UNIT_CODE_START, ORG_LEVEL_START);
         String orgLevel = contentSet.getString(ORG_LEVEL_START, ORG_LEVEL_END);

         orgUnit = new OrgUnit();
         orgUnit.setOrgDescription(orgUnitDescription);
         orgUnit.setOrgCode(orgUnitCode);
         orgUnit.setParentOrgCode(parentOrgUnitCode);
         orgUnit.setOrgLevel(new Long(orgLevel));
         orgUnit.setActive(true);
         orgUnits.add(orgUnit);
      }
      return orgUnits;

   }
}
