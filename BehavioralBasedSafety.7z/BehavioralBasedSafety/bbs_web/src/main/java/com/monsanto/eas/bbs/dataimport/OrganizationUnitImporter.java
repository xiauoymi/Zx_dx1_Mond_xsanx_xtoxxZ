package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.OrgUnit;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 12:59:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface OrganizationUnitImporter {
  List<OrgUnit> getOrgUnits() throws IOException, ContentSetException;
}
