package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.Plant;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 9, 2010
 * Time: 10:58:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class PlantAreaTO {
  private String plantCode;
  private String areaDescription;
  private String subAreaDescription;
  private String lang;

  private Language language;
  private Plant plant;
  private Area area;
  private Area subArea;

  public PlantAreaTO() {
  }

  public PlantAreaTO(String plantCode, String areaDescription, String subAreaDescription, String language) {
    this.plantCode = plantCode;
    this.areaDescription = areaDescription;
    this.subAreaDescription = subAreaDescription;
    this.lang = language;
  }

  public String getAreaDescription() {
    return areaDescription;
  }

  public void setAreaDescription(String areaDescription) {
    this.areaDescription = areaDescription;
  }

  public String getPlantCode() {
    return plantCode;
  }

  public String getSubAreaDescription() {
    return subAreaDescription;
  }

  public String getLang() {
    return lang;
  }

  public Language getLanguage() {
    return language;
  }

  public void setLanguage(Language language) {
    this.language = language;
  }

  public Plant getPlant() {
    return plant;
  }

  public void setPlant(Plant plant) {
    this.plant = plant;
  }

  public Area getArea() {
    return area;
  }

  public void setArea(Area area) {
    this.area = area;
  }

  public Area getSubArea() {
    return subArea;
  }

  public void setSubArea(Area subArea) {
    this.subArea = subArea;
  }
}
