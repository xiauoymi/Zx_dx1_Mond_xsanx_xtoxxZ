package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Plant;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 10:52:49 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PlantDataImporter {
  List<Plant> getPlants() throws IOException, ContentSetException;
}
