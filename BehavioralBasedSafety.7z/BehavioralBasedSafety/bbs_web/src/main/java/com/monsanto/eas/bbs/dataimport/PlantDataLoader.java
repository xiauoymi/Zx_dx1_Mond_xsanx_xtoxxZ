package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.CountryDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempPlant;
import com.monsanto.eas.bbs.util.EmailBean;
import com.monsanto.eas.bbs.util.EmailBeanException;
import org.apache.log4j.Logger;
import org.springframework.mail.SimpleMailMessage;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlantDataLoader {
   private PlantDAO plantDAO;
   private PlantDataImporter dataImporter;
   private CountryDAO countryDAO;

   private static Logger logger = Logger.getLogger(PlantDataLoader.class);

   public PlantDataLoader(PlantDataImporter dataImporter, PlantDAO plantDAO, CountryDAO countryDAO) {
      this.plantDAO = plantDAO;
      this.dataImporter = dataImporter;
      this.countryDAO = countryDAO;
   }

   public void newLoadPlantData(final EmailBean email) throws IOException, ContentSetException, EmailBeanException {
      List<Plant> plants = dataImporter.getPlants();
      logger.info("Plants read from feed: " + plants.size());
      try {

         plantDAO.clearTempPlants();

         addTempPlants(plants, email);
         logger.info("added temp plants.");
         plantDAO.updatePlants();
         logger.info("updated plants: " + plants.size());
         plantDAO.addPlants();
         logger.info("added new plants.");
         plantDAO.clearTempPlants();
         logger.info("cleared temp plants.");
      }
      catch (Exception e) {
         plantDAO.clearTempPlants();
         logger.error("Error while updating plants...\n" + e.getMessage(), e);
      }
   }

   private void addTempPlants(final List<Plant> plants, final EmailBean email) throws EmailBeanException {
      TempPlant tempPlant = null;
      Map<String, Country> countryMap = getCountryMapByCode();

      for (Plant plant : plants) {
         final String countryCode = plant.getCountryCode();
         final String plantCode = plant.getPlantCode();
         Country country = countryMap.get(plant.getCountryCode());

         if (country == null) {
            country = new Country();
            country.setCountryCode(plant.getCountryCode());
            country.setDescription(plant.getCountryCode());
            country.setActive(true);
            countryDAO.addCountry(country);

            //try {
               email.getTemplateMessage()
                       .setText(String.format("country is null for >'%s'< and plant_code >'%s'<", countryCode, plantCode));
               SimpleMailMessage mailTemplateTemp = new SimpleMailMessage(email.getTemplateMessage());
               email.getMailSender().send(mailTemplateTemp);
            /*} catch ( ) {
               throw new EmailBeanException("Caught null pointer exception in PlantDataLoader.addTempPlants().", npe);
            }*/
         }

         tempPlant = new TempPlant(plant.getId(), plant.getPlantCode(), plant.getPlantName1(), plant.getVala(),
                 plant.getCustomerNumberForPlant(), plant.getVendorNbrForPlant(), plant.getCal(), plant.getPlantName2(),
                 plant.getStreet(), plant.getPoBox(), plant.getPostalCode(), plant.getCity(), plant.getPorg(),
                 plant.isActive(), plant.getModUser(), plant.getModDate());
         tempPlant.setCountryCode(plant.getCountryCode());
         tempPlant.setCountry(country);
         plantDAO.addTempPlant(tempPlant);
      }
   }

   private Map<String, Country> getCountryMapByCode() {
      Map<String, Country> countryMap = new HashMap<String, Country>();
      List<Country> countries = countryDAO.lookupActiveCountries();
      for (Country country : countries) {
         countryMap.put(country.getCountryCode(), country);
      }
      return countryMap;
   }
}
