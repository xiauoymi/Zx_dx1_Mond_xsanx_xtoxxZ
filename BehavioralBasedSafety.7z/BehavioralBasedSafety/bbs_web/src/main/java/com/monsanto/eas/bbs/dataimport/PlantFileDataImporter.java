package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Plant;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 10:53:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlantFileDataImporter implements PlantDataImporter {
  private static final int STREET_NAME_START = 34;
  private static final int COUNTRY_CODE_START = 44;
  private static final int COUNTRY_CODE_END = 46;
  private static final int PLANT_NAME_START = 4;
  private SpreadSheet spreadSheet;

  public PlantFileDataImporter(String filePath) {
    spreadSheet = new FixedLengthSpreadSheet(filePath);
  }

  public List<Plant> getPlants() throws IOException, ContentSetException {
    List<Plant> plants = new ArrayList();
    Plant plant;
    ContentSet contentSet = spreadSheet.getContentSet();
    while (contentSet.next()){
      plant = new Plant();
      String plantCode = contentSet.getString(0, PLANT_NAME_START);
      String plantName = contentSet.getString(PLANT_NAME_START, STREET_NAME_START);
      String streetName = contentSet.getString(STREET_NAME_START, COUNTRY_CODE_START);
      String countryCode = contentSet.getString(COUNTRY_CODE_START, COUNTRY_CODE_END);
      plant.setPlantCode(plantCode);
      plant.setPlantName1(plantName);
      plant.setStreet(streetName);
      plant.setCountryCode(countryCode);
      plant.setActive(true);
      plants.add(plant);
    }
    return plants;
  }
}
