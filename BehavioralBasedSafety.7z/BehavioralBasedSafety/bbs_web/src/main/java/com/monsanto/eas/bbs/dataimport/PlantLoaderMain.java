package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.CountryDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.util.EmailBean;
import com.monsanto.eas.bbs.util.EmailBeanException;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 9:40:29 PM
 * To change this template use File | Settings | File Templates.
 */

public final class PlantLoaderMain {

    private static Logger logger = Logger.getLogger(PlantLoaderMain.class);

    private PlantLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException, EmailBeanException {
        final Properties filepaths = new Properties();
        String filePath = "bbs.feed.plant";

        try {
            filepaths.load(PlantLoaderMain.class.getResourceAsStream("bbs_feed.properties"));
        }
        catch (IOException ioe) {
            logger.error("Could not find properties file.", ioe);
            return;
        }
        filePath = filepaths.getProperty(filePath);

        ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        PlantDAO plantDAO = (PlantDAO) context.getBean("plantDao");
        CountryDAO countryDAO = (CountryDAO) context.getBean("countryDao");
        EmailBean email = (EmailBean) context.getBean("plantDataEmailBean");

        PlantDataImporter dataImporter = new PlantFileDataImporter(filePath);
        PlantDataLoader plantDataLoader = new PlantDataLoader(dataImporter, plantDAO, countryDAO);
        plantDataLoader.newLoadPlantData(email);
    }
}
