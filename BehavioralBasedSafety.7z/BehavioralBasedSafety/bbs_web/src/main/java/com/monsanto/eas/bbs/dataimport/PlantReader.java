package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Plant;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 8:49:56 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PlantReader {
  List<Plant> getPlantData();
}
