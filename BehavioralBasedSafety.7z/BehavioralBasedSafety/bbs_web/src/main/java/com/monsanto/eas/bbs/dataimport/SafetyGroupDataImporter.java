package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.SafetyGroup;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 19, 2010
 * Time: 5:03:36 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SafetyGroupDataImporter {

  List<SafetyGroup> getSafetyGroups() throws IOException, ContentSetException;
}
