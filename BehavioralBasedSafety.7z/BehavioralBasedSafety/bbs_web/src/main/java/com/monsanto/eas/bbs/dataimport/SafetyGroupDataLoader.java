package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempSafetyGroup;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Jan 19, 2010 Time: 4:59:01 PM To change this template use File |
 * Settings | File Templates.
 */
public class SafetyGroupDataLoader {
    private SafetyGroupDataImporter safetyGroupDataImporter;
    private PlantDAO plantDAO;
    private OrgUnitDAO orgUnitDAO;
    private SafetyGroupDAO safetyGroupDAO;

    private static Logger logger = Logger.getLogger(SafetyGroupDataLoader.class);

    public SafetyGroupDataLoader(SafetyGroupDataImporter safetyGroupDataImporter, PlantDAO plantDAO,
                                 OrgUnitDAO orgUnitDAO, SafetyGroupDAO safetyGroupDAO) {
        this.safetyGroupDataImporter = safetyGroupDataImporter;
        this.plantDAO = plantDAO;
        this.orgUnitDAO = orgUnitDAO;
        this.safetyGroupDAO = safetyGroupDAO;
    }

    public void loadSafetyGroupData() throws IOException, ContentSetException {
        List<SafetyGroup> groupsList = safetyGroupDataImporter.getSafetyGroups();
        logger.info("Safety Groups read from feed: " + groupsList.size());
        try {
            safetyGroupDAO.clearTempSafetyGroups();

            addTempSafetyGroups(groupsList);
            safetyGroupDAO.updateSafetyGroups();
            safetyGroupDAO.addSafetyGroups();
            plantDAO.inactivatePlantsNotAssociatedWithSafetyGroup();
            safetyGroupDAO.clearTempSafetyGroups();
        }
        catch (Exception e) {
            logger.error("Error while updating safety groups\n" + e.getMessage(), e);
            safetyGroupDAO.clearTempSafetyGroups();
        }
    }

    private void addTempSafetyGroups(List<SafetyGroup> groups) {
        Map<String, Plant> mapOfPlantsByCode = getMapOfAllPlants();
        TempSafetyGroup tempSafetyGroup = null;
        int tmpSafetyGrpInsertedCounter = 0;

        for (SafetyGroup group : groups) {

            if(group.getLocationCode().equals("")){
                continue;
            }

            String dataLoadError = "";
            group.setActive(true);

            if (group.getGroupCode().equalsIgnoreCase("DEL") || group.getGroupCode().equalsIgnoreCase("MRG")) {
                dataLoadError += "Setting as inactive coz Group Code is " + group.getGroupCode();
                group.setActive(false);
            }
            if (mapOfPlantsByCode.containsKey(group.getPlantCode())) {
                group.setPlant(mapOfPlantsByCode.get(group.getPlantCode()));
            } else {
                dataLoadError += "Setting as inactive - plant code not found";
                group.setActive(false);
                group.setPlant(null);
            }

            List<OrgUnit> orgUnits = orgUnitDAO.findByCriteria(group.getOrgUnitCode());
            if (orgUnits.size() == 0) {
                dataLoadError += "Setting as inactive - org unit code not found";
                group.setActive(false);
            } else if (orgUnits.size() > 1) {
                group.setActive(false);
                dataLoadError += "Too many org units found with this org unit code";
            } else {
                group.setOrgUnitId(orgUnits.get(0).getId());
            }

            group.setDataLoadError(dataLoadError);

            tempSafetyGroup = new TempSafetyGroup();
            tempSafetyGroup.setActive(group.getActive());
            tempSafetyGroup.setPlant(group.getPlant());
            tempSafetyGroup.setOrgUnitId(group.getOrgUnitId());
            tempSafetyGroup.setDataLoadError(group.getDataLoadError());
            tempSafetyGroup.setPlantCode(group.getPlantCode());
            tempSafetyGroup.setGroupText(group.getGroupText());
            tempSafetyGroup.setGroupCode(group.getGroupCode());
            tempSafetyGroup.setLocationCode(group.getLocationCode());
            tempSafetyGroup.setSafetyGroupCode(group.getSafetyGroupCode());
            tempSafetyGroup.setBiotechInd(group.isBiotechInd());

            safetyGroupDAO.addTempSafetyGroup(tempSafetyGroup);
            tmpSafetyGrpInsertedCounter++;
        }

        logger.info("Temporal Safety Groups inserted " + tmpSafetyGrpInsertedCounter);
    }

    private Map<String, Plant> getMapOfAllPlants() {
        Map<String, Plant> map = new HashMap<String, Plant>();
        List<Plant> allPlants = plantDAO.lookupAllPlants();
        for (Plant plant : allPlants) {
            map.put(plant.getPlantCode(), plant);
        }
        return map;
    }
}
