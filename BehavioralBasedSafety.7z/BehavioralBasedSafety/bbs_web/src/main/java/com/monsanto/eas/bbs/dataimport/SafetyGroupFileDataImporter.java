package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.SafetyGroup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SafetyGroupFileDataImporter implements SafetyGroupDataImporter {
   private static final int PLANT_CODE_START = 58;
   private static final int GROUP_CODE_START = 62;
   private static final int ORGANIZATION_CODE_START = 65;
   private static final int ORGANIZATION_CODE_END = 70;
   private static final int LOCATION_CODE_START = 71;
   private static final int LOCATION_CODE_END = 77;
   private static final int BIOTECH_INDICATOR_START = 131;
   private static final int BIOTECH_INDICATOR_END = 132;
   private static final int SAFETY_GROUP_CODE_START = 3;
   private static final int SAFETY_GROUP_DESCRIPTION_START = 8;
   private SpreadSheet spreadSheet;


   public SafetyGroupFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   public List<SafetyGroup> getSafetyGroups() throws IOException, ContentSetException {
      final List<SafetyGroup> safetyGroups = new ArrayList();
      SafetyGroup safetyGroup;
      final ContentSet contentSet = spreadSheet.getContentSet();

      while (contentSet.next()) {
         final String safetyGroupCode = contentSet.getString(SAFETY_GROUP_CODE_START, SAFETY_GROUP_DESCRIPTION_START);
         final String safetyGroupDescription = contentSet.getString(SAFETY_GROUP_DESCRIPTION_START, PLANT_CODE_START).trim();
         final String plantCode = contentSet.getString(PLANT_CODE_START, GROUP_CODE_START);
         final String groupCode = contentSet.getString(GROUP_CODE_START, ORGANIZATION_CODE_START);
         final String organizationCode = contentSet.getString(ORGANIZATION_CODE_START, ORGANIZATION_CODE_END);
         final String locationCode = contentSet.getString(LOCATION_CODE_START, LOCATION_CODE_END).trim();
         final String biotechInd = contentSet.getString(BIOTECH_INDICATOR_START, BIOTECH_INDICATOR_END);

         safetyGroup = new SafetyGroup();
         safetyGroup.setPlantCode(plantCode);
         safetyGroup.setGroupText(safetyGroupDescription);
         safetyGroup.setSafetyGroupCode(safetyGroupCode);
         safetyGroup.setOrgUnitCode(organizationCode);
         safetyGroup.setGroupCode(groupCode);
         safetyGroup.setLocationCode(locationCode);
         safetyGroup.setBiotechInd(biotechInd != null && biotechInd.equals("X") ? true : false);

         safetyGroups.add(safetyGroup);
      }
      return safetyGroups;

   }
}
