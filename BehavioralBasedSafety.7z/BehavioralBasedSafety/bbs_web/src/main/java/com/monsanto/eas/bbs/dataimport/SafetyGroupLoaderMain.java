package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 9:40:29 PM
 * To change this template use File | Settings | File Templates.
 */

public final class SafetyGroupLoaderMain {

    private static Logger logger = Logger.getLogger(SafetyGroupLoaderMain.class);

    private SafetyGroupLoaderMain() {
    }

    public static void main(String[] args) throws IOException, ContentSetException {
        final Properties filepaths = new Properties();
        String filePath = "bbs.feed.safety_group";

        try {
            filepaths.load(PlantLoaderMain.class.getResourceAsStream("filepaths.properties"));
        }
        catch (IOException ioe) {
            logger.error("Could not find properties file.", ioe);
            return;
        }
        filePath = filepaths.getProperty(filePath);

        ApplicationContext context = new ClassPathXmlApplicationContext("dao-config.xml");
        PlantDAO plantDAO = (PlantDAO) context.getBean("plantDao");
        OrgUnitDAO orgUnitDAO = (OrgUnitDAO) context.getBean("orgUnitDao");
        SafetyGroupDAO safetyGroupDAO = (SafetyGroupDAO) context.getBean("safetyGroupDao");
        SafetyGroupDataImporter safetyGroupDataImporter = new SafetyGroupFileDataImporter(filePath);
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();

        logger.info("Complete.");
    }
}