package com.monsanto.eas.bbs.dataimport;

import java.io.FileNotFoundException;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 4:31:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SpreadSheet {
  ContentSet getContentSet() throws FileNotFoundException;
}
