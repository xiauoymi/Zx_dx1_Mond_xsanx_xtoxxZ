/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.WorkAreaDAO;
import com.monsanto.eas.bbs.hibernate.WorkArea;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkAreaDataLoader {
   private WorkAreaDataImporter workAreaDataImporter;
   private WorkAreaDAO workAreaDAO;

   private static Logger logger = Logger.getLogger(WorkAreaDataLoader.class);

   /**
    * Instantiates a work area data loader.
    *
    * @param workAreaDataImporter the work area data importer
    * @param workAreaDAO          the work area data access object
    */
   public WorkAreaDataLoader(WorkAreaDataImporter workAreaDataImporter, WorkAreaDAO workAreaDAO) {
      this.workAreaDataImporter = workAreaDataImporter;
      this.workAreaDAO = workAreaDAO;
   }

   /**
    * Loads all work area data.
    *
    * @throws IOException
    * @throws ContentSetException
    */
   public void loadWorkAreaData() throws IOException, ContentSetException {
      final List<WorkArea> workAreas = workAreaDataImporter.getWorkAreas();
      logger.info("Work Areas read from feed: " + workAreas.size());

      workAreaDAO.clearWorkAreas();

      for (WorkArea workArea : workAreas) {
         workAreaDAO.addWorkArea(workArea);
      }
   }

   public Map<String, WorkArea> getWorkAreaMap() {
      final Map<String, WorkArea> map = new HashMap<String, WorkArea>();
      final List<WorkArea> list = workAreaDAO.lookupAll();

      for (WorkArea workArea : list) {
         map.put(workArea.getPlantCode(), workArea);
      }
      return map;
   }
}