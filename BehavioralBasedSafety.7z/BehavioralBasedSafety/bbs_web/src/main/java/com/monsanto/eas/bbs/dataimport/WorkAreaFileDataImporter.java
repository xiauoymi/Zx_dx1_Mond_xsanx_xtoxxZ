/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.WorkArea;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkAreaFileDataImporter implements WorkAreaDataImporter
{
   private static final int PLANT_CODE_START = 60;
   private static final int PLANT_CODE_END = 64;
   private SpreadSheet spreadSheet;

   private static Logger logger = Logger.getLogger(WorkAreaFileDataImporter.class);

   /**
    * Instantiates a work area file data importer.
    *
    * @param filePath the path name of the data to be loaded
    */
   public WorkAreaFileDataImporter(String filePath) {
      spreadSheet = new FixedLengthSpreadSheet(filePath);
   }

   /**
    * Parses the data to be imported.
    *
    * @return a list of work areas parsed
    * @throws IOException
    * @throws ContentSetException
    */
   public List<WorkArea> getWorkAreas() throws IOException, ContentSetException {
      final List<WorkArea> workAreas = new ArrayList();
      WorkArea workArea;
      final ContentSet contentSet = spreadSheet.getContentSet();

      while (contentSet.next()) {

         workArea = new WorkArea();
         final String description = contentSet.getString(0, PLANT_CODE_START).trim();
         final String plantCode = contentSet.getString(PLANT_CODE_START, PLANT_CODE_END);

         if (plantCode != null && description != null && plantCode.equals("3940") && description.equals("PLANT")) {
            logger.info("...skipping " + description + "\t" + plantCode);
            continue;
         }

         workArea.setDescription(description);
         workArea.setPlantCode(plantCode);
         workAreas.add(workArea);
      }
      return workAreas;
   }

   public static Map<String, WorkArea> getWorkAreaMap(final ContentSet contentSet) throws IOException,
           ContentSetException {
      WorkArea workArea;
      final Map<String, WorkArea> map = new HashMap<String, WorkArea>();
      while (contentSet.next()) {
         workArea = new WorkArea();
         final String description = contentSet.getString(0, PLANT_CODE_START);
         final String plantCode = contentSet.getString(PLANT_CODE_START, PLANT_CODE_END);
         workArea.setDescription(description);
         workArea.setPlantCode(plantCode);
         map.put(plantCode, workArea);
      }
      return map;
   }
}