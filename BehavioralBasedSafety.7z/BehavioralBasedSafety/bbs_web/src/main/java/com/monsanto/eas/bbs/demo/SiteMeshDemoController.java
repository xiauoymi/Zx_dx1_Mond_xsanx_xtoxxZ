/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * SiteMeshDemoController was created on Dec 10, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Filename:    $HeadURL$
 * Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$
 *          Last Change: $Author$     On: $Date$
 */
@Controller
@RequestMapping(value="/demo/*")
public class SiteMeshDemoController {

  @RequestMapping(value="sitemeshDemo")
  public String siteMeshDemoPage() {
    return "demo/sitemeshDemo/body";
  }
}
