/*
 BBSConstants was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.filter;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public interface BBSConstants {
  String BBS_USER = "bbsUser";
  String OBSERVATIONS = "OBSERVATIONS";
  String ADMINISTRATORS = "ADMINISTRATORS";
  String VIEW = "view";
}