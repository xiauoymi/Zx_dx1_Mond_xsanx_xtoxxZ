/*
 BBSFilter was created on Dec 23, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.filter;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.service.UserService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Component
public class BBSFilter implements Filter {
    private FilterConfig config;
    @Autowired
    private UserService userService;

    private KerberosSecurity security;

    private static Logger logger = Logger.getLogger(BBSFilter.class);

    public void init(FilterConfig filterConfig) throws ServletException {
        this.config = filterConfig;
        ServletContext servletContext = filterConfig.getServletContext();
        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        if (webApplicationContext != null) {
            AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext.getAutowireCapableBeanFactory();
            autowireCapableBeanFactory.autowireBean(this);
        }
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws
            IOException, ServletException {

        HttpSession session = ((HttpServletRequest) request).getSession();
        final BBSUser bbsUser = (BBSUser) session.getAttribute(BBSConstants.BBS_USER);

        if (bbsUser == null && ((HttpServletRequest) request).getRequestURL().indexOf("eboReports") == -1) {
            security = getKerberosSecurity();
            security.init((HttpServletRequest) request);
            String userId = security.getUserID();
            logger.info("User retrieved from Kerberos: " + userId );

            if (StringUtils.isNullOrEmpty(userId)) {
                ((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN);
            } else {
                BBSUser user = userService.findByUserID(userId);

                logger.info("User retrieved from BBS_DB: " + user );

                if (user == null) {
                    ((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN);
                } else {
                    session.setAttribute(BBSConstants.BBS_USER, user);
                }
            }
        }
        chain.doFilter(request, response);
    }

    private KerberosSecurity getKerberosSecurity() {
        if (security == null) {
            return new KerberosSecurity();
        } else {
            return security;
        }
    }

    public void destroy() {
    }

    public FilterConfig getConfig() {
        return config;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public void setSecurity(KerberosSecurity security) {
        this.security = security;
    }
}