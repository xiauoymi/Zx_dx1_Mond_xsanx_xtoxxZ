/*
 Area was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@Entity(name = "A")
@Table(schema = "BBS", name = "AREA")
public class Area implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;
   private static final int PRIME_HASH_CODE_CONSTANT_2 = 17;

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @ManyToOne(cascade = CascadeType.ALL)
   @JoinColumn(name = "PARENT_ID", referencedColumnName = "ID")
   private Area parentArea;

   @Column(name = "ACTIVE")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "AREA_LEVEL")
   private int level;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();

   //  @OneToMany(fetch = FetchType.LAZY)
   //  @JoinColumn(name="PARENT_ID", referencedColumnName = "ID")
   @Transient
   private Set<Area> subAreas = new HashSet<Area>();

   //@Transient
   //private Set<LanguageBasedArea> subArea = new HashSet<Area>();


   //  @OneToMany(cascade = CascadeType.ALL)
//  @JoinColumn(name = "AREA_ID", referencedColumnName ="ID" )
   @Transient
   private Collection<LanguageBasedArea> languageBasedSubAreas = new ArrayList<LanguageBasedArea>();

   public Area() {
   }

   public Area(Long id, Area parentArea, boolean active) {
      this.id = id;
      this.parentArea = parentArea;
      this.active = active;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public Area getParentArea() {
      return parentArea;
   }

   public void setParentArea(Area parentArea) {
      this.parentArea = parentArea;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public Set<Area> getSubAreas() {
      return subAreas;
   }

   public void setSubAreas(Set<Area> subAreas) {
      this.subAreas = subAreas;
   }

   public int getLevel() {
      return level;
   }

   public void setLevel(int level) {
      this.level = level;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

   @Override
   public int hashCode() {
//    int result;
//    result = (id != null ? id.hashCode() : 0);
//    result = 31 * result + (parentArea != null ? parentArea.hashCode() : 0);
//
//    return result;
      return new HashCodeBuilder(PRIME_HASH_CODE_CONSTANT_2, PRIME_HASH_CODE_CONSTANT).append(id).append(isActive()).append(parentArea).toHashCode();
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (!(o instanceof Area)) {
         return false;
      }

      Area area = (Area) o;

      return new EqualsBuilder().append(area.getId(), id).append(area.isActive(), isActive()).append(area.getParentArea(), parentArea).isEquals();
   }

   public Collection<LanguageBasedArea> getLanguageBasedSubAreas() {
      return languageBasedSubAreas;
   }

   public void setLanguageBasedSubAreas(Collection<LanguageBasedArea> languageBasedSubAreas) {
      this.languageBasedSubAreas = languageBasedSubAreas;
   }
}