/*
 BBSRole was created on Feb 2, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "ROLE")
public class BBSRole {
   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   @Column(name = "ID")
   private Long id;

   @Column(name = "DESCRIPTION")
   private String description;

   @Column(name = "ACTIVE")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();


   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

}