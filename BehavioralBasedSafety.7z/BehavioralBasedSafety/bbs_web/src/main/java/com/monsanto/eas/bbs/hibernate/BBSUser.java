/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * BBSUser was created on Dec 16, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.hibernate;

import com.monsanto.eas.bbs.util.HibernateUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $HeadURL$ Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$ Last Change: $Author$     On: $Date$
 */
@Entity
@Table(schema = "BBS", name = "BBS_USER")
public class BBSUser implements Serializable {

    private static final int HASHCODE_PRIME = 31;
    private static final int PRIME_HASH_CODE_CONSTANT = HASHCODE_PRIME;

    @Id
    @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
    @Column(name = "ID")
    private Long id;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "MIDDLE_NAME")
    private String middleName;

    @Column(name = "IS_EMPLOYEE")
    @Type(type = "yes_no")
    private boolean employee;

    @Column(name = "LAST_LOGIN")
    private Date lastLogin;

    @Column(name = "ACTIVE")
    @Type(type = "yes_no")
    private boolean active;

    @Column(name = "MOD_USER")
    private String modUser;

    @Column(name = "MOD_DATE")
    private Date modDate;

    @Transient
    private Date endDateFormat;

    @Transient
    private Date startDateFormat;

    @Transient
    private boolean alreadyPersisted;

    @Column(name = "DATA_LOAD_ERROR")
    private String dataLoadError;

    @ManyToOne(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @Column(name = "LOCATION_CODE")
    private String locationCode;

    @ManyToOne(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
    @JoinColumn(name = "DEPARTMENT_ID", referencedColumnName = "ID")
    private Department department;

    @ManyToMany(targetEntity = BBSRole.class, fetch = FetchType.EAGER)
    @JoinTable(name = "USER_ROLE", joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    @Where(clause = "NVL(ACTIVE, 'N')<>'N'")
    private Set<BBSRole> roles = new HashSet<BBSRole>();

    @Column(name = "PHONE_NBR")
    private String phoneNumber;

    @Column(name = "COST_CENTER")
    private String costCenter;

    @Column(name = "EMAIL_ADDR")
    private String emailAddress;

    @ManyToOne(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
    @JoinColumn(name = "MGR_USER_ID", referencedColumnName = "USER_ID")
    private BBSUser manager;

    @Column(name = "COMPANY_CODE")
    private String companyCode;

    @Column(name = "BUSINESS_AREA")
    private String businessArea;


    public static final String ESH_ADMIN = "ESH_ADMIN";
    public static final String GLOBAL_LEAD = "GLOBAL_LEAD";
    public static final String EMEA_REGION_ADMIN = "EMEA_REGION_ADMIN";

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("id=" + id + " ");
        sb.append("userId=" + userId + " ");
        sb.append("firstName=" + firstName + " ");
        sb.append("lastName=" + lastName + " ");
        sb.append("middleName=" + middleName + " ");
        sb.append("locationCode=" + locationCode + " ");

        return sb.toString();
    }

    public BBSUser() {
    }

    public BBSUser(Long id, String userId, String firstName, String lastName, String middleName, boolean employee,
                   Date lastLogin,
                   String modUser, Date modDate) {

        this.id = id;
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.employee = employee;
        this.lastLogin = lastLogin;
        this.modUser = modUser;
        this.modDate = modDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getFullName() {
        String fullName = firstName;
        if (StringUtils.isNotBlank(this.middleName)) {
            fullName = fullName + " " + this.middleName;
        }
        fullName = fullName + " " + lastName;
        return fullName;
    }

    public boolean isEmployee() {
        return employee;
    }

    public void setEmployee(boolean employee) {
        this.employee = employee;
    }

    public Date getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(Date lastLogin) {
        this.lastLogin = lastLogin;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public Plant getPlant() {
        return HibernateUtils.initializeAndUnproxy(plant);
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Department getDepartment() {
        return HibernateUtils.initializeAndUnproxy(department);
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void setRoles(Set<BBSRole> roles) {
        this.roles = roles;
    }

    public Set<BBSRole> getRoles() {
        return roles;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        //if (o == null || getClass() != o.getClass()) return false;
        if (!(o instanceof BBSUser)) return false;

        final BBSUser bbsUser = (BBSUser) o;

        if (active != bbsUser.active) return false;
        if (employee != bbsUser.employee) return false;

        if (costCenter == null || costCenter.equals("")) {
            if (bbsUser.getCostCenter() != null && !bbsUser.getCostCenter().equals("")) {
                return false;
            }
        } else if (!costCenter.equals(bbsUser.getCostCenter())) {
            return false;
        }

        if (getDepartment() == null || getDepartment().getCode().longValue() == 0) {
            if (bbsUser.getDepartment() != null && bbsUser.getDepartment().getCode().longValue() != 0) {
                return false;
            }
        } else if (!getDepartment().getCode().equals(bbsUser.getDepartment().getCode())) {
            return false;
        }

        //if (department != null ? !department.equals(bbsUser.department) : bbsUser.department != null) return false;

        if (emailAddress == null || emailAddress.equals("")) {
            if (bbsUser.getEmailAddress() != null && !bbsUser.getEmailAddress().equals("")) {
                return false;
            }
        } else if (!emailAddress.equals(bbsUser.getEmailAddress())) {
            return false;
        }

        if (firstName == null || firstName.equals("")) {
            if (bbsUser.getFirstName() != null && !bbsUser.getFirstName().equals("")) {
                return false;
            }
        } else if (!firstName.equals(bbsUser.getFirstName())) {
            return false;
        }

        if (lastName == null || lastName.equals("")) {
            if (bbsUser.getLastName() != null && !bbsUser.getLastName().equals("")) {
                return false;
            }
        } else if (!lastName.equals(bbsUser.getLastName())) {
            return false;
        }

        if (locationCode == null || locationCode.equals("")) {
            if (bbsUser.getLocationCode() != null && !bbsUser.getLocationCode().equals("")) {
                return false;
            }
        } else if (!locationCode.equals(bbsUser.getLocationCode())) {
            return false;
        }

        if (manager == null || manager.getUserId().equals("")) {
            if (bbsUser.getManager() != null && !bbsUser.getManager().getUserId().equals("")) {
                return false;
            }
        } else if (!manager.getUserId().equals(bbsUser.getManager().getUserId())) {
            return false;
        }

        //if (manager != null ? !manager.getUserId().equals(bbsUser.manager.getUserId()) : bbsUser.manager != null) return false;

        if (middleName == null || middleName.equals("")) {
            if (bbsUser.getMiddleName() != null && !bbsUser.getMiddleName().equals("")) {
                return false;
            }
        } else if (!middleName.equals(bbsUser.getMiddleName())) {
            return false;
        }

        if (phoneNumber == null || phoneNumber.equals("")) {
            if (bbsUser.getPhoneNumber() != null && !bbsUser.getPhoneNumber().equals("")) {
                return false;
            }
        } else if (!phoneNumber.equals(bbsUser.getPhoneNumber())) {
            return false;
        }

        if (getPlant() == null || getPlant().getPlantCode().equals("")) {
            if (bbsUser.getPlant() != null && !bbsUser.getPlant().getPlantCode().equals("")) {
                return false;
            }
        } else if (!getPlant().getPlantCode().equals(bbsUser.getPlant().getPlantCode())) {
            return false;
        }

        //if (plant != null ? !plant.equals(bbsUser.plant) : bbsUser.plant != null) return false;
        if (companyCode == null || companyCode.equals("")) {
            if (bbsUser.getCompanyCode() != null && !bbsUser.getCompanyCode().equals("")) {
                return false;
            }
        } else if (!companyCode.equals(bbsUser.getCompanyCode())) {
            return false;
        }

        if (businessArea == null || businessArea.equals("")) {
            if (bbsUser.getBusinessArea() != null && !bbsUser.getBusinessArea().equals("")) {
                return false;
            }
        } else if (!businessArea.equals(bbsUser.getBusinessArea())) {
            return false;
        }

        if (userId == null || userId.equals("")) {
            if (bbsUser.getUserId() != null && !bbsUser.getUserId().equals("")) {
                return false;
            }
        } else if (!userId.equals(bbsUser.getUserId())) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = userId != null ? userId.hashCode() : 0;
        result = HASHCODE_PRIME * result + (firstName != null ? firstName.hashCode() : 0);
        result = HASHCODE_PRIME * result + (lastName != null ? lastName.hashCode() : 0);
        result = HASHCODE_PRIME * result + (middleName != null ? middleName.hashCode() : 0);
        result = HASHCODE_PRIME * result + (employee ? 1 : 0);
        result = HASHCODE_PRIME * result + (active ? 1 : 0);
        result = HASHCODE_PRIME * result + (plant != null ? plant.hashCode() : 0);
        result = HASHCODE_PRIME * result + (locationCode != null ? locationCode.hashCode() : 0);
        result = HASHCODE_PRIME * result + (department != null ? department.hashCode() : 0);
        result = HASHCODE_PRIME * result + (phoneNumber != null ? phoneNumber.hashCode() : 0);
        result = HASHCODE_PRIME * result + (costCenter != null ? costCenter.hashCode() : 0);
        result = HASHCODE_PRIME * result + (emailAddress != null ? emailAddress.hashCode() : 0);
        result = HASHCODE_PRIME * result + (manager != null ? manager.hashCode() : 0);
        result = HASHCODE_PRIME * result + (companyCode != null ? companyCode.hashCode() : 0);
        result = HASHCODE_PRIME * result + (businessArea != null ? businessArea.hashCode() : 0);
        return result;
    }


    public void setEndDate(Date endDateFormat) {
        this.endDateFormat = endDateFormat;
    }

    public void setStartDate(Date startDateFormat) {
        this.startDateFormat = startDateFormat;
    }

    public Date getEndDateFormat() {
        return endDateFormat;
    }

    public void setEndDateFormat(Date endDateFormat) {
        this.endDateFormat = endDateFormat;
    }

    public Date getStartDateFormat() {
        return startDateFormat;
    }

    public String getDataLoadError() {
        return dataLoadError;
    }

    public void setDataLoadError(String dataLoadError) {
        this.dataLoadError = dataLoadError;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Boolean isUserThis(final String str) {
        for (BBSRole role : roles) {
            if (role.getDescription().equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }

    public boolean isESHAdmin() {
        for (BBSRole role : roles) {
            if (role.getDescription().equalsIgnoreCase(ESH_ADMIN)) {
                return true;
            }
        }
        return false;
    }

    public boolean isGlobalLead() {
        for (BBSRole role : roles) {
            if (role.getDescription().equalsIgnoreCase(GLOBAL_LEAD)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEMEAAdmin() {
        for (BBSRole role : roles) {
            if (role.getDescription().equalsIgnoreCase(EMEA_REGION_ADMIN)) {
                return true;
            }
        }
        return false;
    }

    public void setLocationCode(final String str) {
        locationCode = str;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public boolean isAlreadyPersisted() {
        return alreadyPersisted;
    }

    public void setAlreadyPersisted(boolean alreadyPersisted) {
        this.alreadyPersisted = alreadyPersisted;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public BBSUser getManager() {
        return manager;
    }

    public void setManager(BBSUser manager) {
        this.manager = manager;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBusinessArea() {
        return businessArea;
    }

    public void setBusinessArea(String businessArea) {
        this.businessArea = businessArea;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
}
