/*
 BehaviorCategory was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author vrbethi
 * @version $Revision$
 */

@Entity
@Table(schema = "BBS", name = "BARRIER_CAT")
//@AssociationOverride(name = "id.barrierCategory.category", joinColumns = @JoinColumn(name = "CAT_ID"))
public class BarrierCategory {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;
   private static final int PRIME_HASH_CODE_CONSTANT_2 = 17;

   @Id
   @Column(name = "ID")
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @ManyToOne
   @JoinColumn(name = "CAT_ID", referencedColumnName = "ID")
   private Category category;

   @Column(name = "active")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();


   public BarrierCategory() {
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public Category getCategory() {
      return category;
   }

   public void setCategory(Category category) {
      this.category = category;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

   @Override
   public int hashCode() {
      return new HashCodeBuilder(PRIME_HASH_CODE_CONSTANT_2, PRIME_HASH_CODE_CONSTANT).append(id).append(isActive()).append(category).toHashCode();
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }

      if (!(o instanceof BarrierCategory)) {
         return false;
      }

      BarrierCategory bc = (BarrierCategory) o;
      return new EqualsBuilder().append(id, bc.getId()).append(isActive(), bc.isActive()).append(category, bc.getCategory()).isEquals();
   }
}