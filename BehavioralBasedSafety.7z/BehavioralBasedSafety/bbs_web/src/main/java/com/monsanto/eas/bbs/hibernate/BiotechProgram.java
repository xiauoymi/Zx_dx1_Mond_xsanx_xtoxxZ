package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 18/06/12
 * Time: 04:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "BBS", name = "BIOTECH_PROGRAM")
public class BiotechProgram implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @Column(name = "PLANT_CODE")
   private String plantCode;

   @Column(name = "PROGRAM")
   private String program;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate;

   public BiotechProgram() {
   }

   public BiotechProgram(final Long id, final String plantCode, final String program) {
      this.id = id;
      this.plantCode = plantCode;
      this.program = program;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getPlantCode() {
      return plantCode;
   }

   public void setPlantCode(String plantCode) {
      this.plantCode = plantCode;
   }

   public String getProgram() {
      return program;
   }

   public void setProgram(String program) {
      this.program = program;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      }

      if (obj == null) {
         return false;
      }

      if (getClass() != obj.getClass()) {
         return false;
      }

      final BiotechProgram biotechProgramTemp = (BiotechProgram) obj;

      if (plantCode == null || plantCode.equals("")) {
         if (biotechProgramTemp.getPlantCode() != null && !biotechProgramTemp.getPlantCode().equals("")) {
            return false;
         }
      } else if (!plantCode.equals(biotechProgramTemp.getPlantCode())) {
         return false;
      }

      if (program == null || program.equals("")) {
         if (biotechProgramTemp.getProgram() != null && !biotechProgramTemp.getProgram().equals("")) {
            return false;
         }
      } else if (!program.equals(biotechProgramTemp.getProgram())) {
         return false;
      }
      return true;
   }

   public int hashCode() {
      int result = 1;

      result = PRIME_HASH_CODE_CONSTANT * result + ((plantCode == null || plantCode.equals("")) ? 0 : plantCode.hashCode());
      result = PRIME_HASH_CODE_CONSTANT * result + ((program == null || program.equals("")) ? 0 : program.hashCode());

      return result;
   }

}
