package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 21/06/12
 * Time: 04:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "BBS", name = "BIOTECH_PROJECT_PLAT")
public class BiotechProjectPlatform implements Serializable {

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @ManyToOne
   @JoinColumn(name = "PROGRAM_ID", referencedColumnName = "ID")
   private BiotechProgram biotechProgram;

   @Column(name = "PROJECT_DESC")
   private String projectDescription;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate;


   public BiotechProjectPlatform() {
   }

   public BiotechProjectPlatform(Long id, BiotechProgram biotechProgram, String projectDescription) {
      this.id = id;
      this.biotechProgram = biotechProgram;
      this.projectDescription = projectDescription;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public BiotechProgram getBiotechProgram() {
      return biotechProgram;
   }

   public void setBiotechProgram(BiotechProgram biotechProgram) {
      this.biotechProgram = biotechProgram;
   }

   public String getProjectDescription() {
      return projectDescription;
   }

   public void setProjectDescription(String projectDescription) {
      this.projectDescription = projectDescription;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }
}
