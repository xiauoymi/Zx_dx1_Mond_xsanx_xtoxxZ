package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(schema = "BBS", name = "CATEGORY")
public class Category
{
   @Id
   @Column(name = "ID")
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @ManyToOne
   @JoinColumn(name = "PARENT_CAT_ID", referencedColumnName = "ID")
   private Category parentCategory;

   @Column(name = "ACTIVE")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "CAT_LEVEL")
   private int level;

   @Transient
   private List<LanguageBasedCategory> subCategories = new ArrayList<LanguageBasedCategory>();

   @Transient
   private Set<BarrierCategory> barrierCategories = new HashSet<BarrierCategory>();

   @ManyToOne
   @JoinColumn(name = "CATEGORY_TYPE_ID", referencedColumnName = "ID")
   private CategoryType categoryType;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();

   public Category() {
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public Category getParentCategory() {
      return parentCategory;
   }

   public void setParentCategory(Category parentCategory) {
      this.parentCategory = parentCategory;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public List<LanguageBasedCategory> getSubCategories() {
      return subCategories;
   }

   public void setSubCategories(List<LanguageBasedCategory> subCategories) {
      this.subCategories = subCategories;
   }

   public CategoryType getCategoryType() {
      return categoryType;
   }

   public int getLevel() {
      return level;
   }

   public void setLevel(int level) {
      this.level = level;
   }

   public void setCategoryType(CategoryType categoryType) {
      this.categoryType = categoryType;
   }

   public Set<BarrierCategory> getBarrierCategories() {
      return barrierCategories;
   }

   public void setBarrierCategories(Set<BarrierCategory> barrierCategories) {
      this.barrierCategories = barrierCategories;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

   public boolean isNew() {
      return ( id == null );
   }

   public boolean hasParent() {
      return ( parentCategory != null );
   }

   public boolean hasGrandParent() {
      return ( hasParent() && parentCategory.hasParent() );
   }

   @Override
   public int hashCode() {
      int result = 0;
      result = (id != null ? id.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object obj) {
      return super.equals(obj);
   }
}