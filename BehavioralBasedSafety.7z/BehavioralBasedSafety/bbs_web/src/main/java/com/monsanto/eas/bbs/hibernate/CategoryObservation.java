/*
 Observation was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

import static com.monsanto.eas.bbs.util.report.enums.CategoryType.ENVIRONMENT;
import static com.monsanto.eas.bbs.util.report.enums.PersonnelType.NOT_APPLICABLE;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author vrbethi
 * @version $Revision$
 */

//CREATE TABLE BBS.CAT_OBSERVATION(
// "ID" NUMBER(10,0),                    done
// "OBSERVATION_ID" NUMBER(10,0),
// "RESPONSE_ID" NUMBER(10,0),       done
// "CATEGORY_ID" NUMBER(10,0),      done
// "DESCRIPTION" NVARCHAR2(2000),    done
// "FEEDBACK" NVARCHAR2(2000),    done
// "IMMEDIATE_ACTIONS" NVARCHAR2(2000),  done
// "COMMENTS" NVARCHAR2(2000),               done
// "BARRIER_CAT_ID" NUMBER(10,0),
// CONSTRAINT CAT_OBSERVATION_PK PRIMARY KEY (ID)
//);

@Entity
@Table(schema = "BBS", name = "CAT_OBSERVATION")
public class CategoryObservation implements Serializable
{
    @Id
    @Column(name = "ID")
    @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "OBSERVATION_ID", referencedColumnName = "ID")
    private Observation observation;

    @ManyToOne
    @JoinColumn(name = "RESPONSE_ID", referencedColumnName = "ID")
    private Response response;

    @ManyToOne
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "ID")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "SUB_CAT_ID", referencedColumnName = "ID")
    private Category subCategory;

    @ManyToOne
    @JoinColumn(name = "SUB_SUB_CAT_ID", referencedColumnName = "ID")
    private Category subSubCategory;

    @ManyToOne
    @JoinColumn(name = "BARRIER_CAT_ID")
    private BarrierCategory barrierCategory;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "FEEDBACK")
    private String feedback;

    @Column(name = "IMMEDIATE_ACTIONS")
    private String immediateActions;

    @Column(name = "SAFE_BEHAVIOR_FEEDBACK")
    private String safeBehaviorFeedback;

    @Column(name = "SAFE_BEHAVIOR_COMMENTS")
    private String safeBehaviorComments;

    @Column(name = "SAFE_BEHAVIOR_DESCRIPTION")
    private String safeBehaviorDescription;

    @Transient
    private String responseDesc;

    @Transient
    private String barrierDesc;

    @Transient
    private String childCatDesc;

    @Transient
    private String parentCatDesc;

    @Transient
    private String grandParentCatDesc;

    @Column(name = "COMMENTS")
    private String comments;

    public CategoryObservation() {
    }

    public CategoryObservation(Long id, String feedback, String comments, String description,
                               String immediateActions, String barrierDesc, String childCatDesc,
                               String parentCatDesc, String grandParentCatDesc, String responseDesc,
                               String safeBehaviorFeedback, String safeBehaviorComments, String safeBehaviorDescription) {
        this.id = id;
        this.feedback = feedback;
        this.comments = comments;
        this.description = description;
        this.immediateActions = immediateActions;
        this.barrierDesc = barrierDesc;
        this.childCatDesc = childCatDesc;
        this.parentCatDesc = parentCatDesc;
        this.grandParentCatDesc = grandParentCatDesc;
        this.responseDesc = responseDesc;
        this.safeBehaviorFeedback = safeBehaviorFeedback;
        this.safeBehaviorComments = safeBehaviorComments;
        this.safeBehaviorDescription = safeBehaviorDescription;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Category getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(Category subCategory) {
        this.subCategory = subCategory;
    }

    public Category getSubSubCategory() {
        return subSubCategory;
    }

    public void setSubSubCategory(Category subSubCategory) {
        this.subSubCategory = subSubCategory;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return ((CategoryObservation) obj).getId().equals(this.getId());
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getImmediateActions() {
        return immediateActions;
    }

    public void setImmediateActions(String immediateActions) {
        this.immediateActions = immediateActions;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public BarrierCategory getBarrierCategory() {
        return barrierCategory;
    }

    public void setBarrierCategory(BarrierCategory barrierCategory) {
        this.barrierCategory = barrierCategory;
    }

    public Observation getObservation() {
        return observation;
    }

    public void setObservation(Observation observation) {
        this.observation = observation;
    }

    public String getResponseDesc() {
        return responseDesc;
    }

    public void setResponseDesc(String responseDesc) {
        this.responseDesc = responseDesc;
    }

    public String getSafeBehaviorFeedback() {
        return safeBehaviorFeedback;
    }

    public void setSafeBehaviorFeedback(String safeBehaviorFeedback) {
        this.safeBehaviorFeedback = safeBehaviorFeedback;
    }

    public String getSafeBehaviorComments() {
        return safeBehaviorComments;
    }

    public void setSafeBehaviorComments(String safeBehaviorComments) {
        this.safeBehaviorComments = safeBehaviorComments;
    }

    public String getSafeBehaviorDescription() {
        return safeBehaviorDescription;
    }

    public void setSafeBehaviorDescription(String safeBehaviorDescription) {
        this.safeBehaviorDescription = safeBehaviorDescription;
    }

    public String getBarrierDesc() {
        return barrierDesc;
    }

    public void setBarrierDesc(String barrierDesc) {
        this.barrierDesc = barrierDesc;
    }

    public String getChildCatDesc() {
        return childCatDesc;
    }

    public void setChildCatDesc(String childCatDesc) {
        this.childCatDesc = childCatDesc;
    }

    public String getParentCatDesc() {
        return parentCatDesc;
    }

    public void setParentCatDesc(String parentCatDesc) {
        this.parentCatDesc = parentCatDesc;
    }

    public String getGrandParentCatDesc() {
        return grandParentCatDesc;
    }

    public void setGrandParentCatDesc(String grandParentCatDesc) {
        this.grandParentCatDesc = grandParentCatDesc;
    }

    public String getPersonnelTypeDesc() {
        return category.getCategoryType().getDescription().equals(ENVIRONMENT.toString()) ? NOT_APPLICABLE.toString() : observation.getPersonnelTypeDesc();
    }
}