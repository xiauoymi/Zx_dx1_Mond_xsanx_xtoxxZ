package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(schema = "BBS", name = "CATEGORY_TYPE")
public class CategoryType implements Serializable
{
    @Id
    @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
    private Long id;

    @Column(name = "ACTIVE")
    @Type(type = "yes_no")
    private boolean active;

    @Column(name = "IS_BEHAVIOR")
    @Type(type = "yes_no")
    private boolean behavior;

    @Column(name = "DESCRIPTION")
    private String description;

    public CategoryType() {
    }

    public CategoryType(int id, String description) {
        this.id = Long.valueOf(id);
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isBehavior() {
        return behavior;
    }

    public void setBehavior(boolean behavior) {
        this.behavior = behavior;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryType that = (CategoryType) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
