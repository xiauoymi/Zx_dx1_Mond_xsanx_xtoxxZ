package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 21, 2010
 * Time: 1:38:56 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "BBS" , name="COUNTRY")
public class Country implements Serializable{

  @Id
  @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
  private Long id;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "COUNTRY_CODE")
  private String countryCode;

  @Column(name = "ACTIVE")
  @Type(type="yes_no")
  private boolean active;

  @Column(name ="SHOW_CONDITION_TAB")
  @Type(type = "yes_no")
  private boolean showEnvironmentTab;

//  @OneToMany(fetch = FetchType.LAZY, mappedBy = "country")
  @Transient
  private Set<Plant> plants = new HashSet<Plant>();

  @Column(name = "REGION_ID")
  private Long regionId;

  public Country(){
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public boolean isShowEnvironmentTab() {
    return showEnvironmentTab;
  }

  public void setShowEnvironmentTab(boolean showEnvironmentTab) {
    this.showEnvironmentTab = showEnvironmentTab;
  }

  public Set<Plant> getPlants() {
    return plants;
  }

  public void setPlants(Set<Plant> plants) {
    this.plants = plants;
  }

  public void setRegionId(final Long regionId) {
    this.regionId = regionId;
  }
  public Long getRegionId() {
    return regionId;
  }
}
