/*
 Department was created on Mar 2, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "DEPARTMENT")
public class Department implements Serializable {
    @Id
    @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "CODE")
    private Long code;

    @Column(name = "active")
    @Type(type = "yes_no")
    private boolean active;

    @Column(name = "is_company")
    @Type(type = "yes_no")
    private boolean company;

    @Column(name = "MOD_USER")
    private String modUser = "BBS_USER";

    @Column(name = "MOD_DATE")
    private Date modDate = new Date();

    private static final long serialVersionUID = -9146791758008323949L;

    public Department(){}

    public Department (Long code, String name) {
        this.code = code;
        this.name = name;
        this.active = true;
        this.company = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isCompany() {
        return company;
    }

    public void setCompany(boolean company) {
        this.company = company;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Department)) {
            return false;
        }

        Department department = (Department) obj;
        if (!id.equals(department.getId())) {
            return false;
        }
        return true;
    }
}