package com.monsanto.eas.bbs.hibernate;

import com.monsanto.eas.bbs.dao.GenericDAO;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Mar 16, 2010
 * Time: 12:50:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class GenericHibernateDAO<T, ID extends Serializable> extends HibernateDaoSupport implements GenericDAO<T, ID>{
  public void save(T entity){
    getHibernateTemplate().save(entity);
  }

  public void delete(T entity) {
    getHibernateTemplate().delete(entity);
  }
}
