package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

@Entity(name = "LA")
@Table(schema = "BBS", name = "LANGUAGE")
public class Language implements Serializable {
   @Id
   @Column(name = "ID")
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @Column(name = "DESCRIPTION")
   private String description;

   @Column(name = "ACTIVE")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "LOCALE")
   private String locale;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();

   @Transient
   private Set<LanguageBasedCategory> languageRelatedCategories;

   @Transient
   private Collection<LanguageBasedArea> languageBasedParentAreas = new ArrayList<LanguageBasedArea>();

   public Language() {
   }

   public Language(Long id, String description, boolean active, String locale) {
      this.id = id;
      this.description = description;
      this.active = active;
      this.locale = locale;
   }

   public Long getId() {
      return id;
   }

   public String getDescription() {
      return description;
   }

   public boolean isActive() {
      return active;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public Collection<LanguageBasedArea> getLanguageBasedParentAreas() {
      return languageBasedParentAreas;
   }

   public void setLanguageBasedParentAreas(Collection<LanguageBasedArea> languageBasedParentAreas) {
      this.languageBasedParentAreas = languageBasedParentAreas;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

   public String getLocale() {
      return locale;
   }

   public void setLocale(String locale) {
      this.locale = locale;
   }


   public Set<LanguageBasedCategory> getLanguageRelatedCategories() {
      return languageRelatedCategories;
   }

   public void setLanguageRelatedCategories(Set<LanguageBasedCategory> languageRelatedCategories) {
      this.languageRelatedCategories = languageRelatedCategories;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (!(o instanceof Language)) {
         return false;
      }

      Language language = (Language) o;
      if (!id.equals(language.getId())) {
         return false;
      }
      return true;
   }

   @Override
   public int hashCode() {
      return id.hashCode();
   }

}