/*
 LanguageBehaviorCategory was created on Jan 12, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author vrbethi
 * @version $Revision$
 */

//--LAN_BEHAVIOR_CATEGORY
//CREATE TABLE BBS.LAN_BARRIER_CAT(
//  "BARRIER_CAT_ID" NUMBER(10,0),
//  "LANG_ID" NUMBER(10,0),
//  "DESCRIPTION" NVARCHAR2(2000),
//  CONSTRAINT  LAN_BARRIER_CAT_PK PRIMARY KEY (BARRIER_CAT_ID,LANG_ID)
//);
@Entity(name = "LBRC")
@Table(schema = "BBS", name = "LAN_BARRIER_CAT")
@AssociationOverrides({
        @AssociationOverride(name = "id.language", joinColumns = @JoinColumn(name = "lang_id")),
        @AssociationOverride(name = "id.barrierCategory", joinColumns = @JoinColumn(name = "BARRIER_CAT_ID")),
        @AssociationOverride(name = "id.barrierCategory.category", joinColumns = @JoinColumn(name = "CAT_ID"))
})
public class LanguageBarrierCategory {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @EmbeddedId
   private LanguageBarrierCategoryPK id;

   @Column(name = "DESCRIPTION")
   private String description;

   public LanguageBarrierCategory() {
   }

   public LanguageBarrierCategoryPK getId() {
      return id;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   @Override
   public int hashCode() {
      int result;
      result = (id != null ? id.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (description != null ? description.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object instance) {
      if (instance == null){
         return false;
      }

      if (!(instance instanceof LanguageBarrierCategory)) {
         return false;
      }

      LanguageBarrierCategory other = (LanguageBarrierCategory) instance;
      if (!(id.getLanguage().getId().equals(other.getId().getLanguage().getId()))) {
         return false;
      }

      if (!(id.getBarrierCategory().getId().equals(other.getId().getBarrierCategory().getId()))) {
         return false;
      }

      // ATT: use immutable fields like description in equals() implementation
      if (!(description.equals(other.getDescription()))) {
         return false;
      }

      return true;
   }

   public void setId(LanguageBarrierCategoryPK id) {
      this.id = id;
   }
}