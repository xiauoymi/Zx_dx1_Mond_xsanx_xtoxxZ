/*
 LanguageBasedArea was created on Jan 28, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "LAN_AREA")
@AssociationOverrides({
        @AssociationOverride(name = "id.language", joinColumns = @JoinColumn(name = "bbs_lang_id")),
        @AssociationOverride(name = "id.area", joinColumns = @JoinColumn(name = "area_id"))
})
public class LanguageBasedArea implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @EmbeddedId
   private LanguageBasedAreaPK id;

   @Column(name = "DESCRIPTION")
   private String description;

   public LanguageBasedArea() {
   }

   public LanguageBasedAreaPK getId() {
      return id;
   }

   public void setId(LanguageBasedAreaPK id) {
      this.id = id;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   @Override
   public boolean equals(Object obj) {
      if (obj == null) {
         return false;
      }

      if (!(obj instanceof LanguageBasedArea)) {
         return false;
      }

      LanguageBasedArea other = (LanguageBasedArea) obj;
      if (!(id.getLanguage().getId().equals(other.getId().getLanguage().getId()))) {
         return false;
      }

      if (!(id.getArea().getId().equals(other.getId().getArea().getId()))) {
         return false;
      }

      // ATT: use immutable fields like description in equals() implementation
      if (!(description.equals(other.getDescription()))) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result;
      result = (id != null ? id.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (description != null ? description.hashCode() : 0);
      return result;
   }
}