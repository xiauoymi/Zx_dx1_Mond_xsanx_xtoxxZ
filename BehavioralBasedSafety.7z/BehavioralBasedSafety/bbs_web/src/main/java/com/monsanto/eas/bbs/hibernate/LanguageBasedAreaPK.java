/*
 LanguageBasedAreaPK was created on Jan 28, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Embeddable

public class LanguageBasedAreaPK implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @ManyToOne
   private Area area;

   @ManyToOne
   private Language language;

   public LanguageBasedAreaPK() {
   }

   public Area getArea() {
      return area;
   }

   public void setArea(Area area) {
      this.area = area;
   }

   public Language getLanguage() {
      return language;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   @Override
   public int hashCode() {
      int result;
      result = (language != null ? language.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (area != null ? area.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }

      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      LanguageBasedAreaPK languageBasedAreaPK = (LanguageBasedAreaPK) o;

      if (language != null ? !language.equals(languageBasedAreaPK.language) : languageBasedAreaPK.language != null) {
         return false;
      }

      if (area != null ? !area.equals(languageBasedAreaPK.getArea()) : languageBasedAreaPK.getArea() != null) {
         return false;
      }

      return true;
   }
}