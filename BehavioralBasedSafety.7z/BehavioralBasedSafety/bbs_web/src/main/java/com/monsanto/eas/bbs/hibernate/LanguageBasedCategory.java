/*
 LanguageBasedCategory was created on Jan 15, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Entity(name = "LCCat")
@Table(schema = "BBS", name = "LAN_CATEGORY")
@AssociationOverrides({
        @AssociationOverride(name = "id.language", joinColumns = @JoinColumn(name = "bbs_lang_id")),
        @AssociationOverride(name = "id.category", joinColumns = @JoinColumn(name = "category_id"))
})
public class LanguageBasedCategory implements Comparable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @Column(name = "DESCRIPTION")
   private String description;

   @EmbeddedId
   private LanguageBasedCategoryPK id;

   public void setDescription(String description) {

      this.description = description;
   }

   public void setId(LanguageBasedCategoryPK id) {
      this.id = id;
   }

   public String getDescription() {
      return description;
   }

   public LanguageBasedCategoryPK getId() {
      return id;
   }

   @Override
   public boolean equals(Object instance) {
      if (instance == null) {
         return false;
      }

      if (!(instance instanceof LanguageBasedCategory)) {
         return false;
      }

      LanguageBasedCategory other = (LanguageBasedCategory) instance;
      if (!(id.getLanguage().getId().equals(other.getId().getLanguage().getId()))) {
         return false;
      }

      if (!(id.getCategory().getId().equals(other.getId().getCategory().getId()))) {
         return false;
      }

      // ATT: use immutable fields like description in equals() implementation
      if (!(description.equals(other.getDescription()))) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result;
      result = (id != null ? id.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (description != null ? description.hashCode() : 0);
      return result;
   }

   public int compareTo(Object o) {
      return getDescription().compareTo(((LanguageBasedCategory) o).getDescription());
   }
}