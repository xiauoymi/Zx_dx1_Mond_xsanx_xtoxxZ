/*
 LanguageBasedCategoryPK was created on Jan 15, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Embeddable
public class LanguageBasedCategoryPK implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @ManyToOne
   private Language language;

   @ManyToOne
   private Category category;

   public void setLanguage(Language language) {
      this.language = language;
   }

   public void setCategory(Category category) {
      this.category = category;
   }

   public Language getLanguage() {
      return language;
   }

   public Category getCategory() {
      return category;
   }

   @Override
   public int hashCode() {
      int result;
      result = (language != null ? language.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (category != null ? category.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      LanguageBasedCategoryPK languageBasedCategoryPK = (LanguageBasedCategoryPK) o;

      return !(language != null ? !language.equals(languageBasedCategoryPK.getLanguage()) :
              languageBasedCategoryPK.getLanguage() != null) &&
              !(category != null ? !category.equals(languageBasedCategoryPK.getCategory()) :
                      languageBasedCategoryPK.getCategory() != null);

   }
}