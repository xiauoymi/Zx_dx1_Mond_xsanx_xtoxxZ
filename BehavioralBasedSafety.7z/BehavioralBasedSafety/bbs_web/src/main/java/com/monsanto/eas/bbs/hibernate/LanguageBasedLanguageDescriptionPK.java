/*
 LanguageBasedLanguageDescriptionPK was created on Mar 23, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ERODRI5
 * @version $Revision$
 */
public class LanguageBasedLanguageDescriptionPK implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @ManyToOne
   private Language languageDescription;

   @ManyToOne
   private Language language;

   public LanguageBasedLanguageDescriptionPK() {
   }

   public Language getLanguageDescription() {
      return languageDescription;
   }

   public void setLanguageDescription(Language languageDescription) {
      this.languageDescription = languageDescription;
   }

   public Language getLanguage() {
      return language;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   @Override
   public int hashCode() {
      int result;
      result = (language != null ? language.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (languageDescription != null ? languageDescription.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }

      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      LanguageBasedLanguageDescriptionPK languageBasedLanguageDescriptionPK = (LanguageBasedLanguageDescriptionPK) o;

      if (language != null ? !language.equals(languageBasedLanguageDescriptionPK.language) : languageBasedLanguageDescriptionPK.language != null) {
         return false;
      }

      if (languageDescription != null ? !languageDescription.equals(languageBasedLanguageDescriptionPK.getLanguageDescription()) : languageBasedLanguageDescriptionPK.getLanguageDescription() != null) {
         return false;
      }

      return true;
   }
}
