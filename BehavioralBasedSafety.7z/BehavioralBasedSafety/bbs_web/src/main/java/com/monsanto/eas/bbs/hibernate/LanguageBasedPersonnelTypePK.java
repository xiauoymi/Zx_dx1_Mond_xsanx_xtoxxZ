/*
 LanguageBasedPersonnelTypePK was created on Jan 28, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Embeddable
public class LanguageBasedPersonnelTypePK implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @ManyToOne
   private PersonnelType personnelType;

   @ManyToOne
   private Language language;

   public LanguageBasedPersonnelTypePK() {
   }

   public PersonnelType getPersonnelType() {
      return personnelType;
   }

   public void setPersonnelType(PersonnelType personnelType) {
      this.personnelType = personnelType;
   }

   public Language getLanguage() {
      return language;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   @Override
   public int hashCode() {
      int result;
      result = (language != null ? language.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (personnelType != null ? personnelType.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }

      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      LanguageBasedPersonnelTypePK languageBasedPersonnelTypePK = (LanguageBasedPersonnelTypePK) o;

      if (language != null ? !language.equals(languageBasedPersonnelTypePK.language) : languageBasedPersonnelTypePK.language != null) {
         return false;
      }

      if (personnelType != null ? !personnelType.equals(languageBasedPersonnelTypePK.getPersonnelType()) : languageBasedPersonnelTypePK.getPersonnelType() != null) {
         return false;
      }

      return true;
   }
}