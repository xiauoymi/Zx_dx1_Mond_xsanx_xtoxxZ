/*
 LanguageBasedResponse was created on Jan 20, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Entity(name = "LBR")
@Table(schema = "BBS", name = "LAN_RESPONSE")
@AssociationOverrides({
        @AssociationOverride(name = "id.language", joinColumns = @JoinColumn(name = "bbs_lang_id")),
        @AssociationOverride(name = "id.response", joinColumns = @JoinColumn(name = "response_id"))
})
public class LanguageBasedResponse implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @EmbeddedId
   private LanguageBasedResponsePK id;

   @Column(name = "DESCRIPTION")
   private String description;

   public LanguageBasedResponse() {
   }

   public LanguageBasedResponsePK getId() {
      return id;
   }

   public void setId(LanguageBasedResponsePK id) {
      this.id = id;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   @Override
   public boolean equals(Object obj) {
      if (obj == null) {
         return false;
      }

      if (!(obj instanceof LanguageBasedResponse)) {
         return false;
      }

      LanguageBasedResponse other = (LanguageBasedResponse) obj;
      if (!(id.getLanguage().getId().equals(other.getId().getLanguage().getId()))) {
         return false;
      }

      if (!(id.getResponse().getId().equals(other.getId().getResponse().getId()))) {
         return false;
      }

      // ATT: use immutable fields like description in equals() implementation
      if (!(description.equals(other.getDescription()))) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result;
      result = (id != null ? id.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (description != null ? description.hashCode() : 0);
      return result;
   }
}