package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(schema = "BBS", name = "LAN_CATEGORY_TYPE")
@AssociationOverrides({
    @AssociationOverride(name = "id.language", joinColumns = @JoinColumn(name = "bbs_lang_id")),
    @AssociationOverride(name = "id.categoryType", joinColumns = @JoinColumn(name = "CATEGORY_TYPE_ID"))
})
public class LanguageCategoryType implements Serializable
{
    private static final int PRIME_HASH_CODE_CONSTANT = 31;

    @EmbeddedId
    private LanguageCategoryTypePK id;

    @Column(name = "DESCRIPTION")
    private String description;

    public LanguageCategoryTypePK getId() {
        return id;
    }

    public void setId(LanguageCategoryTypePK id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = PRIME_HASH_CODE_CONSTANT * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (!(obj instanceof LanguageCategoryType)) {
            return false;
        }

        LanguageCategoryType other = (LanguageCategoryType) obj;
        if (!(id.getLanguage().getId().equals(other.getId().getLanguage().getId()))) {
            return false;
        }

        if (!(id.getCategoryType().getId().equals(other.getId().getCategoryType().getId()))) {
            return false;
        }

        // ATT: use immutable fields like description in equals() implementation
        if (!(description.equals(other.getDescription()))) {
            return false;
        }

        return true;
    }
}
