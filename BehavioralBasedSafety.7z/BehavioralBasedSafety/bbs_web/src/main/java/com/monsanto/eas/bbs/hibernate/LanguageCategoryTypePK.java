package com.monsanto.eas.bbs.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: Apr 20, 2010
 * Time: 2:20:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class LanguageCategoryTypePK implements Serializable {

   private static final int PRIME_HASH_CODE_CONSTANT = 31;

   @ManyToOne
   private CategoryType categoryType;

   @ManyToOne
   private Language language;

   public CategoryType getCategoryType() {
      return categoryType;
   }

   public void setCategoryType(CategoryType categoryType) {
      this.categoryType = categoryType;
   }

   public Language getLanguage() {
      return language;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   @Override
   public int hashCode() {
      int result;
      result = (language != null ? language.hashCode() : 0);
      result = PRIME_HASH_CODE_CONSTANT * result + (categoryType != null ? categoryType.hashCode() : 0);
      return result;
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      }

      if (obj == null || getClass() != obj.getClass()) {
         return false;
      }

      LanguageCategoryTypePK languageCategoryTypePK = (LanguageCategoryTypePK) obj;

      return !(language != null ? !language.equals(languageCategoryTypePK.language) :
              languageCategoryTypePK.language != null) && !(categoryType != null ? !categoryType.equals(languageCategoryTypePK.getCategoryType()) :
              languageCategoryTypePK.getCategoryType() != null);
   }
}
