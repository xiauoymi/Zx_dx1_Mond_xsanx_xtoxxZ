package com.monsanto.eas.bbs.hibernate;

import com.monsanto.eas.bbs.util.report.enums.*;
import com.monsanto.eas.bbs.util.report.enums.CategoryType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.persistence.Column;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.monsanto.eas.bbs.util.report.enums.CategoryType.ENVIRONMENT;
import static com.monsanto.eas.bbs.util.report.enums.PersonnelType.NOT_APPLICABLE;

@Entity
@Table(schema = "BBS", name = "OBSERVATION")
public class Observation implements Serializable {
   @Id
   @Column(name = "ID")
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @OneToOne
   @JoinColumn(name = "ENTERED_BY", referencedColumnName = "ID")
   private BBSUser enteredBy;

   @OneToOne
   @JoinColumn(name = "ENTERED_FOR", referencedColumnName = "ID")
   private BBSUser enteredFor;

   @OneToOne
   @JoinColumn(name = "LANGUAGE_ID", referencedColumnName = "ID")
   private Language language;

   @Column(name = "DATE_ENTERED")
   private Date dateEntered;

   @Transient
   private String areaDesc;
   @Transient
   private String subAreaDesc;
   @Transient
   private String personnelTypeDesc;

   @Column(name = "IS_ACTIVE")
   @Type(type = "yes_no")
   private boolean active;

   @OneToOne
   @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
   private Plant plant;

   @OneToOne
   @JoinColumn(name = "SAFETY_GROUP_ID", referencedColumnName = "ID")
   private SafetyGroup safetyGroup;

   @OneToOne
   @JoinColumn(name = "BIOTECH_PROGRAM_ID", referencedColumnName = "ID")
   private BiotechProgram biotechProgram;

   @OneToOne
   @JoinColumn(name = "BIOTECH_PROJECT_ID", referencedColumnName = "ID")
   private BiotechProjectPlatform biotechProjectPlatform;

   @ManyToOne
   @JoinColumn(name = "AREA_ID", referencedColumnName = "ID")
   private Area area;

   @OneToOne
   @JoinColumn(name = "SUB_AREA_ID", referencedColumnName = "ID")
   private Area subArea;

   @OneToOne
   @JoinColumn(name = "PERSONNEL_TYPE_ID", referencedColumnName = "ID")
   private PersonnelType personnelType;

   @OneToMany(fetch = FetchType.EAGER, mappedBy = "observation", cascade = CascadeType.ALL)
   private List<CategoryObservation> categoryObservations = new ArrayList<CategoryObservation>();

   @OneToOne
   @JoinColumn(name = "TASK_ID", referencedColumnName = "ID")
   private Task task;

   @Transient
   private String categoryTypeDescription;

   @Column(name = "MOD_USER")
   private String modUser;

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();

   public Observation() {
   }

   public Observation(Long id, BBSUser enteredBy, BBSUser enteredFor, Date dateEntered,
                      SafetyGroup safetyGroup, String areaDesc, String subAreaDesc,
                      String personnelTypeDesc, BiotechProgram biotechProgram, BiotechProjectPlatform biotechProjectPlatform, Task task, String modUser, Date modDate) {
      this.id = id;
      this.enteredBy = enteredBy;
      this.enteredFor = enteredFor;
      this.dateEntered = dateEntered;
      this.safetyGroup = safetyGroup;
      this.areaDesc = areaDesc;
      this.subAreaDesc = subAreaDesc;
      this.personnelTypeDesc = personnelTypeDesc;
      this.biotechProgram = biotechProgram;
      this.biotechProjectPlatform = biotechProjectPlatform;
      this.task = task;
      this.modUser = modUser;
      this.modDate = modDate;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public BBSUser getEnteredBy() {
      return enteredBy;
   }

   public void setEnteredBy(BBSUser enteredBy) {
      this.enteredBy = enteredBy;
   }

   public BBSUser getEnteredFor() {
      return enteredFor;
   }

   public void setEnteredFor(BBSUser enteredFor) {
      this.enteredFor = enteredFor;
   }

   public Date getDateEntered() {
      return dateEntered;
   }

   public void setDateEntered(Date dateEntered) {
      this.dateEntered = dateEntered;
   }

   public Plant getPlant() {
      return plant;
   }

   public void setPlant(Plant plant) {
      this.plant = plant;
   }

   public SafetyGroup getSafetyGroup() {
      return safetyGroup;
   }

   public void setSafetyGroup(SafetyGroup safetyGroup) {
      this.safetyGroup = safetyGroup;
   }

   public Area getArea() {
      return area;
   }

   public void setArea(Area area) {
      this.area = area;
   }

   public Area getSubArea() {
      return subArea;
   }

   public void setSubArea(Area subArea) {
      this.subArea = subArea;
   }

   public PersonnelType getPersonnelType() {
      return personnelType;
   }

   public void setPersonnelType(PersonnelType personnelType) {
      this.personnelType = personnelType;
   }

   public Language getLanguage() {
      return language;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   public List<CategoryObservation> getCategoryObservations() {
      categoryObservations.size();
      return categoryObservations;
   }

   public void setCategoryObservations(List<CategoryObservation> categoryObservations) {
      this.categoryObservations = categoryObservations;
   }

   public Task getTask() {
      return task;
   }

   public void setTask(Task task) {
      this.task = task;
   }

   public String getAreaDesc() {
      return areaDesc;
   }

   public void setAreaDesc(String areaDesc) {
      this.areaDesc = areaDesc;
   }

   public String getSubAreaDesc() {
      return subAreaDesc;
   }

   public void setSubAreaDesc(String subAreaDesc) {
      this.subAreaDesc = subAreaDesc;
   }

   public String getPersonnelTypeDesc() {
      return (categoryTypeDescription != null && categoryTypeDescription.equals(ENVIRONMENT.toString())) ? NOT_APPLICABLE.toString() : personnelTypeDesc;
   }

   public void setPersonnelTypeDesc(String personnelTypeDesc) {
      this.personnelTypeDesc = personnelTypeDesc;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public BiotechProgram getBiotechProgram() {
      return biotechProgram;
   }

   public void setBiotechProgram(BiotechProgram biotechProgram) {
      this.biotechProgram = biotechProgram;
   }

   public BiotechProjectPlatform getBiotechProjectPlatform() {
      return biotechProjectPlatform;
   }

   public void setBiotechProjectPlatform(BiotechProjectPlatform biotechProjectPlatform) {
      this.biotechProjectPlatform = biotechProjectPlatform;
   }

   public String getCategoryTypeDescription() {
      return categoryTypeDescription;
   }

   public void setCategoryTypeDescription(String categoryTypeDescription) {
      this.categoryTypeDescription = categoryTypeDescription;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Observation that = (Observation) o;
        return !(id != null ? !id.equals(that.id) : that.id != null);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}