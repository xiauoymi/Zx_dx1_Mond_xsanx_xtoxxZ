package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 12:24:50 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "BBS", name = "ORG_UNITS" )
public class OrgUnit implements Serializable{

  @Id
  @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
  private Long id;

  @Column(name = "DESCRIPTION")
  private String orgDescription;

  @Column(name = "ORG_UNIT_CODE")
  private String orgCode;

  @Column(name="ACTIVE")
  @Type(type = "yes_no")
  private boolean active;


  @OneToMany(fetch = FetchType.EAGER)
  @JoinColumn(name="PARENT_ID", referencedColumnName = "ID")
  private Set<Area> subOrgUnits = new HashSet<Area>();

  @Column(name = "ORG_LVL")
  private Long orgLevel;

  @Column(name = "DATA_LOAD_ERROR")
  private String dataLoadError;

  @Column(name = "MOD_USER")
  private String modUser;//  "MOD_USER" VARCHAR2(250),

  @Column(name = "MOD_DATE")
  private Date modDate;//  "MOD_DATE" DATE,

  @Column(name = "PARENT_ORG_CODE")
  private String parentOrgCode;

  public OrgUnit() {
  }

  public String getOrgDescription() {
    return orgDescription;
  }

  public void setOrgDescription(String orgDescription) {
    this.orgDescription = orgDescription;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Area> getSubOrgUnits() {
    return subOrgUnits;
  }

  public void setSubOrgUnits(Set<Area> subOrgUnits) {
    this.subOrgUnits = subOrgUnits;
  }

  public Long getOrgLevel() {
    return orgLevel;
  }

  public void setOrgLevel(Long orgLevel) {
    this.orgLevel = orgLevel;
  }

  public String getDataLoadError() {
    return dataLoadError;
  }

  public void setDataLoadError(String dataLoadError) {
    this.dataLoadError = dataLoadError;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getOrgCode() {
    return orgCode;
  }

  public void setOrgCode(String orgCode) {
    this.orgCode = orgCode;
  }

  public void setParentOrgCode(String orgUnitCode) {
    this.parentOrgCode = orgUnitCode;
  }

  public String getParentOrgCode() {
    return parentOrgCode;
  }

  public Long getId(){
    return id;
  }
}
