/*
 PlantArea was created on Feb 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "PLANT_AREA")
public class PlantArea {
  @EmbeddedId
  private PlantAreaPk id;

  public Area getArea() {
    return id.getArea();
  }

  public Plant getPlant() {
    return id.getPlant();
  }

  public PlantAreaPk getId() {
    return id;
  }

  public void setId(PlantAreaPk pk) {
    this.id = pk;
  }
}