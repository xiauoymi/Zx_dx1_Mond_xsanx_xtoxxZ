/*
 Response was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@Entity
@Table(schema = "BBS", name = "RESPONSE")
public class Response {

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @Column(name = "active")
   @Type(type = "yes_no")
   private boolean active;

   @Column(name = "show_dialog")
   @Type(type = "yes_no")
   private boolean showDialog;

   @Column(name = "is_default")
   @Type(type = "yes_no")
   private boolean defaultOption;

   @Column(name = "display_order")
   private int displayOrder;

   @Column(name = "MOD_USER")
   private String modUser = "BBS_USER";

   @Column(name = "MOD_DATE")
   private Date modDate = new Date();


   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public boolean isShowDialog() {
      return showDialog;
   }

   public void setShowDialog(boolean showDialog) {
      this.showDialog = showDialog;
   }

   public boolean isDefaultOption() {
      return defaultOption;
   }

   public void setDefaultOption(boolean defaultOption) {
      this.defaultOption = defaultOption;
   }

   public int getDisplayOrder() {
      return displayOrder;
   }

   public void setDisplayOrder(int displayOrder) {
      this.displayOrder = displayOrder;
   }

   public String getModUser() {
      return modUser;
   }

   public void setModUser(String modUser) {
      this.modUser = modUser;
   }

   public Date getModDate() {
      return modDate;
   }

   public void setModDate(Date modDate) {
      this.modDate = modDate;
   }
}