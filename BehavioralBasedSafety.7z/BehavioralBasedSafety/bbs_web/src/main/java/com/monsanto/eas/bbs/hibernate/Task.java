package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/05/13
 * Time: 04:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "BBS", name = "TASK")
public class Task implements Serializable {

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @Column(name = "DESCRIPTION")
   private String description;

   public Task(){}

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }
}
