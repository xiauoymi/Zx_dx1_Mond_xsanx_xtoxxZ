/*
 TempBBSUser was created on Feb 19, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "TEMP_BBS_USER")
public class TempBBSUser implements Serializable {

   private static final int HASHCODE_PRIME = 31;
   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   @Column(name = "ID")
   private Long id;

   @Column(name = "USER_ID")
   private String userId;

   @Column(name = "FIRST_NAME")
   private String firstName;

   @Column(name = "LAST_NAME")
   private String lastName;

   @Column(name = "MIDDLE_NAME")
   private String middleName;

   @ManyToOne(cascade = CascadeType.ALL)
   @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
   private Plant plant;

   @ManyToOne(cascade = CascadeType.ALL)
   @JoinColumn(name = "DEPARTMENT_ID", referencedColumnName = "ID")
   private Department department;

   @Column(name = "LOCATION_CODE")
   private String locationCode;

   @Transient
   private boolean alreadyPersisted;

   @Column(name = "PHONE_NBR")
   private String phoneNumber;

   @Column(name = "COST_CENTER")
   private String costCenter;

   @Column(name = "EMAIL_ADDR")
   private String emailAddress;

   //@ManyToOne(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
   //@JoinColumn(name = "MGR_USER_ID", referencedColumnName = "USER_ID")
   //private TempBBSUser manager;
   @Column(name = "MGR_USER_ID")
   private String manager;

   @Column(name = "COMPANY_CODE")
   private String companyCode;

   @Column(name = "BUSINESS_AREA")
   private String businessArea;


   public TempBBSUser(){}

   public String toString() {
      StringBuilder sb = new StringBuilder();
      sb.append("id=" + id + " ");
      sb.append("userId=" + userId + " ");
      sb.append("firstName=" + firstName + " ");
      sb.append("lastName=" + lastName + " ");
      sb.append("middleName=" + middleName + " ");
      sb.append("locationCode=" + locationCode + " ");

      return sb.toString();
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getUserId() {
      return userId;
   }

   public void setUserId(String userId) {
      this.userId = userId;
   }

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public String getMiddleName() {
      return middleName;
   }

   public void setMiddleName(String middleName) {
      this.middleName = middleName;
   }

   public Plant getPlant() {
      return plant;
   }

   public void setPlant(Plant plant) {
      this.plant = plant;
   }

   public Department getDepartment() {
      return department;
   }

   public void setDepartment(Department department) {
      this.department = department;
   }

   public String getLocationCode() {
      return locationCode;
   }

   public void setLocationCode(final String str) {
      locationCode = str;
   }


   public boolean isAlreadyPersisted() {
      return alreadyPersisted;
   }

   public void setAlreadyPersisted(boolean alreadyPersisted) {
      this.alreadyPersisted = alreadyPersisted;
   }

   public String getBusinessArea() {
      return businessArea;
   }

   public void setBusinessArea(String businessArea) {
      this.businessArea = businessArea;
   }

   public String getCompanyCode() {
      return companyCode;
   }

   public void setCompanyCode(String companyCode) {
      this.companyCode = companyCode;
   }

   public String getCostCenter() {
      return costCenter;
   }

   public void setCostCenter(String costCenter) {
      this.costCenter = costCenter;
   }

   public String getEmailAddress() {
      return emailAddress;
   }

   public void setEmailAddress(String emailAddress) {
      this.emailAddress = emailAddress;
   }
   /*
   public TempBBSUser getManager() {
      return manager;
   }

   public void setManager(TempBBSUser manager) {
      this.manager = manager;
   }
   */

   public String getManager() {
      return manager;
   }

   public void setManager(String manager) {
      this.manager = manager;
   }

   public String getPhoneNumber() {
      return phoneNumber;
   }

   public void setPhoneNumber(String phoneNumber) {
      this.phoneNumber = phoneNumber;
   }

    @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      //if (o == null || getClass() != o.getClass()) return false;
      if (!(o instanceof TempBBSUser)) return false;

      final TempBBSUser bbsUser = (TempBBSUser) o;

      if (costCenter == null || costCenter.equals("")) {
         if (bbsUser.getCostCenter() != null && !bbsUser.getCostCenter().equals("")) {
            return false;
         }
      } else if (!costCenter.equals(bbsUser.getCostCenter())) {
         return false;
      }

      if (getDepartment() == null || getDepartment().getCode().longValue() == 0) {
         if (bbsUser.getDepartment() != null && bbsUser.getDepartment().getCode().longValue() != 0) {
            return false;
         }
      } else if (!getDepartment().getCode().equals(bbsUser.getDepartment().getCode())) {
         return false;
      }

      if (emailAddress == null || emailAddress.equals("")) {
         if (bbsUser.getEmailAddress() != null && !bbsUser.getEmailAddress().equals("")) {
            return false;
         }
      } else if (!emailAddress.equals(bbsUser.getEmailAddress())) {
         return false;
      }

      if (firstName == null || firstName.equals("")) {
         if (bbsUser.getFirstName() != null && !bbsUser.getFirstName().equals("")) {
            return false;
         }
      } else if (!firstName.equals(bbsUser.getFirstName())) {
         return false;
      }

      if (lastName == null || lastName.equals("")) {
         if (bbsUser.getLastName() != null && !bbsUser.getLastName().equals("")) {
            return false;
         }
      } else if (!lastName.equals(bbsUser.getLastName())) {
         return false;
      }

      if (locationCode == null || locationCode.equals("")) {
         if (bbsUser.getLocationCode() != null && !bbsUser.getLocationCode().equals("")) {
            return false;
         }
      } else if (!locationCode.equals(bbsUser.getLocationCode())) {
         return false;
      }

      /*
      if (manager == null || manager.getUserId().equals("")) {
         if (bbsUser.getManager() != null && !bbsUser.getManager().getUserId().equals("")) {
            return false;
         }
      } else if (!manager.getUserId().equals(bbsUser.getManager().getUserId())) {
         return false;
      }
      */

      if (manager == null || manager.equals("")) {
         if (bbsUser.getManager() != null && !bbsUser.getManager().equals("")) {
            return false;
         }
      } else if (!manager.equals(bbsUser.getManager())) {
         return false;
      }


      if (middleName == null || middleName.equals("")) {
         if (bbsUser.getMiddleName() != null && !bbsUser.getMiddleName().equals("")) {
            return false;
         }
      } else if (!middleName.equals(bbsUser.getMiddleName())) {
         return false;
      }

      if (phoneNumber == null || phoneNumber.equals("")) {
         if (bbsUser.getPhoneNumber() != null && !bbsUser.getPhoneNumber().equals("")) {
            return false;
         }
      } else if (!phoneNumber.equals(bbsUser.getPhoneNumber())) {
         return false;
      }

      if (getPlant() == null || getPlant().getPlantCode().equals("")) {
         if (bbsUser.getPlant() != null && !bbsUser.getPlant().getPlantCode().equals("")) {
            return false;
         }
      } else if (!getPlant().getPlantCode().equals(bbsUser.getPlant().getPlantCode())) {
         return false;
      }

      if (companyCode == null || companyCode.equals("")) {
         if (bbsUser.getCompanyCode() != null && !bbsUser.getCompanyCode().equals("")) {
            return false;
         }
      } else if (!companyCode.equals(bbsUser.getCompanyCode())) {
         return false;
      }

      if (businessArea == null || businessArea.equals("")) {
         if (bbsUser.getBusinessArea() != null && !bbsUser.getBusinessArea().equals("")) {
            return false;
         }
      } else if (!businessArea.equals(bbsUser.getBusinessArea())) {
         return false;
      }

      if (userId == null || userId.equals("")) {
         if (bbsUser.getUserId() != null && !bbsUser.getUserId().equals("")) {
            return false;
         }
      } else if (!userId.equals(bbsUser.getUserId())) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = userId != null ? userId.hashCode() : 0;
      result = HASHCODE_PRIME * result + (firstName != null ? firstName.hashCode() : 0);
      result = HASHCODE_PRIME * result + (lastName != null ? lastName.hashCode() : 0);
      result = HASHCODE_PRIME * result + (middleName != null ? middleName.hashCode() : 0);
      result = HASHCODE_PRIME * result + (plant != null ? plant.hashCode() : 0);
      result = HASHCODE_PRIME * result + (locationCode != null ? locationCode.hashCode() : 0);
      result = HASHCODE_PRIME * result + (department != null ? department.hashCode() : 0);
      result = HASHCODE_PRIME * result + (phoneNumber != null ? phoneNumber.hashCode() : 0);
      result = HASHCODE_PRIME * result + (costCenter != null ? costCenter.hashCode() : 0);
      result = HASHCODE_PRIME * result + (emailAddress != null ? emailAddress.hashCode() : 0);
      result = HASHCODE_PRIME * result + (manager != null ? manager.hashCode() : 0);
      result = HASHCODE_PRIME * result + (companyCode != null ? companyCode.hashCode() : 0);
      result = HASHCODE_PRIME * result + (businessArea != null ? businessArea.hashCode() : 0);
      return result;
   }


   public BBSUser getBBSUserFromTempBBSUser(){
      BBSUser bbsUser = new BBSUser();
      BBSUser bbsUserManager = null;

      bbsUser.setUserId(getUserId());
      bbsUser.setFirstName(getFirstName());
      bbsUser.setLastName(getLastName());
      bbsUser.setMiddleName(getMiddleName());

      bbsUser.setEmployee(true);
      bbsUser.setActive(true);

      /*
      Plant plant = null;
      if(null != result[4]){
         plant = new Plant();
         plant.setId((Long) result[4]);
      }
      */
      bbsUser.setPlant(getPlant());
      /*
      Department department = null;
      if(null != result[5]){
         department = new Department();
         department.setId((Long) result[5]);
      }
      //department.setCode((Long) result[5]);
      */
      bbsUser.setDepartment(getDepartment());

      bbsUser.setLocationCode(getLocationCode());
      bbsUser.setPhoneNumber(getPhoneNumber());
      bbsUser.setCostCenter(getCostCenter());
      bbsUser.setEmailAddress(null);

      if(null != getManager() && !"".equals(getManager())){
         bbsUserManager = new BBSUser();
         bbsUserManager.setUserId(getManager());
      }

      bbsUser.setManager(bbsUserManager);

      bbsUser.setCompanyCode(getCompanyCode());
      bbsUser.setBusinessArea(getBusinessArea());

      return bbsUser;
   }

}