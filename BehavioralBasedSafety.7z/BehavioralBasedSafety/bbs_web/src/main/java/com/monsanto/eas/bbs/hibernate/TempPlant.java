/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "TEMP_PLANT")
public class TempPlant implements Serializable {
  @Id
  @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
  private Long id;

  @Column(name = "PLANT_CODE")
  private String plantCode;

  @Column(name = "PLANT_NAME_1")
  private String plantName1;

  @Column(name = "VALA")
  private String vala;

  @Column(name = "CUST_NO_PLANT")
  private String custNbrForPlant;

  @Column(name = "VENDOR_NO_PLANT")
  private String vendorNbrForPlant;

  @Column(name = "CAL")
  private String cal;

  @Column(name = "PLANT_NAME_2")
  private String plantName2;

  @Column(name = "STREET")
  private String street;

  @Column(name = "PO_BOX")
  private String poBox;

  @Column(name = "POSTAL_CODE")
  private String postalCode;

  @Column(name = "CITY")
  private String city;

  @Column(name = "PORG")
  private String porg;

  @Column(name = "ACTIVE")
  @Type(type = "yes_no")
  private boolean active;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  @Transient
  private Set<Area> areas = new HashSet<Area>();

  @Transient
  private Set<SafetyGroup> safetyGroups = new HashSet<SafetyGroup>();

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "ID")
  private Country country;

  @Transient
  private String countryCode;

  @Transient
  private String regionDescription;

  public TempPlant() {
  }

  public TempPlant(Long id, String plantCode, String plantName1, String vala, String custNbrForPlant,
               String vendorNbrForPlant, String cal, String plantName2, String street, String poBox,
               String postalCode, String city, String porg, boolean active, String modUser,
               Date modDate) {
    this.id = id;
    this.plantCode = plantCode;
    this.plantName1 = plantName1;
    this.vala = vala;
    this.custNbrForPlant = custNbrForPlant;
    this.vendorNbrForPlant = vendorNbrForPlant;
    this.cal = cal;
    this.plantName2 = plantName2;
    this.street = street;
    this.poBox = poBox;
    this.postalCode = postalCode;
    this.city = city;
    this.porg = porg;
    this.active = active;
    this.modUser = modUser;
    this.modDate = modDate;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getPlantCode() {
    return plantCode;
  }

  public void setPlantCode(String plantCode) {
    this.plantCode = plantCode;
  }

  public String getPlantName1() {
    return plantName1;
  }

  public void setPlantName1(String plantName1) {
    this.plantName1 = plantName1;
  }

  public String getVala() {
    return vala;
  }

  public void setVala(String vala) {
    this.vala = vala;
  }

  public String getCustomerNumberForPlant() {
    return custNbrForPlant;
  }

  public void setCustNbrForPlant(String custNbrForPlant) {
    this.custNbrForPlant = custNbrForPlant;
  }

  public String getVendorNbrForPlant() {
    return vendorNbrForPlant;
  }

  public void setVendorNbrForPlant(String vendorNbrForPlant) {
    this.vendorNbrForPlant = vendorNbrForPlant;
  }

  public String getCal() {
    return cal;
  }

  public void setCal(String cal) {
    this.cal = cal;
  }

  public String getPlantName2() {
    return plantName2;
  }

  public void setPlantName2(String plantName2) {
    this.plantName2 = plantName2;
  }

  public String getStreet() {
    return street;
  }

  public void setStreet(String street) {
    this.street = street;
  }

  public String getPoBox() {
    return poBox;
  }

  public void setPoBox(String poBox) {
    this.poBox = poBox;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getPorg() {
    return porg;
  }

  public void setPorg(String porg) {
    this.porg = porg;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Set<Area> getAreas() {
    return areas;
  }

  public void setAreas(Set<Area> areas) {
    this.areas = areas;
  }

  public Set<SafetyGroup> getSafetyGroups() {
    return safetyGroups;
  }

  public void setSafetyGroups(Set<SafetyGroup> safetyGroups) {
    this.safetyGroups = safetyGroups;
  }

  @Override
  public int hashCode() {
    return id.hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof Plant)) {
      return false;
    }

    Plant plant = (Plant) obj;
    if (!id.equals(plant.getId())) {
      return false;
    }
    return true;

  }

  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getRegionDescription() {
    return regionDescription;
  }

  public void setRegionDescription(String regionDescription) {
    this.regionDescription = regionDescription;
  }
}