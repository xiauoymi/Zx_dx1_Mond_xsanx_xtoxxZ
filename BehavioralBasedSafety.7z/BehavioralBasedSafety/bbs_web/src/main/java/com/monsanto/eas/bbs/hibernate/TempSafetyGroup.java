/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.hibernate;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "TEMP_SAFETY_GROUP")
public class TempSafetyGroup implements Serializable {

    @Id
    @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
    private Long id;
    @Column(name = "GROUP_TEXT")
    private String groupText;

    @ManyToOne
    @JoinColumn(name = "PLANT_CODE_ID", referencedColumnName = "ID")
    private Plant plant;

    @Column(name = "ACTIVE")
    @Type(type = "yes_no")
    private boolean active;

    @Column(name = "DATA_LOAD_ERROR")
    private String dataLoadError;

    @Column(name = "SAFETY_GROUP_CODE")
    private String safetyGroupCode;

    @Column(name = "ORG_UNIT_ID")
    private Long orgUnitId;

    @Column(name = "PLANT_CODE")
    private String plantCode;

    @Transient
    private String orgUnitCode;

    @Transient
    private String groupCode;

    @Column(name = "LOCATION_CODE")
    private String locationCode;

    @Column(name = "BIOTECH_IND")
    @Type(type = "yes_no")
    private boolean biotechInd;

    public TempSafetyGroup() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGroupText() {
        return groupText;
    }

    public void setGroupText(String groupText) {
        this.groupText = groupText;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isBiotechInd() {
        return biotechInd;
    }

    public void setBiotechInd(boolean biotechInd) {
        this.biotechInd = biotechInd;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getDataLoadError() {
        return dataLoadError;
    }

    public void setDataLoadError(String dataLoadError) {
        this.dataLoadError = dataLoadError;
    }

    public String getSafetyGroupCode() {
        return safetyGroupCode;
    }

    public void setSafetyGroupCode(String safetyGroupCode) {
        this.safetyGroupCode = safetyGroupCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public Long getOrgUnitId() {
        return orgUnitId;
    }

    public void setOrgUnitId(Long orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getOrgUnitCode() {
        return orgUnitCode;
    }

    public void setOrgUnitCode(String orgUnitCode) {
        this.orgUnitCode = orgUnitCode;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }
}