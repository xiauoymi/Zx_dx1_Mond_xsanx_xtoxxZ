/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
@Entity
@Table(schema = "BBS", name = "WORK_AREA")
public class WorkArea implements Serializable {

   @Id
   @SequenceGenerator(name = "bbsSeq", sequenceName = "BBS.BBS_SEQ")
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bbsSeq")
   private Long id;

   @Column(name = "DESCRIPTION")
   private String description;

   @Column(name = "PLANT_CODE")
   private String plantCode;


   public WorkArea() {
   }

   public WorkArea(final String plantCode, final String description) {
      this.plantCode = plantCode;
      this.description = description;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public Long getWorkAreaId() {
      return id;
   }

   public void setPlantCode(final String plantCode) {
      this.plantCode = plantCode;
   }

   public String getPlantCode() {
      return plantCode;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(final String description) {
      this.description = description;
   }
}