package com.monsanto.eas.bbs.model;

import com.monsanto.eas.bbs.hibernate.*;

import java.util.Date;
import java.util.List;

import static ch.lambdaj.Lambda.extract;
import static ch.lambdaj.Lambda.on;

public class ReportCriteria {
    private String dateFormat;
    private Date dateFrom;
    private Date dateTo;
    private String reportDateFrom;
    private String reportDateTo;
    private Language language;
    private LanguageBasedResponse languageBasedResponse;
    private BBSUser user;

    private List<LanguageCategoryType> languageCategoryTypeList;
    private List<Plant> plantList;
    private List<Country> countryList;
    private List<Region> regionList;

    private boolean searchByCountryCriteria;
    private boolean searchByRegionCriteria;
    private boolean searchBySiteCriteria;

    public static final String SEARCH_CRITERIA_REGION = "region";
    public static final String SEARCH_CRITERIA_COUNTRY = "country";
    public static final String SEARCH_CRITERIA_PLANT = "plant";

    public BBSUser getUser() {
        return user;
    }

    public void setUser(BBSUser user) {
        this.user = user;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public List<LanguageCategoryType> getLanguageCategoryTypeList() {
        return languageCategoryTypeList;
    }

    public void setLanguageCategoryTypeList(List<LanguageCategoryType> languageCategoryTypeList) {
        this.languageCategoryTypeList = languageCategoryTypeList;
    }

    public LanguageBasedResponse getLanguageBasedResponse() {
        return languageBasedResponse;
    }

    public void setLanguageBasedResponse(LanguageBasedResponse languageBasedResponse) {
        this.languageBasedResponse = languageBasedResponse;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getReportDateFrom() {
        return reportDateFrom;
    }

    public void setReportDateFrom(String reportDateFrom) {
        this.reportDateFrom = reportDateFrom;
    }

    public String getReportDateTo() {
        return reportDateTo;
    }

    public void setReportDateTo(String reportDateTo) {
        this.reportDateTo = reportDateTo;
    }

    public List<Plant> getPlantList() {
        return plantList;
    }

    public void setPlantList(List<Plant> plantList) {
        this.plantList = plantList;
    }

    public List<Country> getCountryList() {
        return countryList;
    }

    public void setCountryList(List<Country> countryList) {
        this.countryList = countryList;
    }

    public List<Region> getRegionList() {
        return regionList;
    }

    public void setRegionList(List<Region> regionList) {
        this.regionList = regionList;
    }

    public boolean isSearchByCountryCriteria() {
        return searchByCountryCriteria;
    }

    public void setSearchByCountryCriteria(boolean searchByCountryCriteria) {
        this.searchByCountryCriteria = searchByCountryCriteria;
    }

    public boolean isSearchByRegionCriteria() {
        return searchByRegionCriteria;
    }

    public void setSearchByRegionCriteria(boolean searchByRegionCriteria) {
        this.searchByRegionCriteria = searchByRegionCriteria;
    }

    public boolean isSearchBySiteCriteria() {
        return searchBySiteCriteria;
    }

    public void setSearchBySiteCriteria(boolean searchBySiteCriteria) {
        this.searchBySiteCriteria = searchBySiteCriteria;
    }

    public String getSearchCriteriaDescription() {
        StringBuffer searchCriteriaDescription = new StringBuffer();

        if (this.isSearchBySiteCriteria()) {
            for (int i = 0; i < this.getPlantList().size(); i++) {
                searchCriteriaDescription.append(this.getPlantList().get(i).getPlantName1());

                if (i != (this.getPlantList().size() - 1)) {
                    searchCriteriaDescription.append(", ");
                }
            }
        } else if (this.isSearchByCountryCriteria()) {
            for (int i = 0; i < this.getCountryList().size(); i++) {
                searchCriteriaDescription.append(this.getCountryList().get(i).getDescription());
                if (i != (this.getCountryList().size() - 1)) {
                    searchCriteriaDescription.append(", ");
                }
            }
        } else if (this.isSearchByRegionCriteria()) {
            for (int i = 0; i < this.getRegionList().size(); i++) {
                searchCriteriaDescription.append(this.getRegionList().get(i).getDescription());
                if (i != (this.getRegionList().size() - 1)) {
                    searchCriteriaDescription.append(", ");
                }
            }
        }

        return searchCriteriaDescription.toString();
    }

    public String getSelectedPlantCodes() {
        StringBuffer selectedPlantCodes = new StringBuffer();

        if (null != this.getPlantList() && this.getPlantList().size() > 0) {
            for (int i = 0; i < this.getPlantList().size(); i++) {
                selectedPlantCodes.append(this.getPlantList().get(i).getPlantCode());

                if (i != (this.getPlantList().size() - 1)) {
                    selectedPlantCodes.append(", ");
                }
            }
        }
        return selectedPlantCodes.toString();
    }

    public String getSelectedRegionIds() {
        StringBuffer selectedRegionsIds = new StringBuffer();

        if (null != this.getRegionList() && this.getRegionList().size() > 0) {
            for (int i = 0; i < this.getRegionList().size(); i++) {
                selectedRegionsIds.append(this.getRegionList().get(i).getId());

                if (i != (this.getRegionList().size() - 1)) {
                    selectedRegionsIds.append(", ");
                }
            }
        }
        return selectedRegionsIds.toString();
    }

    public String getSelectedCountryIds() {
        StringBuffer selectedCountryids = new StringBuffer();

        if (null != this.getCountryList() && this.getCountryList().size() > 0) {
            for (int i = 0; i < this.getCountryList().size(); i++) {

                selectedCountryids.append(this.getCountryList().get(i).getId());

                if (i != (this.getCountryList().size() - 1)) {
                    selectedCountryids.append(", ");
                }
            }
        }
        return selectedCountryids.toString();
    }

    public String getSelectedPlantIds() {
        StringBuffer selectedPlantIds = new StringBuffer();

        if (null != this.getPlantList() && this.getPlantList().size() > 0) {
            for (int i = 0; i < this.getPlantList().size(); i++) {
                selectedPlantIds.append(this.getPlantList().get(i).getId());

                if (i != (this.getPlantList().size() - 1)) {
                    selectedPlantIds.append(", ");
                }
            }
        }
        return selectedPlantIds.toString();
    }

    public String getSearchCriteriaDescriptionHeader() {
        if (this.isSearchBySiteCriteria()) {
            return SEARCH_CRITERIA_PLANT;
        } else if (this.isSearchByCountryCriteria()) {
            return SEARCH_CRITERIA_COUNTRY;
        } else if (this.isSearchByRegionCriteria()) {
            return SEARCH_CRITERIA_REGION;
        }

        return SEARCH_CRITERIA_PLANT;
    }

    public List<Long> getCategoryTypeIds() {
        return extract(languageCategoryTypeList, on(LanguageCategoryType.class).getId().getCategoryType().getId());
    }

}
