package com.monsanto.eas.bbs.model;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.Plant;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: 9/7/11
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class SiteRptCriteria {
  private Plant plant;
  private Language language;
  private BBSUser user;

  public SiteRptCriteria() {
  }

  public SiteRptCriteria(Language language, Plant plant) {
    this.language = language;
    this.plant = plant;
  }

  public BBSUser getUser() {
    return user;
  }

  public void setUser(BBSUser user) {
    this.user = user;
  }

  public Plant getPlant() {
    return plant;
  }

  public void setPlant(Plant plant) {
    this.plant = plant;
  }

  public Language getLanguage() {
    return language;
  }

  public void setLanguage(Language language) {
    this.language = language;
  }

}
