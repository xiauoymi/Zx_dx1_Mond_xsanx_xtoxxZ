package com.monsanto.eas.bbs.model.report;

@ReportTitle("BBS Administrators")
public class AdminUser extends User
{
    private static final int FIFTH = 5;

    private String role;

    public AdminUser(String firstName, String lastName, String userId, String site, String role) {
        super(firstName, lastName, userId, site);
        this.role = role;
    }

    @ReportProperty(header = "Role", order = FIFTH, key = "selectRole")
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}
