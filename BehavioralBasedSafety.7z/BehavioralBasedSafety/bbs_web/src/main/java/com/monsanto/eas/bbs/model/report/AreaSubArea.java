package com.monsanto.eas.bbs.model.report;

public class AreaSubArea
{
    private Object id;
    private String areaName;
    private String subAreaName;
    private String language;

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getSubAreaName() {
        return subAreaName;
    }

    public void setSubAreaName(String subAreaName) {
        this.subAreaName = subAreaName;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAreaSubAreaName() {
        return areaName + subAreaName;
    }

}
