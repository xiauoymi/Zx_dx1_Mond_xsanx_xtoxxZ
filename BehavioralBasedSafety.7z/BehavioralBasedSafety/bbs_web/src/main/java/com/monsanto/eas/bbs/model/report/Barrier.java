package com.monsanto.eas.bbs.model.report;

@ReportTitle("Barriers")
public class Barrier
{
    private static final int FIRST = 1;
    private static final int SECOND = 2;
    private static final int THIRD = 3;
    private static final int FOURTH = 4;

    private String barrier;
    private String category;
    private String subcategory;
    private String status;

    @ReportProperty(header = "Barrier", order = FIRST)
    public String getBarrier() {
        return barrier;
    }

    public void setBarrier(String barrier) {
        this.barrier = barrier;
    }

    @ReportProperty(header = "Category", order = SECOND)
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @ReportProperty(header = "Sub-Category", order = THIRD)
    public String getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }

    @ReportProperty(header = "Status", order = FOURTH)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
