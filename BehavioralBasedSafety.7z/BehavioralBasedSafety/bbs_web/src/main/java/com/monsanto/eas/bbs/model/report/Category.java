package com.monsanto.eas.bbs.model.report;

@ReportTitle("Categories")
public class Category
{
    private static final int FIRST = 1;
    private static final int SECOND = 2;
    private static final int THIRD = 3;
    private static final int FOURTH = 4;
    private static final int FIFTH = 5;

    private String categoryType;
    private String category;
    private String subCategory;
    private String detail;
    private String status;

    public Category() {
    }

    public Category(String categoryType, String category, String subCategory, String detail, String status) {
        this.categoryType = categoryType;
        this.category = category;
        this.subCategory = subCategory;
        this.detail = detail;
        this.status = status;
    }

    @ReportProperty(header = "Category Type", order = FIRST, key = "categoryType")
    public String getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(String categoryType) {
        this.categoryType = categoryType;
    }

    @ReportProperty(header = "Category", order = SECOND, key = "category")
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @ReportProperty(header = "Sub Category", order = THIRD, key = "subCategory")
    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    @ReportProperty(header = "Detail", order = FOURTH, key = "detail")
    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @ReportProperty(header = "Status", order = FIFTH, key = "status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
