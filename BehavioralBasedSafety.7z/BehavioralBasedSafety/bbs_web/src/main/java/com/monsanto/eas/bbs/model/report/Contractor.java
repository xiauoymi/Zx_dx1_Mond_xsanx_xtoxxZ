package com.monsanto.eas.bbs.model.report;

@ReportTitle("Contractors")
public class Contractor extends User
{
    private static final int FIFTH = 5;
    private static final int SIXTH = 6;

    private String company;
    private String status;

    public Contractor() {
        super();
    }

    public Contractor(String firstName, String lastName, String userId, String site, String company, String status) {
        super(firstName, lastName, userId, site);
        this.company = company;
        this.status = status;
    }

    @ReportProperty(header = "Company", order = FIFTH, key = "company")
    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @ReportProperty(header = "Status", order = SIXTH, key = "status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
