package com.monsanto.eas.bbs.model.report;

@ReportTitle("Contractor Companies")
public class ContractorCompany
{
    private String company;

    public ContractorCompany() {
    }

    public ContractorCompany(String company) {
        this.company = company;
    }

    @ReportProperty(header = "Company", order = 1, key = "company")
    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
