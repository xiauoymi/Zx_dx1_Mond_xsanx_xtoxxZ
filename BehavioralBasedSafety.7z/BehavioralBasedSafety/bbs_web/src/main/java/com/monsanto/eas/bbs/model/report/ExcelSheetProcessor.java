package com.monsanto.eas.bbs.model.report;

import org.apache.poi.hssf.usermodel.HSSFSheet;

public interface ExcelSheetProcessor
{
    void processSheet(HSSFSheet sheet);
}
