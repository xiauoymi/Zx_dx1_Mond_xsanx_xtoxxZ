package com.monsanto.eas.bbs.model.report;

@ReportTitle("Work Areas and Locations")
public class LanguagesForAreaSubArea implements Comparable<LanguagesForAreaSubArea>
{
    private static final int FIRST = 1;
    private static final int SECOND = 2;
    private static final int THIRD = 3;
    private static final int FOURTH = 4;
    private static final int FIFTH = 5;
    private static final int SIXTH = 6;
    private static final int SEVENTH = 7;
    private static final int EIGHTH = 8;
    private static final int NINTH = 9;
    private static final int TENTH = 10;
    private static final int ELEVENTH = 11;
    private static final int TWELVETH = 12;
    private static final int THIRTEENTH = 13;
    private static final int FOURTEENTH = 14;
    private AreaSubArea english;
    private AreaSubArea french;
    private AreaSubArea spanish;
    private AreaSubArea dutch;
    private AreaSubArea portuguese;
    private AreaSubArea turkish;
    private AreaSubArea italian;
    private AreaSubArea german;
    private AreaSubArea hungarian;

    public AreaSubArea getEnglish() {
        return english;
    }

    public void setEnglish(AreaSubArea english) {
        this.english = english;
    }

    public AreaSubArea getFrench() {
        return french;
    }

    public void setFrench(AreaSubArea french) {
        this.french = french;
    }

    public AreaSubArea getSpanish() {
        return spanish;
    }

    public void setSpanish(AreaSubArea spanish) {
        this.spanish = spanish;
    }

    public AreaSubArea getDutch() {
        return dutch;
    }

    public void setDutch(AreaSubArea dutch) {
        this.dutch = dutch;
    }

    public AreaSubArea getPortuguese() {
        return portuguese;
    }

    public void setPortuguese(AreaSubArea portuguese) {
        this.portuguese = portuguese;
    }

    public AreaSubArea getTurkish() {
        return turkish;
    }

    public void setTurkish(AreaSubArea turkish) {
        this.turkish = turkish;
    }

    public AreaSubArea getItalian() {
        return italian;
    }

    public void setItalian(AreaSubArea italian) {
        this.italian = italian;
    }

    public AreaSubArea getGerman() {
        return german;
    }

    public void setGerman(AreaSubArea german) {
        this.german = german;
    }

    public AreaSubArea getHungarian() {
        return hungarian;
    }

    public void setHungarian(AreaSubArea hungarian) {
        this.hungarian = hungarian;
    }

    @ReportProperty(header = "Work Area", order = FIRST)
    public String getEnglishAreaName() {
        return english.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = SECOND)
    public String getEnglishSubAreaName() {
        return english.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = THIRD)
    public String getFrenchAreaName() {
        return french.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = FOURTH)
    public String getFrenchSubAreaName() {
        return french.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = FIFTH)
    public String getSpanishAreaName() {
        return spanish.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = SIXTH)
    public String getSpanishSubAreaName() {
        return spanish.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = SEVENTH)
    public String getDutchAreaName() {
        return dutch.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = EIGHTH)
    public String getDutchSubAreaName() {
        return dutch.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = NINTH)
    public String getPortugueseAreaName() {
        return portuguese.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = TENTH)
    public String getPortugueseSubAreaName() {
        return portuguese.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = ELEVENTH)
    public String getTurkishAreaName() {
        return turkish.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = TWELVETH)
    public String getTurkishSubAreaName() {
        return turkish.getSubAreaName();
    }

    @ReportProperty(header = "Work Area", order = THIRTEENTH)
    public String getItalianAreaName() {
        return italian.getAreaName();
    }

    @ReportProperty(header = "Work Location", order = FOURTEENTH)
    public String getItalianSubAreaName() {
        return italian.getSubAreaName();
    }

    @Override
    public int compareTo(LanguagesForAreaSubArea o) {
        return english.getAreaSubAreaName().compareTo(o.english.getAreaSubAreaName());
    }
}
