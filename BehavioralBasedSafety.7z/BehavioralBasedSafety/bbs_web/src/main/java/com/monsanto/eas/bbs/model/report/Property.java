package com.monsanto.eas.bbs.model.report;

import com.google.common.base.Throwables;
import org.apache.log4j.Logger;

import java.lang.reflect.Method;

public class Property implements Comparable<Property>
{
    private static final Logger LOG = Logger.getLogger(Property.class);

    private String name;
    private String key;
    private String header;
    private Integer order;
    private Method method;

    public Property() {
    }

    public Property(ReportProperty property, Method method) {
        this.name = getPropertyName(method);
        this.key = property.key();
        this.header = property.header();
        this.order = property.order();
        this.method = method;
    }

    private String getPropertyName(Method method) {
        String propertyName = method.getName();
        final int beginIndex = 3;
        final int endIndex = 4;
        return propertyName.substring(beginIndex, endIndex).toLowerCase() + propertyName.substring(endIndex);
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String valueFor(Object item) {
        String stringValue = null;
        try {
            final Object value = method.invoke(item);
            stringValue = (value != null ? value.toString() : "");
        }
        catch (Exception e) {
            LOG.error(e.getMessage(), e);
            Throwables.propagate(e);
        }
        return stringValue;
    }

    @Override
    public int compareTo(Property spec) {
        return order.compareTo(spec.order);
    }

}
