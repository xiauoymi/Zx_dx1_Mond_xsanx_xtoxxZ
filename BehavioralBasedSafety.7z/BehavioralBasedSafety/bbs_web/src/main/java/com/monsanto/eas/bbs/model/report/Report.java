package com.monsanto.eas.bbs.model.report;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

public class Report
{
    private String title;
    private List<Property> properties;
    private List items;
    private int headerRowIndex = 0;

    public Report() {
    }

    public Report(List items) {
        this.items = items;
        initTitleAndProperties();
    }

    private void initTitleAndProperties() {
        if (items != null && !items.isEmpty()) {
            Object item = items.get(0);
            if (item != null) {
                initTitle(item);
                initProperties(item);
            }
        }
    }

    private void initTitle(Object item) {
        ReportTitle reportTitle = item.getClass().getAnnotation(ReportTitle.class);
        if (reportTitle != null) {
            this.title = reportTitle.value();
        }
    }

    private void initProperties(Object item) {
        properties = newArrayList();
        for (Method method : item.getClass().getMethods()) {
            ReportProperty property = method.getAnnotation(ReportProperty.class);
            if (property != null) {
                properties.add(new Property(property, method));
            }
        }
        Collections.sort(properties);
    }

    public void setItems(List<Object> items) {
        this.items = items;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
    }

    public List<Property> getProperties() {
        return properties;
    }

    public List<Object> getItems() {
        return items;
    }

    public int getPropertyCount() {
        return properties.size();
    }

    public int getItemCount() {
        return items == null ? 0 : items.size();
    }

    public boolean isEmpty() {
        return items == null || items.isEmpty();
    }

    public int getHeaderRowIndex() {
        return headerRowIndex;
    }

    public Report setHeaderRowIndex(int headerRowIndex) {
        this.headerRowIndex = headerRowIndex;
        return this;
    }
}
