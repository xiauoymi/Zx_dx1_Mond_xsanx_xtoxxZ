package com.monsanto.eas.bbs.model.report;

@ReportTitle("Tasks")
public class Task
{
    private String task;

    public Task() {
    }

    public Task(String task) {
        this.task = task;
    }

    @ReportProperty(header = "Task", order = 1, key = "task")
    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }
}
