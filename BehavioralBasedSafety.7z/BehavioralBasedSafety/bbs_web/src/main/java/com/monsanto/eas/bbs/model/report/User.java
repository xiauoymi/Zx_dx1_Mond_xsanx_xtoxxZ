package com.monsanto.eas.bbs.model.report;

public abstract class User
{
    private static final int FIRST = 1;
    private static final int SECOND = 2;
    private static final int THIRD = 3;
    private static final int FOURTH = 4;

    private String lastName;
    private String firstName;
    private String userId;
    private String site;

    public User() {
    }

    public User(String firstName, String lastName, String userId, String site) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userId = userId;
        this.site = site;
    }

    @ReportProperty(header = "Last Name", order = FIRST, key = "lastname")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @ReportProperty(header = "First Name", order = SECOND, key = "firstname")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @ReportProperty(header = "User ID", order = THIRD, key = "uid")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @ReportProperty(header = "Site", order = FOURTH, key = "plant")
    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
}
