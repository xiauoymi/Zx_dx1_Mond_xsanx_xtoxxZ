/*
 AdminService was created on Feb 15, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dataimport.PlantAreaTO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.LanguageBarrierCategory;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.hibernate.LanguageBasedCategory;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public interface AdminService {

  void addPlantAreas(List<PlantAreaTO> plantAreas);

  Map<String, String> saveLanguageBarriers(List<LanguageBarrierCategory> languageBarriers);

  Map<String,String> saveLanguageBasedAreas(List<LanguageBasedArea> languageBasedAreas);

  Map<String, String> saveLanguageBasedCategories(List<LanguageBasedCategory> languageBasedCategories);

  List<String> saveUsers(List<BBSUser> bbsUsers);
}