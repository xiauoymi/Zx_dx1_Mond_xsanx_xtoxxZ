package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.AreaDAO;
import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dataimport.PlantAreaTO;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.categorykeys.CategoryKeys;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.*;

import static java.lang.String.format;

@Service
@RemotingDestination(value = "adminService")
public class AdminServiceImpl implements AdminService {
    private static final Logger LOG = Logger.getLogger(AdminServiceImpl.class);
    @Autowired
    private AreaDAO areaDao;
    @Autowired
    private LanguageBasedAreaDAO languageBasedAreaDao;
    @Autowired
    private CategoryDAO categoryDao;
    @Autowired
    private LanguageDAO languageDao;
    @Autowired
    private UserService userService;


    public AdminServiceImpl() {
    }

    public AdminServiceImpl(AreaDAO areaDAO, CategoryDAO categoryDAO, LanguageDAO languageDAO,
                            UserService userService, LanguageBasedAreaDAO languageBasedAreaDao) {
        this.areaDao = areaDAO;
        this.categoryDao = categoryDAO;
        this.languageDao = languageDAO;
        this.userService = userService;
        this.languageBasedAreaDao = languageBasedAreaDao;
    }

    @RemotingInclude
    public List<String> saveUsers(List<BBSUser> bbsUsers) {
        List<String> errors = new ArrayList<String>();
        for (BBSUser user : bbsUsers) {
            try {
                userService.saveOrUpdate(user);
            }
            catch (Exception e) {
                final String errorMsg = format(
                    "An error occurred when saving '%s' user: %s - %s",
                    user.getUserId(), e.getClass().getName(), e.getMessage()
                );
                LOG.error(errorMsg, e);
                errors.add(errorMsg);
            }
        }
        return errors;
    }

    @RemotingInclude
    public Map<String, String> saveLanguageBasedCategories(List<LanguageBasedCategory> languageBasedCategories) {
        Map<String, String> errors = new HashMap<String, String>();
        for (LanguageBasedCategory languageBasedCategory : languageBasedCategories) {
            final LanguageBasedCategory lbCategory = getExisitingCategoryByDescription(languageBasedCategory);

            if (lbCategory == null ||
                    lbCategory.getId().getCategory().getId().equals(languageBasedCategory.getId().getCategory().getId())) {

                boolean isNewCategory = languageBasedCategory.getId().getCategory().isNew();
                categoryDao.saveLanguageBasedCategory(languageBasedCategory);
                inactivateChildCategoriesIfCategoryIsInactive(languageBasedCategory);

                if (isNewCategory) {
                    final Collection<LanguageBasedCategory> categories = getTranslatedLanguageBasedCategories(languageBasedCategory);
                    for (LanguageBasedCategory lbc : categories) {
                        categoryDao.saveLanguageBasedCategory(lbc);
                    }
                }
            }
            else {
                final Category category = languageBasedCategory.getId().getCategory();
                errors.put(
                    CategoryKeys.getValue(true, category.isNew(), true, category.hasParent(), category.hasGrandParent()),
                    getErrorMessageForCategory(lbCategory)
                );
            }
        }
        return errors;
    }

    private String getErrorMessageForCategory(LanguageBasedCategory languageBasedCategory) {
        Category category = languageBasedCategory.getId().getCategory();
        return getResourceBundleForCurrentLocale().getString(CategoryKeys.getValue(
                false, category.isNew(), category.isActive(), category.hasParent(), category.hasGrandParent()
            )
        ) + " - " + languageBasedCategory.getDescription();
    }

    private ResourceBundle getResourceBundleForCurrentLocale() {
        return ResourceBundle.getBundle("messages", LocaleContextHolder.getLocale());
    }

    @RemotingInclude
    public Map<String, String> saveLanguageBasedAreas(List<LanguageBasedArea> languageBasedAreas) {
        Map<String, String> errors = new HashMap<String, String>();

        for (LanguageBasedArea languageBasedArea : languageBasedAreas) {
            final LanguageBasedArea lbArea = getExisitingAreaByDescription(languageBasedArea);
            if (lbArea == null || lbArea.getId().getArea().getId().equals(languageBasedArea.getId().getArea().getId())) {
                boolean isNewArea = languageBasedArea.getId().getArea().getId() == null;
                languageBasedAreaDao.saveLanguageBasedArea(languageBasedArea);
                inactivateSubAreasIfAreaIsInactive(languageBasedArea);
                if (isNewArea) {
                    final Collection<LanguageBasedArea> areas = getTranslatedLanguageBasedAreas(languageBasedArea);
                    for (LanguageBasedArea lba : areas) {
                        languageBasedAreaDao.saveLanguageBasedArea(lba);
                    }
                }
            } else {
                ResourceBundle rb = getResourceBundleForCurrentLocale();
                boolean isArea = lbArea.getId().getArea().getParentArea() == null;
                String error = lbArea.getId().getArea().isActive() ?
                        isArea ? rb.getString("activeAreaExists") : rb.getString("activeSubAreaExists")
                        : isArea ? rb.getString("inactiveAreaExists") : rb.getString("inactiveSubAreaExists");
                error += " - " + languageBasedArea.getDescription();

                errors.put(
                        languageBasedArea.getId().getArea().getId() == null ?
                                languageBasedArea.getId().getArea().getParentArea() == null ? "newArea" : "newSubArea"
                                : languageBasedArea.getId().getArea().getParentArea() == null ? "area" : "subArea",
                        error);
            }
        }
        return errors;
    }

    @RemotingInclude
    public Map<String, String> saveLanguageBarriers(List<LanguageBarrierCategory> languageBarriers) {
        Map<String, String> errors = new HashMap<String, String>();
        for (LanguageBarrierCategory languageBarrierCategory : languageBarriers) {
            LanguageBarrierCategory existingBarrier = getExisitingBarrierByDescription(languageBarrierCategory);
            if (existingBarrier == null || existingBarrier.getId().getBarrierCategory().getId()
                    .equals(languageBarrierCategory.getId().getBarrierCategory().getId())) {
                boolean isNewBarrier = languageBarrierCategory.getId().getBarrierCategory().getId() == null;
                categoryDao.saveLanguageBarrierCategory(languageBarrierCategory);
                if (isNewBarrier) {
                    final Collection<LanguageBarrierCategory> languageBarrierCategories = getTranslatedLanguageBarrierCategories(
                            languageBarrierCategory);
                    for (LanguageBarrierCategory lbc : languageBarrierCategories) {
                        categoryDao.saveLanguageBarrierCategory(lbc);
                    }
                }
            } else {
                ResourceBundle rb = getResourceBundleForCurrentLocale();
                String error = existingBarrier.getId().getBarrierCategory().isActive() ?
                        rb.getString("activeBarrierExits") : rb.getString("inactiveBarrierExits");
                error += " - " + languageBarrierCategory.getDescription();

                errors.put(languageBarrierCategory.getId().getBarrierCategory().getId() == null ? "newBarrier" : "barrier",
                        error);
            }
        }
        return errors;
    }

    @RemotingInclude
    public void addPlantAreas(List<PlantAreaTO> plantAreas) {
        for (PlantAreaTO plantAreaTO : plantAreas) {
            Area area = plantAreaTO.getArea();
            boolean isNewArea = area.getId() == null;
            areaDao.addPlantArea(plantAreaTO.getPlant(), area);
            if (isNewArea) {
                LanguageBasedArea lba = new LanguageBasedArea();
                lba.setDescription(plantAreaTO.getAreaDescription());
                LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
                pk.setArea(area);
                pk.setLanguage(plantAreaTO.getLanguage());
                lba.setId(pk);
                saveLanguageBasedArea(lba, isNewArea);
            }
        }
    }

    @RemotingInclude
    public void deletePlantAreas(List<PlantAreaTO> plantAreas) {
        for (PlantAreaTO plantAreaTO : plantAreas) {
            areaDao.deletePlantArea(plantAreaTO.getPlant(), plantAreaTO.getArea());
            List<Area> subAreas = areaDao.lookupSubAreas(plantAreaTO.getArea());
            for (Area subArea : subAreas) {
                areaDao.deletePlantArea(plantAreaTO.getPlant(), subArea);
            }
        }
    }

    private void saveLanguageBasedArea(LanguageBasedArea languageBasedArea, boolean newArea) {
        languageBasedAreaDao.saveLanguageBasedArea(languageBasedArea);
        if (newArea) {
            final Collection<LanguageBasedArea> languageBasedAreas = getTranslatedLanguageBasedAreas(languageBasedArea);
            for (LanguageBasedArea lba : languageBasedAreas) {
                languageBasedAreaDao.saveLanguageBasedArea(lba);
            }
        }
    }

    private LanguageBarrierCategory getExisitingBarrierByDescription(LanguageBarrierCategory languageBarrier) {
        return categoryDao
                .lookupLanguageBarrierByDescriptionAndCategory(languageBarrier.getDescription(),
                        languageBarrier.getId().getLanguage(), languageBarrier.getId().getBarrierCategory().getCategory());
    }

    private LanguageBasedArea getExisitingAreaByDescription(LanguageBasedArea languageBasedArea) {
        LanguageBasedArea area;
        if (languageBasedArea.getId().getArea().getParentArea() == null) {
            area = languageBasedAreaDao
                    .lookupLanguageBasedArea(languageBasedArea.getDescription(), languageBasedArea.getId().getLanguage());
        } else {
            area = languageBasedAreaDao
                    .lookupLanguageBasedSubArea(languageBasedArea.getDescription(),
                            languageBasedArea.getId().getArea().getParentArea(),
                            languageBasedArea.getId().getLanguage());
        }
        return area;
    }

    private LanguageBasedCategory getExisitingCategoryByDescription(LanguageBasedCategory languageBasedCategory) {
        LanguageBasedCategory category;
        if (languageBasedCategory.getId().getCategory().getParentCategory() == null) {
            category = categoryDao
                    .lookupLanguageBasedCategoryByDescriptionAndType(languageBasedCategory.getDescription(),
                            languageBasedCategory.getId().getLanguage(),
                            languageBasedCategory.getId().getCategory().getCategoryType());
        } else {
            category = categoryDao
                    .lookupLanguageBasedSubCategoryByDescriptionAndType(languageBasedCategory.getDescription(),
                            languageBasedCategory.getId().getCategory().getParentCategory(),
                            languageBasedCategory.getId().getLanguage(),
                            languageBasedCategory.getId().getCategory().getCategoryType());
        }
        return category;
    }

    private void inactivateChildCategoriesIfCategoryIsInactive(LanguageBasedCategory languageBasedCategory) {
        if (!languageBasedCategory.getId().getCategory().isActive()) {

            final List<Category> subCategories = categoryDao.lookupSubCategoriesForCategory(languageBasedCategory.getId().getCategory());

            for (Category subCategory : subCategories) {
                subCategory.setActive(false);
                categoryDao.saveOrUpdateCategory(subCategory);

                final List<Category> subSubCategories = categoryDao.lookupSubCategoriesForCategory(subCategory);
                for (Category subSubCategory : subSubCategories) {
                    subSubCategory.setActive(false);
                    categoryDao.saveOrUpdateCategory(subSubCategory);
                }
            }
        }
    }

    private void inactivateSubAreasIfAreaIsInactive(LanguageBasedArea languageBasedArea) {
        if (!languageBasedArea.getId().getArea().isActive()) {
            final List<Area> subAreas = areaDao.lookupSubAreas(languageBasedArea.getId().getArea());
            for (Area subArea : subAreas) {
                subArea.setActive(false);
                areaDao.saveOrUpdateArea(subArea);
            }
        }
    }

    private Collection<LanguageBasedCategory> getTranslatedLanguageBasedCategories(LanguageBasedCategory
                                                                                           languageBasedCategory) {
        Collection<LanguageBasedCategory> languageBasedCategories = new ArrayList<LanguageBasedCategory>();
        final List<Language> languages = languageDao.findAll();
        for (Language lang : languages) {
            if (!languageBasedCategory.getId().getLanguage().equals(lang)) {
//        String translatedValue1 = translationService
//            .translate(languageBasedCategory.getDescription(), languageBasedCategory.getId().getLanguage(),
//                lang);
                LanguageBasedCategory lbc = new LanguageBasedCategory();
                lbc.setDescription(languageBasedCategory.getDescription());
                LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
                pk.setCategory(languageBasedCategory.getId().getCategory());
                pk.setLanguage(lang);
                lbc.setId(pk);
                languageBasedCategories.add(lbc);
            }
        }
        return languageBasedCategories;
    }

    private Collection<LanguageBarrierCategory> getTranslatedLanguageBarrierCategories
            (
                    LanguageBarrierCategory
                            languageBarrierCategory) {
        Collection<LanguageBarrierCategory> languageBarrierCategories = new ArrayList<LanguageBarrierCategory>();
        final List<Language> languages = languageDao.findAll();
        for (Language lang : languages) {
            if (!languageBarrierCategory.getId().getLanguage().equals(lang)) {
//        String translatedValue1 = translationService
//            .translate(languageBarrierCategory.getDescription(), languageBarrierCategory.getId().getLanguage(),
//                lang);
                LanguageBarrierCategory lbc = new LanguageBarrierCategory();
                lbc.setDescription(languageBarrierCategory.getDescription());
                LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();
                pk.setBarrierCategory(languageBarrierCategory.getId().getBarrierCategory());
                pk.setLanguage(lang);
                lbc.setId(pk);
                languageBarrierCategories.add(lbc);
            }
        }
        return languageBarrierCategories;
    }

    private Collection<LanguageBasedArea> getTranslatedLanguageBasedAreas
            (
                    LanguageBasedArea
                            languageBasedArea) {
        Collection<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
        final List<Language> languages = languageDao.findAll();
        for (Language lang : languages) {
            if (!languageBasedArea.getId().getLanguage().equals(lang)) {
//        String translatedValue1 = translationService
//            .translate(languageBasedArea.getDescription(), languageBasedArea.getId().getLanguage(),
//                lang);
                LanguageBasedArea lba = new LanguageBasedArea();
                lba.setDescription(languageBasedArea.getDescription());
                LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
                pk.setArea(languageBasedArea.getId().getArea());
                pk.setLanguage(lang);
                lba.setId(pk);
                languageBasedAreas.add(lba);
            }
        }
        return languageBasedAreas;
    }
}