package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.model.report.LanguagesForAreaSubArea;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.List;

public interface AreaService
{
    @RemotingInclude
    List<Language> lookupPlantLanguageAndAreas(Plant plant);

    @RemotingInclude
    List<Language> lookupLanguageAndAreas();

    @RemotingInclude
    List<LanguagesForAreaSubArea> getWorkAreasAndWorkLocations(Plant plant);
}