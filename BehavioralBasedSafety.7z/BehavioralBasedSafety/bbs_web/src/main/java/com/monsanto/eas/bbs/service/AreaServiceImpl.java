package com.monsanto.eas.bbs.service;

import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.report.AreaSubArea;
import com.monsanto.eas.bbs.model.report.LanguagesForAreaSubArea;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
@RemotingDestination(value = "areaService")
public class AreaServiceImpl implements AreaService {

    private static final Logger LOG = Logger.getLogger(AreaServiceImpl.class);

    @Autowired
    private LanguageBasedAreaDAO languageBasedAreaDAO;

    @Autowired
    private LanguageDAO languageDao;

    public AreaServiceImpl() {
    }

    public AreaServiceImpl(LanguageBasedAreaDAO languageBasedAreaDAO, LanguageDAO languageDao) {
        this.languageBasedAreaDAO = languageBasedAreaDAO;
        this.languageDao = languageDao;
    }


    @RemotingInclude
    public void addArea(Area area, String description, Language language) {
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription(description);
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        lba.setId(pk);
        pk.setArea(area);
        pk.setLanguage(language);
        languageBasedAreaDAO.addLanguageBasedArea(lba);
    }


    @RemotingInclude
    public List<Language> lookupLanguageAndAreas() {
        List<Language> languages = languageDao.findAll();
        for (Language language : languages) {
            List<LanguageBasedArea> parentAreas = languageBasedAreaDAO.lookupAllParentAreasByLanguage(language);
            for (LanguageBasedArea parentArea : parentAreas) {
                parentArea.getId().getArea().setLanguageBasedSubAreas(languageBasedAreaDAO.lookupAllSubAreasByAreaAndLanguage(parentArea.getId().getArea(), language));
            }
            language.setLanguageBasedParentAreas(parentAreas);
        }
        return languages;
    }

    @Override
    @RemotingInclude
    public List<Language> lookupPlantLanguageAndAreas(Plant plant) {
        List<Language> languages = languageDao.findAll();
        for (Language language : languages) {
            List<LanguageBasedArea> parentAreas = languageBasedAreaDAO.lookupLanguageBasedAreas(plant, language, true);
            for (LanguageBasedArea parentArea : parentAreas) {
                parentArea.getId().getArea().setLanguageBasedSubAreas(languageBasedAreaDAO.lookupSubAreasForAnArea(parentArea.getId().getArea(), plant, language, true));
            }
            language.setLanguageBasedParentAreas(parentAreas);
        }
        return languages;
    }

    @Override
    @RemotingInclude
    public List<LanguagesForAreaSubArea> getWorkAreasAndWorkLocations(Plant plant) {
        final List<Language> languages = plant != null ? lookupPlantLanguageAndAreas(plant) : lookupLanguageAndAreas();
        Map<Object, List<AreaSubArea>> subAreaMap = Maps.newHashMap();
        for (Language language : languages) {
            for (LanguageBasedArea languageBasedArea : language.getLanguageBasedParentAreas()) {
                for (LanguageBasedArea languageBasedSubArea : languageBasedArea.getId().getArea().getLanguageBasedSubAreas()) {
                    AreaSubArea areaSubArea = new AreaSubArea();
                    areaSubArea.setId(languageBasedSubArea.getId().getArea().getId());
                    areaSubArea.setAreaName(languageBasedArea.getDescription());
                    areaSubArea.setSubAreaName(languageBasedSubArea.getDescription());
                    areaSubArea.setLanguage(language.getDescription().toLowerCase());

                    List<AreaSubArea> subAreasByLanguage = subAreaMap.get(areaSubArea.getId());
                    if (subAreasByLanguage == null) {
                        subAreasByLanguage = Lists.newArrayList();
                    }
                    subAreasByLanguage.add(areaSubArea);
                    subAreaMap.put(areaSubArea.getId(), subAreasByLanguage);
                }
            }
        }

        List<LanguagesForAreaSubArea> languagesForAreaSubAreas = Lists.newArrayList();
        for (Object areaSubAreaId : subAreaMap.keySet()) {
            LanguagesForAreaSubArea languagesForAreaSubArea = new LanguagesForAreaSubArea();
            for (AreaSubArea areaSubArea : subAreaMap.get(areaSubAreaId)) {
                try {
                    PropertyUtils.setProperty(languagesForAreaSubArea, areaSubArea.getLanguage(), areaSubArea);
                }
                catch (Exception e) {
                    LOG.error(e.getMessage(), e);
                    Throwables.propagate(e);
                }
            }
            languagesForAreaSubAreas.add(languagesForAreaSubArea);
        }
        Collections.sort(languagesForAreaSubAreas);
        return languagesForAreaSubAreas;
    }

}