package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 22/06/12
 * Time: 12:00 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BiotechService {

    List<BiotechProgram> lookupBiotechProgramsForPlant(Plant plant);

    List<BiotechProjectPlatform> lookupBiotechProjectsForProgram(BiotechProgram biotechProgram);
}
