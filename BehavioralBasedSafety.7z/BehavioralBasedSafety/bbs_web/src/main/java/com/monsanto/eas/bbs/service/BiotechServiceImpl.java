package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.BiotechDAO;
import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 22/06/12
 * Time: 12:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "biotechService")
public class BiotechServiceImpl implements BiotechService{

    @Autowired
    private BiotechDAO biotechDAO;

    public BiotechServiceImpl(){}

    public BiotechServiceImpl(BiotechDAO biotechDAO){
        this.biotechDAO = biotechDAO;
    }

    @RemotingInclude
    public List<BiotechProgram> lookupBiotechProgramsForPlant(Plant plant) {
        return biotechDAO.lookupBiotechProgramsForPlant(plant);
    }

    @RemotingInclude
    public List<BiotechProjectPlatform> lookupBiotechProjectsForProgram(BiotechProgram biotechProgram) {
        return biotechDAO.lookupBiotechProjectsForProgram(biotechProgram);
    }
}
