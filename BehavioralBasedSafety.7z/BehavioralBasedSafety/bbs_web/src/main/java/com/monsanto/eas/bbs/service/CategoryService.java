/*
 CategoryService was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface CategoryService {
   List<LanguageBasedCategory> lookupSubcategoriesForACategory(Language language, Category category, boolean onlyActiveCategories);

   List<LanguageBasedCategory> lookupSubcategoriesForACategory(Language language, Category category);

   List<Observation> lookupAllObservationForSubSubCategory(Category subSubCategory);

   List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType, boolean onlyActiveCategories);

   List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType);

   List<LanguageCategoryType> lookupLanguageCategoryTypes(Language language);

   void addLanguageBarrierCat(Language language, Map<String, String> langBasedBarrierCatDictionary);

   void addLanguageBasedCategory(Language language, Map<String, String> langBasedCategoryDictionary);

   void addLanguageBasedCategoryType(Language language, Map<String,String> langBasedCategoryTypeDictionary);
}