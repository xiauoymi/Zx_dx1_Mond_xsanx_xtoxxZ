/*
 CategoryServiceImpl was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dao.ObservationDAO;
import com.monsanto.eas.bbs.hibernate.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@Service
@RemotingDestination(value = "categoryService")
public class CategoryServiceImpl implements CategoryService {

   @Autowired
   private CategoryDAO categoryDAO;
   @Autowired
   private ObservationDAO observationDAO;
   @Autowired
   private LanguageDAO languageDAO;

   private static Logger logger = Logger.getLogger(CategoryServiceImpl.class);

   public CategoryServiceImpl() {
   }

   public CategoryServiceImpl(CategoryDAO catDao, ObservationDAO observationDao) {
      this.categoryDAO = catDao;
      this.observationDAO = observationDao;
   }

   public CategoryServiceImpl(CategoryDAO catDao, LanguageDAO languageDAO) {
      this.categoryDAO = catDao;
      this.languageDAO = languageDAO;
   }

   @RemotingInclude
   public List<LanguageCategoryType> lookupLanguageCategoryTypes(Language language) {
      return categoryDAO.lookupLanguageCategoryTypes(language);
   }

   @RemotingInclude
   public List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType, boolean onlyActiveCategories) {
      return categoryDAO.lookupLanguageBasedCategoriesByType(language, categoryType, onlyActiveCategories);
   }

   @RemotingInclude
   public List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType) {
      boolean onlyActiveCategories = true;
      return categoryDAO.lookupLanguageBasedCategoriesByType(language, categoryType, onlyActiveCategories);
   }

   @RemotingInclude
   public List<LanguageBasedCategory> lookupSubcategoriesForACategory(Language language, Category category, boolean onlyActiveCategories) {
      return categoryDAO.lookupAllSubCategoriesForACategory(language, category, onlyActiveCategories);
   }

   @RemotingInclude
   public List<LanguageBasedCategory> lookupSubcategoriesForACategory(Language language, Category category) {
      boolean onlyActiveCategories = true;
      return categoryDAO.lookupAllSubCategoriesForACategory(language, category, onlyActiveCategories);
   }

   public List<Observation> lookupAllObservationForSubSubCategory(Category subSubCategory) {
      return observationDAO.lookupAllObservationForSubSubCategory(subSubCategory);
   }

   public void addLanguageBarrierCat(Language language, Map<String, String> langBasedBarrierCatDictionary) {
      List<LanguageBarrierCategory> list = categoryDAO.lookupLanguageBarriers();
      String langBasedCatBarrierDesc = null;

      logger.info("Adding language barrier cats.");

      for (LanguageBarrierCategory cat : list) {

         if(cat.getDescription() == null || (null != cat.getDescription() && cat.getDescription().trim().equals("")) ){
            continue;
         }

         LanguageBarrierCategoryPK primaryKey = new LanguageBarrierCategoryPK();
         primaryKey.setBarrierCategory(cat.getId().getBarrierCategory());
         primaryKey.setLanguage(language);

         langBasedCatBarrierDesc = langBasedBarrierCatDictionary.get( cat.getDescription().trim() );

         LanguageBarrierCategory obj = new LanguageBarrierCategory();
         obj.setId(primaryKey);
         obj.setDescription( null != langBasedCatBarrierDesc && !langBasedCatBarrierDesc.equals("") ? langBasedCatBarrierDesc : cat.getDescription().trim() );

         try{
            categoryDAO.saveLanguageBarrierCategory(obj);
         }
         catch (Exception e) {
            logger.error( e.getCause() , e);
         }
      }
   }

   public void addLanguageBasedCategory(Language language, Map<String, String> langBasedCategoryDictionary) {
      List<LanguageBasedCategory> list = categoryDAO.lookupAllLanguageCategories();
      String langBasedCategoryDesc = null;

      logger.info("Adding language categories.");

      for (LanguageBasedCategory cat : list) {

         if(cat.getDescription() == null || (null != cat.getDescription() && cat.getDescription().trim().equals("")) ){
            continue;
         }

         LanguageBasedCategoryPK primaryKey = new LanguageBasedCategoryPK();
         primaryKey.setCategory(cat.getId().getCategory());
         primaryKey.setLanguage(language);

         langBasedCategoryDesc = langBasedCategoryDictionary.get( cat.getDescription().trim() );

         LanguageBasedCategory obj = new LanguageBasedCategory();
         obj.setId(primaryKey);
         obj.setDescription( null != langBasedCategoryDesc && !langBasedCategoryDesc.equals("") ? langBasedCategoryDesc : cat.getDescription().trim() );

         try{
            categoryDAO.saveLanguageBasedCategory(obj);
         }
         catch (Exception e) {
            logger.error( e.getCause(), e );
         }
      }
   }

   public void addLanguageBasedCategoryType(Language language, Map<String, String> langBasedCategoryTypeDictionary) {
      List<LanguageCategoryType> list = categoryDAO.lookupLanguageCategoryTypes(languageDAO.lookupLanguageByLocale("en"));
      String langBasedCategoryTypeDesc = null;

      logger.info("Adding language category types.");

      for (LanguageCategoryType cat : list) {

         if(cat.getDescription() == null || (null != cat.getDescription() && cat.getDescription().trim().equals("")) ){
            continue;
         }

         LanguageCategoryTypePK primaryKey = new LanguageCategoryTypePK();
         primaryKey.setCategoryType(cat.getId().getCategoryType());
         primaryKey.setLanguage(language);

         langBasedCategoryTypeDesc = langBasedCategoryTypeDictionary.get( cat.getDescription().trim() );

         LanguageCategoryType obj = new LanguageCategoryType();
         obj.setId(primaryKey);
         obj.setDescription( null != langBasedCategoryTypeDesc && ! langBasedCategoryTypeDesc.equals("") ? langBasedCategoryTypeDesc : cat.getDescription().trim() );

         try{
            categoryDAO.saveOrUpdateLanguageCategoryType(obj);
         }
         catch (Exception e) {
            logger.error( e.getCause(), e );
         }
      }
   }


}