package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Region;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 2/08/12
 * Time: 03:40 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CountryService {

   List<Country> lookupActiveCountriesWithValidRegionID();

   List<Country> lookupActiveCountriesByRegionID(Long[] regionId);

   List<Country> lookupActiveCountriesByRegionIDAndByUserRole(String regionId, BBSUser loggedInUser);

   void activateInactivateEnvironmentalTabByRegion(Region region, boolean activeFlag);

   void activateInactivateEnvironmentalTabByCountry(Country country, boolean activeFlag);
}
