package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.CountryDAO;
import com.monsanto.eas.bbs.dao.RegionDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Region;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 2/08/12
 * Time: 03:44 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "countryService")
public class CountryServiceImpl implements CountryService {

   @Autowired
   private CountryDAO countryDAO;

   @Autowired
   private RegionDAO regionDAO;

   @RemotingInclude
   public List<Country> lookupActiveCountriesWithValidRegionID() {
      return countryDAO.lookupActiveCountriesWithValidRegionID();
   }

   @RemotingInclude
   public List<Country> lookupActiveCountriesByRegionID(Long[] regionId) {
      return countryDAO.lookupActiveCountriesByRegionID(regionId);
   }

   @RemotingInclude
   public List<Country> lookupActiveCountriesByRegionIDAndByUserRole(String selectedRegionIds, BBSUser loggedInUser) {
      String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(loggedInUser);
      return countryDAO.lookupActiveCountriesByRegionIDAndByUserRole(selectedRegionIds, loggedInUser, userOwnsRegionDesc);
   }

   @RemotingInclude
   public void activateInactivateEnvironmentalTabByRegion(Region region, boolean activeFlag) {
      countryDAO.activateInactivateEnvironmentalTabByRegion(region, activeFlag);
   }

   @RemotingInclude
   public void activateInactivateEnvironmentalTabByCountry(Country country, boolean activeFlag) {
      countryDAO.activateInactivateEnvironmentalTabByCountry(country, activeFlag);
   }
}
