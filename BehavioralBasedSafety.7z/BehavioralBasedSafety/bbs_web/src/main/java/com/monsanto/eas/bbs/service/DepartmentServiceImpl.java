/*
 DepartmentServiceImpl was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.DepartmentDAO;
import com.monsanto.eas.bbs.hibernate.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "departmentService")
public class DepartmentServiceImpl implements DepartmentService {
  @Autowired
  private DepartmentDAO departmentDAO;

  public DepartmentServiceImpl() {
  }

  public DepartmentServiceImpl(DepartmentDAO departmentDAO) {
    this.departmentDAO = departmentDAO;
  }

  @RemotingInclude
  public List<Department> lookupAllCompanies(boolean active) {
    return departmentDAO.lookupDepartmentsByCompanyFlag(true, active);
  }
}