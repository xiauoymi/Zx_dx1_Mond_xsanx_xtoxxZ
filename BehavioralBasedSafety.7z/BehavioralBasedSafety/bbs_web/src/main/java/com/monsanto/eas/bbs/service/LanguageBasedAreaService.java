package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 12/16/13
 * Time: 11:33 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LanguageBasedAreaService {

    void addLanguageBasedAreas(String locale);

    void addLanguageBasedAreas(Language language, Map<String, String> langBasedDescriptionDictionary);

    List<LanguageBasedArea> lookupSubAreasForAnArea(Area area, Plant plant, Language language);

    @RemotingInclude
    List<LanguageBasedArea> lookupAvailableSubAreasForPlant(Area area, Plant plant, Language language);

    @RemotingInclude
    List<LanguageBasedArea> lookupLanguageBasedAreas(Language language);

    @RemotingInclude
    List<LanguageBasedArea> lookupInactiveLanguageBasedAreas(Language language);

    @RemotingInclude
    List<LanguageBasedArea> lookupInactiveSubAreasForAnArea(Area area, Plant plant, Language language);

    @RemotingInclude
    List<LanguageBasedArea> lookupLanguageBasedAreasWithInactiveSubAreas(Language language);

}
