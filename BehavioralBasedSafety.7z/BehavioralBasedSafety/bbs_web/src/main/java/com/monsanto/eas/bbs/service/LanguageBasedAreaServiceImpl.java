package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 12/16/13
 * Time: 11:36 AM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "languageBasedAreaService")
public class LanguageBasedAreaServiceImpl implements LanguageBasedAreaService {

    private static final String ADDING_AREAS_MSG = "Adding language based areas.";
    private static final String ALREADY_ADDED = "Already been added: ";
    @Autowired
    private LanguageBasedAreaDAO languageBasedAreaDAO;

    @Autowired
    private LanguageDAO languageDao;

    private static Logger logger = Logger.getLogger(LanguageBasedAreaServiceImpl.class);

    public LanguageBasedAreaServiceImpl() {
    }

    public LanguageBasedAreaServiceImpl(LanguageBasedAreaDAO languageBasedAreaDAO, LanguageDAO languageDao) {
        this.languageBasedAreaDAO = languageBasedAreaDAO;
        this.languageDao = languageDao;
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupLanguageBasedAreas(Language language) {
        return languageBasedAreaDAO.lookupLanguageBasedAreas(null, language, true);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupLanguageBasedAreasWithInactiveSubAreas(Language language) {
        return languageBasedAreaDAO.lookupLanguageBasedAreasWithInactiveSubAreas(language);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupInactiveLanguageBasedAreas(Language language) {
        return languageBasedAreaDAO.lookupLanguageBasedAreas(null, language, false);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupSubAreasForAnArea(Area area, Plant plant, Language language) {
        return languageBasedAreaDAO.lookupSubAreasForAnArea(area, plant, language, true);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupInactiveSubAreasForAnArea(Area area, Plant plant, Language language) {
        return languageBasedAreaDAO.lookupSubAreasForAnArea(area, plant, language, false);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupAvailableSubAreasForPlant(Area area, Plant plant, Language language) {
        return languageBasedAreaDAO.lookupAvailableSubAreasForPlant(area, plant, language);
    }

    public void addLanguageBasedAreas(String locale) {
        final List<LanguageBasedArea> list = languageBasedAreaDAO.lookupAllAreas();
        Language language = languageDao.lookupLanguageByLocale(locale);

        logger.info(ADDING_AREAS_MSG);

        for (LanguageBasedArea area : list) {
            LanguageBasedAreaPK primaryKey = new LanguageBasedAreaPK();
            primaryKey.setArea(area.getId().getArea());
            primaryKey.setLanguage(language);
            LanguageBasedArea obj = new LanguageBasedArea();
            obj.setId(primaryKey);
            obj.setDescription(area.getDescription());

            try {
                languageBasedAreaDAO.addLanguageBasedArea(obj);
            }
            catch (DataIntegrityViolationException e) {
                logger.error(ALREADY_ADDED + obj.getId().getLanguage().getId() + " (" + obj.getId().getLanguage().getLocale() + "), '" + obj.getDescription() + "'.", e);
            }
        }
    }

    public void addLanguageBasedAreas(Language language, Map<String, String> langBasedDescriptionDictionary) {
        final List<LanguageBasedArea> list = languageBasedAreaDAO.lookupAllAreas();
        String langBasedDesc = null;

        logger.info(ADDING_AREAS_MSG);

        for (LanguageBasedArea area : list) {

            if (area.getDescription() == null || (null != area.getDescription() && area.getDescription().trim().equals(""))) {
                continue;
            }

            LanguageBasedAreaPK primaryKey = new LanguageBasedAreaPK();
            primaryKey.setArea(area.getId().getArea());
            primaryKey.setLanguage(language);

            LanguageBasedArea obj = new LanguageBasedArea();
            obj.setId(primaryKey);

            langBasedDesc = langBasedDescriptionDictionary.get(area.getDescription().trim());

            obj.setDescription(null != langBasedDesc && !langBasedDesc.equals("") ? langBasedDesc : area.getDescription().trim());

            try {
                languageBasedAreaDAO.addLanguageBasedArea(obj);
            }
            catch (DataIntegrityViolationException e) {
                logger.error(ALREADY_ADDED + obj.getId().getLanguage().getId() + " (" + obj.getId().getLanguage().getLocale() + "), '" + obj.getDescription() + "'.", e);
            }
        }
    }

}
