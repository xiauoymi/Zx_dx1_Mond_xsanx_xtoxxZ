/*
 LanguageService was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public interface LanguageService {
   List<Language> lookupAllLanguages();

   List<LanguageBasedResponse> lookupResponsesForALanguage(Language language);

   List<LanguageBarrierCategory> lookupActiveBarriersForALanguageAndSubCategory(Language language, Category category);

   List<LanguageBarrierCategory> lookupInactiveBarriersForALanguageAndSubCategory(Language language, Category category);

   List<LanguageBarrierCategory> lookupActiveAndInactiveBarriersForALanguageAndSubCategory(Language lang, Category category);

   Language lookupLanguageByLocale(String locale);

   List<LanguageBasedPersonnelType> lookupPersonnelTypesForALanguage(Language language);

   List<LanguageBasedLanguageDescription> lookupLanguagesForALanguage(Language language);

   void insertLanguage(String description, Boolean active, String locale);
   void addLanguageDescription(Language language, Map<String, String> langBasedCategoryDictionary);
   void addLanguageResponse(Language language, Map<String, String> langBasedCategoryDictionary);
}