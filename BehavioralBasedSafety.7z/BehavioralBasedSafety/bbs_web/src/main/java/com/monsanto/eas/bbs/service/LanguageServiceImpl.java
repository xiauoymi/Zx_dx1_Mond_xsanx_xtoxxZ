/*
 LanguageServiceImpl was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.comparator.ResponseDisplayOrderComparator;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "languageService")
public class LanguageServiceImpl implements LanguageService
{
    @Autowired
    private LanguageDAO languageDao;

    private static Logger logger = Logger.getLogger(LanguageServiceImpl.class);


    public LanguageServiceImpl() {
    }

    public LanguageServiceImpl(LanguageDAO languageDao) {
        this.languageDao = languageDao;
    }

    @RemotingInclude
    public List<Language> lookupAllLanguages() {
        return this.languageDao.findAll();
    }

    @RemotingInclude
    public Language lookupLanguageByLocale(String locale) {
        Language language = this.languageDao.lookupLanguageByLocale(locale);
        if (language == null) {
            language = this.languageDao.lookupLanguageByLocale("en");
        }
        return language;
    }

    @RemotingInclude
    public List<LanguageBasedLanguageDescription> lookupLanguagesForALanguage(Language language) {
        return languageDao.lookupLanguagesForALanguage(language);
    }

    @RemotingInclude
    public List<LanguageBasedResponse> lookupResponsesForALanguage(Language language) {
        List<LanguageBasedResponse> languageBasedResponses = this.languageDao.lookupResponsesForALanguage(language);
        Collections.sort(languageBasedResponses, new ResponseDisplayOrderComparator());
        return languageBasedResponses;
    }

    @RemotingInclude
    public List<LanguageBasedPersonnelType> lookupPersonnelTypesForALanguage(Language language) {
        return this.languageDao.lookupPersonnelTypesForALanguage(language);
    }

    @RemotingInclude
    public List<LanguageBarrierCategory> lookupActiveBarriersForALanguageAndSubCategory(Language language, Category category) {
        return this.languageDao.lookupActiveBarriersForALanguageAndSubCategory(language, category);
    }

    @RemotingInclude
    public List<LanguageBarrierCategory> lookupInactiveBarriersForALanguageAndSubCategory(Language language, Category category) {
        return this.languageDao.lookupInactiveBarriersForALanguageAndSubCategory(language, category);
    }

    @RemotingInclude
    public List<LanguageBarrierCategory> lookupActiveAndInactiveBarriersForALanguageAndSubCategory(Language lang, Category category) {
        return this.languageDao.lookupActiveAndInactiveBarriersForALanguageAndSubCategory(lang, category);
    }

    public void insertLanguage(String description, Boolean active, String locale) {
        Language obj = new Language();
        obj.setActive(active);
        obj.setDescription(description);
        obj.setLocale(locale);
        Language language = languageDao.lookupLanguageByLocale(locale);
        if (language == null) {
            languageDao.addLanguage(obj);
        }
    }

    public void addLanguageDescription(Language language, Map<String, String> langBasedCategoryDictionary) {
        List<Language> list = languageDao.findAll();
        String langBasedCategoryDesc = null;

        logger.info("Adding language based language.");

        for (Language lang : list) {

            if (lang.getDescription() == null || (null != lang.getDescription() && lang.getDescription().trim().equals(""))) {
                continue;
            }

            LanguageBasedLanguageDescriptionPK primaryKey = new LanguageBasedLanguageDescriptionPK();
            primaryKey.setLanguageDescription(language);
            primaryKey.setLanguage(lang);

            langBasedCategoryDesc = langBasedCategoryDictionary.get(lang.getDescription().trim());

            LanguageBasedLanguageDescription obj = new LanguageBasedLanguageDescription();
            obj.setId(primaryKey);
            obj.setDescription(null != langBasedCategoryDesc && !langBasedCategoryDesc.equals("") ? langBasedCategoryDesc : lang.getDescription().trim());

            try {
                languageDao.saveOrUpdateLanguageBasedLanguage(obj);
            } catch (Exception e) {
                logger.error(e.getCause(), e);
            }
        }
    }

    public void addLanguageResponse(Language language, Map<String, String> langBasedCategoryDictionary) {
        final List<LanguageBasedResponse> list = languageDao.lookupResponsesForALanguage(languageDao.lookupLanguageByLocale("en"));
        String langBasedLanguageResponse = null;

        logger.info("Adding language based responses.");

        for (LanguageBasedResponse response : list) {

            if (response.getDescription() == null || (null != response.getDescription() && response.getDescription().trim().equals(""))) {
                continue;
            }

            LanguageBasedResponsePK primaryKey = new LanguageBasedResponsePK();
            primaryKey.setResponse(response.getId().getResponse());
            primaryKey.setLanguage(language);

            langBasedLanguageResponse = langBasedCategoryDictionary.get(response.getDescription().trim());

            LanguageBasedResponse obj = new LanguageBasedResponse();
            obj.setId(primaryKey);
            obj.setDescription(null != langBasedLanguageResponse && !langBasedLanguageResponse.equals("") ? langBasedLanguageResponse : response.getDescription().trim());

            try {
                languageDao.saveOrUpdateLanguageBasedResponse(obj);
            } catch (Exception e) {
                logger.error(e.getCause(), e);
            }
        }

    }
}