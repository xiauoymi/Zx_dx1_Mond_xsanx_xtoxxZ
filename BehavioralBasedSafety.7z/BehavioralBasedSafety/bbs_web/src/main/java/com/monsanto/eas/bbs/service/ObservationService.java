/*
 ObservationService was created on Jan 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface ObservationService {
    void addObservation(Observation observation);

    void updateObservation(Observation observation);

    Observation lookupObservation(Long id);

    List<Observation> lookupObservations(ReportCriteria reportCriteria);

    @RemotingInclude
    void inactivateObservation(Observation observation);
}