/*
 ObservationServiceImpl was created on Jan 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.CategoryObservationDAO;
import com.monsanto.eas.bbs.dao.ObservationDAO;
import com.monsanto.eas.bbs.dao.TaskDAO;
import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.hibernate.Task;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.util.opendocument.ServiceRuntimeException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "observationService")
public class ObservationServiceImpl implements ObservationService {

   @Autowired
   private ObservationDAO observationDao;

   @Autowired
   private TaskDAO taskDAO;

   @Autowired
   private CategoryObservationDAO categoryObservationDAO;

   private Logger logger = Logger.getLogger(ObservationServiceImpl.class.getName());

   public ObservationServiceImpl() {
   }

   public ObservationServiceImpl(ObservationDAO observationDao) {
      this.observationDao = observationDao;
   }

   @RemotingInclude
   public Observation lookupObservation(Long id) {
      return this.observationDao.lookupObservation(id);
   }

   @RemotingInclude
   public List<Observation> lookupObservations(ReportCriteria reportCriteria) {
      return this.observationDao.lookupObservations(reportCriteria);
   }

   @RemotingInclude
   public void addObservation(Observation observation) {
      try{
         Task observationTask = addNewTask(observation.getTask());
         observation.setTask(observationTask);
         observationDao.addObservation(observation);
      }
      catch (Exception e){
         logger.error( "", e);
         throw new ServiceRuntimeException(e);
      }
   }

   @RemotingInclude
   public void updateObservation(Observation observation) {
      try{
         Task observationTask = addNewTask(observation.getTask());
         observation.setTask(observationTask);

         observationDao.updateObservation(observation);
         categoryObservationDAO.deleteCategoryObservationInNAStatus(observation.getCategoryObservations());
      }
      catch (Exception e){
         logger.error( "", e);
         throw new ServiceRuntimeException(e);
      }

   }

   private Task addNewTask(Task task){
      Task observationTask = null;
      //Check if the task already existed, otherwise add it
      if( task != null){
         if( task.getId() == 0 && !task.getDescription().equals("")) {

            observationTask = taskDAO.lookupTaskByDescription(task.getDescription());

            if(observationTask == null){
               observationTask = new Task();
               observationTask.setDescription(task.getDescription());
               taskDAO.addNewTask(observationTask);
            }

         } else if(task.getId() != 0) {
            observationTask = task;
         }
      }

      return observationTask;
   }

   @RemotingInclude
   public void inactivateObservation(Observation observation) {
      observationDao.inactivateObservation(observation);
   }

}