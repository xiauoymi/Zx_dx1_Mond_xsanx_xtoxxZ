package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.Language;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 01:52 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PersonnelTypeService {
   void addLanguagePersonnelType(Language language, Map<String, String> langBasedPersonnelTypeDictionary);
}
