package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.PersonnelTypeDAO;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelType;
import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelTypePK;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/11/12
 * Time: 01:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class PersonnelTypeServiceImpl implements PersonnelTypeService {

   @Autowired
   private PersonnelTypeDAO personnelDao;

   private static Logger logger = Logger.getLogger(PersonnelTypeServiceImpl.class);

   public PersonnelTypeServiceImpl(PersonnelTypeDAO personnelDao){
      this.personnelDao = personnelDao;
   }

   public void addLanguagePersonnelType(Language language, Map<String, String> langBasedPersonnelTypeDictionary) {
      final List<LanguageBasedPersonnelType> list = personnelDao.lookupLanguageBasedPersonnelTypesByLanguage();
      String langBasedPersonnelType = null;

      logger.info("Adding language based personnel types.");

      for (LanguageBasedPersonnelType type : list) {

         if(type.getDescription() == null || (null != type.getDescription() && type.getDescription().trim().equals("")) ){
            continue;
         }

         LanguageBasedPersonnelTypePK primaryKey = new LanguageBasedPersonnelTypePK();
         primaryKey.setPersonnelType(type.getId().getPersonnelType());
         primaryKey.setLanguage(language);

         langBasedPersonnelType = langBasedPersonnelTypeDictionary.get( type.getDescription().trim() );

         LanguageBasedPersonnelType obj = new LanguageBasedPersonnelType();
         obj.setId(primaryKey);
         obj.setDescription( null != langBasedPersonnelType && ! langBasedPersonnelType.equals("") ? langBasedPersonnelType : type.getDescription().trim());

         try{
            personnelDao.addLanguageBasedPersonnelType(obj);
         }
         catch (Exception e) {
            logger.error( e.getCause(), e );
         }
      }
   }

}
