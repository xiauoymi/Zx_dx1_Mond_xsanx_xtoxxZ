/*
 PlantService was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public interface PlantService {

   List<Plant> lookupAllPlants();

   List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea();

   List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser);

   List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId);

   //-- lookup All Plants Associated With Safety Group And WorkArea By CountryId & user's role
   List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String countryId, BBSUser loggedInUser);

   List<Plant> lookupAllPlantsAssociatedWithSafetyGroup();

   List<SafetyGroup> lookupSafetyGroupsForPlant(Plant plant);

   List<LanguageBasedArea> lookupAreasForPlant(Plant plant, Language language);

   List<LanguageBasedArea> lookupAvailableAreasForPlant(Plant plant, Language language);
}