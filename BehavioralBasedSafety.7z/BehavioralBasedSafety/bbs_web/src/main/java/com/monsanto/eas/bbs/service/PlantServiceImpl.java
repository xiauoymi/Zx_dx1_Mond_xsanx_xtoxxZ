/*
 PlantServiceImpl was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.RegionDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "plantService")
public class PlantServiceImpl implements PlantService {
    @Autowired
    private PlantDAO plantDAO;
    @Autowired
    private SafetyGroupDAO safetyGroupDAO;

    @Autowired
    private LanguageBasedAreaDAO languageBasedAreaDAO;

    @Autowired
    private RegionDAO regionDAO;

    public PlantServiceImpl() {
    }

    public PlantServiceImpl(PlantDAO plantDAO, SafetyGroupDAO safetyGroupDAO, LanguageBasedAreaDAO languageBasedAreaDAO) {
        this.plantDAO = plantDAO;
        this.safetyGroupDAO = safetyGroupDAO;
        this.languageBasedAreaDAO = languageBasedAreaDAO;
    }

    @RemotingInclude
    public List<SafetyGroup> lookupSafetyGroupsForPlant(Plant plant) {
        return safetyGroupDAO.lookupSafetyGroupsByPlant(plant);
    }

    @RemotingInclude
    public List<Plant> lookupAllPlants() {
        return plantDAO.lookupAllPlants();
    }

    @RemotingInclude
    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea() {
        return plantDAO.lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea();
    }

    @RemotingInclude
    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser) {
        return plantDAO.lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(loggedInUser, getUserOwnRegionDescription(loggedInUser));
    }

    @RemotingInclude
    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId) {
        return plantDAO.lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(countryId);
    }

    @RemotingInclude
    public List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String countryId, BBSUser loggedInUser) {
        return plantDAO.lookupAllValidPlantsByCountryIdAndByUserRole(countryId, loggedInUser, getUserOwnRegionDescription(loggedInUser));
    }

    public String getUserOwnRegionDescription(BBSUser loggedInUser) {
        return regionDAO.lookupRegionDescriptionByBBSUser(loggedInUser);
    }

    @RemotingInclude
    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroup() {
        return plantDAO.lookupAllPlantsAssociatedWithSafetyGroup();
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupAreasForPlant(Plant plant, Language language) {
        return languageBasedAreaDAO.lookupLanguageBasedAreas(plant, language, true);
    }

    @RemotingInclude
    public List<LanguageBasedArea> lookupAvailableAreasForPlant(Plant plant, Language language) {
        return languageBasedAreaDAO.lookupAvailableAreasForPlant(plant, language);
    }
}