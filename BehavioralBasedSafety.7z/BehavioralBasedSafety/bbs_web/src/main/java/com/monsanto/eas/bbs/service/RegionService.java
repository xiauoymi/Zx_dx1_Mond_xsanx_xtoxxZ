package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Region;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 2/08/12
 * Time: 03:54 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RegionService {

   List<Region> lookupAllRegions();

   List<Region> lookupAllRegionsByUserRole(BBSUser loggedInUser);
}
