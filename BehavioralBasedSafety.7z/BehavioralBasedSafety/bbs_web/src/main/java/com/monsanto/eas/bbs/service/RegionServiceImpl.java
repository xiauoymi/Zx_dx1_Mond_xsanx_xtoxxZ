package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.RegionDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Region;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 2/08/12
 * Time: 03:55 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "regionService")
public class RegionServiceImpl implements RegionService {

   @Autowired
   private RegionDAO regionDAO;

   @RemotingInclude
   public List<Region> lookupAllRegions() {
      return regionDAO.lookupAllRegions();
   }

   @RemotingInclude
   public List<Region> lookupAllRegionsByUserRole(BBSUser loggedInUser) {
      return regionDAO.lookupAllRegionsByUserRole(loggedInUser);
   }
}
