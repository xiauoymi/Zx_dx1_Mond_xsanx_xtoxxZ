package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.BBSRole;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 19, 2010
 * Time: 4:17:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RoleService {
  List<BBSRole> lookUpAllRoles();
}
