package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.RoleDAO;
import com.monsanto.eas.bbs.hibernate.BBSRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 19, 2010
 * Time: 4:17:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "roleService")
public class RoleServiceImpl implements RoleService {
  @Autowired
  private RoleDAO roleDAO;

  public RoleServiceImpl(RoleDAO roleDAO) {
    this.roleDAO = roleDAO;
  }

  public RoleServiceImpl() {
  }

  @RemotingInclude
  public List<BBSRole> lookUpAllRoles() {
    return roleDAO.lookUpAllRoles();  //To change body of implemented methods use File | Settings | File Templates.
  }
}
