package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.Task;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/05/13
 * Time: 04:50 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TaskService {

   List<Task> lookupAllTasks();
}
