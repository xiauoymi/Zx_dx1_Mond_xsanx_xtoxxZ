package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.TaskDAO;
import com.monsanto.eas.bbs.hibernate.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/05/13
 * Time: 04:57 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "taskService")
public class TaskServiceImpl implements TaskService {

   @Autowired
   private TaskDAO taskDAO;

   @RemotingInclude
   public List<Task> lookupAllTasks() {
      return taskDAO.lookupAllTasks();
   }

}
