/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * UserServices was created on Dec 18, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.service;


import com.monsanto.eas.bbs.hibernate.BBSUser;

import java.util.List;

/**
 * Filename:    $HeadURL$
 * Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$
 *          Last Change: $Author$     On: $Date$
 */
public interface UserService {

  void saveOrUpdate(BBSUser user);

  BBSUser findByUserID(String user);
  
  List<BBSUser> lookupUserByCriteria(String name);

  List<BBSUser> lookupAllUsers(boolean active);

  List<BBSUser> lookUpUsersWithRoles();
}
