/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * UserServicesImpl was created on Dec 18, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.RoleDAO;
import com.monsanto.eas.bbs.dao.UserDAO;
import com.monsanto.eas.bbs.hibernate.BBSRole;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Filename:    $HeadURL$ Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$ Last Change: $Author$     On: $Date$
 */
@Service
@RemotingDestination(value = "userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDAO userDao;

    @Autowired
    private RoleDAO roleDao;

    public UserServiceImpl() {
    }

    public UserServiceImpl(UserDAO userDao, RoleDAO roleDAO) {
        this.userDao = userDao;
        this.roleDao = roleDAO;
    }

    @RemotingInclude
    public void saveOrUpdate(BBSUser user) {
        BBSUser userRetrieved = this.userDao.findByUserId(user.getUserId());
        if (userRetrieved != null) {
            user.setId(userRetrieved.getId());
        }
        for (BBSRole role : user.getRoles()) {
            roleDao.saveOrUpdateRole(role);
        }
        this.userDao.addUser(user);
    }

    @RemotingInclude
    public BBSUser findByUserID(String user) {
        return userDao.findByUserId(user);
    }

    public List<BBSUser> lookupUserByCriteria(String name) {
        return this.userDao.lookupUserByCriteria(name);
    }

    @RemotingInclude
    public List<BBSUser> lookupAllUsers(boolean active) {
        return this.userDao.lookupAllUsers(active);
    }

    @RemotingInclude
    public List<BBSUser> lookUpUsersWithRoles() {
        return this.userDao.lookupUserWithRoles();  //To change body of implemented methods use File | Settings | File Templates.
    }

    @RemotingInclude
    public List<BBSUser> lookupAllContractors(boolean active) {
        return this.userDao.lookupAllContractors(active);
    }
}
