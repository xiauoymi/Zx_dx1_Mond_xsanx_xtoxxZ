package com.monsanto.eas.bbs.service.categorykeys;

public enum CategoryKey
{
    ACTIVE_DETAIL_CATEGORY_EXISTS    ( new CategoryKeyID ( false,   false,   true,   true,   true  ), "activeDetailCategoryExists"   ),
    ACTIVE_SUBCATEGORY_EXISTS        ( new CategoryKeyID ( false,   false,   true,   true,   false ), "activeSubCategoryExists"      ),
    ACTIVE_CATEGORY_EXISTS           ( new CategoryKeyID ( false,   false,   true,   false,  false ), "activeCategoryExists"         ),
    INACTIVE_DETAIL_CATEGORY_EXISTS  ( new CategoryKeyID ( false,   false,   false,  true,   true  ), "inactiveDetailCategoryExists" ),
    INACTIVE_SUBCATEGORY_EXISTS      ( new CategoryKeyID ( false,   false,   false,  true,   false ), "inactiveSubCategoryExists"    ),
    INACTIVE_CATEGORY_EXISTS         ( new CategoryKeyID ( false,   false,   false,  false,  false ), "inactiveCategoryExists"       ),
    NEW_SUB_SUBCATEGORY              ( new CategoryKeyID ( true,    true,    true,   true,   true  ), "newSubSubCategory"            ),
    NEW_SUBCATEGORY                  ( new CategoryKeyID ( true,    true,    true,   true,   false ), "newSubCategory"               ),
    NEW_CATEGORY                     ( new CategoryKeyID ( true,    true,    true,   false,  false ), "newCategory"                  ),
    SUB_SUBCATEGORY                  ( new CategoryKeyID ( true,    false,   true,   true,   true  ), "subSubCategory"               ),
    SUBCATEGORY                      ( new CategoryKeyID ( true,    false,   true,   true,   false ), "subCategory"                  ),
    CATEGORY                         ( new CategoryKeyID ( true,    false,   true,   false,  false ), "category"                     ),
    ;

    private final CategoryKeyID id;
    private final String value;

    private CategoryKey(CategoryKeyID id, String value) {
        this.id = id;
        this.value = value;
    }

    CategoryKeyID getId() {
        return id;
    }

    public String getValue() {
        return value;
    }
}
