package com.monsanto.eas.bbs.service.categorykeys;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

class CategoryKeyID
{
    private final boolean isErrorMessageKey;
    private final boolean categoryIsNew;
    private final boolean categoryIsActive;
    private final boolean categoryHasParent;
    private final boolean categoryHasGrandParent;

    CategoryKeyID(
        boolean isErrorMessageKey, boolean categoryIsNew, boolean categoryIsActive, boolean categoryHasParent, boolean categoryHasGrandParent
    ) {
        this.isErrorMessageKey = isErrorMessageKey;
        this.categoryIsNew = categoryIsNew;
        this.categoryIsActive = categoryIsActive;
        this.categoryHasParent = categoryHasParent;
        this.categoryHasGrandParent = categoryHasGrandParent;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        CategoryKeyID id = (CategoryKeyID) obj;
        return new EqualsBuilder()
            .append(isErrorMessageKey, id.isErrorMessageKey)
            .append(categoryIsNew, id.categoryIsNew)
            .append(categoryIsActive, id.categoryIsActive)
            .append(categoryHasParent, id.categoryHasParent)
            .append(categoryHasGrandParent, id.categoryHasGrandParent)
            .isEquals()
        ;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(isErrorMessageKey)
            .append(categoryIsNew)
            .append(categoryIsActive)
            .append(categoryHasParent)
            .append(categoryHasGrandParent)
            .toHashCode()
        ;
    }
}
