package com.monsanto.eas.bbs.service.categorykeys;

import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;

public final class CategoryKeys
{
    private CategoryKeys() {
    }

    private static final Map<CategoryKeyID, CategoryKey> KEY_MAP = initKeyMap();

    private static Map<CategoryKeyID, CategoryKey> initKeyMap() {
        Map<CategoryKeyID, CategoryKey> map = newHashMap();
        for (CategoryKey currentKey : CategoryKey.values()) {
            map.put(currentKey.getId(), currentKey);
        }
        return map;
    }

    public static String getValue(
        boolean isErrorMessageKey, boolean isNewCategory, boolean categoryIsActive, boolean categoryHasParent, boolean categoryHasGrandParent
    ){
        return KEY_MAP.get(new CategoryKeyID(isErrorMessageKey, isNewCategory, categoryIsActive, categoryHasParent, categoryHasGrandParent)).getValue();
    }
}
