package com.monsanto.eas.bbs.service.report;

import com.google.common.base.Function;
import com.monsanto.eas.bbs.model.report.Report;

import java.util.Collection;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

public abstract class AbstractReportFetcher implements ReportFetcher
{
    private Function<Object, Object> transformer;

    public AbstractReportFetcher() {
    }

    public AbstractReportFetcher(Function<Object, Object> transformer) {
        this.transformer = transformer;
    }

    protected static String nvl(String str) {
        return (str == null ? "" : str.trim());
    }

    private List<Object> createTargetItems(Collection sourceItems) {
        List<Object> targetItems = newArrayList();
        if (sourceItems != null) {
            for (Object sourceItem : sourceItems) {
                if (sourceItem != null) {
                    targetItems.add(transformer.apply(sourceItem));
                }
            }
        }
        return targetItems;
    }

    @Override
    public final Report lookupReport(String reportName, Object parameters) {
        if (transformer != null) {
            return new Report(createTargetItems(getSourceItems(parameters)));
        }
        return new Report(newArrayList(getSourceItems(parameters)));
    }

    protected abstract Collection getSourceItems(Object parameters);
}
