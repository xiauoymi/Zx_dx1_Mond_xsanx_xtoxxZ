package com.monsanto.eas.bbs.service.report;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import javax.sql.DataSource;
import java.util.Collection;
import java.util.Collections;

public abstract class AbstractSQLBasedReportFetcher extends AbstractReportFetcher
{
    private final DataSource dataSource;
    private final String sqlFilename;
    private final Class targetClass;

    public AbstractSQLBasedReportFetcher(DataSource dataSource, String sqlFilename, Class targetClass) {
        super();
        this.dataSource = dataSource;
        this.sqlFilename = sqlFilename;
        this.targetClass = targetClass;
    }

    @Override
    protected final Collection getSourceItems(Object parameters) {
        final SQLStatement sqlStatement = new SQLStatementReader().readSQLStatementsFromFile(getClass(), sqlFilename);
        if (sqlStatement != null) {
            return new SimpleJdbcTemplate(dataSource).query(sqlStatement.getSql(), new SQLOutParametersRowMapper(sqlStatement, targetClass));
        }
        return Collections.emptyList();
    }
}
