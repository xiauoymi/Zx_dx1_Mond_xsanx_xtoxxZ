package com.monsanto.eas.bbs.service.report;

import com.google.common.base.Function;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.model.report.AdminUser;
import com.monsanto.eas.bbs.service.UserService;

import java.util.Collection;

public class AdminUsersFetcher extends AbstractReportFetcher
{
    private final UserService userService;

    public AdminUsersFetcher(UserService userService) {
        super(new Function<Object, Object>()
        {
            @Override
            public Object apply(Object source) {
                BBSUser user = (BBSUser) source;
                return new AdminUser(
                    nvl(user.getFirstName()),
                    nvl(user.getLastName()),
                    nvl(user.getUserId()),
                    user.getPlant() != null ? nvl(user.getPlant().getPlantName1()) : "",
                    user.getRoles() != null && !user.getRoles().isEmpty() ? nvl(user.getRoles().iterator().next().getDescription()) : ""
                );
            }
        });
        this.userService = userService;
    }

    @Override
    protected Collection getSourceItems(Object parameters) {
        return userService.lookUpUsersWithRoles();
    }
}
