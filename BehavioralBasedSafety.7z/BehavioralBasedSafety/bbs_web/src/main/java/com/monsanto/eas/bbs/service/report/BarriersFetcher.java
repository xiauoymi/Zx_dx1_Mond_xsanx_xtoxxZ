package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Barrier;

import javax.sql.DataSource;

public class BarriersFetcher extends AbstractSQLBasedReportFetcher
{
    public BarriersFetcher(DataSource dataSource) {
        super(dataSource, "getListOfBarriers.sql", Barrier.class);
    }
}
