package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Category;

import javax.sql.DataSource;

public class CategoriesFetcher extends AbstractSQLBasedReportFetcher
{
    public CategoriesFetcher(DataSource dataSource) {
        super(dataSource, "getListOfCategories.sql", Category.class);
    }
}
