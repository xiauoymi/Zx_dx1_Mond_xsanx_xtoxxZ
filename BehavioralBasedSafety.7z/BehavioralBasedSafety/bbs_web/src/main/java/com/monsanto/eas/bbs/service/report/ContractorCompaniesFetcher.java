package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.ContractorCompany;

import javax.sql.DataSource;

public class ContractorCompaniesFetcher extends AbstractSQLBasedReportFetcher
{
    public ContractorCompaniesFetcher(DataSource dataSource) {
        super(dataSource, "getListOfContractorCompanies.sql", ContractorCompany.class);
    }
}
