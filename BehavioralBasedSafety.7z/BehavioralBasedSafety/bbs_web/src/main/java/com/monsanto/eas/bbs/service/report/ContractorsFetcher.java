package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Contractor;

import javax.sql.DataSource;

public class ContractorsFetcher extends AbstractSQLBasedReportFetcher
{
    public ContractorsFetcher(DataSource dataSource) {
        super(dataSource, "getListOfContractors.sql", Contractor.class);
    }
}
