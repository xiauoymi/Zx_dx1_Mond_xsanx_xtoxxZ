package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Report;

public interface ReportFetcher
{
    Report lookupReport(String reportName, Object parameters);
}
