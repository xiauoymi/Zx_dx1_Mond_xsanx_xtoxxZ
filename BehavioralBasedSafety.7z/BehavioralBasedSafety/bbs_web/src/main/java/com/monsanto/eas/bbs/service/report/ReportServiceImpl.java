package com.monsanto.eas.bbs.service.report;

import com.google.common.collect.Maps;
import com.monsanto.eas.bbs.model.report.Report;
import com.monsanto.eas.bbs.service.AreaService;
import com.monsanto.eas.bbs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.Map;

@Service
@RemotingDestination(value = "reportService")
public class ReportServiceImpl implements ReportService
{
    @Autowired private UserService userService;
    @Autowired private DataSource dataSource;
    @Autowired private AreaService areaService;

    private Map<String, ReportFetcher> fetchers;

    public ReportServiceImpl() {
    }

    public ReportServiceImpl(DataSource dataSource, UserService userService) {
        this.dataSource = dataSource;
        this.userService = userService;
    }

    private void initFetchers() {
        if (fetchers == null) {
            fetchers = Maps.newHashMap();
            fetchers.put("adminUsersReport", new AdminUsersFetcher(userService));
            fetchers.put("contractorsReport", new ContractorsFetcher(dataSource));
            fetchers.put("contractorCompaniesReport", new ContractorCompaniesFetcher(dataSource));
            fetchers.put("categoriesReport", new CategoriesFetcher(dataSource));
            fetchers.put("barriersReport", new BarriersFetcher(dataSource));
            fetchers.put("tasksReport", new TasksFetcher(dataSource));
            fetchers.put("workAreasAndWorkLocationsBySiteReport", new WorkAreasAndWorkLocationsBySiteFetcher(areaService));
            fetchers.put("workAreasAndWorkLocationsReport", new WorkAreasAndWorkLocationsFetcher(areaService));
        }
    }

    private ReportFetcher getFetcher(String reportName) {
        initFetchers();
        return fetchers.get(reportName);
    }

    @Override
    @RemotingInclude
    public Report lookupReport(String reportName, Object parameters) {
        return getFetcher(reportName).lookupReport(reportName, parameters);
    }
}
