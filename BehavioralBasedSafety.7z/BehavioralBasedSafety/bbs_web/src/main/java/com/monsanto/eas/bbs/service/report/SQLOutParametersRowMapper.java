package com.monsanto.eas.bbs.service.report;

import com.google.common.base.Throwables;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SQLOutParametersRowMapper implements ParameterizedRowMapper
{
    private static final Logger LOG = Logger.getLogger(SQLOutParametersRowMapper.class);

    private final Class targetClass;
    private final SQLStatement sqlStatement;

    public SQLOutParametersRowMapper(SQLStatement sqlStatement, Class targetClass) {
        this.sqlStatement = sqlStatement;
        this.targetClass = targetClass;
    }

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        Object bean = null;
        try {
            bean = targetClass.newInstance();
            int index = 0;
            for (SQLParameter parameter : sqlStatement.getParameters()) {
                if (parameter.isOut()) {
                    PropertyUtils.setProperty(bean, parameter.getName(), rs.getObject(++index));
                }
            }
        }
        catch (Exception e) {
            LOG.error("Error mapping row.", e);
            Throwables.propagate(e);
        }
        return bean;
    }
}
