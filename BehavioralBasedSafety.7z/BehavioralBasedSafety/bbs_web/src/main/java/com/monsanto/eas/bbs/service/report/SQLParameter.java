package com.monsanto.eas.bbs.service.report;

public class SQLParameter
{
    private final String inOut;
    private final String name;

    public SQLParameter(String inOut, String name) {
        this.inOut = inOut;
        this.name = name;
    }

    public boolean isIn() {
        return inOut.equals("IN");
    }

    public boolean isOut() {
        return inOut.equals("OUT");
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "SQLParameter {" +
            "inOut='" + inOut + '\'' +
            ", name='" + name + '\'' +
            '}';
    }
}
