package com.monsanto.eas.bbs.service.report;

import com.google.common.collect.Lists;

import java.util.List;

public class SQLStatement
{
    private String sql;
    private final List<SQLParameter> parameters = Lists.newArrayList();

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public List<SQLParameter> getParameters() {
        return parameters;
    }

    public void addParameter(SQLParameter parameter) {
        parameters.add(parameter);
    }
}
