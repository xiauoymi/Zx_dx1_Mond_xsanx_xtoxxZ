package com.monsanto.eas.bbs.service.report;

import com.google.common.base.Joiner;
import com.google.common.base.Throwables;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.google.common.collect.Lists.newArrayList;

public class SQLStatementReader
{
    private static final Logger LOG = Logger.getLogger(SQLStatementReader.class);

    private static class LineParser
    {
        private static final Pattern PARAMETER_PATTERN = Pattern.compile("/\\* *\\[(IN|OUT), *([A-Z|a-z]+)\\] *\\*/");
        private final String originalLine;
        private String strippedLine;
        private SQLParameter parameter;

        public LineParser(final String originalLine) {
            this.originalLine = originalLine;
            initSQLParameter();
        }

        private void initSQLParameter() {
            strippedLine = originalLine.trim();
            Matcher matcher = PARAMETER_PATTERN.matcher(strippedLine);
            if (matcher.find()) {
                parameter = new SQLParameter(matcher.group(1), matcher.group(2));
                strippedLine = strippedLine.substring(0, matcher.start());
            }
        }

        public LineParser addParameterToStatement(SQLStatement sqlStatement) {
            if (sqlStatement != null && parameter != null) {
                sqlStatement.addParameter(parameter);
            }
            return this;
        }

        public String getStrippedLine() {
            return strippedLine;
        }
    }

    public SQLStatement readSQLStatementsFromFile(Class relativeTo, String sqlFilename)
    {
        SQLStatement sqlStatement = null;
        try {
            final BufferedReader in = new BufferedReader(new InputStreamReader(relativeTo.getResourceAsStream(sqlFilename)));
            List<String> lines = newArrayList();
            String line;
            while ((line = in.readLine()) != null) {
                if (sqlStatement == null) {
                    sqlStatement = new SQLStatement();
                }
                line = new LineParser(line).addParameterToStatement(sqlStatement).getStrippedLine();
                lines.add(line);
                if (line.contains(";")) {
                    sqlStatement.setSql(normalizeSQL(lines));
                }
            }
            in.close();
        }
        catch (Exception e) {
            LOG.error(String.format("Error reading SQL file '%s'.", sqlFilename), e);
            Throwables.propagate(e);
        }
        return sqlStatement;
    }

    private String normalizeSQL(List<String> lines) {
        String sql = Joiner.on(" ").skipNulls().join(lines);
        String normalizedSql = sql.trim();
        if (!sql.equals("")) {
            normalizedSql = sql.replaceAll(";", "");
            while (normalizedSql.contains("  ")) {
                normalizedSql = normalizedSql.replaceAll("  ", " ");
            }
            normalizedSql = normalizedSql.trim();
        }
        return normalizedSql;
    }

}
