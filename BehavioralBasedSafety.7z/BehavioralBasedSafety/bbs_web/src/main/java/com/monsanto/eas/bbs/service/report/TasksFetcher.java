package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Task;

import javax.sql.DataSource;

public class TasksFetcher extends AbstractSQLBasedReportFetcher
{
    public TasksFetcher(DataSource dataSource) {
        super(dataSource, "getListOfTasks.sql", Task.class);
    }
}
