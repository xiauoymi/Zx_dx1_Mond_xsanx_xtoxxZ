package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.model.report.Report;
import com.monsanto.eas.bbs.service.AreaService;

public class WorkAreasAndWorkLocationsFetcher implements ReportFetcher
{
    private final AreaService areaService;

    public WorkAreasAndWorkLocationsFetcher(AreaService areaService) {
        this.areaService = areaService;
    }

    @Override
    public Report lookupReport(String reportName, Object parameters) {
        return new Report(areaService.getWorkAreasAndWorkLocations(null));
    }
}
