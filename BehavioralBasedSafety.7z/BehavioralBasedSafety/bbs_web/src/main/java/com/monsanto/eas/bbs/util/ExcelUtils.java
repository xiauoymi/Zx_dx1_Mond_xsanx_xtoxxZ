package com.monsanto.eas.bbs.util;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

import static org.apache.poi.ss.usermodel.CellStyle.ALIGN_CENTER;
import static org.apache.poi.ss.usermodel.CellStyle.BORDER_THIN;

public final class ExcelUtils
{
    private static final int DEFAULT_WIDTH_IN_CHARS = 20;
    private static final int WIDTH_OF_ONE_CHAR = 256;
    private static final byte LIGHT_GREEN_RED_COMPONENT = (byte) 234;
    private static final byte LIGHT_GREEN_GREEN_COMPONENT = (byte) 240;
    private static final byte LIGHT_GREEN_BLUE_COMPONENT = (byte) 217;
    private static final byte AUTOMATIC_RED_COMPONENT = (byte) 18;
    private static final byte AUTOMATIC_GREEN_COMPONENT = (byte) 83;
    private static final byte AUTOMATIC_BLUE_COMPONENT = (byte) 98;

    private ExcelUtils() {}

    public static HSSFCell addCell(HSSFSheet sheet, HSSFRow headerRow, HSSFCellStyle cellStyle, String text, int cellNum) {
        HSSFCell cell = headerRow.createCell((short) cellNum);
        sheet.setColumnWidth((short) cellNum, (short) (DEFAULT_WIDTH_IN_CHARS * WIDTH_OF_ONE_CHAR));
        cell.setCellValue(text);
        if (cellStyle != null) {
            cell.setCellStyle(cellStyle);
        }
        return cell;
    }

    public static HSSFCellStyle getCellStyle(HSSFWorkbook workbook, short color) {
        HSSFCellStyle cellStyle = workbook.createCellStyle();
        HSSFFont font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(color);
        cellStyle.setFont(font);
        return cellStyle;
    }

    public static HSSFCellStyle getHeaderStyle(HSSFSheet sheet) {
        HSSFPalette palette = sheet.getWorkbook().getCustomPalette();
        palette.setColorAtIndex(HSSFColor.LIGHT_GREEN.index, LIGHT_GREEN_RED_COMPONENT, LIGHT_GREEN_GREEN_COMPONENT, LIGHT_GREEN_BLUE_COMPONENT);
        palette.setColorAtIndex(HSSFColor.AUTOMATIC.index, AUTOMATIC_RED_COMPONENT, AUTOMATIC_GREEN_COMPONENT, AUTOMATIC_BLUE_COMPONENT);
        HSSFCellStyle style = getCellStyle(sheet.getWorkbook(), HSSFColor.AUTOMATIC.index);
        style.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setAlignment(ALIGN_CENTER);
        style.setBorderTop(BORDER_THIN);
        style.setBorderRight(BORDER_THIN);
        style.setBorderBottom(BORDER_THIN);
        style.setBorderLeft(BORDER_THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        return style;
    }
}
