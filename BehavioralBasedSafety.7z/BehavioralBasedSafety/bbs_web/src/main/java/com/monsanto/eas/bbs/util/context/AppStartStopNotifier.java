package com.monsanto.eas.bbs.util.context;

import org.apache.log4j.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class AppStartStopNotifier implements ServletContextListener
{
    private static final Logger LOG = Logger.getLogger(AppStartStopNotifier.class);

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        LOG.info(
            "\r\n  ____  ____   _____    _____ _             _           _" +
            "\r\n |  _ \\|  _ \\ / ____|  / ____| |           | |         | |" +
            "\r\n | |_) | |_) | (___   | (___ | |_ __ _ _ __| |_ ___  __| |" +
            "\r\n |  _ <|  _ < \\___ \\   \\___ \\| __/ _` | '__| __/ _ \\/ _` |" +
            "\r\n | |_) | |_) |____) |  ____) | || (_| | |  | ||  __/ (_| |" +
            "\r\n |____/|____/|_____/  |_____/ \\__\\__,_|_|   \\__\\___|\\__,_|" +
            "\r\n"
        );
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        LOG.info(
            "\r\n  ____  ____   _____    _____ _                             _" +
            "\r\n |  _ \\|  _ \\ / ____|  / ____| |                           | |" +
            "\r\n | |_) | |_) | (___   | (___ | |_ ___  _ __  _ __   ___  __| |" +
            "\r\n |  _ <|  _ < \\___ \\   \\___ \\| __/ _ \\| '_ \\| '_ \\ / _ \\/ _` |" +
            "\r\n | |_) | |_) |____) |  ____) | || (_) | |_) | |_) |  __/ (_| |" +
            "\r\n |____/|____/|_____/  |_____/ \\__\\___/| .__/| .__/ \\___|\\__,_|" +
            "\r\n                                      | |   | |" +
            "\r\n                                      |_|   |_|" +
            "\r\n"
        );
    }
}
