package com.monsanto.eas.bbs.util.opendocument;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class EBOSessionManager {
   @Autowired
    private CrystalEnterprise crystalEnterprise;

    public EBOSessionManager() {
      crystalEnterprise = new CrystalEnterprise();
    }
//
//    public EBOSessionManager(CrystalEnterprise crystalEnterprise) {
//      this.crystalEnterprise = crystalEnterprise;
//    }

    public ISessionMgr getSessionManager() throws SDKException {
        return crystalEnterprise.getSessionMgr();
    }

  public void setCrystalEnterprise(CrystalEnterprise crystalEnterprise) {
    this.crystalEnterprise = crystalEnterprise;
  }
}
