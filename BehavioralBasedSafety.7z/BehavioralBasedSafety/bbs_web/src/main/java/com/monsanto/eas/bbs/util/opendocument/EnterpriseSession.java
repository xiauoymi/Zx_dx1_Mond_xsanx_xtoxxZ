package com.monsanto.eas.bbs.util.opendocument;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class EnterpriseSession {
   @Autowired
   private EBOSessionManager eboSessionManager;

   private static OpenDocumentPropertyFile servPropFile = new OpenDocumentPropertyFile(OpenDocumentConstants.PROPERTIES_FILE_NAME);

   private static Log log = LogFactory.getLog(EnterpriseSession.class);

   public IEnterpriseSession connectToEBOCMSServer() {

      final String userName = servPropFile.getProperty(OpenDocumentConstants.USERNAME);
      final String pswrdFile = servPropFile.getProperty(OpenDocumentConstants.PASSWORD_FILE_NAME);
      final String keyFile = servPropFile.getProperty(OpenDocumentConstants.KEY_FILE_NAME);
      final String appId = servPropFile.getProperty(OpenDocumentConstants.APP_IDENTIFIER);
      final String sysId = servPropFile.getProperty(OpenDocumentConstants.FILE_LOCATION_SYSTEM_IDENTIFIER);

      final String decryptPassword = getPasswordForServiceAccount(pswrdFile, keyFile, appId, sysId);

      final String cmsServer = servPropFile.getPropertyForSpecificEnvironment(OpenDocumentConstants.EBO_CMS_SERVER);
      final String cmsServerPort = servPropFile.getPropertyForSpecificEnvironment(OpenDocumentConstants.EBO_CMS_SERVER_PORT);
      final String cmsServerString = new StringBuffer(cmsServer).append(":").append(cmsServerPort).toString();
      final String cmsServerAuthenticationType = OpenDocumentConstants.LDAP_SECURITY;

      IEnterpriseSession enterpriseSession = null;
      try {
         ISessionMgr iSessionMgr = eboSessionManager.getSessionManager();
         enterpriseSession = iSessionMgr.logon(userName, decryptPassword, cmsServerString,
                 cmsServerAuthenticationType);
      } catch (SDKException e) {
         log.error(e.getMessage());
         throw new ServiceRuntimeException("Unable to connect to the EBO CMS server in " + System.getProperty("lsi.function"), e);
      }
      return enterpriseSession;
   }

   private String getPasswordForServiceAccount(String pswrdFile, String keyFile, String appId, String sysId) {
      String decryptPassword;
      try {
         decryptPassword = EncryptionUtils
                 .GetDecryptedStringFromExternalStorage(sysId, appId,
                         pswrdFile, keyFile);
      } catch (EncryptorException ee) {
         throw new ServiceRuntimeException("Error decrypting service password", ee);
      }
      return decryptPassword;
   }

   public void setEboSessionManager(EBOSessionManager eboSessionManager) {
      this.eboSessionManager = eboSessionManager;
   }
}
