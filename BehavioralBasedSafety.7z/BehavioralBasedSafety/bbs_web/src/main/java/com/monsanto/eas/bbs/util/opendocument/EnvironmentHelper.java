package com.monsanto.eas.bbs.util.opendocument;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class EnvironmentHelper extends com.monsanto.Util.EnvironmentHelper {

    private static final int PROD = 0;
    private static final int TEST = 1;
	private static final int DEVL = 2;
	private static final int LOCAL = 3;

    public static int getEnvironment() {

        String environment = com.monsanto.Util.EnvironmentHelper.getFunction();

        if (sf_cstrPrd.equals(environment) || sf_cstrPostProd.equals(environment) ){ return PROD;}
        if (sf_cstrIt.equals(environment) || sf_cstrTst.equals(environment) ){ return TEST;}
        if (sf_cstrDev.equals(environment)  ){ return DEVL;}

        return LOCAL;
    }

}
