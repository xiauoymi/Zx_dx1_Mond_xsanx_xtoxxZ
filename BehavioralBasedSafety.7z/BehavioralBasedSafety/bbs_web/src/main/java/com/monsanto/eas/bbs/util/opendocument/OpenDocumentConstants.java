package com.monsanto.eas.bbs.util.opendocument;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface OpenDocumentConstants {
   String EBO_CMS_SERVER = "eboCMSServer";
   String EBO_CMS_SERVER_PORT = "port";
   String EBO_OPEN_DOCUMENT_URL = "eboOpenDocURL";
   String EBO_SERVICE_URL = "EBOServiceURL";
   String PROPERTIES_FILE_NAME = "service-account";
   String FILE_LOCATION_SYSTEM_IDENTIFIER = "file.location.system.identifier";
   String USERNAME = "username";
   String PASSWORD_FILE_NAME = "password.file.name";
   String KEY_FILE_NAME = "key.file.name";
   String APP_IDENTIFIER = "app.identifier";
   String LDAP_SECURITY = "secLDAP";

   String EBO_REPORT_LINK = "eboReports/" + "boOpenDocumentView.htm";
   String DOCUMENT_ID = "docUID";
   String PARAMETERS = "params";
   String QUERY_PARAM_DELIMITER = ",";
   String EBO_PARAM_ASSIGNMENT = ":=";
   String AMPERSAND = "&";
   String S_TYPE = "sType";
   String SINGLE_VALUE_PROMPT = "lsS";
}
