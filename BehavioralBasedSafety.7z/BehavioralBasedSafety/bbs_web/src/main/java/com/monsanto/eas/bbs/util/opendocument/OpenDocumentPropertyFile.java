package com.monsanto.eas.bbs.util.opendocument;

import com.monsanto.Util.EnvironmentHelperException;
import org.apache.log4j.Logger;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class OpenDocumentPropertyFile {
    private static final String MSR_PROPERTIES = "msr.properties";
    /**
    * utility used to load the property file
    */
   private ResourceBundle resourceBundle;
   //private String propFile = null;

   private static Logger logger = Logger.getLogger(OpenDocumentPropertyFile.class);

   /**
    * @param resourceBundle
    */
   public OpenDocumentPropertyFile(String propFile) {
      super();

      try {
         resourceBundle = ResourceBundle.getBundle(propFile);
      }
      catch (MissingResourceException e) {
          logPropertiesFileNotFoundError(e, propFile);
      }
   }

    private void logPropertiesFileNotFoundError(MissingResourceException e, String propFile) {
        logger.error("msrProperties static initializer: "
            + "The " + propFile + ".properties file cannot be loaded.  "
            + "MissingResourceException = "
            + e.getMessage(), e);
    }

   /**
    * gets a property
    *
    * @param String aPropertyKey property key
    * @return String property value
    */
   public String getProperty(String aPropertyKey) {
      String lPropertyValue = null;

      try {
         lPropertyValue = resourceBundle.getString(aPropertyKey).trim();
      }
      catch (MissingResourceException e) {
          logPropertiesFileNotFoundError(e, MSR_PROPERTIES);
          return lPropertyValue;
      }
      return lPropertyValue;
   }

   /**
    * gets a property
    *
    * @param String aPropertyKey property key
    * @return String property value
    */
   public String getPropertyForSpecificEnvironment(String aPropertyKey) {
      String lPropertyValue = null;
      String envPrefix = null;
      try {
         envPrefix = EnvironmentHelper.getPropertyPrefix();
      }
      catch (EnvironmentHelperException ehe) {
         logger.error(ehe.getMessage(), ehe);
      }

      try {
         lPropertyValue = resourceBundle.getString(envPrefix + aPropertyKey).trim();
      } catch (MissingResourceException e) {
          logPropertiesFileNotFoundError(e, MSR_PROPERTIES);
          return lPropertyValue;
      }
      return lPropertyValue;
   }
}
