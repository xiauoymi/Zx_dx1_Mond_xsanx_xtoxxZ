package com.monsanto.eas.bbs.util.report.beans;

import com.google.common.base.Throwables;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;

public class Property
{
    private static final Logger LOG = Logger.getLogger(Property.class);
    private final String name;
    private final Class type;

    public Property(String name, Class type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public Class getType() {
        return type;
    }

    public Object getValueFor(Object obj) {
        Object value = null;
        try {
            value = PropertyUtils.getProperty(obj, name);
        }
        catch (Exception e) {
            LOG.error(e.getMessage(), e);
            Throwables.propagate(e);
        }
        return value;
    }
}
