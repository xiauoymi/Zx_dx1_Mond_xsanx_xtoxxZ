package com.monsanto.eas.bbs.util.report.enums;

import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;

public enum CategoryType
{
    ENVIRONMENT (1, "Environment Condition"),
    BEHAVIOR    (2, "Behavior");

    private static final Map<Long, CategoryType> CATEGORY_TYPE_MAP = newHashMap();
    static {
        CATEGORY_TYPE_MAP.put(ENVIRONMENT.getId(), ENVIRONMENT);
        CATEGORY_TYPE_MAP.put(BEHAVIOR.getId(), BEHAVIOR);
    }

    private final Long id;
    private final String description;

    private CategoryType(int id, String description) {
        this.id = (long) id;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public static CategoryType getById(Long id) {
        return CATEGORY_TYPE_MAP.get(id);
    }
}
