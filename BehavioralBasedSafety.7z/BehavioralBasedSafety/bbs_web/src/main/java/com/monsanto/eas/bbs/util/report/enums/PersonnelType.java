package com.monsanto.eas.bbs.util.report.enums;

public enum PersonnelType
{
    CONTRACTOR     ( "Contractor"                ),
    EMPLOYEE       ( "Monsanto Employee"         ),
    TEMPORARY      ( "Seasonal/Temporary worker" ),
    NOT_APPLICABLE ( "Not Applicable"            );

    private String description;

    private PersonnelType(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return description;
    }
}
