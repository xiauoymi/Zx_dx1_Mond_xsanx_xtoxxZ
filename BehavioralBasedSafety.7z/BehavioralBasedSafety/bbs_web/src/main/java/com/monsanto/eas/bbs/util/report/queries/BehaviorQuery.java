package com.monsanto.eas.bbs.util.report.queries;

import org.hibernate.Hibernate;

import java.util.List;

import static com.monsanto.eas.bbs.util.report.enums.CategoryType.BEHAVIOR;

public class BehaviorQuery extends ObservationQuery
{
    private static final int START_INDEX = 31;

    public BehaviorQuery() {
        super(BEHAVIOR.getId());
    }

    protected StringBuilder appendResultMappings(StringBuilder resultColumns) {
        return resultColumns
            .append(", bbs.cat_observation.safe_behavior_feedback as safebehaviorfeedback")
            .append(", bbs.cat_observation.safe_behavior_comments as safebehaviorcomments")
            .append(", bbs.cat_observation.safe_behavior_description as safebehaviordescription")
            .append(", lanresp.description as response ")
        ;
    }

    @Override
    protected List<ResultMapping> appendResultMappings(List<ResultMapping> resultMappings) {
        int index = START_INDEX;
        resultMappings.add(new ResultMapping(index++, "bbs.cat_observation.safe_behavior_feedback", "safeBehaviorFeedback", Hibernate.STRING));
        resultMappings.add(new ResultMapping(index++, "bbs.cat_observation.safe_behavior_comments", "safeBehaviorComments", Hibernate.STRING));
        resultMappings.add(new ResultMapping(index++, "bbs.cat_observation.safe_behavior_description", "safeBehaviorDescription", Hibernate.STRING));
        resultMappings.add(new ResultMapping(index++, "lanresp.description", "response", Hibernate.STRING));
        return resultMappings;
    }

    @Override
    protected StringBuilder appendJoinFilters(StringBuilder joinFilters) {
        return joinFilters
            .append(" inner join bbs.response resp on resp.id = bbs.cat_observation.response_id")
            .append(" inner join bbs.lan_response lanresp on lanresp.response_id = resp.id")
            .append(" and lanresp.bbs_lang_id = bbs.language.id")
        ;
    }

    @Override
    protected StringBuilder appendWhereFilters(StringBuilder whereFilters) {
        return whereFilters;
    }

    @Override
    protected StringBuilder appendOrderByClauses(StringBuilder orderByClauses) {
        return orderByClauses;
    }
}
