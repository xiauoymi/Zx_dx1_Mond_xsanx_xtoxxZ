package com.monsanto.eas.bbs.util.report.queries;

import java.util.List;

import static com.monsanto.eas.bbs.util.report.enums.CategoryType.ENVIRONMENT;

public class EnvironmentQuery extends ObservationQuery
{
    public EnvironmentQuery() {
        super(ENVIRONMENT.getId());
    }

    @Override
    protected List<ResultMapping> appendResultMappings(List<ResultMapping> resultMappings) {
        return resultMappings;
    }

    @Override
    protected StringBuilder appendJoinFilters(StringBuilder joinFilters) {
        return joinFilters;
    }

    @Override
    protected StringBuilder appendWhereFilters(StringBuilder whereFilters) {
        return whereFilters;
    }

    @Override
    protected StringBuilder appendOrderByClauses(StringBuilder orderByClauses) {
        return orderByClauses;
    }

}
