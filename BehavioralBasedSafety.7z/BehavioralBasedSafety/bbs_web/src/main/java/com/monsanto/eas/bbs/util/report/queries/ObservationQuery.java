package com.monsanto.eas.bbs.util.report.queries;

import com.google.common.base.Joiner;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import java.util.List;

import static ch.lambdaj.Lambda.extract;
import static ch.lambdaj.Lambda.on;
import static com.google.common.collect.Lists.newArrayList;

public abstract class ObservationQuery
{
    private static final int START_INDEX = 0;
    private final Long categoryTypeId;
    private final List<ResultMapping> resultMappings;

    protected ObservationQuery(long categoryTypeId) {
        this.categoryTypeId = categoryTypeId;
        this.resultMappings = initResultMappings();
    }

    private String buildSQL() {
        return new StringBuilder("SELECT ")
            .append(Joiner.on(", ").join(extract(resultMappings, on(ResultMapping.class).getCompleteColumnSelectExpression())))
            .append(initJoinFilters())
            .append(initWhereFilters())
            .append(initOrderByClauses())
            .toString()
        ;
    }

    private List<ResultMapping> initResultMappings() {
        List<ResultMapping> mappings = newArrayList();
        int index = START_INDEX;
        mappings.add(new ResultMapping(index++, "bbs.observation.id", "observationId", Hibernate.LONG));
        mappings.add(new ResultMapping(index++, "enteredby.first_name", "enteredByFirstName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "enteredby.last_name", "enteredByLastName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "enteredfor.first_name", "enteredForFirstName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "enteredfor.last_name", "enteredForLastName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.observation.date_entered", "dateEntered", Hibernate.TIMESTAMP));
        mappings.add(new ResultMapping(index++, "bbs.lan_personnel_type.description", "personnelTypeDesc", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.safety_group.group_text", "safetyGroup", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.biotech_program.program", "biotechProgram", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.biotech_project_plat.project_desc", "biotechProject", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.task.description", "task", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "lanarea.description", "area", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "sublanarea.description", "subArea", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.cat_observation.feedback", "feedback", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.cat_observation.comments", "comments", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.cat_observation.description", "catObservation", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.cat_observation.immediate_actions", "immediateActions", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.lan_barrier_cat.description", "barrier", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "lanSubSubCat.description", "subSubCat", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "lanSubCat.description", "subCat", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "lanCat.description", "category", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "dept.name", "departmentName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.cat_observation.id", "catObservationId", Hibernate.LONG));
        mappings.add(new ResultMapping(index++, "enteredby.id", "enteredById", Hibernate.LONG));
        mappings.add(new ResultMapping(index++, "enteredby.user_id", "enteredByUserId", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "enteredby.plant_id", "enteredByPlantId", Hibernate.LONG));
        mappings.add(new ResultMapping(index++, "bbs.observation.plant_id", "observationPlantId", Hibernate.LONG));
        mappings.add(new ResultMapping(index++, "(select first_name || ' ' || last_name from bbs.bbs_user where user_id = bbs.observation.mod_user)", "modUser", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.observation.mod_date", "modDate", Hibernate.DATE));
        mappings.add(new ResultMapping(index++, "bbs.plant.plant_name_1", "plantName", Hibernate.STRING));
        mappings.add(new ResultMapping(index++, "bbs.category_type.description", "categoryTypeDesc", Hibernate.STRING));
        return appendResultMappings(mappings);
    }

    private StringBuilder initJoinFilters() {
        StringBuilder joinFilters = new StringBuilder()
            .append(" FROM")
                .append(" bbs.cat_observation")
                    .append(" inner join bbs.observation on bbs.cat_observation.observation_id = bbs.observation.id")
                    .append(" and trunc(bbs.observation.date_entered) between to_date(':reportDateFrom', ':dateFormat') and to_date(':reportDateTo', ':dateFormat')")
                    .append(" left outer join bbs.bbs_user enteredby on enteredby.id = bbs.observation.entered_by")
                    .append(" left outer join bbs.bbs_user enteredfor on enteredfor.id = bbs.observation.entered_for")
                    .append(" left outer join bbs.department dept on dept.id = enteredfor.department_id")
                    .append(" inner join bbs.language on bbs.language.id = :languageId")
                    .append(" inner join bbs.plant on bbs.plant.id = bbs.observation.plant_id")
                    .append(" and bbs.plant.id IN (:selectedPlantIds)")
                    .append(" inner join bbs.safety_group on bbs.safety_group.id = bbs.observation.safety_group_id")
                    .append(" left outer join bbs.BIOTECH_PROGRAM on bbs.BIOTECH_PROGRAM.id = bbs.observation.biotech_program_id")
                    .append(" left outer join bbs.BIOTECH_PROJECT_PLAT on bbs.BIOTECH_PROJECT_PLAT.id = bbs.observation.biotech_project_id")
                    .append(" left outer join bbs.task on bbs.task.id = bbs.observation.task_id")
                    .append(" left outer join bbs.personnel_type on bbs.observation.personnel_type_id = bbs.personnel_type.id")
                    .append(" left outer join bbs.lan_personnel_type on bbs.personnel_type.id = bbs.lan_personnel_type.personnel_type_id")
                    .append(" and bbs.lan_personnel_type.bbs_lang_id = bbs.language.id")
                    .append(" inner join bbs.area subarea on subarea.id = bbs.observation.sub_area_id")
                    .append(" inner join bbs.lan_area sublanarea on sublanarea.area_id = subarea.id")
                    .append(" and sublanarea.bbs_lang_id = bbs.language.id")
                    .append(" inner join bbs.area area on area.id = bbs.observation.area_id")
                    .append(" inner join bbs.lan_area lanarea on lanarea.area_id = area.id")
                    .append(" and lanarea.bbs_lang_id = bbs.language.id")
                    .append(" left outer join bbs.barrier_cat on (bbs.barrier_cat.id = bbs.cat_observation.barrier_cat_id)")
                    .append(" left outer join bbs.lan_barrier_cat on bbs.lan_barrier_cat.barrier_cat_id = bbs.barrier_cat.id")
                    .append(" and bbs.lan_barrier_cat.lang_id = bbs.language.id")
                    .append(" left outer join bbs.category subSubCategory on subSubCategory.id = bbs.cat_observation.sub_sub_cat_id")
                    .append(" left outer join bbs.lan_category lanSubSubCat on lanSubSubCat.category_id = subSubCategory.id")
                    .append(" and lanSubSubCat.bbs_lang_id = bbs.language.id")
                    .append(" inner join bbs.category subCategory on subCategory.id = bbs.cat_observation.sub_cat_id")
                    .append(" inner join bbs.lan_category lanSubCat on lanSubCat.category_id = subCategory.id")
                    .append(" and lanSubCat.bbs_lang_id = bbs.language.id")
                    .append(" inner join bbs.category category on category.id = bbs.cat_observation.category_id")
                    .append(" inner join bbs.lan_category lanCat on lanCat.category_id = category.id")
                    .append(" and lanCat.bbs_lang_id = bbs.language.id")
                    .append(" inner join bbs.category_type on category_type.id = category.category_type_id")
                    .append(" and category_type.id = ")
                    .append(categoryTypeId)
        ;
        return appendJoinFilters(joinFilters);
    }

    private StringBuilder initWhereFilters() {
        StringBuilder whereFilters = new StringBuilder()
            .append(" WHERE bbs.observation.is_active = 'Y'")
        ;
        return appendWhereFilters(whereFilters);
    }

    private StringBuilder initOrderByClauses() {
        StringBuilder orderByClauses = new StringBuilder()
            .append(" ORDER BY observationId desc")
        ;
        return appendOrderByClauses(orderByClauses);
    }

    private SQLQuery buildQuery(Session session, ObservationQueryParameters parameters) {
        SQLQuery query = session.createSQLQuery(parameters.replaceInSQL(buildSQL()));
        for (ResultMapping mapping: resultMappings) {
            mapping.addScalarTo(query);
        }
        return query;
    }
    protected abstract List<ResultMapping> appendResultMappings(List<ResultMapping> resultMappings);
    protected abstract StringBuilder appendJoinFilters(StringBuilder joinFilters);
    protected abstract StringBuilder appendWhereFilters(StringBuilder whereFilters);
    protected abstract StringBuilder appendOrderByClauses(StringBuilder orderByClauses);

    private ObservationQueryResult mapFields(Object[] tuple) {
        ObservationQueryResult observationQueryResult = new ObservationQueryResult();
        for (ResultMapping mapping: resultMappings) {
            mapping.setPropertyValue(observationQueryResult, tuple);
        }
        return observationQueryResult;
    }

    public List<ObservationQueryResult> getResults(Session session, ObservationQueryParameters parameters) {
        List<ObservationQueryResult> observationQueryResults = newArrayList();
        SQLQuery query = buildQuery(session, parameters);
        List results = query.list();
        for (Object result : results) {
            Object[] tuple = (Object[]) result;
            observationQueryResults.add(mapFields(tuple));
        }
        return observationQueryResults;
    }
}
