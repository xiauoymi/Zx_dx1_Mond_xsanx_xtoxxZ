package com.monsanto.eas.bbs.util.report.queries;

public class ObservationQueryParameters
{
    private String reportDateFrom;
    private String dateFormat;
    private String reportDateTo;
    private String languageId;
    private String selectedPlantIds;

    public String replaceInSQL(String sql) {
        String replacedSQL = replace(sql, ":reportDateFrom", reportDateFrom);
        replacedSQL = replace(replacedSQL, ":dateFormat", dateFormat);
        replacedSQL = replace(replacedSQL, ":reportDateTo", reportDateTo);
        replacedSQL = replace(replacedSQL, ":languageId", languageId);
        replacedSQL = replace(replacedSQL, ":selectedPlantIds", selectedPlantIds);
        return replacedSQL;
    }

    private String replace(String sql, String parameter, String value) {
        return (value == null) ? sql : sql.replaceAll(parameter, value);
    }

    public void setReportDateFrom(String reportDateFrom) {
        this.reportDateFrom = reportDateFrom;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public void setReportDateTo(String reportDateTo) {
        this.reportDateTo = reportDateTo;
    }

    public void setLanguageId(String languageId) {
        this.languageId = languageId;
    }

    public void setSelectedPlantIds(String selectedPlantIds) {
        this.selectedPlantIds = selectedPlantIds;
    }
}
