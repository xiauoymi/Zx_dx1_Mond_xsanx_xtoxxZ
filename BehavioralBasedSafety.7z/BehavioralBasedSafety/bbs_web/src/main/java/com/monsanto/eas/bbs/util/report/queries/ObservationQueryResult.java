package com.monsanto.eas.bbs.util.report.queries;

import com.monsanto.eas.bbs.util.report.enums.CategoryType;
import org.apache.commons.lang.builder.EqualsBuilder;

import java.util.Date;

public class ObservationQueryResult implements Comparable<ObservationQueryResult>
{
    private static final int HASHCODE_PRIME = 31;
    private Long observationId;
    private String enteredByFirstName;
    private String enteredByLastName;
    private String enteredForFirstName;
    private String enteredForLastName;
    private Date dateEntered;
    private String personnelTypeDesc;
    private String safetyGroup;
    private String biotechProgram;
    private String biotechProject;
    private String task;
    private String area;
    private String subArea;
    private String feedback;
    private String comments;
    private String catObservation;
    private String immediateActions;
    private String barrier;
    private String subSubCat;
    private String subCat;
    private String category;
    private String departmentName;
    private Long catObservationId;
    private Long enteredById;
    private String enteredByUserId;
    private Long enteredByPlantId;
    private Long observationPlantId;
    private String modUser;
    private Date modDate;
    private String plantName;
    private String categoryTypeDesc;
    private String safeBehaviorFeedback;
    private String safeBehaviorComments;
    private String safeBehaviorDescription;
    private String response;

    public Long getObservationId() {
        return observationId;
    }

    public void setObservationId(Long observationId) {
        this.observationId = observationId;
    }

    public String getEnteredByFirstName() {
        return enteredByFirstName;
    }

    public void setEnteredByFirstName(String enteredByFirstName) {
        this.enteredByFirstName = enteredByFirstName;
    }

    public String getEnteredByLastName() {
        return enteredByLastName;
    }

    public void setEnteredByLastName(String enteredByLastName) {
        this.enteredByLastName = enteredByLastName;
    }

    public String getEnteredForFirstName() {
        return enteredForFirstName;
    }

    public void setEnteredForFirstName(String enteredForFirstName) {
        this.enteredForFirstName = enteredForFirstName;
    }

    public String getEnteredForLastName() {
        return enteredForLastName;
    }

    public void setEnteredForLastName(String enteredForLastName) {
        this.enteredForLastName = enteredForLastName;
    }

    public Date getDateEntered() {
        return dateEntered;
    }

    public void setDateEntered(Date dateEntered) {
        this.dateEntered = dateEntered;
    }

    public String getPersonnelTypeDesc() {
        return personnelTypeDesc;
    }

    public void setPersonnelTypeDesc(String personnelTypeDesc) {
        this.personnelTypeDesc = personnelTypeDesc;
    }

    public String getSafetyGroup() {
        return safetyGroup;
    }

    public void setSafetyGroup(String safetyGroup) {
        this.safetyGroup = safetyGroup;
    }

    public String getBiotechProgram() {
        return biotechProgram;
    }

    public void setBiotechProgram(String biotechProgram) {
        this.biotechProgram = biotechProgram;
    }

    public String getBiotechProject() {
        return biotechProject;
    }

    public void setBiotechProject(String biotechProject) {
        this.biotechProject = biotechProject;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getSubArea() {
        return subArea;
    }

    public void setSubArea(String subArea) {
        this.subArea = subArea;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCatObservation() {
        return catObservation;
    }

    public void setCatObservation(String catObservation) {
        this.catObservation = catObservation;
    }

    public String getImmediateActions() {
        return immediateActions;
    }

    public void setImmediateActions(String immediateActions) {
        this.immediateActions = immediateActions;
    }

    public String getBarrier() {
        return barrier;
    }

    public void setBarrier(String barrier) {
        this.barrier = barrier;
    }

    public String getSubSubCat() {
        return subSubCat;
    }

    public void setSubSubCat(String subSubCat) {
        this.subSubCat = subSubCat;
    }

    public String getSubCat() {
        return subCat;
    }

    public void setSubCat(String subCat) {
        this.subCat = subCat;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Long getCatObservationId() {
        return catObservationId;
    }

    public void setCatObservationId(Long catObservationId) {
        this.catObservationId = catObservationId;
    }

    public Long getEnteredById() {
        return enteredById;
    }

    public void setEnteredById(Long enteredById) {
        this.enteredById = enteredById;
    }

    public String getEnteredByUserId() {
        return enteredByUserId;
    }

    public void setEnteredByUserId(String enteredByUserId) {
        this.enteredByUserId = enteredByUserId;
    }

    public Long getEnteredByPlantId() {
        return enteredByPlantId;
    }

    public void setEnteredByPlantId(Long enteredByPlantId) {
        this.enteredByPlantId = enteredByPlantId;
    }

    public Long getObservationPlantId() {
        return observationPlantId;
    }

    public void setObservationPlantId(Long observationPlantId) {
        this.observationPlantId = observationPlantId;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getCategoryTypeDesc() {
        return categoryTypeDesc;
    }

    public void setCategoryTypeDesc(String categoryTypeDesc) {
        this.categoryTypeDesc = categoryTypeDesc;
    }

    public String getSafeBehaviorFeedback() {
        return safeBehaviorFeedback;
    }

    public void setSafeBehaviorFeedback(String safeBehaviorFeedback) {
        this.safeBehaviorFeedback = safeBehaviorFeedback;
    }

    public String getSafeBehaviorComments() {
        return safeBehaviorComments;
    }

    public void setSafeBehaviorComments(String safeBehaviorComments) {
        this.safeBehaviorComments = safeBehaviorComments;
    }

    public String getSafeBehaviorDescription() {
        return safeBehaviorDescription;
    }

    public void setSafeBehaviorDescription(String safeBehaviorDescription) {
        this.safeBehaviorDescription = safeBehaviorDescription;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        ObservationQueryResult result = (ObservationQueryResult) obj;
        return new EqualsBuilder()
            .append(observationId, result.observationId)
            .append(catObservationId, result.catObservationId)
            .isEquals()
        ;
    }

    @Override
    public int hashCode() {
        int result = observationId != null ? observationId.hashCode() : 0;
        result = HASHCODE_PRIME * result + (catObservationId != null ? catObservationId.hashCode() : 0);
        return result;
    }

    private int compare(Comparable o1, Comparable o2) {
        return (o1 == null || o2 == null) ? 0 : o1.compareTo(o2);
    }

    private int compareCategoryTypeDesc(String categoryTypeDesc1, String categoryTypeDesc2) {
        return (categoryTypeDesc1 == null || categoryTypeDesc2 == null)
            ? 0
            : compare(
                CategoryType.valueOf(categoryTypeDesc1).ordinal(),
                CategoryType.valueOf(categoryTypeDesc2).ordinal()
            )
        ;
    }

    @Override
    public int compareTo(ObservationQueryResult o) {
        int result = compare(observationId, o.observationId);
        result = (result == 0 ? compareCategoryTypeDesc(categoryTypeDesc, o.categoryTypeDesc) : result);
        result = (result == 0 ? compare(response, o.response) : result);
        result = (result == 0 ? compare(catObservationId, o.catObservationId) : result);
        return result;
    }
}
