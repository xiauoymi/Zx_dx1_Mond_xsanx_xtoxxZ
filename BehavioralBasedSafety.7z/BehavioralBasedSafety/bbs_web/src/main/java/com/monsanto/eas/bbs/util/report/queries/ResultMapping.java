package com.monsanto.eas.bbs.util.report.queries;

import com.google.common.base.Throwables;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.type.NullableType;

import static org.apache.commons.beanutils.PropertyUtils.setProperty;

public class ResultMapping
{
    private static final Logger LOG = Logger.getLogger(ResultMapping.class);

    private final int tupleIndex;
    private String columnSelectExpression;
    private String alias;
    private NullableType hibernateType;

    public ResultMapping(int tupleIndex, String columnSelectExpression, String alias, NullableType hibernateType) {
        this.tupleIndex = tupleIndex;
        this.columnSelectExpression = columnSelectExpression;
        this.alias = alias;
        this.hibernateType = hibernateType;
    }

    public String getCompleteColumnSelectExpression() {
        return columnSelectExpression + " AS " + alias;
    }

    public void setPropertyValue(ObservationQueryResult observationQueryResult, Object[] tuple) {
        try {
            setProperty(observationQueryResult, alias, tuple[tupleIndex]);
        }
        catch (Exception e) {
            LOG.error(e.getMessage(), e);
            Throwables.propagate(e);
        }
    }

    public void addScalarTo(SQLQuery query) {
        query.addScalar(alias, hibernateType);
    }
}
