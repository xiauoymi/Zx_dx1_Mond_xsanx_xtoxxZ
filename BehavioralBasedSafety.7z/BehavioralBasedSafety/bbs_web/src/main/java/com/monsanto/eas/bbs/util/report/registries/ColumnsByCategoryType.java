package com.monsanto.eas.bbs.util.report.registries;

import com.monsanto.eas.bbs.util.report.enums.CategoryType;
import com.monsanto.eas.bbs.util.report.enums.Column;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;
import static com.monsanto.eas.bbs.util.report.enums.CategoryType.*;
import static com.monsanto.eas.bbs.util.report.enums.Column.*;

public final class ColumnsByCategoryType
{
    private ColumnsByCategoryType() {
    }

    private static final Map<Long, Set<Column>> COLUMNS_BY_CATEGORY_TYPE_ID = newHashMap();

    static
    {
        associateColumn( OBSERVATION,                withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( OBSERVED_BY,                withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( WORK_AREA,                  withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( WORK_LOCATION,              withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( SAFETY_GROUP,               withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( BIOTECH_PROGRAM,            withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( BIOTECH_PROJECT_PLATFORM,   withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( TASK,                       withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( RESPONSE,                   withCategoryTypes(               BEHAVIOR ) );
        associateColumn( PERSONNEL_TYPE,             withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( CREATE_DATE,                withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( ENTERED_BY,                 withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( LAST_MODIFIED_BY,           withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( LAST_MODIFIED_DATE,         withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( DEPARTMENT,                 withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( CATEGORY_TYPE,              withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( CATEGORY,                   withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( SUB_CATEGORY,               withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( DETAIL_CATEGORY,            withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( DESCRIBE_WHAT_HAPPENED,     withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
        associateColumn( IMMEDIATE_ACTIONS,          withCategoryTypes( ENVIRONMENT            ) );
        associateColumn( FEEDBACK_GIVEN,             withCategoryTypes(               BEHAVIOR ) );
        associateColumn( COMMENTS_RECEIVED,          withCategoryTypes(               BEHAVIOR ) );
        associateColumn( BARRIER,                    withCategoryTypes(               BEHAVIOR ) );
        associateColumn( SAFE_BEHAVIOR_FEEDBACK,     withCategoryTypes(               BEHAVIOR ) );
        associateColumn( SAFE_BEHAVIOR_COMMENT,      withCategoryTypes(               BEHAVIOR ) );
        associateColumn( SAFE_BEHAVIOR_DESCRIPTION,  withCategoryTypes(               BEHAVIOR ) );
        associateColumn( PLANT,                      withCategoryTypes( ENVIRONMENT,  BEHAVIOR ) );
    }

    private static void associateColumn(Column column, List<CategoryType> categoryTypes) {
        for (CategoryType categoryType : categoryTypes) {
            if (!COLUMNS_BY_CATEGORY_TYPE_ID.containsKey(categoryType.getId())) {
                COLUMNS_BY_CATEGORY_TYPE_ID.put(categoryType.getId(), new HashSet<Column>());
            }
            COLUMNS_BY_CATEGORY_TYPE_ID.get(categoryType.getId()).add(column);
        }
    }

    private static List<CategoryType> withCategoryTypes(CategoryType... categoryTypes) {
        return newArrayList(categoryTypes);
    }

    public static Set<Column> getById(Long categoryTypeId) {
        return COLUMNS_BY_CATEGORY_TYPE_ID.get(categoryTypeId);
    }
}
