package com.monsanto.eas.bbs.util.report.registries;

import com.monsanto.eas.bbs.util.report.enums.Column;

import java.util.Map;

import static com.google.common.collect.Maps.newTreeMap;
import static com.monsanto.eas.bbs.util.report.enums.Column.*;

public final class KeysByColumn
{
    private static final Map<Column, String> KEYS_BY_COLUMN = newTreeMap();

    static {
        associateColumn( OBSERVATION,               withKey( "observationNum"          ) );
        associateColumn( OBSERVED_BY,               withKey( "observedBy"              ) );
        associateColumn( WORK_AREA,                 withKey( "area"                    ) );
        associateColumn( WORK_LOCATION,             withKey( "subArea"                 ) );
        associateColumn( SAFETY_GROUP,              withKey( "safetygroup"             ) );
        associateColumn( BIOTECH_PROGRAM,           withKey( "program"                 ) );
        associateColumn( BIOTECH_PROJECT_PLATFORM,  withKey( "projectPlatform"         ) );
        associateColumn( TASK,                      withKey( "task"                    ) );
        associateColumn( RESPONSE,                  withKey( "response"                ) );
        associateColumn( PERSONNEL_TYPE,            withKey( "personnelType"           ) );
        associateColumn( CREATE_DATE,               withKey( "date"                    ) );
        associateColumn( ENTERED_BY,                withKey( "enteredBy"               ) );
        associateColumn( LAST_MODIFIED_BY,          withKey( "lastModifiedBy"          ) );
        associateColumn( LAST_MODIFIED_DATE,        withKey( "lastModifiedDate"        ) );
        associateColumn( DEPARTMENT,                withKey( "department"              ) );
        associateColumn( CATEGORY_TYPE,             withKey( "categoryType"            ) );
        associateColumn( CATEGORY,                  withKey( "category"                ) );
        associateColumn( SUB_CATEGORY,              withKey( "subCategory"             ) );
        associateColumn( DETAIL_CATEGORY,           withKey( "detailCategory"          ) );
        associateColumn( DESCRIBE_WHAT_HAPPENED,    withKey( "describeWhatHappened"    ) );
        associateColumn( IMMEDIATE_ACTIONS,         withKey( "immediateActions"        ) );
        associateColumn( FEEDBACK_GIVEN,            withKey( "feedbackGiven"           ) );
        associateColumn( COMMENTS_RECEIVED,         withKey( "commentsReceived"        ) );
        associateColumn( BARRIER,                   withKey( "barrier"                 ) );
        associateColumn( SAFE_BEHAVIOR_FEEDBACK,    withKey( "safeBehaviorFeedback"    ) );
        associateColumn( SAFE_BEHAVIOR_COMMENT,     withKey( "safeBehaviorComments"    ) );
        associateColumn( SAFE_BEHAVIOR_DESCRIPTION, withKey( "safeBehaviorDescription" ) );
        associateColumn( PLANT,                     withKey( "plant"                   ) );
    }

    private static void associateColumn(Column column, String key) {
        KEYS_BY_COLUMN.put(column, key);
    }

    private static String withKey(String key) {
        return key;
    }

    public static String get(Column column) {
        return KEYS_BY_COLUMN.get(column);
    }

    private KeysByColumn() {
    }
}
