package com.monsanto.eas.bbs.util.report.registries;

import com.monsanto.eas.bbs.util.report.enums.Column;
import com.monsanto.eas.bbs.util.report.beans.Property;

import java.util.Date;
import java.util.Map;

import static com.google.common.collect.Maps.newTreeMap;
import static com.monsanto.eas.bbs.util.report.enums.Column.*;

public final class PropertiesByColumn
{
    private static final Map<Column, Property> PROPERTIES_BY_COLUMN = newTreeMap();

    static
    {
        associateColumn( OBSERVATION,               withProperty( "observation.id" )                                                     );
        associateColumn( OBSERVED_BY,               withProperty( "observation.enteredFor.fullName")                                     );
        associateColumn( WORK_AREA,                 withProperty( "observation.areaDesc")                                                );
        associateColumn( WORK_LOCATION,             withProperty( "observation.subAreaDesc")                                             );
        associateColumn( SAFETY_GROUP,              withProperty( "observation.safetyGroup.groupText")                                   );
        associateColumn( BIOTECH_PROGRAM,           withProperty( "observation.biotechProgram.program")                                  );
        associateColumn( BIOTECH_PROJECT_PLATFORM,  withProperty( "observation.biotechProjectPlatform.projectDescription")               );
        associateColumn( TASK,                      withProperty( "observation.task.description")                                        );
        associateColumn( RESPONSE,                  withProperty( "responseDesc")                                                        );
        associateColumn( PERSONNEL_TYPE,            withProperty( "personnelTypeDesc")                                                   );
        associateColumn( CREATE_DATE,               withProperty( "observation.dateEntered"),                               ofDateType() );
        associateColumn( ENTERED_BY,                withProperty( "observation.enteredBy.fullName")                                      );
        associateColumn( LAST_MODIFIED_BY,          withProperty( "observation.modUser")                                                 );
        associateColumn( LAST_MODIFIED_DATE,        withProperty( "observation.modDate"),                                   ofDateType() );
        associateColumn( DEPARTMENT,                withProperty( "observation.enteredFor.department.name")                              );
        associateColumn( CATEGORY_TYPE,             withProperty( "category.categoryType.description")                                   );
        associateColumn( CATEGORY,                  withProperty( "grandParentCatDesc")                                                  );
        associateColumn( SUB_CATEGORY,              withProperty( "parentCatDesc")                                                       );
        associateColumn( DETAIL_CATEGORY,           withProperty( "childCatDesc")                                                        );
        associateColumn( DESCRIBE_WHAT_HAPPENED,    withProperty( "description")                                                         );
        associateColumn( IMMEDIATE_ACTIONS,         withProperty( "immediateActions")                                                    );
        associateColumn( FEEDBACK_GIVEN,            withProperty( "feedback")                                                            );
        associateColumn( COMMENTS_RECEIVED,         withProperty( "comments")                                                            );
        associateColumn( BARRIER,                   withProperty( "barrierDesc")                                                         );
        associateColumn( SAFE_BEHAVIOR_FEEDBACK,    withProperty( "safeBehaviorFeedback")                                                );
        associateColumn( SAFE_BEHAVIOR_COMMENT,     withProperty( "safeBehaviorComments")                                                );
        associateColumn( SAFE_BEHAVIOR_DESCRIPTION, withProperty( "safeBehaviorDescription")                                             );
        associateColumn( PLANT,                     withProperty( "observation.safetyGroup.plant.plantName1")                            );
    }

    private PropertiesByColumn() {
    }

    private static void associateColumn(Column column, String propertyName) {
        associateColumn(column, withProperty(propertyName), ofStringType());
    }

    private static void associateColumn(Column column, String propertyName, Class propertyType) {
        PROPERTIES_BY_COLUMN.put(column, new Property(propertyName, propertyType));
    }

    private static String withProperty(String propertyName) {
        return propertyName;
    }

    private static Class ofStringType() {
        return String.class;
    }

    private static Class ofDateType() {
        return Date.class;
    }

    public static Property get(Column column) {
        return PROPERTIES_BY_COLUMN.get(column);
    }
}
