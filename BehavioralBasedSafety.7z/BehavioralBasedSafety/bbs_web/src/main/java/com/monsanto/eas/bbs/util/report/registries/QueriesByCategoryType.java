package com.monsanto.eas.bbs.util.report.registries;

import com.monsanto.eas.bbs.util.report.queries.BehaviorQuery;
import com.monsanto.eas.bbs.util.report.queries.EnvironmentQuery;
import com.monsanto.eas.bbs.util.report.queries.ObservationQuery;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;
import static com.monsanto.eas.bbs.util.report.enums.CategoryType.BEHAVIOR;
import static com.monsanto.eas.bbs.util.report.enums.CategoryType.ENVIRONMENT;

public final class QueriesByCategoryType
{
    private static final Map<Long, ObservationQuery> QUERIES_BY_CATEGORY_TYPE_ID = newHashMap();

    static {
        QUERIES_BY_CATEGORY_TYPE_ID.put(ENVIRONMENT.getId(), new EnvironmentQuery());
        QUERIES_BY_CATEGORY_TYPE_ID.put(BEHAVIOR.getId(), new BehaviorQuery());
    }

    public static List<ObservationQuery> getByIds(List<Long> categoryTypeIds) {
        List<Long> sortedCategoryTypeIds = newArrayList(categoryTypeIds);
        Collections.sort(sortedCategoryTypeIds);
        List<ObservationQuery> queries = newArrayList();
        for (Long categoryTypeId : sortedCategoryTypeIds) {
            queries.add(QUERIES_BY_CATEGORY_TYPE_ID.get(categoryTypeId));
        }
        return queries;
    }

    private QueriesByCategoryType() {
    }
}
