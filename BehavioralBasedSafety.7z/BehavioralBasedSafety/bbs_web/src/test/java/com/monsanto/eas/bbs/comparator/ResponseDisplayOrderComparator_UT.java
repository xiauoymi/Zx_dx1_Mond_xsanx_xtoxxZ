/*
 ResponseDisplayOrderComparator_UT was created on Feb 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.comparator;

import com.monsanto.eas.bbs.hibernate.LanguageBasedResponse;
import com.monsanto.eas.bbs.hibernate.LanguageBasedResponsePK;
import com.monsanto.eas.bbs.hibernate.Response;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class ResponseDisplayOrderComparator_UT {

    @Test
    public void testCompareTo() throws Exception {
        Response response1 = new Response();
        response1.setId(new Long(2));
        response1.setActive(true);
        response1.setDefaultOption(true);
        response1.setDisplayOrder(2);

        LanguageBasedResponse languageBasedResponse1 = new LanguageBasedResponse();
        languageBasedResponse1.setDescription("Negative 1");
        LanguageBasedResponsePK pk1 = new LanguageBasedResponsePK();

        pk1.setResponse(response1);

        languageBasedResponse1.setId(pk1);

        Response response2 = new Response();
        response2.setId(new Long(2));
        response2.setActive(true);
        response2.setDefaultOption(true);
        response2.setDisplayOrder(1);

        LanguageBasedResponse languageBasedResponse2 = new LanguageBasedResponse();
        languageBasedResponse2.setDescription("Negative 1");
        LanguageBasedResponsePK pk2 = new LanguageBasedResponsePK();

        pk2.setResponse(response2);

        languageBasedResponse2.setId(pk2);
        ResponseDisplayOrderComparator comparator = new ResponseDisplayOrderComparator();

        assertEquals(1, comparator.compare(languageBasedResponse1, languageBasedResponse2));
        assertEquals(-1, comparator.compare(languageBasedResponse2, languageBasedResponse1));

        languageBasedResponse2.getId().getResponse().setDisplayOrder(2);
        assertEquals(0, comparator.compare(languageBasedResponse2, languageBasedResponse1));
    }
}