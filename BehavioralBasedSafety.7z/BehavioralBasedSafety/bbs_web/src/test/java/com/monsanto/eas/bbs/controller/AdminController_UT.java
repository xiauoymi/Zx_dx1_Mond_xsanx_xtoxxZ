package com.monsanto.eas.bbs.controller;

import com.monsanto.eas.bbs.controller.admin.AdminController;
import com.monsanto.eas.bbs.filter.BBSConstants;
import com.monsanto.eas.bbs.hibernate.BBSRole;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Mar 15, 2010
 * Time: 3:45:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class AdminController_UT {

    @Test
    public void testHandleRequestInternal_UserHasNoRole_ReturnNullModelAndView() throws Exception {
        AdminController adminController = new AdminController();
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpSession httpSession = new MockHttpSession();
        httpSession.setAttribute(BBSConstants.BBS_USER, new BBSUser());
        request.setSession(httpSession);
        request.setMethod("GET");
        ModelAndView modelAndView = adminController.handleRequest(request, new MockHttpServletResponse());
        assertNull(modelAndView);
    }

    private BBSUser setUpGeneralUser(String userRole){
        BBSUser bbsUser = new BBSUser();
        Set roles = new HashSet();
        BBSRole role = new BBSRole();
        role.setId((long) 1);
        role.setDescription(userRole);
        roles.add(role);
        bbsUser.setRoles(roles);

        return bbsUser;
    }

    @Test
    public void testHandleRequestInternal_UserIsESHRole_ReturnNullModelAndView() throws Exception {
        AdminController adminController = new AdminController();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setParameter("view", "testpath");
        MockHttpSession httpSession = new MockHttpSession();

        BBSUser bbsUser = setUpGeneralUser(BBSUser.ESH_ADMIN);
        httpSession.setAttribute(BBSConstants.BBS_USER, bbsUser);
        request.setSession(httpSession);
        request.setMethod("GET");
        ModelAndView modelAndView = adminController.handleRequest(request, new MockHttpServletResponse());
        assertEquals("admin/testpath", modelAndView.getViewName());
    }

    @Test
    public void testHandleRequestInternal_UserIsGlobalLead() throws Exception {
        AdminController adminController = new AdminController();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setParameter("view", "testpath");
        MockHttpSession httpSession = new MockHttpSession();

        BBSUser bbsUser = setUpGeneralUser(BBSUser.GLOBAL_LEAD);

        httpSession.setAttribute(BBSConstants.BBS_USER, bbsUser);
        request.setSession(httpSession);
        request.setMethod("GET");
        ModelAndView modelAndView = adminController.handleRequest(request, new MockHttpServletResponse());
        assertEquals("admin/testpath", modelAndView.getViewName());
    }

    @Test
    public void testHandleRequestInternal_UserIsEMEAAdmin() throws Exception {
        AdminController adminController = new AdminController();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setParameter("view", "testpath");
        MockHttpSession httpSession = new MockHttpSession();

        BBSUser bbsUser = setUpGeneralUser(BBSUser.EMEA_REGION_ADMIN);

        httpSession.setAttribute(BBSConstants.BBS_USER, bbsUser);
        request.setSession(httpSession);
        request.setMethod("GET");
        ModelAndView modelAndView = adminController.handleRequest(request, new MockHttpServletResponse());
        assertEquals("admin/testpath", modelAndView.getViewName());
    }
}
