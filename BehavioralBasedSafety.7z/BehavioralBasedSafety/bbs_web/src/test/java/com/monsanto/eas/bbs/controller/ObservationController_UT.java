/*
 ObservationController_UT was created on Dec 28, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.controller;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class ObservationController_UT {

    @Test
    public void testhandleRequestInternal_ObservationPageDisplayed() throws Exception {
        ObservationController controller = new ObservationController();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setMethod("GET");
        final ModelAndView modelAndView = controller.handleRequest(request, new MockHttpServletResponse());
        assertEquals("observation/observationEntry", modelAndView.getViewName());
    }
}