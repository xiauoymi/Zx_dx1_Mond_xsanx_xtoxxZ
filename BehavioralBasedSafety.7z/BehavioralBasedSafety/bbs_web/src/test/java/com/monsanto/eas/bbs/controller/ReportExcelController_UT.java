/*
 ObservationController_UT was created on Dec 28, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.controller;

import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.service.ObservationService;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author VRBETHI
 * @version $Revision$
 */
public class ReportExcelController_UT {

    @Test
    public void testhandleRequestInternal_ReportPageDisplayed() throws Exception {
        ObservationService observationService = new MockObservationSerice();
        ReportExcelController controller = new ReportExcelController(observationService);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setMethod("GET");

        request.setParameter("languageId", "1");
        request.setParameter("languageDesc", "1");
        request.setParameter("plantId", "1");
        request.setParameter("plantName1", "1");
        request.setParameter("dateFormat", "1");
        request.setParameter("dateFrom", "08/17/1977");
        request.setParameter("dateTo", "08/17/1977");
        request.setParameter("categoryTypeIds", "1");
        request.setParameter("categoryTypeDesc", "1");
        request.setParameter("responseId", "1");
        request.setParameter("responseDesc", "1");
        request.setParameter("showDialogForResponse", "1");

        final ModelAndView modelAndView = controller.handleRequest(request, new MockHttpServletResponse());
        Map map = modelAndView.getModel();
        assertNotNull(map.get("observations"));
    }

    private class MockObservationSerice implements ObservationService {
        public void addObservation(Observation observation) {
        }

        public void updateObservation(Observation observation) {
        }

        public Observation lookupObservation(Long id) {
            return null;
        }

        public List<Observation> lookupObservations(ReportCriteria reportCriteria) {
            return new ArrayList();
        }

        public void inactivateObservation(Observation observation) {
        }

    }
}