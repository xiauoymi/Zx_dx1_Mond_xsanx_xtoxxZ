/*
 ReportExcelView_UT was created on Feb 9, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.controller;

import com.google.common.collect.Lists;
import com.monsanto.eas.bbs.filter.BBSConstants;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.ReportCriteria;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class ReportExcelView_UT {

    @Test
    public void testBuildExcelDocument() throws Exception {
        MockReportExcelView view = new MockReportExcelView();
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        HSSFWorkbook workbook = new HSSFWorkbook();
        Map model = new HashMap();
        ReportCriteria criteria = new ReportCriteria();
        criteria.setDateFormat("DD/MM/YYYY");
        Language lang = new Language();
        lang.setId(new Long(12));
        lang.setDescription("Lang 12");
        criteria.setLanguage(lang);

        CategoryType catType = new CategoryType();
        catType.setId(1L);

        LanguageCategoryType languageCategoryType = new LanguageCategoryType();
        languageCategoryType.setDescription("Cat Type 34");
        LanguageCategoryTypePK catPK = new LanguageCategoryTypePK();
        catPK.setCategoryType(catType);
        catPK.setLanguage(lang);
        languageCategoryType.setId(catPK);

        criteria.setDateFrom(new Date());
        criteria.setDateTo(new Date());

        criteria.setLanguageCategoryTypeList(Lists.newArrayList(languageCategoryType));
        model.put("reportCriteria", criteria);
        List<Observation> observations = new ArrayList<Observation>();
        model.put("observations", observations);

        request.setParameter("locale", "tr");
        view.buildExcelDocument(model, workbook, request, response);
        HSSFSheet sheet = workbook.getSheet(BBSConstants.OBSERVATIONS);
        assertNotNull(sheet);
        HSSFRow header = sheet.getRow(1);
        assertEquals("Lang 12", header.getCell((short) 0).getStringCellValue());
    }

    private class MockReportExcelView extends ReportExcelView {
        @Override
        protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request,
                                          HttpServletResponse response) throws IOException {
            super.buildExcelDocument(model, workbook, request, response);
        }
    }
}