package com.monsanto.eas.bbs.controller.admin;

import com.google.common.collect.Lists;
import com.monsanto.eas.bbs.model.report.Contractor;
import com.monsanto.eas.bbs.model.report.Report;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.DelegatingServletOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReportExcelView_MT
{
    @Mock private HttpServletRequest request;
    @Mock private HttpServletResponse response;

    @Before
    public void setUp() throws Exception {
        when(response.getOutputStream()).thenReturn(new DelegatingServletOutputStream(new FileOutputStream("Report.xls")));
    }

    @Test
    public void testBuildExcelDocument() throws Exception {
        ReportExcelView view = new ReportExcelView();
        final List<Object> items = Lists.newArrayList();
        items.add(new Contractor("Fernanda", "Calissi", "FNCALI", "'Inactive' Monsanto - Itai", "Sudeste", "Active"));
        items.add(new Contractor("Julianderson", "Lourenço", "AND20100036", "Andirá", "Labor Trabalho Temporário", "Active"));

        Map model = new HashMap();
        model.put("report", new Report(items));
        view.render(model, request, response);
    }
}