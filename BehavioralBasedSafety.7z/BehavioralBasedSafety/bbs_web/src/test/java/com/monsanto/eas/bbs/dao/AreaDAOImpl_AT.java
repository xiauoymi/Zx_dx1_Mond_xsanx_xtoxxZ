/*
 AreaDAOImpl_AT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class AreaDAOImpl_AT {
    @Autowired
    AreaDAO areaDao = null;
    @Autowired
    LanguageBasedAreaDAO languageBasedAreaDAO = null;
    @Autowired
    PlantDAO plantDao = null;
    @Autowired
    LanguageDAO langageDao = null;
    @Autowired
    TestDAOImpl testDao = null;
    Plant plant1;
    Language language1;
    Area area1, area2, area3;
    Area subArea1, subArea2, subArea3;

    @Before
    public void setUp() {
        language1 = new Language();
        language1.setDescription("Langugage 1 for AT");
        language1.setActive(true);
        langageDao.addLanguage(language1);
        plant1 = new Plant();
        plant1.setPlantName1("Plant name 1 for AT");
        plant1.setActive(true);
        plantDao.addPlant(plant1);
        area1 = new Area();
        area1.setActive(true);
        areaDao.saveOrUpdateArea(area1);
        area2 = new Area();
        area2.setActive(true);
        areaDao.saveOrUpdateArea(area2);
        area3 = new Area();
        area3.setActive(false);
        areaDao.saveOrUpdateArea(area3);
        subArea1 = new Area();
        subArea1.setParentArea(area1);
        subArea1.setActive(true);
        areaDao.saveOrUpdateArea(subArea1);
        subArea2 = new Area();
        subArea2.setParentArea(area1);
        subArea2.setActive(false);
        areaDao.saveOrUpdateArea(subArea2);
        subArea3 = new Area();
        subArea3.setParentArea(area1);
        subArea3.setActive(true);
        areaDao.saveOrUpdateArea(subArea3);

        LanguageBasedArea languageBasedArea1 = new LanguageBasedArea();
        languageBasedArea1.setDescription("New Area 1 for AT");
        LanguageBasedAreaPK areaPK = new LanguageBasedAreaPK();
        areaPK.setArea(area1);
        areaPK.setLanguage(language1);
        languageBasedArea1.setId(areaPK);
        testDao.saveOrUpdate(languageBasedArea1);

        LanguageBasedArea languageBasedArea2 = new LanguageBasedArea();
        languageBasedArea2.setDescription("New Area 2 for AT");
        LanguageBasedAreaPK areaPK2 = new LanguageBasedAreaPK();
        areaPK2.setArea(area2);
        areaPK2.setLanguage(language1);
        languageBasedArea2.setId(areaPK2);
        testDao.saveOrUpdate(languageBasedArea2);

        LanguageBasedArea languageBasedArea3 = new LanguageBasedArea();
        languageBasedArea3.setDescription("New Area 3 for AT");
        LanguageBasedAreaPK areaPK3 = new LanguageBasedAreaPK();
        areaPK3.setArea(area3);
        areaPK3.setLanguage(language1);
        languageBasedArea3.setId(areaPK3);
        testDao.saveOrUpdate(languageBasedArea3);

        LanguageBasedArea languageBasedSubArea1 = new LanguageBasedArea();
        languageBasedSubArea1.setDescription("New Sub Area 1 for AT");
        LanguageBasedAreaPK subAreaPK = new LanguageBasedAreaPK();
        subAreaPK.setArea(subArea1);
        subAreaPK.setLanguage(language1);
        languageBasedSubArea1.setId(subAreaPK);
        testDao.saveOrUpdate(languageBasedSubArea1);

        LanguageBasedArea languageBasedSubArea2 = new LanguageBasedArea();
        languageBasedSubArea2.setDescription("New Sub Area 2 for AT");
        LanguageBasedAreaPK subAreaPK2 = new LanguageBasedAreaPK();
        subAreaPK2.setArea(subArea2);
        subAreaPK2.setLanguage(language1);
        languageBasedSubArea2.setId(subAreaPK2);
        testDao.saveOrUpdate(languageBasedSubArea2);

        LanguageBasedArea languageBasedSubArea3 = new LanguageBasedArea();
        languageBasedSubArea3.setDescription("New Sub Area 3 for AT");
        LanguageBasedAreaPK subAreaPK1 = new LanguageBasedAreaPK();
        subAreaPK1.setArea(subArea3);
        subAreaPK1.setLanguage(language1);
        languageBasedSubArea3.setId(subAreaPK1);
        testDao.saveOrUpdate(languageBasedSubArea3);

        PlantArea plantArea1 = new PlantArea();
        PlantAreaPk plantAreaPk = new PlantAreaPk();
        plantAreaPk.setArea(area1);
        plantAreaPk.setPlant(plant1);
        plantArea1.setId(plantAreaPk);
        testDao.saveOrUpdate(plantArea1);

        PlantArea plantSubArea1 = new PlantArea();
        PlantAreaPk plantSubAreaPK1 = new PlantAreaPk();
        plantSubAreaPK1.setArea(subArea1);
        plantSubAreaPK1.setPlant(plant1);
        plantSubArea1.setId(plantSubAreaPK1);
        testDao.saveOrUpdate(plantSubArea1);
    }

    /*
    @Test
    public void testLookupAreas_AreaIsReturned() throws Exception {
        Area area = areaDao.lookupArea("New Area 1 for AT", language1);
        assertNotNull(area);
    }
    */

    @Test
    public void testLookupAreasForAPlant_WithPlant_ListOfAreasReturned() throws Exception {
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreas(plant1, language1, true);
        assertTrue(areas.size() == 1);
        assertEquals("New Area 1 for AT", areas.get(0).getDescription());
    }

    @Test
    public void testLookupAreasForAPlant_NoPlant_ListOfAreasReturned() throws Exception {
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreas(null, language1, true);
        assertTrue(areas.size() == 2);
        assertEquals("New Area 1 for AT", areas.get(0).getDescription());
        assertEquals("New Area 2 for AT", areas.get(1).getDescription());
    }

    @Test
    public void testLookupAreasForAPlant_NoPlantInactiveArea_ListOfAreasReturned() throws Exception {
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreas(null, language1, false);
        assertTrue(areas.size() == 1);
        assertEquals("New Area 3 for AT", areas.get(0).getDescription());
    }

    @Test
    public void testLookupLanguageBasedAreasWithInactiveSubAreas_ListOfAreasReturned() throws Exception {
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreasWithInactiveSubAreas(language1);
        assertTrue(areas.size() == 1);
        assertEquals("New Area 1 for AT", areas.get(0).getDescription());
    }

    @Test
    public void testLookupAvailableAreasForPlant_ListOfAreasReturned() throws Exception {
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupAvailableAreasForPlant(plant1, language1);
        assertTrue(areas.size() == 1);
        assertEquals("New Area 2 for AT", areas.get(0).getDescription());
    }

    @Test
    public void testLookupSubAreasForAnArea_NoPlantActiveSubArea_ListOfSubAreasReturned() throws Exception {
        List<LanguageBasedArea> subAreas = languageBasedAreaDAO.lookupSubAreasForAnArea(area1, null, language1, true);
        assertEquals(2, subAreas.size());
//    assertEquals("New Sub Area 1 for AT", subAreas.get(0).getDescription());
        assertNotNull(subAreas.get(0).getDescription());
    }

    @Test
    public void testLookupSubAreasForAnArea_NoPlantInactiveSubArea_ListOfSubAreasReturned() throws Exception {
        List<LanguageBasedArea> subAreas = languageBasedAreaDAO.lookupSubAreasForAnArea(area1, null, language1, false);
        assertEquals(1, subAreas.size());
        assertEquals("New Sub Area 2 for AT", subAreas.get(0).getDescription());
    }

    @Test
    public void testLookupSubAreasForAnArea_PlantActiveSubArea_ListOfSubAreasReturned() throws Exception {
        List<LanguageBasedArea> subAreas = languageBasedAreaDAO.lookupSubAreasForAnArea(area1, plant1, language1, true);
        assertEquals(1, subAreas.size());
        assertEquals("New Sub Area 1 for AT", subAreas.get(0).getDescription());
    }

    @Test
    public void testLookupSubAreasNotAssociatedWithThisPlant_ListOfSubAreasReturned() throws Exception {
        List<LanguageBasedArea> subAreas = languageBasedAreaDAO.lookupAvailableSubAreasForPlant(area1, plant1, language1);
        assertEquals(1, subAreas.size());
        assertEquals("New Sub Area 3 for AT", subAreas.get(0).getDescription());
    }

    @Test
    public void testLookupSubAreas() throws Exception {
        final List<Area> subAreas = areaDao.lookupSubAreas(area1);
        assertEquals(2, subAreas.size());
    }

    @Test
    public void testLookupLanguageBasedParentAreaAndSubAreas() throws Exception {
        List<LanguageBasedArea> subAreas = languageBasedAreaDAO.lookupAllSubAreasByAreaAndLanguage(area1, language1);
        assertEquals(2, subAreas.size());
        assertEquals("New Sub Area 1 for AT", subAreas.get(0).getDescription());
    }

    @Test
    public void testAddPlantArea() throws Exception {
        area3.setActive(true);
        areaDao.addPlantArea(plant1, area3);
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreas(plant1, language1, true);
        assertTrue(area3.isActive());
        assertEquals(2, areas.size());
        assertEquals("New Area 1 for AT", areas.get(0).getDescription());
        assertEquals("New Area 3 for AT", areas.get(1).getDescription());
    }
    //todo sonal to fix this test.
//  @Test
//  public void testDeletePlantArea() throws Exception {
//    areaDao.deletePlantArea(plant1, area1);
//    List<LanguageBasedArea> areas = areaDao.lookupLanguageBasedAreas(plant1, language1, true);
//    assertEquals(0, areas.size());
//  }

    @Test
    public void testSaveLanguageBasedArea() throws Exception {
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("New saved area");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area newArea = new Area();
        newArea.setActive(true);
        pk.setArea(newArea);
        pk.setLanguage(language1);
        lba.setId(pk);
        languageBasedAreaDAO.saveLanguageBasedArea(lba);
        List<LanguageBasedArea> areas = languageBasedAreaDAO.lookupLanguageBasedAreas(null, language1, true);
        assertEquals(3, areas.size());
        assertEquals("New saved area", areas.get(2).getDescription());
    }

}