/*
 AreaDAOImpl_UT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional

public class AreaDAOImpl_UT {

    @Autowired
    AreaDAO areaDAO;

    //@Ignore("Comment out to test with the SpringJUnit4ClassRunner")
    @Test
    public void testLookupAreaById() {
        Area area = areaDAO.lookupAreaById(new Long(6577154));

        assertNotNull("This area should not be null, as it exists " + area.getId(), area);
    }

    @Test
    public void testLookupAllParentAreas() throws Exception {
        AreaDAOImpl dao = new AreaDAOImpl();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS();
        dao.setSessionFactory(mockSessionFactory);

        List<Area> areas = dao.lookupAllParentAreas();
        assertEquals(0, areas.size());
    }

    @Test
    public void testSaveOrUpdateArea() throws Exception {
        AreaDAOImpl dao = new AreaDAOImpl();
        List resultList = new ArrayList<Area>();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(resultList);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, resultList);
        dao.setHibernateTemplate(mockTemplate);

        Area area = new Area();
        area.setId(new Long(1));
        area.setActive(true);
        area.setLevel(1);
        area.setParentArea(null);

        dao.saveOrUpdateArea(area);

        Area searchedArea = dao.lookupAreaById(area.getId());

        assertNotNull("This are should exist, as it was just inserted " + area.getId(), searchedArea);
    }

    @Test
    public void testLookupSubAreas() {
        Area area = new Area();
        area.setId(new Long(6577165));
        area.setActive(true);
        area.setLevel(1);
        area.setParentArea(null);

        List<Area> areaList = areaDAO.lookupSubAreas(area);
        assertNotNull("This list should not be null", areaList);
        assertTrue("This list should have returned more than one subArea for this parent " + area.getId(), areaList.size() > 1);
    }

    @Test
    public void testAddPlantArea() {
        AreaDAOImpl dao = new AreaDAOImpl();
        List resultList = new ArrayList();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(resultList);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, resultList);
        dao.setHibernateTemplate(mockTemplate);

        Plant plant = new Plant();
        plant.setActive(true);
        plant.setId(new Long(5373279));
        plant.setPlantCode("3000");
        plant.setPlantName1("St Louis MO");

        Area area = new Area();
        area.setId(new Long(6577165));
        area.setActive(true);
        area.setLevel(1);
        area.setParentArea(null);

        dao.addPlantArea(plant, area);

        Area searchedArea = dao.lookupAreaById(area.getId());

        assertNotNull("area wasn't added", searchedArea);
    }

    @Test
    public void testDeletePlantArea() {
        AreaDAOImpl dao = new AreaDAOImpl();
        List resultList = new ArrayList();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(resultList);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, resultList);
        dao.setHibernateTemplate(mockTemplate);

        Plant plant = new Plant();
        plant.setActive(true);
        plant.setId(new Long(5373279));
        plant.setPlantCode("3000");
        plant.setPlantName1("St Louis MO");

        Area area = new Area();
        area.setId(new Long(6577165));
        area.setActive(true);
        area.setLevel(1);
        area.setParentArea(null);

        dao.deletePlantArea(plant, area);

        Area searchedArea = dao.lookupAreaById(area.getId());

        assertNull("area wasn't removed", searchedArea);
    }

}
