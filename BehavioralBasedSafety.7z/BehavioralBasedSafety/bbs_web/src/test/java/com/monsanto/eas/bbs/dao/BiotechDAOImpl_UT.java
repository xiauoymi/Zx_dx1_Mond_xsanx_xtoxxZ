package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/15/14
 * Time: 12:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class BiotechDAOImpl_UT {

    @Test
    public void testAddBiotechProgram() {
        BiotechDAOImpl biotechDAO = new BiotechDAOImpl();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(new ArrayList<BiotechProgram>());
        biotechDAO.setHibernateTemplate(mockTemplate);

        BiotechProgram biotechProgram = new BiotechProgram();

        List<BiotechProgram> biotechProgramList = biotechDAO.getAllBiotechPrograms();

        assertEquals("before inserting, there shouldn't be any biotech program", 0, biotechProgramList.size());

        biotechDAO.addBiotechProgram(biotechProgram);

        assertEquals("after inserting, there should be 1 biotech program", 1, biotechProgramList.size());
    }

    @Test
    public void testAddBiotechProjectPlatform() {
        BiotechDAOImpl biotechDAO = new BiotechDAOImpl();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(new ArrayList<BiotechProjectPlatform>());
        biotechDAO.setHibernateTemplate(mockTemplate);

        BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();

        List<BiotechProjectPlatform> biotechProjectPlatforms = biotechDAO.getAllBiotechProjects();

        assertEquals("before inserting, there shouldn't be any biotech project", 0, biotechProjectPlatforms.size());

        biotechDAO.addBiotechProjectPlatform(biotechProjectPlatform);

        assertEquals("after inserting, there should be 1 biotech project", 1, biotechProjectPlatforms.size());
    }

    @Test
    public void testLookupBiotechProgramsForPlant() {
        BiotechDAOImpl biotechDAO = new BiotechDAOImpl();

        List<BiotechProgram> biotechProgramList = new ArrayList<BiotechProgram>();

        BiotechProgram biotechProgram = new BiotechProgram();
        BiotechProgram biotechProgram2 = new BiotechProgram();

        biotechProgramList.add(biotechProgram);
        biotechProgramList.add(biotechProgram2);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(biotechProgramList);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, biotechProgramList);
        biotechDAO.setHibernateTemplate(mockTemplate);

        Plant plant = new Plant();
        plant.setPlantCode("3000");

        List<BiotechProgram> totalBiotechProgramList = biotechDAO.lookupBiotechProgramsForPlant(plant);

        assertEquals("There should be 2 biotech programs", 2, totalBiotechProgramList.size());
    }


    @Test
    public void testLookupBiotechProjectsForProgram() {
        BiotechDAOImpl biotechDAO = new BiotechDAOImpl();

        List<BiotechProjectPlatform> biotechProjectPlatforms = new ArrayList<BiotechProjectPlatform>();

        BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();
        BiotechProjectPlatform biotechProjectPlatform2 = new BiotechProjectPlatform();

        biotechProjectPlatforms.add(biotechProjectPlatform);
        biotechProjectPlatforms.add(biotechProjectPlatform2);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(biotechProjectPlatforms);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, biotechProjectPlatforms);
        biotechDAO.setHibernateTemplate(mockTemplate);

        BiotechProgram biotechProgram = new BiotechProgram();
        biotechProgram.setId(new Long(1));

        List<BiotechProjectPlatform> totalBiotechProjectPlatform = biotechDAO.lookupBiotechProjectsForProgram(biotechProgram);

        assertEquals("There should be 2 biotech projects", 2, totalBiotechProjectPlatform.size());
    }
}
