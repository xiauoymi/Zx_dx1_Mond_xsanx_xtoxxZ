/*
 CategoryTypeDAOImpl_AT was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class CategoryDAOImpl_AT {
    @Autowired
    private CategoryDAO categoryDao = null;
    @Autowired
    LanguageDAO langageDao = null;
    @Autowired
    TestDAOImpl testDao = null;

    Language language;
    CategoryType categoryType;
    LanguageCategoryType languageCategoryType;
    Category category;
    Category subCategory;

    private Category subSubCategory;


    @Before
    public void setUp() {
        language = new Language();
        language.setDescription("Langugage 1 for AT");
        language.setActive(true);
        langageDao.addLanguage(language);

        categoryType = new CategoryType();
        categoryType.setActive(true);
        testDao.saveOrUpdate(categoryType);

        languageCategoryType = new LanguageCategoryType();
        LanguageCategoryTypePK pk = new LanguageCategoryTypePK();
        pk.setCategoryType(categoryType);
        pk.setLanguage(language);
        languageCategoryType.setId(pk);
        languageCategoryType.setDescription("Category Type 1 for Lang 1 for AT");
        testDao.saveOrUpdate(languageCategoryType);

        category = new Category();
        category.setActive(true);
        categoryDao.saveOrUpdateCategory(category);
        subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        categoryDao.saveOrUpdateCategory(subCategory);
        subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setActive(true);
    }

    @Test
    public void LookupAllCategories_ListOfCategoriesReturned_AllAreActive() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(2));
        CategoryType catType = new CategoryType();
        catType.setId(new Long(2));

        boolean onlyActiveCategories = true;

        List<LanguageBasedCategory> categories = categoryDao.lookupLanguageBasedCategoriesByType(lang, catType, onlyActiveCategories);
        assertTrue(categories.size() >= 2);
        for (LanguageBasedCategory category : categories) {
            assertNotNull(category);
        }
    }

    @Test
    public void LookupLanguageCategoryTypes_ListOfCategoryTypesReturned_AllAreActive() throws Exception {
        List<LanguageCategoryType> types = categoryDao.lookupLanguageCategoryTypes(language);
        assertEquals(1, types.size());
        assertEquals("Category Type 1 for Lang 1 for AT", types.get(0).getDescription());
    }

    @Test
    public void LookupSubCategoriesForCategory_ListOfCategoryTypesReturned_AllAreActive() throws Exception {
        Category cat = new Category();
        cat.setId(new Long(7790053));
        List<Category> types = categoryDao.lookupSubCategoriesForCategory(cat);
        assertTrue(types.size() >= 2);
    }

    @Test
    public void lookupLanguageBasedSubCategoryByDescriptionAndType() throws Exception {
        Category cat = new Category();
        cat.setId(new Long(6577138));
        Language lang = new Language();
        lang.setId(new Long(2));
        CategoryType catType = new CategoryType();
        catType.setId(new Long(2));
        final LanguageBasedCategory basedCategory = categoryDao
                .lookupLanguageBasedSubCategoryByDescriptionAndType("Body Movement",
                        cat, lang, catType);
        assertNotNull(basedCategory);
    }

    @Test
    public void saveLanguageBasedCategory_Saved() throws Exception {
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("new cat");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category cat = new Category();
        CategoryType type = new CategoryType();
        type.setId(new Long(2));
        cat.setCategoryType(type);
        pk.setCategory(cat);
        Language lang = new Language();
        lang.setId(new Long(2));
        pk.setLanguage(lang);
        lbc.setId(pk);
        categoryDao.saveLanguageBasedCategory(lbc);
    }

    @Test
    public void saveLanguageBarrierCategory_Saved() throws Exception {
        LanguageBarrierCategory lbc = new LanguageBarrierCategory();
        lbc.setDescription("new ba from test - updated");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();

        Category cat = new Category();
        cat.setId(new Long(6577138));
        Language lang = new Language();
        lang.setId(new Long(2));
        CategoryType catType = new CategoryType();
        catType.setId(new Long(2));
        final LanguageBasedCategory basedCategory = categoryDao
                .lookupLanguageBasedSubCategoryByDescriptionAndType("Body Movement",
                        cat, lang, catType);

        BarrierCategory barrier = new BarrierCategory();
        barrier.setId(new Long(1495350));
        barrier.setCategory(basedCategory.getId().getCategory());
        pk.setBarrierCategory(barrier);
        pk.setLanguage(lang);
        lbc.setId(pk);
        categoryDao.saveLanguageBarrierCategory(lbc);
    }

    @Test
    public void LookupAllSubCategoriesForACategory_ListOfSubCategoriesReturned_AllAreActive() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        Category cat = new Category();
        cat.setId(new Long(6577138));
        List<LanguageBasedCategory> categories = categoryDao.lookupAllSubCategoriesForACategory(lang, cat, true);
        assertTrue(categories.size() > 0);
        for (LanguageBasedCategory subCat : categories) {
            assertTrue(subCat.getId().getCategory().isActive());
            assertEquals(cat.getId(), subCat.getId().getCategory().getParentCategory().getId());
        }
    }

    @After
    public void tearDown() {
        categoryDao.deleteCategory(category);
        categoryDao.deleteCategory(subCategory);
    }
}