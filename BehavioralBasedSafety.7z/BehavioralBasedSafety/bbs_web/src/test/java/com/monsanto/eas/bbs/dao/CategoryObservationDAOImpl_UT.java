package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.CategoryObservation;
import com.monsanto.eas.bbs.hibernate.Response;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/15/14
 * Time: 4:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class CategoryObservationDAOImpl_UT {

    @Test
    public void testDeleteCategoryObservation() {
        CategoryObservationDAOImpl categoryObservationDAO = new CategoryObservationDAOImpl();

        List<CategoryObservation> categoryObservationList = new ArrayList<CategoryObservation>();
        CategoryObservation categoryObservation = new CategoryObservation();
        categoryObservation.setId(new Long(1));

        categoryObservationList.add(categoryObservation);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(categoryObservationList);
        categoryObservationDAO.setHibernateTemplate(mockHibernateTemplate);

        assertEquals("Before deleting, the list contains 1 element", 1, categoryObservationList.size());

        categoryObservationDAO.deleteCategoryObservation(categoryObservation);

        assertEquals("after deleting, the list contains 0 elements", 0, categoryObservationList.size());
    }


    @Test
    public void testDeleteCategoryObservationInNAStatus() {
        CategoryObservationDAOImpl categoryObservationDAO = new CategoryObservationDAOImpl();

        List<CategoryObservation> categoryObservationList = new ArrayList<CategoryObservation>();
        CategoryObservation categoryObservation = new CategoryObservation();
        categoryObservation.setId(new Long(1));

        Response response = new Response();
        response.setActive(true);
        response.setDefaultOption(true);

        CategoryObservation categoryObservation2 = new CategoryObservation();
        categoryObservation2.setId(new Long(2));
        categoryObservation2.setResponse(response);

        Response response2 = new Response();
        response2.setActive(true);
        response2.setDefaultOption(false);

        CategoryObservation categoryObservation3 = new CategoryObservation();
        categoryObservation3.setId(new Long(3));
        categoryObservation3.setResponse(response2);

        categoryObservationList.add(categoryObservation);
        categoryObservationList.add(categoryObservation2);
        categoryObservationList.add(categoryObservation3);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(categoryObservationList);
        categoryObservationDAO.setHibernateTemplate(mockHibernateTemplate);

        assertEquals("Before deleting, the list contains 3 elements", 3, categoryObservationList.size());

        categoryObservationDAO.deleteCategoryObservationInNAStatus(categoryObservationList);

        assertEquals("after deleting, the list contains 2 elements", 2, categoryObservationList.size());
    }
}
