package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 21, 2010
 * Time: 4:13:07 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class CountryDAOImpl_AT {

    @Autowired
    protected CountryDAO countryDao = null;

    @Autowired
    protected RegionDAO regionDAO = null;

    private Country getDummyCountry() {
        Country country = new Country();
        country.setDescription("Country Test");
        country.setActive(true);
        country.setCountryCode("CT");
        country.setRegionId(new Long(1));
        country.setShowEnvironmentTab(true);

        return country;
    }

    @Test
    public void testAddCountry() {
        Country country = getDummyCountry();

        Country tempCountry = countryDao.lookupCountryByCountryCode( country.getCountryCode() );

        assertNull("Before inserting, country should not exist", tempCountry);

        countryDao.addCountry(country);

        tempCountry = countryDao.lookupCountryByCountryCode( country.getCountryCode() );

        assertNotNull("after inserting, country should exist", tempCountry);
    }

    @Test
    public void testDeleteCountry() {
        Country country = getDummyCountry();

        String countryCode = country.getCountryCode();

        countryDao.deleteCountry(country);

        country = countryDao.lookupCountryByCountryCode( countryCode );

        assertNull("after deleting, country should be null", country);
    }

    @Test
    public void testActivateInactivateEnvironmentalTabByRegion_Activated() {
        long regionId = 5l;

        Region region = new Region();
        region.setDescription("NORTH AMERICA");
        region.setId(regionId);

        boolean activeFlagStatusToSet = true;

        countryDao.activateInactivateEnvironmentalTabByRegion(region, activeFlagStatusToSet);

        List<Country> countryByRegionList = countryDao.lookupActiveCountriesByRegionID( new Long[] {regionId} );

        for(Country country : countryByRegionList){
            assertTrue("show environmental tab for this region should be " + activeFlagStatusToSet, country.isShowEnvironmentTab());
        }
    }

    @Test
    public void testActivateInactivateEnvironmentalTabByRegion_Inactivated() {
        long regionId = 5l;

        Region region = new Region();
        region.setDescription("NORTH AMERICA");
        region.setId( regionId );

        boolean activeFlagStatusToSet = false;

        countryDao.activateInactivateEnvironmentalTabByRegion(region, activeFlagStatusToSet);

        List<Country> countryByRegionList = countryDao.lookupActiveCountriesByRegionID( new Long[] {regionId} );

        for(Country country : countryByRegionList){
            assertFalse("show environmental tab for this region should be " + activeFlagStatusToSet, country.isShowEnvironmentTab());
        }
    }

    @Test
    public void testLookupActiveCountries() {
        List<Country> activeCountryList = countryDao.lookupActiveCountries();

        assertTrue("active country list should be greater than 0", activeCountryList.size() >= 1);

        for(Country country : activeCountryList){
            assertTrue("Country should be active", country.isActive());
        }
    }

    @Test
    public void testLookupActiveCountriesWithValidRegionID(){
        List<Country> activeCountryList = countryDao.lookupActiveCountriesWithValidRegionID();

        assertTrue("active country list should be greater than 0", activeCountryList.size() >= 1);

        for(Country country : activeCountryList){
            assertTrue("Country should be active and regionId should not be null", country.isActive() && country.getRegionId() != null);
        }
    }

    @Test
    public void testActivateInactivateEnvironmentalTabByCountry() {
        Country tempCountry = countryDao.lookupCountryByCountryCode( "US" );
        boolean initialStatusOfTheShowEnvTabProperty = tempCountry.isShowEnvironmentTab();

        boolean statusToSetForTheShowEnvTabProperty = ! initialStatusOfTheShowEnvTabProperty;

        countryDao.activateInactivateEnvironmentalTabByCountry(tempCountry, statusToSetForTheShowEnvTabProperty);

        tempCountry = countryDao.lookupCountryByCountryCode( "US" );
        boolean statusOfTheShowEnvTabPropertyAfterBeingActivatedInactivated = tempCountry.isShowEnvironmentTab();

        assertTrue("The ShowEnvTabProperty for the country was changed",
                initialStatusOfTheShowEnvTabProperty != statusOfTheShowEnvTabPropertyAfterBeingActivatedInactivated);
    }

    private BBSUser getDummyBBSUser(String userRoleDescription, long userCountryId, long userRegionId){
        Set roles = new HashSet();
        BBSRole role = new BBSRole();
        role.setDescription(userRoleDescription);
        roles.add(role);

        Country country = new Country();
        //country.setDescription("USA");
        country.setId(userCountryId);
        //country.setActive(true);
        //country.setCountryCode("US");
        country.setRegionId(userRegionId);

        Plant plant = new Plant();
        /*
        plant.setId(new Long(5373279));
        plant.setActive(true);
        plant.setPlantName1("St Louis MO");
        plant.setPlantCode("3000");
        */
        plant.setCountry(country);

        BBSUser bbsUser = new BBSUser();
        bbsUser.setPlant(plant);

        if(null != userRoleDescription){
            bbsUser.setRoles(roles);
        }

        return bbsUser;
    }


    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_NO_ROLE_AND_NOT_EMEA() {
        String userRoleDescription = null;
        long userCountryId = 232l;  //-- US
        long userRegionId = 5l;     //-- NORTH AMERICA
        BBSUser bbsUser = getDummyBBSUser(userRoleDescription, userCountryId, userRegionId);

        String regionIdSearched = "5";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertEquals("Not EMEA users and without role have access to all the countries", totalActiveCountriesByRegion, countryList.size());
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_NO_ROLE_AND_EMEA() {
        String userRoleDescription = null;
        long userCountryId = 75l; //-- FRANCE
        long userRegionId = 1l;   //-- EMEA

        BBSUser bbsUser = getDummyBBSUser(userRoleDescription, userCountryId, userRegionId);

        String regionIdSearched = "5";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertTrue( totalActiveCountriesByRegion != countryList.size());
        assertTrue( totalActiveCountriesByRegion > countryList.size());
        assertTrue("EMEA users don't have access to other regions", countryList.size() == 0);
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_NO_ROLE_AND_EMEA_USER_AND_REGION() {
        String userRoleDescription = null;
        long userCountryId = 75l; //-- FRANCE
        long userRegionId = 1l;   //-- EMEA

        BBSUser bbsUser = getDummyBBSUser(userRoleDescription, userCountryId, userRegionId);

        String regionIdSearched = "1";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertTrue( totalActiveCountriesByRegion != countryList.size());
        assertTrue( totalActiveCountriesByRegion > countryList.size());
        assertTrue("EMEA users have access only to their own site", countryList.size() == 1);
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_GLOBAL_LEAD() {
        long userCountryId = 232l;
        long userRegionId = 5l;

        BBSUser bbsUser = getDummyBBSUser(BBSUser.GLOBAL_LEAD, userCountryId, userRegionId);

        String regionIdSearched = "5";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertEquals("GLOBAL LEAD should have access to all the countries", totalActiveCountriesByRegion, countryList.size());
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_ESH_ADMIN() {
        long userCountryId = 232l;
        long userRegionId = 5l;

        BBSUser bbsUser = getDummyBBSUser(BBSUser.ESH_ADMIN, userCountryId, userRegionId);

        String regionIdSearched = "5";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertEquals("ESH_ADMIN's not from EMEA have the same access as GLOBAL_ADMINS", totalActiveCountriesByRegion, countryList.size());
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_EMEA_ESH_ADMIN_LookingADifferentRegion() {
        long userCountryId = 75l; //-- FRANCE
        long userRegionId = 1l;   //-- EMEA

        BBSUser bbsUser = getDummyBBSUser(BBSUser.ESH_ADMIN, userCountryId, userRegionId);

        String regionIdSearched = "5";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertEquals("ESH_ADMIN's not from EMEA have the same access as GLOBAL_ADMINS", totalActiveCountriesByRegion, countryList.size());
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole_EMEA_ESH_ADMIN_LookingIntoTheirOwnRegion() {
        long userCountryId = 75l; //-- FRANCE
        long userRegionId = 1l;   //-- EMEA

        BBSUser bbsUser = getDummyBBSUser(BBSUser.ESH_ADMIN, userCountryId, userRegionId);

        String regionIdSearched = "1";

        int totalActiveCountriesByRegion = countryDao.lookupActiveCountriesByRegionID( new Long[] {Long.parseLong(regionIdSearched)} ).size();

        String userOwnsRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);
        List<Country> countryList = countryDao.lookupActiveCountriesByRegionIDAndByUserRole(regionIdSearched, bbsUser, userOwnsRegionDesc);

        assertTrue( "Country by region list should be greater than user's own country list", totalActiveCountriesByRegion > countryList.size());
        assertEquals("ESH_ADMIN looking for more sites into their own region, only have access to their own site",
                1, countryList.size());
    }

}
