/*
 DepartmentDAOImpl_UT was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.Department;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class DepartmentDAOImpl_UT {

    @Test
    public void testLookupDepartmentsByCompanyFlag() {
        DepartmentDAOImpl dao = new DepartmentDAOImpl();

        List<Department> depts = new ArrayList<Department>();
        depts.add(new Department());
        depts.add(new Department());

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(depts);
        dao.setHibernateTemplate(mockTemplate);

        List<Department> departments = dao.lookupDepartmentsByCompanyFlag(true, true);
        assertEquals(2, departments.size());
    }

    @Test
    public void testLookupAllDepartments() throws Exception {
        DepartmentDAOImpl dao = new DepartmentDAOImpl();
        List<Department> depts = new ArrayList<Department>();
        depts.add(new Department());
        depts.add(new Department());

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(depts);
        dao.setHibernateTemplate(mockTemplate);

        List<Department> departments = dao.lookupAllDepartments();
        assertEquals(2, departments.size());
    }

    @Test
    public void testLookupDepartmentByCode_NotFound() throws Exception {
        DepartmentDAOImpl dao = new DepartmentDAOImpl();
        List<Department> depts = new ArrayList<Department>();
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(depts);
        dao.setHibernateTemplate(mockTemplate);

        Department department = dao.lookupDepartmentByCode(new Long(123));
        assertNull(department);
    }

    @Test
    public void testLookupDepartmentByCode_Found() throws Exception {
        DepartmentDAOImpl dao = new DepartmentDAOImpl();
        List<Department> depts = new ArrayList<Department>();
        Department dept = new Department();
        dept.setCode(new Long(123));
        dept.setName("Dept 123");
        depts.add(dept);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(depts);
        dao.setHibernateTemplate(mockTemplate);

        Department department = dao.lookupDepartmentByCode(new Long(123));
        assertNotNull(department);
        assertEquals(new Long(123), department.getCode());
        assertEquals("Dept 123", department.getName());
    }

    @Test
    public void testGetMapOfAllDepartments() {
        DepartmentDAOImpl dao = new DepartmentDAOImpl();
        List<Department> departmentList = getDummyDepartmentList();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(departmentList);
        dao.setHibernateTemplate(mockTemplate);

        Map<Long, Department> departmentMap = dao.getMapOfAllDepartments();

        int zeroBasedCustomIndex = 2;

        assertNotNull(departmentMap);
        assertEquals("Both Departments should match", departmentList.get(zeroBasedCustomIndex), departmentMap.get(new Long(3)));
    }

    private List<Department> getDummyDepartmentList() {
        List<Department> departmentList = new ArrayList<Department>();

        Department dept = new Department();
        dept.setId(new Long(123));
        dept.setCode(new Long(1));
        dept.setName("ACCOUNTING");
        departmentList.add(dept);

        Department dept2 = new Department();
        dept2.setId(new Long(456));
        dept2.setCode(new Long(2));
        dept2.setName("ADMINISTRATION");
        departmentList.add(dept2);

        Department dept3 = new Department();
        dept3.setId(new Long(789));
        dept3.setCode(new Long(3));
        dept3.setName("AGRONOMIC TRAITS");
        departmentList.add(dept3);

        Department dept4 = new Department();
        dept4.setId(new Long(987));
        dept4.setCode(new Long(4));
        dept4.setName("ARCHITECTURE");
        departmentList.add(dept4);

        return departmentList;
    }
}