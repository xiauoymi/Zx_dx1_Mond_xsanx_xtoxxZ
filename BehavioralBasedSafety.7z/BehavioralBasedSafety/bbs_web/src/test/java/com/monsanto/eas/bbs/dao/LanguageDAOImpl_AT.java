/*
 LanguageDAOImpl_AT was created on Dec 28, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.hibernate.Transaction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class LanguageDAOImpl_AT {
    @Autowired
    LanguageDAO languageDAO = null;
    Transaction transaction = null;
    Language language;
    private Category category;
    @Autowired
    private CategoryDAO categoryDao;
    private Category subCategory;
    private Category subSubCategory;

    @Autowired
    private PersonnelTypeDAO personnelTypeDAO;
    private Language lang;
    private Language languageDescription;
    private LanguageBasedLanguageDescription languageBasedLanguageDescription;
    private PersonnelType personnelType;
    private LanguageBasedPersonnelType languageBasedPersonnelType;

    @Autowired
    private LangugeBasedPersonnelTypeDAOImpl langugeBasedPersonnelTypeDAO;
    @Autowired
    private LanguageBasedLanguageDescriptionDAOImpl languageBasedLanguageDescriptionDAO;

    @Before
    public void setUp() {
        category = new Category();
        category.setActive(true);
        categoryDao.saveOrUpdateCategory(category);

        subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        categoryDao.saveOrUpdateCategory(subCategory);

        subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setActive(true);
        categoryDao.saveOrUpdateCategory(subSubCategory);

        language = new Language();
        language.setActive(true);
        language.setDescription("English1");
        language.setLocale("xx");
        languageDAO.addLanguage(language);
        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("CATEGORY FOR XX");
        LanguageBasedCategoryPK pk5 = new LanguageBasedCategoryPK();
        pk5.setLanguage(language);
        pk5.setCategory(category);
        languageBasedCategory.setId(pk5);
        Set<LanguageBasedCategory> categories = new HashSet<LanguageBasedCategory>();
        categories.add(languageBasedCategory);
        language.setLanguageRelatedCategories(categories);
        languageDAO.addLanguage(language);

    }

    @Test
    public void LookupLanguagebyLocale_ReturnsLanguage() throws Exception {
        final Language language1 = languageDAO.lookupLanguageByLocale("en");
        assertNotNull(language1);
    }

    @Test
    public void testLookupAllLanguage_ListOfLanguagesReturned() throws Exception {
        List<Language> languageList = languageDAO.findAll();
        assertTrue(languageList.size() >= 1);
        for (Language lang : languageList) {
            if (lang.getLocale().equalsIgnoreCase("xx")) {
                assertNotNull(lang.getId());
                assertTrue(lang.isActive());
            }
        }
    }

    @Test
    public void LookupLanguageBasedResponses_ListOfResponsesReturned() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(2));
        List<LanguageBasedResponse> responseList = languageDAO.lookupResponsesForALanguage(lang);
        assertEquals(3, responseList.size());
        for (LanguageBasedResponse lbr : responseList) {
            assertNotNull(lbr.getId());
            assertNotNull(lbr.getDescription());
        }
    }

    @Test
    public void LookupLanguageBasedLanguageDescription_ListOfLanguageDescriptionReturned() throws Exception {
        lang = new Language();
        lang.setActive(true);
        lang.setLocale("en");
        languageDAO.addLanguage(lang);

        languageDescription = new Language();
        languageDescription.setActive(true);
        languageDAO.addLanguage(languageDescription);

        languageBasedLanguageDescription = new LanguageBasedLanguageDescription();

        LanguageBasedLanguageDescriptionPK languageBasedLanguageDescriptionPK = new LanguageBasedLanguageDescriptionPK();
        languageBasedLanguageDescriptionPK.setLanguage(lang);
        languageBasedLanguageDescriptionPK.setLanguageDescription(languageDescription);

        languageBasedLanguageDescription.setDescription("Ingles");

        languageBasedLanguageDescription.setId(languageBasedLanguageDescriptionPK);

        languageBasedLanguageDescriptionDAO.save(languageBasedLanguageDescription);

        List<LanguageBasedLanguageDescription> list = languageDAO.lookupLanguagesForALanguage(languageDescription);
        assertTrue(list.size() == 1);
        for (LanguageBasedLanguageDescription lbld : list) {
            assertNotNull(lbld.getId());
            assertNotNull(lbld.getDescription());
            assertEquals("Ingles", lbld.getDescription());
        }
    }

    @Test
    public void LookupLanguageBasedPersonnelTypes_ListOfPersonnelTypesReturned() throws Exception {
        lang = new Language();
        lang.setActive(true);
        lang.setDescription("TestDescription");
//    lang.setId(new Long(2));
        languageDAO.addLanguage(lang);

        personnelType = new PersonnelType();
        personnelType.setActive(true);
        personnelTypeDAO.addPersonnelType(personnelType);

        languageBasedPersonnelType = new LanguageBasedPersonnelType();

        LanguageBasedPersonnelTypePK languageBasedPersonnelTypePK = new LanguageBasedPersonnelTypePK();
        languageBasedPersonnelTypePK.setLanguage(lang);
        languageBasedPersonnelTypePK.setPersonnelType(personnelType);

        languageBasedPersonnelType.setDescription("TPT");

        languageBasedPersonnelType.setId(languageBasedPersonnelTypePK);
//    personnelTypeDAO.addLanguageBasedPersonnelType(languageBasedPersonnelType);
        langugeBasedPersonnelTypeDAO.save(languageBasedPersonnelType);


        List<LanguageBasedPersonnelType> list = languageDAO.lookupPersonnelTypesForALanguage(lang);
        assertTrue(list.size() == 1);
        for (LanguageBasedPersonnelType lbr : list) {
            assertNotNull(lbr.getId());
            assertNotNull(lbr.getDescription());
        }
    }

    //todo get rid of this test or modify this test since admin  functionality is there.
/*
  @Test
  public void LookupLanguageBasedBarriers_ListOfBarriersReturned() throws Exception {
    Language lang = new Language();
    lang.setId(new Long(1));
    Category cat = new Category();
    cat.setId(new Long(197547));
    List<LanguageBarrierCategory> barrierCategoryList = languageDAO.lookupActiveBarriersForALanguageAndSubCategory(lang, cat);
    assertTrue(barrierCategoryList.size()>2);
    for (LanguageBarrierCategory lbr : barrierCategoryList) {
      assertNotNull(lbr.getId());
    }
  }
*/

    @After
    public void tearDown() {
        categoryDao.deleteCategory(subSubCategory);
        categoryDao.deleteCategory(subCategory);
        categoryDao.deleteCategory(category);
        if (languageBasedPersonnelType != null) {
            langugeBasedPersonnelTypeDAO.delete(languageBasedPersonnelType);
        }
        if (languageBasedLanguageDescription != null) {
            languageBasedLanguageDescriptionDAO.delete(languageBasedLanguageDescription);
        }
        if (personnelType != null) {
            personnelTypeDAO.deletePersonnelType(personnelType);
        }
        languageDAO.deleteLanguage(language);
        if (languageDescription != null) {
            languageDAO.deleteLanguage(languageDescription);
        }
        if (lang != null) {
            languageDAO.deleteLanguage(lang);
        }
    }
}