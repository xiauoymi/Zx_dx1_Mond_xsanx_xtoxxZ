/*
 ObservationDAOImpl_AT was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.google.common.collect.Lists;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.ReportCriteria;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ObservationDAOImpl_AT {

    private Category category;
    private Category subCategory;
    private Category subSubCategory;
    @Autowired
    private CategoryDAOImpl categoryDao = null;

    @Autowired
    private PlantDAOImpl plantDao = null;

    @Autowired
    private AreaDAOImpl areaDao = null;

    @Autowired
    private SafetyGroupDAOImpl safetyGroupDAO = null;

    @Autowired
    private ObservationDAO observationDao = null;

    @Autowired
    private UserDAO userDao;

    @Autowired
    private PersonnelTypeDAOImpl personnelTypeDAO = null;

    private Observation observation;
    Plant plant;
    BBSUser user;
    Area area;

    Area subArea;
    SafetyGroup group;
    Response response;
    PersonnelType personnelType;

    @Before
    public void setUp() {

        plant = new Plant();
        plantDao.addPlant(plant);

        observation = new Observation();
        observation.setPlant(plant);
        group = new SafetyGroup();
        group.setPlant(plant);
        group.setGroupText("TEST");
        group.setActive(true);
        safetyGroupDAO.addSafetyGroup(group);

        observation.setSafetyGroup(group);
        observation.setPersonnelType(personnelType);
        observation.setArea(area);
        observation.setActive(true);

    }

    @Test
    public void testAddObservation_ObservationSaved() throws Exception {
        observationDao.save(observation);
        Observation observation1 = observationDao.lookupObservation(observation.getId());
        assertNotNull(observation1);
        assertEquals(observation.getPlant().getId(), plant.getId());

        assertEquals(observation.getId(), observation1.getId());
        assertEquals(observation.getEnteredBy(), user);
    }

    @Test
    public void testLookupObservationByCriteria_ObservationsMatchingCriteriaReturned() throws Exception {
//    observationDao.addObservation(observation);
        observationDao.save(observation);
        Observation observation1 = observationDao.lookupObservation(observation.getId());
        assertNotNull(observation1);
        assertEquals(observation1.getId(), observation.getId());
    }

    @Test
    public void testInactivateObservation_ObservationsInactivated() throws Exception {
        observationDao.addObservation(observation);
        Observation observation1 = observationDao.lookupObservation(observation.getId());
        assertNotNull(observation1);
        assertTrue(observation1.isActive());

        observationDao.inactivateObservation(observation);
        try {
            observationDao.lookupObservation(observation.getId());
            //fail("This should have failed");
        } catch (Exception e) {
            assertEquals("Index: 0, Size: 0", e.getMessage());
        }
    }

    @Test
    public void testLookupObservations_ObservationsMatchingCriteriaReturned() throws Exception {
        Plant pl = new Plant();
        pl.setId(new Long(185953));
        Language language = new Language();
        language.setId(new Long(5));

        CategoryType categoryType = new CategoryType();
        categoryType.setId(new Long(1));
        categoryType.setBehavior(true);

        LanguageCategoryType languageCategoryType = new LanguageCategoryType();
        LanguageCategoryTypePK catPK = new LanguageCategoryTypePK();
        catPK.setLanguage(language);
        catPK.setCategoryType(categoryType);
        languageCategoryType.setId(catPK);

        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(Calendar.YEAR, calendar1.get(Calendar.YEAR) - 1);

        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.YEAR, calendar2.get(Calendar.YEAR) + 1);

        LanguageBasedResponse lbr = new LanguageBasedResponse();
        LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
        Response response = new Response();
        response.setId(new Long(2));
        response.setShowDialog(new Boolean(true));
        pk.setResponse(response);
        lbr.setId(pk);

        BBSUser bbsUser = new BBSUser();
        bbsUser.setUserId("JTMURR");
        Plant userPlant = new Plant();
        userPlant.setId(new Long(5373279));
        bbsUser.setPlant(userPlant);

        /*
        ReportCriteria criteria = new ReportCriteria("MM/dd/yyyy", language, pl, calendar1.getTime(), calendar2.getTime(),
                languageCategoryType, lbr);
        */

        String dateFormat = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        ReportCriteria rc = new ReportCriteria();
        rc.setDateFormat(dateFormat);
        rc.setLanguage(language);
        rc.setLanguageCategoryTypeList(Lists.newArrayList(languageCategoryType));
        rc.setLanguageBasedResponse(lbr);
        rc.setUser(bbsUser);

        rc.setReportDateFrom(sdf.format(calendar1.getTime()));
        rc.setReportDateTo(sdf.format(calendar2.getTime()));

        List<Observation> observations = observationDao.lookupObservations(rc);
        assertNotNull(observations);
    }

    @Test
    public void testReportResultsWithPortugueseLocale() {

        final ReportCriteria rc = buildTestReportCriteria("5", "Portuguese", "DD/MM/YYYY", "28/09/2012", "02/10/2012");

        final List results = observationDao.lookupObservations(rc);

        assertTrue(results.size() > 0);
    }

    /*
    @Test
    public void testReportResultsWithWrongPortuguesLocale() {

       final ReportCriteria rc = buildTestReportCriteria("5", "Portuguese", "MM/DD/YYYY", "28/09/2012", "02/10/2012" );
       List results = null;
       String errorCause = null;

       try {
           results = observationDao.lookupObservations(rc);
       } catch (Exception e) {
          errorCause = e.getCause().getMessage();
       }

       assertTrue( errorCause.contains("ORA-01843: not a valid month") );
    }
    */


    private ReportCriteria buildTestReportCriteria(String languageId, String languageDesc, String dateFormat, String dateFromStr, String dateToStr) {

        String plantId = "5373279";
        String plantName1 = "St Louis MO";

        String categoryTypeId = "2";
        String isBehavior = "true";
        String responseId = null;
        String responseDesc = null;
        String showDialogForResponse = null;
        String userId = "FJADAN";

        Plant plant = new Plant();
        plant.setId(new Long(plantId));
        plant.setPlantName1(plantName1);
        Language language = new Language();
        language.setId(new Long(languageId));
        language.setDescription(languageDesc);

        CategoryType categoryType = new CategoryType();
        categoryType.setId(new Long(categoryTypeId));
        categoryType.setBehavior(Boolean.parseBoolean(isBehavior));

        LanguageCategoryType languageCategoryType = new LanguageCategoryType();
        LanguageCategoryTypePK catPK = new LanguageCategoryTypePK();
        catPK.setCategoryType(categoryType);
        catPK.setLanguage(language);
        languageCategoryType.setId(catPK);

        LanguageBasedResponse lbr = null;
        if (StringUtils.isNotBlank(responseId)) {
            lbr = new LanguageBasedResponse();
            lbr.setDescription(responseDesc);
            LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
            Response response = new Response();
            response.setId(new Long(responseId));
            response.setShowDialog(Boolean.valueOf(showDialogForResponse));
            pk.setResponse(response);
            lbr.setId(pk);
        }

        BBSUser bbsUser = new BBSUser();
        bbsUser.setId(0L);
        bbsUser.setPlant(plant);

        final ReportCriteria rc = new ReportCriteria();
        rc.setDateFormat(dateFormat);
        rc.setLanguage(language);
        rc.setLanguageCategoryTypeList(Lists.newArrayList(languageCategoryType));
        rc.setLanguageBasedResponse(lbr);
        rc.setReportDateFrom(dateFromStr);
        rc.setReportDateTo(dateToStr);
        rc.setUser(bbsUser);

        return rc;
    }

}