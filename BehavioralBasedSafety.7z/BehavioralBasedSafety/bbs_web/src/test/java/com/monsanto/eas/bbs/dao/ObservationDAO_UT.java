package com.monsanto.eas.bbs.dao;

import com.google.common.collect.Lists;
import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.model.ReportCriteria;
import com.monsanto.eas.bbs.service.mock.MockPlantDAO;
import com.monsanto.eas.bbs.service.mock.MockRegionDAO;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/14/14
 * Time: 8:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObservationDAO_UT {

    @Test
    public void testAddObservation() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        Observation observation = new Observation();

        assertEquals("size of the list before inserting should be 0", 0, observationList.size());

        observationDAO.addObservation(observation);

        assertEquals("size of the list after inserting should be 1", 1, observationList.size());
    }

    @Test
    public void testUpdateObservation() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        Observation observation = new Observation();
        observation.setId(new Long(1));

        assertEquals("value of observation.active before updating should be false", false, observation.isActive());

        observationDAO.updateObservation(observation);

        Observation searchedObservation = observationDAO.lookupObservation(new Long(1));
        assertEquals("value of observation.active after updating should be true", true, searchedObservation.isActive());
    }


    @Test
    public void testDeleteObservation() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();

        Observation observation = new Observation();
        observation.setId(new Long(1));

        observationList.add(observation);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        assertEquals("size of the list before deleting should be 1", 1, observationList.size());

        observationDAO.deleteObservation(observation);

        assertEquals("size of the list after deleting should be 0", 0, observationList.size());
    }


    @Test
    public void testInactivateObservation() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();

        Observation observation = new Observation();
        observation.setId(new Long(1));
        observation.setActive(true);

        observationList.add(observation);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        assertEquals("value of observation.active before updating should be true", true, observation.isActive());

        observationDAO.inactivateObservation(observation);

        Observation searchedObservation = observationDAO.lookupObservation(new Long(1));
        assertEquals("value of observation.active after updating should be false", false, searchedObservation.isActive());
    }


    @Test(expected = RuntimeException.class)
    public void testLookupObservation_IdNotUnique() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();

        Observation observation = new Observation();
        observation.setId(new Long(1));

        Observation observation2 = new Observation();
        observation2.setId(new Long(1));

        observationList.add(observation);
        observationList.add(observation2);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        Observation searchedObservation = observationDAO.lookupObservation(new Long(1));
    }

    @Test
    public void testGetObservationCategoryTypeDescription() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(new ArrayList());
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        List<CategoryObservation> categoryObservationList = new ArrayList<CategoryObservation>();

        CategoryType categoryType = new CategoryType();
        categoryType.setDescription("");

        Category category = new Category();
        category.setCategoryType(categoryType);

        CategoryObservation categoryObservation = new CategoryObservation();
        categoryObservation.setCategory(category);

        categoryObservationList.add(categoryObservation);

        Observation observation = new Observation();
        observation.setId(new Long(1));
        observation.setCategoryObservations(categoryObservationList);


        //String obsCatTypeDesc = observationDAO.getObservationCategoryTypeDescription(observation);
    }

    @Test
    public void testLookupObservations_By_Country() {
        List rawObsList = getRawObservationArray();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(rawObsList);
        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(mockSessionFactory, rawObsList);

        CountryDAOImpl countryDAO = new CountryDAOImpl();
        countryDAO.setHibernateTemplate(mockHibernateTemplate);

        ObservationDAOImpl observationDAO = new ObservationDAOImpl(new MockPlantDAO(), new MockRegionDAO(), countryDAO);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        ReportCriteria criteria = buildReportCriteria_Search_By_Country();

        List<Observation> observations = observationDAO.lookupObservations(criteria);

        assertNotNull(observations);
    }

    @Test
    public void testLookupAllObservationForSubSubCategory() {
        ObservationDAOImpl observationDAO = new ObservationDAOImpl();

        List<Observation> observationList = new ArrayList<Observation>();
        Observation observation = new Observation();
        observation.setId(new Long(1));

        observationList.add(observation);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(observationList);
        observationDAO.setHibernateTemplate(mockHibernateTemplate);

        Category category = new Category();
        category.setId(new Long(1));

        List<Observation> obsByCat = observationDAO.lookupAllObservationForSubSubCategory(category);

        assertNotNull(obsByCat);
    }

    private List<Observation> getDummyObservationList() {
        List<Observation> observationList = new ArrayList<Observation>();
        Observation observation = new Observation();
        Observation observation2 = new Observation();

        observationList.add(observation);
        observationList.add(observation2);

        return observationList;
    }

    private List getRawObservationArray() {
        List rawObsList = new ArrayList();
        Object[] rawObsArray = new Object[]{new Long(1), "ENTERED BY FIRST NAME", "ENTERED BY LAST NAME", "ENTERED FOR FIRST NAME", "ENTERED FOR LAST NAME", new java.util.Date(),
                "Seasonal/Temporary worker", "CASA GRANDE-RD-COTTON DPL-FULL TIME", null, null, "task", "Treating", "Seed Treating",
                null, null, null, null, null, "Safety Glasses", "Eyes/ Face/ Ear",
                "Personal Protective Equipment", "COTTON BREEDING ARIZONA", new Long(21164695), new Long(141522), "JCHATC", new Long(190827),
                new Long(190827), null, new java.util.Date(), "Casa Grande, AZ", "BEHAVIOR",
                null, null, null, "Safe"};

        Object[] rawObsArray2 = new Object[]{new Long(2), "ENTERED BY FIRST NAME", "ENTERED BY LAST NAME", "ENTERED FOR FIRST NAME", "ENTERED FOR LAST NAME", new java.util.Date(),
                "Seasonal/Temporary worker", "CASA GRANDE-RD-COTTON DPL-FULL TIME", null, null, "task", "Treating", "Seed Treating",
                null, null, null, null, null, "Safety Glasses", "Eyes/ Face/ Ear",
                "Personal Protective Equipment", "COTTON BREEDING ARIZONA", new Long(21164695), new Long(141522), "JCHATC", new Long(190827),
                new Long(190827), null, new java.util.Date(), "Casa Grande, AZ", "BEHAVIOR",
                null, null, null, "Risk"};

        rawObsList.add(rawObsArray);
        rawObsList.add(rawObsArray2);

        return rawObsList;
    }

    private ReportCriteria buildReportCriteria_Search_By_Country() {

        Language language = new Language();
        language.setId(new Long(2));
        language.setDescription("English");

        CategoryType categoryType = new CategoryType();
        LanguageCategoryType languageCategoryType = new LanguageCategoryType();
        LanguageCategoryTypePK catPK = new LanguageCategoryTypePK();

        categoryType.setId(new Long(1));
        categoryType.setBehavior(false);

        catPK.setCategoryType(categoryType);
        catPK.setLanguage(language);
        languageCategoryType.setId(catPK);

        languageCategoryType.setDescription("ENVIRONMENT");

        LanguageBasedResponse lbr = null;
        /*
        if (StringUtils.isNotBlank(responseId)) {
            lbr = new LanguageBasedResponse();
            lbr.setDescription(responseDesc);
            LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
            Response response = new Response();
            response.setId(new Long(responseId));
            response.setShowDialog(Boolean.valueOf(showDialogForResponse));
            pk.setResponse(response);
            lbr.setId(pk);
        }
        */
        Set roles = new HashSet();
        BBSRole role = new BBSRole();
        role.setId((long) 1);
        role.setDescription(BBSUser.GLOBAL_LEAD);
        roles.add(role);

        Plant plant = new Plant();
        plant.setId(new Long(1));

        BBSUser bbsUser = new BBSUser();
        bbsUser.setId(new Long(1));
        bbsUser.setPlant(plant);
        bbsUser.setRoles(roles);

        List<Country> countryList = new ArrayList<Country>();

        Country country = new Country();
        country.setId(new Long(232));
        country.setCountryCode("US");
        country.setDescription("USA");

        countryList.add(country);

        final ReportCriteria rc = new ReportCriteria();
        rc.setDateFormat("MM/DD/YYYY");
        rc.setLanguage(language);
        rc.setLanguageCategoryTypeList(Lists.newArrayList(languageCategoryType));
        rc.setLanguageBasedResponse(lbr);
        rc.setCountryList(countryList);
        rc.setSearchByCountryCriteria(true);
        rc.setUser(bbsUser);

        return rc;
    }

}
