/*
 AreaDAOImpl_AT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.OrgUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class OrgUnitDAOImpl_AT {
    @Autowired
    OrgUnitDAO orgUnitDAO = null;
    OrgUnit orgUnit;
    private static final String ORG_UNIT_CODE = "XXXX";

    @Before
    public void setUp() {
        orgUnit = new OrgUnit();
        orgUnit.setOrgCode(ORG_UNIT_CODE);
        orgUnit.setActive(true);
        orgUnitDAO.addOrgUnit(orgUnit);
    }

    @Test
    public void testFindByCriteria() throws Exception {
        List<OrgUnit> orgUnits = orgUnitDAO.findByCriteria(ORG_UNIT_CODE);
        OrgUnit orgUnit1 = orgUnits.get(0);
        assertEquals(ORG_UNIT_CODE, orgUnit1.getOrgCode());
    }

    @After
    public void tearDown() {
        orgUnitDAO.deleteOrgUnit(orgUnit);
    }
}