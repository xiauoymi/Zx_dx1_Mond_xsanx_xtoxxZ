/*
 PersonnelDAOImpl was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelType;
import com.monsanto.eas.bbs.hibernate.LanguageBasedPersonnelTypePK;
import com.monsanto.eas.bbs.hibernate.PersonnelType;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
/*
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
*/
public class PersonnelTypeDAOImpl_AT {


    @Before
    public void setUp() {

        List<LanguageBasedPersonnelType> languageBasedPersonnelTypeList = new ArrayList<LanguageBasedPersonnelType>();

        LanguageBasedPersonnelType languageBasedPersonnelType = new LanguageBasedPersonnelType();
        LanguageBasedPersonnelTypePK id = new LanguageBasedPersonnelTypePK();
        languageBasedPersonnelType.setId(id);
        languageBasedPersonnelType.setDescription("Contractor");

        LanguageBasedPersonnelType languageBasedPersonnelType2 = new LanguageBasedPersonnelType();
        LanguageBasedPersonnelTypePK id2 = new LanguageBasedPersonnelTypePK();
        languageBasedPersonnelType2.setId(id2);
        languageBasedPersonnelType2.setDescription("Monsanto Employee");

        LanguageBasedPersonnelType languageBasedPersonnelType3 = new LanguageBasedPersonnelType();
        LanguageBasedPersonnelTypePK id3 = new LanguageBasedPersonnelTypePK();
        languageBasedPersonnelType3.setId(id3);
        languageBasedPersonnelType3.setDescription("Seasonal/Temporary worker");

        languageBasedPersonnelTypeList.add(languageBasedPersonnelType);
        languageBasedPersonnelTypeList.add(languageBasedPersonnelType2);
        languageBasedPersonnelTypeList.add(languageBasedPersonnelType3);

    }

    private List<PersonnelType> getDummyPersonnelTypeList() {
        List<PersonnelType> personnelTypeList = new ArrayList<PersonnelType>();
        PersonnelType personnelType1 = new PersonnelType();
        personnelType1.setActive(true);
        personnelType1.setId(new Long(1));

        PersonnelType personnelType2 = new PersonnelType();
        personnelType2.setActive(true);
        personnelType2.setId(new Long(2));

        personnelTypeList.add(personnelType1);
        personnelTypeList.add(personnelType2);

        return personnelTypeList;
    }

    @Ignore
    @Test
    public void testGetAllPersonnelType_ListReturned() throws Exception {
        PersonnelTypeDAOImpl personnelTypeDAO = new PersonnelTypeDAOImpl();

        List<PersonnelType> personnelTypeList = new ArrayList<PersonnelType>();
        PersonnelType personnelType1 = new PersonnelType();
        personnelType1.setActive(true);
        personnelType1.setId(new Long(1));

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(personnelTypeList);
        personnelTypeDAO.setHibernateTemplate(mockTemplate);

        /*
        List<PersonnelType> personnelList = dao.lookupPersonnelType();
        assertTrue(personnelList.size() > 1);
        for (PersonnelType personnelType : personnelList) {
            assertTrue(personnelType.isActive());
        }
        */
    }

    @Test
    public void testAddPersonnelType() {
        PersonnelTypeDAOImpl personnelTypeDAO = new PersonnelTypeDAOImpl();

        List<PersonnelType> personnelTypeList = getDummyPersonnelTypeList();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(personnelTypeList);
        personnelTypeDAO.setHibernateTemplate(mockTemplate);

        assertTrue("PersonnelType list size before inserting must be 2", personnelTypeDAO.lookupPersonnelType().size() == 2);

        PersonnelType personnelType = new PersonnelType();
        personnelType.setActive(true);
        personnelType.setId(new Long(3));

        personnelTypeDAO.addPersonnelType(personnelType);

        assertTrue("PersonnelType list size after inserting must be 3", personnelTypeDAO.lookupPersonnelType().size() == 3);
    }

    @Test
    public void testDeletePersonnelType() {

        PersonnelTypeDAOImpl personnelTypeDAO = new PersonnelTypeDAOImpl();

        List<PersonnelType> personnelTypeList = getDummyPersonnelTypeList();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(personnelTypeList);
        personnelTypeDAO.setHibernateTemplate(mockTemplate);

        assertTrue("PersonnelType list size before deleting must be 2", personnelTypeDAO.lookupPersonnelType().size() == 2);

        PersonnelType personnelType = new PersonnelType();
        personnelType.setActive(true);
        personnelType.setId(new Long(2));

        personnelTypeDAO.deletePersonnelType(personnelType);

        assertTrue("PersonnelType list size after deleting must be 1", personnelTypeDAO.lookupPersonnelType().size() == 1);
    }

    @Ignore
    @Test
    public void testAddLanguageBasedPersonnelType() {

        PersonnelTypeDAOImpl personnelTypeDAO = new PersonnelTypeDAOImpl();

        List<PersonnelType> personnelTypeList = getDummyPersonnelTypeList();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(personnelTypeList);
        personnelTypeDAO.setHibernateTemplate(mockTemplate);

        LanguageBasedPersonnelType languageBasedPersonnelType = new LanguageBasedPersonnelType();

        LanguageBasedPersonnelTypePK id = new LanguageBasedPersonnelTypePK();

        languageBasedPersonnelType.setId(id);
        languageBasedPersonnelType.setDescription("Contractor");

        personnelTypeDAO.addLanguageBasedPersonnelType(languageBasedPersonnelType);
    }


    @Test
    public void testLookupLanguageBasedPersonnelTypesByLanguage() {
        PersonnelTypeDAOImpl personnelTypeDAO = new PersonnelTypeDAOImpl();

        List<LanguageBasedPersonnelType> languageBasedPersonnelTypes = new ArrayList<LanguageBasedPersonnelType>();

        LanguageBasedPersonnelType lbpt = new LanguageBasedPersonnelType();
        LanguageBasedPersonnelType lbpt2 = new LanguageBasedPersonnelType();

        languageBasedPersonnelTypes.add(lbpt);
        languageBasedPersonnelTypes.add(lbpt2);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(languageBasedPersonnelTypes);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, languageBasedPersonnelTypes);
        personnelTypeDAO.setHibernateTemplate(mockTemplate);

        Language defaultLanguage = new Language(new Long(2), "English", true, "en");

        List<LanguageBasedPersonnelType> languageBasedPersonnelTypeList = personnelTypeDAO.lookupLanguageBasedPersonnelTypesByLanguage(defaultLanguage);

        assertNotNull(languageBasedPersonnelTypeList);
        assertEquals("languageBasedPersonnelTypeList should have 2 elements ", 2, languageBasedPersonnelTypeList.size() );
    }


}