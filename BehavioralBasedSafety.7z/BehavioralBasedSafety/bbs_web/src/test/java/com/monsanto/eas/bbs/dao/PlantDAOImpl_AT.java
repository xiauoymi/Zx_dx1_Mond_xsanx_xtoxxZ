/*
 PlantDAOImpl_AT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class PlantDAOImpl_AT {
    @Autowired
    private PlantDAO plantDao = null;

    @Autowired
    private SafetyGroupDAO safetyGroupDAO = null;

    @Autowired
    private AreaDAO areaDao;

    private Plant plant = null;
    private Plant plant1 = null;

    private Area area;
    private Area subArea;

    private SafetyGroup safetyGroup;

    @Before
    public void setUp() {
        plant = new Plant();
        plant.setActive(true);
        plant.setCustomerNumberForPlant("C0001");
        plant.setVendorNbrForPlant("V0001");
        plant.setPlantName1("Plant Name");
        plant.setPlantCode("9999");

        area = new Area();
        area.setActive(true);
        subArea = new Area();
        subArea.setParentArea(area);
        subArea.setActive(true);
        Set<Area> subAreas = new HashSet<Area>();
        subAreas.add(subArea);
        area.setSubAreas(subAreas);
//    areaDao.saveOrUpdateArea(area);

        safetyGroup = new SafetyGroup();
        safetyGroup.setActive(true);
        safetyGroup.setPlant(plant);
        safetyGroupDAO.addSafetyGroup(safetyGroup);


        Set<Area> areas = new HashSet<Area>();
        areas.add(area);

        Set<SafetyGroup> safetyGroups = new HashSet<SafetyGroup>();
        safetyGroups.add(safetyGroup);
        plant.setAreas(areas);
        plant.setSafetyGroups(safetyGroups);
        plantDao.addPlant(plant);


        plant1 = new Plant();
        plant1.setActive(true);
        plant1.setCustomerNumberForPlant("C0002");
        plant1.setVendorNbrForPlant("V0002");
        plant1.setPlantName1("name 2");
        plantDao.addPlant(plant1);
    }

    @Test
    public void testLookupAllPlantsThatAreActive_ListReturned() throws Exception {
        List<Plant> activePlants = plantDao.lookupAllPlants();
        assertTrue(activePlants.size() >= 1);
        for (Plant activePlant : activePlants) {
            assertNotNull(activePlant.getId());
            assertTrue(activePlant.isActive());
            if ("Plant Name".equalsIgnoreCase(activePlant.getPlantName1())) {
                assertEquals(1, activePlant.getAreas().size());
                Area area2 = activePlant.getAreas().iterator().next();
                assertTrue(area2.equals(area));
                assertEquals(1, area2.getSubAreas().size());
                Area subArea2 = area2.getSubAreas().iterator().next();
                assertTrue(subArea.equals(subArea2));

                assertEquals(1, activePlant.getSafetyGroups().size());
                for (SafetyGroup group : activePlant.getSafetyGroups()) {
                    assertTrue(group.equals(safetyGroup));
                    assertTrue(plant.equals(group.getPlant()));
                }
            }
        }
    }

    @Test
    public void testLookupPlantsByCriteria_ListOfPlantsReturned() throws Exception {
        List<Plant> plants = plantDao.findByCriteria("Name", null);
        assertTrue(plants.size() >= 2);
        for (Plant p : plants) {
            assertTrue(p.getPlantName1().toLowerCase().contains("name".toLowerCase()));
        }
    }

    @Test
    public void LookupPlantsByCriteria_NullPassed_ListOfPlantsReturned() throws Exception {
        List<Plant> plants = plantDao.findByCriteria(null, null);
        assertNull(plants);
    }

    @Test
    public void LookupPlantsByCriteria_PlantCodePassed_ListOfPlantsReturned() throws Exception {
        List<Plant> plants = plantDao.findByCriteria(null, "9999");
        assertNotNull(plants);
        assertEquals(1, plants.size());
    }


    @After
    public void tearDown() {
        plantDao.deletePlant(plant);
        plantDao.deletePlant(plant1);
    }

}