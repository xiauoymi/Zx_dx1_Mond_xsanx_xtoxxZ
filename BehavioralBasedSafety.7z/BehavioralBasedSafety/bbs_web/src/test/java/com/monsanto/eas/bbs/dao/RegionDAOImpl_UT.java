/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Before;
import org.junit.Test;
import org.springframework.scheduling.quartz.SimpleTriggerBean;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
/*
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
*/
/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class RegionDAOImpl_UT {
    //@Autowired
    //RegionDAO regionDAO = new MockRegionDAO();

    RegionDAOImpl regionDAO;

    private Map<Long, Region> regionMap;
    private Map<Long, Region> regionMapByPlantCode;
    private Map<Long, Region> regionMapByPlantCodeRepeatedValues;

    @Before
    public void init() {
        regionMap = new HashMap<Long, Region>();
        regionMap.put(new Long(1), new Region("EMEA", true));
        regionMap.put(new Long(2), new Region("LATIN AMERICA SOUTH", true));
        regionMap.put(new Long(3), new Region("ASIA PACIFIC", true));
        regionMap.put(new Long(4), new Region("LATIN AMERICA NORTH", true));
        regionMap.put(new Long(5), new Region("NORTH AMERICA", true));
        regionMap.put(new Long(6), new Region("BRAZIL", true));
        regionMap.put(new Long(7), new Region("CHINA", true));
        regionMap.put(new Long(8), new Region("INDIA", true));

        regionMapByPlantCode = new HashMap<Long, Region>();
        regionMapByPlantCode.put(new Long(3000), new Region("EMEA", true));
        regionMapByPlantCode.put(new Long(3001), new Region("LATIN AMERICA SOUTH", true));
        regionMapByPlantCode.put(new Long(3002), new Region("BRAZIL", true));

        regionMapByPlantCodeRepeatedValues = new HashMap<Long, Region>();
        regionMapByPlantCodeRepeatedValues.put(new Long(5000), new Region("LATIN AMERICA SOUTH", true));
        regionMapByPlantCodeRepeatedValues.put(new Long(5001), new Region("LATIN AMERICA SOUTH", true));
        regionMapByPlantCodeRepeatedValues.put(new Long(5002), new Region("LATIN AMERICA SOUTH", true));

        /*
        regionDAO = mock(RegionDAOImpl.class);

        when(regionDAO.lookupRegionDescriptionByRegionId(new Long(2))).thenReturn(regionMap.get(new Long(2)).getDescription());
        */
    }

    @Test
    public void testLookupRegionDescriptionByRegionId() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMap);
        regionDAO.setupSessionFactory(mockSessionFactory);

        String regionDescription = regionDAO.lookupRegionDescriptionByRegionId(new Long(2));

        assertEquals("LATIN AMERICA SOUTH", regionDescription);
    }

    @Test
    public void testLookupRegionDescriptionByPlantId() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMapByPlantCode);
        regionDAO.setupSessionFactory(mockSessionFactory);

        String regionDescription = regionDAO.lookupRegionDescriptionByPlantId(new Long(3000));

        assertEquals("EMEA", regionDescription);
    }

    @Test
    public void testLookupRegionDescriptionByPlantId_NonUniqueResult() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMapByPlantCodeRepeatedValues);
        regionDAO.setupSessionFactory(mockSessionFactory);

        String regionDescription = regionDAO.lookupRegionDescriptionByPlantId(new Long(5002));

        assertEquals("", regionDescription);
    }

    @Test
    public void testIsInEMEARegion() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        String userRegion = "EMEA";

        boolean isEMEARegion = regionDAO.isInEMEARegion(userRegion);

        assertTrue("Is EMEA Region", isEMEARegion);
    }

    @Test
    public void testLookupRegionDescriptionByBBSUser() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();
        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMap);
        regionDAO.setupSessionFactory(mockSessionFactory);

        BBSUser bbsUser = new BBSUser();

        Country bbsUserCountry = new Country();
        bbsUserCountry.setId(new Long(232));
        bbsUserCountry.setActive(true);
        bbsUserCountry.setCountryCode("US");
        bbsUserCountry.setDescription("USA");
        bbsUserCountry.setRegionId(new Long(5));

        Plant bbsUserPlant = new Plant();
        bbsUserPlant.setActive(true);
        bbsUserPlant.setPlantCode("3000");
        bbsUserPlant.setPlantName1("St Louis MO");
        bbsUserPlant.setCountry(bbsUserCountry);

        bbsUser.setPlant(bbsUserPlant);

        String userRegionDesc = regionDAO.lookupRegionDescriptionByBBSUser(bbsUser);

        assertEquals("User Region Desc should be NORTH AMERICA", "NORTH AMERICA", userRegionDesc);

    }

    @Test
    public void testLookupAllRegions() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        List<Region> regionList = new ArrayList<Region>(regionMap.values());

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(regionList);
        regionDAO.setHibernateTemplate(mockHibernateTemplate);

        List<Region> searchedRegionList = regionDAO.lookupAllRegions();

        assertEquals("the list must contain 8 regions", 8, searchedRegionList.size());
    }

    @Test
    public void testLookupAllRegionsByUserRole() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        List<Region> regionList = new ArrayList<Region>();
        Region region = new Region("NORTH AMERICA", true);
        regionList.add(region);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMap);
        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(mockSessionFactory, regionList);
        regionDAO.setHibernateTemplate(mockHibernateTemplate);

        BBSUser bbsUser = new BBSUser();

        Country bbsUserCountry = new Country();
        bbsUserCountry.setId(new Long(232));
        bbsUserCountry.setActive(true);
        bbsUserCountry.setCountryCode("US");
        bbsUserCountry.setDescription("USA");
        bbsUserCountry.setRegionId(new Long(5));

        Plant bbsUserPlant = new Plant();
        bbsUserPlant.setActive(true);
        bbsUserPlant.setPlantCode("3000");
        bbsUserPlant.setPlantName1("St Louis MO");
        bbsUserPlant.setCountry(bbsUserCountry);

        bbsUser.setPlant(bbsUserPlant);

        Set roles = new HashSet();
        BBSRole role = new BBSRole();
        role.setId((long) 1);
        role.setDescription(BBSUser.ESH_ADMIN);
        roles.add(role);
        bbsUser.setRoles(roles);

        List<Region> userRegionList = regionDAO.lookupAllRegionsByUserRole(bbsUser);

        assertNotNull(userRegionList);
        assertEquals("NORTH AMERICA", userRegionList.get(0).getDescription());
    }

    @Test
    public void testLookupAllRegionsByUserRole_EMEA_UserRegion() {
        RegionDAOImpl regionDAO = new RegionDAOImpl();

        List<Region> regionList = new ArrayList<Region>();
        Region region = new Region("EMEA", true);
        regionList.add(region);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(regionMap);
        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(mockSessionFactory, regionList);
        regionDAO.setHibernateTemplate(mockHibernateTemplate);

        BBSUser bbsUser = new BBSUser();

        Country bbsUserCountry = new Country();
        bbsUserCountry.setId(new Long(75));
        bbsUserCountry.setActive(true);
        bbsUserCountry.setCountryCode("FR");
        bbsUserCountry.setDescription("France");
        bbsUserCountry.setRegionId(new Long(1));

        Plant bbsUserPlant = new Plant();
        bbsUserPlant.setActive(true);
        bbsUserPlant.setPlantCode("1287");
        bbsUserPlant.setPlantName1("Trebes");
        bbsUserPlant.setCountry(bbsUserCountry);

        bbsUser.setPlant(bbsUserPlant);

        Set roles = new HashSet();
        BBSRole role = new BBSRole();
        role.setId((long) 1);
        role.setDescription(BBSUser.ESH_ADMIN);
        roles.add(role);
        bbsUser.setRoles(roles);

        List<Region> userRegionList = regionDAO.lookupAllRegionsByUserRole(bbsUser);

        assertNotNull(userRegionList);
        assertEquals("EMEA", userRegionList.get(0).getDescription());
    }

}