package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.BBSRole;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 19, 2010
 * Time: 3:23:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class RoleDAOImpl_UT {

    @Test
    public void testLookUpAllRoles() throws Exception {
        RoleDAOImpl roleDAO = new RoleDAOImpl();
        List<BBSRole> bbsRoleList = new ArrayList<BBSRole>();

        BBSRole bbsRole1 = new BBSRole();
        bbsRole1.setDescription("ADMIN");
        bbsRole1.setActive(true);
        bbsRole1.setId(1l);

        bbsRoleList.add(bbsRole1);

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(bbsRoleList);
        roleDAO.setHibernateTemplate(mockHibernateTemplate);

        List<BBSRole> roles = roleDAO.lookUpAllRoles();
        assertNotNull(roles);
        assertEquals(1, roles.size());
    }

    @Test
    public void testSaveOrUpdateRole(){
        RoleDAOImpl roleDAO = new RoleDAOImpl();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(new ArrayList<BBSRole>());
        roleDAO.setHibernateTemplate(mockHibernateTemplate);

        BBSRole bbsRole1 = new BBSRole();
        bbsRole1.setDescription("ADMIN_TEST");
        bbsRole1.setActive(true);
        bbsRole1.setId(2l);

        roleDAO.saveOrUpdateRole(bbsRole1);
        List<BBSRole> bbsRoleList = roleDAO.lookUpAllRoles();

        assertTrue("The list contains the object we've just inserted", bbsRoleList.contains(bbsRole1));
    }

}
