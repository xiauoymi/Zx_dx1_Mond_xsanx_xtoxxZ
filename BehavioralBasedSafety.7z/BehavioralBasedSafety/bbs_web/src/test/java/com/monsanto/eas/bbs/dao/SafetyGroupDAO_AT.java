/*
 SafetyGroupDAO_AT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class SafetyGroupDAO_AT {
    @Autowired
    private SafetyGroupDAO safetyGroupDAO = null;
    @Autowired
    private PlantDAO plantDao;

    Plant plant;
    SafetyGroup safetyGroup;

    @Before
    public void setup() {
        plant = new Plant();
        plantDao.addPlant(plant);
        safetyGroup = new SafetyGroup();
        safetyGroup.setPlant(plant);
        safetyGroup.setGroupText("TEST");
        safetyGroup.setActive(true);
        safetyGroup.setLocationCode("1000");
        safetyGroup.setPlantCode("2000");
        safetyGroupDAO.addSafetyGroup(safetyGroup);
    }

    @Test
    public void testLookupAllSafetyGroupsThatBelongToAPlant_ListReturned() throws Exception {
        List<SafetyGroup> safetyGroups = safetyGroupDAO.lookupSafetyGroupsByPlant(plant);
        assertEquals(1, safetyGroups.size());
        for (SafetyGroup group : safetyGroups) {
            assertNotNull(group.getId());
            assertEquals(plant.getId(), group.getPlant().getId());
            assertTrue(group.isActive());
        }
    }

    @After
    public void tearDown() {
        safetyGroupDAO.deleteSafetyGroup(safetyGroup);
        plantDao.deletePlant(plant);

    }
}