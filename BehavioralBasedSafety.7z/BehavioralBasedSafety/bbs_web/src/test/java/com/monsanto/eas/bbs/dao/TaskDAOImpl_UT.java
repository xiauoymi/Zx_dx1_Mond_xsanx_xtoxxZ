package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.Task;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/15/14
 * Time: 4:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class TaskDAOImpl_UT {

    private List<Task> getDummyTaskList() {
        List<Task> taskList = new ArrayList<Task>();
        Task task = new Task();
        task.setId(new Long(1));
        task.setDescription("Test Task 1");

        Task task2 = new Task();
        task2.setId(new Long(2));
        task2.setDescription("Test Task 2");

        Task task3 = new Task();
        task3.setId(new Long(3));
        task3.setDescription("Test Task 3");

        taskList.add(task);
        taskList.add(task2);
        taskList.add(task3);

        return taskList;
    }

    @Test
    public void testLookupAllTasks() {
        TaskDAOImpl taskDAO = new TaskDAOImpl();

        List<Task> taskList = getDummyTaskList();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(taskList);
        taskDAO.setHibernateTemplate(mockHibernateTemplate);

        List<Task> retrievedList = taskDAO.lookupAllTasks();

        assertEquals(taskList, retrievedList);
    }

    @Test
    public void testLookupTaskByDescription() {
        TaskDAOImpl taskDAO = new TaskDAOImpl();

        List<Task> taskList = getDummyTaskList();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(taskList);
        taskDAO.setHibernateTemplate(mockHibernateTemplate);

        MockSessionFactoryForBBS mockSessionFactoryForBBS = new MockSessionFactoryForBBS(taskList);
        taskDAO.setupSessionFactory(mockSessionFactoryForBBS);

        Task retrievedTask = taskDAO.lookupTaskByDescription("Test Task 1");

        assertEquals(taskList.get(0), retrievedTask);
    }


    @Test
    public void testAddNewTask() {
        TaskDAOImpl taskDAO = new TaskDAOImpl();

        List<Task> taskList = getDummyTaskList();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(taskList);
        taskDAO.setHibernateTemplate(mockHibernateTemplate);

        Task taskToAdd = new Task();
        taskToAdd.setId(new Long(4));
        taskToAdd.setDescription("Test Task 4");

        assertEquals("before inserting, task list contains 3 elements", 3, taskDAO.lookupAllTasks().size());

        taskDAO.addNewTask(taskToAdd);

        assertEquals("after inserting, task list contains 4 elements", 4, taskDAO.lookupAllTasks().size());
    }

}
