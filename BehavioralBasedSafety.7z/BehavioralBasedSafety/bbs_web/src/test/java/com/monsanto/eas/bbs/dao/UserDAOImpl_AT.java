/*
 * Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 * UserDAOImpl_AT was created on Jan 18, 2009 using Monsanto resources and is the sole property of Monsanto.
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.hibernate.*;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Filename:    $HeadURL$ Label:       $Id$
 *
 * @author AASEN
 * @version $Revision$ Last Change: $Author$     On: $Date$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class UserDAOImpl_AT {

    @Autowired
    protected UserDAO userDao;


    private TempBBSUser getTestDummyUser(String userId) {
        Country country = new Country();
        country.setDescription("USA");
        country.setId(new Long(232));
        country.setActive(true);
        country.setCountryCode("US");

        Plant plant = new Plant();
        plant.setId(new Long(5373279));
        plant.setActive(true);
        plant.setPlantName1("St Louis MO");
        plant.setPlantCode("3000");
        plant.setCountry(country);

        Department department = new Department();
        department.setId(new Long(6597173));
        department.setActive(true);
        department.setCode(new Long(51108394));
        department.setName("CB-CENTRAL SALES-IA EAST");

        /*
        Date currentDate = new Date();

        BBSUser user = new BBSUser();
        //user.setId(new Long(99999));
        user.setUserId(userId);
        user.setFirstName("FIRSTNAME");
        user.setLastName("LASTNAME");
        user.setMiddleName("MIDDLENAME");
        user.setEmployee(true);
        user.setLastLogin(currentDate);
        user.setModUser("MOD_USER");
        user.setModDate(currentDate);
        user.setPlant(plant);
        user.setDepartment(department);
        */

        TempBBSUser tempBBSUser = new TempBBSUser();
        tempBBSUser.setUserId(userId);
        tempBBSUser.setFirstName("FIRSTNAME");
        tempBBSUser.setLastName("LASTNAME");
        tempBBSUser.setMiddleName("MIDDLENAME");
        //tempBBSUser.setPlant(plant);
        //tempBBSUser.setDepartment(department);

        return tempBBSUser;
    }


    @Test
    public void testAddUser() {
        String userId = "TEST_USER";
        BBSUser bbsUser = getTestDummyUser(userId).getBBSUserFromTempBBSUser();

        BBSUser lookedUpUser = userDao.findByUserId(userId);

        assertNull("before adding, user should not exist", lookedUpUser);

        userDao.addUser(bbsUser);

        assertNotNull("after inserting, user should exist", userDao.findByUserId(userId));
    }


    @Test
    public void testAddTempUser() {
        String userId = "TEST_USER";
        TempBBSUser tempBBSUser = getTestDummyUser(userId);

        userDao.addTempUser(tempBBSUser);
        assertNotNull("after inserting, user should exist", tempBBSUser);
    }


    @Test
    public void testDeleteUser() {
        String userId = "TEST_USER";
        BBSUser bbsUser = getTestDummyUser(userId).getBBSUserFromTempBBSUser();

        userDao.addUser(bbsUser);
        assertNotNull("after inserting, user should exist", userDao.findByUserId(userId));

        boolean userDeleted = userDao.deleteUser(bbsUser);

        assertNull("after deleting, user should not exist", userDao.findByUserId(userId));
        assertTrue("user was not deleted", userDeleted);
    }

    @Test
    public void testLookupUserByCriteria() {
        List<BBSUser> bbsUserList = userDao.lookupUserByCriteria("TEST");

        assertNotNull("looking up for a test user, shouldn't be null", bbsUserList);
        assertTrue(bbsUserList.size() >= 1);
    }

    @Ignore
    @Test
    public void testLookupAllUsers() {
        List<BBSUser> bbsActiveUserList = userDao.lookupAllUsers(true);

        assertNotNull("looking up for active user, shouldn't be null", bbsActiveUserList);
        assertTrue(bbsActiveUserList.size() >= 1);
    }

    @Test
    public void testLookupAllContractors() {
        List<BBSUser> bbsContractorUserList = userDao.lookupAllContractors(true);

        assertNotNull("looking up for active user, shouldn't be null", bbsContractorUserList);
        assertTrue(bbsContractorUserList.size() >= 1);
    }

    @Test
    public void testGetTempBBSUsersPendingForInsert() {
        Map<String, BBSUser> bbsUserPendingMap = userDao.getTempBBSUsersPendingForInsert();
        assertNotNull(bbsUserPendingMap);
    }

    @Test
    public void testGetTempBBSUsersWithNotExistingManager() {
        List<TempBBSUser> bbsUsersWithNotExistingManager = userDao.getTempBBSUsersWithNotExistingManager();
        assertNotNull(bbsUsersWithNotExistingManager);
        assertTrue(bbsUsersWithNotExistingManager.size() >= 1);
    }

    @Test
    public void testLookupUserWithRoles() {
        List<BBSUser> bbsUserList = userDao.lookupUserWithRoles();

        assertNotNull(bbsUserList);
        assertTrue("list of bbs users with roles should be greater than 0", bbsUserList.size() >= 1);
        assertTrue("role set for any bbs user of this list should be greater than 0", bbsUserList.get(0).getRoles().size() >=1 );
    }
}