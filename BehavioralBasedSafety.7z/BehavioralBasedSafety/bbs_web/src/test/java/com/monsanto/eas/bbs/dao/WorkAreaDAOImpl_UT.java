/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dao;

import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.WorkArea;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import com.monsanto.eas.bbs.service.mock.MockWorkAreaDAO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkAreaDAOImpl_UT {
    @Autowired
    WorkAreaDAO workAreaDAO = new MockWorkAreaDAO();


    @Test
    public void testLookupAll() throws Exception {
        final List<WorkArea> workAreas = workAreaDAO.lookupAll();
        assertNotNull(workAreas);
    }

    @Test
    public void testAddWorkArea() {
        WorkAreaDAOImpl workAreaDAO = new WorkAreaDAOImpl();

        List<WorkArea> workAreaList = new ArrayList<WorkArea>();

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(workAreaList);
        workAreaDAO.setHibernateTemplate(mockTemplate);

        WorkArea workArea = new WorkArea();
        workArea.setId(new Long(21877998));
        workArea.setPlantCode("1183");
        workArea.setDescription("Uberlandia, Brazil - Agroceres");

        workAreaDAO.addWorkArea(workArea);

        assertTrue("work area list should have been greater than zero", workAreaDAO.lookupAll().size() == 1);
    }

    @Test
    public void testDeleteWorkArea() {
        WorkAreaDAOImpl workAreaDAO = new WorkAreaDAOImpl();

        List<WorkArea> workAreaList = new ArrayList<WorkArea>();

        WorkArea workArea = new WorkArea("Uberlandia, Brazil - Agroceres", "1183");

        workAreaList.add(workArea);

        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(workAreaList);
        workAreaDAO.setHibernateTemplate(mockTemplate);

        assertEquals("work area list contains one element before deleting", 1, workAreaDAO.lookupAll().size());

        workAreaDAO.deleteWorkArea(workArea);

        assertEquals("work area list must be empty after deleting", 0, workAreaDAO.lookupAll().size());
    }

    @Test
    public void testLookupWorkAreaWithLocation() throws Exception {
        WorkAreaDAOImpl workAreaDAO = new WorkAreaDAOImpl();

        List<WorkArea> workAreaList = new ArrayList<WorkArea>();

        WorkArea workArea = new WorkArea("Uberlandia, Brazil - Agroceres", "1183");

        workAreaList.add(workArea);

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(workAreaList);
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, workAreaList);
        workAreaDAO.setHibernateTemplate(mockTemplate);

        List<WorkArea> workAreas = workAreaDAO.lookupAllAreasWithLocations();

        assertEquals("work area list should contain one element", 1, workAreas.size());
    }


    @Test
    public void testClearWorkAreas() {
        WorkAreaDAOImpl workAreaDAO = new WorkAreaDAOImpl();

        final MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS();
        MockHibernateTemplate mockTemplate = new MockHibernateTemplate(mockSessionFactory, null);
        workAreaDAO.setHibernateTemplate(mockTemplate);

        workAreaDAO.clearWorkAreas();
    }

}