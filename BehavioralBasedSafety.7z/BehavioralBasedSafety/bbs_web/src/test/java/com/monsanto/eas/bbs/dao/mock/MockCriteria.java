package com.monsanto.eas.bbs.dao.mock;

import org.hibernate.HibernateException;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/7/14
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockCriteria extends com.monsanto.wst.hibernate.mock.MockCriteria {

    public Object uniqueResult() throws HibernateException {
        Object o = null;
        List resultList = list();
        if (resultList != null && resultList.size() > 0) {
            o = new Object();
            o = resultList.get(0);
        }
        return o;
    }
}
