/*
 MockHibernateTemplate was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.dao.mock;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.HibernateTemplate;

import java.io.Serializable;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockHibernateTemplate extends HibernateTemplate {
    private List list;
    private DetachedCriteria detachedCriteria;

    public MockHibernateTemplate(List list) {
        this.list = list;
    }

    public MockHibernateTemplate(org.hibernate.SessionFactory sessionFactory, List list) {
        super(sessionFactory);
        this.list = list;
    }

    @Override
    public List findByCriteria(DetachedCriteria criteria) throws DataAccessException {
        detachedCriteria = criteria;
        return list;
    }

    @Override
    public List findByCriteria(DetachedCriteria criteria, int firstResult, int maxResults) throws DataAccessException {
        return list;
    }

    @Override
    public List loadAll(java.lang.Class entityClass) throws org.springframework.dao.DataAccessException {
        return list;
    }

    @Override
    public void saveOrUpdate(java.lang.Object entity) throws DataAccessException {
        if(!list.contains(entity)){
            list.add(entity);
        }
    }

    @Override
    public java.io.Serializable save(java.lang.Object entity) throws org.springframework.dao.DataAccessException {
        list.add(entity);
        return (Serializable)entity;
    }

    @Override
    public void delete(java.lang.Object entity) throws org.springframework.dao.DataAccessException {
        list.remove(entity);
    }

    public DetachedCriteria getDetachedCriteria() {
        return detachedCriteria;
    }
}