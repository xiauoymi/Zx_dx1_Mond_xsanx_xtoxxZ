package com.monsanto.eas.bbs.dao.mock;

import org.hibernate.*;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/9/14
 * Time: 12:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockSQLQuery implements SQLQuery {

    private Map resultMap;
    private long searchedIndex;

    public MockSQLQuery(Map resultMap, long searchedIndex) {
        this.resultMap = resultMap;
        this.searchedIndex = searchedIndex;
    }

    public MockSQLQuery(Map resultMap, String qryString) {
        this.resultMap = resultMap;

        Pattern p = Pattern.compile("=\\s*[0-9]+");
        Matcher m = p.matcher(qryString);

        long searchedIndex = 0;

        while (m.find()) {
            String resultString = m.group();
            resultString = resultString.replace("=", "");
            resultString = resultString.trim();
            searchedIndex = Long.parseLong(resultString);
        }

        this.searchedIndex = searchedIndex;
    }

    public SQLQuery addEntity(String entityName) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addEntity(String alias, String entityName) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addEntity(String alias, String entityName, LockMode lockMode) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addEntity(Class entityClass) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addEntity(String alias, Class entityClass) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addEntity(String alias, Class entityClass, LockMode lockMode) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addJoin(String alias, String path) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addJoin(String alias, String path, LockMode lockMode) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addScalar(String columnAlias, Type type) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addScalar(String columnAlias) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery setResultSetMapping(String name) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addSynchronizedQuerySpace(String querySpace) {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addSynchronizedEntityName(String entityName) throws MappingException {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public SQLQuery addSynchronizedEntityClass(Class entityClass) throws MappingException {
        return this;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getQueryString() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Type[] getReturnTypes() throws HibernateException {
        return new Type[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getReturnAliases() throws HibernateException {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getNamedParameters() throws HibernateException {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Iterator iterate() throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public ScrollableResults scroll() throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public ScrollableResults scroll(ScrollMode scrollMode) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List list() throws HibernateException {
        List resultListLocal = new ArrayList(resultMap.values());
        return resultListLocal;
    }

    public Object uniqueResult() throws HibernateException {
        Object resultObject = resultMap.get(searchedIndex).toString();
        List duplicatedList = new ArrayList();

        for(Object currentObj : resultMap.values()){
            if(duplicatedList.contains(currentObj)){
                throw new NonUniqueResultException(2);
            } else {
                duplicatedList.add(currentObj);
            }
        }

        return resultObject;
    }

    public int executeUpdate() throws HibernateException {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setMaxResults(int maxResults) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setFirstResult(int firstResult) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setReadOnly(boolean readOnly) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCacheable(boolean cacheable) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCacheRegion(String cacheRegion) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setTimeout(int timeout) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setFetchSize(int fetchSize) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setLockMode(String alias, LockMode lockMode) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setComment(String comment) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setFlushMode(FlushMode flushMode) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCacheMode(CacheMode cacheMode) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameter(int position, Object val, Type type) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameter(String name, Object val, Type type) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameter(int position, Object val) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameter(String name, Object val) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameters(Object[] values, Type[] types) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameterList(String name, Collection vals, Type type) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameterList(String name, Collection vals) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameterList(String name, Object[] vals, Type type) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setParameterList(String name, Object[] vals) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setProperties(Object bean) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setProperties(Map bean) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setString(int position, String val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCharacter(int position, char val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBoolean(int position, boolean val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setByte(int position, byte val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setShort(int position, short val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setInteger(int position, int val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setLong(int position, long val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setFloat(int position, float val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setDouble(int position, double val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBinary(int position, byte[] val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setText(int position, String val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setSerializable(int position, Serializable val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setLocale(int position, Locale locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBigDecimal(int position, BigDecimal number) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBigInteger(int position, BigInteger number) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setDate(int position, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setTime(int position, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setTimestamp(int position, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCalendar(int position, Calendar calendar) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCalendarDate(int position, Calendar calendar) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setString(String name, String val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCharacter(String name, char val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBoolean(String name, boolean val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setByte(String name, byte val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setShort(String name, short val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setInteger(String name, int val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setLong(String name, long val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setFloat(String name, float val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setDouble(String name, double val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBinary(String name, byte[] val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setText(String name, String val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setSerializable(String name, Serializable val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setLocale(String name, Locale locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBigDecimal(String name, BigDecimal number) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setBigInteger(String name, BigInteger number) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setDate(String name, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setTime(String name, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setTimestamp(String name, Date date) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCalendar(String name, Calendar calendar) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setCalendarDate(String name, Calendar calendar) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setEntity(int position, Object val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setEntity(String name, Object val) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Query setResultTransformer(ResultTransformer transformer) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
