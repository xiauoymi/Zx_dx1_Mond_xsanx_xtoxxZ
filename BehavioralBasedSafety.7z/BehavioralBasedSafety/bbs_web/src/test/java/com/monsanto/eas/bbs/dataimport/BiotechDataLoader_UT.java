package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.BiotechDAO;
import com.monsanto.eas.bbs.hibernate.BiotechProgram;
import com.monsanto.eas.bbs.hibernate.BiotechProjectPlatform;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 18/06/12
 * Time: 04:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class BiotechDataLoader_UT {

    @Test
    public void testLoadBiotechData() throws IOException, ContentSetException {

        BiotechDataImporter mockBiotechDataImporter = new MockBiotechDataImporter();
        BiotechDAO mockBiotechDAO = new MockBiotechDao();

        BiotechDataLoader biotechDataLoader = new BiotechDataLoader(mockBiotechDataImporter, mockBiotechDAO);
        biotechDataLoader.loadBiotechData();

        int numberOfTimesAddBiotechCalled = ((MockBiotechDao) mockBiotechDAO).numberOfTimesAddBiotechProgramCalled;
        assertEquals(2, numberOfTimesAddBiotechCalled);
    }


    @Test
    public void testAddBiotechProjectInfo() {
        BiotechDAO mockBiotechDAO = new MockBiotechDao();

        BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();
        BiotechProgram biotechProgram = new BiotechProgram();
        biotechProgram.setId(1l);
        biotechProgram.setPlantCode("3925");
        biotechProgram.setProgram("CAMBRIDGE");

        biotechProjectPlatform.setBiotechProgram(biotechProgram);
        biotechProjectPlatform.setProjectDescription("OPTIMIZATION & DESIGN");
        biotechProjectPlatform.setId(1l);

        mockBiotechDAO.addBiotechProjectPlatform(biotechProjectPlatform);

        int numberOfTimesAddBiotechProjectCalled = ((MockBiotechDao) mockBiotechDAO).numberOfTimesAddBiotechProjectCalled;

        assertEquals(1, numberOfTimesAddBiotechProjectCalled);
    }

    @Test
    public void testLookupBiotechProgramsForPlant() {

        BiotechDAO mockBiotechDAO = new MockBiotechDao();

        Plant plant = new Plant();
        plant.setPlantCode("3000");

        List<BiotechProgram> biotechProgramList = mockBiotechDAO.lookupBiotechProgramsForPlant(plant);

    }

    private class MockBiotechDataImporter implements BiotechDataImporter {

        private boolean wasGetBiotechInfoCalled = false;

        public List<BiotechTO> getBiotechInfo() throws IOException, ContentSetException {
            final List<BiotechTO> biotechList = new ArrayList<BiotechTO>();

            BiotechTO biotechTO = new BiotechTO();
            biotechTO.setPlantCode("3000");
            biotechTO.setProgram("AGRONOMIC TRAITS");
            biotechTO.setProjectPlatform("PROTEIN SCIENCE");
            biotechList.add(biotechTO);

            biotechTO = new BiotechTO();
            biotechTO.setPlantCode("3000");
            biotechTO.setProgram("BIOTECH ADMIN & OTHER");
            biotechTO.setProjectPlatform("OTHER");
            biotechList.add(biotechTO);

            biotechTO = new BiotechTO();
            biotechTO.setPlantCode("3000");
            biotechTO.setProgram("BIOTECH OPERATIONS & COLLABORA");
            biotechTO.setProjectPlatform("OPERATIONS & COLLABORATIONS");
            biotechList.add(biotechTO);

            return biotechList;
        }
    }

    private class MockBiotechDao implements BiotechDAO {

        private int numberOfTimesAddBiotechProgramCalled = 0;
        private int numberOfTimesAddBiotechProjectCalled = 0;

        public void addBiotechProgram(BiotechProgram biotechProgram) {
            numberOfTimesAddBiotechProgramCalled++;
        }

        public void addBiotechProjectPlatform(BiotechProjectPlatform biotechProjectPlatform) {
            numberOfTimesAddBiotechProjectCalled++;
        }

        public List<BiotechProgram> getAllBiotechPrograms() {

            final List<BiotechProgram> biotechProgramList = new ArrayList<BiotechProgram>();

            BiotechProgram biotechProgram = new BiotechProgram();
            biotechProgram.setId(1l);
            biotechProgram.setPlantCode("3925");
            biotechProgram.setProgram("CAMBRIDGE");

            biotechProgramList.add(biotechProgram);

            biotechProgram = new BiotechProgram();
            biotechProgram.setId(2l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("AGRONOMIC TRAITS");

            biotechProgramList.add(biotechProgram);

            return biotechProgramList;
        }

        public List<BiotechProjectPlatform> getAllBiotechProjects() {

            final List<BiotechProjectPlatform> biotechProjectPlatformList = new ArrayList<BiotechProjectPlatform>();

            BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();

            BiotechProgram biotechProgram = new BiotechProgram();
            biotechProgram.setId(1l);
            biotechProgram.setPlantCode("3925");
            biotechProgram.setProgram("CAMBRIDGE");

            biotechProjectPlatform.setBiotechProgram(biotechProgram);
            biotechProjectPlatform.setProjectDescription("OPTIMIZATION & DESIGN");
            biotechProjectPlatform.setId(3l);

            biotechProjectPlatformList.add(biotechProjectPlatform);

            biotechProjectPlatform = new BiotechProjectPlatform();
            biotechProgram = new BiotechProgram();
            biotechProgram.setId(2l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("AGRONOMIC TRAITS");

            biotechProjectPlatform.setBiotechProgram(biotechProgram);
            biotechProjectPlatform.setProjectDescription("PROTEIN SCIENCE");
            biotechProjectPlatform.setId(4l);

            biotechProjectPlatformList.add(biotechProjectPlatform);

            return biotechProjectPlatformList;
        }

        public List<BiotechProgram> lookupBiotechProgramsForPlant(Plant plant) {
            final List<BiotechProgram> biotechProgramList = new ArrayList<BiotechProgram>();

            BiotechProgram biotechProgram = new BiotechProgram();
            biotechProgram.setId(1l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("AGRONOMIC TRAITS");

            biotechProgramList.add(biotechProgram);

            biotechProgram = new BiotechProgram();
            biotechProgram.setId(2l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("BIOTECH ADMIN & OTHER");

            biotechProgramList.add(biotechProgram);

            biotechProgram = new BiotechProgram();
            biotechProgram.setId(3l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("BIOTECH OPERATIONS & COLLABORA");

            biotechProgramList.add(biotechProgram);

            biotechProgram = new BiotechProgram();
            biotechProgram.setId(4l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("BIOTECH OPERATIONS, PATENT SCI");

            biotechProgramList.add(biotechProgram);

            biotechProgram = new BiotechProgram();
            biotechProgram.setId(5l);
            biotechProgram.setPlantCode("3000");
            biotechProgram.setProgram("BIOTECH STRATEGY & OPERATIONS");

            biotechProgramList.add(biotechProgram);

            return biotechProgramList;
        }

        public List<BiotechProjectPlatform> lookupBiotechProjectsForProgram(BiotechProgram biotechProgram) {

            final List<BiotechProjectPlatform> biotechProjectPlatformList = new ArrayList<BiotechProjectPlatform>();

            BiotechProjectPlatform biotechProjectPlatform = new BiotechProjectPlatform();
            biotechProjectPlatform.setBiotechProgram(biotechProgram);
            biotechProjectPlatform.setProjectDescription("INFORMATION MANAGEMENT");

            biotechProjectPlatformList.add(biotechProjectPlatform);

            biotechProjectPlatform = new BiotechProjectPlatform();
            biotechProjectPlatform.setBiotechProgram(biotechProgram);
            biotechProjectPlatform.setProjectDescription("PROSPECTING LEAD");

            return biotechProjectPlatformList;
        }
    }

}
