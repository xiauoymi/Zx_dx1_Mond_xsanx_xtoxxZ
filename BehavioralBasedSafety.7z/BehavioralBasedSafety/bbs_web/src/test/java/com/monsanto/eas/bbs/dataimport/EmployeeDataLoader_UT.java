package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.DepartmentDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.dao.UserDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Department;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempBBSUser;
import com.monsanto.eas.bbs.service.mock.MockDepartmentDAO;
import com.monsanto.eas.bbs.service.mock.MockPlantDAO;
import com.monsanto.eas.bbs.service.mock.MockSafetyGroupDAO;
import com.monsanto.eas.bbs.service.mock.MockUserDAO;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Jan 17, 2010 Time: 11:09:09 PM To change this template use File |
 * Settings | File Templates.
 */
public class EmployeeDataLoader_UT {

    @Test
    public void testLoadEmployeeData_CallGetEmployeeData_OneEmployeeReturned_CallGetPlantId_InsertEmployeeCalled() throws
            Exception {
        EmployeeDataImporter employeeDataImporter = new MockEmployeeDataImporter();

        PlantDAO plantDAO = new MockPlantDAO();
        UserDAO userDAO = new MockUserDAO();
        DepartmentDAO departmentDAO = new MockDepartmentDAO(null, null);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();

        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, departmentDAO, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();

        boolean wasGetEmployeeCalled = ((MockEmployeeDataImporter) employeeDataImporter).wasGetEmployeeCalled();
        boolean wasGetPlaintIdCalled = ((MockPlantDAO) plantDAO).wasGetPlantIdCalled();
        int numberOfTimesFindPlantByCriteriaCalled = ((MockPlantDAO) plantDAO).numberOfTimesFindPlantByCriteriaCalled();

        assertTrue(wasGetEmployeeCalled);
        assertFalse(wasGetPlaintIdCalled);
        assertEquals(0, numberOfTimesFindPlantByCriteriaCalled);

        List<TempBBSUser> tempUsers = ((MockUserDAO) userDAO).getTempUsers();
        assertEquals(1, tempUsers.size());
        assertEquals(new Long(2233), tempUsers.get(0).getDepartment().getId());
        assertEquals(new Long(123), tempUsers.get(0).getDepartment().getCode());
        assertEquals("123 Name", tempUsers.get(0).getDepartment().getName());
    }

    @Test
    public void testLoadEmployeeData_CallGetEmployeeData_DepartmentAlreadyExists_InsertEmployeeCalled() throws
            Exception {
        EmployeeDataImporter employeeDataImporter = new MockEmployeeDataImporter();
        PlantDAO plantDAO = new MockPlantDAO();
        UserDAO userDAO = new MockUserDAO();
        Department dept = new Department();
        dept.setId(new Long(2233));
        dept.setCode(new Long(123));

        DepartmentDAO departmentDAO = new MockDepartmentDAO(null, dept);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, departmentDAO, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();

        boolean wasGetEmployeeCalled = ((MockEmployeeDataImporter) employeeDataImporter).wasGetEmployeeCalled();
        boolean wasGetPlaintIdCalled = ((MockPlantDAO) plantDAO).wasGetPlantIdCalled();
        int numberOfTimesFindPlantByCriteriaCalled = ((MockPlantDAO) plantDAO).numberOfTimesFindPlantByCriteriaCalled();

        assertTrue(wasGetEmployeeCalled);
        assertFalse(wasGetPlaintIdCalled);
        assertEquals(0, numberOfTimesFindPlantByCriteriaCalled);
        List<TempBBSUser> tempUsers = ((MockUserDAO) userDAO).getTempUsers();
        assertEquals(1, tempUsers.size());
        assertEquals(new Long(2233), tempUsers.get(0).getDepartment().getId());
        assertEquals(new Long(123), tempUsers.get(0).getDepartment().getCode());
    }

    @Test
    public void testLoadEmployeeData_CallGetEmployeeData_OneEmployeeReturned_CallGetPlantId_NoPlantsReturned_SetErrorOnEmployee() throws
            Exception {
        EmployeeDataImporter employeeDataImporter = new MockEmployeeDataImporter();
        PlantDAO plantDAO = new MockPlantDAO_NoPlantsReturned();
        UserDAO userDAO = new MockUserDAO();
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, null, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();
//    List<BBSUser> bbsUsers = ((MockEmployeeDataImporter) employeeDataImporter).getEmployeesData();
//    BBSUser user = bbsUsers.get(0);
//    String dataLoadError = user.getDataLoadError();
//    assertEquals("No Plant associated with employee", dataLoadError);
    }

    @Test
    public void testLoadEmployeeData_CallGetEmployeeData_OneEmployeeReturned_CallGetPlantId_ManyPlantsReturned_SetErrorOnEmployee() throws
            Exception {
        EmployeeDataImporter employeeDataImporter = new MockEmployeeDataImporter();
        PlantDAO plantDAO = new MockPlantDAO_ManyPlantsReturned();
        UserDAO userDAO = new MockUserDAO();
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, null, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();
        List<TempBBSUser> bbsUsers = ((MockEmployeeDataImporter) employeeDataImporter).getEmployeesData();
        TempBBSUser user = bbsUsers.get(0);
//    String dataLoadError = user.getDataLoadError();
//    assertEquals("Many Plants associated with employee", dataLoadError);
    }

    @Test
    public void testLoadEmployeeData_CallGetEmployeeData_NoEmployeeReturned_CallGetPlantId() throws Exception {
        EmployeeDataImporter employeeDataImporter = new MockEmployeeDataImporter_NoEmployeeReturned();
        PlantDAO plantDAO = new MockPlantDAO();
        UserDAO userDAO = new MockUserDAO();
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        EmployeeDataLoader employeeDataLoader = new EmployeeDataLoader(employeeDataImporter, plantDAO, userDAO, null, safetyGroupDAO);
        employeeDataLoader.loadEmployeeData();
        int numberOfTimesFindPlantByCriteriaCalled = ((MockPlantDAO) plantDAO).numberOfTimesFindPlantByCriteriaCalled();
        int numberOfTimesAddUserCalled = ((MockUserDAO) userDAO).numberOfTimesAddUserCalled();
        assertEquals(0, numberOfTimesFindPlantByCriteriaCalled);
        assertEquals(0, numberOfTimesAddUserCalled);
    }


    //todo add business rule: is plant_id a required field for user data. If yes throw an exception. can an employee belong to more than one plant

    private class MockEmployeeDataImporter implements EmployeeDataImporter {
        private boolean wasGetEmployeeCalled = false;
        List<TempBBSUser> bbsUserList;

        public boolean wasGetEmployeeCalled() {
            return wasGetEmployeeCalled;  //To change body of created methods use File | Settings | File Templates.
        }

        public List<TempBBSUser> getEmployees() {
            bbsUserList = new ArrayList<TempBBSUser>();
            TempBBSUser tempUser = new TempBBSUser();
            Plant plant = new Plant();
            plant.setPlantCode("234");
            plant.setPlantName1("234 Name");
            tempUser.setPlant(plant);
            Department department = new Department();
            department.setId(new Long(2233));
            department.setCode(new Long(123));
            department.setName("123 Name");
            tempUser.setDepartment(department);
            bbsUserList.add(tempUser);
            wasGetEmployeeCalled = true;
            return bbsUserList;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<TempBBSUser> getTempBBSUsers() throws IOException, ContentSetException {
            return getEmployees();
        }

        public HashMap<String, TempBBSUser> getTempBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public HashMap<String, BBSUser> getBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }


        public List<TempBBSUser> getEmployeesData() {
            return bbsUserList;
        }
    }

    private class MockEmployeeDataImporter_NoEmployeeReturned implements EmployeeDataImporter {
        public List<TempBBSUser> getEmployees() {
            return new ArrayList();  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<TempBBSUser> getTempBBSUsers() throws IOException, ContentSetException {
            return getEmployees();
        }

        public HashMap<String, TempBBSUser> getTempBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public HashMap<String, BBSUser> getBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }

    private class MockEmployeeDataImporter_ManyEmployeeReturned implements EmployeeDataImporter {
        public List<TempBBSUser> getEmployees() {
            List<TempBBSUser> bbsUserList = new ArrayList<TempBBSUser>();
            bbsUserList.add(new TempBBSUser());
            bbsUserList.add(new TempBBSUser());
            return bbsUserList;  //To change body of implemented methods use File | Settings | File Templates.

        }

        public List<TempBBSUser> getTempBBSUsers() throws IOException, ContentSetException {
            return getEmployees();
        }

        public HashMap<String, TempBBSUser> getTempBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public HashMap<String, BBSUser> getBBSUsersMap() throws IOException, ContentSetException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }

}
