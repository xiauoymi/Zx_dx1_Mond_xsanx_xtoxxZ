package com.monsanto.eas.bbs.dataimport;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 2:04:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class FixedColumnContentSet_UT {

    @Test
    public void testCreateContentSet_CallNext_EmptyFile() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("empty.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        assertFalse(contentSet.next());
    }

    @Test
    public void testCreateContentSet_CallNext_OneLineInFile() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("file_one_line.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        assertTrue(contentSet.next());
        assertFalse(contentSet.next());
    }

    @Test
    public void testCreateContentSet_CallNext_MoreThanOneLineInFile() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("more_than_one_line.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        assertTrue(contentSet.next());
        assertTrue(contentSet.next());
        assertFalse(contentSet.next());
    }

    @Test
    public void testCreateContentSet_CallNext_GetString() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("more_than_one_line.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        contentSet.next();
        assertEquals("3489", contentSet.getString(0, 4));
        assertEquals("MONSANTO COMPANY - W", contentSet.getString(4, 24));
    }

    @Test
    public void testCreateContentSet_GetString_WhenEndIndexGreaterThanStringLenghReturnTillEndOfString() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("more_than_one_line.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        contentSet.next();
        assertEquals("3489", contentSet.getString(0, 4));
        assertEquals("MONSANTO COMPANY - WEXFORD    0300138324US", contentSet.getString(4, 250).trim());
    }

    @Test(expected = IOException.class)
    public void testClose() throws Exception {
        //BufferedReader reader = new BufferedReader(new FileReader("more_than_one_line.txt"));
        //ContentSet contentSet = new FixedColumnContentSet(reader);
        BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("more_than_one_line.txt"), "UTF8"));
        ContentSet contentSet = new FixedColumnContentSet(reader);
        contentSet.close();
        reader.ready();
        /*
        try {
            reader.ready(); //internally calls ensureOpen(), which should ideally fail.
            fail("'Stream Closed' exception should be thrown.");
        } catch (IOException e) {
            //expected path
        }
        */
    }


}
