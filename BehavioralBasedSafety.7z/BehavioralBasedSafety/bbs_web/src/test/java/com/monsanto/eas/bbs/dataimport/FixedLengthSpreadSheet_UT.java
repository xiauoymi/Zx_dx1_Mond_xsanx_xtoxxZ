package com.monsanto.eas.bbs.dataimport;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 17, 2010
 * Time: 3:40:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class FixedLengthSpreadSheet_UT {

    @Test
    public void testGetContent_FixedLenghSpreadSheet() throws Exception {
        SpreadSheet spreadSheet = new FixedLengthSpreadSheet("com/monsanto/eas/bbs/dataimport/more_than_one_line.txt");
        ContentSet contentSet = spreadSheet.getContentSet();
        assertNotNull(contentSet);
    }

}
