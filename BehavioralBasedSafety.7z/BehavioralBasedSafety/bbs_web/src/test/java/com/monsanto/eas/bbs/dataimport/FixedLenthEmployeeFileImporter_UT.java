package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.TempBBSUser;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 18, 2010
 * Time: 4:36:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class FixedLenthEmployeeFileImporter_UT {

    @Test
    public void testGetEmployee_FileContainsOnlyOneRecord() throws Exception {
        EmployeeDataImporter employeeDataImporter = new EmployeeFileDataImporter("com/monsanto/eas/bbs/dataimport/employee_data_one_line.txt");
        List<TempBBSUser> bbsUserList = employeeDataImporter.getEmployees();
        assertEquals(1, bbsUserList.size());
        assertEquals("Bethina", bbsUserList.get(0).getLastName());
        assertEquals("Vijayaram", bbsUserList.get(0).getFirstName());
        assertEquals("VRBETHI", bbsUserList.get(0).getUserId());
        assertEquals("1000", bbsUserList.get(0).getPlant().getPlantCode());
    }

}
