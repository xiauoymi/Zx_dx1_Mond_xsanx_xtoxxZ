package com.monsanto.eas.bbs.dataimport;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;

import javax.mail.internet.MimeMessage;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: Jul 28, 2011
 * Time: 2:16:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockJavaMailSender implements JavaMailSender {
  public MimeMessage createMimeMessage() {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public MimeMessage createMimeMessage(InputStream contentStream) throws MailException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(MimeMessage mimeMessage) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(MimeMessage[] mimeMessages) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(MimeMessagePreparator mimeMessagePreparator) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(MimeMessagePreparator[] mimeMessagePreparators) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(SimpleMailMessage simpleMessage) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void send(SimpleMailMessage[] simpleMessages) throws MailException {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
