package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempPlant;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 3:40:45 PM
 * To change this template use File | Settings | File Templates.
 */
class MockPlantDAO_ManyPlantsReturned implements PlantDAO {
   private Integer numberOfTimesAddTempPlantCalled = 0;
   private Integer numberOfTimesUpdatePlantsCalled = 0;
   private Integer numberOfTimesAddPlantsCalled = 0;
   private Integer numberOfTimesClearTempPlantsCalled = 0;

   public List<Plant> lookupAllPlants() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

    public Map<String, Plant> getMapOfAllPlants() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea() {
      return null;
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser, String userOwnsRegionDesc) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByRegionId(String regionId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String selectedCountryIds, BBSUser loggedInUser, String userOwnsRegionDesc) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroup() {
      return null;
   }

   public void addPlant(Plant plant) {
      //To change body of implemented methods use File | Settings | File Templates.
   }

   public void deletePlant(Plant plant) {
      //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> findByCriteria(String plantName1, String plantCode) {
      List<Plant> plants = new ArrayList();
      plants.add(new Plant());
      plants.add(new Plant());
      return plants;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public void inactivatePlantsNotAssociatedWithSafetyGroup() {
      //To change body of implemented methods use File | Settings | File Templates.
   }

   public void updatePlantWorkAreas() {
   }

   public void addTempPlant(TempPlant plant) {
      numberOfTimesAddTempPlantCalled++;
   }

   public void updatePlants() {
      numberOfTimesUpdatePlantsCalled++;
   }

   public void addPlants() {
      numberOfTimesAddPlantsCalled++;
   }

   public void clearTempPlants() {
      numberOfTimesClearTempPlantsCalled++;
   }
}
