package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 10:43:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrgUnitFileDataImporter_UT {

    @Test
    public void testOrgUnits_FileContainsOnlyOneRow() throws Exception {
        OrganizationUnitImporter dataImporter = new OrganizationUnitFileDataImporter("com/monsanto/eas/bbs/dataimport/orgUnits_data_one_line.txt");
        List<OrgUnit> orgUnits = dataImporter.getOrgUnits();
        assertEquals(1, orgUnits.size());
        assertEquals("WHEAT", orgUnits.get(0).getOrgDescription());
        assertEquals("16232", orgUnits.get(0).getOrgCode());
        assertEquals(new Long(6).toString(), orgUnits.get(0).getOrgLevel().toString());
        assertEquals("01014", orgUnits.get(0).getParentOrgCode());
    }

    @Test
    public void testGetPlants_FileEmpty() throws Exception {
        PlantDataImporter dataImporter = new PlantFileDataImporter("com/monsanto/eas/bbs/dataimport/orgUnits_empty.txt");
        List<Plant> plants = dataImporter.getPlants();
        assertEquals(0, plants.size());
    }

    @Test
    public void testGetPlants_FileContainsMoreThanOneRecord() throws Exception {
        PlantDataImporter dataImporter = new PlantFileDataImporter("com/monsanto/eas/bbs/dataimport/orgUnits_more_than_one_line.txt");
        List<Plant> plants = dataImporter.getPlants();
        assertEquals(2, plants.size());
    }

}