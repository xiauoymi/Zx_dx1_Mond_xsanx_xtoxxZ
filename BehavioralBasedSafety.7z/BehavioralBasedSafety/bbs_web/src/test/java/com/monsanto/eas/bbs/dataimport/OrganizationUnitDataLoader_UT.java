package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.TempOrgUnit;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 20, 2010
 * Time: 11:29:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class OrganizationUnitDataLoader_UT {

    @Test
    public void testLoadPlantData_PlantDataReaderCalled_InsertCalledOnOneOrgUnit() throws Exception {
        OrganizationUnitImporter dataImporter = new MockOrganizationUnitImporter();
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO();
        OrganizationUnitDataLoader organizationUnitDataLoader = new OrganizationUnitDataLoader(dataImporter, orgUnitDAO);
        organizationUnitDataLoader.loadOrganizationUnits();
        boolean wasGetOrgUnitsCalled = ((MockOrganizationUnitImporter) dataImporter).wasGetOrgUnitsDataCalled();
        int numberOfTimesInsertCalled = ((MockOrgUnitDAO) orgUnitDAO).numberOfTimesInsertCalled();
        assertTrue(wasGetOrgUnitsCalled);
        assertEquals(1, numberOfTimesInsertCalled);
    }

    private class MockOrganizationUnitImporter implements OrganizationUnitImporter {
        private boolean wasGetOrgUnitsCalled = false;

        public boolean wasGetOrgUnitsDataCalled() {
            return wasGetOrgUnitsCalled;  //To change body of created methods use File | Settings | File Templates.
        }

        public List<OrgUnit> getOrgUnits() {
            List<OrgUnit> orgUnits = new ArrayList();
            orgUnits.add(new OrgUnit());
            wasGetOrgUnitsCalled = true;
            return orgUnits;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }

    private class MockOrgUnitDAO implements OrgUnitDAO {
        private int numberOfTimesAddCalled = 0;

        public void addOrgUnit(OrgUnit orgUnit) {
            numberOfTimesAddCalled++;
        }

        public void addTempOrgUnit(TempOrgUnit tempOrgUnit) {
            //To change body of implemented methods use File | Settings | File Templates.
        }


        public void assignOrgUnitParents() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void deleteOrgUnit(OrgUnit orgUnit) {
            //To change body of implemented methods use File | Settings | File Templates.
        }


        public void addOrgUnits() {
            numberOfTimesAddCalled++;
        }

        public void updateOrgUnits() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void clearTempOrgUnits() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<OrgUnit> findByCriteria(String orgUnitCode) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<String> lookupAllOrgUnitCodes() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public int numberOfTimesInsertCalled() {
            return numberOfTimesAddCalled;  //To change body of created methods use File | Settings | File Templates.
        }
    }
}
