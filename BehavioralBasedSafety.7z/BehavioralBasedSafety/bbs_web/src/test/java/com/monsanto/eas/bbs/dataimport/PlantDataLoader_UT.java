package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.CountryDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.Region;
import com.monsanto.eas.bbs.service.mock.MockPlantDAO;
import com.monsanto.eas.bbs.util.EmailBean;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 8:43:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlantDataLoader_UT {

    @Test
    public void testLoadPlantData_PlantDataReaderCalled_InsertCalledOnOnePlant_GetCountryIdForCountryCode_CountryDoesNotExist_AddCountryCalled() throws Exception {
        PlantDataImporter dataImporter = new MockPlantDataImporter();
        PlantDAO plantDAO = new MockPlantDAO();
        CountryDAO countryDAO = new MockCountryDAO_CodeDoesNotExist();
        EmailBean email = new MockEmailBean();
        PlantDataLoader plantDataLoader = new PlantDataLoader(dataImporter, plantDAO, countryDAO);
        plantDataLoader.newLoadPlantData(email);
        boolean wasPlantDataCalled = ((MockPlantDataImporter) dataImporter).wasGetPlantDataCalled();
        //int numberOfTimesInsertCalled = ((MockPlantDAO)plantDAO).numberOfTimesInsertCalled();
        int numberOfTimesAddCountryCalled = ((MockCountryDAO_CodeDoesNotExist) countryDAO).numberOfTimesAddCountryCalled();
        Integer tempPlantsAdded = ((MockPlantDAO) plantDAO).getNumberOfTimesAddTempPlantCalled();
        assertTrue(wasPlantDataCalled);
        assertEquals(1, tempPlantsAdded.intValue());
        //assertEquals(1,numberOfTimesInsertCalled);
        assertEquals(1, numberOfTimesAddCountryCalled);
    }

    @Test
    public void testLoadPlantData_PlantDataReaderCalled_InsertCalledOnOnePlant_GetCountryIdForCountryCode_CountryExist_AddCountryNotCalled() throws Exception {
        PlantDataImporter dataImporter = new MockPlantDataImporter();
        PlantDAO plantDAO = new MockPlantDAO();
        CountryDAO countryDAO = new MockCountryDAO_CodeDoesNotExist();
        countryDAO.lookupActiveCountries();
        EmailBean email = new MockEmailBean();
        PlantDataLoader plantDataLoader = new PlantDataLoader(dataImporter, plantDAO, countryDAO);
        plantDataLoader.newLoadPlantData(email);
        boolean wasPlantDataCalled = ((MockPlantDataImporter) dataImporter).wasGetPlantDataCalled();
        int numberOfTimesAddCountryCalled = ((MockCountryDAO_CodeDoesNotExist) countryDAO).numberOfTimesAddCountryCalled();
        Integer tempPlantsAdded = ((MockPlantDAO) plantDAO).getNumberOfTimesAddTempPlantCalled();
        assertTrue(wasPlantDataCalled);
        assertEquals(1, tempPlantsAdded.intValue());
        assertEquals(1, numberOfTimesAddCountryCalled);
    }

    private class MockPlantDataImporter implements PlantDataImporter {
        private boolean wasGetPlantDataCalled = false;

        public boolean wasGetPlantDataCalled() {
            return wasGetPlantDataCalled;  //To change body of created methods use File | Settings | File Templates.
        }

        public int numberOfTimesInsertCalled() {
            return 0;  //To change body of created methods use File | Settings | File Templates.
        }

        public List<Plant> getPlants() throws IOException, ContentSetException {
            wasGetPlantDataCalled = true;
            List<Plant> plants = new ArrayList<Plant>();
            plants.add(new Plant());
            return plants;  //To change body of implemented methods use File | Settings | File Templates.

        }
    }

    private class MockDataImporter_ReturnsTwoPlants implements PlantDataImporter {
        public List<Plant> getPlants() throws IOException, ContentSetException {
            List<Plant> plants = new ArrayList<Plant>();
            plants.add(new Plant());
            plants.add(new Plant());
            return plants;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }


    private class MockCountryDAO_CodeDoesNotExist implements CountryDAO {
        public List<Country> lookupActiveCountriesByRegionIDAndByUserRole(String regionId, BBSUser loggedInUser, String userOwnsRegionDesc) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        private int numberOfTimesAddCountryCalled = 0;

        public void addCountry(Country country) {
            numberOfTimesAddCountryCalled++;
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<Country> lookupActiveCountries() {
            return new ArrayList<Country>();  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<Country> lookupActiveCountriesWithValidRegionID() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<Country> lookupActiveCountriesByRegionID(Long[] regionId) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void deleteCountry(Country country) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Long lookupRegionId(Country country) {
            return new Long(2);
        }

        public void activateInactivateEnvironmentalTabByRegion(Region region, boolean activeFlag) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void activateInactivateEnvironmentalTabByCountry(Country country, boolean activeFlag) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public Country lookupCountryByCountryCode(String countryCode) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public int numberOfTimesAddCountryCalled() {
            return numberOfTimesAddCountryCalled;  //To change body of created methods use File | Settings | File Templates.
        }
    }
}
