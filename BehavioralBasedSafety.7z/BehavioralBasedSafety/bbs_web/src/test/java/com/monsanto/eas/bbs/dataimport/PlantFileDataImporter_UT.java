package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.Plant;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 10:43:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlantFileDataImporter_UT {

    //todo add country code to plant
    @Test
    public void testGetPlants_FileContainsOnlyOneRow() throws Exception {
        PlantDataImporter dataImporter = new PlantFileDataImporter("com/monsanto/eas/bbs/dataimport/plant_data_one_line.txt");
        List<Plant> plants = dataImporter.getPlants();
        assertEquals(1, plants.size());
        assertEquals("3489", plants.get(0).getPlantCode());
        assertEquals("MONSANTO COMPANY - WEXFORD", plants.get(0).getPlantName1().trim());
        assertEquals("0300138324", plants.get(0).getStreet());
        assertEquals("US", plants.get(0).getCountryCode());
    }

    @Test
    public void testGetPlants_FileEmpty() throws Exception {
        PlantDataImporter dataImporter = new PlantFileDataImporter("com/monsanto/eas/bbs/dataimport/empty.txt");
        List<Plant> plants = dataImporter.getPlants();
        assertEquals(0, plants.size());
    }

    @Test
    public void testGetPlants_FileContainsMoreThanOneRecord() throws Exception {
        PlantDataImporter dataImporter = new PlantFileDataImporter("com/monsanto/eas/bbs/dataimport/more_than_one_line.txt");
        List<Plant> plants = dataImporter.getPlants();
        assertEquals(2, plants.size());
    }

}
