package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.OrgUnitDAO;
import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.hibernate.OrgUnit;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempOrgUnit;
import com.monsanto.eas.bbs.hibernate.TempSafetyGroup;
import com.monsanto.eas.bbs.service.mock.MockPlantDAO;
import com.monsanto.eas.bbs.service.mock.MockSafetyGroupDAO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 19, 2010
 * Time: 4:55:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class SafetyGroupDataLoader_UT {

    @Test
    public void testLoadSafetyGroupData_GroupCodeIsDEL_SafetyGroupIsInactive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("DEL");
        group.setPlantCode("P001");
        group.setOrgUnitCode("2345");
        group.setLocationCode("1004");
        safetyGroups.add(group);
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnit orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(1, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertEquals(new Long(1), safetyGroup.getPlant().getId());
        assertEquals(new Long(2345), safetyGroup.getOrgUnitId());
        assertFalse(safetyGroup.isActive());
    }

    @Test
    public void testLoadSafetyGroupData_GroupCodeIsMRG_SafetyGroupIsInactive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("MRG");
        group.setPlantCode("P001");
        group.setOrgUnitCode("2345");
        group.setLocationCode("1004");
        safetyGroups.add(group);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnit orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(1, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertEquals(new Long(1), safetyGroup.getPlant().getId());
        assertEquals(new Long(2345), safetyGroup.getOrgUnitId());
        assertFalse(safetyGroup.isActive());
    }

    @Test
    public void testLoadSafetyGroupData_SafetyGroupIsActive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("SOMETHING");
        group.setPlantCode("P001");
        group.setOrgUnitCode("2345");
        group.setLocationCode("1004");
        safetyGroups.add(group);
        group = new SafetyGroup();
        group.setGroupCode("SOMETHING1");
        group.setPlantCode("P001");
        group.setOrgUnitCode("2345");
        group.setLocationCode("1004");
        safetyGroups.add(group);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnit orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(2, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertEquals(new Long(1), safetyGroup.getPlant().getId());
        assertEquals(new Long(2345), safetyGroup.getOrgUnitId());
        assertTrue(safetyGroup.isActive());
    }

    @Test
    public void testLoadSafetyGroupData_NoPlantFound_SafetyGroupIsInactive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("SOMETHING");
        group.setPlantCode("not found");
        group.setLocationCode("1004");
        group.setOrgUnitCode("2345");
        safetyGroups.add(group);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnit orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(1, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertFalse(safetyGroup.isActive());
        assertNull(safetyGroup.getPlant());
        assertEquals(new Long(2345), safetyGroup.getOrgUnitId());
    }

    @Test
    public void testLoadSafetyGroupData_NoOrgUnitFound_SafetyGroupIsInactive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("SOMETHING");
        group.setPlantCode("1262");
        group.setLocationCode("1004");
        group.setOrgUnitCode("00100");
        safetyGroups.add(group);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(1, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertFalse(safetyGroup.isActive());
        assertNull(safetyGroup.getPlant());
        assertNull(safetyGroup.getOrgUnitId());
        assertEquals("Setting as inactive - plant code not foundSetting as inactive - org unit code not found", safetyGroup.getDataLoadError());
    }

    @Test
    public void testLoadSafetyGroupData_MoreThanOneOrgUnitFound_SafetyGroupIsInactive() throws Exception {
        List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setGroupCode("SOMETHING");
        group.setPlantCode("not found");
        group.setOrgUnitCode("2345");
        group.setLocationCode("1004");
        safetyGroups.add(group);
        SafetyGroupDataImporter safetyGroupDataImporter = new MockSafetyGroupDataImporter(safetyGroups);
        PlantDAO plantDAO = new MockPlantDAO();
        List<OrgUnit> orgUnits = new ArrayList<OrgUnit>();
        OrgUnit orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        orgUnit = new OrgUnit();
        orgUnit.setId(new Long(2345));
        orgUnit.setOrgCode("2345");
        orgUnits.add(orgUnit);
        OrgUnitDAO orgUnitDAO = new MockOrgUnitDAO(orgUnits);
        SafetyGroupDAO safetyGroupDAO = new MockSafetyGroupDAO();
        SafetyGroupDataLoader safetyGroupDataLoader = new SafetyGroupDataLoader(safetyGroupDataImporter, plantDAO, orgUnitDAO, safetyGroupDAO);
        safetyGroupDataLoader.loadSafetyGroupData();
        assertTrue(((MockPlantDAO) plantDAO).isInactivatePlantsNotAssociatedWithSafetyGroupCalled());
        List<TempSafetyGroup> safetyGroupsAdded = ((MockSafetyGroupDAO) safetyGroupDAO).getTempSafetyGroupsAdded();
        assertEquals(1, safetyGroupsAdded.size());
        TempSafetyGroup safetyGroup = safetyGroupsAdded.get(0);
        assertFalse(safetyGroup.isActive());
        assertNull(safetyGroup.getPlant());
        assertNull(safetyGroup.getOrgUnitId());
        assertEquals("Setting as inactive - plant code not foundToo many org units found with this org unit code", safetyGroup.getDataLoadError());
    }

    private class MockSafetyGroupDataImporter implements SafetyGroupDataImporter {
        private List<SafetyGroup> safetyGroups = new ArrayList<SafetyGroup>();

        private MockSafetyGroupDataImporter(List<SafetyGroup> safetyGroups) {
            this.safetyGroups = safetyGroups;
        }

        public List<SafetyGroup> getSafetyGroups() {
            return safetyGroups;
        }
    }

    private class MockOrgUnitDAO implements OrgUnitDAO {
        private List<OrgUnit> orgUnits;

        public void addOrgUnit(OrgUnit orgUnit) {
        }

        public void addTempOrgUnit(TempOrgUnit tempOrgUnit) {
            //To change body of implemented methods use File | Settings | File Templates.
        }


        public void assignOrgUnitParents() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        private MockOrgUnitDAO(List<OrgUnit> orgUnits) {
            this.orgUnits = orgUnits;
        }

        public void deleteOrgUnit(OrgUnit orgUnit) {
        }


        public void addOrgUnits() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void updateOrgUnits() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void clearTempOrgUnits() {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public List<OrgUnit> findByCriteria(String orgUnitCode) {
            return orgUnits;
        }

        public List<String> lookupAllOrgUnitCodes() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }
}
