package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 16, 2010
 * Time: 10:43:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class SafetyGroupFileDataImporter_UT {

    //todo add country code to plant
    @Test
    public void testGetPlants_FileContainsOnlyOneRow() throws Exception {
        SafetyGroupDataImporter dataImporter = new SafetyGroupFileDataImporter("com/monsanto/eas/bbs/dataimport/safety_grp_data_one_line.txt");
        List<SafetyGroup> safetyGroups = dataImporter.getSafetyGroups();
        assertEquals(1, safetyGroups.size());
        assertEquals("03007", safetyGroups.get(0).getSafetyGroupCode());
        assertEquals("1191", safetyGroups.get(0).getPlantCode());
        assertEquals("WS VITTORIA-ADMIN/SALES-DIRECT EMPL", safetyGroups.get(0).getGroupText().trim());
        assertEquals("10198", safetyGroups.get(0).getOrgUnitCode());
    }

    @Test
    public void testGetPlants_FileEmpty() throws Exception {
        SafetyGroupDataImporter dataImporter = new SafetyGroupFileDataImporter("com/monsanto/eas/bbs/dataimport/safety_grp_data_empty.txt");
        List<SafetyGroup> safetyGroups = dataImporter.getSafetyGroups();
        assertEquals(0, safetyGroups.size());
    }

    @Test
    public void testGetPlants_FileContainsMoreThanOneRecord() throws Exception {
        SafetyGroupDataImporter dataImporter = new SafetyGroupFileDataImporter("com/monsanto/eas/bbs/dataimport/safety_grp_data_more_than_one_line.txt");
        List<SafetyGroup> safetyGroups = dataImporter.getSafetyGroups();
        assertEquals(2, safetyGroups.size());
    }

}