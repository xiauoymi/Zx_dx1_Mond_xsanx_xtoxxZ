/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.dao.WorkAreaDAO;
import com.monsanto.eas.bbs.hibernate.WorkArea;
import com.monsanto.eas.bbs.service.mock.MockWorkAreaDAO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkAreaDataLoader_UT {

    @Test
    public void testTempPlantId() throws Exception {
        final WorkAreaDataImporter workAreaDataImporter = new MockWorkAreaDataImporter();
        final WorkAreaDAO workAreaDAO = new MockWorkAreaDAO();
        WorkAreaDataLoader workAreaDataLoader = new WorkAreaDataLoader(workAreaDataImporter, workAreaDAO);
        workAreaDataLoader.loadWorkAreaData();
        final Boolean wasWorkAreaDataCalled = ((MockWorkAreaDataImporter) workAreaDataImporter).getWasGetWorkAreasCalled();
        assertTrue(wasWorkAreaDataCalled);
    }

    private class MockWorkAreaDataImporter implements WorkAreaDataImporter {
        private Boolean wasGetWorkAreasCalled = false;

        public Boolean getWasGetWorkAreasCalled() {
            return wasGetWorkAreasCalled;
        }

        public void setWasGetWorkAreasCalled(Boolean b) {
            wasGetWorkAreasCalled = b;
        }

        public List<WorkArea> getWorkAreas() {
            setWasGetWorkAreasCalled(true);
            final List<WorkArea> workAreas = new ArrayList<WorkArea>();
            WorkArea workArea = new WorkArea();
            workArea.setDescription("test 1");
            workArea.setPlantCode("1000");
            workAreas.add(workArea);

            workArea = new WorkArea();
            workArea.setDescription("test 2");
            workArea.setPlantCode("2000");
            workAreas.add(workArea);

            return workAreas;
        }
    }
}