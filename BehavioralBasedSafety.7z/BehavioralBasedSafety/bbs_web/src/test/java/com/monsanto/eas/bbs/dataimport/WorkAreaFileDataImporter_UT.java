/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.dataimport;

import com.monsanto.eas.bbs.hibernate.WorkArea;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkAreaFileDataImporter_UT {

    private final Properties filepaths = new Properties();
    private final String prefix = "dev";
    private String filePathOneLine = prefix + ".workarea.oneline";
    private String filePathTwoLines = prefix + ".workarea.twolines";
    private String filePathEmpty = prefix + ".empty";

    private static Logger logger = Logger.getLogger(WorkAreaFileDataImporter_UT.class);

    @Before
    public void setUp() {
        try {
            try {
                filepaths.load(WorkAreaLoaderMain.class.getResourceAsStream("filepaths.properties"));
            } catch (NullPointerException nullPointerException) {
                logger.error("Could not find properties file.");
                return;
            }
            filePathOneLine = filepaths.getProperty(filePathOneLine);
            filePathTwoLines = filepaths.getProperty(filePathTwoLines);
            filePathEmpty = filepaths.getProperty(filePathEmpty);
        } catch (IOException e) {
            logger.error("Error loading properties file.\n" + e.getMessage());
        }
    }

    @Test
    public void testGetWorkAreasOneRow() throws Exception {
        WorkAreaDataImporter dataImporter = new WorkAreaFileDataImporter("com/monsanto/eas/bbs/dataimport/work_area_one_line.txt");
        List<WorkArea> workAreas = dataImporter.getWorkAreas();
        assertEquals(1, workAreas.size());
        assertEquals("CREVE COEUR", workAreas.get(0).getDescription().trim());
        assertEquals("3000", workAreas.get(0).getPlantCode().trim());
    }

    @Test
    public void testGetWorkAreasEmpty() throws Exception {
        WorkAreaDataImporter dataImporter = new WorkAreaFileDataImporter("com/monsanto/eas/bbs/dataimport/empty.txt");
        List<WorkArea> workAreas = dataImporter.getWorkAreas();
        assertEquals(0, workAreas.size());
    }

    @Test
    public void testGetWorkAreasTwoRows() throws Exception {
        WorkAreaDataImporter dataImporter = new WorkAreaFileDataImporter("com/monsanto/eas/bbs/dataimport/work_area_two_lines.txt");
        List<WorkArea> workAreas = dataImporter.getWorkAreas();
        assertEquals(2, workAreas.size());
    }
}