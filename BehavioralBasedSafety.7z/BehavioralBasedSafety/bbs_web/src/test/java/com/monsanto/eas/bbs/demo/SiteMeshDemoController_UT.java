/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * SiteMeshDemoController_UT was created on Dec 11, 2009 using Monsanto resources and is the sole property of Monsanto.
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.demo;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 * Filename:    $HeadURL$
 * Label:       $Id$
 * @author      AASEN
 * @version     $Revision$
 *              Last Change: $Author$     On: $Date$
 */
public class SiteMeshDemoController_UT {

  private SiteMeshDemoController siteMeshDemoController = null;

  @Before
  public void setUpBeforeMethod() {
    siteMeshDemoController = new SiteMeshDemoController();
  }

  @After
  public void tearDownAfterMethod() {
    siteMeshDemoController = null;
  }

  /**
   * Method: notNull_siteMeshDemoPage()
   */
  @Test
  public void nonNull_siteMeshDemoPage() {
    assertNotNull(siteMeshDemoController.siteMeshDemoPage());
  }

  /**
   * Method: gettingCorrectSiteMeshDemoPage()
   */
  @Test
  public void gettingCorrectSiteMeshDemoPage() {
    assertEquals("demo/sitemeshDemo/body", siteMeshDemoController.siteMeshDemoPage());
  }


}


