/*
 BBSFilter_UT was created on Dec 23, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.filter;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.eas.bbs.filter.mock.MockUserService;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import org.junit.Test;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockFilterConfig;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import java.security.ProviderException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class BBSFilter_UT {

    @Test
    public void testInit() throws Exception {
        BBSFilter filter = new BBSFilter();
        FilterConfig config = new MockFilterConfig();
        filter.init(config);
        assertNotNull(filter.getConfig());
        assertNotNull(filter);
    }

    @Test
    public void testDestroy() throws Exception {
        BBSFilter filter = new BBSFilter();
        filter.destroy();
        assertNotNull(filter);
    }

    @Test
    public void testDoFilter_UserNotSetInSession_UserIdNotFoundInSecurity_AccessDenied() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();
        BBSFilter filter = new BBSFilter();
        filter.setUserService(new MockUserService(null));
        filter.setSecurity(new MockKerberosSecurity(null));
        filter.doFilter(request, response, chain);
        assertNull(filter.getConfig());
        assertNull(request.getSession().getAttribute(BBSConstants.BBS_USER));
        assertEquals(403, response.getStatus());
    }

    @Test
    public void testDoFilter_UserNotSetInSession_UserNotFoundInDataBase_AccessDenied() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();
        BBSFilter filter = new BBSFilter();
        filter.setUserService(new MockUserService(null));
        filter.setSecurity(new MockKerberosSecurity("testUSER"));
        filter.doFilter(request, response, chain);
        assertNull(filter.getConfig());
        assertNull(request.getSession().getAttribute(BBSConstants.BBS_USER));
        assertEquals(403, response.getStatus());
    }

    @Test
    public void testDoFilter_UserNotSetInSession_UserFound_SetInSession() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();
        BBSFilter filter = new BBSFilter();
        BBSUser bbsUser = new BBSUser();
        bbsUser.setId(new Long(2345));

        filter.setUserService(new MockUserService(bbsUser));
        filter.setSecurity(new MockKerberosSecurity("testUSER"));
        filter.doFilter(request, response, chain);
        bbsUser = (BBSUser) request.getSession().getAttribute(BBSConstants.BBS_USER);
        assertEquals(new Long(2345), bbsUser.getId());
    }

    @Test
    public void testDoFilter_UserIdIsSetInSession() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        BBSUser bbsUser = new BBSUser();
        bbsUser.setId(new Long(1234));
        request.getSession().setAttribute(BBSConstants.BBS_USER, bbsUser);
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();
        BBSFilter filter = new BBSFilter();

        filter.doFilter(request, response, chain);
        bbsUser = (BBSUser) request.getSession().getAttribute(BBSConstants.BBS_USER);
        assertEquals(new Long(1234), bbsUser.getId());
    }

    private class MockKerberosSecurity extends KerberosSecurity {
        private String name;
        private String fullName;

        private MockKerberosSecurity(String name) {
            this.name = name;
        }

        @Override
        public void init(HttpServletRequest request) throws ProviderException {
            fullName = "TEST USER";
        }

        @Override
        public String getUserID() {
            return name;
        }

        @Override
        public String getFullName() {
            return fullName;
        }
    }
}