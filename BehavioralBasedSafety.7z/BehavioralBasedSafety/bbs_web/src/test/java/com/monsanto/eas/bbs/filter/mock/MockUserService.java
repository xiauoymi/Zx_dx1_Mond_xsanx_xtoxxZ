/*
 MockUserService was created on Feb 2, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.filter.mock;

import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.service.UserService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockUserService implements UserService {
    private BBSUser bbsUser;
    private List<BBSUser> savedUsers = new ArrayList<BBSUser>();

    public MockUserService(BBSUser bbsUser) {
        this.bbsUser = bbsUser;
    }

    public void saveOrUpdate(BBSUser user) {
        savedUsers.add(user);
    }

    public BBSUser findByUserID(String user) {
        if ("USER_IN_DB".equalsIgnoreCase(user) || "testUSER".equalsIgnoreCase(user)) {
            return bbsUser;
        }
        return null;
    }

    public List<BBSUser> lookupUserByCriteria(String name) {
        return null;
    }

    public List<BBSUser> lookupAllUsers(boolean active) {
        return null;
    }

    public List<BBSUser> lookUpUsersWithRoles() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }


    public List<BBSUser> getSavedUsers() {
        return savedUsers;
    }
}