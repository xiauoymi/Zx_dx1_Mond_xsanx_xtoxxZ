/*
 Area_UT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class Area_UT {
    Area area;

    @Before
    public void setUp() {
        area = new Area();
    }

    @Test
    public void testConstruct_ObjectNotNull() throws Exception {
        assertNotNull(area);
    }

    @Test
    public void testGetterAndSetters() throws Exception {
        area.setId((long) 100);
        Plant parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        Area parentArea = new Area((long) 1, null, true);
        area.setParentArea(parentArea);
        area.setActive(true);
        assertEquals(new Long(100), area.getId());
        assertEquals(new Long(1), area.getParentArea().getId());
    }

    @Test
    public void testEquals_IdsAreSame_ReturnsTrue() throws Exception {
        area.setId((long) 100);
        Area area1 = new Area();
        area1.setId((long) 100);
        assertTrue(area.equals(area1));
    }

    @Test
    public void testEquals_IdsAreNotSame_ReturnsFalse() throws Exception {
        area.setId((long) 100);
        Plant parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        Area parentArea = new Area((long) 1, null, true);
        area.setParentArea(parentArea);
        area.setActive(true);
        Area area1 = new Area();
        area1.setId((long) 101);
        parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        parentArea = new Area((long) 1, null, true);
        area1.setParentArea(parentArea);
        area1.setActive(true);
        assertTrue(!area.equals(area1));
    }

    @Test
    public void testEquals_AllPropertiesAreSame_ReturnsTrue() throws Exception {
        area.setId((long) 100);
        Plant parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        Area parentArea = new Area((long) 1, null, true);
        area.setParentArea(parentArea);
        area.setActive(true);
        Area area1 = new Area();
        area1.setId((long) 100);
        parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        parentArea = new Area((long) 1, null, true);
        area1.setParentArea(parentArea);
        area1.setActive(true);
        assertTrue(area.equals(area1));
    }

    @Test
    public void testHashCode_SameValuesInObjects_ReturnsFalse() throws Exception {
        area.setId((long) 100);
        Plant parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        Area parentArea = new Area((long) 1, null, true);
        area.setParentArea(parentArea);
        area.setActive(true);
        Area area1 = new Area();
        area1.setId((long) 100);
        parentPlant = new Plant();
        parentPlant.setId((long) 1);
        parentPlant.setPlantCode("P001");
        parentArea = new Area((long) 2, null, true);
        area1.setParentArea(parentArea);
        area1.setActive(true);
        assertTrue(area.hashCode() != area1.hashCode());
    }
}