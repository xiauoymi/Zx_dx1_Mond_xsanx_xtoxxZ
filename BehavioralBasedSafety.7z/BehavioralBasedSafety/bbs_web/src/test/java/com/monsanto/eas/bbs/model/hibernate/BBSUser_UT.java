/*
 BBSUser_UT was created on Feb 2, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.BBSRole;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class BBSUser_UT {

    @Test
    public void testFullName() throws Exception {
        BBSUser user = new BBSUser();
        user.setFirstName("first");
        user.setMiddleName("m");
        user.setLastName("last");
        assertEquals("first m last", user.getFullName());
        user.setMiddleName(null);
        assertEquals("first last", user.getFullName());
    }

    @Test
    public void testIsAdmin_ReturnsFalse() throws Exception {
        BBSUser user = new BBSUser();
        Set<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setDescription("NOTADMIN");
        roles.add(role);
        user.setRoles(roles);

        assertFalse(user.isESHAdmin());
    }

    @Test
    public void testIsAdmin_ReturnsTrue() throws Exception {
        BBSUser user = new BBSUser();
        Set<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setDescription("NOTADMIN");
        roles.add(role);
        role = new BBSRole();
        role.setDescription(BBSUser.ESH_ADMIN);
        roles.add(role);

        user.setRoles(roles);

        assertTrue(user.isESHAdmin());
    }

    @Test
    public void testIsGlobalLead_ReturnsFalse() throws Exception {
        BBSUser user = new BBSUser();
        Set<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setDescription("NOTADMIN");
        roles.add(role);
        user.setRoles(roles);

        assertFalse(user.isGlobalLead());
    }

    @Test
    public void testIsGlobalLead_ReturnsTrue() throws Exception {
        BBSUser user = new BBSUser();
        Set<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setDescription("NOTADMIN");
        roles.add(role);
        role = new BBSRole();
        role.setDescription(BBSUser.GLOBAL_LEAD);
        roles.add(role);

        user.setRoles(roles);

        assertTrue(user.isGlobalLead());
    }
}