package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.BarrierCategory;
import com.monsanto.eas.bbs.hibernate.Category;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Mar 19, 2010
 * Time: 12:24:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class BarrierCategory_UT {

    @Test
    public void testEquals_SetOnlyId() throws Exception {
        BarrierCategory barrierCategory = new BarrierCategory();
        barrierCategory.setId((long) 1);
        BarrierCategory barrierCategoryOne = new BarrierCategory();
        barrierCategoryOne.setId((long) 1);
        assertTrue(barrierCategory.equals(barrierCategoryOne));
    }

    @Test
    public void testEquals_SameObject() throws Exception {
        BarrierCategory barrierCategory = new BarrierCategory();
        assertTrue(barrierCategory.equals(barrierCategory));
    }

    @Test
    public void testEquals_NoBarrierObjectPassed() throws Exception {
        BarrierCategory barrierCategory = new BarrierCategory();
        assertFalse(barrierCategory.equals(new Object()));
    }

    @Test
    public void testEquauls_SetIdCategory() throws Exception {
        BarrierCategory barrierCategory = new BarrierCategory();
        barrierCategory.setId((long) 1);
        Category category = new Category();
        barrierCategory.setCategory(category);
        BarrierCategory barrierCategoryOne = new BarrierCategory();
        barrierCategoryOne.setId((long) 1);
        barrierCategoryOne.setCategory(category);
        assertTrue(barrierCategory.equals(barrierCategoryOne));
    }

    @Test
    public void testHashCode_SetIdCategory() throws Exception {
        BarrierCategory barrierCategory = new BarrierCategory();
        barrierCategory.setId((long) 1);
        Category category = new Category();
        barrierCategory.setCategory(category);
        BarrierCategory barrierCategoryOne = new BarrierCategory();
        barrierCategoryOne.setId((long) 1);
        barrierCategoryOne.setCategory(category);
        assertEquals(barrierCategory.hashCode(), barrierCategoryOne.hashCode());
    }

}
