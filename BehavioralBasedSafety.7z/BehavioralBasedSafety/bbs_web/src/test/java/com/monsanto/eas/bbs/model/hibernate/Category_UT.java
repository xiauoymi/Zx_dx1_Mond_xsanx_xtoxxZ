/*
 Category_UT was created on Jan 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Category;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class Category_UT {

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        Category cat = new Category();
        assertNotNull(cat);
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        Category cat = new Category();
        cat.setActive(true);
        cat.setParentCategory(null);
        cat.setId(new Long(1));
        assertEquals(new Long(1), cat.getId());
        assertNull(cat.getParentCategory());
        assertTrue(cat.isActive());
    }
}