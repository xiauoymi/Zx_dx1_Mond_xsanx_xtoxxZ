package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Plant;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Jan 21, 2010
 * Time: 3:28:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class Country_UT {

    @Test
    public void testCreateCountry() throws Exception {
        Country country = new Country();
        assertNotNull(country);
    }

    @Test
    public void testCreateCountryWithValues() throws Exception {
        Plant plant = new Plant();
        plant.setId((long) 1);
        Set<Plant> plants = new HashSet();
        plants.add(plant);
        Country country = new Country();
        country.setActive(true);
        country.setCountryCode("US");
        country.setDescription("United States");
        country.setId(new Long(1));
        country.setPlants(plants);

        assertEquals("1", country.getId().toString());
        assertEquals("US", country.getCountryCode());
        assertEquals("United States", country.getDescription());
        assertNotNull(country.getPlants());
    }

}
