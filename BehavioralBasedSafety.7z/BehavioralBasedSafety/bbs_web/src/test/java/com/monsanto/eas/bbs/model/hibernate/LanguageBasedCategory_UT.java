/*
 LanguageBasedCategory_UT was created on Jan 15, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Category;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedCategory;
import com.monsanto.eas.bbs.hibernate.LanguageBasedCategoryPK;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class LanguageBasedCategory_UT {

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        assertNotNull(lbc);
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("CategoryForXX");
        LanguageBasedCategoryPK languageBasedCategoryPK = new LanguageBasedCategoryPK();
        languageBasedCategoryPK.setLanguage(lang);
        languageBasedCategoryPK.setCategory(category);
        languageBasedCategory.setId(languageBasedCategoryPK);
        assertEquals("CategoryForXX", languageBasedCategory.getDescription());
        assertEquals(lang, languageBasedCategory.getId().getLanguage());
        assertEquals(category, languageBasedCategory.getId().getCategory());
    }

    @Test
    public void testEquals_IdsAreTheSame_ReturnsTrue() throws Exception {
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("CategoryForXX");
        LanguageBasedCategoryPK languageBasedCategoryPK = new LanguageBasedCategoryPK();
        languageBasedCategoryPK.setLanguage(lang);
        languageBasedCategoryPK.setCategory(category);
        languageBasedCategory.setId(languageBasedCategoryPK);

        category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory1 = new LanguageBasedCategory();
        languageBasedCategory1.setDescription("CategoryForXX");
        LanguageBasedCategoryPK languageBasedCategoryPK1 = new LanguageBasedCategoryPK();
        languageBasedCategoryPK1.setLanguage(lang);
        languageBasedCategoryPK1.setCategory(category);
        languageBasedCategory1.setId(languageBasedCategoryPK);
        assertTrue(languageBasedCategory.equals(languageBasedCategory1));
    }

    @Test
    public void testEquals_IdsAreNotTheSame_ReturnsFalse() throws Exception {
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("CategoryForXX");
        LanguageBasedCategoryPK languageBasedCategoryPK = new LanguageBasedCategoryPK();
        languageBasedCategoryPK.setLanguage(lang);
        languageBasedCategoryPK.setCategory(category);
        languageBasedCategory.setId(languageBasedCategoryPK);

        category = new Category();
        category.setActive(true);
        category.setId(new Long(2));

        lang = new Language();
        lang.setId(new Long(2));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory1 = new LanguageBasedCategory();
        languageBasedCategory1.setDescription("Category2ForXX");
        LanguageBasedCategoryPK languageBasedCategoryPK1 = new LanguageBasedCategoryPK();
        languageBasedCategoryPK1.setLanguage(lang);
        languageBasedCategoryPK1.setCategory(category);
        languageBasedCategory1.setId(languageBasedCategoryPK);
        assertTrue(!languageBasedCategory.equals(languageBasedCategory1));
    }

    @Test
    public void CompareTo() throws Exception {
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("ENGLISH");
        lang.setLocale("en");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("Category1ForEN");
        LanguageBasedCategoryPK languageBasedCategoryPK = new LanguageBasedCategoryPK();
        languageBasedCategoryPK.setLanguage(lang);
        languageBasedCategoryPK.setCategory(category);
        languageBasedCategory.setId(languageBasedCategoryPK);

        category = new Category();
        category.setActive(true);
        category.setId(new Long(2));

        lang = new Language();
        lang.setId(new Long(2));
        lang.setDescription("FRENCH");
        lang.setLocale("fr");
        lang.setActive(true);

        LanguageBasedCategory languageBasedCategory1 = new LanguageBasedCategory();
        languageBasedCategory1.setDescription("Category2ForFR");
        LanguageBasedCategoryPK languageBasedCategoryPK1 = new LanguageBasedCategoryPK();
        languageBasedCategoryPK1.setLanguage(lang);
        languageBasedCategoryPK1.setCategory(category);
        languageBasedCategory1.setId(languageBasedCategoryPK);
        assertTrue(languageBasedCategory.compareTo(languageBasedCategory1) < 0);
    }
}