/*
 LanguageBasedResponse_UT was created on Jan 20, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedResponse;
import com.monsanto.eas.bbs.hibernate.LanguageBasedResponsePK;
import com.monsanto.eas.bbs.hibernate.Response;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class LanguageBasedResponse_UT {

    @Test
    public void Constructor_ObjectNotNull() throws Exception {
        LanguageBasedResponse response = new LanguageBasedResponse();
        assertNotNull(response);
    }

    @Test
    public void GettersAndSetters() throws Exception {
        LanguageBasedResponse languageBasedResponse = new LanguageBasedResponse();

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        Response response = new Response();
        response.setId(new Long(2));
        response.setActive(true);

        LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
        pk.setLanguage(lang);
        pk.setResponse(response);

        languageBasedResponse.setId(pk);
        languageBasedResponse.setDescription("positive");

        assertEquals(1L, languageBasedResponse.getId().getLanguage().getId().longValue());
        assertEquals(2L, languageBasedResponse.getId().getResponse().getId().longValue());
        assertEquals("positive", languageBasedResponse.getDescription());
    }

    @Test
    public void testEquals_IdsAreTheSame_ReturnsTrue() throws Exception {
        LanguageBasedResponse languageBasedResponse = new LanguageBasedResponse();

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        Response response = new Response();
        response.setId(new Long(2));
        response.setActive(true);

        LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
        pk.setLanguage(lang);
        pk.setResponse(response);

        languageBasedResponse.setId(pk);
        languageBasedResponse.setDescription("positive");


        lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        response = new Response();
        response.setId(new Long(2));
        response.setActive(true);

        LanguageBasedResponsePK pk1 = new LanguageBasedResponsePK();
        pk1.setLanguage(lang);
        pk1.setResponse(response);

        languageBasedResponse.setId(pk1);

        LanguageBasedResponse languageBasedResponse1 = new LanguageBasedResponse();

        languageBasedResponse1.setId(pk1);
        languageBasedResponse1.setDescription("positive");

        assertTrue(languageBasedResponse.equals(languageBasedResponse1));
    }


    @Test
    public void testEquals_IdsAreNotTheSame_ReturnsFalse() throws Exception {
        LanguageBasedResponse languageBasedResponse = new LanguageBasedResponse();

        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("XX");
        lang.setLocale("xx");
        lang.setActive(true);

        Response response = new Response();
        response.setId(new Long(2));
        response.setActive(true);

        LanguageBasedResponsePK pk = new LanguageBasedResponsePK();
        pk.setLanguage(lang);
        pk.setResponse(response);

        languageBasedResponse.setId(pk);
        languageBasedResponse.setDescription("positive");


        lang = new Language();
        lang.setId(new Long(3));
        lang.setDescription("YY");
        lang.setLocale("yy");
        lang.setActive(true);

        response = new Response();
        response.setId(new Long(4));
        response.setActive(true);

        LanguageBasedResponsePK pk1 = new LanguageBasedResponsePK();
        pk1.setLanguage(lang);
        pk1.setResponse(response);

        languageBasedResponse.setId(pk1);

        LanguageBasedResponse languageBasedResponse1 = new LanguageBasedResponse();

        languageBasedResponse1.setId(pk1);
        languageBasedResponse1.setDescription("negative");

        assertTrue(!languageBasedResponse.equals(languageBasedResponse1));
    }
}