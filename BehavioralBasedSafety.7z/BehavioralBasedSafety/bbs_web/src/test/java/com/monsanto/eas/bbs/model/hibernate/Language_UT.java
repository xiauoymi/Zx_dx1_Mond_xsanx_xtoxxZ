/*
 Language_UT was created on Jan 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Category;
import com.monsanto.eas.bbs.hibernate.Language;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class Language_UT {

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        Language lang = new Language();
        assertNotNull(lang);
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("ENGLISH");
        lang.setLocale("en");
        lang.setActive(true);
        assertEquals(new Long(1), lang.getId());
        assertTrue("ENGLISH".equalsIgnoreCase(lang.getDescription()));
        assertTrue("en".equalsIgnoreCase(lang.getLocale()));
        assertTrue(lang.isActive());
    }

    @Test
    public void testLookupLanguageBasedBehaviors_ListOfBehaviorsReturned() throws Exception {
        Category category = new Category();
        category.setActive(true);
        Category subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        Category subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setActive(true);
        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setDescription("ENGLISH");
        lang.setLocale("en");
        lang.setActive(true);
    }

    @Test
    public void testEquals_SameIds_ReturnsTrue() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        Language lang1 = new Language();
        lang1.setId(new Long(1));
        assertTrue(lang.equals(lang1));
    }

    @Test
    public void testEquals_ObjectsNotSameType() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        assertFalse(lang.equals(new Object()));
    }

    @Test
    public void testHashCode_SameObjects_ReturnsTrue() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setLocale("yy");
        lang.setActive(true);
        lang.setDescription("test");
        Language lang1 = new Language();
        lang1.setId(new Long(2));
        lang1.setLocale("xx");
        lang1.setActive(true);
        lang1.setDescription("first");
        assertTrue(lang.hashCode() != lang1.hashCode());
    }

    @Test
    public void testEquals_DifferentLanguages_ReturnsFalse() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        lang.setLocale("te");
        lang.setActive(true);
        lang.setDescription("Test");
        Language lang1 = new Language();
        lang.setId(new Long(2));
        lang.setLocale("xe");
        lang.setActive(true);
        lang.setDescription("Best");
        assertTrue(!lang.equals(lang1));
    }
}