/*
 Observation_UT was created on Jan 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.*;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class Observation_UT {

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        Observation observation = new Observation();
        assertNotNull(observation);
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
                "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());

        BBSUser user = new BBSUser(new Long(1), "ABC123", "FIRST", "LAST", "M", true, new Date(), "TEST", new Date());

        Area area = new Area(new Long(100), null, true);
        Area subArea = new Area(new Long(101), area, true);


        SafetyGroup group = new SafetyGroup(new Long(1), "ABC001", plant, true, false);

        Response response = new Response();
        response.setId(new Long(1));
        response.setActive(true);
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Category subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        subCategory.setId(new Long(2));

        Category subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setId(new Long(3));
        subSubCategory.setActive(true);

        PersonnelType personnelType = new PersonnelType();
        personnelType.setActive(true);

        Observation observation = new Observation();
        observation.setArea(area);
        observation.setSubArea(subArea);
        observation.setDateEntered(new Date());
        observation.setPlant(plant);
        observation.setSafetyGroup(group);
        observation.setPersonnelType(personnelType);
        observation.setId(new Long(1));
        observation.setEnteredBy(user);

        assertEquals(new Long(1), observation.getId());
        assertEquals(user.getUserId(), observation.getEnteredBy().getUserId());
        assertEquals(personnelType, observation.getPersonnelType());
        assertEquals(group, observation.getSafetyGroup());
        assertEquals(plant, observation.getPlant());
        assertEquals(subArea, observation.getSubArea());
        assertEquals(area, observation.getArea());
    }
}