/*
 Plant_UT was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import org.junit.Test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class Plant_UT {

    @Test
    public void testConstruct_ObjectNotNull() throws Exception {
        Plant plant = new Plant();
        assertNotNull(plant);
    }

    @Test
    public void testConstructor_ValuesForEachMemberSet() throws Exception {
        Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
                "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
        Area area = new Area();
        area.setId(new Long(100));
        area.setActive(true);
        Set<Area> areas = new HashSet<Area>();
        areas.add(area);
        plant.setAreas(areas);


        Set<SafetyGroup> groups = new HashSet<SafetyGroup>();
        SafetyGroup group = new SafetyGroup();
        group.setActive(true);
        group.setGroupText("Test");
        group.setPlant(plant);
        group.setId(new Long(111));
        groups.add(group);
        plant.setSafetyGroups(groups);

        assertEquals(new Long(1), plant.getId());
        assertTrue(plant.isActive());
        assertEquals("NA", plant.getPorg());
        assertEquals("Java", plant.getCity());
        assertEquals("12345", plant.getPostalCode());
        assertEquals("PO BOX 1234", plant.getPoBox());
        assertEquals("Java World", plant.getStreet());
        assertEquals("Plant Name 2", plant.getPlantName2());
        assertEquals("Plant Name 1", plant.getPlantName1());
        assertEquals("vala", plant.getVala());
        assertEquals("001", plant.getCal());
        assertEquals("V001", plant.getVendorNbrForPlant());
        assertEquals("C001", plant.getCustomerNumberForPlant());
        assertEquals("P001", plant.getPlantCode());
        assertEquals(1, plant.getAreas().size());
        for (Area area2 : plant.getAreas()) {
            assertTrue(area2.equals(area));
        }

        assertEquals(1, plant.getSafetyGroups().size());
        for (SafetyGroup sg : plant.getSafetyGroups()) {
            assertTrue(sg.equals(group));
            assertTrue(sg.getPlant().equals(plant));
        }
    }

    @Test
    public void testPlantDescription() throws Exception {
        Plant plant = new Plant();
        plant.setRegionDescription("NORTH AMERICA");
        assertEquals(plant.getRegionDescription(), "NORTH AMERICA");
    }
}