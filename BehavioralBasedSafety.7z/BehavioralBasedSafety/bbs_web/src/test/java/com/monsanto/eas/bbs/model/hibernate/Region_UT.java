/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Region;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class Region_UT {

    @Test
    public void testRegionConstructor() throws Exception {
        Region region = new Region();
        assertNotNull(region);
    }

    @Test
    public void testRegionMethods() throws Exception {
        Region region = new Region();
        region.setId(new Long(2));
        region.setDescription("LATIN AMERICA SOUTH");
        assertEquals(new Long(2), region.getId());
        assertEquals("LATIN AMERICA SOUTH", region.getDescription());
    }
}