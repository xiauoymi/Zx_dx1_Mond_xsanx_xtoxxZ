/*
 Response_UT was created on Jan 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Response;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class Response_UT {

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        Response response = new Response();
        assertNotNull(response);
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        Response response = new Response();
        response.setActive(true);
        response.setId(new Long(1));
        assertEquals(new Long(1), response.getId());
        assertTrue(response.isActive());
    }
}