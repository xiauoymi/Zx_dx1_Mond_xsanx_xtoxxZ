/*
 SafetyGroup_UT was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class SafetyGroup_UT {

    SafetyGroup safety;

    @Before
    public void setUp() {
        safety = new SafetyGroup();
    }

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        assertNotNull(safety);
    }

    @Test
    public void testValues_AllMemberVariablesAreSet() throws Exception {
        Plant plant = new Plant();
        plant.setId(new Long(1));
        plant.setPlantCode("P001");
        plant.setPlantName1("Malus");
        plant.setPlantName2("Domestica");
        safety = new SafetyGroup(new Long(100), "S0001", plant, true, false);
        assertEquals(new Long(100), safety.getId());
        assertEquals("S0001", safety.getGroupText());
        assertEquals(new Long(1), safety.getPlant().getId());
        assertEquals("P001", safety.getPlant().getPlantCode());
        assertEquals("Malus", safety.getPlant().getPlantName1());
        assertEquals("Domestica", safety.getPlant().getPlantName2());
        assertTrue(safety.isActive());
    }
}