/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.model.hibernate;

import com.monsanto.eas.bbs.hibernate.WorkArea;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class WorkArea_UT {

    private final String description = "SANTA HELENA DEGOIAS";
    private final String plantCode = "1076";

    @Test
    public void testWorkAreaConstructor() throws Exception {
        final WorkArea workArea = new WorkArea();
        assertNotNull(workArea);
    }

    @Test
    public void testWorkArea() throws Exception {
        final WorkArea workArea = new WorkArea();
        workArea.setDescription(description);
        workArea.setPlantCode(plantCode);
        assertEquals(description, workArea.getDescription());
        assertEquals(plantCode, workArea.getPlantCode());
    }
}
