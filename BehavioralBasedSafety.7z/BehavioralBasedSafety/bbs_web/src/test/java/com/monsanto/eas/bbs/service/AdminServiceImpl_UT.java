package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.dataimport.PlantAreaTO;
import com.monsanto.eas.bbs.filter.mock.MockUserService;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockAreaDAO;
import com.monsanto.eas.bbs.service.mock.MockCategoryDAO;
import com.monsanto.eas.bbs.service.mock.MockLanguageBasedAreaDAO;
import com.monsanto.eas.bbs.service.mock.MockLangugageDAO;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class AdminServiceImpl_UT {

    private LanguageDAO langugageDAO;
    private MockAreaDAO areaDAO;
    private MockCategoryDAO categoryDAO;
    private MockUserService userService;
    private MockLanguageBasedAreaDAO languageBasedAreaDAO;

    @Before
    public void setUp() {
        LocaleContextHolder.setLocale(new Locale("en"));
        categoryDAO = new MockCategoryDAO(null, null, null);
        areaDAO = new MockAreaDAO(null, null);
        langugageDAO = new MockLangugageDAO();
        langugageDAO = new MockLangugageDAO();
        languageBasedAreaDAO = new MockLanguageBasedAreaDAO();
        userService = new MockUserService(new BBSUser());
    }

    @Test
    public void SaveUsers_IdIsEmpty_UserNotInDatabase_Saved() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, userService, languageBasedAreaDAO);
        List<BBSUser> bbsUsers = new ArrayList<BBSUser>();
        BBSUser user = new BBSUser();
        user.setUserId("USER_NOT_IN_DB");
        bbsUsers.add(user);
        List<String> errors = service.saveUsers(bbsUsers);
        List<BBSUser> savedUsers = ((MockUserService) userService).getSavedUsers();
        assertEquals(1, savedUsers.size());
        assertEquals(0, errors.size());
    }

    @Test
    public void testSaveUsers_UsersSaved() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, userService, languageBasedAreaDAO);
        List<BBSUser> bbsUsers = new ArrayList<BBSUser>();
        bbsUsers.add(new BBSUser());
        bbsUsers.add(new BBSUser());
        List<String> errors = service.saveUsers(bbsUsers);
        List<BBSUser> savedUsers = ((MockUserService) userService).getSavedUsers();
        assertEquals(2, savedUsers.size());
        assertEquals(0, errors.size());
    }

    @Test
    public void testsaveLanguageBasedCategory_NewCategory_TranslateAndSave() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, userService, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        pk.setCategory(new Category());
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(3, savedLanguageBasedCatories.size());

        final Iterator<LanguageBasedCategory> iterator = savedLanguageBasedCatories.iterator();
        LanguageBasedCategory basedCategory = iterator.next();
        assertEquals(new Long(1234), basedCategory.getId().getCategory().getId());
        assertEquals("English", basedCategory.getId().getLanguage().getDescription());
        assertEquals("in english", basedCategory.getDescription());
        basedCategory = iterator.next();
        assertEquals(new Long(1234), basedCategory.getId().getCategory().getId());
        assertEquals("Spanish", basedCategory.getId().getLanguage().getDescription());
        assertEquals("in english", basedCategory.getDescription());
        basedCategory = iterator.next();
        assertEquals(new Long(1234), basedCategory.getId().getCategory().getId());
        assertEquals("Hindi", basedCategory.getId().getLanguage().getDescription());
        assertEquals("in english", basedCategory.getDescription());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(6, savedCategories.size());
        assertFalse(savedCategories.iterator().next().isActive());
    }

    @Test
    public void testsaveLanguageBasedCategory_ExistingCategory_DontTranslateSave() throws Exception {
        LanguageBasedCategory existingLbc = new LanguageBasedCategory();
        LanguageBasedCategoryPK pkCat = new LanguageBasedCategoryPK();
        existingLbc.setId(pkCat);
        Category cat = new Category();
        cat.setId(new Long(234));
        pkCat.setCategory(cat);

        categoryDAO = new MockCategoryDAO(existingLbc, null, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category category = new Category();
        category.setId(new Long(234));
        category.setActive(true);
        pk.setCategory(category);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(1, savedLanguageBasedCatories.size());

        final Iterator<LanguageBasedCategory> iterator = savedLanguageBasedCatories.iterator();
        LanguageBasedCategory basedCategory = iterator.next();
        assertEquals(new Long(1234), basedCategory.getId().getCategory().getId());
        assertEquals("English", basedCategory.getId().getLanguage().getDescription());
        assertEquals("in english", basedCategory.getDescription());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(0, savedCategories.size());
    }

    @Test
    public void testsaveLanguageBasedCategory_UpdateCategoryAlreadyExists_NotSaved() throws Exception {
        LanguageBasedCategory existingLbc = new LanguageBasedCategory();
        existingLbc.setDescription("EXISTING CAT");
        LanguageBasedCategoryPK pkCat = new LanguageBasedCategoryPK();
        existingLbc.setId(pkCat);
        Category cat = new Category();
        cat.setActive(true);
        cat.setId(new Long(12));
        pkCat.setCategory(cat);

        categoryDAO = new MockCategoryDAO(existingLbc, null, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category category = new Category();
        category.setId(new Long(234));
        category.setActive(true);
        pk.setCategory(category);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(1, errorMap.size());
        assertEquals("Active Category with this description already exists - EXISTING CAT", errorMap.get("category"));

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(0, savedLanguageBasedCatories.size());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(0, savedCategories.size());
    }

    @Test
    public void testsaveLanguageBasedCategory_NewCategoryAlreadyExists_NotSaved() throws Exception {
        LanguageBasedCategory existingLbc = new LanguageBasedCategory();
        existingLbc.setDescription("EXISTING CAT");
        LanguageBasedCategoryPK pkCat = new LanguageBasedCategoryPK();
        existingLbc.setId(pkCat);
        Category cat = new Category();
        cat.setId(new Long(12));
        pkCat.setCategory(cat);

        categoryDAO = new MockCategoryDAO(existingLbc, null, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category category = new Category();
        category.setActive(true);
        pk.setCategory(category);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(1, errorMap.size());
        assertEquals("Inactive Category with this description already exists - EXISTING CAT", errorMap.get("newCategory"));

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(0, savedLanguageBasedCatories.size());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(0, savedCategories.size());
    }

    @Test
    public void testsaveLanguageBasedCategory_NewSubCategoryAlreadyExists_NotSaved() throws Exception {
        LanguageBasedCategory existingLbc = new LanguageBasedCategory();
        existingLbc.setDescription("EXISTING CAT");
        LanguageBasedCategoryPK pkCat = new LanguageBasedCategoryPK();
        existingLbc.setId(pkCat);
        Category cat = new Category();
        cat.setParentCategory(new Category());
        cat.setId(new Long(12));
        pkCat.setCategory(cat);

        categoryDAO = new MockCategoryDAO(null, existingLbc, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category category = new Category();
        category.setActive(true);
        category.setParentCategory(new Category());
        pk.setCategory(category);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(1, errorMap.size());
        assertEquals("Inactive Sub Category with this description already exists - EXISTING CAT", errorMap.get("newSubCategory"));

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(0, savedLanguageBasedCatories.size());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(0, savedCategories.size());
    }

    @Test
    public void testsaveLanguageBasedCategory_UpdateDetailCategoryAlreadyExists_NotSaved() throws Exception {
        LanguageBasedCategory existingLbc = new LanguageBasedCategory();
        existingLbc.setDescription("EXISTING CAT");
        LanguageBasedCategoryPK pkCat = new LanguageBasedCategoryPK();
        existingLbc.setId(pkCat);
        Category cat = new Category();
        Category parentCat = new Category();
        parentCat.setParentCategory(new Category());
        cat.setParentCategory(parentCat);
        cat.setActive(true);
        cat.setId(new Long(12));
        pkCat.setCategory(cat);

        categoryDAO = new MockCategoryDAO(null, existingLbc, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedCategory lbc = new LanguageBasedCategory();
        lbc.setDescription("in english");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        Category category = new Category();
        category.setActive(true);
        Category parentCategory = new Category();
        parentCategory.setParentCategory(new Category());
        category.setParentCategory(parentCategory);
        pk.setCategory(category);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBasedCategory> lbcs = new ArrayList<LanguageBasedCategory>();
        lbcs.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBasedCategories(lbcs);
        assertEquals(1, errorMap.size());
        assertEquals("Active Detail Category with this description already exists - EXISTING CAT", errorMap.get("newSubSubCategory"));

        final Collection<LanguageBasedCategory> savedLanguageBasedCatories = categoryDAO.getSavedLanguageBasedCatories();
        assertEquals(0, savedLanguageBasedCatories.size());

        final Collection<Category> savedCategories = categoryDAO.getSavedCategories();
        assertEquals(0, savedCategories.size());
    }

    @Test
    public void testsaveLanguageBarrierCategory_NewBarrier_TranslateAndSave() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBarrierCategory lbc = new LanguageBarrierCategory();
        lbc.setDescription("in english");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();
        BarrierCategory barrierCategory = new BarrierCategory();
        pk.setBarrierCategory(barrierCategory);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBarriers(barriers);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBarrierCategory> savedLanguageBasedCatories = categoryDAO
                .getSavedLanguageBarrierCategories();
        assertEquals(3, savedLanguageBasedCatories.size());

        final Iterator<LanguageBarrierCategory> iterator = savedLanguageBasedCatories.iterator();
        LanguageBarrierCategory languageBarrierCategory = iterator.next();
        assertEquals(new Long(1234), languageBarrierCategory.getId().getBarrierCategory().getId());
        assertEquals("English", languageBarrierCategory.getId().getLanguage().getDescription());
        assertEquals("in english", languageBarrierCategory.getDescription());
        languageBarrierCategory = iterator.next();
        assertEquals(new Long(1234), languageBarrierCategory.getId().getBarrierCategory().getId());
        assertEquals("Spanish", languageBarrierCategory.getId().getLanguage().getDescription());
        assertEquals("in english", languageBarrierCategory.getDescription());
        languageBarrierCategory = iterator.next();
        assertEquals(new Long(1234), languageBarrierCategory.getId().getBarrierCategory().getId());
        assertEquals("Hindi", languageBarrierCategory.getId().getLanguage().getDescription());
        assertEquals("in english", languageBarrierCategory.getDescription());
    }

    @Test
    public void testsaveLanguageBarrierCategory_ExistingBarrier_DontTranslateAndSave() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBarrierCategory lbc = new LanguageBarrierCategory();
        lbc.setDescription("in english");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();
        BarrierCategory barrierCategory = new BarrierCategory();
        barrierCategory.setId(new Long(234));
        pk.setBarrierCategory(barrierCategory);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBarriers(barriers);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBarrierCategory> savedLanguageBasedCatories = categoryDAO
                .getSavedLanguageBarrierCategories();
        assertEquals(1, savedLanguageBasedCatories.size());

        final Iterator<LanguageBarrierCategory> iterator = savedLanguageBasedCatories.iterator();
        LanguageBarrierCategory languageBarrierCategory = iterator.next();
        assertEquals(new Long(1234), languageBarrierCategory.getId().getBarrierCategory().getId());
        assertEquals("English", languageBarrierCategory.getId().getLanguage().getDescription());
        assertEquals("in english", languageBarrierCategory.getDescription());
    }

    @Test
    public void testsaveLanguageBarrierCategory_NewBarrierAlreadyExists_NotSaved() throws Exception {
        LanguageBarrierCategory existingLanguageBarrierCategory = new LanguageBarrierCategory();
        existingLanguageBarrierCategory.setDescription("EXISTING BARRIER");
        LanguageBarrierCategoryPK pkBarrier = new LanguageBarrierCategoryPK();
        BarrierCategory barrier = new BarrierCategory();
        barrier.setId(new Long(12));
        pkBarrier.setBarrierCategory(barrier);
        existingLanguageBarrierCategory.setId(pkBarrier);

        categoryDAO = new MockCategoryDAO(null, null, existingLanguageBarrierCategory);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBarrierCategory lbc = new LanguageBarrierCategory();
        lbc.setDescription("in english");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();
        BarrierCategory barrierCategory = new BarrierCategory();
        pk.setBarrierCategory(barrierCategory);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBarriers(barriers);
        assertEquals(1, errorMap.size());
        assertEquals("Inactive Barrier with this description already exists - in english", errorMap.get("newBarrier"));

        final Collection<LanguageBarrierCategory> savedLanguageBasedCatories = categoryDAO
                .getSavedLanguageBarrierCategories();
        assertEquals(0, savedLanguageBasedCatories.size());
    }

    @Test
    public void testsaveLanguageBarrierCategory_UpdateBarrierAlreadyExists_NotSaved() throws Exception {
        LanguageBarrierCategory existingLanguageBarrierCategory = new LanguageBarrierCategory();
        existingLanguageBarrierCategory.setDescription("EXISTING BARRIER");
        LanguageBarrierCategoryPK pkBarrier = new LanguageBarrierCategoryPK();
        BarrierCategory barrier = new BarrierCategory();
        barrier.setActive(true);
        barrier.setId(new Long(12));
        pkBarrier.setBarrierCategory(barrier);
        existingLanguageBarrierCategory.setId(pkBarrier);

        categoryDAO = new MockCategoryDAO(null, null, existingLanguageBarrierCategory);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBarrierCategory lbc = new LanguageBarrierCategory();
        lbc.setDescription("in english");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();
        BarrierCategory barrierCategory = new BarrierCategory();
        barrierCategory.setId(new Long(234));
        pk.setBarrierCategory(barrierCategory);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lbc.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(lbc);
        Map<String, String> errorMap = service.saveLanguageBarriers(barriers);
        assertEquals(1, errorMap.size());
        assertEquals("Active Barrier with this description already exists - in english", errorMap.get("barrier"));

        final Collection<LanguageBarrierCategory> savedLanguageBasedCatories = categoryDAO
                .getSavedLanguageBarrierCategories();
        assertEquals(0, savedLanguageBasedCatories.size());
    }

    @Test
    public void testSaveLanguageBasedArea_NewArea_DontTranslateAndSave() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(3, savedLanguageBasedAreas.size());

        final Iterator<LanguageBasedArea> iterator = savedLanguageBasedAreas.iterator();
        LanguageBasedArea basedArea = iterator.next();
        assertEquals(new Long(1234), basedArea.getId().getArea().getId());
        assertEquals("English", basedArea.getId().getLanguage().getDescription());
        assertEquals("in english", basedArea.getDescription());
        basedArea = iterator.next();
        assertEquals(new Long(1234), basedArea.getId().getArea().getId());
        assertEquals("Spanish", basedArea.getId().getLanguage().getDescription());
        assertEquals("in english", basedArea.getDescription());
        basedArea = iterator.next();
        assertEquals(new Long(1234), basedArea.getId().getArea().getId());
        assertEquals("Hindi", basedArea.getId().getLanguage().getDescription());
        assertEquals("in english", basedArea.getDescription());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(2, savedAreas.size());
        assertFalse(savedAreas.iterator().next().isActive());
    }

    @Test
    public void testSaveLanguageBasedArea_ExistingArea_DontTranslateAndSave() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        area.setId(new Long(234));
        area.setActive(true);
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(0, errorMap.size());

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(1, savedLanguageBasedAreas.size());

        final Iterator<LanguageBasedArea> iterator = savedLanguageBasedAreas.iterator();
        LanguageBasedArea basedArea = iterator.next();
        assertEquals(new Long(1234), basedArea.getId().getArea().getId());
        assertEquals("English", basedArea.getId().getLanguage().getDescription());
        assertEquals("in english", basedArea.getDescription());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(0, savedAreas.size());
    }

    @Test
    public void testSaveLanguageBasedArea_NewAreaDescAlreadyExists_NotSaved() throws Exception {
        LanguageBasedArea exisingLBA = new LanguageBasedArea();
        exisingLBA.setDescription("EXISTING AREA");
        LanguageBasedAreaPK areaPK = new LanguageBasedAreaPK();
        Area existingArea = new Area();
        existingArea.setActive(true);
        existingArea.setId(new Long(12));
        areaPK.setArea(existingArea);
        exisingLBA.setId(areaPK);
        //areaDAO = new MockAreaDAO(exisingLBA, null);
        languageBasedAreaDAO = new MockLanguageBasedAreaDAO(exisingLBA, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        area.setActive(true);
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(1, errorMap.size());
        assertEquals("Active Work Area with this description already exists - in english", errorMap.get("newArea"));

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(0, savedLanguageBasedAreas.size());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(0, savedAreas.size());
    }

    @Test
    public void testSaveLanguageBasedArea_UpdateAreaDescAlreadyExists_NotSaved() throws Exception {
        LanguageBasedArea exisingLBA = new LanguageBasedArea();
        exisingLBA.setDescription("EXISTING AREA");
        LanguageBasedAreaPK areaPK = new LanguageBasedAreaPK();
        Area existingArea = new Area();
        existingArea.setId(new Long(12));
        areaPK.setArea(existingArea);
        exisingLBA.setId(areaPK);
        //areaDAO = new MockAreaDAO(exisingLBA, null);
        languageBasedAreaDAO = new MockLanguageBasedAreaDAO(exisingLBA, null);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        area.setId(new Long(234));
        area.setActive(true);
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(1, errorMap.size());
        assertEquals("Inactive Work Area with this description already exists - in english", errorMap.get("area"));

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(0, savedLanguageBasedAreas.size());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(0, savedAreas.size());
    }

    @Test
    public void testSaveLanguageBasedArea_NewSubAreaDescAlreadyExists_NotSaved() throws Exception {
        LanguageBasedArea exisingLBA = new LanguageBasedArea();
        exisingLBA.setDescription("EXISTING AREA");
        LanguageBasedAreaPK areaPK = new LanguageBasedAreaPK();
        Area existingArea = new Area();
        existingArea.setId(new Long(12));
        areaPK.setArea(existingArea);
        exisingLBA.setId(areaPK);
        languageBasedAreaDAO = new MockLanguageBasedAreaDAO(null, exisingLBA);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        area.setParentArea(new Area());
        area.setActive(true);
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(1, errorMap.size());
        assertEquals("Inactive Work Area with this description already exists - in english", errorMap.get("newSubArea"));

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(0, savedLanguageBasedAreas.size());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(0, savedAreas.size());
    }

    @Test
    public void testSaveLanguageBasedArea_UpdateSubAreaDescAlreadyExists_NotSaved() throws Exception {
        LanguageBasedArea exisingLBA = new LanguageBasedArea();
        exisingLBA.setDescription("EXISTING AREA");
        LanguageBasedAreaPK areaPK = new LanguageBasedAreaPK();
        Area existingArea = new Area();
        existingArea.setActive(true);
        existingArea.setId(new Long(12));
        areaPK.setArea(existingArea);
        exisingLBA.setId(areaPK);
        //areaDAO = new MockAreaDAO(null, exisingLBA);
        languageBasedAreaDAO = new MockLanguageBasedAreaDAO(null, exisingLBA);
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        LanguageBasedArea lba = new LanguageBasedArea();
        lba.setDescription("in english");
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area = new Area();
        area.setId(new Long(123));
        area.setParentArea(new Area());
        area.setActive(true);
        pk.setArea(area);
        Language language = new Language();
        language.setId(new Long(1));
        language.setDescription("English");
        pk.setLanguage(language);
        lba.setId(pk);
        List<LanguageBasedArea> lbas = new ArrayList<LanguageBasedArea>();
        lbas.add(lba);
        Map<String, String> errorMap = service.saveLanguageBasedAreas(lbas);
        assertEquals(1, errorMap.size());
        assertEquals("Active Work Area with this description already exists - in english", errorMap.get("subArea"));

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(0, savedLanguageBasedAreas.size());

        final Collection<Area> savedAreas = areaDAO.getSavedAreas();
        assertEquals(0, savedAreas.size());
    }

    @Test
    public void testAddPlantArea_Save() throws Exception {
        AdminService service = new AdminServiceImpl(areaDAO, categoryDAO, langugageDAO, null, languageBasedAreaDAO);
        List<PlantAreaTO> plantAreas = new ArrayList<PlantAreaTO>();
        PlantAreaTO plantArea = new PlantAreaTO();
        plantArea.setArea(new Area());
        Language lang = new Language();
        lang.setId(new Long(222));
        plantArea.setLanguage(lang);
        plantArea.setPlant(new Plant());
        plantAreas.add(plantArea);

        plantArea = new PlantAreaTO();
        Area area = new Area();
        area.setId(new Long(234));
        plantArea.setArea(area);
        Language language = new Language();
        language.setId(new Long(111));
        plantArea.setLanguage(language);
        Plant plant = new Plant();
        plant.setId(new Long(222));
        plantArea.setPlant(plant);
        plantAreas.add(plantArea);

        service.addPlantAreas(plantAreas);
        assertEquals(2, areaDAO.getPlantAreas().size());

        final Collection<LanguageBasedArea> savedLanguageBasedAreas = languageBasedAreaDAO.getLanguageBasedAreas();
        assertEquals(4, savedLanguageBasedAreas.size());
        assertEquals(new Long(1234), savedLanguageBasedAreas.iterator().next().getId().getArea().getId());
        assertEquals(new Long(222), savedLanguageBasedAreas.iterator().next().getId().getLanguage().getId());
    }
}