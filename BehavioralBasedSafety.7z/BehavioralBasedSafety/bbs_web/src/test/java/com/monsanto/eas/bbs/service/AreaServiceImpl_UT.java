/*
 AreaServiceImpl_UT was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.Language;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.service.mock.MockLanguageBasedAreaDAO;
import com.monsanto.eas.bbs.service.mock.MockLangugageDAO;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class AreaServiceImpl_UT {

    @Test
    public void testGetAllParentAreasAndSubAreas_ListReturned() throws Exception {
        LanguageBasedAreaDAO languageBasedAreaDAO = new MockLanguageBasedAreaDAO();
        LanguageDAO languageDao = new MockLangugageDAO();

        AreaServiceImpl areaService = new AreaServiceImpl(languageBasedAreaDAO, languageDao);

        List<Language> languages = areaService.lookupLanguageAndAreas();
        assertNotNull(languages);
        assertEquals(3, languages.size());
        Language language = languages.iterator().next();
        assertEquals("English", language.getDescription());
        assertEquals(2, language.getLanguageBasedParentAreas().size());
        LanguageBasedArea parentArea = language.getLanguageBasedParentAreas().iterator().next();
        assertEquals("K Cafe", parentArea.getDescription());
        assertEquals(2, parentArea.getId().getArea().getLanguageBasedSubAreas().size());
        LanguageBasedArea subArea = parentArea.getId().getArea().getLanguageBasedSubAreas().iterator().next();
        assertEquals("Pizza Bar", subArea.getDescription());
    }

    @Test
    public void testGetAllParentAreasAndSubAreasForPlant_ListReturned() throws Exception {
        LanguageBasedAreaDAO languageBasedAreaDAO = new MockLanguageBasedAreaDAO();
        LanguageDAO languageDao = new MockLangugageDAO();

        Plant plant = new Plant();
        plant.setId(new Long(1));
        AreaServiceImpl areaService = new AreaServiceImpl(languageBasedAreaDAO, languageDao);

        List<Language> languages = areaService.lookupPlantLanguageAndAreas(plant);
        assertNotNull(languages);
        assertEquals(3, languages.size());
        Language language = languages.iterator().next();
        assertEquals("English", language.getDescription());
        assertEquals(2, language.getLanguageBasedParentAreas().size());
    }
}