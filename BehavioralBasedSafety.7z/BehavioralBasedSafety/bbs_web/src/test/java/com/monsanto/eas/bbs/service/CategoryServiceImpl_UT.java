/*
 CategoryServiceImpl_UT was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.dao.ObservationDAO;
import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockCategoryDAO;
import com.monsanto.eas.bbs.service.mock.MockObservationDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class CategoryServiceImpl_UT {

    private CategoryDAO catDao = null;
    private ObservationDAO observationDao = null;
    private CategoryService service;

    @Before
    public void setUp() {
        catDao = new MockCategoryDAO(null, null, null);
        observationDao = new MockObservationDAO();
        service = new CategoryServiceImpl(catDao, observationDao);
    }

    @Test
    public void testLookupAllSubCategories_ListOfActiveSubCategoriesReturned() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        Category category = new Category();
        category.setId(new Long(1));
        List<LanguageBasedCategory> subCategories = service.lookupSubcategoriesForACategory(lang, category, true);
        assertEquals(1, subCategories.size());
        for (LanguageBasedCategory lbc : subCategories) {
            assertTrue(lbc.getId().getCategory().isActive());
            assertEquals(category.getId(), lbc.getId().getCategory().getParentCategory().getId());
            assertEquals("TEST DESCR FOR ENGLISH", lbc.getDescription());
        }
    }

    @Test
    public void testLookupAllObservationsEnteredForSubSubCategory_ListOfObservationsEnteredReturned() throws Exception {
        Category category = new Category();
        category.setId(new Long(1));
        Category subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        Category subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setActive(true);
        List<Observation> observations = service.lookupAllObservationForSubSubCategory(subSubCategory);
        assertEquals(1, observations.size());
//    assertEquals(3L, observations.get(0).getSubSubCategory().getId().longValue());
    }

    @Test
    public void testLookupLanguageCategoryTypes_ReturnsTypes() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        List<LanguageCategoryType> languageCategoryTypes = service.lookupLanguageCategoryTypes(lang);
        assertEquals(2, languageCategoryTypes.size());
        assertEquals("BEHAVIOR123", languageCategoryTypes.get(0).getDescription());
        assertEquals("BEHAVIOR234", languageCategoryTypes.get(1).getDescription());
    }

    @Test
    public void testLookupLanguageBasedCategoriesByType_ReturnsTypes() throws Exception {
        Language lang = new Language();
        lang.setId(new Long(1));
        CategoryType catType = new CategoryType();
        catType.setBehavior(true);
        List<LanguageBasedCategory> categoryList = service.lookupLanguageBasedCategoriesByType(lang, catType);
        assertEquals(2, categoryList.size());
        assertEquals("Cat 1", categoryList.get(0).getDescription());
        assertEquals("Cat 2", categoryList.get(1).getDescription());
    }

}