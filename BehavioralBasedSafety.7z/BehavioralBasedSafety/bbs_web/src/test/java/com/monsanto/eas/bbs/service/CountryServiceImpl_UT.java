package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.CountryDAOImpl;
import com.monsanto.eas.bbs.dao.mock.MockHibernateTemplate;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Country;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.service.mock.MockSessionFactoryForBBS;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/2/14
 * Time: 3:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class CountryServiceImpl_UT {

    @Test
    public void testLookupActiveCountriesWithValidRegionID() {
        CountryDAOImpl countryDAO = new CountryDAOImpl();
        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(new ArrayList<Country>());

        countryDAO.setHibernateTemplate(mockHibernateTemplate);

        List<Country> countryList = countryDAO.lookupActiveCountriesWithValidRegionID();
        assertNotNull(countryList);
    }

    @Test
    public void testLookupActiveCountriesByRegionID() {
        CountryDAOImpl countryDAO = new CountryDAOImpl();
        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(new ArrayList<Country>());

        countryDAO.setHibernateTemplate(mockHibernateTemplate);

        Long[] countryIDList = new Long[]{1L, 3L, 4L};
        List<Country> countryList = countryDAO.lookupActiveCountriesByRegionID(countryIDList);
        assertNotNull(countryList);
    }

    @Test
    public void testLookupActiveCountriesByRegionIDAndByUserRole() {
        CountryDAOImpl countryDAO = new CountryDAOImpl();

        MockHibernateTemplate mockHibernateTemplate = new MockHibernateTemplate(new ArrayList<Country>());
        MockSessionFactoryForBBS mockSessionFactory = new MockSessionFactoryForBBS(new ArrayList<Country>());
        countryDAO.setHibernateTemplate(mockHibernateTemplate);
        countryDAO.setSessionFactory(mockSessionFactory);

        String regionIDList = "1, 2, 3";
        String userOwnsRegionDesc = "EMEA";

        Country country = new Country();
        country.setRegionId(1L);
        Plant plant = new Plant();
        plant.setCountry(country);

        BBSUser loggedInUser = new BBSUser();
        loggedInUser.setPlant(plant);

        List<Country> countryList = countryDAO.lookupActiveCountriesByRegionIDAndByUserRole(regionIDList, loggedInUser, userOwnsRegionDesc);
        assertNotNull(countryList);
    }

}
