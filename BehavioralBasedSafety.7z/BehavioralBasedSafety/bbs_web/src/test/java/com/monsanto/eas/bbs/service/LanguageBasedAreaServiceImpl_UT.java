package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.Area;
import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.service.mock.MockLanguageBasedAreaDAO;
import com.monsanto.eas.bbs.service.mock.MockLangugageDAO;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 12/16/13
 * Time: 12:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class LanguageBasedAreaServiceImpl_UT {

    @Test
    public void testGetAllActiveSubAreasForAnArea_ListReturned() throws Exception {
        LanguageBasedAreaDAO languageBasedAreaDAO = new MockLanguageBasedAreaDAO();
        LanguageDAO languageDAO = new MockLangugageDAO();

        Area area = new Area(new Long(1), null, true);

        LanguageBasedAreaServiceImpl languageBasedAreaService = new LanguageBasedAreaServiceImpl(languageBasedAreaDAO, languageDAO);

        List<LanguageBasedArea> languageBasedAreas = languageBasedAreaService.lookupSubAreasForAnArea(area, null, null);
        LanguageBasedArea languageBasedArea = languageBasedAreas.get(0);
        assertNotNull(languageBasedArea.getId());
        assertTrue(languageBasedArea.getId().getArea().isActive());
        assertTrue(area.isActive());
        assertEquals(new Long(100), languageBasedArea.getId().getArea().getId());
        assertEquals(new Long(1), languageBasedArea.getId().getArea().getParentArea().getId());
    }

    @Test
    public void testAddLanguageBasedAreas_CallLookUpAllAreas() throws Exception {
        LanguageBasedAreaDAO languageBasedAreaDAO = new MockLanguageBasedAreaDAO();
        LanguageDAO languageDAO = new MockLangugageDAO();

        LanguageBasedAreaServiceImpl languageBasedAreaService = new LanguageBasedAreaServiceImpl(languageBasedAreaDAO, languageDAO);

        languageBasedAreaService.addLanguageBasedAreas("EN");
        boolean wasAddLanguageCalled = ((MockLanguageBasedAreaDAO) languageBasedAreaDAO).isWasAddLanguageAreaCalled();
        assertTrue(wasAddLanguageCalled);
    }

}
