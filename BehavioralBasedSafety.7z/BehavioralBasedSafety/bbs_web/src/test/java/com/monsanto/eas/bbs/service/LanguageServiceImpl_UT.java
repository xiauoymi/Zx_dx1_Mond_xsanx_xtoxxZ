/*
 LanguageServiceImpl_UT was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockLangugageDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class LanguageServiceImpl_UT {

    MockLangugageDAO langugageDAO;

    @Before
    public void setUp() {
        langugageDAO = new MockLangugageDAO();
    }

    @Test
    public void testLookupAllLanguages_ListOfAllActiveLanguagesReturned() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        List<Language> languageList = service.lookupAllLanguages();
        assertTrue(langugageDAO.wasFindAllCalled());
        assertNotNull(languageList);
        assertEquals(3, languageList.size());
        for (Language lang : languageList) {
            assertTrue(lang.isActive());
        }
    }

    @Test
    public void testLookupResponseForALanguage_ListOfResponsesReturned() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        Language lang = new Language();
        lang.setLocale("en");
        lang.setDescription("ENGLISH");
        List<LanguageBasedResponse> responseList = service.lookupResponsesForALanguage(lang);
        assertEquals(2, responseList.size());
        assertEquals("en", responseList.get(0).getId().getLanguage().getLocale());
        assertEquals(1, responseList.get(0).getId().getResponse().getDisplayOrder());
        assertEquals("Negative 2", responseList.get(0).getDescription());
        assertEquals("en", responseList.get(1).getId().getLanguage().getLocale());
        assertEquals(2, responseList.get(1).getId().getResponse().getDisplayOrder());
        assertEquals("Negative 1", responseList.get(1).getDescription());
    }

    @Test
    public void testLookupPersonnelTypeForALanguage_ListOfPersonnelTypeReturned() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        Language lang = new Language();
        lang.setLocale("en");
        lang.setDescription("ENGLISH");
        List<LanguageBasedPersonnelType> list = service.lookupPersonnelTypesForALanguage(lang);
        assertEquals(1, list.size());
        for (LanguageBasedPersonnelType type : list) {
            assertEquals("en", type.getId().getLanguage().getLocale());
            assertNotNull(type.getId().getPersonnelType());
            assertEquals("Contractor", type.getDescription());
        }
    }

    @Test
    public void testLookupBarriersForALanguageAndCategory_ListOfResponsesReturned() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        Language lang = new Language();
        lang.setLocale("en");
        lang.setDescription("ENGLISH");
        Category category = new Category();
        category.setId(new Long(1));
        List<LanguageBarrierCategory> barriers = service.lookupActiveBarriersForALanguageAndSubCategory(lang, category);
        assertEquals(1, barriers.size());
        for (LanguageBarrierCategory barrierCategory : barriers) {
            assertEquals("en", barrierCategory.getId().getLanguage().getLocale());
            assertEquals("Barrier 1", barrierCategory.getDescription());
        }
    }

    @Test
    public void testInsertLanguage_CallLookupLanguageByLocale_IfNullReturnedCallInsert() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        service.insertLanguage("ENGLISH", true, "EN");
        boolean wasLookupLanguageByLocaleCalled = ((MockLangugageDAO) langugageDAO).wasLookupLanguageByLocaleCalled();
        assertTrue(wasLookupLanguageByLocaleCalled);
        boolean called = ((MockLangugageDAO) langugageDAO).isWasAddLanguageCalled();
        assertTrue(called);
    }

    //Add test to test if Language is not returned..
    @Test
    public void testInsertLanguage_CallLookupLanguageByLocale_CallInsertNotCalled() throws Exception {
        LanguageService service = new LanguageServiceImpl(langugageDAO);
        service.lookupLanguageByLocale("SW");
        boolean wasLookupLanguageByLocaleCalled = ((MockLangugageDAO) langugageDAO).wasLookupLanguageByLocaleCalled();
        assertTrue(wasLookupLanguageByLocaleCalled);
        boolean called = ((MockLangugageDAO) langugageDAO).isWasAddLanguageCalled();
        assertFalse(called);
    }

    //Delete insertLanguage from AddLanguageMain and make sure it is getting called from LanguageService

}