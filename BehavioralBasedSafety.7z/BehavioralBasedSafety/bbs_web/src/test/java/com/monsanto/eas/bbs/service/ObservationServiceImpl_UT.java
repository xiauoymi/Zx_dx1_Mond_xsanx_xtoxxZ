/*
 ObservationServiceImpl_UAT was created on Jan 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockObservationDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ObservationServiceImpl_UT {

    ObservationService service;
    Observation observation = new Observation();


    @Before
    public void setUp() {
        Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
                "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());

        BBSUser user = new BBSUser(new Long(1), "ABC123", "FIRST", "LAST", "M", true, new Date(), "TEST", new Date());

        Area area = new Area(new Long(100), null, true);
        Area subArea = new Area(new Long(101), area, true);


        SafetyGroup group = new SafetyGroup(new Long(1), "ABC001", plant, true, false);

        Response response = new Response();
        response.setId(new Long(1));
        response.setActive(true);
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));

        Category subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        subCategory.setId(new Long(2));

        Category subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setId(new Long(3));
        subSubCategory.setActive(true);

        PersonnelType personnelType = new PersonnelType();
        personnelType.setActive(true);

        Language lang = new Language();
        lang.setId(new Long(1));


//    observation.setCategory(category);
//    observation.setSubCategory(subCategory);
//    observation.setSubSubCategory(subSubCategory);
        observation.setLanguage(lang);
        observation.setArea(area);
        observation.setSubArea(subArea);
//    observation.setComments(comment);
//    observation.setBehaviorCategory(behavior);
//    observation.setFeedbackGiven(feedback);
        observation.setDateEntered(new Date());
//    observation.setObservationDescr("Test Observation");
        observation.setPlant(plant);
        observation.setSafetyGroup(group);
//    observation.setObservationType(obsType);
        observation.setPersonnelType(personnelType);
        observation.setId(new Long(1));
        observation.setEnteredBy(user);
        observation.setActive(true);

        CategoryObservation co = new CategoryObservation();
        co.setCategory(subSubCategory);
        List<CategoryObservation> cos = new ArrayList<CategoryObservation>();
        cos.add(co);
        observation.setCategoryObservations(cos);
    }

    @Test
    public void testSaveAnObservation_EntrySaved() throws Exception {
        MockObservationDAO dao = new MockObservationDAO();
        service = new ObservationServiceImpl(dao);
        service.addObservation(observation);
        assertTrue(dao.getWasAddObservationCalled());
        assertTrue(observation.isActive());
    }

    @Test
    public void testLookupObservation_ObservationFound() throws Exception {
        MockObservationDAO dao = new MockObservationDAO();
        service = new ObservationServiceImpl(dao);
        dao.addObservation(observation);
        Observation observation1 = service.lookupObservation(observation.getId());
        assertTrue(observation1.equals(observation));
        assertTrue(dao.isWasLookupObservationCalled());
    }

    @Test
    public void testInactivateObservation_ObservationInactivated() throws Exception {
        MockObservationDAO dao = new MockObservationDAO();
        service = new ObservationServiceImpl(dao);
        dao.inactivateObservation(observation);
        assertTrue(dao.isObservationInactivate());
    }

    @Test
    public void testUpdateObservation_ObservationUpdated() throws Exception {
        MockObservationDAO dao = new MockObservationDAO();
        service = new ObservationServiceImpl(dao);
        dao.updateObservation(observation);
        assertTrue(dao.isObservationUpdated());
    }
}