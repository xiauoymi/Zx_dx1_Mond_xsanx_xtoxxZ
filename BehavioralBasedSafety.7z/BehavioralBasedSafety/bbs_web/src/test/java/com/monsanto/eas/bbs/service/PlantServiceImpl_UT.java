/*
 PlantServiceImpl_UT was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.LanguageBasedArea;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.service.mock.MockLanguageBasedAreaDAO;
import com.monsanto.eas.bbs.service.mock.MockPlantDAO;
import com.monsanto.eas.bbs.service.mock.MockSafetyGroupDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class PlantServiceImpl_UT {

    PlantService plantService;

    @Before
    public void setUp() {
        plantService = new PlantServiceImpl(null, null, null);

    }

    @Test
    public void testConstructor_ObjectNotNull() throws Exception {
        assertNotNull(plantService);
    }

    @Test
    public void testLookupAllActivePlants_ListOfPlantsAreReturned() throws Exception {
        plantService = new PlantServiceImpl(new MockPlantDAO(), null, null);
        List<Plant> activePlants = plantService.lookupAllPlants();
        assertNotNull(activePlants);
        assertEquals(2, activePlants.size());
        for (Plant plant : activePlants) {
            assertTrue(plant.isActive());
        }
    }

    @Test
    public void testLookupAllSafetyGroupsForAPlant_ListOfSafetyGroupReturned() throws Exception {
        plantService = new PlantServiceImpl(null, new MockSafetyGroupDAO(), null);
        Plant plant = new Plant();
        plant.setId(new Long(1));
        List<SafetyGroup> safetyGroups = plantService.lookupSafetyGroupsForPlant(plant);
        assertEquals(2, safetyGroups.size());
        assertEquals("ABC001", safetyGroups.get(0).getGroupText());
        assertEquals(new Long(1), safetyGroups.get(0).getPlant().getId());
        assertEquals("XYZ001", safetyGroups.get(1).getGroupText());
        assertEquals(new Long(1), safetyGroups.get(1).getPlant().getId());
    }

    @Test
    public void testLookupAllActiveAreasForAPlant_ListOfAreasReturned() throws Exception {
        plantService = new PlantServiceImpl(null, null, new MockLanguageBasedAreaDAO(null, null));
        Plant plant = new Plant();
        plant.setId(new Long(1));
        List<LanguageBasedArea> languageBasedAreas = plantService.lookupAreasForPlant(plant, null);
        for (LanguageBasedArea languageBasedArea : languageBasedAreas) {
            assertNotNull(languageBasedArea.getId().getArea().getId());
            assertTrue(languageBasedArea.getId().getArea().isActive());
        }
    }

}