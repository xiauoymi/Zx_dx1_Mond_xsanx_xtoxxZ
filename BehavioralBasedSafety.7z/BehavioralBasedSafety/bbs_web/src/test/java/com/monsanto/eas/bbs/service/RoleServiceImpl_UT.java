package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.dao.RoleDAO;
import com.monsanto.eas.bbs.hibernate.BBSRole;
import com.monsanto.eas.bbs.service.mock.MockRoleDAO;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA. User: VRBETHI Date: Feb 19, 2010 Time: 4:13:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class RoleServiceImpl_UT {

    @Test
    public void testLookUpAllRoles() throws Exception {
        RoleDAO roleDAO = new MockRoleDAO();
        RoleService service = new RoleServiceImpl(roleDAO);
        List<BBSRole> roles = service.lookUpAllRoles();
        boolean wasLookUpRolesCalled = ((MockRoleDAO) roleDAO).wasLookUpRolesCalled();
        assertTrue(wasLookUpRolesCalled);
    }

}
