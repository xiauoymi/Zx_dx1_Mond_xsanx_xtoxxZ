/*
 * Copyright:  Copyright  2009 Monsanto.  All rights reserved.
 * UserServicesImpl_AT was created on (TODO:Add Month) 18, 2009 using Monsanto resources and is the sole property of Monsanto.
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.eas.bbs.service;


import com.monsanto.eas.bbs.hibernate.BBSUser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

/**
 *
 * Filename:    $HeadURL$
 * Label:       $Id$
 * @author      AASEN
 * @version     $Revision$
 *              Last Change: $Author$     On: $Date$
 */
public class UserServiceImpl_AT {

  private UserServiceImpl userServicesImpl = null;
  private BBSUser testUser = null;

  @Before
  public void setUpBeforeMethod() {
    userServicesImpl = new UserServiceImpl();

    // Create a Test User to be added in the database.
    Date currentDate = new Date();
    testUser = new BBSUser(9999l, "TSTUSR", "Test", "User", "S", true,  currentDate, "Mod_User", currentDate);
  }

  @After
  public void tearDownAfterMethod() {
    userServicesImpl = null;
    testUser = null;
  }

  /**
   * Method: addUser(BBSUser user)
   */
  @Test
  public void testAddUser() throws Exception {
    
  }


}


