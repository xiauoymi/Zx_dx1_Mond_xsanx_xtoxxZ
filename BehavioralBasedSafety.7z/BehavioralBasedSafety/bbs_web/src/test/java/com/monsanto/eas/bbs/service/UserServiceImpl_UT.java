/*
 UserServiceImpl_UT was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service;

import com.monsanto.eas.bbs.hibernate.*;
import com.monsanto.eas.bbs.service.mock.MockRoleDAO;
import com.monsanto.eas.bbs.service.mock.MockUserDAO;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class UserServiceImpl_UT {

    private MockUserDAO userDao;

    @Before
    public void setUp() {
        userDao = new MockUserDAO();

        Plant plant = new Plant();
        plant.setId(new Long(3000));
        plant.setActive(true);
        plant.setCustomerNumberForPlant("C0001");
        plant.setVendorNbrForPlant("V0001");
        plant.setPlantName1("Plant Name");
        plant.setPlantCode("9999");
        plant.setCountry(new Country());

        Department department = new Department();
        department.setActive(true);
        department.setCode((long) 1000);
        department.setCompany(true);
        department.setName("TestName");

        Date currentDate = new Date();

        BBSUser user = new BBSUser();
        user.setId(new Long(1));
        user.setUserId("TEST_USR");
        user.setFirstName("FIRSTNAME");
        user.setLastName("LASTNAME");
        user.setMiddleName("MIDDLENAME");
        user.setEmployee(true);
        user.setLastLogin(currentDate);
        user.setModUser("MOD_USER");
        user.setModDate(currentDate);
        user.setPlant(plant);
        user.setDepartment(department);

        userDao.addUser(user);
    }


    @Test
    public void testLookupUserById_UserIdPresentInDatabase_ReturnTrue() throws Exception {
        //userDao = new MockUserDAO();
        UserService service = new UserServiceImpl(userDao, null);
        BBSUser userFound = service.findByUserID("TEST_USR");
        assertTrue(userDao.isWasfindByUserIdCalled());
        assertNotNull(userFound);
        assertEquals("TEST_USR", userFound.getUserId());
    }

    @Test
    public void testLookupUserById_UserIdNotPresentInDatabase_ReturnFalse() throws Exception {
        //userDao = new MockUserDAO();
        UserService service = new UserServiceImpl(userDao, null);
        BBSUser userFound = service.findByUserID("MOCKUSER");
        assertTrue(userDao.isWasfindByUserIdCalled());
        assertNull(userFound);
    }

    @Test
    public void testSaveOrUpdate_ExistingUser() throws Exception {
        //userDao = new MockUserDAO();
        MockRoleDAO roleDao = new MockRoleDAO();
        UserService service = new UserServiceImpl(userDao, roleDao);
        BBSUser userToSave = new BBSUser(new Long(1), "MOCKUSER1", "TEST", "USER", null, false, null, null, null);
        HashSet<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setId(new Long(11));
        roles.add(role);
        role = new BBSRole();
        role.setId(new Long(12));
        roles.add(role);
        userToSave.setRoles(roles);
        service.saveOrUpdate(userToSave);
        assertTrue(userDao.isWasAddUserCalled());
        final BBSUser user = userDao.getSavedUser();
        assertEquals(new Long(1), user.getId());
        assertEquals("MOCKUSER1", user.getUserId());
        assertEquals("TEST", user.getFirstName());
        assertEquals("USER", user.getLastName());
        assertNull(user.getPlant());
        assertNull(user.getDepartment());
        assertEquals(2, roleDao.getRolesSaved().size());
    }

    @Test
    public void testSaveOrUpdate_NewUser() throws Exception {
        //userDao = new MockUserDAO();
        MockRoleDAO roleDao = new MockRoleDAO();
        UserService service = new UserServiceImpl(userDao, roleDao);
        BBSUser userToSave = new BBSUser(new Long(1), "MOCKUSER", "TEST", "USER", null, false, null, null, null);
        Plant plant = new Plant();
        plant.setId(new Long(13));
        userToSave.setPlant(plant);
        Department department = new Department();
        department.setId(new Long(14));
        userToSave.setDepartment(department);
        HashSet<BBSRole> roles = new HashSet<BBSRole>();
        BBSRole role = new BBSRole();
        role.setId(new Long(11));
        roles.add(role);
        role = new BBSRole();
        role.setId(new Long(12));
        roles.add(role);
        userToSave.setRoles(roles);
        service.saveOrUpdate(userToSave);
        assertTrue(userDao.isWasAddUserCalled());
        assertTrue(userDao.isWasAddUserCalled());
        final BBSUser user = userDao.getSavedUser();
        assertEquals(new Long(1), user.getId());
        assertEquals("MOCKUSER", user.getUserId());
        assertEquals("TEST", user.getFirstName());
        assertEquals("USER", user.getLastName());
        assertEquals(2, roleDao.getRolesSaved().size());
        assertEquals(new Long(13), user.getPlant().getId());
        assertEquals(new Long(14), user.getDepartment().getId());
    }

    @Test
    public void testLookupUserByCriteria_FirstNameProvided_ListOfAllNamesMatchingFirstNameReturned() throws Exception {
        //userDao = new MockUserDAO();
        UserService service = new UserServiceImpl(userDao, null);
        List<BBSUser> users = service.lookupUserByCriteria("TEST");
        assertTrue(userDao.isWasLookupUserByCriteriaCalled());
        assertEquals(2, users.size());
        assertEquals("TEST", users.get(0).getFirstName());
        assertEquals("TEST", users.get(1).getLastName());
    }

    @Test
    public void testLookupAllActiveUsers_ListOfAllActiveUsersReturned() throws Exception {
        //userDao = new MockUserDAO();
        UserService service = new UserServiceImpl(userDao, null);
        List<BBSUser> users = service.lookupAllUsers(true);
        assertEquals(2, users.size());
        assertEquals("John", users.get(0).getFirstName());
        assertTrue(users.get(0).isActive());
        assertEquals("f", users.get(1).getLastName());
        assertTrue(users.get(1).isActive());
    }

    @Test
    public void testLookupUsersWithRoles() throws Exception {
        //userDao = new MockUserDAO();
        UserService service = new UserServiceImpl(userDao, null);
        List<BBSUser> users = service.lookUpUsersWithRoles();
        assertTrue(users.size() > 0);
    }
}