/*
 MockAreaDAO was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.AreaDAO;
import com.monsanto.eas.bbs.dataimport.PlantAreaTO;
import com.monsanto.eas.bbs.hibernate.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class MockAreaDAO implements AreaDAO {
    private boolean wasLookUpAreaCalled = false;
    private boolean wasLookUpSubAreaCalled = false;
    private boolean wasInsertPlantAreaCalled = false;
    private boolean wasLookAllAreasCalled = false;
    private boolean wasAddLanguageAreaCalled = false;
    //private Collection<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
    private Collection<PlantAreaTO> plantAreas = new ArrayList<PlantAreaTO>();
    private Collection<Area> savedAreas = new ArrayList<Area>();
    private Collection<LanguageBasedArea> savedLanguageBasedAreas = new ArrayList<LanguageBasedArea>();
    private LanguageBasedArea existingLanguageBasedArea;
    private LanguageBasedArea existingLangaugeBasedSubArea;
    private LanguageBasedArea languageBasedArea;

    public MockAreaDAO(LanguageBasedArea existingLanguageBasedArea, LanguageBasedArea existingLangaugeBasedSubArea) {
        this.existingLanguageBasedArea = existingLanguageBasedArea;
        this.existingLangaugeBasedSubArea = existingLangaugeBasedSubArea;
    }

    public List<Area> lookupAllParentAreas() {
        Area area = new Area();
        area.setId(new Long(1));
        area.setActive(true);
        area.setLevel(1);
        area.setParentArea(null);
        List<Area> areas = new ArrayList<Area>();
        areas.add(area);
        return areas;
    }


    public void saveOrUpdateArea(Area area) {
        savedAreas.add(area);
    }

    public Area lookupAreaById(Long id) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Area lookupArea(String areaDescription, Language language) {
        wasLookUpAreaCalled = true;
        return new Area();
    }

    public Area lookupSubArea(Area area, String subAreaDescription, Language language) {
        wasLookUpSubAreaCalled = true;
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }


    public void deletePlantArea(Plant plant, Area area) {
    }

    public void addPlantArea(Plant plant, Area area) {
        PlantAreaTO plantArea = new PlantAreaTO();
        plantArea.setArea(area);
        plantArea.setPlant(plant);
        plantAreas.add(plantArea);
        wasInsertPlantAreaCalled = true;
    }

    public List<Area> lookupSubAreas(Area area) {
        List<Area> areas = new ArrayList<Area>();
        Area area1 = new Area();
        area1.setActive(true);
        areas.add(area1);
        area1 = new Area();
        area1.setActive(true);
        areas.add(area1);
        return areas;
    }

    public Collection<Area> getSavedAreas() {
        return savedAreas;
    }

    public Collection<LanguageBasedArea> getSavedLanguageBasedAreas() {
        return savedLanguageBasedAreas;
    }

    public boolean wasLookUpAreaCalled() {
        return wasLookUpAreaCalled;  //To change body of created methods use File | Settings | File Templates.
    }

    public boolean wasLookUpSubAreaCalled() {
        return wasLookUpSubAreaCalled;  //To change body of created methods use File | Settings | File Templates.
    }

    public boolean wasInsertPlantAreaCalled() {
        return wasInsertPlantAreaCalled;  //To change body of created methods use File | Settings | File Templates.
    }

    public Collection<PlantAreaTO> getPlantAreas() {
        return plantAreas;
    }

    public boolean isWasLookAllAreasCalled() {
        return wasLookAllAreasCalled;
    }

    public boolean isWasAddLanguageAreaCalled() {
        return wasAddLanguageAreaCalled;
    }
}