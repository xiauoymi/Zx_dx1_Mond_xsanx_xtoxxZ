/*
 MockCategoryDAO was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.CategoryDAO;
import com.monsanto.eas.bbs.hibernate.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class MockCategoryDAO implements CategoryDAO {
  private Collection<LanguageBasedCategory> savedLanguageBasedCatories = new ArrayList<LanguageBasedCategory>();
  private Collection<LanguageBarrierCategory> savedLanguageBarrierCategories = new ArrayList<LanguageBarrierCategory>();
  private Collection<Category> savedCategories = new ArrayList<Category>();
  private LanguageBasedCategory existingLanguageBasedCategory;
  private LanguageBarrierCategory existingLanguageBarrierCategory;
  private LanguageBasedCategory existingLanguageBasedSubCategory;

  public MockCategoryDAO(LanguageBasedCategory existingLanguageBasedCategory,
                         LanguageBasedCategory existingLanguageBasedSubCategory,
                         LanguageBarrierCategory existingLanguageBarrierCategory) {
    this.existingLanguageBasedCategory = existingLanguageBasedCategory;
    this.existingLanguageBasedSubCategory = existingLanguageBasedSubCategory;
    this.existingLanguageBarrierCategory = existingLanguageBarrierCategory;
  }

  public LanguageBasedCategory lookupLanguageBasedCategoryByDescriptionAndType(String catDescription, Language language,
                                                                               CategoryType categoryType) {
    return existingLanguageBasedCategory;
  }

  public LanguageBasedCategory lookupLanguageBasedSubCategoryByDescriptionAndType(String catDescription,
                                                                                  Category parentCategory,
                                                                                  Language language,
                                                                                  CategoryType categoryType) {
    return existingLanguageBasedSubCategory;
  }

  public LanguageBarrierCategory lookupLanguageBarrierByDescriptionAndCategory(String barrierDescription,
                                                                               Language language, Category category) {
    return existingLanguageBarrierCategory;
  }

  public List<LanguageBasedCategory> lookupLanguageBasedCategoriesByType(Language language, CategoryType categoryType, boolean onlyActiveCategories) {
    List<LanguageBasedCategory> categoryList = new ArrayList<LanguageBasedCategory>();
    LanguageBasedCategory category = new LanguageBasedCategory();
    category.setDescription("Cat 1");
    categoryList.add(category);
    category = new LanguageBasedCategory();
    category.setDescription("Cat 2");
    categoryList.add(category);
    return categoryList;
  }

  public List<Category> lookupSubCategoriesForCategory(Category category) {
    List<Category> cats = new ArrayList<Category>();
    Category cat = new Category();
    cat.setId(new Long(1));
    cat.setActive(true);
    cats.add(cat);
    cat = new Category();
    cat.setId(new Long(2));
    cat.setActive(true);
    cats.add(cat);
    return cats;
  }

  public List<LanguageBasedCategory> lookupAllSubCategoriesForACategory(Language language, Category parentCategory, boolean includeInactiveCategories) {
    Category category = new Category();
    category.setId(new Long(1));
    category.setActive(true);

    Category subCategory = new Category();
    subCategory.setId(new Long(2));
    subCategory.setActive(true);
    subCategory.setParentCategory(category);

    Language lang = new Language();
    lang.setId(new Long(1));
    lang.setActive(true);
    lang.setLocale("en");
    lang.setDescription("ENGLISH");


    LanguageBasedCategory lbc = new LanguageBasedCategory();
    LanguageBasedCategoryPK id = new LanguageBasedCategoryPK();
    id.setCategory(subCategory);
    id.setLanguage(lang);
    lbc.setId(id);
    lbc.setDescription("TEST DESCR FOR ENGLISH");

    List<LanguageBasedCategory> lbcList = new ArrayList<LanguageBasedCategory>();
    lbcList.add(lbc);
    return lbcList;
  }

  public void saveOrUpdateCategory(Category category) {
    savedCategories.add(category);
  }

  public void deleteCategory(Category category) {
  }

  public Collection<Category> getSavedCategories() {
    return savedCategories;
  }

  public void saveLanguageBasedCategory(LanguageBasedCategory languageBasedCategory) {
    languageBasedCategory.getId().getCategory().setId(new Long(1234));
    savedLanguageBasedCatories.add(languageBasedCategory);
  }

  public void saveLanguageBarrierCategory(LanguageBarrierCategory languageBarrierCategory) {
    languageBarrierCategory.getId().getBarrierCategory().setId(new Long(1234));
    savedLanguageBarrierCategories.add(languageBarrierCategory);
  }

  public List<LanguageCategoryType> lookupLanguageCategoryTypes(Language language) {
    List<LanguageCategoryType> types = new ArrayList<LanguageCategoryType>();

    CategoryType categoryType = new CategoryType();
    categoryType.setId(new Long(123));
    LanguageCategoryType languageCategoryType = new LanguageCategoryType();
    languageCategoryType.setDescription("BEHAVIOR123");
    LanguageCategoryTypePK catPK = new LanguageCategoryTypePK();
    catPK.setCategoryType(categoryType);
    catPK.setLanguage(language);
    languageCategoryType.setId(catPK);
    types.add(languageCategoryType);

    categoryType = new CategoryType();
    categoryType.setId(new Long(234));
    languageCategoryType = new LanguageCategoryType();
    languageCategoryType.setDescription("BEHAVIOR234");
    catPK = new LanguageCategoryTypePK();
    catPK.setCategoryType(categoryType);
    catPK.setLanguage(language);
    languageCategoryType.setId(catPK);
    types.add(languageCategoryType);

    return types;
  }

  public List<LanguageBarrierCategory> lookupLanguageBarriers() {
    return null;
  }

  public List<LanguageBarrierCategory> lookupLanguageBarriers(Language language) {
    return null;
  }

  public List<LanguageBasedCategory> lookupAllLanguageCategories() {
    List<LanguageBasedCategory> categoryList = new ArrayList<LanguageBasedCategory>();
    LanguageBasedCategory category = new LanguageBasedCategory();
    category.setDescription("Cat 1");
    categoryList.add(category);
    category = new LanguageBasedCategory();
    category.setDescription("Cat 2");
    categoryList.add(category);
    return categoryList;
  }

  public List<LanguageBasedCategory> lookupAllLanguageCategories(Language language) {
    List<LanguageBasedCategory> categoryList = new ArrayList<LanguageBasedCategory>();
    LanguageBasedCategory category = new LanguageBasedCategory();
    category.setDescription("Cat 1");
    categoryList.add(category);
    category = new LanguageBasedCategory();
    category.setDescription("Cat 2");
    categoryList.add(category);
    return categoryList;
  }

  public void saveOrUpdateLanguageCategoryType(LanguageCategoryType languageCategoryType) {
  }

  public Collection<LanguageBasedCategory> getSavedLanguageBasedCatories() {
    return savedLanguageBasedCatories;
  }

  public Collection<LanguageBarrierCategory> getSavedLanguageBarrierCategories() {
    return savedLanguageBarrierCategories;
  }
}