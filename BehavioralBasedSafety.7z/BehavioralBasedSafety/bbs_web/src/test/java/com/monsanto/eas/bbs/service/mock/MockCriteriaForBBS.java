/*
 MockCriteria was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Criterion;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class MockCriteriaForBBS extends MockCriteria {
   private int firstResult;
  private int maxResult;
  private List<String> fetchModes = new ArrayList<String>();
  private Object uniqueResult;
  private List list;

  public MockCriteriaForBBS() {
  }

  public MockCriteriaForBBS(Object uniqueResult, List list) {
    this.uniqueResult = uniqueResult;
    this.list = list;
  }

  @Override
  public List<Criterion> getCriteria() {
    return super.getCriteria();
  }

  @Override
  public Criteria add(Criterion criterion) {
    return super.add(criterion);
  }

  public Object uniqueResult() throws HibernateException {
    return this.uniqueResult;
  }

  public Criteria setFirstResult(int i) {
    this.firstResult = i;
    return super.setFirstResult(i);
  }

  public Criteria setMaxResults(int i) {
    this.maxResult = i;
    return super.setMaxResults(i);
  }

  public int getFirstResult() {
    return firstResult;
  }

  public int getMaxResult() {
    return maxResult;
  }

  public Criteria setFetchMode(String s, FetchMode fetchMode) throws HibernateException {
    this.fetchModes.add(s + "-" + fetchMode);
    return super.setFetchMode(s, fetchMode);
  }

  public List<String> getFetchModes() {
    return fetchModes;
  }

  public List list() throws HibernateException {
    if(list == null){
      return super.list();
    }else{
      return list;
    }
  }
}