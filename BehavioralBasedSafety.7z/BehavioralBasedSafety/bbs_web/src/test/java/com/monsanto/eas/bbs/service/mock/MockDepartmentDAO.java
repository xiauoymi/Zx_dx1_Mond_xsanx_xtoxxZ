/*
 MockDepartmentDAO was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.DepartmentDAO;
import com.monsanto.eas.bbs.hibernate.Department;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockDepartmentDAO implements DepartmentDAO {
    private List<Department> departments;
    private Department department;

    public MockDepartmentDAO(List<Department> departments, Department department) {
        this.departments = departments;
        this.department = department;
    }

    public List<Department> lookupDepartmentsByCompanyFlag(boolean isCompany, boolean active) {
        return departments;
    }

    public Department lookupDepartmentByCode(Long code) {
        return department;
    }

   public List<Department> lookupAllDepartments() {
       Department department1 = new Department();
       department1.setCode(3000l);

       Department department2 = new Department();
       department2.setId(2233l);
       department2.setCode(123l);
       department2.setName("123 Name");

       List<Department> departmentList = new ArrayList<Department>();
       departmentList.add(department1);
       departmentList.add(department2);

       return departmentList;
   }

    public Map<Long, Department> getMapOfAllDepartments() {
        Map<Long, Department> map = new HashMap<Long, Department>();
        List<Department> departments = lookupAllDepartments();
        for (Department department : departments) {
            map.put(department.getCode(), department);
        }
        return map;
    }

    public void save(Department entity) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void delete(Department entity) {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}