/*
 MockHibernateSessionForBBS was created on Jan 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class MockHibernateSessionForBBS extends MockHibernateSession {
  @Override
  public Criteria createCriteria(Class aClass) {
    return new MockCriteria();
  }
}