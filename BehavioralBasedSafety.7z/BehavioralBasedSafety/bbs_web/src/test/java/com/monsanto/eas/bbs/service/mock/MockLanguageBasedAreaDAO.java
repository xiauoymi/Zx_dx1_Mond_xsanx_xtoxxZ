package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.LanguageBasedAreaDAO;
import com.monsanto.eas.bbs.hibernate.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 12/12/13
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockLanguageBasedAreaDAO implements LanguageBasedAreaDAO {

    private boolean wasLookAllAreasCalled = false;

    private Collection<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
    private LanguageBasedArea existingLanguageBasedArea;
    private LanguageBasedArea existingLangaugeBasedSubArea;
    private LanguageBasedArea languageBasedArea;
    private boolean wasAddLanguageAreaCalled = false;

    public MockLanguageBasedAreaDAO(){}

    public MockLanguageBasedAreaDAO(LanguageBasedArea existingLanguageBasedArea, LanguageBasedArea existingLangaugeBasedSubArea) {
        this.existingLanguageBasedArea = existingLanguageBasedArea;
        this.existingLangaugeBasedSubArea = existingLangaugeBasedSubArea;
    }

    public void addLanguageBasedArea(LanguageBasedArea languageBasedArea) {
        wasAddLanguageAreaCalled = true;
    }

    public void saveLanguageBasedArea(LanguageBasedArea lba) {
        lba.getId().getArea().setId(new Long(1234));
        languageBasedAreas.add(lba);
    }

    public LanguageBasedArea lookupLanguageBasedArea(String areaDescription, Language language) {
        return existingLanguageBasedArea;
    }

    public LanguageBasedArea lookupLanguageBasedArea(Area area, Language language) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public LanguageBasedArea lookupLanguageBasedSubArea(String subAreaDescription, Area area, Language language) {
        return existingLangaugeBasedSubArea;
    }

    public List<LanguageBasedArea> lookupLanguageBasedAreas(Plant plant, Language language, boolean activeFlagForArea) {
        List<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
        LanguageBasedArea languageBasedArea = new LanguageBasedArea();
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area1 = new Area(new Long(100), null, true);
        pk.setArea(area1);
        languageBasedArea.setId(pk);
        languageBasedAreas.add(languageBasedArea);

        LanguageBasedArea languageBasedArea2 = new LanguageBasedArea();
        LanguageBasedAreaPK pk2 = new LanguageBasedAreaPK();
        Area area2 = new Area(new Long(101), null, true);
        pk2.setArea(area2);
        languageBasedArea2.setId(pk2);
        languageBasedAreas.add(languageBasedArea2);
        return languageBasedAreas;
    }

    public List<LanguageBasedArea> lookupSubAreasForAnArea(Area area, Plant plant, Language language, boolean activeFlagForSubArea) {
        List<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
        LanguageBasedArea languageBasedArea = new LanguageBasedArea();
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area1 = new Area(new Long(100), area, true);
        pk.setArea(area1);
        languageBasedArea.setId(pk);
        languageBasedAreas.add(languageBasedArea);

        LanguageBasedArea languageBasedArea2 = new LanguageBasedArea();
        LanguageBasedAreaPK pk2 = new LanguageBasedAreaPK();
        Area area2 = new Area(new Long(101), area, true);
        pk2.setArea(area2);
        languageBasedArea2.setId(pk2);
        languageBasedAreas.add(languageBasedArea2);
        return languageBasedAreas;
    }

    public List<LanguageBasedArea> lookupAvailableAreasForPlant(Plant plant, Language language) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<LanguageBasedArea> lookupAvailableSubAreasForPlant(Area parentArea, Plant plant, Language language) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<LanguageBasedArea> lookupAllSubAreasByAreaAndLanguage(Area area, Language language) {
        List<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
        LanguageBasedArea languageBasedArea = new LanguageBasedArea();
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area1 = new Area(new Long(100), null, true);
        pk.setArea(area1);
        languageBasedArea.setId(pk);
        languageBasedArea.setDescription("Pizza Bar");
        languageBasedAreas.add(languageBasedArea);

        LanguageBasedArea languageBasedArea2 = new LanguageBasedArea();
        LanguageBasedAreaPK pk2 = new LanguageBasedAreaPK();
        Area area2 = new Area(new Long(101), null, true);
        pk2.setArea(area2);
        languageBasedArea2.setId(pk2);
        languageBasedArea2.setDescription("Exit Door");
        languageBasedAreas.add(languageBasedArea2);
        return languageBasedAreas;
    }

    public List<LanguageBasedArea> lookupLanguageBasedAreasWithInactiveSubAreas(Language language) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<LanguageBasedArea> lookupAllAreas() {
        wasLookAllAreasCalled = true;
        List<LanguageBasedArea> list = new ArrayList<LanguageBasedArea>();
        languageBasedArea = new LanguageBasedArea();
        languageBasedArea.setId(new LanguageBasedAreaPK());
        list.add(languageBasedArea);

        return list;
    }

    public List<LanguageBasedArea> lookupAllAreas(Language language) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<LanguageBasedArea> lookupAllParentAreasByLanguage(Language language) {
        List<LanguageBasedArea> languageBasedAreas = new ArrayList<LanguageBasedArea>();
        LanguageBasedArea languageBasedArea = new LanguageBasedArea();
        LanguageBasedAreaPK pk = new LanguageBasedAreaPK();
        Area area1 = new Area(new Long(100), null, true);
        pk.setArea(area1);
        languageBasedArea.setId(pk);
        languageBasedArea.setDescription("K Cafe");
        languageBasedAreas.add(languageBasedArea);

        LanguageBasedArea languageBasedArea2 = new LanguageBasedArea();
        LanguageBasedAreaPK pk2 = new LanguageBasedAreaPK();
        Area area2 = new Area(new Long(101), null, true);
        pk2.setArea(area2);
        languageBasedArea2.setId(pk2);
        languageBasedArea2.setDescription("G Canopy");
        languageBasedAreas.add(languageBasedArea2);
        return languageBasedAreas;
    }

    public Collection<LanguageBasedArea> getLanguageBasedAreas() {
        return languageBasedAreas;
    }

    public boolean isWasAddLanguageAreaCalled() {
        return wasAddLanguageAreaCalled;
    }
}
