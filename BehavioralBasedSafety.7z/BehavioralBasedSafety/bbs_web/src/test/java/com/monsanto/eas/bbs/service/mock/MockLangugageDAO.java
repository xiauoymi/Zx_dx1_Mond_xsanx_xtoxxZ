/*
 MockLangugageDAO was created on Dec 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.LanguageDAO;
import com.monsanto.eas.bbs.hibernate.*;

import java.util.ArrayList;
import java.util.List;

/**
 * lookupLanguageByLocale
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class MockLangugageDAO implements LanguageDAO {
    private boolean wasFindAllCalled = false;
    private boolean wasFindAllLanguageBasedCategoriesCalled = false;
    private boolean wasLookUpLanguageByLocaleCalled = false;
    private boolean wasAddLanguageCalled = false;

    public List<Language> findAll() {
        wasFindAllCalled = true;
        ArrayList<Language> languages = new ArrayList<Language>();

        languages.add(new Language(new Long(1), "English", true, "en"));
        languages.add(new Language(new Long(2), "Spanish", true, "es"));
        languages.add(new Language(new Long(3), "Hindi", true, "hi"));
        return languages;
    }

    public void addLanguage(Language language) {
        wasAddLanguageCalled = true;

    }

    public void deleteLanguage(Language language) {
    }

    public boolean wasFindAllCalled() {
        return wasFindAllCalled;
    }

    public void lookupAllBehaviorCategoriesForALanguage(Language lang) {
    }

    public Language lookupLanguageByLocale(String locale) {
        wasLookUpLanguageByLocaleCalled = true;
        if (locale != null && locale.equalsIgnoreCase("SW")) {
            return null;
        }
        return null;
    }

    public List<LanguageBasedCategory> lookupCategoriesForALanguageByType(Language language, boolean isTypeBehavior) {

        Category category = new Category();
        category.setActive(true);

        LanguageBasedCategory languageBasedCategory = new LanguageBasedCategory();
        languageBasedCategory.setDescription("Category");
        LanguageBasedCategoryPK pk = new LanguageBasedCategoryPK();
        pk.setLanguage(language);
        pk.setCategory(category);
        languageBasedCategory.setId(pk);
        List<LanguageBasedCategory> categories = new ArrayList<LanguageBasedCategory>();
        categories.add(languageBasedCategory);
        return categories;
    }

    public boolean wasFindAllLanguageBasedCategoriesCalled() {
        return wasFindAllLanguageBasedCategoriesCalled;
    }

    public List<LanguageBasedResponse> lookupResponsesForALanguage(Language language) {
        List<LanguageBasedResponse> responseList = new ArrayList<LanguageBasedResponse>();

        Response response = new Response();
        response.setId(new Long(2));
        response.setActive(true);
        response.setDefaultOption(true);
        response.setDisplayOrder(2);

        LanguageBasedResponse languageBasedResponse = new LanguageBasedResponse();
        languageBasedResponse.setDescription("Negative 1");
        LanguageBasedResponsePK pk = new LanguageBasedResponsePK();

        pk.setLanguage(language);
        pk.setResponse(response);

        languageBasedResponse.setId(pk);
        responseList.add(languageBasedResponse);

        response = new Response();
        response.setId(new Long(2));
        response.setActive(true);
        response.setDefaultOption(true);
        response.setDisplayOrder(1);

        languageBasedResponse = new LanguageBasedResponse();
        languageBasedResponse.setDescription("Negative 2");
        pk = new LanguageBasedResponsePK();

        pk.setLanguage(language);
        pk.setResponse(response);

        languageBasedResponse.setId(pk);
        responseList.add(languageBasedResponse);
        return responseList;
    }

    public List<LanguageBasedPersonnelType> lookupPersonnelTypesForALanguage(Language language) {
        PersonnelType personnelType = new PersonnelType();
        personnelType.setId(new Long(1));
        personnelType.setActive(true);

        LanguageBasedPersonnelType languageBasedPersonnelType = new LanguageBasedPersonnelType();
        languageBasedPersonnelType.setDescription("Contractor");
        LanguageBasedPersonnelTypePK pk = new LanguageBasedPersonnelTypePK();
        pk.setLanguage(language);
        pk.setPersonnelType(personnelType);

        languageBasedPersonnelType.setId(pk);

        List<LanguageBasedPersonnelType> list = new ArrayList<LanguageBasedPersonnelType>();
        list.add(languageBasedPersonnelType);
        return list;
    }

    public List<LanguageBasedLanguageDescription> lookupLanguagesForALanguage(Language languageDescription) {
        Language language = new Language();
        language.setId(new Long(1));
        language.setActive(true);

        LanguageBasedLanguageDescription languageBasedLanguageDescription = new LanguageBasedLanguageDescription();
        languageBasedLanguageDescription.setDescription("Espa�ol");
        LanguageBasedLanguageDescriptionPK pk = new LanguageBasedLanguageDescriptionPK();
        pk.setLanguage(language);
        pk.setLanguageDescription(languageDescription);

        languageBasedLanguageDescription.setId(pk);

        List<LanguageBasedLanguageDescription> list = new ArrayList<LanguageBasedLanguageDescription>();
        list.add(languageBasedLanguageDescription);
        return list;
    }

    public void saveOrUpdateLanguageBasedLanguage(LanguageBasedLanguageDescription lbld) {
    }

    public void saveOrUpdateLanguageBasedResponse(LanguageBasedResponse response) {
    }

    public List<LanguageBarrierCategory> lookupActiveBarriersForALanguageAndSubCategory(Language language, Category category) {
        BarrierCategory barrier = new BarrierCategory();
        barrier.setId(new Long(2));
        barrier.setActive(true);

        LanguageBarrierCategory languageBarrierCategory = new LanguageBarrierCategory();
        languageBarrierCategory.setDescription("Barrier 1");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();

        pk.setLanguage(language);
        pk.setBarrierCategory(barrier);

        languageBarrierCategory.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(languageBarrierCategory);
        return barriers;
    }

    public List<LanguageBarrierCategory> lookupActiveAndInactiveBarriersForALanguageAndSubCategory(Language lang, Category category) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<LanguageBarrierCategory> lookupInactiveBarriersForALanguageAndSubCategory(Language language, Category category) {
        BarrierCategory barrier = new BarrierCategory();
        barrier.setId(new Long(3));
        barrier.setActive(false);

        LanguageBarrierCategory languageBarrierCategory = new LanguageBarrierCategory();
        languageBarrierCategory.setDescription("Barrier 2");
        LanguageBarrierCategoryPK pk = new LanguageBarrierCategoryPK();

        pk.setLanguage(language);
        pk.setBarrierCategory(barrier);

        languageBarrierCategory.setId(pk);
        List<LanguageBarrierCategory> barriers = new ArrayList<LanguageBarrierCategory>();
        barriers.add(languageBarrierCategory);
        return barriers;
    }

    public boolean wasLookupLanguageByLocaleCalled() {
        return wasLookUpLanguageByLocaleCalled;  //To change body of created methods use File | Settings | File Templates.
    }

    public boolean isWasAddLanguageCalled() {
        return wasAddLanguageCalled;
    }
}