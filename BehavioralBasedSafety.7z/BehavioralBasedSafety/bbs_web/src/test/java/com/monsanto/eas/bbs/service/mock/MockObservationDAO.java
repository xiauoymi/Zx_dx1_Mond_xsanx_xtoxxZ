/*
 MockObservationDAO was created on Jan 6, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.ObservationDAO;
import com.monsanto.eas.bbs.hibernate.Category;
import com.monsanto.eas.bbs.hibernate.Observation;
import com.monsanto.eas.bbs.model.ReportCriteria;
import org.apache.poi.hssf.extractor.ExcelExtractor;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class MockObservationDAO implements ObservationDAO {
    private static Observation observation;
    private boolean wasAddObservationCalled = false;
    private boolean wasLookupObservationCalled = false;
    private boolean observationInactivate;
    private boolean observationUpdated;

    public List<Observation> lookupAllObservationForSubSubCategory(Category cat) {
        Category category = new Category();
        category.setActive(true);
        category.setId(new Long(1));
        Category subCategory = new Category();
        subCategory.setParentCategory(category);
        subCategory.setActive(true);
        subCategory.setId(new Long(2));
        Category subSubCategory = new Category();
        subSubCategory.setParentCategory(subCategory);
        subSubCategory.setId(new Long(3));
        subSubCategory.setActive(true);
        Observation observation1 = new Observation();
//    observation1.setCategory(category);
//    observation1.setSubCategory(subSubCategory);
//    observation1.setSubSubCategory(subSubCategory);
        List<Observation> observationList = new ArrayList<Observation>();
        observationList.add(observation1);
        return observationList;
    }

    //todo this method needs to be deleted.
    public void addObservation(Observation observation) {
        this.observation = observation;
        wasAddObservationCalled = true;
    }

    public void updateObservation(Observation observation) {
        this.observation = observation;
        observationUpdated = true;
    }

    public Observation getObservation() {
        return observation;
    }

    public void deleteObservation(Observation observation) {
    }

    public boolean getWasAddObservationCalled() {
        return wasAddObservationCalled;
    }

    public Observation lookupObservation(Long observationId) {
        wasLookupObservationCalled = true;
        return observation;

    }

    public List<Observation> lookupObservations(ReportCriteria reportCriteria) {
       List<Observation> observationList = new ArrayList<Observation>();

       Observation observation = new Observation();
       observationList.add(observation);

       return observationList;
    }

    public boolean isWasLookupObservationCalled() {
        return wasLookupObservationCalled;
    }

    public void save(Observation entity) {
        this.observation = entity;
        wasAddObservationCalled = true;
    }

    public void delete(Observation entity) {
    }

    public void inactivateObservation(Observation observation) {
        observationInactivate = true;
    }

    public boolean isObservationInactivate() {
        return observationInactivate;
    }

    public boolean isObservationUpdated() {
        return observationUpdated;
    }
}