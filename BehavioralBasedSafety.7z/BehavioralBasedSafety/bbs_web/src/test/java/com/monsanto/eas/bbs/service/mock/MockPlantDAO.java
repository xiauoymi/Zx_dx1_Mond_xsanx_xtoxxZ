/*
 MockPlantDAO was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.PlantDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.TempPlant;

import java.util.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class MockPlantDAO implements PlantDAO {
   private int numberOfTimesAddPlantCalled;
   private boolean wasGetPlantIdCalled = false;
   private int numberOfTimesFindPlantByCriteriaCalled = 0;
   private Integer numberOfTimesAddTempPlantCalled = 0;
   private Integer numberOfTimesUpdatePlantsCalled = 0;
   private Integer numberOfTimesAddPlantsCalled = 0;
   private Integer numberOfTimesClearTempPlantsCalled = 0;
   private Integer numberOfTempPlants = 0;
   private boolean inactivatePlantsNotAssociatedWithSafetyGroupCalled;

   public List<Plant> lookupAllPlants() {
      List<Plant> plantList = new ArrayList<Plant>();
      Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      plant = new Plant(new Long(2), "P002", "Plant Name 21", "vala", "C002", "V002", "002", "Plant Name 22",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      return plantList;
   }

    public Map<String, Plant> getMapOfAllPlants() {
        Map<String, Plant> map = new HashMap<String, Plant>();
        List<Plant> allPlants = lookupAllPlants();
        if (allPlants == null) {
            return map;
        }
        for (Plant plant : allPlants) {
            map.put(plant.getPlantCode(), plant);
        }
        return map;
    }

    public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkArea() {
      List<Plant> plantList = new ArrayList<Plant>();
      Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      plant = new Plant(new Long(2), "P002", "Plant Name 21", "vala", "C002", "V002", "002", "Plant Name 22",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      return plantList;
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByUserRole(BBSUser loggedInUser, String userOwnsRegionDesc) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByCountryId(String countryId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroupAndWorkAreaByRegionId(String regionId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllValidPlantsByCountryIdAndByUserRole(String selectedCountryIds, BBSUser loggedInUser, String userOwnsRegionDesc) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<Plant> lookupAllPlantsAssociatedWithSafetyGroup() {
      List<Plant> plantList = new ArrayList<Plant>();
      Plant plant = new Plant(new Long(1), "P001", "Plant Name 1", "vala", "C001", "V001", "001", "Plant Name 2",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      plant = new Plant(new Long(2), "P002", "Plant Name 21", "vala", "C002", "V002", "002", "Plant Name 22",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      return plantList;
   }

   public void addPlant(Plant plant) {
      numberOfTimesAddPlantCalled++;
   }

   public void deletePlant(Plant plant) {
   }

   public void inactivatePlantsNotAssociatedWithSafetyGroup() {
      inactivatePlantsNotAssociatedWithSafetyGroupCalled = true;
   }

   public void updatePlantWorkAreas() {
   }

   public void addTempPlant(TempPlant plant) {
      numberOfTimesAddTempPlantCalled++;
   }

   public void updatePlants() {
      numberOfTimesUpdatePlantsCalled++;
   }

   public void addPlants() {
      numberOfTimesAddPlantsCalled++;
   }

   public void clearTempPlants() {
      numberOfTimesClearTempPlantsCalled++;
   }

   public List<Plant> findByCriteria(String plantName1, String plantCode) {
      List<Plant> plantList = new ArrayList<Plant>();
      Plant plant = new Plant(new Long(1), "P001", plantName1, "vala", "C001", "V001", "001", "Plant Name 2",
              "Java World", "PO BOX 1234", "12345", "Java", "NA", true, "TEST", new Date());
      plantList.add(plant);
      wasGetPlantIdCalled = true;
      numberOfTimesFindPlantByCriteriaCalled++;
      return plantList;
   }

   public int numberOfTimesInsertCalled() {
      return numberOfTimesAddPlantCalled;  //To change body of created methods use File | Settings | File Templates.
   }

   public boolean wasGetPlantIdCalled() {
      return wasGetPlantIdCalled;  //To change body of created methods use File | Settings | File Templates.
   }

   public int numberOfTimesFindPlantByCriteriaCalled() {
      return numberOfTimesFindPlantByCriteriaCalled;  //To change body of created methods use File | Settings | File Templates.
   }

   public boolean isInactivatePlantsNotAssociatedWithSafetyGroupCalled() {
      return inactivatePlantsNotAssociatedWithSafetyGroupCalled;
   }

   public Integer getNumberOfTimesAddTempPlantCalled() {
      return numberOfTimesAddTempPlantCalled;
   }
}