/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.RegionDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.Region;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class MockRegionDAO implements RegionDAO {

    public String lookupRegionDescriptionByRegionId(Long regionId) {
        if (regionId.equals(new Long(2))) {
            return "LATIN AMERICA SOUTH";
        } else if (regionId.equals(new Long(1))) {
            return "EMEA";
        }
        return "FOO";
    }

    public String lookupRegionDescriptionByPlantId(Long plantId) {
        if (plantId.equals(new Long(5373279))) {
            return "NORTH AMERICA";
        }
        return "FOO";
    }

    public Boolean isInEMEARegion(String region) {
        return region.equals("EMEA");
    }

    public String lookupRegionDescriptionByBBSUser(BBSUser loggedInUser) {
        String userOwnsRegionDesc = "";
        Long regionId = null;

        try {
            regionId = loggedInUser.getPlant().getCountry().getRegionId();
        } catch (Exception e) {
        }

        if (regionId != null) {
            userOwnsRegionDesc = lookupRegionDescriptionByRegionId(regionId);
        }

        return userOwnsRegionDesc;
    }

    public List<Region> lookupAllRegions() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List<Region> lookupAllRegionsByUserRole(BBSUser loggedInUser) {
        String userOwnRegionDesc = lookupRegionDescriptionByRegionId(loggedInUser.getPlant().getCountry().getRegionId());

        List<Region> regionList = new ArrayList<Region>();

        Boolean userIsGlobalLead = loggedInUser.isGlobalLead();
        Boolean userIsESHAdmin = loggedInUser.isESHAdmin();
        Boolean userIsEMEAAdmin = loggedInUser.isEMEAAdmin();

        if (!userIsGlobalLead && !userIsEMEAAdmin) {

            //--If the user is a ESH Admin, based on EMEA region or
            //--If the user in not an ESH Admin, nor a EMEA Admin, nor a Global Lead, then selects only her own site
            if ("EMEA".equals(userOwnRegionDesc)) {
                if (!userIsESHAdmin) {
                    regionList.add(getEMEARegion());
                }
            } else {
                regionList = getAllRegionsButEMEA();
            }

        } else {
            regionList = getAllRegions();
        }

        return regionList;
    }

    private List<Region> getAllRegions() {
        List<Region> regionList = new ArrayList<Region>();

        Region region = new Region();
        region.setId(new Long(5));
        region.setDescription("NORTH AMERICA");
        region.setActive(true);

        regionList.add(region);

        Region region2 = new Region();
        region2.setId(new Long(6));
        region2.setDescription("BRAZIL");
        region2.setActive(true);

        regionList.add(region2);

        Region region3 = new Region();
        region3.setId(new Long(1));
        region3.setDescription("EMEA");
        region3.setActive(true);

        regionList.add(region3);

        return regionList;
    }

    private List<Region> getAllRegionsButEMEA() {
        List<Region> regionList = new ArrayList<Region>();

        Region region = new Region();
        region.setId(new Long(5));
        region.setDescription("NORTH AMERICA");
        region.setActive(true);

        regionList.add(region);

        Region region2 = new Region();
        region2.setId(new Long(6));
        region2.setDescription("BRAZIL");
        region2.setActive(true);

        regionList.add(region2);

        return regionList;
    }

    private Region getEMEARegion() {
        Region region = new Region();
        region.setId(new Long(1));
        region.setDescription("EMEA");
        region.setActive(true);

        return region;
    }

}