/*
 MockRoleDAO was created on Mar 3, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.RoleDAO;
import com.monsanto.eas.bbs.hibernate.BBSRole;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockRoleDAO implements RoleDAO {
  private boolean wasLookUpRolesCalled = false;
  private List<BBSRole> rolesSaved = new ArrayList<BBSRole>();

  public List<BBSRole> lookUpAllRoles() {
    wasLookUpRolesCalled = true;
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void saveOrUpdateRole(BBSRole role) {
    rolesSaved.add(role);
  }

  public boolean wasLookUpRolesCalled() {
    return wasLookUpRolesCalled;  //To change body of created methods use File | Settings | File Templates.
  }

  public List<BBSRole> getRolesSaved() {
    return rolesSaved;
  }
}