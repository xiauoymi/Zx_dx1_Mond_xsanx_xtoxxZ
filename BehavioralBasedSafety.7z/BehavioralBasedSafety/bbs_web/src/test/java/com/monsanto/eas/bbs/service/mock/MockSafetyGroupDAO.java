/*
 MockSafetyGroupDAO was created on Jan 4, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.SafetyGroupDAO;
import com.monsanto.eas.bbs.hibernate.Plant;
import com.monsanto.eas.bbs.hibernate.SafetyGroup;
import com.monsanto.eas.bbs.hibernate.TempSafetyGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class MockSafetyGroupDAO implements SafetyGroupDAO {
    private List<SafetyGroup> safetyGroupsAdded = new ArrayList<SafetyGroup>();
    private List<TempSafetyGroup> tempSafetyGroupsAdded = new ArrayList<TempSafetyGroup>();

    public List<SafetyGroup> lookupSafetyGroupsByPlant(Plant plant) {
        List<SafetyGroup> groups = new ArrayList<SafetyGroup>();
        groups.add(new SafetyGroup(new Long(1), "ABC001", plant, true, false));
        groups.add(new SafetyGroup(new Long(2), "XYZ001", plant, true, false));
        return groups;
    }

    public void addSafetyGroup(SafetyGroup safetyGroup) {
        safetyGroupsAdded.add(safetyGroup);
    }

    public void deleteSafetyGroup(SafetyGroup safetyGroup) {
    }

    public void addTempSafetyGroup(TempSafetyGroup tempSafetyGroup) {
        tempSafetyGroupsAdded.add(tempSafetyGroup);
    }

    public void updateSafetyGroups() {
    }

    public void setBiotechIndicator() {
    }

    public void addSafetyGroups() {
    }

    public void clearTempSafetyGroups() {
    }

    public List<SafetyGroup> getSafetyGroupsAdded() {
        return safetyGroupsAdded;
    }

    public List<TempSafetyGroup> getTempSafetyGroupsAdded() {
        return tempSafetyGroupsAdded;
    }

    public List<SafetyGroup> lookupAll() {
        final List<SafetyGroup> all = lookupSafetyGroupsByPlant(null);
        return all;
    }

    public Map<String, SafetyGroup> getMapOfAllSafetyGroups() {
        Map<String, SafetyGroup> map = new HashMap<String, SafetyGroup>();
        List<SafetyGroup> groups = lookupAll();
        for (SafetyGroup group : groups) {
            map.put(group.getLocationCode(), group);
        }
        return map;
    }
}