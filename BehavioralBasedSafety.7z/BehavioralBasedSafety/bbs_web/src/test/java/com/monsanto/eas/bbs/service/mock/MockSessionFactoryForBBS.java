/*
 MockSessionFactoryForBBS was created on Feb 26, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.bbs.service.mock;

import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.classic.Session;
import org.hibernate.engine.FilterDefinition;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.metadata.CollectionMetadata;
import org.hibernate.stat.Statistics;

import javax.naming.NamingException;
import javax.naming.Reference;
import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockSessionFactoryForBBS implements SessionFactory {
    private MockSessionForBBS mockSession = new MockSessionForBBS();

    public MockSessionFactoryForBBS(){
        mockSession.setCriteriaResults(new ArrayList());
    }

    public MockSessionFactoryForBBS(List queryResults){
        mockSession.setCriteriaResults(queryResults);
    }

    public void setResultList(List resultList){
        mockSession.setCriteriaResults(resultList);
    }

    public MockSessionFactoryForBBS(Map resultMap){
        mockSession.setResultMap(resultMap);
    }

    public MockSessionForBBS getMockSession() {
        return mockSession;
    }

    public Session openSession(Connection connection) {
        return null;
    }

    public Session openSession(Interceptor interceptor) throws HibernateException {
        return null;
    }

    public Session openSession(Connection connection, Interceptor interceptor) {
        return null;
    }

    public Session openSession() throws HibernateException {
        return null;
    }

    public Session getCurrentSession() throws HibernateException {
        //mockSession = new MockSessionForBBS();
        return mockSession;
    }

    public ClassMetadata getClassMetadata(Class persistentClass) throws HibernateException {
        return null;
    }

    public ClassMetadata getClassMetadata(String entityName) throws HibernateException {
        return null;
    }

    public CollectionMetadata getCollectionMetadata(String roleName) throws HibernateException {
        return null;
    }

    public Map getAllClassMetadata() throws HibernateException {
        return null;
    }

    public Map getAllCollectionMetadata() throws HibernateException {
        return null;
    }

    public Statistics getStatistics() {
        return null;
    }

    public void close() throws HibernateException {
    }

    public boolean isClosed() {
        return false;
    }

    public void evict(Class persistentClass) throws HibernateException {
    }

    public void evict(Class persistentClass, Serializable id) throws HibernateException {
    }

    public void evictEntity(String entityName) throws HibernateException {
    }

    public void evictEntity(String entityName, Serializable id) throws HibernateException {
    }

    public void evictCollection(String roleName) throws HibernateException {
    }

    public void evictCollection(String roleName, Serializable id) throws HibernateException {
    }

    public void evictQueries() throws HibernateException {
    }

    public void evictQueries(String cacheRegion) throws HibernateException {
    }

    public StatelessSession openStatelessSession() {
        return null;
    }

    public StatelessSession openStatelessSession(Connection connection) {
        return null;
    }

    public Set getDefinedFilterNames() {
        return null;
    }

    public FilterDefinition getFilterDefinition(String filterName) throws HibernateException {
        return null;
    }

    public Reference getReference() throws NamingException {
        return null;
    }
}
