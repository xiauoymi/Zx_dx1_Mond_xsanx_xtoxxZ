package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.UserDAO;
import com.monsanto.eas.bbs.hibernate.BBSUser;
import com.monsanto.eas.bbs.hibernate.TempBBSUser;

import java.util.*;

public class MockUserDAO implements UserDAO {
   private boolean wasfindByUserIdCalled = false;
   private boolean wasAddUserCalled = false;
   private int numberOfTimesAddUserCalled;
   private BBSUser savedUser;
   private Map<String, BBSUser> bbsUserMap = new HashMap<String, BBSUser>();
   private List<TempBBSUser> tempUsers = new ArrayList<TempBBSUser>();

   public boolean isWasLookupUserByCriteriaCalled() {
      return wasLookupUserByCriteriaCalled;
   }

   private boolean wasLookupUserByCriteriaCalled = false;


   public void addUser(BBSUser user) {
      savedUser = user;
      numberOfTimesAddUserCalled++;
      wasAddUserCalled = true;

      bbsUserMap.put(user.getUserId(), user);
   }

   public List<BBSUser> lookupAllContractors(boolean active) {
      //return null;
      List<BBSUser> bbsUserList = new ArrayList<BBSUser>();
      bbsUserList.add(new BBSUser(new Long(1), "test", "test", "test", "test", true, new Date(), "TEST", new Date()));
      bbsUserList.add(new BBSUser(new Long(2), "test", "test", "test", "test", true, new Date(), "TEST", new Date()));
      return bbsUserList;
   }

   public Boolean isUserInRegion(Long regionId, String userName) {
      Boolean b = (regionId.equals(new Long(5)) && userName.equals("TEST_USR"));
      return b;
   }

   public Boolean isUserInRegion(String regionDescription, String userName) {
      return (regionDescription.equals("NORTH AMERICA") && userName.equals("TEST_USR"));
   }

   public List<BBSUser> lookupUserWithRoles() {
      List<BBSUser> userList = new ArrayList<BBSUser>();
      userList.add(new BBSUser(new Long(1), "test", "test", "test", "test", true, new Date(), "TEST", new Date()));
      userList.add(new BBSUser(new Long(2), "test", "test", "test", "test", true, new Date(), "TEST", new Date()));
      return userList;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public Integer getTotalBBSUsers() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public boolean updateUser(BBSUser user) {
      return false;
   }

   public void addTempUser(TempBBSUser tempUser) {
      tempUsers.add(tempUser);
   }

   public List<TempBBSUser> getTempUsers() {
      return tempUsers;
   }

   public boolean deleteUser(BBSUser user) {

      if (bbsUserMap.get(user.getUserId()) != null) {
         bbsUserMap.remove(user.getUserId());
         return true;
      }
      return false;
   }

   public BBSUser findByUserId(String userId) {
      wasfindByUserIdCalled = true;
      if ("MOCKUSER".equalsIgnoreCase(userId)) {
         return null;
      }

      if (bbsUserMap.get(userId) != null) {
         return bbsUserMap.get(userId);
      }
      return null;
      /*
      Plant plant = new Plant();
      plant.setId(new Long(133));
      user.setPlant(plant);
      Department department = new Department();
      department.setId(new Long(143));
      user.setDepartment(department);
      HashSet<BBSRole> roles = new HashSet<BBSRole>();
      BBSRole role = new BBSRole();
      role.setId(new Long(11));
      roles.add(role);
      user.setRoles(roles);

      return user;
      */
   }

   public boolean isWasfindByUserIdCalled() {
      return wasfindByUserIdCalled;
   }

   public boolean isWasAddUserCalled() {
      return wasAddUserCalled;
   }

   public List<BBSUser> lookupUserByCriteria(String userName) {
      wasLookupUserByCriteriaCalled = true;
      List<BBSUser> users = new ArrayList<BBSUser>();
      BBSUser user = new BBSUser(new Long(1), "ABC123", userName, null, null, true, new Date(), "TEST", new Date());
      users.add(user);
      user = new BBSUser(new Long(2), "ABC123", null, userName, null, true, new Date(), "TEST", new Date());
      users.add(user);
      return users;

   }

   public int numberOfTimesAddUserCalled() {
      return numberOfTimesAddUserCalled;  //To change body of created methods use File | Settings | File Templates.
   }

   public BBSUser getSavedUser() {
      return savedUser;
   }

   public List<BBSUser> lookupAllUsers(boolean active) {
      List<BBSUser> users = new ArrayList<BBSUser>();
      BBSUser user = new BBSUser(new Long(1), "JDOE", "John", null, "Doe", true, new Date(), "TEST", new Date());
      user.setActive(true);
      users.add(user);
      user = new BBSUser(new Long(1), "JDOE1", "Jane", "f", "Doe", true, new Date(), "TEST", new Date());
      user.setActive(true);
      users.add(user);
      return users;
   }

   public List<TempBBSUser> lookupTempUsers(boolean active) {
      List<TempBBSUser> users = new ArrayList<TempBBSUser>();

      TempBBSUser user = new TempBBSUser();
      user.setId(new Long(1));
      user.setUserId("JDOE");
      user.setFirstName("John");
      user.setLastName("Doe");
      user.setManager("JDOE_MANAGER");
      users.add(user);

      user = new TempBBSUser();
      user.setId(new Long(2));
      user.setUserId("JDOE1");
      user.setFirstName("Jane");
      user.setLastName("Doe");
      user.setManager("JDOE_MANAGER2");
      users.add(user);
      users.add(user);

      user = new TempBBSUser();
      user.setId(new Long(3));
      user.setUserId("JDOE_MANAGER");
      user.setFirstName("JMANAGER");
      user.setLastName("Doe");
      users.add(user);

      return users;
   }


   public Map<String, BBSUser> getTempBBSUsersPendingForInsert() {
      Map<String, BBSUser> map = new HashMap<String, BBSUser>();

      List<BBSUser> users = lookupAllUsers(true);
      List<TempBBSUser> tempUsers = lookupTempUsers(true);

      for (TempBBSUser bbsUserTemp : tempUsers) {
         if ( ! users.contains(bbsUserTemp)) {
            map.put( bbsUserTemp.getUserId(), bbsUserTemp.getBBSUserFromTempBBSUser());
         }
      }
      return map;
   }

   public List<TempBBSUser> getTempBBSUsersWithNotExistingManager() {
      List<TempBBSUser> tempUsers = lookupTempUsers(true);
      List<TempBBSUser> tempUsers2 = lookupTempUsers(true);

      List<TempBBSUser> userWithNotExistingManagerList = new ArrayList<TempBBSUser>();

      for (TempBBSUser bbsUserTemp : tempUsers) {

         TempBBSUser user = new TempBBSUser();
         user.setUserId(bbsUserTemp.getUserId());
         user.setFirstName("JMANAGER");
         user.setLastName("Doe");

         if ( ! tempUsers2.contains(user)) {
            userWithNotExistingManagerList.add(bbsUserTemp);
         }
      }

      return userWithNotExistingManagerList;
   }

   public void setDefaultValueForUsersWithInvalidManager() {
      List<TempBBSUser> tempUsers = getTempBBSUsersWithNotExistingManager();

      for(TempBBSUser tempBBSUser : tempUsers){
         tempBBSUser.setManager(null);
      }
   }

   public Map<String, BBSUser> lookupUsersByUserId(String[] usersId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<BBSUser> lookupAllUsersByUserId(String[] usersId) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<BBSUser> lookupAllUsersWithoutDependencies(boolean active) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public List<BBSUser> lookupAllUsersWithoutDependecies(boolean active) {
      List<BBSUser> users = new ArrayList<BBSUser>();
      BBSUser user = new BBSUser(new Long(1), "JDOE", "John", null, "Doe", true, new Date(), "TEST", new Date());
      user.setActive(true);
      users.add(user);
      user = new BBSUser(new Long(1), "JDOE1", "Jane", "f", "Doe", true, new Date(), "TEST", new Date());
      user.setActive(true);
      users.add(user);
      return users;
   }

   public List<TempBBSUser> lookupAllTempUsers() {
      return null;
   }

   public void inactivateBBSUsers() {
   }

   public void inactivateBBSUsersByChunk(String[] usersId) {
      //To change body of implemented methods use File | Settings | File Templates.
   }

   public void inactivateAllEmployeeBBSUsers() {
      //To change body of implemented methods use File | Settings | File Templates.
   }

   public void inactivateBBSUsers(String inactiveUserList) {
      //To change body of implemented methods use File | Settings | File Templates.
   }


   public void updateBBSUsers() {
   }

   public void clearTempUsers() {
   }
}