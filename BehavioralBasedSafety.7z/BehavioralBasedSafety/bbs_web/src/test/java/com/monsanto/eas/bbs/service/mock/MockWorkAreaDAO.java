/*
 Copyright:  Copyright  2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.bbs.service.mock;

import com.monsanto.eas.bbs.dao.WorkAreaDAO;
import com.monsanto.eas.bbs.hibernate.WorkArea;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author JTMURR
 * @version $Revision$
 */
public class MockWorkAreaDAO implements WorkAreaDAO {
  private List<WorkArea> list = new ArrayList<WorkArea>();
  private Boolean addWorkAreaCalled = false;
  private Boolean deleteWorkAreaCalled = false;
  private Boolean clearWorkAreasCalled = false;

  public List<WorkArea> lookupAll() {
    return list;
  }


  public void addWorkArea(WorkArea workArea) {
    list.add(workArea);
    setAddWorkAreaCalled(true);
  }

  public void deleteWorkArea(WorkArea workArea) {
    list.remove(workArea);
    setDeleteWorkAreaCalled(true);
  }

  public void clearWorkAreas() {
    setClearWorkAreasCalled(true);
  }

  public List<WorkArea> lookupAllAreasWithLocations() {
    List<WorkArea> workAreaList = new ArrayList<WorkArea>();
    workAreaList.add(new WorkArea("test", "test"));
    return workAreaList; //To change body of implemented methods use File | Settings | File Templates.
  }

  private void setAddWorkAreaCalled(Boolean b) {
    addWorkAreaCalled = b;
  }

  private void setDeleteWorkAreaCalled(Boolean b) {
    deleteWorkAreaCalled = b;
  }

  public Boolean getClearWorkAreasCalled() {
    return clearWorkAreasCalled;
  }

  public void setClearWorkAreasCalled(Boolean clearWorkAreasCalled) {
    this.clearWorkAreasCalled = clearWorkAreasCalled;
  }
}