package com.monsanto.eas.bbs.service.report;

import com.monsanto.eas.bbs.dao.UserDAO;
import com.monsanto.eas.bbs.model.report.Report;
import com.monsanto.eas.bbs.service.UserService;
import com.monsanto.eas.bbs.service.UserServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ReportServiceImpl_AT
{
    @Autowired private DataSource dataSource;
    @Autowired private UserDAO userDao;

    private ReportServiceImpl service;

    @Before
    public void setUp() {
        UserService userService = new UserServiceImpl(userDao, null);
        service = new ReportServiceImpl(dataSource, userService);
    }

    @Test
    public void testAdminUsersReport() {
        Report report = service.lookupReport("adminUsersReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 5, report.getPropertyCount());
    }

    @Test
    public void testContractorsReport() {
        Report report = service.lookupReport("contractorsReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 6, report.getPropertyCount());
    }

    @Test
    public void testContractorCompaniesReport() {
        Report report = service.lookupReport("contractorCompaniesReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 1, report.getPropertyCount());
    }

    @Test
    public void testCategoriesReport() {
        Report report = service.lookupReport("categoriesReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 5, report.getPropertyCount());
    }

    @Test
    public void testBarriersReport() {
        Report report = service.lookupReport("barriersReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 4, report.getPropertyCount());
    }

    @Test
    public void testTasksReport() {
        Report report = service.lookupReport("tasksReport", null);

        assertTrue("The report should return at least 1 item.", report.getItemCount() > 0);
        assertEquals("The number of properties in the report is incorrect.", 1, report.getPropertyCount());
    }
}