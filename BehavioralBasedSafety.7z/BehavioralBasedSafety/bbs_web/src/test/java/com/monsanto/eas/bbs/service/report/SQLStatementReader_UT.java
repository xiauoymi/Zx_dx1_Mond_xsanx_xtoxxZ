package com.monsanto.eas.bbs.service.report;

import org.junit.Test;

import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class SQLStatementReader_UT
{

    @Test
    public void testReadSQLStatementsFromFile() throws Exception {
        SQLStatement sqlStatement = new SQLStatementReader().readSQLStatementsFromFile(CategoriesFetcher.class, "getListOfCategories.sql");

        assertNotNull(sqlStatement);
        assertEquals(
            "The expected SQL was not returned.",
            "SELECT TRIM(BOTH CHR(9) FROM TRIM(LCT.DESCRIPTION)) AS \"Category Type\", TRIM(BOTH CHR(9) FROM TRIM(LC1.DESCRIPTION)) AS \"Category\", TRIM(BOTH CHR(9) FROM TRIM(LC2.DESCRIPTION)) AS \"Sub Category\", NVL(TRIM(BOTH CHR(9) FROM TRIM(LC3.DESCRIPTION)), '---------------------------------') AS \"Detail\", DECODE( ( SELECT CT.ACTIVE || C1.ACTIVE || C2.ACTIVE || C3.ACTIVE FROM DUAL ), 'YYY', 'Active', 'YYYY', 'Active', 'Inactive' ) AS \"Status\" FROM BBS.CATEGORY C1 INNER JOIN BBS.CATEGORY C2 ON C2.PARENT_CAT_ID = C1.ID LEFT OUTER JOIN BBS.CATEGORY C3 ON C3.PARENT_CAT_ID = C2.ID LEFT OUTER JOIN BBS.LAN_CATEGORY LC1 ON LC1.CATEGORY_ID = C1.ID LEFT OUTER JOIN BBS.LAN_CATEGORY LC2 ON LC2.CATEGORY_ID = C2.ID AND LC2.BBS_LANG_ID = LC1.BBS_LANG_ID LEFT OUTER JOIN BBS.LAN_CATEGORY LC3 ON LC3.CATEGORY_ID = C3.ID AND LC3.BBS_LANG_ID = LC2.BBS_LANG_ID LEFT OUTER JOIN BBS.CATEGORY_TYPE CT ON C1.CATEGORY_TYPE_ID = CT.ID LEFT OUTER JOIN BBS.LAN_CATEGORY_TYPE LCT ON CT.ID = LCT.CATEGORY_TYPE_ID AND LCT.BBS_LANG_ID = LC1.BBS_LANG_ID WHERE LC1.BBS_LANG_ID = 2 AND C1.PARENT_CAT_ID IS NULL AND LCT.DESCRIPTION IS NOT NULL ORDER BY \"Status\", \"Category Type\", \"Category\", \"Sub Category\", \"Detail\"",
            sqlStatement.getSql()
        );

        List<SQLParameter> parameters = sqlStatement.getParameters();
        assertEquals("Invalid number of parameters parsed.", 5, parameters.size());

        Iterator<SQLParameter> iterator = parameters.iterator();
        assertIsOutputParameterWithName(iterator.next(), "categoryType");
        assertIsOutputParameterWithName(iterator.next(), "category");
        assertIsOutputParameterWithName(iterator.next(), "subCategory");
        assertIsOutputParameterWithName(iterator.next(), "detail");
        assertIsOutputParameterWithName(iterator.next(), "status");
    }

    private void assertIsOutputParameterWithName(SQLParameter parameter, String parameterName) {
        assertEquals("Parameter is not of type OUT.", true, parameter.isOut());
        assertEquals("Parameter name is incorrect.", parameterName, parameter.getName());
    }
}