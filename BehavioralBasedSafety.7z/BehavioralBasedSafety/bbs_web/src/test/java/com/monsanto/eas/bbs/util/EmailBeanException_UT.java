package com.monsanto.eas.bbs.util;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: FJADAN
 * Date: 1/8/14
 * Time: 10:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmailBeanException_UT {

    @Test(expected = EmailBeanException.class)
    public void testCustomEmailBeanException() throws Exception {
        throw new EmailBeanException("This is a test for custom Email exception", new RuntimeException());
    }
}
