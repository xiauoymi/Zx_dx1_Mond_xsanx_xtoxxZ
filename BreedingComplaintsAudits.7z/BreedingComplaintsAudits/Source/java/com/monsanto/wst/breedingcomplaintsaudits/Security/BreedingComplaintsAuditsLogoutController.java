package com.monsanto.wst.breedingcomplaintsaudits.Security;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.AbstractLogging.Logger;

import java.io.IOException;

/**
 *
 * <p>Title: BreedingComplaintsAuditsLogoutController.java</p>
 * <p>Description: Closes the session and calls the logon controller.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: BreedingComplaintsAuditsLogoutController.java,v 1.1 2006-08-08 19:49:25 ardharn Exp $
 */
public class BreedingComplaintsAuditsLogoutController implements UseCaseController
{
   /**
    * Closes the session and calls the logon controller to re-logon the user.
    * @param helper A Use Case Controller helper class.
    * @throws java.io.IOException
    */
   public void run(UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      helper.closeSession();
      helper.displayHTML_File("html/BreedingComplaintsAuditsLogon.html");

      Logger.traceExit();
   }
}
