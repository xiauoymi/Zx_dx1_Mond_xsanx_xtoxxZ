/*
 * Created on Mar 7, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.Security;

import com.monsanto.wst.breedingcomplaintsaudits.model.User;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;

import javax.servlet.http.HttpSession;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MCASSecurity {

	public static synchronized boolean isAuthorized(HttpSession session,String permissionId) {
		boolean authorized = false;
		User user = (User)session.getAttribute("user");
		if (user!=null) {
			if (McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.securityCheck").equals("true"))
				authorized=user.isRole(permissionId);
			else
				authorized=true;		// Set default in case that the securityCheck flag is false.
		}
		return authorized;
	}
}
