//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;

/** 
 * MyEclipse Struts
 * Creation date: 04-07-2005
 * 
 * XDoclet definition:
 * @struts:form name="auditForm"
 */
public class AuditForm extends org.apache.struts.validator.ValidatorForm {

	// --------------------------------------------------------- Instance Variables
	
	private com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject auditObj = new com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject();
	
	private boolean recordSavedMsg;
	
	private boolean displayCarTable2 = false;
	
	private boolean displayParTable2 = false;
	
	private String displayTab; 
	
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}
	
	
	
	
	/**
	 * @return Returns the auditObj.
	 */
	public AuditObject getAuditObj() {
		return auditObj;
	}
	/**
	 * @param auditObj The auditObj to set.
	 */
	public void setAuditObj(AuditObject auditObj) {
		this.auditObj = auditObj;
	}
	/**
	 * @return Returns the recordSavedMsg.
	 */
	public boolean isRecordSavedMsg() {
		return recordSavedMsg;
	}
	/**
	 * @param recordSavedMsg The recordSavedMsg to set.
	 */
	public void setRecordSavedMsg(boolean recordSavedMsg) {
		this.recordSavedMsg = recordSavedMsg;
	}
	
	/**
	 * @return Returns the displayCarTable2.
	 */
	public boolean isDisplayCarTable2() {
		return displayCarTable2;
	}
	/**
	 * @param displayCarTable2 The displayCarTable2 to set.
	 */
	public void setDisplayCarTable2(boolean displayCarTable2) {
		this.displayCarTable2 = displayCarTable2;
	}
	/**
	 * @return Returns the displayParTable2.
	 */
	public boolean isDisplayParTable2() {
		return displayParTable2;
	}
	/**
	 * @param displayParTable2 The displayParTable2 to set.
	 */
	public void setDisplayParTable2(boolean displayParTable2) {
		this.displayParTable2 = displayParTable2;
	}
	
	/**
	 * @return Returns the displayTab.
	 */
	public String getDisplayTab() {
		return displayTab;
	}
	/**
	 * @param displayTab The displayTab to set.
	 */
	public void setDisplayTab(String displayTab) {
		this.displayTab = displayTab;
	}

	
}