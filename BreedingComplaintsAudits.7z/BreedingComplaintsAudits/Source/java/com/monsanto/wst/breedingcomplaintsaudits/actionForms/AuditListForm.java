//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.struts.validator.ValidatorActionForm;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;

/** 
 * MyEclipse Struts
 * Creation date: 04-27-2005
 * 
 * XDoclet definition:
 * @struts:form name="auditListForm"
 */
public class AuditListForm extends ValidatorActionForm {

	//**For capturing user selection...
	private AuditListObject auditFilterObj = new AuditListObject();
	
	private LinkedHashMap auditMap = new LinkedHashMap();
	
	private boolean auditMapEmpty;
	
	
	
	/**
	 * @return Returns the auditMapEmpty.
	 */
	public boolean isAuditMapEmpty() {
		return auditMapEmpty;
	}
	/**
	 * @param auditMapEmpty The auditMapEmpty to set.
	 */
	public void setAuditMapEmpty(boolean auditMapEmpty) {
		this.auditMapEmpty = auditMapEmpty;
	}
	/**
	 * @return Returns the auditFilterObj.
	 */
	public AuditListObject getAuditFilterObj() {
		return auditFilterObj;
	}
	/**
	 * @param auditFilterObj The auditFilterObj to set.
	 */
	public void setAuditFilterObj(AuditListObject auditFilterObj) {
		this.auditFilterObj = auditFilterObj;
	}
	/**
	 * @return Returns the auditMap.
	 */
	public LinkedHashMap getAuditMap() {
		return auditMap;
	}
	/**
	 * @param auditMap The auditMap to set.
	 */
	public void setAuditMap(HashMap auditMap) {
		this.auditMap = new LinkedHashMap(auditMap);
	}
	/**
	 * @param auditMap The auditMap to set.
	 */
	public void setAuditMap(LinkedHashMap auditMap) {
		this.auditMap = auditMap;
	}
	
	
	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}
	
}