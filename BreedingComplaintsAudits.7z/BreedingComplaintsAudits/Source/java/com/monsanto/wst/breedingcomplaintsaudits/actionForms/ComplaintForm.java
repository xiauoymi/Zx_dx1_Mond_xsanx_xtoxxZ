/*
 * Created on Jan 18, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actionForms;


import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintForm extends org.apache.struts.validator.ValidatorActionForm {
	private Complaint c;	
	
	/**
	 * 
	 */
	public ComplaintForm() {
		super();
		this.setC(new Complaint());
	}
	/**
	 * @return Returns the c.
	 */
	public Complaint getC() {
		return c;
	}
	/**
	 * @param c The c to set.
	 */
	public void setC(Complaint c) {
		this.c = c;
	}

	
//	public void reset(ActionMapping mapping, ServletRequest request) {
//		this.c = null;
//		this.c.setComplaint_id(null);
//		this.c.setRow_entry_date(null);
//		this.c.setCreated_by(null);
//		this.c.setAffected_areas(null);
//		this.c.setBatch_four(null);
//		this.c.setBatch_one(null);
//		this.c.setBatch_three(null);
//		this.c.setBatch_two(null);
//		this.c.setBrand_four(null);
//		this.c.setBrand_one(null);
//		this.c.setBrand_three(null);
//		this.c.setBrand_two(null);
//		this.c.setClaim_number(null);
//		this.c.setCommunication_date(null);
//		this.c.setContainment_actions(null);
//		this.c.setCrop_id(null);
//		this.c.setDriver_performance(false);
//		this.c.setIncorrect_shipment(false);
//		this.c.setDelivery_other(false);
//		this.c.setPackaging_condition(false);
//		this.c.setTag_error(false);
//		this.c.setSeed_appearance(false);
//		this.c.setSeed_variability(false);
//		this.c.setEmergence_concerns(false);
//		this.c.setProduct_purity(false);
//		this.c.setEarly_season_other(false);
//		this.c.setGrowth_development(false);
//		this.c.setPollination_problems(false);
//		this.c.setHerbicide_injury(false);
//		this.c.setStress_susceptability(false);
//		this.c.setDisease_development(false);
//		this.c.setMidseason_other(false);
//		this.c.setInsect_outbreaks_injury(false);
//		this.c.setLateseason_disease_development(false);
//		this.c.setMaintaining_seed_until_harvest(false);
//		this.c.setInsect_development(false);
//		this.c.setMaturity_drydown(false);
//		this.c.setSeed_development(false);
//		this.c.setLate_season_other(false);
//		this.c.setNoncompetitive_yield(false);
//	}

	
//	public ActionErrors validate(ActionMapping mapping,
//            ServletRequest request) {
//		Map paramMap = request.getParameterMap();;
//		//List batchList = this.c.getBatch_list();
//		//batchList.clear();
//		//batchList.addAll(tmpList);
//		ActionErrors actionErrors = super.validate(mapping,request);
//		return actionErrors;
//	}
	
}
