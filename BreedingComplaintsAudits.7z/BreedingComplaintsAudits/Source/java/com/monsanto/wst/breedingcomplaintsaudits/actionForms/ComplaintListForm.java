/*
 * Created on Feb 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintListForm extends org.apache.struts.validator.ValidatorActionForm {
	private String controlNumber;
	private String createDate;
	private String initiatedBy;
	private String salesYr;
	private String reportingLocation;
	private String responsibleLocation;
	private String status;
	private String region;
	private String claimNumber;
	private String crop;
	
	private String state;
	private String variety;
	private String batch;
    private String qualityissue;

   	private LinkedHashMap complaintsList;


    public String getQualityissue() {
           return qualityissue;
       }

       public void setQualityissue(String qualityissue) {
           this.qualityissue = qualityissue;
       }
    
	/**
	 * 
	 */
	public ComplaintListForm() {
		super();
	}
	
	
	
	/**
	 * @return Returns the batch.
	 */
	public String getBatch() {
		return batch;
	}
	/**
	 * @param batch The batch to set.
	 */
	public void setBatch(String batch) {
		this.batch = batch;
	}
	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return Returns the variety.
	 */
	public String getVariety() {
		return variety;
	}
	/**
	 * @param variety The variety to set.
	 */
	public void setVariety(String variety) {
		this.variety = variety;
	}
	/**
	 * @return Returns the crop.
	 */
	public String getCrop() {
		return "1";
	}
	/**
	 * @param crop The crop to set.
	 */
	public void setCrop(String crop) {
		this.crop = "1";
	}
	/**
	 * @return Returns the claimNumber.
	 */
	public String getClaimNumber() {
		return claimNumber;
	}
	/**
	 * @param claimNumber The claimNumber to set.
	 */
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	/**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}
	/**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}
	/**
	 * @return Returns the createDate.
	 */
	public String getCreateDate() {
		return createDate;
	}
	/**
	 * @param createDate The createDate to set.
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	/**
	 * @return Returns the initiatedBy.
	 */
	public String getInitiatedBy() {
		return initiatedBy;
	}
	/**
	 * @param initiatedBy The initiatedBy to set.
	 */
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the complaintsList.
	 */
	public LinkedHashMap getComplaintsList() {
		return complaintsList;
	}
	/**
	 * @param complaintsList The complaintsList to set.
	 */
	public void setComplaintsList(Map complaintsList) {
		this.complaintsList = new LinkedHashMap(complaintsList);
	}
	public void setComplaintsList(LinkedHashMap complaintsList) {
		this.complaintsList = complaintsList;
	}
	/**
	 * @return Returns the salesYr.
	 */
	public String getSalesYr() {
		return salesYr;
	}
	/**
	 * @param salesYr The salesYr to set.
	 */
	public void setSalesYr(String salesYr) {
		this.salesYr = salesYr;
	}
	/**
	 * @return Returns the reportingLocation.
	 */
	public String getReportingLocation() {
		return reportingLocation;
	}
	/**
	 * @param reportingLocation The reportingLocation to set.
	 */
	public void setReportingLocation(String reportingLocation) {
		this.reportingLocation = reportingLocation;
	}
	/**
	 * @return Returns the responsibleLocation.
	 */
	public String getResponsibleLocation() {
		return responsibleLocation;
	}
	/**
	 * @param responsibleLocation The responsibleLocation to set.
	 */
	public void setResponsibleLocation(String responsibleLocation) {
		this.responsibleLocation = responsibleLocation;
	}
}
