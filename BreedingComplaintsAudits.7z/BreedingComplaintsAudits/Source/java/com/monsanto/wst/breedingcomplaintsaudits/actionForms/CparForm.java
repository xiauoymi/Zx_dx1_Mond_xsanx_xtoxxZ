/*
 * Created on Feb 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparForm extends org.apache.struts.validator.ValidatorActionForm {
	private Cpar cpar;
	
	public CparForm() {
		super();
		this.setCpar(new Cpar());
	}

	/**
	 * @return Returns the cpar.
	 */
	public Cpar getCpar() {
		return cpar;
	}
	/**
	 * @param cpar The cpar to set.
	 */
	public void setCpar(Cpar cpar) {
		this.cpar = cpar;
	}
}
