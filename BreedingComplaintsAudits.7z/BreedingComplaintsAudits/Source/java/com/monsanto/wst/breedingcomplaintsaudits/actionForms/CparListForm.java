/*
 * Created on Feb 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparListForm extends org.apache.struts.validator.ValidatorActionForm {
	private String controlNumber="";
	private String createDateFrom="";
	private String createDateTo="";
	private String initiatedBy="";
	private String status="";
	private String region="";
	private String filingLocation="";
	private String responsibleLocation="";
	private String claimNumber="";
    private String isoStandard;
    private LinkedHashMap cparsList;
	
	public CparListForm() {
		super();
	}
	/**
	 * @return Returns the claimNumber.
	 */
	public String getClaimNumber() {
		return claimNumber;
	}
	/**
	 * @param claimNumber The claimNumber to set.
	 */
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

    public String getIsoStandard() {
        return isoStandard;
    }

    public void setIsoStandard(String iso_standard) {
        this.isoStandard = iso_standard;
    }

    /**
	 * @return Returns the complaintsList.
	 */
	public LinkedHashMap getCparsList() {
		return cparsList;
	}
	/**
	 * @param cparsList The complaintsList to set.
	 */
	public void setCparsList(Map cparsList) {
		this.cparsList = new LinkedHashMap(cparsList);
	}
	public void setCparsList(LinkedHashMap cparsList) {
		this.cparsList = cparsList;
	}
	/**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}
	/**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}

	/**
	 * @return Returns the initiatedBy.
	 */
	public String getInitiatedBy() {
		return initiatedBy;
	}
	/**
	 * @param initiatedBy The initiatedBy to set.
	 */
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return Returns the createDateFrom.
	 */
	public String getCreateDateFrom() {
		return createDateFrom;
	}
	/**
	 * @param createDateFrom The createDateFrom to set.
	 */
	public void setCreateDateFrom(String createDateFrom) {
		this.createDateFrom = createDateFrom;
	}
	/**
	 * @return Returns the createDateTo.
	 */
	public String getCreateDateTo() {
		return createDateTo;
	}
	/**
	 * @param createDateTo The createDateTo to set.
	 */
	public void setCreateDateTo(String createDateTo) {
		this.createDateTo = createDateTo;
	}
	/**
	 * @return Returns the filingLocation.
	 */
	public String getFilingLocation() {
		return filingLocation;
	}
	/**
	 * @param filingLocation The filingLocation to set.
	 */
	public void setFilingLocation(String filingLocation) {
		this.filingLocation = filingLocation;
	}
	/**
	 * @return Returns the responsibleLocation.
	 */
	public String getResponsibleLocation() {
		return responsibleLocation;
	}
	/**
	 * @param responsibleLocation The responsibleLocation to set.
	 */
	public void setResponsibleLocation(String responsibleLocation) {
		this.responsibleLocation = responsibleLocation;
	}
	
	public void reset() {
		this.setClaimNumber("");
		this.setControlNumber("");
		this.setCreateDateFrom("");
		this.setCreateDateTo("");
		this.setInitiatedBy("");
		this.setRegion("");
		this.setStatus("0");
		this.setFilingLocation("");
		this.setResponsibleLocation("");
        this.setIsoStandard("");
    }
}
