//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.struts.validator.ValidatorActionForm;

import com.monsanto.wst.breedingcomplaintsaudits.model.CparLog;

/** 
 * MyEclipse Struts
 * Creation date: 07-14-2005
 * 
 * XDoclet definition:
 * @struts:form name="cparLogForm"
 */
public class CparLogForm extends ValidatorActionForm {
	
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	CparLog cparLog = new CparLog();
	
	//**Report Tag Objects...	
	private HashMap hash = new HashMap();	//**Data HashMap
	private InputStream xmlIn;				//**Report Structure Stream			
	private String sortBy;	
	private String sortOrder;

	private Date currDate = new Date(System.currentTimeMillis());
	
	private String currDateStr;
	
	
	
	/**
	 * @return Returns the currDateStr.
	 */
	public String getCurrDateStr() {
		currDateStr = getDateFormat(currDate);
		return currDateStr;
	}
	/**
	 * @param currDateStr The currDateStr to set.
	 */
	public void setCurrDateStr(String currDateStr) {
		this.currDateStr = currDateStr;
	}
	/**
	 * @return Returns the currDate.
	 */
	public Date getCurrDate() {
		return currDate;
	}
	/**
	 * @param currDate The currDate to set.
	 */
	public void setCurrDate(Date currDate) {
		this.currDate = currDate;
	}
	/**
	 * @return Returns the hash.
	 */
	public HashMap getHash() {
		return hash;
	}
	/**
	 * @param hash The hash to set.
	 */
	public void setHash(HashMap hash) {
		this.hash = hash;
	}
	/**
	 * @return Returns the sortBy.
	 */
	public String getSortBy() {
		return sortBy;
	}
	/**
	 * @param sortBy The sortBy to set.
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	/**
	 * @return Returns the sortOrder.
	 */
	public String getSortOrder() {
		return sortOrder;
	}
	/**
	 * @param sortOrder The sortOrder to set.
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	/**
	 * @return Returns the xmlIn.
	 */
	public InputStream getXmlIn() {
		return xmlIn;
	}
	/**
	 * @param xmlIn The xmlIn to set.
	 */
	public void setXmlIn(InputStream xmlIn) {
		this.xmlIn = xmlIn;
	}
	/**
	 * @return Returns the cparLog.
	 */
	public CparLog getCparLog() {
		return cparLog;
	}
	/**
	 * @param cparLog The cparLog to set.
	 */
	public void setCparLog(CparLog cparLog) {
		this.cparLog = cparLog;
	}
	
	private String getDateFormat(Date date){
		try {
			sdf.format(date).toString();
			return sdf.format(date).toString();
		}
		catch (Exception e){
			return "";
		}
	}	
}