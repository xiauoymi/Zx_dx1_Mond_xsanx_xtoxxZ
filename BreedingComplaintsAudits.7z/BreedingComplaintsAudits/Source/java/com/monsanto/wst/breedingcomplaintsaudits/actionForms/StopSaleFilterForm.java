//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.io.InputStream;
import java.util.HashMap;

import org.apache.struts.validator.ValidatorActionForm;

import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleFilter;

/** 
 * MyEclipse Struts
 * Creation date: 06-22-2005
 * 
 * XDoclet definition:
 * @struts:form name="stopSaleFilterForm"
 */
public class StopSaleFilterForm extends ValidatorActionForm {

	StopSaleFilter stopSaleFilter = new StopSaleFilter();
	
	//**Report Tag Objects...	
	private HashMap hash = new HashMap();	//**Data HashMap
	private InputStream xmlIn;				//**Report Structure Stream			
	private String sortBy;	
	private String sortOrder;
	
	

	/**
	 * @return Returns the hash.
	 */
	public HashMap getHash() {
		return hash;
	}
	/**
	 * @param hash The hash to set.
	 */
	public void setHash(HashMap hash) {
		this.hash = hash;
	}
	/**
	 * @return Returns the sortBy.
	 */
	public String getSortBy() {
		return sortBy;
	}
	/**
	 * @param sortBy The sortBy to set.
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	/**
	 * @return Returns the sortOrder.
	 */
	public String getSortOrder() {
		return sortOrder;
	}
	/**
	 * @param sortOrder The sortOrder to set.
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	/**
	 * @return Returns the stopSaleFilter.
	 */
	public StopSaleFilter getStopSaleFilter() {
		return stopSaleFilter;
	}
	/**
	 * @param stopSaleFilter The stopSaleFilter to set.
	 */
	public void setStopSaleFilter(StopSaleFilter stopSaleFilter) {
		this.stopSaleFilter = stopSaleFilter;
	}
	/**
	 * @return Returns the xmlIn.
	 */
	public InputStream getXmlIn() {
		return xmlIn;
	}
	/**
	 * @param xmlIn The xmlIn to set.
	 */
	public void setXmlIn(InputStream xmlIn) {
		this.xmlIn = xmlIn;
	}
}