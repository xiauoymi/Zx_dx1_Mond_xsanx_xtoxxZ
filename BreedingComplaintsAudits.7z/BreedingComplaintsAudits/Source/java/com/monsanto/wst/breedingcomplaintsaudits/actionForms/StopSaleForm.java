//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import org.apache.struts.validator.ValidatorActionForm;

import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleObject;

/** 
 * MyEclipse Struts
 * Creation date: 05-04-2005
 * 
 * XDoclet definition:
 * @struts:form name="stopSaleForm"
 */
public class StopSaleForm extends ValidatorActionForm {
	
	//**Variables...
	private StopSaleObject stopSale = new StopSaleObject();
	
	
	
	//**Accessor and Mutators...
	/**
	 * @return Returns the stopSale.
	 */
	public StopSaleObject getStopSale() {
		return stopSale;
	}
	/**
	 * @param stopSale The stopSale to set.
	 */
	public void setStopSale(StopSaleObject stopSale) {
		this.stopSale = stopSale;
	}
}