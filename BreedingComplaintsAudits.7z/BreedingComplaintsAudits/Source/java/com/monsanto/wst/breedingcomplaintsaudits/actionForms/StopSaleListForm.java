//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actionForms;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.struts.validator.ValidatorActionForm;

import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleListObject;

/** 
 * MyEclipse Struts
 * Creation date: 05-17-2005
 * 
 * XDoclet definition:
 * @struts:form name="stopSaleListForm"
 */
public class StopSaleListForm extends ValidatorActionForm {

	private StopSaleListObject stopSaleFilter = new StopSaleListObject();
	
	private LinkedHashMap stopSaleMap = new LinkedHashMap();
	
	private boolean stopSaleMapEmpty;
	
	
	/**
	 * @return Returns the stopSaleFilter.
	 */
	public StopSaleListObject getStopSaleFilter() {
		return stopSaleFilter;
	}
	/**
	 * @param stopSaleFilter The stopSaleFilter to set.
	 */
	public void setStopSaleFilter(StopSaleListObject stopSaleFilter) {
		this.stopSaleFilter = stopSaleFilter;
	}
	/**
	 * @return Returns the stopSaleMap.
	 */
	public LinkedHashMap getStopSaleMap() {
		return stopSaleMap;
	}
	/**
	 * @param stopSaleMap The stopSaleMap to set.
	 */
	public void setStopSaleMap(LinkedHashMap stopSaleMap) {
		this.stopSaleMap = stopSaleMap;
	}
	public void setStopSaleMap(HashMap stopSaleMap) {
		this.stopSaleMap =  new LinkedHashMap(stopSaleMap);
	}
	/**
	 * @return Returns the stopSaleMapEmpty.
	 */
	public boolean isStopSaleMapEmpty() {
		return stopSaleMapEmpty;
	}
	/**
	 * @param stopSaleMapEmpty The stopSaleMapEmpty to set.
	 */
	public void setStopSaleMapEmpty(boolean stopSaleMapEmpty) {
		this.stopSaleMapEmpty = stopSaleMapEmpty;
	}
}