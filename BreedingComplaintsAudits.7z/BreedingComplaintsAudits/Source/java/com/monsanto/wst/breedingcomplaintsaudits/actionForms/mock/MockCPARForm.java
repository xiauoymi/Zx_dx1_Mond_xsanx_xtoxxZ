/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actionForms.mock;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.CparForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;

/**
 * Filename:    $RCSfile: MockCPARForm.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-17 02:15:53 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockCPARForm extends CparForm {

  private Cpar cpar;

  public MockCPARForm(Cpar cpar) {
    this.cpar = cpar;
  }

  public Cpar getCpar() {
    return cpar;
  }
}