/*
 * Created on Jan 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ActionHelper {
	private static Map statesList = null;
	private static Map salesyearList = null;
	private static Map locationList = null;
	private static Map statusList = null;
	private static Map cropList = null;
	private static Map qualityissueList = null;
	private static Map uomList = null;
	private static Map seedsizeList = null;
	private static Map brandList = null;
	private static Map regionList = null;
	private static Map varityList = null;
	public static Map generatorList = null;
	public static Map evaluatorList = null;
	public static Map findingTypeList = null;
	public static Map isoStandardList = null;
    public static Map evaluationEffectiveList = null;
	public static Map continualImprovementsList = null;
	public static Map responsibleLocationList = null;
	public static String ADMIN_EMAIL=null;
	public static String AFFINA_EMAIL=null;	
	public static String STATE_LIST = "statesList";
	public static String SALES_YEAR_LIST = "salesyearList";
	public static String LOCATION_LIST = "locationList";
	public static String RESPONSIBLE_LOCATION_LIST = "responsibleLocationList";
	public static String STATUS_LIST = "statusList";
	public static String CROP_LIST = "cropList";
	public static String GENERATOR_LIST = "generatorList";
	public static String EVALUATOR_LIST = "evaluatorList";
	public static String FINDING_TYPE_LIST = "findingTypeList";
	public static String ISO_STANDARD_LIST = "isoStandardList";
	public static String QUALITY_ISSUE_LIST = "qualityissueList";
	public static String EMAIL_TYPE_COMPLAINT_NEW = "New Complaint:";
	public static String EMAIL_TYPE_COMPLAINT_STATUS_CHANGED = "Complaint Closed:";
  public static String EMAIL_TYPE_FEEDBACK_CHANGED = "Feedback Changed:";
  public static String EMAIL_TYPE_AUDIT_CHANGED = "Audit Changed:";
  public static String EMAIL_TYPE_AUDIT_NEW = "New Audit:";
  public static String EMAIL_TYPE_CPAR_NEW = "New Car/Par:";
  public static String EMAIL_TYPE_CPAR_STATUS_CHANGED = "Car/Par Status Changed:";
  public static String EMAIL_TYPE_CPAR_CHANGED = "Car/Par Changed:";
  public static String UOM_LIST = "uomList";
	public static String SEED_SIZE_LIST = "seedsizeList";
	public static String BRAND_LIST = "brandList";
	public static String VARIETY_LIST = "varityList";
	public static String REGION_LIST = "regionList";
    public static String EVAL_EFFECTIVE_LIST = "evalEffectiveList";
    public static String CONTINUAL_IMPROVEMENTS_LIST = "continualImprovementsList";
	public static String MSG = "msg";
	public static String ERROR_MSG = "error_msg";
	
	public ActionHelper(){
		
	}

	/**
	 * @return Returns the brandList.
	 */
	public static Map getBrandList() throws Exception {
		if (brandList == null ){
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				brandList = lookupService.getBrands();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return brandList;
	}

	/**
	 * @return Returns the brandList.
	 */
	public static Map getRegionList() throws Exception {
		if (regionList == null ){
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				regionList = lookupService.getRegions();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return regionList;
	}
	/**
	 * @return Returns the Responsible location List.
	 */
	public static Map getResponsibleLocationList() throws Exception {
		if (responsibleLocationList == null ){
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				 responsibleLocationList = lookupService.getResponsibleLocations();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return responsibleLocationList;
	}

	
	/**
	 * @return Returns the cropList.
	 */
	public static Map getCropList() throws Exception {
		if (cropList == null ){
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				cropList = lookupService.getCrops();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return cropList;
	}
	/**
	 * @return Returns the locationList.
	 */
	public static Map getLocationList() throws Exception {
		if (locationList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				locationList = lookupService.getLocations();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return locationList;
	}
	/**
	 * @return Returns the qualityissueList.
	 */
	public static Map getQualityissueList() throws Exception{
		if (qualityissueList == null) {
            try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				qualityissueList = lookupService.getQualityIssues();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}

		}		
		return qualityissueList;
	}


    /**
       * @return Returns the evaluationEffectiveList.
       */
      public static Map getEvalEffectiveList() throws Exception {
               if (evaluationEffectiveList == null ){

          try
          {
              evaluationEffectiveList = new LinkedHashMap();
              evaluationEffectiveList.put("","Select");
              evaluationEffectiveList.put("1","Yes");
              evaluationEffectiveList.put("0","No");

          }
          catch(Exception e)
          {
           throw new Exception(e.getMessage());
          }

       }
          return evaluationEffectiveList;
      }

    /**
       * @return Returns the continualImprovementsList.
       */
      public static Map getContinualImprovementsList() throws Exception {
               if (continualImprovementsList == null ){

          try
          {
              continualImprovementsList = new LinkedHashMap();
              continualImprovementsList.put("","Select C.I.");
              continualImprovementsList.put("2","Yes");
              continualImprovementsList.put("1","No");

          }
          catch(Exception e)
          {
           throw new Exception(e.getMessage());
          }

       }
          return continualImprovementsList;
      }


    	/**
	 * @return Returns the salesyearList.
	 */
	public static Map getSalesyearList() throws Exception {
		if (salesyearList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				salesyearList = lookupService.getYear();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return salesyearList;
	}
	/**
	 * @return Returns the seedsizeList.
	 */
	public static Map getSeedsizeList() throws Exception {
		if (seedsizeList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				seedsizeList = lookupService.getSeedSize();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return seedsizeList;
	}
	/**
	 * @return Returns the statesList.
	 */
	public static Map getStatesList() throws Exception {
		if (statesList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				statesList = lookupService.getStates();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}
		return statesList;
	}
	/**
	 * @return Returns the statusList.
	 */
	public synchronized static Map getStatusList(String type) throws Exception {
		Map statusListNew;
		try {
			LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
			statusListNew = lookupService.getStatus(type);
		}
		catch (ServiceException se){
			throw new Exception(se.getMessage());
		}		
		if (statusList == null) {
			statusList = statusListNew;
		}
		else {
			if (!statusList.keySet().equals(statusListNew.keySet())) {
				statusList = statusListNew;
			}				
		}
		return statusList;
	}
	/**
	 * @return Returns the uomList.
	 */
	public static Map getUomList() throws Exception {
		if (uomList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				uomList = lookupService.getUOM();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return uomList;
	}
	/**
	 * @return Returns the varityList.
	 */
	public static Map getVarityList() throws Exception {
		if (varityList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				varityList = lookupService.getVarities();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return varityList;
	}
	
	/**
	 * @return Returns the varityList.
	 */
	public static Map getGeneratorList() throws Exception {
		if (generatorList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				generatorList = lookupService.getGenerator();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return generatorList;
	}

	/**
	 * @return Returns the varityList.
	 */
	public static Map getEvaluatorList() throws Exception {
		if (evaluatorList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				evaluatorList = lookupService.getEffectivenessEvaluator();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return evaluatorList;
	}
	
	/**
	 * @return Returns the varityList.
	 */
	public static Map getFindingTypeList() throws Exception {
		if (findingTypeList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				findingTypeList = lookupService.getFindingTypes();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return findingTypeList;
	}
	
	/**
	 * @return Returns the isoStandardList.
	 */
	public static Map getIsoStandardList() throws Exception {
		if (isoStandardList == null) {
			try {
				LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
				isoStandardList = lookupService.getISOStandards();
			}
			catch (ServiceException se){
				throw new Exception(se.getMessage());
			}
		}		
		return isoStandardList;
	}
	
	public static synchronized void reloadAllData() throws Exception{
		try {
			LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
			salesyearList = lookupService.getYear();	
			statesList = lookupService.getStates();
			locationList = lookupService.getLocations();
			responsibleLocationList = lookupService.getResponsibleLocations();
            qualityissueList = lookupService.getQualityIssues();
            evaluationEffectiveList = ActionHelper.getEvalEffectiveList() ;
            continualImprovementsList = ActionHelper.getContinualImprovementsList();
			cropList = lookupService.getCrops();
			uomList = lookupService.getUOM();
			seedsizeList = lookupService.getSeedSize();
			regionList = lookupService.getRegions();
			varityList = lookupService.getVarities();
			ADMIN_EMAIL = ((String[])lookupService.getEmail("ADMN"))[0];
			AFFINA_EMAIL = ((String[])lookupService.getEmail("AFFN"))[0];
		}
		catch (ServiceException se){
			throw new Exception(se.getMessage());
		}		
	}
}
