//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl
package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.AuditForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.*;
import com.monsanto.wst.breedingcomplaintsaudits.service.AuditService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.Util.StringUtils;
import org.apache.log4j.Category;
import org.apache.struts.action.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * MyEclipse Struts
 * || Om Ganeshay Namah: ||
 * Creation date: 04-07-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:action path="/audit" name="auditForm" scope="request" validate="true"
 */
public class AuditAction extends Action {
  //**Log4j logger
  static Category logger = Category.getInstance(AuditAction.class.getName());

  //private String prevOperation = "none";

  // --------------------------------------------------------- Methods

  /**
   * Method execute
   *
   * @param mapping
   * @param form
   * @param request
   * @param response
   * @return ActionForward
   */
  public ActionForward execute(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    AuditForm auditForm = (AuditForm) form;
    //**FindingMap: Car (Empty/Not)
    if (auditForm.getAuditObj().getFindingCarMap().size() > 0) {
      auditForm.getAuditObj().setFindingCarMapEmpty(false);
    } else {
      auditForm.getAuditObj().setFindingCarMapEmpty(true);
    }

    //**FindingMap: Par (Empty/Not)
    if (auditForm.getAuditObj().getFindingParMap().size() > 0) {
      auditForm.getAuditObj().setFindingParMapEmpty(false);
    } else {
      auditForm.getAuditObj().setFindingParMapEmpty(true);
    }
    logger.info("SelectedTab: " + request.getParameter("currentTab"));
    if (request.getParameter("currentTab") != null && !request.getParameter("currentTab").equals("none")) {
      request.getSession().setAttribute("sessionCurrentTab", request.getParameter("currentTab"));
    }

    //**Testing...
//		FindingObject findingObj = new FindingObject();
//		findingObj.setCarID("C-1000-05-1");
//		findingObj.setParID("P-2000-06-2");
//		findingObj.setFindingDesc("Finding Desc #1: " +
//				"This is the desc of finding #1, whose car number is C-1000-05-1 and " +
//				"whose par no is P-2000-06-2. This is testing done to see whether the " +
//				"short desc works fine. -Rasesh");
//		findingObj.setFindingID("333");
//		
//		HashMap findingObjMap = new HashMap();
//		findingObjMap.put("333", findingObj);
//		
//		auditForm.getAuditObj().setFindingObjMap(findingObjMap);

    //**End Testing...succesful !!!

    //**Initial Settings.. record-saved Msg to false, prevOptn = none...
    auditForm.setRecordSavedMsg(false);

    //*****Include this only in this main action...
    setLocationList(request);
    setRegionList(request);
    setResponsibleLocationList(request);
    //**Check for action clicked..
    String action = getActionType(request.getParameterMap());
    logger.info("Action: " + action);
    auditForm.setDisplayTab("none");

    //**Display-Tab
    if ((action.equalsIgnoreCase("Add New Finding") || action.equalsIgnoreCase("View/Edit")
            || action.equalsIgnoreCase("Create Car") || action.equalsIgnoreCase("Save")) &&
            request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
      auditForm.setDisplayTab("major");
    }
    if ((action.equalsIgnoreCase("Add New Finding") || action.equalsIgnoreCase("View/Edit")
            || action.equalsIgnoreCase("Create Par") || action.equalsIgnoreCase("Save")) &&
            request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
      auditForm.setDisplayTab("observation");
    }

    //**Create Car action...
    if (action.equalsIgnoreCase("Create Car")) {

      //**Settings...
      auditForm.setDisplayTab("major");

      //**Call the action...
      String auditFindingID = getActionKey(request.getParameterMap());
      FindingObject findingObj = (FindingObject) auditForm.getAuditObj().getFindingCarMap().get(auditFindingID);
      if (findingObj.getCparID() != null && !findingObj.getCparID().equals("")) {
        request.setAttribute("duplicateCarMsg", "Duplicate CAR. CAR for this record already exists. To view this CAR ");
        request.setAttribute("cparId", findingObj.getCparID());
        return mapping.findForward("faliure");
      } else {
        request.setAttribute("iscar", "true");
        return createCPARAction(auditFindingID, mapping, form, request, response);
      }
    }

    //**Create Par action...
    if (action.equalsIgnoreCase("Create Par")) {

      //**Settings...
      auditForm.setDisplayTab("observation");

      //**Call the action...
      String auditFindingID = getActionKey(request.getParameterMap());
      FindingObject findingObj = (FindingObject) auditForm.getAuditObj().getFindingParMap().get(auditFindingID);
      if (findingObj.getCparID() != null && !findingObj.getCparID().equals("")) {
        request.setAttribute("duplicateParMsg", "Duplicate PAR. PAR for this record already exists. To view this PAR ");
        request.setAttribute("cparId", findingObj.getCparID());
        return mapping.findForward("faliure");
      } else {
        request.setAttribute("iscar", "false");
        return createCPARAction(auditFindingID, mapping, form, request, response);
      }
    }

    //**View action...
    //**To get into this method: Link: "audit.do?audit_finding_id=View"
    //**Modify this link so that it is: "audit.do?audit_id=View"
    if (action.equalsIgnoreCase("View")) {
      AuditObject auditViewObj = new AuditObject();

      //**print the audit_no...
      String findingID = getActionKey(request.getParameterMap());
      logger.info("Finding ID (for View Request):: " + findingID);

      //****Mainly pull all the data for given "audit_id" and populate it to the auditForm...
      //****This method will also be called from audit_filter_page...(use modified link)
      try {
        AuditService as = getAuditService();
        auditViewObj = as.getAudit(findingID);
      }
      catch (Exception e) {
        logger.error("Error getting getAudit Service.");
      }

      //**Set it into the Form Bean...
      auditForm.setAuditObj(auditViewObj);

      //**Settings...

      //**FindingMap: Car (Empty/Not)
      if (auditForm.getAuditObj().getFindingCarMap().size() > 0) {
        auditForm.getAuditObj().setFindingCarMapEmpty(false);
      } else {
        auditForm.getAuditObj().setFindingCarMapEmpty(true);
      }

      //**FindingMap: Par (Empty/Not)
      if (auditForm.getAuditObj().getFindingParMap().size() > 0) {
        auditForm.getAuditObj().setFindingParMapEmpty(false);
      } else {
        auditForm.getAuditObj().setFindingParMapEmpty(true);
      }
      auditForm.setDisplayCarTable2(false);
      auditForm.setDisplayParTable2(false);
    }

    //**To get into this method: Link: "audit.do?audit_number=ViewFromList"
    if (action.equalsIgnoreCase("ViewFromList")) {
      AuditObject auditViewObj = new AuditObject();

      //**print the audit_no...
      String auditNo = getActionKey(request.getParameterMap());
      logger.info("AuditNo (for View Request):: " + auditNo);

      //****Mainly pull all the data for given "audit_id" and populate it to the auditForm...
      //****This method will also be called from audit_filter_page...(use modified link)
      try {
        AuditService as = getAuditService();
        auditViewObj = as.getAuditFromList(auditNo);
      }
      catch (Exception e) {
        logger.error("Error getting getAuditFromList Service.");
      }

      //**Set it into the Form Bean...
      auditForm.setAuditObj(auditViewObj);

      //**Settings...

      //**FindingMap: Car (Empty/Not)
      if (auditForm.getAuditObj().getFindingCarMap().size() > 0) {
        auditForm.getAuditObj().setFindingCarMapEmpty(false);
      } else {
        auditForm.getAuditObj().setFindingCarMapEmpty(true);
      }

      //**FindingMap: Par (Empty/Not)
      if (auditForm.getAuditObj().getFindingParMap().size() > 0) {
        auditForm.getAuditObj().setFindingParMapEmpty(false);
      } else {
        auditForm.getAuditObj().setFindingParMapEmpty(true);
      }
      auditForm.setDisplayCarTable2(false);
      auditForm.setDisplayParTable2(false);
      request.getSession().setAttribute("originalAudit", auditViewObj.clone());
    }

    //**Cancel action...
    if (action.equalsIgnoreCase("Cancel")) {
      auditForm.setDisplayCarTable2(false);
      auditForm.setDisplayParTable2(false);
      if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
        auditForm.setDisplayTab("major");
      }
      if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
        auditForm.setDisplayTab("observation");
      }
    }
    if (action.equalsIgnoreCase("Save") && request.getSession().getAttribute("prevAction").equals("add")) {
      String findingID = getActionKey(request.getParameterMap());
      logger.info("Save-Add: " + findingID);

      //**Save the Finding-audit into the database...
      ActionForward insertFindingForward = insertFinding(mapping, form, request, response);
      ActionForward successFwd = mapping.findForward("success");
      if (insertFindingForward.equals(successFwd)) {
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
      }
      return insertFindingForward;
    }
    if (action.equalsIgnoreCase("Save") && request.getSession().getAttribute("prevAction").equals("edit")) {
      String findingID = getActionKey(request.getParameterMap());
      logger.info("Save-Edit: " + findingID);

      //**Save the Finding-audit into the database...
      ActionForward updateFindingForward = updateFinding(mapping, form, request, response);
      ActionForward successFwd = mapping.findForward("success");
      if (updateFindingForward.equals(successFwd)) {
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
      } else {
        String descBuffer = request.getSession().getAttribute("descBuffer").toString();
        if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
          ((FindingObject) auditForm.getAuditObj().getFindingCarMap().get(findingID)).setFindingDesc(descBuffer);
          //auditForm.getAuditObj().getEditFindingObj().setFindingDesc("");
        } else {
          ((FindingObject) auditForm.getAuditObj().getFindingParMap().get(findingID)).setFindingDesc(descBuffer);
          //auditForm.getAuditObj().getEditFindingObj().setFindingDesc("");
        }
      }
      return updateFindingForward;
    }

    //**Car
    if (action.equalsIgnoreCase("View/Edit") &&
            request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
      request.getSession().setAttribute("prevAction", "edit");

//			String findingID = getActionKey(request.getParameterMap());
//			logger.info("FindingID = " + findingID);

      //**Step1: Call Save/Update() action...
      ActionForward faliureFwd = mapping.findForward("faliure");

      //**Submit needs to be done first...
      if (auditForm.getAuditObj().getAuditNumber() == null ||
              auditForm.getAuditObj().getAuditNumber().equals("")) {
        System.out.println("\n\n\n\n\n\n\nTest Factory");
        System.out.println("1");
        System.out.println("End\n\n\n\n\n\n");
        ActionForward submitForward = saveAndSubmit(mapping, form, request, response);
        if (submitForward.equals(faliureFwd)) {
          return submitForward;
        }
      }
      //**Update needs to be done first...
      else {
        ActionForward updateForward = updateAction(mapping, form, request, response);
        if (updateForward.equals(faliureFwd)) {
          return updateForward;
        }
      }

      //**Set the editFindingObj...
      String findingID = getActionKey(request.getParameterMap());

      //**Incase blank desc saved...
      String descBuffer = ((FindingObject) auditForm.getAuditObj().getFindingCarMap().get(findingID)).getFindingDesc();
      if (descBuffer != null && !descBuffer.equals("")) {
        request.getSession().setAttribute("descBuffer", descBuffer);
      }
      FindingObject editObj = new FindingObject();
      editObj = (FindingObject) auditForm.getAuditObj().getFindingCarMap().get(findingID);
      auditForm.getAuditObj().setEditFindingObj(editObj);

      //**Show table2..depending on car/par...
      if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
        auditForm.setDisplayCarTable2(true);
        auditForm.setDisplayParTable2(false);
      }
    }

    //**Par
    if (action.equalsIgnoreCase("View/Edit") &&
            request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
      request.getSession().setAttribute("prevAction", "edit");

//			String findingID = getActionKey(request.getParameterMap());
//			logger.info("FindingID = " + findingID);

      //**Step1: Call Save/Update() action...
      ActionForward faliureFwd = mapping.findForward("faliure");

      //**Submit needs to be done first...
      if (auditForm.getAuditObj().getAuditNumber() == null ||
              auditForm.getAuditObj().getAuditNumber().equals("")) {
        System.out.println("\n\n\n\n\n\n\nTest Factory");
        System.out.println("2");
        System.out.println("End\n\n\n\n\n\n");
        ActionForward submitForward = saveAndSubmit(mapping, form, request, response);
        if (submitForward.equals(faliureFwd)) {
          return submitForward;
        }
      }
      //**Update needs to be done first...
      else {
        ActionForward updateForward = updateAction(mapping, form, request, response);
        if (updateForward.equals(faliureFwd)) {
          return updateForward;
        }
      }

      //**Set the editFindingObj...
      String findingID = getActionKey(request.getParameterMap());

      //**Incase blank desc saved...
      String descBuffer = ((FindingObject) auditForm.getAuditObj().getFindingParMap().get(findingID)).getFindingDesc();
      if (descBuffer != null && !descBuffer.equals("")) {
        request.getSession().setAttribute("descBuffer", descBuffer);
      }
      FindingObject editObj = new FindingObject();
      editObj = (FindingObject) auditForm.getAuditObj().getFindingParMap().get(findingID);
      auditForm.getAuditObj().setEditFindingObj(editObj);

      //**Show table2..depending on car/par...
      if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
        auditForm.setDisplayParTable2(true);
        auditForm.setDisplayCarTable2(false);
      }
    }

    //**Save&Update -> submit action();
    if (action.equalsIgnoreCase("Save & Update") &&
            auditForm.getAuditObj() != null &&
            (auditForm.getAuditObj().getAuditNumber() == null ||
                    auditForm.getAuditObj().getAuditNumber().equals(""))) {

      //**Call Save & Update() action...
      System.out.println("\n\n\n\n\n\n\nTest Factory");
      System.out.println("3");
      System.out.println("End\n\n\n\n\n\n");
      ActionForward submitForward = saveAndSubmit(mapping, form, request, response);
      return submitForward;
    }//End of Save & Update action.

    //**Add New Finding action(); Car/Par
    if (action.equalsIgnoreCase("Add New Finding")) {
      request.getSession().setAttribute("prevAction", "add");

      //logger.info("SelectedTab: " + auditForm.getAuditObj().getCurrentTab());

      //**Step1: Call Save/Update() action...
      ActionForward faliureFwd = mapping.findForward("faliure");

      //**Submit needs to be done first...
      if (auditForm.getAuditObj().getAuditNumber() == null ||
              auditForm.getAuditObj().getAuditNumber().equals("")) {
        System.out.println("\n\n\n\n\n\n\nTest Factory");
        System.out.println("4");
        System.out.println("End\n\n\n\n\n\n");
        ActionForward submitForward = saveAndSubmit(mapping, form, request, response);
        if (submitForward.equals(faliureFwd)) {
          return submitForward;
        }
      }
      //**Update needs to be done first...
      else {
        ActionForward updateForward = updateAction(mapping, form, request, response);
        if (updateForward.equals(faliureFwd)) {
          return updateForward;
        }
      }

      //**Create new-reseted editFindingObj...
      FindingObject newEditObj = new FindingObject();
      newEditObj.setCparID("");
      newEditObj.setControlNumber("");
      newEditObj.setFindingDesc("");
      newEditObj.setFindingID("-1");
      auditForm.getAuditObj().setEditFindingObj(newEditObj);

      //**Imp task: reset in all other clicks...not reqd...(cause its default "false" in the FormBean)
      if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
        auditForm.setDisplayCarTable2(true);
        auditForm.setDisplayParTable2(false);
      }
      if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
        auditForm.setDisplayParTable2(true);
        auditForm.setDisplayCarTable2(false);
      }
    }//End of Add New Finding action.

    //**Update -> update action();
    if (action.equalsIgnoreCase("Save & Update") &&
            auditForm.getAuditObj() != null &&
            auditForm.getAuditObj().getAuditNumber() != null &&
            !auditForm.getAuditObj().getAuditNumber().equals("")) {

      //**Call Update() action...
      ActionForward updateForward = updateAction(mapping, form, request, response);
      return updateForward;
    }//End of Update action.

    //**Save&Update -> submit action();
    if (action.equalsIgnoreCase("Reset")) {
      if (auditForm.getAuditObj() != null) {
        AuditObject audit = new AuditObject();
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
        auditForm.setAuditObj(audit);

        //reset(audit);
      }
    }//End of Reset action.
    return mapping.findForward("success");
  }

  //**CreateCar Action()...
  public ActionForward createCPARAction(
          String auditFindingID,
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    AuditForm auditForm = (AuditForm) form;
    AuditObject auditObj = auditForm.getAuditObj();

    //**Mainly put all the copy details into request/session...
    //**Call CparNew() action
    Cpar cparFindingObj = new Cpar();
    cparFindingObj.setRegion(auditObj.getRegion_id());
    cparFindingObj.setFiling_location(auditObj.getLocationCode());
    cparFindingObj.setResponsible_location(auditObj.getLocationCode());
    cparFindingObj.setReport_date(auditObj.getAuditDate());
    if (request.getAttribute("iscar").equals("true")) {
      cparFindingObj.setInvestigation_findings
              (((FindingObject) auditObj.getFindingCarMap().get(auditFindingID)).getFindingDesc());
    } else {
      cparFindingObj.setInvestigation_findings
              (((FindingObject) auditObj.getFindingParMap().get(auditFindingID)).getFindingDesc());
    }
    cparFindingObj.setInitiated_by(auditObj.getAuditor());
    cparFindingObj.setAudit_number(auditObj.getAuditNumber());
    cparFindingObj.setAudit_finding_id(auditFindingID);
    cparFindingObj.setAudit_id(auditObj.getAuditID());
    cparFindingObj.setGenerator("7");
    request.setAttribute("cparFindingObj", cparFindingObj);
    request.setAttribute("createCAR", "true");
    request.setAttribute("Generator", "Audit");
    return mapping.findForward("successCpar");
  }

  //**Update Action()...
  public ActionForward updateAction(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    AuditObject originalAudit = (AuditObject) request.getSession().getAttribute("originalAudit");
    logger.info("update...");
    AuditForm auditForm = (AuditForm) form;
    AuditObject auditObj = auditForm.getAuditObj();
      
    resetAuditAreaSelections(auditObj, request);      //**Checkbox-error fix..deselect problem fixed...
    if (auditForm.getAuditObj() != null) {
      //**Imp Step1: Validations during main submit...
      if (!doSubmitValidation(auditObj, request)) {
        return mapping.findForward("faliure");
      }
    }
    //**UpdateAudit()..............................................
    try {
      AuditService as = getAuditService();
      //**Imp Step2: Set the row-user-id...
      User user = (User) request.getSession().getAttribute("user");
      auditObj.setRowUserID(user.getUser_id());
      as.updateAudit(auditObj);
      //**Some Form settings...
      auditForm.setRecordSavedMsg(true);
      if (!auditObj.equals(originalAudit)) {
        sendAuditChangeEmail(auditObj, request);
      }
      request.getSession().setAttribute("originalAudit", auditObj.clone());
    }
    catch (Exception e) {
      logger.error("Error updating Audit.", e);
      return mapping.findForward("faliure");
    }
    //**************************************************************
    return mapping.findForward("success");
  }

  protected AuditService getAuditService() throws ServiceException {
    return (AuditService) ServiceLocator.locateService(AuditService.class);
  }

  //**Insert Finding()...
  public ActionForward insertFinding(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    AuditForm auditForm = (AuditForm) form;
    AuditObject auditObj = auditForm.getAuditObj();
    ActionErrors errors = new ActionErrors();
    if (auditObj.getEditFindingObj().getFindingDesc() == null || auditObj.getEditFindingObj().getFindingDesc().equals("")) {
      errors.add("findingDescEmpty", new ActionError("errors.mcas.audit.FindingDesc.empty"));
    }

/*
			if(auditObj.getEditFindingObj().getFindingDesc() != null && auditObj.getEditFindingObj().getFindingDesc().length() > 4000){
				errors.add("findingDescTooLarge", new ActionError("errors.mcas.audit.FindingDesc.tooLarge"));
			}
*/
    if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
      auditForm.setDisplayTab("major");
      auditForm.setDisplayCarTable2(true);
      auditForm.setDisplayParTable2(false);
    }
    if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
      auditForm.setDisplayTab("observation");
      auditForm.setDisplayParTable2(true);
      auditForm.setDisplayCarTable2(false);
    }

    //**Errors present and return faliure forward...
    if (!errors.isEmpty()) {
      saveErrors(request, errors);
      return mapping.findForward("faliure");
    }
    try {
      AuditService as = getAuditService();

      //**Imp Step2: Set the row-user-id...
      User user = (User) request.getSession().getAttribute("user");
      auditObj.getEditFindingObj().setRowUserID(user.getUser_id());

      //**For Car
      if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
        auditObj.getEditFindingObj().setCar_flag("Y");
        FindingObject resultObj = as.insertFinding(auditObj.getAuditNumber(), auditObj.getEditFindingObj());
        resultObj.setCar_flag("Y");
        auditObj.getFindingCarMap().put(resultObj.getFindingID(), resultObj);
        auditForm.getAuditObj().setFindingCarMapEmpty(false);
      }

      //**For Par
      if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
        auditObj.getEditFindingObj().setCar_flag("N");
        FindingObject resultObj = as.insertFinding(auditObj.getAuditNumber(), auditObj.getEditFindingObj());
        resultObj.setCar_flag("N");
        auditObj.getFindingParMap().put(resultObj.getFindingID(), resultObj);
        auditForm.getAuditObj().setFindingParMapEmpty(false);
      }
      return mapping.findForward("success");

      //**Some Form settings...
      //auditForm.setRecordSavedMsg(true);
    }
    catch (Exception e) {
      logger.error("Error locating Audit Service: ");
      e.printStackTrace();
      return mapping.findForward("faliure");
    }
  }

  //**Update Finding()...
  public ActionForward updateFinding(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    AuditForm auditForm = (AuditForm) form;
    AuditObject auditObj = auditForm.getAuditObj();
    ActionErrors errors = new ActionErrors();
    if (auditObj.getEditFindingObj().getFindingDesc() == null || auditObj.getEditFindingObj().getFindingDesc().equals("")) {
      errors.add("findingDescEmpty", new ActionError("errors.mcas.audit.FindingDesc.empty"));
    }
    if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
      auditForm.setDisplayTab("major");
      auditForm.setDisplayCarTable2(true);
      auditForm.setDisplayParTable2(false);
    }
    if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
      auditForm.setDisplayTab("observation");
      auditForm.setDisplayParTable2(true);
      auditForm.setDisplayCarTable2(false);
    }
    //**Errors present and return faliure forward...
    if (!errors.isEmpty()) {
      saveErrors(request, errors);
      return mapping.findForward("faliure");
    }
    try {
      AuditService as = getAuditService();
      //**Imp Step2: Set the row-user-id...
      User user = (User) request.getSession().getAttribute("user");
      auditObj.getEditFindingObj().setRowUserID(user.getUser_id());
      as.updateFinding(auditObj.getEditFindingObj());
      //**For Car
      if (request.getSession().getAttribute("sessionCurrentTab").equals("major")) {
        auditObj.getFindingCarMap().put(auditObj.getEditFindingObj().getFindingID(), auditObj.getEditFindingObj());
      }
      //**For Par
      if (request.getSession().getAttribute("sessionCurrentTab").equals("observation")) {
        auditObj.getFindingParMap().put(auditObj.getEditFindingObj().getFindingID(), auditObj.getEditFindingObj());
      }
      return mapping.findForward("success");
      //**Some Form settings...
      //auditForm.setRecordSavedMsg(true);
    }
    catch (Exception e) {
      logger.error("Error locating Audit Service: ");
      e.printStackTrace();
      return mapping.findForward("faliure");
    }
  }

  //**Save & Update Action()...
  public ActionForward saveAndSubmit(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    logger.info("submit...");
    AuditForm auditForm = (AuditForm) form;
    AuditObject auditObj = new AuditObject();
    if (auditForm.getAuditObj() != null) {
      auditObj = auditForm.getAuditObj();
      //**Imp Step1: Validations during main submit...
      if (!doSubmitValidation(auditObj, request)) {
        return mapping.findForward("faliure");
      }
    }
    //**InsertAudit()..............................................
    try {
      AuditService as = getAuditService();
      //**Imp Step2: Set the row-user-id...
      User user = (User) request.getSession().getAttribute("user");
      auditObj.setRowUserID(user.getUser_id());
      String autoAuditNumber = "";
      String auditID = "";
      String returnStr = as.insertAudit(auditObj);
      StringTokenizer st = new StringTokenizer(returnStr, ";");
      for (int i = 0; i < 2; i++) {
        if (i == 0) {
          autoAuditNumber = st.nextToken();
        }
        if (i == 1) {
          auditID = st.nextToken();
        }
      }
      //**Set the new auto-generated-audit-number and audit_id...
      auditForm.getAuditObj().setAuditNumber(autoAuditNumber);
      auditForm.getAuditObj().setAuditID(auditID);
      //**Some Form settings...
      auditForm.setRecordSavedMsg(true);
      //prevOperation = "submit";
      sendNewAuditEmail(auditForm.getAuditObj(), request);
      request.getSession().setAttribute("originalAudit", auditForm.getAuditObj().clone());      
    }
    catch (Exception e) {
      logger.error("Error locating Audit Service: ");
      e.printStackTrace();
      return mapping.findForward("faliure");
    }
    return mapping.findForward("success");
    //**************************************************************
  }

  /**
   * Resets the submit-fields (currently).
   *
   * @param audit
   */
//	public void reset(AuditObject audit){
//		audit.setAuditDate("");
//		audit.setAuditNumber("");
//		audit.setAuditor("");
//		audit.setAuditorEmail("");
//		audit.setAuditOverview("");
//		
//		audit.setConditioning(false);
//		audit.setField(false);
//		audit.setHarvest(false);
//		audit.setOffSiteFacilities(false);
//		audit.setPackaging(false);
//		audit.setPlanting(false);
//		audit.setQaLab(false);
//		audit.setWarehouseDistribution(false);
//		
//		audit.setLocationCode("");
//		audit.setPreparedBy("");
//		audit.setPreparedByEmail("");
//		audit.setPreparedDate("");
//		audit.setSiteISOContact("");
//		audit.setSiteISOContactEmail("");
//		
//		audit.setRegion_id("");
//	}

  /**
   * Validations during main submit
   *
   * @param auditObj
   * @param request
   * @return
   */
  public boolean doSubmitValidation(AuditObject auditObj, HttpServletRequest request) {
    ActionErrors errors = new ActionErrors();

    //**Location-Code validation...
    if (auditObj.getLocationCode() == null || auditObj.getLocationCode().equals("")) {
      errors.add("locationCodeEmpty", new ActionError("errors.mcas.audit.locationCode.empty"));
    }

    //**Audit-Date validation...
    if (auditObj.getAuditDate() == null || auditObj.getAuditDate().equals("")) {
      errors.add("auditDateEmpty", new ActionError("errors.mcas.audit.auditDate.empty"));
    } else {
      //**Date Validation...(mm/dd/yyyy)...
      StringTokenizer st = new StringTokenizer(auditObj.getAuditDate(), "/");

      //**Date Format Error Yes/No...
      boolean dateErr = false;
      if (st.countTokens() != 3) {
        dateErr = true;
      } else {
        for (int i = 0; i < 3; i++) {
          if (i == 0) {
            String month = st.nextToken().trim();
            if (month.length() != 2) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(month);
              if (x < 0 || x > 12) {
                dateErr = true;
              }
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
          if (i == 1) {
            String day = st.nextToken().trim();
            if (day.length() != 2) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(day);
              if (x < 0 || x > 31) {
                dateErr = true;
              }
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
          if (i == 2) {
            String year = st.nextToken().trim();
            if (year.length() != 4) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(year);
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
        }
      }
      if (dateErr) {
        errors.add("auditDateFormat", new ActionError("errors.mcas.audit.auditDate.format"));
      }
    }

    //**Audit-Region validation...
    if (auditObj.getRegion_id() == null || auditObj.getRegion_id().equals("")) {
      errors.add("regionIDEmpty", new ActionError("errors.mcas.audit.regionID.empty"));
    }

    //**Auditor validation...
    if (auditObj.getAuditor() == null || auditObj.getAuditor().equals("")) {
      errors.add("auditorEmpty", new ActionError("errors.mcas.audit.auditor.empty"));
    }

    //**Location-Code validation...
/*
		if(auditObj.getAuditOverview() != null && auditObj.getAuditOverview().length() > 4000){
			errors.add("auditOverviewTooLarge", new ActionError("errors.mcas.audit.auditOverview.tooLarge"));
		}
*/

    //**Audit-PreparedBy validation...
    if (auditObj.getPreparedBy() == null || auditObj.getPreparedBy().equals("")) {
      errors.add("preparedByEmpty", new ActionError("errors.mcas.audit.preparedBy.empty"));
    }

    //**Audit-PreparedDate validation...
    if (auditObj.getPreparedDate() == null || auditObj.getPreparedDate().equals("")) {
      errors.add("preparedDateEmpty", new ActionError("errors.mcas.audit.preparedDate.empty"));
    } else {
      //**Date Validation...(mm/dd/yyyy)...
      StringTokenizer st = new StringTokenizer(auditObj.getPreparedDate(), "/");

      //**Date Format Error Yes/No...
      boolean dateErr = false;
      if (st.countTokens() != 3) {
        dateErr = true;
      } else {
        for (int i = 0; i < 3; i++) {
          if (i == 0) {
            String month = st.nextToken().trim();
            if (month.length() != 2) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(month);
              if (x < 0 || x > 12) {
                dateErr = true;
              }
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
          if (i == 1) {
            String day = st.nextToken().trim();
            if (day.length() != 2) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(day);
              if (x < 0 || x > 31) {
                dateErr = true;
              }
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
          if (i == 2) {
            String year = st.nextToken().trim();
            if (year.length() != 4) {
              dateErr = true;
            }
            try {
              int x = Integer.parseInt(year);
            }
            catch (Exception ex) {
              dateErr = true;
            }
          }
        }
      }
      if (dateErr) {
        errors.add("auditPreparedDateFormat", new ActionError("errors.mcas.audit.preparedDate.format"));
      }
    }
    //**Audit-Number validation...
//		if(auditObj.getAuditNumber() == null || auditObj.getAuditNumber().equals("")){				
//			errors.add("auditNumberEmpty", new ActionError("errors.mcas.audit.auditNumber.empty"));				
//		}

    //**Errors present and return faliure forward...
    if (!errors.isEmpty()) {
      saveErrors(request, errors);
      return false;
    }
    return true;
  }

  /**
   * To fill the Location-List in the combo-box
   *
   * @param request
   */
  public void setLocationList(HttpServletRequest request) {

    //**To get the Location-List in the combo-box.......................
    try {
      request.setAttribute("locationList", ActionHelper.getLocationList());
    }
    catch (Exception ex) {
      logger.error("Error getting the Location-List: ");
      ex.printStackTrace();
    }

    //********************************************************************
  }

  public void setResponsibleLocationList(HttpServletRequest request) {

    //**To get the Responsible Location-List in the combo-box.......................
    try {
      request.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST, ActionHelper.getResponsibleLocationList());
    }
    catch (Exception ex) {
      logger.error("Error getting the Location-List: ");
      ex.printStackTrace();
    }

    //********************************************************************
  }

  /**
   * To fill the Region-List in the combo-box
   *
   * @param request
   */
  public void setRegionList(HttpServletRequest request) {

    //**To get the Location-List in the combo-box.......................
    try {
      request.setAttribute("regionList", ActionHelper.getRegionList());
    }
    catch (Exception ex) {
      logger.error("Error getting the Region-List: ");
      ex.printStackTrace();
    }
    //********************************************************************
  }

  /**
   * Gets the action-button clicked...
   *
   * @param parameterMap
   * @return
   */
  public String getActionType(Map parameterMap) {
    String action = null;
    String[] valueArr = null;
    Iterator iter = parameterMap.keySet().iterator();
    for (int i = 0; i < parameterMap.size(); i++) {
    }
    while (iter.hasNext()) {
      Object key = iter.next();
      Object value = parameterMap.get(key);
      valueArr = (String[]) value;
      if (((String) valueArr[0]).equalsIgnoreCase("Reset")) {
        return "Reset";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Save & Update")) {
        return "Save & Update";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Add New Finding")) {
        return "Add New Finding";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("View/Edit")) {
        return "View/Edit";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Save")) {
        return "Save";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Create Car")) {
        return "Create Car";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Create Par")) {
        return "Create Par";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Cancel")) {
        return "Cancel";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("View")) {
        return "View";
      }
      if (((String) valueArr[0]).equalsIgnoreCase("ViewFromList")) {
        return "ViewFromList";
      }
    }
    return "notype";
  }

  /**
   * Gets key for the action-button clicked...
   *
   * @param parameterMap
   * @return
   */
  public String getActionKey(Map parameterMap) {
    String action = null;
    String[] valueArr = null;
    Iterator iter = parameterMap.keySet().iterator();
    for (int i = 0; i < parameterMap.size(); i++) {
    }
    while (iter.hasNext()) {
      Object key = iter.next();
      Object value = parameterMap.get(key);
      valueArr = (String[]) value;
      if (((String) valueArr[0]).equalsIgnoreCase("Reset")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Save & Update")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Add New Finding")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("View/Edit")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Save")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Create Par")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Create Car")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("Cancel")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("View")) {
        return (String) key;
      }
      if (((String) valueArr[0]).equalsIgnoreCase("ViewFromList")) {
        return (String) key;
      }
    }
    return "notype";
  }

  private void getAuditFormDefaults(HttpServletRequest request) throws Exception {
    HttpSession session = request.getSession();
    session.setAttribute(ActionHelper.STATUS_LIST, null);
    if (session.getAttribute(ActionHelper.LOCATION_LIST) == null)
      session.setAttribute(ActionHelper.LOCATION_LIST, ActionHelper.getLocationList());
    if (session.getAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST) == null)
      session.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST, ActionHelper.getResponsibleLocationList());
  }

  private void resetAuditAreaSelections(AuditObject auditObj, HttpServletRequest request) {
    if (request.getParameterMap().get("auditObj.qaLab") != null) {
      auditObj.setQaLab(true);
    } else {
      auditObj.setQaLab(false);
    }
    if (request.getParameterMap().get("auditObj.conditioning") != null) {
      auditObj.setConditioning(true);
    } else {
      auditObj.setConditioning(false);
    }
    if (request.getParameterMap().get("auditObj.field") != null) {
      auditObj.setField(true);
    } else {
      auditObj.setField(false);
    }
    if (request.getParameterMap().get("auditObj.harvest") != null) {
      auditObj.setHarvest(true);
    } else {
      auditObj.setHarvest(false);
    }
    if (request.getParameterMap().get("auditObj.packaging") != null) {
      auditObj.setPackaging(true);
    } else {
      auditObj.setPackaging(false);
    }
    if (request.getParameterMap().get("auditObj.planting") != null) {
      auditObj.setPlanting(true);
    } else {
      auditObj.setPlanting(false);
    }
    if (request.getParameterMap().get("auditObj.warehouseDistribution") != null) {
      auditObj.setWarehouseDistribution(true);
    } else {
      auditObj.setWarehouseDistribution(false);
    }
    if (request.getParameterMap().get("auditObj.offSiteFacilities") != null) {
      auditObj.setOffSiteFacilities(true);
    } else {
      auditObj.setOffSiteFacilities(false);
    }
  }

  protected EmailUtil getEmailUtil() {
    return new EmailUtil();
  }

  protected LookUpService getLookupService() throws ServiceException {
    return (LookUpService) ServiceLocator.locateService(LookUpService.class);
  }

  private boolean sendAuditChangeEmail(AuditObject audit, HttpServletRequest request) throws Exception {
    try {
      EmailUtil emailUtil = getEmailUtil();
      if (!StringUtils.isNullOrEmpty(ActionHelper.ADMIN_EMAIL)
              && !StringUtils.isNullOrEmpty(getResponsibleLocationEmail(audit))) {
        emailUtil.setTo(getResponsibleLocationEmail(audit));
        emailUtil.setFrom(ActionHelper.ADMIN_EMAIL);
        emailUtil.setSubject(ActionHelper.EMAIL_TYPE_AUDIT_CHANGED + " '" + getAuditNumber(audit) + "' - " + getAppName());
        emailUtil.setBody("The Audit '" + getAuditNumber(audit) + "' has been modified. Click here to logon to the SBFAS system: " + getContactURL(request) +
                "\n\n\n\n\n" + getEmailFooter());
        return emailUtil.sendMail();
      }
      return false;
    }
    catch (Exception e) {
      throw new Exception(e);
    }
  }

  private boolean sendNewAuditEmail(AuditObject audit, HttpServletRequest request) throws Exception {
    try {
      EmailUtil emailUtil = getEmailUtil();
      if (!StringUtils.isNullOrEmpty(ActionHelper.ADMIN_EMAIL)
              && !StringUtils.isNullOrEmpty(getResponsibleLocationEmail(audit))) {
        emailUtil.setTo(getResponsibleLocationEmail(audit));
        emailUtil.setFrom(ActionHelper.ADMIN_EMAIL);
        emailUtil.setSubject(ActionHelper.EMAIL_TYPE_AUDIT_NEW + " '" + getAuditNumber(audit) + "' - " + getAppName());
        emailUtil.setBody("A new Audit '" + getAuditNumber(audit) + "' has been entered into the SBAF system. Click here to logon to the SBFAS system: " + getContactURL(request) +
                "\n\n\n\n\n" + getEmailFooter());
        return emailUtil.sendMail();
      }
      return false;
    }
    catch (Exception e) {
      throw new Exception(e);
    }
  }

  private String getContactURL(HttpServletRequest request) {
    return (request.getRequestURL().toString().split(request.getContextPath()))[0] + request.getContextPath();
  }

  private String getAuditNumber(AuditObject audit) {
    return audit.getAuditNumber();
  }

  private String getEmailFooter() {
    return McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.EmailFooter");
  }

  private String getAppName() {
    return McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.AppName");
  }

  private String getResponsibleLocationEmail(AuditObject audit) throws ServiceException {
    String responsibleLocationEmail = null;
    LookUpService lookupService = getLookupService();
    String locationCode = audit.getLocationCode();
    System.out.println("locationCode = " + locationCode);
    if (!StringUtils.isNullOrEmpty(locationCode)) {
      String[] emails = lookupService.getEmail(locationCode.split("_")[0]);
      if (emails != null && emails.length > 0) {
        System.out.println("emails[0] = " + emails[0]);
        System.out.println("emails[1] = " + emails[1]);
        responsibleLocationEmail = emails[0];
      }
    }
    if (StringUtils.isNullOrEmpty(responsibleLocationEmail)) {
      logger.error("Error sending audit change email: Responsible Location Email is null or empty.");
    }
    return responsibleLocationEmail;
  }
}