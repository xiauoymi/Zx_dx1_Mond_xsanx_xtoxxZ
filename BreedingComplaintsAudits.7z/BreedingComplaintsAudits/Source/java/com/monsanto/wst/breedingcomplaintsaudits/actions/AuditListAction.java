//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actions;


import com.monsanto.wst.breedingcomplaintsaudits.actionForms.AuditListForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.service.AuditService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

/** 
 * MyEclipse Struts
 * Creation date: 04-27-2005
 * 
 * XDoclet definition:
 * @struts:action path="/auditList" name="auditListForm" scope="request"
 */
public class AuditListAction extends DispatchAction {

	static Category logger = Category.getInstance(AuditListAction.class.getName());
	
	private String sortCriteria;
	private String sortOrder;
    private String order;
    private String criteria;

	/**
	 * Method display
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward auditListDisplay(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		AuditListForm auditListForm = (AuditListForm) form;
		
		//*****LocationList Filling...
		setLocationRegionList(request);
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method sort
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward sort(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		AuditListForm auditListForm = (AuditListForm) form;
		
		//*****LocationList Filling...
		setLocationRegionList(request);

		//**Read the request parameters...Sort Order and Criteria.
		getSortValues(request);

         //**Get the HashMap and sort it...
		//sortList(auditListForm.getAuditMap(), sortCriteria, sortOrder);



		return mapping.findForward("success");
	}
	
	public ActionForward auditListReset(
			ActionMapping mapping,
			ActionForm form,
			HttpServletRequest request,
			HttpServletResponse response) {
			AuditListForm auditListForm = (AuditListForm) form;
			
			//*****LocationList Filling...
			setLocationRegionList(request);
			
			auditListForm.setAuditFilterObj(new AuditListObject());
			auditListForm.setAuditMap(new HashMap());
			
			//**Reset sort-order
			resetSortOrder(request);
			
			return mapping.findForward("success");
		}
	
	/** 
	 * Method submit
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward auditListSubmit(
			ActionMapping mapping,
			ActionForm form,
			HttpServletRequest request,
			HttpServletResponse response) {
			AuditListForm af = (AuditListForm) form;

			//**Add selected page to session...

			        String selectedPage = request.getParameter("selectedPage");
                               
            if(request.getParameter("pagination").equals("true"))
            {
                  sortCriteria = request.getParameter("sortCriteria");
                  sortOrder = request.getParameter("sortOrder");
                  request.getSession().setAttribute("lastAuditSortCriteria", sortCriteria);
		          request.getSession().setAttribute("lastAuditSortOrder", sortOrder);
            }
        else
            {
                         getSortValues(request);
            }


			if(selectedPage != null){
				request.getSession().setAttribute("selectedPage", selectedPage);
			}
			else{
				request.getSession().setAttribute("selectedPage", "1");
			}



			//logger.info("selectedPage = " + request.getSession().getAttribute("selectedPage"));

			LinkedHashMap auditList = null;

	    	float pages = 0;
	    	HttpSession session = request.getSession();

	    	int pageNumber;
	    	if (!(request.getParameter("pageNumber").equals(null)) && request.getParameter("reset").equals("false")){

	    		pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
                System.out.println("pageNumber = '" + pageNumber + "'\n");
	    		try {
			    	AuditService as = (AuditService)ServiceLocator.locateService(AuditService.class);
                  	auditList = as.getAuditList(af.getAuditFilterObj() ,request.getParameter("pageNumber"),Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder);

		    	}
	    		catch (Exception e){
	    			logger.info("Error getting 'getAuditList' service...");
	    		}
		    	if (request.getParameter("getMax").equals("true")) {
		    		session.setAttribute("pageNumber","1");
		    	}
		    	else
		    	{
		    		if (pageNumber < 11 && pageNumber > 0)
                    session.setAttribute("pageNumber","1");

		    		else
                    {
		    			session.setAttribute("pageNumber",request.getParameter("pageNumber"));

                    }
		    	}
	    	}


	    	   if ((auditList != null) && !(auditList.equals(null))){
	    		pages = Float.parseFloat(auditList.get("maxRows").toString());
	    		auditList.remove("maxRows");

	    		if (auditList.size() > 0 && pages > 0) {

		    		af.setAuditMap(auditList);


                    session.setAttribute("pages",new Float(pages/10));

		    	}
		    	else
		    		af.setAuditMap(null);
	    	}
	    	else{

	    		af.setAuditMap(null);
	    	}
	    	//**Reset sort-order
		//	resetSortOrder(request);



			return (mapping.findForward("success"));
			
		}
	
	/**
	 * To fill the Location-List in the combo-box
	 * 
	 * @param request
	 */
	public void setLocationRegionList(HttpServletRequest request) {	
		
		//**To get the Location-List and Region-List in the combo-box.......................
		try{
			request.getSession().setAttribute("locationList", ActionHelper.getLocationList());
			request.getSession().setAttribute("regionList", ActionHelper.getRegionList());
			request.getSession().setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST, ActionHelper.getResponsibleLocationList());

		}
		catch(Exception ex){
			logger.error("Error getting the Location-List: ");
			ex.printStackTrace();
		}
		//********************************************************************
	}
	
	/**
	 * To get the sortCriteria and determine the sortOrder.
	 * 
	 * @param request
	 */
	private void getSortValues(HttpServletRequest request){
		sortOrder = "asc";
		sortCriteria = request.getParameter("sortCriteria");

		String lastSortCriteria = request.getSession().getAttribute("lastAuditSortCriteria") + "";
      	if(lastSortCriteria == null){
			sortOrder = "asc";
		}
		else{	// => Not_Null
			if(sortCriteria.equalsIgnoreCase(lastSortCriteria)){
				sortOrder = request.getSession().getAttribute("lastAuditSortOrder") + "";
				if(sortOrder == null){
					sortOrder = "asc";
				}
				else{	// => Not_Null
					if(sortOrder.equalsIgnoreCase("asc")){
						sortOrder = "desc";
					}
					else{
						sortOrder = "asc";
					}
				}
			}
			else{
				sortOrder = "asc";
			}
		}


		request.getSession().setAttribute("lastAuditSortCriteria", sortCriteria);
		request.getSession().setAttribute("lastAuditSortOrder", sortOrder);
				
//		logger.info("Sort Criteria = " + sortCriteria);		
//		logger.info("Sort Order = " + sortOrder);
	}
	
	/**
	 * To reset the sortOrder after every submit or refresh(display).
	 *  
	 * @param request
	 */
	private void resetSortOrder(HttpServletRequest request){
		request.getSession().setAttribute("lastAuditSortOrder", "dec");
	}
	
	private void sortList(LinkedHashMap hash, String sortBy, String sortOrd){
		Vector dataVector = new Vector();
	 	
	 	Iterator it = hash.keySet().iterator();
	 	
	 	while(it.hasNext()){
	 		dataVector.add((AuditListObject)hash.get(it.next()));
	 	}
	 	
	 	hash.clear();
	 	
	 	//**String Tokens
	 	if(sortBy.equalsIgnoreCase("auditNumber") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((AuditListObject)a).getAuditNumber() != null) ?
									((AuditListObject)a).getAuditNumber().trim().split("-") : "".split("-");								
							String bTokens[] = (((AuditListObject)b).getAuditNumber() != null) ?
									((AuditListObject)b).getAuditNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal > bVal){
										return 1;
									}
									if(aVal < bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("auditNumber") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((AuditListObject)a).getAuditNumber() != null) ?
									((AuditListObject)a).getAuditNumber().trim().split("-") : "".split("-");								
							String bTokens[] = (((AuditListObject)b).getAuditNumber() != null) ?
									((AuditListObject)b).getAuditNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal < bVal){
										return 1;
									}
									if(aVal > bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**String
	 	if(sortBy.equalsIgnoreCase("site") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getLocationCode() != null ? 
									((AuditListObject)a).getLocationCode().trim() : "";
							String bToken = ((AuditListObject)b).getLocationCode() != null ? 
									((AuditListObject)b).getLocationCode().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("site") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getLocationCode() != null ? 
									((AuditListObject)a).getLocationCode().trim() : "";
							String bToken = ((AuditListObject)b).getLocationCode() != null ? 
									((AuditListObject)b).getLocationCode().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Date
	 	if(sortBy.equalsIgnoreCase("auditDate") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							long aDate;
							long bDate;
							
							try{
								String aToken = ((AuditListObject)a).getAuditDate().trim();
								String bToken = ((AuditListObject)b).getAuditDate().trim();
							
								aDate = new java.util.Date(aToken).getTime();
								bDate = new java.util.Date(bToken).getTime();
							}
							catch(Exception ex){
								aDate = 0;
								bDate = 0;
							}
							
							if(aDate > bDate){
								return 1;
							}
							if(aDate < bDate){
								return -1;
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("auditDate") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							long aDate;
							long bDate;
							
							try{
								String aToken = ((AuditListObject)a).getAuditDate().trim();
								String bToken = ((AuditListObject)b).getAuditDate().trim();
							
								aDate = new java.util.Date(aToken).getTime();
								bDate = new java.util.Date(bToken).getTime();
							}
							catch(Exception ex){
								aDate = 0;
								bDate = 0;
							}
							
							if(aDate < bDate){
								return 1;
							}
							if(aDate > bDate){
								return -1;
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Strings
	 	if(sortBy.equalsIgnoreCase("auditor") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getAuditor() != null ? 
									((AuditListObject)a).getAuditor().trim() : "";
							String bToken = ((AuditListObject)b).getAuditor() != null ? 
									((AuditListObject)b).getAuditor().trim() : "";
							
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("auditor") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getAuditor() != null ? 
									((AuditListObject)a).getAuditor().trim() : "";
							String bToken = ((AuditListObject)b).getAuditor() != null ? 
									((AuditListObject)b).getAuditor().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Optional, String
	 	if(sortBy.equalsIgnoreCase("preparedBy") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getPreparedBy() != null ? 
								((AuditListObject)a).getPreparedBy().trim() : "";
							String bToken = ((AuditListObject)b).getPreparedBy() != null ? 
								((AuditListObject)b).getPreparedBy().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("preparedBy") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((AuditListObject)a).getPreparedBy() != null ? 
									((AuditListObject)a).getPreparedBy().trim() : "";
							
							String bToken = ((AuditListObject)b).getPreparedBy() != null ? 
									((AuditListObject)b).getPreparedBy().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Optional, String Tokens
	 	if(sortBy.equalsIgnoreCase("carParNumber") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((AuditListObject)a).getCparNumber() != null) ?
								((AuditListObject)a).getCparNumber().trim().split("-") : "".split("-");
								
							String bTokens[] = (((AuditListObject)b).getCparNumber() != null) ?
									((AuditListObject)b).getCparNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal > bVal){
										return 1;
									}
									if(aVal < bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("carParNumber") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((AuditListObject)a).getCparNumber() != null) ?
									((AuditListObject)a).getCparNumber().trim().split("-") : "".split("-");
									
							String bTokens[] = (((AuditListObject)b).getCparNumber() != null) ?
									((AuditListObject)b).getCparNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal < bVal){
										return 1;
									}
									if(aVal > bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Copy dataVector to the HashMap...
	 	int size = dataVector.size();
	 	for (int i=0; i< size; i++)
	 	{	
	 		hash.put((i + ""),dataVector.get(i));
	 	}

	}

}