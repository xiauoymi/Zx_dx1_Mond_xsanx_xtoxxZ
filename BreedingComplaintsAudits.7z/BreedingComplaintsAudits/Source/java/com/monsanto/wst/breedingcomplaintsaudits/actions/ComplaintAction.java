/*
 * Created on Jan 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.ComplaintForm;
import com.monsanto.wst.breedingcomplaintsaudits.actionForms.ComplaintListForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.User;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.service.*;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.Util.StringUtils;
import org.apache.struts.action.*;
import org.apache.struts.actions.DispatchAction;
import org.apache.log4j.Category;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style -
 *         Code Templates
 */
public class ComplaintAction extends DispatchAction {
  private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
  private String sortCriteria;
  private String sortOrder;
  static Category logger = Category.getInstance(ComplaintAction.class.getName());

  public ActionForward complaintMain(ActionMapping mapping,
                                     ActionForm form,
                                     HttpServletRequest request,
                                     HttpServletResponse response)
          throws Exception {
    getComplaintFormDefaults(request);
    ComplaintListForm complaintListForm = (ComplaintListForm) form;
    String resetCList = request.getParameter("resetCList");
    if (resetCList != null && resetCList.equals("true")) {
      complaintListForm.setComplaintsList(null);
    }
    request.getSession().setAttribute("pageNumber", "1");
    request.setAttribute("selectedPage", "1");

    //**Reset sort-order
    resetSortOrder(request);
    return (mapping.findForward("success"));
  }

  public ActionForward complaintList(ActionMapping mapping,
                                     ActionForm form,
                                     HttpServletRequest request,
                                     HttpServletResponse response)
          throws Exception {

    //**Add selected page to session...
    String selectedPage = request.getParameter("selectedPage");
    if (selectedPage != null) {
      request.getSession().setAttribute("selectedPage", selectedPage);
    } else {
      request.getSession().setAttribute("selectedPage", "1");
    }
    if (request.getParameter("isPaging").toString().equals("true")) {
      sortCriteria = request.getParameter("sortCriteria");
      sortOrder = request.getParameter("sortOrder");
      request.getSession().setAttribute("lastComplaintSortCriteria", sortCriteria);
      request.getSession().setAttribute("lastComplaintSortOrder", sortOrder);
    } else {
      getSortValues(request);
    }
    LinkedHashMap complaintsList = null;
    float pages = 0;
    HttpSession session = request.getSession();
    getComplaintFormDefaults(request);
    ComplaintListForm cf = (ComplaintListForm) form;
    int pageNumber;
    if (!(request.getParameter("pageNumber").equals(null)) && request.getParameter("reset").equals("false")) {
      pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
      try {
        ComplaintService cs = getComplaintService();
        complaintsList = cs.getComplaintsList(cf.getControlNumber(), cf.getCreateDate(), cf.getInitiatedBy(),
                cf.getSalesYr(), cf.getStatus(), cf.getRegion(), cf.getClaimNumber(), cf.getReportingLocation(),
                cf.getResponsibleLocation(), cf.getCrop(), cf.getBatch(), cf.getState(), cf.getVariety(),
                cf.getQualityissue(), request.getParameter("pageNumber"),
                Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder);
      }
      catch (Exception e) {
        throw new Exception(e);
      }
      if (request.getParameter("getMax").equals("true")) {
        session.setAttribute("pageNumber", "1");
      } else {
        if (pageNumber < 11 && pageNumber > 0) {
          session.setAttribute("pageNumber", "1");
        } else {
          session.setAttribute("pageNumber", request.getParameter("pageNumber"));
        }
      }
    }
    if ((complaintsList != null) && !(complaintsList.equals(null))) {
      pages = Float.parseFloat(complaintsList.get("maxRows").toString());
      complaintsList.remove("maxRows");
      if (complaintsList.size() > 0 && pages > 0) {
        cf.setComplaintsList(complaintsList);
        session.setAttribute("pages", new Float(pages / 10));
      } else {
        cf.setComplaintsList(null);
      }
    } else {
      cf.setComplaintsList(null);
    }

    //**Reset sort-order
    ////resetSortOrder(request);
    return (mapping.findForward("success"));
  }

  public ActionForward complaintNew(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
          throws Exception {
    String forward = "";
    getComplaintFormDefaults(request);
    ComplaintForm cf = (ComplaintForm) form;
    Map map = request.getParameterMap();
    User user = (User) request.getSession().getAttribute("user");
    try {
      ComplaintService cs = getComplaintService();
      if (cf.getC() == null) {
        Complaint c = new Complaint();
        c.setComplaint_id(cs.getComplaintPK());
        c.setCreated_by(user.getUser_id());
        c.setRow_entry_date(sdf.format(new Date()));
        c.setRow_user_id(user.getUser_id());
        cf.setC(c);
      } else {
        cf.getC().setComplaint_id(cs.getComplaintPK());
        cf.getC().setCreated_by(user.getUser_id());
        cf.getC().setRow_user_id(user.getUser_id());
        cf.getC().setRow_entry_date(sdf.format(new Date()));
      }
      if (request.getParameter("affina").equals("true")) {
        forward = "successAffina";
        cf.getC().setAffina_entry_flag("Y");
      } else {
        forward = "success";
        cf.getC().setAffina_entry_flag("N");
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    clearFoundBatches(request);
    setEditValue(request, "complaintNew");

    //request.setAttribute("displayReset", "true");
    return (mapping.findForward(forward));
  }

  /**
   * @param request
   */
  private void setEditValue(HttpServletRequest request, String method) {
    HttpSession session = request.getSession();
    if (method.equals("complaintNew")) {
      session.setAttribute("complaintEdit", "false");
      request.setAttribute("showCAR", "false");
    }
    if (method.equals("complaintEdit")) {
      session.setAttribute("complaintEdit", "true");
      request.setAttribute("showCAR", "true");
    }
    if (method.equals("complaintSubmit")) {
      session.setAttribute("complaintEdit", "true");
      request.setAttribute("showCAR", "true");
    }
  }

  public ActionForward complaintEdit(ActionMapping mapping,
                                     ActionForm form,
                                     HttpServletRequest request,
                                     HttpServletResponse response)
          throws Exception {
    String forward = "";
    String foundCAR = "";
    String strCPARControlNumber = "";
    Complaint c;
    getComplaintFormDefaults(request);
    ComplaintForm cf = (ComplaintForm) form;
    cf.setC(null);
    User user = (User) request.getSession().getAttribute("user");
    try {
      ComplaintService cs = getComplaintService();
      CparService cpars = getCPARService();
      c = cs.getComplaint(request.getParameter("complaintId"));
      // Set new user.
      c.setRow_user_id(user.getUser_id());
      cf.setC(c);
      foundCAR = cpars.findCAR(request.getParameter("complaintId"));
      strCPARControlNumber = cpars.findControlNumberText(request.getParameter("complaintId"));
      if (!foundCAR.equals("")) {
        request.setAttribute("cparId", foundCAR);
      }
      if (!strCPARControlNumber.equals("")) {
        request.setAttribute("controlNumber", strCPARControlNumber);
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    forward = getForward(request);
    clearFoundBatches(request);
    setEditValue(request, "complaintEdit");
    request.setAttribute("displayReset", "false");
    request.getSession().setAttribute("originalComplaint", c);
    return (mapping.findForward(forward));
  }

  public ActionForward complaintSubmit(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response)
          throws Exception {
    Complaint originalComplaint = (Complaint) request.getSession().getAttribute("originalComplaint");
    String forward;
    String foundCAR;
    String strCPARControlNumber;
    ComplaintForm cf = (ComplaintForm) form;
    Complaint c = cf.getC();
    //**Change-Request: Atleast one checkbox should be selected...Form Validation...
    if (c.getAffina_entry_flag().equals("N")) {
      if (!validateFeedbackType(c)) {
        ActionErrors errors = new ActionErrors();
        errors.add("FeedbackType", new ActionError("com.monsanto.wst.breedingcomplaintsaudits.complaint.feedbackType"));
        saveErrors(request, errors);
        return mapping.findForward("failure");
      }
    }
    forward = getForward(request);
    try {
      ComplaintService cs = getComplaintService();
      CparService cpars = getCPARService();
      if (c != null) {
        if (request.getSession().getAttribute("complaintEdit").equals("true")) {
          cs.updateComplaint(c);
          request.setAttribute("msg", "true");
//				Send E-mail.
          if (c.getStatus_id().equals("1")) {
            sendEMails(c, ActionHelper.EMAIL_TYPE_COMPLAINT_STATUS_CHANGED, request);
          }
          if (!c.equals(originalComplaint)) {
            sendEMails(c, ActionHelper.EMAIL_TYPE_FEEDBACK_CHANGED, request);
          }
          setEditValue(request, "complaintSubmit");
// 				Create CAR logic
          foundCAR = cpars.findCAR(c.getComplaint_id());
          strCPARControlNumber = cpars.findControlNumberText(c.getComplaint_id());
          if (!foundCAR.equals("")) {
            request.setAttribute("cparId", foundCAR);
          }
          if (!strCPARControlNumber.equals("")) {
            request.setAttribute("controlNumber", strCPARControlNumber);
          }
          if (!(request.getParameter("createCAR") == null || request.getParameter("iscar") == null) &&
                  request.getParameter("createCAR").equals("true")) {
            if (!foundCAR.equals("")) {
              request.setAttribute("errorMsg", "Duplicate CAR. CAR for this record already exists.");
            } else {
              forward = "successCPAR";
            }
          }
        } else {
          if (request.getParameter("createCAR") == null && request.getParameter("iscar") == null) {
            cs.insertComplaint(c);
//							Send E-mail.		    				
            if (c.getStatus_id().equals("1")) {
              sendEMails(c, ActionHelper.EMAIL_TYPE_COMPLAINT_STATUS_CHANGED, request);
            } else {
              sendEMails(c, ActionHelper.EMAIL_TYPE_COMPLAINT_NEW, request);
            }
            request.setAttribute("msg", "true");
            setEditValue(request, "complaintSubmit");
          }
        }
      }
      request.getSession().setAttribute("originalComplaint", c);
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    return (mapping.findForward(forward));
  }

  protected CparService getCPARService() throws ServiceException {
    return (CparService) ServiceLocator.locateService(CparService.class);
  }

  protected ComplaintService getComplaintService() throws ServiceException {
    return (ComplaintService) ServiceLocator.locateService(ComplaintService.class);
  }

  private boolean validateFeedbackType(Complaint c) {
    return c.getQuality_issue().length() > 0 && c.getQuality_issue() != null;
  }

  private boolean validateCheckboxes(Complaint c) {
    return ((validateDeliveryIssue(c) || validatePlantingIssue(c) ||
            validateMidSeasonIssue(c) || validateHarvestIssue(c)));
  }

  private boolean validateHarvestIssue(Complaint c) {
    return ((c.isDisease_development()) || (c.isInsect_development()) || (c.isSeed_development()) ||
            (c.isNoncompetitive_yield()) || (c.isMaintaining_seed_until_harvest()) || (c.isMaturity_drydown()) ||
            (c.isLate_season_other()));
  }

  private boolean validateMidSeasonIssue(Complaint c) {
    return ((c.isGrowth_development()) || (c.isHerbicide_injury()) || (c.isDisease_development()) ||
            (c.isInsect_outbreaks_injury()) || (c.isPollination_problems()) || (c.isStress_susceptability()) ||
            (c.isMidseason_other()));
  }

  private boolean validatePlantingIssue(Complaint c) {
    return ((c.isSeed_variability()) || (c.isSeed_appearance()) || (c.isEmergence_concerns()) ||
            (c.isProduct_purity()) || (c.isEarly_season_other()));
  }

  private boolean validateDeliveryIssue(Complaint c) {
    return ((c.isDriver_performance()) || (c.isIncorrect_shipment()) || (c.isDelivery_other()) ||
            (c.isPackaging_condition()) || (c.isTag_error()));
  }

  public ActionForward complaintFindBatches(ActionMapping mapping,
                                            ActionForm form,
                                            HttpServletRequest request,
                                            HttpServletResponse response)
          throws Exception {
    String forward = "success";
    Complaint c = ((ComplaintForm) form).getC();
    Map batches = null;
    try {
      ComplaintService cs = getComplaintService();
      if (!(request.getParameter("batchNumber").equals(null)) &&
              !(request.getParameter("batchNumber").equals(""))) {
        batches = cs.findBatches(request.getParameter("batchNumber").trim(), c.getComplaint_id());
      }
      forward = getForward(request);
      request.getSession().setAttribute(request.getParameter("batchID"), batches);
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    return (mapping.findForward(forward));
  }

  /**
   * Method sort
   *
   * @param mapping
   * @param form
   * @param request
   * @param response
   * @return ActionForward
   */
  public ActionForward sort(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    ComplaintListForm complaintListForm = (ComplaintListForm) form;

    //*****LocationList Filling...
    try {
      getComplaintFormDefaults(request);
    }
    catch (Exception ex) {
      System.out.println("Error getting Complaint default lists.");
      ex.printStackTrace();
    }

    //**Read the request parameters...Sort Order and Criteria.
    getSortValues(request);

    //**Get the HashMap and sort it...
    ///sortList(complaintListForm.getComplaintsList(), sortCriteria, sortOrder);

    //**Set it back in the form...
    return mapping.findForward("success");
  }

  protected void getComplaintFormDefaults(HttpServletRequest request) throws Exception {
    HttpSession session = request.getSession();
    session.setAttribute(ActionHelper.STATUS_LIST, null);
    if (session.getAttribute(ActionHelper.CROP_LIST) == null) {
      session.setAttribute(ActionHelper.CROP_LIST, ActionHelper.getCropList());
    }
    if (session.getAttribute(ActionHelper.LOCATION_LIST) == null) {
      session.setAttribute(ActionHelper.LOCATION_LIST, ActionHelper.getLocationList());
    }
    if (session.getAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST) == null) {
      session.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST, ActionHelper.getResponsibleLocationList());
    }
    if (session.getAttribute(ActionHelper.QUALITY_ISSUE_LIST) == null) {
      session.setAttribute(ActionHelper.QUALITY_ISSUE_LIST, ActionHelper.getQualityissueList());
    }
    if (session.getAttribute(ActionHelper.SALES_YEAR_LIST) == null) {
      session.setAttribute(ActionHelper.SALES_YEAR_LIST, ActionHelper.getSalesyearList());
    }
    if (session.getAttribute(ActionHelper.SEED_SIZE_LIST) == null) {
      session.setAttribute(ActionHelper.SEED_SIZE_LIST, ActionHelper.getSeedsizeList());
    }
    if (session.getAttribute(ActionHelper.STATE_LIST) == null) {
      session.setAttribute(ActionHelper.STATE_LIST, ActionHelper.getStatesList());
    }
    if (session.getAttribute(ActionHelper.STATUS_LIST) == null) {
      session.setAttribute(ActionHelper.STATUS_LIST, ActionHelper.getStatusList("COMPLAINT"));
    }
    if (session.getAttribute(ActionHelper.UOM_LIST) == null) {
      session.setAttribute(ActionHelper.UOM_LIST, ActionHelper.getUomList());
    }
    if (session.getAttribute(ActionHelper.VARIETY_LIST) == null) {
      session.setAttribute(ActionHelper.VARIETY_LIST, ActionHelper.getVarityList());
    }
    if (session.getAttribute(ActionHelper.REGION_LIST) == null) {
      session.setAttribute(ActionHelper.REGION_LIST, ActionHelper.getRegionList());
    }
  }

  private void clearFoundBatches(HttpServletRequest request) {
    HttpSession session = request.getSession();
    session.setAttribute("batchList1", null);
    session.setAttribute("batchList2", null);
    session.setAttribute("batchList3", null);
    session.setAttribute("batchList4", null);
    session.setAttribute("batchListAffina1", null);
    session.setAttribute("batchListAffina2", null);
    session.setAttribute("batchListAffina3", null);
    session.setAttribute("batchListAffina4", null);
  }

  private String getForward(HttpServletRequest request) {
    String forward = "";
    User user = (User) request.getSession().getAttribute("user");
    if (user.isRole("6") || user.isRole("3")) {
      if (!user.isRole("6") && user.isRole("3")) {
        forward = "successAffina";
      } else {
        forward = "success";
      }
    } else if (!user.isRole("6") && !user.isRole("3") && (user.isRole("5") || user.isRole("2"))) {
      if (!user.isRole("5") && user.isRole("2")) {
        forward = "successAffina";
      } else {
        forward = "success";
      }
    }
    return forward;
  }

  private boolean sendEMails(Complaint c, String type, HttpServletRequest request) throws Exception {
    String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.AppName");
    String emailFooter = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.EmailFooter");
    String complaintID = c.getComplaint_id();
    String url = (request.getRequestURL().toString().split(request.getContextPath()))[0] + request.getContextPath();
    //String urlLink=url+"/complaint.do?method=complaintEdit&complaintId="+complaintID;
    try {
      EmailUtil emailUtil = getEmailUtil();
      if (type.equals(ActionHelper.EMAIL_TYPE_COMPLAINT_NEW) && ActionHelper.AFFINA_EMAIL != null && !(ActionHelper.AFFINA_EMAIL.equals(""))) {
        emailUtil.setTo(ActionHelper.AFFINA_EMAIL);
        emailUtil.setFrom(ActionHelper.ADMIN_EMAIL);
        emailUtil.setSubject(ActionHelper.EMAIL_TYPE_COMPLAINT_NEW + " Feedback ID:" + complaintID + " - " + appName);
        emailUtil.setBody("A new feedback (Feedback id:" + complaintID +
                ") has been entered into the SBFAS system. Click here to logon to the SBFAS system: " + url +
                "\n\n\n\n\n" + emailFooter);
        return emailUtil.sendMail();
      }
      String responsibleLocationEmail = getResponsibleLocationEmail(c);
      if (type.equals(ActionHelper.EMAIL_TYPE_FEEDBACK_CHANGED)
              && !StringUtils.isNullOrEmpty(ActionHelper.ADMIN_EMAIL)
              && !StringUtils.isNullOrEmpty(responsibleLocationEmail)) {
        emailUtil.setTo(responsibleLocationEmail);
        emailUtil.setFrom(ActionHelper.ADMIN_EMAIL);
        emailUtil.setSubject(ActionHelper.EMAIL_TYPE_FEEDBACK_CHANGED + " '" + complaintID + "' - " + appName);
        emailUtil.setBody("The Feedback '" + complaintID + "' has been modified. Click here to logon to the SBFAS system: " + url +
                "\n\n\n\n\n" + emailFooter);
        return emailUtil.sendMail();
      }
      return false;
    }
    catch (Exception e) {
      throw new Exception(e);
    }
  }

  private String getResponsibleLocationEmail(Complaint c) throws ServiceException {
    LookUpService lookupService = getLookupService();
    String[] emails = new String[0];
    if (!StringUtils.isNullOrEmpty(c.getResponsible_plant_code())) {
      emails = lookupService.getEmail(c.getResponsible_plant_code().split("_")[0]);
    }
    String responsibleLocationEmail = null;
    if (emails != null && emails.length > 0) {
      responsibleLocationEmail = emails[0];
    }
    if(StringUtils.isNullOrEmpty(responsibleLocationEmail)) {
      logger.error("Error sending feedback change email: Responsible Plant Location Email is null or empty.");
    }
    return responsibleLocationEmail;
  }

  protected LookUpService getLookupService() throws ServiceException {
    return (LookUpService) ServiceLocator.locateService(LookUpService.class);
  }

  protected EmailUtil getEmailUtil() {
    return new EmailUtil();
  }

  /**
   * To get the sortCriteria and determine the sortOrder.
   *
   * @param request
   */
  private void getSortValues(HttpServletRequest request) {
    sortOrder = "asc";
    sortCriteria = request.getParameter("sortCriteria");
    String lastSortCriteria = request.getSession().getAttribute("lastComplaintSortCriteria") + "";
    if (lastSortCriteria == null) {
      sortOrder = "asc";
    } else {    // => Not_Null
      if (sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
        sortOrder = request.getSession().getAttribute("lastComplaintSortOrder") + "";
        if (sortOrder == null) {
          sortOrder = "asc";
        } else {    // => Not_Null
          if (sortOrder.equalsIgnoreCase("asc")) {
            sortOrder = "desc";
          } else {
            sortOrder = "asc";
          }
        }
      } else {
        sortOrder = "asc";
      }
    }
    request.getSession().setAttribute("lastComplaintSortCriteria", sortCriteria);
    request.getSession().setAttribute("lastComplaintSortOrder", sortOrder);
  }

  /**
   * To reset the sortOrder after every submit or refresh(display).
   *
   * @param request
   */
  private void resetSortOrder(HttpServletRequest request) {
    request.getSession().setAttribute("lastComplaintSortOrder", "desc");
  }

  private void sortList(LinkedHashMap hash, String sortBy, String sortOrd) {
    Vector dataVector = new Vector();
    Iterator it = hash.keySet().iterator();
    while (it.hasNext()) {
      dataVector.add((List) hash.get(it.next()));
    }
    hash.clear();

    //**Reqd, int
    if (sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  int aInt;
                  int bInt;
                  try {
                    String aToken = ((List) a).get(0).toString().trim();
                    String bToken = ((List) b).get(0).toString().trim();
                    aInt = Integer.parseInt(aToken);
                    bInt = Integer.parseInt(bToken);
                  }
                  catch (Exception ex) {
                    aInt = 0;
                    bInt = 0;
                  }
                  if (aInt > bInt) {
                    return 1;
                  }
                  if (aInt < bInt) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(0).toString().trim();
                  String bToken = ((List) b).get(0).toString().trim();
                  int aInt = Integer.parseInt(aToken);
                  int bInt = Integer.parseInt(bToken);
                  if (aInt < bInt) {
                    return 1;
                  }
                  if (aInt > bInt) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Reqd, Date
    if (sortBy.equalsIgnoreCase("createdDate") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  long aDate;
                  long bDate;
                  try {
                    String aToken = ((List) a).get(1).toString().trim();
                    String bToken = ((List) b).get(1).toString().trim();
                    aDate = new java.util.Date(aToken).getTime();
                    bDate = new java.util.Date(bToken).getTime();
                  }
                  catch (Exception ex) {
                    aDate = 0;
                    bDate = 0;
                  }
                  if (aDate > bDate) {
                    return 1;
                  }
                  if (aDate < bDate) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("createdDate") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  long aDate;
                  long bDate;
                  try {
                    String aToken = ((List) a).get(1).toString().trim();
                    String bToken = ((List) b).get(1).toString().trim();
                    aDate = new java.util.Date(aToken).getTime();
                    bDate = new java.util.Date(bToken).getTime();
                  }
                  catch (Exception ex) {
                    aDate = 0;
                    bDate = 0;
                  }
                  if (aDate < bDate) {
                    return 1;
                  }
                  if (aDate > bDate) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("initiatedBy") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(2) != null ?
                          ((List) a).get(2).toString().trim() : "";
                  String bToken = ((List) b).get(2) != null ?
                          ((List) b).get(2).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("initiatedBy") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(2) != null ?
                          ((List) a).get(2).toString().trim() : "";
                  String bToken = ((List) b).get(2) != null ?
                          ((List) b).get(2).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("salesYear") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(3) != null ?
                          ((List) a).get(3).toString().trim() : "";
                  String bToken = ((List) b).get(3) != null ?
                          ((List) b).get(3).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("salesYear") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(3) != null ?
                          ((List) a).get(3).toString().trim() : "";
                  String bToken = ((List) b).get(3) != null ?
                          ((List) b).get(3).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(4) != null ?
                          ((List) a).get(4).toString().trim() : "";
                  String bToken = ((List) b).get(4) != null ?
                          ((List) b).get(4).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(4) != null ?
                          ((List) a).get(4).toString().trim() : "";
                  String bToken = ((List) b).get(4) != null ?
                          ((List) b).get(4).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(5) != null ?
                          ((List) a).get(5).toString().trim() : "";
                  String bToken = ((List) b).get(5) != null ?
                          ((List) b).get(5).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(5) != null ?
                          ((List) a).get(5).toString().trim() : "";
                  String bToken = ((List) b).get(5) != null ?
                          ((List) b).get(5).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("claimNumber") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(6) != null ?
                          ((List) a).get(6).toString().trim() : "";
                  String bToken = ((List) b).get(6) != null ?
                          ((List) b).get(6).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("claimNumber") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((List) a).get(6) != null ?
                          ((List) a).get(6).toString().trim() : "";
                  String bToken = ((List) b).get(6) != null ?
                          ((List) b).get(6).toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Copy dataVector to the HashMap...
    int size = dataVector.size();
    for (int i = 0; i < size; i++) {
      hash.put((i + ""), dataVector.get(i));
    }
  }
}
