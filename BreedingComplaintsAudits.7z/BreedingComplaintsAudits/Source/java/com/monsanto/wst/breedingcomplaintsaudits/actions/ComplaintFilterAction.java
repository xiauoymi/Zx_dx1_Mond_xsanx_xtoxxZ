//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.ComplaintFilterForm;
import com.monsanto.wst.breedingcomplaintsaudits.exportTool.ExportClass;
import com.monsanto.wst.breedingcomplaintsaudits.model.ComplaintFilter;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.ExportBean;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.ReportTag;
import com.monsanto.wst.breedingcomplaintsaudits.service.ComplaintService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.HashMap;

/** 
 * MyEclipse Struts
 * Creation date: 05-31-2005
 * 
 * XDoclet definition:
 * @struts:action path="/complaintFilter" name="complaintFilterForm" scope="request"
 */
public class ComplaintFilterAction extends DispatchAction {

	static Category logger = Category.getInstance(ComplaintFilterAction.class.getName());
	
	private static String fileName;
	
	private static String sheetName;
	
	/** 
	 * Method display
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward display(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) form;
		
		try{
			//**Initialize Combo Boxes...
			getComplaintFormDefaults(request);
		}
		catch(Exception ex){
			logger.error("Error retrieving lists in complaint filter.");
		}
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method submit
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward submit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) form;
		
		//**Set/ResetSelections...(to rectify checkbox error)
		resetSelections(complaintFilterForm.getComplaintFilter(), request);
		
		//**1. Call the getComplaintReportList() Service/DAO to get HashMap of Data (hash)
		HashMap hash = new HashMap();
		

		try{
			ComplaintService cs = (ComplaintService) ServiceLocator.locateService(ComplaintService.class);
			hash = cs.getComplaintReport(complaintFilterForm.getComplaintFilter());
		}
		catch(Exception e){
			logger.error("Error getting 'getComplaintReport()' Service.");
		}
		
		//**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the ComplaintFilter Form Bean.
		complaintFilterForm.setHash(hash);
		
		String file = "";
		InputStream xmlIn = null;
//		if(xmlIn.markSupported()){
//			try{
//				xmlIn.reset();
//				logger.error("Complaint report: XmlIn reset success...");
//			}
//			catch(Exception ex){
//				logger.error("Complaint report: XmlIn reset error...");
//			}
//		}
		try{
			file = McasProperties.getMcasProperties().getString("complaint.reportStructure");
			if (file == null){System.out.println("\n\n\n\n"+file+"\n\n\n\n");}
			System.out.println("\n\n\n\n"+file+"\n\n\n\n");
			ClassLoader classLoader = ComplaintFilterAction.class.getClassLoader();
			xmlIn = classLoader.getResourceAsStream(file);
			if (xmlIn == null){System.out.println("\n\n\n\n"+xmlIn+"\n\n\n\n");}
		}
		catch(Exception ex){
			logger.error("Property Error: Problem getting the Complaint-Report-Structure.Xml filename.");
		}		
		complaintFilterForm.setXmlIn(xmlIn);
		
		complaintFilterForm.setSortBy("col1");
		complaintFilterForm.setSortOrder("asc");


		return mapping.findForward("success");
	}
	
	/** 
	 * Method export
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward export(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) form;
		
		logger.info("Export to Excel called...");
		
		//**The Export Functionality...
		try{
			
			ExportBean exportBean = ReportTag.getExportData();
			
			fileName = exportBean.getExcelFileName();
			sheetName = exportBean.getExcelSheetName();
			
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-disposition", "filename=" + fileName);
		
			ServletOutputStream sos = response.getOutputStream();
			BufferedOutputStream bos = new BufferedOutputStream(sos);
		
			ExportClass export2Excel = new ExportClass();
			
			//**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector... 			
			export2Excel.setSheetName(sheetName);
			export2Excel.setTotalFields(exportBean.getTotalFields());
			export2Excel.setColHeader(exportBean.getExportColHeader());
			export2Excel.setVector(exportBean.getExportDataVector());
			
			export2Excel.setBos(bos);
			
			export2Excel.exportExcel();
		
			bos = export2Excel.getBos();
		
			bos.flush();
			bos.close();
			sos.close();
		}
		catch(Exception ex){			
			logger.info("-> Error exporting Complaint Report." + ex.getMessage());
		}
		
		logger.info("-> Excel file created.");
		
		return mapping.findForward("success");
	}
	
	/**
	 * List/Combo Box Filling method...
	 * 
	 * @param request
	 * @throws Exception
	 */
	 private void getComplaintFormDefaults(HttpServletRequest request) throws Exception {
    	HttpSession session = request.getSession();
    	session.setAttribute(ActionHelper.STATUS_LIST,null);
    	if (session.getAttribute(ActionHelper.CROP_LIST) == null )
    		session.setAttribute(ActionHelper.CROP_LIST,ActionHelper.getCropList());
		if (session.getAttribute(ActionHelper.LOCATION_LIST) == null )
			session.setAttribute(ActionHelper.LOCATION_LIST,ActionHelper.getLocationList());
		if (session.getAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST) == null )
			session.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST,ActionHelper.getResponsibleLocationList());
        if (session.getAttribute(ActionHelper.QUALITY_ISSUE_LIST) == null )
	    	session.setAttribute(ActionHelper.QUALITY_ISSUE_LIST,ActionHelper.getQualityissueList());
    	if (session.getAttribute(ActionHelper.SALES_YEAR_LIST) == null )
    		session.setAttribute(ActionHelper.SALES_YEAR_LIST,ActionHelper.getSalesyearList());
    	if (session.getAttribute(ActionHelper.STATUS_LIST) == null )
    		session.setAttribute(ActionHelper.STATUS_LIST,ActionHelper.getStatusList("COMPLAINT"));
    	if (session.getAttribute(ActionHelper.VARIETY_LIST) == null )
    		session.setAttribute(ActionHelper.VARIETY_LIST,ActionHelper.getVarityList());
    	if (session.getAttribute(ActionHelper.REGION_LIST) == null )
    		session.setAttribute(ActionHelper.REGION_LIST,ActionHelper.getRegionList());
    }
	 
	 /**
		 * To set/reset all the checkboxs again, and rectify the checkbox-reset error
		 * 
		 * @param stopSale
		 * @param request
		 */
		private void resetSelections(ComplaintFilter complaintFilter, HttpServletRequest request){
			
			if(request.getParameterMap().get("complaintFilter.driverPerformance") != null){
				complaintFilter.setDriverPerformance(true);
			}
			else{
				complaintFilter.setDriverPerformance(false);
			}
			if(request.getParameterMap().get("complaintFilter.packagingCondition") != null){
				complaintFilter.setPackagingCondition(true);
			}
			else{
				complaintFilter.setPackagingCondition(false);
			}
			if(request.getParameterMap().get("complaintFilter.incorrectShipment") != null){
				complaintFilter.setIncorrectShipment(true);
			}
			else{
				complaintFilter.setIncorrectShipment(false);
			}
			if(request.getParameterMap().get("complaintFilter.tagError") != null){
				complaintFilter.setTagError(true);
			}
			else{
				complaintFilter.setTagError(false);
			}
			if(request.getParameterMap().get("complaintFilter.deliveryOther") != null){
				complaintFilter.setDeliveryOther(true);
			}
			else{
				complaintFilter.setDeliveryOther(false);
			}
			
			if(request.getParameterMap().get("complaintFilter.seedAppearance") != null){
				complaintFilter.setSeedAppearance(true);
			}
			else{
				complaintFilter.setSeedAppearance(false);
			}
			if(request.getParameterMap().get("complaintFilter.seedVariability") != null){
				complaintFilter.setSeedVariability(true);
			}
			else{
				complaintFilter.setSeedVariability(false);
			}
			if(request.getParameterMap().get("complaintFilter.emergenceConcerns") != null){
				complaintFilter.setEmergenceConcerns(true);
			}
			else{
				complaintFilter.setEmergenceConcerns(false);
			}
			if(request.getParameterMap().get("complaintFilter.productPurity") != null){
				complaintFilter.setProductPurity(true);
			}
			else{
				complaintFilter.setProductPurity(false);
			}
			if(request.getParameterMap().get("complaintFilter.earlySeasonOther") != null){
				complaintFilter.setEarlySeasonOther(true);
			}
			else{
				complaintFilter.setEarlySeasonOther(false);
			}
			
			if(request.getParameterMap().get("complaintFilter.growthDevelopment") != null){
				complaintFilter.setGrowthDevelopment(true);
			}
			else{
				complaintFilter.setGrowthDevelopment(false);
			}
			if(request.getParameterMap().get("complaintFilter.herbicideInjury") != null){
				complaintFilter.setHerbicideInjury(true);
			}
			else{
				complaintFilter.setHerbicideInjury(false);
			}
			if(request.getParameterMap().get("complaintFilter.diseaseDevelopment") != null){
				complaintFilter.setDiseaseDevelopment(true);
			}
			else{
				complaintFilter.setDiseaseDevelopment(false);
			}
			if(request.getParameterMap().get("complaintFilter.insectOutbreaksInjury") != null){
				complaintFilter.setInsectOutbreaksInjury(true);
			}
			else{
				complaintFilter.setInsectOutbreaksInjury(false);
			}
			if(request.getParameterMap().get("complaintFilter.pollinationProblems") != null){
				complaintFilter.setPollinationProblems(true);
			}
			else{
				complaintFilter.setPollinationProblems(false);
			}
			if(request.getParameterMap().get("complaintFilter.stressSusceptability") != null){
				complaintFilter.setStressSusceptability(true);
			}
			else{
				complaintFilter.setStressSusceptability(false);
			}
			if(request.getParameterMap().get("complaintFilter.midSeasonOther") != null){
				complaintFilter.setMidSeasonOther(true);
			}
			else{
				complaintFilter.setMidSeasonOther(false);
			}
			
			if(request.getParameterMap().get("complaintFilter.lateSeasonDiseaseDevelopment") != null){
				complaintFilter.setLateSeasonDiseaseDevelopment(true);
			}
			else{
				complaintFilter.setLateSeasonDiseaseDevelopment(false);
			}
			if(request.getParameterMap().get("complaintFilter.insectDevelopment") != null){
				complaintFilter.setInsectDevelopment(true);
			}
			else{
				complaintFilter.setInsectDevelopment(false);
			}
			if(request.getParameterMap().get("complaintFilter.seedDevelopment") != null){
				complaintFilter.setSeedDevelopment(true);
			}
			else{
				complaintFilter.setSeedDevelopment(false);
			}
			if(request.getParameterMap().get("complaintFilter.nonCompetitiveYield") != null){
				complaintFilter.setNonCompetitiveYield(true);
			}
			else{
				complaintFilter.setNonCompetitiveYield(false);
			}
			if(request.getParameterMap().get("complaintFilter.maintainingSeedUntilHarvest") != null){
				complaintFilter.setMaintainingSeedUntilHarvest(true);
			}
			else{
				complaintFilter.setMaintainingSeedUntilHarvest(false);
			}
			if(request.getParameterMap().get("complaintFilter.maturityDrydown") != null){
				complaintFilter.setMaturityDrydown(true);
			}
			else{
				complaintFilter.setMaturityDrydown(false);
			}
			if(request.getParameterMap().get("complaintFilter.lateSeasonOther") != null){
				complaintFilter.setLateSeasonOther(true);
			}
			else{
				complaintFilter.setLateSeasonOther(false);
			}
			
		} 

}