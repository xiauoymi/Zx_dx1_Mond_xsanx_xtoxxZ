//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.CparLogForm;
import com.monsanto.wst.breedingcomplaintsaudits.exportTool.ExportClass;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.service.CparService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.ExportBean;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.ReportTag;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;

/** 
 * MyEclipse Struts
 * Creation date: 07-14-2005
 * 
 * XDoclet definition:
 * @struts:action path="/cparLog" name="cparLogForm" scope="request"
 */
public class CparLogAction extends DispatchAction {
	
	static Category logger = Category.getInstance(CparFilterAction.class.getName());

	private static String fileName;	
	private static String sheetName;
	
	/** 
	 * Method display
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward display(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		CparLogForm cparLogForm = (CparLogForm) form;
		
		try{
			getCparFormDefaults(request);
		}
		catch(Exception ex){
			logger.error("Error populating the lists for Car/Par Log: " + ex.getMessage());
		}
		cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method export
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward export(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		CparLogForm cparLogForm = (CparLogForm) form;
		
		//**The Export Functionality...
		try{
			
			ExportBean exportBean = ReportTag.getExportData();
			
			fileName = exportBean.getExcelFileName();
			sheetName = exportBean.getExcelSheetName();
			
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-disposition", "filename=" + fileName);
		
			ServletOutputStream sos = response.getOutputStream();
			BufferedOutputStream bos = new BufferedOutputStream(sos);
		
			ExportClass export2Excel = new ExportClass();
			
			//**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector... 			
			export2Excel.setSheetName(sheetName);
			export2Excel.setTotalFields(exportBean.getTotalFields());
			export2Excel.setColHeader(exportBean.getExportColHeader());
			export2Excel.setVector(exportBean.getExportDataVector());
			
			export2Excel.setBos(bos);
			
			export2Excel.exportExcel();
		
			bos = export2Excel.getBos();
		
			bos.flush();
			bos.close();
			sos.close();
		}
		catch(Exception ex){			
			logger.info("-> Error exporting Cpar Log Report." + ex.getMessage());
		}
		
		logger.info("-> Excel file created.");
		
		cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
		return mapping.findForward("submit");
	}
	
	/** 
	 * Method submit
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward submit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		CparLogForm cparLogForm = (CparLogForm) form;
		
		//**1. Call the getCparReportList() Service/DAO to get HashMap of Data (hash)
		HashMap hash = new HashMap();
		
		try{
			CparService cs = (CparService)ServiceLocator.locateService(CparService.class);
			hash = cs.getCparLog(cparLogForm.getCparLog());
		}
		catch(Exception e){
			logger.error("Error getting 'getCparLog()' Service.");
		}
		
		//**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the cparFilter FormBean.
		cparLogForm.setHash(hash);
		
		String file = "";
		InputStream xmlIn = null;		
		try{
			file = McasProperties.getMcasProperties().getString("cpar.logStructure");

			ClassLoader classLoader = CparFilterAction.class.getClassLoader();
			xmlIn = classLoader.getResourceAsStream(file);
		}
		catch(Exception ex){
			logger.error("Property Error: Problem getting the Cpar-Log-Structure.Xml filename.");
		}		
		
		cparLogForm.setXmlIn(xmlIn);
		
		cparLogForm.setSortBy("col1");
		cparLogForm.setSortOrder("asc");
		
		cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
		return mapping.findForward("submit");
	}
	
	private void getCparFormDefaults(HttpServletRequest request) throws Exception {
    	HttpSession session = request.getSession();
    	session.setAttribute(ActionHelper.STATUS_LIST,null);
    	if (session.getAttribute(ActionHelper.SALES_YEAR_LIST) == null )
    		session.setAttribute(ActionHelper.SALES_YEAR_LIST,ActionHelper.getSalesyearList());
		if (session.getAttribute(ActionHelper.LOCATION_LIST) == null )
			session.setAttribute(ActionHelper.LOCATION_LIST,ActionHelper.getLocationList());
		if (session.getAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST) == null )
			session.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST,ActionHelper.getResponsibleLocationList());

    }
}