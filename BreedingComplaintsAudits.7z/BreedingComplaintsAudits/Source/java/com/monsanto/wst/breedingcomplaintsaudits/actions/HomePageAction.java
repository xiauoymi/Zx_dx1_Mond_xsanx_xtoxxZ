/*
 * Created on Mar 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.wst.breedingcomplaintsaudits.model.User;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.service.UserAccountService;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class HomePageAction extends DispatchAction {
    public ActionForward homePageLogon(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
		throws Exception {
    	HttpSession session = request.getSession();
    	User user = null;
    	if ((session.getAttribute("user")==null)) {
    		user = new User();    		
    		if (McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.authorize").equals("true")) {
	//TODO Get user info from Active Directory API and store it in user.
	    		KerberosSecurity sec = new KerberosSecurity();
	    		sec.init(request);	// HttpServletRequest
	    		user.setUser_id(sec.getUserID());
	    		user.setFull_name(sec.getFullName());
	
	//			For testing purpose only.
	//    		user.setUser_id("TLGRIF");
	    		
	// 		Get permission info for this user.
	    		try {
	    			UserAccountService us = (UserAccountService)ServiceLocator.locateService(UserAccountService.class);;
	    			user = us.getUserInfo(user);
	    		}
	    		catch (Exception e){
	    			throw new Exception(e);
	    		}
    		}
    		session.setAttribute("user",user); 
    		ActionHelper.reloadAllData();
    	}
		return (mapping.findForward("success"));
    }
	
}
