//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.ComplaintForm;
import com.monsanto.wst.breedingcomplaintsaudits.actionForms.StopSaleForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.User;
import com.monsanto.wst.breedingcomplaintsaudits.service.ComplaintService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.service.StopSaleService;
import com.monsanto.wst.breedingcomplaintsaudits.service.StopSaleServiceImpl;

/** 
 * MyEclipse Struts
 * Creation date: 05-04-2005
 * 
 * XDoclet definition:
 * @struts:action path="/stopSale" name="stopSaleForm" scope="request"
 */
public class StopSaleAction extends DispatchAction {
	
	static Category logger = Category.getInstance(StopSaleAction.class.getName());
	
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	/** 
	 * Method display
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward stopSaleDisplay(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleForm stopSaleForm = (StopSaleForm) form;
		
		//**Filling the combo-boxes...
		getStopSaleDefaultLists(request);
		clearFoundBatches(request);
		
		//**Fill in the preloaded fields...
		User user = (User)request.getSession().getAttribute("user");
		
		stopSaleForm.getStopSale().setCreatedBy(user.getUser_id());
		stopSaleForm.getStopSale().setEntryDate(sdf.format(new Date()));
		stopSaleForm.getStopSale().setStatus("10");
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method view
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward stopSaleView(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleForm stopSaleForm = (StopSaleForm) form;
		
		//**Filling the combo-boxes...
		getStopSaleDefaultLists(request);
		clearFoundBatches(request);
		
		int stopSaleID = 0;
		try{
			stopSaleID = Integer.parseInt(request.getParameter("stopSaleId"));
		}
		catch(Exception ex){
			logger.error("StopSaleView: stopSaleID is not a valid integer.");
		}
		
		logger.info("Req stop_sale_id for View: " + request.getParameter("stopSaleId"));
		
		//**Call View Service...
		StopSaleObject returnObj = new StopSaleObject(); 
		try{
			StopSaleServiceImpl ss = (StopSaleServiceImpl)ServiceLocator.locateService(StopSaleService.class);
			returnObj = ss.getStopSale(stopSaleID);
			//logger.info("test");
		}
		catch(Exception ex){
			logger.error("Error locating StopSale Service.");
		}
		
		//**Set it to the form...
		stopSaleForm.setStopSale(returnObj);
		
		return mapping.findForward("success");
	}
	

	/** 
	 * Method viewByNumber
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward stopSaleViewByNumber(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleForm stopSaleForm = (StopSaleForm) form;
		
		//**Filling the combo-boxes...
		getStopSaleDefaultLists(request);
		clearFoundBatches(request);
		
		String stopSaleNumber = request.getParameter("stopSaleNumber");
		
		logger.info("Req stop_sale_no for View: " + stopSaleNumber);
		
		//**Call View Service...
		StopSaleObject returnObj = new StopSaleObject(); 
		try{
			StopSaleServiceImpl ss = (StopSaleServiceImpl)ServiceLocator.locateService(StopSaleService.class);
			returnObj = ss.getStopSaleByNumber(stopSaleNumber);
		}
		catch(Exception ex){
			logger.error("Error locating StopSale Service.");
		}
		
		//**Set it to the form...
		stopSaleForm.setStopSale(returnObj);
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method submit
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward stopSaleSubmit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleForm stopSaleForm = (StopSaleForm) form;
		
		//**Set/ResetSelections...(to rectify checkbox error)
		resetSelections(stopSaleForm.getStopSale(), request);
		clearFoundBatches(request);
		
		//**Update Action...
		if(stopSaleForm.getStopSale().getControlNumber() != null && !stopSaleForm.getStopSale().getControlNumber().equals("")){
			
			boolean returnVal = false;
			try{
				StopSaleServiceImpl ss = (StopSaleServiceImpl)ServiceLocator.locateService(StopSaleService.class);
				returnVal = ss.updateStopSale(stopSaleForm.getStopSale());
				//logger.info("test");
			}
			catch(Exception ex){
				logger.error("Error locating StopSale Service.");
			}
			
		}
		//**Submit Action...
		else{
			String returnVal = "";
			try{
				StopSaleServiceImpl ss = (StopSaleServiceImpl)ServiceLocator.locateService(StopSaleService.class);
				returnVal = ss.insertStopSale(stopSaleForm.getStopSale());
				//logger.info("test");
			}
			catch(Exception ex){
				logger.error("Error locating StopSale Service.");
			}
			
			//**Set the stopSale ID and No...
			StringTokenizer st = new StringTokenizer(returnVal, ";");
			for(int i = 0; i < 2; i++){
				if(st.hasMoreTokens() && i == 0){
					stopSaleForm.getStopSale().setControlNumber(st.nextToken());
				}
				if(st.hasMoreTokens() && i == 1){
					stopSaleForm.getStopSale().setStopSaleID(st.nextToken());
				}			
			}
		}
		
		request.setAttribute("recordSaved", "true");
		
		return mapping.findForward("success");
	}
	
	
	/** 
	 * Method createCar
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward stopSaleCreateCar(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleForm stopSaleForm = (StopSaleForm) form;
		
		//logger.info("Create Car Method: Ctrl No=" + stopSaleForm.getStopSale().getControlNumber());
		
		clearFoundBatches(request);
		
		StopSaleObject stopSale = stopSaleForm.getStopSale();
		
		if(stopSale.getCarID() != null && !stopSale.getCarID().equals("")){
			
			request.setAttribute("duplicateCarMsg","Duplicate CAR. CAR for this record already exists. To view this CAR ");
			request.setAttribute("cparId", stopSale.getCarID());
			
			return mapping.findForward("faliure");
		}
		else{
			Cpar cparStopSaleObj = new Cpar();
		
			cparStopSaleObj.setRegion(stopSale.getRegion());
			cparStopSaleObj.setFiling_location(stopSale.getFillingLocation());
			cparStopSaleObj.setResponsible_location(stopSale.getResponsibleLocation());
			cparStopSaleObj.setIssue_year(stopSale.getSalesYear());
			cparStopSaleObj.setInvestigation_findings(stopSale.getInvestigationFindings());
			cparStopSaleObj.setRoot_cause(stopSale.getRootCause());
			cparStopSaleObj.setContainment_actions(stopSale.getContainmentAction());
			cparStopSaleObj.setLong_term_corrective_action(stopSale.getLongTermCorrectiveAction());
		
			cparStopSaleObj.setStop_sale_id(stopSale.getStopSaleID());
			cparStopSaleObj.setStop_sale_number(stopSale.getControlNumber());
			cparStopSaleObj.setGenerator("5");
		
			request.setAttribute("cparStopSaleObj", cparStopSaleObj);			
			request.setAttribute("createCAR", "true");			
			request.setAttribute("Generator", "Stop Sale");
			request.setAttribute("iscar", "true");
		
			return mapping.findForward("successCPAR");
		}
	}
	
	
	public ActionForward stopSaleFindBatches(ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response)
		throws Exception {
    	String forward="success";
    	
    	StopSaleObject stopSale  = ((StopSaleForm)form).getStopSale();
    	
    	Map batches=null;
    	
    	try {
    		ComplaintService cs = (ComplaintService)ServiceLocator.locateService(ComplaintService.class);
    		
    		if (!(request.getParameter("batchNumber").equals(null)) && !(request.getParameter("batchNumber").equals(""))){
    			
    			if(stopSale.getStopSaleID() != null && !stopSale.getStopSaleID().equals("")){
    				batches=cs.findBatches(request.getParameter("batchNumber").trim(), stopSale.getStopSaleID()); //**Stop-Sale_id...[Result Set Excludes this id]
    			}
    			else{
    				batches=cs.findBatches(request.getParameter("batchNumber").trim(), "0"); //**Any no (which will not be the id) (for new records...)
    			}
    		}
    		forward = "success";
    		request.getSession().setAttribute(request.getParameter("batchID"),batches);
    	}
		catch (Exception e){
			throw new Exception(e);
		}	    	
		
		return (mapping.findForward(forward));
    }

	/**
	 * To fill up the location, status, region list etc...
	 *
	 */
	private void getStopSaleDefaultLists(HttpServletRequest request){
		try{
			HttpSession session = request.getSession();
			session.setAttribute(ActionHelper.STATUS_LIST,null);
			if (session.getAttribute(ActionHelper.CROP_LIST) == null )
				session.setAttribute(ActionHelper.CROP_LIST,ActionHelper.getCropList());
			if (session.getAttribute(ActionHelper.LOCATION_LIST) == null )
				session.setAttribute(ActionHelper.LOCATION_LIST,ActionHelper.getLocationList());
			if (session.getAttribute(ActionHelper.QUALITY_ISSUE_LIST) == null )
				session.setAttribute(ActionHelper.QUALITY_ISSUE_LIST,ActionHelper.getQualityissueList());
			if (session.getAttribute(ActionHelper.SALES_YEAR_LIST) == null )
				session.setAttribute(ActionHelper.SALES_YEAR_LIST,ActionHelper.getSalesyearList());
			if (session.getAttribute(ActionHelper.SEED_SIZE_LIST) == null )
				session.setAttribute(ActionHelper.SEED_SIZE_LIST,ActionHelper.getSeedsizeList());
			if (session.getAttribute(ActionHelper.STATE_LIST) == null )
				session.setAttribute(ActionHelper.STATE_LIST,ActionHelper.getStatesList());
			if (session.getAttribute(ActionHelper.STATUS_LIST) == null )
				session.setAttribute(ActionHelper.STATUS_LIST,ActionHelper.getStatusList("STOP SALE"));
			if (session.getAttribute(ActionHelper.UOM_LIST) == null )
				session.setAttribute(ActionHelper.UOM_LIST,ActionHelper.getUomList());
			if (session.getAttribute(ActionHelper.VARIETY_LIST) == null )
				session.setAttribute(ActionHelper.VARIETY_LIST,ActionHelper.getVarityList());
			if (session.getAttribute(ActionHelper.REGION_LIST) == null )
				session.setAttribute(ActionHelper.REGION_LIST,ActionHelper.getRegionList());
		}
		catch(Exception ex){
			logger.error("Problem getting default lists for StopSale");
		}
	}
	
	/**
	 * To set/reset all the checkboxs again, and rectify the checkbox-reset error
	 * 
	 * @param stopSale
	 * @param request
	 */
	private void resetSelections(StopSaleObject stopSale, HttpServletRequest request){
		
		if(request.getParameterMap().get("stopSale.seedCount") != null){
			stopSale.setSeedCount(true);
		}
		else{
			stopSale.setSeedCount(false);
		}
		if(request.getParameterMap().get("stopSale.germination") != null){
			stopSale.setGermination(true);
		}
		else{
			stopSale.setGermination(false);
		}
		if(request.getParameterMap().get("stopSale.purity") != null){
			stopSale.setPurity(true);
		}
		else{
			stopSale.setPurity(false);
		}
		if(request.getParameterMap().get("stopSale.tagDate") != null){
			stopSale.setTagDate(true);
		}
		else{
			stopSale.setTagDate(false);
		}
		if(request.getParameterMap().get("stopSale.otherReason") != null){
			stopSale.setOtherReason(true);
		}
		else{
			stopSale.setOtherReason(false);
		}
		if(request.getParameterMap().get("stopSale.reLabel") != null){
			stopSale.setReLabel(true);
		}
		else{
			stopSale.setReLabel(false);
		}
		if(request.getParameterMap().get("stopSale.dump") != null){
			stopSale.setDump(true);
		}
		else{
			stopSale.setDump(false);
		}
		if(request.getParameterMap().get("stopSale.recount") != null){
			stopSale.setRecount(true);
		}
		else{
			stopSale.setRecount(false);
		}
		if(request.getParameterMap().get("stopSale.restrict") != null){
			stopSale.setRestrict(true);
		}
		else{
			stopSale.setRestrict(false);
		}
		if(request.getParameterMap().get("stopSale.otherActionFlag") != null){
			stopSale.setOtherActionFlag(true);
		}
		else{
			stopSale.setOtherActionFlag(false);
		}
	}
	
	
	private void clearFoundBatches(HttpServletRequest request){
    	HttpSession session = request.getSession();
    	session.setAttribute("batchList1",null);
    	session.setAttribute("batchList2",null);
    	session.setAttribute("batchList3",null);
    	session.setAttribute("batchList4",null);
    }
}