//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.breedingcomplaintsaudits.actions;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.*;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.AuditListForm;
import com.monsanto.wst.breedingcomplaintsaudits.actionForms.StopSaleListForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleListObject;
import com.monsanto.wst.breedingcomplaintsaudits.service.AuditService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.service.StopSaleService;

/** 
 * MyEclipse Struts
 * Creation date: 05-17-2005
 * 
 * XDoclet definition:
 * @struts:action path="/stopSaleList" name="stopSaleListForm"
 */
public class StopSaleListAction extends DispatchAction {

	static Category logger = Category.getInstance(StopSaleListAction.class.getName());
	
	private String sortCriteria;
	private String sortOrder;
	
	/** 
	 * Method display
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward display(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
		
		logger.info("SS-List-Display...");
		
		//*****List Filling...
		setRequiredList(request);
		
		return mapping.findForward("success");
	}
	
	
	/** 
	 * Method submit
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward submit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
		
		logger.info("SS-List-Submit...");
		
		//**Add selected page to session...
		String selectedPage = request.getParameter("selectedPage");
		if(selectedPage != null){	
			request.getSession().setAttribute("selectedPage", selectedPage);
		}
		else{
			request.getSession().setAttribute("selectedPage", "1");
		}

       if (request.getParameter("isPaging").toString().equals("true"))
        {
          sortCriteria = request.getParameter("sortCriteria");
          sortOrder = request.getParameter("sortOrder");
          request.getSession().setAttribute("lastStopSaleSortCriteria", sortCriteria);
          request.getSession().setAttribute("lastStopSaleSortOrder", sortOrder);

        }
       else
        {
             getSortValues(request);
        }

		LinkedHashMap stopSaleList = null;
    	float pages = 0;
    	HttpSession session = request.getSession();
    	
    	int pageNumber;
    	if (!(request.getParameter("pageNumber").equals(null)) && request.getParameter("reset").equals("false")){
    		pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
    		try {
		    	StopSaleService ss = (StopSaleService)ServiceLocator.locateService(StopSaleService.class);
		    	stopSaleList = ss.getStopSaleList(stopSaleListForm.getStopSaleFilter() ,request.getParameter("pageNumber"),Boolean.getBoolean(request.getParameter("getMax")),sortCriteria,sortOrder);

	    	}
    		catch (Exception e){
    			logger.info("Error getting 'getStopSaleList' service...");
    		}
	    	if (request.getParameter("getMax").equals("true")) {
	    		session.setAttribute("pageNumber","1");
	    	}		    		
	    	else
	    	{
	    		if (pageNumber < 11 && pageNumber > 0)
	    			session.setAttribute("pageNumber","1");
	    		else
	    			session.setAttribute("pageNumber",request.getParameter("pageNumber"));
	    	}
    	}
    	if ((stopSaleList != null) && !(stopSaleList.equals(null))){
    		pages = Float.parseFloat(stopSaleList.get("maxRows").toString());
    		stopSaleList.remove("maxRows");
	    	
    		if (stopSaleList.size() > 0 && pages > 0) {
	    		stopSaleListForm.setStopSaleMap(stopSaleList);
	    		session.setAttribute("pages",new Float(pages/10));		    		
	    	}
	    	else
	    		stopSaleListForm.setStopSaleMap(null);
    	}
    	else{
    		stopSaleListForm.setStopSaleMap(null);
    	}
    	
    	//**Reset sort-order
	///	resetSortOrder(request);
    	
		return mapping.findForward("success");
	}
	
	
	/** 
	 * Method reset
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward reset(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
		
		logger.info("SS-List-Reset...");
		
		//*****List Filling...
		setRequiredList(request);
		
		stopSaleListForm.setStopSaleFilter(new StopSaleListObject());
		stopSaleListForm.setStopSaleMap(new HashMap());
		
		//**Reset sort-order
		resetSortOrder(request);
		
		return mapping.findForward("success");
	}
	
	/** 
	 * Method sort
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward sort(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
		
		//*****LocationList Filling...
		setRequiredList(request);
		
		//**Read the request parameters...Sort Order and Criteria.
		getSortValues(request);
		
		//**Get the HashMap and sort it...
		//sortList(stopSaleListForm.getStopSaleMap(), sortCriteria, sortOrder);
		
		//**Set it back in the form...
		
		return mapping.findForward("success");
	}
	
	/**
	 * To fill all the Lists in the combo-box
	 * 
	 * @param request
	 */
	public void setRequiredList(HttpServletRequest request) {	
		
		//**To get the Location-List and Region-List in the combo-box.......................
		try{
			request.getSession().setAttribute("locationList", ActionHelper.getLocationList());
			request.getSession().setAttribute("regionList", ActionHelper.getRegionList());
			request.getSession().setAttribute("statusList", ActionHelper.getStatusList("STOP SALE"));
			request.getSession().setAttribute("cropList", ActionHelper.getCropList());
			request.getSession().setAttribute("salesyearList", ActionHelper.getSalesyearList());
		}
		catch(Exception ex){
			logger.error("Error getting the Lists: ");
			ex.printStackTrace();
		}
		//********************************************************************
	}
	
	/**
	 * To get the sortCriteria and determine the sortOrder.
	 * 
	 * @param request
	 */
	private void getSortValues(HttpServletRequest request){
		sortOrder = "asc";
		sortCriteria = request.getParameter("sortCriteria");		
		String lastSortCriteria = request.getSession().getAttribute("lastStopSaleSortCriteria") + "";
		
		if(lastSortCriteria == null){
			sortOrder = "asc";
		}
		else{	// => Not_Null
			if(sortCriteria.equalsIgnoreCase(lastSortCriteria)){
				sortOrder = request.getSession().getAttribute("lastStopSaleSortOrder") + "";		
				if(sortOrder == null){
					sortOrder = "asc";
				}
				else{	// => Not_Null
					if(sortOrder.equalsIgnoreCase("asc")){
						sortOrder = "desc";
					}
					else{
						sortOrder = "asc";
					}
				}
			}
			else{
				sortOrder = "asc";
			}
		}
		request.getSession().setAttribute("lastStopSaleSortCriteria", sortCriteria);
		request.getSession().setAttribute("lastStopSaleSortOrder", sortOrder);
				
//		logger.info("Sort Criteria = " + sortCriteria);		
//		logger.info("Sort Order = " + sortOrder);
	}
	
	/**
	 * To reset the sortOrder after every submit or refresh(display).
	 *  
	 * @param request
	 */
	private void resetSortOrder(HttpServletRequest request){
		request.getSession().setAttribute("lastStopSaleSortOrder", "desc");
	}
	
	private void sortList(LinkedHashMap hash, String sortBy, String sortOrd){
		Vector dataVector = new Vector();
	 	
	 	Iterator it = hash.keySet().iterator();
	 	
	 	while(it.hasNext()){
	 		dataVector.add((StopSaleListObject)hash.get(it.next()));
	 	}
	 	
	 	hash.clear();
	 	
	 	//**String Tokens
	 	if(sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((StopSaleListObject)a).getControlNumber() != null) ?
									((StopSaleListObject)a).getControlNumber().trim().split("-") : "".split("-");								
							String bTokens[] = (((StopSaleListObject)b).getControlNumber() != null) ?
									((StopSaleListObject)b).getControlNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal > bVal){
										return 1;
									}
									if(aVal < bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aTokens[] = (((StopSaleListObject)a).getControlNumber() != null) ?
									((StopSaleListObject)a).getControlNumber().trim().split("-") : "".split("-");								
							String bTokens[] = (((StopSaleListObject)b).getControlNumber() != null) ?
									((StopSaleListObject)b).getControlNumber().trim().split("-") : "".split("-");
							
							int noOfTokens = aTokens.length;
							
							for(int i = 0; i < noOfTokens; i++){
								
								try{
									int aVal = Integer.parseInt(aTokens[i]);
									int bVal = Integer.parseInt(bTokens[i]);
									
									if(aVal < bVal){
										return 1;
									}
									if(aVal > bVal){
										return -1;
									}
								}
								catch(Exception ex){
									//**These are probably just Strings...
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
										return 1;
									}
									if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
										return -1;
									}						
								}
								
							}
							
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**String
	 	if(sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getStatus() != null ? 
									((StopSaleListObject)a).getStatus().trim() : "";
							String bToken = ((StopSaleListObject)b).getStatus() != null ? 
									((StopSaleListObject)b).getStatus().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getStatus() != null ? 
									((StopSaleListObject)a).getStatus().trim() : "";
							String bToken = ((StopSaleListObject)b).getStatus() != null ? 
									((StopSaleListObject)b).getStatus().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	
	 	//**Strings
	 	if(sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getRegion() != null ? 
									((StopSaleListObject)a).getRegion().trim() : "";
							String bToken = ((StopSaleListObject)b).getRegion() != null ? 
									((StopSaleListObject)b).getRegion().trim() : "";
							
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getRegion() != null ? 
									((StopSaleListObject)a).getRegion().trim() : "";
							String bToken = ((StopSaleListObject)b).getRegion() != null ? 
									((StopSaleListObject)b).getRegion().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Optional, String
	 	if(sortBy.equalsIgnoreCase("responsibleLocation") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getResponsibleLocation() != null ? 
								((StopSaleListObject)a).getResponsibleLocation().trim() : "";
							String bToken = ((StopSaleListObject)b).getResponsibleLocation() != null ? 
								((StopSaleListObject)b).getResponsibleLocation().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("responsibleLocation") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getResponsibleLocation() != null ? 
								((StopSaleListObject)a).getResponsibleLocation().trim() : "";
							String bToken = ((StopSaleListObject)b).getResponsibleLocation() != null ? 
								((StopSaleListObject)b).getResponsibleLocation().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Optional, String
	 	if(sortBy.equalsIgnoreCase("crop") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getCrop() != null ? 
								((StopSaleListObject)a).getCrop().trim() : "";
							String bToken = ((StopSaleListObject)b).getCrop() != null ? 
								((StopSaleListObject)b).getCrop().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("crop") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getCrop() != null ? 
								((StopSaleListObject)a).getCrop().trim() : "";
							String bToken = ((StopSaleListObject)b).getCrop() != null ? 
								((StopSaleListObject)b).getCrop().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Optional, String
	 	if(sortBy.equalsIgnoreCase("dealer") && sortOrd.equalsIgnoreCase("asc")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getDealer() != null ? 
								((StopSaleListObject)a).getDealer().trim() : "";
							String bToken = ((StopSaleListObject)b).getDealer() != null ? 
								((StopSaleListObject)b).getDealer().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	if(sortBy.equalsIgnoreCase("dealer") && sortOrd.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
						public int compare(Object a, Object b) {
							
							String aToken = ((StopSaleListObject)a).getDealer() != null ? 
								((StopSaleListObject)a).getDealer().trim() : "";
							String bToken = ((StopSaleListObject)b).getDealer() != null ? 
								((StopSaleListObject)b).getDealer().trim() : "";
								
							if(aToken.compareToIgnoreCase(bToken) < 0 ){
								return 1;
							}
							if(aToken.compareToIgnoreCase(bToken) > 0 ){
								return -1;
							}
							return 0;
						}
				}

		 	  );
		}
	 	
	 	//**Copy dataVector to the HashMap...
	 	int size = dataVector.size();
	 	for (int i=0; i< size; i++)
	 	{	
	 		hash.put((i + ""),dataVector.get(i));
	 	}

	}
}