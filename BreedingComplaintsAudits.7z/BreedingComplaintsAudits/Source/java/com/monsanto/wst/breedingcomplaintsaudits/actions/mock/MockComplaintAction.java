/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actions.mock;

import com.monsanto.wst.breedingcomplaintsaudits.actions.ComplaintAction;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.service.ComplaintService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.service.CparService;
import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockComplaintService;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockCPARService;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;

import javax.servlet.http.HttpServletRequest;

/**
 * Filename:    $RCSfile: MockComplaintAction.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 16:00:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockComplaintAction extends ComplaintAction {

  private MockEmailUtil mockEmailUtil = new MockEmailUtil();

  public EmailUtil getEmailUtil() {
    return mockEmailUtil;
  }

  protected ComplaintService getComplaintService() throws ServiceException {
    return new MockComplaintService();
  }

  protected CparService getCPARService() throws ServiceException {
    return new MockCPARService();
  }

  protected LookUpService getLookupService() throws ServiceException {
    return new MockLookupService();
  }

  protected void getComplaintFormDefaults(HttpServletRequest request) throws Exception {
    //noop
  }
}