/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actions.mock;

import com.monsanto.wst.breedingcomplaintsaudits.actions.CparAction;
import com.monsanto.wst.breedingcomplaintsaudits.service.CparService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockCPARService;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockCparAction.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-22 22:53:11 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockCparAction extends CparAction {

  private MockEmailUtil mockEmailUtil = new MockEmailUtil();

  protected CparService getCPARService() throws ServiceException {
    return new MockCPARService();
  }

  protected LookUpService getLookupService() throws ServiceException {
    return new MockLookupService();
  }

  public EmailUtil getEmailUtil() {
    return mockEmailUtil;
  }

  protected Map getStatusList() throws Exception {
    Map statusList = new HashMap();
    statusList.put("1", "Open");
    statusList.put("2", "Close");
    return statusList;
  }

  protected void getCparFormDefaults(HttpServletRequest request) throws Exception {
    //noop
  }
}