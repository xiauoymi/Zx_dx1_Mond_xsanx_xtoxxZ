package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.actions.ActionHelper;
import com.monsanto.wst.breedingcomplaintsaudits.actions.AuditAction;
import com.monsanto.wst.breedingcomplaintsaudits.actions.mock.MockAuditAction;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockActionMapping;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockResponse;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockRequest;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockUser;
import com.monsanto.wst.breedingcomplaintsaudits.actionForms.mock.MockAuditForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.service.AuditService;
import com.monsanto.wst.breedingcomplaintsaudits.service.AuditServiceImpl;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 17, 2007
 * Time: 10:25:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class AuditAction_AT extends TestCase {
    MockRequest mockRequest;
    MockResponse mockResponse;
    private AuditObject auditObj;

    public void setup (){
        mockRequest = new MockRequest();
        mockRequest.getSession().setAttribute("user", new MockUser());
    }

    public void testUpdateAudit_RegulatoryComplianceSet_SavedInAudit() throws Exception{
        ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
        System.out.println("mockRequest = " + mockRequest);
        mockRequest = new MockRequest();
        mockRequest.getSession().setAttribute("user", new MockUser());
        MockAuditForm mockForm = new MockAuditForm (getAudit("A111-11 _10-1", "Monsanto", "Changed Overview", "10/17/2007", "Ramya", "10/17/2007", "testLocationCode_someOtherString"));
        mockRequest.getSession().setAttribute("originalAudit", mockForm);
        //mockRequest.getParameterMap();

        MockAuditAction auditAction = new MockAuditAction();
        auditAction.saveAndSubmit(new MockActionMapping(), mockForm, mockRequest, mockResponse);
        mockForm.getAuditObj().setField(true);
        auditAction.updateAction(new MockActionMapping(), mockForm, mockRequest, mockResponse);
    }

    private AuditObject getAudit(String auditNumber, String auditor, String overview, String auditDate, String preparedBy, String preparedDate, String locationCode) {
    AuditObject auditObject = new AuditObject();
    auditObject.setAuditNumber(auditNumber);
    auditObject.setAuditID("4861");
    auditObject.setLocationCode(locationCode);
    auditObject.setAuditDate(auditDate);
    auditObject.setAuditor(auditor);
    auditObject.setPreparedBy(preparedBy);
    auditObject.setPreparedDate(preparedDate);
    auditObject.setAuditOverview(overview);
    //auditObject.setField(regCompliance);
    auditObject.setFindingCarMap(new HashMap());
    auditObject.setFindingParMap(new HashMap());
    return auditObject;
  }
}
