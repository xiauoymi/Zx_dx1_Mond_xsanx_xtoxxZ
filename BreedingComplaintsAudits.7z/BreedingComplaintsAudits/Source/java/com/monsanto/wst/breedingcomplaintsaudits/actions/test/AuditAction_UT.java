/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.mock.MockAuditForm;
import com.monsanto.wst.breedingcomplaintsaudits.actions.ActionHelper;
import com.monsanto.wst.breedingcomplaintsaudits.actions.mock.MockAuditAction;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockActionMapping;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockRequest;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockResponse;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockUser;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: AuditAction_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-11-08 18:25:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class AuditAction_UT extends TestCase {
  MockRequest mockRequest;

  protected void setUp() throws IOException {
    mockRequest = new MockRequest();
    mockRequest.getSession().setAttribute("user", new MockUser());
  }

  public void testUpdateAction_SendsEmailToResponsibleLocation_IfAnyChangeIsMadeToAudit() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString"));
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.updateAction(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    assertEquals("The Audit 'A-111-564' has been modified. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            auditAction.getEmailUtil().getBody());
    assertEquals("Audit Changed: 'A-111-564' - Soybean Breeding Feedback and Audit System",
            auditAction.getEmailUtil().getSubject());
    assertEquals("testLocationEmail@monsanto.com", auditAction.getEmailUtil().getTo());
  }

  public void testUpdateAction_SendsNoEmail_IfNoChangeIsMadeToAudit() throws Exception {
      ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
      mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString"));
      MockAuditAction auditAction = new MockAuditAction();
      auditAction.updateAction(new MockActionMapping(),
              new MockAuditForm(getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
              mockRequest,
              new MockResponse());
      validateNoEmailSent(auditAction);
  }

  public void testUpdateAction_SendsNoEmail_IfResponsibleLocationEmailIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "nullLocationCode_someOtherString"));
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.updateAction(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "nullLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(auditAction);
  }

  public void testUpdateAction_SendsNoEmail_IfAdminIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = null;
    mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString"));
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.updateAction(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(auditAction);
  }

  public void testUpdateAction_SavesOriginalAuditObjectIntoSession() throws Exception {
    ActionHelper.ADMIN_EMAIL = "sbaf@monsanto.com";
    mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString"));
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.updateAction(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    AuditObject originalAudit = (AuditObject) mockRequest.getSession().getAttribute("originalAudit");
    assertNotNull(originalAudit);
    assertEquals("A-111-564", originalAudit.getAuditNumber());
    assertEquals("Changed Overview", originalAudit.getAuditOverview());
  }

  public void testViewAction_SavesOriginalAuditObjectIntoSession() throws Exception {
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.execute(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    AuditObject originalAudit = (AuditObject) mockRequest.getSession().getAttribute("originalAudit");
    assertNotNull(originalAudit);
    assertEquals("A-111-564", originalAudit.getAuditNumber());
    assertEquals("default text", originalAudit.getAuditOverview());
  }

  public void testSaveAndSubmitAction_SendsEmailToResponsibleLocation_IfNewAuditIsCreated() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.saveAndSubmit(new MockActionMapping(),
            new MockAuditForm(getAudit("", "Monsanto", "New Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    assertEquals("A new Audit 'A-111-564' has been entered into the SBAF system. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            auditAction.getEmailUtil().getBody());
    assertEquals("New Audit: 'A-111-564' - Soybean Breeding Feedback and Audit System",
            auditAction.getEmailUtil().getSubject());
    assertEquals("testLocationEmail@monsanto.com", auditAction.getEmailUtil().getTo());
  }

  public void testSaveAndUpdateAction_SavesRecentlyCreatedAuditObjectAsOriginalObjectIntoSession() throws Exception {
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.saveAndSubmit(new MockActionMapping(),
            new MockAuditForm(getAudit("", "Monsanto", "New Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    AuditObject originalAudit = (AuditObject) mockRequest.getSession().getAttribute("originalAudit");
    assertNotNull(originalAudit);
    assertEquals("A-111-564", originalAudit.getAuditNumber());
    assertEquals("New Overview", originalAudit.getAuditOverview());
  }

  public void testSaveAndSubmitAction_SendsNoEmail_IfResponsibleLocationEmailIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.saveAndSubmit(new MockActionMapping(),
            new MockAuditForm(getAudit("", "Monsanto", "New Overview", "03/15/2007", "David", "03/26/2007", "nullLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(auditAction);
  }

  public void testSaveAndSubmitAction_SendsNoEmail_IfAdminIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = null;
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.saveAndSubmit(new MockActionMapping(),
            new MockAuditForm(getAudit("", "Monsanto", "New Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    //validateNoEmailSent(auditAction);
  }

  private void validateNoEmailSent(MockAuditAction auditAction) {
    assertEquals(null, auditAction.getEmailUtil().getBody());
    assertEquals(null, auditAction.getEmailUtil().getSubject());
    assertEquals(null, auditAction.getEmailUtil().getTo());
  }


  public void testUpdateAudit_RegulatoryComplianceInformationChecked_SavedInformationInAudit() throws Exception{
     ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("originalAudit", getAudit("A-111-564", "Monsanto", "Test Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString"));
    MockAuditAction auditAction = new MockAuditAction();
    auditAction.updateAction(new MockActionMapping(),
            new MockAuditForm(getAudit("A-111-564", "Monsanto", "Changed Overview", "03/15/2007", "David", "03/26/2007", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    assertEquals("The Audit 'A-111-564' has been modified. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            auditAction.getEmailUtil().getBody());
    assertEquals("Audit Changed: 'A-111-564' - Soybean Breeding Feedback and Audit System",
            auditAction.getEmailUtil().getSubject());
    assertEquals("testLocationEmail@monsanto.com", auditAction.getEmailUtil().getTo());

  }

  private AuditObject getAudit(String auditNumber, String auditor, String overview, String auditDate, String preparedBy, String preparedDate, String locationCode) {
    AuditObject audit = new AuditObject();
    audit.setAuditNumber(auditNumber);
    audit.setAuditID("4861");
    audit.setLocationCode(locationCode);
    audit.setAuditDate(auditDate);
    audit.setAuditor(auditor);
    audit.setPreparedBy(preparedBy);
    audit.setPreparedDate(preparedDate);
    audit.setAuditOverview(overview);
    audit.setFindingCarMap(new HashMap());
    audit.setFindingParMap(new HashMap());
    audit.setRowUserID("RRMALL");
    return audit;
  }
}