package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import org.dbunit.operation.DatabaseOperation;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.ITable;
import com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl;
import com.monsanto.wst.breedingcomplaintsaudits.dao.ComplaintDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.ComplaintDAOImpl;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;

import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 22, 2007
 * Time: 10:06:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComplaintAction_AT extends BCASDatabaseTestCase{
    protected DatabaseOperation getSetUpOperation() throws Exception {
        return super.getSetUpOperation();
    }

    protected DatabaseOperation getTearDownOperation() throws Exception {
        return super.getTearDownOperation();
    }
    
    public void testFeedbackResponseTextSavedInComplaintTable() throws Exception{
       ComplaintDAO cd = new ComplaintDAOImpl();
       Complaint c = cd.getComplaint("1");
        System.out.println("c.getComplaint_id() = " + c.getComplaint_id());
       c.setContainment_actions("This is a test Feedback Response");
       cd.updateComplaint(c);
       QueryDataSet partialDataSet = new QueryDataSet(getConnection());
        partialDataSet
                .addTable("COMPLAINT_DOCUMENTATION",
                        "SELECT * from COMPLAINT_DOCUMENTATION WHERE COMPLAINT_ID=1");
        ITable table = partialDataSet.getTable("COMPLAINT_DOCUMENTATION");
        String value = (String) table.getValue(0, "CONTAINMENT_ACTION");
        assertEquals("This is a test Feedback Response", value);
    }
}
