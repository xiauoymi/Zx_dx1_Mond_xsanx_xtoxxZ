/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.mock.MockComplaintForm;
import com.monsanto.wst.breedingcomplaintsaudits.actions.ActionHelper;
import com.monsanto.wst.breedingcomplaintsaudits.actions.mock.MockComplaintAction;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockActionMapping;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockRequest;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockResponse;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockUser;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: ComplaintAction_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 16:00:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class ComplaintAction_UT extends TestCase {

  MockRequest mockRequest;

  protected void setUp() throws IOException {
    mockRequest = new MockRequest();
    mockRequest.getSession().setAttribute("user", new MockUser());
  }

  public void testComplaintSubmit_SendsEmailToResponsibleLocation_IfAnyChangeIsMade() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("complaintEdit", "true");
    mockRequest.getSession().setAttribute("originalComplaint", getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString"));
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintSubmit(
            new MockActionMapping(),
            new MockComplaintForm(getComplaint("1234", "Changed Problem Desc", "N", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    assertEquals("The Feedback '1234' has been modified. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            complaintAction.getEmailUtil().getBody());
    assertEquals("Feedback Changed: '1234' - Soybean Breeding Feedback and Audit System",
            complaintAction.getEmailUtil().getSubject());
    assertEquals("testLocationEmail@monsanto.com", complaintAction.getEmailUtil().getTo());
  }

  public void testComplaintSubmit_SendsNoEmail_IfNoChangeIsMade() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("complaintEdit", "true");
    mockRequest.getSession().setAttribute("originalComplaint", getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString"));
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintSubmit(
            new MockActionMapping(),
            new MockComplaintForm(getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(complaintAction);
  }

  public void testComplaintSubmit_SendsNoEmail_IfAdminEmailIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = null;
    mockRequest.getSession().setAttribute("complaintEdit", "true");
    mockRequest.getSession().setAttribute("originalComplaint", getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString"));
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintSubmit(
            new MockActionMapping(),
            new MockComplaintForm(getComplaint("1234", "Changed Problem Desc", "N", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(complaintAction);
  }

  public void testComplaintSubmit_SendsNoEmail_IfResponsibleLocationEmailIsAbsent() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("complaintEdit", "true");
    mockRequest.getSession().setAttribute("originalComplaint", getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString"));
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintSubmit(
            new MockActionMapping(),
            new MockComplaintForm(getComplaint("1234", "Changed Problem Desc", "N", "nullLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(complaintAction);
  }

  public void testModifiedComplaintObjectIsSavedIntoSession_AfterCompletionOfSubmitAction() throws Exception {
    ActionHelper.ADMIN_EMAIL = "admin@sbaf.com";
    mockRequest.getSession().setAttribute("complaintEdit", "true");
    mockRequest.getSession().setAttribute("originalComplaint", getComplaint("1234", "Original Problem Desc", "N", "testLocationCode_someOtherString"));
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintSubmit(
            new MockActionMapping(),
            new MockComplaintForm(getComplaint("1234", "Changed Problem Desc", "N", "testLocationCode_someOtherString")),
            mockRequest,
            new MockResponse());
    Complaint originalComplaint = (Complaint) mockRequest.getSession().getAttribute("originalComplaint");
    assertNotNull(originalComplaint);
    assertEquals("1234", originalComplaint.getComplaint_id());
    assertEquals("Changed Problem Desc", originalComplaint.getProblem_description());
  }

  public void testOriginalComplaintObjectIsSavedIntoSession_AfterCompletionOfViewOrEditAction() throws Exception {
    MockComplaintAction complaintAction = new MockComplaintAction();
    complaintAction.complaintEdit(
            new MockActionMapping(),
            new MockComplaintForm(null),
            mockRequest,
            new MockResponse());
    Complaint originalComplaint = (Complaint) mockRequest.getSession().getAttribute("originalComplaint");
    assertNotNull(originalComplaint);
    assertEquals("1234", originalComplaint.getComplaint_id());
    assertEquals("some problem", originalComplaint.getProblem_description());
  }

  private void validateNoEmailSent(MockComplaintAction complaintAction) {
    assertEquals(null, complaintAction.getEmailUtil().getBody());
    assertEquals(null, complaintAction.getEmailUtil().getSubject());
    assertEquals(null, complaintAction.getEmailUtil().getTo());
  }

  private Complaint getComplaint(String complaint_id, String problem_description, String affina_entry_flag, String responsible_plant_code) {
    Complaint complaint = new Complaint();
    complaint.setComplaint_id(complaint_id);
    complaint.setProblem_description(problem_description);
    complaint.setAffina_entry_flag(affina_entry_flag);
    complaint.setQuality_issue("testQuality");
    complaint.setStatus_id("2");
    complaint.setResponsible_plant_code(responsible_plant_code);
    return complaint;
  }
}