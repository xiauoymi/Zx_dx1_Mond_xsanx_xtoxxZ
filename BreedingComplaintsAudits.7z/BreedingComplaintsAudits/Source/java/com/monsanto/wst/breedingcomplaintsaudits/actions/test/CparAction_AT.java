package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import com.monsanto.wst.breedingcomplaintsaudits.service.CparService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceLocator;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparList;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import org.dbunit.operation.DatabaseOperation;

import java.util.LinkedHashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Nov 5, 2007
 * Time: 10:21:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class CparAction_AT extends BCASDatabaseTestCase {

    protected DatabaseOperation getSetUpOperation() throws Exception {
        return super.getSetUpOperation();
    }

    protected DatabaseOperation getTearDownOperation() throws Exception {
        return super.getTearDownOperation();
    }

    public void testGetCParsFromSystemWhenNoCriteriaSpecified() throws Exception{
        CparList cpar;
        CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
        LinkedHashMap cparList = cs.getCparsList("","","","","","","","","","","","1",true,"ROWNUM","ASC");
        assertNotNull(cparList);
        cpar = (CparList) cparList.get("1");
        assertEquals("TEST-999        - Test description                        ",cpar.getIsoStandard());
    }

    public void testEditCparGotBackFromSearchWithNoCriteriaSpecified() throws Exception{
        CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
        Cpar cpar = cs.getCpar("1");
        assertEquals("999",cpar.getIso_standard());
    }


    public void testAddtionalFieldElementIsBeingRetrievedFromDAOForASingleSearchResultWithNoOptionsSpecified() throws Exception{
        CparList cpar;
        CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
        LinkedHashMap cparList = cs.getCparsList("C-123","10/23/2005","10/27/2005","RRMALL","4","1", "123","Y","1_1","1_1", "999", "1", true,"DATE_REPORTED","ASC");
        assertNotNull(cparList);
        if ((cpar = (CparList) cparList.get("1")) != null)
         assertEquals("TEST-999        - Test description                        ",cpar.getIsoStandard());
    }

    public void testUpdateCparWithElementBeingSet() throws Exception{
        CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
        Cpar cpar = cs.getCpar("1");
        cpar.setIso_standard("96");
        cs.updateCpar(cpar);
        LinkedHashMap cparList = cs.getCparsList("C-123","10/23/2005","10/27/2005","RRMALL","4","1", "123","Y","1_1","1_1", "999", "1", true,"DATE_REPORTED","ASC");
        assertNotNull(cparList);
        assertEquals(cpar.getIso_standard(), "96");
    }
}
