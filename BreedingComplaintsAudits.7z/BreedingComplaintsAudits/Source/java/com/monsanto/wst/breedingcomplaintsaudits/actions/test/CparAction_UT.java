/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.mock.MockCPARForm;
import com.monsanto.wst.breedingcomplaintsaudits.actions.mock.MockCparAction;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockActionMapping;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockRequest;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockResponse;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockUser;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: CparAction_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-10-29 18:23:46 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class CparAction_UT extends TestCase {

  MockRequest mockRequest;

  protected void setUp() throws IOException {
    mockRequest = new MockRequest();
    mockRequest.getSession().setAttribute("user", new MockUser());
  }

  public void testCparSubmit_SendsNoEmail_IfNoChangeIsMade() throws Exception {
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    mockRequest.setParameter("statusChanged", "false");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(cparAction);
  }

  public void testCparSubmit_SendsEmailToResponsible() throws Exception {
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    mockRequest.setParameter("statusChanged", "true");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    assertEquals("testLocationEmail@monsanto.com", cparAction.getEmailUtil().getTo());
    assertEquals("The status on CAR 'TestControl#' has been set to Open. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            cparAction.getEmailUtil().getBody());
    assertEquals("CAR Status Change: 'TestControl#' - Soybean Breeding Feedback and Audit System",
            cparAction.getEmailUtil().getSubject());
  }

  public void testCparSubmit_SendsEmailToResponsibleLocationMailBox_InsteadOfInitiatedByEmail_OnPARStatusChange() throws Exception {
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    mockRequest.setParameter("statusChanged", "true");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "N", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    assertEquals("testLocationEmail@monsanto.com", cparAction.getEmailUtil().getTo());
    assertEquals("The status on PAR 'TestControl#' has been set to Open. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            cparAction.getEmailUtil().getBody());
    assertEquals("PAR Status Change: 'TestControl#' - Soybean Breeding Feedback and Audit System",
            cparAction.getEmailUtil().getSubject());
  }

  public void testCparSubmit_SendsNoEmail_IfResponsibleLocationEmailIsNullOrEmpty_ForCPARStatusChange() throws Exception {
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    MockCparAction cparAction = new MockCparAction();
    mockRequest.setParameter("statusChanged", "true");
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "Y", "testLocationCodeWithEmptyEmailList_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(cparAction);
  }

  public void testCparSubmit_SendsEmailToResponsibleLocationMailBox_OnAnyCARChange_SpecificallyInvestigationFindings() throws Exception {
    String originalInvestigationFindings = "Original Investigation Findings";
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", originalInvestigationFindings));
    String changedInvestigationFindings = "Changed Investigation Findings";
    mockRequest.setParameter("statusChanged", "false");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", changedInvestigationFindings)),
            mockRequest,
            new MockResponse());
    assertEquals("testLocationEmail@monsanto.com", cparAction.getEmailUtil().getTo());
    assertEquals("The CAR 'TestControl#' has been modified. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            cparAction.getEmailUtil().getBody());
    assertEquals("CAR Change: 'TestControl#' - Soybean Breeding Feedback and Audit System",
            cparAction.getEmailUtil().getSubject());
  }

  public void testCparSubmit_SendsEmailToResponsibleLocationMailBox_OnAnyPARChange_SpecificallyControlNumber() throws Exception {
    String originalControlNumber = "TestControl#1";
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR(originalControlNumber, "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    mockRequest.setParameter("statusChanged", "false");
    MockCparAction cparAction = new MockCparAction();
    String changedControlNumber = "TestControl#2";
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR(changedControlNumber, "N", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "2", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    assertEquals("testLocationEmail@monsanto.com", cparAction.getEmailUtil().getTo());
    assertEquals("The PAR 'TestControl#2' has been modified. " +
            "Click here to logon to the SBFAS system: http://w3d.monsanto.com/bcas" +
            "\n" + "\n" + "\n" + "\n" + "\n" +
            "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com",
            cparAction.getEmailUtil().getBody());
    assertEquals("PAR Change: 'TestControl#2' - Soybean Breeding Feedback and Audit System",
            cparAction.getEmailUtil().getSubject());
  }

  public void testCparSubmit_SendsNoEmail_IfResponsibleLocationEmailIsNullOrEmpty_ForAnyChange() throws Exception {
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", "Original Investigation Findings"));
    String changedInvestigationFindings = "Changed Investigation Findings";
    mockRequest.setParameter("statusChanged", "false");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "N", "locationCodeWithNullEmailList_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", changedInvestigationFindings)),
            mockRequest,
            new MockResponse());
    validateNoEmailSent(cparAction);
  }

  public void testOriginalCPARObjectIsSavedIntoSession_OnCompletionOfViewOrEditAction() throws Exception {
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparEdit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "N", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "2", "InProgress", "Original Investigation Findings")),
            mockRequest,
            new MockResponse());
    Cpar cpar = (Cpar) mockRequest.getSession().getAttribute("originalCpar");
    assertNotNull(cpar);
    assertEquals("Y", cpar.getCar_flag());
    assertEquals("testUser", cpar.getCreated_by());
    assertEquals("testContainmentAction", cpar.getContainment_actions());
  }

  public void testModifedCPARObjectIsSavedAsOriginalCparIntoSession_OnCompletionOfSubmitAction() throws Exception {
    String originalInvestigationFindings = "Original Investigation Findings";
    mockRequest.getSession().setAttribute("cparEdit", "true");
    mockRequest.getSession().setAttribute("originalCpar", getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", originalInvestigationFindings));
    String changedInvestigationFindings = "Changed Investigation Findings";
    mockRequest.setParameter("statusChanged", "false");
    MockCparAction cparAction = new MockCparAction();
    cparAction.cparSubmit(new MockActionMapping(),
            new MockCPARForm(getTestCPAR("TestControl#", "Y", "testLocationCode_someOtherString", "testReportInitiatorEmail@monsanto.com", "1", "InProgress", changedInvestigationFindings)),
            mockRequest,
            new MockResponse());
    Cpar cpar = (Cpar) mockRequest.getSession().getAttribute("originalCpar");
    assertNotNull(cpar);
    assertEquals("TestControl#", cpar.getControl_number());
    assertEquals("Changed Investigation Findings", cpar.getInvestigation_findings());
  }

  private void validateNoEmailSent(MockCparAction cparAction) {
    assertEquals(null, cparAction.getEmailUtil().getTo());
    assertEquals(null, cparAction.getEmailUtil().getBody());
    assertEquals(null, cparAction.getEmailUtil().getSubject());
  }

  private Cpar getTestCPAR(String controlNumber, String carFlag, String responsibleLocation, String reportInitiatorEmail, String statusId, String continualImprovements, String investigationFindings) {
    Cpar testCAR = new Cpar();
    testCAR.setControl_number(controlNumber);
    testCAR.setCar_flag(carFlag);
    testCAR.setResponsible_location(responsibleLocation);
    testCAR.setReport_initiator_email(reportInitiatorEmail);
    testCAR.setStatus_id(statusId);
    testCAR.setContinual_Improvements(continualImprovements);
    testCAR.setInvestigation_findings(investigationFindings);
    return testCAR;
  }
}