package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.XMLUtil.DOMUtil;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 17, 2007
 * Time: 11:50:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateAudit_AT extends BCASDatabaseTestCase{
    protected DatabaseOperation getSetUpOperation() throws Exception {

        return super.getSetUpOperation();
    }

     protected DatabaseOperation getTearDownOperation() throws Exception {
       return super.getTearDownOperation();
     }
    
     public void testUpdateAuditWithRegulatoryComplianceSet_UpdatesAuditAreas() throws Exception{
         AuditDAO auditDao = new AuditDAOImpl();
         AuditObject auditObject = auditDao.getAuditFromList("A111-11 _10-1");
         auditObject.setField(true);
         auditDao.updateAudit(auditObject);
         QueryDataSet partialDataSet = new QueryDataSet(getConnection());
         partialDataSet
                 .addTable("M_AUDIT_AREAS",
                         "SELECT * from M_AUDIT_AREAS WHERE AUDIT_ID=1");
         //todo modify later
         FlatXmlDataSet.write(partialDataSet,
                 new FileOutputStream("c://field.xml"));
    }
}
