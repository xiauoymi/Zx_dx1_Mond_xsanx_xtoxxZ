package com.monsanto.wst.breedingcomplaintsaudits.controller;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 23, 2006
 * Time: 12:55:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestMCASController implements UseCaseController {

  public void run(UCCHelper helper) throws IOException {
    helper.forward("/pages/contact_us.htm");
  }
}
