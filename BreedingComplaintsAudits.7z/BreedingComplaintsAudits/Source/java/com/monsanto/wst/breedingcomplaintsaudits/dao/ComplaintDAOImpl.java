/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.ComplaintFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.RowBean;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jbrahmb
 *
 *         TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style -
 *         Code Templates
 */
public class ComplaintDAOImpl extends BaseDAOImpl implements ComplaintDAO {

    static Category logger = Category.getInstance(ComplaintDAOImpl.class.getName());

    private static final String COMPLAINT_PK_SQL = "select COMPLAINT_SEQ.nextval from dual";

    private static final String UPDATE_COMPLAINT_SQL = "UPDATE COMPLAINT SET " +
        "CLAIM_NUMBER=?, STATUS_ID=?, " +
        "SALES_YR_ID=?, STATE_ID=?, " +
        "REPORT_INITIATOR=?, REPORT_DATE=?, COMMUNICATION_DATE=?, " +
        "FIELD_COMMUNICATOR=?, REPORTING_LOCATION_CODE=?, RESPONSIBLE_PLANT_CODE=?, " +
        "CROP_ID=?, PERSON_INVESTIGATING=?, SEED_SIZE_ID=?, " +
        "QTY_AFFECTED=?, QTY_UOM_ID=?, DELIVERY_INFO=?, " +
        "ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=?, ROW_TASK_ID=?, " +
        "ROW_USER_ID=?, CREATED_BY=?, REGION_ID=?, " +
        "COMPLAINT_QUALITY_ISSUE_ID=?, SETTLEMENT_VALUE=?, AFFINA_ENTRY_FLAG=?, REPORT_INITIATOR_EMAIL=?, RESPONSIBLE_LOC_ID=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String DELETE_COMPLAINT_BATCH_SQL = "DELETE FROM COMPLAINT_BATCH " +
        "WHERE COMPLAINT_ID=? ";

    private static final String UPDATE_COMPLAINT_DEALER_SQL = "UPDATE COMPLAINT_DEALER SET " +
        "DEALER_NAME=?, DEALER_ADDRESS=?, " +
        "DEALER_CITY=?, DEALER_STATE_ID=?, DEALER_PHONE=?, " +
        "DEALER_BA_ID=?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
        "ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String UPDATE_COMPLAINT_DISEASE_SQL = "UPDATE COMPLAINT_DISEASE_INFO SET " +
        "DISEASE_OBSERVED=?, HERBICIDE_TYPE_CY=?,	" +
        "HERBICIDE_RATE_CY=?, HERBICIDE_TIMING_CY=?, HERBICIDE_TYPE_PY=?, " +
        "HERBICIDE_RATE_PY=?, HERBICIDE_TIMING_PY=?, ROW_USER_ID=?, " +
        "ROW_TASK_ID=?, ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String UPDATE_COMPLAINT_DOCUMENTATION_SQL = "UPDATE COMPLAINT_DOCUMENTATION SET " +
        "PROBLEM_DESCRIPTION=?, CONTAINMENT_ACTION=?, " +
        "ROOT_CAUSE=?, LONG_TERM_CORRECTION_ACTION=?, ROW_USER_ID=?, " +
        "ROW_TASK_ID=?, ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String UPDATE_CPAR_TO_COMPLAINT_DOCUMENTATION_SQL = "UPDATE COMPLAINT_DOCUMENTATION SET " +
        "ROW_USER_ID=?, ROW_TASK_ID=?, ROW_MODIFY_DATE=? ";

    private static final String UPDATE_COMPLAINT_GROWER_SQL = "UPDATE COMPLAINT_GROWER SET " +
        "GROWER_NAME=?, GROWER_ADDRESS=?, " +
        "GROWER_CITY=?, GROWER_STATE_ID=?, GROWER_PHONE=?, " +
        "GROWER_BA_ID=?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
        "ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String UPDATE_COMPLAINT_INSECT_SQL = "UPDATE COMPLAINT_INSECT_INFO SET " +
        "INSECTS_OBSERVED=?, INSECTICIDE_TYPE_CY=?, " +
        "INSECTICIDE_RATE_CY=?, INSECTICIDE_TIMING_CY=?, INSECTICIDE_TYPE_PY=?, " +
        "INSECTICIDE_RATE_PY=?, INSECTICIDE_TIMING_PY=?, ROW_USER_ID=?, " +
        "ROW_TASK_ID=?, ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String DELETE_COMPLAINT_ISSUES_SQL = "DELETE FROM COMPLAINT_ISSUES " +
        "WHERE COMPLAINT_ID=?";

    private static final String UPDATE_COMPLAINT_PLANTING_SQL = "UPDATE COMPLAINT_PLANTING_INFO SET " +
        "TOTAL_ACRES=?, AFFECTED_ACRES=?, " +
        "TECHNOLOGY=?, PLANTING_DATE=?, PLANTER_TYPE=?, " +
        "PLANTER_DEPTH=?, POPULATION_PLANTED=?, POPULATION_OBSERVED=?, " +
        "TILLAGE=?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
        "ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=? " +
        "WHERE COMPLAINT_ID=?";

    private static final String DELETE_COMPLAINT_VARIETY_SQL = "DELETE FROM COMPLAINT_VARIETY " +
        "WHERE COMPLAINT_ID=?";

    private static final String COMPLAINT_SQL = "INSERT INTO COMPLAINT (" +
        "COMPLAINT_ID, CLAIM_NUMBER, STATUS_ID, " +
        "SALES_YR_ID, STATE_ID, " +
        "REPORT_INITIATOR, REPORT_DATE, COMMUNICATION_DATE, " +
        "FIELD_COMMUNICATOR, REPORTING_LOCATION_CODE, RESPONSIBLE_PLANT_CODE, " +
        "CROP_ID, PERSON_INVESTIGATING, SEED_SIZE_ID, " +
        "QTY_AFFECTED, QTY_UOM_ID, DELIVERY_INFO, " +
        "ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROW_TASK_ID, " +
        "ROW_USER_ID, CREATED_BY, REGION_ID," +
        "COMPLAINT_QUALITY_ISSUE_ID, SETTLEMENT_VALUE, AFFINA_ENTRY_FLAG, REPORT_INITIATOR_EMAIL, RESPONSIBLE_LOC_ID) " +
        "VALUES (? ,? ,? ," +
        "? ,? ," +
        "? ,? ,? ," +
        "? ,? ,? ," +
        "? ,? ,? ," +
        "? ,? ,? ," +
        "? ,? ,? ," +
        "? ,? ,? ," +
        "?, ?, ?, ?, ?)";

    private static final String COMPLAINT_BATCH_SQL = "INSERT INTO COMPLAINT_BATCH (" +
        "BATCH_NUMBER, COMPLAINT_ID)" +
        " VALUES ( ?, ?)";

    private static final String COMPLAINT_DEALER_SQL = "INSERT INTO COMPLAINT_DEALER ( " +
        "COMPLAINT_ID, DEALER_NAME, DEALER_ADDRESS, " +
        "DEALER_CITY, DEALER_STATE_ID, DEALER_PHONE, " +
        "DEALER_BA_ID, ROW_USER_ID, ROW_TASK_ID, " +
        "ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?,? )";

    private static final String COMPLAINT_DISEASE_SQL = "INSERT INTO COMPLAINT_DISEASE_INFO ( " +
        "COMPLAINT_ID, DISEASE_OBSERVED, HERBICIDE_TYPE_CY,	" +
        "HERBICIDE_RATE_CY, HERBICIDE_TIMING_CY, HERBICIDE_TYPE_PY, " +
        "HERBICIDE_RATE_PY, HERBICIDE_TIMING_PY, ROW_USER_ID, " +
        "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?,? )";

    private static final String COMPLAINT_DOCUMENTATION_SQL = "INSERT INTO COMPLAINT_DOCUMENTATION ( " +
        "COMPLAINT_ID, PROBLEM_DESCRIPTION, CONTAINMENT_ACTION, " +
        "ROOT_CAUSE, LONG_TERM_CORRECTION_ACTION, ROW_USER_ID, " +
        "ROW_TASK_ID, ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?,? )";

    private static final String COMPLAINT_GROWER_SQL = "INSERT INTO COMPLAINT_GROWER ( " +
        "COMPLAINT_ID, GROWER_NAME, GROWER_ADDRESS, " +
        "GROWER_CITY, GROWER_STATE_ID, GROWER_PHONE, " +
        "GROWER_BA_ID, ROW_USER_ID, ROW_TASK_ID, " +
        "ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?)";

    private static final String COMPLAINT_INSECT_SQL = "INSERT INTO COMPLAINT_INSECT_INFO ( " +
        "COMPLAINT_ID, INSECTS_OBSERVED, INSECTICIDE_TYPE_CY, " +
        "INSECTICIDE_RATE_CY, INSECTICIDE_TIMING_CY, INSECTICIDE_TYPE_PY, " +
        "INSECTICIDE_RATE_PY, INSECTICIDE_TIMING_PY, ROW_USER_ID, " +
        "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?)";

    private static final String COMPLAINT_ISSUES_SQL = "INSERT INTO COMPLAINT_ISSUES ( " +
        "COMPLAINT_ISSUE_ID, COMPLAINT_ID, ROW_USER_ID, " +
        "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?)";

    private static final String COMPLAINT_PLANTING_SQL = "INSERT INTO COMPLAINT_PLANTING_INFO ( " +
        "COMPLAINT_ID, TOTAL_ACRES, AFFECTED_ACRES, " +
        "TECHNOLOGY, PLANTING_DATE, PLANTER_TYPE, " +
        "PLANTER_DEPTH, POPULATION_PLANTED, POPULATION_OBSERVED, " +
        "TILLAGE, ROW_USER_ID, ROW_TASK_ID, " +
        "ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
        "VALUES ( ?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?, ?, " +
        "?, ?)";

    private static final String COMPLAINT_VARIETY_SQL = "INSERT INTO COMPLAINT_VARIETY ( " +
        "COMPLAINT_ID, VARIETY_ID) " +
        "VALUES ( ?, ?)";

    private static final String GET_COMPLAINT_MAIN = "SELECT * FROM COMPLAINT C, RESPONSIBLE_LOCATION RL WHERE COMPLAINT_ID=? AND RL.RESPONSIBLE_LOC_ID=C.RESPONSIBLE_LOC_ID";
    private static final String GET_COMPLAINT_DEALER = "SELECT * FROM COMPLAINT_DEALER WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_GROWER = "SELECT * FROM COMPLAINT_GROWER WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_DISEASE_INFO = "SELECT * FROM COMPLAINT_DISEASE_INFO WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_DOCUMENTATION = "SELECT * FROM COMPLAINT_DOCUMENTATION WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_INSECT_INFO = "SELECT * FROM COMPLAINT_INSECT_INFO WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_PLANTING_INFO = "SELECT * FROM COMPLAINT_PLANTING_INFO WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_VARIETY = "SELECT * FROM COMPLAINT_VARIETY WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_BATCH = "SELECT * FROM COMPLAINT_BATCH WHERE COMPLAINT_ID=?";
    private static final String GET_COMPLAINT_ISSUES = "SELECT * FROM COMPLAINT_ISSUES WHERE COMPLAINT_ID=?";

    private static final String GET_COMPLAINTS_LIST =

        "SELECT RANKING, COMPLAINT_ID, CLAIM_NUMBER, " +
            "SALES_YR, " +
            "STATUS_DESCRIPTION, REPORT_INITIATOR, ROW_ENTRY_DATE, " +
            "REGION_DESCRIPTION FROM  " +
            " (SELECT ROWNUM as RANKING, COMPLAINT_ID, CLAIM_NUMBER, " +
            "SALES_YR, " +
            "STATUS_DESCRIPTION, REPORT_INITIATOR, ROW_ENTRY_DATE, " +
            "REGION_DESCRIPTION FROM " +
            "(SELECT  C.COMPLAINT_ID, CLAIM_NUMBER, " +
            "(SELECT Y.SHORT_DESCRIPTION FROM YEAR_REF Y WHERE Y.YEAR_ID=C.SALES_YR_ID) SALES_YR," +
            "(SELECT S.STATUS_DESCRIPTION FROM STATUS_REF S WHERE S.STATUS_ID=C.STATUS_ID) STATUS_DESCRIPTION, " +
            "REPORT_INITIATOR, ROW_ENTRY_DATE, " +
            "(SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=C.REGION_ID) REGION_DESCRIPTION " +
            "FROM COMPLAINT C ";
    private static final String GET_COUNT_COMPLAINTS_LIST = "SELECT COUNT(C.COMPLAINT_ID) FROM COMPLAINT C ";

    private static final String FIND_BATCHES = "SELECT A.ID,A.TYPE FROM " +
        "(SELECT C.BATCH_NUMBER BATCH_NUMBER,C.COMPLAINT_ID ID,'Complaint' TYPE " +
        "FROM COMPLAINT_BATCH C UNION ALL " +
        "SELECT S.BATCH_NUMBER BATCH_NUMBER,S.STOP_SALE_ID ID,'Stop Sale' TYPE " +
        "FROM STOP_SALE_BATCH S) A WHERE upper(A.BATCH_NUMBER)=upper('";

    private static final String GET_STOP_SALE_NUMBER_FROM_ID =
        "SELECT S.CONTROL_NUMBER STOP_SALE_NUMBER FROM STOP_SALE S WHERE S.STOP_SALE_ID = ?";

    private static final String GET_COMPLAINT_REPORT =
	    "SELECT " +
	        "COMPLAINT.COMPLAINT_ID CONTROL_NUMBER, "+
	        "COMPLAINT.CLAIM_NUMBER,  "+
	        "STATUS_REF.STATUS_DESCRIPTION, "+
	        "YEAR_REF.SHORT_DESCRIPTION SALES_YR, "+
	        "COMPLAINT_STATE.STATE_ABBR    STATE,  "+
	        "COMPLAINT.REPORT_INITIATOR INITIATED_BY,  "+
	        "COMPLAINT.REPORT_DATE CREATED_DATE,  "+
	        "COMPLAINT.COMMUNICATION_DATE,  "+
	        "COMPLAINT.FIELD_COMMUNICATOR,  "+
	        "COMPLAINT.REPORTING_LOCATION_CODE, "+
	        "REPORTING.LOCATION_SHORT_NAME    REPORTING_LOCATION, "+
	        "COMPLAINT.RESPONSIBLE_PLANT_CODE, "+
		    "(SELECT CONCAT(L.LOCATION_SHORT_NAME, CONCAT(' ', CONCAT(FR.FUNCTION_CODE, CONCAT(' ', RESPONSIBLE.PROGRAM_CODE)))) "+
		    "FROM LOCATION_REF L, FUNCTION_REF FR  "+
		    "WHERE RESPONSIBLE.LOCATION_CODE = L.LOCATION_CODE AND FR.FUNCTION_ID = RESPONSIBLE.FUNCTION_ID AND RESPONSIBLE.RESPONSIBLE_LOC_ID = COMPLAINT.RESPONSIBLE_LOC_ID) RESPONSIBLE_LOCATION, "+
	        "CROP_REF.SHORT_DESCRIPTION CROP,  "+
	        "COMPLAINT.PERSON_INVESTIGATING,  "+
	        "SEED_SIZE_REF.DESCRIPTION    SEED_SIZE, "+
	        "COMPLAINT.QTY_AFFECTED,  "+
	        "QTY_UOM_REF.QTY_DESCRIPTION    QTY_UOM, "+
	        "COMPLAINT.DELIVERY_INFO,  "+
	        "COMPLAINT.CREATED_BY,  "+
	        "REGION_REF.REGION_DESCRIPTION REGION, "+
	        "COMPLAINT_QUALITY_ISSUE_REF.COMPLAINT_QUALITY_ISSUE, "+
	        "COMPLAINT.SETTLEMENT_VALUE, "+
	        "COMPLAINT_BATCH.BATCH_NUMBER,  "+
	        "COMPLAINT_DOCUMENTATION.PROBLEM_DESCRIPTION, "+
	        "COMPLAINT_DOCUMENTATION.CONTAINMENT_ACTION,  "+
	        "COMPLAINT_DOCUMENTATION.ROOT_CAUSE,  "+
	        "COMPLAINT_DOCUMENTATION.LONG_TERM_CORRECTION_ACTION, "+
	        "COMPLAINT_DISEASE_INFO.DISEASE_OBSERVED,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_TYPE_CY,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_RATE_CY,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_TIMING_CY,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_TYPE_PY,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_RATE_PY,  "+
	        "COMPLAINT_DISEASE_INFO.HERBICIDE_TIMING_PY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTS_OBSERVED,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_TYPE_CY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_RATE_CY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_TIMING_CY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_TYPE_PY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_RATE_PY,  "+
	        "COMPLAINT_INSECT_INFO.INSECTICIDE_TIMING_PY,  "+
	        "COMPLAINT_PLANTING_INFO.TOTAL_ACRES,  "+
	        "COMPLAINT_PLANTING_INFO.AFFECTED_ACRES,  "+
	        "COMPLAINT_PLANTING_INFO.TECHNOLOGY,  "+
	        "COMPLAINT_PLANTING_INFO.PLANTING_DATE,  "+
	        "COMPLAINT_PLANTING_INFO.PLANTER_TYPE,  "+
	        "COMPLAINT_PLANTING_INFO.PLANTER_DEPTH,  "+
	        "COMPLAINT_PLANTING_INFO.POPULATION_PLANTED, "+
	        "COMPLAINT_PLANTING_INFO.POPULATION_OBSERVED,  "+
	        "COMPLAINT_PLANTING_INFO.TILLAGE,  "+
	        "COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_DESCRIPTION, "+
	        "COMPLAINT_ISSUE_TYPE_REF.DESCRIPTION    ISSUE_TYPE, "+
	        "COMPLAINT_GROWER.GROWER_NAME,  "+
	        "COMPLAINT_GROWER.GROWER_ADDRESS,  "+
	        "COMPLAINT_GROWER.GROWER_CITY,  "+
	        "COMPLAINT_GROWER.GROWER_PHONE,  "+
	        "COMPLAINT_GROWER.GROWER_BA_ID,  "+
	        "COMPLAINT_DEALER.DEALER_NAME,  "+
	        "COMPLAINT_DEALER.DEALER_ADDRESS,  "+
	        "COMPLAINT_DEALER.DEALER_CITY,  "+
	        "COMPLAINT_DEALER.DEALER_PHONE,  "+
	        "COMPLAINT_DEALER.DEALER_BA_ID,  "+
	        "VARIETY_REF.DESCRIPTION    VARIETY  "+
	        "FROM  "+
	        "COMPLAINT, COMPLAINT_BATCH, COMPLAINT_DEALER, COMPLAINT_DISEASE_INFO, COMPLAINT_DOCUMENTATION, "+
	        "COMPLAINT_GROWER, COMPLAINT_INSECT_INFO, COMPLAINT_ISSUES, COMPLAINT_PLANTING_INFO,  "+
	        "COMPLAINT_VARIETY, STATUS_REF, YEAR_REF, LOCATION_REF REPORTING, RESPONSIBLE_LOCATION RESPONSIBLE, "+
	        "STATE_REF COMPLAINT_STATE, CROP_REF, SEED_SIZE_REF, QTY_UOM_REF, REGION_REF,  "+
	        "COMPLAINT_ISSUE_REF, COMPLAINT_ISSUE_TYPE_REF, VARIETY_REF, COMPLAINT_QUALITY_ISSUE_REF "+
	        "WHERE   "+
	        "STATUS_REF.STATUS_ID = COMPLAINT.STATUS_ID AND "+
	        "YEAR_REF.YEAR_ID = COMPLAINT.SALES_YR_ID    AND  "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_BATCH.COMPLAINT_ID(+)    AND "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_DEALER.COMPLAINT_ID(+)    AND  "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_DISEASE_INFO.COMPLAINT_ID(+)    AND "+
	        "COMPLAINT.COMPLAINT_ID =    COMPLAINT_DOCUMENTATION.COMPLAINT_ID(+)    AND "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_GROWER.COMPLAINT_ID(+)    AND  "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_INSECT_INFO.COMPLAINT_ID(+)    AND "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_ISSUES.COMPLAINT_ID(+)    AND  "+
	        "COMPLAINT.COMPLAINT_ID =    COMPLAINT_PLANTING_INFO.COMPLAINT_ID(+)    AND "+
	        "COMPLAINT.COMPLAINT_ID = COMPLAINT_VARIETY.COMPLAINT_ID(+)    AND  "+
	        "REPORTING.LOCATION_CODE(+) = COMPLAINT.REPORTING_LOCATION_CODE    AND  "+
	        "RESPONSIBLE.RESPONSIBLE_LOC_ID(+) = COMPLAINT.RESPONSIBLE_LOC_ID    AND "+
	        "COMPLAINT_STATE.STATE_ID(+) = COMPLAINT.STATE_ID    AND  "+
	        "CROP_REF.CROP_ID(+) = COMPLAINT.CROP_ID    AND  "+
	        "SEED_SIZE_REF.SEED_SIZE_ID(+) = COMPLAINT.SEED_SIZE_ID    AND "+
	        "QTY_UOM_REF.QTY_UOM_ID(+) = COMPLAINT.QTY_UOM_ID    AND  "+
	        "REGION_REF.REGION_ID(+) = COMPLAINT.REGION_ID    AND  "+
	        "COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_ID(+) =    COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID   AND "+
	        "COMPLAINT_ISSUE_TYPE_REF.COMPLAINT_ISSUE_TYPE_ID(+) =    COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_TYPE_ID  AND "+
	        "COMPLAINT_QUALITY_ISSUE_REF.COMPLAINT_QUALITY_ISSUE_ID(+) =    COMPLAINT.COMPLAINT_QUALITY_ISSUE_ID  AND  "+
	        "VARIETY_REF.VARIETY_ID(+) = COMPLAINT_VARIETY.VARIETY_ID ";

    //TODO Remove this Mapping after the checkboxes are stored in value object as List or Map and rendered dynamically on page.
    private static Map complaintIssuesMap = new HashMap();

    static {
        complaintIssuesMap.put("driver_performance", "1");
        complaintIssuesMap.put("packaging_condition", "2");
        complaintIssuesMap.put("incorrect_shipment", "3");
        complaintIssuesMap.put("tag_error", "4");
        complaintIssuesMap.put("delivery_other", "5");
        complaintIssuesMap.put("seed_appearance", "6");
        complaintIssuesMap.put("seed_variability", "7");
        complaintIssuesMap.put("emergence_concerns", "8");
        complaintIssuesMap.put("product_purity", "9");
        complaintIssuesMap.put("early_season_other", "10");
        complaintIssuesMap.put("growth_development", "11");
        complaintIssuesMap.put("herbicide_injury", "12");
        complaintIssuesMap.put("disease_development", "13");
        complaintIssuesMap.put("insect_outbreaks_injury", "14");
        complaintIssuesMap.put("pollination_problems", "15");
        complaintIssuesMap.put("stress_susceptability", "16");
        complaintIssuesMap.put("midseason_other", "17");
        complaintIssuesMap.put("lateseason_disease_development", "18");
        complaintIssuesMap.put("insect_development", "19");
        complaintIssuesMap.put("seed_development", "20");
        complaintIssuesMap.put("noncompetitive_yield", "21");
        complaintIssuesMap.put("maintaining_seed_until_harvest", "22");
        complaintIssuesMap.put("maturity_drydown", "23");
        complaintIssuesMap.put("late_season_other", "24");
    }

    //TODO Remove this Mapping after the checkboxes are stored in value object as List or Map and rendered dynamically on page.
    private static Map complaintIssuesReverseMap = new HashMap();

    static {
        complaintIssuesReverseMap.put("1", "driver_performance");
        complaintIssuesReverseMap.put("2", "packaging_condition");
        complaintIssuesReverseMap.put("3", "incorrect_shipment");
        complaintIssuesReverseMap.put("4", "tag_error");
        complaintIssuesReverseMap.put("5", "delivery_other");
        complaintIssuesReverseMap.put("6", "seed_appearance");
        complaintIssuesReverseMap.put("7", "seed_variability");
        complaintIssuesReverseMap.put("8", "emergence_concerns");
        complaintIssuesReverseMap.put("9", "product_purity");
        complaintIssuesReverseMap.put("10", "early_season_other");
        complaintIssuesReverseMap.put("11", "growth_development");
        complaintIssuesReverseMap.put("12", "herbicide_injury");
        complaintIssuesReverseMap.put("13", "disease_development");
        complaintIssuesReverseMap.put("14", "insect_outbreaks_injury");
        complaintIssuesReverseMap.put("15", "pollination_problems");
        complaintIssuesReverseMap.put("16", "stress_susceptability");
        complaintIssuesReverseMap.put("17", "midseason_other");
        complaintIssuesReverseMap.put("18", "lateseason_disease_development");
        complaintIssuesReverseMap.put("19", "insect_development");
        complaintIssuesReverseMap.put("20", "seed_development");
        complaintIssuesReverseMap.put("21", "noncompetitive_yield");
        complaintIssuesReverseMap.put("22", "maintaining_seed_until_harvest");
        complaintIssuesReverseMap.put("23", "maturity_drydown");
        complaintIssuesReverseMap.put("24", "late_season_other");
    }

    private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    private static final String COMPLAINT_DOCUMENTATION_EXISTS = "SELECT (1) FROM COMPLAINT_DOCUMENTATION WHERE COMPLAINT_ID = ?";

    /**
     * Constructor. Initialize the datasource.
     *
     */
    public ComplaintDAOImpl() throws DAOException {

    }

    public String getComplaintPK() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(COMPLAINT_PK_SQL);
            rs = ps.executeQuery();
            rs.next();
            String pk = rs.getString(1);
            return pk;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private void insertUpdateComplaint(Complaint c, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        int parameterIndx = 1;
        try {
            conn = getConnection();
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_SQL);
                ps.setLong(28, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_SQL);
                ps.setLong(parameterIndx, Long.parseLong(c.getComplaint_id()));
                parameterIndx++;
            }

            ps.setString(parameterIndx, c.getClaim_number());
            ps.setLong(parameterIndx + 1, Long.parseLong(c.getStatus_id()));
            ps.setLong(parameterIndx + 2, Long.parseLong(c.getSales_year_id()));
            ps.setInt(parameterIndx + 3, Integer.parseInt(c.getState_id()));
            ps.setString(parameterIndx + 4, c.getReport_initiator());
	        //checked
            ps.setDate(parameterIndx + 5, new Date(new java.util.Date(c.getReport_date()).getTime()));
            if (!(c.getCommunication_date() == null) && !(c.getCommunication_date().equals(""))) {
                ps.setDate(parameterIndx + 6, new Date(new java.util.Date(c.getCommunication_date()).getTime()));
            }
            else {
                ps.setDate(parameterIndx + 6, null);
            }

            ps.setString(parameterIndx + 7, c.getField_communicator());
            ps.setString(parameterIndx + 8, c.getReporting_location_code());
	        String plant_code = c.getResponsible_plant_code();
	        String[] plants = plant_code.split("_");
            ps.setString(parameterIndx + 9, plants[0]);
            if (!(c.getCrop_id() == null) && !(c.getCrop_id().equals(""))) {
                ps.setInt(parameterIndx + 10, Integer.parseInt(c.getCrop_id()));
            }
            else {
                ps.setNull(parameterIndx + 10, Types.INTEGER);
            }
            ps.setString(parameterIndx + 11, c.getPerson_investigating());
            if (!(c.getSeed_size_id() == null) && !(c.getSeed_size_id().equals(""))) {
                ps.setLong(parameterIndx + 12, Long.parseLong(c.getSeed_size_id()));
            }
            else {
                ps.setNull(parameterIndx + 12, Types.INTEGER);
            }
            if (!(c.getQuantity_affected() == null) && !(c.getQuantity_affected().equals(""))) {
                ps.setLong(parameterIndx + 13, Long.parseLong(c.getQuantity_affected()));
            }
            else {
                ps.setNull(parameterIndx + 13, Types.INTEGER);
            }
            if (!(c.getQuantity_uom_id() == null) && !(c.getQuantity_uom_id().equals(""))) {
                ps.setLong(parameterIndx + 14, Long.parseLong(c.getQuantity_uom_id()));
            }
            else {
                ps.setNull(parameterIndx + 14, Types.INTEGER);
            }
            ps.setString(parameterIndx + 15, c.getDelivery_info());
            ps.setDate(parameterIndx + 17, new Date(new java.util.Date().getTime()));
            if (isUpdate) {
                ps.setDate(parameterIndx + 16, new Date(new java.util.Date(c.getRow_entry_date()).getTime()));
                if (c.getAffina_entry_flag().equals("Y")) {
                    ps.setString(parameterIndx + 18, "AFFINA EDIT");
                    setQualityIssue(c, ps, parameterIndx);
                }
                else if (c.getAffina_entry_flag().equals("N")) {
                    ps.setString(parameterIndx + 18, "COMPLAINT EDIT");
                    setQualityIssue(c, ps, parameterIndx);
                }
            }
            else if (!isUpdate) {
                ps.setDate(parameterIndx + 16, new Date(new java.util.Date().getTime()));
                if (c.getAffina_entry_flag().equals("Y")) {
                    ps.setString(parameterIndx + 18, "AFFINA ENTRY");
                    ps.setNull(parameterIndx + 22, Types.INTEGER);
                }
                else if (c.getAffina_entry_flag().equals("N")) {
                    ps.setString(parameterIndx + 18, "COMPLAINT ENTRY");
                    setQualityIssue(c, ps, parameterIndx);
                }
            }
            ps.setString(parameterIndx + 19, c.getRow_user_id());
            ps.setString(parameterIndx + 20, c.getCreated_by());
            ps.setInt(parameterIndx + 21, Integer.parseInt(c.getRegion_id()));

            if (!(c.getSettlement_value().trim().equals(""))) {
                ps.setFloat(parameterIndx + 23, Float.parseFloat(c.getSettlement_value().trim()));
            }
            else {
                ps.setFloat(parameterIndx + 23, Types.INTEGER);
            }

            ps.setString(parameterIndx + 24, c.getAffina_entry_flag());
            ps.setString(parameterIndx + 25, c.getReport_initiator_email());
	        ps.setString(parameterIndx + 26, plants[1]);



            if (ps.executeUpdate() > 0) {


                this.insertComplaint_Grower(c, conn, isUpdate);

                this.insertComplaint_Dealer(c, conn, isUpdate);
                this.insertComplaint_Disease(c, conn, isUpdate);
                this.insertComplaint_Documentation(c, conn, isUpdate);
                this.insertComplaint_Insect(c, conn, isUpdate);
                this.insertComplaint_Planting(c, conn, isUpdate);
                if (isUpdate) {
                    this.deleteBatches(c.getComplaint_id(), conn);
                    this.deleteVarieties(c.getComplaint_id(), conn);
                    this.deleteIssues(c.getComplaint_id(), conn);
                    conn.commit();
                }
                this.insertComplaint_Batch(c, conn);
                this.insertComplaint_Variety(c, conn);
                this.insertComplaint_Issues(c, conn);



            }

            conn.commit();
            System.out.println("I Row Inserted/Updated !");
        }
        catch (Exception e) {
            try {
                conn.rollback();
            }
            catch (Exception ex) {
                throw new DAOException(ex);
            }
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private void setQualityIssue(Complaint c, PreparedStatement ps, int parameterIndx) throws SQLException {
        if (!(c.getQuality_issue().equals(null)) && !(c.getQuality_issue().trim().equals(""))) {
            ps.setInt(parameterIndx + 22, Integer.parseInt(c.getQuality_issue()));
        }
        else {
            ps.setNull(parameterIndx + 22, Types.INTEGER);
        }
    }

    /**
     * @param complaint_id
     */
    private void deleteIssues(String complaint_id, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        try {
            ps = conn.prepareStatement(DELETE_COMPLAINT_ISSUES_SQL);
            ps.setLong(1, Long.parseLong(complaint_id));
            rows = ps.executeUpdate();
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * @param complaint_id
     */
    private void deleteVarieties(String complaint_id, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        try {
            ps = conn.prepareStatement(DELETE_COMPLAINT_VARIETY_SQL);
            ps.setLong(1, Long.parseLong(complaint_id));
            rows = ps.executeUpdate();
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * @param complaint_id
     */
    private void deleteBatches(String complaint_id, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        try {
            ps = conn.prepareStatement(DELETE_COMPLAINT_BATCH_SQL);
            ps.setLong(1, Long.parseLong(complaint_id));
            rows = ps.executeUpdate();
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    public void insertComplaint(Complaint c) throws DAOException {
        insertUpdateComplaint(c, false);
    }

    public void updateComplaint(Complaint c) throws DAOException {
        insertUpdateComplaint(c, true);
    }

    public void deleteComplaint(Complaint c) throws DAOException {
    }

    public Map findBatches(String batch_number, String complaint_stopsale_id) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(FIND_BATCHES + batch_number + "') and A.ID <> " + complaint_stopsale_id);

            System.out.println(FIND_BATCHES + batch_number + "') and A.ID <> " + complaint_stopsale_id);

            rs = ps.executeQuery();
            if (rs != null && !(rs.equals(null))) {
                result = new HashMap();
            }
            while (rs.next()) {
                String stopSaleNumber = "";

                //**Changes Start here (for displaying the Stop_Sale_Number)
                if (rs.getString("TYPE").equals("Stop Sale")) {
                    try {
                        PreparedStatement ps2 = null;
                        ResultSet rs2 = null;
                        ps2 = conn.prepareStatement(GET_STOP_SALE_NUMBER_FROM_ID);
                        ps2.setString(1, rs.getString("ID"));

                        rs2 = ps2.executeQuery();

                        while (rs2.next()) {
                            stopSaleNumber = rs2.getString("STOP_SALE_NUMBER");
                        }
                    }
                    catch (Exception ex) {
                        throw new DAOException(ex);
                    }

                    result.put(rs.getString("ID"), stopSaleNumber + " - " + rs.getString("TYPE"));
                }
                else {
                    result.put(rs.getString("ID"), rs.getString("ID") + " - " + rs.getString("TYPE"));
                }

                //**Changes End...
                //result.put(rs.getString("ID"), rs.getString("ID") + " - " + rs.getString("TYPE"));
            }
            return result;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    public LinkedHashMap getComplaintsList(String controlNumber, String createDate, String initiatedBy, String salesYr,
                                           String status, String region, String claimNumber, String reportingLocation,
                                           String responsibleLocation, String crop, String batch, String state,
                                           String variety, String qualityIssue, String intPage, boolean getMax,
                                           String sortCrit, String sortOrd) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause;
        List paramList = new ArrayList();
        LinkedHashMap complaints = null;
        try {
            int Page = Integer.parseInt(intPage);
            if (!(controlNumber == null) && !(controlNumber.equals(""))) {
                paramList.add("controlNumber");
            }
            if (!(createDate == null) && !(createDate.equals(""))) {
                paramList.add("createDate");
            }
            if (!(initiatedBy == null) && !(initiatedBy.equals(""))) {
                paramList.add("initiatedBy");
            }
/*
            if (!(salesYr == null) && !(salesYr.equals("")) && !(salesYr.equals("0"))) {
                paramList.add("salesYr");
            }
*/
            if (!(status == null) && !(status.equals("")) && !(status.equals("0"))) {
                paramList.add("status");
            }
            if (!(region == null) && !(region.equals("")) && !(region.equals("0"))) {
                paramList.add("region");
            }
/*
            if (!(claimNumber == null) && !(claimNumber.equals(""))) {
                paramList.add("claimNumber");
            }
*/
            if (!(reportingLocation == null) && !(reportingLocation.equals(""))) {
                paramList.add("reportingLocation");
            }
            if (!(responsibleLocation == null) && !(responsibleLocation.equals(""))) {
                paramList.add("responsibleLocation");
            }
/*
            if (!(crop == null) && !(crop.equals(""))) {
                paramList.add("crop");
            }
*/

/*
            if (!(batch == null) && !(batch.equals(""))) {
                paramList.add("batch");
            }
*/
/*
            if (!(state == null) && !(state.equals(""))) {
                paramList.add("state");
            }
*/
            if (!(variety == null) && !(variety.equals("")) && !(variety.equals("0"))) {
                paramList.add("variety");
            }
            if (!(qualityIssue == null) && !(qualityIssue.equals("")) && !(qualityIssue.equals("0"))) {
                paramList.add("qualityIssue");
            }

            conn = getConnection();
            whereClause = new StringBuffer();

            for (int i = 0; i < paramList.size(); i++) {
                if (paramList.get(i).equals("batch")) {
                    whereClause.append(" , COMPLAINT_BATCH CB  ");
                }
                if (paramList.get(i).equals("variety")) {
                    whereClause.append(" , COMPLAINT_VARIETY CV  ");
                }

            }

            if (paramList.size() > 0) {
                whereClause.append("WHERE ");
            }
            for (int i = 0; i < paramList.size(); i++) {
                if (paramList.get(i).equals("controlNumber")) {
                    whereClause.append("C.COMPLAINT_ID=" + controlNumber);
                }
                if (paramList.get(i).equals("createDate")) {
                    whereClause.append("C.ROW_ENTRY_DATE=to_Date('" + createDate + "','MM-dd-YYYY')");
                }
                if (paramList.get(i).equals("initiatedBy")) {
                    whereClause.append("upper(C.REPORT_INITIATOR) like upper('" + initiatedBy + "%')");
                }
                if (paramList.get(i).equals("salesYr")) {
                    whereClause.append("C.SALES_YR_ID=" + salesYr);
                }
                if (paramList.get(i).equals("status")) {
                    whereClause.append("C.STATUS_ID=" + status);
                }
                if (paramList.get(i).equals("region")) {
                    whereClause.append("C.REGION_ID=" + region);
                }
                if (paramList.get(i).equals("claimNumber")) {
                    whereClause.append("C.CLAIM_NUMBER='" + claimNumber + "'");
                }
                if (paramList.get(i).equals("reportingLocation")) {
                    whereClause.append("C.REPORTING_LOCATION_CODE='" + reportingLocation + "'");
                }
                if (paramList.get(i).equals("responsibleLocation")) {
	                String [] plant_codes = responsibleLocation.split("_");
	                if(plant_codes[1] != null){
	                    whereClause.append("C.RESPONSIBLE_LOC_ID='" + plant_codes[1] + "'");
	                }
                }
                if (paramList.get(i).equals("crop")) {
                    whereClause.append("C.CROP_ID='" + crop + "'");
                }

                if (paramList.get(i).equals("state")) {
                    whereClause.append("C.STATE_ID='" + state + "'");
                }
                if (paramList.get(i).equals("batch")) {
                    whereClause.append(
                        "CB.COMPLAINT_ID = C.COMPLAINT_ID and upper(CB.BATCH_NUMBER) Like upper('" + batch + "%')");
                }
                if (paramList.get(i).equals("variety")) {
                    whereClause.append("CV.COMPLAINT_ID = C.COMPLAINT_ID and CV.VARIETY_ID = " + variety);
                }
                if (paramList.get(i).equals("qualityIssue")) {
                    whereClause.append(" C.COMPLAINT_QUALITY_ISSUE_ID = '" + qualityIssue + "'");
                }

                if (i < paramList.size() - 1) {
                    whereClause.append(" and ");
                }
            }

            System.out.println(GET_COUNT_COMPLAINTS_LIST + whereClause.toString());
            ps = conn.prepareStatement(GET_COUNT_COMPLAINTS_LIST + whereClause.toString());
            rs = ps.executeQuery();
            if (rs.next()) {
                complaints = new LinkedHashMap();
                complaints.put("maxRows", rs.getString(1));
            }
            //This appends to second query GET_COMPLAINTS_LIST
            if (sortCrit.equals("ROW_ENTRY_DATE") || sortCrit.equals("COMPLAINT_ID") || sortCrit.equals("SALES_YR")) {
                whereClause.append(" ORDER BY " + sortCrit + " " + sortOrd + " ))  WHERE RANKING BETWEEN " +
                    ((Page * 10) - 9) + " and " + Page * 10);
            }
            else {
                whereClause.append(" ORDER BY Lower(" + sortCrit + ") " + sortOrd + " ))  WHERE RANKING BETWEEN " +
                    ((Page * 10) - 9) + " and " + Page * 10);
            }

            ps = conn.prepareStatement(GET_COMPLAINTS_LIST + whereClause.toString());
            System.out.println(GET_COMPLAINTS_LIST + whereClause.toString());
            rs = ps.executeQuery();
            while (rs.next()) {
                List row = new ArrayList(6);
                row.add(rs.getString("COMPLAINT_ID"));
                row.add(sdf.format(rs.getDate("ROW_ENTRY_DATE")));
                row.add(rs.getString("REPORT_INITIATOR"));
//                row.add(rs.getString("SALES_YR"));
                row.add(rs.getString("STATUS_DESCRIPTION"));
                row.add(rs.getString("REGION_DESCRIPTION"));
//                row.add(rs.getString("CLAIM_NUMBER"));
                complaints.put(rs.getString("COMPLAINT_ID"), row);
            }
            return complaints;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    public Complaint getComplaint(String complaint_id) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Complaint c = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(GET_COMPLAINT_MAIN);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            c = new Complaint();
            while (rs.next()) {
                setComplaintObjectWithResultsFromQuery(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_DEALER);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintDealerInformationFromDealerQuery(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_GROWER);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintGrowerInformationFromGrowerQuery(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_DISEASE_INFO);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintDiseaseInformationFromDiseaseQuery(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_INSECT_INFO);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintInsectInfoFromInsectQuery(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_DOCUMENTATION);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintDocumentation(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_PLANTING_INFO);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setComplaintPlantingInformation(c, rs);
            }
            ps = conn.prepareStatement(GET_COMPLAINT_BATCH);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            int countBatches = 1;
            while (rs.next()) {
                setComplaintBatchInformation(countBatches, c, rs);
                countBatches++;
            }
            ps = conn.prepareStatement(GET_COMPLAINT_VARIETY);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            int countVarieties = 1;
            while (rs.next()) {
                setComplaintVariety(countVarieties, c, rs);
                countVarieties++;
            }
            ps = conn.prepareStatement(GET_COMPLAINT_ISSUES);
            ps.setString(1, complaint_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                String issueName = complaintIssuesReverseMap.get(rs.getString("COMPLAINT_ISSUE_ID")).toString();
                setComplaintIssues(issueName, c);
            }
            return c;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private void setComplaintIssues(String issueName, Complaint c) {
        if (issueName.equals("driver_performance")) {
            c.setDriver_performance(true);
        }
        if (issueName.equals("packaging_condition")) {
            c.setPackaging_condition(true);
        }
        if (issueName.equals("incorrect_shipment")) {
            c.setIncorrect_shipment(true);
        }
        if (issueName.equals("tag_error")) {
            c.setTag_error(true);
        }
        if (issueName.equals("delivery_other")) {
            c.setDelivery_other(true);
        }
        if (issueName.equals("seed_appearance")) {
            c.setSeed_appearance(true);
        }
        if (issueName.equals("seed_variability")) {
            c.setSeed_variability(true);
        }
        if (issueName.equals("emergence_concerns")) {
            c.setEmergence_concerns(true);
        }
        if (issueName.equals("product_purity")) {
            c.setProduct_purity(true);
        }
        if (issueName.equals("early_season_other")) {
            c.setEarly_season_other(true);
        }
        if (issueName.equals("growth_development")) {
            c.setGrowth_development(true);
        }
        if (issueName.equals("herbicide_injury")) {
            c.setHerbicide_injury(true);
        }
        if (issueName.equals("disease_development")) {
            c.setDisease_development(true);
        }
        if (issueName.equals("insect_outbreaks_injury")) {
            c.setInsect_outbreaks_injury(true);
        }
        if (issueName.equals("pollination_problems")) {
            c.setPollination_problems(true);
        }
        if (issueName.equals("stress_susceptability")) {
            c.setStress_susceptability(true);
        }
        if (issueName.equals("midseason_other")) {
            c.setMidseason_other(true);
        }
        if (issueName.equals("lateseason_disease_development")) {
            c.setLateseason_disease_development(true);
        }
        if (issueName.equals("insect_development")) {
            c.setInsect_development(true);
        }
        if (issueName.equals("seed_development")) {
            c.setSeed_development(true);
        }
        if (issueName.equals("noncompetitive_yield")) {
            c.setNoncompetitive_yield(true);
        }
        if (issueName.equals("maintaining_seed_until_harvest")) {
            c.setMaintaining_seed_until_harvest(true);
        }
        if (issueName.equals("maturity_drydown")) {
            c.setMaturity_drydown(true);
        }
        if (issueName.equals("late_season_other")) {
            c.setLate_season_other(true);
        }
    }

    private void setComplaintVariety(int countVarieties, Complaint c, ResultSet rs) throws SQLException {
        if (countVarieties == 1) {
            c.setVariety_one(rs.getString("VARIETY_ID"));
        }
        if (countVarieties == 2) {
            c.setVariety_two(rs.getString("VARIETY_ID"));
        }
        if (countVarieties == 3) {
            c.setVariety_three(rs.getString("VARIETY_ID"));
        }
        if (countVarieties == 4) {
            c.setVariety_four(rs.getString("VARIETY_ID"));
        }
    }

    private void setComplaintBatchInformation(int countBatches, Complaint c, ResultSet rs) throws SQLException {
        if (countBatches == 1) {
            c.setBatch_one(rs.getString("BATCH_NUMBER"));
        }
        if (countBatches == 2) {
            c.setBatch_two(rs.getString("BATCH_NUMBER"));
        }
        if (countBatches == 3) {
            c.setBatch_three(rs.getString("BATCH_NUMBER"));
        }
        if (countBatches == 4) {
            c.setBatch_four(rs.getString("BATCH_NUMBER"));
        }
    }

    private void setComplaintPlantingInformation(Complaint c, ResultSet rs) throws SQLException {
        c.setTotal_acres(rs.getString("TOTAL_ACRES"));
        c.setAffected_areas(rs.getString("AFFECTED_ACRES"));
        c.setTechnology(rs.getString("TECHNOLOGY"));
        c.setPlanting_date(getDateFormat(rs.getDate("PLANTING_DATE")));
        c.setPlanter_type(rs.getString("PLANTER_TYPE"));
        c.setPlanter_depth(rs.getString("PLANTER_DEPTH"));
        c.setPopulation_planted(rs.getString("POPULATION_PLANTED"));
        c.setPopulation_observed(rs.getString("POPULATION_OBSERVED"));
        c.setTillage(rs.getString("TILLAGE"));
    }

    private void setComplaintDocumentation(Complaint c, ResultSet rs) throws SQLException {
        c.setProblem_description(rs.getString("PROBLEM_DESCRIPTION"));
        c.setContainment_actions(rs.getString("CONTAINMENT_ACTION"));
        c.setRoot_cause(rs.getString("ROOT_CAUSE"));
        c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
    }

    private void setComplaintInsectInfoFromInsectQuery(Complaint c, ResultSet rs) throws SQLException {
        c.setInsects_observed(rs.getString("INSECTS_OBSERVED"));
        c.setInsecticide_type_current(rs.getString("INSECTICIDE_TYPE_CY"));
        c.setInsecticide_rate_current(rs.getString("INSECTICIDE_RATE_CY"));
        c.setInsecticide_timming_current(rs.getString("INSECTICIDE_TIMING_CY"));
        c.setInsecticide_type_prev(rs.getString("INSECTICIDE_TYPE_PY"));
        c.setInsecticide_rate_prev(rs.getString("INSECTICIDE_RATE_PY"));
        c.setInsecticide_timming_prev(rs.getString("INSECTICIDE_TIMING_PY"));
    }

    private void setComplaintDiseaseInformationFromDiseaseQuery(Complaint c, ResultSet rs) throws SQLException {
        c.setDisease_observed(rs.getString("DISEASE_OBSERVED"));
        c.setHerbicide_type_current(rs.getString("HERBICIDE_TYPE_CY"));
        c.setHerbicide_rate_current(rs.getString("HERBICIDE_RATE_CY"));
        c.setHerbicide_timming_current(rs.getString("HERBICIDE_TIMING_CY"));
        c.setHerbicide_type_prev(rs.getString("HERBICIDE_TYPE_PY"));
        c.setHerbicide_rate_prev(rs.getString("HERBICIDE_RATE_PY"));
        c.setHerbicide_timming_prev(rs.getString("HERBICIDE_TIMING_PY"));
    }

    private void setComplaintGrowerInformationFromGrowerQuery(Complaint c, ResultSet rs) throws SQLException {
        c.setGrower_name(rs.getString("GROWER_NAME"));
        c.setGrower_address(rs.getString("GROWER_ADDRESS"));
        c.setGrower_city(rs.getString("GROWER_CITY"));
        c.setGrower_state(rs.getString("GROWER_STATE_ID"));
        if (!(rs.getString("GROWER_PHONE") == null)) {
            c.setGrower_phone(rs.getString("GROWER_PHONE").trim());
        }
        else {
            c.setGrower_phone(rs.getString("GROWER_PHONE"));
        }
        c.setGrower_ba_id(rs.getString("GROWER_BA_ID"));
    }

    private void setComplaintDealerInformationFromDealerQuery(Complaint c, ResultSet rs) throws SQLException {
        c.setDealer_name(rs.getString("DEALER_NAME"));
        c.setDealer_address(rs.getString("DEALER_ADDRESS"));
        c.setDealer_city(rs.getString("DEALER_CITY"));
        c.setDealer_state(rs.getString("DEALER_STATE_ID"));
        if (!(rs.getString("DEALER_PHONE") == null)) {
            c.setDealer_phone(rs.getString("DEALER_PHONE").trim());
        }
        else {
            c.setDealer_phone(rs.getString("DEALER_PHONE"));
        }
        c.setDealer_ba_id(rs.getString("DEALER_BA_ID"));
    }

    private void setComplaintObjectWithResultsFromQuery(Complaint c, ResultSet rs) throws SQLException {
        c.setComplaint_id(rs.getString("COMPLAINT_ID"));
        c.setClaim_number(rs.getString("CLAIM_NUMBER"));
        c.setStatus_id(rs.getString("STATUS_ID"));
        c.setSales_year_id(rs.getString("SALES_YR_ID"));
        c.setState_id(rs.getString("STATE_ID"));
        c.setReport_initiator(rs.getString("REPORT_INITIATOR"));
        c.setReport_date(getDateFormat(rs.getDate("REPORT_DATE")));
        c.setCommunication_date(getDateFormat(rs.getDate("COMMUNICATION_DATE")));
        c.setField_communicator(rs.getString("FIELD_COMMUNICATOR"));
        c.setReporting_location_code(rs.getString("REPORTING_LOCATION_CODE"));
        c.setResponsible_plant_code(rs.getString("LOCATION_CODE")+"_"+rs.getString("RESPONSIBLE_LOC_ID"));
        c.setCrop_id(rs.getString("CROP_ID"));
        c.setPerson_investigating(rs.getString("PERSON_INVESTIGATING"));
        c.setSeed_size_id(rs.getString("SEED_SIZE_ID"));
        c.setQuantity_affected(rs.getString("QTY_AFFECTED"));
        c.setQuantity_uom_id(rs.getString("QTY_UOM_ID"));
        c.setDelivery_info(rs.getString("DELIVERY_INFO"));
        c.setCreated_by(rs.getString("CREATED_BY"));
        c.setRegion_id(rs.getString("REGION_ID"));
        c.setQuality_issue(rs.getString("COMPLAINT_QUALITY_ISSUE_ID"));
        c.setRow_entry_date(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
        c.setRegion_id(rs.getString("REGION_ID"));
        c.setSettlement_value(rs.getString("SETTLEMENT_VALUE"));
        c.setAffina_entry_flag(rs.getString("AFFINA_ENTRY_FLAG"));
        c.setReport_initiator_email(rs.getString("REPORT_INITIATOR_EMAIL"));
        c.setRow_user_id(rs.getString("ROW_USER_ID"));
    }

    public HashMap getComplaintReport(ComplaintFilter complaintFilter) throws DAOException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause = new StringBuffer();
        HashMap hash = new HashMap();

        try {
            conn = getConnection();

            if ((complaintFilter.getControlNumber() != null) && !(complaintFilter.getControlNumber().equals(""))) {
                whereClause
                    .append(" AND COMPLAINT.COMPLAINT_ID = '" + complaintFilter.getControlNumber().trim() + "' ");
            }
            if ((complaintFilter.getCreatedDate() != null) && !(complaintFilter.getCreatedDate().equals(""))) {
                whereClause.append(" AND COMPLAINT.REPORT_DATE = TO_DATE('" +
                    getDateFormat(new Date(new java.util.Date(complaintFilter.getCreatedDate()).getTime())) +
                    "', 'MM/DD/YYYY') ");
            }
            if ((complaintFilter.getInitiatedBy() != null) && !(complaintFilter.getInitiatedBy().equals(""))) {
                whereClause.append(" AND UPPER(COMPLAINT.REPORT_INITIATOR) lIKE UPPER('" +
                    complaintFilter.getInitiatedBy().trim() + "%') ");
            }
            if ((complaintFilter.getClaimNumber() != null) && !(complaintFilter.getClaimNumber().equals(""))) {
                whereClause.append(" AND UPPER(COMPLAINT.CLAIM_NUMBER) LIKE UPPER('" +
                    complaintFilter.getClaimNumber().trim() + "%') ");
            }
            if ((complaintFilter.getBatch() != null) && !(complaintFilter.getBatch().equals(""))) {
                whereClause.append(
                    " AND UPPER(COMPLAINT_BATCH.BATCH_NUMBER) = UPPER('" + complaintFilter.getBatch().trim() + "') ");
            }
            if ((complaintFilter.getReportingLocation() != null) && (complaintFilter.getReportingLocation().length > 0))
            {
                whereClause.append(getSelectedFields(" AND COMPLAINT.REPORTING_LOCATION_CODE IN ",
                    complaintFilter.getReportingLocation()));
            }
            if ((complaintFilter.getResponsibleLocation() != null) && (complaintFilter.getResponsibleLocation().length > 0)) {
	            String [] plant_codes = complaintFilter.getResponsibleLocation();
	            String [] plants = new String[plant_codes.length];
	            String [] code;
	            boolean bflag = false;

	            for(int i=0; i < plant_codes.length; i++){
		            code =  plant_codes[i].split("_");
		            if(code.length == 2){
				        plants[i] = new String(code[1]);
				        bflag = true;
		            }
	            }
	            if(bflag)
                    whereClause.append(getSelectedFields(" AND COMPLAINT.RESPONSIBLE_LOC_ID IN ", plants));
            }

            if ((complaintFilter.getStatus() != null) && (complaintFilter.getStatus().length > 0)) {
                whereClause.append(getSelectedFields(" AND COMPLAINT.STATUS_ID IN ", complaintFilter.getStatus()));
            }
            if ((complaintFilter.getRegion() != null) && (complaintFilter.getRegion().length > 0)) {
                whereClause.append(getSelectedFields(" AND COMPLAINT.REGION_ID IN ", complaintFilter.getRegion()));
            }
            if ((complaintFilter.getCrop() != null) && (complaintFilter.getCrop().length > 0)) {
                whereClause.append(getSelectedFields(" AND COMPLAINT.CROP_ID IN ", complaintFilter.getCrop()));
            }
            if ((complaintFilter.getSalesYear() != null) && (complaintFilter.getSalesYear().length > 0)) {
                whereClause.append(getSelectedFields(" AND COMPLAINT.SALES_YR_ID IN ", complaintFilter.getSalesYear()));
            }
            if ((complaintFilter.getVariety() != null) && (complaintFilter.getVariety().length > 0)) {
                whereClause
                    .append(getSelectedFields(" AND COMPLAINT_VARIETY.VARIETY_ID IN ", complaintFilter.getVariety()));
            }
            if ((complaintFilter.getQualityIssue() != null) && (complaintFilter.getQualityIssue().length > 0)) {
                whereClause.append(getSelectedFields(" AND COMPLAINT.COMPLAINT_QUALITY_ISSUE_ID IN ",
                    complaintFilter.getQualityIssue()));
            }

            whereClause.append(getComplaintIssues(complaintFilter));

            whereClause.append(" ORDER BY COMPLAINT.COMPLAINT_ID ASC ");

            logger.info(GET_COMPLAINT_REPORT + whereClause.toString());

            ps = conn.prepareStatement(GET_COMPLAINT_REPORT + whereClause.toString());

            rs = ps.executeQuery();

            int rowCount = 0;

            while (rs.next()) {

                rowCount++;

                //** Fill in the RowBean Object...
                RowBean rowBean = new RowBean();

                //**Oracle-Database Error Solution...
                //The "LONG" and "LONGRAW" fields needs to be accessed first to avoid the
                //"java.sql.SQLException: Stream has already been closed" error.

                String deliveryInfo = "";
                deliveryInfo = rs.getString("DELIVERY_INFO");
                if (deliveryInfo == null) {
                    deliveryInfo = "-";
                }

                rowBean.setCol1(rs.getInt("CONTROL_NUMBER") + "");

/*
                if (rs.getString("CLAIM_NUMBER") != null && !(rs.getString("CLAIM_NUMBER").trim().equals("")))
                {    //**This can be null...
                    rowBean.setCol2(rs.getString("CLAIM_NUMBER"));
                }
                else {
                    rowBean.setCol2("-");
                }
*/
               if (rs.getString("STATUS_DESCRIPTION") != null &&
                    !(rs.getString("STATUS_DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol2(rs.getString("STATUS_DESCRIPTION"));
                }
                else {
                    rowBean.setCol2(rs.getString("-"));
                }
/*
                if (rs.getString("SALES_YR") != null && !(rs.getString("SALES_YR").trim().equals(""))) {
                    rowBean.setCol4(rs.getString("SALES_YR"));
                }
                else {
                    rowBean.setCol4("-");
                }
                if (rs.getString("STATE") != null && !(rs.getString("STATE").trim().equals(""))) {
                    rowBean.setCol5(rs.getString("STATE"));
                }
                else {
                    rowBean.setCol5("-");
                }
*/
                if (rs.getString("INITIATED_BY") != null && !(rs.getString("INITIATED_BY").trim().equals(""))) {
                    rowBean.setCol3(rs.getString("INITIATED_BY"));
                }
                else {
                    rowBean.setCol3("-");
                }
                if (rs.getDate("CREATED_DATE") != null) {
                    rowBean.setCol4(getDateFormat(rs.getDate("CREATED_DATE")));
                }
                else {
                    rowBean.setCol4("-");
                }
                if (rs.getDate("COMMUNICATION_DATE") != null) {
                    rowBean.setCol5(getDateFormat(rs.getDate("COMMUNICATION_DATE")));
                }
                else {
                    rowBean.setCol5("-");
                }
                if (rs.getString("FIELD_COMMUNICATOR") != null &&
                    !(rs.getString("FIELD_COMMUNICATOR").trim().equals(""))) {
                    rowBean.setCol6(rs.getString("FIELD_COMMUNICATOR"));
                }
                else {
                    rowBean.setCol6("-");
                }
                if (rs.getString("REPORTING_LOCATION_CODE") != null &&
                    !(rs.getString("REPORTING_LOCATION_CODE").trim().equals(""))) {
                    rowBean.setCol7(rs.getString("REPORTING_LOCATION_CODE"));
                }
                else {
                    rowBean.setCol7("-");
                }
//checked
                if (rs.getString("REPORTING_LOCATION") != null &&
                    !(rs.getString("REPORTING_LOCATION").trim().equals(""))) {
                    rowBean.setCol8(rs.getString("REPORTING_LOCATION"));
                }
                else {
                    rowBean.setCol8("-");
                }
                if (rs.getString("RESPONSIBLE_PLANT_CODE") != null &&
                    !(rs.getString("RESPONSIBLE_PLANT_CODE").trim().equals(""))) {
                    rowBean.setCol9(rs.getString("RESPONSIBLE_PLANT_CODE"));
                }
                else {
                    rowBean.setCol9("-");
                }
                if (rs.getString("RESPONSIBLE_LOCATION") != null &&
                    !(rs.getString("RESPONSIBLE_LOCATION").trim().equals(""))) {
                    rowBean.setCol10(rs.getString("RESPONSIBLE_LOCATION"));
                }
                else {
                    rowBean.setCol10("-");
                }
/*
                if (rs.getString("CROP") != null && !(rs.getString("CROP").trim().equals(""))) {
                    rowBean.setCol14(rs.getString("CROP"));
                }
                else {
                    rowBean.setCol14("-");
                }
*/
                if (rs.getString("PERSON_INVESTIGATING") != null &&
                    !(rs.getString("PERSON_INVESTIGATING").trim().equals(""))) {
                    rowBean.setCol11(rs.getString("PERSON_INVESTIGATING"));
                }
                else {
                    rowBean.setCol11("-");
                }
/*
                if (rs.getString("SEED_SIZE") != null && !(rs.getString("SEED_SIZE").trim().equals(""))) {
                    rowBean.setCol16(rs.getString("SEED_SIZE"));
                }
                else {
                    rowBean.setCol16("-");
                }
                if (rs.getString("QTY_AFFECTED") != null && !(rs.getString("QTY_AFFECTED").trim().equals(""))) {
                    rowBean.setCol17(rs.getString("QTY_AFFECTED"));
                }
                else {
                    rowBean.setCol17("-");
                }
                if (rs.getString("QTY_UOM") != null && !(rs.getString("QTY_UOM").trim().equals(""))) {
                    rowBean.setCol18(rs.getString("QTY_UOM"));
                }
                else {
                    rowBean.setCol18("-");
                }
*/

/*
                rowBean.setCol12(deliveryInfo);
*/

                if (rs.getString("CREATED_BY") != null && !(rs.getString("CREATED_BY").trim().equals(""))) {
                    rowBean.setCol12(rs.getString("CREATED_BY"));
                }
                else {
                    rowBean.setCol12("-");
                }

                if (rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))) {
                    rowBean.setCol13(rs.getString("REGION"));
                }
                else {
                    rowBean.setCol13("-");
                }
                if (rs.getString("COMPLAINT_QUALITY_ISSUE") != null &&
                    !(rs.getString("COMPLAINT_QUALITY_ISSUE").trim().equals(""))) {
                    rowBean.setCol14(rs.getString("COMPLAINT_QUALITY_ISSUE"));
                }
                else {
                    rowBean.setCol14("-");
                }
/*
                if (rs.getString("SETTLEMENT_VALUE") != null && !(rs.getString("SETTLEMENT_VALUE").trim().equals(""))) {
                    rowBean.setCol23(rs.getString("SETTLEMENT_VALUE"));
                }
                else {
                    rowBean.setCol23("-");
                }
*/
/*
                if (rs.getString("BATCH_NUMBER") != null && !(rs.getString("BATCH_NUMBER").trim().equals(""))) {
                    rowBean.setCol16(rs.getString("BATCH_NUMBER"));
                }
                else {
                    rowBean.setCol16("-");
                }
*/
                if (rs.getString("PROBLEM_DESCRIPTION") != null &&
                    !(rs.getString("PROBLEM_DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol15(rs.getString("PROBLEM_DESCRIPTION"));
                }
                else {
                    rowBean.setCol15("-");
                }
/*
                if (rs.getString("CONTAINMENT_ACTION") != null &&
                    !(rs.getString("CONTAINMENT_ACTION").trim().equals(""))) {
                    rowBean.setCol26(rs.getString("CONTAINMENT_ACTION"));
                }
                else {
                    rowBean.setCol26("-");
                }
                if (rs.getString("ROOT_CAUSE") != null && !(rs.getString("ROOT_CAUSE").trim().equals(""))) {
                    rowBean.setCol27(rs.getString("ROOT_CAUSE"));
                }
                else {
                    rowBean.setCol27("-");
                }
                if (rs.getString("LONG_TERM_CORRECTION_ACTION") != null &&
                    !(rs.getString("LONG_TERM_CORRECTION_ACTION").trim().equals(""))) {
                    rowBean.setCol28(rs.getString("LONG_TERM_CORRECTION_ACTION"));
                }
                else {
                    rowBean.setCol28("-");
                }
                if (rs.getString("DISEASE_OBSERVED") != null && !(rs.getString("DISEASE_OBSERVED").trim().equals(""))) {
                    rowBean.setCol29(rs.getString("DISEASE_OBSERVED"));
                }
                else {
                    rowBean.setCol29("-");
                }
                if (rs.getString("HERBICIDE_TYPE_CY") != null && !(rs.getString("HERBICIDE_TYPE_CY").trim().equals("")))
                {
                    rowBean.setCol30(rs.getString("HERBICIDE_TYPE_CY"));
                }
                else {
                    rowBean.setCol30("-");
                }

                if (rs.getString("HERBICIDE_RATE_CY") != null && !(rs.getString("HERBICIDE_RATE_CY").trim().equals("")))
                {
                    rowBean.setCol31(rs.getString("HERBICIDE_RATE_CY"));
                }
                else {
                    rowBean.setCol31("-");
                }
                if (rs.getString("HERBICIDE_TIMING_CY") != null &&
                    !(rs.getString("HERBICIDE_TIMING_CY").trim().equals(""))) {
                    rowBean.setCol32(rs.getString("HERBICIDE_TIMING_CY"));
                }
                else {
                    rowBean.setCol32("-");
                }
//checked
                if (rs.getString("HERBICIDE_TYPE_PY") != null && !(rs.getString("HERBICIDE_TYPE_PY").trim().equals("")))
                {
                    rowBean.setCol33(rs.getString("HERBICIDE_TYPE_PY"));
                }
                else {
                    rowBean.setCol33("-");
                }
                if (rs.getString("HERBICIDE_RATE_PY") != null && !(rs.getString("HERBICIDE_RATE_PY").trim().equals("")))
                {
                    rowBean.setCol34(rs.getString("HERBICIDE_RATE_PY"));
                }
                else {
                    rowBean.setCol34("-");
                }
                if (rs.getString("HERBICIDE_TIMING_PY") != null &&
                    !(rs.getString("HERBICIDE_TIMING_PY").trim().equals(""))) {
                    rowBean.setCol35(rs.getString("HERBICIDE_TIMING_PY"));
                }
                else {
                    rowBean.setCol35("-");
                }
                if (rs.getString("INSECTS_OBSERVED") != null && !(rs.getString("INSECTS_OBSERVED").trim().equals(""))) {
                    rowBean.setCol36(rs.getString("INSECTS_OBSERVED"));
                }
                else {
                    rowBean.setCol36("-");
                }
                if (rs.getString("INSECTICIDE_TYPE_CY") != null &&
                    !(rs.getString("INSECTICIDE_TYPE_CY").trim().equals(""))) {
                    rowBean.setCol37(rs.getString("INSECTICIDE_TYPE_CY"));
                }
                else {
                    rowBean.setCol37("-");
                }
                if (rs.getString("INSECTICIDE_RATE_CY") != null &&
                    !(rs.getString("INSECTICIDE_RATE_CY").trim().equals(""))) {
                    rowBean.setCol38(rs.getString("INSECTICIDE_RATE_CY"));
                }
                else {
                    rowBean.setCol38("-");
                }
                if (rs.getString("INSECTICIDE_TIMING_CY") != null &&
                    !(rs.getString("INSECTICIDE_TIMING_CY").trim().equals(""))) {
                    rowBean.setCol39(rs.getString("INSECTICIDE_TIMING_CY"));
                }
                else {
                    rowBean.setCol39("-");
                }
                if (rs.getString("INSECTICIDE_TYPE_PY") != null &&
                    !(rs.getString("INSECTICIDE_TYPE_PY").trim().equals(""))) {
                    rowBean.setCol40(rs.getString("INSECTICIDE_TYPE_PY"));
                }
                else {
                    rowBean.setCol40("-");
                }

                if (rs.getString("INSECTICIDE_RATE_PY") != null &&
                    !(rs.getString("INSECTICIDE_RATE_PY").trim().equals(""))) {
                    rowBean.setCol41(rs.getString("INSECTICIDE_RATE_PY"));
                }
                else {
                    rowBean.setCol41("-");
                }
                if (rs.getString("INSECTICIDE_TIMING_PY") != null &&
                    !(rs.getString("INSECTICIDE_TIMING_PY").trim().equals(""))) {
                    rowBean.setCol42(rs.getString("INSECTICIDE_TIMING_PY"));
                }
                else {
                    rowBean.setCol42("-");
                }
                if (rs.getString("TOTAL_ACRES") != null && !(rs.getString("TOTAL_ACRES").trim().equals(""))) {
                    rowBean.setCol43(rs.getString("TOTAL_ACRES"));
                }
                else {
                    rowBean.setCol43("-");
                }
                if (rs.getString("AFFECTED_ACRES") != null && !(rs.getString("AFFECTED_ACRES").trim().equals(""))) {
                    rowBean.setCol44(rs.getString("AFFECTED_ACRES"));
                }
                else {
                    rowBean.setCol44("-");
                }
                if (rs.getString("TECHNOLOGY") != null && !(rs.getString("TECHNOLOGY").trim().equals(""))) {
                    rowBean.setCol45(rs.getString("TECHNOLOGY"));
                }
                else {
                    rowBean.setCol45("-");
                }
                if (rs.getDate("PLANTING_DATE") != null) {
                    rowBean.setCol46(getDateFormat(rs.getDate("PLANTING_DATE")));
                }
                else {
                    rowBean.setCol46("-");
                }
                if (rs.getString("PLANTER_TYPE") != null && !(rs.getString("PLANTER_TYPE").trim().equals(""))) {
                    rowBean.setCol47(rs.getString("PLANTER_TYPE"));
                }
                else {
                    rowBean.setCol47("-");
                }
                if (rs.getString("PLANTER_DEPTH") != null && !(rs.getString("PLANTER_DEPTH").trim().equals(""))) {
                    rowBean.setCol48(rs.getString("PLANTER_DEPTH"));
                }
                else {
                    rowBean.setCol48("-");
                }
                if (rs.getString("POPULATION_PLANTED") != null &&
                    !(rs.getString("POPULATION_PLANTED").trim().equals(""))) {
                    rowBean.setCol49(rs.getString("POPULATION_PLANTED"));
                }
                else {
                    rowBean.setCol49("-");
                }
                if (rs.getString("POPULATION_OBSERVED") != null &&
                    !(rs.getString("POPULATION_OBSERVED").trim().equals(""))) {
                    rowBean.setCol50(rs.getString("POPULATION_OBSERVED"));
                }
                else {
                    rowBean.setCol50("-");
                }

                if (rs.getString("TILLAGE") != null && !(rs.getString("TILLAGE").trim().equals(""))) {
                    rowBean.setCol51(rs.getString("TILLAGE"));
                }
                else {
                    rowBean.setCol51("-");
                }
*/
/*
	            if (rs.getString("COMPLAINT_ISSUE_DESCRIPTION") != null &&
                    !(rs.getString("COMPLAINT_ISSUE_DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol18(rs.getString("COMPLAINT_ISSUE_DESCRIPTION"));
                }
                else {
                    rowBean.setCol18("-");
                }
                if (rs.getString("ISSUE_TYPE") != null && !(rs.getString("ISSUE_TYPE").trim().equals(""))) {
                    rowBean.setCol19(rs.getString("ISSUE_TYPE"));
                }
                else {
                    rowBean.setCol19("-");
                }
*/

/*                if (rs.getString("GROWER_NAME") != null && !(rs.getString("GROWER_NAME").trim().equals(""))) {
                    rowBean.setCol54(rs.getString("GROWER_NAME"));
                }
                else {
                    rowBean.setCol54("-");
                }
                if (rs.getString("GROWER_ADDRESS") != null && !(rs.getString("GROWER_ADDRESS").trim().equals(""))) {
                    rowBean.setCol55(rs.getString("GROWER_ADDRESS"));
                }
                else {
                    rowBean.setCol55("-");
                }
                if (rs.getString("GROWER_CITY") != null && !(rs.getString("GROWER_CITY").trim().equals(""))) {
                    rowBean.setCol56(rs.getString("GROWER_CITY"));
                }
                else {
                    rowBean.setCol56("-");
                }
                if (rs.getString("GROWER_PHONE") != null && !(rs.getString("GROWER_PHONE").trim().equals(""))) {
                    rowBean.setCol57(rs.getString("GROWER_PHONE"));
                }
                else {
                    rowBean.setCol57("-");
                }
                if (rs.getString("GROWER_BA_ID") != null && !(rs.getString("GROWER_BA_ID").trim().equals(""))) {
                    rowBean.setCol58(rs.getString("GROWER_BA_ID"));
                }
                else {
                    rowBean.setCol58("-");
                }
                if (rs.getString("DEALER_NAME") != null && !(rs.getString("DEALER_NAME").trim().equals(""))) {
                    rowBean.setCol59(rs.getString("DEALER_NAME"));
                }
                else {
                    rowBean.setCol59("-");
                }
                if (rs.getString("DEALER_ADDRESS") != null && !(rs.getString("DEALER_ADDRESS").trim().equals(""))) {
                    rowBean.setCol60(rs.getString("DEALER_ADDRESS"));
                }
                else {
                    rowBean.setCol60("-");
                }

                if (rs.getString("DEALER_CITY") != null && !(rs.getString("DEALER_CITY").trim().equals(""))) {
                    rowBean.setCol61(rs.getString("DEALER_CITY"));
                }
                else {
                    rowBean.setCol61("-");
                }
                if (rs.getString("DEALER_PHONE") != null && !(rs.getString("DEALER_PHONE").trim().equals(""))) {
                    rowBean.setCol62(rs.getString("DEALER_PHONE"));
                }
                else {
                    rowBean.setCol62("-");
                }
                if (rs.getString("DEALER_BA_ID") != null && !(rs.getString("DEALER_BA_ID").trim().equals(""))) {
                    rowBean.setCol63(rs.getString("DEALER_BA_ID"));
                }
                else {
                    rowBean.setCol63("-");
                }
*/
                if (rs.getString("VARIETY") != null && !(rs.getString("VARIETY").trim().equals(""))) {
                    rowBean.setCol16(rs.getString("VARIETY"));
                }
                else {
                    rowBean.setCol16("-");
                }

                hash.put(rowCount + "", rowBean);

            }


            return hash;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                //**Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * Method to set the complaint_issues fields...
     *
     * @param complaintFilter
     *
     * @return
     */
    private StringBuffer getComplaintIssues(ComplaintFilter complaintFilter) {

        StringBuffer issuesClause = new StringBuffer();

        List paramList = new ArrayList();

        if (complaintFilter.isDriverPerformance()) {
            paramList.add("1");
        }
        if (complaintFilter.isPackagingCondition()) {
            paramList.add("2");
        }
        if (complaintFilter.isIncorrectShipment()) {
            paramList.add("3");
        }
        if (complaintFilter.isTagError()) {
            paramList.add("4");
        }
        if (complaintFilter.isDeliveryOther()) {
            paramList.add("5");
        }

        if (complaintFilter.isSeedAppearance()) {
            paramList.add("6");
        }
        if (complaintFilter.isSeedVariability()) {
            paramList.add("7");
        }
        if (complaintFilter.isEmergenceConcerns()) {
            paramList.add("8");
        }
        if (complaintFilter.isProductPurity()) {
            paramList.add("9");
        }
        if (complaintFilter.isEarlySeasonOther()) {
            paramList.add("10");
        }

        if (complaintFilter.isGrowthDevelopment()) {
            paramList.add("11");
        }
        if (complaintFilter.isHerbicideInjury()) {
            paramList.add("12");
        }
        if (complaintFilter.isDiseaseDevelopment()) {
            paramList.add("13");
        }
        if (complaintFilter.isInsectOutbreaksInjury()) {
            paramList.add("14");
        }
        if (complaintFilter.isPollinationProblems()) {
            paramList.add("15");
        }
        if (complaintFilter.isStressSusceptability()) {
            paramList.add("16");
        }
        if (complaintFilter.isMidSeasonOther()) {
            paramList.add("17");
        }

        if (complaintFilter.isLateSeasonDiseaseDevelopment()) {
            paramList.add("18");
        }
        if (complaintFilter.isInsectDevelopment()) {
            paramList.add("19");
        }
        if (complaintFilter.isSeedDevelopment()) {
            paramList.add("20");
        }
        if (complaintFilter.isNonCompetitiveYield()) {
            paramList.add("21");
        }
        if (complaintFilter.isMaintainingSeedUntilHarvest()) {
            paramList.add("22");
        }
        if (complaintFilter.isMaturityDrydown()) {
            paramList.add("22");
        }
        if (complaintFilter.isLateSeasonOther()) {
            paramList.add("24");
        }

        int size = paramList.size();

        if (size > 0) {
            issuesClause.append(" AND COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID IN ");
        }
        else {
            issuesClause.append("");
            return issuesClause;
        }

        issuesClause.append("(");

        for (int i = 0; i < size; i++) {

            issuesClause.append("'" + paramList.get(i).toString() + "'");

            if (i < size - 1) {
                issuesClause.append(",");
            }
        }

        issuesClause.append(")");

        return issuesClause;
    }

    /**
     * This method just makes a string out of selected fields like ('1744', '1745',...)
     *
     * @param strArray
     *
     * @return
     */
    private StringBuffer getSelectedFields(String query, String[] strArray) {

        int size = strArray.length;

        StringBuffer fieldClause = new StringBuffer();
        fieldClause.append("");

        //**To remove the null elements...
        for (int i = 0; i < size; i++) {

            if (strArray[i].equals("") || strArray[i].equals("0")) {
                size--;
            }
        }

        if (size == 0) {
            return fieldClause;
        }

        fieldClause.append(query + "(");

        for (int i = 0; i < strArray.length; i++) {

            //**Skip null elements...
            if (strArray[i].equals("") || strArray[i].equals("0")) {
                continue;
            }

            fieldClause.append("'" + strArray[i].trim() + "'");

            if (i < strArray.length - 1) {
                fieldClause.append(",");
            }
        }

        fieldClause.append(")");

        return fieldClause;
    }

    private int insertComplaint_Grower(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_GROWER_SQL);
                ps.setLong(11, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_GROWER_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }

            ps.setString(paramIndx, c.getGrower_name());
            ps.setString(paramIndx + 1, c.getGrower_address());
            ps.setString(paramIndx + 2, c.getGrower_city());
            if (!(c.getGrower_state() == null) && !(c.getGrower_state().equals(""))) {
                ps.setInt(paramIndx + 3, Integer.parseInt(c.getGrower_state()));
            }
            else {
                ps.setNull(paramIndx + 3, Types.INTEGER);
            }
            ps.setString(paramIndx + 4, c.getGrower_phone());
            ps.setString(paramIndx + 5, c.getGrower_ba_id());
            ps.setString(paramIndx + 6, "APPLICATION");
            ps.setString(paramIndx + 7, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 8, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            //conn.commit();
            return rows;
        }
        catch (Exception e) {
//			try  { 
//				conn.rollback(); 
//				}
//			catch(Exception ex) {
//				throw new DAOException(ex);
//				}			
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                //this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private int insertComplaint_Batch(Complaint c, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List batchList = null;
        int rows = 0;
        long complaint_id;
        try {
            batchList = getBatchList(c);
            complaint_id = Long.parseLong(c.getComplaint_id());
            if (batchList.size() > 0) {
                ps = conn.prepareStatement(COMPLAINT_BATCH_SQL);
                for (int i = 0; i < batchList.size(); i++) {
                    ps.setString(1, batchList.get(i).toString());
                    ps.setLong(2, complaint_id);
                    rows = rows + ps.executeUpdate();
                }
            }
            return rows;
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * @param c
     *
     * @return
     */
    private List getBatchList(Complaint c) {
        List batches = new ArrayList();
        if (c.getBatch_one() != null && c.getBatch_one() != "" && !(c.getBatch_one().equals(null)) &&
            !(c.getBatch_one().equals(""))) {
            batches.add(c.getBatch_one());
        }
        if (c.getBatch_two() != null && c.getBatch_two() != "" && !(c.getBatch_two().equals(null)) &&
            !(c.getBatch_two().equals(""))) {
            batches.add(c.getBatch_two());
        }
        if (c.getBatch_three() != null && c.getBatch_three() != "" && !(c.getBatch_three().equals(null)) &&
            !(c.getBatch_three().equals(""))) {
            batches.add(c.getBatch_three());
        }
        if (c.getBatch_four() != null && c.getBatch_four() != "" && !(c.getBatch_four().equals(null)) &&
            !(c.getBatch_four().equals(""))) {
            batches.add(c.getBatch_four());
        }
        return batches;
    }

    private int insertComplaint_Dealer(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_DEALER_SQL);
                ps.setLong(11, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_DEALER_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getDealer_name());
            ps.setString(paramIndx + 1, c.getDealer_address());
            ps.setString(paramIndx + 2, c.getDealer_city());
            if (!(c.getDealer_state() == null) && !(c.getDealer_state().equals(""))) {
                ps.setInt(paramIndx + 3, Integer.parseInt(c.getDealer_state()));
            }
            else {
                ps.setNull(paramIndx + 3, Types.INTEGER);
            }
            ps.setString(paramIndx + 4, c.getDealer_phone());
            ps.setString(paramIndx + 5, c.getDealer_ba_id());
            ps.setString(paramIndx + 6, "APPLICATION");
            ps.setString(paramIndx + 7, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 8, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            return rows;
        }
        catch (Exception e) {

            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private int insertComplaint_Disease(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_DISEASE_SQL);
                ps.setLong(12, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_DISEASE_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getDisease_observed());
            ps.setString(paramIndx + 1, c.getHerbicide_type_current());
            ps.setString(paramIndx + 2, c.getHerbicide_rate_current());
            ps.setString(paramIndx + 3, c.getHerbicide_timming_current());
            ps.setString(paramIndx + 4, c.getHerbicide_type_prev());
            ps.setString(paramIndx + 5, c.getHerbicide_rate_prev());
            ps.setString(paramIndx + 6, c.getHerbicide_timming_prev());
            ps.setString(paramIndx + 7, "APPLICATION");
            ps.setString(paramIndx + 8, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            return rows;
        }
        catch (Exception e) {

            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private int insertComplaint_Documentation(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate && complaintDocumentationExists(c, conn)) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_DOCUMENTATION_SQL);
                ps.setLong(9, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_DOCUMENTATION_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getProblem_description());
            ps.setString(paramIndx + 1, c.getContainment_actions());
            ps.setString(paramIndx + 2, c.getRoot_cause());
            ps.setString(paramIndx + 3, c.getLong_term_corrective_action());
            ps.setString(paramIndx + 4, "APPLICATION");
            ps.setString(paramIndx + 5, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 6, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 7, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            return rows;
        }
        catch (Exception e) {

            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }

            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private boolean complaintDocumentationExists(Complaint c, Connection conn) throws SQLException {
        PreparedStatement statement = conn.prepareStatement(COMPLAINT_DOCUMENTATION_EXISTS);
        statement.setString(1, c.getComplaint_id());
        ResultSet result = statement.executeQuery();
        String theString = "";
        if (result.next()) {
            theString = result.getString(1);
        }
        cleanup(result, statement);
        return "1".equals(theString);
    }

    private void cleanup(ResultSet result, PreparedStatement statement) throws SQLException {
        result.close();
        statement.close();
    }

    private int insertComplaint_Insect(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_INSECT_SQL);
                ps.setLong(12, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_INSECT_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getInsects_observed());
            ps.setString(paramIndx + 1, c.getInsecticide_type_current());
            ps.setString(paramIndx + 2, c.getInsecticide_rate_current());
            ps.setString(paramIndx + 3, c.getInsecticide_timming_current());
            ps.setString(paramIndx + 4, c.getInsecticide_type_prev());
            ps.setString(paramIndx + 5, c.getInsecticide_rate_prev());
            ps.setString(paramIndx + 6, c.getInsecticide_timming_prev());
            ps.setString(paramIndx + 7, "APPLICATION");
            ps.setString(paramIndx + 8, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            return rows;
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private int insertComplaint_Issues(Complaint c, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        List issuesList = null;
        long complaint_id;
        try {
            issuesList = getIssuesList(c);
            complaint_id = Long.parseLong(c.getComplaint_id());
            if (issuesList.size() > 0) {
                ps = conn.prepareStatement(COMPLAINT_ISSUES_SQL);
                for (int i = 0; i < issuesList.size(); i++) {
                    ps.setLong(1, Long.parseLong(issuesList.get(i).toString()));
                    ps.setLong(2, complaint_id);
                    ps.setString(3, "APPLICATION");
                    ps.setString(4, "COMPLAINT ENTRY");
                    ps.setDate(5, new Date(new java.util.Date().getTime()));
                    ps.setDate(6, new Date(new java.util.Date().getTime()));
                    rows = rows + ps.executeUpdate();
                }
            }
            return rows;
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * @return
     */
    private List getIssuesList(Complaint c) {
        List issueList = new ArrayList();
        if (c.isDriver_performance()) {
            issueList.add(complaintIssuesMap.get("driver_performance"));
        }
        if (c.isPackaging_condition()) {
            issueList.add(complaintIssuesMap.get("packaging_condition"));
        }
        if (c.isIncorrect_shipment()) {
            issueList.add(complaintIssuesMap.get("incorrect_shipment"));
        }
        if (c.isTag_error()) {
            issueList.add(complaintIssuesMap.get("tag_error"));
        }
        if (c.isDelivery_other()) {
            issueList.add(complaintIssuesMap.get("delivery_other"));
        }
        if (c.isSeed_appearance()) {
            issueList.add(complaintIssuesMap.get("seed_appearance"));
        }
        if (c.isSeed_variability()) {
            issueList.add(complaintIssuesMap.get("seed_variability"));
        }
        if (c.isEmergence_concerns()) {
            issueList.add(complaintIssuesMap.get("emergence_concerns"));
        }
        if (c.isProduct_purity()) {
            issueList.add(complaintIssuesMap.get("product_purity"));
        }
        if (c.isEarly_season_other()) {
            issueList.add(complaintIssuesMap.get("early_season_other"));
        }
        if (c.isGrowth_development()) {
            issueList.add(complaintIssuesMap.get("growth_development"));
        }
        if (c.isHerbicide_injury()) {
            issueList.add(complaintIssuesMap.get("herbicide_injury"));
        }
        if (c.isDisease_development()) {
            issueList.add(complaintIssuesMap.get("disease_development"));
        }
        if (c.isInsect_outbreaks_injury()) {
            issueList.add(complaintIssuesMap.get("insect_outbreaks_injury"));
        }
        if (c.isPollination_problems()) {
            issueList.add(complaintIssuesMap.get("pollination_problems"));
        }
        if (c.isStress_susceptability()) {
            issueList.add(complaintIssuesMap.get("stress_susceptability"));
        }
        if (c.isMidseason_other()) {
            issueList.add(complaintIssuesMap.get("midseason_other"));
        }
        if (c.isLateseason_disease_development()) {
            issueList.add(complaintIssuesMap.get("lateseason_disease_development"));
        }
        if (c.isInsect_development()) {
            issueList.add(complaintIssuesMap.get("insect_development"));
        }
        if (c.isSeed_development()) {
            issueList.add(complaintIssuesMap.get("seed_development"));
        }
        if (c.isNoncompetitive_yield()) {
            issueList.add(complaintIssuesMap.get("noncompetitive_yield"));
        }
        if (c.isMaintaining_seed_until_harvest()) {
            issueList.add(complaintIssuesMap.get("maintaining_seed_until_harvest"));
        }
        if (c.isMaturity_drydown()) {
            issueList.add(complaintIssuesMap.get("maturity_drydown"));
        }
        if (c.isLate_season_other()) {
            issueList.add(complaintIssuesMap.get("late_season_other"));
        }
        return issueList;
    }

    private int insertComplaint_Planting(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(UPDATE_COMPLAINT_PLANTING_SQL);
                ps.setLong(14, Long.parseLong(c.getComplaint_id()));
            }
            else {
                ps = conn.prepareStatement(COMPLAINT_PLANTING_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
                paramIndx++;
            }
            if (!(c.getTotal_acres() == null) && !(c.getTotal_acres().equals(""))) {
                ps.setFloat(paramIndx, Float.parseFloat(c.getTotal_acres()));
            }
            else {
                ps.setNull(paramIndx, Types.FLOAT);
            }
            if (!(c.getAffected_areas() == null) && !(c.getAffected_areas().equals(""))) {
                ps.setFloat(paramIndx + 1, Float.parseFloat(c.getAffected_areas()));
            }
            else {
                ps.setNull(paramIndx + 1, Types.FLOAT);
            }
            ps.setString(paramIndx + 2, c.getTechnology());
            if (!(c.getPlanting_date() == null) && !(c.getPlanting_date().equals(""))) {
                ps.setDate(paramIndx + 3, new Date(new java.util.Date(c.getPlanting_date()).getTime()));
            }
            else {
                ps.setDate(paramIndx + 3, null);
            }
            ps.setString(paramIndx + 4, c.getPlanter_type());
            if (!(c.getPlanter_depth() == null) && !(c.getPlanter_depth().equals(""))) {
                ps.setFloat(paramIndx + 5, Float.parseFloat(c.getPlanter_depth()));
            }
            else {
                ps.setNull(paramIndx + 5, Types.INTEGER);
            }
            if (!(c.getPopulation_planted() == null) && !(c.getPopulation_planted().equals(""))) {
                ps.setFloat(paramIndx + 6, Float.parseFloat(c.getPopulation_planted()));
            }
            else {
                ps.setNull(paramIndx + 6, Types.FLOAT);
            }
            if (!(c.getPopulation_observed() == null) && !(c.getPopulation_observed().equals(""))) {
                ps.setFloat(paramIndx + 7, Float.parseFloat(c.getPopulation_observed()));
            }
            else {
                ps.setNull(paramIndx + 7, Types.FLOAT);
            }
            ps.setString(paramIndx + 8, c.getTillage());
            ps.setString(paramIndx + 9, "APPLICATION");
            ps.setString(paramIndx + 10, "COMPLAINT ENTRY");
            ps.setDate(paramIndx + 11, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 12, new Date(new java.util.Date().getTime()));
            rows = ps.executeUpdate();
            return rows;
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    private int insertComplaint_Variety(Complaint c, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        List varietyList = null;
        try {
            varietyList = getVarietyList(c);
            if (varietyList.size() > 0) {
                ps = conn.prepareStatement(COMPLAINT_VARIETY_SQL);
                for (int i = 0; i < varietyList.size(); i++) {
                    ps.setLong(1, Long.parseLong(c.getComplaint_id()));
                    ps.setLong(2, Long.parseLong(varietyList.get(i).toString()));
                    rows = rows + ps.executeUpdate();
                }
            }
            return rows;
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
    }

    /**
     * @param c
     *
     * @return
     */
    private List getVarietyList(Complaint c) {
        List varityList = new ArrayList();
        if ((c.getVariety_one() != null) && !(c.getVariety_one().equals("")) && !(c.getVariety_one().equals("0")))
        {
            varityList.add(c.getVariety_one());
        }
/*
        if (!(c.getVariety_two().equals(null)) && !(c.getVariety_two().equals("")) && !(c.getVariety_two().equals("0")))
        {
            varityList.add(c.getVariety_two());
        }
        if (!(c.getVariety_three().equals(null)) && !(c.getVariety_three().equals("")) &&
            !(c.getVariety_three().equals("0"))) {
            varityList.add(c.getVariety_three());
        }
        if (!(c.getVariety_four().equals(null)) && !(c.getVariety_four().equals("")) &&
            !(c.getVariety_four().equals("0"))) {
            varityList.add(c.getVariety_four());
        }
*/
        return varityList;
    }

    private String getDateFormat(Date date) {
        try {
            sdf.format(date).toString();
            return sdf.format(date).toString();
        }
        catch (Exception e) {
            return "";
        }
    }

    public void updateComplaintDocumentation(Cpar cpar) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        boolean update = false;
        StringBuffer query = new StringBuffer(UPDATE_CPAR_TO_COMPLAINT_DOCUMENTATION_SQL);
        try {
            if (!(cpar.getRoot_cause() == null) && !(cpar.getRoot_cause().equals(""))) {
                query.append(", ROOT_CAUSE='" + cpar.getRoot_cause() + "'");
                update = true;
            }
            if (!(cpar.getLong_term_corrective_action() == null) && !(cpar.getLong_term_corrective_action().equals("")))
            {
                query.append(", LONG_TERM_CORRECTION_ACTION='" + cpar.getLong_term_corrective_action() + "'");
                update = true;
            }

            if (!(cpar.getEvaluation_comments() == null) && !(cpar.getEvaluation_comments().equals(""))) {
                query.append(", EVALUATION_COMMENTS='" + cpar.getEvaluation_comments() + "'");
                update = true;
            }

            if (update) {
                conn = getConnection();
                query.append(" WHERE COMPLAINT_ID=" + cpar.getComplaint_id());
                ps = conn.prepareStatement(query.toString());
                ps.setString(1, "APPLICATION");
                ps.setString(2, "CAR UPDATE");
                ps.setDate(3, new Date(new java.util.Date().getTime()));
                ps.executeUpdate();
                conn.commit();
                System.out.println("Complaint Updated !");
            }
        }
        catch (Exception e) {
            try {
                conn.rollback();
            }
            catch (Exception ex) {
                throw new DAOException(ex);
            }
            throw new DAOException(e);
        }
        finally {
            try {
                // Close the result sets, statement and connection.
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                this.closeConnection(conn);
            }
            catch (SQLException ex) {
                throw new DAOException(ex.toString());
            }
        }
	}	
}
