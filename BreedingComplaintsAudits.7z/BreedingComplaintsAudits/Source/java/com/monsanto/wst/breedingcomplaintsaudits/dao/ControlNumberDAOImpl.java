/*
 * Created on Mar 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.monsanto.wst.breedingcomplaintsaudits.actions.ActionHelper;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;

import javax.swing.*;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlNumberDAOImpl extends BaseDAOImpl implements ControlNumberDAO {
	/**
	 * Constructor. Initialize the datasource.
	 * @exception SQLException if lookup of datasource fails
	 */	
	public ControlNumberDAOImpl() throws DAOException {

	}
	
	public boolean generateControlNumber(Object o) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer controlSeq;
		boolean result=false;
		try{
			if (o!=null) {
				conn = getConnection();
				controlSeq = new StringBuffer();
				if (o instanceof Cpar) {
					Cpar cpar=(Cpar)o;

                  	    if (cpar.getCar_flag().equals("Y"))
						    controlSeq.append("C-");
					    else
                          {
                              if (!(cpar.getContinual_Improvements().equals("null")) || (cpar.getContinual_Improvements().equals("")))
                              {
                                 if (cpar.getContinual_Improvements().equals("2"))
                                    controlSeq.append("CI-");
                                 else
                                 controlSeq.append("P-");
                              }
                          }

					controlSeq.append(cpar.getFiling_location().trim());
					controlSeq.append("-");
					controlSeq.append(ActionHelper.getSalesyearList().get(cpar.getIssue_year()).toString().substring(2).trim());
					controlSeq.append("-");
					ps = conn.prepareStatement(getQueryString(controlSeq.toString(),"cpar"));
					rs = ps.executeQuery();
					if (rs!=null){
						rs.next();
						controlSeq.append(String.valueOf(rs.getLong(1) + 1));
					}
					else
						controlSeq.append("1");
					cpar.setControl_number(controlSeq.toString());
					result=true;
				}
				else {
//TODO 				Can check for object being any other type like stop sale, audit etc and implement controlSeq logic.
				}				
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}   
	
	private String getQueryString(String seqNo,String tblName){
		StringBuffer query= new StringBuffer();
		query.append("select");
		query.append(" max(to_number(substr(control_number,length('");
		query.append(seqNo);
		query.append("')+1))) ");
		query.append("from ");
		query.append(tblName);
		query.append(" where control_number like '");
		query.append(seqNo);
		query.append("%'");
		System.out.println(query.toString());
		return query.toString();
		
		
	}
}
