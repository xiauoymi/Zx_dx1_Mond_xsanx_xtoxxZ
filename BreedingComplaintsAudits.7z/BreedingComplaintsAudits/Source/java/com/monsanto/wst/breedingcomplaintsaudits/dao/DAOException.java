/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.sql.SQLException;

import org.apache.log4j.Category;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DAOException extends Exception{
	
	static Category logger = Category.getInstance(DAOException.class.getName());
	
	protected SQLException sqlException;
	
	public DAOException(){}
	
	public DAOException(String errMsg){
		super(errMsg);
		logger.error("DAOException: " + errMsg);
	}
	
	public DAOException(SQLException sqlErr){
		super(sqlErr);
		logger.error("DAO-SQLException...");
	}
	
	public DAOException(Exception err){
		super(err);
	}
	
	public DAOException(String errMsg, SQLException sqlErr){
		super(sqlErr);
		StringBuffer msgBuff = new StringBuffer(errMsg);
		msgBuff.append(": ");
		msgBuff.append(sqlErr.getMessage());
		this.sqlException = sqlErr;
		
		logger.error("DAO-SQLException Msg: " + errMsg);
	}
	
	public SQLException getSQLException(){
		return this.sqlException;
	}
	
	public String getMessage(){
		return super.getMessage();
	}
	
    public void printStackTrace() {
        if (sqlException != null) {
            sqlException.printStackTrace();
        }
        /*
        else {
            this.printStackTrace();
        }
         **/
    }
}
