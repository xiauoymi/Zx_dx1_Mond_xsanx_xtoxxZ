/*
 * Created on Jan 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DAOFactory {
	private static Map daoMap;
//	private static final DAOFactory instance = new DAOFactory(); // singleton instance

	private static Log logger = LogFactory.getLog(DAOFactory.class);	
	
// singleton 'getInstance' method.
//	public static DAOFactory getInstance() {
//		return instance; 
//	}
	
//	private DAOFactory() {
//		daoMap = new HashMap();
//		daoMap.put(ComplaintDAO.class, ComplaintDAOImpl.class);
//	}
	
	static {
		daoMap = new HashMap();
		daoMap.put(ComplaintDAO.class, ComplaintDAOImpl.class);
		daoMap.put(LookUpDAO.class, LookUpDAOImpl.class);
		daoMap.put(CparDAO.class, CparDAOImpl.class);
		daoMap.put(UserAccountDAO.class, UserAccountDAOImpl.class);
		daoMap.put(ControlNumberDAO.class, ControlNumberDAOImpl.class);
		daoMap.put(AuditDAO.class, AuditDAOImpl.class);
		daoMap.put(StopSaleDAO.class, StopSaleDAOImpl.class);
	}
	
	public static Object getDao(Class type) throws DAOException {
        if (logger.isTraceEnabled())
            logger.trace("Entering - clazz=" + type);

        if (type == null) {
            throw new DAOException("cannot retrieve DAO implementation for null name");
        }

        Object dao = null;
        Class clazz = (Class) daoMap.get(type);
        
        if (clazz != null){
            try {
                dao = clazz.newInstance();
                if (logger.isDebugEnabled()) {
                    logger.debug("found DAO implementation '" + dao.getClass() + "' for name '" + type + "'");
                }
            } catch (Exception ie) {
                throw new DAOException("could not instantiate DAO for name '" + type + "': " + ie.getMessage());
            }
        }
        else{
            throw new DAOException("could not find implementation class for name '" + type + "'");
        }
        if (logger.isTraceEnabled())
            logger.trace("Exiting");
        return dao;
	}
}
