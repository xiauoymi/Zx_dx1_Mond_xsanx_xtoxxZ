/*
 * Created on Jan 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface LookUpDAO {
	public Map getStates() throws DAOException;
	public Map getStatus(String type) throws DAOException;
	public Map getLocations() throws DAOException;
	public Map getResponsibleLocations() throws DAOException;
    public Map getQualityIssues() throws DAOException;
	public Map getYear() throws DAOException;
	public Map getCrops() throws DAOException;
	public Map getSeedSize() throws DAOException;
	public Map getUOM() throws DAOException;
	public Map getVarities() throws DAOException;
	public Map getBrands() throws DAOException;
	public Map getRegions() throws DAOException;
	public Map getGenerator() throws DAOException;
	public Map getEffectivenessEvaluator() throws DAOException;
	public Map getFindingTypes() throws DAOException;
	public Map getISOStandards() throws DAOException;
	public String[] getEmail(String locationCode) throws DAOException;
	public Map getCAREmails(int overdueIntvl) throws DAOException;
	public Map getEmailServiceParams() throws DAOException;
	public void setMailSentDateParam(int mailSentDate) throws DAOException;
	public void addMailSentDateParam(int mailSentDate) throws DAOException;

    public Map getComplaintEmails(int overdue) throws DAOException;
}
