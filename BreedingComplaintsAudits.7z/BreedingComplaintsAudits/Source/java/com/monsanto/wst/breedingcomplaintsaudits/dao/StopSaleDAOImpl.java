/*
 * Created on May 9, 2005
 *
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.sql.Date;
import java.util.List;
import java.util.LinkedHashMap;

import org.apache.log4j.Category;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleObject;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.RowBean;

/**
 * @author rdesai2
 */
public class StopSaleDAOImpl extends BaseDAOImpl implements StopSaleDAO {
	
	static Category logger = Category.getInstance(StopSaleDAOImpl.class.getName());
	
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	
	private static final String GET_ORACLE_SYSDATE = 
    	"SELECT SYSDATE FROM DUAL";
	
	private static final String GET_STOP_SALE_SEQ_NEXTVAL =
		"SELECT STOP_SALE_SEQ.NEXTVAL FROM DUAL";
	
	private static final String AUTO_STOP_SALE_NUMBER =
		"SELECT MAX(TO_NUMBER(SUBSTR(CONTROL_NUMBER,LENGTH('S-XXXX-YY-')+1))) MAX FROM STOP_SALE WHERE CONTROL_NUMBER LIKE ?";
	
	private static final String INSERT_STOP_SALE =
		"INSERT INTO STOP_SALE " +
			"(STOP_SALE_ID, CONTROL_NUMBER, DATE_REPORTED,  " +
			"PERSON_INVESTIGATING, REGION_ID, REPORT_INITIATOR, " +
			"REPORTING_LOCATION_CODE,  SALES_YEAR_ID, STATE_ID, STATUS_ID, " +
			"ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROW_TASK_ID, ROW_USER_ID ";
	
	private static final String INSERT_STOP_SALE_DOC =
		"INSERT INTO STOP_SALE_DOCUMENTATION " +
			"(STOP_SALE_ID, ROW_ENTRY_DATE, ROW_USER_ID, " +
			"ROW_TASK_ID, ROW_MODIFY_DATE ,INVESTIGATION_FINDINGS ";
	
	private static final String INSERT_STOP_SALE_VARIETY =
		"INSERT INTO STOP_SALE_VARIETY (STOP_SALE_ID, VARIETY_ID) VALUES (?, ?)";
	
	private static final String INSERT_STOP_SALE_BATCH =
		"INSERT INTO STOP_SALE_BATCH (STOP_SALE_ID, BATCH_NUMBER) VALUES (?, ?)";
	
	private static final String INSERT_STOP_SALE_REASON =
		"INSERT INTO STOP_SALE_REASON (STOP_SALE_ID, STOP_SALE_REASON_ID) VALUES (?, ?)";
	
	private static final String INSERT_STOP_SALE_ACTION_FLAG =
		"INSERT INTO STOP_SALE_ACTION (STOP_SALE_ID, STOP_SALE_ACTION_ID) VALUES (?, ?)";
	
	private static final String UPDATE_STOP_SALE =
		"UPDATE " +
			"STOP_SALE " +
		"SET " +
			"STATUS_ID = ?, REGION_ID = ?, " +
			"REPORTING_LOCATION_CODE = ?, REPORT_INITIATOR = ?, " +
			"DATE_REPORTED = to_date(?, 'mm/dd/yyyy'), SALES_YEAR_ID = ?, " +
			"RESPONSIBLE_PLANT_CODE = ?, FIELD_COMMUNICATOR = ?, " +
			"STATE_ID = ?, SHIPPING_LOCATION_CODE = ?, " +
			"DEALER = ?, DEALER_PHONE_NO = ?, " +
			"STATE_REPORT_NUMBER = ?, STATE_VALUE = ?, " +
			"STATE_CONTACT = ?, STATE_PHONE_NUMBER = ?, " +
			"STATE_RETEST = ?, MONSANTO_VALUE = ?, " +
			"PERSON_INVESTIGATING = ?, " +
			"CROP_ID = ?, LABEL_VALUE = ?, " +
			"QUALITY_ISSUE_FLAG = ?, QTY_UOM_ID = ?, " +
			"SEED_SIZE_ID = ?, ACTION_COMMENTS = ?, " +
			"ROW_MODIFY_DATE = ? , " +
			"ROW_TASK_ID = ?, " +
			"ROW_USER_ID = ? ";
	
	private static final String UPDATE_STOP_SALE_DOC =
		"UPDATE " +
			"STOP_SALE_DOCUMENTATION " +
		"SET " +
			"INVESTIGATION_FINDINGS = ?, ROOT_CAUSE = ?, " +
			"CONTAINMENT_ACTION = ?, LONG_TERM_CORRECTION_ACTION = ?, " +
			"ROW_USER_ID = ?, ROW_TASK_ID = ?, " +
			"ROW_MODIFY_DATE = ? " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String DELETE_STOP_SALE_VARIETY = 
		"DELETE FROM STOP_SALE_VARIETY WHERE STOP_SALE_ID = ?";
	
	private static final String DELETE_STOP_SALE_BATCH = 
		"DELETE FROM STOP_SALE_BATCH WHERE STOP_SALE_ID = ?";
	
	private static final String DELETE_STOP_SALE_REASON = 
		"DELETE FROM STOP_SALE_REASON WHERE STOP_SALE_ID = ?";
	
	private static final String DELETE_STOP_SALE_ACTION_FLAG = 
		"DELETE FROM STOP_SALE_ACTION WHERE STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE =
		"SELECT " +
			"STOP_SALE_ID, CONTROL_NUMBER, DATE_REPORTED REPORT_DATE, PERSON_INVESTIGATING INVESTIGATOR, " +
			"REGION_ID REGION, REPORT_INITIATOR INITIATED_BY, REPORTING_LOCATION_CODE FILLING_LOCATION, " +
			"SALES_YEAR_ID, STATE_ID, STATUS_ID, ROW_USER_ID CREATED_BY, RESPONSIBLE_PLANT_CODE RESPONSIBLE_LOCATION, " +
			"FIELD_COMMUNICATOR, SHIPPING_LOCATION_CODE SHIPPING_LOCATION, DEALER, DEALER_PHONE_NO, " +
			"STATE_REPORT_NUMBER, STATE_VALUE, STATE_CONTACT, STATE_PHONE_NUMBER, STATE_RETEST, MONSANTO_VALUE, " +
			"CROP_ID, LABEL_VALUE, QUALITY_ISSUE_FLAG, QTY_AFFECTED, QTY_UOM_ID, SEED_SIZE_ID, ACTION_COMMENTS, ROW_ENTRY_DATE " +
		"FROM " +
			"STOP_SALE " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_DOC =
		"SELECT " +
			"INVESTIGATION_FINDINGS, ROOT_CAUSE, " +
			"CONTAINMENT_ACTION, LONG_TERM_CORRECTION_ACTION " +
		"FROM " +
			"STOP_SALE_DOCUMENTATION " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_VARIETY =
		"SELECT " +
			"VARIETY_ID " +
		"FROM " +
			"STOP_SALE_VARIETY " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_BATCH =
		"SELECT " +
			"BATCH_NUMBER " +
		"FROM " +
			"STOP_SALE_BATCH " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_REASON =
		"SELECT " +
			"STOP_SALE_REASON_ID " +
		"FROM " +
			"STOP_SALE_REASON " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_ACTION =
		"SELECT " +
			"STOP_SALE_ACTION_ID " +
		"FROM " +
			"STOP_SALE_ACTION " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_CAR =
		"SELECT " +
			"CPAR_ID CAR_ID, " +
			"CONTROL_NUMBER CAR_NUMBER " +
		"FROM " +
			"CPAR " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_NO =
		"SELECT " +
			"CONTROL_NUMBER STOP_SALE_NUMBER " +
		"FROM " +
			"STOP_SALE " +
		"WHERE " +
			"STOP_SALE_ID = ?";
	
	private static final String GET_STOP_SALE_LIST_COUNT =
		"SELECT COUNT(*) MAX_ROWS FROM STOP_SALE S ";
	
	private static final String GET_STOP_SALE_LIST =
		" SELECT RANKING, STOP_SALE_ID,CONTROL_NUMBER, STATUS,RESPONSIBLE_LOCATION,REGION,CROP,DEALER  FROM " +
            "(SELECT ROWNUM AS RANKING, STOP_SALE_ID,CONTROL_NUMBER, STATUS,RESPONSIBLE_LOCATION,REGION,CROP,DEALER  FROM  " +
			" (SELECT " +
				"S.STOP_SALE_ID, S.CONTROL_NUMBER, " +
				"(SELECT SR.STATUS_DESCRIPTION FROM STATUS_REF SR WHERE SR.STATUS_ID=S.STATUS_ID) STATUS, " +
				"(SELECT L.LOCATION_SHORT_NAME FROM LOCATION_REF L WHERE L.LOCATION_CODE=S.RESPONSIBLE_PLANT_CODE) RESPONSIBLE_LOCATION, " +
				"(SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=S.REGION_ID) REGION, " +
				"(SELECT C.SHORT_DESCRIPTION FROM CROP_REF C WHERE C.CROP_ID=S.CROP_ID) CROP, " +
				"S.DEALER " +
			"FROM " +
				"STOP_SALE S ";
	
	private static final String GET_YEAR =
		"SELECT SHORT_DESCRIPTION YEAR FROM YEAR_REF WHERE YEAR_ID = ?";
	
	private static final String GET_STOP_SALE_ID =
		"SELECT STOP_SALE_ID FROM STOP_SALE WHERE CONTROL_NUMBER = ?";
	
	private static final String GET_STOP_SALE_REPORT =
		"SELECT " +
			"STOP_SALE.CONTROL_NUMBER, " +
			"YEAR_REF.SHORT_DESCRIPTION AS YEAR, " +
			"STATUS_REF.STATUS_DESCRIPTION AS STATUS, " +
			"STOP_SALE.REPORT_INITIATOR, " +
			"STOP_SALE.PERSON_INVESTIGATING, " +
			"STOP_SALE.FIELD_COMMUNICATOR, " +
			"CROP_REF.SHORT_DESCRIPTION AS CROP, " +
			"SEED_SIZE_REF.DESCRIPTION AS SEED_SIZE, " +
			"STOP_SALE.QTY_AFFECTED, " +
			"QTY_UOM_REF.QTY_DESCRIPTION AS UOM, " +
			"STOP_SALE.QUALITY_ISSUE_FLAG, " +
			"STOP_SALE.DEALER, " +
			"STOP_SALE.DEALER_PHONE_NO, " +
			"STOP_SALE.STATE_VALUE, " +
			"STOP_SALE.STATE_RETEST, " +
			"STOP_SALE.STATE_REPORT_NUMBER, " +
			"STOP_SALE.STATE_CONTACT, " +
			"STOP_SALE.STATE_PHONE_NUMBER, " +
			"STOP_SALE.DATE_REPORTED, " +
			"STOP_SALE.MONSANTO_VALUE, " +
			"STOP_SALE.LABEL_VALUE, " +
			"STOP_SALE.ACTION_COMMENTS, " +
			"REGION_REF.REGION_DESCRIPTION, " +
			"STATE_REF.STATE_LONG_NAME, " +
			"REPORTING.LOCATION_SHORT_NAME AS REPORTING_LOCATION, " +
			"SHIPPING.LOCATION_SHORT_NAME AS SHIPPING_LOCATION, " +
			"RESPONSIBLE.LOCATION_SHORT_NAME AS RESPONSIBLE_LOCATION, " +
			"ACTION.DESCRIPTION AS ACTION, " +
			"STOP_SALE_REASON_REF.DESCRIPTION AS REASON, " +
			"STOP_SALE_BATCH.BATCH_NUMBER, " +
			"VARIETY_REF.DESCRIPTION AS VARIETY, " +
			"STOP_SALE_DOCUMENTATION.INVESTIGATION_FINDINGS, " +
			"STOP_SALE_DOCUMENTATION.LONG_TERM_CORRECTION_ACTION, " +
			"STOP_SALE_DOCUMENTATION.ROOT_CAUSE, " +
			"STOP_SALE_DOCUMENTATION.CONTAINMENT_ACTION " +
		"FROM " +
			"STOP_SALE," +
			"YEAR_REF, " +
			"STATUS_REF, " +
			"CROP_REF, " +
			"SEED_SIZE_REF, " +
			"QTY_UOM_REF, " +
			"REGION_REF, " +
			"STATE_REF, " +
			"LOCATION_REF REPORTING, " +
			"LOCATION_REF SHIPPING, " +
			"LOCATION_REF RESPONSIBLE, " +
			"STOP_SALE_ACTION, " +
			"STOP_SALE_ACTION_REF ACTION, " +
			"STOP_SALE_BATCH, " +
			"STOP_SALE_VARIETY, " +
			"VARIETY_REF, " +
			"STOP_SALE_DOCUMENTATION, " +
			"STOP_SALE_REASON, " +
			"STOP_SALE_REASON_REF " +
		"WHERE " +
			"YEAR_REF.YEAR_ID = STOP_SALE.SALES_YEAR_ID    AND " +
			"STATUS_REF.STATUS_ID = STOP_SALE.STATUS_ID    AND " +
			"REGION_REF.REGION_ID = STOP_SALE.REGION_ID    AND " +
			"CROP_REF.CROP_ID(+) = STOP_SALE.CROP_ID    AND " +
			"SEED_SIZE_REF.SEED_SIZE_ID(+) = STOP_SALE.SEED_SIZE_ID    AND " +
			"QTY_UOM_REF.QTY_UOM_ID(+) = STOP_SALE.QTY_UOM_ID    AND " +
			"STATE_REF.STATE_ID(+) = STOP_SALE.STATE_ID    AND " +
			"STOP_SALE.REPORTING_LOCATION_CODE = REPORTING.LOCATION_CODE(+)    AND " +
			"STOP_SALE.SHIPPING_LOCATION_CODE = SHIPPING.LOCATION_CODE(+)    AND " +
			"STOP_SALE.RESPONSIBLE_PLANT_CODE = RESPONSIBLE.LOCATION_CODE(+)    AND " +
			"STOP_SALE_ACTION.STOP_SALE_ID(+) = STOP_SALE.STOP_SALE_ID    AND " +
			"STOP_SALE_ACTION.STOP_SALE_ACTION_ID =    ACTION.STOP_SALE_ACTION_ID(+) AND " +
			"STOP_SALE.STOP_SALE_ID = STOP_SALE_BATCH.STOP_SALE_ID(+)    AND " +
			"STOP_SALE.STOP_SALE_ID = STOP_SALE_VARIETY.STOP_SALE_ID(+)    AND " +
			"VARIETY_REF.VARIETY_ID(+) = STOP_SALE_VARIETY.VARIETY_ID    AND " +
			"STOP_SALE.STOP_SALE_ID = STOP_SALE_DOCUMENTATION.STOP_SALE_ID(+)    AND " +
			"STOP_SALE.STOP_SALE_ID = STOP_SALE_REASON.STOP_SALE_ID(+)    AND " +
			"STOP_SALE_REASON_REF.STOP_SALE_REASON_ID(+) =    STOP_SALE_REASON.STOP_SALE_REASON_ID ";
	
	/**
	 * Constructor.
	 * @exception DAOException
	 */	
	public StopSaleDAOImpl() throws DAOException {
		
	}
	
	public String insertStopSale(StopSaleObject stopSale) throws DAOException{
		
		logger.info("StopSaleDAO: Executing insertStopSale() operation...");
		
		//**Imp Variables...
		int stopSaleID = 0;		
		String stopSaleNumber = "";
		
		Date oracleSysdate = new Date(System.currentTimeMillis());
		
		Connection conn = null;
	
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			//**Get Connection...
			conn = getConnection();
			
			//**Get the oracle sysdate...
			//oracleSysdate = getOracleSysDate(conn);
			
			//**Get the stopSale_seq value...
			stopSaleID = getStopSaleSeqValue(conn);
			
			//**Get the auto-generated stopSale_no...
			stopSaleNumber = createStopSaleNumber(stopSale, conn);
			
			//**Perform Insert-Operation...dynamic query...
			insertStopSaleObject(stopSaleID, stopSaleNumber, oracleSysdate, stopSale, conn);
			
			//**Insert StopSale Doc...dynamic query...
			insertStopSaleDoc(stopSaleID, oracleSysdate, stopSale, conn);
			
			//****Insert Varieties...
			if(stopSale.getVariety_one() != null && !stopSale.getVariety_one().equals("0")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_one(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_two() != null && !stopSale.getVariety_two().equals("0")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_two(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_three() != null && !stopSale.getVariety_three().equals("0")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_three(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_four() != null && !stopSale.getVariety_four().equals("0")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_four(), INSERT_STOP_SALE_VARIETY, conn);
			}
			
			//****Insert Batches...
			if(stopSale.getBatch_one() != null && !stopSale.getBatch_one().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_one(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_two() != null && !stopSale.getBatch_two().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_two(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_three() != null && !stopSale.getBatch_three().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_three(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_four() != null && !stopSale.getBatch_four().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_four(), INSERT_STOP_SALE_BATCH, conn);
			}
			
			//****Insert Reasons...
			if(stopSale.isSeedCount()){
				insertStopSaleRef(stopSaleID, "1", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isGermination()){
				insertStopSaleRef(stopSaleID, "2", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isPurity()){
				insertStopSaleRef(stopSaleID, "3", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isTagDate()){
				insertStopSaleRef(stopSaleID, "4", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isOtherReason()){
				insertStopSaleRef(stopSaleID, "5", INSERT_STOP_SALE_REASON, conn);
			}
			
			//****Insert Action Flags...
			if(stopSale.isReLabel()){
				insertStopSaleRef(stopSaleID, "1", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isRecount()){
				insertStopSaleRef(stopSaleID, "2", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isDump()){
				insertStopSaleRef(stopSaleID, "3", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isRestrict()){
				insertStopSaleRef(stopSaleID, "4", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isOtherActionFlag()){
				insertStopSaleRef(stopSaleID, "5", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			
			logger.info("Stop Sale Insert done...!!!");
			
			//**Return both the stopsale-number and stopSale_id
			return stopSaleNumber + ";" + stopSaleID;
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSale()...");
			logger.error("SQLException while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSale()...");
			logger.error("Exception while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		finally {
			try {
				//**Close the result sets, statement and connection.
				if (rs != null) 
					rs.close();
				
				if (ps != null) 
					ps.close();
				
				this.closeConnection(conn);
			} 
			catch(SQLException ex) {
				logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSale()...");
				logger.error("SQLException while closing: " + ex.getMessage());
				throw new DAOException(ex);
			}
		}
	}
	
	
	public boolean updateStopSale(StopSaleObject stopSale) throws DAOException{
		
		logger.info("StopSaleDAO: Executing updateStopSale() operation...");
		
		int stopSaleID = 0;
		
		//**Imp Variables...
		if(stopSale.getStopSaleID() != null){	
			stopSaleID = Integer.parseInt(stopSale.getStopSaleID());
		}
		
		Date oracleSysdate = new Date(System.currentTimeMillis());
		
		Connection conn = null;
	
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			//**Get Connection...
			conn = getConnection();
			
			//**Get the oracle sysdate...
			//oracleSysdate = getOracleSysDate(conn);
					
			//**Perform Update-Operation...dynamic query...
			updateStopSaleObject(stopSaleID, oracleSysdate, stopSale, conn);
			
			//**Update StopSale Doc...dynamic query...
			updateStopSaleDoc(stopSaleID, oracleSysdate, stopSale, conn);
			
			
			//**Delete existing variety, batch, reason and action-flag...
			deleteStopSaleRef(stopSaleID, conn);
			
			
			//****Insert Varieties...
			if(stopSale.getVariety_one() != null && !stopSale.getVariety_one().equals("0") 
					&& !stopSale.getVariety_one().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_one(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_two() != null && !stopSale.getVariety_two().equals("0")
					&&!stopSale.getVariety_two().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_two(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_three() != null && !stopSale.getVariety_three().equals("0")
					&& !stopSale.getVariety_three().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_three(), INSERT_STOP_SALE_VARIETY, conn);
			}
			if(stopSale.getVariety_four() != null && !stopSale.getVariety_four().equals("0")
					&& !stopSale.getVariety_four().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getVariety_four(), INSERT_STOP_SALE_VARIETY, conn);
			}
			
			//****Insert Batches...
			if(stopSale.getBatch_one() != null && !stopSale.getBatch_one().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_one(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_two() != null && !stopSale.getBatch_two().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_two(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_three() != null && !stopSale.getBatch_three().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_three(), INSERT_STOP_SALE_BATCH, conn);
			}
			if(stopSale.getBatch_four() != null && !stopSale.getBatch_four().equals("")){
				insertStopSaleRef(stopSaleID, stopSale.getBatch_four(), INSERT_STOP_SALE_BATCH, conn);
			}
			
			//****Insert Reasons...
			if(stopSale.isSeedCount()){
				insertStopSaleRef(stopSaleID, "1", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isGermination()){
				insertStopSaleRef(stopSaleID, "2", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isPurity()){
				insertStopSaleRef(stopSaleID, "3", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isTagDate()){
				insertStopSaleRef(stopSaleID, "4", INSERT_STOP_SALE_REASON, conn);
			}
			if(stopSale.isOtherReason()){
				insertStopSaleRef(stopSaleID, "5", INSERT_STOP_SALE_REASON, conn);
			}
			
			//****Insert Action Flags...
			if(stopSale.isReLabel()){
				insertStopSaleRef(stopSaleID, "1", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isRecount()){
				insertStopSaleRef(stopSaleID, "2", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isDump()){
				insertStopSaleRef(stopSaleID, "3", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isRestrict()){
				insertStopSaleRef(stopSaleID, "4", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			if(stopSale.isOtherActionFlag()){
				insertStopSaleRef(stopSaleID, "5", INSERT_STOP_SALE_ACTION_FLAG, conn);
			}
			
			logger.info("Stop Sale Update done...!!!");
			
			//**Return boolean
			return true;
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSale()...");
			logger.error("SQLException while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSale()...");
			logger.error("Exception while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		finally {
			try {
				//**Close the result sets, statement and connection.
				if (rs != null) 
					rs.close();
				
				if (ps != null) 
					ps.close();
				
				this.closeConnection(conn);
			} 
			catch(SQLException ex) {
				logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSale()...");
				logger.error("SQLException while closing: " + ex.getMessage());
				throw new DAOException(ex);
			}
		}
	}
	
	
	public StopSaleObject getStopSale(int stopSaleID) throws DAOException{
		
		logger.info("StopSaleDAO: Executing getStopSale() for stop_Sale_id: " + stopSaleID);
		
		Connection conn = null;
	
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		StopSaleObject stopSale = new StopSaleObject();
		
		try{
			//**Get Connection...
			conn = getConnection();
								
			//**Implement View Table: Stop_Sale (each function sets diff parts of stopSale...)
			getStopSaleObj(stopSaleID, stopSale, conn);
			
			//**Implement View Table: Stop_Sale_DOC
			getStopSaleDoc(stopSaleID, stopSale, conn);
			
			//**Implement View Table: Stop_Sale_VARIETY
			getStopSaleVariety(stopSaleID, stopSale, conn);
			
			//**Implement View Table: Stop_Sale_BATCH
			getStopSaleBatch(stopSaleID, stopSale, conn);
			
			//**Implement View Table: Stop_Sale_REASON
			getStopSaleReason(stopSaleID, stopSale, conn);
			
			//**Implement View Table: Stop_Sale_ACTION_FLAG
			getStopSaleAction(stopSaleID, stopSale, conn);
			
			//**Implement View Table: CPAR
			getStopSaleCar(stopSaleID, stopSale, conn);
			
			logger.info("GET Stop_Sale done...!!!");
			
			//**Return boolean
			return stopSale;			
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSale()...");
			logger.error("SQLException while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSale()...");
			logger.error("Exception while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		finally {
			try {
				//**Close the result sets, statement and connection.
				if (rs != null) 
					rs.close();
				
				if (ps != null) 
					ps.close();
				
				this.closeConnection(conn);
			} 
			catch(SQLException ex) {
				logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSale()...");
				logger.error("SQLException while closing: " + ex.getMessage());
				throw new DAOException(ex);
			}
		}
	}
	
	public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws DAOException{
		
		Connection conn = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		int stopSaleID = 0;
		
		try{
			conn = getConnection();
			
			ps = conn.prepareStatement("SELECT STOP_SALE_ID FROM STOP_SALE WHERE CONTROL_NUMBER = '" + stopSaleNumber +"'");
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				stopSaleID = rs.getInt("STOP_SALE_ID");
			}
		}
		catch(Exception ex){
			logger.error("Database error while getting stop_sale_id.");
		}
		
		return getStopSale(stopSaleID);
	}
	
	public String getStopSaleNumberFromID(int stopSaleID) throws DAOException{
		Connection conn = null;
	
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String stopSaleNumber = "";
		
		try{
			//**Get Connection...
			conn = getConnection();
								
			try{
				ps = conn.prepareStatement(GET_STOP_SALE_NO);
				ps.setInt(1, stopSaleID);
				
				rs = ps.executeQuery();
				
				while(rs.next()){
					stopSaleNumber = rs.getString("STOP_SALE_NUMBER");
				}
			}
			catch(Exception ex){
				logger.error("Database error while getting stop sale no.");
			}
			
			return stopSaleNumber;			
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleNo()...");
			logger.error("SQLException while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleNo()...");
			logger.error("Exception while getting connection: " + e.getMessage());
			throw new DAOException(e);
		}
		finally {
			try {
				//**Close the result sets, statement and connection.
				if (rs != null) 
					rs.close();
				
				if (ps != null) 
					ps.close();
				
				this.closeConnection(conn);
			} 
			catch(SQLException ex) {
				logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleNo()...");
				logger.error("SQLException while closing: " + ex.getMessage());
				throw new DAOException(ex);
			}
		}
	}
	
	public LinkedHashMap getStopSaleList(StopSaleListObject stopSale, String intPage,boolean getMax, String sortCrit, String sortOrd) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer whereClause = new StringBuffer();
		List paramList = new ArrayList();
		LinkedHashMap stopSaleMap = new LinkedHashMap();
		
		try{
			int Page = Integer.parseInt(intPage);
			
			if (!(stopSale.getControlNumber().equals(null)) && !(stopSale.getControlNumber().equals("")))
				paramList.add("controlNumber");
			if (!(stopSale.getStatus().equals(null)) && !(stopSale.getStatus().equals("")) && !(stopSale.getStatus().equals("0")))
				paramList.add("status");
			if (!(stopSale.getResponsibleLocation().equals(null)) && !(stopSale.getResponsibleLocation().equals("")))
				paramList.add("responsibleLocation");
			if (!(stopSale.getRegion().equals(null)) && !(stopSale.getRegion().equals("")) && !(stopSale.getRegion().equals("0")))
				paramList.add("region");			
			if (!(stopSale.getCrop().equals(null)) && !(stopSale.getCrop().equals("")))
				paramList.add("crop");
			if (!(stopSale.getDealer().equals(null)) && !(stopSale.getDealer().equals("")))
				paramList.add("dealer");
			if (!(stopSale.getFillingLocation().equals(null)) && !(stopSale.getFillingLocation().equals("")))
				paramList.add("fillingLocation");
			if (!(stopSale.getShippingLocation().equals(null)) && !(stopSale.getShippingLocation().equals("")))
				paramList.add("shippingLocation");
			if (!(stopSale.getSalesYear().equals(null)) && !(stopSale.getSalesYear().equals("")) && !(stopSale.getSalesYear().equals("0")))
				paramList.add("salesYear");
			if (!(stopSale.getInitiatedBy().equals(null)) && !(stopSale.getInitiatedBy().equals("")))
				paramList.add("initiatedBy");
			
			conn = getConnection();
			
			if (paramList.size() > 0){
				whereClause.append(" WHERE ");
			}		
			
			for (int i =0; i<paramList.size(); i++){
				if (paramList.get(i).equals("controlNumber")){
					whereClause.append("UPPER(S.CONTROL_NUMBER) = UPPER('" + stopSale.getControlNumber().trim() + "')");
				}
				if (paramList.get(i).equals("status")){
					whereClause.append("S.STATUS_ID = '" + stopSale.getStatus() + "'");
				}
				if (paramList.get(i).equals("responsibleLocation")){
					whereClause.append("S.RESPONSIBLE_PLANT_CODE = '" + stopSale.getResponsibleLocation() + "'");
				}
				if (paramList.get(i).equals("region")){
					whereClause.append("S.REGION_ID = '" + stopSale.getRegion() + "'");
				}				
				if (paramList.get(i).equals("crop")){
					whereClause.append("S.CROP_ID = '" + stopSale.getCrop() + "'");
				}
				if (paramList.get(i).equals("dealer")){
					whereClause.append("UPPER(S.DEALER) LIKE UPPER('" + stopSale.getDealer() + "%')");
				}
				if (paramList.get(i).equals("fillingLocation")){
					whereClause.append("S.REPORTING_LOCATION_CODE = '" + stopSale.getFillingLocation() + "'");
				}
				if (paramList.get(i).equals("shippingLocation")){
					whereClause.append("S.SHIPPING_LOCATION_CODE = '" + stopSale.getShippingLocation() + "'");
				}
				if (paramList.get(i).equals("salesYear")){
					whereClause.append("S.SALES_YEAR_ID = '" + stopSale.getSalesYear() + "'");
				}
				if (paramList.get(i).equals("initiatedBy")){
					whereClause.append("UPPER(S.REPORT_INITIATOR) LIKE UPPER('" + stopSale.getInitiatedBy() + "%')");
				}
				if (i < paramList.size() - 1)
					whereClause.append(" AND ");					
			}
			
			ps = conn.prepareStatement(GET_STOP_SALE_LIST_COUNT + whereClause.toString());
			
			logger.info(GET_STOP_SALE_LIST_COUNT + whereClause.toString());
			
			rs = ps.executeQuery();
			
			if (rs.next()){
				stopSaleMap.put("maxRows", rs.getString("MAX_ROWS"));
			}
			
			whereClause.append("ORDER BY Lower("  +  sortCrit + ") " + sortOrd  + " )) WHERE RANKING BETWEEN " + ((Page*10) - 9) + " AND " + Page*10);
			
			ps = conn.prepareStatement(GET_STOP_SALE_LIST + whereClause.toString());
			
			logger.info(GET_STOP_SALE_LIST + whereClause.toString());
			
			rs = ps.executeQuery();
			
			while (rs.next()){
				
				StopSaleListObject stopSaleRow = new StopSaleListObject();
				
				stopSaleRow.setStopSaleID(rs.getString("STOP_SALE_ID"));
				stopSaleRow.setControlNumber(rs.getString("CONTROL_NUMBER"));
				stopSaleRow.setStatus(rs.getString("STATUS"));
				stopSaleRow.setResponsibleLocation(rs.getString("RESPONSIBLE_LOCATION"));
				stopSaleRow.setRegion(rs.getString("REGION"));
				stopSaleRow.setCrop(rs.getString("CROP"));
				stopSaleRow.setDealer(rs.getString("DEALER"));
				
				stopSaleMap.put(rs.getString("STOP_SALE_ID"), stopSaleRow);
			}
			
			return stopSaleMap;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	  //**Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}			
	}
	
	public HashMap getStopSaleReport(StopSaleFilter stopSaleFilter) throws DAOException{
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer whereClause = new StringBuffer();
		HashMap hash = new HashMap();
		
		try{
			conn = getConnection();
			
			if ((stopSaleFilter.getControlNumber() != null) && !(stopSaleFilter.getControlNumber().equals(""))){
				whereClause.append(" AND UPPER(STOP_SALE.CONTROL_NUMBER) LIKE UPPER('" + stopSaleFilter.getControlNumber().trim() + "%') ");
			}
			if ((stopSaleFilter.getInitiatedBy() != null) && !(stopSaleFilter.getInitiatedBy().equals(""))){
				whereClause.append(" AND UPPER(STOP_SALE.REPORT_INITIATOR) LIKE UPPER('" + stopSaleFilter.getInitiatedBy().trim() + "%') ");
			}
			if ((stopSaleFilter.getDateReported() != null) && !(stopSaleFilter.getDateReported().equals(""))){
				whereClause.append(" AND STOP_SALE.DATE_REPORTED = TO_DATE('" + getDateFormat(new Date(new java.util.Date(stopSaleFilter.getDateReported()).getTime())) + "', 'MM/DD/YYYY') ");
			}
			if ((stopSaleFilter.getInvestigator() != null) && !(stopSaleFilter.getInvestigator().equals(""))){
				whereClause.append(" AND UPPER(STOP_SALE.PERSON_INVESTIGATING) LIKE UPPER('" + stopSaleFilter.getInvestigator().trim() + "%') ");
			}
			if ((stopSaleFilter.getBatchNumber() != null) && !(stopSaleFilter.getBatchNumber().equals(""))){
				whereClause.append(" AND UPPER(STOP_SALE_BATCH.BATCH_NUMBER) LIKE UPPER('" + stopSaleFilter.getBatchNumber().trim() + "%') ");
			}			
			if ((stopSaleFilter.getStatus() != null) && (stopSaleFilter.getStatus().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.STATUS_ID IN ", stopSaleFilter.getStatus()));				
			}
			if ((stopSaleFilter.getRegion() != null) && (stopSaleFilter.getRegion().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.REGION_ID IN ", stopSaleFilter.getRegion()));				
			}
			if ((stopSaleFilter.getSalesYear() != null) && (stopSaleFilter.getSalesYear().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.SALES_YEAR_ID IN ", stopSaleFilter.getSalesYear()));				
			}
			if ((stopSaleFilter.getState() != null) && (stopSaleFilter.getState().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.STATE_ID IN ", stopSaleFilter.getState()));				
			}
			if ((stopSaleFilter.getCrop() != null) && (stopSaleFilter.getCrop().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.CROP_ID IN ", stopSaleFilter.getCrop()));				
			}
			if ((stopSaleFilter.getFilingLocation() != null) && (stopSaleFilter.getFilingLocation().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.REPORTING_LOCATION_CODE IN ", stopSaleFilter.getFilingLocation()));				
			}
			if ((stopSaleFilter.getResponsibleLocation() != null) && (stopSaleFilter.getResponsibleLocation().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.RESPONSIBLE_PLANT_CODE IN ", stopSaleFilter.getResponsibleLocation()));				
			}
			if ((stopSaleFilter.getShippingLocation() != null) && (stopSaleFilter.getShippingLocation().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE.SHIPPING_LOCATION_CODE IN ", stopSaleFilter.getShippingLocation()));				
			}
			if ((stopSaleFilter.getVariety() != null) && (stopSaleFilter.getVariety().length > 0)){
				whereClause.append(getSelectedFields(" AND STOP_SALE_VARIETY.VARIETY_ID IN ", stopSaleFilter.getVariety()));				
			}
			
			whereClause.append(getStopSaleReason(stopSaleFilter));
			whereClause.append(getStopSaleAction(stopSaleFilter));
			
			logger.info(GET_STOP_SALE_REPORT + whereClause.toString());
			
			ps = conn.prepareStatement(GET_STOP_SALE_REPORT + whereClause.toString());
			
			rs = ps.executeQuery();
			
			int rowCount = 0;
			while (rs.next()){
				
				rowCount++;
				
				//** Fill in the RowBean Object...
				RowBean rowBean = new RowBean();
				
				if(rs.getString("CONTROL_NUMBER") != null && !(rs.getString("CONTROL_NUMBER").trim().equals(""))){
					rowBean.setCol1(rs.getString("CONTROL_NUMBER"));
				}
				else{
					rowBean.setCol1("-");
				}
				if(rs.getString("YEAR") != null && !(rs.getString("YEAR").trim().equals(""))){
					rowBean.setCol2(rs.getString("YEAR"));
				}
				else{
					rowBean.setCol2("-");
				}
				if(rs.getString("STATUS") != null && !(rs.getString("STATUS").trim().equals(""))){
					rowBean.setCol3(rs.getString("STATUS"));
				}
				else{
					rowBean.setCol3("-");
				}
				if(rs.getString("REPORT_INITIATOR") != null && !(rs.getString("REPORT_INITIATOR").trim().equals(""))){
					rowBean.setCol4(rs.getString("REPORT_INITIATOR"));
				}
				else{
					rowBean.setCol4("-");
				}
				if(rs.getString("PERSON_INVESTIGATING") != null && !(rs.getString("PERSON_INVESTIGATING").trim().equals(""))){
					rowBean.setCol5(rs.getString("PERSON_INVESTIGATING"));
				}
				else{
					rowBean.setCol5("-");
				}
				if(rs.getString("FIELD_COMMUNICATOR") != null && !(rs.getString("FIELD_COMMUNICATOR").trim().equals(""))){
					rowBean.setCol6(rs.getString("FIELD_COMMUNICATOR"));
				}
				else{
					rowBean.setCol6("-");
				}
				if(rs.getString("CROP") != null && !(rs.getString("CROP").trim().equals(""))){
					rowBean.setCol7(rs.getString("CROP"));
				}
				else{
					rowBean.setCol7("-");
				}
				if(rs.getString("SEED_SIZE") != null && !(rs.getString("SEED_SIZE").trim().equals(""))){
					rowBean.setCol8(rs.getString("SEED_SIZE"));
				}
				else{
					rowBean.setCol8("-");
				}
				if(rs.getString("QTY_AFFECTED") != null && !(rs.getString("QTY_AFFECTED").trim().equals(""))){
					rowBean.setCol9(rs.getString("QTY_AFFECTED"));
				}
				else{
					rowBean.setCol9("-");
				}
				if(rs.getString("UOM") != null && !(rs.getString("UOM").trim().equals(""))){
					rowBean.setCol10(rs.getString("UOM"));
				}
				else{
					rowBean.setCol10("-");
				}
				if(rs.getString("QUALITY_ISSUE_FLAG") != null && !(rs.getString("QUALITY_ISSUE_FLAG").trim().equals(""))){
					rowBean.setCol11(rs.getString("QUALITY_ISSUE_FLAG"));
				}
				else{
					rowBean.setCol11("-");
				}
				if(rs.getString("DEALER") != null && !(rs.getString("DEALER").trim().equals(""))){
					rowBean.setCol12(rs.getString("DEALER"));
				}
				else{
					rowBean.setCol12("-");
				}
				if(rs.getString("DEALER_PHONE_NO") != null && !(rs.getString("DEALER_PHONE_NO").trim().equals(""))){
					rowBean.setCol13(rs.getString("DEALER_PHONE_NO"));
				}
				else{
					rowBean.setCol13("-");
				}
				if(rs.getString("STATE_VALUE") != null && !(rs.getString("STATE_VALUE").trim().equals(""))){
					rowBean.setCol14(rs.getString("STATE_VALUE"));
				}
				else{
					rowBean.setCol14("-");
				}
				if(rs.getString("STATE_RETEST") != null && !(rs.getString("STATE_RETEST").trim().equals(""))){
					rowBean.setCol15(rs.getString("STATE_RETEST"));
				}
				else{
					rowBean.setCol15("-");
				}
				if(rs.getString("STATE_REPORT_NUMBER") != null && !(rs.getString("STATE_REPORT_NUMBER").trim().equals(""))){
					rowBean.setCol16(rs.getString("STATE_REPORT_NUMBER"));
				}
				else{
					rowBean.setCol16("-");
				}
				if(rs.getString("STATE_CONTACT") != null && !(rs.getString("STATE_CONTACT").trim().equals(""))){
					rowBean.setCol17(rs.getString("STATE_CONTACT"));
				}
				else{
					rowBean.setCol17("-");
				}
				if(rs.getString("STATE_PHONE_NUMBER") != null && !(rs.getString("STATE_PHONE_NUMBER").trim().equals(""))){
					rowBean.setCol18(rs.getString("STATE_PHONE_NUMBER"));
				}
				else{
					rowBean.setCol18("-");
				}
				if(rs.getDate("DATE_REPORTED") != null){
					rowBean.setCol19(getDateFormat(rs.getDate("DATE_REPORTED")));
				}
				else{
					rowBean.setCol19("-");
				}
				if(rs.getString("MONSANTO_VALUE") != null && !(rs.getString("MONSANTO_VALUE").trim().equals(""))){
					rowBean.setCol20(rs.getString("MONSANTO_VALUE"));
				}
				else{
					rowBean.setCol20("-");
				}
				if(rs.getString("LABEL_VALUE") != null && !(rs.getString("LABEL_VALUE").trim().equals(""))){
					rowBean.setCol21(rs.getString("LABEL_VALUE"));
				}
				else{
					rowBean.setCol21("-");
				}
				if(rs.getString("ACTION_COMMENTS") != null && !(rs.getString("ACTION_COMMENTS").trim().equals(""))){
					rowBean.setCol22(rs.getString("ACTION_COMMENTS"));
				}
				else{
					rowBean.setCol22("-");
				}
				if(rs.getString("REGION_DESCRIPTION") != null && !(rs.getString("REGION_DESCRIPTION").trim().equals(""))){
					rowBean.setCol23(rs.getString("REGION_DESCRIPTION"));
				}
				else{
					rowBean.setCol23("-");
				}
				if(rs.getString("STATE_LONG_NAME") != null && !(rs.getString("STATE_LONG_NAME").trim().equals(""))){
					rowBean.setCol24(rs.getString("STATE_LONG_NAME"));
				}
				else{
					rowBean.setCol24("-");
				}
				if(rs.getString("REPORTING_LOCATION") != null && !(rs.getString("REPORTING_LOCATION").trim().equals(""))){
					rowBean.setCol25(rs.getString("REPORTING_LOCATION"));
				}
				else{
					rowBean.setCol25("-");
				}
				if(rs.getString("SHIPPING_LOCATION") != null && !(rs.getString("SHIPPING_LOCATION").trim().equals(""))){
					rowBean.setCol26(rs.getString("SHIPPING_LOCATION"));
				}
				else{
					rowBean.setCol26("-");
				}
				if(rs.getString("RESPONSIBLE_LOCATION") != null && !(rs.getString("RESPONSIBLE_LOCATION").trim().equals(""))){
					rowBean.setCol27(rs.getString("RESPONSIBLE_LOCATION"));
				}
				else{
					rowBean.setCol27("-");
				}
				if(rs.getString("ACTION") != null && !(rs.getString("ACTION").trim().equals(""))){
					rowBean.setCol28(rs.getString("ACTION"));
				}
				else{
					rowBean.setCol28("-");
				}
				if(rs.getString("REASON") != null && !(rs.getString("REASON").trim().equals(""))){
					rowBean.setCol29(rs.getString("REASON"));
				}
				else{
					rowBean.setCol29("-");
				}
				if(rs.getString("BATCH_NUMBER") != null && !(rs.getString("BATCH_NUMBER").trim().equals(""))){
					rowBean.setCol30(rs.getString("BATCH_NUMBER"));
				}
				else{
					rowBean.setCol30("-");
				}
				if(rs.getString("VARIETY") != null && !(rs.getString("VARIETY").trim().equals(""))){
					rowBean.setCol31(rs.getString("VARIETY"));
				}
				else{
					rowBean.setCol31("-");
				}
				if(rs.getString("INVESTIGATION_FINDINGS") != null && !(rs.getString("INVESTIGATION_FINDINGS").trim().equals(""))){
					rowBean.setCol32(rs.getString("INVESTIGATION_FINDINGS"));
				}
				else{
					rowBean.setCol32("-");
				}
				if(rs.getString("LONG_TERM_CORRECTION_ACTION") != null && !(rs.getString("LONG_TERM_CORRECTION_ACTION").trim().equals(""))){
					rowBean.setCol33(rs.getString("LONG_TERM_CORRECTION_ACTION"));
				}
				else{
					rowBean.setCol33("-");
				}
				if(rs.getString("ROOT_CAUSE") != null && !(rs.getString("ROOT_CAUSE").trim().equals(""))){
					rowBean.setCol34(rs.getString("ROOT_CAUSE"));
				}
				else{
					rowBean.setCol34("-");
				}
				if(rs.getString("CONTAINMENT_ACTION") != null && !(rs.getString("CONTAINMENT_ACTION").trim().equals(""))){
					rowBean.setCol35(rs.getString("CONTAINMENT_ACTION"));
				}
				else{
					rowBean.setCol35("-");
				}
				
				
				hash.put(rowCount + "", rowBean);
			}
			
			return hash;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	  //**Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}
	
	/**
	 * Method to set the ss_reason fields...
	 * 
	 * @param complaintFilter
	 * @return
	 */
	private StringBuffer getStopSaleReason(StopSaleFilter stopSaleFilter){
		
		StringBuffer issuesClause = new StringBuffer();
		
		List paramList = new ArrayList();
		
		if (stopSaleFilter.isSeedCount()){
			paramList.add("1");
		}
		if (stopSaleFilter.isGermination()){
			paramList.add("2");
		}
		if (stopSaleFilter.isPurity()){
			paramList.add("3");
		}
		if (stopSaleFilter.isTagDate()){
			paramList.add("4");
		}
		if (stopSaleFilter.isOtherReason()){
			paramList.add("5");
		}
		
		int size = paramList.size();
		
		if(size > 0){
			issuesClause.append(" AND STOP_SALE_REASON.STOP_SALE_REASON_ID IN ");
		}
		else{
			issuesClause.append("");
			return issuesClause;
		}
		
		issuesClause.append("(");
		
		for(int i = 0; i < size; i++){
			
			issuesClause.append("'" + paramList.get(i).toString() + "'");
			
			if (i < size - 1){
				issuesClause.append(",");
			}
		}
		
		issuesClause.append(")");
		
		return issuesClause;
	}
	
	/**
	 * Method to set the ss_action fields...
	 * 
	 * @param complaintFilter
	 * @return
	 */
	private StringBuffer getStopSaleAction(StopSaleFilter stopSaleFilter){
		
		StringBuffer issuesClause = new StringBuffer();
		
		
		List paramList = new ArrayList();
		
		if (stopSaleFilter.isReLabel()){
			paramList.add("1");
		}
		if (stopSaleFilter.isRecount()){
			paramList.add("2");
		}
		if (stopSaleFilter.isDump()){
			paramList.add("3");
		}
		if (stopSaleFilter.isRestrict()){
			paramList.add("4");
		}
		if (stopSaleFilter.isOtherActionFlag()){
			paramList.add("5");
		}
		
		int size = paramList.size();
		
		if(size > 0){
			issuesClause.append(" AND STOP_SALE_ACTION.STOP_SALE_ACTION_ID IN ");
		}
		else{
			issuesClause.append("");
			return issuesClause;
		}
		
		issuesClause.append("(");
		
		for(int i = 0; i < size; i++){
			
			issuesClause.append("'" + paramList.get(i).toString() + "'");
			
			if (i < size - 1){
				issuesClause.append(",");
			}
		}
		
		issuesClause.append(")");
		
		return issuesClause;
	}
	
	/**
	 * This method just makes a string out of selected fields like ('1744', '1745',...)
	 * 
	 * @param strArray
	 * @return
	 */
	private StringBuffer getSelectedFields(String query, String[] strArray){
		
		int size = strArray.length;
		
		StringBuffer fieldClause = new StringBuffer();
		fieldClause.append("");
		
		//**To remove the null elements...
		for(int i = 0; i < size; i++){
			
			if(strArray[i].equals("") || strArray[i].equals("0")){
				size--;
			}
		}
		
		if(size == 0){
			return fieldClause;
		}
		
		fieldClause.append(query + "(");
		
		for(int i = 0; i < strArray.length; i++){
			
			//**Skip null elements...
			if(strArray[i].equals("") || strArray[i].equals("0")){
				continue;
			}
			
			fieldClause.append("'" + strArray[i].trim() + "'");
			
			if (i < strArray.length - 1){
				fieldClause.append(",");
			}
		}
		
		fieldClause.append(")");
		
		return fieldClause;
	}
	
	/**
	 * To get the data from main table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleObj(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				stopSale.setStopSaleID(rs.getString("STOP_SALE_ID"));
				stopSale.setControlNumber(rs.getString("CONTROL_NUMBER"));
				stopSale.setReportDate(getDateFormat(rs.getDate("REPORT_DATE")));
				stopSale.setInvestigator(rs.getString("INVESTIGATOR"));
				stopSale.setRegion(rs.getString("REGION"));
				stopSale.setInitiatedBy(rs.getString("INITIATED_BY"));
				stopSale.setFillingLocation(rs.getString("FILLING_LOCATION"));
				stopSale.setSalesYear(rs.getString("SALES_YEAR_ID"));
				stopSale.setStateID(rs.getString("STATE_ID"));
				stopSale.setStatus(rs.getString("STATUS_ID"));
				stopSale.setCreatedBy(rs.getString("CREATED_BY"));
				stopSale.setResponsibleLocation(rs.getString("RESPONSIBLE_LOCATION"));
				stopSale.setFieldCommunicator(rs.getString("FIELD_COMMUNICATOR"));
				stopSale.setShippingLocation(rs.getString("SHIPPING_LOCATION"));
				stopSale.setDealer(rs.getString("DEALER"));
				stopSale.setDealerPhone(rs.getString("DEALER_PHONE_NO"));
				stopSale.setStateReportNumber(rs.getString("STATE_REPORT_NUMBER"));
				stopSale.setStateValue(rs.getString("STATE_VALUE"));
				stopSale.setStateContact(rs.getString("STATE_CONTACT"));
				stopSale.setStatePhone(rs.getString("STATE_PHONE_NUMBER"));
				stopSale.setStateRetest(rs.getString("STATE_RETEST"));
				stopSale.setMonsantoValue(rs.getString("MONSANTO_VALUE"));
				stopSale.setCropID(rs.getString("CROP_ID"));
				stopSale.setLabelValue(rs.getString("LABEL_VALUE"));
				stopSale.setQualityIssue(rs.getString("QUALITY_ISSUE_FLAG"));
				stopSale.setQuantityAffected(rs.getString("QTY_AFFECTED"));
				stopSale.setQualityUomID(rs.getString("QTY_UOM_ID"));
				stopSale.setSeedSizeID(rs.getString("SEED_SIZE_ID"));
				stopSale.setActionComments(rs.getString("ACTION_COMMENTS"));
				stopSale.setEntryDate(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleObj()...");
			logger.error("SQLException while getting StopSaleObj: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleObj()...");
			logger.error("Exception while getting StopSaleObj: " + e.getMessage());
		}
		
	}
	
	
	/**
	 * To get the data from Doc table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleDoc(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_DOC);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				stopSale.setInvestigationFindings(rs.getString("INVESTIGATION_FINDINGS"));
				stopSale.setRootCause(rs.getString("ROOT_CAUSE"));
				stopSale.setContainmentAction(rs.getString("CONTAINMENT_ACTION"));
				stopSale.setLongTermCorrectiveAction(rs.getString("LONG_TERM_CORRECTION_ACTION"));				
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleDoc()...");
			logger.error("SQLException while getting StopSaleDoc: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleDoc()...");
			logger.error("Exception while getting StopSaleDoc: " + e.getMessage());
		}
		
	}
	
	/**
	 * To get the data from Cpar table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleCar(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_CAR);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				stopSale.setCarID(rs.getString("CAR_ID"));
				stopSale.setCarNumber(rs.getString("CAR_NUMBER"));
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleCar()...");
			logger.error("SQLException while getting Car: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleCar()...");
			logger.error("Exception while getting Car: " + e.getMessage());
		}		
	}
	
	
	/**
	 * To get the data from Variety table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleVariety(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_VARIETY);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			int cnt = 0;
			while(rs.next()){
				
				if(cnt == 0 && !rs.getString("VARIETY_ID").equals("")){
					stopSale.setVariety_one(rs.getString("VARIETY_ID"));
				}
				if(cnt == 1 && !rs.getString("VARIETY_ID").equals("")){
					stopSale.setVariety_two(rs.getString("VARIETY_ID"));
				}
				if(cnt == 2 && !rs.getString("VARIETY_ID").equals("")){
					stopSale.setVariety_three(rs.getString("VARIETY_ID"));
				}
				if(cnt == 3 && !rs.getString("VARIETY_ID").equals("")){
					stopSale.setVariety_four(rs.getString("VARIETY_ID"));
				}
				
				cnt++;
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleVariety()...");
			logger.error("SQLException while getting Variety: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleVariety()...");
			logger.error("Exception while getting Variety: " + e.getMessage());
		}
		
	}
	
	
	/**
	 * To get the data from Batch table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleBatch(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_BATCH);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			int cnt = 0;
			while(rs.next()){
				
				if(cnt == 0 && !rs.getString("BATCH_NUMBER").equals("")){
					stopSale.setBatch_one(rs.getString("BATCH_NUMBER"));
				}
				if(cnt == 1 && !rs.getString("BATCH_NUMBER").equals("")){
					stopSale.setBatch_two(rs.getString("BATCH_NUMBER"));
				}
				if(cnt == 2 && !rs.getString("BATCH_NUMBER").equals("")){
					stopSale.setBatch_three(rs.getString("BATCH_NUMBER"));
				}
				if(cnt == 3 && !rs.getString("BATCH_NUMBER").equals("")){
					stopSale.setBatch_four(rs.getString("BATCH_NUMBER"));
				}
				
				cnt++;
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleBatch()...");
			logger.error("SQLException while getting Batch: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleBatch()...");
			logger.error("Exception while getting Batch: " + e.getMessage());
		}
		
	}
	
	/**
	 * To get the data from Reason table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleReason(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_REASON);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				
				if(rs.getString("STOP_SALE_REASON_ID").trim().equals("1")){
					stopSale.setSeedCount(true);
				}
				if(rs.getString("STOP_SALE_REASON_ID").trim().equals("2")){
					stopSale.setGermination(true);
				}
				if(rs.getString("STOP_SALE_REASON_ID").trim().equals("3")){
					stopSale.setPurity(true);
				}
				if(rs.getString("STOP_SALE_REASON_ID").trim().equals("4")){
					stopSale.setTagDate(true);
				}
				if(rs.getString("STOP_SALE_REASON_ID").trim().equals("5")){
					stopSale.setOtherReason(true);
				}
				
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleReason()...");
			logger.error("SQLException while getting Reason: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleReason()...");
			logger.error("Exception while getting Reason: " + e.getMessage());
		}
		
	}
	
	
	/**
	 * To get the data from Action table...
	 * @param conn
	 * @return
	 */
	private void getStopSaleAction(int stopSaleID, StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_ACTION);
			ps.setInt(1, stopSaleID);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				
				if(rs.getString("STOP_SALE_ACTION_ID").trim().equals("1")){
					stopSale.setReLabel(true);
				}
				if(rs.getString("STOP_SALE_ACTION_ID").trim().equals("2")){
					stopSale.setRecount(true);
				}
				if(rs.getString("STOP_SALE_ACTION_ID").trim().equals("3")){
					stopSale.setDump(true);
				}
				if(rs.getString("STOP_SALE_ACTION_ID").trim().equals("4")){
					stopSale.setRestrict(true);
				}
				if(rs.getString("STOP_SALE_ACTION_ID").trim().equals("5")){
					stopSale.setOtherActionFlag(true);
				}
				
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleAction()...");
			logger.error("SQLException while getting Action: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getStopSaleAction()...");
			logger.error("Exception while getting Action: " + e.getMessage());
		}
		
	}
	
	/**
	 * To update reqd/optional fields into the STOP_SALE (main) Table.
	 * 
	 * @param stopSaleID
	 * @param oracleSysdate
	 * @param stopSale
	 * @param conn
	 */
	private void updateStopSaleObject(int stopSaleID, Date oracleSysdate,StopSaleObject stopSale,Connection conn){
		
		//**Dynamic Query Formation...
		PreparedStatement ps = null;
		List paramList = new ArrayList();
		
		StringBuffer setClause = new StringBuffer();
		setClause.append(" ");
		
		try{
			
			if(stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")){
				setClause.append(" ,QTY_AFFECTED = ? WHERE STOP_SALE_ID = ?");
			}
			else{
				setClause.append(" WHERE STOP_SALE_ID = ?");
			}
			
			logger.info(UPDATE_STOP_SALE + setClause.toString());
			
			ps = conn.prepareStatement(UPDATE_STOP_SALE + setClause.toString());
			
			ps.setString(1, stopSale.getStatus());
			ps.setString(2, stopSale.getRegion());
			ps.setString(3, stopSale.getFillingLocation());
			ps.setString(4, stopSale.getInitiatedBy());
			ps.setString(5, getDateFormat(new Date(new java.util.Date(stopSale.getReportDate()).getTime())));
			ps.setString(6, stopSale.getSalesYear());
			ps.setString(7, stopSale.getResponsibleLocation());
			ps.setString(8, stopSale.getFieldCommunicator());
			ps.setString(9, stopSale.getStateID());
			ps.setString(10, stopSale.getShippingLocation());
			ps.setString(11, stopSale.getDealer());
			ps.setString(12, stopSale.getDealerPhone());
			ps.setString(13, stopSale.getStateReportNumber());
			ps.setString(14, stopSale.getStateValue());
			ps.setString(15, stopSale.getStateContact());
			ps.setString(16, stopSale.getStatePhone());
			ps.setString(17, stopSale.getStateRetest());
			ps.setString(18, stopSale.getMonsantoValue());
			ps.setString(19, stopSale.getInvestigator());
			ps.setString(20, stopSale.getCropID());
			ps.setString(21, stopSale.getLabelValue());
			ps.setString(22, stopSale.getQualityIssue());
			ps.setString(23, stopSale.getQualityUomID());
			ps.setString(24, stopSale.getSeedSizeID());
			ps.setString(25, stopSale.getActionComments());
			ps.setDate(26, oracleSysdate);
			ps.setString(27, "SS_MODIFY");
			ps.setString(28, stopSale.getCreatedBy());
			
			if(stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")){
				ps.setInt(29, Integer.parseInt(stopSale.getQuantityAffected()));
				ps.setString(30, stopSale.getStopSaleID());
			}
			else{
				ps.setString(29, stopSale.getStopSaleID());
			}
			
			ps.executeUpdate();
			
			conn.commit();
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSale(obj, conn)...");
			logger.error("SQLException while updating: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSale(obj, conn)...");
			logger.error("Exception while updating: " + e.getMessage());
		}
		
	}
	
	private void deleteStopSaleRef(int stopSaleID, Connection conn){
		PreparedStatement ps = null;
		
		//**Delete Variety...
		try{
			ps = conn.prepareStatement(DELETE_STOP_SALE_VARIETY);			
			ps.setInt(1, stopSaleID);			
			ps.executeUpdate();			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("SQLException while deleting variety: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("Exception while deleting variety: " + e.getMessage());
		}
		
		//**Delete Batch...
		try{
			ps = conn.prepareStatement(DELETE_STOP_SALE_BATCH);			
			ps.setInt(1, stopSaleID);			
			ps.executeUpdate();			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("SQLException while deleting batch: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("Exception while deleting batch: " + e.getMessage());
		}
		
		//**Delete Reason...
		try{
			ps = conn.prepareStatement(DELETE_STOP_SALE_REASON);			
			ps.setInt(1, stopSaleID);			
			ps.executeUpdate();			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("SQLException while deleting reason: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("Exception while deleting reason: " + e.getMessage());
		}
		
		//**Delete Action-Flag...
		try{
			ps = conn.prepareStatement(DELETE_STOP_SALE_ACTION_FLAG);			
			ps.setInt(1, stopSaleID);			
			ps.executeUpdate();			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("SQLException while deleting action flags: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: deleteStopSaleRef...");
			logger.error("Exception while deleting action flags: " + e.getMessage());
		}
		
		logger.info("Ref table data for this record deleted...");
	}
	
	
	/**
	 * To update the stop_sale_documentation table...
	 * 
	 * @param stopSaleID
	 * @param stopSale
	 * @param conn
	 */
	private void updateStopSaleDoc(int stopSaleID, Date oracleSysdate, StopSaleObject stopSale, Connection conn){
		PreparedStatement ps = null;
		
		try{
			ps = conn.prepareStatement(UPDATE_STOP_SALE_DOC);
			
			ps.setString(1, stopSale.getInvestigationFindings());
			ps.setString(2, stopSale.getRootCause());
			ps.setString(3, stopSale.getContainmentAction());
			ps.setString(4, stopSale.getLongTermCorrectiveAction());
			ps.setString(5, stopSale.getCreatedBy());
			ps.setString(6, "SS_DOC_MODIFY");
			ps.setDate(7, oracleSysdate);
			ps.setInt(8, stopSaleID);
			
			ps.executeUpdate();
			
			conn.commit();
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSaleDoc...");
			logger.error("SQLException while updating doc: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSaleDoc...");
			logger.error("Exception while updating doc: " + e.getMessage());
		}
	}
	
	/**
	 * To insert reqd/optional fields into the STOP_SALE (main) Table.
	 * 
	 * @param stopSaleID
	 * @param stopSaleNumber
	 * @param oracleSysdate
	 * @param stopSale
	 * @param conn
	 */
	private void insertStopSaleObject(int stopSaleID, String stopSaleNumber, Date oracleSysdate, StopSaleObject stopSale, Connection conn){
		
		//**Dynamic Query Formation...
		PreparedStatement ps = null;
		List paramList = new ArrayList();
		
		
		StringBuffer fieldClause = new StringBuffer();
		fieldClause.append(" ");
		
		try{
			//conn = getConnection();
		
			if(stopSale.getResponsibleLocation() != null && !stopSale.getResponsibleLocation().equals("")){
				paramList.add("ResponsibleLoc");
				fieldClause.append(",RESPONSIBLE_PLANT_CODE ");
			}
			if(stopSale.getFieldCommunicator() != null && !stopSale.getFieldCommunicator().equals("")){
				paramList.add("FieldCommunicator");
				fieldClause.append(",FIELD_COMMUNICATOR ");
			}
			if(stopSale.getShippingLocation() != null && !stopSale.getShippingLocation().equals("")){
				paramList.add("ShippingLoc");
				fieldClause.append(",SHIPPING_LOCATION_CODE ");
			}
			if(stopSale.getDealer() != null && !stopSale.getDealer().equals("")){
				paramList.add("Dealer");
				fieldClause.append(",DEALER ");
			}
			if(stopSale.getDealerPhone() != null && !stopSale.getDealerPhone().equals("")){
				paramList.add("DealerPhone");
				fieldClause.append(",DEALER_PHONE_NO ");
			}
			if(stopSale.getStateReportNumber() != null && !stopSale.getStateReportNumber().equals("")){
				paramList.add("StateRepNo");
				fieldClause.append(",STATE_REPORT_NUMBER ");
			}
			if(stopSale.getStateValue() != null && !stopSale.getStateValue().equals("")){
				paramList.add("StateVal");
				fieldClause.append(",STATE_VALUE ");
			}
			if(stopSale.getStateContact() != null && !stopSale.getStateContact().equals("")){
				paramList.add("StateContact");
				fieldClause.append(",STATE_CONTACT ");
			}
			if(stopSale.getStatePhone() != null && !stopSale.getStatePhone().equals("")){
				paramList.add("StatePhone");
				fieldClause.append(",STATE_PHONE_NUMBER ");
			}
			if(stopSale.getStateRetest() != null && !stopSale.getStateRetest().equals("")){
				paramList.add("StateRetest");
				fieldClause.append(",STATE_RETEST ");
			}
			if(stopSale.getMonsantoValue() != null && !stopSale.getMonsantoValue().equals("")){
				paramList.add("MonsantoVal");
				fieldClause.append(",MONSANTO_VALUE ");
			}
			if(stopSale.getCropID() != null && !stopSale.getCropID().equals("")){
				paramList.add("Crop");
				fieldClause.append(",CROP_ID ");
			}
			if(stopSale.getLabelValue() != null && !stopSale.getLabelValue().equals("")){
				paramList.add("LabelVal");
				fieldClause.append(",LABEL_VALUE ");
			}
			if(stopSale.getQualityIssue() != null && !stopSale.getQualityIssue().equals("")){
				paramList.add("QualityIssue");
				fieldClause.append(",QUALITY_ISSUE_FLAG ");
			}
			if(stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")){
				paramList.add("QuantityAffected");
				fieldClause.append(",QTY_AFFECTED ");
			}
			if(stopSale.getQualityUomID() != null && !stopSale.getQualityUomID().equals("")){
				paramList.add("QualityUom");
				fieldClause.append(",QTY_UOM_ID ");
			}
			if(stopSale.getSeedSizeID() != null && !stopSale.getSeedSizeID().equals("")){
				paramList.add("SeedSize");
				fieldClause.append(",SEED_SIZE_ID ");
			}
			if(stopSale.getActionComments() != null && !stopSale.getActionComments().equals("")){
				paramList.add("ActionComments");
				fieldClause.append(",ACTION_COMMENTS ");
			}
		
			
			StringBuffer valueClause = new StringBuffer();;
			fieldClause.append(" ");
			
			valueClause.append(") VALUES (");
			
			//**Required Fields...
			valueClause.append(stopSaleID);
			valueClause.append(",'" + stopSaleNumber + "'");
			valueClause.append(",to_date('" + getDateFormat(new Date(new java.util.Date(stopSale.getReportDate()).getTime())) + "','mm/dd/yyyy')");
			valueClause.append(",'" + stopSale.getInvestigator() + "'");
			valueClause.append(",'" + stopSale.getRegion() + "'");
			valueClause.append(",'" + stopSale.getInitiatedBy() + "'");
			valueClause.append(",'" + stopSale.getFillingLocation() + "'");
			valueClause.append(",'" + stopSale.getSalesYear() + "'");
			valueClause.append(",'" + stopSale.getStateID() + "'");
			valueClause.append(",'" + stopSale.getStatus() + "'");
			valueClause.append(",to_date('" + getDateFormat(oracleSysdate) + "','mm/dd/yyyy')");
			valueClause.append(",to_date('" + getDateFormat(oracleSysdate) + "','mm/dd/yyyy')");
			valueClause.append(",'" + "STOP_SALE_ENTRY" + "'");
			valueClause.append(",'" + stopSale.getCreatedBy() + "'");
			
			//**Optional Fields...
			for (int i =0;i<paramList.size();i++){
				if (paramList.get(i).equals("ResponsibleLoc")){
					valueClause.append(",'" + stopSale.getResponsibleLocation() + "'");
				}
				if (paramList.get(i).equals("FieldCommunicator")){
					valueClause.append(",'" + stopSale.getFieldCommunicator() + "'");
				}
				if (paramList.get(i).equals("ShippingLoc")){
					valueClause.append(",'" + stopSale.getShippingLocation() + "'");
				}
				if (paramList.get(i).equals("Dealer")){
					valueClause.append(",'" + stopSale.getDealer() + "'");
				}
				if (paramList.get(i).equals("DealerPhone")){
					valueClause.append(",'" + stopSale.getDealerPhone() + "'");
				}
				if (paramList.get(i).equals("StateRepNo")){
					valueClause.append(",'" + stopSale.getStateReportNumber() + "'");
				}
				if (paramList.get(i).equals("StateVal")){
					valueClause.append(",'" + stopSale.getStateValue() + "'");
				}
				if (paramList.get(i).equals("StateContact")){
					valueClause.append(",'" + stopSale.getStateContact() + "'");
				}
				if (paramList.get(i).equals("StatePhone")){
					valueClause.append(",'" + stopSale.getStatePhone() + "'");
				}
				if (paramList.get(i).equals("StateRetest")){
					valueClause.append(",'" + stopSale.getStateRetest() + "'");
				}
				if (paramList.get(i).equals("MonsantoVal")){
					valueClause.append(",'" + stopSale.getMonsantoValue() + "'");
				}
				if (paramList.get(i).equals("Crop")){
					valueClause.append(",'" + stopSale.getCropID() + "'");
				}
				if (paramList.get(i).equals("LabelVal")){
					valueClause.append(",'" + stopSale.getLabelValue() + "'");
				}
				if (paramList.get(i).equals("QualityIssue")){
					valueClause.append(",'" + stopSale.getQualityIssue()+ "'");
				}
				if (paramList.get(i).equals("QuantityAffected")){
					valueClause.append("," + stopSale.getQuantityAffected());
				}
				if (paramList.get(i).equals("QualityUom")){
					valueClause.append(",'" + stopSale.getQualityUomID() + "'");
				}
				if (paramList.get(i).equals("SeedSize")){
					valueClause.append(",'" + stopSale.getSeedSizeID() + "'");
				}
				if (paramList.get(i).equals("ActionComments")){
					valueClause.append(",'" + stopSale.getActionComments() + "'");
				}
			}
			
			valueClause.append(")");
			
			logger.info(INSERT_STOP_SALE + fieldClause.toString() + valueClause.toString());
			
			ps = conn.prepareStatement(INSERT_STOP_SALE + fieldClause.toString() + valueClause.toString());
			
			ps.executeUpdate();
			
			conn.commit();
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSale(obj, conn)...");
			logger.error("SQLException while inserting: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSale(obj, conn)...");
			logger.error("Exception while inserting: " + e.getMessage());
		}
		
	}
	
	
	/**
	 * To insert reqd/optional fields into the STOP_SALE_DOCUMENTATION Table.
	 * 
	 * @param stopSaleID
	 * @param oracleSysdate
	 * @param stopSale
	 * @param conn
	 */
	private void insertStopSaleDoc(int stopSaleID, Date oracleSysdate, StopSaleObject stopSale, Connection conn){
		
		//**Dynamic Query Formation...
		PreparedStatement ps = null;
		List paramList = new ArrayList();
		
		
		StringBuffer fieldClause = new StringBuffer();
		fieldClause.append(" ");
		
		try{
			//conn = getConnection();
		
			if(stopSale.getRootCause() != null && !stopSale.getRootCause().equals("")){
				paramList.add("RootCause");
				fieldClause.append(",ROOT_CAUSE ");
			}
			if(stopSale.getContainmentAction() != null && !stopSale.getContainmentAction().equals("")){
				paramList.add("ContainmentAction");
				fieldClause.append(",CONTAINMENT_ACTION ");
			}
			if(stopSale.getLongTermCorrectiveAction() != null && !stopSale.getLongTermCorrectiveAction().equals("")){
				paramList.add("LongTermCorrectiveAction");
				fieldClause.append(",LONG_TERM_CORRECTION_ACTION ");
			}
		
			StringBuffer valueClause = new StringBuffer();;
			fieldClause.append(" ");
			
			valueClause.append(") VALUES (");
			
			//**Required Fields...
			valueClause.append(stopSaleID);
			valueClause.append(",to_date('" + getDateFormat(oracleSysdate) + "','mm/dd/yyyy')");
			valueClause.append(",'" + stopSale.getCreatedBy() + "'");
			valueClause.append(",'" + "SS_DOC_ENTRY" + "'");
			valueClause.append(",to_date('" + getDateFormat(oracleSysdate) + "','mm/dd/yyyy')");
			valueClause.append(",'" + stopSale.getInvestigationFindings() + "'");
			
			
			//**Optional Fields...
			for (int i =0;i<paramList.size();i++){
				if (paramList.get(i).equals("RootCause")){
					valueClause.append(",'" + stopSale.getRootCause() + "'");
				}
				if (paramList.get(i).equals("ContainmentAction")){
					valueClause.append(",'" + stopSale.getContainmentAction() + "'");
				}
				if (paramList.get(i).equals("LongTermCorrectiveAction")){
					valueClause.append(",'" + stopSale.getLongTermCorrectiveAction() + "'");
				}				
			}
			
			valueClause.append(")");
			
			logger.info(INSERT_STOP_SALE_DOC + fieldClause.toString() + valueClause.toString());
			
			ps = conn.prepareStatement(INSERT_STOP_SALE_DOC + fieldClause.toString() + valueClause.toString());
			
			ps.executeUpdate();
			
			conn.commit();
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSaleDoc...");
			logger.error("SQLException while inserting: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSaleDoc...");
			logger.error("Exception while inserting: " + e.getMessage());
		}		
	}
	
	/**
	 * To insert each variety/batch/reason/action-flag, if present...
	 * 
	 * @param stopSaleID
	 * @param variety
	 * @param conn
	 */
	private void insertStopSaleRef(int stopSaleID, String valueStr, String queryStr, Connection conn){
		PreparedStatement ps = null;
		
		//**Perform Insert-Variety-Operation...
		try{
			ps = conn.prepareStatement(queryStr);
			
			ps.setInt(1, stopSaleID);
			ps.setString(2, valueStr);
			
			ps.executeUpdate();
			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSaleRef()...");
			logger.error("SQLException while inserting ref: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: insertStopSaleRef()...");
			logger.error("Exception while inserting ref: " + e.getMessage());
		}
	}
	
	
	/**
	 * Creates a new Stop_Sale_Number: [S-FillingLocation-Sales_Year(last 2 digits)-Seq-No]
	 * 
	 * @param stopSale
	 * @param conn
	 * @return
	 */
	private String createStopSaleNumber(StopSaleObject stopSale, Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sales_year = "";
		
		try{
			ps = conn.prepareStatement(GET_YEAR);
			ps.setString(1, stopSale.getSalesYear());
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				sales_year = rs.getString("YEAR");
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: createStopSaleNumber()...");
			logger.error("SQLException while getting stopSale_sales_year: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: createStopSaleNumber()...");
			logger.error("Exception while getting stopSale_sales_year: " + e.getMessage());
		}
		
		
		int max = 0;
		
		String compareTo = "S-" + 
							stopSale.getFillingLocation() + "-" + 
							sales_year.substring(sales_year.length() - 2, sales_year.length()) + "-" +
							"%";
		
		try{
			ps = conn.prepareStatement(AUTO_STOP_SALE_NUMBER);
			ps.setString(1, compareTo);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				max = rs.getInt("MAX");
			}
			
			String returnStr = "S-" + 
								stopSale.getFillingLocation() + 
								"-" + 
								sales_year.substring(sales_year.length() - 2, sales_year.length()) + 
								"-" +
								(max + 1); 

			return returnStr;
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: createStopSaleNumber()...");
			logger.error("SQLException while getting stopSale_no: " + e.getMessage());
			return "";
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: createStopSaleNumber()...");
			logger.error("Exception while getting stopSale_no: " + e.getMessage());
			return "";
		}
	
	}
	
	/**
	 * Gets the next-seq value for stop_sale...
	 * 
	 * @param conn
	 * @return
	 */
	private int getStopSaleSeqValue(Connection conn){
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		int stopsaleSeqNextVal = 0;
		
		try{
			ps = conn.prepareStatement(GET_STOP_SALE_SEQ_NEXTVAL);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				stopsaleSeqNextVal = rs.getInt("NEXTVAL");
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getAuditSeqValue()...");
			logger.error("SQLException while getting stopsale_seq: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getAuditSeqValue()...");
			logger.error("Exception while getting stopsale_seq: " + e.getMessage());
		}
		
		return stopsaleSeqNextVal;
	}
	
	/**
	 * To get the Oracle System Date...
	 * @param conn
	 * @return
	 */
	private Date getOracleSysDate(Connection conn){
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		Date oracleSysdate = new Date(System.currentTimeMillis());
		
		//**Get the oracle sysdate...
		try{
			ps = conn.prepareStatement(GET_ORACLE_SYSDATE);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				oracleSysdate = rs.getDate("SYSDATE");
			}
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getOracleSysDate()...");
			logger.error("SQLException while getting sysdate: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: getOracleSysDate()...");
			logger.error("Exception while getting sysdate: " + e.getMessage());
		}
		
		return oracleSysdate;
	}
	
	/**
	 * Converts to MM/DD/YYYY String...
	 * @param date
	 * @return
	 */
	private String getDateFormat(Date date){
		try {
			sdf.format(date).toString();
			return sdf.format(date).toString();
		}
		catch (Exception e){
			return "";
		}
	}
	
}
