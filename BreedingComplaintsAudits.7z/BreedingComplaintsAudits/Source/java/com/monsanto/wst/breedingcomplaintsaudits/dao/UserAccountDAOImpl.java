/*
 * Created on Mar 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.monsanto.wst.breedingcomplaintsaudits.model.User;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserAccountDAOImpl extends BaseDAOImpl implements UserAccountDAO {
	private static Log logger = LogFactory.getLog(LookUpDAOImpl.class);
	private String USER_ROLES_LKP= "Select U.PERMISSION_ID, P.DESCRIPTION from USER_PERMISSION U, PERMISSION_REF P where U.PERMISSION_ID=P.PERMISSION_ID and U.USER_ID='";
	
	/**
	 * Constructor. Initialize the datasource.
	 * @exception SQLException if lookup of datasource fails
	 */	
	public UserAccountDAOImpl() throws DAOException {

	}
	

	public User getUserInfo(User user) throws DAOException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map roleMap = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(USER_ROLES_LKP + user.getUser_id().toUpperCase().trim() + "'");
			rs = ps.executeQuery();
			if ( rs != null ){
				roleMap = new TreeMap();
				while (rs.next()){
					roleMap.put(rs.getString("PERMISSION_ID"),rs.getString("DESCRIPTION"));
				}
			}
			user.setRoleMap(roleMap);
			return user;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
			
	}
}
