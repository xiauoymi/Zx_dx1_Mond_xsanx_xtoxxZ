package com.monsanto.wst.breedingcomplaintsaudits.dao.mock;

import com.monsanto.wst.breedingcomplaintsaudits.dao.LookUpDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;

import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 25, 2007
 * Time: 8:33:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockLookUpDAO implements LookUpDAO {
    public Map getStates() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getStatus(String type) throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getLocations() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getResponsibleLocations() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getQualityIssues() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getYear() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getCrops() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getSeedSize() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getUOM() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getVarities() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getBrands() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getRegions() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getGenerator() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getEffectivenessEvaluator() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getFindingTypes() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getISOStandards() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getEmail(String locationCode) throws DAOException {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getCAREmails(int overdueIntvl) throws DAOException {
        Map CAREmails = new HashMap();
        CAREmails.put ("CPAR_ID", new Integer (1));
        CAREmails.put("CONTROL_NUMBER", new String("C-111-11-1"));
        CAREmails.put ("E_MAIL", new String ("ramya.mallya@monsanto.com"));
        CAREmails.put ("OWNER_EMAIL", new String("administrator.sbfas@monsanto.com"));
        CAREmails.put ("EMAIL_OWNER_FLAG",new String("N"));
        return CAREmails;
    }

    public Map getEmailServiceParams() throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setMailSentDateParam(int mailSentDate) throws DAOException {
//To change body of implemented methods use File | Settings | File Templates.
    }

    public void addMailSentDateParam(int mailSentDate) throws DAOException {
//To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getComplaintEmails(int overdue) throws DAOException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
