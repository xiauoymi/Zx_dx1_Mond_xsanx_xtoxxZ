/*
 * Created on Feb 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao.test;

import java.util.Map;
import java.util.LinkedHashMap;

import junit.framework.Assert;
import junit.framework.TestCase;

import com.monsanto.wst.breedingcomplaintsaudits.dao.ComplaintDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.dao.ComplaintDAOImpl;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintDAOImplTest extends TestCase {

  public final void testGetComplaintPK() throws DAOException {
    //TODO Implement getComplaintPK().
     ComplaintDAO complaintDao = new ComplaintDAOImpl();
      String primaryKey = complaintDao.getComplaintPK();
      System.out.println("primaryKey = " + primaryKey);
      assertNotNull (primaryKey);
  }

  public final void testInsertComplaint() {
    //TODO Implement insertComplaint().
  }

  public final void testUpdateComplaint() {
    //TODO Implement updateComplaint().
  }

  public final void testGetComplaintsList() {
    //todo...Uncomment and fix this test
//    LinkedHashMap complaintsList = null;
//    try {
//      ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
//      complaintsList = cd.getComplaintsList("283", "", "", "", "", "", "", "", "", "", "", "", "", "", "1", true, "ROWNUM", "ASC");
//    }
//    catch (Exception e) {
//      System.out.println(e.getMessage());
//    }
//    Assert.assertNotNull(complaintsList);
  }

  public final void testGetComplaint() {

    //TODO Implement getComplaint().
  }

}
