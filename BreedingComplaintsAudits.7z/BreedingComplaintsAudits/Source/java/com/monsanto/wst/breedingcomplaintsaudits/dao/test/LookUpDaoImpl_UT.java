package com.monsanto.wst.breedingcomplaintsaudits.dao.test;

import com.monsanto.wst.breedingcomplaintsaudits.actions.test.BCASDatabaseTestCase;
import com.monsanto.wst.breedingcomplaintsaudits.dao.LookUpDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.LookUpDAOImpl;
import org.dbunit.operation.DatabaseOperation;

import java.util.Map;

import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 22, 2007
 * Time: 1:24:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class LookUpDaoImpl_UT extends TestCase {
    public void testListOfOverdueComplaints_NotEmpty() throws Exception {
        LookUpDAO lookupDao = new LookUpDAOImpl();
        int overdue = 90;
        Map overdueComplaints = lookupDao.getComplaintEmails(overdue);
        assertNotNull(overdueComplaints);
    }
}
