/*
 * Created on Feb 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.exception;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McasExceptionHandler extends ExceptionHandler {
	
	static Category logger = Category.getInstance(McasExceptionHandler.class.getName());
	
	public ActionForward execute(
		      Exception ex,
		      ExceptionConfig ae,
		      ActionMapping mapping,
		      ActionForm formInstance,
		      HttpServletRequest request,
		      HttpServletResponse response)
		   throws ServletException {
//		      request.setAttribute("myException",ex);
//		      request.setAttribute("myForm",formInstance);
//		      request.setAttribute("myKey",ae.getKey());
			  
			  Date errorDate = new Date(System.currentTimeMillis());	
		
			  ex.printStackTrace();
			  
			  logger.error("Error Date : " + errorDate.getMonth() + ":" + errorDate.getDate() + ":" + errorDate.getYear() + " Error Time : " + errorDate.getHours() + ":" + errorDate.getMinutes() + ":" + errorDate.getSeconds());
			  
			  logger.error("Error Type..." + ex.getClass());
			  
			  //***Priniting the entire stack trace to logger file...
			  logger.error("Detailed Error Stack Trace...");			  
			  ByteArrayOutputStream stream = new ByteArrayOutputStream();
			  ex.printStackTrace(new PrintStream(stream));
			  String errorText = stream.toString();			  
			  logger.error(errorText);
			  
			  
		      return new ActionForward(ae.getPath());
		   }

}
