/**
 * Export Tool (ExportClass) was created on Jun 10, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.breedingcomplaintsaudits.exportTool;

import java.io.BufferedOutputStream;
import java.util.Vector;

import org.apache.log4j.Category;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.RowBean;

/**
 * Export Tool...
 * 
 * @author Rasesh Desai
 *
 */
public class ExportClass {
	
	static Category logger = Category.getInstance(ExportClass.class.getName());
	
	private Vector vector = new Vector();
	
	private Vector colHeader = new Vector();
	
	BufferedOutputStream bos;
	
	private String sheetName;
	
	private int totalFields = 0;
	
	
	/**
	 * @return Returns the totalFields.
	 */
	public int getTotalFields() {
		return totalFields;
	}
	/**
	 * @param totalFields The totalFields to set.
	 */
	public void setTotalFields(int totalFields) {
		this.totalFields = totalFields;
	}
	/**
	 * @return Returns the sheetName.
	 */
	public String getSheetName() {
		return sheetName;
	}
	/**
	 * @param sheetName The sheetName to set.
	 */
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
	/**
	 * @return Returns the colHeader.
	 */
	public Vector getColHeader() {
		return colHeader;
	}
	/**
	 * @param colHeader The colHeader to set.
	 */
	public void setColHeader(Vector colHeader) {
		this.colHeader = colHeader;
	}
	/**
	 * @return Returns the bos.
	 */
	public BufferedOutputStream getBos() {
		return bos;
	}
	/**
	 * @param bos The bos to set.
	 */
	public void setBos(BufferedOutputStream bos) {
		this.bos = bos;
	}
	/**
	 * @return Returns the vector.
	 */
	public Vector getVector() {
		return vector;
	}
	/**
	 * @param vector The vector to set.
	 */
	public void setVector(Vector vector) {
		this.vector = vector;
	}
	/**
	 * The main method for exporting the data present in hash to
	 * an Excel file.
	 *
	 */
	public void exportExcel(){
		
		logger.info("ExportExcel()...");
		
		try{
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet();

			wb.setSheetName(0, sheetName, HSSFWorkbook.ENCODING_COMPRESSED_UNICODE );
		
			HSSFRow row = null;
			HSSFCell col = null;
			
			HSSFCellStyle cs = wb.createCellStyle();
			
			//**Font to display the text in bold...(font and cs)
			HSSFFont font = wb.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			
			cs.setFont(font);
					
			for (int rownum = 0; rownum < vector.size() + 1; rownum++)
			{
				row = sheet.createRow(rownum);
				
				RowBean dataRow = new RowBean();
				
				if(rownum != 0){
					//**Data from Vector...
					dataRow = (RowBean)vector.get(rownum - 1);
				}
				
				for (short cellnum = 0; cellnum < totalFields; cellnum++)
				{
					col = row.createCell(cellnum);					
					col.setCellType(HSSFCell.CELL_TYPE_STRING);
					
					if(rownum == 0){
						//For Column Header...bold letters reqd.
						col.setCellStyle(cs);
						col.setCellValue(colHeader.get(cellnum) + "");
					}
					else{ 
						if(cellnum == 0){
							col.setCellValue(dataRow.getCol1());							
						}
						if(cellnum == 1){
							col.setCellValue(dataRow.getCol2());
						}
						if(cellnum == 2){
							col.setCellValue(dataRow.getCol3());
						}
						if(cellnum == 3){
							col.setCellValue(dataRow.getCol4());
						}
						if(cellnum == 3){
							col.setCellValue(dataRow.getCol4());
						}
						if(cellnum == 4){
							col.setCellValue(dataRow.getCol5());
						}
						if(cellnum == 5){
							col.setCellValue(dataRow.getCol6());
						}
						if(cellnum == 6){
							col.setCellValue(dataRow.getCol7());
						}
						if(cellnum == 7){
							col.setCellValue(dataRow.getCol8());
						}
						if(cellnum == 8){
							col.setCellValue(dataRow.getCol9());
						}
						if(cellnum == 9){
							col.setCellValue(dataRow.getCol10());
						}
						if(cellnum == 10){
							col.setCellValue(dataRow.getCol11());
						}
						if(cellnum == 11){
							col.setCellValue(dataRow.getCol12());
						}
						if(cellnum == 12){
							col.setCellValue(dataRow.getCol13());
						}
						if(cellnum == 13){
							col.setCellValue(dataRow.getCol14());
						}						
						if(cellnum == 14){
							col.setCellValue(dataRow.getCol15());
						}
						if(cellnum == 15){
							col.setCellValue(dataRow.getCol16());
						}
						if(cellnum == 16){
							col.setCellValue(dataRow.getCol17());
						}
						if(cellnum == 17){
							col.setCellValue(dataRow.getCol18());
						}
						if(cellnum == 18){
							col.setCellValue(dataRow.getCol19());
						}
						if(cellnum == 19){
							col.setCellValue(dataRow.getCol20());
						}
						if(cellnum == 20){
							col.setCellValue(dataRow.getCol21());
						}
						if(cellnum == 21){
							col.setCellValue(dataRow.getCol22());
						}
						if(cellnum == 22){
							col.setCellValue(dataRow.getCol23());
						}
						if(cellnum == 23){
							col.setCellValue(dataRow.getCol24());
						}						
						if(cellnum == 24){
							col.setCellValue(dataRow.getCol25());
						}
						if(cellnum == 25){
							col.setCellValue(dataRow.getCol26());
						}
						if(cellnum == 26){
							col.setCellValue(dataRow.getCol27());
						}
						if(cellnum == 27){
							col.setCellValue(dataRow.getCol28());
						}
						if(cellnum == 28){
							col.setCellValue(dataRow.getCol29());
						}
						if(cellnum == 29){
							col.setCellValue(dataRow.getCol30());
						}
						if(cellnum == 30){
							col.setCellValue(dataRow.getCol31());
						}
						if(cellnum == 31){
							col.setCellValue(dataRow.getCol32());
						}
						if(cellnum == 32){
							col.setCellValue(dataRow.getCol33());
						}
						if(cellnum == 33){
							col.setCellValue(dataRow.getCol34());
						}						
						if(cellnum == 34){
							col.setCellValue(dataRow.getCol35());
						}
						if(cellnum == 35){
							col.setCellValue(dataRow.getCol36());
						}
						if(cellnum == 36){
							col.setCellValue(dataRow.getCol37());
						}
						if(cellnum == 37){
							col.setCellValue(dataRow.getCol38());
						}
						if(cellnum == 38){
							col.setCellValue(dataRow.getCol39());
						}
						if(cellnum == 39){
							col.setCellValue(dataRow.getCol40());
						}
						if(cellnum == 40){
							col.setCellValue(dataRow.getCol41());
						}
						if(cellnum == 41){
							col.setCellValue(dataRow.getCol42());
						}
						if(cellnum == 42){
							col.setCellValue(dataRow.getCol43());
						}
						if(cellnum == 43){
							col.setCellValue(dataRow.getCol44());
						}						
						if(cellnum == 44){
							col.setCellValue(dataRow.getCol45());
						}
						if(cellnum == 45){
							col.setCellValue(dataRow.getCol46());
						}
						if(cellnum == 46){
							col.setCellValue(dataRow.getCol47());
						}
						if(cellnum == 47){
							col.setCellValue(dataRow.getCol48());
						}
						if(cellnum == 48){
							col.setCellValue(dataRow.getCol49());
						}
						if(cellnum == 49){
							col.setCellValue(dataRow.getCol50());
						}
						if(cellnum == 50){
							col.setCellValue(dataRow.getCol51());
						}
						if(cellnum == 51){
							col.setCellValue(dataRow.getCol52());
						}
						if(cellnum == 52){
							col.setCellValue(dataRow.getCol53());
						}
						if(cellnum == 53){
							col.setCellValue(dataRow.getCol54());
						}
						if(cellnum == 54){
							col.setCellValue(dataRow.getCol55());
						}
						if(cellnum == 55){
							col.setCellValue(dataRow.getCol56());
						}
						if(cellnum == 56){
							col.setCellValue(dataRow.getCol57());
						}
						if(cellnum == 57){
							col.setCellValue(dataRow.getCol58());
						}
						if(cellnum == 58){
							col.setCellValue(dataRow.getCol59());
						}
						if(cellnum == 59){
							col.setCellValue(dataRow.getCol60());
						}
						if(cellnum == 60){
							col.setCellValue(dataRow.getCol61());
						}
						if(cellnum == 61){
							col.setCellValue(dataRow.getCol62());
						}
						if(cellnum == 62){
							col.setCellValue(dataRow.getCol63());
						}
						if(cellnum == 63){
							col.setCellValue(dataRow.getCol64());
						}
						if(cellnum == 64){
							col.setCellValue(dataRow.getCol65());
						}
						if(cellnum == 65){
							col.setCellValue(dataRow.getCol66());
						}
						if(cellnum == 66){
							col.setCellValue(dataRow.getCol67());
						}
						if(cellnum == 67){
							col.setCellValue(dataRow.getCol68());
						}
						if(cellnum == 68){
							col.setCellValue(dataRow.getCol69());
						}
						if(cellnum == 69){
							col.setCellValue(dataRow.getCol70());
						}
						if(cellnum == 70){
							col.setCellValue(dataRow.getCol71());
						}
						if(cellnum == 71){
							col.setCellValue(dataRow.getCol72());
						}
						if(cellnum == 72){
							col.setCellValue(dataRow.getCol73());
						}
						if(cellnum == 73){
							col.setCellValue(dataRow.getCol74());
						}
						if(cellnum == 73){
							col.setCellValue(dataRow.getCol74());
						}
						if(cellnum == 74){
							col.setCellValue(dataRow.getCol75());
						}
						if(cellnum == 75){
							col.setCellValue(dataRow.getCol76());
						}
						if(cellnum == 76){
							col.setCellValue(dataRow.getCol77());
						}
						if(cellnum == 77){
							col.setCellValue(dataRow.getCol78());
						}
						if(cellnum == 78){
							col.setCellValue(dataRow.getCol79());
						}
						if(cellnum == 79){
							col.setCellValue(dataRow.getCol80());
						}
						if(cellnum == 80){
							col.setCellValue(dataRow.getCol81());
						}
						if(cellnum == 81){
							col.setCellValue(dataRow.getCol82());
						}
						if(cellnum == 82){
							col.setCellValue(dataRow.getCol83());
						}
						if(cellnum == 83){
							col.setCellValue(dataRow.getCol84());
						}
						if(cellnum == 84){
							col.setCellValue(dataRow.getCol85());
						}
						if(cellnum == 85){
							col.setCellValue(dataRow.getCol86());
						}
						if(cellnum == 86){
							col.setCellValue(dataRow.getCol87());
						}
						if(cellnum == 87){
							col.setCellValue(dataRow.getCol88());
						}
						if(cellnum == 88){
							col.setCellValue(dataRow.getCol89());
						}
						if(cellnum == 89){
							col.setCellValue(dataRow.getCol90());
						}
						if(cellnum == 90){
							col.setCellValue(dataRow.getCol91());
						}
						if(cellnum == 91){
							col.setCellValue(dataRow.getCol92());
						}
						if(cellnum == 92){
							col.setCellValue(dataRow.getCol93());
						}
						if(cellnum == 93){
							col.setCellValue(dataRow.getCol94());
						}
						if(cellnum == 94){
							col.setCellValue(dataRow.getCol95());
						}
						if(cellnum == 95){
							col.setCellValue(dataRow.getCol96());
						}
						if(cellnum == 96){
							col.setCellValue(dataRow.getCol97());
						}
						if(cellnum == 97){
							col.setCellValue(dataRow.getCol98());
						}
						if(cellnum == 98){
							col.setCellValue(dataRow.getCol99());
						}
						if(cellnum == 99){
							col.setCellValue(dataRow.getCol100());
						}
				
					}
					
				}
			}
		
			wb.write(bos);
		}
		catch(Exception ex){
			logger.error("Error writing the Excel File to BufferedOutputStream." + ex.getMessage());
		}

	}
	
}
