/*
 * Created on Mar 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.filters;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LogonFilter implements Filter {

	   private  FilterConfig _filterConfig = null;

	   /** 
	   * The  server calls this method to initialize the Filter and
	   * passes  in a FilterConfig object.
	   */
	   public  void init (FilterConfig filterConfig)
	               throws  javax.servlet.ServletException
	   {
	      _filterConfig = filterConfig;
	   }
	    
	   /**
	   * Return  the FilterConfig object
	   */
	   public  FilterConfig getFilterConfig()
	   {
	      return _filterConfig;
	   }
	   public  void doFilter (ServletRequest request, 
	   							ServletResponse  response, 
								FilterChain  chain)
					throws  java.io.IOException, javax.servlet.ServletException
       {
	   	
		   	HttpServletRequest  httprequest = (HttpServletRequest)request;
		   	HttpServletResponse  httpresponse = (HttpServletResponse)response;
			String  path = httprequest.getRequestURI();	
			String contextPath = httprequest.getContextPath();
			String[] urls = path.split(contextPath);
	        if ((httprequest.getSession().getAttribute("user")==null && urls.length > 1 && !(urls[1].equals("/logon.do"))) || (urls.length > 1 && urls[1].split("/").length > 2 )) {
	        	httpresponse.sendRedirect(contextPath);
	        }		
			// Pass  control to the next filter in the chain.
			else
				chain.doFilter(request,  response);
	   } 	
	   
	   /** 
	   * Notifies  the filter that it is being taken out of service.
	   */
	   public  void destroy()
	   {
	      // free  resources
	   }

}
