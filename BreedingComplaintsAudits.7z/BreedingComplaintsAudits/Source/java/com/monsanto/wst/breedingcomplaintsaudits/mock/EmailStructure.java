package com.monsanto.wst.breedingcomplaintsaudits.mock;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 23, 2007
 * Time: 8:01:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmailStructure {
    public String to;
    public String from;
    public String subject;
    public String body;
    private String cc;

    public EmailStructure(String to, String from, String subject, String body, String cc) {
        this.to = to;
        this.from = from;
        this.subject = subject;
        this.body = body;
        this.cc = cc;
    }

    public String getBody (){
        return this.body;
    }

    public String getSubject (){
        return this.subject;
    }
    
    public String getFrom (){
        return this.from;
    }

    public String getTo (){
        return this.to;
    }


    public String getCc() {
        return cc;
    }
}
