/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.mock;

import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * Filename:    $RCSfile: MockEmailUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2008-01-29 15:05:42 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockEmailUtil extends EmailUtil {

  private String to;
  private String from;
  private String subject;
  private String body;
  private String cc;
  public boolean wasSendEmailCalled = false;
  public List emailStructures = new ArrayList();

    public void setFrom(String from) {
    this.from = from;
  }

  public void setTo(String to) {
    this.to = to;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public void setBody(String body) {
    this.body = body;
  }

  public String getFrom() {
    return from;
  }

  public String getTo() {
    return to;
  }

  public String getSubject() {
    return subject;
  }

  public String getBody() {
    return body;
  }

  public String getCc (){
      return cc;
  }

  public void setCc (String cc){
      this.cc = cc;
  }

  public boolean sendMail() throws Exception {
    System.out.println("Mock Email Sent out...");
    wasSendEmailCalled = true;
      System.out.println("to = " + to);
      System.out.println("from = " + from);
      System.out.println("subject = " + subject);
      System.out.println("body = " + body);
      System.out.println("cc = " + cc);
    EmailStructure emailStructure = new EmailStructure (to, from, subject, body, cc);
    emailStructures.add (emailStructure);
    return true;
  }
}