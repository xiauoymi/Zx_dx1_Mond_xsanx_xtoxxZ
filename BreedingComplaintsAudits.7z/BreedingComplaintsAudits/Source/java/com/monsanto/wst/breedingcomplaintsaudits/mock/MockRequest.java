/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.mock;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletInputStream;
import javax.servlet.RequestDispatcher;
import java.util.Enumeration;
import java.util.Map;
import java.util.Locale;
import java.util.HashMap;
import java.security.Principal;
import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.io.BufferedReader;

/**
 * Filename:    $RCSfile: MockRequest.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-11-08 18:44:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class MockRequest implements HttpServletRequest {

  private MockSession mockSession = new MockSession();
  private Map parameterMap = new HashMap();
  private Map attributeMap = new HashMap();

  public HttpSession getSession() {
    return mockSession;
  }

  public boolean isRequestedSessionIdValid() {
    return false;
  }

  public boolean isRequestedSessionIdFromCookie() {
    return false;
  }

  public boolean isRequestedSessionIdFromURL() {
    return false;
  }

  public boolean isRequestedSessionIdFromUrl() {
    return false;
  }

  public void setParameter(String parameterName, String parameterValue) {
    parameterMap.put(parameterName, parameterValue);
  }

  public String getParameter(String parameterName) {
    return (String) parameterMap.get(parameterName);
  }

  public Map getParameterMap() {
    parameterMap.put("A-111-564", new String[]{"ViewFromList"});
    return parameterMap;
  }

  public Enumeration getParameterNames() {
    return null;
  }

  public String[] getParameterValues(String string) {
    return new String[0];
  }

  public String getProtocol() {
    return null;
  }

  public String getScheme() {
    return null;
  }

  public String getServerName() {
    return null;
  }

  public int getServerPort() {
    return 0;
  }

  public BufferedReader getReader() throws IOException {
    return null;
  }

  public String getRemoteAddr() {
    return null;
  }

  public String getRemoteHost() {
    return null;
  }

  public void setAttribute(String attributeName, Object object) {
    attributeMap.put(attributeName, object);
  }

  public void removeAttribute(String string) {
  }

  public Locale getLocale() {
    return null;
  }

  public Enumeration getLocales() {
    return null;
  }

  public boolean isSecure() {
    return false;
  }

  public RequestDispatcher getRequestDispatcher(String string) {
    return null;
  }

  public String getRealPath(String string) {
    return null;
  }

  public int getRemotePort() {
    return 0;
  }

  public String getLocalName() {
    return null;
  }

  public String getLocalAddr() {
    return null;
  }

  public int getLocalPort() {
    return 0;
  }

  public Object getAttribute(String attributeName) {
    return attributeMap.get(attributeName);
  }

  public Enumeration getAttributeNames() {
    return null;
  }

  public String getCharacterEncoding() {
    return null;
  }

  public void setCharacterEncoding(String string) throws UnsupportedEncodingException {
  }

  public int getContentLength() {
    return 0;
  }

  public String getContentType() {
    return null;
  }

  public ServletInputStream getInputStream() throws IOException {
    return null;
  }

  public String getAuthType() {
    return null;
  }

  public Cookie[] getCookies() {
    return new Cookie[0];
  }

  public long getDateHeader(String string) {
    return 0;
  }

  public String getHeader(String string) {
    return null;
  }

  public Enumeration getHeaders(String string) {
    return null;
  }

  public Enumeration getHeaderNames() {
    return null;
  }

  public int getIntHeader(String string) {
    return 0;
  }

  public String getMethod() {
    return null;
  }

  public String getPathInfo() {
    return null;
  }

  public String getPathTranslated() {
    return null;
  }

  public String getContextPath() {
    return "/bcas";
  }

  public String getQueryString() {
    return null;
  }

  public String getRemoteUser() {
    return null;
  }

  public boolean isUserInRole(String string) {
    return false;
  }

  public Principal getUserPrincipal() {
    return null;
  }

  public String getRequestedSessionId() {
    return null;
  }

  public String getRequestURI() {
    return null;
  }

  public StringBuffer getRequestURL() {
    return new StringBuffer("http://w3d.monsanto.com/bcas/cpar.do?method=cparEdit&cparId=123");
  }

  public String getServletPath() {
    return null;
  }

  public HttpSession getSession(boolean b) {
    return null;
  }


}