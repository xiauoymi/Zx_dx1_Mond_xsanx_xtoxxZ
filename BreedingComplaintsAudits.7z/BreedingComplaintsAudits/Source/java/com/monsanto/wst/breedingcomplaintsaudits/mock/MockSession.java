/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.mock;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import javax.servlet.ServletContext;
import java.util.Enumeration;
import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockSession.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-22 22:53:11 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockSession implements HttpSession {

  private Map sessionMap = new HashMap();

  public long getCreationTime() {
    return 0;
  }

  public String getId() {
    return null;
  }

  public long getLastAccessedTime() {
    return 0;
  }

  public ServletContext getServletContext() {
    return null;
  }

  public void setMaxInactiveInterval(int i) {
  }

  public int getMaxInactiveInterval() {
    return 0;
  }

  public HttpSessionContext getSessionContext() {
    return null;
  }

  public Object getAttribute(String attributeName) {
    return sessionMap.get(attributeName);
  }

  public Object getValue(String string) {
    return null;
  }

  public Enumeration getAttributeNames() {
    return null;
  }

  public String[] getValueNames() {
    return new String[0];
  }

  public void setAttribute(String string, Object object) {
    sessionMap.put(string, object);
  }

  public void putValue(String string, Object object) {
  }

  public void removeAttribute(String string) {
  }

  public void removeValue(String string) {
  }

  public void invalidate() {
  }

  public boolean isNew() {
    return false;
  }
}