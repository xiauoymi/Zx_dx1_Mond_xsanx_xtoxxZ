/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.mock;

import com.monsanto.wst.breedingcomplaintsaudits.model.User;

/**
 * Filename:    $RCSfile: MockUser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-10-29 18:23:46 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockUser extends User {

  public MockUser() {
    setUser_id("RRMALL");
    setFull_name("Mallya,Ramya");
    setEmail("ramya.mallya@monsanto.com");
  }
}