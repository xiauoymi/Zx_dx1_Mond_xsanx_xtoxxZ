/*
 * Created on Jan 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import com.monsanto.wst.breedingcomplaintsaudits.util.ComparisonUtil;


/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to.
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Complaint {
	
	private String  complaint_id; 
	private String  claim_number;             
	private String  status_id;                 
	private String  sales_year_id;               
	private String  state_id;                  
	private String  report_initiator;
	private String  report_initiator_email;
	private String  report_date;               
	private String  communication_date;
	private String 	region_id;
	private String  field_communicator;        
	private String  reporting_location_code;   
	private String  responsible_plant_code;               
	private String  person_investigating;      
	private String  crop_id; 
	private String  quality_issue;
	private String  quantity_affected;             
	private String  quantity_uom_id;                
	private String  seed_size_id;
	//TODO Also change the Batch variables to a List and Variety variables to Map or List when rendering it dynamically on UI.
//	private List 	varity_list;
//	private List	batch_list;
	private String batch_one;
	private String batch_two;
	private String batch_three;
	private String batch_four;
	private String variety_one;
	private String variety_two;
	private String variety_three;
	private String variety_four;
	
	private String foundBatch1;
	private String foundBatch2;
	private String foundBatch3;
	private String foundBatch4;
	
	private String problem_description;
	private String containment_actions;
	private String root_cause;
	private String long_term_corrective_action;
	private boolean driver_performance;
	private boolean incorrect_shipment;
	private boolean delivery_other;
	private boolean packaging_condition;
	private boolean tag_error;
	private boolean seed_appearance;
	private boolean seed_variability;
	private boolean emergence_concerns;
	private boolean product_purity;
	private boolean early_season_other;
	private boolean growth_development;
	private boolean pollination_problems;
	private boolean herbicide_injury;
	private boolean stress_susceptability;
	private boolean disease_development;
	private boolean midseason_other;
	private boolean insect_outbreaks_injury;
	private boolean lateseason_disease_development;
	private boolean maintaining_seed_until_harvest;
	private boolean insect_development;
	private boolean maturity_drydown;
	private boolean seed_development;
	private boolean late_season_other;
	private boolean noncompetitive_yield;
	private String  delivery_info;	
	private String issue_other;
	private String total_acres;
	private String affected_areas;
	private String technology;
	private String population_planted;
	private String population_observed;
	private String tillage;
	private String planting_date;
	private String planter_type;
	private String planter_depth;
	private String disease_observed;
	private String herbicide_type_current;
	private String herbicide_timming_current;
	private String herbicide_rate_current;
	private String herbicide_type_prev;
	private String herbicide_timming_prev;
	private String herbicide_rate_prev;
	private String insects_observed;
	private String insecticide_type_current;
	private String insecticide_timming_current;
	private String insecticide_rate_current;
	private String insecticide_type_prev;
	private String insecticide_timming_prev;
	private String insecticide_rate_prev;
	private String grower_name;
	private String grower_address;
	private String grower_city;
	private String grower_state;
	private String grower_phone;
	private String grower_ba_id;
	private String dealer_name;
	private String dealer_address;
	private String dealer_city;
	private String dealer_state;
	private String dealer_phone;
	private String dealer_ba_id;
	private String created_by;
	private String 	row_entry_date;  
	private String  row_modify_date;        
	private String  row_task_id;        
	private String  row_user_id;
	private String settlement_value;
	private String affina_entry_flag;

	public String getIssue_other() {
		return issue_other;
	}

	public void setIssue_other(String issue_other) {
		this.issue_other = issue_other;
	}


	public Complaint(){
		initialize();
	}
	
	/**
	 * 
	 */
	private void initialize() {
//TODO Delete this line after testing action logic.		
//		this.setAffina_entry_flag("N");
		//This is temporary
		this.setSettlement_value("0");
	}

	/**
	 * @return Returns the containment_actions.
	 */
	public String getContainment_actions() {
		return containment_actions;
	}
	/**
	 * @param containment_actions The containment_actions to set.
	 */
	public void setContainment_actions(String containment_actions) {
		this.containment_actions = containment_actions;
	}
	/**
	 * @return Returns the long_term_corrective_action.
	 */
	public String getLong_term_corrective_action() {
		return long_term_corrective_action;
	}
	/**
	 * @param long_term_corrective_action The long_term_corrective_action to set.
	 */
	public void setLong_term_corrective_action(
			String long_term_corrective_action) {
		this.long_term_corrective_action = long_term_corrective_action;
	}
	/**
	 * @return Returns the problem_description.
	 */
	public String getProblem_description() {
		return problem_description;
	}
	/**
	 * @param problem_description The problem_description to set.
	 */
	public void setProblem_description(String problem_description) {
		this.problem_description = problem_description;
	}
	/**
	 * @return Returns the root_cause.
	 */
	public String getRoot_cause() {
		return root_cause;
	}
	/**
	 * @param root_cause The root_cause to set.
	 */
	public void setRoot_cause(String root_cause) {
		this.root_cause = root_cause;
	}

	
	/**
	 * @return Returns the claim_number.
	 */
	public String getClaim_number() {
		return claim_number;
	}
	/**
	 * @param claim_number The claim_number to set.
	 */
	public void setClaim_number(String claim_number) {
		this.claim_number = claim_number;
	}
	/**
	 * @return Returns the communication_date.
	 */
	public String getCommunication_date() {
		return communication_date;
	}
	/**
	 * @param communication_date The communication_date to set.
	 */
	public void setCommunication_date(String communication_date) {
		this.communication_date = communication_date;
	}
	/**
	 * @return Returns the complaint_id.
	 */
	public String getComplaint_id() {
		return complaint_id;
	}
	/**
	 * @param complaint_id The complaint_id to set.
	 */
	public void setComplaint_id(String complaint_id) {
		this.complaint_id = complaint_id;
	}
	/**
	 * @return Returns the crop_id.
	 */
	public String getCrop_id() {
		return "1";
	}
	/**
	 * @param crop_id The crop_id to set.
	 */
	public void setCrop_id(String crop_id) {
		this.crop_id = "1";
	}
	/**
	 * @return Returns the delivery_info.
	 */
	public String getDelivery_info() {
		return delivery_info;
	}
	/**
	 * @param delivery_info The delivery_info to set.
	 */
	public void setDelivery_info(String delivery_info) {
		this.delivery_info = delivery_info;
	}
	/**
	 * @return Returns the field_communicator.
	 */
	public String getField_communicator() {
		return field_communicator;
	}
	/**
	 * @param field_communicator The field_communicator to set.
	 */
	public void setField_communicator(String field_communicator) {
		this.field_communicator = field_communicator;
	}
	/**
	 * @return Returns the person_investigating.
	 */
	public String getPerson_investigating() {
		return person_investigating;
	}
	/**
	 * @param person_investigating The person_investigating to set.
	 */
	public void setPerson_investigating(String person_investigating) {
		this.person_investigating = person_investigating;
	}
	/**
	 * @return Returns the quality_issue.
	 */
	public String getQuality_issue() {
		return quality_issue;
	}
	/**
	 * @param quality_issue The quality_issue to set.
	 */
	public void setQuality_issue(String quality_issue) {
		this.quality_issue = quality_issue;
	}
	/**
	 * @return Returns the quantity_affected.
	 */
	public String getQuantity_affected() {
		return quantity_affected;
	}
	/**
	 * @param quantity_affected The quantity_affected to set.
	 */
	public void setQuantity_affected(String quantity_affected) {
		this.quantity_affected = quantity_affected;
	}
	/**
	 * @return Returns the quantity_uom_id.
	 */
	public String getQuantity_uom_id() {
		return quantity_uom_id;
	}
	/**
	 * @param quantity_uom_id The quantity_uom_id to set.
	 */
	public void setQuantity_uom_id(String quantity_uom_id) {
		this.quantity_uom_id = quantity_uom_id;
	}
	/**
	 * @return Returns the report_date.
	 */
	public String getReport_date() {
		return report_date;
	}
	/**
	 * @param report_date The report_date to set.
	 */
	public void setReport_date(String report_date) {
		this.report_date = report_date;
	}
	/**
	 * @return Returns the report_initiator.
	 */
	public String getReport_initiator() {
		return report_initiator;
	}
	/**
	 * @param report_initiator The report_initiator to set.
	 */
	public void setReport_initiator(String report_initiator) {
		this.report_initiator = report_initiator;
	}
	/**
	 * @return Returns the reporting_location_code.
	 */
	public String getReporting_location_code() {
		return reporting_location_code;
	}
	/**
	 * @param reporting_location_code The reporting_location_code to set.
	 */
	public void setReporting_location_code(String reporting_location_code) {
		this.reporting_location_code = reporting_location_code;
	}
	/**
	 * @return Returns the responsible_plant_code.
	 */
	public String getResponsible_plant_code() {
		return responsible_plant_code;
	}
	/**
	 * @param responsible_plant_code The responsible_plant_code to set.
	 */
	public void setResponsible_plant_code(String responsible_plant_code) {
		this.responsible_plant_code = responsible_plant_code;
	}
	/**
	 * @return Returns the row_entry_date.
	 */
	public String getRow_entry_date() {
		return row_entry_date;
	}
	/**
	 * @param row_entry_date The row_entry_date to set.
	 */
	public void setRow_entry_date(String row_entry_date) {
		this.row_entry_date = row_entry_date;
	}
	/**
	 * @return Returns the row_modify_date.
	 */
	public String getRow_modify_date() {
		return row_modify_date;
	}
	/**
	 * @param row_modify_date The row_modify_date to set.
	 */
	public void setRow_modify_date(String row_modify_date) {
		this.row_modify_date = row_modify_date;
	}
	/**
	 * @return Returns the row_task_id.
	 */
	public String getRow_task_id() {
		return row_task_id;
	}
	/**
	 * @param row_task_id The row_task_id to set.
	 */
	public void setRow_task_id(String row_task_id) {
		this.row_task_id = row_task_id;
	}
	/**
	 * @return Returns the row_user_id.
	 */
	public String getRow_user_id() {
		return row_user_id;
	}
	/**
	 * @param row_user_id The row_user_id to set.
	 */
	public void setRow_user_id(String row_user_id) {
		this.row_user_id = row_user_id;
	}
	/**
	 * @return Returns the sales_year_id.
	 */
	public String getSales_year_id() {
		/*return sales_year_id;*/
		return "0";
	}
	/**
	 * @param sales_year_id The sales_year_id to set.
	 */
	public void setSales_year_id(String sales_year_id) {
		this.sales_year_id = "0";
	}
	/**
	 * @return Returns the seed_size_id.
	 */
	public String getSeed_size_id() {
		return seed_size_id;
	}
	/**
	 * @param seed_size_id The seed_size_id to set.
	 */
	public void setSeed_size_id(String seed_size_id) {
		this.seed_size_id = seed_size_id;
	}
	/**
	 * @return Returns the state_id.
	 */
	public String getState_id() {
		/*return state_id;*/
		return "1";
	}
	/**
	 * @param state_id The state_id to set.
	 */
	public void setState_id(String state_id) {
		this.state_id = "1";
	}
	/**
	 * @return Returns the status_id.
	 */
	public String getStatus_id() {
		return status_id;
	}
	/**
	 * @param status_id The status_id to set.
	 */
	public void setStatus_id(String status_id) {
		this.status_id = status_id;
	}

	
//	/**
//	 * @return Returns the varity_list.
//	 */
//	public Map getVarity_list() {
//		return varity_list;
//	}
//	/**
//	 * @param varity_list The varity_list to set.
//	 */
//	public void setVarity_list(Map varity_list) {
//		this.varity_list = varity_list;
//	}
//
//	
//	/**
//	 * @return Returns the batch_list.
//	 */
//	public List getBatch_list() {
//		return batch_list;
//	}
//	/**
//	 * @param batch_list The batch_list to set.
//	 */
//	public void setBatch_list(List batch_list) {
//		this.batch_list = batch_list;
//	}

	
	/**
	 * @return Returns the affected_areas.
	 */
	public String getAffected_areas() {
		return affected_areas;
	}
	/**
	 * @param affected_areas The affected_areas to set.
	 */
	public void setAffected_areas(String affected_areas) {
		this.affected_areas = affected_areas;
	}
	/**
	 * @return Returns the dealer_address.
	 */
	public String getDealer_address() {
		return dealer_address;
	}
	/**
	 * @param dealer_address The dealer_address to set.
	 */
	public void setDealer_address(String dealer_address) {
		this.dealer_address = dealer_address;
	}
	/**
	 * @return Returns the dealer_ba_id.
	 */
	public String getDealer_ba_id() {
		return dealer_ba_id;
	}
	/**
	 * @param dealer_ba_id The dealer_ba_id to set.
	 */
	public void setDealer_ba_id(String dealer_ba_id) {
		this.dealer_ba_id = dealer_ba_id;
	}
	/**
	 * @return Returns the dealer_city.
	 */
	public String getDealer_city() {
		return dealer_city;
	}
	/**
	 * @param dealer_city The dealer_city to set.
	 */
	public void setDealer_city(String dealer_city) {
		this.dealer_city = dealer_city;
	}
	/**
	 * @return Returns the dealer_name.
	 */
	public String getDealer_name() {
		return dealer_name;
	}
	/**
	 * @param dealer_name The dealer_name to set.
	 */
	public void setDealer_name(String dealer_name) {
		this.dealer_name = dealer_name;
	}
	/**
	 * @return Returns the dealer_phone.
	 */
	public String getDealer_phone() {
		return dealer_phone;
	}
	/**
	 * @param dealer_phone The dealer_phone to set.
	 */
	public void setDealer_phone(String dealer_phone) {
		this.dealer_phone = dealer_phone;
	}
	/**
	 * @return Returns the dealer_state.
	 */
	public String getDealer_state() {
		return dealer_state;
	}
	/**
	 * @param dealer_state The dealer_state to set.
	 */
	public void setDealer_state(String dealer_state) {
		this.dealer_state = dealer_state;
	}
	/**
	 * @return Returns the delivery_other.
	 */
	public boolean isDelivery_other() {
		return delivery_other;
	}
	/**
	 * @param delivery_other The delivery_other to set.
	 */
	public void setDelivery_other(boolean delivery_other) {
		this.delivery_other = delivery_other;
	}
	
	/**
	 * @return Returns the driver_performance.
	 */
	public boolean isDriver_performance() {
		return driver_performance;
	}
	
	/**
	 * @param driver_performance The driver_performance to set.
	 */
	public void setDriver_performance(boolean driver_performance) {
		this.driver_performance = driver_performance;
	}
	
	/**
	 * @return Returns the disease_development.
	 */
	public boolean isDisease_development() {
		return disease_development;
	}
	/**
	 * @param disease_development The disease_development to set.
	 */
	public void setDisease_development(boolean disease_development) {
		this.disease_development = disease_development;
	}
	/**
	 * @return Returns the disease_observed.
	 */
	public String getDisease_observed() {
		return disease_observed;
	}
	/**
	 * @param disease_observed The disease_observed to set.
	 */
	public void setDisease_observed(String disease_observed) {
		this.disease_observed = disease_observed;
	}
	/**
	 * @return Returns the early_season_other.
	 */
	public boolean isEarly_season_other() {
		return early_season_other;
	}
	/**
	 * @param early_season_other The early_season_other to set.
	 */
	public void setEarly_season_other(boolean early_season_other) {
		this.early_season_other = early_season_other;
	}
	/**
	 * @return Returns the emergence_concerns.
	 */
	public boolean isEmergence_concerns() {
		return emergence_concerns;
	}
	/**
	 * @param emergence_concerns The emergence_concerns to set.
	 */
	public void setEmergence_concerns(boolean emergence_concerns) {
		this.emergence_concerns = emergence_concerns;
	}
	/**
	 * @return Returns the grower_address.
	 */
	public String getGrower_address() {
		return grower_address;
	}
	/**
	 * @param grower_address The grower_address to set.
	 */
	public void setGrower_address(String grower_address) {
		this.grower_address = grower_address;
	}
	/**
	 * @return Returns the grower_ba_id.
	 */
	public String getGrower_ba_id() {
		return grower_ba_id;
	}
	/**
	 * @param grower_ba_id The grower_ba_id to set.
	 */
	public void setGrower_ba_id(String grower_ba_id) {
		this.grower_ba_id = grower_ba_id;
	}
	/**
	 * @return Returns the grower_city.
	 */
	public String getGrower_city() {
		return grower_city;
	}
	/**
	 * @param grower_city The grower_city to set.
	 */
	public void setGrower_city(String grower_city) {
		this.grower_city = grower_city;
	}
	/**
	 * @return Returns the grower_name.
	 */
	public String getGrower_name() {
		return grower_name;
	}
	/**
	 * @param grower_name The grower_name to set.
	 */
	public void setGrower_name(String grower_name) {
		this.grower_name = grower_name;
	}
	/**
	 * @return Returns the grower_phone.
	 */
	public String getGrower_phone() {
		return grower_phone;
	}
	/**
	 * @param grower_phone The grower_phone to set.
	 */
	public void setGrower_phone(String grower_phone) {
		this.grower_phone = grower_phone;
	}
	/**
	 * @return Returns the grower_state.
	 */
	public String getGrower_state() {
		return grower_state;
	}
	/**
	 * @param grower_state The grower_state to set.
	 */
	public void setGrower_state(String grower_state) {
		this.grower_state = grower_state;
	}
	/**
	 * @return Returns the growth_development.
	 */
	public boolean isGrowth_development() {
		return growth_development;
	}
	/**
	 * @param growth_development The growth_development to set.
	 */
	public void setGrowth_development(boolean growth_development) {
		this.growth_development = growth_development;
	}
	/**
	 * @return Returns the herbicide_injury.
	 */
	public boolean isHerbicide_injury() {
		return herbicide_injury;
	}
	/**
	 * @param herbicide_injury The herbicide_injury to set.
	 */
	public void setHerbicide_injury(boolean herbicide_injury) {
		this.herbicide_injury = herbicide_injury;
	}
	/**
	 * @return Returns the herbicide_rate_current.
	 */
	public String getHerbicide_rate_current() {
		return herbicide_rate_current;
	}
	/**
	 * @param herbicide_rate_current The herbicide_rate_current to set.
	 */
	public void setHerbicide_rate_current(String herbicide_rate_current) {
		this.herbicide_rate_current = herbicide_rate_current;
	}
	/**
	 * @return Returns the herbicide_rate_prev.
	 */
	public String getHerbicide_rate_prev() {
		return herbicide_rate_prev;
	}
	/**
	 * @param herbicide_rate_prev The herbicide_rate_prev to set.
	 */
	public void setHerbicide_rate_prev(String herbicide_rate_prev) {
		this.herbicide_rate_prev = herbicide_rate_prev;
	}
	/**
	 * @return Returns the herbicide_timming_current.
	 */
	public String getHerbicide_timming_current() {
		return herbicide_timming_current;
	}
	/**
	 * @param herbicide_timming_current The herbicide_timming_current to set.
	 */
	public void setHerbicide_timming_current(String herbicide_timming_current) {
		this.herbicide_timming_current = herbicide_timming_current;
	}
	/**
	 * @return Returns the herbicide_timming_prev.
	 */
	public String getHerbicide_timming_prev() {
		return herbicide_timming_prev;
	}
	/**
	 * @param herbicide_timming_prev The herbicide_timming_prev to set.
	 */
	public void setHerbicide_timming_prev(String herbicide_timming_prev) {
		this.herbicide_timming_prev = herbicide_timming_prev;
	}
	/**
	 * @return Returns the herbicide_type_current.
	 */
	public String getHerbicide_type_current() {
		return herbicide_type_current;
	}
	/**
	 * @param herbicide_type_current The herbicide_type_current to set.
	 */
	public void setHerbicide_type_current(String herbicide_type_current) {
		this.herbicide_type_current = herbicide_type_current;
	}
	/**
	 * @return Returns the herbicide_type_prev.
	 */
	public String getHerbicide_type_prev() {
		return herbicide_type_prev;
	}
	/**
	 * @param herbicide_type_prev The herbicide_type_prev to set.
	 */
	public void setHerbicide_type_prev(String herbicide_type_prev) {
		this.herbicide_type_prev = herbicide_type_prev;
	}
	/**
	 * @return Returns the incorrect_shipment.
	 */
	public boolean isIncorrect_shipment() {
		return true;
	}
	/**
	 * @param incorrect_shipment The incorrect_shipment to set.
	 */
	public void setIncorrect_shipment(boolean incorrect_shipment) {
		this.incorrect_shipment = true;
	}
	/**
	 * @return Returns the insect_development.
	 */
	public boolean isInsect_development() {
		return insect_development;
	}
	/**
	 * @param insect_development The insect_development to set.
	 */
	public void setInsect_development(boolean insect_development) {
		this.insect_development = insect_development;
	}
	/**
	 * @return Returns the insect_outbreaks_injury.
	 */
	public boolean isInsect_outbreaks_injury() {
		return insect_outbreaks_injury;
	}
	/**
	 * @param insect_outbreaks_injury The insect_outbreaks_injury to set.
	 */
	public void setInsect_outbreaks_injury(boolean insect_outbreaks_injury) {
		this.insect_outbreaks_injury = insect_outbreaks_injury;
	}
	/**
	 * @return Returns the insecticide_rate_current.
	 */
	public String getInsecticide_rate_current() {
		return insecticide_rate_current;
	}
	/**
	 * @param insecticide_rate_current The insecticide_rate_current to set.
	 */
	public void setInsecticide_rate_current(String insecticide_rate_current) {
		this.insecticide_rate_current = insecticide_rate_current;
	}
	/**
	 * @return Returns the insecticide_rate_prev.
	 */
	public String getInsecticide_rate_prev() {
		return insecticide_rate_prev;
	}
	/**
	 * @param insecticide_rate_prev The insecticide_rate_prev to set.
	 */
	public void setInsecticide_rate_prev(String insecticide_rate_prev) {
		this.insecticide_rate_prev = insecticide_rate_prev;
	}
	/**
	 * @return Returns the insecticide_timming_current.
	 */
	public String getInsecticide_timming_current() {
		return insecticide_timming_current;
	}
	/**
	 * @param insecticide_timming_current The insecticide_timming_current to set.
	 */
	public void setInsecticide_timming_current(
			String insecticide_timming_current) {
		this.insecticide_timming_current = insecticide_timming_current;
	}
	/**
	 * @return Returns the insecticide_timming_prev.
	 */
	public String getInsecticide_timming_prev() {
		return insecticide_timming_prev;
	}
	/**
	 * @param insecticide_timming_prev The insecticide_timming_prev to set.
	 */
	public void setInsecticide_timming_prev(String insecticide_timming_prev) {
		this.insecticide_timming_prev = insecticide_timming_prev;
	}
	/**
	 * @return Returns the insecticide_type_current.
	 */
	public String getInsecticide_type_current() {
		return insecticide_type_current;
	}
	/**
	 * @param insecticide_type_current The insecticide_type_current to set.
	 */
	public void setInsecticide_type_current(String insecticide_type_current) {
		this.insecticide_type_current = insecticide_type_current;
	}
	/**
	 * @return Returns the insecticide_type_prev.
	 */
	public String getInsecticide_type_prev() {
		return insecticide_type_prev;
	}
	/**
	 * @param insecticide_type_prev The insecticide_type_prev to set.
	 */
	public void setInsecticide_type_prev(String insecticide_type_prev) {
		this.insecticide_type_prev = insecticide_type_prev;
	}
	/**
	 * @return Returns the insects_observed.
	 */
	public String getInsects_observed() {
		return insects_observed;
	}
	/**
	 * @param insects_observed The insects_observed to set.
	 */
	public void setInsects_observed(String insects_observed) {
		this.insects_observed = insects_observed;
	}
	/**
	 * @return Returns the late_season_other.
	 */
	public boolean isLate_season_other() {
		return late_season_other;
	}
	/**
	 * @param late_season_other The late_season_other to set.
	 */
	public void setLate_season_other(boolean late_season_other) {
		this.late_season_other = late_season_other;
	}
	/**
	 * @return Returns the lateseason_disease_development.
	 */
	public boolean isLateseason_disease_development() {
		return lateseason_disease_development;
	}
	/**
	 * @param lateseason_disease_development The lateseason_disease_development to set.
	 */
	public void setLateseason_disease_development(
			boolean lateseason_disease_development) {
		this.lateseason_disease_development = lateseason_disease_development;
	}
	/**
	 * @return Returns the maintaining_seed_until_harvest.
	 */
	public boolean isMaintaining_seed_until_harvest() {
		return maintaining_seed_until_harvest;
	}
	/**
	 * @param maintaining_seed_until_harvest The maintaining_seed_until_harvest to set.
	 */
	public void setMaintaining_seed_until_harvest(
			boolean maintaining_seed_until_harvest) {
		this.maintaining_seed_until_harvest = maintaining_seed_until_harvest;
	}
	/**
	 * @return Returns the maturity_drydown.
	 */
	public boolean isMaturity_drydown() {
		return maturity_drydown;
	}
	/**
	 * @param maturity_drydown The maturity_drydown to set.
	 */
	public void setMaturity_drydown(boolean maturity_drydown) {
		this.maturity_drydown = maturity_drydown;
	}
	/**
	 * @return Returns the midseason_other.
	 */
	public boolean isMidseason_other() {
		return midseason_other;
	}
	/**
	 * @param midseason_other The midseason_other to set.
	 */
	public void setMidseason_other(boolean midseason_other) {
		this.midseason_other = midseason_other;
	}
	/**
	 * @return Returns the noncompetitive_yield.
	 */
	public boolean isNoncompetitive_yield() {
		return noncompetitive_yield;
	}
	/**
	 * @param noncompetitive_yield The noncompetitive_yield to set.
	 */
	public void setNoncompetitive_yield(boolean noncompetitive_yield) {
		this.noncompetitive_yield = noncompetitive_yield;
	}
	/**
	 * @return Returns the packaging_condition.
	 */
	public boolean isPackaging_condition() {
		return packaging_condition;
	}
	/**
	 * @param packaging_condition The packaging_condition to set.
	 */
	public void setPackaging_condition(boolean packaging_condition) {
		this.packaging_condition = packaging_condition;
	}
	/**
	 * @return Returns the planter_depth.
	 */
	public String getPlanter_depth() {
		return planter_depth;
	}
	/**
	 * @param planter_depth The planter_depth to set.
	 */
	public void setPlanter_depth(String planter_depth) {
		this.planter_depth = planter_depth;
	}
	/**
	 * @return Returns the planter_type.
	 */
	public String getPlanter_type() {
		return planter_type;
	}
	/**
	 * @param planter_type The planter_type to set.
	 */
	public void setPlanter_type(String planter_type) {
		this.planter_type = planter_type;
	}
	/**
	 * @return Returns the planting_date.
	 */
	public String getPlanting_date() {
		return planting_date;
	}
	/**
	 * @param planting_date The planting_date to set.
	 */
	public void setPlanting_date(String planting_date) {
		this.planting_date = planting_date;
	}
	/**
	 * @return Returns the pollination_problems.
	 */
	public boolean isPollination_problems() {
		return pollination_problems;
	}
	/**
	 * @param pollination_problems The pollination_problems to set.
	 */
	public void setPollination_problems(boolean pollination_problems) {
		this.pollination_problems = pollination_problems;
	}
	/**
	 * @return Returns the population_observed.
	 */
	public String getPopulation_observed() {
		return population_observed;
	}
	/**
	 * @param population_observed The population_observed to set.
	 */
	public void setPopulation_observed(String population_observed) {
		this.population_observed = population_observed;
	}
	/**
	 * @return Returns the population_planted.
	 */
	public String getPopulation_planted() {
		return population_planted;
	}
	/**
	 * @param population_planted The population_planted to set.
	 */
	public void setPopulation_planted(String population_planted) {
		this.population_planted = population_planted;
	}
	/**
	 * @return Returns the product_purity.
	 */
	public boolean isProduct_purity() {
		return product_purity;
	}
	/**
	 * @param product_purity The product_purity to set.
	 */
	public void setProduct_purity(boolean product_purity) {
		this.product_purity = product_purity;
	}
	/**
	 * @return Returns the seed_appearance.
	 */
	public boolean isSeed_appearance() {
		return seed_appearance;
	}
	/**
	 * @param seed_appearance The seed_appearance to set.
	 */
	public void setSeed_appearance(boolean seed_appearance) {
		this.seed_appearance = seed_appearance;
	}
	/**
	 * @return Returns the seed_development.
	 */
	public boolean isSeed_development() {
		return seed_development;
	}
	/**
	 * @param seed_development The seed_development to set.
	 */
	public void setSeed_development(boolean seed_development) {
		this.seed_development = seed_development;
	}
	/**
	 * @return Returns the seed_variability.
	 */
	public boolean isSeed_variability() {
		return seed_variability;
	}
	/**
	 * @param seed_variability The seed_variability to set.
	 */
	public void setSeed_variability(boolean seed_variability) {
		this.seed_variability = seed_variability;
	}
	/**
	 * @return Returns the stress_susceptability.
	 */
	public boolean isStress_susceptability() {
		return stress_susceptability;
	}
	/**
	 * @param stress_susceptability The stress_susceptability to set.
	 */
	public void setStress_susceptability(boolean stress_susceptability) {
		this.stress_susceptability = stress_susceptability;
	}
	/**
	 * @return Returns the tag_error.
	 */
	public boolean isTag_error() {
		return tag_error;
	}
	/**
	 * @param tag_error The tag_error to set.
	 */
	public void setTag_error(boolean tag_error) {
		this.tag_error = tag_error;
	}
	/**
	 * @return Returns the technology.
	 */
	public String getTechnology() {
		return technology;
	}
	/**
	 * @param technology The technology to set.
	 */
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	/**
	 * @return Returns the tillage.
	 */
	public String getTillage() {
		return tillage;
	}
	/**
	 * @param tillage The tillage to set.
	 */
	public void setTillage(String tillage) {
		this.tillage = tillage;
	}
	/**
	 * @return Returns the total_acres.
	 */
	public String getTotal_acres() {
		return total_acres;
	}
	/**
	 * @param total_acres The total_acres to set.
	 */
	public void setTotal_acres(String total_acres) {
		this.total_acres = total_acres;
	}
	/**
	 * @return Returns the created_by.
	 */
	public String getCreated_by() {
		return created_by;
	}
	/**
	 * @param created_by The created_by to set.
	 */
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	/**
	 * @return Returns the region_id.
	 */
	public String getRegion_id() {
		return region_id;
	}
	/**
	 * @param region_id The region_id to set.
	 */
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	/**
	 * @return Returns the batch_four.
	 */
	public String getBatch_four() {
		return batch_four;
	}
	/**
	 * @param batch_four The batch_four to set.
	 */
	public void setBatch_four(String batch_four) {
		this.batch_four = batch_four;
	}
	/**
	 * @return Returns the batch_one.
	 */
	public String getBatch_one() {
		return batch_one;
	}
	/**
	 * @param batch_one The batch_one to set.
	 */
	public void setBatch_one(String batch_one) {
		this.batch_one = batch_one;
	}
	/**
	 * @return Returns the batch_three.
	 */
	public String getBatch_three() {
		return batch_three;
	}
	/**
	 * @param batch_three The batch_three to set.
	 */
	public void setBatch_three(String batch_three) {
		this.batch_three = batch_three;
	}
	/**
	 * @return Returns the batch_two.
	 */
	public String getBatch_two() {
		return batch_two;
	}
	/**
	 * @param batch_two The batch_two to set.
	 */
	public void setBatch_two(String batch_two) {
		this.batch_two = batch_two;
	}
	/**
	 * @return Returns the variety_four.
	 */
	public String getVariety_four() {
		return variety_four;
	}
	/**
	 * @param variety_four The variety_four to set.
	 */
	public void setVariety_four(String variety_four) {
		this.variety_four = variety_four;
	}
	/**
	 * @return Returns the variety_one.
	 */
	public String getVariety_one() {
		return variety_one;
	}
	/**
	 * @param variety_one The variety_one to set.
	 */
	public void setVariety_one(String variety_one) {
		this.variety_one = variety_one;
	}
	/**
	 * @return Returns the variety_three.
	 */
	public String getVariety_three() {
		return variety_three;
	}
	/**
	 * @param variety_three The variety_three to set.
	 */
	public void setVariety_three(String variety_three) {
		this.variety_three = variety_three;
	}
	/**
	 * @return Returns the variety_two.
	 */
	public String getVariety_two() {
		return variety_two;
	}
	/**
	 * @param variety_two The variety_two to set.
	 */
	public void setVariety_two(String variety_two) {
		this.variety_two = variety_two;
	}
	/**
	 * @return Returns the affina_entry_flag.
	 */
	public String getAffina_entry_flag() {
		return affina_entry_flag;
	}
	/**
	 * @param affina_entry_flag The affina_entry_flag to set.
	 */
	public void setAffina_entry_flag(String affina_entry_flag) {
		this.affina_entry_flag = affina_entry_flag;
	}
	/**
	 * @return Returns the settlement_value.
	 */
	public String getSettlement_value() {
		return settlement_value;
	}
	/**
	 * @param settlement_value The settlement_value to set.
	 */
	public void setSettlement_value(String settlement_value) {
		this.settlement_value = settlement_value;
	}
	/**
	 * @return Returns the foundBatch1.
	 */
	public String getFoundBatch1() {
		return foundBatch1;
	}
	/**
	 * @param foundBatch1 The foundBatch1 to set.
	 */
	public void setFoundBatch1(String foundBatch1) {
		this.foundBatch1 = foundBatch1;
	}
	/**
	 * @return Returns the foundBatch2.
	 */
	public String getFoundBatch2() {
		return foundBatch2;
	}
	/**
	 * @param foundBatch2 The foundBatch2 to set.
	 */
	public void setFoundBatch2(String foundBatch2) {
		this.foundBatch2 = foundBatch2;
	}
	/**
	 * @return Returns the foundBatch3.
	 */
	public String getFoundBatch3() {
		return foundBatch3;
	}
	/**
	 * @param foundBatch3 The foundBatch3 to set.
	 */
	public void setFoundBatch3(String foundBatch3) {
		this.foundBatch3 = foundBatch3;
	}
	/**
	 * @return Returns the foundBatch4.
	 */
	public String getFoundBatch4() {
		return foundBatch4;
	}
	/**
	 * @param foundBatch4 The foundBatch4 to set.
	 */
	public void setFoundBatch4(String foundBatch4) {
		this.foundBatch4 = foundBatch4;
	}
	/**
	 * @return Returns the report_initiator_email.
	 */
	public String getReport_initiator_email() {
		return report_initiator_email;
	}
	/**
	 * @param report_initiator_email The report_initiator_email to set.
	 */
	public void setReport_initiator_email(String report_initiator_email) {
		this.report_initiator_email = report_initiator_email;
	}

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(super.toString() + "\n");
        buffer.append("complaint_id " + complaint_id + "\n");
        buffer.append("claim_number " + claim_number + "\n");
        buffer.append("status_id " + status_id + "\n");
        buffer.append("sales_year_id " + sales_year_id + "\n");
        buffer.append("state_id " + state_id + "\n");
        buffer.append("report_initiator " + report_initiator + "\n");
        buffer.append("report_initiator_email " + report_initiator_email + "\n");
        buffer.append("report_date " + report_date + "\n");
        buffer.append("communication_date " + communication_date + "\n");
        buffer.append("region_id " + region_id + "\n");
        buffer.append("field_communicator " + field_communicator + "\n");
        buffer.append("reporting_location_code " + reporting_location_code + "\n");
        buffer.append("responsible_plant_code " + responsible_plant_code + "\n");
        buffer.append("person_investigating " + person_investigating + "\n");
        buffer.append("crop_id " + crop_id + "\n");
        buffer.append("quality_issue " + quality_issue + "\n");
        buffer.append("quantity_affected " + quantity_affected + "\n");
        buffer.append("quantity_uom_id " + quantity_uom_id + "\n");
        buffer.append("seed_size_id " + seed_size_id + "\n");
        buffer.append("batch_one " + batch_one + "\n");
        buffer.append("batch_two " + batch_two + "\n");
        buffer.append("batch_three " + batch_three + "\n");
        buffer.append("batch_four " + batch_four + "\n");
        buffer.append("variety_one " + variety_one + "\n");
        buffer.append("variety_two " + variety_two + "\n");
        buffer.append("variety_three " + variety_three + "\n");
        buffer.append("variety_four " + variety_four + "\n");
        buffer.append("foundBatch1 " + foundBatch1 + "\n");
        buffer.append("foundBatch2 " + foundBatch2 + "\n");
        buffer.append("foundBatch3 " + foundBatch3 + "\n");
        buffer.append("foundBatch4 " + foundBatch4 + "\n");
        buffer.append("foundBatch4 " + foundBatch4 + "\n");
        buffer.append("problem_description " + problem_description + "\n");
        buffer.append("containment_actions " + containment_actions + "\n");
        buffer.append("root_cause " + root_cause + "\n");
        buffer.append("long_term_corrective_action " + long_term_corrective_action + "\n");
        buffer.append("driver_performance " + driver_performance + "\n");
        buffer.append("incorrect_shipment " + incorrect_shipment + "\n");
        buffer.append("delivery_other " + delivery_other + "\n");
        buffer.append("packaging_condition " + packaging_condition + "\n");
        buffer.append("tag_error " + tag_error + "\n");
        buffer.append("seed_appearance " + seed_appearance + "\n");
        buffer.append("seed_variability " + seed_variability + "\n");
        buffer.append("emergence_concerns " + emergence_concerns + "\n");
        buffer.append("product_purity " + product_purity + "\n");
        buffer.append("product_purity " + product_purity + "\n");
        buffer.append("early_season_other " + early_season_other + "\n");
        buffer.append("growth_development " + growth_development + "\n");
        buffer.append("pollination_problems " + pollination_problems + "\n");
        buffer.append("herbicide_injury " + herbicide_injury + "\n");
        buffer.append("stress_susceptability " + stress_susceptability + "\n");
        buffer.append("disease_development " + disease_development + "\n");
        buffer.append("midseason_other " + midseason_other + "\n");
        buffer.append("insect_outbreaks_injury " + insect_outbreaks_injury + "\n");
        buffer.append("lateseason_disease_development " + lateseason_disease_development + "\n");
        buffer.append("maintaining_seed_until_harvest " + maintaining_seed_until_harvest + "\n");
        buffer.append("insect_development " + insect_development + "\n");
        buffer.append("maturity_drydown " + maturity_drydown + "\n");
        buffer.append("seed_development " + seed_development + "\n");
        buffer.append("late_season_other " + late_season_other + "\n");
        buffer.append("noncompetitive_yield " + noncompetitive_yield + "\n");
	    buffer.append("delivery_info " + delivery_info + "\n");
	    buffer.append("issue_other " + issue_other + "\n");
        buffer.append("total_acres " + total_acres + "\n");
        buffer.append("affected_areas " + affected_areas + "\n");
        buffer.append("technology " + technology + "\n");
        buffer.append("population_planted " + population_planted + "\n");
        buffer.append("population_observed " + population_observed + "\n");
        buffer.append("tillage " + tillage + "\n");
        buffer.append("planting_date " + planting_date + "\n");
        buffer.append("planter_type " + planter_type + "\n");
        buffer.append("planter_depth " + planter_depth + "\n");
        buffer.append("disease_observed " + disease_observed + "\n");
        buffer.append("herbicide_type_current " + herbicide_type_current + "\n");
        buffer.append("herbicide_timming_current " + herbicide_timming_current + "\n");
        buffer.append("herbicide_rate_current " + herbicide_rate_current + "\n");
        buffer.append("herbicide_type_prev " + herbicide_type_prev + "\n");
        buffer.append("herbicide_timming_prev " + herbicide_timming_prev + "\n");
        buffer.append("herbicide_rate_prev " + herbicide_rate_prev + "\n");
        buffer.append("insects_observed " + insects_observed + "\n");
        buffer.append("insecticide_type_current " + insecticide_type_current + "\n");
        buffer.append("insecticide_timming_current " + insecticide_timming_current + "\n");
        buffer.append("insecticide_rate_current " + insecticide_rate_current + "\n");
        buffer.append("insecticide_rate_current " + insecticide_rate_current + "\n");
        buffer.append("insecticide_type_prev " + insecticide_type_prev + "\n");
        buffer.append("insecticide_timming_prev " + insecticide_timming_prev + "\n");
        buffer.append("insecticide_rate_prev " + insecticide_rate_prev + "\n");
        buffer.append("grower_name " + grower_name + "\n");
        buffer.append("grower_address " + grower_address + "\n");
        buffer.append("grower_city " + grower_city + "\n");
        buffer.append("grower_state " + grower_state + "\n");
        buffer.append("grower_phone " + grower_phone + "\n");
        buffer.append("grower_ba_id " + grower_ba_id + "\n");
        buffer.append("dealer_name " + dealer_name + "\n");
        buffer.append("dealer_address " + dealer_address + "\n");
        buffer.append("dealer_city " + dealer_city + "\n");
        buffer.append("dealer_state " + dealer_state + "\n");
        buffer.append("dealer_phone " + dealer_phone + "\n");
        buffer.append("dealer_ba_id " + dealer_ba_id + "\n");
        buffer.append("created_by " + created_by + "\n");
        buffer.append("row_entry_date " + row_entry_date + "\n");
        buffer.append("row_modify_date " + row_modify_date + "\n");
        buffer.append("row_task_id " + row_task_id + "\n");
        buffer.append("settlement_value " + settlement_value + "\n");
        buffer.append("affina_entry_flag " + affina_entry_flag + "\n");

        return buffer.toString();
    }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Complaint complaint = (Complaint) o;
    if(ComparisonUtil.unequal(status_id, complaint.status_id)) return false;
    if(ComparisonUtil.unequal(region_id, complaint.region_id)) return false;
    if(ComparisonUtil.unequal(reporting_location_code, complaint.reporting_location_code)) return false;
    if(ComparisonUtil.unequal(report_initiator, complaint.report_initiator)) return false;
    if(ComparisonUtil.unequal(report_date, complaint.report_date)) return false;
    if(ComparisonUtil.unequal(communication_date, complaint.communication_date)) return false;
    if(ComparisonUtil.unequal(responsible_plant_code, complaint.responsible_plant_code)) return false;
    if(ComparisonUtil.unequal(field_communicator, complaint.field_communicator)) return false;
    if(ComparisonUtil.unequal(person_investigating, complaint.person_investigating)) return false;
    if(ComparisonUtil.unequal(variety_one, complaint.variety_one)) return false;
    if(ComparisonUtil.unequal(quality_issue, complaint.quality_issue)) return false;
    if(ComparisonUtil.unequal(problem_description, complaint.problem_description)) return false;
    return true;
  }
}
