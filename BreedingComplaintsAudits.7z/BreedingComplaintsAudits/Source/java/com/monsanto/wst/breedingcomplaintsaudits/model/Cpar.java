/*
 * Created on Feb 18, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.breedingcomplaintsaudits.util.ComparisonUtil;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Style - Code Templates
 */
public class Cpar {

  private String cpar_id;

  private String complaint_id;

  private String stop_sale_id;

  private String stop_sale_number;

  private String audit_finding_id;

  private String audit_id;

  private String audit_number;

  private String control_number;

  private String claim_number;

  private String status_id;

  private boolean suppress_overdue_notice;

  private String created_by;

  private String issue_year;

  private String initiated_by;

  private String report_initiator_email;

  private String report_date;

  private String finding_type;

  private String iso_standard;

  private String generator;

  private String mgmt_approval_person;

  private String mgmt_approval_date;

  private String site_manager;

  private String effectiveness_evaluator;

  private String filing_location;

  private String responsible_location;

  private String investigation_findings;

  private String containment_actions_person;

  private String containment_actions_date;

  private String containment_actions;

  private String root_cause_person;

  private String root_cause_date;

  private String root_cause;

  private String long_term_corrective_action_person;

  private String long_term_corrective_action_date;

  private String long_term_corrective_action;

  private String evaluation_person;

  private String evaluation_date;

  private String evaluation_comments;

  private String evaluation_effective;

  private boolean evaluation_not_applicable;

  private String car_flag;

  private String region;

  private String continual_Improvements;

  private String row_entry_date;

  private String row_modify_date;

  private String row_task_id;

  private String row_user_id;

  /**
   * @return Returns the stop_sale_number.
   */
  public String getStop_sale_number() {
    return stop_sale_number;
  }

  /**
   * @param stop_sale_number The stop_sale_number to set.
   */
  public void setStop_sale_number(String stop_sale_number) {
    this.stop_sale_number = stop_sale_number;
  }

  /**
   * @return Returns the audit_number.
   */
  public String getAudit_number() {
    return audit_number;
  }

  /**
   * @param audit_number The audit_number to set.
   */
  public void setAudit_number(String audit_number) {
    this.audit_number = audit_number;
  }

  /**
   * @return Returns the audit_id.
   */
  public String getAudit_id() {
    return audit_id;
  }

  /**
   * @param audit_id The audit_id to set.
   */
  public void setAudit_id(String audit_id) {
    this.audit_id = audit_id;
  }

  /**
   * @return Returns the audit_finding_id.
   */
  public String getAudit_finding_id() {
    return audit_finding_id;
  }

  /**
   * @param audit_finding_id The audit_finding_id to set.
   */
  public void setAudit_finding_id(String audit_finding_id) {
    this.audit_finding_id = audit_finding_id;
  }

  /**
   * @return Returns the car_flag.
   */
  public String getCar_flag() {
    return car_flag;
  }

  /**
   * @param car_flag The car_flag to set.
   */
  public void setCar_flag(String car_flag) {
    this.car_flag = car_flag;
  }

  /**
   * @return Returns the claim_number.
   */
  public String getClaim_number() {
    return claim_number;
  }

  /**
   * @param claim_number The claim_number to set.
   */
  public void setClaim_number(String claim_number) {
    this.claim_number = claim_number;
  }

  /**
   * @return Returns the complaint_id.
   */
  public String getComplaint_id() {
    return complaint_id;
  }

  /**
   * @param complaint_id The complaint_id to set.
   */
  public void setComplaint_id(String complaint_id) {
    this.complaint_id = complaint_id;
  }

  public boolean isSuppress_overdue_notice() {
    return suppress_overdue_notice;
  }

  public void setSuppress_overdue_notice(boolean suppress_overdue_notice) {
    this.suppress_overdue_notice = suppress_overdue_notice;
  }

  /**
   * @return Returns the containment_actions.
   */
  public String getContainment_actions() {
    return containment_actions;
  }

  /**
   * @param containment_actions The containment_actions to set.
   */
  public void setContainment_actions(String containment_actions) {
    this.containment_actions = containment_actions;
  }

  /**
   * @return Returns the control_number.
   */
  public String getControl_number() {
    return control_number;
  }

  /**
   * @param control_number The control_number to set.
   */
  public void setControl_number(String control_number) {
    this.control_number = control_number;
  }

  /**
   * @return Returns the cpar_id.
   */
  public String getCpar_id() {
    return cpar_id;
  }

  /**
   * @param cpar_id The cpar_id to set.
   */
  public void setCpar_id(String cpar_id) {
    this.cpar_id = cpar_id;
  }

  /**
   * @return Returns the created_by.
   */
  public String getCreated_by() {
    return created_by;
  }

  /**
   * @param created_by The created_by to set.
   */
  public void setCreated_by(String created_by) {
    this.created_by = created_by;
  }

  /**
   * @return Returns the effectiveness_evaluator.
   */
  public String getEffectiveness_evaluator() {
    return effectiveness_evaluator;
  }

  /**
   * @param effectiveness_evaluator The effectiveness_evaluator to set.
   */
  public void setEffectiveness_evaluator(String effectiveness_evaluator) {
    this.effectiveness_evaluator = effectiveness_evaluator;
  }

  /**
   * @return Returns the evaluation_date.
   */
  public String getEvaluation_date() {
    return evaluation_date;
  }

  /**
   * @param evaluation_date The evaluation_date to set.
   */
  public void setEvaluation_date(String evaluation_date) {
    this.evaluation_date = evaluation_date;
  }

  /**
   * @return Returns the filing_location.
   */
  public String getFiling_location() {
    return filing_location;
  }

  /**
   * @param filing_location The filing_location to set.
   */
  public void setFiling_location(String filing_location) {
    this.filing_location = filing_location;
  }

  /**
   * @return Returns the finding_type.
   */
  public String getFinding_type() {
    return finding_type;
  }

  /**
   * @param finding_type The finding_type to set.
   */
  public void setFinding_type(String finding_type) {
    this.finding_type = finding_type;
  }

  /**
   * @return Returns the generator.
   */
  public String getGenerator() {
    return generator;
  }

  /**
   * @param generator The generator to set.
   */
  public void setGenerator(String generator) {
    this.generator = generator;
  }

  /**
   * @return Returns the initiated_by.
   */
  public String getInitiated_by() {
    return initiated_by;
  }

  /**
   * @param initiated_by The initiated_by to set.
   */
  public void setInitiated_by(String initiated_by) {
    this.initiated_by = initiated_by;
  }

  /**
   * @return Returns the investigation_findings.
   */
  public String getInvestigation_findings() {
    return investigation_findings;
  }

  /**
   * @param investigation_findings The investigation_findings to set.
   */
  public void setInvestigation_findings(String investigation_findings) {
    this.investigation_findings = investigation_findings;
  }

  /**
   * @return Returns the iso_standard.
   */
  public String getIso_standard() {
    return iso_standard;
  }

  /**
   * @param iso_standard The iso_standard to set.
   */
  public void setIso_standard(String iso_standard) {
    this.iso_standard = iso_standard;
  }

  /**
   * @return Returns the issue_year.
   */
  public String getIssue_year() {
    return "0";
  }

  /**
   * @param issue_year The issue_year to set.
   */
  public void setIssue_year(String issue_year) {
    this.issue_year = "0";
  }

  /**
   * @return Returns the long_term_corrective_action.
   */
  public String getLong_term_corrective_action() {
    return long_term_corrective_action;
  }

  /**
   * @param long_term_corrective_action The long_term_corrective_action to set.
   */
  public void setLong_term_corrective_action(
          String long_term_corrective_action) {
    this.long_term_corrective_action = long_term_corrective_action;
  }

  public String getEvaluation_comments() {
    return evaluation_comments;
  }

  public void setEvaluation_comments(String evaluation_comments) {
    this.evaluation_comments = evaluation_comments;
  }


  /**
   * @return Returns the evaluation_person
   */
  public String getEvaluation_person() {
    return evaluation_person;
  }

  public void setEvaluation_person(
          String eval_person) {
    this.evaluation_person = eval_person;
  }


  /**
   * @return Returns the evaluation_effective
   */
  public String getEvaluation_effective() {
    return evaluation_effective;
  }

  /**
   * @param eval_effective The evaluation_effective to set.
   */
  public void setEvaluation_effective(
          String eval_effective) {
    this.evaluation_effective = eval_effective;
  }

  public String getContinual_Improvements() {
    return continual_Improvements;
  }

  /**
   * @param continual_Improvements The continual_Improvements to set.
   */

  public void setContinual_Improvements(String continual_Improvements) {
    this.continual_Improvements = continual_Improvements;
  }


  public boolean isEvaluation_not_applicable() {
    return evaluation_not_applicable;
  }

  public void setEvaluation_not_applicable(boolean evaluation_not_applicable) {
    this.evaluation_not_applicable = evaluation_not_applicable;
  }

  /**
   * @return Returns the mgmt_approval_date.
   */
  public String getMgmt_approval_date() {
    return mgmt_approval_date;
  }

  /**
   * @param mgmt_approval_date The mgmt_approval_date to set.
   */
  public void setMgmt_approval_date(String mgmt_approval_date) {
    this.mgmt_approval_date = mgmt_approval_date;
  }

  /**
   * @return Returns the region.
   */
  public String getRegion() {
    return "1";
  }

  /**
   * @param region The region to set.
   */
  public void setRegion(String region) {
    this.region = "1";
  }

  /**
   * @return Returns the report_date.
   */
  public String getReport_date() {
    return report_date;
  }

  /**
   * @param report_date The report_date to set.
   */
  public void setReport_date(String report_date) {
    this.report_date = report_date;
  }

  /**
   * @return Returns the responsible_location.
   */
  public String getResponsible_location() {
    return responsible_location;
  }

  /**
   * @param responsible_location The responsible_location to set.
   */
  public void setResponsible_location(String responsible_location) {
    this.responsible_location = responsible_location;
  }

  /**
   * @return Returns the root_cause.
   */
  public String getRoot_cause() {
    return root_cause;
  }

  /**
   * @param root_cause The root_cause to set.
   */
  public void setRoot_cause(String root_cause) {
    this.root_cause = root_cause;
  }

  /**
   * @return Returns the row_entry_date.
   */
  public String getRow_entry_date() {
    return row_entry_date;
  }

  /**
   * @param row_entry_date The row_entry_date to set.
   */
  public void setRow_entry_date(String row_entry_date) {
    this.row_entry_date = row_entry_date;
  }

  /**
   * @return Returns the row_modify_date.
   */
  public String getRow_modify_date() {
    return row_modify_date;
  }

  /**
   * @param row_modify_date The row_modify_date to set.
   */
  public void setRow_modify_date(String row_modify_date) {
    this.row_modify_date = row_modify_date;
  }

  /**
   * @return Returns the row_task_id.
   */
  public String getRow_task_id() {
    return row_task_id;
  }

  /**
   * @param row_task_id The row_task_id to set.
   */
  public void setRow_task_id(String row_task_id) {
    this.row_task_id = row_task_id;
  }

  /**
   * @return Returns the row_user_id.
   */
  public String getRow_user_id() {
    return row_user_id;
  }

  /**
   * @param row_user_id The row_user_id to set.
   */
  public void setRow_user_id(String row_user_id) {
    this.row_user_id = row_user_id;
  }

  /**
   * @return Returns the site_manager.
   */
  public String getSite_manager() {
    return site_manager;
  }

  /**
   * @param site_manager The site_manager to set.
   */
  public void setSite_manager(String site_manager) {
    this.site_manager = site_manager;
  }

  /**
   * @return Returns the status_id.
   */
  public String getStatus_id() {
    return status_id;
  }

  /**
   * @param status_id The status_id to set.
   */
  public void setStatus_id(String status_id) {
    this.status_id = status_id;
  }

  /**
   * @return Returns the stop_sale_id.
   */
  public String getStop_sale_id() {
    return stop_sale_id;
  }

  /**
   * @param stop_sale_id The stop_sale_id to set.
   */
  public void setStop_sale_id(String stop_sale_id) {
    this.stop_sale_id = stop_sale_id;
  }

  /**
   * @return Returns the containment_actions_date.
   */
  public String getContainment_actions_date() {
    return containment_actions_date;
  }

  /**
   * @param containment_actions_date The containment_actions_date to set.
   */
  public void setContainment_actions_date(String containment_actions_date) {
    this.containment_actions_date = containment_actions_date;
  }

  /**
   * @return Returns the containment_actions_person.
   */
  public String getContainment_actions_person() {
    return containment_actions_person;
  }

  /**
   * @param containment_actions_person The containment_actions_person to set.
   */
  public void setContainment_actions_person(String containment_actions_person) {
    this.containment_actions_person = containment_actions_person;
  }

  /**
   * @return Returns the long_term_corrective_action_date.
   */
  public String getLong_term_corrective_action_date() {
    return long_term_corrective_action_date;
  }

  /**
   * @param long_term_corrective_action_date
   *         The long_term_corrective_action_date to set.
   */
  public void setLong_term_corrective_action_date(
          String long_term_corrective_action_date) {
    this.long_term_corrective_action_date = long_term_corrective_action_date;
  }

  /**
   * @return Returns the long_term_corrective_action_person.
   */
  public String getLong_term_corrective_action_person() {
    return long_term_corrective_action_person;
  }

  /**
   * @param long_term_corrective_action_person
   *         The long_term_corrective_action_person to set.
   */
  public void setLong_term_corrective_action_person(
          String long_term_corrective_action_person) {
    this.long_term_corrective_action_person = long_term_corrective_action_person;
  }

  /**
   * @return Returns the mgmt_approval_person.
   */
  public String getMgmt_approval_person() {
    return mgmt_approval_person;
  }

  /**
   * @param mgmt_approval_person The mgmt_approval_person to set.
   */
  public void setMgmt_approval_person(String mgmt_approval_person) {
    this.mgmt_approval_person = mgmt_approval_person;
  }

  /**
   * @return Returns the root_cause_date.
   */
  public String getRoot_cause_date() {
    return root_cause_date;
  }

  /**
   * @param root_cause_date The root_cause_date to set.
   */
  public void setRoot_cause_date(String root_cause_date) {
    this.root_cause_date = root_cause_date;
  }

  /**
   * @return Returns the root_cause_person.
   */
  public String getRoot_cause_person() {
    return root_cause_person;
  }

  /**
   * @param root_cause_person The root_cause_person to set.
   */
  public void setRoot_cause_person(String root_cause_person) {
    this.root_cause_person = root_cause_person;
  }

  /**
   * @return Returns the report_initiator_email.
   */
  public String getReport_initiator_email() {
    return report_initiator_email;
  }

  /**
   * @param report_initiator_email The report_initiator_email to set.
   */
  public void setReport_initiator_email(String report_initiator_email) {
    this.report_initiator_email = report_initiator_email;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Cpar cpar = (Cpar) o;
    if (ComparisonUtil.unequal(suppress_overdue_notice, cpar.suppress_overdue_notice)) return false;
    if (ComparisonUtil.unequal(containment_actions, cpar.containment_actions)) return false;
    if (ComparisonUtil.unequal(containment_actions_date, cpar.containment_actions_date)) return false;
    if (ComparisonUtil.unequal(containment_actions_person, cpar.containment_actions_person)) return false;
    if (ComparisonUtil.unequal(evaluation_comments, cpar.evaluation_comments)) return false;
    if (ComparisonUtil.unequal(evaluation_date, cpar.evaluation_date)) return false;
    if (ComparisonUtil.unequal(evaluation_effective, cpar.evaluation_effective)) return false;
    if (ComparisonUtil.unequal(evaluation_person, cpar.evaluation_person)) return false;
    if (ComparisonUtil.unequal(finding_type, cpar.finding_type)) return false;
    if (ComparisonUtil.unequal(generator, cpar.generator)) return false;
    if (ComparisonUtil.unequal(initiated_by, cpar.initiated_by)) return false;
    if (ComparisonUtil.unequal(investigation_findings, cpar.investigation_findings)) return false;
    if (ComparisonUtil.unequal(iso_standard, cpar.iso_standard)) return false;
    if (ComparisonUtil.unequal(long_term_corrective_action, cpar.long_term_corrective_action)) return false;
    if (ComparisonUtil.unequal(long_term_corrective_action_date, cpar.long_term_corrective_action_date)) return false;
    if (ComparisonUtil.unequal(long_term_corrective_action_person, cpar.long_term_corrective_action_person)) return false;
    if (ComparisonUtil.unequal(mgmt_approval_date, cpar.mgmt_approval_date)) return false;
    if (ComparisonUtil.unequal(mgmt_approval_person, cpar.mgmt_approval_person)) return false;
    if (ComparisonUtil.unequal(report_date, cpar.report_date)) return false;
    if (ComparisonUtil.unequal(responsible_location, cpar.responsible_location)) return false;
    if (ComparisonUtil.unequal(root_cause, cpar.root_cause)) return false;
    if (ComparisonUtil.unequal(root_cause_date, cpar.root_cause_date)) return false;
    if (ComparisonUtil.unequal(root_cause_person, cpar.root_cause_person)) return false;
    if (ComparisonUtil.unequal(site_manager, cpar.site_manager)) return false;
    if (ComparisonUtil.unequal(status_id, cpar.status_id)) return false;
    return true;
  }

  public String toString() {
    System.out.println(suppress_overdue_notice);
    System.out.println(containment_actions);
    System.out.println(containment_actions_date);
    System.out.println(containment_actions_person);
    System.out.println(control_number);
    System.out.println(created_by);
    System.out.println(evaluation_comments);
    System.out.println(evaluation_date);
    System.out.println(evaluation_effective);
    System.out.println(evaluation_person);
    System.out.println(finding_type);
    System.out.println(generator);
    System.out.println(initiated_by);
    System.out.println(investigation_findings);
    System.out.println(iso_standard);
    System.out.println(long_term_corrective_action);
    System.out.println(long_term_corrective_action_date);
    System.out.println(long_term_corrective_action_person);
    System.out.println(mgmt_approval_date);
    System.out.println(mgmt_approval_person);
    System.out.println(report_date);
    System.out.println(responsible_location);
    System.out.println(root_cause);
    System.out.println(root_cause_date);
    System.out.println(root_cause_person);
    System.out.println(row_entry_date);
    System.out.println(site_manager);
    System.out.println(status_id);
    return "";
  }
}