/*
 * Created on Jul 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.io.Serializable;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparList implements Serializable {
	
	private String cparId;
	private String controlNumber;
	private String createdDate;
	private String initiatedBy;
	private String status;
	private String region;
    private String claimNumber;
    private String isoStandard;

    /**
	 * @return Returns the claimNumber.
	 */
	public String getClaimNumber() {
		return claimNumber;
	}

    /**
	 * @param claimNumber The claimNumber to set.
	 */
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

    /**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}

    /**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}

    /**
	 * @return Returns the cparId.
	 */
	public String getCparId() {
		return cparId;
	}

    /**
	 * @param cparId The cparId to set.
	 */
	public void setCparId(String cparId) {
		this.cparId = cparId;
	}

    /**
	 * @return Returns the createdDate.
	 */
	public String getCreatedDate() {
		return createdDate;
	}

    /**
	 * @param createdDate The createdDate to set.
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

    /**
	 * @return Returns the initiatedBy.
	 */
	public String getInitiatedBy() {
		return initiatedBy;
	}

    /**
	 * @param initiatedBy The initiatedBy to set.
	 */
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}

    /**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return "";
	}

    /**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = "";
	}

    /**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}

    /**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

    public String getIsoStandard() {
        return isoStandard;
    }


    public void setIsoStandard(String isoStandardId) {
        this.isoStandard = isoStandardId;
    }
}
