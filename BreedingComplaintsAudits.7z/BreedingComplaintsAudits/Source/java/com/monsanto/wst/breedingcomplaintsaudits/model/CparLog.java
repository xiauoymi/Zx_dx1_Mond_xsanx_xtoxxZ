/*
 * Created on Jul 14, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.io.Serializable;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparLog implements Serializable {
	
	private String cparFlag;
	private String[] yearOfIssue;
	private String responsibleLocation;
	
	
	
	/**
	 * @return Returns the cparFlag.
	 */
	public String getCparFlag() {
		return cparFlag;
	}
	/**
	 * @param cparFlag The cparFlag to set.
	 */
	public void setCparFlag(String cparFlag) {
		this.cparFlag = cparFlag;
	}
	
	/**
	 * @return Returns the responsibleLocation.
	 */
	public String getResponsibleLocation() {
		return responsibleLocation;
	}
	/**
	 * @param responsibleLocation The responsibleLocation to set.
	 */
	public void setResponsibleLocation(String responsibleLocation) {
		this.responsibleLocation = responsibleLocation;
	}
	/**
	 * @return Returns the yearOfIssue.
	 */
	public String[] getYearOfIssue() {
		return yearOfIssue;
	}
	/**
	 * @param yearOfIssue The yearOfIssue to set.
	 */
	public void setYearOfIssue(String[] yearOfIssue) {
		this.yearOfIssue = yearOfIssue;
	}
}
