/*
 * Created on Apr 15, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import com.monsanto.wst.breedingcomplaintsaudits.util.ComparisonUtil;

import java.io.Serializable;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FindingObject implements Serializable, Cloneable {
	
	private String findingID;
	
	private String findingDesc;
	
	private String shortFindingDesc;
	
	private String cparID;
	
	private String controlNumber; //**Actually the cpar-id
	
	private String findingType;
	
	private String rowUserID;
	
	private String car_flag; 

	/**
	 * @return Returns the findingType.
	 */
	public String getFindingType() {
		return findingType;
	}
	/**
	 * @param findingType The findingType to set.
	 */
	public void setFindingType(String findingType) {
		this.findingType = findingType;
	}
	/**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}
	/**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}
	/**
	 * @return Returns the cparID.
	 */
	public String getCparID() {
		return cparID;
	}
	/**
	 * @param cparID The cparID to set.
	 */
	public void setCparID(String cparID) {
		this.cparID = cparID;
	}
	/**
	 * @return Returns the car_flag.
	 */
	public String getCar_flag() {
		return car_flag;
	}
	/**
	 * @param car_flag The car_flag to set.
	 */
	public void setCar_flag(String car_flag) {
		this.car_flag = car_flag;
	}
	/**
	 * @return Returns the rowUserID.
	 */
	public String getRowUserID() {
		return rowUserID;
	}
	/**
	 * @param rowUserID The rowUserID to set.
	 */
	public void setRowUserID(String rowUserID) {
		this.rowUserID = rowUserID;
	}
	/**
	 * @param shortFindingDesc The shortFindingDesc to set.
	 */
	public void setShortFindingDesc(String shortFindingDesc) {
		this.shortFindingDesc = shortFindingDesc;
	}
	/**
	 * @return Returns the shortFindingDesc.
	 */
	public String getShortFindingDesc() {
		
		if(findingDesc.length() > 70){
			
			shortFindingDesc = findingDesc.substring(0, 70) + "...";
			
			return shortFindingDesc;
		}
		else{
			return findingDesc;
		}
		
		
	}
	/**
	 * @param shortFindingDesc The shortFindingDesc to set.
	 */
//	public void setShortFindingDesc(String shortFindingDesc) {
//		this.shortFindingDesc = shortFindingDesc;
//	}
	
	/**
	 * @return Returns the findingDesc.
	 */
	public String getFindingDesc() {
		return findingDesc;
	}
	/**
	 * @param findingDesc The findingDesc to set.
	 */
	public void setFindingDesc(String findingDesc) {
		this.findingDesc = findingDesc;
	}
	/**
	 * @return Returns the findingID.
	 */
	public String getFindingID() {
		return findingID;
	}
	/**
	 * @param findingID The findingID to set.
	 */
	public void setFindingID(String findingID) {
		this.findingID = findingID;
	}

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    FindingObject findingObject = (FindingObject) o;
    if (ComparisonUtil.unequal(car_flag, findingObject.car_flag)) return false;
    if (ComparisonUtil.unequal(controlNumber, findingObject.controlNumber)) return false;
    if (ComparisonUtil.unequal(cparID, findingObject.cparID)) return false;
    if (ComparisonUtil.unequal(findingDesc, findingObject.findingDesc)) return false;
    if (ComparisonUtil.unequal(findingID, findingObject.findingID)) return false;
    if (ComparisonUtil.unequal(findingType, findingObject.findingType)) return false;
    if (ComparisonUtil.unequal(rowUserID, findingObject.rowUserID)) return false;
    if (ComparisonUtil.unequal(shortFindingDesc, findingObject.shortFindingDesc)) return false;
    return true;
  }

  public Object clone() {
    try {
      return super.clone();
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException("FatalError: FindingObject needs to implement Cloneable interface.");
    }
  }
}