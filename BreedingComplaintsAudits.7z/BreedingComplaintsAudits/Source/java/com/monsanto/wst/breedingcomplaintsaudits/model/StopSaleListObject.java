/*
 * Created on May 17, 2005
 *
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.io.Serializable;

/**
 * @author rdesai2
 * 
 */
public class StopSaleListObject implements Serializable{
		
	private String stopSaleID;
	
	//**Grid Fields...
	private String controlNumber;
	private String status;
	private String responsibleLocation;
	private String region;
	private String crop;
	private String dealer;
	
	//**Other Filter Fields...
	private String fillingLocation;	
	private String shippingLocation;
	private String salesYear;
	private String initiatedBy;
	private String initiatedByEmail;
	

	//**Accessor and Mutators...
	
	/**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}
	/**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}
	/**
	 * @return Returns the crop.
	 */
	public String getCrop() {
		return crop;
	}
	/**
	 * @param crop The crop to set.
	 */
	public void setCrop(String crop) {
		this.crop = crop;
	}
	/**
	 * @return Returns the dealer.
	 */
	public String getDealer() {
		return dealer;
	}
	/**
	 * @param dealer The dealer to set.
	 */
	public void setDealer(String dealer) {
		this.dealer = dealer;
	}
	
	/**
	 * @return Returns the fillingLocation.
	 */
	public String getFillingLocation() {
		return fillingLocation;
	}
	/**
	 * @param fillingLocation The fillingLocation to set.
	 */
	public void setFillingLocation(String fillingLocation) {
		this.fillingLocation = fillingLocation;
	}
	/**
	 * @return Returns the initiatedBy.
	 */
	public String getInitiatedBy() {
		return initiatedBy;
	}
	/**
	 * @param initiatedBy The initiatedBy to set.
	 */
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the responsibleLocation.
	 */
	public String getResponsibleLocation() {
		return responsibleLocation;
	}
	/**
	 * @param responsibleLocation The responsibleLocation to set.
	 */
	public void setResponsibleLocation(String responsibleLocation) {
		this.responsibleLocation = responsibleLocation;
	}
	/**
	 * @return Returns the salesYear.
	 */
	public String getSalesYear() {
		return salesYear;
	}
	/**
	 * @param salesYear The salesYear to set.
	 */
	public void setSalesYear(String salesYear) {
		this.salesYear = salesYear;
	}
	/**
	 * @return Returns the shippingLocation.
	 */
	public String getShippingLocation() {
		return shippingLocation;
	}
	/**
	 * @param shippingLocation The shippingLocation to set.
	 */
	public void setShippingLocation(String shippingLocation) {
		this.shippingLocation = shippingLocation;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the stopSaleID.
	 */
	public String getStopSaleID() {
		return stopSaleID;
	}
	/**
	 * @param stopSaleID The stopSaleID to set.
	 */
	public void setStopSaleID(String stopSaleID) {
		this.stopSaleID = stopSaleID;
	}
	/**
	 * @return Returns the initiatedByEmail.
	 */
	public String getInitiatedByEmail() {
		return initiatedByEmail;
	}
	/**
	 * @param initiatedByEmail The initiatedByEmail to set.
	 */
	public void setInitiatedByEmail(String initiatedByEmail) {
		this.initiatedByEmail = initiatedByEmail;
	}
}
