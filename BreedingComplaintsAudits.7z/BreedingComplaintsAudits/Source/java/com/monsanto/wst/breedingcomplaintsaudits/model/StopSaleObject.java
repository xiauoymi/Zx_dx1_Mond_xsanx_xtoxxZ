/*
 * Created on May 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.io.Serializable;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StopSaleObject implements Serializable {
	
	//**Main Table
	private String entryDate;
	private String createdBy;
	private String status;
	private String region;
	
	//**Main Table
	private String stopSaleID;
	private String controlNumber;
	private String fillingLocation;
	private String initiatedBy;
	private String initiatedByEmail;	//**hidden...
	private String reportDate;
	private String salesYear;
	
	//**Main Table
	private String responsibleLocation;
	private String fieldCommunicator;
	private String fieldCommunicatorEmail;	//**hidden...
	private String stateID;
	
	//**Main Table
	private String shippingLocation;
	private String dealer;
	private String dealerPhone;
	
	//**Main Table
	private String stateReportNumber;
	private String stateValue;
	private String stateContact;
	private String statePhone;
	private String stateRetest;
	private String monsantoValue;
	
	//**Main Table
	private String investigator;
	private String investigatorEmail;	//**hidden
	private String cropID;	//**TABLE: CROP_REF
	private String labelValue;
	private String qualityIssue;
	private String quantityAffected;
	private String qualityUomID;	//**TABLE: QTY_UOM_REF
	private String seedSizeID;	//**TABLE: SEED_SIZE_REF
	
	//**TABLE: STOP_SALE_VARIETY/ VARIETY_REF
	private String variety_one;
	private String variety_two;
	private String variety_three;
	private String variety_four;
	
	//**TABLE: STOP_SALE_BATCH
	private String batch_one;
	private String batch_two;
	private String batch_three;
	private String batch_four;
	
	private String foundBatch1;
	private String foundBatch2;
	private String foundBatch3;
	private String foundBatch4;
	
	//**Main Table
	private String investigationFindings;
	private String rootCause;
	private String containmentAction;
	private String longTermCorrectiveAction;
	
	//**TABLE: STOP_SALE_REASON/ _REF
	private boolean seedCount;
	private boolean germination;
	private boolean purity;
	private boolean tagDate;
	private boolean otherReason;
	
	//**TABLE: STOP_SALE_ACTION/ _REF
	private boolean reLabel;
	private boolean dump;
	private boolean recount;
	private boolean restrict;
	private boolean otherActionFlag;
	
	//**Main Table
	private String actionComments;
	
	
	//**Car Fields...
	private String carID;
	
	private String carNumber;
	
	
	
	
	
	/**
	 * @return Returns the foundBatch1.
	 */
	public String getFoundBatch1() {
		return foundBatch1;
	}
	/**
	 * @param foundBatch1 The foundBatch1 to set.
	 */
	public void setFoundBatch1(String foundBatch1) {
		this.foundBatch1 = foundBatch1;
	}
	/**
	 * @return Returns the foundBatch2.
	 */
	public String getFoundBatch2() {
		return foundBatch2;
	}
	/**
	 * @param foundBatch2 The foundBatch2 to set.
	 */
	public void setFoundBatch2(String foundBatch2) {
		this.foundBatch2 = foundBatch2;
	}
	/**
	 * @return Returns the foundBatch3.
	 */
	public String getFoundBatch3() {
		return foundBatch3;
	}
	/**
	 * @param foundBatch3 The foundBatch3 to set.
	 */
	public void setFoundBatch3(String foundBatch3) {
		this.foundBatch3 = foundBatch3;
	}
	/**
	 * @return Returns the foundBatch4.
	 */
	public String getFoundBatch4() {
		return foundBatch4;
	}
	/**
	 * @param foundBatch4 The foundBatch4 to set.
	 */
	public void setFoundBatch4(String foundBatch4) {
		this.foundBatch4 = foundBatch4;
	}
	/**
	 * @return Returns the carID.
	 */
	public String getCarID() {
		return carID;
	}
	/**
	 * @param carID The carID to set.
	 */
	public void setCarID(String carID) {
		this.carID = carID;
	}
	/**
	 * @return Returns the carNumber.
	 */
	public String getCarNumber() {
		return carNumber;
	}
	/**
	 * @param carNumber The carNumber to set.
	 */
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	/**
	 * @return Returns the stopSaleID.
	 */
	public String getStopSaleID() {
		return stopSaleID;
	}
	/**
	 * @param stopSaleID The stopSaleID to set.
	 */
	public void setStopSaleID(String stopSaleID) {
		this.stopSaleID = stopSaleID;
	}
	/**
	 * @return Returns the fieldCommunicatorEmail.
	 */
	public String getFieldCommunicatorEmail() {
		return fieldCommunicatorEmail;
	}
	/**
	 * @param fieldCommunicatorEmail The fieldCommunicatorEmail to set.
	 */
	public void setFieldCommunicatorEmail(String fieldCommunicatorEmail) {
		this.fieldCommunicatorEmail = fieldCommunicatorEmail;
	}
	/**
	 * @return Returns the initiatedByEmail.
	 */
	public String getInitiatedByEmail() {
		return initiatedByEmail;
	}
	/**
	 * @param initiatedByEmail The initiatedByEmail to set.
	 */
	public void setInitiatedByEmail(String initiatedByEmail) {
		this.initiatedByEmail = initiatedByEmail;
	}
	/**
	 * @return Returns the investigatorEmail.
	 */
	public String getInvestigatorEmail() {
		return investigatorEmail;
	}
	/**
	 * @param investigatorEmail The investigatorEmail to set.
	 */
	public void setInvestigatorEmail(String investigatorEmail) {
		this.investigatorEmail = investigatorEmail;
	}
	/**
	 * @return Returns the stateID.
	 */
	public String getStateID() {
		return stateID;
	}
	/**
	 * @param stateID The stateID to set.
	 */
	public void setStateID(String stateID) {
		this.stateID = stateID;
	}
	/**
	 * @return Returns the actionComments.
	 */
	public String getActionComments() {
		return actionComments;
	}
	/**
	 * @param actionComments The actionComments to set.
	 */
	public void setActionComments(String actionComments) {
		this.actionComments = actionComments;
	}
	
	/**
	 * @return Returns the batch_four.
	 */
	public String getBatch_four() {
		return batch_four;
	}
	/**
	 * @param batch_four The batch_four to set.
	 */
	public void setBatch_four(String batch_four) {
		this.batch_four = batch_four;
	}
	/**
	 * @return Returns the batch_one.
	 */
	public String getBatch_one() {
		return batch_one;
	}
	/**
	 * @param batch_one The batch_one to set.
	 */
	public void setBatch_one(String batch_one) {
		this.batch_one = batch_one;
	}
	/**
	 * @return Returns the batch_three.
	 */
	public String getBatch_three() {
		return batch_three;
	}
	/**
	 * @param batch_three The batch_three to set.
	 */
	public void setBatch_three(String batch_three) {
		this.batch_three = batch_three;
	}
	/**
	 * @return Returns the batch_two.
	 */
	public String getBatch_two() {
		return batch_two;
	}
	/**
	 * @param batch_two The batch_two to set.
	 */
	public void setBatch_two(String batch_two) {
		this.batch_two = batch_two;
	}
	/**
	 * @return Returns the variety_four.
	 */
	public String getVariety_four() {
		return variety_four;
	}
	/**
	 * @param variety_four The variety_four to set.
	 */
	public void setVariety_four(String variety_four) {
		this.variety_four = variety_four;
	}
	/**
	 * @return Returns the variety_one.
	 */
	public String getVariety_one() {
		return variety_one;
	}
	/**
	 * @param variety_one The variety_one to set.
	 */
	public void setVariety_one(String variety_one) {
		this.variety_one = variety_one;
	}
	/**
	 * @return Returns the variety_three.
	 */
	public String getVariety_three() {
		return variety_three;
	}
	/**
	 * @param variety_three The variety_three to set.
	 */
	public void setVariety_three(String variety_three) {
		this.variety_three = variety_three;
	}
	/**
	 * @return Returns the variety_two.
	 */
	public String getVariety_two() {
		return variety_two;
	}
	/**
	 * @param variety_two The variety_two to set.
	 */
	public void setVariety_two(String variety_two) {
		this.variety_two = variety_two;
	}
	/**
	 * @return Returns the containmentAction.
	 */
	public String getContainmentAction() {
		return containmentAction;
	}
	/**
	 * @param containmentAction The containmentAction to set.
	 */
	public void setContainmentAction(String containmentAction) {
		this.containmentAction = containmentAction;
	}
	/**
	 * @return Returns the controlNumber.
	 */
	public String getControlNumber() {
		return controlNumber;
	}
	/**
	 * @param controlNumber The controlNumber to set.
	 */
	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}
	/**
	 * @return Returns the createdBy.
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy The createdBy to set.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return Returns the cropID.
	 */
	public String getCropID() {
		return cropID;
	}
	/**
	 * @param cropID The cropID to set.
	 */
	public void setCropID(String cropID) {
		this.cropID = cropID;
	}
	/**
	 * @return Returns the dealer.
	 */
	public String getDealer() {
		return dealer;
	}
	/**
	 * @param dealer The dealer to set.
	 */
	public void setDealer(String dealer) {
		this.dealer = dealer;
	}
	/**
	 * @return Returns the dealerPhone.
	 */
	public String getDealerPhone() {
		return dealerPhone;
	}
	/**
	 * @param dealerPhone The dealerPhone to set.
	 */
	public void setDealerPhone(String dealerPhone) {
		this.dealerPhone = dealerPhone;
	}
	/**
	 * @return Returns the dump.
	 */
	public boolean isDump() {
		return dump;
	}
	/**
	 * @param dump The dump to set.
	 */
	public void setDump(boolean dump) {
		this.dump = dump;
	}
	/**
	 * @return Returns the entryDate.
	 */
	public String getEntryDate() {
		return entryDate;
	}
	/**
	 * @param entryDate The entryDate to set.
	 */
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	/**
	 * @return Returns the fieldCommunicator.
	 */
	public String getFieldCommunicator() {
		return fieldCommunicator;
	}
	/**
	 * @param fieldCommunicator The fieldCommunicator to set.
	 */
	public void setFieldCommunicator(String fieldCommunicator) {
		this.fieldCommunicator = fieldCommunicator;
	}
	/**
	 * @return Returns the fillingLocation.
	 */
	public String getFillingLocation() {
		return fillingLocation;
	}
	/**
	 * @param fillingLocation The fillingLocation to set.
	 */
	public void setFillingLocation(String fillingLocation) {
		this.fillingLocation = fillingLocation;
	}
	/**
	 * @return Returns the germination.
	 */
	public boolean isGermination() {
		return germination;
	}
	/**
	 * @param germination The germination to set.
	 */
	public void setGermination(boolean germination) {
		this.germination = germination;
	}
	/**
	 * @return Returns the initiatedBy.
	 */
	public String getInitiatedBy() {
		return initiatedBy;
	}
	/**
	 * @param initiatedBy The initiatedBy to set.
	 */
	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}
	/**
	 * @return Returns the investigationFindings.
	 */
	public String getInvestigationFindings() {
		return investigationFindings;
	}
	/**
	 * @param investigationFindings The investigationFindings to set.
	 */
	public void setInvestigationFindings(String investigationFindings) {
		this.investigationFindings = investigationFindings;
	}
	/**
	 * @return Returns the investigator.
	 */
	public String getInvestigator() {
		return investigator;
	}
	/**
	 * @param investigator The investigator to set.
	 */
	public void setInvestigator(String investigator) {
		this.investigator = investigator;
	}
	/**
	 * @return Returns the labelValue.
	 */
	public String getLabelValue() {
		return labelValue;
	}
	/**
	 * @param labelValue The labelValue to set.
	 */
	public void setLabelValue(String labelValue) {
		this.labelValue = labelValue;
	}
	/**
	 * @return Returns the longTermCorrectiveAction.
	 */
	public String getLongTermCorrectiveAction() {
		return longTermCorrectiveAction;
	}
	/**
	 * @param longTermCorrectiveAction The longTermCorrectiveAction to set.
	 */
	public void setLongTermCorrectiveAction(String longTermCorrectiveAction) {
		this.longTermCorrectiveAction = longTermCorrectiveAction;
	}
	/**
	 * @return Returns the monsantoValue.
	 */
	public String getMonsantoValue() {
		return monsantoValue;
	}
	/**
	 * @param monsantoValue The monsantoValue to set.
	 */
	public void setMonsantoValue(String monsantoValue) {
		this.monsantoValue = monsantoValue;
	}
	/**
	 * @return Returns the otherActionFlag.
	 */
	public boolean isOtherActionFlag() {
		return otherActionFlag;
	}
	/**
	 * @param otherActionFlag The otherActionFlag to set.
	 */
	public void setOtherActionFlag(boolean otherActionFlag) {
		this.otherActionFlag = otherActionFlag;
	}
	/**
	 * @return Returns the otherReason.
	 */
	public boolean isOtherReason() {
		return otherReason;
	}
	/**
	 * @param otherReason The otherReason to set.
	 */
	public void setOtherReason(boolean otherReason) {
		this.otherReason = otherReason;
	}
	/**
	 * @return Returns the purity.
	 */
	public boolean isPurity() {
		return purity;
	}
	/**
	 * @param purity The purity to set.
	 */
	public void setPurity(boolean purity) {
		this.purity = purity;
	}
	
	/**
	 * @return Returns the quantityAffected.
	 */
	public String getQuantityAffected() {
		return quantityAffected;
	}
	/**
	 * @param quantityAffected The quantityAffected to set.
	 */
	public void setQuantityAffected(String quantityAffected) {
		this.quantityAffected = quantityAffected;
	}
	/**
	 * @return Returns the qualityIssue.
	 */
	public String getQualityIssue() {
		return qualityIssue;
	}
	/**
	 * @param qualityIssue The qualityIssue to set.
	 */
	public void setQualityIssue(String qualityIssue) {
		this.qualityIssue = qualityIssue;
	}
	/**
	 * @return Returns the qualityUomID.
	 */
	public String getQualityUomID() {
		return qualityUomID;
	}
	/**
	 * @param qualityUomID The qualityUomID to set.
	 */
	public void setQualityUomID(String qualityUomID) {
		this.qualityUomID = qualityUomID;
	}
	/**
	 * @return Returns the recount.
	 */
	public boolean isRecount() {
		return recount;
	}
	/**
	 * @param recount The recount to set.
	 */
	public void setRecount(boolean recount) {
		this.recount = recount;
	}
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return Returns the reLabel.
	 */
	public boolean isReLabel() {
		return reLabel;
	}
	/**
	 * @param reLabel The reLabel to set.
	 */
	public void setReLabel(boolean reLabel) {
		this.reLabel = reLabel;
	}
	/**
	 * @return Returns the reportDate.
	 */
	public String getReportDate() {
		return reportDate;
	}
	/**
	 * @param reportDate The reportDate to set.
	 */
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	/**
	 * @return Returns the responsibleLocation.
	 */
	public String getResponsibleLocation() {
		return responsibleLocation;
	}
	/**
	 * @param responsibleLocation The responsibleLocation to set.
	 */
	public void setResponsibleLocation(String responsibleLocation) {
		this.responsibleLocation = responsibleLocation;
	}
	/**
	 * @return Returns the restrict.
	 */
	public boolean isRestrict() {
		return restrict;
	}
	/**
	 * @param restrict The restrict to set.
	 */
	public void setRestrict(boolean restrict) {
		this.restrict = restrict;
	}
	/**
	 * @return Returns the rootCause.
	 */
	public String getRootCause() {
		return rootCause;
	}
	/**
	 * @param rootCause The rootCause to set.
	 */
	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}
	/**
	 * @return Returns the salesYear.
	 */
	public String getSalesYear() {
		return salesYear;
	}
	/**
	 * @param salesYear The salesYear to set.
	 */
	public void setSalesYear(String salesYear) {
		this.salesYear = salesYear;
	}
	/**
	 * @return Returns the seedCount.
	 */
	public boolean isSeedCount() {
		return seedCount;
	}
	/**
	 * @param seedCount The seedCount to set.
	 */
	public void setSeedCount(boolean seedCount) {
		this.seedCount = seedCount;
	}
	/**
	 * @return Returns the seedSizeID.
	 */
	public String getSeedSizeID() {
		return seedSizeID;
	}
	/**
	 * @param seedSizeID The seedSizeID to set.
	 */
	public void setSeedSizeID(String seedSizeID) {
		this.seedSizeID = seedSizeID;
	}
	/**
	 * @return Returns the shippingLocation.
	 */
	public String getShippingLocation() {
		return shippingLocation;
	}
	/**
	 * @param shippingLocation The shippingLocation to set.
	 */
	public void setShippingLocation(String shippingLocation) {
		this.shippingLocation = shippingLocation;
	}
	/**
	 * @return Returns the stateContact.
	 */
	public String getStateContact() {
		return stateContact;
	}
	/**
	 * @param stateContact The stateContact to set.
	 */
	public void setStateContact(String stateContact) {
		this.stateContact = stateContact;
	}
	/**
	 * @return Returns the statePhone.
	 */
	public String getStatePhone() {
		return statePhone;
	}
	/**
	 * @param statePhone The statePhone to set.
	 */
	public void setStatePhone(String statePhone) {
		this.statePhone = statePhone;
	}
	/**
	 * @return Returns the stateReportNumber.
	 */
	public String getStateReportNumber() {
		return stateReportNumber;
	}
	/**
	 * @param stateReportNumber The stateReportNumber to set.
	 */
	public void setStateReportNumber(String stateReportNumber) {
		this.stateReportNumber = stateReportNumber;
	}
	/**
	 * @return Returns the stateRetest.
	 */
	public String getStateRetest() {
		return stateRetest;
	}
	/**
	 * @param stateRetest The stateRetest to set.
	 */
	public void setStateRetest(String stateRetest) {
		this.stateRetest = stateRetest;
	}
	/**
	 * @return Returns the stateValue.
	 */
	public String getStateValue() {
		return stateValue;
	}
	/**
	 * @param stateValue The stateValue to set.
	 */
	public void setStateValue(String stateValue) {
		this.stateValue = stateValue;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the tagDate.
	 */
	public boolean isTagDate() {
		return tagDate;
	}
	/**
	 * @param tagDate The tagDate to set.
	 */
	public void setTagDate(boolean tagDate) {
		this.tagDate = tagDate;
	}
	
}
