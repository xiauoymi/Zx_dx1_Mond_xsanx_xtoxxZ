/*
 * Created on Mar 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class User {
	private String user_id;
	private String full_name;
	private String email;
	private Map roleMap;
	
	
	public User() {
		super();
		this.roleMap = new TreeMap();
	}

	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return Returns the roleMap.
	 */
	public Map getRoleMap() {
		return roleMap;
	}
	/**
	 * @param roleMap The roleMap to set.
	 */
	public void setRoleMap(Map roleMap) {
		this.roleMap = roleMap;
	}

	/**
	 * @param roleMap The roleMap to set.
	 */
	public boolean isRole(String permissionId) {
		return this.roleMap.containsKey(permissionId);
	}	
	
	/**
	 * @return Returns the user_id.
	 */
	public String getUser_id() {
		return user_id;
	}
	
	/**
	 * @param user_id The user_id to set.
	 */
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	/**
	 * @return Returns the full_name.
	 */
	public String getFull_name() {
		return full_name;
	}
	/**
	 * @param full_name The full_name to set.
	 */
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
}
