/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.model.test;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;
import junit.framework.TestCase;

import java.util.HashMap;

/**
 * Filename:    $RCSfile: AuditObject_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-28 22:59:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class AuditObject_UT extends TestCase {

  public void testEquals_ReturnsTrue_IfObjectsAreEqual() throws Exception {
    AuditObject audit1 = new AuditObject();
    audit1.setAuditID("557");
    audit1.setAuditorEmail("test@monsanto.com");
    audit1.setFindingCarMap(getFindingMap1());

    AuditObject audit2 = new AuditObject();
    audit2.setAuditID("557");
    audit2.setAuditorEmail("test@monsanto.com");
    audit2.setFindingCarMap(getFindingMap2());

    assertTrue(audit1.equals(audit2));
  }

  public void testEquals_ReturnsFalse_IfObjectsAreUnequal() throws Exception {
    AuditObject audit1 = new AuditObject();
    audit1.setAuditID("557");
    audit1.setAuditor("Monsanto.com");
    audit1.setFindingCarMap(getFindingMap1());

    AuditObject audit2 = new AuditObject();
    audit2.setAuditID("557");
    audit2.setAuditor("Monsanto.com");
    audit2.setFindingCarMap(getModifiedFindingMap2());

    assertFalse(audit1.equals(audit2));
  }

  public void testClone() throws Exception {
    AuditObject original = getOriginalAuditObject("Desc before cloning", true, "car1", "CarFinding before cloning", "par1", "ParFinding before cloning");
    AuditObject copy = (AuditObject)original.clone();
    modifyOriginalObject(original, "Desc after cloning", false, "car1", "CarFinding after cloning", "par1", "ParFinding after cloning");
    assertEquals("Desc before cloning", copy.getAuditOverview());
    assertEquals(true, copy.isHarvest());
    assertEquals("CarFinding before cloning", ((FindingObject)copy.getFindingCarMap().get("car1")).getFindingDesc());
    assertEquals("ParFinding before cloning", ((FindingObject)copy.getFindingParMap().get("par1")).getFindingDesc());
  }

  private void modifyOriginalObject(AuditObject original, String auditOverview, boolean harvest, String carFindingId, String carFindingDesc, String parFindingId, String parFindingDesc) {
    original.setAuditOverview(auditOverview);
    original.setHarvest(harvest);
    FindingObject findingObject = (FindingObject) original.getFindingCarMap().get(carFindingId);
    findingObject.setFindingDesc(carFindingDesc);
    findingObject = (FindingObject) original.getFindingParMap().get(parFindingId);
    findingObject.setFindingDesc(parFindingDesc);
  }

  private AuditObject getOriginalAuditObject(String auditOverview, boolean harvest, String findingID, String findingDesc, String parFindingID, String parFindingDesc) {
    AuditObject original = new AuditObject();
    original.setAuditOverview(auditOverview);
    original.setHarvest(harvest);
    HashMap findingCarMap = new HashMap();
    findingCarMap.put(findingID, getFindingObject(findingID, null, findingDesc));
    original.setFindingCarMap(findingCarMap);
    HashMap findingParMap = new HashMap();
    findingParMap.put(parFindingID, getFindingObject(parFindingID, null, parFindingDesc));
    original.setFindingParMap(findingParMap);
    return original;
  }

  private HashMap getFindingMap2() {
    HashMap findingCarMap2 = new HashMap();
    findingCarMap2.put("f1", getFindingObject("f1", "112", "test..."));
    findingCarMap2.put("f2", getFindingObject("f2", "1124", "test2..."));
    findingCarMap2.put("f3", getFindingObject("f3", "1132", "test3..."));
    return findingCarMap2;
  }

  private HashMap getModifiedFindingMap2() {
    HashMap findingCarMap2 = new HashMap();
    findingCarMap2.put("f1", getFindingObject("f1", "112", "test..."));
    findingCarMap2.put("f2", getFindingObject("f2", "1124", "Changed test!!!..."));
    findingCarMap2.put("f3", getFindingObject("f3", "1132", "test3..."));
    return findingCarMap2;
  }

  private HashMap getFindingMap1() {
    HashMap findingCarMap = new HashMap();
    findingCarMap.put("f1", getFindingObject("f1", "112", "test..."));
    findingCarMap.put("f3", getFindingObject("f3", "1132", "test3..."));
    findingCarMap.put("f2", getFindingObject("f2", "1124", "test2..."));
    return findingCarMap;
  }

  private FindingObject getFindingObject(String findingID, String cparID, String findingDesc) {
    FindingObject findingObj = new FindingObject();
    findingObj.setFindingID(findingID);
    findingObj.setCparID(cparID);
    findingObj.setFindingDesc(findingDesc);
    return findingObj;
  }
}