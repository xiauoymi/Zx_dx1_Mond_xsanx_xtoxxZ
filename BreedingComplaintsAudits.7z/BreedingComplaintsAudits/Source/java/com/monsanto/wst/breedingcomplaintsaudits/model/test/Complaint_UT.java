/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.model.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;

/**
 * Filename:    $RCSfile: Complaint_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 16:00:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class Complaint_UT extends TestCase {

  public void testEquals_ReturnsTrue_IfBothComplaintObjectsAreEqual() throws Exception {
    Complaint complaint1 = getComplaint("1234", "prob desc", "N");
    Complaint complaint2 = getComplaint("1234", "prob desc", "N");
    assertTrue(complaint1.equals(complaint2));
  }

  public void testEquals_ReturnsFalse_IfComplaintObjectsAreUnEqual() throws Exception {
    Complaint complaint1 = getComplaint("1234", "prob desc", "N");
    Complaint complaint2 = getComplaint("1234", "new prob desc", "N");
    assertFalse(complaint1.equals(complaint2));
  }

  private Complaint getComplaint(String complaint_id, String problem_description, String affina_entry_flag) {
    Complaint complaint = new Complaint();
    complaint.setComplaint_id(complaint_id);
    complaint.setAffina_entry_flag(affina_entry_flag);
    complaint.setProblem_description(problem_description);
    return complaint;
  }
}