/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.model.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;

/**
 * Filename:    $RCSfile: Cpar_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 16:00:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class Cpar_UT extends TestCase {

  public void testEquals_ReturnsTrue_IfBothSessionAndRequestCparObjectsAreEqual() throws Exception {
    Cpar sessionCpar = new Cpar();
    sessionCpar.setControl_number("sessionCpar#1");
    sessionCpar.setFiling_location("22");
    sessionCpar.setInvestigation_findings("Some Text");

    Cpar requestCpar = new Cpar();
    requestCpar.setControl_number("sessionCpar#1");
    requestCpar.setFiling_location("22");
    requestCpar.setInvestigation_findings("Some Text");
    
    assertTrue(sessionCpar.equals(requestCpar));
  }

  public void testEquals_ReturnsFalse_IfThereIsAnyChange() throws Exception {
    Cpar sessionCpar = new Cpar();
    sessionCpar.setControl_number("1234");
    sessionCpar.setFiling_location("22");
    sessionCpar.setInvestigation_findings("Some Text");

    Cpar requestCpar = new Cpar();
    requestCpar.setControl_number("1234");
    requestCpar.setFiling_location("22");
    requestCpar.setInvestigation_findings("Changed Text");

    assertFalse(sessionCpar.equals(requestCpar));
  }

  public void testEquals_ReturnsFalse_IfEitherFieldIsNull() throws Exception {
    Cpar sessionCpar = new Cpar();
    sessionCpar.setControl_number("1234");
    sessionCpar.setFiling_location("22");
    sessionCpar.setInvestigation_findings("Some Text");

    Cpar requestCpar = new Cpar();
    requestCpar.setControl_number("1234");
    requestCpar.setFiling_location("22");
    requestCpar.setInvestigation_findings(null);

    assertFalse(sessionCpar.equals(requestCpar));
  }
}