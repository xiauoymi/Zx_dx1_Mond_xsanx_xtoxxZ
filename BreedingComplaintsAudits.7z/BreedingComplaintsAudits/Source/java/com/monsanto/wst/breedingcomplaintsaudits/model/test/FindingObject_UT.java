/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.model.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;

/**
 * Filename:    $RCSfile: FindingObject_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-28 22:59:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class FindingObject_UT extends TestCase {

  public void testEquals_ReturnsTrue_IfObjectsAreEqual() throws Exception {
    FindingObject findingObj1 = getFindingObject("f1", "222", "test...");
    FindingObject findingObj2 = getFindingObject("f1", "222", "test...");
    assertTrue(findingObj1.equals(findingObj2));
  }

  public void testEquals_ReturnsFalse_IfObjectsAreUnequal() throws Exception {
    FindingObject findingObj1 = getFindingObject("f1", "222", "test...");
    FindingObject findingObj2 = getFindingObject("f1", "222", "new test...");
    assertFalse(findingObj1.equals(findingObj2));
  }

  public void testClone() throws Exception {
    FindingObject original = new FindingObject();
    original.setFindingDesc("desc before cloning");
    FindingObject copy = (FindingObject) original.clone();
    original.setFindingDesc("desc after cloning");
    assertEquals("desc before cloning", copy.getFindingDesc());
  }

  private FindingObject getFindingObject(String findingID, String cparID, String findingDesc) {
    FindingObject findingObj = new FindingObject();
    findingObj.setFindingID(findingID);
    findingObj.setCparID(cparID);
    findingObj.setFindingDesc(findingDesc);
    return findingObj;
  }
}