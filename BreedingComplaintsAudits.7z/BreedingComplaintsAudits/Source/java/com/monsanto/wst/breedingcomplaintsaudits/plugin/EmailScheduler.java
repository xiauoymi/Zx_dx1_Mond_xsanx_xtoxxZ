/*
 * Created on Mar 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.plugin;

import java.util.Calendar;
import java.util.Timer;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;

import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.service.EmailService;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailScheduler implements PlugIn {

	public void init(ActionServlet servlet,
            ModuleConfig config)
     throws ServletException {
		try {
            Timer timer= new Timer();
			Calendar cal  = Calendar.getInstance();
			int days=Integer.parseInt(McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.emailServ.intvl"));
			String[] multilplyFactorArr=McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.emailServ.intvlMultiplyFactor").split("x");
			// Multiply factor should default to 1.
			long multilplyFactor=1;
			for (int i = 0; i < multilplyFactorArr.length;i++)
				multilplyFactor=multilplyFactor*Integer.parseInt(multilplyFactorArr[i]);
			if (days < 1)
				days = 1;
			String[] time = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.emailServ.startTime").split(":");
			cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(time[0]));
			cal.set(Calendar.MINUTE,Integer.parseInt(time[1]));
			cal.set(Calendar.SECOND,Integer.parseInt(time[2]));
			
			EmailService emailService = new EmailService();
			
			timer.scheduleAtFixedRate(emailService, cal.getTime(), multilplyFactor*days);
			emailService = null;
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}
	
	public void destroy () {
		
	}
	
}
