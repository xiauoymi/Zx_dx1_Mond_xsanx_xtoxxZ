/*
 * Created on Feb 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.resources;

import java.util.ResourceBundle;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class McasProperties {
	private static ResourceBundle myResource=null;
	
	public static ResourceBundle getMcasProperties(){
		if (myResource == null){
			try {				
			 	myResource = ResourceBundle.getBundle("com.monsanto.wst.breedingcomplaintsaudits.resources.ApplicationResources");
				if (myResource == null){System.out.println("\n\n\n\n This is a test\n\n\n\n");}
			}
			catch (Exception e){
				e.printStackTrace();
			}
		}
		return myResource;
	}
	
}
