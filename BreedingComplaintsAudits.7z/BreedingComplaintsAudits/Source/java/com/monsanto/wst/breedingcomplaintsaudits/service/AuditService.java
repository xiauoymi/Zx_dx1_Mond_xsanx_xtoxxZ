/*
 * Created on Apr 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.LinkedHashMap;


import com.monsanto.wst.breedingcomplaintsaudits.model.AuditFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;


/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuditService {
		
	public String insertAudit(AuditObject auditObj) throws ServiceException;
	
	public boolean updateAudit(AuditObject auditObj) throws ServiceException;
		
	public FindingObject insertFinding(String auditNumber, FindingObject FindingObj) throws ServiceException;
	
	public boolean updateFinding(FindingObject FindingObj) throws ServiceException;
	
	public AuditObject getAudit(String findingID) throws ServiceException;
	
	public AuditObject getAuditFromList(String auditNo) throws ServiceException;
	
	public LinkedHashMap getAuditList(AuditListObject filterObj,String intPage,boolean getMax,String sortCriteria, String sortOrder) throws ServiceException;


	public String getAuditNumberFromFinding(int findingID) throws ServiceException;
	
	public HashMap getAuditReport(AuditFilter auditFilter) throws ServiceException;
}
