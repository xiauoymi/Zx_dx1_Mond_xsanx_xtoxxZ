/*
 * Created on Apr 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.LinkedHashMap;


import org.apache.log4j.Category;

import com.monsanto.wst.breedingcomplaintsaudits.actions.AuditAction;
import com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditServiceImpl implements AuditService{
	
	static Category logger = Category.getInstance(AuditAction.class.getName());
	
	public String insertAudit(AuditObject auditObj) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.insertAudit(auditObj);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
	public boolean updateAudit(AuditObject auditObj) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.updateAudit(auditObj);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
	public String getAuditNumberFromFinding(int findingID) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.getAuditNumberFromFinding(findingID);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
	public AuditObject getAudit(String findingID) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO (getAudit) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.getAudit(findingID);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
	public AuditObject getAuditFromList(String auditNo) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO (getAuditFromList) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.getAuditFromList(auditNo);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
	
	public FindingObject insertFinding(String auditNumber, FindingObject findingObj) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO (insertFinding) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.insertFinding(auditNumber, findingObj);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	public boolean updateFinding(FindingObject findingObj) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO (updateFinding) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.updateFinding(findingObj);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	
	public LinkedHashMap getAuditList(AuditListObject filterObj,String intPage,boolean getMax,String sortCriteria, String sortOrder) throws ServiceException{
		
		logger.info("AuditService: Locating Audit DAO (getAuditList) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.getAuditList(filterObj, intPage, getMax,sortCriteria, sortOrder);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	public HashMap getAuditReport(AuditFilter auditFilter) throws ServiceException{
		logger.info("AuditService: Locating Audit DAO (getAuditReport) service...");
		
		try{
			AuditDAO ad = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
			return ad.getAuditReport(auditFilter);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	
}
