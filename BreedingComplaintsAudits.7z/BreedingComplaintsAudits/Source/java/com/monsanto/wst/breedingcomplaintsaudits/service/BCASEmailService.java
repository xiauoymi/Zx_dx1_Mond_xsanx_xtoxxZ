package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;

import java.util.Map;
import java.util.Iterator;
import java.util.Date;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 23, 2007
 * Time: 7:29:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class BCASEmailService {
    private EmailCollector[] emailCollectors;


    public BCASEmailService(EmailCollector[] emailCollectors) {
        this.emailCollectors = emailCollectors;
    }

    public void doRun() {
        if (!mailSentOutToday()){// && "prod".equals(System.getProperty("lsi.function"))){
            try {
                LookUpService lookUpService = createLookUpService();
                Integer interval = (Integer) lookUpService.getEmailServiceParams().get("CAR_OVERDUE_INT");
                for (int i = 0; i < emailCollectors.length; i++) {
                    EmailCollector emailCollector = emailCollectors[i];
                    EmailSender emailSender = new EmailSender(emailCollector.getEmailType(), emailCollector.getEmails(lookUpService, interval.intValue()), lookUpService, interval, createEmailUtil());
                    emailSender.sendEmail();
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected LookUpService createLookUpService() throws ServiceException {
        LookUpService lookUpService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
        return lookUpService;
    }


    protected EmailUtil createEmailUtil() {
        EmailUtil emailUtil = new EmailUtil();
        return emailUtil;
    }

    private String getServerHostname() {
        String hostname = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostname = addr.getHostName();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return hostname;
    }


    /**
     * To avoid the duplicate emails sent each day...
     *
     * @return boolean
     */
    private boolean mailSentOutToday() {
        Date currentDate = getCurrentDate();

        //**Lookup for the mail_sent_date...
        Integer mailSentDbDate = new Integer(0);
        try {
            LookUpService lookUpSerivce = createLookUpService();
            Map result = lookUpSerivce.getEmailServiceParams();
            if (result.get("MAIL_SENT_DATE") == null) {
                lookUpSerivce.addMailSentDateParam(0);
                return false;
            } else {
                mailSentDbDate = (Integer) result.get("MAIL_SENT_DATE");
            }

        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        if (mailSentDbDate.intValue() == currentDate.getDate()) {
            return true;
        }

        return false;
    }

    protected Date getCurrentDate() {
        return new Date(System.currentTimeMillis());
    }
}
