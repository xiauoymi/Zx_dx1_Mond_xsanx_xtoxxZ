package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 31, 2007
 * Time: 2:28:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class CAREmailCollector implements EmailCollector {
    public Map getEmails(LookUpService lookUpService, int interval) throws ServiceException {
        return lookUpService.getCAREmails(interval);
    }

    public String getEmailType() {
        return "CAR";
    }
}
