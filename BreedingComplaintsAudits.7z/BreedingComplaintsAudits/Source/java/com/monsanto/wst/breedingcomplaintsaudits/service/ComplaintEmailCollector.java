package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 31, 2007
 * Time: 2:39:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ComplaintEmailCollector implements EmailCollector {
    public Map getEmails(LookUpService lookUpService, int interval) throws ServiceException {
        return lookUpService.getComplaintEmails(interval);
    }

    public String getEmailType() {
        return "Complaint";
    }
}
