/*
 * Created on Jan 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;

import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.ComplaintFilter;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface ComplaintService {
	public String getComplaintPK() throws ServiceException;
	public void insertComplaint(Complaint c) throws ServiceException;
	public void updateComplaint(Complaint c) throws ServiceException;
	public void deleteComplaint(Complaint c) throws ServiceException;
	public LinkedHashMap getComplaintsList(String controlNumber,String createDate,String initiatedBy,String salesYr,String status,String region,String claimNumber,String reportingLocation,String responsibleLocation,String crop, String batch, String state, String variety, String qualityIssue,String intPage,boolean getMax,String sortCriteria,String sortOrder) throws ServiceException;
	public Complaint getComplaint(String complaint_id) throws ServiceException;
	public Map findBatches(String batch_number, String complaint_stopsale_id) throws ServiceException;
	
	public HashMap getComplaintReport(ComplaintFilter complaintFilter) throws ServiceException;
}
