/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.dao.ComplaintDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.ComplaintFilter;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintServiceImpl implements ComplaintService {
	
	public String getComplaintPK() throws ServiceException{
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			return cd.getComplaintPK();
        }
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public void insertComplaint(Complaint c) throws ServiceException{
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			cd.insertComplaint(c);
		}
		catch(DAOException e){
			throw new ServiceException(e);
		}
		catch(Exception e){
			throw new ServiceException(e);
		}		
	}
	public void updateComplaint(Complaint c) throws ServiceException{
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			cd.updateComplaint(c);
		}
		catch(DAOException e){
			throw new ServiceException(e);
		}
		catch(Exception e){
			throw new ServiceException(e);
		}		
	}
	public void deleteComplaint(Complaint c) throws ServiceException{
		
	}
	public LinkedHashMap getComplaintsList(String controlNumber,String createDate,String initiatedBy,String salesYr,String status,String region,String claimNumber,String reportingLocation,String responsibleLocation,String crop, String batch, String state, String variety, String qualityIssue, String intPage,boolean getMax, String sortCriteria, String sortOrder) throws ServiceException{
		LinkedHashMap complaintsList=null;
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			complaintsList = cd.getComplaintsList( controlNumber, createDate, initiatedBy,salesYr,status,region, claimNumber, reportingLocation,responsibleLocation,  crop, batch, state, variety, qualityIssue,intPage, getMax,sortCriteria,sortOrder);
		}
		catch (Exception e){
			System.out.println(e.getMessage());
		}		
		return complaintsList;
	}
	
	public Complaint getComplaint(String complaint_id) throws ServiceException{
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			return cd.getComplaint(complaint_id);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}

	public Map findBatches(String batch_number, String complaint_stopsale_id) throws ServiceException {
		Map batches = null;
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			return cd.findBatches(batch_number, complaint_stopsale_id);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
		
	}
	
	public HashMap getComplaintReport(ComplaintFilter complaintFilter) throws ServiceException {
		try{
			ComplaintDAO cd = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
			return cd.getComplaintReport(complaintFilter);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
		
	}
	
	
}
