/*
 * Created on Feb 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;

import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparLog;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface CparService {
	public String getCparPK() throws ServiceException;
	public void insertCpar(Cpar cpar) throws ServiceException;
	public void updateCpar(Cpar cpar) throws ServiceException;
	public void deleteCpar(Cpar cpar) throws ServiceException;
	public LinkedHashMap getCparsList(String controlNumber, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String carFlag, String filingLoc, String responsibleLoc, String isoStandard, String intPage, boolean getMax, String sortCriteria, String sortOrder) throws ServiceException;
	public Cpar getCpar(String Cpar_id) throws ServiceException;
	public boolean findControlNumber(String control_number) throws ServiceException;
	public String findCAR(String complaint_id) throws ServiceException;
	public String findControlNumberText(String complaint_id) throws ServiceException;	
	public HashMap getCparReport(CparFilter cparFilter) throws ServiceException;	
	public HashMap getCparLog(CparLog cparLog) throws ServiceException;
}
