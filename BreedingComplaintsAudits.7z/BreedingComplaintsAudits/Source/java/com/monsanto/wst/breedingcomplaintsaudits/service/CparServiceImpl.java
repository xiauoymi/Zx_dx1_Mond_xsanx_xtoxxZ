/*
 * Created on Feb 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;

import com.monsanto.wst.breedingcomplaintsaudits.dao.CparDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparLog;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparList;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparServiceImpl implements CparService {
	public String getCparPK() throws ServiceException{
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.getCparPK();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public void insertCpar(Cpar c) throws ServiceException{
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			cd.insertCpar(c);
		}
		catch(DAOException e){
			throw new ServiceException(e);
		}
		catch(Exception e){
			throw new ServiceException(e);
		}		
	}
	public void updateCpar(Cpar c) throws ServiceException{
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			cd.updateCpar(c);
		}
		catch(DAOException e){
			throw new ServiceException(e);
		}
		catch(Exception e){
			throw new ServiceException(e);
		}		
	}
	public void deleteCpar(Cpar c) throws ServiceException{
		
	}
	public LinkedHashMap getCparsList(String controlNumber, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String carFlag, String filingLoc, String responsibleLoc, String isoStandard, String intPage, boolean getMax, String criteria, String order) throws ServiceException{
		LinkedHashMap CparsList=null;
		try{
            System.out.println("Getting CPARS\n");
            CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			CparsList = cd.getCparsList(controlNumber, createDateFrom, createDateTo,initiatedBy,status,region, claimNumber, carFlag, filingLoc, responsibleLoc, isoStandard, intPage, getMax,criteria, order);
        }
		catch (Exception e){
			System.out.println(e.getMessage());
		}		
		return CparsList;
	}
	
	public Cpar getCpar(String Cpar_id) throws ServiceException{
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.getCpar(Cpar_id);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	public boolean findControlNumber(String control_number) throws ServiceException {
		Map batches = null;
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.findControlNumber(control_number);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
		
	}
	
	public String findCAR(String complaint_id) throws ServiceException {
		Map batches = null;
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.findCAR(complaint_id);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
		
	}
	
	public String findControlNumberText(String complaint_id) throws ServiceException {
		Map batches = null;
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.findControlNumberText(complaint_id);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
		
	}	
	
	public HashMap getCparReport(CparFilter cparFilter) throws ServiceException{
		
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.getCparReport(cparFilter);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	} 
	
	public HashMap getCparLog(CparLog cparLog) throws ServiceException{
		
		try{
			CparDAO cd = (CparDAO) DAOFactory.getDao(CparDAO.class);
			return cd.getCparLog(cparLog);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	} 
	
	
}
