package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;

import java.util.Map;
import java.util.Iterator;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 29, 2007
 * Time: 2:33:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmailSender {
    private String emailType;
    private Map result;
    private LookUpService lookUpService;
    private Integer overdueIntvl;
    private EmailUtil emailUtil;

    public EmailSender(String type, Map result, LookUpService lookupService, Integer interval, EmailUtil emailService) {
        this.emailType = type;
        this.result = result;
        this.lookUpService = lookupService;
        this.overdueIntvl = interval;
        this.emailUtil = emailService;
    }

    public void sendEmail() throws Exception {
        String urlLink = createApplicationURL();
        if (result != null) {
            String ADMIN_EMAIL = lookUpService.getEmail("ADMN")[0];
            Iterator iter = result.entrySet().iterator();
            while (iter.hasNext()) {
                sendSingleEmail(ADMIN_EMAIL, emailUtil, overdueIntvl, urlLink, (Map.Entry) iter.next(), emailType);
            }
        }

        lookUpService.setMailSentDateParam((new Date(System.currentTimeMillis())).getDate());
    }

    private void sendSingleEmail(String ADMIN_EMAIL, EmailUtil emailUtil, Integer overdueIntvl, String urlLink, Map.Entry entry, String emailType) throws Exception {
        String[] emails;
        emails = (String[]) entry.getValue();
        if (emails.length > 0 && !(emails[1].equals("")) && (ADMIN_EMAIL != null) && !(ADMIN_EMAIL.equals(""))) {
            emailUtil.setTo(emails[1]);
            if (emails.length > 2){
                    emailUtil.setCc(emails[2]);
            }
            else
                emailUtil.setCc(null);

            emailUtil.setFrom(ADMIN_EMAIL.trim());
            String control_number = emails[0];
            emailUtil.setSubject(emailType + " Status Overdue: " + emailType + " '" + control_number + "' - " + McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.AppName"));
            emailUtil.setBody(emailType + " '" + control_number + "' has not been approved within " + overdueIntvl + " day(s).  Click here to logon to the SBFAS system: " + urlLink + "\n\n\n\n\n" + McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.EmailFooter"));
            emailUtil.sendMail();
        }


    }

    private String createApplicationURL() {
        return "http://" + McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.emailServ.linkDomain");
    }
}

