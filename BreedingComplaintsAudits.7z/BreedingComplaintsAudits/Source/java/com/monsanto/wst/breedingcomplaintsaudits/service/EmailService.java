/*
 * Created on Mar 22, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import org.apache.log4j.Category;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimerTask;
import java.net.UnknownHostException;
import java.net.InetAddress;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailService extends TimerTask {

    static Category logger = Category.getInstance(EmailService.class.getName());

    public EmailService() {
    }

    // Email Logic goes here.
    public void run() {

        BCASEmailService bcasEmailService = new BCASEmailService(new EmailCollector[]{new CAREmailCollector(), new ComplaintEmailCollector()});
        bcasEmailService.doRun();
    }
}

