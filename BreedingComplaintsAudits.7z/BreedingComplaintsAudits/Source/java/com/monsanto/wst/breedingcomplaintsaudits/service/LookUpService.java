/*
 * Created on Jan 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.Map;


/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface LookUpService {
	public Map getStates() throws ServiceException;
	public Map getStatus(String type) throws ServiceException;
	public Map getLocations() throws ServiceException;
    public Map getQualityIssues() throws ServiceException;
	public Map getYear() throws ServiceException;
	public Map getCrops() throws ServiceException;
	public Map getSeedSize() throws ServiceException;
	public Map getUOM() throws ServiceException;
	public Map getVarities() throws ServiceException;
	public Map getBrands() throws ServiceException;
	public Map getRegions() throws ServiceException;
	public Map getResponsibleLocations() throws ServiceException;
	public Map getGenerator() throws ServiceException;
	public Map getEffectivenessEvaluator() throws ServiceException;
	public Map getFindingTypes() throws ServiceException;
	public Map getISOStandards() throws ServiceException;
	public String[] getEmail(String locationCode) throws ServiceException;
	public Map getCAREmails(int overdueIntvl) throws ServiceException;
	public Map getEmailServiceParams() throws ServiceException;
	public void setMailSentDateParam(int mailSentDate) throws ServiceException;
	public void addMailSentDateParam(int mailSentDate) throws ServiceException;
    public Map getComplaintEmails (int overdueIntvl) throws ServiceException;
}
