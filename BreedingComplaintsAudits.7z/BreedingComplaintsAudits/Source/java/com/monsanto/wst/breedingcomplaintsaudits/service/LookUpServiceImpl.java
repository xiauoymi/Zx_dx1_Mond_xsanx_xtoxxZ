/*
 * Created on Jan 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.dao.LookUpDAO;

import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LookUpServiceImpl implements LookUpService {
	
	
	public Map getStates() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getStates();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}			
	}
	
	
	public Map getStatus(String type) throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getStatus(type);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getLocations() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getLocations();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}
	public Map getResponsibleLocations() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getResponsibleLocations();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}

    public Map getQualityIssues() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getQualityIssues();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
	}

	public Map getYear() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getYear();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getCrops() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getCrops();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getSeedSize() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getSeedSize();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getUOM() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getUOM();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getVarities() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getVarities();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	
	public Map getBrands() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getBrands();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}	
	}

	public Map getRegions() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getRegions();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}	
	}

	public Map getGenerator() throws ServiceException{
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getGenerator();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public Map getEffectivenessEvaluator() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getEffectivenessEvaluator();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public Map getFindingTypes() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getFindingTypes();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public Map getISOStandards() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getISOStandards();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}

	public String[] getEmail(String locationCode) throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getEmail(locationCode);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}	

	
	public Map getCAREmails(int overdueIntvl) throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getCAREmails(overdueIntvl);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}	
	
	public Map getEmailServiceParams() throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getEmailServiceParams();
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public void setMailSentDateParam(int mailSentDate) throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			lookupdao.setMailSentDateParam(mailSentDate);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
	
	public void addMailSentDateParam(int mailSentDate) throws ServiceException {
		try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			lookupdao.addMailSentDateParam(mailSentDate);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}

    public Map getComplaintEmails(int overdueIntvl) throws ServiceException {
       try{
			LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
			return lookupdao.getComplaintEmails(overdueIntvl);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
    }
}
