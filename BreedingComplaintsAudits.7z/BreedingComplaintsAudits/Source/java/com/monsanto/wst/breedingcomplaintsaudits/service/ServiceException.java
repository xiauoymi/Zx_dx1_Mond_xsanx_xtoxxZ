/*
 * Created on Jan 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import org.apache.log4j.Category;

import com.monsanto.wst.breedingcomplaintsaudits.exception.McasExceptionHandler;


/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ServiceException extends Exception{
	
	static Category logger = Category.getInstance(McasExceptionHandler.class.getName());
	
	public ServiceException(){}
	
	public ServiceException(String errMsg){
		super(errMsg);
		logger.error("ServiceException: " + errMsg);
	}
	
	public ServiceException(Exception err){
		super(err);
		logger.error("ServiceException Error...");
	}

	public ServiceException(String msg, Exception err){
		super(msg + ": " + err.getMessage());		
		logger.error("ServiceException String Message..." + msg);		
		logger.error("ServiceException Error-Msg..." + err.getMessage());
		  
	}
	
	public String getMessage(){
		return super.getMessage();
	}
	
    public void printStackTrace() {
        this.printStackTrace();
    }
}
