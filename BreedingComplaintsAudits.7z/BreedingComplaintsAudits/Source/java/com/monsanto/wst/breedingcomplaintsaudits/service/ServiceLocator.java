/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class ServiceLocator
{
	private static Map serviceMap;

	private static Log logger = LogFactory.getLog(ServiceLocator.class);	
	
	//**Implementing caching...
	static {
		serviceMap = new HashMap();
		serviceMap.put(ComplaintService.class, ComplaintServiceImpl.class);	
		serviceMap.put(LookUpService.class, LookUpServiceImpl.class);
		serviceMap.put(CparService.class, CparServiceImpl.class);
		serviceMap.put(UserAccountService.class, UserAccountServiceImpl.class);
		serviceMap.put(ControlNumberService.class, ControlNumberServiceImpl.class);
		serviceMap.put(AuditService.class, AuditServiceImpl.class);
		serviceMap.put(StopSaleService.class, StopSaleServiceImpl.class);		
	}
	
	/**
	 * This method looks up and returns the implentation class for a given service class type. 
	 * @param type
	 * @return Object
	 * @throws ServiceException
	 */
	public static Object locateService(Class type) throws ServiceException {
        if (logger.isTraceEnabled())
            logger.trace("Entering - clazz=" + type);

        if (type == null) {
            throw new ServiceException("cannot retrieve Service implementation for null name");
        }

        Object service = null;
        Class clazz = (Class) serviceMap.get(type);
        
        if (clazz != null){
            try {
            	service = clazz.newInstance();
                if (logger.isDebugEnabled()) {
                    logger.debug("found Service implementation '" + service.getClass() + "' for name '" + type + "'");
                }
            } catch (Exception ie) {
                throw new ServiceException("could not instantiate Service for name '" + type + "': " + ie.getMessage());
            }
        }
        else{
            throw new ServiceException("could not find Service implementation class for name '" + type + "'");
        }
        if (logger.isTraceEnabled())
            logger.trace("Exiting");
        return service;
	}  
}
