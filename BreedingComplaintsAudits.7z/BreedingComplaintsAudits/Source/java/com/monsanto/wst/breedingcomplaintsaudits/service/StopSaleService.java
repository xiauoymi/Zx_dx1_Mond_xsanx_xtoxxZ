/*
 * Created on May 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleObject;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface StopSaleService {

	public String insertStopSale(StopSaleObject stopSale) throws ServiceException;
	
	public boolean updateStopSale(StopSaleObject stopSale) throws ServiceException;
	
	public StopSaleObject getStopSale(int stopSaleID) throws ServiceException;
	
	public String getStopSaleNumberFromID(int stopSaleID) throws ServiceException;
	
	public LinkedHashMap getStopSaleList(StopSaleListObject stopSale, String intPage,boolean getMax,String sortCriteria, String sortOrder) throws ServiceException;
	
	public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws ServiceException;
	
	public HashMap getStopSaleReport(StopSaleFilter stopSaleFilter) throws ServiceException;
}
