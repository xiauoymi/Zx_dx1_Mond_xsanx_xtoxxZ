/*
 * Created on May 9, 2005
 *
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Category;

import com.monsanto.wst.breedingcomplaintsaudits.actions.AuditAction;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAO;
import com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.StopSaleObject;

/**
 * @author rdesai2
 *
 */
public class StopSaleServiceImpl implements StopSaleService{
	
	static Category logger = Category.getInstance(AuditAction.class.getName());
	
	public String insertStopSale(StopSaleObject stopSale) throws ServiceException{
		
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.insertStopSale(stopSale);
		}
		catch(Exception ex){
			logger.error("Error locating insertStopSale DAO.");
		}
		
		return "";
	}
	
	public LinkedHashMap getStopSaleList(StopSaleListObject stopSale, String intPage,boolean getMax,String sortCriteria, String sortOrder) throws ServiceException{
		
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.getStopSaleList(stopSale, intPage, getMax,sortCriteria,sortOrder);
		}
		catch(Exception ex){
			logger.error("Error locating insertStopSale DAO.");
		}
		
		return new LinkedHashMap();
	}
	
	public boolean updateStopSale(StopSaleObject stopSale) throws ServiceException{
		
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.updateStopSale(stopSale);
		}
		catch(Exception ex){
			logger.error("Error locating insertStopSale DAO.");
		}
		
		return false;
	}
	
	public StopSaleObject getStopSale(int stopSaleID) throws ServiceException{
		
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.getStopSale(stopSaleID);
		}
		catch(Exception ex){
			logger.error("Error locating getStopSale DAO.");
		}
		
		return new StopSaleObject();
	}
	
	
	public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws ServiceException{
		
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.getStopSaleByNumber(stopSaleNumber);
		}
		catch(Exception ex){
			logger.error("Error locating getStopSaleByNo DAO.");
		}
		
		return new StopSaleObject();
	}
	
	public String getStopSaleNumberFromID(int stopSaleID) throws ServiceException{
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.getStopSaleNumberFromID(stopSaleID);
		}
		catch(Exception ex){
			logger.error("Error locating getStopSaleNo DAO.");
		}
		
		return "";	
	}
	
	public HashMap getStopSaleReport(StopSaleFilter stopSaleFilter) throws ServiceException{
		try{
			StopSaleDAOImpl sd = (StopSaleDAOImpl)DAOFactory.getDao(StopSaleDAO.class);
			return sd.getStopSaleReport(stopSaleFilter);
		}
		catch(Exception ex){
			logger.error("Error locating getStopSaleNo DAO.");
			return new HashMap();
		} 
	}	
}