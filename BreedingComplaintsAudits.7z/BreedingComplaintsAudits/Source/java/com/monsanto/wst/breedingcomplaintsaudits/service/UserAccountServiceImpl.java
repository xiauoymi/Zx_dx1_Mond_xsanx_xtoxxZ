/*
 * Created on Mar 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.service;

import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOException;
import com.monsanto.wst.breedingcomplaintsaudits.dao.DAOFactory;
import com.monsanto.wst.breedingcomplaintsaudits.dao.UserAccountDAO;
import com.monsanto.wst.breedingcomplaintsaudits.model.User;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserAccountServiceImpl implements UserAccountService {
	public User getUserInfo(User user) throws ServiceException{
		try{
			UserAccountDAO uad = (UserAccountDAO) DAOFactory.getDao(UserAccountDAO.class);
			return uad.getUserInfo(user);
		}
		catch(DAOException e){
			throw new ServiceException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new ServiceException(e.getMessage());
		}		
	}
}
