package com.monsanto.wst.breedingcomplaintsaudits.service.acceptancetest;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.service.BCASEmailService;
import com.monsanto.wst.breedingcomplaintsaudits.service.test.MockBCASEmailService;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.actions.test.BCASDatabaseTestCase;
import org.dbunit.database.QueryDataSet;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.DatabaseTestCase;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.ext.oracle.OracleConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.xml.sax.InputSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 23, 2007
 * Time: 7:29:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class BCASEmailService_AT extends DatabaseTestCase {
    private OracleConnection oracleConnection;

    protected IDatabaseConnection getConnection() throws Exception {
           Class driverClass =
                Class.forName("oracle.jdbc.driver.OracleDriver");
        //todo get parameters from property file
        Connection jdbcConnection =
                DriverManager.getConnection(
                        "jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "bcas", "bcas_123");
        oracleConnection = new OracleConnection(jdbcConnection, "bcas");
        return oracleConnection;
    }

    protected IDataSet getDataSet() throws Exception {
        InputSource in = new InputSource("com/monsanto/wst/breedingcomplaintsaudits/service/test/auditData.xml");
        return new FlatXmlDataSet(in);
    }

    protected void setUp() throws Exception {
       QueryDataSet partialDataSet = new QueryDataSet(getConnection());
        partialDataSet
                .addTable("CPAR",
                        "UPDATE CPAR SET SUPPRESS_OVERDUE=1 WHERE CPAR_ID<>1");
        super.setUp();
    }
     protected DatabaseOperation getTearDownOperation() throws Exception {
        return DatabaseOperation.REFRESH;
    }



    public void testEmailUtilIsCalledCorrectly() throws Exception{
        PreparedStatement stmt = getConnection().getConnection().prepareStatement("delete APP_PARAMETER where APP_PARAMETER_CODE='MAIL_SENT_DATE'");
        stmt.execute();
        MockBCASEmailService bcasEmail = new MockBCASEmailService ();
        bcasEmail.doRun();
        assertTrue(bcasEmail.mockEmailUtil.wasSendEmailCalled);
        stmt.execute();
    }

}

