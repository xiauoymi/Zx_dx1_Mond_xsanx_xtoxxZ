/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.service.mock;

import com.monsanto.wst.breedingcomplaintsaudits.service.AuditService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditFilter;

import java.util.LinkedHashMap;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockAuditService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-04-06 22:53:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockAuditService implements AuditService {

  public boolean updateAudit(AuditObject auditObj) throws ServiceException {
    return true;
  }

  public String insertAudit(AuditObject auditObj) throws ServiceException {
    return "A-111-564;TestAuditId";
  }

  public FindingObject insertFinding(String auditNumber, FindingObject FindingObj) throws ServiceException {
    return null;
  }

  public boolean updateFinding(FindingObject FindingObj) throws ServiceException {
    return false;
  }

  public AuditObject getAudit(String findingID) throws ServiceException {
    return null;
  }

  public AuditObject getAuditFromList(String auditNo) throws ServiceException {
    AuditObject audit = new AuditObject();
    audit.setAuditID("1234");
    audit.setAuditNumber("A-111-564");
    audit.setAuditOverview("default text");
    return audit;
  }

  public LinkedHashMap getAuditList(AuditListObject filterObj, String intPage, boolean getMax, String sortCriteria, String sortOrder) throws ServiceException {
    return null;
  }

  public String getAuditNumberFromFinding(int findingID) throws ServiceException {
    return null;
  }

  public HashMap getAuditReport(AuditFilter auditFilter) throws ServiceException {
    return null;
  }
}