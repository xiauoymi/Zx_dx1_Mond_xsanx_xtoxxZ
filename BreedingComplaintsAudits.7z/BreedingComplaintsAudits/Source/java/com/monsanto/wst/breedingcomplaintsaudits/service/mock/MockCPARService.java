/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.service.mock;

import com.monsanto.wst.breedingcomplaintsaudits.service.CparService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparLog;

import java.util.LinkedHashMap;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockCPARService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-11-19 21:20:51 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MockCPARService implements CparService {

  public void updateCpar(Cpar cpar) throws ServiceException {
    System.out.println("MockCPARService: Cpar updated...");
  }

  public String getCparPK() throws ServiceException {
    return null;
  }

  public void insertCpar(Cpar cpar) throws ServiceException {
  }

  public void deleteCpar(Cpar cpar) throws ServiceException {
  }

  public LinkedHashMap getCparsList(String controlNumber, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String carFlag, String filingLoc, String responsibleLoc, String isoStandard, String intPage, boolean getMax, String sortCriteria, String sortOrder) throws ServiceException {
    return null;
  }

  public Cpar getCpar(String Cpar_id) throws ServiceException {
    Cpar cpar = new Cpar();
    cpar.setCar_flag("Y");
    cpar.setCreated_by("testUser");
    cpar.setContainment_actions("testContainmentAction");
    return cpar;
  }

  public boolean findControlNumber(String control_number) throws ServiceException {
    return false;
  }

  public String findCAR(String complaint_id) throws ServiceException {
    return "";
  }

  public String findControlNumberText(String complaint_id) throws ServiceException {
    return "test-ctrl-no";
  }

  public HashMap getCparReport(CparFilter cparFilter) throws ServiceException {
    return null;
  }

  public HashMap getCparLog(CparLog cparLog) throws ServiceException {
    return null;
  }

}