/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.service.mock;

import com.monsanto.wst.breedingcomplaintsaudits.service.ComplaintService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;
import com.monsanto.wst.breedingcomplaintsaudits.model.Complaint;
import com.monsanto.wst.breedingcomplaintsaudits.model.ComplaintFilter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: MockComplaintService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 16:00:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockComplaintService implements ComplaintService {

  public void updateComplaint(Complaint c) throws ServiceException {
    System.out.println("[MockComplaintService]: 'Update complete...'");
  }

  public String getComplaintPK() throws ServiceException {
    return null;
  }

  public void insertComplaint(Complaint c) throws ServiceException {
  }

  public void deleteComplaint(Complaint c) throws ServiceException {
  }

  public LinkedHashMap getComplaintsList(String controlNumber, String createDate, String initiatedBy, String salesYr, String status, String region, String claimNumber, String reportingLocation, String responsibleLocation, String crop, String batch, String state, String variety, String qualityIssue, String intPage, boolean getMax, String sortCriteria, String sortOrder) throws ServiceException {
    return null;
  }

  public Complaint getComplaint(String complaint_id) throws ServiceException {
    Complaint complaint = new Complaint();
    complaint.setComplaint_id("1234");
    complaint.setProblem_description("some problem");
    return complaint;
  }

  public Map findBatches(String batch_number, String complaint_stopsale_id) throws ServiceException {
    return null;
  }

  public HashMap getComplaintReport(ComplaintFilter complaintFilter) throws ServiceException {
    return null;
  }
}