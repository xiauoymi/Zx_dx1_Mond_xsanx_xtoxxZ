package com.monsanto.wst.breedingcomplaintsaudits.service.mock;

import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;

import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 30, 2007
 * Time: 12:25:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockEmailLookupService implements LookUpService {
    Map carEmails = new HashMap();
    private Integer mailSentDate = null;
    private Map complaintEmails = new HashMap();

    public Map getStates() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getStatus(String type) throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getLocations() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getQualityIssues() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getYear() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getCrops() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getSeedSize() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getUOM() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getVarities() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getBrands() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getRegions() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getResponsibleLocations() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getGenerator() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getEffectivenessEvaluator() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getFindingTypes() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getISOStandards() throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getEmail(String locationCode) throws ServiceException {
        if ("ADMN".equals(locationCode))
            return new String[]{"a", "cc"};
        if ("location1".equals (locationCode))
            return new String[]{"abcd@blah.com","abcd_cc@blah.com"};
        if ("location2".equals(locationCode))
            return new String[]{"efgh@blah.com","efgh_cc@blah.com"};
        return null;
    }

    public Map getCAREmails(int overdueIntvl) throws ServiceException {
        return carEmails;
    }

    public void addCAREmail(Integer cparId, String controlNumber, String email, String ownerEmail, String ownerEmailFlag) {
        String[] entry = new String[]{controlNumber, email, ownerEmail, ownerEmailFlag};
        carEmails.put(cparId, entry);
    }

    public Map getEmailServiceParams() throws ServiceException {
        Map emailServiceParams = new HashMap ();
        if (mailSentDate != null)
            emailServiceParams.put ("MAIL_SENT_DATE", mailSentDate);
        emailServiceParams.put ("CAR_OVERDUE_INT",new Integer(1));
        return emailServiceParams;
    }

    public void setMailSentDateParam(int mailSentDate) throws ServiceException {
        this.mailSentDate = new Integer(mailSentDate);
    }

    public void addMailSentDateParam(int mailSentDate) throws ServiceException {
        this.mailSentDate = new Integer(mailSentDate);
    }

    public Map getComplaintEmails(int overdueIntvl) throws ServiceException {
        return this.complaintEmails;
    }

    public void addComplaintEmail(Integer complaintId, String controlNumber, String email, String ownerEmail, String ownerEmailFlag) {
         String[] entry = new String[]{controlNumber, email, ownerEmail, ownerEmailFlag};
        complaintEmails.put(complaintId, entry);
    }
}
