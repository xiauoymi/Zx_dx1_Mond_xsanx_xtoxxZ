/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.service.mock;

import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;

import java.util.Map;

/**
 * Filename:    $RCSfile: MockLookupService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-10-29 18:23:46 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockLookupService implements LookUpService {

  public String[] getEmail(String locationCode) throws ServiceException {
    if ("testLocationCode".equalsIgnoreCase(locationCode)) {
      return new String[]{"testLocationEmail@monsanto.com", "testOwnerEmail@monsanto.com"};
    }
    if ("testLocationCodeWithEmptyEmailList".equalsIgnoreCase(locationCode)) {
      return new String[]{};
    }
    if ("testLocationCodeWithNullLocationEmail".equalsIgnoreCase(locationCode)) {
      return new String[]{null};
    }
    if ("testLocationCodeWithEmptyLocationEmail".equalsIgnoreCase(locationCode)) {
      return new String[]{};
    }
    return null;
  }

  public Map getStates() throws ServiceException {
    return null;
  }

  public Map getStatus(String type) throws ServiceException {
    return null;
  }

  public Map getLocations() throws ServiceException {
    return null;
  }

  public Map getQualityIssues() throws ServiceException {
    return null;
  }

  public Map getYear() throws ServiceException {
    return null;
  }

  public Map getCrops() throws ServiceException {
    return null;
  }

  public Map getSeedSize() throws ServiceException {
    return null;
  }

  public Map getUOM() throws ServiceException {
    return null;
  }

  public Map getVarities() throws ServiceException {
    return null;
  }

  public Map getBrands() throws ServiceException {
    return null;
  }

  public Map getRegions() throws ServiceException {
    return null;
  }

  public Map getResponsibleLocations() throws ServiceException {
    return null;
  }

  public Map getGenerator() throws ServiceException {
    return null;
  }

  public Map getEffectivenessEvaluator() throws ServiceException {
    return null;
  }

  public Map getFindingTypes() throws ServiceException {
    return null;
  }

  public Map getISOStandards() throws ServiceException {
    return null;
  }

  public Map getCAREmails(int overdueIntvl) throws ServiceException {
    return null;
  }

  public Map getEmailServiceParams() throws ServiceException {
    return null;
  }

  public void setMailSentDateParam(int mailSentDate) throws ServiceException {
  }

  public void addMailSentDateParam(int mailSentDate) throws ServiceException {
  }

    public Map getComplaintEmails(int overdueIntvl) throws ServiceException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}