package com.monsanto.wst.breedingcomplaintsaudits.service.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.mock.EmailStructure;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 31, 2007
 * Time: 1:10:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class BCASEmailService_UT extends TestCase {
    public void testSingleCAREmailSentOutIfNoMailSentOutIsSet() throws Exception {
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
        service.doRun();
        assertEquals(1, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(createExpectedSubject("C-1", "CAR"), emailStructure.getSubject());
        assertEquals(createExpectedBody("C-1", "CAR"), emailStructure.getBody());
        assertEquals("b", emailStructure.getTo());
//        assertEquals("c", emailStructure.getCc());
    }

    public void testSingleCAREmailSentOnlyToLocationOwnerIfEmailOwnerFlagIsNotSetToNoAndIfNoMailSentOutIsSet() throws Exception {
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", null, "N");
        service.doRun();
        assertEquals(1, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(createExpectedSubject("C-1", "CAR"), emailStructure.getSubject());
        assertEquals(createExpectedBody("C-1", "CAR"), emailStructure.getBody());
        assertEquals("b", emailStructure.getTo());
        assertNull(emailStructure.getCc());
    }

      public void testSingleCAREmailSentOnlyToLocationOwnerIfEmailOwnerFlagIsSetToNoAndIfNoMailSentOutIsSet() throws Exception {
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "Y");
        service.doRun();
        assertEquals(1, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(createExpectedSubject("C-1", "CAR"), emailStructure.getSubject());
        assertEquals(createExpectedBody("C-1", "CAR"), emailStructure.getBody());
        assertEquals("b", emailStructure.getTo());
        assertNotNull(emailStructure.getCc());
        assertEquals("c", emailStructure.getCc());
    }

    public void testNoEmailSentIfMailSentOutIsSetIfDateIsToday() throws Exception {
        Date currentDate = new Date();
         MockEmailLookupService lookUpService = new MockEmailLookupService();
         MockBCASEmailService service = new MockBCASEmailService();
         MockEmailUtil emailUtil = service.mockEmailUtil;
         service.lookupService = lookUpService;
         service.currentDate = currentDate;
         lookUpService.setMailSentDateParam(currentDate.getDate());
         lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
         service.doRun();
         assertEquals(0, emailUtil.emailStructures.size());
     }

    public void testEmailSentIfMailSentOutIsSetAndIfDateIsNotToday() throws Exception {
        Date currentDate = new Date(2005,11,10);
         MockEmailLookupService lookUpService = new MockEmailLookupService();
         MockBCASEmailService service = new MockBCASEmailService();
         MockEmailUtil emailUtil = service.mockEmailUtil;
         service.lookupService = lookUpService;
         lookUpService.setMailSentDateParam(currentDate.getDate());
         lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
         service.doRun();
         assertEquals(1, emailUtil.emailStructures.size());
     }

    public void testComplaintEmailSentOut() throws Exception{
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addComplaintEmail (new Integer(1), "Complaint-1", "b1", "c1", "N");
        service.doRun();
        assertEquals(1, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(createExpectedSubject("Complaint-1", "Complaint"), emailStructure.getSubject());
        assertEquals(createExpectedBody("Complaint-1", "Complaint"), emailStructure.getBody());
        assertEquals("b1", emailStructure.getTo());
//        assertEquals("c1", emailStructure.getCc());
    }

     public void testComplaintAndCPAREmailSentOut() throws Exception{
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
        lookUpService.addComplaintEmail (new Integer(1), "Complaint-1", "b1", "c1", "N");
        service.doRun();
        assertEquals(2, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);

        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
          assertEquals(createExpectedSubject("C-1", "CAR"), emailStructure.getSubject());
        assertEquals(createExpectedBody("C-1", "CAR"), emailStructure.getBody());
        assertEquals("b", emailStructure.getTo());
//        assertEquals("c", emailStructure.getCc());
         emailStructure = (EmailStructure) emailUtil.emailStructures.get(1);
        assertEquals(createExpectedSubject("Complaint-1", "Complaint"), emailStructure.getSubject());
        assertEquals(createExpectedBody("Complaint-1", "Complaint"), emailStructure.getBody());
        assertEquals("b1", emailStructure.getTo());
//        assertEquals("c1", emailStructure.getCc());
    }

    public void testOnlyCPAREmailsSentOutWhenThereAreNoOverdueComplaints() throws Exception {
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        MockBCASEmailService service = new MockBCASEmailService();
        MockEmailUtil emailUtil = service.mockEmailUtil;
        service.lookupService = lookUpService;
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
       // lookUpService.addComplaintEmail(new Integer(1), "Complaint-1", "b1", "c1", "N");
        service.doRun();
        assertEquals(1, emailUtil.emailStructures.size());
        assertEquals(lookUpService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);

        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(createExpectedSubject("C-1", "CAR"), emailStructure.getSubject());
        assertEquals(createExpectedBody("C-1", "CAR"), emailStructure.getBody());
        assertEquals("b", emailStructure.getTo());
//        assertEquals("c", emailStructure.getCc());
//        assertEquals(createExpectedSubject("Complaint-1", "Complaint"), emailStructure.getSubject());
//        assertEquals(createExpectedBody("Complaint-1", "Complaint"), emailStructure.getBody());
//        assertEquals("b1", emailStructure.getTo());
//        assertEquals("c1", emailStructure.getCc());
    }

    private String createExpectedBody(String control_number, String emailType) {
        return emailType + " '" + control_number + "' has not been approved within 1 day(s).  Click here to logon to the SBFAS system: http://w3.mfg.monsanto.com/bcas\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com";

    }

    private String createExpectedSubject(String control_number, String emailType) {
        return emailType + " Status Overdue: "+ emailType + " '" + control_number + "' - Soybean Breeding Feedback and Audit System";

    }

}
