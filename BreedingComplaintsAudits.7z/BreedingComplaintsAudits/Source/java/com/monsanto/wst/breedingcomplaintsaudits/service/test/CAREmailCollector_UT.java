package com.monsanto.wst.breedingcomplaintsaudits.service.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.service.CAREmailCollector;
import com.monsanto.wst.breedingcomplaintsaudits.service.EmailCollector;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 31, 2007
 * Time: 2:25:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class CAREmailCollector_UT extends TestCase {
    public void testCollectsCorrectEmails() throws Exception{
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        lookUpService.addCAREmail(new Integer(1), "C-1", "b", "c", "N");
        EmailCollector emailCollector = new CAREmailCollector();
        Map result = emailCollector.getEmails (lookUpService, 1);
        assertNotNull(result);
        assertEquals(1, result.size());
        String[] entryData = (String[]) result.get(new Integer(1));
        assertNotNull(entryData);
        assertEquals("C-1", entryData[0]);
        assertEquals("b", entryData[1]);
        assertEquals("c", entryData[2]);
        assertEquals("N", entryData[3]);
    }

    public void testReturnsCorrectTypeOfEmail() throws Exception{
        EmailCollector emailCollector = new CAREmailCollector();
        assertEquals("CAR",emailCollector.getEmailType());
    }
}
