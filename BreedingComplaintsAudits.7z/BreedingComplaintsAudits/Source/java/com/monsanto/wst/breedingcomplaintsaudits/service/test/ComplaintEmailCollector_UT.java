package com.monsanto.wst.breedingcomplaintsaudits.service.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.service.EmailCollector;
import com.monsanto.wst.breedingcomplaintsaudits.service.CAREmailCollector;
import com.monsanto.wst.breedingcomplaintsaudits.service.ComplaintEmailCollector;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 31, 2007
 * Time: 2:38:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ComplaintEmailCollector_UT extends TestCase {
      public void testCollectsCorrectEmails() throws Exception{
        MockEmailLookupService lookUpService = new MockEmailLookupService();
        lookUpService.addComplaintEmail(new Integer(1), "C-1", "b", "c", "N");
        EmailCollector emailCollector = new ComplaintEmailCollector();
        Map result = emailCollector.getEmails (lookUpService, 1);
        assertNotNull(result);
        assertEquals(1, result.size());
        String[] entryData = (String[]) result.get(new Integer(1));
        assertNotNull(entryData);
        assertEquals("C-1", entryData[0]);
        assertEquals("b", entryData[1]);
        assertEquals("c", entryData[2]);
        assertEquals("N", entryData[3]);
    }

    public void testReturnsCorrectTypeOfEmail() throws Exception{
        EmailCollector emailCollector = new ComplaintEmailCollector();
        assertEquals("Complaint",emailCollector.getEmailType());
    }
}
