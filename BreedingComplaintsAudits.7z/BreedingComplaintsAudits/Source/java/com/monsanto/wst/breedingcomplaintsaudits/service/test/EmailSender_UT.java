package com.monsanto.wst.breedingcomplaintsaudits.service.test;

import junit.framework.TestCase;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

import com.monsanto.wst.breedingcomplaintsaudits.service.LookUpService;
import com.monsanto.wst.breedingcomplaintsaudits.service.EmailSender;
import com.monsanto.wst.breedingcomplaintsaudits.service.mock.MockEmailLookupService;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.mock.EmailStructure;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 29, 2007
 * Time: 2:23:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmailSender_UT extends TestCase {
    private Iterator iterator;

    public void testEmailSingleResult () throws Exception{
        Map emailEntryDetails = getSingleEmailEntry();
        Integer interval = new Integer (1);
        LookUpService lookupService = new MockEmailLookupService();
        MockEmailUtil emailUtil = new MockEmailUtil();
        String type = "CAR";
        EmailSender emailSender = new EmailSender(type, emailEntryDetails, lookupService, interval, emailUtil);
        emailSender.sendEmail ();
        assertEquals(emailUtil.emailStructures.size(), 1);
        EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(0);
        assertEquals(lookupService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        assertEquals(createExpectedBody(), emailStructure.getBody());
        assertEquals(createExpectedSubject(), emailStructure.getSubject());
        assertEquals ("a", emailStructure.getFrom());
        assertEquals("b", emailStructure.getTo());
        assertEquals("c", emailStructure.getCc());
    }

    private Map getSingleEmailEntry() {
        Map emailEntryDetails = new HashMap();
        String[] entryData = new String[]{"a","b","c"};
        emailEntryDetails.put("A", entryData);
        return emailEntryDetails;
    }

    public void testEmailMultipleResults() throws Exception {
        int i = 0;
        Map emailEntryDetails = getEmailEntries();
        Integer interval = new Integer(1);
        LookUpService lookupService = new MockEmailLookupService();
        MockEmailUtil emailUtil = new MockEmailUtil();
        String type = "CAR";
        EmailSender emailSender = new EmailSender(type, emailEntryDetails, lookupService, interval, emailUtil);
        emailSender.sendEmail();
        assertEquals(emailUtil.emailStructures.size(), emailEntryDetails.size());
        assertEquals(lookupService.getEmail("ADMN")[0], emailUtil.getFrom());
        assertTrue(emailUtil.wasSendEmailCalled);
        iterator = emailEntryDetails.entrySet().iterator();
        while (iterator.hasNext()){
            EmailStructure emailStructure = (EmailStructure) emailUtil.emailStructures.get(i);
            String[] emails = (String[]) ((Map.Entry) iterator.next()).getValue();
            assertEquals(createExpectedSubject(emails[0]), emailStructure.getSubject());
            assertEquals(createExpectedBody(emails[0]), emailStructure.getBody());
            assertEquals(emails[1], emailStructure.getTo());
            assertEquals(emails[2], emailStructure.getCc());
            i++;
        }
    }

   private Map getEmailEntries() {
        Map emailEntryDetails = getSingleEmailEntry();
        String[] entryData = new String[]{"d", "e", "f"};
        emailEntryDetails.put("B", entryData);
        return emailEntryDetails;
    }

    private String createExpectedBody (String control_number) {
        return "CAR '" + control_number + "' has not been approved within 1 day(s).  Click here to logon to the SBFAS system: http://w3.mfg.monsanto.com/bcas\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com";

    }

    private String createExpectedSubject (String control_number) {
         return "CAR Status Overdue: CAR '" + control_number + "' - Soybean Breeding Feedback and Audit System";
    }


    private String createExpectedSubject() {
        return "CAR Status Overdue: CAR 'a' - Soybean Breeding Feedback and Audit System";
    }

    private String createExpectedBody() {
         return "CAR 'a' has not been approved within 1 day(s).  Click here to logon to the SBFAS system: http://w3.mfg.monsanto.com/bcas\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "If you experience any problems please e-mail the SBFAS Administrator team at: administrator.sbfas@monsanto.com";

    }
}
