package com.monsanto.wst.breedingcomplaintsaudits.service.test;

import com.monsanto.wst.breedingcomplaintsaudits.service.*;
import com.monsanto.wst.breedingcomplaintsaudits.mock.MockEmailUtil;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 29, 2007
 * Time: 1:56:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockBCASEmailService extends BCASEmailService {
    public MockEmailUtil mockEmailUtil = new MockEmailUtil();
    public LookUpService lookupService;
    public Date currentDate = new Date();

    public MockBCASEmailService() {
        super(new EmailCollector[]{new CAREmailCollector(), new ComplaintEmailCollector()});
    }

    protected EmailUtil createEmailUtil() {
        return mockEmailUtil;
    }


    protected LookUpService createLookUpService() throws ServiceException {
        LookUpService retService =  this.lookupService;
        if (retService == null) {
            retService = super.createLookUpService();
        }
        return retService;
    }


    protected Date getCurrentDate() {
        return this.currentDate;
    }
}
