/**
 * Reporting Tool (ColumnBean) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

/**
 * ColumnBean: This is the class/object used to fill in the column formatting instructions by the XmlParser
 * after it parses the report structure file.
 * 
 * @author Rasesh Desai
 *
 */
public class ColumnBean {
	
	private String colWidth;
	private String name;
	private String mappingField;
	private String type;
	private String align;
	private String valign;
	private String textColor;
	private String textSize;
	private String bgColor;
	private String font;
	private String cssClass;
	private String bold;
	private String underline;
	
	private String nowrap;
	
	private String dataLength;
	
	
	
	/**
	 * @return Returns the dataLength.
	 */
	public String getDataLength() {
		return dataLength;
	}
	/**
	 * @param dataLength The dataLength to set.
	 */
	public void setDataLength(String dataLength) {
		this.dataLength = dataLength;
	}
	/**
	 * @return Returns the nowrap.
	 */
	public String getNowrap() {
		return nowrap;
	}
	/**
	 * @param nowrap The nowrap to set.
	 */
	public void setNowrap(String nowrap) {
		this.nowrap = nowrap;
	}
	/**
	 * @return Returns the bold.
	 */
	public String getBold() {
		return bold;
	}
	/**
	 * @param bold The bold to set.
	 */
	public void setBold(String bold) {
		this.bold = bold;
	}
	/**
	 * @return Returns the underline.
	 */
	public String getUnderline() {
		return underline;
	}
	/**
	 * @param underline The underline to set.
	 */
	public void setUnderline(String underline) {
		this.underline = underline;
	}
	/**
	 * @return Returns the align.
	 */
	public String getAlign() {
		return align;
	}
	/**
	 * @param align The align to set.
	 */
	public void setAlign(String align) {
		this.align = align;
	}
	/**
	 * @return Returns the bgColor.
	 */
	public String getBgColor() {
		return bgColor;
	}
	/**
	 * @param bgColor The bgColor to set.
	 */
	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}
	/**
	 * @return Returns the colWidth.
	 */
	public String getColWidth() {
		return colWidth;
	}
	/**
	 * @param colWidth The colWidth to set.
	 */
	public void setColWidth(String colWidth) {
		this.colWidth = colWidth;
	}
	/**
	 * @return Returns the cssClass.
	 */
	public String getCssClass() {
		return cssClass;
	}
	/**
	 * @param cssClass The cssClass to set.
	 */
	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}
	/**
	 * @return Returns the font.
	 */
	public String getFont() {
		return font;
	}
	/**
	 * @param font The font to set.
	 */
	public void setFont(String font) {
		this.font = font;
	}
	/**
	 * @return Returns the mappingField.
	 */
	public String getMappingField() {
		return mappingField;
	}
	/**
	 * @param mappingField The mappingField to set.
	 */
	public void setMappingField(String mappingField) {
		this.mappingField = mappingField;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the textColor.
	 */
	public String getTextColor() {
		return textColor;
	}
	/**
	 * @param textColor The textColor to set.
	 */
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	/**
	 * @return Returns the textSize.
	 */
	public String getTextSize() {
		return textSize;
	}
	/**
	 * @param textSize The textSize to set.
	 */
	public void setTextSize(String textSize) {
		this.textSize = textSize;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return Returns the valign.
	 */
	public String getValign() {
		return valign;
	}
	/**
	 * @param valign The valign to set.
	 */
	public void setValign(String valign) {
		this.valign = valign;
	}
	public String toString() {
	      String newline = System.getProperty( "line.separator" );
	      StringBuffer buf = new StringBuffer();

	      buf.append( "--- #Colunm --- ColWidth: " + colWidth + " Name: " + name + 
	      		" type: " + type + " align: " + align + " valign: " + valign
				+ " tc: " + textColor + " ts: " + textSize + " bgc: " + bgColor
				+ " font: " + font + " class: " + cssClass + " mapping: " + mappingField).append( newline );

	      return buf.toString();
	}
}
