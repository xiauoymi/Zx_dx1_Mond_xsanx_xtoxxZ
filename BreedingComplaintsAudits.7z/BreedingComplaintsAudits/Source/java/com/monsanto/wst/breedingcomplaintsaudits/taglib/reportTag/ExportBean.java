/**
 * Reporting Tool/ Export Tool (ExportBean) was created on Jun 10, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

import java.util.Vector;

/**
 * Export Bean...
 * 
 * @author Rasesh Desai
 *
 */
public class ExportBean {
	
	private int totalFields;	
	private Vector exportDataVector = new Vector();
	private Vector exportColHeader = new Vector();

	private String excelFileName;
	private String excelSheetName;
	
	
	
	/**
	 * @return Returns the excelFileName.
	 */
	public String getExcelFileName() {
		return excelFileName;
	}
	/**
	 * @param excelFileName The excelFileName to set.
	 */
	public void setExcelFileName(String excelFileName) {
		this.excelFileName = excelFileName;
	}
	/**
	 * @return Returns the excelSheetName.
	 */
	public String getExcelSheetName() {
		return excelSheetName;
	}
	/**
	 * @param excelSheetName The excelSheetName to set.
	 */
	public void setExcelSheetName(String excelSheetName) {
		this.excelSheetName = excelSheetName;
	}
	/**
	 * @return Returns the exportColHeader.
	 */
	public Vector getExportColHeader() {
		return exportColHeader;
	}
	/**
	 * @param exportColHeader The exportColHeader to set.
	 */
	public void setExportColHeader(Vector exportColHeader) {
		this.exportColHeader = exportColHeader;
	}
	/**
	 * @return Returns the exportDataVector.
	 */
	public Vector getExportDataVector() {
		return exportDataVector;
	}
	/**
	 * @param exportDataVector The exportDataVector to set.
	 */
	public void setExportDataVector(Vector exportDataVector) {
		this.exportDataVector = exportDataVector;
	}
	/**
	 * @return Returns the totalFields.
	 */
	public int getTotalFields() {
		return totalFields;
	}
	/**
	 * @param totalFields The totalFields to set.
	 */
	public void setTotalFields(int totalFields) {
		this.totalFields = totalFields;
	}
}
