/**
 * Reporting Tool(PageBuilder) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

import org.apache.log4j.Category;

/**
 * PageBuilder: This class builds the jsp tags depending upon the inputs given by the reportTag class.
 * tag.
 * 
 * @author Rasesh Desai
 *
 */
public class PageBuilder {
	
	static Category logger = Category.getInstance(PageBuilder.class.getName());
	
	private static final String START_TABLE = "<TABLE ";
	private static final String END_TABLE = "</TABLE>";
	
	private static final String START_ROW = "<TR ";
	private static final String END_ROW = "</TR>";
	
	private static final String START_COL = "<TD ";
	private static final String END_COL = "</TD>";
	
	private static int colCount = 0;
	
	public String reportTitle(String title, String titleColor, String titleFont, String titleBold, String titleUnderline){
		
		String bold = "";
		String endBold = "";
		String underline = "";
		String endUnderline = "";
		
		if(titleBold.trim().equalsIgnoreCase("true")){
			bold = "<B>";
			endBold = "</B>";
		}
		
		if(titleUnderline.trim().equalsIgnoreCase("true")){
			underline = "<U>";
			endUnderline = "</U>";
		}
		
		logger.debug("<FONT " +
				"color=\"" + titleColor + "\" " +
				"face=\"" + titleFont + "\">" +
				bold +
				underline + title + endUnderline +
				endBold +
				"</FONT><BR><BR>");
		
		return "<FONT " +
				"color=\"" + titleColor + "\" " +
				"face=\"" + titleFont + "\">" +
				bold +
				underline + title + endUnderline +
				endBold +
				"</FONT><BR><BR>";
	}
	
	public String startTable(String width, String border, String cellPadding, String cellSpacing, String tableClass){		
		
		colCount = 0;
		
		logger.debug(START_TABLE + "width=\"" + width + "\" "
							+ "border=\"" + border + "\" "
							+ "cellspacing=\"" + cellSpacing + "\" "
							+ "cellpadding=\"" + cellPadding + "\" "
							+ "class=\"" + tableClass + "\" "
							+ ">");
		
		return START_TABLE 	+ "width=\"" + width + "\" "
							+ "border=\"" + border + "\" "
							+ "cellspacing=\"" + cellSpacing + "\" "
							+ "cellpadding=\"" + cellPadding + "\" "
							+ "class=\"" + tableClass + "\" "
							+ ">";		
	}
	
	public String endTable(){
		logger.debug(END_TABLE);
		return END_TABLE;
	}
	
	public String startRow(String height){
		
		String bgcolor= "";
		
		//** TODO Alternate Color Row Logic...uncomment if needed...		
//		if(colCount > 1){
//			if(colCount % 2 == 0){
//				bgcolor = "#CCCCCC";
//			}
//			else{
//				bgcolor = "";
//			}
//		}
		colCount++;
		
		logger.debug(START_ROW 
				  + "height=\"" + height + "\" " 
				  + "bgcolor=\"" + bgcolor + "\" "
				  + ">");
				
		return START_ROW 
			  + "height=\"" + height + "\" " 
			  + "bgcolor=\"" + bgcolor + "\" "
			  + ">";
	}
	
	public String endRow(){
		logger.debug(END_ROW);
		return END_ROW;
	}
	
	public String startCol(ColumnBean col, String text, boolean headerCol){
			return startDataCol(col, text);
	}
	
	public String startHeaderCol(String name, String width, String align, String valign,
								String textColor, String textSize, String bgcolor, String font,
								String hdrBold, String hdrUnderline, String cssClass,String hdrNowrap){
		
		String bold = "";
		String underline = "";	
		String endBold = "";
		String endUnderline = "";		
		String nowrap = "";
		
		if(hdrNowrap.trim().equalsIgnoreCase("true")){
			nowrap = " NOWRAP ";
		}
		
		if(hdrBold.trim().equalsIgnoreCase("true")){
			bold = "<B>";
			endBold = "</B>";
		}
		
		if(hdrUnderline.trim().equalsIgnoreCase("true")){
			underline = "<U>";
			endUnderline = "</U>";
		}
		
		
		String returnVal = START_COL + nowrap + " width=\"" + width + "\" " 
							+ "align=\"" + align + "\" "
							+ "valign=\"" + valign + "\" "
							+ "bgcolor=\"" + bgcolor + "\" "
							+ ">"
							+ "<FONT size=\"" + textSize + "\" "
							+ "color=\"" + textColor + "\" "
							+ "face=\"" + font + "\""
							+ ">";
		
		returnVal += bold + underline + name + endUnderline + endBold;
		
		returnVal += "</FONT>";
		
		logger.debug(returnVal);		
		return returnVal;
		
	}
	
	public String startDataCol(ColumnBean col, String text){
		
		String align = "";
		String valign = "middle";	//default...
		String width = "";
		String bgcolor = "";
		String font = "";
		String textSize = "";
		String textColor = "";
		String cssClass = "";
		String name = "Column Name";
		String nowrap = "";
		
		if(col.getNowrap().trim().equalsIgnoreCase("true")){
			nowrap = " NOWRAP ";
		}
		
		if(col.getAlign() != null){
			align = col.getAlign();
		}
		if(col.getBgColor() != null){
			bgcolor = col.getBgColor();
		}
		if(col.getCssClass() != null){
			cssClass = col.getCssClass();
		}
		if(col.getColWidth() != null){
			width = col.getColWidth();
		}
		if(col.getFont() != null){
			font = col.getFont();
		}
		if(col.getName() != null){
			name = col.getName();
		}
		if(col.getTextColor() != null){
			textColor = col.getTextColor();
		}
		if(col.getTextSize() != null){
			textSize = col.getTextSize();
		}
		if(col.getValign() != null){
			valign = col.getValign();
		}
		
		
		String returnVal = START_COL + nowrap +  " width=\"" + width + "\" " 
							+ "align=\"" + align + "\" "
							+ "valign=\"" + valign + "\" "
							+ "bgcolor=\"" + bgcolor + "\" "
							+ ">"
							+ "<FONT size=\"" + textSize + "\" "
							+ "color=\"" + textColor + "\" "
							+ "face=\"" + font + "\""
							+ ">";
		
		if(col.getBold().equalsIgnoreCase("true")){
			returnVal += "<B>";
		}
		
		if(col.getUnderline().equalsIgnoreCase("true")){
			returnVal += "<U>";
		}
		
		returnVal += text;
		
		if(col.getUnderline().equalsIgnoreCase("true")){
			returnVal += "</U>";
		}
		
		if(col.getBold().equalsIgnoreCase("true")){
			returnVal += "</B>";
		}
		
		returnVal += "</FONT>";
		
		logger.debug(returnVal);		
		return returnVal;
		
	}
	
	
	
	public String endCol(){
		logger.debug(END_COL);
		return END_COL;
	}
	
	/**
	 * TODO Future additions, if needed...to display a link...
	 * (this string should be used in the "data cell" instead of just text/data...)
	 * (This will involve some changes to ReportTag and PageBuilder code)
	 * 
	 * <column>
	 * 		<type>link</type>
	 * </column>
	 * 
	 * @param text
	 * @param target
	 * @return
	 */
	public String getLink(String text, String target){	
		logger.debug("<a href=\"" + target + "\">"+ text +"</a>");		
		return "<a href=\"" + target + "\">"+ text +"</a>"; 		
	}
	
	/**
	 * TODO Future additions, if needed...to display an image...
	 * (this string should be used in the "data cell" instead of just text/data...)
	 * (This will involve some changes to ReportTag and PageBuilder code)
	 * 
	 * <column>
	 * 		<type>image</type>
	 * </column>
	 * 
	 * @param text
	 * @param target
	 * @return
	 */
	public String getImage(String path){	
		logger.debug("<img src=\"" + path + "\">");
		return "<img src=\"" + path + "\">"; 
	}
	
	/**
	 * TODO Future additions, if needed...to display an image with link/target...
	 * (this string should be used in the "data cell" instead of just text/data...)
	 * (This will involve some changes to ReportTag and PageBuilder code)
	 * 
	 * <column>
	 * 		<type>imagePath</type>
	 * </column>
	 * 
	 * @param text
	 * @param target
	 * @return
	 */
	public String getImageLink(String path, String target){	
		logger.debug("<a href=\"" + target + "\"><img src=\"" + path + "\"></a>");
		return "<a href=\"" + target + "\"><img src=\"" + path + "\"></a>"; 		
	}
	
	
}
