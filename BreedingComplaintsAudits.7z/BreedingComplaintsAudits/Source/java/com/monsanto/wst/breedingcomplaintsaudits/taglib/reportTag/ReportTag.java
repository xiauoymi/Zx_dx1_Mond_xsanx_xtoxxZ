/**
 * Reporting Tool (ReportTag) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Category;


/**
 * Reporting Tool: This is a tool to generate custom report. It mainly consists of a custom tag
 * <tags:reportTag .../> which takes in 4 attributes: 
 * 		1. InputStream (which is the XML file that takes the formatting instructions)
 * 		2. HashMap (that contains the data)
 * 		3. SortBy (field by which the report needs to be sorted, Currently supported sorting by col1, col2 and col3)
 * 		4. SortOrder (asc/des order)
 * 		5. ExportSupport: true/false. (It will accordingly provide the data for export.)
 * 
 * The report tag looks like this:
 * 
 * <tags:reportTag xmlIn="${complaintFilterForm.xmlIn}" hash="${complaintFilterForm.hash}" 
                    sortBy="${complaintFilterForm.sortBy}" sortOrder="${complaintFilterForm.sortOrder}" 
                    exportSupport="true" />
 *
 * The variables can also be present in request/session scope Eg: hash="${requestScope.hash}" 
 *
 *  @author Rasesh Desai
 *
 */
public class ReportTag extends SimpleTagSupport {
	
	static Category logger = Category.getInstance(ReportTag.class.getName());
	
	private InputStream xmlIn;
	
	private HashMap hash;
	
	private String sortBy;	
	
	private String sortOrder;	
	
	private boolean exportSupport;
	
	private Vector exportColHeader = new Vector();
	
	private static ExportBean exportBean = new ExportBean();
	
	Vector dataVector;
	
	public static boolean PARSING_ERROR = false;
	
	/**
	 * @param exportSupport The exportSupport to set.
	 */
	public void setExportSupport(boolean exportSupport) {
		this.exportSupport = exportSupport;
	}
	/**
	 * @param dataVector The dataVector to set.
	 */
	public void setDataVector(Vector dataVector) {
		this.dataVector = dataVector;
	}
	/**
	 * @param sortOrder The order to set.
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	/**
	 * @param sortBy The sortBy to set.
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	/**
	 * Xml InputStream Setter
	 * 
	 * @param xmlIn The xmlIn to set.
	 */
	public void setXmlIn(InputStream xmlIn) {
		this.xmlIn = xmlIn;
	}
	
	/**
	 * Data Hash Setter
	 * 
	 * @param coll
	 */
	public void setHash(HashMap coll) {
	      this.hash = coll;
	}

	
	//**Step2: doTag() Method...
	public void doTag() throws JspException, IOException {
		
		//**Call the report Parser...
		XmlParser parser = new XmlParser();	
		
		ReportBean report = parser.getParsedXmlBean(xmlIn);
		
		if(report == null){
			getJspContext().getOut().write("<Br><Font color=\"#003366\" face=\"Arial, Helvetica, sans-serif\" size=\"3px\">Xml Parser Error</Font>");
			PARSING_ERROR = true;
		}
		else{
			
			if(report.isErrorFlag()){
				getJspContext().getOut().write("<Br><Font color=\"#003366\" face=\"Arial, Helvetica, sans-serif\" size=\"3px\">" + report.getErrorMsg()+ "</Font>");
				PARSING_ERROR = true;
			}
			else{
				
				//**Display the body as it is...
				StringWriter sw = new StringWriter();
				getJspBody().invoke(sw);
				getJspContext().getOut().print(sw.toString());
		
				//**  NOTE: A subsequent call to the reset method repositions this stream at the last marked position 
				//**  (or since the start of the file, if mark has not been called)so that subsequent reads 
				//**  re-read the same bytes. [Also see mark(int readlimit) and markSupported(), if reqd...] 
				
				if(xmlIn.markSupported()){
					xmlIn.reset();
				}
				
				PageBuilder builder = new PageBuilder();
				
				if(report != null){
					//**Report Title...
					String title = "";
					String titleColor = "";
					String titleFont = "";
					String titleBold = "";
					String titleUnderline = "";
					
					if(report.getTitle() != null){
						title = report.getTitle();
					}
					if(report.getTitleColor() != null){
						titleColor = report.getTitleColor();
					}
					if(report.getTitleFont() != null){
						titleFont = report.getTitleFont();
					}
					if(report.getTitleBold() != null){
						titleBold = report.getTitleBold();
					}
					if(report.getTitleUnderline() != null){
						titleUnderline = report.getTitleUnderline();
					}
					
					getJspContext().getOut().write(builder.reportTitle(title, titleColor, titleFont,titleBold, titleUnderline));
							
					//**<TABLE>
					//**Default Values...
					String border = "1";
					String cellSpacing = "0";
					String cellPadding = "0";
					String width = "";
					String tableClass = "";
						
					if(report.getBorder() != null){
						border = report.getBorder();
					}
					if(report.getCellPadding() != null){
						cellPadding = report.getCellPadding();
					}
					if(report.getCellSpacing() != null){
						cellSpacing = report.getCellSpacing();
					}
					if(report.getTableClass() != null){
						tableClass = report.getTableClass();
					}
						
					getJspContext().getOut().write(builder.startTable(width, border, cellPadding, cellSpacing, tableClass));
					
					
					//Header Row...
					//**<TR>
					if(report.getHeaderHeight() != null){	
						getJspContext().getOut().write(builder.startRow(report.getHeaderHeight()));
					}
					else{
						getJspContext().getOut().write(builder.startRow(""));		//**OR Some default value...
					}
					
					for(int i = 0; i < report.getColumns().size(); i++){
						//**<TD>
						getJspContext().getOut().write(
										  builder.startHeaderCol(((ColumnBean)report.getColumns().get(i)).getName(),
								          ((ColumnBean)report.getColumns().get(i)).getColWidth(), ((ColumnBean)report.getColumns().get(i)).getAlign(), 
										  report.getHeaderValign(), report.getHeaderTextColor(), report.getHeaderTextSize(),
										  report.getHeaderBgColor(), report.getHeaderFont(), report.getHeaderBold(),
										  report.getHeaderUnderline(), report.getHeaderClass(), report.getHeaderNowrap())
										  );		
						//**</TD>
						getJspContext().getOut().write(builder.endCol());
						
						if(exportSupport){
							exportColHeader.add(((ColumnBean)report.getColumns().get(i)).getName());
						}
					}
					
					//**</TR>
					getJspContext().getOut().write(builder.endRow());
				
				
					//Data Row...(hashMap loop)
					//Iterator it = hash.keySet().iterator();
					
					if(sortBy != null){
						if(sortOrder != null){
							sortHashMap(hash, sortBy, sortOrder);
						}
						else{
							sortHashMap(hash, sortBy, "asc");
						}
					}
					else{
						sortHashMap(hash, "col1", "asc"); //default
					}
					
					//**If export functionality os supported...
					if(exportSupport){
						exportBean.setExportDataVector(dataVector);
						exportBean.setExportColHeader(exportColHeader);
						exportBean.setTotalFields(report.getColumns().size());
						exportBean.setExcelFileName(report.getExcelFileName());
						exportBean.setExcelSheetName(report.getExcelSheetName());
					}
					
					for(int j = 0; j < dataVector.size(); j++){
						
						RowBean row = (RowBean)dataVector.get(j);
						
						//**<TR>
						if(report.getHeaderHeight() != null){	
							getJspContext().getOut().write(builder.startRow(report.getRowHeight()));
						}
						else{
							getJspContext().getOut().write(builder.startRow(""));		//**OR Some default value...
						}
					
						for(int i = 0; i < report.getColumns().size(); i++){
							
							String mappingField = ((ColumnBean)report.getColumns().get(i)).getMappingField();
							String strDesc = "";
							int dataLength = -1;
							
							if(mappingField.equalsIgnoreCase("col1")){
								strDesc = row.getCol1();
							}						
							if(mappingField.equalsIgnoreCase("col2")){
								strDesc = row.getCol2();
							}
							if(mappingField.equalsIgnoreCase("col3")){
								strDesc = row.getCol3();
							}
							if(mappingField.equalsIgnoreCase("col4")){
								strDesc = row.getCol4();
							}
							if(mappingField.equalsIgnoreCase("col5")){
								strDesc = row.getCol5();
							}
							if(mappingField.equalsIgnoreCase("col6")){
								strDesc = row.getCol6();
							}
							if(mappingField.equalsIgnoreCase("col7")){
								strDesc = row.getCol7();
							}
							if(mappingField.equalsIgnoreCase("col8")){
								strDesc = row.getCol8();
							}
							if(mappingField.equalsIgnoreCase("col9")){
								strDesc = row.getCol9();
							}
							if(mappingField.equalsIgnoreCase("col10")){
								strDesc = row.getCol10();
							}
							
							if(mappingField.equalsIgnoreCase("col11")){
								strDesc = row.getCol11();
							}						
							if(mappingField.equalsIgnoreCase("col12")){
								strDesc = row.getCol12();
							}
							if(mappingField.equalsIgnoreCase("col13")){
								strDesc = row.getCol13();
							}
							if(mappingField.equalsIgnoreCase("col14")){
								strDesc = row.getCol14();
							}
							if(mappingField.equalsIgnoreCase("col15")){
								strDesc = row.getCol15();
							}
							if(mappingField.equalsIgnoreCase("col16")){
								strDesc = row.getCol16();
							}
							if(mappingField.equalsIgnoreCase("col17")){
								strDesc = row.getCol17();
							}
							if(mappingField.equalsIgnoreCase("col18")){
								strDesc = row.getCol18();
							}
							if(mappingField.equalsIgnoreCase("col19")){
								strDesc = row.getCol19();
							}
							if(mappingField.equalsIgnoreCase("col20")){
								strDesc = row.getCol20();
							}
							
							if(mappingField.equalsIgnoreCase("col21")){
								strDesc = row.getCol21();
							}						
							if(mappingField.equalsIgnoreCase("col22")){
								strDesc = row.getCol22();
							}
							if(mappingField.equalsIgnoreCase("col23")){
								strDesc = row.getCol23();
							}
							if(mappingField.equalsIgnoreCase("col24")){
								strDesc = row.getCol24();
							}
							if(mappingField.equalsIgnoreCase("col25")){
								strDesc = row.getCol25();
							}
							if(mappingField.equalsIgnoreCase("col26")){
								strDesc = row.getCol26();
							}
							if(mappingField.equalsIgnoreCase("col27")){
								strDesc = row.getCol27();
							}
							if(mappingField.equalsIgnoreCase("col28")){
								strDesc = row.getCol28();
							}
							if(mappingField.equalsIgnoreCase("col29")){
								strDesc = row.getCol29();
							}
							if(mappingField.equalsIgnoreCase("col30")){
								strDesc = row.getCol30();
							}
							
							if(mappingField.equalsIgnoreCase("col31")){
								strDesc = row.getCol31();
							}						
							if(mappingField.equalsIgnoreCase("col32")){
								strDesc = row.getCol32();
							}
							if(mappingField.equalsIgnoreCase("col33")){
								strDesc = row.getCol33();
							}
							if(mappingField.equalsIgnoreCase("col34")){
								strDesc = row.getCol34();
							}
							if(mappingField.equalsIgnoreCase("col35")){
								strDesc = row.getCol35();
							}
							if(mappingField.equalsIgnoreCase("col36")){
								strDesc = row.getCol36();
							}
							if(mappingField.equalsIgnoreCase("col37")){
								strDesc = row.getCol37();
							}
							if(mappingField.equalsIgnoreCase("col38")){
								strDesc = row.getCol38();
							}
							if(mappingField.equalsIgnoreCase("col39")){
								strDesc = row.getCol39();
							}
							if(mappingField.equalsIgnoreCase("col40")){
								strDesc = row.getCol40();
							}
							
							if(mappingField.equalsIgnoreCase("col41")){
								strDesc = row.getCol41();
							}						
							if(mappingField.equalsIgnoreCase("col42")){
								strDesc = row.getCol42();
							}
							if(mappingField.equalsIgnoreCase("col43")){
								strDesc = row.getCol43();
							}
							if(mappingField.equalsIgnoreCase("col44")){
								strDesc = row.getCol44();
							}
							if(mappingField.equalsIgnoreCase("col45")){
								strDesc = row.getCol45();
							}
							if(mappingField.equalsIgnoreCase("col46")){
								strDesc = row.getCol46();
							}
							if(mappingField.equalsIgnoreCase("col47")){
								strDesc = row.getCol47();
							}
							if(mappingField.equalsIgnoreCase("col48")){
								strDesc = row.getCol48();
							}
							if(mappingField.equalsIgnoreCase("col49")){
								strDesc = row.getCol49();
							}
							if(mappingField.equalsIgnoreCase("col50")){
								strDesc = row.getCol50();
							}
							
							if(mappingField.equalsIgnoreCase("col51")){
								strDesc = row.getCol51();
							}						
							if(mappingField.equalsIgnoreCase("col52")){
								strDesc = row.getCol52();
							}
							if(mappingField.equalsIgnoreCase("col53")){
								strDesc = row.getCol53();
							}
							if(mappingField.equalsIgnoreCase("col54")){
								strDesc = row.getCol54();
							}
							if(mappingField.equalsIgnoreCase("col55")){
								strDesc = row.getCol55();
							}
							if(mappingField.equalsIgnoreCase("col56")){
								strDesc = row.getCol56();
							}
							if(mappingField.equalsIgnoreCase("col57")){
								strDesc = row.getCol57();
							}
							if(mappingField.equalsIgnoreCase("col58")){
								strDesc = row.getCol58();
							}
							if(mappingField.equalsIgnoreCase("col59")){
								strDesc = row.getCol59();
							}
							if(mappingField.equalsIgnoreCase("col60")){
								strDesc = row.getCol60();
							}
							
							if(mappingField.equalsIgnoreCase("col61")){
								strDesc = row.getCol61();
							}						
							if(mappingField.equalsIgnoreCase("col62")){
								strDesc = row.getCol62();
							}
							if(mappingField.equalsIgnoreCase("col63")){
								strDesc = row.getCol63();
							}
							if(mappingField.equalsIgnoreCase("col64")){
								strDesc = row.getCol64();
							}
							if(mappingField.equalsIgnoreCase("col65")){
								strDesc = row.getCol65();
							}
							if(mappingField.equalsIgnoreCase("col66")){
								strDesc = row.getCol66();
							}
							if(mappingField.equalsIgnoreCase("col67")){
								strDesc = row.getCol67();
							}
							if(mappingField.equalsIgnoreCase("col68")){
								strDesc = row.getCol68();
							}
							if(mappingField.equalsIgnoreCase("col69")){
								strDesc = row.getCol69();
							}
							if(mappingField.equalsIgnoreCase("col70")){
								strDesc = row.getCol70();
							}
							
							if(mappingField.equalsIgnoreCase("col71")){
								strDesc = row.getCol71();
							}						
							if(mappingField.equalsIgnoreCase("col72")){
								strDesc = row.getCol72();
							}
							if(mappingField.equalsIgnoreCase("col73")){
								strDesc = row.getCol73();
							}
							if(mappingField.equalsIgnoreCase("col74")){
								strDesc = row.getCol74();
							}
							if(mappingField.equalsIgnoreCase("col75")){
								strDesc = row.getCol75();
							}
							if(mappingField.equalsIgnoreCase("col76")){
								strDesc = row.getCol76();
							}
							if(mappingField.equalsIgnoreCase("col77")){
								strDesc = row.getCol77();
							}
							if(mappingField.equalsIgnoreCase("col78")){
								strDesc = row.getCol78();
							}
							if(mappingField.equalsIgnoreCase("col79")){
								strDesc = row.getCol79();
							}
							if(mappingField.equalsIgnoreCase("col80")){
								strDesc = row.getCol80();
							}
							
							if(mappingField.equalsIgnoreCase("col81")){
								strDesc = row.getCol81();
							}						
							if(mappingField.equalsIgnoreCase("col82")){
								strDesc = row.getCol82();
							}
							if(mappingField.equalsIgnoreCase("col83")){
								strDesc = row.getCol83();
							}
							if(mappingField.equalsIgnoreCase("col84")){
								strDesc = row.getCol84();
							}
							if(mappingField.equalsIgnoreCase("col85")){
								strDesc = row.getCol85();
							}
							if(mappingField.equalsIgnoreCase("col86")){
								strDesc = row.getCol86();
							}
							if(mappingField.equalsIgnoreCase("col87")){
								strDesc = row.getCol87();
							}
							if(mappingField.equalsIgnoreCase("col88")){
								strDesc = row.getCol88();
							}
							if(mappingField.equalsIgnoreCase("col89")){
								strDesc = row.getCol89();
							}
							if(mappingField.equalsIgnoreCase("col90")){
								strDesc = row.getCol90();
							}
							
							if(mappingField.equalsIgnoreCase("col91")){
								strDesc = row.getCol91();
							}						
							if(mappingField.equalsIgnoreCase("col92")){
								strDesc = row.getCol92();
							}
							if(mappingField.equalsIgnoreCase("col93")){
								strDesc = row.getCol93();
							}
							if(mappingField.equalsIgnoreCase("col94")){
								strDesc = row.getCol94();
							}
							if(mappingField.equalsIgnoreCase("col95")){
								strDesc = row.getCol95();
							}
							if(mappingField.equalsIgnoreCase("col96")){
								strDesc = row.getCol96();
							}
							if(mappingField.equalsIgnoreCase("col97")){
								strDesc = row.getCol97();
							}
							if(mappingField.equalsIgnoreCase("col98")){
								strDesc = row.getCol98();
							}
							if(mappingField.equalsIgnoreCase("col99")){
								strDesc = row.getCol99();
							}
							if(mappingField.equalsIgnoreCase("col100")){
								strDesc = row.getCol100();
							}
							
							if(((ColumnBean)report.getColumns().get(i)).getDataLength() != null){
								try{
									dataLength = Integer.parseInt(((ColumnBean)report.getColumns().get(i)).getDataLength());  
								}
								catch(Exception ex){
									logger.info("Integer expected in the DataLength attribute found in " + mappingField);
								}
							}
								
							if(dataLength != -1 && strDesc.length() > dataLength){
								strDesc = strDesc.substring(0, dataLength) + "..."; 
							}
								
							getJspContext().getOut().write(builder.startCol(((ColumnBean)report.getColumns().get(i)), strDesc, false));		
							getJspContext().getOut().write(builder.endCol());
						}
					
						//**</TR>
						getJspContext().getOut().write(builder.endRow());
					}
					
					//**</TR>
					getJspContext().getOut().write(builder.endRow());
				
					
					//**</TABLE>
					getJspContext().getOut().write(builder.endTable());
				}
				
			}//END ELSE (ERROR_MSG)
			
		}// END ELSE (REPORT == NULL)
		
	  }
	
	/**
	 * Sorts HashMap based on any 3 fields col1/col2/col3 and in reqd order.
	 * 
	 * @param hash
	 * @param field
	 * @param order
	 */
	 public void sortHashMap(HashMap hash, String field, String order){
	 	
	 	dataVector = new Vector();
	 	
	 	Iterator it = hash.keySet().iterator();
	 	
	 	while(it.hasNext()){
	 		dataVector.add((RowBean)hash.get(it.next()));
	 	}
	 	
	 	
	 	//**No Sorting
	 	if(field.equals("")){
	 		return;
	 	}
	 	
	 	if(order.equals("")){
	 		order = "asc";	//default...
	 	}
	 	
	 	if(field.equalsIgnoreCase("col1") && order.equalsIgnoreCase("asc")){
	 	   Collections.sort(dataVector, 
				new Comparator(){
			public int compare(Object a, Object b) {
				
				String aTokens[] = ((RowBean)a).getCol1().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol1().trim().split("-");
				
				int noOfTokens = aTokens.length;
				
				for(int i = 0; i < noOfTokens; i++){
					
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
						
						if(aVal > bVal){
							return 1;
						}
						if(aVal < bVal){
							return -1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return 1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return -1;
						}						
					}
					
				}
				
				return 0;
			}
			}

	 	  );
	 	}
	 	
	 	if(field.equalsIgnoreCase("col1") && order.equalsIgnoreCase("dec")){
		 	   Collections.sort(dataVector, 
					new Comparator(){
				public int compare(Object a, Object b) {
			
				String aTokens[] = ((RowBean)a).getCol1().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol1().trim().split("-");
					
				int noOfTokens = aTokens.length;
					
				for(int i = 0; i < noOfTokens; i++){
						
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
							
						if(aVal > bVal){
							return -1;
						}
						if(aVal < bVal){
							return 1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return -1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return 1;
						}						
					}
						
				}	
				return 0;
				}
				}

		 	  );
		}
	 	
	 	if(field.equalsIgnoreCase("col2") && order.equalsIgnoreCase("asc")){
		 	Collections.sort(dataVector, 
					new Comparator(){
				public int compare(Object a, Object b) {
				
				String aTokens[] = ((RowBean)a).getCol2().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol2().trim().split("-");
					
				int noOfTokens = aTokens.length;
					
				for(int i = 0; i < noOfTokens; i++){
						
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
							
						if(aVal > bVal){
							return 1;
						}
						if(aVal < bVal){
							return -1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return 1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return -1;
						}						
					}
						
				}	
					
				return 0;
				}
				}

		 	);
	    }
	 	
	 	if(field.equalsIgnoreCase("col2") && order.equalsIgnoreCase("dec")){
		 	Collections.sort(dataVector, 
					new Comparator(){
				public int compare(Object a, Object b) {
				
				String aTokens[] = ((RowBean)a).getCol2().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol2().trim().split("-");
					
				int noOfTokens = aTokens.length;
					
				for(int i = 0; i < noOfTokens; i++){
						
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
							
						if(aVal > bVal){
							return -1;
						}
						if(aVal < bVal){
							return 1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return -1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return 1;
						}						
					}
						
				}
				return 0;
				}
				}

		 	);
	    }
	 	
	 	if(field.equalsIgnoreCase("col3") && order.equalsIgnoreCase("asc")){
		 	Collections.sort(dataVector, 
					new Comparator(){
				public int compare(Object a, Object b) {
				
				String aTokens[] = ((RowBean)a).getCol3().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol3().trim().split("-");
					
				int noOfTokens = aTokens.length;
					
				for(int i = 0; i < noOfTokens; i++){
						
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
							
						if(aVal > bVal){
							return 1;
						}
						if(aVal < bVal){
							return -1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return 1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return -1;
						}						
					}
						
				}
					
				return 0;
				}
				}

		 	);
	   }
	 	
	 	if(field.equalsIgnoreCase("col3") && order.equalsIgnoreCase("dec")){
		 	Collections.sort(dataVector, 
					new Comparator(){
				public int compare(Object a, Object b) {
				
				String aTokens[] = ((RowBean)a).getCol3().trim().split("-");
				String bTokens[] = ((RowBean)b).getCol3().trim().split("-");
					
				int noOfTokens = aTokens.length;
					
				for(int i = 0; i < noOfTokens; i++){
						
					try{
						int aVal = Integer.parseInt(aTokens[i]);
						int bVal = Integer.parseInt(bTokens[i]);
							
						if(aVal > bVal){
							return -1;
						}
						if(aVal < bVal){
							return 1;
						}
					}
					catch(Exception ex){
						//**These are probably just Strings...
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) > 0 ){
							return -1;
						}
						if(aTokens[i].compareToIgnoreCase(bTokens[i]) < 0 ){
							return 1;
						}						
					}
						
				}
					
				return 0;
				}
				}

		 	);
	 	}	
	 	
	 }
	 
	 /**
	  * Returns the Exporting data...
	  * 
	  * @return ExportBean (col, data and #ofFields)
	  */
	 public static  ExportBean getExportData(){	 	
	 	return exportBean;
	 }
	
}
