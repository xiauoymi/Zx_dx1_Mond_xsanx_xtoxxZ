/**
 * Reporting Tool (RowBean) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

/**
 * RowBean: This is the class/object used to fill in the Data. The object of this class
 * has to be present in the HashMap taken by the report tag.
 * 
 * @author Rasesh Desai
 *
 */
public class RowBean {
	
	String col1;
	String col2;
	String col3;
	String col4;
	String col5;
	String col6;
	String col7;
	String col8;
	String col9;
	String col10;
	
	String col11;
	String col12;
	String col13;
	String col14;
	String col15;
	String col16;
	String col17;
	String col18;
	String col19;
	String col20;
	
	String col21;
	String col22;
	String col23;
	String col24;
	String col25;
	String col26;
	String col27;
	String col28;
	String col29;
	String col30;
	
	String col31;
	String col32;
	String col33;
	String col34;
	String col35;
	String col36;
	String col37;
	String col38;
	String col39;
	String col40;
	
	String col41;
	String col42;
	String col43;
	String col44;
	String col45;
	String col46;
	String col47;
	String col48;
	String col49;
	String col50;
	
	String col51;
	String col52;
	String col53;
	String col54;
	String col55;
	String col56;
	String col57;
	String col58;
	String col59;
	String col60;
	
	String col61;
	String col62;
	String col63;
	String col64;
	String col65;
	String col66;
	String col67;
	String col68;
	String col69;
	String col70;
	
	String col71;
	String col72;
	String col73;
	String col74;
	String col75;
	String col76;
	String col77;
	String col78;
	String col79;
	String col80;
	
	String col81;
	String col82;
	String col83;
	String col84;
	String col85;
	String col86;
	String col87;
	String col88;
	String col89;
	String col90;
	
	String col91;
	String col92;
	String col93;
	String col94;
	String col95;
	String col96;
	String col97;
	String col98;
	String col99;
	String col100;
	
	
	
	
	/**
	 * @return Returns the col51.
	 */
	public String getCol51() {
		return col51;
	}
	/**
	 * @param col51 The col51 to set.
	 */
	public void setCol51(String col51) {
		this.col51 = col51;
	}
	/**
	 * @return Returns the col52.
	 */
	public String getCol52() {
		return col52;
	}
	/**
	 * @param col52 The col52 to set.
	 */
	public void setCol52(String col52) {
		this.col52 = col52;
	}
	/**
	 * @return Returns the col53.
	 */
	public String getCol53() {
		return col53;
	}
	/**
	 * @param col53 The col53 to set.
	 */
	public void setCol53(String col53) {
		this.col53 = col53;
	}
	/**
	 * @return Returns the col54.
	 */
	public String getCol54() {
		return col54;
	}
	/**
	 * @param col54 The col54 to set.
	 */
	public void setCol54(String col54) {
		this.col54 = col54;
	}
	/**
	 * @return Returns the col55.
	 */
	public String getCol55() {
		return col55;
	}
	/**
	 * @param col55 The col55 to set.
	 */
	public void setCol55(String col55) {
		this.col55 = col55;
	}
	/**
	 * @return Returns the col56.
	 */
	public String getCol56() {
		return col56;
	}
	/**
	 * @param col56 The col56 to set.
	 */
	public void setCol56(String col56) {
		this.col56 = col56;
	}
	/**
	 * @return Returns the col57.
	 */
	public String getCol57() {
		return col57;
	}
	/**
	 * @param col57 The col57 to set.
	 */
	public void setCol57(String col57) {
		this.col57 = col57;
	}
	/**
	 * @return Returns the col58.
	 */
	public String getCol58() {
		return col58;
	}
	/**
	 * @param col58 The col58 to set.
	 */
	public void setCol58(String col58) {
		this.col58 = col58;
	}
	/**
	 * @return Returns the col59.
	 */
	public String getCol59() {
		return col59;
	}
	/**
	 * @param col59 The col59 to set.
	 */
	public void setCol59(String col59) {
		this.col59 = col59;
	}
	/**
	 * @return Returns the col60.
	 */
	public String getCol60() {
		return col60;
	}
	/**
	 * @param col60 The col60 to set.
	 */
	public void setCol60(String col60) {
		this.col60 = col60;
	}
	/**
	 * @return Returns the col1.
	 */
	public String getCol1() {
		return col1;
	}
	/**
	 * @param col1 The col1 to set.
	 */
	public void setCol1(String col1) {
		this.col1 = col1;
	}
	/**
	 * @return Returns the col10.
	 */
	public String getCol10() {
		return col10;
	}
	/**
	 * @param col10 The col10 to set.
	 */
	public void setCol10(String col10) {
		this.col10 = col10;
	}
	/**
	 * @return Returns the col100.
	 */
	public String getCol100() {
		return col100;
	}
	/**
	 * @param col100 The col100 to set.
	 */
	public void setCol100(String col100) {
		this.col100 = col100;
	}
	/**
	 * @return Returns the col11.
	 */
	public String getCol11() {
		return col11;
	}
	/**
	 * @param col11 The col11 to set.
	 */
	public void setCol11(String col11) {
		this.col11 = col11;
	}
	/**
	 * @return Returns the col12.
	 */
	public String getCol12() {
		return col12;
	}
	/**
	 * @param col12 The col12 to set.
	 */
	public void setCol12(String col12) {
		this.col12 = col12;
	}
	/**
	 * @return Returns the col13.
	 */
	public String getCol13() {
		return col13;
	}
	/**
	 * @param col13 The col13 to set.
	 */
	public void setCol13(String col13) {
		this.col13 = col13;
	}
	/**
	 * @return Returns the col14.
	 */
	public String getCol14() {
		return col14;
	}
	/**
	 * @param col14 The col14 to set.
	 */
	public void setCol14(String col14) {
		this.col14 = col14;
	}
	/**
	 * @return Returns the col15.
	 */
	public String getCol15() {
		return col15;
	}
	/**
	 * @param col15 The col15 to set.
	 */
	public void setCol15(String col15) {
		this.col15 = col15;
	}
	/**
	 * @return Returns the col16.
	 */
	public String getCol16() {
		return col16;
	}
	/**
	 * @param col16 The col16 to set.
	 */
	public void setCol16(String col16) {
		this.col16 = col16;
	}
	/**
	 * @return Returns the col17.
	 */
	public String getCol17() {
		return col17;
	}
	/**
	 * @param col17 The col17 to set.
	 */
	public void setCol17(String col17) {
		this.col17 = col17;
	}
	/**
	 * @return Returns the col18.
	 */
	public String getCol18() {
		return col18;
	}
	/**
	 * @param col18 The col18 to set.
	 */
	public void setCol18(String col18) {
		this.col18 = col18;
	}
	/**
	 * @return Returns the col19.
	 */
	public String getCol19() {
		return col19;
	}
	/**
	 * @param col19 The col19 to set.
	 */
	public void setCol19(String col19) {
		this.col19 = col19;
	}
	/**
	 * @return Returns the col2.
	 */
	public String getCol2() {
		return col2;
	}
	/**
	 * @param col2 The col2 to set.
	 */
	public void setCol2(String col2) {
		this.col2 = col2;
	}
	/**
	 * @return Returns the col20.
	 */
	public String getCol20() {
		return col20;
	}
	/**
	 * @param col20 The col20 to set.
	 */
	public void setCol20(String col20) {
		this.col20 = col20;
	}
	/**
	 * @return Returns the col21.
	 */
	public String getCol21() {
		return col21;
	}
	/**
	 * @param col21 The col21 to set.
	 */
	public void setCol21(String col21) {
		this.col21 = col21;
	}
	/**
	 * @return Returns the col22.
	 */
	public String getCol22() {
		return col22;
	}
	/**
	 * @param col22 The col22 to set.
	 */
	public void setCol22(String col22) {
		this.col22 = col22;
	}
	/**
	 * @return Returns the col23.
	 */
	public String getCol23() {
		return col23;
	}
	/**
	 * @param col23 The col23 to set.
	 */
	public void setCol23(String col23) {
		this.col23 = col23;
	}
	/**
	 * @return Returns the col24.
	 */
	public String getCol24() {
		return col24;
	}
	/**
	 * @param col24 The col24 to set.
	 */
	public void setCol24(String col24) {
		this.col24 = col24;
	}
	/**
	 * @return Returns the col25.
	 */
	public String getCol25() {
		return col25;
	}
	/**
	 * @param col25 The col25 to set.
	 */
	public void setCol25(String col25) {
		this.col25 = col25;
	}
	/**
	 * @return Returns the col26.
	 */
	public String getCol26() {
		return col26;
	}
	/**
	 * @param col26 The col26 to set.
	 */
	public void setCol26(String col26) {
		this.col26 = col26;
	}
	/**
	 * @return Returns the col27.
	 */
	public String getCol27() {
		return col27;
	}
	/**
	 * @param col27 The col27 to set.
	 */
	public void setCol27(String col27) {
		this.col27 = col27;
	}
	/**
	 * @return Returns the col28.
	 */
	public String getCol28() {
		return col28;
	}
	/**
	 * @param col28 The col28 to set.
	 */
	public void setCol28(String col28) {
		this.col28 = col28;
	}
	/**
	 * @return Returns the col29.
	 */
	public String getCol29() {
		return col29;
	}
	/**
	 * @param col29 The col29 to set.
	 */
	public void setCol29(String col29) {
		this.col29 = col29;
	}
	/**
	 * @return Returns the col3.
	 */
	public String getCol3() {
		return col3;
	}
	/**
	 * @param col3 The col3 to set.
	 */
	public void setCol3(String col3) {
		this.col3 = col3;
	}
	/**
	 * @return Returns the col30.
	 */
	public String getCol30() {
		return col30;
	}
	/**
	 * @param col30 The col30 to set.
	 */
	public void setCol30(String col30) {
		this.col30 = col30;
	}
	/**
	 * @return Returns the col31.
	 */
	public String getCol31() {
		return col31;
	}
	/**
	 * @param col31 The col31 to set.
	 */
	public void setCol31(String col31) {
		this.col31 = col31;
	}
	/**
	 * @return Returns the col32.
	 */
	public String getCol32() {
		return col32;
	}
	/**
	 * @param col32 The col32 to set.
	 */
	public void setCol32(String col32) {
		this.col32 = col32;
	}
	/**
	 * @return Returns the col33.
	 */
	public String getCol33() {
		return col33;
	}
	/**
	 * @param col33 The col33 to set.
	 */
	public void setCol33(String col33) {
		this.col33 = col33;
	}
	/**
	 * @return Returns the col34.
	 */
	public String getCol34() {
		return col34;
	}
	/**
	 * @param col34 The col34 to set.
	 */
	public void setCol34(String col34) {
		this.col34 = col34;
	}
	/**
	 * @return Returns the col35.
	 */
	public String getCol35() {
		return col35;
	}
	/**
	 * @param col35 The col35 to set.
	 */
	public void setCol35(String col35) {
		this.col35 = col35;
	}
	/**
	 * @return Returns the col36.
	 */
	public String getCol36() {
		return col36;
	}
	/**
	 * @param col36 The col36 to set.
	 */
	public void setCol36(String col36) {
		this.col36 = col36;
	}
	/**
	 * @return Returns the col37.
	 */
	public String getCol37() {
		return col37;
	}
	/**
	 * @param col37 The col37 to set.
	 */
	public void setCol37(String col37) {
		this.col37 = col37;
	}
	/**
	 * @return Returns the col38.
	 */
	public String getCol38() {
		return col38;
	}
	/**
	 * @param col38 The col38 to set.
	 */
	public void setCol38(String col38) {
		this.col38 = col38;
	}
	/**
	 * @return Returns the col39.
	 */
	public String getCol39() {
		return col39;
	}
	/**
	 * @param col39 The col39 to set.
	 */
	public void setCol39(String col39) {
		this.col39 = col39;
	}
	/**
	 * @return Returns the col4.
	 */
	public String getCol4() {
		return col4;
	}
	/**
	 * @param col4 The col4 to set.
	 */
	public void setCol4(String col4) {
		this.col4 = col4;
	}
	/**
	 * @return Returns the col40.
	 */
	public String getCol40() {
		return col40;
	}
	/**
	 * @param col40 The col40 to set.
	 */
	public void setCol40(String col40) {
		this.col40 = col40;
	}
	/**
	 * @return Returns the col41.
	 */
	public String getCol41() {
		return col41;
	}
	/**
	 * @param col41 The col41 to set.
	 */
	public void setCol41(String col41) {
		this.col41 = col41;
	}
	/**
	 * @return Returns the col42.
	 */
	public String getCol42() {
		return col42;
	}
	/**
	 * @param col42 The col42 to set.
	 */
	public void setCol42(String col42) {
		this.col42 = col42;
	}
	/**
	 * @return Returns the col43.
	 */
	public String getCol43() {
		return col43;
	}
	/**
	 * @param col43 The col43 to set.
	 */
	public void setCol43(String col43) {
		this.col43 = col43;
	}
	/**
	 * @return Returns the col44.
	 */
	public String getCol44() {
		return col44;
	}
	/**
	 * @param col44 The col44 to set.
	 */
	public void setCol44(String col44) {
		this.col44 = col44;
	}
	/**
	 * @return Returns the col45.
	 */
	public String getCol45() {
		return col45;
	}
	/**
	 * @param col45 The col45 to set.
	 */
	public void setCol45(String col45) {
		this.col45 = col45;
	}
	/**
	 * @return Returns the col46.
	 */
	public String getCol46() {
		return col46;
	}
	/**
	 * @param col46 The col46 to set.
	 */
	public void setCol46(String col46) {
		this.col46 = col46;
	}
	/**
	 * @return Returns the col47.
	 */
	public String getCol47() {
		return col47;
	}
	/**
	 * @param col47 The col47 to set.
	 */
	public void setCol47(String col47) {
		this.col47 = col47;
	}
	/**
	 * @return Returns the col48.
	 */
	public String getCol48() {
		return col48;
	}
	/**
	 * @param col48 The col48 to set.
	 */
	public void setCol48(String col48) {
		this.col48 = col48;
	}
	/**
	 * @return Returns the col49.
	 */
	public String getCol49() {
		return col49;
	}
	/**
	 * @param col49 The col49 to set.
	 */
	public void setCol49(String col49) {
		this.col49 = col49;
	}
	/**
	 * @return Returns the col5.
	 */
	public String getCol5() {
		return col5;
	}
	/**
	 * @param col5 The col5 to set.
	 */
	public void setCol5(String col5) {
		this.col5 = col5;
	}
	/**
	 * @return Returns the col50.
	 */
	public String getCol50() {
		return col50;
	}
	/**
	 * @param col50 The col50 to set.
	 */
	public void setCol50(String col50) {
		this.col50 = col50;
	}
	/**
	 * @return Returns the col6.
	 */
	public String getCol6() {
		return col6;
	}
	/**
	 * @param col6 The col6 to set.
	 */
	public void setCol6(String col6) {
		this.col6 = col6;
	}
	/**
	 * @return Returns the col61.
	 */
	public String getCol61() {
		return col61;
	}
	/**
	 * @param col61 The col61 to set.
	 */
	public void setCol61(String col61) {
		this.col61 = col61;
	}
	/**
	 * @return Returns the col62.
	 */
	public String getCol62() {
		return col62;
	}
	/**
	 * @param col62 The col62 to set.
	 */
	public void setCol62(String col62) {
		this.col62 = col62;
	}
	/**
	 * @return Returns the col63.
	 */
	public String getCol63() {
		return col63;
	}
	/**
	 * @param col63 The col63 to set.
	 */
	public void setCol63(String col63) {
		this.col63 = col63;
	}
	/**
	 * @return Returns the col64.
	 */
	public String getCol64() {
		return col64;
	}
	/**
	 * @param col64 The col64 to set.
	 */
	public void setCol64(String col64) {
		this.col64 = col64;
	}
	/**
	 * @return Returns the col65.
	 */
	public String getCol65() {
		return col65;
	}
	/**
	 * @param col65 The col65 to set.
	 */
	public void setCol65(String col65) {
		this.col65 = col65;
	}
	/**
	 * @return Returns the col66.
	 */
	public String getCol66() {
		return col66;
	}
	/**
	 * @param col66 The col66 to set.
	 */
	public void setCol66(String col66) {
		this.col66 = col66;
	}
	/**
	 * @return Returns the col67.
	 */
	public String getCol67() {
		return col67;
	}
	/**
	 * @param col67 The col67 to set.
	 */
	public void setCol67(String col67) {
		this.col67 = col67;
	}
	/**
	 * @return Returns the col68.
	 */
	public String getCol68() {
		return col68;
	}
	/**
	 * @param col68 The col68 to set.
	 */
	public void setCol68(String col68) {
		this.col68 = col68;
	}
	/**
	 * @return Returns the col69.
	 */
	public String getCol69() {
		return col69;
	}
	/**
	 * @param col69 The col69 to set.
	 */
	public void setCol69(String col69) {
		this.col69 = col69;
	}
	/**
	 * @return Returns the col7.
	 */
	public String getCol7() {
		return col7;
	}
	/**
	 * @param col7 The col7 to set.
	 */
	public void setCol7(String col7) {
		this.col7 = col7;
	}
	/**
	 * @return Returns the col70.
	 */
	public String getCol70() {
		return col70;
	}
	/**
	 * @param col70 The col70 to set.
	 */
	public void setCol70(String col70) {
		this.col70 = col70;
	}
	/**
	 * @return Returns the col71.
	 */
	public String getCol71() {
		return col71;
	}
	/**
	 * @param col71 The col71 to set.
	 */
	public void setCol71(String col71) {
		this.col71 = col71;
	}
	/**
	 * @return Returns the col72.
	 */
	public String getCol72() {
		return col72;
	}
	/**
	 * @param col72 The col72 to set.
	 */
	public void setCol72(String col72) {
		this.col72 = col72;
	}
	/**
	 * @return Returns the col73.
	 */
	public String getCol73() {
		return col73;
	}
	/**
	 * @param col73 The col73 to set.
	 */
	public void setCol73(String col73) {
		this.col73 = col73;
	}
	/**
	 * @return Returns the col74.
	 */
	public String getCol74() {
		return col74;
	}
	/**
	 * @param col74 The col74 to set.
	 */
	public void setCol74(String col74) {
		this.col74 = col74;
	}
	/**
	 * @return Returns the col75.
	 */
	public String getCol75() {
		return col75;
	}
	/**
	 * @param col75 The col75 to set.
	 */
	public void setCol75(String col75) {
		this.col75 = col75;
	}
	/**
	 * @return Returns the col76.
	 */
	public String getCol76() {
		return col76;
	}
	/**
	 * @param col76 The col76 to set.
	 */
	public void setCol76(String col76) {
		this.col76 = col76;
	}
	/**
	 * @return Returns the col77.
	 */
	public String getCol77() {
		return col77;
	}
	/**
	 * @param col77 The col77 to set.
	 */
	public void setCol77(String col77) {
		this.col77 = col77;
	}
	/**
	 * @return Returns the col78.
	 */
	public String getCol78() {
		return col78;
	}
	/**
	 * @param col78 The col78 to set.
	 */
	public void setCol78(String col78) {
		this.col78 = col78;
	}
	/**
	 * @return Returns the col79.
	 */
	public String getCol79() {
		return col79;
	}
	/**
	 * @param col79 The col79 to set.
	 */
	public void setCol79(String col79) {
		this.col79 = col79;
	}
	/**
	 * @return Returns the col8.
	 */
	public String getCol8() {
		return col8;
	}
	/**
	 * @param col8 The col8 to set.
	 */
	public void setCol8(String col8) {
		this.col8 = col8;
	}
	/**
	 * @return Returns the col80.
	 */
	public String getCol80() {
		return col80;
	}
	/**
	 * @param col80 The col80 to set.
	 */
	public void setCol80(String col80) {
		this.col80 = col80;
	}
	/**
	 * @return Returns the col81.
	 */
	public String getCol81() {
		return col81;
	}
	/**
	 * @param col81 The col81 to set.
	 */
	public void setCol81(String col81) {
		this.col81 = col81;
	}
	/**
	 * @return Returns the col82.
	 */
	public String getCol82() {
		return col82;
	}
	/**
	 * @param col82 The col82 to set.
	 */
	public void setCol82(String col82) {
		this.col82 = col82;
	}
	/**
	 * @return Returns the col83.
	 */
	public String getCol83() {
		return col83;
	}
	/**
	 * @param col83 The col83 to set.
	 */
	public void setCol83(String col83) {
		this.col83 = col83;
	}
	/**
	 * @return Returns the col84.
	 */
	public String getCol84() {
		return col84;
	}
	/**
	 * @param col84 The col84 to set.
	 */
	public void setCol84(String col84) {
		this.col84 = col84;
	}
	/**
	 * @return Returns the col85.
	 */
	public String getCol85() {
		return col85;
	}
	/**
	 * @param col85 The col85 to set.
	 */
	public void setCol85(String col85) {
		this.col85 = col85;
	}
	/**
	 * @return Returns the col86.
	 */
	public String getCol86() {
		return col86;
	}
	/**
	 * @param col86 The col86 to set.
	 */
	public void setCol86(String col86) {
		this.col86 = col86;
	}
	/**
	 * @return Returns the col87.
	 */
	public String getCol87() {
		return col87;
	}
	/**
	 * @param col87 The col87 to set.
	 */
	public void setCol87(String col87) {
		this.col87 = col87;
	}
	/**
	 * @return Returns the col88.
	 */
	public String getCol88() {
		return col88;
	}
	/**
	 * @param col88 The col88 to set.
	 */
	public void setCol88(String col88) {
		this.col88 = col88;
	}
	/**
	 * @return Returns the col89.
	 */
	public String getCol89() {
		return col89;
	}
	/**
	 * @param col89 The col89 to set.
	 */
	public void setCol89(String col89) {
		this.col89 = col89;
	}
	/**
	 * @return Returns the col9.
	 */
	public String getCol9() {
		return col9;
	}
	/**
	 * @param col9 The col9 to set.
	 */
	public void setCol9(String col9) {
		this.col9 = col9;
	}
	/**
	 * @return Returns the col90.
	 */
	public String getCol90() {
		return col90;
	}
	/**
	 * @param col90 The col90 to set.
	 */
	public void setCol90(String col90) {
		this.col90 = col90;
	}
	/**
	 * @return Returns the col91.
	 */
	public String getCol91() {
		return col91;
	}
	/**
	 * @param col91 The col91 to set.
	 */
	public void setCol91(String col91) {
		this.col91 = col91;
	}
	/**
	 * @return Returns the col92.
	 */
	public String getCol92() {
		return col92;
	}
	/**
	 * @param col92 The col92 to set.
	 */
	public void setCol92(String col92) {
		this.col92 = col92;
	}
	/**
	 * @return Returns the col93.
	 */
	public String getCol93() {
		return col93;
	}
	/**
	 * @param col93 The col93 to set.
	 */
	public void setCol93(String col93) {
		this.col93 = col93;
	}
	/**
	 * @return Returns the col94.
	 */
	public String getCol94() {
		return col94;
	}
	/**
	 * @param col94 The col94 to set.
	 */
	public void setCol94(String col94) {
		this.col94 = col94;
	}
	/**
	 * @return Returns the col95.
	 */
	public String getCol95() {
		return col95;
	}
	/**
	 * @param col95 The col95 to set.
	 */
	public void setCol95(String col95) {
		this.col95 = col95;
	}
	/**
	 * @return Returns the col96.
	 */
	public String getCol96() {
		return col96;
	}
	/**
	 * @param col96 The col96 to set.
	 */
	public void setCol96(String col96) {
		this.col96 = col96;
	}
	/**
	 * @return Returns the col97.
	 */
	public String getCol97() {
		return col97;
	}
	/**
	 * @param col97 The col97 to set.
	 */
	public void setCol97(String col97) {
		this.col97 = col97;
	}
	/**
	 * @return Returns the col98.
	 */
	public String getCol98() {
		return col98;
	}
	/**
	 * @param col98 The col98 to set.
	 */
	public void setCol98(String col98) {
		this.col98 = col98;
	}
	/**
	 * @return Returns the col99.
	 */
	public String getCol99() {
		return col99;
	}
	/**
	 * @param col99 The col99 to set.
	 */
	public void setCol99(String col99) {
		this.col99 = col99;
	}
}
