/**
 * Reporting Tool(XmlParser) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag;

import java.io.InputStream;

import org.apache.commons.digester.Digester;
import org.apache.log4j.Category;

import com.monsanto.wst.breedingcomplaintsaudits.exception.XmlExceptionHandler;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;


/**
 * XmlParser: This class uses the Jakarata Digester Framework to parse the report structure file.
 * 
 * @author Rasesh Desai
 */
public class XmlParser {
	
	static Category logger = Category.getInstance(XmlParser.class.getName());
	
	public ReportBean getParsedXmlBean(InputStream xmlInputStr){
		
		xmlInputStr.mark(0);
		
		InputStream xmlIn = xmlInputStr;
		
		ReportBean  report = new ReportBean();
		
		try{			
			Digester digester = new Digester();
			
			//**Custom Error Handler...
			XmlExceptionHandler xmlHandler = new XmlExceptionHandler();
			digester.setErrorHandler(xmlHandler);
			
			//**Validating Xml against Schema...
			digester.setNamespaceAware(true);
			digester.register("http://java.sun.com/xml/jaxp/properties/schemaLanguage", 
					"http://www.w3.org/2001/XMLSchema"); 
			digester.setSchema(McasProperties.getMcasProperties().getString("schemaLocation"));
			digester.setValidating(true);				
		
			digester.addObjectCreate("report", ReportBean.class);
			digester.addSetProperties("report", "width", "width");
			digester.addBeanPropertySetter("report/title", "title");
			digester.addBeanPropertySetter("report/titleColor", "titleColor");
			digester.addBeanPropertySetter("report/titleFont", "titleFont");
			digester.addBeanPropertySetter("report/titleBold", "titleBold");
			digester.addBeanPropertySetter("report/titleUnderline", "titleUnderline");
			digester.addBeanPropertySetter("report/cellSpacing", "cellSpacing");
			digester.addBeanPropertySetter("report/cellPadding", "cellPadding");
			digester.addBeanPropertySetter("report/border", "border");
			digester.addBeanPropertySetter("report/headerHeight", "headerHeight");
			digester.addBeanPropertySetter("report/rowHeight", "rowHeight");
		
			digester.addBeanPropertySetter("report/tableClass", "tableClass");
		
			digester.addBeanPropertySetter("report/headerAlign", "headerAlign");
			digester.addBeanPropertySetter("report/headerValign", "headerValign");
			digester.addBeanPropertySetter("report/headerTextColor", "headerTextColor");
			digester.addBeanPropertySetter("report/headerTextSize", "headerTextSize");
			digester.addBeanPropertySetter("report/headerBgColor", "headerBgColor");
			digester.addBeanPropertySetter("report/headerFont", "headerFont");
			digester.addBeanPropertySetter("report/headerBold", "headerBold");
			digester.addBeanPropertySetter("report/headerUnderline", "headerUnderline");
			digester.addBeanPropertySetter("report/headerClass", "headerClass");
			digester.addBeanPropertySetter("report/headerNowrap", "headerNowrap");
			digester.addBeanPropertySetter("report/excelFileName", "excelFileName");
			digester.addBeanPropertySetter("report/excelSheetName", "excelSheetName");
			
			digester.addObjectCreate("report/column", ColumnBean.class);
			digester.addSetProperties("report/column", "colWidth", "colWidth");
			digester.addBeanPropertySetter("report/column/name", "name");
			digester.addBeanPropertySetter("report/column/mappingField", "mappingField");
			digester.addBeanPropertySetter("report/column/type", "type");
			digester.addBeanPropertySetter("report/column/align", "align");
			digester.addBeanPropertySetter("report/column/valign", "valign");
			digester.addBeanPropertySetter("report/column/textColor", "textColor");
			digester.addBeanPropertySetter("report/column/textSize", "textSize");
			digester.addBeanPropertySetter("report/column/bgColor", "bgColor");
			digester.addBeanPropertySetter("report/column/font", "font");
			digester.addBeanPropertySetter("report/column/bold", "bold");
			digester.addBeanPropertySetter("report/column/underline", "underline");
			digester.addBeanPropertySetter("report/column/class", "cssClass");
			digester.addBeanPropertySetter("report/column/nowrap", "nowrap");
			digester.addBeanPropertySetter("report/column/dataLengthInChar", "dataLength");
			
			digester.addSetNext("report/column", "addColumn");
			
			report = (ReportBean)digester.parse(xmlIn);
			
			xmlInputStr.reset();			
			xmlInputStr.close();
			
			if(XmlExceptionHandler.ERROR_FLAG){
				logger.error("Error validating the Xml File against its schema.");
				ReportBean errorReport = new ReportBean();
				errorReport.setErrorFlag(true);
				errorReport.setErrorMsg(XmlExceptionHandler.ERROR_MSG);
				return errorReport;
			}

			logger.info("Done Parsing...");
			
			report.setErrorFlag(false);			
			return report;
			
		}
		catch(Exception ex){
			System.out.println("Error parsing the ReportStructure File.");
			return null;
		}
	}
	
}
