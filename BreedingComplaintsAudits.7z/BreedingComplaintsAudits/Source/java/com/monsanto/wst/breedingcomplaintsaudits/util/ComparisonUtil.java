/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.util;

import com.monsanto.Util.StringUtils;

/**
 * Filename:    $RCSfile: ComparisonUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 20:31:14 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class ComparisonUtil {

  public static boolean unequal(boolean booleanVar1, boolean booleanVar2) {
    return booleanVar1 != booleanVar2;
  }

  /**
   * This is a result of invalid data found while comparing FormBean Objects with the ones retrieved from Database (or DAOs).
   * FormBean returns empty strings or spaces while DAOs return nulls for the same field which looks identical.
   * Thus these both need to be considered as equal because it is not a change made by user.
   *
   * @throws Exception
   */
  public static boolean unequal(String stringVar1, String stringVar2) {
    return StringUtils.isNullOrEmpty(stringVar1) && !StringUtils.isNullOrEmpty(stringVar2)
            || StringUtils.isNullOrEmpty(stringVar2) && !StringUtils.isNullOrEmpty(stringVar1)
            || !StringUtils.isNullOrEmpty(stringVar1) && !StringUtils.isNullOrEmpty(stringVar2) && !stringVar1.equals(stringVar2);
  }
}