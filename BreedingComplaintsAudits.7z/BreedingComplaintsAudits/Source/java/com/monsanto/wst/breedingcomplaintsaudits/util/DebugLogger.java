/*
 DebugLogger was created on May 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.breedingcomplaintsaudits.util;

import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Filename:    $RCSfile: DebugLogger.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-09 16:57:55 $
 *
 * @author emgoode
 * @version $Revision: 1.1 $
 */
public class DebugLogger {

    public static Logger logger = Logger.getLogger(DebugLogger.class);

    public DebugLogger() {
        launchLogger();
    }

    public static void launchLogger() {
        RollingFileAppender appender = null;
        try {
            appender = new RollingFileAppender(new PatternLayout("[%d %p] - %m %n"), "C:/TEMP/MCAS_DEBUG.log");
            appender.setMaxFileSize("1024");
        }
        catch (Exception e) {
            System.out.println("THREW AN ERROR");
            e.printStackTrace();
        }

        if (appender == null) {
            System.out.println("APPENDER IS NULL!");
        }

        System.out.println("Logger is Initialized...");

        logger.addAppender(appender);
        logger.setLevel((Level) Level.DEBUG);

        logger.debug("DEBUG LOGGING IS TUNRED ON!!!");
    }



}