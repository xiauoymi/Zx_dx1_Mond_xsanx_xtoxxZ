/*
 * Created on Jan 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.Util.StringUtils;
import org.apache.log4j.Category;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailUtil {

  //**Log4j logger
  static Category logger = Category.getInstance(EmailUtil.class.getName());

  static String host = null;
  String from = "";
  String to = "";
  String cc = "";
  String bcc = "";
  String body = "Welcome to JavaMail";
  String subject = "Hello JavaMail";

  public EmailUtil() {
    super();
    if (host == null) {
      host = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.mail.host");
    }
  }

  public boolean sendMail() throws Exception {
    boolean result = true;
    try {
      Properties props = System.getProperties();
      String hostPropertyName = "mail.smtp.host";
      props.put(hostPropertyName, host);
      if(StringUtils.isNullOrEmpty(host)) {
        logger.error("Error sending email: Property '" + hostPropertyName + "' is missing in ApplicationResources.properties.");
      }
      Session session = Session.getDefaultInstance(props, null);
      MimeMessage message = new MimeMessage(session);
      setFromOnMessage(message);
      setTOOnMessage(message);
      setCCOnMessage(message);
      setBCCOnMessage(message);
      message.setSubject(subject);
      message.setText(body);
      Transport.send(message);
    }
    catch (MessagingException me) {
      result = false;
      logger.error("MessagingException occured while sending email message: " + me.getMessage(), me);
    }
    catch (Exception e) {
      result = false;
      logger.error("Exception occured while sending email message: " + e.getMessage(), e);
    }
    return result;
  }

  /**
   * @return Returns the from.
   */
  public String getFrom() {
    return from;
  }

  /**
   * @param from The from to set.
   */
  public void setFrom(String from) {
    this.from = from;
  }

  /**
   * @return Returns the to.
   */
  public String getTo() {
    return to;
  }

  /**
   * @param to The to to set.
   */
  public void setTo(String to) {
    this.to = to;
  }

  /**
   * @param to The to to set.
   */
  public void appendTo(String to) {
    if (!(this.to.equals("")))
      this.to = this.to + "," + to;
  }

  /**
   * @return Returns the subject.
   */
  public String getSubject() {
    return subject;
  }

  /**
   * @param subject The subject to set.
   */
  public void setSubject(String subject) {
    this.subject = subject;
  }

  /**
   * @return Returns the body.
   */
  public String getBody() {
    return body;
  }

  /**
   * @param body The body to set.
   */
  public void setBody(String body) {
    this.body = body;
  }

  /**
   * @return Returns the bcc.
   */
  public String getBcc() {
    return bcc;
  }

  /**
   * @param bcc The bcc to set.
   */
  public void setBcc(String bcc) {
    this.bcc = bcc;
  }

  /**
   * @return Returns the cc.
   */
  public String getCc() {
    return cc;
  }

  /**
   * @param cc The cc to set.
   */
  public void setCc(String cc) {
    this.cc = cc;
  }

  /**
   * @param to The to to set.
   */
  public void appendCC(String cc) {
    if (!(this.cc.equals("")))
      this.cc = this.cc + "," + cc;
  }

  /**
   * @param to The to to set.
   */
  public void appendBCC(String bcc) {
    if (!(this.bcc.equals("")))
      this.bcc = this.bcc + "," + bcc;
  }

  private void setBCCOnMessage(MimeMessage message) throws MessagingException {
    if (!(this.bcc.equals(""))) {
      message.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc));
    }
  }

  private void setCCOnMessage(MimeMessage message) throws MessagingException {
    if (!(this.cc.equals(""))) {
      message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
    }
  }

  private void setTOOnMessage(MimeMessage message) throws MessagingException {
    if(StringUtils.isNullOrEmpty(to)) {
      logger.error("Error sending email: Recipient (TO) email address missing. Please check for previous errors.");
    }
    message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
  }

  private void setFromOnMessage(MimeMessage message) throws MessagingException {
    if(StringUtils.isNullOrEmpty(from)) {
      logger.error("Error sending email: Sender email address missing. Please set 'E_MAIL' field in LOCATION_REF table for LocationCode 'ADMN' with a valid admin email address.");
    }
    message.setFrom(new InternetAddress(from));
  }
}
