/*
 McasCalendar was created on Mar 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.breedingcomplaintsaudits.util;

import java.util.GregorianCalendar;
import java.util.Date;
import java.util.Calendar;

/**
 * Filename:    $RCSfile: McasCalendar.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-08-09 16:57:55 $
 *
 * @author emgoode
 * @version $Revision: 1.1 $
 */
public class McasCalendar extends GregorianCalendar {

    public static Date theCurrentDate = new Date(System.currentTimeMillis());

    //TODO create offset constructor

    public McasCalendar() {
        this.setTimeInMillis(System.currentTimeMillis());
    }

    public McasCalendar(long lTime) {
        this.setTimeInMillis(lTime);
    }

    public int getMonth() {
        return get(Calendar.MONTH) + 1;
    }

    public int getDay() {
        return get(Calendar.DAY_OF_MONTH);
    }

    public int getYear() {
        return get(Calendar.YEAR);
    }

    public int getHours() {
        return get(Calendar.HOUR_OF_DAY);
    }

    public int getMinutes() {
        return get(Calendar.MINUTE);
    }

    public int getSeconds() {
        return get(Calendar.SECOND);
    }


}