/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.breedingcomplaintsaudits.util.test;

import junit.framework.TestCase;
import com.monsanto.wst.breedingcomplaintsaudits.util.ComparisonUtil;

/**
 * Filename:    $RCSfile: ComparisonUtil_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-26 20:31:14 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class ComparisonUtil_UT extends TestCase {

  public void testUnequal_BooleanVariables() throws Exception {
    assertTrue(ComparisonUtil.unequal(true, false));
    assertFalse(ComparisonUtil.unequal(true, true));
  }

  public void testUnequal_ReturnsFalse_LogicallyConsideringNullsAndSpacesAsEmptyValues() throws Exception {
    assertFalse(ComparisonUtil.unequal("", ""));
    assertFalse(ComparisonUtil.unequal(null, null));
    assertFalse(ComparisonUtil.unequal(null, ""));
    assertFalse(ComparisonUtil.unequal(null, "  "));
  }

  public void testUnequal_ReturnsTrue_IfStringsAreUnequal() throws Exception {
    assertTrue(ComparisonUtil.unequal(null, "val2"));
    assertTrue(ComparisonUtil.unequal("val1", ""));
    assertTrue(ComparisonUtil.unequal("val1", "val2"));
  }
}