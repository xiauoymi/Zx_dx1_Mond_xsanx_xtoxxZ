/*
 * Created on Feb 23, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.actions;

import com.monsanto.wst.breedingcomplaintsaudits.actionForms.CparForm;
import com.monsanto.wst.breedingcomplaintsaudits.actionForms.CparListForm;
import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparList;
import com.monsanto.wst.breedingcomplaintsaudits.model.User;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import com.monsanto.wst.breedingcomplaintsaudits.service.*;
import com.monsanto.wst.breedingcomplaintsaudits.util.EmailUtil;
import com.monsanto.Util.StringUtils;
import org.apache.log4j.Category;
import org.apache.struts.action.*;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class CparAction extends DispatchAction {

  //**Log4j logger
  static Category logger = Category.getInstance(AuditAction.class.getName());

  private String sortCriteria;
  private String sortOrder;

  private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

  public ActionForward cparList(ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response)
          throws Exception {

    //**Add selected page to session...
    String selectedPage = request.getParameter("selectedPage");
    if (selectedPage != null) {
      request.getSession().setAttribute("selectedPage", selectedPage);
    } else {
      request.getSession().setAttribute("selectedPage", "1");
    }
    LinkedHashMap cparsList = null;
    float pages = 0;
    HttpSession session = request.getSession();
    if (request.getParameter("isSorting").toString().equals("false")) {
      sortCriteria = request.getParameter("sortCriteria");
      sortOrder = request.getParameter("sortOrder");
      request.getSession().setAttribute("lastCparSortCriteria", sortCriteria);
      request.getSession().setAttribute("lastCparSortOrder", sortOrder);
    } else {
      getSortValues(request);
    }
    getCparFormDefaults(request);
    CparListForm cf = (CparListForm) form;
    if (session.getAttribute("iscar") != null && !(session.getAttribute("iscar").equals(null)) && !(session.getAttribute("iscar").equals(request.getParameter("iscar")))) {
// 			Reset CaprListForm for this case if CAR/PAR switch.    		
      cf.reset();
    }
    session.setAttribute("iscar", request.getParameter("iscar"));
    String carFlag;
    int pageNumber;
    if (request.getParameter("iscar").equals("true")) {
      carFlag = "Y";
    } else {
      carFlag = "N";
    }
    if (!(request.getParameter("pageNumber").equals(null)) && request.getParameter("reset").equals("false")) {
      pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
      try {
        CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
        cparsList = cs.getCparsList(cf.getControlNumber().trim(), cf.getCreateDateFrom(), cf.getCreateDateTo(), cf.getInitiatedBy().trim(), cf.getStatus(), cf.getRegion(), cf.getClaimNumber().trim(), carFlag, cf.getFilingLocation(), cf.getResponsibleLocation(), cf.getIsoStandard(), request.getParameter("pageNumber"), Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder);
      }
      catch (Exception e) {
        e.printStackTrace();
        throw new Exception(e);
      }
      if ("true".equals(request.getParameter("getMax"))) {
        session.setAttribute("pageNumber", "1");
      } else {
        if (pageNumber < 11 && pageNumber > 0)
          session.setAttribute("pageNumber", "1");
        else
          session.setAttribute("pageNumber", request.getParameter("pageNumber"));
      }
    }
     if(cparsList != null && cparsList.size() >0){
      pages = Float.parseFloat(cparsList.get("maxRows").toString());
      cparsList.remove("maxRows");
      if (cparsList.size() > 0 && pages > 0) {
        cf.setCparsList(cparsList);
        session.setAttribute("pages", new Float(pages / 10));
      } else
        cf.setCparsList(null);
    } else {
      cf.setCparsList(null);
     }

    //**Reset sort-order
    //resetSortOrder(request);
    return (mapping.findForward("successList"));
  }

  public ActionForward cparNew(ActionMapping mapping,
                               ActionForm form,
                               HttpServletRequest request,
                               HttpServletResponse response)
          throws Exception {
    String forward;
    getCparFormDefaults(request);
    request.getSession().setAttribute("iscar", request.getParameter("iscar"));
    CparForm cf = (CparForm) form;
    Map map = request.getParameterMap();
    User user = (User) request.getSession().getAttribute("user");
    try {
      CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
      if (cf.getCpar() == null) {
        Cpar c = new Cpar();
        c.setCpar_id(cs.getCparPK());
        c.setRow_entry_date(sdf.format(new Date()));
        c.setCreated_by(user.getUser_id());
        c.setRow_user_id(user.getUser_id());
        c.setStatus_id("4");  //**Status: Open
        cf.setCpar(c);
      } else {
        cf.getCpar().setCpar_id(cs.getCparPK());
        cf.getCpar().setRow_entry_date(sdf.format(new Date()));
        cf.getCpar().setCreated_by(user.getUser_id());
        cf.getCpar().setRow_user_id(user.getUser_id());
        cf.getCpar().setStatus_id("4"); //**Status: Open
      }
      if (request.getParameter("iscar").equals("true")) {
        cf.getCpar().setCar_flag("Y");
        if (!(request.getParameter("createCAR") == null || request.getParameter("iscar").equals(null)) && request.getParameter("createCAR").equals("true")) {
          getCARData(request, cf.getCpar());  //**Gets the complaint details...
          request.setAttribute("msg", "false");
        }
      } else {
        cf.getCpar().setCar_flag("N");
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    getAuditStopSaleNumber(cf, request);
    forward = getForward(cf.getCpar());
    setCPAR(request, cf.getCpar());
    setEditValue(request, "cparNew");
    return (mapping.findForward(forward));
  }


  public ActionForward cparFindingNew(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response)
          throws Exception {
    String forward;
    getCparFormDefaults(request);
    request.getSession().setAttribute("iscar", request.getAttribute("iscar"));
    CparForm cf = (CparForm) form;
    Map map = request.getParameterMap();
    User user = (User) request.getSession().getAttribute("user");
    try {
      CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
      if (cf.getCpar() == null) {
        Cpar c = new Cpar();
        c.setCpar_id(cs.getCparPK());
        c.setRow_entry_date(sdf.format(new Date()));
        c.setCreated_by(user.getUser_id());
        c.setRow_user_id(user.getUser_id());
        c.setStatus_id("4");  //**Status: Open
        cf.setCpar(c);
      } else {
        cf.getCpar().setCpar_id(cs.getCparPK());
        cf.getCpar().setRow_entry_date(sdf.format(new Date()));
        cf.getCpar().setCreated_by(user.getUser_id());
        cf.getCpar().setRow_user_id(user.getUser_id());
        cf.getCpar().setStatus_id("4"); //**Status: Open
      }
      if (request.getAttribute("iscar").equals("true")) {
        cf.getCpar().setCar_flag("Y");
        if (!(request.getAttribute("createCAR") == null || request.getAttribute("iscar").equals(null)) && request.getAttribute("createCAR").equals("true")) {
          getCARFindingData(request, cf.getCpar());  //**Gets the audit-Finding details...for CAR
          request.setAttribute("msg", "false");
        }
      } else {
        getCARFindingData(request, cf.getCpar()); //**Gets the audit-Finding details...also for PAR
        cf.getCpar().setCar_flag("N");

        //****Maybe we need to add this line here also...****check
        //request.setAttribute("msg","false");
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    getAuditStopSaleNumber(cf, request);
    forward = getForward(cf.getCpar());
    setCPAR(request, cf.getCpar());
    setEditValue(request, "cparNew");
    return (mapping.findForward(forward));
  }


  public ActionForward cparStopSaleNew(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response)
          throws Exception {
    String forward;
    getCparFormDefaults(request);
    request.getSession().setAttribute("iscar", request.getAttribute("iscar"));
    CparForm cf = (CparForm) form;
    Map map = request.getParameterMap();
    User user = (User) request.getSession().getAttribute("user");
    try {
      CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
      if (cf.getCpar() == null) {
        Cpar c = new Cpar();
        c.setCpar_id(cs.getCparPK());
        c.setRow_entry_date(sdf.format(new Date()));
        c.setCreated_by(user.getUser_id());
        c.setRow_user_id(user.getUser_id());
        c.setStatus_id("4");  //**Status: Open
        cf.setCpar(c);
      } else {
        cf.getCpar().setCpar_id(cs.getCparPK());
        cf.getCpar().setRow_entry_date(sdf.format(new Date()));
        cf.getCpar().setCreated_by(user.getUser_id());
        cf.getCpar().setRow_user_id(user.getUser_id());
        cf.getCpar().setStatus_id("4"); //**Status: Open
      }
      if (request.getAttribute("iscar").equals("true")) {
        cf.getCpar().setCar_flag("Y");
        if (!(request.getAttribute("createCAR") == null || request.getAttribute("iscar").equals(null)) && request.getAttribute("createCAR").equals("true")) {
          getCARStopSaleData(request, cf.getCpar());  //**Gets the audit-Finding details...for CAR
          request.setAttribute("msg", "false");
        }
      } else {
        getCARStopSaleData(request, cf.getCpar()); //**Gets the audit-Finding details...also for PAR
        cf.getCpar().setCar_flag("N");

        //****Maybe we need to add this line here also...****check
        //request.setAttribute("msg","false");
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    getAuditStopSaleNumber(cf, request);
    forward = getForward(cf.getCpar());
    setCPAR(request, cf.getCpar());
    setEditValue(request, "cparNew");
    return (mapping.findForward(forward));
  }


  /**
   * Method sort
   *
   * @param mapping
   * @param form
   * @param request
   * @param response
   * @return ActionForward
   */
  public ActionForward sort(
          ActionMapping mapping,
          ActionForm form,
          HttpServletRequest request,
          HttpServletResponse response) {
    CparListForm cparListForm = (CparListForm) form;

    //*****LocationList Filling...
    try {
      getCparFormDefaults(request);
    }
    catch (Exception ex) {
      System.out.println("Error getting Complaint default lists.");
      ex.printStackTrace();
    }

    //**Read the request parameters...Sort Order and Criteria.
    getSortValues(request);

    //**Get the HashMap and sort it...
    //	sortList(cparListForm.getCparsList(), sortCriteria, sortOrder);

    //**Set it back in the form...
    return mapping.findForward("successList");
  }

  private void getCARData(HttpServletRequest request, Cpar cpar) {
    cpar.setComplaint_id(request.getParameter("c.complaint_id").toString());
    cpar.setClaim_number(request.getParameter("c.claim_number"));
    cpar.setFiling_location(request.getParameter("c.reporting_location_code"));
    cpar.setResponsible_location(request.getParameter("c.responsible_plant_code"));
    cpar.setReport_date(request.getParameter("c.report_date"));
    cpar.setIssue_year(request.getParameter("c.sales_year_id"));
    //cpar.setInitiated_by(request.getParameter("c.report_initiator"));
    cpar.setReport_initiator_email(request.getParameter("c.report_initiator_email"));
    cpar.setRegion(request.getParameter("c.region_id"));
    cpar.setGenerator("6");
  }


  private void getCARFindingData(HttpServletRequest request, Cpar cpar) {
    Cpar cparReqObj = new Cpar();
    cparReqObj = (Cpar) request.getAttribute("cparFindingObj");
    cpar.setRegion(cparReqObj.getRegion());
    cpar.setFiling_location(cparReqObj.getFiling_location());
    cpar.setResponsible_location(cparReqObj.getResponsible_location());
    cpar.setReport_date(cparReqObj.getReport_date());
    cpar.setInitiated_by(cparReqObj.getInitiated_by());
    cpar.setAudit_finding_id(cparReqObj.getAudit_finding_id());
    cpar.setAudit_number(cparReqObj.getAudit_number());
    cpar.setAudit_id(cparReqObj.getAudit_id());
    cpar.setInvestigation_findings(cparReqObj.getInvestigation_findings());
    //cpar.setGenerator(cparReqObj.getGenerator());
  }

  private void getCARStopSaleData(HttpServletRequest request, Cpar cpar) {
    Cpar cparReqObj = new Cpar();
    cparReqObj = (Cpar) request.getAttribute("cparStopSaleObj");
    cpar.setRegion(cparReqObj.getRegion());
    cpar.setFiling_location(cparReqObj.getFiling_location());
    cpar.setResponsible_location(cparReqObj.getResponsible_location());
    cpar.setIssue_year(cparReqObj.getIssue_year());
    cpar.setInvestigation_findings(cparReqObj.getInvestigation_findings());
    cpar.setRoot_cause(cparReqObj.getRoot_cause());
    cpar.setContainment_actions(cparReqObj.getContainment_actions());
    cpar.setLong_term_corrective_action(cparReqObj.getLong_term_corrective_action());
    cpar.setStop_sale_id(cparReqObj.getStop_sale_id());
    cpar.setStop_sale_number(cparReqObj.getStop_sale_number());
    cpar.setGenerator(cparReqObj.getGenerator());

  }

  private void setEditValue(HttpServletRequest request, String method) {
    HttpSession session = request.getSession();
    if (method.equals("cparNew")) {
      session.setAttribute("cparEdit", "false");
    }
    if (method.equals("cparFindControlNumber")) {
      session.setAttribute("cparEdit", "false");
    }
    if (method.equals("cparEdit")) {
      session.setAttribute("cparEdit", "true");
    }
    if (method.equals("cparSubmit")) {
      session.setAttribute("cparEdit", "true");
    }
  }

  public ActionForward cparEdit(ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response)
          throws Exception {
    String forward = "";
    Cpar c;
    getCparFormDefaults(request);
    CparForm cf = (CparForm) form;
    cf.setCpar(null);
    User user = (User) request.getSession().getAttribute("user");
    try {
      CparService cs = getCPARService();
      c = cs.getCpar(request.getParameter("cparId"));
      c.setRow_user_id(user.getUser_id());
      cf.setCpar(c);
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    setCPAR(request, c);
    getAuditStopSaleNumber(cf, request);
    forward = getForward(c);
    setEditValue(request, "cparEdit");
    request.getSession().setAttribute("originalCpar", c);
    return (mapping.findForward(forward));
  }

  public ActionForward cparSubmit(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
          throws Exception {
    Cpar originalCpar = (Cpar) request.getSession().getAttribute("originalCpar");
    CparForm cf = (CparForm) form;
    String forward = "";
    boolean foundControlNumber = false;
    Cpar cpar = ((CparForm) form).getCpar();
    if (cpar.getCar_flag().equals("N")) {
      ActionErrors errors = new ActionErrors();
      boolean flag = false;
      if (cpar.getContinual_Improvements().equals("null") || cpar.getContinual_Improvements().equals("")) {
        flag = true;
      }
      if (flag) {
        errors.add("continualImprovements", new ActionError("com.monsanto.wst.breedingcomplaintsaudits.cpar.continualImprovements"));
      }
      if (!errors.isEmpty()) {
        saveErrors(request, errors);
        return mapping.findForward("failure");
      }
    }
    try {
      CparService cs = getCPARService();
      ControlNumberService cons = (ControlNumberService) ServiceLocator.locateService(ControlNumberService.class);
      if (cpar != null) {
        if (request.getSession().getAttribute("cparEdit").equals("true")) {
          cs.updateCpar(cpar);
          if (request.getParameter("statusChanged").equals("true")) {
            sendEMails(cpar, ActionHelper.EMAIL_TYPE_CPAR_STATUS_CHANGED, request);
          } else {
            if (!cpar.equals(originalCpar)) {
              sendEMails(cpar, ActionHelper.EMAIL_TYPE_CPAR_CHANGED, request);
            }
          }
          request.setAttribute("msg", "true");
        } else {
          foundControlNumber = cons.generateControlNumber(cpar);
          if (!foundControlNumber) {
            request.setAttribute("errorMsg", String.valueOf(foundControlNumber));
          } else {
            cs.insertCpar(cpar);
            sendEMails(cpar, ActionHelper.EMAIL_TYPE_CPAR_NEW, request);
            request.setAttribute("msg", "true");
          }
        }
      }
    }
    catch (Exception e) {
      throw new Exception(e);
    }
    setCPAR(request, cpar);
    getAuditStopSaleNumber(cf, request);
    forward = getForward(cpar);
    if (foundControlNumber)
      setEditValue(request, "cparSubmit");
    request.getSession().setAttribute("originalCpar", cpar);
    return (mapping.findForward(forward));
  }

// Do not need this as this logic goes in cparSubmit.    
//    public ActionForward cparFindControlNumber(ActionMapping mapping,
//            ActionForm form,
//            HttpServletRequest request,
//            HttpServletResponse response)
//		throws Exception {
//    	String forward;
//    	Cpar c = ((CparForm)form).getCpar();
//    	boolean foundControlNumber=false;
//    	try {
//    		CparService cs = (CparService)ServiceLocator.locateService(CparService.class);
//    		if (!(request.getParameter("controlNumber").equals(null)) && !(request.getParameter("controlNumber").equals(""))){
//    			foundControlNumber=cs.findControlNumber(request.getParameter("controlNumber").trim());
//    		}
//    		forward=getForward(c);
//    		if (foundControlNumber) {
//    			request.setAttribute("errorMsg",String.valueOf(foundControlNumber));
//    		}    		
//    	}
//		catch (Exception e){
//			throw new Exception(e);
//		}
//		setCPAR(request,c);
//    	forward=getForward(c);
//    	setEditValue(request,"cparFindControlNumber");	
//		return (mapping.findForward(forward));
//    }	


  protected void getCparFormDefaults(HttpServletRequest request) throws Exception {
    HttpSession session = request.getSession();
    session.setAttribute(ActionHelper.STATUS_LIST, null);
    if (session.getAttribute(ActionHelper.GENERATOR_LIST) == null)
      session.setAttribute(ActionHelper.GENERATOR_LIST, ActionHelper.getGeneratorList());
    if (session.getAttribute(ActionHelper.LOCATION_LIST) == null)
      session.setAttribute(ActionHelper.LOCATION_LIST, ActionHelper.getLocationList());
    if (session.getAttribute(ActionHelper.EVALUATOR_LIST) == null)
      session.setAttribute(ActionHelper.EVALUATOR_LIST, ActionHelper.getEvaluatorList());
    if (session.getAttribute(ActionHelper.SALES_YEAR_LIST) == null)
      session.setAttribute(ActionHelper.SALES_YEAR_LIST, ActionHelper.getSalesyearList());
    if (session.getAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST) == null)
      session.setAttribute(ActionHelper.RESPONSIBLE_LOCATION_LIST, ActionHelper.getResponsibleLocationList());
    if (session.getAttribute(ActionHelper.FINDING_TYPE_LIST) == null)
      session.setAttribute(ActionHelper.FINDING_TYPE_LIST, ActionHelper.getFindingTypeList());
    if (session.getAttribute(ActionHelper.ISO_STANDARD_LIST) == null)
      session.setAttribute(ActionHelper.ISO_STANDARD_LIST, ActionHelper.getIsoStandardList());
    if (session.getAttribute(ActionHelper.STATUS_LIST) == null)
      session.setAttribute(ActionHelper.STATUS_LIST, ActionHelper.getStatusList("CPAR"));
    if (session.getAttribute(ActionHelper.REGION_LIST) == null)
      session.setAttribute(ActionHelper.REGION_LIST, ActionHelper.getRegionList());
    if (session.getAttribute(ActionHelper.EVAL_EFFECTIVE_LIST) == null)
      session.setAttribute(ActionHelper.EVAL_EFFECTIVE_LIST, ActionHelper.getEvalEffectiveList());
    if (session.getAttribute(ActionHelper.CONTINUAL_IMPROVEMENTS_LIST) == null)
      session.setAttribute(ActionHelper.CONTINUAL_IMPROVEMENTS_LIST, ActionHelper.getContinualImprovementsList());

//TODO These may be needed in each action if session object gets heavy.
//   		session.setAttribute(ActionHelper.UOM_LIST,null);
//   		session.setAttribute(ActionHelper.VARIETY_LIST,null);    	
  }

  private String getForward(Cpar c) {
    String forward = "success";
//    	TODO After authentication implementation change following lines to select based on user roles.
//		Default forward for both CAR and PAR.    	
    return forward;
  }

  private void setCPAR(HttpServletRequest request, Cpar cpar) {
    if (cpar.getCar_flag().equals("Y"))
      request.getSession().setAttribute("iscar", "true");
    else
      request.getSession().setAttribute("iscar", "false");
  }

  private boolean sendEMails(Cpar cpar, String type, HttpServletRequest request) throws Exception {
    String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.AppName");
    String emailFooter = McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.EmailFooter");
    String cparControlNumber = cpar.getControl_number();
    String[] emails;
    String url = (request.getRequestURL().toString().split(request.getContextPath()))[0] + request.getContextPath();
    //String urlLink=url+"/cpar.do?method=cparEdit&cparId="+cparID;
    String cparStr = "";
    try {
      LookUpService lookupService = getLookupService();
      String[] location = cpar.getResponsible_location().split("_");
      emails = lookupService.getEmail(location[0]);
      if (cpar.getCar_flag().equals("Y")) {
        cparStr = "CAR";
      } else {
        cparStr = "PAR";
      }
      EmailUtil emailUtil = getEmailUtil();
      if (emails == null || emails.length == 0 || StringUtils.isNullOrEmpty(emails[0])) {
        return false;
      }
      emailUtil.setTo(emails[0]);
      emailUtil.setFrom(ActionHelper.ADMIN_EMAIL);
      if (type.equals(ActionHelper.EMAIL_TYPE_CPAR_NEW)) {
        if (emails.length > 1 && emails[1] != null) {
          emailUtil.setCc(emails[1]);
        }
        emailUtil.setSubject("New " + cparStr + ": '" + cparControlNumber + "' - " + appName);
        emailUtil.setBody("A new " + cparStr + " (" + cparStr + ": '" + cparControlNumber + "') has been entered into the SBFAS system. Click here to logon to the SBFAS system: " + url + "\n\n\n\n\n" + emailFooter);
      }
      if (type.equals(ActionHelper.EMAIL_TYPE_CPAR_STATUS_CHANGED)) {
        emailUtil.setSubject(cparStr + " Status Change: '" + cparControlNumber + "' - " + appName);
        emailUtil.setBody("The status on " + cparStr + " '" + cparControlNumber + "' has been set to " + getStatusList().get(cpar.getStatus_id()).toString().trim() + ". Click here to logon to the SBFAS system: " + url + "\n\n\n\n\n" + emailFooter);
      }
      if (type.equals(ActionHelper.EMAIL_TYPE_CPAR_CHANGED)) {
        emailUtil.setSubject(cparStr + " Change: '" + cparControlNumber + "' - " + appName);
        emailUtil.setBody("The " + cparStr + " '" + cparControlNumber + "' has been modified. Click here to logon to the SBFAS system: " + url + "\n\n\n\n\n" + emailFooter);
      }
      return emailUtil.sendMail();
    }
    catch (Exception e) {
      throw new Exception(e);
    }
  }

  private void getAuditStopSaleNumber(CparForm cf, HttpServletRequest request) {
    if (cf.getCpar().getAudit_finding_id() != null && !cf.getCpar().getAudit_finding_id().equals("")) {
      String tempAuditNo = "";
      try {
        AuditService as = (AuditService) ServiceLocator.locateService(AuditService.class);
        tempAuditNo = as.getAuditNumberFromFinding(Integer.parseInt(cf.getCpar().getAudit_finding_id()));
        cf.getCpar().setAudit_number(tempAuditNo);
      }
      catch (Exception ex) {
        logger.error("Error finding service to get Audit_Number From Finding_ID");
      }
      request.getSession().setAttribute("tempAuditNo", tempAuditNo);
    }
    if (cf.getCpar().getStop_sale_id() != null && !cf.getCpar().getStop_sale_id().equals("")) {
      String tempStopSaleNo = "";
      try {
        StopSaleService ss = (StopSaleService) ServiceLocator.locateService(StopSaleService.class);
        tempStopSaleNo = ss.getStopSaleNumberFromID(Integer.parseInt(cf.getCpar().getStop_sale_id()));
        cf.getCpar().setStop_sale_number(tempStopSaleNo);
      }
      catch (Exception ex) {
        logger.error("Error finding service to get Stop_Sale_Number From ID");
      }
      request.getSession().setAttribute("tempStopSaleNo", tempStopSaleNo);
    }
  }

  /**
   * To get the sortCriteria and determine the sortOrder.
   *
   * @param request
   */
  private void getSortValues(HttpServletRequest request) {
    sortOrder = "asc";
    sortCriteria = request.getParameter("sortCriteria");
    String lastSortCriteria = request.getSession().getAttribute("lastCparSortCriteria") + "";
    if (lastSortCriteria == null) {
      sortOrder = "asc";
    } else {  // => Not_Null
      if (sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
        sortOrder = request.getSession().getAttribute("lastCparSortOrder") + "";
        if (sortOrder == null) {
          sortOrder = "asc";
        } else {  // => Not_Null
          if (sortOrder.equalsIgnoreCase("asc")) {
            sortOrder = "desc";
          } else {
            sortOrder = "asc";
          }
        }
      } else {
        sortOrder = "asc";
      }
    }
    request.getSession().setAttribute("lastCparSortCriteria", sortCriteria);
    request.getSession().setAttribute("lastCparSortOrder", sortOrder);
  }

  /**
   * To reset the sortOrder after every submit or refresh(display).
   *
   * @param request
   */
  private void resetSortOrder(HttpServletRequest request) {
    request.getSession().setAttribute("lastCparSortOrder", "dec");
  }

  private void sortList(LinkedHashMap hash, String sortBy, String sortOrd) {
    Vector dataVector = new Vector();
    Iterator it = hash.keySet().iterator();
    while (it.hasNext()) {
      dataVector.add((CparList) hash.get(it.next()));
    }
    hash.clear();

    //**Token
    if (sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aTokens[] = (((CparList) a).getControlNumber() != null) ?
                          ((CparList) a).getControlNumber().toString().trim().split("-") : "".split("-");
                  String bTokens[] = (((CparList) b).getControlNumber() != null) ?
                          ((CparList) b).getControlNumber().toString().trim().split("-") : "".split("-");
                  int noOfTokens = aTokens.length;
                  for (int i = 0; i < noOfTokens; i++) {
                    try {
                      int aVal = Integer.parseInt(aTokens[i]);
                      int bVal = Integer.parseInt(bTokens[i]);
                      if (aVal > bVal) {
                        return 1;
                      }
                      if (aVal < bVal) {
                        return -1;
                      }
                    }
                    catch (Exception ex) {
                      //**These are probably just Strings...
                      if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                        return 1;
                      }
                      if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                        return -1;
                      }
                    }

                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("controlNumber") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aTokens[] = (((CparList) a).getControlNumber() != null) ?
                          ((CparList) a).getControlNumber().toString().trim().split("-") : "".split("-");
                  String bTokens[] = (((CparList) b).getControlNumber() != null) ?
                          ((CparList) b).getControlNumber().toString().trim().split("-") : "".split("-");
                  int noOfTokens = aTokens.length;
                  for (int i = 0; i < noOfTokens; i++) {
                    try {
                      int aVal = Integer.parseInt(aTokens[i]);
                      int bVal = Integer.parseInt(bTokens[i]);
                      if (aVal < bVal) {
                        return 1;
                      }
                      if (aVal > bVal) {
                        return -1;
                      }
                    }
                    catch (Exception ex) {
                      //**These are probably just Strings...
                      if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                        return 1;
                      }
                      if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                        return -1;
                      }
                    }
                  }
                  return 0;
                }
              }
      );
    }

    //**Date
    if (sortBy.equalsIgnoreCase("createdDate") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  long aDate;
                  long bDate;
                  try {
                    String aToken = ((CparList) a).getCreatedDate().toString().trim();
                    String bToken = ((CparList) b).getCreatedDate().toString().trim();
                    aDate = new java.util.Date(aToken).getTime();
                    bDate = new java.util.Date(bToken).getTime();
                  }
                  catch (Exception ex) {
                    aDate = 0;
                    bDate = 0;
                  }
                  if (aDate > bDate) {
                    return 1;
                  }
                  if (aDate < bDate) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("createdDate") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  long aDate;
                  long bDate;
                  try {
                    String aToken = ((CparList) a).getCreatedDate().toString().trim();
                    String bToken = ((CparList) b).getCreatedDate().toString().trim();
                    aDate = new java.util.Date(aToken).getTime();
                    bDate = new java.util.Date(bToken).getTime();
                  }
                  catch (Exception ex) {
                    aDate = 0;
                    bDate = 0;
                  }
                  if (aDate < bDate) {
                    return 1;
                  }
                  if (aDate > bDate) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("initiatedBy") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getInitiatedBy() != null ?
                          ((CparList) a).getInitiatedBy().toString().trim() : "";
                  String bToken = ((CparList) b).getInitiatedBy() != null ?
                          ((CparList) b).getInitiatedBy().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("initiatedBy") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getInitiatedBy() != null ?
                          ((CparList) a).getInitiatedBy().toString().trim() : "";
                  String bToken = ((CparList) b).getInitiatedBy() != null ?
                          ((CparList) b).getInitiatedBy().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getStatus() != null ?
                          ((CparList) a).getStatus().toString().trim() : "";
                  String bToken = ((CparList) b).getStatus() != null ?
                          ((CparList) b).getStatus().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("status") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getStatus() != null ?
                          ((CparList) a).getStatus().toString().trim() : "";
                  String bToken = ((CparList) b).getStatus() != null ?
                          ((CparList) b).getStatus().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getRegion() != null ?
                          ((CparList) a).getRegion().toString().trim() : "";
                  String bToken = ((CparList) b).getRegion() != null ?
                          ((CparList) b).getRegion().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("region") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getRegion() != null ?
                          ((CparList) a).getRegion().toString().trim() : "";
                  String bToken = ((CparList) b).getRegion() != null ?
                          ((CparList) b).getRegion().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Optional, String
    if (sortBy.equalsIgnoreCase("claimNumber") && sortOrd.equalsIgnoreCase("asc")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getClaimNumber() != null ?
                          ((CparList) a).getClaimNumber().toString().trim() : "";
                  String bToken = ((CparList) b).getClaimNumber() != null ?
                          ((CparList) b).getClaimNumber().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }
    if (sortBy.equalsIgnoreCase("claimNumber") && sortOrd.equalsIgnoreCase("dec")) {
      Collections.sort(dataVector,
              new Comparator() {
                public int compare(Object a, Object b) {
                  String aToken = ((CparList) a).getClaimNumber() != null ?
                          ((CparList) a).getClaimNumber().toString().trim() : "";
                  String bToken = ((CparList) b).getClaimNumber() != null ?
                          ((CparList) b).getClaimNumber().toString().trim() : "";
                  if (aToken.compareToIgnoreCase(bToken) < 0) {
                    return 1;
                  }
                  if (aToken.compareToIgnoreCase(bToken) > 0) {
                    return -1;
                  }
                  return 0;
                }
              }
      );
    }

    //**Copy dataVector to the HashMap...
    int size = dataVector.size();
    for (int i = 0; i < size; i++) {
      hash.put((i + ""), dataVector.get(i));
    }

  }

  protected CparService getCPARService() throws ServiceException {
    return (CparService) ServiceLocator.locateService(CparService.class);
  }

  protected LookUpService getLookupService() throws ServiceException {
    return (LookUpService) ServiceLocator.locateService(LookUpService.class);
  }

  protected EmailUtil getEmailUtil() {
    return new EmailUtil();
  }

  protected Map getStatusList() throws Exception {
    return ActionHelper.getStatusList("CPAR");
  }
}
