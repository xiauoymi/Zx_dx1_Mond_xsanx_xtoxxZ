/*
 * Created on Apr 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.monsanto.wst.breedingcomplaintsaudits.model.AuditFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditListObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.AuditObject;
import com.monsanto.wst.breedingcomplaintsaudits.model.FindingObject;
import com.monsanto.wst.breedingcomplaintsaudits.service.ServiceException;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuditDAO {
	
	public String insertAudit(AuditObject auditObj) throws DAOException;
	
	public boolean updateAudit(AuditObject auditObj) throws DAOException;
	
	public FindingObject insertFinding(String auditNumber, FindingObject FindingObj) throws DAOException;
	
	public boolean updateFinding(FindingObject FindingObj) throws DAOException;
	
	public AuditObject getAudit(String findingID) throws DAOException;
	
	public AuditObject getAuditFromList(String auditNo) throws DAOException;
	
	public LinkedHashMap getAuditList(AuditListObject filterObj, String intPage,boolean getMax,String sortCriteria, String sortOrder) throws DAOException;
	
	public String getAuditNumberFromFinding(int findingID) throws DAOException;
	
	public HashMap getAuditReport(AuditFilter auditFilter) throws DAOException;

  List getCARList(String auditId) throws DAOException;
}
