/*
 * Created on Apr 8, 2005
 *
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import com.monsanto.wst.breedingcomplaintsaudits.model.*;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.RowBean;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author rdesai2
 *
 */
public class AuditDAOImpl extends BaseDAOImpl implements AuditDAO{

  //**Log4j logger
  static Category logger = Category.getInstance(AuditDAOImpl.class.getName());

  private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

  private static final String INSERT_AUDIT_SQL =
      "INSERT INTO M_AUDIT " +
          "(AUDIT_ID, LOCATION_CODE, AUDIT_DATE, AUDIT_NUMBER, " +
          "AUDITOR, REGION_ID, ROW_USER_ID, ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE, RESPONSIBLE_LOCATION_ID) " +
          "VALUES " +
          "(?, ?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?)";

//    private static final String INSERT_CAR_FINDING_SQL =
//    	("INSERT " +
//    		"INTO M_AUDIT_FINDINGS " +
//    			"(AUDIT_FINDING_ID, AUDIT_ID, " +
//    			"DESCRIPTION, ROW_USER_ID, " +
//    			"ROW_TASK_ID, ROW_ENTRY_DATE, " +
//    			"ROW_MODIFY_DATE, CAR_FLAG)" +
//    		"VALUES " +
//    			"(?, ?, " +
//    			"?, ?, " +
//    			"?, ?, " +
//    			"?, 'Y')");
//
//    private static final String INSERT_PAR_FINDING_SQL =
//    	("INSERT " +
//    		"INTO M_AUDIT_FINDINGS " +
//    			"(AUDIT_FINDING_ID, AUDIT_ID, " +
//    			"DESCRIPTION, ROW_USER_ID, " +
//    			"ROW_TASK_ID, ROW_ENTRY_DATE, " +
//    			"ROW_MODIFY_DATE, CAR_FLAG)" +
//    		"VALUES " +
//    			"(?, ?, " +
//    			"?, ?, " +
//    			"?, ?, " +
//    			"?, 'N')");

  private static final String INSERT_AUDIT_FINDING_SQL =
      ("INSERT " +
          "INTO M_AUDIT_FINDINGS " +
          "(AUDIT_FINDING_ID, AUDIT_ID, " +
          "DESCRIPTION, ROW_USER_ID, " +
          "ROW_TASK_ID, ROW_ENTRY_DATE, " +
          "ROW_MODIFY_DATE, CAR_FLAG)" +
          "VALUES " +
          "(?, ?, " +
          "?, ?, " +
          "?, ?, " +
          "?, ?)");

  private static final String UPDATE_AUDIT_FINDING_SQL =
      ("UPDATE " +
          "M_AUDIT_FINDINGS " +
          "SET " +
          "DESCRIPTION = ?, " +
          "ROW_USER_ID = ?, " +
          "ROW_TASK_ID = ?, " +
          "ROW_MODIFY_DATE = ? " +
          "WHERE " +
          "AUDIT_FINDING_ID = ?");

  private static final String GET_AUDIT_SEQ_NEXTVAL =
      "SELECT AUDIT_SEQ.NEXTVAL FROM DUAL";

  private static final String GET_AUDIT_FINDING_SEQ_NEXTVAL =
      "SELECT AUDIT_FINDING_SEQ.NEXTVAL FROM DUAL";

  private static final String GET_ORACLE_SYSDATE =
      "SELECT SYSDATE FROM DUAL";

  private static final String GET_AUDIT_AREA_DESC =
      "SELECT " +
          "DESCRIPTION " +
          "FROM " +
          "M_AUDIT_AREAS_REF " +
          "WHERE " +
          "AREA_ID = '2'";

  private static final String INSERT_AUDIT_AREAS =
      ("INSERT INTO M_AUDIT_AREAS " +
          "(AUDIT_ID, AUDIT_AREA_ID) " +
          "VALUES (?, ?)");

  private static final String GET_MAX_AUDIT_NUMBER =
      ("SELECT " +
          "MAX(TO_NUMBER(SUBSTR(AUDIT_NUMBER,LENGTH('A-1744-04-')+1))) MAX " +
          "FROM " +
          "M_AUDIT " +
          "WHERE " +
          "AUDIT_NUMBER LIKE ?");

  private static final String UPDATE_AUDIT_OVERVIEW =
      ("UPDATE " +
          "M_AUDIT " +
          "SET " +
          "AUDIT_OVERVIEW = ? " +
          "WHERE " +
          "AUDIT_ID = ?");

  private static final String UPDATE_PREPARED_BY =
      ("UPDATE " +
          "M_AUDIT " +
          "SET " +
          "PREPARED_BY = ? " +
          "WHERE " +
          "AUDIT_ID = ?");

  private static final String UPDATE_PREPARED_DATE =
      ("UPDATE " +
          "M_AUDIT " +
          "SET " +
          "PREPARED_DATE = ? " +
          "WHERE AUDIT_ID = ?");

  private static final String UPDATE_ISO_CONTACT =
      ("UPDATE " +
          "M_AUDIT " +
          "SET " +
          "ISO_CONTACT = ? " +
          "WHERE " +
          "AUDIT_ID = ?");


  private static final String AUTO_AUDIT_NUMBER =
      ("SELECT " +
          "MAX(TO_NUMBER(SUBSTR(AUDIT_NUMBER,LENGTH('A-XXXX_XXXX-YY-')+1))) MAX " +
          "FROM " +
          "M_AUDIT " +
          "WHERE " +
          "AUDIT_NUMBER LIKE ?");

  private static final String GET_AUDIT_ID =
      ("SELECT AUDIT_ID FROM M_AUDIT WHERE AUDIT_NUMBER = ?");

  private static final String UPDATE_AUDIT_SQL =
      ("UPDATE " +
          "M_AUDIT " +
          "SET " +
          "LOCATION_CODE = ?, " +
          "AUDIT_DATE = ?, " +
          "AUDITOR = ?, " +
          "REGION_ID = ?, " +
          "ROW_USER_ID = ?, " +
          "ROW_TASK_ID = ?, " +
          "ROW_MODIFY_DATE = ?, " +
          "RESPONSIBLE_LOCATION_ID = ? " +
          "WHERE " +
          "AUDIT_ID = ?");


  private static final String GET_AUDIT_FROM_FINDING =
      ("SELECT AUDIT_ID FROM M_AUDIT_FINDINGS WHERE AUDIT_FINDING_ID = ?");

  private static final String GET_AUDIT_DETAILS = ("SELECT * FROM M_AUDIT A WHERE A.AUDIT_ID = ?");

/*
    	("SELECT A.AUDIT_ID, A.AUDIT_DATE, A.AUDIT_NUMBER, A.AUDITOR, A.ISO_CONTACT, A.AUDIT_OVERVIEW, " +
		    "A.AUDITOR_SIGNATURE, A.ROW_USER_ID, A.ROW_TASK_ID, A.ROW_ENTRY_DATE, A.ROW_MODIFY_DATE, A.REGION_ID, " +
		    "A.PREPARED_BY, A.PREPARED_DATE, RL.LOCATION_CODE, RL.RESPONSIBLE_LOC_ID " +
		    "FROM M_AUDIT A, RESPONSIBLE_LOCATION RL WHERE A.LOCATION_CODE=RL.RESPONSIBLE_LOC_ID AND A.AUDIT_ID = ?");
*/

  private static final String GET_AUDIT_AREAS =
      ("SELECT AUDIT_AREA_ID FROM M_AUDIT_AREAS WHERE AUDIT_ID = ?");

  private static final String GET_FINDING_DETAILS =
      ("SELECT * FROM M_AUDIT_FINDINGS WHERE AUDIT_ID = ?");

  private static final String GET_CPAR_DETAILS =
      ("SELECT " +
          "C.CPAR_ID, " +
          "C.CONTROL_NUMBER, " +
          "(SELECT FT.DESCRIPTION " +
          "FROM FINDING_TYPE_REF FT " +
          "WHERE FT.FINDING_TYPE_ID = C.FINDING_TYPE_ID) FINDING_TYPE " +
          "FROM " +
          "CPAR C " +
          "WHERE " +
          "C.AUDIT_FINDING_ID = ?");

  private static final String UPDATE_CPAR_INVESTIGATION_FINDING =
      ("UPDATE " +
          "CPAR_DOCUMENTATION " +
          "SET " +
          "INVESTIGATION_FINDINGS = ?, " +
          "Row_User_id = ?, " +
          "Row_task_id = ?, " +
          "Row_modify_date = ? " +
          "WHERE " +
          "CPAR_ID = (SELECT CPAR_ID FROM CPAR WHERE AUDIT_FINDING_ID = ?)");

  private static final String GET_AUDIT_LIST =
      ("SELECT  AUDIT_ID,AUDIT_NUMBER,SITE,AUDIT_DATE,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, RANKING FROM  " +
          "(SELECT  AUDIT_ID,AUDIT_NUMBER,SITE,AUDIT_DATE,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, ROWNUM AS RANKING " +
          " FROM " +
          "( SELECT " +
          "A.AUDIT_ID AUDIT_ID,A.AUDIT_NUMBER AUDIT_NUMBER, " +
          "(SELECT CONCAT(L.LOCATION_SHORT_NAME, CONCAT(FR.FUNCTION_CODE, CONCAT(' ', RL.PROGRAM_CODE))) " +
          "FROM RESPONSIBLE_LOCATION RL, LOCATION_REF L, FUNCTION_REF FR " +
          "WHERE RL.LOCATION_CODE = L.LOCATION_CODE AND FR.FUNCTION_ID = RL.FUNCTION_ID AND RL.RESPONSIBLE_LOC_ID = A.RESPONSIBLE_LOCATION_ID) SITE, " +
          "A.AUDIT_DATE, " +
          "A.AUDITOR, " +
          "A.PREPARED_BY, " +
          "'CONTROL_NUMBER' CONTROL_NUMBER, " +
          "'CPAR_ID' CPAR_ID  " +
          " FROM  M_AUDIT A");
//
//  private static final String GET_AUDIT_LIST =
//      ("SELECT  AUDIT_NUMBER,SITE,AUDIT_DATE,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, RANKING FROM  " +
//          "(SELECT  AUDIT_NUMBER,SITE,AUDIT_DATE,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, ROWNUM AS RANKING " +
//          " FROM " +
//          "( SELECT " +
//          "A.AUDIT_NUMBER AUDIT_NUMBER, " +
//          "(SELECT CONCAT(L.LOCATION_SHORT_NAME, CONCAT(FR.FUNCTION_CODE, CONCAT(' ', RL.PROGRAM_CODE))) " +
//          "FROM RESPONSIBLE_LOCATION RL, LOCATION_REF L, FUNCTION_REF FR " +
//          "WHERE RL.LOCATION_CODE = L.LOCATION_CODE AND FR.FUNCTION_ID = RL.FUNCTION_ID AND RL.RESPONSIBLE_LOC_ID = A.RESPONSIBLE_LOCATION_ID) SITE, " +
//          "A.AUDIT_DATE, " +
//          "A.AUDITOR, " +
//          "A.PREPARED_BY, " +
//          "(SELECT C.CONTROL_NUMBER " +
//          "FROM CPAR C " +
//          "WHERE " +
//          "C.AUDIT_FINDING_ID = F.AUDIT_FINDING_ID) CONTROL_NUMBER, " +
//          "(SELECT C.CPAR_ID FROM CPAR C WHERE C.AUDIT_FINDING_ID = F.AUDIT_FINDING_ID) CPAR_ID  " +
//          " FROM  M_AUDIT A LEFT JOIN M_AUDIT_FINDINGS F ON  A.AUDIT_ID = F.AUDIT_ID  ");
////

  private static final String GET_AUDIT_LIST_COUNT =
      ("SELECT " +
          "COUNT(*) COUNT " +
          "FROM " +
          "M_AUDIT A");

  private static final String GET_AUDIT_LIST_CPAR =
      ("SELECT " +
          "A.AUDIT_ID AUDIT_ID, A.AUDIT_NUMBER AUDIT_NUMBER, " +
          "(CONCAT(L.LOCATION_SHORT_NAME, CONCAT(FR.FUNCTION_CODE, CONCAT(RL.PROGRAM_CODE))) SITE), A.AUDIT_DATE, " +
          "A.AUDITOR, A.PREPARED_BY, " +
          "CP.CPAR_ID, " +
          "CP.CONTROL_NUMBER " +
          "FROM " +
          "M_AUDIT A, RESPONSIBLE_LOCATION RL, LOCATION_REF L, FUNCTION_REF FR " +
          "M_AUDIT_FINDINGS F, CPAR CP " +
          "WHERE " +
          "RL.RESPONSIBLE_LOC_ID = M_AUDIT.RESPONSIBLE_LOC_ID AND "+
          "FR.FUNCTION_ID = RL.FUNCTION_ID AND "+
          "L.LOCATION_CODE = RL.LOCATION_CODE AND "+
          "A.AUDIT_ID = F.AUDIT_ID AND " +
          "F.AUDIT_FINDING_ID = CP.AUDIT_FINDING_ID AND " +
          "UPPER(CP.CONTROL_NUMBER) = ? ");

  private static final String DELETE_AUDIT_AREAS =
      ("DELETE FROM M_AUDIT_AREAS WHERE AUDIT_ID = ?");

  private static final String GET_AUDIT_NUMBER_FROM_FINDING =
      ("SELECT " +
          "A.AUDIT_NUMBER " +
          "FROM " +
          "M_AUDIT A, M_AUDIT_FINDINGS F " +
          "WHERE " +
          "A.AUDIT_ID = F.AUDIT_ID AND " +
          "F.AUDIT_FINDING_ID = ?");

  private static final String GET_AUDIT_REPORT =
      "SELECT " +
          "M_AUDIT.AUDIT_NUMBER, " +
          "M_AUDIT.LOCATION_CODE, " +
          "CONCAT(LOCATION_REF.LOCATION_SHORT_NAME, "+
          "CONCAT(FUNCTION_REF.FUNCTION_CODE, CONCAT('  ', RESPONSIBLE_LOCATION.PROGRAM_CODE))) LOCATION_SHORT_NAME, "+
          "M_AUDIT.AUDIT_OVERVIEW, " +
          "CPAR.CONTROL_NUMBER AS CAR_PAR_NUMBER, " +
          "M_AUDIT.AUDIT_DATE, " +
          "M_AUDIT_AREAS_REF.DESCRIPTION AS AUDIT_AREA, " +
          "M_AUDIT_FINDINGS.DESCRIPTION AS FINDING, " +
          "M_AUDIT.AUDITOR, " +
          "M_AUDIT.ISO_CONTACT, " +
          "REGION_REF.REGION_DESCRIPTION AS REGION, " +
          "M_AUDIT.PREPARED_BY, " +
          "M_AUDIT.PREPARED_DATE " +
          "FROM " +
          "M_AUDIT, " +
          "RESPONSIBLE_LOCATION, " +
          "LOCATION_REF, "+
          "FUNCTION_REF, "+
          "REGION_REF, " +
          "M_AUDIT_AREAS, " +
          "M_AUDIT_AREAS_REF, " +
          "M_AUDIT_FINDINGS, " +
          "CPAR " +
          "WHERE " +
          "RESPONSIBLE_LOCATION.RESPONSIBLE_LOC_ID = M_AUDIT.RESPONSIBLE_LOCATION_ID AND "+
          "FUNCTION_REF.FUNCTION_ID = RESPONSIBLE_LOCATION.FUNCTION_ID AND "+
          "LOCATION_REF.LOCATION_CODE = RESPONSIBLE_LOCATION.LOCATION_CODE AND "+
          "REGION_REF.REGION_ID = M_AUDIT.REGION_ID    AND " +
          "M_AUDIT.AUDIT_ID = M_AUDIT_AREAS.AUDIT_ID(+)    AND " +
          "M_AUDIT_AREAS_REF.AREA_ID(+) = M_AUDIT_AREAS.AUDIT_AREA_ID    AND " +
          "M_AUDIT.AUDIT_ID = M_AUDIT_FINDINGS.AUDIT_ID(+)    AND " +
          "M_AUDIT_FINDINGS.AUDIT_FINDING_ID = CPAR.AUDIT_FINDING_ID(+) ";


  /**
   * Constructor.
   * @exception DAOException
   */
  public AuditDAOImpl() throws DAOException {

  }

  public FindingObject insertFinding(String auditNumber, FindingObject findingObj) throws DAOException{

    logger.info("AuditDAO: Executing insertFinding() operation...");

    //**Imp Variables...
    Date oracleSysdate = new Date(System.currentTimeMillis());
    String autoAuditNumber = auditNumber;
    int auditID = 0;
    int auditFindingID = 0;

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get audit-id for the given audit-number
      auditID = getAuditID(autoAuditNumber, conn);

      //**Get audit-finding-seq
      auditFindingID = getAuditFindingSeq(conn);

      //**Perform Insert-Operation...
      insertFindingObject(auditFindingID, auditID, oracleSysdate, findingObj, conn);

    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertFinding()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertFinding()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertFinding()...");
        logger.error("SQLException at updateAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }

    FindingObject resultObj = new FindingObject();

    resultObj.setFindingID(auditFindingID + "");
    resultObj.setFindingDesc(findingObj.getFindingDesc());
    resultObj.setCparID(findingObj.getCparID());
    resultObj.setControlNumber(findingObj.getControlNumber());
    resultObj.setRowUserID(findingObj.getRowUserID());
    resultObj.setShortFindingDesc(findingObj.getShortFindingDesc());

    return resultObj;
  }



  public AuditObject getAudit(String findingID) throws DAOException{

    logger.info("AuditDAO: Executing getAudit() operation...");

    //**Imp Variables...
    int auditID = 0;
    int auditFindingID = Integer.parseInt(findingID);

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      AuditObject audit = new AuditObject();

      //**Get audit-id for the given audit-findig-id...
      auditID = getAuditFromFinding(auditFindingID, conn);

      //**Get audit-details...
      getAuditDetails(auditID, audit, conn);

      //**Get audit-areas...
      getAuditAreas(auditID, audit, conn);

      //**Get audit-finding-details...
      getFindingDetails(auditID, audit, conn);

      return audit;

    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAudit()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAudit()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAudit()...");
        logger.error("SQLException at updateAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }
  }



  public AuditObject getAuditFromList(String auditNo) throws DAOException{

    logger.info("AuditDAO: Executing getAuditFromList() operation...");

    //**Imp Variables...
    int auditID = 0;

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      AuditObject audit = new AuditObject();

      //**Get audit-id for the given audit-no...
      auditID = getAuditID(auditNo, conn);

      //**Get audit-details...
      getAuditDetails(auditID, audit, conn);

      //**Get audit-areas...
      getAuditAreas(auditID, audit, conn);

      //**Get audit-finding-details...
      getFindingDetails(auditID, audit, conn);

      return audit;

    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFromList()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFromList()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFromList()...");
        logger.error("SQLException at updateAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }
  }


  public String getAuditNumberFromFinding(int findingID) throws DAOException{

    logger.info("AuditDAO: Executing getAuditFromList() operation...");

    //**Imp Variables...
    String auditNumber = "";

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      auditNumber = getAuditNoFromFinding(findingID, conn);

      return auditNumber;

    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNumberFromFinding()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNumberFromFinding()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNumberFromFinding()...");
        logger.error("SQLException at getAuditNumberFromFinding() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }
  }


  public boolean updateFinding(FindingObject findingObj) throws DAOException{

    logger.info("AuditDAO: Executing updateFinding() operation...");

    //**Imp Variables...
    Date oracleSysdate = new Date(System.currentTimeMillis());

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Perform Insert-Operation...
      updateFindingObject(Integer.parseInt(findingObj.getFindingID()), oracleSysdate, findingObj, conn);

      //**CPAR MODIFY: Investigation Finding, iff cpar present...[NOT REQUIRED NOW...]
//			if(findingObj.getCparID() != null && !findingObj.getCparID().equals("")){
//				updateCparInvestigationFinding(Integer.parseInt(findingObj.getFindingID()), oracleSysdate, findingObj, conn);
//			}

      return true;
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateFinding()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateFinding()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateFinding()...");
        logger.error("SQLException at updateAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }
  }

  public boolean updateAudit(AuditObject auditObj)throws DAOException{

    logger.info("AuditDAO: Executing updateAudit() operation...");

    //**Imp Variables...
    Date oracleSysdate = new Date(System.currentTimeMillis());
    String autoAuditNumber = auditObj.getAuditNumber();
    int auditID = 0;

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get audit-id for the given audit-number
      auditID = getAuditID(autoAuditNumber, conn);

      //**Perform Insert-Operation...
      updateAuditObject(auditID, oracleSysdate, auditObj, conn);

      //**Delete the existing Audit-Areas...then add new selected ones...
      deleteAuditedAreas(auditID, conn);

      //**Insert the Areas Audited...
      insertAuditedAreas(auditID, auditObj, conn);

      //**Update Area-Overview, if filled in...
      if(auditObj.getAuditOverview() != null && !auditObj.getAuditOverview().equals("")){
        updateAuditOverview(auditObj.getAuditOverview(), auditID, conn);
      }

      //**Update Prepared-BY, if filled in...
      if(auditObj.getPreparedBy() != null && !auditObj.getPreparedBy().equals("")){
        updatePreparedBy(auditObj.getPreparedBy(), auditID, conn);
      }

      //**Update Prepared_Date, if filled in...
      if(auditObj.getPreparedDate() != null && !auditObj.getPreparedDate().equals("")){
        updatePreparedDate(auditObj.getPreparedDate(), auditID, conn);
      }

      //**Update ISO-Contact, if filled in...
      if(auditObj.getSiteISOContact() != null && !auditObj.getSiteISOContact().equals("")){
        updateIsoContact(auditObj.getSiteISOContact(), auditID, conn);
      }


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAudit()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAudit()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAudit()...");
        logger.error("SQLException at updateAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }

    return true;
  }

  public String insertAudit(AuditObject auditObj) throws DAOException{

    logger.info("AuditDAO: Executing insertAudit() operation...");

    //**Imp Variables...
    int auditSeqNextVal = 0;
    Date oracleSysdate = new Date(System.currentTimeMillis());
    String autoAuditNumber = "";

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try{
      conn = getConnection();

      //**Get the audit_seq value...
      auditSeqNextVal = getAuditSeqValue(conn);

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get the auto-generated audit_no...
      autoAuditNumber = getAuditNumberMax(auditObj, conn);


      //**Perform Insert-Operation...
      insertAuditObject(auditSeqNextVal, autoAuditNumber, oracleSysdate, auditObj, conn);

      //**Insert the Areas Audited...
      insertAuditedAreas(auditSeqNextVal, auditObj, conn);

      //**Update Area-Overview, if filled in...
      if(auditObj.getAuditOverview() != null && !auditObj.getAuditOverview().equals("")){
        updateAuditOverview(auditObj.getAuditOverview(), auditSeqNextVal, conn);
      }

      //**Update Prepared-BY, if filled in...
      if(auditObj.getPreparedBy() != null && !auditObj.getPreparedBy().equals("")){
        updatePreparedBy(auditObj.getPreparedBy(), auditSeqNextVal, conn);
      }

      //**Update Prepared_Date, if filled in...
      if(auditObj.getPreparedDate() != null && !auditObj.getPreparedDate().equals("")){
        updatePreparedDate(auditObj.getPreparedDate(), auditSeqNextVal, conn);
      }

      //**Update ISO-Contact, if filled in...
      if(auditObj.getSiteISOContact() != null && !auditObj.getSiteISOContact().equals("")){
        updateIsoContact(auditObj.getSiteISOContact(), auditSeqNextVal, conn);
      }



    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAudit()...");
      logger.error("SQLException while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAudit()...");
      logger.error("Exception while getting connection: " + e.getMessage());
      throw new DAOException(e);
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAudit()...");
        logger.error("SQLException at insertAudit() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }

    //**Return both the audit-number and audit_id
    return autoAuditNumber + ";" + auditSeqNextVal;
  }


  public LinkedHashMap getAuditList(AuditListObject filterObj,String intPage,boolean getMax,String sortCriteria,String sortOrder) throws DAOException{

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    StringBuffer whereClause;
    String orderBySort;
    List paramList = new ArrayList();
    LinkedHashMap audits = null;
    try{
      conn = getConnection();

      if (!(filterObj.getCparNumber().equals(null)) && !(filterObj.getCparNumber().equals(""))){
        return getAuditsForFinding(filterObj, ps, rs, conn, paramList);
      }//end if

      else{

        return getAuditIfNoFindingSelected(filterObj, intPage, sortCriteria, sortOrder, ps, rs, conn, paramList, audits);

      }//end else
    }
    catch(SQLException e){

      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditList()...");
      logger.error("SQLException while getting audit_list: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditList()...");
      logger.error("Exception while getting audit_list: " + e.getMessage());
    }
    finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null)
          rs.close();

        if (ps != null)
          ps.close();

        this.closeConnection(conn);
      }
      catch(SQLException ex) {
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditList()...");
        logger.error("SQLException at getAuditList() while closing: " + ex.getMessage());
        throw new DAOException(ex);
      }
    }

    return new LinkedHashMap();
  }

  private LinkedHashMap getAuditIfNoFindingSelected(AuditListObject filterObj, String intPage, String sortCriteria, String sortOrder, PreparedStatement ps, ResultSet rs, Connection conn, List paramList, LinkedHashMap audits) throws SQLException {
    StringBuffer whereClause;
    String orderBySort;
    int Page = Integer.parseInt(intPage);
    if (!(filterObj.getLocationCode() == null) && !(filterObj.getLocationCode().equals("")))
      paramList.add("locationCode");
    if (!(filterObj.getAuditDate() == null) && !(filterObj.getAuditDate().equals("")))
      paramList.add("auditDate");
    if (!(filterObj.getAuditor() == null) && !(filterObj.getAuditor().equals("")))
      paramList.add("auditor");
    if (!(filterObj.getPreparedBy() == null) && !(filterObj.getPreparedBy().equals("")))
      paramList.add("preparedBy");
    if (!(filterObj.getRegion() == null) && !(filterObj.getRegion().equals("")))
      paramList.add("region");
    if (!(filterObj.getAuditNumber() == null) && !(filterObj.getAuditNumber().equals("")))
      paramList.add("auditNumber");

    whereClause = new StringBuffer();

    if (paramList.size() > 0){
      whereClause.append(" WHERE ");
    }

    String plant_code = filterObj.getLocationCode();
    String[] plants = plant_code.split("_");

    for (int i =0;i<paramList.size();i++){

      if (paramList.get(i).equals("locationCode")){

        whereClause.append(" A.RESPONSIBLE_LOCATION_ID=" + "'" + plants[1] + "'");
      }
      if (paramList.get(i).equals("auditDate")){
        whereClause.append(" A.AUDIT_DATE=to_Date('" + filterObj.getAuditDate().trim() + "','MM-dd-YYYY')");
      }
      if (paramList.get(i).equals("auditor")){
        whereClause.append(" upper(A.AUDITOR) like" + "'" + filterObj.getAuditor().toUpperCase().trim() + "%'");
      }
      if (paramList.get(i).equals("preparedBy")){
        whereClause.append(" upper(A.PREPARED_BY) like" + "'" + filterObj.getPreparedBy().toUpperCase().trim() + "%'");
      }
      if (paramList.get(i).equals("region")){
        whereClause.append(" upper(A.REGION_ID)=" + "'" + filterObj.getRegion() + "'");
      }
      if (paramList.get(i).equals("auditNumber")){
        whereClause.append(" upper(A.AUDIT_NUMBER)=" + "'" + filterObj.getAuditNumber().toUpperCase().trim() + "'");
      }
      if (i < paramList.size() - 1)
        whereClause.append(" AND ");
    }
    System.out.println("The query I am executing is '" + GET_AUDIT_LIST_COUNT + whereClause.toString() + "'\n");
    ps = conn.prepareStatement(GET_AUDIT_LIST_COUNT + whereClause.toString());

    logger.info(GET_AUDIT_LIST_COUNT + whereClause.toString());

    rs = ps.executeQuery();
    if (rs.next()){
      audits = new LinkedHashMap();
      audits.put("maxRows",rs.getString("COUNT"));
    }

    if (sortCriteria.equals("AUDIT_DATE") )
      orderBySort  =  ("  ORDER BY " + sortCriteria + " " + sortOrder + " )) ");
    else
      orderBySort  =  ("  ORDER BY lower(" + sortCriteria + ") " + sortOrder + " )) ");

    String _whereRanking =   " WHERE RANKING BETWEEN " + ((Page*10) - 9) + " AND " + Page*10 ;

    //	whereClause.append(" WHERE RANKING BETWEEN " + ((Page*10) - 9) + " AND " + Page*10);
    ps = conn.prepareStatement(GET_AUDIT_LIST + whereClause.toString() + orderBySort + _whereRanking.toString());
    System.out.println("Get audit list query = '" + GET_AUDIT_LIST + whereClause.toString() + orderBySort + _whereRanking.toString() + "'\n");
    logger.info(GET_AUDIT_LIST +  orderBySort + whereClause.toString());

    rs = ps.executeQuery();
    int rank = (Page*10 - 9);

    while (rs.next()){
      AuditListObject al = new AuditListObject();

      al.setAuditNumber(rs.getString("AUDIT_NUMBER").trim());
      al.setLocationCode(rs.getString("SITE"));
      al.setAuditDate(sdf.format(rs.getDate("AUDIT_DATE")));
      al.setAuditor(rs.getString("AUDITOR"));
      al.setPreparedBy(rs.getString("PREPARED_BY"));
      //al.setCparNumber("TEST");
//      al.setCparNumber(rs.getString("CONTROL_NUMBER"));
      al.setCparID(0);
      al.setAuditId(rs.getString("AUDIT_ID"));

//      if(rs.getString("CPAR_ID") != null && !rs.getString("CPAR_ID").equals("")){
//        al.setCparID(Integer.parseInt(rs.getString("CPAR_ID")));
//      }

      System.out.println(rs.getString("AUDIT_NUMBER").trim());
      audits.put(rank + "", al);


      System.out.println("Rank:");
      System.out.println(rank);
      String r = rank + "";

      rank++;

    }

    return audits;
  }

  private LinkedHashMap getAuditsForFinding(AuditListObject filterObj, PreparedStatement ps, ResultSet rs, Connection conn, List paramList) throws SQLException {
    LinkedHashMap audits;
    StringBuffer whereClause;//**Run a different Query...cpar query...
    audits = new LinkedHashMap();
    audits.put("maxRows", "1");


    if (!(filterObj.getLocationCode() == null) && !(filterObj.getLocationCode().equals("")))
      paramList.add("locationCode");
    if (!(filterObj.getAuditDate() == null) && !(filterObj.getAuditDate().equals("")))
      paramList.add("auditDate");
    if (!(filterObj.getAuditor() == null) && !(filterObj.getAuditor().equals("")))
      paramList.add("auditor");
    if (!(filterObj.getPreparedBy() == null) && !(filterObj.getPreparedBy().equals("")))
      paramList.add("preparedBy");
    if (!(filterObj.getRegion() == null) && !(filterObj.getRegion().equals("")))
      paramList.add("region");
    if (!(filterObj.getAuditNumber() == null) && !(filterObj.getAuditNumber().equals("")))
      paramList.add("auditNumber");

    whereClause = new StringBuffer();

    String plant_code = filterObj.getLocationCode();
    String[] plants = plant_code.split("_");

    for (int i =0;i<paramList.size();i++){

      if (paramList.get(i).equals("locationCode")){

        whereClause.append(" AND A.RESPONSIBLE_LOCATION_ID=" + "'" + plants[1] + "'");
      }
      if (paramList.get(i).equals("auditDate")){
        whereClause.append(" AND A.AUDIT_DATE=to_Date('" + filterObj.getAuditDate().trim() + "','MM-dd-YYYY')");
      }
      if (paramList.get(i).equals("auditor")){
        whereClause.append(" AND upper(A.AUDITOR) like" + "'" + filterObj.getAuditor().toUpperCase().trim() + "%'");
      }
      if (paramList.get(i).equals("preparedBy")){
        whereClause.append(" AND upper(A.PREPARED_BY) like" + "'" + filterObj.getPreparedBy().toUpperCase().trim() + "%'");
      }
      if (paramList.get(i).equals("region")){
        whereClause.append(" AND upper(A.REGION_ID)=" + "'" + filterObj.getRegion() + "'");
      }
      if (paramList.get(i).equals("auditNumber")){
        whereClause.append(" AND upper(A.AUDIT_NUMBER)=" + "'" + filterObj.getAuditNumber().toUpperCase().trim() + "'");
      }
    }
    ps = conn.prepareStatement(GET_AUDIT_LIST_CPAR + whereClause.toString());
    System.out.println(GET_AUDIT_LIST_CPAR);
    ps.setString(1, filterObj.getCparNumber().toUpperCase().trim());

    rs = ps.executeQuery();

    while(rs.next()){
      AuditListObject al = new AuditListObject();

      al.setAuditNumber(rs.getString("AUDIT_NUMBER").trim());
      al.setLocationCode(rs.getString("SITE"));
      al.setAuditDate(sdf.format(rs.getDate("AUDIT_DATE")));
      al.setAuditor(rs.getString("AUDITOR"));
      al.setPreparedBy(rs.getString("PREPARED_BY"));
      al.setCparNumber(rs.getString("CONTROL_NUMBER"));
      if(rs.getString("CPAR_ID") != null && !rs.getString("CPAR_ID").equals("")){
        al.setCparID(Integer.parseInt(rs.getString("CPAR_ID")));
      }

      audits.put(rs.getString("AUDIT_NUMBER"), al);

    }
    return audits;
  }

  public HashMap getAuditReport(AuditFilter auditFilter) throws DAOException{

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    StringBuffer whereClause = new StringBuffer();
    HashMap hash = new HashMap();

    try{
      conn = getConnection();

      if ((auditFilter.getAuditNumber() != null) && !(auditFilter.getAuditNumber().equals(""))){
        whereClause.append(" AND UPPER(M_AUDIT.AUDIT_NUMBER) LIKE UPPER('" + auditFilter.getAuditNumber().trim() + "%') ");
      }
      if ((auditFilter.getAuditDate() != null) && !(auditFilter.getAuditDate().equals(""))){
        whereClause.append(" AND M_AUDIT.AUDIT_DATE = TO_DATE('" + getDateFormat(new Date(new java.util.Date(auditFilter.getAuditDate()).getTime())) + "', 'MM/DD/YYYY') ");
      }
      if ((auditFilter.getPreparedBy() != null) && !(auditFilter.getPreparedBy().equals(""))){
        whereClause.append(" AND UPPER(M_AUDIT.PREPARED_BY) LIKE UPPER('" + auditFilter.getPreparedBy().trim() + "%') ");
      }
      if ((auditFilter.getPreparedDate() != null) && !(auditFilter.getPreparedDate().equals(""))){
        whereClause.append(" AND M_AUDIT.PREPARED_DATE = TO_DATE('" + getDateFormat(new Date(new java.util.Date(auditFilter.getPreparedDate()).getTime())) + "', 'MM/DD/YYYY') ");
      }
      if ((auditFilter.getAuditor() != null) && !(auditFilter.getAuditor().equals(""))){
        whereClause.append(" AND UPPER(M_AUDIT.AUDITOR) LIKE UPPER('" + auditFilter.getAuditor().trim() + "%') ");
      }
      if ((auditFilter.getSiteIsoContact() != null) && !(auditFilter.getSiteIsoContact().equals(""))){
        whereClause.append(" AND UPPER(M_AUDIT.ISO_CONTACT) LIKE UPPER('" + auditFilter.getSiteIsoContact().trim() + "%') ");
      }
      if ((auditFilter.getCparNumber() != null) && !(auditFilter.getCparNumber().equals(""))){
        whereClause.append(" AND UPPER(CPAR.CONTROL_NUMBER) LIKE UPPER('" + auditFilter.getCparNumber().trim() + "%') ");
      }

      if ((auditFilter.getSite() != null) && (auditFilter.getSite().length > 0)) {
        String [] plant_codes = auditFilter.getSite();
        String [] plants = new String[plant_codes.length];
        String [] code;
        boolean bflag = false;

        for(int i=0; i < plant_codes.length; i++){
          code =  plant_codes[i].split("_");
          if(code.length == 2){
            plants[i] = new String(code[1]);
            bflag = true;
          }
        }
        if(bflag)
          whereClause.append(getSelectedFields(" AND M_AUDIT.RESPONSIBLE_LOCATION_ID IN ", plants));
      }

      if ((auditFilter.getRegion() != null) && (auditFilter.getRegion().length > 0)){
        whereClause.append(getSelectedFields(" AND M_AUDIT.REGION_ID IN ", auditFilter.getRegion()));
      }

      whereClause.append(getAuditAreas(auditFilter));

      logger.info(GET_AUDIT_REPORT + whereClause.toString());

      ps = conn.prepareStatement(GET_AUDIT_REPORT + whereClause.toString());

      rs = ps.executeQuery();

      int rowCount = 0;
      while (rs.next()){

        rowCount++;

        //** Fill in the RowBean Object...
        RowBean rowBean = new RowBean();

        if(rs.getString("AUDIT_NUMBER") != null && !(rs.getString("AUDIT_NUMBER").trim().equals(""))){
          rowBean.setCol1(rs.getString("AUDIT_NUMBER"));
        }
        else{
          rowBean.setCol1("-");
        }
        if(rs.getString("LOCATION_CODE") != null && !(rs.getString("LOCATION_CODE").trim().equals(""))){
          rowBean.setCol2(rs.getString("LOCATION_CODE"));
        }
        else{
          rowBean.setCol2("-");
        }
        if(rs.getString("LOCATION_SHORT_NAME") != null && !(rs.getString("LOCATION_SHORT_NAME").trim().equals(""))){
          rowBean.setCol3(rs.getString("LOCATION_SHORT_NAME"));
        }
        else{
          rowBean.setCol3("-");
        }
        if(rs.getString("AUDIT_OVERVIEW") != null && !(rs.getString("AUDIT_OVERVIEW").trim().equals(""))){
          rowBean.setCol4(rs.getString("AUDIT_OVERVIEW"));
        }
        else{
          rowBean.setCol4("-");
        }
        if(rs.getString("CAR_PAR_NUMBER") != null && !(rs.getString("CAR_PAR_NUMBER").trim().equals(""))){
          rowBean.setCol5(rs.getString("CAR_PAR_NUMBER"));
        }
        else{
          rowBean.setCol5("-");
        }
        if(rs.getDate("AUDIT_DATE") != null){
          rowBean.setCol6(getDateFormat(rs.getDate("AUDIT_DATE")));
        }
        else{
          rowBean.setCol6("-");
        }
        if(rs.getString("AUDIT_AREA") != null && !(rs.getString("AUDIT_AREA").trim().equals(""))){
          rowBean.setCol7(rs.getString("AUDIT_AREA"));
        }
        else{
          rowBean.setCol7("-");
        }
        if(rs.getString("FINDING") != null && !(rs.getString("FINDING").trim().equals(""))){
          rowBean.setCol8(rs.getString("FINDING"));
        }
        else{
          rowBean.setCol8("-");
        }
        if(rs.getString("AUDITOR") != null && !(rs.getString("AUDITOR").trim().equals(""))){
          rowBean.setCol9(rs.getString("AUDITOR"));
        }
        else{
          rowBean.setCol9("-");
        }
        if(rs.getString("ISO_CONTACT") != null && !(rs.getString("ISO_CONTACT").trim().equals(""))){
          rowBean.setCol10(rs.getString("ISO_CONTACT"));
        }
        else{
          rowBean.setCol10("-");
        }
/*
				if(rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))){
					rowBean.setCol11(rs.getString("REGION"));
				}
				else{
					rowBean.setCol11("-");
				}
*/
        if(rs.getString("PREPARED_BY") != null && !(rs.getString("PREPARED_BY").trim().equals(""))){
          rowBean.setCol11(rs.getString("PREPARED_BY"));
        }
        else{
          rowBean.setCol11("-");
        }
        if(rs.getDate("PREPARED_DATE") != null){
          rowBean.setCol12(getDateFormat(rs.getDate("PREPARED_DATE")));
        }
        else{
          rowBean.setCol12("-");
        }

        hash.put(rowCount + "", rowBean);
      }

      return hash;
    }
    catch(SQLException e){
      throw new DAOException(e.getMessage(),e);
    }
    catch(Exception e){
      throw new DAOException(e);
    }finally {
      try {
        //**Close the result sets, statement and connection.
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        this.closeConnection(conn);
      } catch(SQLException ex) {
        throw new DAOException(ex.toString());
      }
    }
  }

  public List getCARList(String auditId) throws DAOException {
    Cpar cpar;
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    List cparList = new ArrayList();
    try {
      connection = getConnection();
      statement = connection.prepareStatement("SELECT C.CONTROL_NUMBER,C.CPAR_ID \n" +
          "FROM CPAR C,M_AUDIT A,M_AUDIT_FINDINGS F\n" +
          "WHERE \n" +
          "C.AUDIT_FINDING_ID = F.AUDIT_FINDING_ID AND A.AUDIT_ID=F.AUDIT_ID AND A.AUDIT_ID=?");
      statement.setString(1,auditId);
      resultSet = statement.executeQuery();
      while(resultSet.next()){
        cpar = new Cpar();
        String cparNumber = resultSet.getString("CONTROL_NUMBER");
        String cparId = resultSet.getString("CPAR_ID");
        cpar.setCpar_id(cparId);
        cpar.setControl_number(cparNumber);
        cparList.add(cpar);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }finally {
      try {
        //**Close the result sets, statement and connection.
        if (resultSet != null) resultSet.close();
        if (statement != null) statement.close();
        this.closeConnection(connection);
      } catch(SQLException ex) {
        throw new DAOException(ex.toString());
      }
    }

    return cparList;
  }

  /**
   * Method to set the audit_areas fields...
   *
   * @param //complaintFilter
   * @return
   */
  private StringBuffer getAuditAreas(AuditFilter auditFilter){

    StringBuffer issuesClause = new StringBuffer();


    List paramList = new ArrayList();

    if (auditFilter.isConditioning()){
      paramList.add("1");
    }
    if (auditFilter.isHarvest()){
      paramList.add("2");
    }
    if (auditFilter.isPackaging()){
      paramList.add("3");
    }
    if (auditFilter.isQaLab()){
      paramList.add("4");
    }
    if (auditFilter.isWarehouseDistribution()){
      paramList.add("5");
    }

    if (auditFilter.isFields()){
      paramList.add("6");
    }
    if (auditFilter.isPlanting()){
      paramList.add("7");
    }
    if (auditFilter.isOffSiteFacilities()){
      paramList.add("8");
    }
    if (auditFilter.isStewardShip()){
      paramList.add("9");
    }


    int size = paramList.size();

    if(size > 0){
      issuesClause.append(" AND M_AUDIT_AREAS_REF.AREA_ID IN ");
    }
    else{
      issuesClause.append("");
      return issuesClause;
    }

    issuesClause.append("(");

    for(int i = 0; i < size; i++){

      issuesClause.append("'" + paramList.get(i).toString() + "'");

      if (i < size - 1){
        issuesClause.append(",");
      }
    }

    issuesClause.append(")");

    return issuesClause;
  }

  /**
   * This method just makes a string out of selected fields like ('1744', '1745',...)
   *
   * @param strArray
   * @return
   */
  private StringBuffer getSelectedFields(String query, String[] strArray){

    int size = strArray.length;

    StringBuffer fieldClause = new StringBuffer();
    fieldClause.append("");

    //**To remove the null elements...
    for(int i = 0; i < size; i++){

      if(strArray[i].equals("") || strArray[i].equals("0")){
        size--;
      }
    }

    if(size == 0){
      return fieldClause;
    }

    fieldClause.append(query + "(");

    for(int i = 0; i < strArray.length; i++){

      //**Skip null elements...
      if(strArray[i].equals("") || strArray[i].equals("0")){
        continue;
      }

      fieldClause.append("'" + strArray[i].trim() + "'");

      if (i < strArray.length - 1){
        fieldClause.append(",");
      }
    }

    fieldClause.append(")");

    return fieldClause;
  }

  public String getAuditNumberMax(AuditObject auditObj, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    int max = 0;


    String compareTo = "A-"+
        auditObj.getLocationCode()+"-"+
        auditObj.getAuditDate().substring(auditObj.getAuditDate().length() - 2, auditObj.getAuditDate().length()) + "-" +
        "%";

    try{
      ps = conn.prepareStatement(AUTO_AUDIT_NUMBER);
      ps.setString(1, compareTo);

      rs = ps.executeQuery();

      while(rs.next()){
        max = rs.getInt("MAX");
      }

      String returnStr = "A-"+
          auditObj.getLocationCode()+"-" +
          auditObj.getAuditDate().substring(auditObj.getAuditDate().length() - 2, auditObj.getAuditDate().length()) + "-" +
          (max + 1);

      return returnStr;
    }
    catch(SQLException e){
      System.out.println("\n\n\n\n\n\n\nSQLException");
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNumberMax()...");
      logger.error("SQLException while getting audit_no_max: " + e.getMessage());
      return "";
    }
    catch(Exception e){
      System.out.println("\n\n\n\n\n\n\n Exception");
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNumberMax()...");
      logger.error("Exception while getting audit_no_max: " + e.getMessage());
      return "";
    }

  }

  public void updatePreparedBy(String preparedBy, int auditID, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(UPDATE_PREPARED_BY);

      ps.setString(1, preparedBy);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: PreparedBy Inserted done.");
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updatePreparedBy()...");
      logger.error("SQLException while inserting PreparedBy: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updatePreparedBy()...");
      logger.error("Exception while inserting PreparedBy: " + e.getMessage());
    }
  }

  public void updatePreparedDate(String preparedDate, int auditID, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(UPDATE_PREPARED_DATE);

      ps.setDate(1, new Date(new java.util.Date(preparedDate).getTime()));
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: PreparedDate Inserted done.");
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updatePreparedDate()...");
      logger.error("SQLException while inserting PreparedDate: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updatePreparedDate()...");
      logger.error("Exception while inserting PreparedDate: " + e.getMessage());
    }
  }

  public void updateIsoContact(String isoContact, int auditID, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(UPDATE_ISO_CONTACT);

      ps.setString(1, isoContact);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: IsoContact Inserted done.");
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateIsoContact()...");
      logger.error("SQLException while inserting IsoContact: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateIsoContact()...");
      logger.error("Exception while inserting IsoContact: " + e.getMessage());
    }
  }



  public void updateAuditOverview(String auditOverview, int auditID, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(UPDATE_AUDIT_OVERVIEW);

      ps.setString(1, auditOverview);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: Audit Overview Inserted done.");
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAuditOverview()...");
      logger.error("SQLException while inserting Audit Overview: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAuditOverview()...");
      logger.error("Exception while inserting Audit Overview: " + e.getMessage());
    }
  }

  public void insertAuditedAreas(int auditID, AuditObject auditObj, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    //**Update to add the Areas Audited...
    Vector auditAreas = new Vector();

    if(auditObj.isConditioning()){
      auditAreas.add("1");
    }
    if(auditObj.isHarvest()){
      auditAreas.add("2");
    }
    if(auditObj.isPackaging()){
      auditAreas.add("3");
    }
    if(auditObj.isQaLab()){
      auditAreas.add("4");
    }
    if(auditObj.isWarehouseDistribution()){
      auditAreas.add("5");
    }
    if(auditObj.isField()){
      auditAreas.add("6");
    }
    if(auditObj.isPlanting()){
      auditAreas.add("7");
    }
    if(auditObj.isOffSiteFacilities()){
      auditAreas.add("8");
    }
    if(auditObj.isStewardship()){
      auditAreas.add("9");
    }
    

    //**Insert-Audit-Areas...
    for(int idx = 0; idx < auditAreas.size(); idx++){
      try{
        ps = conn.prepareStatement(INSERT_AUDIT_AREAS);

        ps.setInt(1, auditID);
        ps.setInt(2, Integer.parseInt(auditAreas.get(idx).toString()));

        ps.executeUpdate();

        conn.commit();

        logger.info("AuditDAO: AuditAreas Inserted done.");
      }
      catch(SQLException e){
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAuditAreas()...");
        logger.error("SQLException while inserting at AuditAreas(): " + e.getMessage());
      }
      catch(Exception e){
        logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAuditAreas()...");
        logger.error("Exception while inserting at AuditAreas(): " + e.getMessage());
      }
    }

  }

  public void insertFindingObject(int auditFindingID, int auditID, Date oracleSysdate, FindingObject findingObj, Connection conn) throws DAOException{
    PreparedStatement ps = null;
    ResultSet rs = null;

    //**Perform Insert-Operation...
    try{

//			if(findingObj.getCar_flag().equals("Y")){
//				ps = conn.prepareStatement(INSERT_CAR_FINDING_SQL);
//			}
//			else{
//				ps = conn.prepareStatement(INSERT_PAR_FINDING_SQL);
//			}

      ps = conn.prepareStatement(INSERT_AUDIT_FINDING_SQL);

      ps.setInt(1, auditFindingID);
      ps.setInt(2, auditID);
      ps.setString(3, findingObj.getFindingDesc());
      ps.setString(4, findingObj.getRowUserID());
      ps.setString(5, "Finding_Entry");
      ps.setDate(6, oracleSysdate);
      ps.setDate(7, oracleSysdate);
      ps.setString(8, findingObj.getCar_flag());

      //((OraclePreparedStatement)ps).setFixedCHAR(8, findingObj.getCar_flag());

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: InsertFinding() operation done.");


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertFindingObject()...");
      logger.error("SQLException inserting at insertFinding(): " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertFindingObject()...");
      logger.error("Exception inserting at insertFinding(): " + e.getMessage());
    }
  }


  public void updateFindingObject(int auditFindingID, Date oracleSysdate, FindingObject findingObj, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    //**Perform Insert-Operation...
    try{
      ps = conn.prepareStatement(UPDATE_AUDIT_FINDING_SQL);

      ps.setString(1, findingObj.getFindingDesc());
      ps.setString(2, findingObj.getRowUserID());
      ps.setString(3, "Finding_Modify");
      ps.setDate(4, oracleSysdate);
      ps.setInt(5, auditFindingID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: UpdateFinding() operation done.");


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateFindingObject()...");
      logger.error("SQLException inserting at updateFinding(): " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateFindingObject()...");
      logger.error("Exception inserting at updateFinding(): " + e.getMessage());
    }
  }


  public void updateCparInvestigationFinding(int auditFindingID, Date oracleSysdate, FindingObject findingObj, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(UPDATE_CPAR_INVESTIGATION_FINDING);

      ps.setString(1, findingObj.getFindingDesc());
      ps.setString(2, findingObj.getRowUserID());
      ps.setString(3, "CPAR MODIFY");
      ps.setDate(4, oracleSysdate);
      ps.setInt(5, auditFindingID);

      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: UpdateCparInvestigationFinding() operation done.");


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: UpdateCparInvestigationFinding()...");
      logger.error("SQLException inserting at UpdateCparInvestigationFinding): " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: UpdateCparInvestigationFinding()...");
      logger.error("Exception inserting at UpdateCparInvestigationFinding(): " + e.getMessage());
    }
  }


  public void insertAuditObject(int auditID, String autoAuditNumber, Date oracleSysdate, AuditObject auditObj, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    //**Perform Insert-Operation...
    try{
      ps = conn.prepareStatement(INSERT_AUDIT_SQL);

      ps.setInt(1, auditID);
      String plant_code = auditObj.getLocationCode();
      String[] plants = plant_code.split("_");

      ps.setString(2, plants[0]);
      ps.setString(11, plants[1]);

      ps.setDate(3, new Date(new java.util.Date(auditObj.getAuditDate()).getTime()));
      ps.setString(4, autoAuditNumber);
      ps.setString(5, auditObj.getAuditor());
      ps.setInt(6, Integer.parseInt(auditObj.getRegion_id()));
      ps.setString(7, auditObj.getRowUserID());
      ps.setString(8, "Audit_Entry");
      ps.setDate(9, oracleSysdate);
      ps.setDate(10, oracleSysdate);



      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: InsertAudit() operation done.");


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAuditObject()...");
      logger.error("SQLException inserting at insertAudit(): " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: insertAuditObject()...");
      logger.error("Exception inserting at insertAudit(): " + e.getMessage());
    }
  }

  public void updateAuditObject(int auditID, Date oracleSysdate, AuditObject auditObj, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    //**Perform Insert-Operation...
    try{
      ps = conn.prepareStatement(UPDATE_AUDIT_SQL);
      String plant_code = new String(auditObj.getAuditNumber().split("-")[1]);

      String[] plants = plant_code.split("_");

      ps.setString(1, plants[0]);
      ps.setDate(2, new Date(new java.util.Date(auditObj.getAuditDate()).getTime()));
      ps.setString(3, auditObj.getAuditor());
      ps.setInt(4, Integer.parseInt(auditObj.getRegion_id()));
      ps.setString(5, auditObj.getRowUserID());
      ps.setString(6, "Audit_Update");
      ps.setDate(7, oracleSysdate);
      ps.setString(8, plants[1]);
      ps.setInt(9, auditID);
      ps.executeUpdate();

      conn.commit();

      logger.info("AuditDAO: UpdateAudit() operation done.");


    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAuditObject()...");
      logger.error("SQLException inserting at updateAudit(): " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: updateAuditObject()...");
      logger.error("Exception inserting at updateAudit(): " + e.getMessage());
    }
  }

  public int getAuditSeqValue(Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditSeqNextVal = 0;

    try{
      ps = conn.prepareStatement(GET_AUDIT_SEQ_NEXTVAL);

      rs = ps.executeQuery();

      while(rs.next()){
        auditSeqNextVal = rs.getInt("NEXTVAL");
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditSeqValue()...");
      logger.error("SQLException while getting audit_seq: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditSeqValue()...");
      logger.error("Exception while getting audit_seq: " + e.getMessage());
    }


    return auditSeqNextVal;
  }


  public int getAuditFindingSeq(Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditFindingSeqNextVal = 0;

    try{
      ps = conn.prepareStatement(GET_AUDIT_FINDING_SEQ_NEXTVAL);

      rs = ps.executeQuery();

      while(rs.next()){
        auditFindingSeqNextVal = rs.getInt("NEXTVAL");
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFindingSeq()...");
      logger.error("SQLException while getting audit_finding_seq: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFindingSeq()...");
      logger.error("Exception while getting audit_finding_seq: " + e.getMessage());
    }


    return auditFindingSeqNextVal;
  }


  public int getAuditID (String auditNumber, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditID = 0;

    try{
      ps = conn.prepareStatement(GET_AUDIT_ID);
      ps.setString(1, auditNumber);

      rs = ps.executeQuery();

      while(rs.next()){
        auditID = rs.getInt("AUDIT_ID");
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditID()...");
      logger.error("SQLException while getting audit_id: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditID()...");
      logger.error("Exception while getting audit_id: " + e.getMessage());
    }


    return auditID;
  }


  public int deleteAuditedAreas (int auditID, Connection conn){
    PreparedStatement ps = null;

    try{
      ps = conn.prepareStatement(DELETE_AUDIT_AREAS);
      ps.setInt(1, auditID);

      ps.executeUpdate();
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: deleteAuditedAreas()...");
      logger.error("SQLException while deleting audit_areas: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: deleteAuditedAreas()...");
      logger.error("Exception while deleting audit_areas: " + e.getMessage());
    }


    return auditID;
  }

  public int getAuditFromFinding(int findingID, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditID = 0;

    try{
      ps = conn.prepareStatement(GET_AUDIT_FROM_FINDING);
      ps.setInt(1, findingID);

      rs = ps.executeQuery();

      while(rs.next()){
        auditID = rs.getInt("AUDIT_ID");
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFromFinding()...");
      logger.error("SQLException while getting audit_id from finding_id: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditFromFinding()...");
      logger.error("Exception while getting audit_id from finding_id: " + e.getMessage());
    }


    return auditID;
  }


  public String getAuditNoFromFinding(int findingID, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    String auditNumber = "";

    try{
      ps = conn.prepareStatement(GET_AUDIT_NUMBER_FROM_FINDING);
      ps.setInt(1, findingID);

      rs = ps.executeQuery();

      while(rs.next()){
        auditNumber = rs.getString("AUDIT_NUMBER");
      }

      return auditNumber;
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNoFromFinding()...");
      logger.error("SQLException while getting audit_id from finding_id: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditNoFromFinding()...");
      logger.error("Exception while getting audit_id from finding_id: " + e.getMessage());
    }

    return "";
  }

  public void getAuditDetails(int auditID, AuditObject audit, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(GET_AUDIT_DETAILS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();

      while(rs.next()){
        //**Required Fields...
        audit.setAuditID(rs.getInt("AUDIT_ID") + "");
        audit.setLocationCode(rs.getString("LOCATION_CODE")+"_"+rs.getString("RESPONSIBLE_LOCATION_ID"));
        audit.setAuditDate(getDateFormat(rs.getDate("AUDIT_DATE")));
        audit.setAuditNumber(rs.getString("AUDIT_NUMBER"));
        audit.setAuditor(rs.getString("AUDITOR"));
        audit.setRowUserID(rs.getString("ROW_USER_ID"));
        audit.setRegion_id(rs.getInt("REGION_ID") + "");

        //**Optional Fields...
        if(rs.getString("ISO_CONTACT") != null && !rs.getString("ISO_CONTACT").equals("")){
          audit.setSiteISOContact(rs.getString("ISO_CONTACT"));
        }
        if(rs.getString("AUDIT_OVERVIEW") != null && !rs.getString("AUDIT_OVERVIEW").equals("")){
          audit.setAuditOverview(rs.getString("AUDIT_OVERVIEW"));
        }
        if(rs.getString("PREPARED_BY") != null && !rs.getString("PREPARED_BY").equals("")){
          audit.setPreparedBy(rs.getString("PREPARED_BY"));
        }
        if(rs.getString("PREPARED_DATE") != null && !rs.getString("PREPARED_DATE").equals("")){
          audit.setPreparedDate(getDateFormat(rs.getDate("PREPARED_DATE")));
        }
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditDetails()...");
      logger.error("SQLException while getting audit details: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditDetails()...");
      logger.error("Exception while getting audit details: " + e.getMessage());
    }

  }


  public void getAuditAreas(int auditID, AuditObject audit, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(GET_AUDIT_AREAS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();

      Vector auditAreas = new Vector();

      while(rs.next()){
        auditAreas.add(rs.getInt("AUDIT_AREA_ID") + "");
      }

      for(int i = 0; i < auditAreas.size(); i++){
        setFieldsInAuditObject(auditAreas, i, audit);
      }

    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditAreas()...");
      logger.error("SQLException while getting audit areas: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getAuditAreas()...");
      logger.error("Exception while getting audit areas: " + e.getMessage());
    }

  }

  private void setFieldsInAuditObject(Vector auditAreas, int i, AuditObject audit) {
    if (auditAreas.get(i).equals("1")) {
      audit.setConditioning(true);
    }
    if (auditAreas.get(i).equals("2")) {
      audit.setHarvest(true);
    }
    if (auditAreas.get(i).equals("3")) {
      audit.setPackaging(true);
    }
    if (auditAreas.get(i).equals("4")) {
      audit.setQaLab(true);
    }
    if (auditAreas.get(i).equals("5")) {
      audit.setWarehouseDistribution(true);
    }
    if (auditAreas.get(i).equals("6")) {
      // Field = Regulatory Compliance in UI
      audit.setField(true);
    }
    if (auditAreas.get(i).equals("7")) {
      audit.setPlanting(true);
    }
    if (auditAreas.get(i).equals("8")) {
      audit.setOffSiteFacilities(true);
    }
    if (auditAreas.get(i).equals("9")) {
      audit.setStewardship(true);
    }
  }

  public void getFindingDetails(int auditID, AuditObject audit, Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(GET_FINDING_DETAILS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();

      while(rs.next()){

        //**Each record contains finding details...

        FindingObject findingObj = new FindingObject();

        int findingID = rs.getInt("AUDIT_FINDING_ID");

        findingObj.setFindingID(findingID + "");
        findingObj.setFindingDesc(rs.getString("DESCRIPTION"));
        findingObj.setRowUserID(rs.getString("ROW_USER_ID"));
        findingObj.setCar_flag(rs.getString("CAR_FLAG"));

        //**Get car_id/ctrl_no
        getCparDetails(findingID, findingObj, conn);

        //CAR-Map
        if(rs.getString("CAR_FLAG").equals("Y")){
          audit.getFindingCarMap().put(findingObj.getFindingID(), findingObj);
        }

        //PAR-Map
        if(rs.getString("CAR_FLAG").equals("N")){
          audit.getFindingParMap().put(findingObj.getFindingID(), findingObj);
        }

      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getFindingDetails()...");
      logger.error("SQLException while getting finding details: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getFindingDetails()...");
      logger.error("Exception while getting finding details: " + e.getMessage());
    }

  }

  public void getCparDetails(int findingID, FindingObject findingObj, Connection conn){
    PreparedStatement ps = null;
    ResultSet rs = null;

    try{
      ps = conn.prepareStatement(GET_CPAR_DETAILS);
      ps.setInt(1, findingID);

      rs = ps.executeQuery();

      while(rs.next()){
        findingObj.setCparID(rs.getInt("CPAR_ID") + "");
        findingObj.setControlNumber(rs.getString("CONTROL_NUMBER"));
        findingObj.setFindingType(rs.getString("FINDING_TYPE"));
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getCparDetails()...");
      logger.error("SQLException while getting cpar details: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getCparDetails()...");
      logger.error("Exception while getting cpar details: " + e.getMessage());
    }
  }

  public Date getOracleSysDate(Connection conn){

    PreparedStatement ps = null;
    ResultSet rs = null;

    Date oracleSysdate = new Date(System.currentTimeMillis());

    //**Get the oracle sysdate...
    try{
      ps = conn.prepareStatement(GET_ORACLE_SYSDATE);

      rs = ps.executeQuery();

      while(rs.next()){
        oracleSysdate = rs.getDate("SYSDATE");
      }
    }
    catch(SQLException e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getOracleSysDate()...");
      logger.error("SQLException while getting sysdate: " + e.getMessage());
    }
    catch(Exception e){
      logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.AuditDAOImpl, MethodName: getOracleSysDate()...");
      logger.error("Exception while getting sysdate: " + e.getMessage());
    }

    return oracleSysdate;
  }

  private String getDateFormat(Date date){
    try {
      sdf.format(date).toString();
      return sdf.format(date).toString();
    }
    catch (Exception e){
      return "";
    }
  }

}
