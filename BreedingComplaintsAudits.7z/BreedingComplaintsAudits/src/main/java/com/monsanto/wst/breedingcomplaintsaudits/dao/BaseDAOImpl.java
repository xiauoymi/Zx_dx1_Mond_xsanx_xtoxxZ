/*
 * Created on Mar 30, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import org.apache.commons.dbcp.BasicDataSource;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BaseDAOImpl {
	private DataSource datasource = null;
  private Connection conn = null;
  private static BasicDataSource basicDataSource ;
  /**
	 * Constructor. Initialize the datasource.
	 * @exception SQLException if lookup of datasource fails
	 */	
	public BaseDAOImpl() throws DAOException {

	    try {
            getDataStore();

          // Lookup for the datasource from JNDI tree
//		 	Context initContext = new InitialContext();
//		 	Context envContext  = (Context)initContext.lookup("java:/comp/env");
//		 	datasource = (DataSource)envContext.lookup("jdbc/bcasdatasource");
//        	String decryptedPassword = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", McasProperties.getMcasProperties().getString("com.monsanto.DBEncryption.key.path"), "CipherValue.hex", "KeyValue.hex");
//        	BasicDataSource bds = (BasicDataSource)datasource;
//        	bds.setPassword(decryptedPassword);

	    } catch (NamingException ne) {  // Naming errors

	      throw new DAOException("NamingException while looking"
	                             + " up DataSource Connection "
	                             + ne.toString());
	    }	
	    catch (EncryptorException ee) {  // Naming errors

		      throw new DAOException("EncryptionException while looking"
		                             + " up DataSource Connection "
		                             + ee.toString());
		}	    
	}

    private void getDataStore() throws NamingException, EncryptorException {
        String lsifunction = System.getProperty("lsi.function");
        String decryptedPassword = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", McasProperties.getMcasProperties().getString("com.monsanto.DBEncryption.key.path"), "CipherValue.hex", "KeyValue.hex");
        if(lsifunction!=null && lsifunction.equalsIgnoreCase("win")){
            datasource = getDataSource();
        }else{
            Context initContext = new InitialContext();
            Context envContext  = (Context)initContext.lookup("java:/comp/env");
            datasource = (DataSource)envContext.lookup("jdbc/bcasdatasource");
            BasicDataSource bds = (BasicDataSource)datasource;
            bds.setPassword(decryptedPassword);
        }
    }

  private DataSource getDataSource() {

    if(basicDataSource == null){
      basicDataSource = new BasicDataSource();
      basicDataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
      basicDataSource.setUrl("jdbc:oracle:oci:@comgend.monsanto.com:1521:comgend");
      basicDataSource.setUsername("BCAS");
      basicDataSource.setPassword("abc_123");
      basicDataSource.setLogAbandoned(true);
      basicDataSource.setRemoveAbandoned(true);
    }
    return basicDataSource;
  }

  /**
	 * Get connection from the datasource.
	 * @return Connection
	 * @throws SQLException
	 */
    protected Connection getConnection() throws SQLException {
	 	conn = datasource.getConnection();
     conn.setAutoCommit(false);
	 	return conn;
    }
    
    /**
     * Close connection.
     * @param conn
     * @throws SQLException
     */
    protected void closeConnection(Connection conn) throws SQLException {
        if ((conn != null) &&!conn.isClosed()) {
            conn.close();
            //conn = null;
          }    	
    }    
}
