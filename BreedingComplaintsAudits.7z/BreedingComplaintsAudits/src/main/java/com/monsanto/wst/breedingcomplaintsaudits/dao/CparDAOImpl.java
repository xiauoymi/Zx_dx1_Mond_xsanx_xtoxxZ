/*
 * Created on Feb 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import com.monsanto.wst.breedingcomplaintsaudits.model.Cpar;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparFilter;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparList;
import com.monsanto.wst.breedingcomplaintsaudits.model.CparLog;
import com.monsanto.wst.breedingcomplaintsaudits.taglib.reportTag.RowBean;
import org.apache.log4j.Category;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CparDAOImpl extends BaseDAOImpl implements CparDAO {
	
	static Category logger = Category.getInstance(CparDAOImpl.class.getName());

	private static final String CPAR_PK_SQL = "select CPAR_SEQ.nextval from dual";

	private static final String UPDATE_CPAR_SQL = "UPDATE CPAR SET " +
												   "STOP_SALE_ID=?, AUDIT_FINDING_ID=?," +
												   " COMPLAINT_ID=?, CPAR_SOURCE_TYPE_ID=?," +
												   " CAR_FLAG=?, CLAIM_NUMBER=?,STATUS_ID=?, REPORT_INITIATOR=?," +
												   " REPORTING_LOCATION_CODE=?, RESPONSIBLE_PLANT_CODE=?, FINDING_TYPE_ID=?," +
												   " ISO_STANDARD_ID=?, ISSUE_YEAR_ID=?, DATE_REPORTED=?, SITE_MANAGER=?," +
												 ////  " EVAL_FOR_EFFECT_DATE=?, EVAL_FOR_EFFECT_TYPE_ID=?, SITE_MANAGER=?," +
												   " ROW_USER_ID=?, ROW_TASK_ID=?, ROW_ENTRY_DATE=?," +
												   " ROW_MODIFY_DATE=?, REGION_ID=?, CONTROL_NUMBER=?, CREATED_BY=?, REPORT_INITIATOR_EMAIL=?, SUPPRESS_OVERDUE_NOTICE=?,  REPORTING_LOC_ID=?, RESPONSIBLE_LOC_ID = ?" +
												   " WHERE CPAR_ID=?";

	
	private static final String UPDATE_CPAR_DOCUMENTATION_SQL	="UPDATE CPAR_DOCUMENTATION SET " +
																"INVESTIGATION_FINDINGS=?, LONG_TERM_CORRECTION_ACTION=?, " +
																"ROOT_CAUSE=?, CONTAINMENT_ACTION=?, EVALUATION_COMMENTS=?, ROW_USER_ID=?, " +
																"ROW_TASK_ID=?, ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=?" +
																"WHERE CPAR_ID=?";
	
	
	private static final String UPDATE_CPAR_RESPONSIBILITY_SQL	="UPDATE CPAR_RESPONSIBILITY SET " +
																  "MGMT_APPROVAL_PERSON=?, MGMT_APPROVAL_DATE=?, " +
																  "LONG_TERM_CORRECT_ACT_PERSON=?, LONG_TERM_CORRECT_ACT_DATE=?, ROOT_CAUSE_PERSON=?,  " +
																  "ROOT_CAUSE_DATE=?, CONTAINMENT_ACTION_PERSON=?, CONTAINMENT_ACTION_DATE=?, " +
                                                                  "EVAL_RESPONSIBLE_PERSON=?, EVAL_DATE=?, EVAL_EFFECTIVE=?, EVAL_PERSON_NOTAPPLICABLE=?, "+
																  "ROW_USER_ID=?, ROW_TASK_ID=?, ROW_MODIFY_DATE=?, " +
																  "ROW_ENTRY_DATE=? " +
																  "WHERE CPAR_ID=?";

	private static final String CPAR_SQL = "INSERT INTO CPAR (" +
																   " CPAR_ID, STOP_SALE_ID, AUDIT_FINDING_ID, " +
																   "COMPLAINT_ID, CPAR_SOURCE_TYPE_ID, " +
																   "CAR_FLAG, CLAIM_NUMBER,STATUS_ID, REPORT_INITIATOR, " +
																   "REPORTING_LOCATION_CODE, RESPONSIBLE_PLANT_CODE, FINDING_TYPE_ID,  " +
																   "ISO_STANDARD_ID, ISSUE_YEAR_ID, DATE_REPORTED, SITE_MANAGER, " +
																  // "EVAL_FOR_EFFECT_DATE, EVAL_FOR_EFFECT_TYPE_ID " +
																   "ROW_USER_ID, ROW_TASK_ID, ROW_ENTRY_DATE, " +
																   "ROW_MODIFY_DATE, REGION_ID, CONTROL_NUMBER, CREATED_BY, REPORT_INITIATOR_EMAIL, SUPPRESS_OVERDUE_NOTICE, REPORTING_LOC_ID, RESPONSIBLE_LOC_ID) " +
																	"VALUES (? ,? ,? ," +
																	"? ,? ," +
																	"? ,? ,? , ?," +
																	"? ,? ,? ," +
																	"? ,? ,? ," +
																	"? ,? ,? ," +
																	"? ,? ,? ," +
																	"? ,? ,?, ?, ?, ? )";
				


	private static final String CPAR_DOCUMENTATION_SQL	="INSERT INTO CPAR_DOCUMENTATION ( " +
																"CPAR_ID, INVESTIGATION_FINDINGS, LONG_TERM_CORRECTION_ACTION, " +
																"ROOT_CAUSE, CONTAINMENT_ACTION, EVALUATION_COMMENTS, ROW_USER_ID, " +
																"ROW_TASK_ID, ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
																"VALUES ( ?, ?, ?, " +
																"?, ?, ?, " +
																"?, ?,?,? )";

	private static final String CPAR_RESPONSIBILITY_SQL	="INSERT INTO CPAR_RESPONSIBILITY ( " +
																"CPAR_ID, MGMT_APPROVAL_PERSON, MGMT_APPROVAL_DATE, " +
																"LONG_TERM_CORRECT_ACT_PERSON, LONG_TERM_CORRECT_ACT_DATE, ROOT_CAUSE_PERSON, " +
																"ROOT_CAUSE_DATE, CONTAINMENT_ACTION_PERSON, CONTAINMENT_ACTION_DATE, " +
                                                                "EVAL_RESPONSIBLE_PERSON, EVAL_DATE, EVAL_EFFECTIVE, EVAL_PERSON_NOTAPPLICABLE, "+
																"ROW_USER_ID, ROW_TASK_ID, ROW_MODIFY_DATE, " +
																"ROW_ENTRY_DATE) " +
																"VALUES ( ?, ?, ?," +
																" ?, ?, ?," +
																" ?, ?, ?," +
                                                                " ?, ?, ?, ?," +
																" ?, ?, ?, ?)";
	
	private static final String GET_CPAR_MAIN = "SELECT * FROM CPAR WHERE CPAR_ID=?";
	private static final String GET_LOCATION_CODE_BY_ID = "SELECT RL.LOCATION_CODE FROM RESPONSIBLE_LOCATION RL WHERE " +
		"RL.RESPONSIBLE_LOC_ID=?";

	private static final String GET_LOCATION_ID_BY_CODE = "SELECT RL.RESPONSIBLE_LOC_ID FROM RESPONSIBLE_LOCATION RL WHERE " +
		"RL.LOCATION_CODE=?";
	private static final String GET_CPAR_DOCUMENTATION = "SELECT * FROM CPAR_DOCUMENTATION WHERE CPAR_ID=?";
	private static final String GET_CPAR_RESPONSIBILITY = "SELECT * FROM CPAR_RESPONSIBILITY WHERE CPAR_ID=?";


    private static final String GET_CPARS_LIST =
            " SELECT  Ranking, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, STATUS_DESCRIPTION, REPORT_INITIATOR, ISO_STANDARD_ID, DATE_REPORTED,  " +
                    " REGION_DESCRIPTION FROM " +
                    " (SELECT ROWNUM as RANKING, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, " +
                    "STATUS_DESCRIPTION, REPORT_INITIATOR, ISO_STANDARD_ID, DATE_REPORTED, " +
                    "REGION_DESCRIPTION FROM " +
                    "(SELECT CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, " +
                    "(SELECT S.STATUS_DESCRIPTION FROM STATUS_REF S WHERE S.STATUS_ID=C.STATUS_ID) STATUS_DESCRIPTION, " +
                    "REPORT_INITIATOR, (SELECT CONCAT (ISO.STANDARD_NUMBER, CONCAT(' - ',ISO.DESCRIPTION)) FROM ISO_STANDARD_REF ISO \n" +
                    "WHERE ISO.ISO_STANDARD_ID=C.ISO_STANDARD_ID) ISO_STANDARD_ID, DATE_REPORTED, " +
                    "(SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=C.REGION_ID) REGION_DESCRIPTION " +
                    "FROM CPAR C ";

    private static final String GET_CPARS_LIST_OLD =
            " SELECT  Ranking, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, STATUS_DESCRIPTION, REPORT_INITIATOR, DATE_REPORTED,  " +
            " REGION_DESCRIPTION FROM " +
            " (SELECT ROWNUM as RANKING, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, " +
														"STATUS_DESCRIPTION, REPORT_INITIATOR, DATE_REPORTED, " +
														"REGION_DESCRIPTION FROM " +
														"(SELECT CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, " +
														"(SELECT S.STATUS_DESCRIPTION FROM STATUS_REF S WHERE S.STATUS_ID=C.STATUS_ID) STATUS_DESCRIPTION, " +
														"REPORT_INITIATOR, DATE_REPORTED, " +
														"(SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=C.REGION_ID) REGION_DESCRIPTION " +
														"FROM CPAR C ";
    private static final String GET_COUNT_CPARS_LIST = "SELECT COUNT(CPAR_ID) FROM CPAR C ";
	
	private static final String FIND_CONTROL_NUMBER = "SELECT COUNT(CPAR_ID) RECORDS FROM CPAR C WHERE upper(CONTROL_NUMBER)=upper('";
	
	private static final String FIND_CAR = "SELECT CPAR_ID FROM CPAR WHERE COMPLAINT_ID=";	
	
	private static final String FIND_CONTROL_NUMBER_TEXT = "SELECT CONTROL_NUMBER FROM CPAR WHERE COMPLAINT_ID=";
	
	private static final String UPDATE_STOP_SALE_DOC =
		"UPDATE " +
			"STOP_SALE_DOCUMENTATION " +
		"SET " +
			"ROOT_CAUSE = ?, " +
			"LONG_TERM_CORRECTION_ACTION = ? " +
		"WHERE " +
			"STOP_SALE_ID = (SELECT STOP_SALE_ID FROM CPAR WHERE CPAR_ID = ?)";
	
	private static final String GET_CPAR_REPORT =
		"SELECT " +
			"CPAR.CONTROL_NUMBER, " +
			"CPAR_SOURCE_TYPE_REF.DESCRIPTION GENERATOR, " +
			"CPAR.CAR_FLAG," +
			"STATUS_REF.STATUS_DESCRIPTION STATUS, " +
			"CPAR.REPORT_INITIATOR INITIATED_BY, " +
			"CPAR.REPORTING_LOCATION_CODE, " +
			"CPAR.RESPONSIBLE_PLANT_CODE, " +
			"FINDING_TYPE_REF.DESCRIPTION FINDING_TYPE, " +
			"ISO_STANDARD_REF.STANDARD_NUMBER ISO_STANDARD_NUMBER, " +
			"ISO_STANDARD_REF.DESCRIPTION ISO_ELEMENT, " +
			"YEAR_REF.SHORT_DESCRIPTION YEAR_OF_ISSUE, " +
			"CPAR.DATE_REPORTED, " +
		    "CPAR.EVAL_FOR_EFFECT_DATE, " +
			"EVAL_FOR_EFFECT_TYPE_REF.DESCRIPTION EFFECT_EVAL, " +
			"CPAR.SITE_MANAGER, " +
			"REGION_REF.REGION_DESCRIPTION REGION, " +
			"CPAR.CLAIM_NUMBER, " +
			"CPAR.CREATED_BY, " +
			"CPAR.REPORT_INITIATOR_EMAIL, " +
			"CPAR.ROW_USER_ID, " +
			"CPAR.ROW_TASK_ID, " +
			"CPAR.ROW_ENTRY_DATE, " +
			"CPAR.ROW_MODIFY_DATE, " +
			"CPAR_DOCUMENTATION.INVESTIGATION_FINDINGS, " +
            "CPAR_DOCUMENTATION.CONTAINMENT_ACTION, " +
            "CPAR_DOCUMENTATION.ROOT_CAUSE, " +
            "CPAR_DOCUMENTATION.LONG_TERM_CORRECTION_ACTION, " +
            "CPAR_DOCUMENTATION.EVALUATION_COMMENTS, " +
			"CPAR_RESPONSIBILITY.MGMT_APPROVAL_PERSON, " +
			"CPAR_RESPONSIBILITY.MGMT_APPROVAL_DATE, " +
            "CPAR_RESPONSIBILITY.CONTAINMENT_ACTION_PERSON, " +
			"CPAR_RESPONSIBILITY.CONTAINMENT_ACTION_DATE, " +
            "CPAR_RESPONSIBILITY.ROOT_CAUSE_PERSON, " +
			"CPAR_RESPONSIBILITY.ROOT_CAUSE_DATE, " +
            "CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_PERSON, " +
			"CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_DATE, " +
            "CPAR_RESPONSIBILITY.EVAL_RESPONSIBLE_PERSON, " +
			"CPAR_RESPONSIBILITY.EVAL_DATE " +
		"FROM " +
			"BCAS.CPAR, " +
			"BCAS.CPAR_DOCUMENTATION, " +
			"BCAS.CPAR_RESPONSIBILITY, " +
			"BCAS.CPAR_SOURCE_TYPE_REF, " +
			"BCAS.STATUS_REF, " +
			"BCAS.FINDING_TYPE_REF, " +
			"BCAS.ISO_STANDARD_REF, " +
			"BCAS.YEAR_REF, " +
			"BCAS.EVAL_FOR_EFFECT_TYPE_REF, " +
			"BCAS.REGION_REF " +
		"WHERE ( " +
			"(CPAR.CPAR_ID = CPAR_DOCUMENTATION.CPAR_ID(+)) " +
			"AND (CPAR.CPAR_ID = CPAR_RESPONSIBILITY.CPAR_ID(+)) " +
			"AND (CPAR_SOURCE_TYPE_REF.CPAR_SOURCE_TYPE_ID(+) =CPAR.CPAR_SOURCE_TYPE_ID) " +
			"AND (STATUS_REF.STATUS_ID(+) = CPAR.STATUS_ID) " +
			"AND (FINDING_TYPE_REF.FINDING_TYPE_ID(+) = CPAR.FINDING_TYPE_ID) " +
			"AND (ISO_STANDARD_REF.ISO_STANDARD_ID(+) = CPAR.ISO_STANDARD_ID) " +
			"AND (YEAR_REF.YEAR_ID(+) = CPAR.ISSUE_YEAR_ID) " +
			"AND (EVAL_FOR_EFFECT_TYPE_REF.EVAL_FOR_EFFECT_TYPE_ID(+) =CPAR.EVAL_FOR_EFFECT_TYPE_ID) " +
			"AND (REGION_REF.REGION_ID(+) = CPAR.REGION_ID) ";
	
	private static final String GET_CPAR_LOG =
		"SELECT " +
			"CPAR.CONTROL_NUMBER,STATUS_REF.STATUS_DESCRIPTION, CPAR.DATE_REPORTED, " +
			"CPAR_DOCUMENTATION.INVESTIGATION_FINDINGS, CPAR_RESPONSIBILITY.MGMT_APPROVAL_DATE, " +
			"CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_DATE, CPAR.EVAL_FOR_EFFECT_DATE, M_AUDIT.AUDIT_NUMBER " +
		"FROM " +
			"CPAR, CPAR_DOCUMENTATION, CPAR_RESPONSIBILITY, M_AUDIT, M_AUDIT_FINDINGS,STATUS_REF " +
		"WHERE " +
			"CPAR.CPAR_ID = CPAR_DOCUMENTATION.CPAR_ID(+) " +
			"AND CPAR.CPAR_ID = CPAR_RESPONSIBILITY.CPAR_ID(+) " +
			"AND M_AUDIT.AUDIT_ID(+) = M_AUDIT_FINDINGS.AUDIT_ID " +
			"AND M_AUDIT_FINDINGS.AUDIT_FINDING_ID(+) = CPAR.AUDIT_FINDING_ID " +
            "AND STATUS_REF.STATUS_ID = CPAR.STATUS_ID ";
	
	
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); 
	
	public CparDAOImpl() throws DAOException {
		
	}
    
	public String getCparPK() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(CPAR_PK_SQL);
			rs = ps.executeQuery();
			rs.next();
			String pk = rs.getString(1);
			return pk;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}

	private void insertUpdateCpar(Cpar c, boolean isUpdate) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String fillingCode;
		int parameterIndx = 1;
		try{
			conn = getConnection();
			if (isUpdate){
				ps = conn.prepareStatement(UPDATE_CPAR_SQL);
                ps.setLong(27,Long.parseLong(c.getCpar_id()));
				fillingCode = new String(c.getControl_number().split("-")[1]);

			}
			else {
				ps = conn.prepareStatement(CPAR_SQL);
                System.out.println(CPAR_SQL);
				ps.setLong(parameterIndx,Long.parseLong(c.getCpar_id()));
				fillingCode = new String(c.getFiling_location());
				parameterIndx++;
			}

			if (!(c.getStop_sale_id()==null) && !(c.getStop_sale_id().equals("")))
				ps.setLong(parameterIndx,Long.parseLong(c.getStop_sale_id()));
			else
				ps.setNull(parameterIndx,Types.INTEGER);

			if (!(c.getAudit_finding_id()==null) && !(c.getAudit_finding_id().equals("")))
				ps.setLong(parameterIndx+1,Long.parseLong(c.getAudit_finding_id()));
			else
				ps.setNull(parameterIndx+1,Types.INTEGER);


			if (!(c.getComplaint_id()==null) && !(c.getComplaint_id().equals("")))
				ps.setLong(parameterIndx+2,Long.parseLong(c.getComplaint_id()));
			else
				ps.setNull(parameterIndx+2,Types.INTEGER);

			if (!(c.getGenerator() == null) && !(c.getGenerator().equals("")))
				ps.setLong(parameterIndx+3,Long.parseLong(c.getGenerator()));
			else
				ps.setNull(parameterIndx+3,Types.INTEGER);

			ps.setString(parameterIndx+4,c.getCar_flag());
			ps.setString(parameterIndx+5,c.getClaim_number());

			if (!(c.getStatus_id() == null) && !(c.getStatus_id().equals("")))
				ps.setLong(parameterIndx+6,Long.parseLong(c.getStatus_id()));
			else
				ps.setNull(parameterIndx+6,Types.INTEGER);

            ps.setString(parameterIndx+7,c.getInitiated_by());

			String[] plants = fillingCode.split("_");
            ps.setString(parameterIndx+8, plants[0]);
            ps.setString(parameterIndx+24, plants[1]);

			plants = c.getResponsible_location().split("_");
            ps.setString(parameterIndx+9,plants[0]);
            ps.setString(parameterIndx+25,plants[1]);

			if (!(c.getFinding_type() == null) && !(c.getFinding_type().equals("")))
				ps.setLong(parameterIndx+10,Long.parseLong(c.getFinding_type()));
			else
				ps.setNull(parameterIndx+10,Types.INTEGER);
            System.out.println("Yahoooooooooooooooo!");
            System.out.println("c.getIso_standard() = " + c.getIso_standard());
            System.out.println("Yahoooooooooooooooo!");
            
            if (!(c.getIso_standard() == null) && !(c.getIso_standard().equals("")))
				ps.setLong(parameterIndx+11,Long.parseLong(c.getIso_standard()));
			else
				ps.setNull(parameterIndx+11,Types.INTEGER);

			if (!(c.getIssue_year() == null) && !(c.getIssue_year().equals("")))
				ps.setLong(parameterIndx+12,Long.parseLong(c.getIssue_year()));
			else
				ps.setNull(parameterIndx+12,Types.INTEGER);

			if (!(c.getReport_date() == null) && !(c.getReport_date().equals("")))
				ps.setDate(parameterIndx+13,new Date(new java.util.Date(c.getReport_date()).getTime()));
			else
				ps.setDate(parameterIndx+13,null);

			ps.setString(parameterIndx+14,c.getSite_manager());
			ps.setString(parameterIndx+15,c.getRow_user_id());
			if (isUpdate) {
				if (c.getCar_flag().equals("Y"))
					ps.setString(parameterIndx+16,"CAR EDIT");
				else if (c.getCar_flag().equals("N"))
					ps.setString(parameterIndx+16,"PAR EDIT");
				ps.setDate(parameterIndx+17,new Date(new java.util.Date(c.getRow_entry_date()).getTime()));
			}
			else if (!isUpdate) {
				if (c.getCar_flag().equals("Y"))
					ps.setString(parameterIndx+16,"CAR ENTRY");
				else if (c.getCar_flag().equals("N"))
					ps.setString(parameterIndx+16,"PAR ENTRY");
				ps.setDate(parameterIndx+17,new Date(new java.util.Date().getTime()));
			}
			ps.setDate(parameterIndx+18,new Date(new java.util.Date().getTime()));
			if (!(c.getRegion()==null) && !(c.getRegion().equals("")))
				ps.setInt(parameterIndx+19,Integer.parseInt(c.getRegion()));
			else
				ps.setNull(parameterIndx+19,Types.INTEGER);

			ps.setString(parameterIndx+20,c.getControl_number());
			ps.setString(parameterIndx+21,c.getCreated_by());
			ps.setString(parameterIndx+22,c.getReport_initiator_email());
            ps.setBoolean(parameterIndx+23,c.isSuppress_overdue_notice());



			if (ps.executeUpdate() > 0){
				this.insertCpar_Documentation(c,conn,isUpdate);
				this.insertCpar_Responsibility(c,conn,isUpdate);				
			}
			if (!(c.getComplaint_id()==null) && !(c.getComplaint_id().equals(""))) {
				ComplaintDAO complaintDao = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
				complaintDao.updateComplaintDocumentation(c);
			}
			conn.commit();
           	System.out.println("I Row Inserted/Updated !");
		}
		catch(Exception e){
			try  { 
				conn.rollback(); 
				}
			catch(Exception ex) {
				throw new DAOException(ex);
				}			
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}

	public void insertCpar(Cpar c) throws DAOException{
		insertUpdateCpar(c,false);
		//updateStopSaleDoc(c.getRoot_cause(), c.getLong_term_corrective_action(), Integer.parseInt(c.getCpar_id()));
	}
	
	public void updateCpar(Cpar c) throws DAOException{
		insertUpdateCpar(c,true);
		//updateStopSaleDoc(c.getRoot_cause(), c.getLong_term_corrective_action(), Integer.parseInt(c.getCpar_id()));
	}
	
	public void updateStopSaleDoc(String rootCause, String longTermCorrAction, int cparID){
		
		Connection conn = null;
		PreparedStatement ps = null;
		
		boolean result=false;
		try{
			conn = getConnection();
			
			ps = conn.prepareStatement(UPDATE_STOP_SALE_DOC);
			
			ps.setString(1, rootCause);
			ps.setString(2, longTermCorrAction);
			ps.setInt(3, cparID);
			
			ps.executeUpdate();
			
			conn.commit();
			
		}
		catch(SQLException e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSaleDoc()...");
			logger.error("SQLException while getting connection: " + e.getMessage());
		}
		catch(Exception e){
			logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSaleDoc()...");
			logger.error("Exception while getting connection: " + e.getMessage());
		}
		finally {
			  try {
			  	//**Close the result sets, statement and connection.
			    if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } 
			  catch(SQLException ex) {
			  	logger.error("FileName: com.monsanto.wst.breedingcomplaintsaudits.dao.StopSaleDAOImpl, MethodName: updateStopSaleDoc()...");
				logger.error("Exception while getting closing: " + ex.getMessage());
			  }
		}
	}
	
	
	public void deleteCpar(Cpar c) throws DAOException{
	}

	public boolean findControlNumber(String control_number) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		boolean result=false;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(FIND_CONTROL_NUMBER + control_number + "')");
			rs = ps.executeQuery();
			while (rs.next()){
				if (rs.getLong("RECORDS") > 0 ) 
					result = true;
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}

	public String findCAR(String complaint_id) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String result="";
		try{
			conn = getConnection();
			ps = conn.prepareStatement(FIND_CAR + complaint_id);
			rs = ps.executeQuery();
			while (rs.next()){
				result = rs.getString("CPAR_ID");
				break;
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public String findControlNumberText(String complaint_id) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String result="";
		try{
			conn = getConnection();
			ps = conn.prepareStatement(FIND_CONTROL_NUMBER_TEXT + complaint_id);
			rs = ps.executeQuery();
			while (rs.next()){
				result = rs.getString("CONTROL_NUMBER");
				break;
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public LinkedHashMap getCparsList(String controlNumber, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String carFlag, String filingLoc, String responsibleLoc, String isoStandard, String intPage, boolean getMax, String sortCrit, String sortOrd) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer whereClause;
		List paramList = new ArrayList();
		LinkedHashMap cpars = null;
		try{
			int Page = Integer.parseInt(intPage);
            createParamList(controlNumber, paramList, createDateFrom, createDateTo, initiatedBy, status, region, claimNumber, filingLoc, responsibleLoc, isoStandard, carFlag);
            conn = getConnection();
			whereClause = new StringBuffer();			
			if (paramList.size() > 0){
				whereClause.append("WHERE ");
			}
			for (int i =0;i<paramList.size();i++){
                generateWhereClause(paramList, i, whereClause, controlNumber, createDateFrom, createDateTo, initiatedBy, status, region, claimNumber, filingLoc, responsibleLoc, isoStandard, carFlag);
			}
			ps = conn.prepareStatement(GET_COUNT_CPARS_LIST + whereClause.toString());
			rs = ps.executeQuery();
			if (rs.next()){
				cpars = new LinkedHashMap();
				cpars.put("maxRows",rs.getString(1));
			}
            modifyWhereClauseBasedOnSortCriteria(sortCrit, whereClause, sortOrd, Page);
            ps = conn.prepareStatement(GET_CPARS_LIST + whereClause.toString());
            rs = ps.executeQuery();
			while (rs.next()){
                createCparsHashMap(rs, cpars);
			}
            return cpars;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}			
	}

    private void createParamList(String controlNumber, List paramList, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String filingLoc, String responsibleLoc, String isoStandard, String carFlag) {
        if (!(controlNumber == null) && !(controlNumber.equals("")))
            paramList.add("controlNumber");
        if (!(createDateFrom == null) && !(createDateFrom.equals("")))
            paramList.add("createDateFrom");
        if (!(createDateTo == null) && !(createDateTo.equals("")))
            paramList.add("createDateTo");
        if (!(initiatedBy == null) && !(initiatedBy.equals("")))
            paramList.add("initiatedBy");
        if (!(status == null) && !(status.equals("")) && !(status.equals("0")))
            paramList.add("status");
        if (!(region == null) && !(region.equals(""))  && !(region.equals("0")))
            paramList.add("region");
        if (!(claimNumber == null) && !(claimNumber.equals("")))
            paramList.add("claimNumber");
        if (!(filingLoc == null) && !(filingLoc.equals("")))
            paramList.add("filingLoc");
        if (!(responsibleLoc == null) && !(responsibleLoc.equals("")))
            paramList.add("responsibleLoc");
        if (!(isoStandard == null) && !(isoStandard.equals("")))
            paramList.add("isoStandard");
        if (!(carFlag == null) && !(carFlag.equals("")))
            paramList.add("carFlag");
    }

    private void generateWhereClause(List paramList, int i, StringBuffer whereClause, String controlNumber, String createDateFrom, String createDateTo, String initiatedBy, String status, String region, String claimNumber, String filingLoc, String responsibleLoc, String isoStandard, String carFlag) {
        String[] plants;
        if (paramList.get(i).equals("controlNumber")){
            whereClause.append("upper(C.CONTROL_NUMBER)=upper('" + controlNumber +"')");
        }
        if (paramList.get(i).equals("createDateFrom")){
            whereClause.append("C.DATE_REPORTED>=to_Date('" + createDateFrom + "','MM-dd-YYYY')");
        }
        if (paramList.get(i).equals("createDateTo")){
            whereClause.append("C.DATE_REPORTED<=to_Date('" + createDateTo + "','MM-dd-YYYY')");
        }
        if (paramList.get(i).equals("initiatedBy")){
            whereClause.append("upper(C.REPORT_INITIATOR) like upper('" + initiatedBy + "%')");
        }
        if (paramList.get(i).equals("status")){
            whereClause.append("C.STATUS_ID="+status);
        }
        if (paramList.get(i).equals("region")){
            whereClause.append("C.REGION_ID="+region);
        }
        if (paramList.get(i).equals("claimNumber")){
            whereClause.append("C.CLAIM_NUMBER='"+claimNumber+"'");
        }
        if (paramList.get(i).equals("filingLoc")){
            plants = filingLoc.split("_");
            whereClause.append("C.REPORTING_LOC_ID='"+plants[1]+"'");
        }
        if (paramList.get(i).equals("responsibleLoc")){
            plants = responsibleLoc.split("_");
            whereClause.append("C.RESPONSIBLE_LOC_ID='"+plants[1]+"'");
        }
        if (paramList.get(i).equals("isoStandard")){
            whereClause.append("C.ISO_STANDARD_ID='"+isoStandard+"'");
        }
        if (paramList.get(i).equals("carFlag")){
            whereClause.append("C.CAR_FLAG='"+carFlag+"'");
        }
        if (i < paramList.size() - 1)
            whereClause.append(" and ");
    }

    private void modifyWhereClauseBasedOnSortCriteria(String sortCrit, StringBuffer whereClause, String sortOrd, int page) {
        if (sortCrit.equals("DATE_REPORTED")) {
            whereClause.append(" ORDER BY " + sortCrit + " " + sortOrd + " ))  WHERE RANKING BETWEEN " + ((page * 10) - 9) + " and " + page * 10);
        } else {
            whereClause.append(" ORDER BY Lower(" + sortCrit + ") " + sortOrd + " ))  WHERE RANKING BETWEEN " + ((page * 10) - 9) + " and " + page * 10);
        }
    }

    private void createCparsHashMap(ResultSet rs, LinkedHashMap cpars) throws SQLException {
        CparList cparList = new CparList();
        createCPARListFromDatabaseResults(cparList, rs);
        cpars.put(rs.getString("CPAR_ID"), cparList) ;
    }

    private void createCPARListFromDatabaseResults(CparList cparList, ResultSet rs) throws SQLException {
        cparList.setCparId(rs.getString("CPAR_ID"));
        cparList.setControlNumber(rs.getString("CONTROL_NUMBER"));
        cparList.setCreatedDate(sdf.format(rs.getDate("DATE_REPORTED")));
        cparList.setInitiatedBy(rs.getString("REPORT_INITIATOR"));
        cparList.setIsoStandard(rs.getString("ISO_STANDARD_ID"));
        cparList.setStatus(rs.getString("STATUS_DESCRIPTION"));
/*
				cparList.setRegion(rs.getString("REGION_DESCRIPTION"));
*/
        if(rs.getString("CLAIM_NUMBER") != null){
            cparList.setClaimNumber(rs.getString("CLAIM_NUMBER"));
        }
        else{
            cparList.setClaimNumber("");
        }

        System.out.println("Returning the CPARList generated from the database\n");
    }

    public Cpar getCpar(String cpar_id) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Cpar c = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(GET_CPAR_MAIN);
			ps.setString(1,cpar_id);
			rs = ps.executeQuery();
			c = new Cpar();

			while (rs.next()){
				c.setCpar_id(rs.getString("CPAR_ID"));
				c.setStop_sale_id(rs.getString("STOP_SALE_ID"));
				c.setAudit_finding_id(rs.getString("AUDIT_FINDING_ID"));
				c.setComplaint_id(rs.getString("COMPLAINT_ID"));
				c.setCreated_by(rs.getString("CREATED_BY"));
				c.setGenerator(rs.getString("CPAR_SOURCE_TYPE_ID"));
				c.setCar_flag(rs.getString("CAR_FLAG"));
				c.setClaim_number(rs.getString("CLAIM_NUMBER"));
				c.setStatus_id(rs.getString("STATUS_ID"));
				c.setInitiated_by(rs.getString("REPORT_INITIATOR"));
				c.setFiling_location(rs.getString("REPORTING_LOCATION_CODE")+"_"+rs.getString("REPORTING_LOC_ID"));
				c.setResponsible_location(rs.getString("RESPONSIBLE_PLANT_CODE")+"_"+rs.getString("RESPONSIBLE_LOC_ID"));
				c.setFinding_type(rs.getString("FINDING_TYPE_ID"));
				c.setIso_standard(rs.getString("ISO_STANDARD_ID"));
				c.setIssue_year(rs.getString("ISSUE_YEAR_ID"));
				c.setReport_date(getDateFormat(rs.getDate("DATE_REPORTED")));
				c.setEvaluation_date(getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
				c.setEffectiveness_evaluator(rs.getString("EVAL_FOR_EFFECT_TYPE_ID"));
				c.setSite_manager(rs.getString("SITE_MANAGER"));
				c.setRow_entry_date(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
				c.setRegion(rs.getString("REGION_ID"));
				c.setControl_number(rs.getString("CONTROL_NUMBER"));
                c.setSuppress_overdue_notice(rs.getBoolean("SUPPRESS_OVERDUE_NOTICE"));
                if ((rs.getString("CONTROL_NUMBER")).startsWith("CI-"))
                   c.setContinual_Improvements("2");
                else
                    c.setContinual_Improvements("1");

				c.setReport_initiator_email(rs.getString("REPORT_INITIATOR_EMAIL"));
				c.setRow_user_id(rs.getString("ROW_USER_ID"));
			}
			ps = conn.prepareStatement(GET_CPAR_RESPONSIBILITY);
			ps.setString(1,cpar_id);
			rs = ps.executeQuery();
			while (rs.next()){
				c.setMgmt_approval_person(rs.getString("MGMT_APPROVAL_PERSON"));
				c.setMgmt_approval_date(getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
				c.setLong_term_corrective_action_person(rs.getString("LONG_TERM_CORRECT_ACT_PERSON"));
				c.setLong_term_corrective_action_date(getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));	
				c.setRoot_cause_person(rs.getString("ROOT_CAUSE_PERSON"));
				c.setRoot_cause_date(getDateFormat(rs.getDate("ROOT_CAUSE_DATE")));	
				c.setContainment_actions_person(rs.getString("CONTAINMENT_ACTION_PERSON"));
				c.setContainment_actions_date(getDateFormat(rs.getDate("CONTAINMENT_ACTION_DATE")));
                c.setEvaluation_person(rs.getString("EVAL_RESPONSIBLE_PERSON"));
                c.setEvaluation_date(getDateFormat(rs.getDate("EVAL_DATE")));
                c.setEvaluation_effective(rs.getString("EVAL_EFFECTIVE"));
                c.setEvaluation_not_applicable(rs.getBoolean("EVAL_PERSON_NOTAPPLICABLE"));

			}
			ps = conn.prepareStatement(GET_CPAR_DOCUMENTATION);
			ps.setString(1,cpar_id);
			rs = ps.executeQuery();
			while (rs.next()){
				c.setInvestigation_findings(rs.getString("INVESTIGATION_FINDINGS"));
				c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
				c.setRoot_cause(rs.getString("ROOT_CAUSE"));
				c.setContainment_actions(rs.getString("CONTAINMENT_ACTION"));
                c.setEvaluation_comments(rs.getString("EVALUATION_COMMENTS") );
			}
			return c;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}

	public HashMap getCparReport(CparFilter cparFilter) throws DAOException{
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer whereClause = new StringBuffer();
		HashMap hash = new HashMap();
		
		try{
			conn = getConnection();
			
			whereClause.append(" AND CPAR.CAR_FLAG = '" + cparFilter.getCarFlag().trim() + "' ");
			
			if ((cparFilter.getControlNumber() != null) && !(cparFilter.getControlNumber().equals(""))){
				whereClause.append(" AND UPPER(CPAR.CONTROL_NUMBER) LIKE UPPER('" + cparFilter.getControlNumber().trim() + "%') ");
			}
			if ((cparFilter.getClaimNumber() != null) && !(cparFilter.getClaimNumber().equals(""))){
				whereClause.append(" AND UPPER(CPAR.CLAIM_NUMBER) LIKE UPPER('" + cparFilter.getClaimNumber().trim() + "%') ");
			}
			if ((cparFilter.getInitiatedBy() != null) && !(cparFilter.getInitiatedBy().equals(""))){
				whereClause.append(" AND UPPER(CPAR.REPORT_INITIATOR) LIKE UPPER('" + cparFilter.getInitiatedBy().trim() + "%') ");
			}

		    if ((cparFilter.getFilingLocation() != null) && (cparFilter.getFilingLocation().length > 0)) {
			    String [] plant_codes = cparFilter.getFilingLocation();
			    String [] plants = new String[plant_codes.length];
			    String [] code;
			    boolean bflag = false;

			    for(int i=0; i < plant_codes.length; i++){
				    code =  plant_codes[i].split("_");
				    if(code.length == 2){
						plants[i] = new String(code[1]);
						bflag = true;
				    }
			    }
			    if(bflag)
			        whereClause.append(getSelectedFields(" AND CPAR.REPORTING_LOC_ID IN ", plants));
		    }
		    if ((cparFilter.getResponsibleLocation() != null) && (cparFilter.getResponsibleLocation().length > 0)) {
			    String [] responsible_loc_code = cparFilter.getResponsibleLocation();
			    String [] resp_locs = new String[responsible_loc_code.length];
			    String [] location;
				boolean bflag = false;
			    for(int i=0; i < responsible_loc_code.length; i++){
				    location =  responsible_loc_code[i].split("_");
				    if(location.length == 2){
				        resp_locs[i] = new String(location[1]);
					    bflag = true;
				    }
			    }
			    if(bflag)
			        whereClause.append(getSelectedFields(" AND CPAR.RESPONSIBLE_LOC_ID IN ", resp_locs));
		    }
			if ((cparFilter.getStatus() != null) && (cparFilter.getStatus().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.STATUS_ID IN ", cparFilter.getStatus()));				
			}
			if ((cparFilter.getYearOfIssue() != null) && (cparFilter.getYearOfIssue().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.ISSUE_YEAR_ID IN ", cparFilter.getYearOfIssue()));				
			}
			if ((cparFilter.getRegion() != null) && (cparFilter.getRegion().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.REGION_ID IN ", cparFilter.getRegion()));				
			}
			if ((cparFilter.getGenerator() != null) && (cparFilter.getGenerator().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.CPAR_SOURCE_TYPE_ID IN ", cparFilter.getGenerator()));				
			}
			if ((cparFilter.getEffectivenessEvaluation() != null) && (cparFilter.getEffectivenessEvaluation().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.EVAL_FOR_EFFECT_TYPE_ID IN ", cparFilter.getEffectivenessEvaluation()));				
			}
			if ((cparFilter.getFindingType() != null) && (cparFilter.getFindingType().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.FINDING_TYPE_ID IN ", cparFilter.getFindingType()));				
			}
			if ((cparFilter.getIsoElement() != null) && (cparFilter.getIsoElement().length > 0)){
				whereClause.append(getSelectedFields(" AND CPAR.ISO_STANDARD_ID IN ", cparFilter.getIsoElement()));				
			}
			
			whereClause.append(" ) ORDER BY CONTROL_NUMBER ");				
			
			logger.info(GET_CPAR_REPORT + whereClause.toString());
            System.out.println("whereClause = '" + whereClause.toString() + "'\n");

            ps = conn.prepareStatement(GET_CPAR_REPORT + whereClause.toString());
			
			rs = ps.executeQuery();
			
			int rowCount = 0;
			while (rs.next()){
				
				rowCount++;
				
				//** Fill in the RowBean Object...
				RowBean rowBean = new RowBean();
				
				if(rs.getString("CONTROL_NUMBER") != null && !(rs.getString("CONTROL_NUMBER").trim().equals(""))){
					rowBean.setCol1(rs.getString("CONTROL_NUMBER"));
				}
				else{
					rowBean.setCol1("-");
				}				
				if(rs.getString("GENERATOR") != null && !(rs.getString("GENERATOR").trim().equals(""))){
					rowBean.setCol2(rs.getString("GENERATOR"));
				}
				else{
					rowBean.setCol2("-");
				}				
				if(rs.getString("CAR_FLAG") != null && !(rs.getString("CAR_FLAG").trim().equals(""))){
					rowBean.setCol3(rs.getString("CAR_FLAG"));
				}
				else{
					rowBean.setCol3("-");
				}				
				if(rs.getString("STATUS") != null && !(rs.getString("STATUS").trim().equals(""))){
					rowBean.setCol4(rs.getString("STATUS"));
				}
				else{
					rowBean.setCol4("-");
				}
				if(rs.getString("INITIATED_BY") != null && !(rs.getString("INITIATED_BY").trim().equals(""))){
					rowBean.setCol5(rs.getString("INITIATED_BY"));
				}
				else{
					rowBean.setCol5("-");
				}
				if(rs.getString("REPORTING_LOCATION_CODE") != null && !(rs.getString("REPORTING_LOCATION_CODE").trim().equals(""))){
					rowBean.setCol6(rs.getString("REPORTING_LOCATION_CODE"));
				}
				else{
					rowBean.setCol6("-");
				}				
				if(rs.getString("RESPONSIBLE_PLANT_CODE") != null && !(rs.getString("RESPONSIBLE_PLANT_CODE").trim().equals(""))){
					rowBean.setCol7(rs.getString("RESPONSIBLE_PLANT_CODE"));
				}
				else{
					rowBean.setCol7("-");
				}				
				if(rs.getString("FINDING_TYPE") != null && !(rs.getString("FINDING_TYPE").trim().equals(""))){
					rowBean.setCol8(rs.getString("FINDING_TYPE"));
				}
				else{
					rowBean.setCol8("-");
				}				
				if(rs.getString("ISO_STANDARD_NUMBER") != null && !(rs.getString("ISO_STANDARD_NUMBER").trim().equals(""))){
					rowBean.setCol9(rs.getString("ISO_STANDARD_NUMBER"));
				}
				else{
					rowBean.setCol9("-");
				}
				if(rs.getString("ISO_ELEMENT") != null && !(rs.getString("ISO_ELEMENT").trim().equals(""))){
					rowBean.setCol10(rs.getString("ISO_ELEMENT"));
				}
				else{
					rowBean.setCol10("-");
				}
				
/*
				if(rs.getString("YEAR_OF_ISSUE") != null && !(rs.getString("YEAR_OF_ISSUE").trim().equals(""))){
					rowBean.setCol11(rs.getString("YEAR_OF_ISSUE"));
				}
				else{
					rowBean.setCol11("-");
				}
*/
				if(rs.getDate("DATE_REPORTED") != null){
					rowBean.setCol11(getDateFormat(rs.getDate("DATE_REPORTED")));
				}
				else{
					rowBean.setCol11("-");
				}				
				if(rs.getDate("EVAL_FOR_EFFECT_DATE") != null){
					rowBean.setCol12(getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
				}
				else{
					rowBean.setCol12("-");
				}				
				if(rs.getString("EFFECT_EVAL") != null && !(rs.getString("EFFECT_EVAL").trim().equals(""))){
					rowBean.setCol13(rs.getString("EFFECT_EVAL"));
				}
				else{
					rowBean.setCol13("-");
				}				
				if(rs.getString("SITE_MANAGER") != null && !(rs.getString("SITE_MANAGER").trim().equals(""))){
					rowBean.setCol14(rs.getString("SITE_MANAGER"));
				}
				else{
					rowBean.setCol14("-");
				}
/*
				if(rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))){
					rowBean.setCol16(rs.getString("REGION"));
				}
				else{
					rowBean.setCol16("-");
				}
				if(rs.getString("CLAIM_NUMBER") != null && !(rs.getString("CLAIM_NUMBER").trim().equals(""))){
					rowBean.setCol17(rs.getString("CLAIM_NUMBER"));
				}
				else{
					rowBean.setCol17("-");
				}				
*/
				if(rs.getString("CREATED_BY") != null && !(rs.getString("CREATED_BY").trim().equals(""))){
					rowBean.setCol15(rs.getString("CREATED_BY"));
				}
				else{
					rowBean.setCol15("-");
				}				
				if(rs.getString("REPORT_INITIATOR_EMAIL") != null && !(rs.getString("REPORT_INITIATOR_EMAIL").trim().equals(""))){
					rowBean.setCol16(rs.getString("REPORT_INITIATOR_EMAIL"));
				}
				else{
					rowBean.setCol16("-");
				}				
				if(rs.getString("ROW_USER_ID") != null && !(rs.getString("ROW_USER_ID").trim().equals(""))){
					rowBean.setCol17(rs.getString("ROW_USER_ID"));
				}
				else{
					rowBean.setCol17("-");
				}
				
				if(rs.getString("ROW_TASK_ID") != null && !(rs.getString("ROW_TASK_ID").trim().equals(""))){
					rowBean.setCol18(rs.getString("ROW_TASK_ID"));
				}
				else{
					rowBean.setCol18("-");
				}				
				if(rs.getDate("ROW_ENTRY_DATE") != null){
					rowBean.setCol19(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
				}
				else{
					rowBean.setCol19("-");
				}				
				if(rs.getDate("ROW_MODIFY_DATE") != null){
					rowBean.setCol20(getDateFormat(rs.getDate("ROW_MODIFY_DATE")));
				}
				else{
					rowBean.setCol20("-");
				}				
				if(rs.getString("INVESTIGATION_FINDINGS") != null && !(rs.getString("INVESTIGATION_FINDINGS").trim().equals(""))){
					rowBean.setCol21(rs.getString("INVESTIGATION_FINDINGS"));
				}
				else{
					rowBean.setCol21("-");
				}
                if(rs.getString("CONTAINMENT_ACTION") != null && !(rs.getString("CONTAINMENT_ACTION").trim().equals(""))){
					rowBean.setCol22(rs.getString("CONTAINMENT_ACTION"));
				}
				else{
					rowBean.setCol22("-");
				}
                if(rs.getString("ROOT_CAUSE") != null && !(rs.getString("ROOT_CAUSE").trim().equals(""))){
					rowBean.setCol23(rs.getString("ROOT_CAUSE"));
				}
				else{
					rowBean.setCol23("-");
				}
                if(rs.getString("LONG_TERM_CORRECTION_ACTION") != null && !(rs.getString("LONG_TERM_CORRECTION_ACTION").trim().equals(""))){
					rowBean.setCol24(rs.getString("LONG_TERM_CORRECTION_ACTION"));
				}
				else{
					rowBean.setCol24("-");
				}
                if(rs.getString("EVALUATION_COMMENTS") != null && !(rs.getString("EVALUATION_COMMENTS").trim().equals(""))){
					rowBean.setCol25(rs.getString("EVALUATION_COMMENTS"));
				}
				else{
					rowBean.setCol25("-");
				}

				if(rs.getString("MGMT_APPROVAL_PERSON") != null && !(rs.getString("MGMT_APPROVAL_PERSON").trim().equals(""))){
					rowBean.setCol26(rs.getString("MGMT_APPROVAL_PERSON"));
				}
				else{
					rowBean.setCol26("-");
				}				
				if(rs.getDate("MGMT_APPROVAL_DATE") != null){
					rowBean.setCol27(getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
				}
				else{
					rowBean.setCol27("-");
				}
                if(rs.getString("CONTAINMENT_ACTION_PERSON") != null && !(rs.getString("CONTAINMENT_ACTION_PERSON").trim().equals(""))){
					rowBean.setCol28(rs.getString("CONTAINMENT_ACTION_PERSON"));
				}
				else{
					rowBean.setCol28("-");
				}
				if(rs.getDate("CONTAINMENT_ACTION_DATE") != null){
					rowBean.setCol29(getDateFormat(rs.getDate("CONTAINMENT_ACTION_DATE")));
				}
				else{
					rowBean.setCol29("-");
				}
                if(rs.getString("ROOT_CAUSE_PERSON") != null && !(rs.getString("ROOT_CAUSE_PERSON").trim().equals(""))){
					rowBean.setCol30(rs.getString("ROOT_CAUSE_PERSON"));
				}
				else{
					rowBean.setCol30("-");
				}
				if(rs.getDate("ROOT_CAUSE_DATE") != null){
					rowBean.setCol31(getDateFormat(rs.getDate("ROOT_CAUSE_DATE")));
				}
				else{
					rowBean.setCol31("-");
				}
                if(rs.getString("LONG_TERM_CORRECT_ACT_PERSON") != null && !(rs.getString("LONG_TERM_CORRECT_ACT_PERSON").trim().equals(""))){
					rowBean.setCol32(rs.getString("LONG_TERM_CORRECT_ACT_PERSON"));
				}
				else{
					rowBean.setCol32("-");
				}
				
				if(rs.getDate("LONG_TERM_CORRECT_ACT_DATE") != null){
					rowBean.setCol33(getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
				}
				else{
					rowBean.setCol33("-");
				}
                if(rs.getString("EVAL_RESPONSIBLE_PERSON") != null && !(rs.getString("EVAL_RESPONSIBLE_PERSON").trim().equals(""))){
					rowBean.setCol34(rs.getString("EVAL_RESPONSIBLE_PERSON"));
				}
				else{
					rowBean.setCol34("-");
				}
				if(rs.getDate("EVAL_DATE") != null){
					rowBean.setCol35(getDateFormat(rs.getDate("EVAL_DATE")));
				}
				else{
					rowBean.setCol35("-");
				}

				hash.put(rowCount + "", rowBean);
				
			}
			
			return hash;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	  //**Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}
	
	public HashMap getCparLog(CparLog cparLog) throws DAOException{
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer whereClause = new StringBuffer();
		HashMap hash = new HashMap();
		
		List paramList = new ArrayList();
		
		try{
			if (!(cparLog.getCparFlag() == null) && !(cparLog.getCparFlag().equals("")) && !(cparLog.getCparFlag().equals("0")))
				paramList.add("cparFlag");
			if (!(cparLog.getResponsibleLocation() == null) && !(cparLog.getResponsibleLocation().equals("")) && !(cparLog.getResponsibleLocation().equals("0")))
				paramList.add("responsibleLocation");
			if ((cparLog.getYearOfIssue() != null) && (cparLog.getYearOfIssue().length > 0))
				paramList.add("yearOfIssue");
		
			
			for (int i =0; i < paramList.size(); i++){
				if (paramList.get(i).equals("cparFlag")){
					if(cparLog.getCparFlag().equals("1")){
						whereClause.append("AND CPAR.CAR_FLAG = 'Y' ");
					}
					if(cparLog.getCparFlag().equals("2")){
						whereClause.append(" AND CPAR.CAR_FLAG = 'N' ");
					}
				}
				if (paramList.get(i).equals("responsibleLocation")){
					String[] plants = cparLog.getResponsibleLocation().split("_");
					whereClause.append(" AND CPAR.RESPONSIBLE_LOC_ID = '" + plants[1] + "' ");
				}
				if (paramList.get(i).equals("yearOfIssue")){
					whereClause.append(getSelectedFields(" AND CPAR.ISSUE_YEAR_ID IN ", cparLog.getYearOfIssue()));
				}													
			}
			
			conn = getConnection();
			
			if(paramList.size() > 0){
				logger.info(GET_CPAR_LOG + whereClause.toString());			
				ps = conn.prepareStatement(GET_CPAR_LOG + whereClause.toString());
			}
			else{
				logger.info(GET_CPAR_LOG);			
				ps = conn.prepareStatement(GET_CPAR_LOG);
			}
			
			rs = ps.executeQuery();
			
			int rowCount = 0;
			while (rs.next()){
				
				rowCount++;
				
				//** Fill in the RowBean Object...
				RowBean rowBean = new RowBean();
				
				if(rs.getString("CONTROL_NUMBER") != null && !(rs.getString("CONTROL_NUMBER").trim().equals(""))){
					rowBean.setCol1(rs.getString("CONTROL_NUMBER"));
				}
				else{
					rowBean.setCol1("-");
				}											
				if(rs.getDate("DATE_REPORTED") != null){
					rowBean.setCol2(getDateFormat(rs.getDate("DATE_REPORTED")));
				}
				else{
					rowBean.setCol2("-");
				}				
				if(rs.getString("INVESTIGATION_FINDINGS") != null && !(rs.getString("INVESTIGATION_FINDINGS").trim().equals(""))){
					rowBean.setCol3(rs.getString("INVESTIGATION_FINDINGS"));
				}
				else{
					rowBean.setCol3("-");
				}
				if(rs.getDate("MGMT_APPROVAL_DATE") != null){
					rowBean.setCol4(getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
				}
				else{
					rowBean.setCol4("-");
				}
				if(rs.getDate("LONG_TERM_CORRECT_ACT_DATE") != null){
					rowBean.setCol5(getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
				}
				else{
					rowBean.setCol5("-");
				}				
				if(rs.getDate("EVAL_FOR_EFFECT_DATE") != null){
					rowBean.setCol6(getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
				}
				else{
					rowBean.setCol6("-");
				}				
				if(rs.getString("STATUS_DESCRIPTION") != null && !(rs.getString("STATUS_DESCRIPTION").trim().equals(""))){
					rowBean.setCol7(rs.getString("STATUS_DESCRIPTION"));
				}
				else{
					rowBean.setCol7("-");
				}
				if(rs.getString("AUDIT_NUMBER") != null && !(rs.getString("AUDIT_NUMBER").trim().equals(""))){
					rowBean.setCol8(rs.getString("AUDIT_NUMBER"));
				}
				else{
					rowBean.setCol8("-");
				}				
				
				hash.put(rowCount + "", rowBean);
				
			}
			
			return hash;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	  //**Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}
	
	/**
	 * This method just makes a string out of selected fields like ('1744', '1745',...)
	 * 
	 * @param strArray
	 * @return
	 */
	private StringBuffer getSelectedFields(String query, String[] strArray){
		
		int size = strArray.length;
		
		StringBuffer fieldClause = new StringBuffer();
		fieldClause.append("");
		
		//**To remove the null elements...
		for(int i = 0; i < size; i++){
			
			if(strArray[i].equals("") || strArray[i].equals("0")){
				size--;
			}
		}
		
		if(size == 0){
			return fieldClause;
		}
		
		fieldClause.append(query + "(");
		
		for(int i = 0; i < strArray.length; i++){
			
			//**Skip null elements...
			if(strArray[i].equals("") || strArray[i].equals("0")){
				continue;
			}
			
			fieldClause.append("'" + strArray[i].trim() + "'");
			
			if (i < strArray.length - 1){
				fieldClause.append(",");
			}
		}
		
		fieldClause.append(")");
		
		return fieldClause;
	}
	
	private int insertCpar_Documentation(Cpar c, Connection conn, boolean isUpdate) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rows = 0;
		int paramIndx = 1;
		try{
			if (isUpdate){
				ps = conn.prepareStatement(UPDATE_CPAR_DOCUMENTATION_SQL);
				ps.setLong(10,Long.parseLong(c.getCpar_id()));
			}
			else{
				ps = conn.prepareStatement(CPAR_DOCUMENTATION_SQL);
				ps.setLong(paramIndx,Long.parseLong(c.getCpar_id()));
				paramIndx++;
			}
			ps.setString(paramIndx,c.getInvestigation_findings());
			ps.setString(paramIndx+1,c.getLong_term_corrective_action());
			ps.setString(paramIndx+2,c.getRoot_cause());
			ps.setString(paramIndx+3,c.getContainment_actions());
            ps.setString(paramIndx+4,c.getEvaluation_comments());
			ps.setString(paramIndx+5,"APPLICATION");
			ps.setString(paramIndx+6,"CPAR ENTRY");
			ps.setDate(paramIndx+7,new Date(new java.util.Date().getTime()));
			ps.setDate(paramIndx+8,new Date(new java.util.Date().getTime()));
			rows = ps.executeUpdate();
			conn.commit();
			return rows;
		}
		catch(Exception e){
			
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();

			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}	
	
	private int insertCpar_Responsibility(Cpar c, Connection conn, boolean isUpdate) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rows = 0;
		int paramIndx = 1;
		try{
			if (isUpdate) {
				ps = conn.prepareStatement(UPDATE_CPAR_RESPONSIBILITY_SQL);
				ps.setLong(17,Long.parseLong(c.getCpar_id()));
			}
			else {
				ps = conn.prepareStatement(CPAR_RESPONSIBILITY_SQL);
				ps.setLong(paramIndx,Long.parseLong(c.getCpar_id()));
				paramIndx++;
              }
			ps.setString(paramIndx,c.getMgmt_approval_person());
			if (!(c.getMgmt_approval_date() == null) && !(c.getMgmt_approval_date().equals("")))
				ps.setDate(paramIndx+1,new Date(new java.util.Date(c.getMgmt_approval_date()).getTime()));
			else
				ps.setDate(paramIndx+1,null);
			ps.setString(paramIndx+2,c.getLong_term_corrective_action_person());
			if (!(c.getLong_term_corrective_action_date() == null) && !(c.getLong_term_corrective_action_date().equals("")))
				ps.setDate(paramIndx+3,new Date(new java.util.Date(c.getLong_term_corrective_action_date()).getTime()));
			else
				ps.setDate(paramIndx+3,null);

			ps.setString(paramIndx+4,c.getRoot_cause_person());
			if (!(c.getRoot_cause_date() == null) && !(c.getRoot_cause_date().equals("")))
				ps.setDate(paramIndx+5,new Date(new java.util.Date(c.getRoot_cause_date()).getTime()));
			else
				ps.setDate(paramIndx+5,null);

			ps.setString(paramIndx+6,c.getContainment_actions_person());
			if (!(c.getContainment_actions_date() == null) && !(c.getContainment_actions_date().equals("")))
				ps.setDate(paramIndx+7,new Date(new java.util.Date(c.getContainment_actions_date()).getTime()));
			else
				ps.setDate(paramIndx+7,null);


            ps.setString(paramIndx+8,c.getEvaluation_person());

            if (!(c.getEvaluation_date() == null) && !(c.getEvaluation_date().equals("")))
				ps.setDate(paramIndx+9,new Date(new java.util.Date(c.getEvaluation_date()).getTime()));
			else
				ps.setDate(paramIndx+9,null);


            ps.setString(paramIndx+10,c.getEvaluation_effective());
            ps.setBoolean(paramIndx+11,c.isEvaluation_not_applicable());
			ps.setString(paramIndx+12,"APPLICATION");
            if (c.getCar_flag().equals("Y"))
				ps.setString(paramIndx+13,"CAR ENTRY");
            else
                ps.setString(paramIndx+13,"PAR ENTRY");
          	ps.setDate(paramIndx+14,new Date(new java.util.Date().getTime()));
			ps.setDate(paramIndx+15,new Date(new java.util.Date().getTime()));

            System.out.println("CPAR_ID is: " + c.getCpar_id());
         	rows = ps.executeUpdate();
			conn.commit();
         	return rows;
		}
		catch(Exception e){
			throw new DAOException(e);
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}	
	
	private String getDateFormat(Date date){
		try {
			sdf.format(date).toString();
			return sdf.format(date).toString();
		}
		catch (Exception e){
			return "";
		}
	}
	private String lookupLocationCodeById(String locId, Connection conn) throws DAOException{
		PreparedStatement ps;
		ResultSet rs;
		String code = null;
		try{
			ps =  conn.prepareStatement(GET_LOCATION_CODE_BY_ID);
			ps.setString(1,locId);
			rs = ps.executeQuery();
			rs.next();
			code = rs.getString(1);

		}catch(SQLException ex){
			throw new DAOException(ex.toString());
		}
		return code;
	}
	private String lookupLocationIdByCode(String locCode, Connection conn) throws DAOException{
		PreparedStatement ps;
		ResultSet rs;
		String code = null;
		try{
			ps =  conn.prepareStatement(GET_LOCATION_ID_BY_CODE);
			ps.setString(1,locCode);
			rs = ps.executeQuery();
			rs.next();
			code = rs.getString(1);

		}catch(SQLException ex){
			throw new DAOException(ex.toString());
		}
		return code;
	}
}
