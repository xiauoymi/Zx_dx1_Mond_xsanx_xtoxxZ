/*
 * Created on Jan 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.dao;

import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jbrahmb
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LookUpDAOImpl extends BaseDAOImpl implements LookUpDAO {

	private static String STATES_LKP = "select state_id, state_abbr from state_ref order by state_abbr asc";
	private static String STATUS_LKP = "select s.status_id, s.status_description from status_ref s, status_type_ref st " +
											"where s.status_type_id = st.status_type_id ";
	private static String LOCATION_LKP = "select location_code, location_short_name from location_ref " +
											"where active_flag = ? order by location_short_name asc";
	private static String RESPONSIBLE_LOCATION_LKP =
										"SELECT R.RESPONSIBLE_LOC_ID, L.LOCATION_SHORT_NAME, F.FUNCTION_CODE, R.PROGRAM_CODE, R.LOCATION_CODE  " +
										"FROM RESPONSIBLE_LOCATION R, LOCATION_REF L, FUNCTION_REF F " +
										"WHERE R.LOCATION_CODE = L.LOCATION_CODE AND F.FUNCTION_ID = R.FUNCTION_ID AND L.ACTIVE_FLAG = 'Y' " +
										"ORDER BY L.LOCATION_SHORT_NAME ASC";

    private static String QUALITY_ISSUE_LKP = "select complaint_quality_issue_id, complaint_quality_issue from complaint_quality_issue_ref " +
											"order by complaint_quality_issue_id asc";

	private static String EMAIL_LKP = " from location_ref " +
	"where location_code = ?";	

	private static String OWNER_EMAIL_FLAG_LKP = "select email_owner_flag from location_ref " + 
	"where location_code = ?";	
	
	private static String CAR_SEND_EMAILS = "select c.cpar_id, c.control_number, l.e_mail,l.OWNER_EMAIL,l.EMAIL_OWNER_FLAG from cpar c, cpar_documentation cd, location_ref l " +
											"where c.RESPONSIBLE_PLANT_CODE=l.LOCATION_CODE and c.CPAR_ID=cd.CPAR_ID and c.CAR_FLAG='Y'  " +
											"and c.STATUS_ID != 6 and c.STATUS_ID != 5 and (c.STATUS_ID!=7  or length(trim(cd.CONTAINMENT_ACTION)) IS NULL or length(trim(cd.ROOT_CAUSE)) IS NULL or length(trim(cd.LONG_TERM_CORRECTION_ACTION)) IS NULL) " +
                                            " and (c.suppress_overdue_notice = '0' or c.suppress_overdue_notice is null) and sysdate > c.row_entry_date + ";
	
	private static String GET_EMAIL_SERVICE_PARAMS="select APP_PARAMETER_CODE,CHARACTER_VALUE,NUMERIC_VALUE,TIMESTAMP from APP_PARAMETER where APP_PARAMETER_CODE IN ('CAR_OVERDUE_INT','ES_START_TIME','ES_INTERVAL','MAIL_SENT_DATE')";
	
	private static String GENERATOR_LKP = "SELECT CPAR_SOURCE_TYPE_ID, DESCRIPTION, ACTIVE_FLAG FROM CPAR_SOURCE_TYPE_REF WHERE ACTIVE_FLAG = ? ORDER BY DESCRIPTION";

	private static String EFFECT_EVALUATOR_LKP = "SELECT EVAL_FOR_EFFECT_TYPE_ID, DESCRIPTION, ACTIVE_FLAG FROM EVAL_FOR_EFFECT_TYPE_REF WHERE ACTIVE_FLAG = ? ORDER BY DESCRIPTION";
	
	private static String FINDING_TYPE_LKP = "SELECT FINDING_TYPE_ID, DESCRIPTION, ACTIVE_FLAG FROM FINDING_TYPE_REF WHERE ACTIVE_FLAG = ? ORDER BY DESCRIPTION";
	
	private static String ISO_STANDARD_LKP = "SELECT ISO_STANDARD_ID, STANDARD_NUMBER, DESCRIPTION, ACTIVE_FLAG, REPORT_STATUS_FLAG FROM ISO_STANDARD_REF WHERE ACTIVE_FLAG = ? ORDER BY STANDARD_NUMBER";
	
	private static String YEAR_LKP = "select year_id, short_description from year_ref order by short_description desc";
	
	private static String CROP_LKP = "select crop_id, short_description from crop_ref where active_flag = ? order by short_description asc";
	
	private static String SEEDSIZE_LKP = "select seed_size_id, description from seed_size_ref where active_flag = ? order by description asc";
	
	private static String QTYUOM_LKP = "select qty_uom_id, qty_description from qty_uom_ref where active_flag = ? order by qty_description asc";
	
	private static String VARIETY_LKP = "select variety_id, description from variety_ref where active_flag = ? order by description asc";
	
	private static String BRAND_LKP = "select brand_id, description from brand_ref where active_flag = ?";
	private static String REGION_LKP = "select * from region_ref order by region_description asc";
	
	private static String SET_MAIL_SENT_PARAM =
		"UPDATE app_parameter " +
		"SET " +
			"numeric_value = ?, " +
			"row_modify_date = sysdate " +
		"WHERE " +
			"app_parameter_code = 'MAIL_SENT_DATE'";
	
	private static String ADD_MAIL_SENT_PARAM =
		"INSERT INTO APP_PARAMETER " +
				"(APP_PARAMETER_CODE, NUMERIC_VALUE, DESCR, ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROW_TASK_ID, ROW_USER_ID) " +
		"VALUES ('MAIL_SENT_DATE', ?, 'To avoid the duplicate emails sent.', SYSDATE, SYSDATE, 'PROG', 'RDESAI2')";
	
	private static Log logger = LogFactory.getLog(LookUpDAOImpl.class);
    private static final String COMPLAINT_SEND_EMAILS = "select feedback.complaint_id, l.e_mail, l.OWNER_EMAIL,l.EMAIL_OWNER_FLAG from bcas.complaint feedback, bcas.complaint_documentation fd, bcas.location_ref l\n" +
            "          where feedback.RESPONSIBLE_PLANT_CODE=l.LOCATION_CODE and feedback.complaint_ID=fd.complaint_ID \n" +
            "\t\t  and feedback.STATUS_ID != 12 and feedback.STATUS_ID != 1 and (feedback.STATUS_ID!=13  or length(trim(fd.CONTAINMENT_ACTION)) IS NULL) \n" +
            "          and sysdate > feedback.row_entry_date + ";

    /**
	 * Constructor. Initialize the datasource.
	 */
	public LookUpDAOImpl() throws DAOException {

	}
	
   
    public Map getStates() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(STATES_LKP);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put(""," ");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}
	
	
	public Map getStatus(String type) throws DAOException{
		if (logger.isDebugEnabled())
			logger.debug(this);
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			StringBuffer whereClause = new StringBuffer(STATUS_LKP);
			whereClause.append("and st.status_type_description ='" + type.toUpperCase() + "'");
			whereClause.append(" and s.active_flag = 'Y'");
			ps = conn.prepareStatement(whereClause.toString());
			System.out.println(whereClause);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new HashMap();
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	
	public Map getLocations() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(LOCATION_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select Location");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}

	public Map getResponsibleLocations() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(RESPONSIBLE_LOCATION_LKP);
			System.out.println(RESPONSIBLE_LOCATION_LKP);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select Location");
				String program_code;
				while (rs.next()){
					if((program_code = rs.getString(4)) == null)
						program_code = "";

					result.put(rs.getString(5)+"_"+rs.getString(1),rs.getString(2)+",   "+rs.getString(3)+"   "+program_code);
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}


    public Map getQualityIssues() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(QUALITY_ISSUE_LKP);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select One");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}
	}

	public Map getYear() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(YEAR_LKP);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Year");
				while(rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	
	public Map getCrops() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(CROP_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select one");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	
	public Map getSeedSize() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(SEEDSIZE_LKP);
			ps.setString(1,"Y");			
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select One");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	
	public Map getUOM() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(QTYUOM_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("","Select UOM");
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}

	
	public Map getVarities() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(VARIETY_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				while (rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}


	public Map getBrands() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(BRAND_LKP);
			ps.setString(1,"Y");			
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new HashMap();
				while(rs.next()){
					result.put(rs.getString(1),rs.getString(2));
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}

	public Map getRegions() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(REGION_LKP);
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("",McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.cpar.selectRegion"));
				while(rs.next()){
					result.put(rs.getString("REGION_ID"),rs.getString("REGION_DESCRIPTION"));
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}	
	
	public Map getGenerator() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(GENERATOR_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("",McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.cpar.selectGenerator"));
				while (rs.next()){
					result.put(rs.getString("CPAR_SOURCE_TYPE_ID"),rs.getString("DESCRIPTION"));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public Map getEffectivenessEvaluator() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(EFFECT_EVALUATOR_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("",McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.cpar.selectEvaluator"));
				while (rs.next()){
					result.put(rs.getString("EVAL_FOR_EFFECT_TYPE_ID"),rs.getString("DESCRIPTION"));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public Map getFindingTypes() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(FINDING_TYPE_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("",McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.cpar.selectFindingType"));
				while (rs.next()){
					result.put(rs.getString("FINDING_TYPE_ID"),rs.getString("DESCRIPTION"));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public Map getISOStandards() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		Map result = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(ISO_STANDARD_LKP);
			ps.setString(1,"Y");
			rs = ps.executeQuery();
			if ( rs != null ){
				result = new LinkedHashMap();
				result.put("",McasProperties.getMcasProperties().getString("com.monsanto.wst.breedingcomplaintsaudits.cpar.selectStandard"));
				while (rs.next()){
					result.put(rs.getString("ISO_STANDARD_ID"),rs.getString("STANDARD_NUMBER") + "   - " + rs.getString("DESCRIPTION"));
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	public String[] getEmail(String locationCode) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String[] result = new String[2];
		String flag="";
		try{
			conn = getConnection();
			ps = conn.prepareStatement(OWNER_EMAIL_FLAG_LKP);
			ps.setString(1,locationCode);
			rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				flag = rs.getString("EMAIL_OWNER_FLAG");
			}
			if (flag.equals("Y"))
				ps = conn.prepareStatement("Select e_mail,owner_email" + EMAIL_LKP);
			else
				ps = conn.prepareStatement("Select e_mail" +EMAIL_LKP);
			ps.setString(1,locationCode);
			rs = ps.executeQuery();
			if ( rs != null ){
				while (rs.next()){
					if (rs.getString("E_MAIL")!=null)
						result[0]=rs.getString("E_MAIL").trim();
					if (flag.equals("Y")){
						if (rs.getString("OWNER_EMAIL")!=null)
							result[1]=rs.getString("OWNER_EMAIL").trim();
					}						
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}	
	
	public Map getCAREmails(int overdueIntvl) throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String[] emails;
		Map result=null;
		String flag="";
		try{
			conn = getConnection();
            ps = conn.prepareStatement(CAR_SEND_EMAILS + overdueIntvl);
            rs = ps.executeQuery();
            if (rs != null) {
				result = new HashMap();
				while (rs.next()){
					flag = rs.getString("EMAIL_OWNER_FLAG");
					if (flag.equals("Y")) {
						emails=new String[3];
						emails[0]=rs.getString("CONTROL_NUMBER");
						if (rs.getString("E_MAIL")!=null)
							emails[1]=rs.getString("E_MAIL").trim();
						else
							emails[1]="";
						if (rs.getString("OWNER_EMAIL")!=null)
							emails[2]=rs.getString("OWNER_EMAIL").trim();
						else
							emails[2]="";
					}
					else {
						emails=new String[2];
						emails[0]=rs.getString("CONTROL_NUMBER");
						if (rs.getString("E_MAIL")!=null)
							emails[1]=rs.getString("E_MAIL").trim();
						else
							emails[1]="";
					}
					result.put(rs.getString("cpar_id"),emails);
				}
			}
			return result;			
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}	

	public Map getEmailServiceParams() throws DAOException{
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String[] emails;
		Map result=null;
		String parameter="";
		try{
			conn = getConnection();
			ps = conn.prepareStatement(GET_EMAIL_SERVICE_PARAMS);
			//ps.setString(1,);
			rs = ps.executeQuery();
			result = new HashMap();
			while (rs.next()){
				if(rs.getString("APP_PARAMETER_CODE") != null && !rs.getString("APP_PARAMETER_CODE").equals("")){
					parameter = rs.getString("APP_PARAMETER_CODE");
					if (parameter.trim().equals("ES_START_TIME") && rs.getString("CHARACTER_VALUE")!=null)
						result.put(parameter,rs.getString("CHARACTER_VALUE").trim());
					else if (rs.getString("NUMERIC_VALUE")!=null)
						result.put(parameter,new Integer(rs.getInt("NUMERIC_VALUE")));
				}
			}
			return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	/** 
	 * This method stores the date(int) on which the mail was sent,
	 * this is to avoid the duplicate emails sent each day.
	 */
	public void setMailSentDateParam(int mailSentDate) throws DAOException{
		PreparedStatement ps = null;
		Connection conn = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(SET_MAIL_SENT_PARAM);
			ps.setInt(1, mailSentDate);
			ps.executeUpdate();		
			conn.commit();
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	  // Close the result sets, statement and connection.
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}
	
	/** 
	 * This method is to add a new entry called "MAIL_SENT_DATE" into the DB...
	 */
	public void addMailSentDateParam(int mailSentDate) throws DAOException{
		PreparedStatement ps = null;
		Connection conn = null;
		try{
			conn = getConnection();
			ps = conn.prepareStatement(ADD_MAIL_SENT_PARAM);
			ps.setInt(1, mailSentDate);
			ps.executeUpdate();		
			conn.commit();
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	  // Close the result sets, statement and connection.
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
	}

    public Map getComplaintEmails(int overdue) throws DAOException {
        PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		String[] emails;
		Map result=null;
		String flag="";
		try{
			conn = getConnection();
            ps = conn.prepareStatement(COMPLAINT_SEND_EMAILS + overdue);
            rs = ps.executeQuery();
            if (rs != null) {
				result = new HashMap();
				while (rs.next()){
					flag = rs.getString("EMAIL_OWNER_FLAG");
					if (flag.equals("Y")) {
						emails=new String[3];
						emails[0]=rs.getString("COMPLAINT_ID");
						if (rs.getString("E_MAIL")!=null)
							emails[1]=rs.getString("E_MAIL").trim();
						else
							emails[1]="";
						if (rs.getString("OWNER_EMAIL")!=null)
							emails[2]=rs.getString("OWNER_EMAIL").trim();
						else
							emails[2]="";
					}
					else {
						emails=new String[2];
						emails[0]=rs.getString("COMPLAINT_ID");
						if (rs.getString("E_MAIL")!=null)
							emails[1]=rs.getString("E_MAIL").trim();
						else
							emails[1]="";
					}
					result.put(rs.getString("complaint_id"),emails);
				}
			}
            System.out.println("result = " + result.values());
            return result;
		}
		catch(SQLException e){
			throw new DAOException(e.getMessage(),e);
		}
		catch(Exception e){
			throw new DAOException(e.getMessage());
		}finally {
			  try {
			  	// Close the result sets, statement and connection.
			      if (rs != null) rs.close();
			      if (ps != null) ps.close();
			      this.closeConnection(conn);
			  } catch(SQLException ex) {
			        throw new DAOException(ex.toString());
			  }
		}		
    }
}
