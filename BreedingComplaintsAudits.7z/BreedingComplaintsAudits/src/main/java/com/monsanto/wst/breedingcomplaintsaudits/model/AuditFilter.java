/*
 * Created on Jun 20, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import java.io.Serializable;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditFilter implements Serializable{
	
	private String auditNumber;
	private String auditDate;
	private String preparedBy;
	private String preparedDate;
	
	private String[] site;
	private String[] region;
	
	private String auditor;
	private String siteIsoContact;
	private String cparNumber;
	
	private boolean conditioning;
	private boolean fields;
	private boolean harvest;
	private boolean packaging;
	private boolean planting;
	private boolean qaLab;
	private boolean warehouseDistribution;
	private boolean offSiteFacilities;
  private boolean stewardShip;


  /**
	 * @return Returns the auditDate.
	 */
	public String getAuditDate() {
		return auditDate;
	}
	/**
	 * @param auditDate The auditDate to set.
	 */
	public void setAuditDate(String auditDate) {
		this.auditDate = auditDate;
	}
	
	/**
	 * @return Returns the cparNumber.
	 */
	public String getCparNumber() {
		return cparNumber;
	}
	/**
	 * @param cparNumber The cparNumber to set.
	 */
	public void setCparNumber(String cparNumber) {
		this.cparNumber = cparNumber;
	}
	/**
	 * @return Returns the auditNumber.
	 */
	public String getAuditNumber() {
		return auditNumber;
	}
	/**
	 * @param auditNumber The auditNumber to set.
	 */
	public void setAuditNumber(String auditNumber) {
		this.auditNumber = auditNumber;
	}
	/**
	 * @return Returns the auditor.
	 */
	public String getAuditor() {
		return auditor;
	}
	/**
	 * @param auditor The auditor to set.
	 */
	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}
	/**
	 * @return Returns the conditioning.
	 */
	public boolean isConditioning() {
		return conditioning;
	}
	/**
	 * @param conditioning The conditioning to set.
	 */
	public void setConditioning(boolean conditioning) {
		this.conditioning = conditioning;
	}
	/**
	 * @return Returns the fields.
	 */
	public boolean isFields() {
		return fields;
	}
	/**
	 * @param fields The fields to set.
	 */
	public void setFields(boolean fields) {
		this.fields = fields;
	}
	/**
	 * @return Returns the harvest.
	 */
	public boolean isHarvest() {
		return harvest;
	}
	/**
	 * @param harvest The harvest to set.
	 */
	public void setHarvest(boolean harvest) {
		this.harvest = harvest;
	}
	/**
	 * @return Returns the offSiteFacilities.
	 */
	public boolean isOffSiteFacilities() {
		return offSiteFacilities;
	}
	/**
	 * @param offSiteFacilities The offSiteFacilities to set.
	 */
	public void setOffSiteFacilities(boolean offSiteFacilities) {
		this.offSiteFacilities = offSiteFacilities;
	}
	/**
	 * @return Returns the packaging.
	 */
	public boolean isPackaging() {
		return packaging;
	}
	/**
	 * @param packaging The packaging to set.
	 */
	public void setPackaging(boolean packaging) {
		this.packaging = packaging;
	}
	/**
	 * @return Returns the planting.
	 */
	public boolean isPlanting() {
		return planting;
	}
	/**
	 * @param planting The planting to set.
	 */
	public void setPlanting(boolean planting) {
		this.planting = planting;
	}
	/**
	 * @return Returns the preparedBy.
	 */
	public String getPreparedBy() {
		return preparedBy;
	}
	/**
	 * @param preparedBy The preparedBy to set.
	 */
	public void setPreparedBy(String preparedBy) {
		this.preparedBy = preparedBy;
	}
	/**
	 * @return Returns the preparedDate.
	 */
	public String getPreparedDate() {
		return preparedDate;
	}
	/**
	 * @param preparedDate The preparedDate to set.
	 */
	public void setPreparedDate(String preparedDate) {
		this.preparedDate = preparedDate;
	}
	/**
	 * @return Returns the qaLab.
	 */
	public boolean isQaLab() {
		return qaLab;
	}
	/**
	 * @param qaLab The qaLab to set.
	 */
	public void setQaLab(boolean qaLab) {
		this.qaLab = qaLab;
	}
	/**
	 * @return Returns the region.
	 */
	public String[] getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String[] region) {
		this.region = region;
	}
	/**
	 * @return Returns the site.
	 */
	public String[] getSite() {
		return site;
	}
	/**
	 * @param site The site to set.
	 */
	public void setSite(String[] site) {
		this.site = site;
	}
	/**
	 * @return Returns the siteIsoContact.
	 */
	public String getSiteIsoContact() {
		return siteIsoContact;
	}
	/**
	 * @param siteIsoContact The siteIsoContact to set.
	 */
	public void setSiteIsoContact(String siteIsoContact) {
		this.siteIsoContact = siteIsoContact;
	}
	/**
	 * @return Returns the warehouseDistribution.
	 */
	public boolean isWarehouseDistribution() {
		return warehouseDistribution;
	}
	/**
	 * @param warehouseDistribution The warehouseDistribution to set.
	 */
	public void setWarehouseDistribution(boolean warehouseDistribution) {
		this.warehouseDistribution = warehouseDistribution;
	}

  public boolean isStewardShip() {
    return stewardShip;
  }

  public void setStewardShip(boolean stewardShip) {
    this.stewardShip = stewardShip;
  }
}
