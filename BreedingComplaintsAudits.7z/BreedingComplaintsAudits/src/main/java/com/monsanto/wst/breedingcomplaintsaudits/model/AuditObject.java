/*
 * Created on Apr 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.model;

import com.monsanto.wst.breedingcomplaintsaudits.util.ComparisonUtil;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author rdesai2
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditObject implements Serializable, Cloneable {
  private String locationCode;
  private String auditDate;
  private String auditNumber;
  private String auditID;
  private String auditor;
  private String auditorEmail;
  private String siteISOContact;
  private String siteISOContactEmail;
  private boolean conditioning;
  private boolean field;
  private boolean harvest;
  private boolean packaging;
  private boolean planting;
  private boolean qaLab;
  private boolean warehouseDistribution;
  private boolean offSiteFacilities;
  private boolean stewardship;
  private String auditOverview;
  private String preparedBy;
  private String preparedByEmail;
  private String preparedDate;
  private String submitString = "1";
  private String resetString = "Reset";
  private String cancelString = "-2";
  private String region_id;
  private String rowUserID;
  private HashMap findingCarMap = new HashMap();
  private HashMap findingParMap = new HashMap();
  FindingObject editFindingObj = new FindingObject();
  boolean findingCarMapEmpty = true;
  boolean findingParMapEmpty = true;


  //private String currentTab;

  /**
   * @return Returns the currentTab.
   */
//	public String getCurrentTab() {
//		return currentTab;
//	}
  /**
   * @param currentTab The currentTab to set.
   */
//	public void setCurrentTab(String currentTab) {
//		this.currentTab = currentTab;

  //	}

  /**
   * @return Returns the editFindingObj.
   */
  public FindingObject getEditFindingObj() {
    return editFindingObj;
  }

  /**
   * @param editFindingObj The editFindingObj to set.
   */
  public void setEditFindingObj(FindingObject editFindingObj) {
    this.editFindingObj = editFindingObj;
  }

  /**
   * @return Returns the findingCarMap.
   */
  public HashMap getFindingCarMap() {
    return findingCarMap;
  }

  /**
   * @param findingCarMap The findingCarMap to set.
   */
  public void setFindingCarMap(HashMap findingCarMap) {
    this.findingCarMap = findingCarMap;
  }

  /**
   * @return Returns the findingParMap.
   */
  public HashMap getFindingParMap() {
    return findingParMap;
  }

  /**
   * @param findingParMap The findingParMap to set.
   */
  public void setFindingParMap(HashMap findingParMap) {
    this.findingParMap = findingParMap;
  }

  /**
   * @return Returns the rowUserID.
   */
  public String getRowUserID() {
    return rowUserID;
  }

  /**
   * @param rowUserID The rowUserID to set.
   */
  public void setRowUserID(String rowUserID) {
    this.rowUserID = rowUserID;
  }

  /**
   * @return Returns the region_id.
   */
  public String getRegion_id() {
    return "1";
  }

  /**
   * @param region_id The region_id to set.
   */
  public void setRegion_id(String region_id) {
    this.region_id = "1";
  }

  /**
   * @return Returns the preparedByEmail.
   */
  public String getPreparedByEmail() {
    return preparedByEmail;
  }

  /**
   * @param preparedByEmail The preparedByEmail to set.
   */
  public void setPreparedByEmail(String preparedByEmail) {
    this.preparedByEmail = preparedByEmail;
  }

  /**
   * @return Returns the resetString.
   */
  public String getResetString() {
    return resetString;
  }

  /**
   * @param resetString The resetString to set.
   */
  public void setResetString(String resetString) {
    this.resetString = resetString;
  }

  /**
   * @return Returns the submitString.
   */
  public String getSubmitString() {
    return submitString;
  }

  /**
   * @param submitString The submitString to set.
   */
  public void setSubmitString(String submitString) {
    this.submitString = submitString;
  }

  /**
   * @return Returns the auditNumber.
   */
  public String getAuditNumber() {
    return auditNumber;
  }

  /**
   * @param auditNumber The auditNumber to set.
   */
  public void setAuditNumber(String auditNumber) {
    this.auditNumber = auditNumber;
  }

  /**
   * @return Returns the conditioning.
   */
  public boolean isConditioning() {
    return conditioning;
  }

  /**
   * @param conditioning The conditioning to set.
   */
  public void setConditioning(boolean conditioning) {
    this.conditioning = conditioning;
  }

  /**
   * @return Returns the field.
   */
  public boolean isField() {
    return field;
  }

  /**
   * @param field The field to set.
   */
  public void setField(boolean field) {
    this.field = field;
  }

  /**
   * @return Returns the harvest.
   */
  public boolean isHarvest() {
    return harvest;
  }

  /**
   * @param harvest The harvest to set.
   */
  public void setHarvest(boolean harvest) {
    this.harvest = harvest;
  }

  /**
   * @return Returns the offSiteFacilities.
   */
  public boolean isOffSiteFacilities() {
    return offSiteFacilities;
  }

  /**
   * @param offSiteFacilities The offSiteFacilities to set.
   */
  public void setOffSiteFacilities(boolean offSiteFacilities) {
    this.offSiteFacilities = offSiteFacilities;
  }

  /**
   * @return Returns the packaging.
   */
  public boolean isPackaging() {
    return packaging;
  }

  /**
   * @param packaging The packaging to set.
   */
  public void setPackaging(boolean packaging) {
    this.packaging = packaging;
  }

  /**
   * @return Returns the planting.
   */
  public boolean isPlanting() {
    return planting;
  }

  /**
   * @param planting The planting to set.
   */
  public void setPlanting(boolean planting) {
    this.planting = planting;
  }

  /**
   * @return Returns the qaLab.
   */
  public boolean isQaLab() {
    return qaLab;
  }

  /**
   * @param qaLab The qaLab to set.
   */
  public void setQaLab(boolean qaLab) {
    this.qaLab = qaLab;
  }

  /**
   * @return Returns the warehouseDistribution.
   */
  public boolean isWarehouseDistribution() {
    return warehouseDistribution;
  }

  /**
   * @param warehouseDistribution The warehouseDistribution to set.
   */
  public void setWarehouseDistribution(boolean warehouseDistribution) {
    this.warehouseDistribution = warehouseDistribution;
  }

  /**
   * @return Returns the auditOverview.
   */
  public String getAuditOverview() {
    return auditOverview;
  }

  /**
   * @param auditOverview The auditOverview to set.
   */
  public void setAuditOverview(String auditOverview) {
    this.auditOverview = auditOverview;
  }

  /**
   * @return Returns the auditDate.
   */
  public String getAuditDate() {
    return auditDate;
  }

  /**
   * @param auditDate The auditDate to set.
   */
  public void setAuditDate(String auditDate) {
    this.auditDate = auditDate;
  }

  /**
   * @return Returns the auditor.
   */
  public String getAuditor() {
    return auditor;
  }

  /**
   * @param auditor The auditor to set.
   */
  public void setAuditor(String auditor) {
    this.auditor = auditor;
  }

  /**
   * @return Returns the auditorEmail.
   */
  public String getAuditorEmail() {
    return auditorEmail;
  }

  /**
   * @param auditorEmail The auditorEmail to set.
   */
  public void setAuditorEmail(String auditorEmail) {
    this.auditorEmail = auditorEmail;
  }

  /**
   * @return Returns the preparedBy.
   */
  public String getPreparedBy() {
    return preparedBy;
  }

  /**
   * @param preparedBy The preparedBy to set.
   */
  public void setPreparedBy(String preparedBy) {
    this.preparedBy = preparedBy;
  }

  /**
   * @return Returns the preparedDate.
   */
  public String getPreparedDate() {
    return preparedDate;
  }

  /**
   * @param preparedDate The preparedDate to set.
   */
  public void setPreparedDate(String preparedDate) {
    this.preparedDate = preparedDate;
  }

  /**
   * @return Returns the locationCode.
   */
  public String getLocationCode() {
    return locationCode;
  }

  /**
   * @param locationCode The locationCode to set.
   */
  public void setLocationCode(String locationCode) {
    this.locationCode = locationCode;
  }

  /**
   * @return Returns the siteISOContact.
   */
  public String getSiteISOContact() {
    return siteISOContact;
  }

  /**
   * @param siteISOContact The siteISOContact to set.
   */
  public void setSiteISOContact(String siteISOContact) {
    this.siteISOContact = siteISOContact;
  }

  /**
   * @return Returns the siteISOContactEmail.
   */
  public String getSiteISOContactEmail() {
    return siteISOContactEmail;
  }

  /**
   * @param siteISOContactEmail The siteISOContactEmail to set.
   */
  public void setSiteISOContactEmail(String siteISOContactEmail) {
    this.siteISOContactEmail = siteISOContactEmail;
  }

  /**
   * @return Returns the cancelString.
   */
  public String getCancelString() {
    return cancelString;
  }

  /**
   * @param cancelString The cancelString to set.
   */
  public void setCancelString(String cancelString) {
    this.cancelString = cancelString;
  }

  public boolean getField() {
    return field;
  }

  /**
   * @return Returns the findingCarMapEmpty.
   */
  public boolean isFindingCarMapEmpty() {
    return findingCarMapEmpty;
  }

  /**
   * @param findingCarMapEmpty The findingCarMapEmpty to set.
   */
  public void setFindingCarMapEmpty(boolean findingCarMapEmpty) {
    this.findingCarMapEmpty = findingCarMapEmpty;
  }

  /**
   * @return Returns the findingParMapEmpty.
   */
  public boolean isFindingParMapEmpty() {
    return findingParMapEmpty;
  }

  public boolean isStewardship() {
    return stewardship;
  }

  public void setStewardship(boolean stewardship) {
    this.stewardship = stewardship;
  }


  /**
   * @param findingParMapEmpty The findingParMapEmpty to set.
   */
  public void setFindingParMapEmpty(boolean findingParMapEmpty) {
    this.findingParMapEmpty = findingParMapEmpty;
  }

  /**
   * @return Returns the auditID.
   */
  public String getAuditID() {
    return auditID;
  }

  /**
   * @param auditID The auditID to set.
   */
  public void setAuditID(String auditID) {
    this.auditID = auditID;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    AuditObject audit = (AuditObject) o;
    if (ComparisonUtil.unequal(auditDate, audit.auditDate)) return false;
    if (ComparisonUtil.unequal(auditor, audit.auditor)) return false;
    if (ComparisonUtil.unequal(siteISOContact, audit.siteISOContact)) return false;
    if (ComparisonUtil.unequal(conditioning, audit.conditioning)) return false;
    if (ComparisonUtil.unequal(warehouseDistribution, audit.warehouseDistribution)) return false;
    if (ComparisonUtil.unequal(harvest, audit.harvest)) return false;
    if (ComparisonUtil.unequal(packaging, audit.packaging)) return false;
    if (ComparisonUtil.unequal(planting, audit.planting)) return false;
    if (ComparisonUtil.unequal(qaLab, audit.qaLab)) return false;
    if (ComparisonUtil.unequal(field, audit.field)) return false;
    if (ComparisonUtil.unequal(stewardship, audit.stewardship)) return false;
    if (ComparisonUtil.unequal(auditOverview, audit.auditOverview)) return false;
    if (ComparisonUtil.unequal(preparedBy, audit.preparedBy)) return false;
    if (ComparisonUtil.unequal(preparedDate, audit.preparedDate)) return false;
    if (findingCarMap != null ? !findingCarMap.equals(audit.findingCarMap) : audit.findingCarMap != null) return false;
    if (findingParMap != null ? !findingParMap.equals(audit.findingParMap) : audit.findingParMap != null) return false;
    return true;
  }

  public Object clone() {
    try {
      AuditObject copy = (AuditObject) super.clone();
      copy.setFindingCarMap(deepCopy(findingCarMap));
      copy.setFindingParMap(deepCopy(findingParMap));
      return copy;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException("FatalError: AuditObject needs to implements Cloneable interface.");
    }
  }

  private HashMap deepCopy(HashMap originalMap) {
    Iterator copyMapIterator = originalMap.keySet().iterator();
    HashMap copyMap = new HashMap();
    while (copyMapIterator.hasNext()) {
      String key = (String) copyMapIterator.next();
      FindingObject findingObject = (FindingObject) originalMap.get(key);
      FindingObject findingObjectCopy = (FindingObject) findingObject.clone();
      copyMap.put(key, findingObjectCopy);
    }
    return copyMap;
  }

  public String toString() {
    System.out.println("auditDate = " + auditDate);
    System.out.println("auditor = " + auditor);
    System.out.println("siteISOContact = " + siteISOContact);
    System.out.println("conditioning = " + conditioning);
    System.out.println("warehouseDistribution = " + warehouseDistribution);
    System.out.println("harvest = " + harvest);
    System.out.println("packaging = " + packaging);
    System.out.println("planting = " + planting);
    System.out.println("qaLab = " + qaLab);
    System.out.println("field=" + field);
    System.out.println("StewardShip=" + stewardship);
    System.out.println("auditOverview = " + auditOverview);
    System.out.println("preparedBy = " + preparedBy);
    System.out.println("preparedDate = " + preparedDate);
    return null;
  }


}