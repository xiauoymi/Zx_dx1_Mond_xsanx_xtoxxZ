/*
 * Created on Apr 29, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.breedingcomplaintsaudits.validations;

import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorUtil;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.Resources;

/**
 * @author rdesai2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class McasValidator
{
  public static boolean validateDate(Object bean,
    ValidatorAction action,
    Field field,
    ActionMessages errors,
    HttpServletRequest request)
  {
    //**Reqd...Step1...get the date-str
  	String dateStr = ValidatorUtil.getValueAsString(bean, field.getProperty());
  	
  	//**We are not checking for required...
  	if(dateStr == null || dateStr.length() == 0){
  		return true;
  	}
  	
  	//**Reqd...Step2...Validation Logic...
  	
  	//**Date Validation...(mm/dd/yyyy)...
	StringTokenizer st = new StringTokenizer(dateStr, "/");
	
	//**Date Format Error Yes/No...
	boolean dateErr = false;
	
	if(st.countTokens() != 3){
		dateErr = true;
	}
	else{
		for(int i = 0; i < 3; i++){
			if(i==0){
				String month = st.nextToken().trim();
				if(month.length() != 2){
					dateErr = true;
				}
				try{
					int x = Integer.parseInt(month);
					if(x < 0 || x > 12){
						dateErr = true;
					}
				}
				catch(Exception ex){
					dateErr = true;
				}
			}
			if(i==1){
				String day = st.nextToken().trim();
				if(day.length() != 2){
					dateErr = true;
				}
				try{
					int x = Integer.parseInt(day);
					if(x < 0 || x > 31){
						dateErr = true;
					}
				}
				catch(Exception ex){
					dateErr = true;
				}
			}
			if(i==2){
				String year = st.nextToken().trim();
				if(year.length() != 4){
					dateErr = true;
				}
				try{
					int x = Integer.parseInt(year);
				}
				catch(Exception ex){
					dateErr = true;
				}
			}
		}
						
	}
	
	if(dateErr){
		//**Reqd...Step3...To add error
	    errors.add(field.getKey(), Resources.getActionMessage(request, action, field));
	    return false;
	}
  	
    
    return true;
  }
}
