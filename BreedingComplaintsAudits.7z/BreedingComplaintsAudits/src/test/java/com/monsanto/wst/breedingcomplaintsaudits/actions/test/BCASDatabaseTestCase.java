package com.monsanto.wst.breedingcomplaintsaudits.actions.test;

import org.dbunit.DatabaseTestCase;
import org.dbunit.ext.oracle.OracleConnection;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.database.IDatabaseConnection;
import org.xml.sax.InputSource;
import org.apache.commons.dbcp.BasicDataSource;

import java.sql.*;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.wst.breedingcomplaintsaudits.resources.McasProperties;

import javax.sql.DataSource;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Oct 17, 2007
 * Time: 11:51:43 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class BCASDatabaseTestCase extends DatabaseTestCase {
    private OracleConnection oracleConnection;
    private DataSource datasource;
    private Connection connection;
    private PreparedStatement ps;

    protected DatabaseOperation getSetUpOperation() throws Exception {
            deleteSetUpData();
            return DatabaseOperation.INSERT;
        }

    private void deleteSetUpData() throws SQLException, EncryptorException {
        //
        // This method deletes data that was inserted during setUpOperation.
        //

      getDataStore();
      connection = datasource.getConnection();
        try {
            ps = connection.prepareStatement("delete from cpar_responsibility where cpar_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from cpar_documentation where cpar_id=1");
            ps.executeQuery();
            ps=connection.prepareStatement("delete from cpar where cpar_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_issues where complaint_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_documentation where complaint_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_dealer where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_grower where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_disease_info where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_insect_info where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_planting_info where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_variety where complaint_id=1");
                        ps.executeQuery();
            ps = connection.prepareStatement("delete from complaint_batch where complaint_id=1");
                        ps.executeQuery();
            ps=connection.prepareStatement("delete from complaint where complaint_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from m_audit_areas where audit_id = 1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from bcas.m_audit_findings where audit_id=1");
            ps.executeQuery();
            ps = connection.prepareStatement("delete from m_audit where audit_id = 1");
            ps.executeQuery();

            System.out.println("executed the query.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("e.getMessage() = " + e.getMessage());
        }
        finally{
            connection.close();
        }
    }

    private void getDataStore () throws EncryptorException {
        String lsifunction = System.getProperty("lsi.function");
        String decryptedPassword = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", McasProperties.getMcasProperties().getString("com.monsanto.DBEncryption.key.path"), "CipherValue.hex", "KeyValue.hex");
        if (lsifunction != null && lsifunction.equalsIgnoreCase("win")) {
            BasicDataSource basicDataSource = new BasicDataSource();
            basicDataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
            basicDataSource.setUrl("jdbc:oracle:oci:@dev01.monsanto.com:1521:comgend");
            basicDataSource.setUsername("BCAS");
            basicDataSource.setPassword("bcas_123");
            datasource = basicDataSource;
        }
    }

    protected IDatabaseConnection getConnection() throws Exception {
        Class driverClass =
                Class.forName("oracle.jdbc.driver.OracleDriver");
        //todo get parameters from property file
        Connection jdbcConnection =
                DriverManager.getConnection(
                        "jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "bcas", "bcas_123");
        oracleConnection = new OracleConnection(jdbcConnection, "bcas");
        return oracleConnection;
    }

    protected IDataSet getDataSet() throws Exception {
        InputSource in = new InputSource("com/monsanto/wst/breedingcomplaintsaudits/service/test/auditData.xml");
        return new FlatXmlDataSet(in);
    }

    protected DatabaseOperation getTearDownOperation() throws Exception {
        return DatabaseOperation.REFRESH;
    }
}
