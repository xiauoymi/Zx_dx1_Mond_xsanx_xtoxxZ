// JavaScript Document

function complaint()
(
parent.left.complaint="images/button_complaints_o.gif";
)

function stopsale()
(
parent.left.stopsale="images/button_stopsale_o.gif";
)

function audit()
(
parent.left.audit="images/button_audit_o.gif";
)

function cars()
(
parent.left.cars="images/button_cars_o.gif";
)

function pars()
(
parent.left.pars="images/button_pars_o.gif";
)