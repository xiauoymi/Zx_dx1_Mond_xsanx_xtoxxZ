//=====================================================================================================================
//DIMENSION GLOBAL SCOPE CLIENT SIDE VARIABLES
//=====================================================================================================================
var oPeoplePicker					//USED TO STORE A REFERENCE TO THE PEOPLE PICKER BROWSER WINDOW OBJECT
var bPeoplePickerIsOpen = false;	//USED TO DENOTE WHETHER THE PEOPLE PICKER WINDOW HAS BEEN OPENED


function Search4People()
{
	//=====================================================================================================================
	//Synopsis: OPENS THE PEOPLE PICKER UTILITY IN A NEW WINDOW
	//
	//   NOTE: loadPeople() MUST exist in this page in order for this feature to work properly.
	//
	//=====================================================================================================================
	// var fieldObject = document.all.hdnPartyID.value;
	//OPEN THE PEOPLE PICKER UTILITY IN A NEW WINDOW
	var lwidth = 600, lheight = 450;
	var ltop = (window.screen.availHeight - lheight)/2;
	var lleft = (window.screen.availWidth - lwidth)/2;
	
	// changed for getting the people picker url from web.config file.
	var sPickerURL = "/ppsclient/PPService.do?selectable=single";
	//var sPickerURL = document.all.hdnPeoplePickerURL.value;
	// If the party ID is present.
	// if(fieldObject != null || fieldObject != "")
	//	sPickerURL = sPickerURL + "?LoadPeople=1";
	oPeoplePicker = window.open(sPickerURL, "PeoplePicker", "status=1,toolbar=0,location=0,directories=0,menubar=0,resizable=0,scrollbars=yes,width=" + lwidth + ",height=" + lheight + ",top=" + ltop + ",left=" + lleft, true);


	bPeoplePickerIsOpen = true;
	//alert(bPeoplePickerIsOpen);
}


function loadPeople()
{//alert("loadPeople = "+bPeoplePickerIsOpen);
//=====================================================================================================================
//Synopsis: PASSES A LIST OF PEOPLE TO BE LOADED IN THE PEOPLE PICKER
//
//			NOTE: The list passed to the PeoplePicker MUST be a comma delimited list of PeopleDirectory PartyIDs!!!
//			NOTE: This function is called by the People Picker Window after it has been loaded and called with
//				  the querystring parameter: "?LoadPeople=1".  Therefore, this function must be named exactly as is!!!
//=====================================================================================================================
	if (bPeoplePickerIsOpen)
	{//alert("in loadPeople , bPeoplePickerIsOpen = "+bPeoplePickerIsOpen);
		oPeoplePicker.loadPeople(document.all.hdnPartyID.value);	//comma delimited list of PartyIDs passed to People Picker
	}
}


function ClosePopUp()
{
//=====================================================================================================================
//Synopsis: ATTEMPTS TO CLOSE THE PEOPLE PICKER IF IT HAS BEEN OPENED, OTHER WISE NOTHING IS DONE
//=====================================================================================================================
	if (bPeoplePickerIsOpen)
	{
		oPeoplePicker.close();
		bPeoplePickerIsOpen = false;
	}
}


function GetSelectedPeople()
{
	//Check to see if any people were selected, If not return
	var iNumSelPeople = oPeoplePicker.GetNumSelectedPeople_Java();
	var lPersonData = 0;
	var lPersonText = 1;
	var arrPeopleDataFrmPP = new Array();
	var arrPartyIDs = new Array();
	var arrLastNameList = new Array();
	var arrFirstNameList = new Array();
	var arrMiddleNameList = new Array();
	var arrPhoneList = new Array();
	var arrUserIDs	= new Array();
	var arrEmailIDs = new Array();
	var aPeople; // 2 diemensional array
	if(iNumSelPeople > 0)
	{
		// alert('inside getselectedpeople');
		aPeople = oPeoplePicker.GetSelectedPeople_Java();
		// alert('after getselectedpeople');
		var tempStrData;
		var tempStrText;
		var tempArray = new Array();
		for (i = 0; i < aPeople.length; i++)
		{
		// alert('inside loop');
		// alert(aPeople.length);
		//	tempStrData = aPeople[i][lPersonData];
		tempStrData = aPeople[i];
		//	tempStrText = aPeople[i][lPersonText];
		// alert(tempStrData);
		// alert(tempStrText);
			// Person text is separated by '<+>', split using this string to separate
			// Text at 0th position is = Party ID
			// Text at 1st positions is = Email Address
			// Text at 2nd positon is = Name in "Last, First Middel" format
			// Text at 3rd position is = User ID(Lan ID)
			tempArray = tempStrData.split("<+>");
			arrPartyIDs[i] = tempArray[0];
			//alert("Party ID = " + arrPartyIDs[i]);
			arrLastNameList[i] = tempArray[2];
			arrFirstNameList[i] = tempArray[3];
			arrMiddleNameList[i] = tempArray[4];
			//alert("Name List = " + arrNameList[i]);
			arrUserIDs[i] = tempArray[5];
			//alert("User Id = " + arrUserIDs[i]);
			// arrPhoneList[i] = tempStrText.substring(tempStrText.indexOf(":")+1,tempStrText.length);
			arrPhoneList[i] = tempArray[6];
			//alert("Phone number = " + arrPhoneList[i]);
			arrEmailIDs[i] = tempArray[1];
		}
		arrPeopleDataFrmPP[0] = arrPartyIDs;
		arrPeopleDataFrmPP[1] = arrLastNameList;
		arrPeopleDataFrmPP[2] = arrFirstNameList;
		arrPeopleDataFrmPP[3] = arrMiddleNameList;
		arrPeopleDataFrmPP[4] = arrUserIDs;
		arrPeopleDataFrmPP[5] = arrPhoneList;
		arrPeopleDataFrmPP[6] = arrEmailIDs;
	}
	// alert(arrPeopleDataFrmPP);
	setValuesFromPeoplePicker(arrPeopleDataFrmPP)
}

// Commented and moved this code on each page.
// --------------------------------------------------
// Each page specific controls need to modify this section according to their needs
//
//	arrPeopleData
//		index - 0 : party id
//		index - 1 : last name
//		index - 2 : first name
//		index - 3 : middle name
//		index - 4 : user id
//		index - 5 : phone id
//		index - 6 : email
//
// ---------------------------------------------------
//function setValuesFromPeoplePicker(arrPeopleData)
//{
//	document.getElementById("username").value = arrPeopleData[4];
//	document.getElementById("reportInitiator").value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
//	document.getElementById("fromAddress").value = arrPeopleData[6] + "@monsanto.com";
//}