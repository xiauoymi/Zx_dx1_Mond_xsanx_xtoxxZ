//|---------------------------------------------------------------------------
//| 1. THIS CODE REQUIRES: 
//|    a. This to be added to head of web page
//|        <script Language="JavaScript" src="printf.js'"></script>
//|
//|    b. A <div id = 'start_prnt'> wrapped around the content to be printed but inside 
//|       the body tag needs to be added
//|           ex:  <body><div id = 'start_prnt'>Content</div></body>
//|
//| 2. THIS CODE ASSUMES: 
//|    a. "tab_on" is the id used to turn on a tab within each div   ex: <div id=""tab_on"></div>
//|
//| 3. LOOKS BETTER BUT NOT REQUIRED:
//|    a. For the sake of appearance it is helpful to use &nbsp; between <textarea> tags
//|       ex: <textarea name='' rows=' ' cols=''>&nbsp;<testarea>
//|
//| 4. STYLE SHEET:
//|    a. No changes to the style sheet are required, but the style sheet(s) must be 
//|       hard coded into the javascript function printFriendly - the second document.write line
//|----------------------------------------------------------------------------

var win=null;

//can trim this down - offers several options to locate the new window
function doOpenWin(mypage,myname,w,h,resize, scroll,pos){
	if(pos=="random"){LeftPosition=(screen.availWidth)?Math.floor(Math.random()*(screen.availWidth-w)):50;TopPosition=(screen.availHeight)?Math.floor(Math.random()*((screen.availHeight-h)-75)):50;}
	if(pos=="center"){LeftPosition=(screen.availWidth)?(screen.availWidth-w)/2:50;TopPosition=(screen.availHeight)?(screen.availHeight-h)/2:50;}
	if(pos=="default"){LeftPosition=50;TopPosition=50}
	if(pos=="bottom"){LeftPosition=(screen.availWidth)?((screen.availWidth-w)-25):50;TopPosition=(screen.availHeight)?((screen.availHeight-h)-60):50;}
	else if((pos!="center" && pos!="random" && pos!="default" && pos!="bottom") || pos==null){LeftPosition=0;TopPosition=20}
	settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable='+resize;
	win=window.open(mypage,myname,settings);
	if(!win.focus){win.focus();}
}

function printFriendly(mytitle,mypage,myname,w,h,resize,scroll,pos) {
	var jStart = document.getElementById("start_prnt");
	var jHtml = walkChildNodes(jStart);
 	//open window
    doOpenWin(mypage,myname,w,h,resize, scroll,pos);
 	//populate window
	if(win != null){
    	win.document.open('text/html');
    	win.document.write("<html><head><title>"+mytitle+"</title>");
// >>>>>> change style sheet(s) name on the line below
        win.document.write("<link rel='stylesheet' type='text/css' href='css/site.css' >");
        win.document.write("</head><body width='680' margin='0' onload='window.print()'>");
    	win.document.write(jHtml);
    	win.document.write("</body></html>");
    	win.document.close();
    	win.focus();
	}
	return;
}
    
function walkChildNodes(jObjRef) {
   var jObj;
   if (jObjRef) {
      if (typeof jObjRef == "string") {jObj = document.getElementById(jObjRef);} 
      else {jObj = jObjRef;}
   } 
   else {jObj = (document.body.parentElement) ? document.body.parentElement : document.body.parentNode; }
   var jEndtag ="";
   var jOutput = "";
   var i, jGroup, jTxt;
   jGroup = jObj.childNodes;
   for (i = 0; i < jGroup.length; i++) {
         jGetChild = true; 
         jEndtag ="";
         switch (jGroup[i].nodeType) {
         case 1:
    		var jThisStr = jGroup[i].tagName;
            jThisStr = jThisStr.toLowerCase();
            if (jGroup[i].type == "textarea"){jThisStr = "p style='padding: 5px 5px 5px 5px;border: 1px solid #003366;background-color: #FFF;'";}
            // remove javascript and images
            if (jThisStr == "script" || jThisStr == "img"){break;}
            // remove all buttons and hidden input
            if (jThisStr == "input" && (jGroup[i].type == "button" || jGroup[i].type == "submit" || jGroup[i].type == "reset" || jGroup[i].type == "hidden")){break;}
            // code assumes that "tab_on" is the id used for tab divs
            if (jThisStr == "a" && jGroup[i].parentNode.tagName.toLowerCase() == "li" && jGroup[i].parentNode.id !="tab_on"){jGetChild = false; break;}
            if (jThisStr == "li" && jGroup[i].id != "tab_on"){jGetChild = false; break;}
            jOutput += "<" + jThisStr;
            if (jThisStr == "table"){ jOutput += " cellspacing=0 cellpadding=0 ";}
            if (jGroup[i].type != "textarea"){
            jOutput += (jGroup[i].colSpan) ? " colspan=" + jGroup[i].colSpan : "";
            jOutput += (jGroup[i].size) ? " size=" + jGroup[i].size : "";
            jOutput += (jGroup[i].type) ? " type='" + jGroup[i].type +"'": "";
            jOutput += (jGroup[i].name) ? " name='" + jGroup[i].name +"'": "";
            jOutput += (jGroup[i].id)   ? " id='" + jGroup[i].id+"'" : "";
            jOutput += (jGroup[i].className)   ? " class='" + jGroup[i].className +"'": "";
            jOutput += (jGroup[i].border) ? " border=" + jGroup[i].border : "";
            //this trys to force the width of none div elements to 650px
            if (jGroup[i].width > 650){jOutput += " width=650"}
            else{jOutput += (jGroup[i].width) ? " width=" + jGroup[i].width : "";}
            }
            //this trys to force the width of divs to 650px
            if (jThisStr == "div" && jGroup[i].clientWidth > 650){jOutput += " style='width:650;overflow: visible;'";}
            else if (jThisStr == "div"){jOutput += " style='overflow: visible;' ";}
            if (jThisStr == "input" && jGroup[i].type == "checkbox" && jGroup[i].checked){jOutput +=" checked ";}
            //if (jThisStr == "select" || (jThisStr == "input" && (jGroup[i].type == "checkbox" || jGroup[i].type == "text"))){jOutput +=" disabled ";}
            if (jThisStr == "select" || (jThisStr == "input" && jGroup[i].type == "text")){jOutput +=" disabled ";}
            if (jThisStr == "input" && jGroup[i].type == "text"){jOutput += " value='" + jGroup[i].value+"'";}
            jOutput += ">";
            if (jThisStr == "select"){
               jGetChild= false;
               jOutput += "<option selected>"+jGroup[i].options(jGroup[i].selectedIndex).text+"</option>";
            }
            if (jThisStr != "input"){jEndtag = "</" + jThisStr + ">";}
            break;
         case 3:
            var jTxtLen = jGroup[i].nodeValue.length;
            jTxt = jGroup[i].nodeValue.substr(0,jTxtLen);
            jOutput += jTxt.replace(/[\r\n]/g,"<cr>");
            break;
         case 8:
            break;

         default:
            //will leave a number on the page which is a nodeType
            jOutput += jGroup[i].nodeType;
      }
      if (jGetChild  && jGroup[i].childNodes.length > 0) {
        jOutput += walkChildNodes(jGroup[i]);
      }
	jOutput += jEndtag
   }
   return jOutput;
}