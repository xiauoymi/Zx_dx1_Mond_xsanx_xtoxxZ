package com.monsanto.wst.businessconducttraining.Security;

import com.monsanto.SecurityServerFactory.SecurityServerFactory;
import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.businessconducttraining.Servlet.I_SessionParams;
import com.monsanto.wst.businessconducttraining.Servlet.BusinessConductTrainingServlet;

import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.security.SecureUser;
import com.monsanto.security.SecurityGateKeeper;
import com.monsanto.security.SecurityServiceException;
import com.monsanto.user.NoSuchUserException;
import com.monsanto.Util.Exceptions.WrappingException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ResourceBundle;


/**
 *
 * <p>Title: BusinessConductTrainingLogonController</p>
 * <p>Description: Validates and logs on the current user.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: BusinessConductTrainingLogonController.java,v 1.2 2006-03-12 02:10:56 mecoru Exp $
 */
public class BusinessConductTrainingLogonController implements UseCaseController
{
   public static final String USER_NAME_PARAM = "UserName";
   public static final String PASSWORD_PARAM =  "Password";

   /**
    * Runs the code that implements the logon use case.
    * @param helper a UCCHelper used to perform common UCC tasks
    * @throws IOException
    */
   public void run (UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      try {
         helper.clearSession();

         SecureUser secureUser = buildSecureUser(helper);

         LoginBrief lb = authorizeUser(helper, secureUser);

         Document doc = DOMUtil.newDocument();
         Element itemElement = DOMUtil.addChildElement(doc, "USER_INFO");
         secureUser.insertXML(itemElement);
         lb.insertXML(itemElement);

         /*  If we get here without an exception being thrown then the user must be valid.  */
         helper.applyStylesheet(doc, "/Stylesheet/MainMenu.xsl");
         
         Logger.traceExit();
      }
      catch (SecurityServiceException sse) {      // Some sort of database problem
         Logger.log(new LoggableError("A error occured while logging on the user. " + "The error was: " + sse.toString()));

         DisplayLogonError.displayLogonFailedWrappingException(helper.getPrintWriter());
      }
      catch (NoLogonInformationException nlie) {  // The user needs to identify himself
         helper.displayHTML_File("html/BusinessConductTrainingLogon.html");

      }
      catch (LogonFailedException lfe) {          // User identified, but logon was not successful (Bad Password?)
         Logger.log(new LoggableInfo("Logon failed: " + lfe.toString()));

         DisplayLogonError.displayLogonFailed(helper.getPrintWriter(), lfe.getMessage());
      }
   }


   /**
    * Logs the user on to the application.
    * @param helper A Use Case Controller helper class.
    * @throws LogonFailedException if the Password was not provided.
    */
   private LoginBrief authorizeUser (UCCHelper helper, SecureUser secureUser) throws LogonFailedException,
                                                                                     SecurityServiceException
   {
      Logger.traceEntry();

      LoginBrief RetVal = null;

      SecurityGateKeeper gateKeeper = new SecurityGateKeeper();
      ResourceBundle bundle = ResourceBundle.getBundle(BusinessConductTrainingServlet.s_cstrResourceBundle);
      SecurityServerFactory factory = new SecurityServerFactory(helper, bundle);
      RetVal = gateKeeper.login(secureUser, SecurityFactory.getAppName(), factory.buildSecurityServer());

      /*  If we get this far we are logged in.  Save the security gatekeeper as a session variable.  */
      helper.setSessionParameter(I_SessionParams.sf_cstrSECURITY_GATEKEEPER, gateKeeper);
      helper.setSessionParameter(I_SessionParams.sf_cstrCURRENT_USER, secureUser);

      Logger.log(new LoggableInfo("Logged on user: " + secureUser.userId()));

      return (LoginBrief) Logger.traceExit(RetVal);
   }


   /**
    * Builds a SecureUser object from the input data.
    * @param helper A Use Case Controller helper class.
    * @return SecureUser - The secure user
    * @throws LogonFailedException if the Password was not provided.
    * @throws NoLogonInformationException if the Username was not provided
    * @throws IOException - Error accessing the session of the input data.
    */
   private SecureUser buildSecureUser (UCCHelper helper) throws LogonFailedException,
                                                                NoLogonInformationException,
                                                                IOException
   {
      Logger.traceEntry();

      SecureUser secureUser = null;

      String cstrUsername = helper.serverAuthorizedUser();
      String cstrPassword = ""; // no password needed for Kerberos
      if ((cstrUsername != null) && !cstrUsername.equals("")) {
      	// return new AuthenticatedUser(cstrUsername);
      } else {
					cstrUsername = helper.getAuthenticatedUserID(); // Authenticated user from Kerberos
					// userid not provided by Kerberos, see if it comes from logon form
					if ((cstrUsername == null) || cstrUsername.equals("")) {
         		cstrUsername = helper.getRequestParameterValue(USER_NAME_PARAM);
         		if ((cstrUsername == null) || cstrUsername.equals("")) {
            	Logger.log(new DebugLogEvent("Login Failed: No Username provided."));
            	throw new NoLogonInformationException("Login Failed: No Username provided.");
         		}

         		cstrPassword = helper.getRequestParameterValue(PASSWORD_PARAM);
         		if (cstrPassword == null || cstrPassword.equals("")) {
            	Logger.log(new DebugLogEvent("Login Failed: No Password provided for user: " + cstrUsername));
            	throw new LogonFailedException("Login Failed: No Password provided.");
         		}
         	}
         	
					try {
						secureUser = new SecureUser(cstrUsername, cstrPassword);
					} catch (NoSuchUserException nsue) {
						Logger.log(new LoggableWarning(nsue));
						throw new LogonFailedException("The user " + cstrUsername + " could not be logged on.");
					} catch (WrappingException we) {
						Logger.log(new LoggableError(we));
						throw new LogonFailedException("The user " + cstrUsername + " could not be logged on." +
						 " (ERROR: " + we.toString() + ")");
					}

			}

      return (SecureUser) Logger.traceExit(secureUser);
   }
}
