package com.monsanto.wst.businessconducttraining.Security;

import com.monsanto.AbstractLogging.Logger;
import java.io.PrintWriter;

/**
 *
 * <p>Title: DisplayLogonError</p>
 * <p>Description: Displays an error page when the user can not be validated
 *  and directs the user back to the logon screen.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: DisplayLogonError.java,v 1.1 2006-03-08 17:56:29 ardharn Exp $
 */
public class DisplayLogonError
{
   /**
    * Displays an error message when a logon fails.
    * @param writer writes the error message as html text.
    */
   public static void displayLogonFailed(PrintWriter writer, String cstrMessage)
   {

      Logger.traceEntry();

      writer.println("<html>");
      writer.println("<head>");
      writer.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
      writer.println("<title>Logon Error</title>");
      writer.println("</head>");
      writer.println("<body bgcolor=\"#cccccc\">");
      writer.println("</p>");
      writer.println("<h2 align=\"center\">");
      writer.println("Logon failed.  Please check your username and password, and try again.");
      writer.println("<p align=\"center\">" + cstrMessage);
      writer.println("<p align=\"center\"><a href=\"../html/BusinessConductTrainingLogon.html\">Logon</a>");
      writer.println("</h2>");
      writer.println("</body>");
      writer.println("</html>");

      writer.close();
      
      Logger.traceExit();
   }

   /**
    * Displays an error message when a logon fails due to a WrappingException.
    * @param writer writes the error message as html text.
    */
   public static void displayLogonFailedWrappingException(PrintWriter writer)
   {

      Logger.traceEntry();

      writer.println("<html>");
      writer.println("<head>");
      writer.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
      writer.println("<title>Logon Error</title>");
      writer.println("</head>");
      writer.println("<body bgcolor=\"#cccccc\">");
      writer.println("</p>");
      writer.println("<h2 align=\"center\">");
      writer.println("Logon failed because there was a problem with the database.");
      writer.println("  Please try again at a later time.");
      writer.println("<p align=\"center\"><a href=\"../html/BusinessConductTrainingLogon.html\">Logon</a>");
      writer.println("</h2>");
      writer.println("</body>");
      writer.println("</html>");

      writer.close();

      Logger.traceExit();
   }
}
