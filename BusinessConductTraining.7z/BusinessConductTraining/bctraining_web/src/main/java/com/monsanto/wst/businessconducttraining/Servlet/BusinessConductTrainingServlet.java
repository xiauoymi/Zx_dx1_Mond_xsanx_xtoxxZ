package com.monsanto.wst.businessconducttraining.Servlet;


import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



/**
 *
 * <p>Title: BusinessConductTrainingServlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: BusinessConductTrainingServlet.java,v 1.2 2006-03-12 02:10:53 mecoru Exp $
 */
public class BusinessConductTrainingServlet extends GatewayServlet
{
   public static final String s_cstrResourceBundle = "com.monsanto.wst.businessconducttraining.Servlet.BusinessConductTraining";

   public BusinessConductTrainingServlet()
   {
      super(600);  // Set the session timeout values in seconds. (600)
   }

   public void init(ServletConfig servletConfig) throws ServletException
   {
      super.init(servletConfig);

      Logger.traceEntry();

      try {
         BusinessConductTrainingLoggerFactory loggerFactory = new BusinessConductTrainingLoggerFactory();
         loggerFactory.setupLogging();
      }
      catch (LogRegistrationException lre) {
         throw new ServletException(lre.toString());
      }
      catch (IOException ioe) {
         throw new ServletException(ioe.toString());
      }

      Logger.traceExit();
   }

   public void destroy()
   {
      Logger.traceEntry();

      try {
         PersistentStore.registerInstance(null);
      }
      catch (WrappingException e) {
      }

      super.destroy();

      Logger.traceExit();
   }

   /**
    * This static method will create an instance of the desired PersistentStore based on
    * data within a property file.
    * @param request - The HttpServlet Request from the servlet container
    * @param response - The HttpServletResponse to be sent back to the servlet container.
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

      try {

         /*  Register the persistent store with this servlet instance.  */
         PersistentStore ps = BusinessConductTrainingPersistentStoreFactory.getStore(s_cstrResourceBundle);
         PersistentStore.registerInstance(ps);

         /*  Pass the doGet along.  */
         super.doGet(request, response);
      }
      catch (WrappingException we) {
         helper.reportError("Error accessing database.  Please notify your technical support contact or try again later.\n" + we.toString());
         helper.closeSession();
      }

      Logger.traceExit();
   }
}
