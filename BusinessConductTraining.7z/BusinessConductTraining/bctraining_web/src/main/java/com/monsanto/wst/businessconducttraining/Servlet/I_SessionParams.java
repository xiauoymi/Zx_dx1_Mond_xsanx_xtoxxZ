package com.monsanto.wst.businessconducttraining.Servlet;



import java.io.File;




/**
 *
 * <p>Title: I_BusinessConductTrainingSessionParams</p>
 * <p>Description: This will serve for constants for putting proposal session lists</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: I_SessionParams.java,v 1.1 2006-03-08 17:56:29 ardharn Exp $
 */
public interface I_SessionParams
{
   /*  User roles  */
   public static final String sf_cstrSECURITY_GATEKEEPER = "BusinessConductTrainingSecurityGatekeeper";
   public static final String sf_cstrCURRENT_USER        = "BusinessConductTrainingUser";

   /*  Directories.  */
   public static final String sf_cstrCONFIG_DIR = "../Config";     // Properties files
   public static final String sf_cstrLINKFILES_DIR = "../linkfiles";  // Files for temp html links
   public static final String sf_cstrIMPORT_DIR = File.separator + "import";        // Uploaded files
   public static final String sf_cstrJAVASCRIPT_DIR = "../JavaScript"; // JavaScript files
   public static final String sf_cstrSTYLESHEET_DIR = "../Stylesheet"; // Stylesheets
   public static final String sf_cstrHTML_DIR = "../html";       // Static html files
   public static final String sf_cstrXML_SCHEMAS_DIR = "";
}
