package com.monsanto.wst.businessconducttraining.controllers;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 25, 2010
 * Time: 9:32:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessConductFilter implements Filter{
  public void init(FilterConfig filterConfig) throws ServletException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
    Locale locale = servletRequest.getLocale();
    String s = locale.getLanguage();
    ((HttpServletRequest)servletRequest).getSession().setAttribute("CURRENT_LOCALE",s);
    filterChain.doFilter(servletRequest,servletResponse);
  }

  public void destroy() {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
