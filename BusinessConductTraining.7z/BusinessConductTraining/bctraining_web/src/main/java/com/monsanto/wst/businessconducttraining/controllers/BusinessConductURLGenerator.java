package com.monsanto.wst.businessconducttraining.controllers;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.ParserException;
import java.io.IOException;
import java.io.PrintStream;
import javax.xml.transform.TransformerException;


/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 10, 2009
 * Time: 2:26:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessConductURLGenerator extends URLGenerator {
  public BusinessConductURLGenerator()
  {
  }

  protected String getSiteSpecificMods(String s)
      throws ParserException, IOException, TransformerException, POSException, POSCommunicationException, PeopleInfoException
  {
      String s1 = getPartyIdBasedOnUserId(getAuthenticatedUserId());
      return s + "?Username=" + s1 + "&Password=monsanto06";
  }

  protected String getAuthenticatedUserId()
  {
      return helper.getAuthenticatedUserID();
  }

  protected String getPartyIdBasedOnUserId(String s)
  {
      System.out.println("User Id from kerberos :" + s);
      String s1 = "";
      try
      {
          PersonInfo personinfo = returnPeople(s);
          s1 = personinfo.getPartyId();
          System.out.println("Party Id :" + s1);
          System.out.println("First Name :" + personinfo.getFirstName());
          System.out.println("Last Name :" + personinfo.getLastName());
          System.out.println("Mail Stop :" + personinfo.getMailStop());
          System.out.println("Phone :" + personinfo.getPartyId());
      }
      catch(Exception exception)
      {
          exception.printStackTrace();
      }
      return s1;
  }

  public PersonInfo returnPeople(String s)
      throws Exception
  {
      PeopleService peopleservice = new PeopleService();
      PersonInfo apersoninfo[] = peopleservice.GetPeople("", "", "", "", s, "", "");
      for(int i = 0; i < apersoninfo.length; i++)
      {
          PersonInfo personinfo = apersoninfo[i];
          if(personinfo.getUserId().equalsIgnoreCase(s))
              return personinfo;
      }

      return null;
  }
  
}
