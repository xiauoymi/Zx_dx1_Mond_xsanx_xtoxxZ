package com.monsanto.wst.businessconducttraining.controllers;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 25, 2010
 * Time: 9:22:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class SAPUtilityClass implements UseCaseController{
  public void run(UCCHelper helper) throws IOException {
    String currentLocale = (String) helper.getSessionParameter("CURRENT_LOCALE");
    String lsifunction = System.getProperty("lsi.function");
    System.out.println("lsifunction = " + lsifunction);
    String url = null;
    if(lsifunction !=null && lsifunction.equalsIgnoreCase("dev")){
      url = "http://stq08a01.monsanto.com:8008/sap/bc/webdynpro/sap/y_esh_near_miss?sap-language=";
    }
    if(lsifunction !=null && lsifunction.equalsIgnoreCase("test")){
      url = "http://stq08a01.monsanto.com:8008/sap/bc/webdynpro/sap/y_esh_near_miss?sap-language=";
    }
    if(lsifunction !=null && lsifunction.equalsIgnoreCase("ps")){
      url = "http://stq08a01.monsanto.com:8008/sap/bc/webdynpro/sap/y_esh_near_miss?sap-language=";
    }
    if(lsifunction !=null && lsifunction.equalsIgnoreCase("prod")){
      url = "http://stp08a32.monsanto.com:8032/sap/bc/webdynpro/sap/y_esh_near_miss?sap-language=";
    }
    System.out.println("url = " + url);
    helper.redirect(url +currentLocale);
  }
}
