package com.monsanto.wst.ccas;

/**
 * User: rrmall
 * Date: Apr 15, 2008
 * Time: 2:23:40 PM
 */
public class DataObject {
    private final String businessName;
    private final String cropId;
    private final String cropName;
    private final String materialGroupId;
    private final String materialGroupName;
    private final String pricingGroupId;
    private final String pricingGroupName;

    public DataObject(String businessName, String cropId, String cropName, String materialGroupId, String materialGroupName, String pricingGroupId, String pricingGroupName) {

        this.businessName = businessName;
        this.cropId = cropId;
        this.cropName = cropName;
        this.materialGroupId = materialGroupId;
        this.materialGroupName = materialGroupName;
        this.pricingGroupId = pricingGroupId;
        this.pricingGroupName = pricingGroupName;
    }
}
