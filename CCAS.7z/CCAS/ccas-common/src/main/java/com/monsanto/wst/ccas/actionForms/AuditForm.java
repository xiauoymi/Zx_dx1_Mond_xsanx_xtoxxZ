//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;

import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 04-07-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:form name="auditForm"
 */
public class AuditForm extends org.apache.struts.validator.ValidatorForm {

    // --------------------------------------------------------- Instance Variables

    private AuditObject auditObj = new AuditObject();

    private boolean recordSavedMsg;

    private boolean displayCarTable2 = false;

    private boolean displayParTable2 = false;

    private boolean displayCiTable2 = false;

    private String displayTab;


    /**
     * Method validate
     * @param mapping
     * @param request
     * @return ActionErrors
     */
//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'validate(...)' not implemented.");
//	}

    /**
     * Method reset
     * @param mapping
     * @param request
     */
//	public void reset(ActionMapping mapping, HttpServletRequest request) {
//
//		throw new UnsupportedOperationException(
//			"Generated method 'reset(...)' not implemented.");
//	}


    /**
     * @return Returns the auditObj.
     */
    public AuditObject getAuditObj() {
        return auditObj;
    }

    /**
     * @param auditObj The auditObj to set.
     */
    public void setAuditObj(AuditObject auditObj) {
        this.auditObj = auditObj;
    }

    /**
     * @return Returns the recordSavedMsg.
     */
    public boolean isRecordSavedMsg() {
        return recordSavedMsg;
    }

    /**
     * @param recordSavedMsg The recordSavedMsg to set.
     */
    public void setRecordSavedMsg(boolean recordSavedMsg) {
        this.recordSavedMsg = recordSavedMsg;
    }

    /**
     * @return Returns the displayCarTable2.
     */
    public boolean isDisplayCarTable2() {
        return displayCarTable2;
    }

    /**
     * @param displayCarTable2 The displayCarTable2 to set.
     */
    public void setDisplayCarTable2(boolean displayCarTable2) {
        this.displayCarTable2 = displayCarTable2;
    }

    /**
     * @return Returns the displayParTable2.
     */
    public boolean isDisplayParTable2() {
        return displayParTable2;
    }

    /**
     * @param displayParTable2 The displayParTable2 to set.
     */
    public void setDisplayParTable2(boolean displayParTable2) {
        this.displayParTable2 = displayParTable2;
    }

    /**
     * @return Returns the displayTab.
     */
    public String getDisplayTab() {
        return displayTab;
    }

    /**
     * @param displayTab The displayTab to set.
     */
    public void setDisplayTab(String displayTab) {
        this.displayTab = displayTab;
    }

    public boolean isDisplayCiTable2() {
        return displayCiTable2;
    }

    public void setDisplayCiTable2(boolean displayCiTable2) {
        this.displayCiTable2 = displayCiTable2;
    }

    public void validateCparFindingMap() {
        Map<String, FindingObject> findingMap = getAuditObj().getFindingCarMap();
        setCarMapStatus(findingMap);

        findingMap = getAuditObj().getFindingParMap();
        setParMapStatus(findingMap);

        findingMap = getAuditObj().getFindingCiMap();
        setCiMapStatus(findingMap);

        setRecordSavedMsg(false);
        setDisplayTab("none");
    }

    private void setParMapStatus(Map<String, FindingObject> findingMap) {
        if (findingMap.size() > 0) {
            getAuditObj().setFindingParMapEmpty(false);
        } else {
            getAuditObj().setFindingParMapEmpty(true);
        }
    }

    private void setCiMapStatus(Map<String, FindingObject> findingMap) {
        if (findingMap.size() > 0) {
            getAuditObj().setFindingCiMapEmpty(false);
        } else {
            getAuditObj().setFindingCiMapEmpty(true);
        }
    }

    private void setCarMapStatus(Map<String, FindingObject> findingMap) {
        if (findingMap.size() > 0) {
            getAuditObj().setFindingCarMapEmpty(false);
        } else {
            getAuditObj().setFindingCarMapEmpty(true);
        }
    }
}