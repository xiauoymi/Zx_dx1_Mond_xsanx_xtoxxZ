//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.SelectedIndex;
import com.monsanto.wst.ccas.model.AuditListObject;
import org.apache.struts.validator.ValidatorActionForm;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 04-27-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:form name="auditListForm"
 */
public class AuditListForm extends ValidatorActionForm {

    //**For capturing user selection...
    private AuditListObject auditFilterObj = new AuditListObject();

    private Map<String, Object> auditMap = new LinkedHashMap<String, Object>();

    private boolean auditMapEmpty;
//  private AuditFilter auditFilter;


    /**
     * @return Returns the auditMapEmpty.
     */
    public boolean isAuditMapEmpty() {
        return auditMapEmpty;
    }

    /**
     * @param auditMapEmpty The auditMapEmpty to set.
     */
    public void setAuditMapEmpty(boolean auditMapEmpty) {
        this.auditMapEmpty = auditMapEmpty;
    }

    /**
     * @return Returns the auditFilterObj.
     */
    public AuditListObject getAuditFilterObj() {
        return auditFilterObj;
    }

    /**
     * @param auditFilterObj The auditFilterObj to set.
     */
    public void setAuditFilterObj(AuditListObject auditFilterObj) {
        this.auditFilterObj = auditFilterObj;
    }

    /**
     * @return Returns the auditMap.
     */
    public Map<String, Object> getAuditMap() {
        return auditMap;
    }

    /**
     * @param auditMap The auditMap to set.
     */
    public void setAuditMap(Map<String, Object> auditMap) {
        this.auditMap = auditMap;
    }

    public void retainSelectedOrChangedDepartmentProcess(List<SelectedIndex> areas) {
        List<CheckboxItem> selectedFunctionalAreaList = new ArrayList<CheckboxItem>();
        if (auditFilterObj.getFunctionalArea() != null) {
            auditFilterObj.getFunctionalArea().resetIndexes(auditFilterObj, areas, selectedFunctionalAreaList);
            auditFilterObj.setSelectedFunctionalAreas(selectedFunctionalAreaList);
        }
    }
}