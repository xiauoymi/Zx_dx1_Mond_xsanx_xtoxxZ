/*
 * Created on Jan 18, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actionForms;


import com.monsanto.wst.ccas.model.Complaint;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintForm extends org.apache.struts.validator.ValidatorActionForm {

    private Complaint c;

    public ComplaintForm() {
        super();
        this.setC(new Complaint());
    }

    /**
     * @return Returns the c.
     */
    public Complaint getC() {
        return c;
    }

    /**
     * @param c The c to set.
     */
    public void setC(Complaint c) {
        this.c = c;
    }

    @Override
    public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
        return super.validate(actionMapping, httpServletRequest);    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    public void reset(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
        super.reset(actionMapping, httpServletRequest);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
