/*
 * Created on Feb 9, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actionForms;

import org.apache.struts.validator.ValidatorActionForm;

import java.util.Map;

/**
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintListForm extends ValidatorActionForm {
    private String controlNumber;
    private String createDate;
    private String initiatedBy;
    private String salesYr;
    private String reporting_location_code;
    private String responsible_plant_code;
    private String status;
    private String region;
    private String claimNumber;
    private String crop;

    private String state;
    private String variety;
    private String batch;
    private String qualityissue;

    private String complaintBusinessId;
    private String feedbackCategoryId;
    private String complaintTypeId;
    private String functionId;

    private Map<String, Object> complaintsList;

    private String salesOfficeCode;
    private int materialGroupCode;
    private int materialGroupPricingCode;
    private int initialAssesmentCode;
    private int complaintLitigationCategoryCode;
    private String toDate;
    private int complaintEntryTypeId;

    private String sapCustomerId;
    private String invoiceNumber;
    private String customerName;
    private String invoiceDate;
    private String from_communication_date;

    private String growerName;
    private String dealerName;

    private String searchText;
    private String initiator_response;

    private String claimStatusTypeIndicator;

    private String closingDate;

    private String person_investigating;

    public String getPerson_investigating() {
        return person_investigating;
    }

    public void setPerson_investigating(String person_investigating) {
        this.person_investigating = person_investigating;
    }

    public String getClaimStatusTypeIndicator() {
        return claimStatusTypeIndicator;
    }

    public void setClaimStatusTypeIndicator(String claimStatusTypeIndicator) {
        this.claimStatusTypeIndicator = claimStatusTypeIndicator;
    }

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }


    public String getGrowerName() {
        return growerName;
    }

    public void setGrowerName(String growerName) {
        this.growerName = growerName;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public String getTo_communication_date() {
        return to_communication_date;
    }

    public void setTo_communication_date(String to_communication_date) {
        this.to_communication_date = to_communication_date;
    }

    private String to_communication_date;

    public String getFrom_communication_date() {
        return from_communication_date;
    }

    public void setFrom_communication_date(String from_communication_date) {
        this.from_communication_date = from_communication_date;
    }


    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    private String entryType;

    public int getComplaintEntryType() {
        return complaintEntryType;
    }

    public void setComplaintEntryType(int complaintEntryType) {
        this.complaintEntryType = complaintEntryType;
    }

    private int complaintEntryType;

    public int getProgramId() {
        return programId;
    }

    public void setProgramId(int programId) {
        this.programId = programId;
    }

    private int programId;

    public int getInitialAssesmentCode() {
        return initialAssesmentCode;
    }

    public void setInitialAssesmentCode(int initialAssesmentCode) {
        this.initialAssesmentCode = initialAssesmentCode;
    }


    public int getMaterialGroupPricingCode() {
        return materialGroupPricingCode;
    }

    public void setMaterialGroupPricingCode(int materialGroupPricingCode) {
        this.materialGroupPricingCode = materialGroupPricingCode;
    }

    public int getMaterialGroupCode() {
        return materialGroupCode;
    }

    public void setMaterialGroupCode(int materialGroupCode) {
        this.materialGroupCode = materialGroupCode;
    }

    public String getSalesOfficeCode() {
        return salesOfficeCode;
    }

    public void setSalesOfficeCode(String salesOfficeCode) {
        this.salesOfficeCode = salesOfficeCode;
    }

    public String getQualityissue() {
        return qualityissue;
    }

    public void setQualityissue(String qualityissue) {
        this.qualityissue = qualityissue;
    }

    /**
     *
     */
    public ComplaintListForm() {
        super();
    }


    /**
     * @return Returns the batch.
     */
    public String getBatch() {
        return batch;
    }

    /**
     * @param batch The batch to set.
     */
    public void setBatch(String batch) {
        this.batch = batch;
    }

    /**
     * @return Returns the state.
     */
    public String getState() {
        return state;
    }

    /**
     * @param state The state to set.
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return Returns the variety.
     */
    public String getVariety() {
        return variety;
    }

    /**
     * @param variety The variety to set.
     */
    public void setVariety(String variety) {
        this.variety = variety;
    }

    /**
     * @return Returns the crop.
     */
    public String getCrop() {
        return crop;
    }

    /**
     * @param crop The crop to set.
     */
    public void setCrop(String crop) {
        this.crop = crop;
    }

    /**
     * @return Returns the claimNumber.
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * @param claimNumber The claimNumber to set.
     */
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the createDate.
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate The createDate to set.
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     * @return Returns the initiatedBy.
     */
    public String getInitiatedBy() {
        return initiatedBy;
    }

    /**
     * @param initiatedBy The initiatedBy to set.
     */
    public void setInitiatedBy(String initiatedBy) {
        this.initiatedBy = initiatedBy;
    }

    /**
     * @return Returns the region.
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return Returns the complaintsList.
     */
    public Map<String, Object> getComplaintsList() {
        return complaintsList;
    }

    public void setComplaintsList(Map<String, Object> complaintsList) {
        this.complaintsList = complaintsList;
    }

    /**
     * @return Returns the salesYr.
     */
    public String getSalesYr() {
        return salesYr;
    }

    /**
     * @param salesYr The salesYr to set.
     */
    public void setSalesYr(String salesYr) {
        this.salesYr = salesYr;
    }

    /**
     * @return Returns the reportingLocation.
     */
    public String getReporting_location_code() {
        return reporting_location_code;
    }

    /**
     * @param reporting_location_code The reportingLocation to set.
     */
    public void setReporting_location_code(String reporting_location_code) {
        this.reporting_location_code = reporting_location_code;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String getResponsible_plant_code() {
        return responsible_plant_code;
    }

    /**
     * @param responsible_plant_code The responsibleLocation to set.
     */
    public void setResponsible_plant_code(String responsible_plant_code) {
        this.responsible_plant_code = responsible_plant_code;
    }


    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }


    public String getFeedbackCategoryId() {
        return feedbackCategoryId;
    }

    public void setFeedbackCategoryId(String feedbackCategoryId) {
        this.feedbackCategoryId = feedbackCategoryId;
    }

    public String getComplaintTypeId() {
        return complaintTypeId;
    }

    public void setComplaintTypeId(String complaintTypeId) {
        this.complaintTypeId = complaintTypeId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public int getComplaintLitigationCategoryCode() {
        return complaintLitigationCategoryCode;
    }

    public void setComplaintLitigationCategoryCode(int complaintLitigationCategoryCode) {
        this.complaintLitigationCategoryCode = complaintLitigationCategoryCode;
    }


    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public int getComplaintEntryTypeId() {
        return complaintEntryTypeId;
    }

    public void setComplaintEntryTypeId(int complaintEntryTypeId) {
        this.complaintEntryTypeId = complaintEntryTypeId;
    }

    public String getSapCustomerId() {
        return sapCustomerId;
    }

    public void setSapCustomerId(String sapCustomerId) {
        this.sapCustomerId = sapCustomerId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getInitiator_response() {
        return initiator_response;
    }

    public void setInitiator_response(String initiator_response) {
        this.initiator_response = initiator_response;
    }

    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

}
