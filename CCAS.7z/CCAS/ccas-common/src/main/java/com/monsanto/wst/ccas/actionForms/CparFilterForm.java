//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.model.CparFilter;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import org.apache.struts.validator.ValidatorActionForm;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 06-15-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:form name="cparFilterForm"
 */
public class CparFilterForm extends ValidatorActionForm {

    private CparFilter cparFilter = new CparFilter();

    //**Report Tag Objects...
    private Map<String, RowBean> hash = new HashMap<String, RowBean>();    //**Data HashMap
    private InputStream xmlIn;                //**Report Structure Stream
    private String sortBy;
    private String sortOrder;


    /**
     * @return Returns the hash.
     */
    public Map<String, RowBean> getHash() {
        return hash;
    }

    /**
     * @param hash The hash to set.
     */
    public void setHash(Map<String, RowBean> hash) {
        this.hash = hash;
    }

    /**
     * @return Returns the sortBy.
     */
    public String getSortBy() {
        return sortBy;
    }

    /**
     * @param sortBy The sortBy to set.
     */
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    /**
     * @return Returns the sortOrder.
     */
    public String getSortOrder() {
        return sortOrder;
    }

    /**
     * @param sortOrder The sortOrder to set.
     */
    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * @return Returns the xmlIn.
     */
    public InputStream getXmlIn() {
        return xmlIn;
    }

    /**
     * @param xmlIn The xmlIn to set.
     */
    public void setXmlIn(InputStream xmlIn) {
        this.xmlIn = xmlIn;
    }

    /**
     * @return Returns the cparFilter.
     */
    public CparFilter getCparFilter() {
        return cparFilter;
    }

    /**
     * @param cparFilter The cparFilter to set.
     */
    public void setCparFilter(CparFilter cparFilter) {
        this.cparFilter = cparFilter;
    }
}
