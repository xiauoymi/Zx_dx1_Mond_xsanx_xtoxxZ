/*
 * Created on Feb 24, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.actions.CparAction;
import com.monsanto.wst.ccas.actions.SessionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.Issue;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.CparServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.Util.StringUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class CparForm extends org.apache.struts.validator.ValidatorActionForm {
    private Cpar cpar;
    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    private final CparService cparService;
    private ActionHelper actionHelper;

    public CparForm() {
        super();
        cparService = new CparServiceImpl();
        actionHelper = new ActionHelper();
        this.setCpar(new Cpar());
    }

    public CparForm(CparService cparService) {
        this.cparService = cparService;
    }

    /**
     * @return Returns the cpar.
     */
    public Cpar getCpar() {
        return cpar;
    }

    /**
     * @param cpar The cpar to set.
     */
    public void setCpar(Cpar cpar) {
        this.cpar = cpar;
    }

    @Override
    //Todo: WHY is this changing session attributes in a Validate method?!?!?!?!!!
    public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
        String regionId = getCpar().getRegion();
//    System.out.println("regionId from CPAR ************* " + regionId);
        Map<String, String> locationMap = null;


        ActionErrors errors = super.validate(actionMapping, httpServletRequest);
        try {
            User user = (User) httpServletRequest.getSession().getAttribute(User.USER);
            

            locationMap = new ActionHelper().getRegionSpecificLocationList(regionId, user.getLocale() );
            Map<String, String> newMap = new HashMap<String, String>();
            for (String str : locationMap.keySet()) {
                newMap.put(str, locationMap.get(str).trim());

            }
            if (httpServletRequest.getSession().getAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST) != null) {
                httpServletRequest.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, newMap);
            }
//            httpServletRequest.getSession().setAttribute("cpar.region", regionId);//This is for MCAS app processor
            CparAction cparAction = new CparAction();
            cparAction.setApplicationSpecificData(httpServletRequest, getType(httpServletRequest), cpar.getRegion(), cpar.getResponsibleRegionId());
//            httpServletRequest.getSession().setAttribute("cpar.region", null);
            SessionHelper sessionHelper = new SessionHelper();
            sessionHelper.setFunctionLocation(httpServletRequest.getSession(), cpar.getResponsible_location());

            if ( actionHelper == null )
                actionHelper = new ActionHelper();
            int businessPreferenceId = actionHelper.getUserBusinessPreference(user);
            httpServletRequest.getSession().setAttribute(ActionHelperConstants.ISO_STANDARD_LIST,
                actionHelper.getIsoStandardList(user.getLocale(),businessPreferenceId , cpar.getQuality_standard()));

        } catch (Exception e) { //todo gobbled exception
            System.out.println("Exception in setting locations  " + e.getMessage());
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return errors;
    }

    private int getType(HttpServletRequest request) {
        String type = request.getParameter(CparConstants.CPAR_CHANGE_TO);
        if (StringUtils.isNullOrEmpty(type)) {
            if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CPAR_TYPE))) {
                type = request.getParameter(CparConstants.CPAR_TYPE);
            } else if (!StringUtils.isNullOrEmpty(request.getParameter("cpar." + CparConstants.CPAR_TYPE))) {
                type = request.getParameter("cpar." + CparConstants.CPAR_TYPE);
            } else {
                return (Integer) request.getAttribute(CparConstants.CPAR_TYPE);
            }
        }
        return Integer.parseInt(type);
    }

    public void createNewCpar(Cpar cparObject, String userId, boolean isParFromFinding) {

        cparObject.setCpar_id(cparService.getCparPK());
        cparObject.setRow_entry_date(sdf.format(new Date()));
        cparObject.setCreated_by(userId);
        cparObject.setRow_user_id(userId);
        cparObject.setStatus_id("4");

        //Findings default to PARs
        if (isParFromFinding)
            cparObject.setContinual_Improvements("1");
        setCpar(cparObject);
    }

    @Override
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        List<Issue> issues = getCpar().getIssues();
        if (issues != null) {
            int i = 0;
            for (Issue issue : issues) {
                issue.setSelected(request.getParameter("issues[" + i + "].selected") != null);
                i++;
            }
            super.reset(mapping, request);
        }
    }
}
