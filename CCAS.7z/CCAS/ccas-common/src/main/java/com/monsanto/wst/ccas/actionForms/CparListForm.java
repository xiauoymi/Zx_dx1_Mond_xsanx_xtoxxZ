/*
 * Created on Feb 24, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.SelectedIndex;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class CparListForm extends org.apache.struts.validator.ValidatorActionForm {

    private CparListObject cparListObject = new CparListObject();
    private int type;
    private Map<String, Object> cparsList;

    public void setCparListObject(CparListObject obj) {
        cparListObject = obj;
    }

    public CparListObject getCparListObject() {
        return cparListObject;
    }

    /**
     * @return Returns the complaintsList.
     */
    public Map<String, Object> getCparsList() {
        return cparsList;
    }

    public void setCparsList(Map<String, Object> cparsList) {
        this.cparsList = cparsList;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void retainSelectedOrChangedDepartmentProcess(List<SelectedIndex> areas) {
        List<CheckboxItem> selectedFunctionalAreaList = new ArrayList<CheckboxItem>();
        if (cparListObject.getFunctionalArea() != null) {
            cparListObject.getFunctionalArea().resetIndexes(cparListObject, areas, selectedFunctionalAreaList);
            cparListObject.setSelectedFunctionalAreas(selectedFunctionalAreaList);
        }
    }
}
