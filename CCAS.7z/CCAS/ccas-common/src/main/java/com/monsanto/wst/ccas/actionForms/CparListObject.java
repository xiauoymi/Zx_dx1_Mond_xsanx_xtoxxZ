package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;

import java.io.Serializable;

public class CparListObject extends ObjectWithCheckboxGroups implements Serializable {
    private String controlNumber = "";
    private String createDateFrom = "";
    private String createDateTo = "";
    private String initiatedBy = "";
    private String status = "";
    private String region = "";
    private String filingLocation = "";
    private String responsibleLocation = "";
    private String responsibleLocationRegion = "";
    private String claimNumber = "";
    private String complaintBusinessId;
    private String siteManager;
    private String functionId;
    private String isoElement;
    private String generator;
    private String findingType;
    private String cparConversion;
    private String filingProgramId;
    private String closingDate = "";
    private String searchText;
    private String responsibleProgramId;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    private String crop;


    public String getResponsibleLocationRegion() {
        return responsibleLocationRegion;
    }

    public void setResponsibleLocationRegion(String responsibleLocationRegion) {
        this.responsibleLocationRegion = responsibleLocationRegion;
    }

    public CparListObject() {
    }

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    public String getFilingProgramId() {
        return filingProgramId;
    }

    public String getResponsibleProgramId() {
        return responsibleProgramId;
    }

    public String getSiteManager() {
        return siteManager;
    }

    public void setSiteManager(String siteManager) {
        this.siteManager = siteManager;
    }

    public void setFilingProgramId(String filingProgramId) {
        this.filingProgramId = filingProgramId;
    }

    public void setResponsibleProgramId(String responsibleProgramId) {
        this.responsibleProgramId = responsibleProgramId;
    }

    /**
     * @return Returns the claimNumber.
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * @param claimNumber The claimNumber to set.
     */
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }


    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the initiatedBy.
     */
    public String getInitiatedBy() {
        return initiatedBy;
    }

    /**
     * @param initiatedBy The initiatedBy to set.
     */
    public void setInitiatedBy(String initiatedBy) {
        this.initiatedBy = initiatedBy;
    }

    /**
     * @return Returns the region.
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return Returns the status.
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return Returns the createDateFrom.
     */
    public String getCreateDateFrom() {
        return createDateFrom;
    }

    /**
     * @param createDateFrom The createDateFrom to set.
     */
    public void setCreateDateFrom(String createDateFrom) {
        this.createDateFrom = createDateFrom;
    }

    /**
     * @return Returns the createDateTo.
     */
    public String getCreateDateTo() {
        return createDateTo;
    }

    /**
     * @param createDateTo The createDateTo to set.
     */
    public void setCreateDateTo(String createDateTo) {
        this.createDateTo = createDateTo;
    }

    /**
     * @return Returns the filingLocation.
     */
    public String getFilingLocation() {
        return filingLocation;
    }

    /**
     * @param filingLocation The filingLocation to set.
     */
    public void setFilingLocation(String filingLocation) {
        this.filingLocation = filingLocation;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String getResponsibleLocation() {
        return responsibleLocation;
    }

    /**
     * @param responsibleLocation The responsibleLocation to set.
     */
    public void setResponsibleLocation(String responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public void reset() {
        setClaimNumber("");
        setControlNumber("");
        setCreateDateFrom("");
        setCreateDateTo("");
        setInitiatedBy("");
        setRegion("");
        setStatus("0");
        setFilingLocation("");
        setResponsibleLocation("");
        setSiteManager("");
        setSearchText("");
        setIsoElement("");
    }

    public String getIsoElement() {
        return isoElement;
    }

    public void setIsoElement(String isoElement) {
        this.isoElement = isoElement;
    }


    public String getGenerator() {
        return generator;
    }

    public void setGenerator(String generator) {
        this.generator = generator;
    }

    public String getFindingType() {
        return findingType;
    }

    public void setFindingType(String findingType) {
        this.findingType = findingType;
    }

    public String getCparConversion() {
        return cparConversion;
    }

    public void setCparConversion(String cparConversion) {
        this.cparConversion = cparConversion;
    }

    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }
}