package com.monsanto.wst.ccas.actionForms;

import org.apache.struts.action.ActionForm;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 2, 2011
 * Time: 3:34:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceAdminForm  extends ActionForm {

    private Map<Integer, String> refTable;
    private Map<Integer, String> refData;
    private Map<Integer, String> refDataType;

    private String refTableSelected;
    private String refDataSelected;
    private String refDataTypeSelected;

    boolean hasActiveFlag;

    private int dataId;
    private String dataValue;
    private String dataValue2;

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    private String business;
    boolean active;

    public boolean isHasActiveFlag() {
        return hasActiveFlag;
    }

    public void setHasActiveFlag(boolean hasActiveFlag) {
        this.hasActiveFlag = hasActiveFlag;
    }

    public Map<Integer, String> getRefTable() {
        return refTable;
    }

    public void setRefTable(Map<Integer, String> refTable) {
        this.refTable = refTable;
    }

    public Map<Integer, String> getRefData() {
        return refData;
    }

    public void setRefData(Map<Integer, String> refData) {
        this.refData = refData;
    }

    public Map<Integer, String> getRefDataType() {
        return refDataType;
    }

    public void setRefDataType(Map<Integer, String> refData) {
        this.refDataType = refData;
    }

    public String getRefDataTypeSelected() {
        return refDataTypeSelected;
    }

    public void setRefDataTypeSelected(String i) {
        refDataTypeSelected = i;
    }

    public String getRefDataSelected() {
        return refDataSelected;
    }

    public void setRefDataSelected(String i) {
        refDataSelected = i;
    }

    public String getRefTableSelected() {
        return refTableSelected;
    }

    public void setRefTableSelected(String i) {
        refTableSelected = i;
    }

    public int getDataId() {
        return dataId;
    }

    public void setDataId(int dataId) {
        this.dataId = dataId;
    }

    public String getDataValue() {
        return dataValue;
    }

    public void setDataValue(String dataValue) {
        this.dataValue = dataValue;
    }

    public String getDataValue2() {
        return dataValue2;
    }

    public void setDataValue2(String dataValue) {
        this.dataValue2 = dataValue;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
