//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.model.StopSaleListObject;
import org.apache.struts.validator.ValidatorActionForm;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 05-17-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:form name="stopSaleListForm"
 */
public class StopSaleListForm extends ValidatorActionForm {

    private StopSaleListObject stopSaleFilter = new StopSaleListObject();

    private Map<String, Object> stopSaleMap = new LinkedHashMap<String, Object>();

    private boolean stopSaleMapEmpty;

    private String crop;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    /**
     * @return Returns the stopSaleFilter.
     */
    public StopSaleListObject getStopSaleFilter() {
        return stopSaleFilter;
    }

    /**
     * @param stopSaleFilter The stopSaleFilter to set.
     */
    public void setStopSaleFilter(StopSaleListObject stopSaleFilter) {
        this.stopSaleFilter = stopSaleFilter;
    }

    /**
     * @return Returns the stopSaleMap.
     */
    public Map<String, Object> getStopSaleMap() {
        return stopSaleMap;
    }

    /**
     * @param stopSaleMap The stopSaleMap to set.
     */
    public void setStopSaleMap(Map<String, Object> stopSaleMap) {
        this.stopSaleMap = stopSaleMap;
    }

    /**
     * @return Returns the stopSaleMapEmpty.
     */
    public boolean isStopSaleMapEmpty() {
        return stopSaleMapEmpty;
    }

    /**
     * @param stopSaleMapEmpty The stopSaleMapEmpty to set.
     */
    public void setStopSaleMapEmpty(boolean stopSaleMapEmpty) {
        this.stopSaleMapEmpty = stopSaleMapEmpty;
    }
}