package com.monsanto.wst.ccas.actionForms;

import com.monsanto.wst.ccas.model.Complaint;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: May 1, 2011
 * Time: 10:08:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class UploadFileForm extends org.apache.struts.validator.ValidatorActionForm {
    public FormFile getLocalFilePath() {
        return localFilePath;
    }

    public void setLocalFilePath(FormFile localFilePath) {
        this.localFilePath = localFilePath;
    }

    private FormFile localFilePath;

    public String getEmailReport() {
        return emailReport;
    }

    public void setEmailReport(String emailReport) {
        this.emailReport = emailReport;
    }

    private String emailReport;

    private Complaint c;

    public UploadFileForm() {
        super();
        this.setC(new Complaint());
    }

    /**
     * @return Returns the c.
     */
    public Complaint getC() {
        return c;
    }

    /**
     * @param c The c to set.
     */
    public void setC(Complaint c) {
        this.c = c;
    }

    @Override
    public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
        return super.validate(actionMapping, httpServletRequest);    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    public void reset(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
        super.reset(actionMapping, httpServletRequest);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
