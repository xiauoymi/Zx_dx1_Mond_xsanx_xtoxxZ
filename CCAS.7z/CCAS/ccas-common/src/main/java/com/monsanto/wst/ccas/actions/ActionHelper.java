/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.applicationinfo.*;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.dao.LocationDAOImpl;
import com.monsanto.wst.ccas.complaints.RegionDaoImpl;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.userAdmin.UserBusiness;
import com.monsanto.wst.ccas.controller.userAdmin.UserRegion;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.LookUpDAO;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.importdata.LocationService;
import com.monsanto.wst.ccas.importdata.LocationServiceImpl;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import org.apache.struts.action.ActionServlet;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.*;

/**
 * @author jbrahmb
 */
public class ActionHelper implements IActionHelper {

    private final ComplaintService complaintService;
    private final LookUpService lookupService;
    private final DataSource dataSource;


    public ActionHelper() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        complaintService = new ComplaintServiceImpl();
        lookupService = new LookUpServiceImpl();
    }

    public ActionHelper(DataSource ds, ComplaintService cs, LookUpService ls) {
        dataSource = ds;
        complaintService = cs;
        lookupService = ls;
    }


    public String getLocationRegion(String locationId) {
        try {
            LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
            return lookupdao.getLocationRegion(locationId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }


    public Map<String, String> getViewableRoleList(String userId, String locale) {
        return lookupService.getViewableRoleList(userId, locale);
    }

    public Map<String, String> getBusinessRelatedCrops(int businessId, String locale) {
        return lookupService.getBusinessRelatedCrops(businessId, locale);
    }

    public Map<String, String> getCropList(String locale) {
        return lookupService.getCrops(locale);
    }

    public Map<String, String> getLocationList(int userBusinessPreferenceId, String locale) {
        return lookupService.getLocations(false, userBusinessPreferenceId, locale);
    }

    /**
     * @param regionId
     * @return Returns the locationList.
     */
    public Map<String, String> getRegionSpecificLocationList(String regionId, String locale) {
        LocationService service = new LocationServiceImpl();
        return service.getRegionRelatedLocationMap(regionId, locale);
    }

    /**
     * @return Returns the qualityissueList.
     */
    public Map<String, String> getQualityissueList(String locale) {
        return lookupService.getQualityIssues(locale);
    }


    /**
     * @return Returns the evaluationEffectiveList.
     */
    public Map<String, String> getEvalEffectiveList(String locale) {
        Map<String, String> evaluationEffectiveList = new LinkedHashMap<String, String>();
        String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.select");
        String yes = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.yes");
        String no = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.no");

        evaluationEffectiveList.put("", select);
        evaluationEffectiveList.put("1", yes);
        evaluationEffectiveList.put("0", no);
        return evaluationEffectiveList;
    }

    /**
     * @return Returns the continualImprovementsList.
     */
    public Map<String, String> getContinualImprovementsList(String locale) {
        Map<String, String> continualImprovementsList = new LinkedHashMap<String, String>();
        String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectCI");
        String yes = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.yes");
        String no = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.no");

        continualImprovementsList.put("", select);
        continualImprovementsList.put("2", yes);
        continualImprovementsList.put("1", no);
        return continualImprovementsList;
    }


    /**
     * @return Returns the salesyearList.
     */
    public Map<String, String> getSalesyearList(String locale) {
        return lookupService.getYear(locale);
    }

    public Map<String, String> getIlTypes(String locale) {
        return lookupService.lookUpIlTypes(locale);
    }

    /**
     * @return Returns the seedsizeList.
     */
    public Map<String, String> getSeedsizeList(String locale) {
        return lookupService.getSeedSize(locale);
    }

    /**
     * @return Returns the statesList.
     */
    public Map<String, String> getStatesList() {
        return lookupService.getStates();
    }

    public Map<String, String> getRegionSpecificStatesList(String userId, String region, String locale) {
        return lookupService.getStatesByRegionSelected(region, locale);
    }

    public Map<String, String> getStatusListByRole(String type, String locale, Map<String, Boolean> roles) {
        return lookupService.getStatusByRole(type, locale, roles);
    }

    /**
     * @return Returns the statusList.
     */
    public Map<String, String> getAllStatusList(String type, String locale) {
        return lookupService.getAllStatus(type, locale);
    }

    public Map<String, String> getClaimStatusTypes(String type, String locale) {
        return lookupService.getClaimStatusTypes(type, locale);
    }

    /**
     * @return Returns the uomList.
     */
    public Map<String, String> getUomList(String locale) {
        return lookupService.getUOM(locale);
    }

    /**
     *
     * @param type
     * @param getActive
     * @param businessId
     * @return Returns the varityList.
     */
    public Map<String, String> getGeneratorList(int type, boolean getActive, String locale, int businessId) {
        return lookupService.getGenerator(type, getActive, locale, businessId);
    }

    /**
     * @return Returns the varityList.
     */
    public Map<String, String> getEvaluatorList(String locale) {
        return lookupService.getEffectivenessEvaluator(locale);
    }

    /**
     *
     * @param type
     * @param getActiveOnly
     * @param businessId
     * @return Returns the varityList.
     */
    public Map<String, String> getFindingTypeList(int type, boolean getActiveOnly, String locale, boolean isMCAS, int businessId) {
        return lookupService.getFindingTypes(type, getActiveOnly, locale, isMCAS, businessId);
    }

    /**
     * @return Returns the isoStandardList.
     */
    public Map<String, String> getIsoStandardList(String locale, int businessId, String qualityProgram) {
        return lookupService.getISOStandards(locale, businessId, qualityProgram);
    }

    public Map<String, String> getQualityStandardList(String locale, int busId) {
        return lookupService.getQualityStandards(locale, busId);
    }

    public Map<String, String> getOrganizationList(String locale, int busId) {
        return lookupService.getOrganizations(locale, busId);
    }

    public Map<String, String> getDepartmentAffectedList(String locale, int busId) {
        return lookupService.getDepartmentAffected(locale, busId);
    }

    public void reloadAllData() {
    }

    public String getAdminEmail() {
        return lookupService.getEmail("ADMN")[0];
    }

    public String getAffinaEmail() {
        return lookupService.getEmail("AFFN")[0];
    }

    public String getCcasSupportEmail() {
        return lookupService.getEmail("SUPP")[0];
    }

    public String getDmposExceptionCcEmail1() {
        return lookupService.getEmail("SUPC")[0];
    }

    public String getDmposExceptionCcEmail2() {
        return lookupService.getEmail("SUPC")[1];
    }

    public String getSbfascasQms() {
        return lookupService.getEmail("SQMS")[0];
    }

    public String getDocumentumDistributionList() {
        return lookupService.getEmail("DOCU")[0];
    }

    public Map<String, String> getBusinessTypes(String locale) {
        return lookupService.getBusinessTypeMap(locale);
    }

    public int getUserBusinessPreference(User user) {
        BusinessService service = (BusinessService) ServiceLocator.locateService(BusinessService.class);
        return service.getBusinessPreference(user);
    }

    public Map<String, String> getBusinessPreferenceRelatedCropList(int businessId, String locale) {
        return lookupService.getBusinessRelatedCrops(businessId, locale);
    }

    public Map<String, String> getRegionsForSearch(String userId, int businessId, boolean validateForUserRole,
                                                   String locale) {
        return lookupService.getRegions(userId, businessId, validateForUserRole, locale);
    }

    public Map<String, ApplicationInfo> setApplicationInfoMap(int businessId, String applicationScreen) {
        ApplicationInfoDao applicationInfoDao = new ApplicationInfoDaoImpl(dataSource);
        ApplicationService applicationService = new ApplicationServiceImpl(applicationInfoDao);
        return applicationService.getBusinessRelatedApplicationInfoMap(businessId, applicationScreen);
    }

    public String getEmptyRegion(String userId, String regionId, String locale) {
        String key = "";
        try {
            Map<String, String> stateIdMap = getRegionSpecificStatesList(userId, regionId, locale);

            if (stateIdMap != null) {
                Iterator<String> itr = stateIdMap.keySet().iterator();
                if (itr.hasNext()) {
                    key = itr.next();
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return key;

    }


//    public List<CheckboxItem> getSelectedCparCategories(Cpar c, Map<String, String[]> requestParamMap,
//                                                        String functionalAreaType) {
//
//        List<CheckboxItem> functionalAreaList = new ArrayList<CheckboxItem>();
//        AuditRequestHelper helper = new AuditRequestHelper();
//        List<SelectedIndex> list = helper.getCheckedIndexes(requestParamMap, functionalAreaType);
//        SelectedIndex index = null;
//        if (list != null && list.size() > 0) {
//            CheckboxGroup checkboxGroupObject = null;
//            Object[] rowFunctionalAreaArray = null;
//            CheckboxRow checkboxRow = null;
//            Object[] rowFunctionalAreaObjectArray = null;
//            CheckboxItem checkboxItem = null;
//            for (SelectedIndex aList : list) {
//                index = aList;
//                if (functionalAreaType != null && functionalAreaType.contains("nonconformanceCategoryList")) {
//                    checkboxGroupObject = c.getNonconformanceCategoryList().get(index.getFirstIndex());
//                } else {
//                    checkboxGroupObject = c.getFunctionalAreaList().get(index.getFirstIndex());
//                }
//                rowFunctionalAreaArray = checkboxGroupObject.getCheckboxRowList();
//                checkboxRow = (CheckboxRow) rowFunctionalAreaArray[index.getSecondIndex()];
//                rowFunctionalAreaObjectArray = checkboxRow.getCheckboxItemList();
//                checkboxItem = (CheckboxItem) rowFunctionalAreaObjectArray[index.getThirdIndex()];
//                functionalAreaList.add(checkboxItem);
//            }
//        }
//        return functionalAreaList;
//    }

    /**
     * Method to Load the Application Info properties based on User's Preferences.
     *
     * @param servlet
     * @param request
     */
    public void setApplicationInfoMap(HttpServletRequest request, int businessId, ActionServlet servlet) {
        Map<String, ApplicationInfo> applicationInfoMap;
        ServletContext context = servlet.getServletContext();
        applicationInfoMap = (Map<String, ApplicationInfo>) context.getAttribute("APPLICATION_INFO");
        applicationInfoMap = new ActionHelper().setApplicationInfoMap(businessId, "COMPLAINTS");
        servlet.getServletContext().setAttribute("APPLICATION_INFO", applicationInfoMap);
        request.getSession().setAttribute("APPLICATION_INFO", applicationInfoMap);
    }

    public Map<String, String> getAssesmentMap(String locale) {
        return lookupService.getAssesmentMap(locale);
    }

    public Map<String, String> getLitigationCategoryMap(String locale) {
        return lookupService.getLitigationCategoryMap(locale);
    }

    public Map<String, String> getBusinessRelatedMaterialGroupMap(int businessId, String locale) {
        return lookupService.lookupBusinessRelatedMaterialGroups(businessId, locale);
    }

    public Map<String, String> getBusinessRelatedMaterialPricingGroupMap(int businessId, String locale) {
        return lookupService.lookupBusinessRelatedMaterialPricingGroups(businessId, locale);
    }

    public Map<String, String> getBusinessRelatedSalesOfficeMap(int businessId, String locale) {
        return lookupService.lookupBusinessRelatedSalesOffices(businessId, locale);
    }

    public String getStatusDescription(String statusId, int statusType, String locale) {
        return lookupService.getStatusDescription(Integer.parseInt(statusId), statusType, locale);
    }

    private UserDetails getUserDetails(String userId, String locale) {
        try {
            UserAdminDAO userAdminDao = getUserAdminDAO();
            return userAdminDao.getSpecificUserDetails(userId, userId, locale);
        } catch (MCASException e) {
            throw new RuntimeException(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public void isUserAuthorizedToViewControls(HttpServletRequest request,
                                               int objectRegionId,
                                               int objectBusinessId,
                                               User user) {
        //Check for User's Role : Security Enhancements
        UserDetails details = getUserDetails(user.getUser_id(), user.getLocale());

        if (details != null && (objectBusinessId == details.getBusinessId())) {
            int roleId = details.getRoleId();
            if (MCASConstants.ROLE_ID_REGIONAL_ADMIN == roleId || MCASConstants.ROLE_ID_USER == roleId ||
                    MCASConstants.ROLE_ID_USER_WITH_AFFINA_ACCESS == roleId) {
                if (!objectRegionExistsInMultipleUserRegions(objectRegionId, details)) {
                    request.setAttribute("canViewControls", false);
                } else {
                    request.setAttribute("canViewControls", true);
                }
            } else if (MCASConstants.ROLE_ID_READ_ONLY_USER ==
                    roleId) {//If the user has READ_ONLY role, do not display any controls
                request.setAttribute("canViewControls", false);
            }
        }
    }

    private boolean objectRegionExistsInMultipleUserRegions(int objectRegionId, UserDetails details) {
        boolean isRegionExists = false;
        UserRegion userRegion = details.getUserRegion();
        String[] regionIdArray = null;
        if (userRegion != null) {
            regionIdArray = userRegion.getUserRegionArray();
            for (String region : regionIdArray) {
                if (objectRegionId == Integer.parseInt(region)) {
                    isRegionExists = true;
                    break;
                }
            }
        }
        return isRegionExists;

    }

    /**
     * Method used to send emails when the user clicks Send Email button
     *
     * @param request
     * @return
     */
    public boolean sendEmailOnUserClick(HttpServletRequest request) throws EmailException {
        boolean condensedEmail = false;
        MCASUtil mcasUtil = new MCASUtil();
        if (request.getParameter("SEND_CONDENSED_EMAIL") != null &&
                request.getParameter("SEND_CONDENSED_EMAIL").equalsIgnoreCase("true")
                && request.getParameter("id_action") != null &&
                request.getParameter("id_action").equalsIgnoreCase("complaint")) {
            condensedEmail = true;
        }
        User user = ((User) request.getSession().getAttribute(User.USER));
        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setFrom(getAdminEmail());
        emailInfo.setSubject(request.getParameter("emailSubject"));
        String[] toEmailAddresses = org.apache.commons.lang.StringUtils.split(request.getParameter("toEmailAddress"), ";");
        emailInfo.setToArray(toEmailAddresses);
        String[] ccEmailAddresses = org.apache.commons.lang.StringUtils.split(request.getParameter("ccEmailAddress"), ";");
        emailInfo.setCcArray(ccEmailAddresses);
        String pageBody = request.getParameter("printPreviewSrc");
        if (condensedEmail && isMCASRowCropUser(user)) {
            pageBody = mcasUtil.getRidOfMCASAdminFieldsFromEmail(pageBody);
        }
        if (condensedEmail) {
            pageBody = mcasUtil.getProcessedBody(pageBody);
        }
        emailInfo.setBody(request.getParameter("comments") + pageBody);
        return new EmailService().sendMailOnObjectCreate(emailInfo, false);
    }

    private boolean isMCASRowCropUser(User user) {
        return user != null && user.getBusinessId() == 1;
    }

    public List<ApplicationAuditProcessor> getApplicationAuditProcessors(String applicationName) {
        ApplicationAuditProcessorFactory applicationAuditProcessorFactory = new ApplicationAuditProcessorFactoryImpl();
        return applicationAuditProcessorFactory.getApplicationAuditProcessor(applicationName);
    }


    public Map<String, String> getBusinessRelatedRegions(List<String> selectedBusinessList) {
        String[] businessIdArr = null;
        int i = 0;
        if (!selectedBusinessList.isEmpty()) {
            businessIdArr = new String[selectedBusinessList.size()];
        }
        for (String businessId : selectedBusinessList) {
            businessIdArr[i++] = businessId;
        }
        UserAdminService service = new UserAdminServiceImpl();
        return service.getRegionsForSelectedBusiness(businessIdArr);
    }

    public List<String> getSelectedBusinessList(String[] businessIds) {
        List<String> businessIdList = new ArrayList<String>();
        if (businessIds != null && !isBusinessNull(businessIds)) {
            businessIdList.addAll(Arrays.asList(businessIds));
        }
        return businessIdList;
    }

    private boolean isBusinessNull(String[] businessIds) {
        return businessIds == null || (businessIds.length == 1 && businessIds[0].equalsIgnoreCase(""));
    }

    public boolean userBelongsToMultipleBusiness(User user, HttpSession session, HttpServletRequest request) {
        boolean userBelongsToMultipleBusiness = false;
        UserAdminDAO userAdminDao = getUserAdminDAO();
        UserDetails userDetails = getUserDetails(user, userAdminDao);

        if (userDetails != null) {
            UserBusiness userBusiness = userDetails.getUserBusiness();
            if (userBusiness != null) {
                String[] businessIds = userBusiness.getBusinessIds();
                if (businessIds.length != 0) {
                    if (businessIds.length > 1) { //user belongs to Multiple Business
                        //load the Business ID:Name to a map and set it into Session
                        session.setAttribute("multipleBusinessMap", getBusinessTypes(user.getLocale()));
                        request.setAttribute("hasMultipleBusiness", "successMultipleBusiness");
                        userBelongsToMultipleBusiness = true;
                    } else {
                        user.setBusinessId(Integer.parseInt(businessIds[0]));
//            user.setUserBusinessPreference(user.getUserBusinessPreference());
                        updateUserBusiness(user, Integer.parseInt(businessIds[0]), false);
                    }
                }
            }
        }
        return userBelongsToMultipleBusiness;
    }

    private UserAdminDAO getUserAdminDAO() {
        try {
            return (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean updateUserBusiness(User user, int businessId, boolean isAssignedToMultipleBusiness) {
        try {
            UserAdminDAO userAdminDao = getUserAdminDAO();
            UserDetails userDetails = getUserDetails(user, userAdminDao);
            userDetails.setBusinessId(businessId);
            if (isAssignedToMultipleBusiness) {
                userDetails.setBusinessPreferenceId(user.getUserBusinessPreference());
            }
            return userAdminDao.editUser(userDetails, userDetails.getUserId());
        } catch (MCASException e) {
            throw new RuntimeException(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    private UserDetails getUserDetails(User user, UserAdminDAO userAdminDao) {
        try {
            return userAdminDao.getSpecificUserDetails(user.getUser_id(), user.getUser_id(), user.getLocale());
        } catch (MCASException e) {
            throw new RuntimeException(e);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> getRegionSpecificLocationList(String region, int locationType, String locale) {
        LocationService service = new LocationServiceImpl(new RegionDaoImpl(dataSource), new LocationDAOImpl(dataSource));
        return service.getRegionRelatedLocations(region, locationType, locale);
    }

    public Map<String, String> getRegionSpecificLocationListSearch(String region, int locationType, String locale) {
        LocationService service = new LocationServiceImpl(new RegionDaoImpl(dataSource), new LocationDAOImpl(dataSource));
        return service.getRegionRelatedLocationsSearch(region, locationType, locale);
    }

    public String getDefaultYear(String locale) {
        String currentYearkey = "";
        Map<String, String> yearMap = getSalesyearList(locale);
        for (String s : yearMap.keySet()) {
            String currentKey = s;
            String value = yearMap.get(currentKey);
            if (value != null && value.equalsIgnoreCase(Integer.toString(Calendar.getInstance().get(1)))) {
                currentYearkey = currentKey;
            }
        }
        return currentYearkey;
    }

    public void getCARData(HttpServletRequest request, Cpar cpar) {
        if (createCar(request) || createPar(request)) {
            //these will be stored with the Complaint now.
            //Bug fixing
            String [] aux = new String[1];
            aux[0] = request.getParameter("c.complaint_id");
            cpar.setComplaint_id(aux);
            cpar.setClaim_number(request.getParameter("c.claim_number"));
            cpar.setFiling_location(request.getParameter("c.reporting_location_code"));
            cpar.setResponsible_location(request.getParameter("c.responsible_plant_code"));
            cpar.setReport_date(request.getParameter("c.report_date"));
            cpar.setIssue_year(request.getParameter("c.sales_year_id"));
            cpar.setFunctionId(request.getParameter("c.functionId"));
            cpar.setReport_initiator_email(request.getParameter("c.report_initiator_email"));
            cpar.setInitiatedByUserId(request.getParameter("c.initiatedByUserId"));
            cpar.setSiteManagerUserId(request.getParameter("c.siteManagerUserId"));
            cpar.setRegion(request.getParameter("c.region_id"));
            cpar.setGenerator(CparConstants.CPAR_COMPLAINT_GENERATOR);
            cpar.setComplaintEntryType(complaintService.getComplaintEntryType(request.getParameter("c.complaint_id")));
            request.setAttribute("msg", "false");
        }
    }

    public boolean createPar(HttpServletRequest request) {
        return !StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CREATE_PAR)) &&
                "true".equalsIgnoreCase(request.getParameter(CparConstants.CREATE_PAR));
    }

    public boolean createCar(HttpServletRequest request) {
        return !StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CREATE_CAR)) &&
                "true".equalsIgnoreCase(request.getParameter(CparConstants.CREATE_CAR));
    }

    /**
     * Method to validate the display of save / update method
     *
     * @param user
     * @param methodType
     * @return
     * @throws Exception
     */
    public boolean isSaveUpdateControlsVisible(User user, String methodType) {
        BusinessServiceImpl serviceImpl = new BusinessServiceImpl();
        return serviceImpl.isSaveUpdateControlVisible(user, methodType);
    }
}
