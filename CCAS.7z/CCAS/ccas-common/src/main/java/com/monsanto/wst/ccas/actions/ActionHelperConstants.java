package com.monsanto.wst.ccas.actions;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ActionHelperConstants { // todo these were moved from ActionHelper.  Need to figure out where they actually belong, and put them there

    public static final String STATE_LIST = "statesList";
    public static final String SALES_YEAR_LIST = "salesyearList";
    public static final String IL_TYPE_LIST = "ilTypeList";
    public static final String LOCATION_LIST = "locationList";
    public static final String REGION_SPECIFIC_LOCATION_LIST = "regionSpecificLocationList";
    public static final String REGION_SPECIFIC_LOCATION_LIST_SEARCH = "regionSpecificLocationListSearch";
    public static final String COMPLAINT_STATUS_LIST = "complaintStatusList";
    public static final String STOP_SALE_STATUS_LIST = "stopsaleStatusList";
    public static final String CPAR_STATUS_LIST = "cparStatusList";
    //    public static final String ALL_STATUS_LIST = "allStatusList";
    public static final String CLAIM_STATUS_LIST = "claimStatusList";
    public static final String COMPLAINT_ROLE_STATUS_LIST = "complaintRoleStatusList";
    //    public static final String STOP_SALE_ROLE_STATUS_LIST = "stopsaleRoleStatusList";
    public static final String CPAR_ROLE_STATUS_LIST = "cparRoleStatusList";
    //    public static final String ROLE_STATUS_LIST = "roleStatusList";
    public static final String CROP_LIST = "cropList";
    public static final String GENERATOR_LIST = "generatorList";
    public static final String EVALUATOR_LIST = "evaluatorList";
    public static final String FINDING_TYPE_LIST = "findingTypeList";
    public static final String ISO_STANDARD_LIST = "isoStandardList";
    public static final String QUALITY_STANDARD_LIST = "qualityStandardList";
    public static final String QUALITY_ISSUE_LIST = "qualityissueList";
    public static final String EMAIL_TYPE_COMPLAINT_NEW = "New Complaint:";
    public static final String EMAIL_TYPE_COMPLAINT_STATUS_CHANGED = "Complaint Status Changed:";
    public static final String EMAIL_TYPE_CPAR_NEW = "New Car/Par:";
    public static final String EMAIL_TYPE_CPAR_STATUS_CHANGED = "Car/Par Status Changed:";
    public static final String EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED = "Car/Par Finding Type Changed:";
    public static final String UOM_LIST = "uomList";
    public static final String SEED_SIZE_LIST = "seedsizeList";
    public static final String BRAND_LIST = "brandList";
    public static final String VARIETY_LIST = "varityList";
    public static final String REGION_LIST = "regionList";
    public static final String ALL_REGION_LIST = "allRegionList";
    public static final String EVAL_EFFECTIVE_LIST = "evalEffectiveList";
    public static final String CONTINUAL_IMPROVEMENTS_LIST = "continualImprovementsList";
    public static final String MSG = "msg";
    public static final String ERROR_MSG = "error_msg";
    public static final String SALES_OFFICE_MAP = "salesOfficeMap";
    public static final String MATERIAL_GROUP_MAP = "materialGropuMap";
    public static final String MATERIAL_GROUP_PRICING_MAP = "materialGropuPricingMap";
    public static final String REGION_LIST_FOR_NEW_COMPLAINTS = "regionListForNewComplaints";
    public static final String CROP_LIST_FOR_NEW_COMPLAINTS = "cropListForNewComplaints";
    public static final String USER_BUSINESS_PREFERENCE_REGION_LIST = "businessPreferenceRegionList";
    public static final String USER_BUSINESS_PREFERENCE_CROP_LIST = "businessPreferenceCropList";
    public static final String COMPLAINT_ASSESMENT_MAP = "complaintAssesmentMap";
    public static final String COMPLAINT_LITIGATION_CATEGORY_MAP = "complaintLitigationCategoryMap";
    public static final String BUSINESS_RELATED_MATERIAL_GROUP_MAP = "businessRelatedMaterialGroupMap";
    public static final String BUSINESS_RELATED_MATERIAL_PRICING_GROUP_MAP = "businessRelatedMaterialPricingGroupMap";
    public static final String BUSINESS_RELATED_SALES_OFFICE_MAP = "businessRelatedSalesOfficeMap";
    public static final String EMAIL_TYPE_STOP_SALE_NEW = "New Stop Sale ";
    public static final String EMAIL_TYPE_STOP_SALE_STATUS_CHANGE = "Stop Sale status changed ";
    public static final String REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST = "regionSpecificResponsibleLocation";
    public static final String REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST_SEARCH = "regionSpecificResponsibleLocationSearch";
    public static final String REGION_SPECIFIC_REPORTING_LOCATION_LIST = "regionSpecificReportingLocation";
    public static final String REGION_SPECIFIC_REPORTING_LOCATION_LIST_SEARCH = "regionSpecificReportingLocationSearch";
    public static final String REGION_SPECIFIC_FILING_LOCATION_LIST = "regionSpecificFilingLocation";
    public static final String REGION_SPECIFIC_FILING_LOCATION_LIST_SEARCH = "regionSpecificFilingLocationSearch";
    public static final String REGION_SPECIFIC_SHIPPING_LOCATION_LIST = "regionSpecificShippingLocation";
    public static final String CPAR_TYPES_FOR_CONVERSION = "cparTypesForConversion";
    public static final String FILING_PROGRAM_LIST = "filingProgramList";
    public static final String RESPONSIBLE_PROGRAM_LIST = "responsibleProgramList";
    public static final String INITIATOR_RESPONSE = "initiator_response";
    public static final String CROP_LIST_FOR_NEW_CPAR = "cropListForNewCPAR";
}
