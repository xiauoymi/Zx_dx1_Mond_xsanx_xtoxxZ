//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASLookupFilterUtil;
import com.monsanto.wst.ccas.validations.McasValidator;
import com.monsanto.wst.ccas.app.ApplicationSecurityProcessor;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactoryImpl;
import com.monsanto.wst.ccas.app.ApplicationSpecificFactory;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import org.apache.log4j.Category;
import org.apache.struts.action.*;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.*;

/**
 * MyEclipse Struts || Om Ganeshay Namah: || Creation date: 04-07-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/audit" name="auditForm" scope="request" validate="true"
 */
public class AuditAction extends DispatchAction {
    private final ActionHelper actionHelper;
    private final AuditService auditService;
    private final CheckboxItemService functionalAreaService;
    private final SessionHelper sessionHelper;
    private DataSource dataSource;
    private final CheckboxItemDao functionalAreaDAO;
    public static final String CURRENT_TAB = "currentTab";
    public static final String BUSINESS_ID = "BUSINESS_ID";//todo: these are all over
    public static final String RECORD_ID = "id";
    private static final String ACTION_ATTACH_FILE = "actionAttachFile";
    private static final String DESC_BUFFER = "descBuffer";
    private static final String PREV_ACTION = "prevAction";
    public static final String AUDIT_FORM = "auditForm";


    public AuditAction() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        actionHelper = new ActionHelper();
        auditService = new AuditServiceImpl();
        sessionHelper = new SessionHelper();
        functionalAreaDAO = new FunctionalAreaDaoImpl(dataSource);
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
    }

    public AuditAction(ActionHelper actionHelper, AuditService auditService, CheckboxItemService functionalAreaService,
                       SessionHelper sessionHelper, CheckboxItemDao functionalAreaDAO) {
        this.actionHelper = actionHelper;
        this.auditService = auditService;
        this.functionalAreaService = functionalAreaService;
        this.sessionHelper = sessionHelper;
        this.functionalAreaDAO = functionalAreaDAO;
    }

    private static final Category logger = Category.getInstance(AuditAction.class.getName());

    public ActionForward executeViewFromList(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);
        actionViewFromList(request, auditForm, user);
        performGeneralPostProcessing(request, auditForm, user);

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeAddNewFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionAddNewFinding(mapping, form, request, response, auditForm, tab, session, user);
    }

    public ActionForward executeDeleteFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);
        actionDeleteFinding(request, auditForm, user, tab);
        performGeneralPostProcessing(request, auditForm, user);

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeAckAndClose(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;

        FindingObject f = new FindingObject();
        f.setFindingID(getActionKey(request));
        f.setAckAndCloseText(auditForm.getAuditObj().getAckAndCloseFindingReason());

        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        actionAckAndCloseFinding(request, f, auditForm, user);

        performGeneralPostProcessing(request, auditForm, user);

        request.setAttribute(CURRENT_TAB, request.getParameter(CURRENT_TAB));

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    private void actionAckAndCloseFinding(HttpServletRequest request, FindingObject f, AuditForm auditForm,
                                          User user) throws
            Exception {

        String auditId = auditForm.getAuditObj().getAuditID();
        FindingObject findingObject = auditForm.getAuditObj().getFindingParMap().get(f.getFindingID());
        findingObject.setAckFindingId(f.getFindingID());
        findingObject.setAckAndCloseText(f.getAckAndCloseText());
        findingObject.setUserNameOfPersonWhoClosedFinding(user.getFull_name());
        findingObject.setAuditId(auditId);
        if ("true".equals(request.getParameter("isAckAndCloseFindingReasonUpdate"))) {
            auditService.updateReasonForFinding(findingObject);
        } else {
            if (auditFindingNotNull(auditId, f.getFindingID())) {
                auditService.closeFinding(findingObject);
            }
        }


        int auditObjectBusinessId = auditForm.getAuditObj().getBusinessId();
        request.setAttribute(BUSINESS_ID, auditObjectBusinessId);
        boolean canViewSaveUpdateControls = actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_CREATE_CAR);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        setFunctionDropdown(request, auditForm);

    }

    public ActionForward executeCreatePar(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionCreateCpar(mapping, form, request, response, auditForm, tab, session, user,
                CparConstants.GEN_FINDING_OBJ_TYPE_PAR);
    }

    public ActionForward executeCreateCar(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionCreateCpar(mapping, form, request, response, auditForm, tab, session, user,
                CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
    }

    public ActionForward executeCreateNC(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionCreateCpar(mapping, form, request, response, auditForm, tab, session, user,
                CparConstants.GEN_FINDING_OBJ_TYPE_NC);
    }

    public ActionForward executeCreateCI(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionCreateCpar(mapping, form, request, response, auditForm, tab, session, user,
                CparConstants.GEN_FINDING_OBJ_TYPE_CI);
    }

    public ActionForward executeSaveUpdate(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        if (auditForm.getAuditObj() != null) {
            return actionSaveUpdate(mapping, form, request, response, auditForm, user);
        }

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeSaveFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter("displayTab");
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        return actionFindingSave(mapping, form, request, response, auditForm, session, user, tab);
    }

    public ActionForward executeCancelFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);
        actionCancelFinding(request, auditForm, user);
        performGeneralPostProcessing(request, auditForm, user);

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeReset(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.FALSE, request, auditForm, session, user);
        actionReset(request, auditForm, user);
        performGeneralPostProcessing(request, auditForm, user);

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeAttachFile(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);

        if (auditForm.getAuditObj() != null) {
            return actionAttachFile(mapping, form, request, response, auditForm, user);
        }

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward executeViewEditFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AuditForm auditForm = (AuditForm) form;
        final String tab = request.getParameter(CURRENT_TAB);
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        performGeneralPreProcessing(Boolean.TRUE, request, auditForm, session, user);
        return actionViewEditFinding(mapping, form, request, response, auditForm, session, user, tab);
    }


    private ActionForward actionCreateCpar(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                           HttpServletResponse response, AuditForm auditForm, String tab,
                                           HttpSession session, User user, int cparType) {
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS,
                actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_CREATE_CAR));
        int auditObjectBusinessId = auditForm.getAuditObj().getBusinessId();
        request.setAttribute(BUSINESS_ID, auditObjectBusinessId);
        String auditFindingID = getActionKey(request);
        auditForm.getAuditObj().setAuditFindingID(auditFindingID);
        request.setAttribute(CparConstants.CPAR_TYPE, cparType);
        boolean isCar = cparType == CparConstants.GEN_FINDING_OBJ_TYPE_CAR;

        AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
        FindingTypeProcessor findingProcessor = auditFindingTypeFactory.getFindingTypeProcessor(isCar, cparType);

        findingProcessor.setDisplayTabInAuditForm(auditForm);
        FindingObject findingObj = findingProcessor.getFindingObject(auditForm, auditFindingID);

        List<ApplicationAuditProcessor> applicationAuditProcessors = getApplicationAuditProcessor(
                (String) session.getAttribute(MCASConstants.APPLICATION_NAME));
        Map<String, String> errorMap = new HashMap<String, String>();
        //todo This code call only one audit processor ... take a look at this
        for (ApplicationAuditProcessor processor : applicationAuditProcessors) {
            if (processor.processCreateCpar(user.getUser_id(), auditForm.getAuditObj(),
                    tab, errorMap,
                    auditService, findingObj)) {
                request.setAttribute(findingProcessor.getDuplicateErrorKey(),
                        findingProcessor.getDuplicateErrorMsg(user.getLocale()));
                request.setAttribute(CparConstants.CPAR_ID, findingObj.getFindingID());
                return mapping.findForward(MCASConstants.FALIURE);
            } else {
                request.setAttribute(CparConstants.IS_CAR_FLAG, Boolean.toString(isCar));
                setFunctionDropdown(request, auditForm);
                return createCPARAction(auditForm.getAuditObj().getAuditFindingID(), mapping, form, request, response,
                        cparType);
            }
        }

        //this causes tests to pass, but won't be reached when the app is running because there will be an ApplicationAuditProcessor.
        return mapping.findForward(MCASConstants.SUCCESS);
    }

    private ActionForward actionAddNewFinding(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                              HttpServletResponse response, AuditForm auditForm, String tab,
                                              HttpSession session, User user) throws Exception {
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        boolean canViewSaveUpdateControls = actionHelper
                .isSaveUpdateControlsVisible(user, AuditConstants.ADD_NEW_AUDIT_FINDING);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        session.setAttribute(PREV_ACTION, AuditConstants.FINDING_ADD);

        ActionForward faliureFwd = mapping.findForward(MCASConstants.FALIURE);

        if (auditForm.getAuditObj().getAuditNumber() == null ||
                auditForm.getAuditObj().getAuditNumber().equals("")) {
            ActionForward submitForward = saveAndSubmit(mapping, form, request, response);
            if (submitForward.equals(faliureFwd)) {
                return submitForward;
            }
        } else {
            ActionForward updateForward = updateAction(mapping, form, request, response);
            if (updateForward.equals(faliureFwd)) {
                return updateForward;
            }
        }
        createNewFindingObject(auditForm);
        setCurrentDisplayTabAndTable(tab, auditForm);

        performGeneralPostProcessing(request, auditForm, user);

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    private void performGeneralPreProcessing(boolean setRegion, HttpServletRequest request, AuditForm auditForm,
                                             HttpSession session, User user) {
        if (setRegion) {
            setRegionInSession(request);
        }

        session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));

        auditForm.validateCparFindingMap();
        setLocationsBasedOnApplication(request, auditForm.getAuditObj().getRegion_id());

        setCurrentTab(request, auditForm);

        setLocationList(request);
        setRegionList(request, user.getUser_id(), user.getBusinessId(), user.getLocale());
        setFunctionList(request);
        setAuditTypeMap(request);
    }

    protected void setReadOnlyFlag(HttpSession session, User user) {
        ApplicationSpecificFactory factory = (new ApplicationSpecificProcessorFactoryImpl())
                .getApplicationSpecificProcessor((String) session.getAttribute(MCASConstants.APPLICATION_NAME));
        ApplicationSecurityProcessor securityProcessor = factory.getApplicationSecurityProcessor();

        final AuditForm form = (AuditForm) session.getAttribute(AUDIT_FORM);

        if (form == null || form.getAuditObj() == null)
            session.setAttribute(MCASConstants.READ_ONLY, false);
        else
            session.setAttribute(MCASConstants.READ_ONLY, securityProcessor.isAuditReadOnly(form, user));
    }

    private void setRegionInSession(HttpServletRequest request) {
        String regionId = request.getParameter(AuditConstants.AUDIT_ENTRY_REGION);
        SessionHelper.setSelectedRegion(request.getSession(), regionId);
    }

    private ActionForward actionFindingSave(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                            HttpServletResponse response, AuditForm auditForm, HttpSession session,
                                            User user, String currentTab) {
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS,
                actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_FINDING_SAVE));
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        String previousAction = session.getAttribute(PREV_ACTION).toString();
        String forward = "";
        ActionForward updateFindingForward = null;
        String findingID = getActionKey(request);
        if (AuditConstants.FINDING_ADD.equalsIgnoreCase(previousAction)) {
            setCurrentDisplayTabAndTable(currentTab,
                    auditForm);
            forward = insertFinding(auditForm.getAuditObj(), request);
            if (forward.equals(MCASConstants.SUCCESS)) {
                auditForm.setDisplayCarTable2(false);
                auditForm.setDisplayParTable2(false);
                auditForm.setDisplayCiTable2(false);
            }
        } else {
            updateFindingForward = updateFinding(mapping, form, request, response);
            if (updateFindingForward != null && MCASConstants.SUCCESS.equalsIgnoreCase(updateFindingForward.getName())) {
                auditForm.setDisplayCarTable2(false);
                auditForm.setDisplayParTable2(false);
                auditForm.setDisplayCiTable2(false);
            } else {
                String descBuffer = session.getAttribute(DESC_BUFFER).toString();

                AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
                FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(currentTab);
                processor.setFindingDesc(auditForm, findingID, descBuffer);
            }
            forward = updateFindingForward.getName();
        }
        setFunctionDropdown(request, auditForm);
        return mapping.findForward(forward);
    }

    private ActionForward actionViewEditFinding(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                                HttpServletResponse response, AuditForm auditForm, HttpSession session,
                                                User user, String currentTab) {

        ActionErrors errors = new ActionErrors();
        String findingID = getActionKey(request);
        auditForm.validateCparFindingMap();
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
        auditForm.setDisplayCiTable2(false);
        boolean isBIOTECHFAS = MCASConstants.APPLICATION_NAME_BIOTECHFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
        try {
            filterLookupsBasedOnUserRegion(auditForm.getAuditObj(), user, request);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return mapping.findForward(MCASConstants.FALIURE);
        }

        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS,
                actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_VIEW_EDIT));
        request.setAttribute(BUSINESS_ID, auditForm.getAuditObj().getBusinessId());
        session.setAttribute(PREV_ACTION, AuditConstants.FINDING_EDIT);
        ActionForward faliureFwd = mapping.findForward(MCASConstants.FALIURE);

        ActionForward forward = null;
        if (StringUtils.isNullOrEmpty(auditForm.getAuditObj().getAuditNumber())) {
            forward = saveAndSubmit(mapping, form, request, response);
        } else {
            forward = updateAction(mapping, form, request, response);
        }
        if (forward.equals(faliureFwd)) {
            return forward;
        }
        String tabSelected = currentTab;

        AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
        FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(tabSelected);
        FindingObject editObj = processor.getFindingObject(auditForm, findingID);
        String descBuffer = processor.getFindingDesc(auditForm, findingID);

        if (!StringUtils.isNullOrEmpty(descBuffer)) {
            session.setAttribute(DESC_BUFFER, descBuffer);
        }
        auditForm.getAuditObj().setEditFindingObj(editObj);
        setCurrentDisplayTabAndTable(tabSelected, auditForm);

        //if (editObj == null || editObj.getCparID() == null) {
        //bug fixing
        if(!isBIOTECHFAS){
            if (StringUtils.isNullOrEmpty(editObj.getUserNameOfPersonWhoClosedFinding()) &&
                    (editObj == null || editObj.getCparID() == null)) {
                errors.add("cparNotFound", new ActionMessage("com.monsanto.wst.ccas.audit.noCpar"));
                saveErrors(request, errors);
                return mapping.findForward(MCASConstants.FALIURE);
            }
        }

        if(isBIOTECHFAS){
            if(editObj.getCparID() == null || editObj.getCparID().isEmpty()){
                return forward;
            }else{
                return new ActionForward("/cpar.do?method=cparEdit&cparId=" + editObj.getCparID());
            }
        }else{
            return new ActionForward("/cpar.do?method=cparEdit&cparId=" + editObj.getCparID());
        }

    }

    private ActionForward actionSaveUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                           HttpServletResponse response, AuditForm auditForm, User user) throws
            Exception {
        ActionForward forward = null;
        if (StringUtils.isNullOrEmpty(auditForm.getAuditObj().getAuditNumber())) {
            forward = saveAndSubmit(mapping, form, request, response);
            filterLookupsBasedOnUserRegion(auditForm.getAuditObj(), user, request);
            setFunctionDropdown(request, auditForm);
        } else {
            forward = updateAction(mapping, form, request, response);
        }
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS,
                actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_SAVE_OR_UPDATE));
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        return forward;
    }

    private ActionForward actionAttachFile(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                           HttpServletResponse response, AuditForm auditForm, User user) {
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS,
                actionHelper.isSaveUpdateControlsVisible(user, ACTION_ATTACH_FILE));
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        ActionForward forward = null;
        if (StringUtils.isNullOrEmpty(auditForm.getAuditObj().getAuditNumber())) {
            forward = saveAndSubmit(mapping, form, request, response);
        } else {
            forward = updateAction(mapping, form, request, response);
        }
        if (forward.getName().equalsIgnoreCase(MCASConstants.SUCCESS)) {
            addRequiredParamsForAddAttachment(auditForm.getAuditObj().getAuditID(),
                    auditForm.getAuditObj().getAuditNumber(), request);
            return mapping.findForward(MCASConstants.FORWARD_MAPPING_ADD_ATTACHMENT_PG);
        }
        return forward;
    }

    private void actionDeleteFinding(HttpServletRequest request, AuditForm auditForm, User user, String displayTab) throws
            Exception {
        String auditId = auditForm.getAuditObj().getAuditID();
        String findingId = getActionKey(request);
        if (auditFindingNotNull(auditId, findingId)) {
            auditService.deleteAuditFinding(auditId, findingId);
            AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
            FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(displayTab);
            processor.removeFinding(auditForm, findingId);
        }
        int auditObjectBusinessId = auditForm.getAuditObj().getBusinessId();
        request.setAttribute(BUSINESS_ID, auditObjectBusinessId);
        boolean canViewSaveUpdateControls = actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_CREATE_CAR);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        setFunctionDropdown(request, auditForm);
    }

    private void actionReset(HttpServletRequest request, AuditForm auditForm, User user) throws
            Exception {
        boolean canViewSaveUpdateControls = actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_NEW);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        if (auditForm.getAuditObj() != null) {
            AuditObject audit = new AuditObject();
            HttpSession session = request.getSession();
            auditForm.setDisplayCarTable2(false);
            auditForm.setDisplayParTable2(false);
            functionalAreaService.setCheckboxGroupsForObject(user.getBusinessId(), false, "A", audit, null, user.getLocale(),
                    user.getPermissionsMap(), "");
            auditForm.setAuditObj(audit);
            request.setAttribute(BUSINESS_ID, user.getBusinessId());
            session.setAttribute(BUSINESS_ID, "" + user.getBusinessId());
        }//End of Reset action.
    }


    private void actionCancelFinding(HttpServletRequest request, AuditForm auditForm, User user) throws
            Exception {
        boolean canViewSaveUpdateControls = actionHelper
                .isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_ADD_FINDING_CANCEL);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        //Set the Business ID
        //request.setAttribute("BUSINESS_ID",user.getBusinessId());
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
        setCurrentTab(request, auditForm);
        setFunctionDropdown(request, auditForm);
    }

    private void setCurrentTab(HttpServletRequest request, AuditForm auditForm) {
        final String tab = request.getParameter(CURRENT_TAB);
        AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
        FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(tab);
        processor.setDisplayTabInAuditForm(auditForm);
    }

    private void actionViewFromList(HttpServletRequest request, AuditForm auditForm, User user) throws
            Exception {
        int currentBusinessId = -1;
        int auditObjectBusinessId = -1;
        boolean canViewSaveUpdateControls = actionHelper.isSaveUpdateControlsVisible(user, AuditConstants.AUDIT_EDIT);
        request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, canViewSaveUpdateControls);
        String auditNo = getActionKey(request);
        logger.info("AuditNo (for View Request):: " + auditNo);
        AuditObject auditViewObj = auditService.getAuditFromList(auditNo, user.getLocale());
        request.getSession().setAttribute(AuditAction.BUSINESS_ID, "" + auditViewObj.getBusinessId());
        auditObjectBusinessId = auditViewObj.getBusinessId();
        //Edit Action.
        //Audit Areas are to be Displayed based on the
        //User's Business Preference
        if (request.getParameter(CparConstants.FROM_CPAR) != null) {
            //If the user comes back from CAR/PAR back to Audit page, display the controls
            //If the user comes back from Attachment page , display the controls
            currentBusinessId = user.getBusinessId();
            if (auditObjectBusinessId != currentBusinessId) {
                request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, MCASConstants.FALSE);
            } else {
                request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, MCASConstants.TRUE);
            }

        } else if (request.getAttribute(MCASConstants.FROM_ATTACH_FILE) != null) {//User comes back from  Attach File
            request.setAttribute(AuditConstants.CAN_VIEW_CONTROLS, MCASConstants.TRUE);

        }
        //Security Enhancement
        actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(auditViewObj.getRegion_id()),
                auditViewObj.getBusinessId(), user);
        request.setAttribute(BUSINESS_ID, auditObjectBusinessId);
        request.setAttribute(MCASConstants.PROGRAM_ID, auditViewObj.getProgram_id());
        //In case of Edit, we need to fetch the audit areas based on the user's preference
        functionalAreaService
                .setCheckboxGroupsForObject(auditObjectBusinessId, true, "A", auditViewObj, auditViewObj.getAuditID(),
                        user.getLocale(), user.getPermissionsMap(), "");
        sessionHelper.setFunctionLocation(request.getSession(), auditViewObj.getLocationCode());
        sessionHelper.setRegionRelatedLocation(request.getSession(), auditViewObj.getRegion_id());
        setRegionList(request, user.getUser_id(), auditObjectBusinessId, user.getLocale());
        auditForm.setAuditObj(auditViewObj);
        auditForm.validateCparFindingMap();
        auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayParTable2(false);
        auditForm.setDisplayCiTable2(false);
    }

    /**
     * Method to create a re-set finding Object
     *
     * @param auditForm
     */
    private void createNewFindingObject(AuditForm auditForm) {
        FindingObject newEditObj = new FindingObject();
        newEditObj.setCparID("");
        newEditObj.setControlNumber("");
        newEditObj.setFindingDesc("");
        newEditObj.setFindingID("-1");
        auditForm.getAuditObj().setEditFindingObj(newEditObj);
    }

    private boolean auditFindingNotNull(String auditId, String findingId) {
        return !StringUtils.isNullOrEmpty(auditId) && !StringUtils.isNullOrEmpty(findingId);
    }

    private void setFunctionDropdown(HttpServletRequest request, AuditForm auditForm) {
        String locationCode = auditForm.getAuditObj().getLocationCode();
        sessionHelper.setFunctionLocation(request.getSession(), locationCode);
    }

    void setLocationsBasedOnApplication(HttpServletRequest request, String regionId) {
        try {
            request.getSession().setAttribute(AuditConstants.AUDIT_FILTER_OBJ_REGION, regionId);
            List<ApplicationAuditProcessor> applicationAuditProcessors = getApplicationAuditProcessor(
                    (String) request.getSession().getAttribute(MCASConstants.APPLICATION_NAME));
            for (ApplicationAuditProcessor processor : applicationAuditProcessors) {
                processor.setAuditDefaultValues(request);
            }
            request.getSession().setAttribute(AuditConstants.AUDIT_FILTER_OBJ_REGION, null);
        } catch (Exception ex) {
            MCASLogUtil.logError("AuditAction: Error getting the Location-List: ", ex);
        }
    }

    private void filterLookupsBasedOnUserRegion(AuditObject auditObj, User user, HttpServletRequest request) throws
            Exception {
        MCASLookupFilterUtil lookupUtil = new MCASLookupFilterUtil();
        lookupUtil.filterLocationLookup(auditObj.getLocationCode(), MCASConstants.HELPER_VAR_USER_IN_AUDIT_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_AUDIT_LOCATION, user, request, auditObj.getBusinessId(),
                ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST);
        lookupUtil.filterRegionLookup(auditObj.getRegion_id(), MCASConstants.HELPER_VAR_USER_IN_AUDIT_REGION,
                MCASConstants.HELPER_VAR_VIEWABLE_AUDIT_REGION, user, request,
                ActionHelperConstants.REGION_LIST_FOR_NEW_COMPLAINTS);


    }

    private void addRequiredParamsForAddAttachment(String auditID, String auditNumber, HttpServletRequest request) {
        request.setAttribute(MCASConstants.REQUEST_VAR_ENTITY_ID, auditID);
        request.setAttribute(MCASConstants.HELPER_VAR_ENTITY_NUMBER, auditNumber);
        request.getSession()
                .setAttribute(MCASConstants.HELPER_VAR_ENTITY_TYPE, MCASConstants.STRATEGY_MAP_KEY_AUDIT_ENTITY);
    }

    //**CreateCar Action()...
    ActionForward createCPARAction(
            String auditFindingID,
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response,
            int type) {
        AuditForm auditForm = (AuditForm) form;
        AuditObject auditObj = auditForm.getAuditObj();
        Cpar cparFindingObj = new Cpar();
        cparFindingObj.setRegion(auditObj.getRegion_id());
        cparFindingObj.setFiling_location(auditObj.getLocationCode());
        cparFindingObj.setResponsible_location(auditObj.getLocationCode());
        cparFindingObj.setReport_date(auditObj.getAuditDate());
        cparFindingObj.setType(type);
        User user = (User) request.getSession().getAttribute(User.USER);
        request.getSession().setAttribute(MCASConstants.DEPARTMENT_AFFECTED_LIST, new ActionHelper().getDepartmentAffectedList(user.getLocale(), user.getBusinessId()));
        if (request.getAttribute(CparConstants.IS_CAR_FLAG).equals(MCASConstants.TRUE)) {
            cparFindingObj.setInvestigation_findings
                    (auditObj.getFindingCarMap().get(auditFindingID).getFindingDesc());
        }

        else if(type==MCASConstants.MCAS_CI_TYPE){
              cparFindingObj.setInvestigation_findings
                    (auditObj.getFindingCiMap().get(auditFindingID).getFindingDesc());
        }

        else {
            cparFindingObj.setInvestigation_findings
                    (auditObj.getFindingParMap().get(auditFindingID).getFindingDesc());
        }

        cparFindingObj.setInitiated_by(auditObj.getAuditor());
        cparFindingObj.setAudit_number(auditObj.getAuditNumber());
        cparFindingObj.setAudit_finding_id(auditFindingID);
        cparFindingObj.setAudit_id(auditObj.getAuditID());
        cparFindingObj.setGenerator(CparConstants.CPAR_INTERNAL_AUDIT_GENERATOR);
        if (!StringUtils.isNullOrEmpty(request.getParameter(AuditConstants.AUDIT_OBJ_LOCATION_CODE))) {
            cparFindingObj.setFunctionId(request.getParameter(AuditConstants.AUDIT_OBJ_LOCATION_CODE));
        }

        request.setAttribute(CparConstants.CPAR_FINDING_OBJ, cparFindingObj);
        request.setAttribute(CparConstants.CREATE_CAR, MCASConstants.TRUE);
        request.setAttribute(CparConstants.GENERATOR, CparConstants.AUDIT);

//    logger.info(
//        "START : Creating CAR/PAR from Audits****User ID****:" + cparFindingObj.getRow_user_id() +
//            ":****Business ID****:" + cparFindingObj.getBusinessId() +
//            ":****User Role****:" + ((User) request.getSession().getAttribute(User.USER)).getPermissionsMap() +
//            ":****Method****:" + getClass() + "createCPARAction()" +
//            ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//            ":****Viewable Region List****:" +
//            request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION) +
//            ":****Region ID in CPAR****:" + request.getParameter(ComplaintConstants.COMPLAINT_FORM_ENTRY_REGION));

        request.setAttribute(AuditAction.BUSINESS_ID, auditObj.getBusinessId());

        return mapping.findForward(CparConstants.FORWARD_SUCCESS_CPAR);

    }


    public ActionForward updateAction(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        AuditForm auditForm = (AuditForm) form;
        final String AUDIT_SOURCE_TYPE = "A";
        User user = (User) request.getSession().getAttribute(User.USER);
        AuditObject auditObj = auditForm.getAuditObj();
        request.setAttribute(BUSINESS_ID, user.getBusinessId());
        if (auditForm.getAuditObj() != null) {
            if (!doSubmitValidation(auditObj, request)) {
                return mapping.findForward(MCASConstants.FALIURE);
            }
        }
        try {
            auditObj.setRowUserID(user.getUser_id());

            CheckboxItemServiceImpl.getSelectedCheckboxItems(auditObj, (Map<String, String[]>) request.getParameterMap(),
                    AuditConstants.AUDIT_OBJ_AUDIT_AREA_LIST);

            auditService.updateAudit(auditObj);
            auditForm.setRecordSavedMsg(true);
            sessionHelper.setFunctionLocation(request.getSession(), auditObj.getLocationCode());
            functionalAreaService.setCheckboxGroupsForObject(user.getBusinessId(), true, "A", auditObj, auditObj.getAuditID(),
                    user.getLocale(), user.getPermissionsMap(),"" );
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return mapping.findForward(MCASConstants.FALIURE);
        }

        return mapping.findForward(MCASConstants.SUCCESS);
    }


    private String insertFinding(
            AuditObject auditObj,
            HttpServletRequest request
    ) {
        ActionErrors errors = new ActionErrors();
        final String currentTab = request.getParameter("displayTab");//CURRENT_TAB);

        User user = (User) request.getSession().getAttribute(User.USER);


        Map<String, String> errorMap = new HashMap<String, String>();
        String resultString = new AuditRequestHelper()
                .insertFinding(user.getUser_id(), auditObj, currentTab, errorMap, auditService);
        if (MCASConstants.FALIURE.equalsIgnoreCase(resultString)) {
            for (String key : errorMap.keySet()) {
                errors.add(key, new ActionMessage(errorMap.get(key)));
            }
        }
        return resultString;
    }

    private void setCurrentDisplayTabAndTable(String currentTab, AuditForm auditForm) {

        AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
        FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(currentTab);
        processor.setDisplayTabAndTableInAuditForm(auditForm);
    }

    ActionForward updateFinding(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

        AuditForm auditForm = (AuditForm) form;

        AuditObject auditObj = auditForm.getAuditObj();

        ActionMessages errors = new ActionMessages();

        if (StringUtils.isNullOrEmpty(auditObj.getEditFindingObj().getFindingDesc())) {
            errors.add(AuditConstants.ERROR_FINDING_DESC_EMPTY, new ActionMessage("errors.mcas.audit.FindingDesc.empty"));
        }

        final String currentTab = request.getParameter(CURRENT_TAB);

        setCurrentDisplayTabAndTable(currentTab, auditForm);
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            return mapping.findForward(MCASConstants.FALIURE);
        }

        try {
            //**Imp Step2: Set the row-user-id...
            User user = (User) request.getSession().getAttribute(User.USER);
            auditObj.getEditFindingObj().setRowUserID(user.getUser_id());
            auditService.updateFinding(auditObj.getEditFindingObj());

            AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
            FindingTypeProcessor processor = auditFindingTypeFactory.getFindingTypeProcessor(currentTab);
            processor.addFinding(auditForm, auditObj);

            return mapping.findForward(MCASConstants.SUCCESS);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return mapping.findForward(MCASConstants.FALIURE);
        }

    }

    List<ApplicationAuditProcessor> getApplicationAuditProcessor(String applicationName) {
        return actionHelper.getApplicationAuditProcessors(applicationName);
    }

    public ActionForward saveAndSubmit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        AuditForm auditForm = (AuditForm) form;

        AuditObject auditObj = new AuditObject();
        User user = (User) request.getSession().getAttribute(User.USER);

        if (auditForm.getAuditObj() != null) {
            auditObj = auditForm.getAuditObj();
//      logger.info("START : If Audit Object Exists ****User ID****:" + auditObj.getRowUserID() +
//          ":****Business ID****:" + auditObj.getBusinessId() +
//          ":****User Role****:" + ((User) request.getSession().getAttribute("user")).getPermissionsMap() +
//          ":****Method****:" + getClass() + "saveAndSubmit()" +
//          ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//          ":****Viewable Region List****:" +
//          request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION) +
//          ":****Region ID in CPAR****:" + auditObj.getRegion_id());


            //Change for Application Specific things
            List<ApplicationAuditProcessor> applicationAuditProcessors = getApplicationAuditProcessor(
                    (String) request.getSession().getAttribute(MCASConstants.APPLICATION_NAME));
            for (ApplicationAuditProcessor processor : applicationAuditProcessors) {
                processor.processAudit(auditObj);
            }

            if (!doSubmitValidation(auditObj, request)) {
                return mapping.findForward(MCASConstants.FALIURE);
            }

        } else {
            auditObj.setCreatedBy(user.getUser_id());
        }

        try {
            //**Imp Step2: Set the row-user-id...

            auditObj.setRowUserID(user.getUser_id());

            //SBFAS allows the user to change the business ID
            if (!MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"))) {
                auditObj.setBusinessId(user.getBusinessId());
            }

            String autoAuditNumber = "";
            String auditID = "";
            //Before Submitting the Audits
            //Prepare a list of Audit Areas selected.
            CheckboxItemServiceImpl
                    .getSelectedCheckboxItems(auditObj, request.getParameterMap(), AuditConstants.AUDIT_OBJ_AUDIT_AREA_LIST);
//      logger.info("START : New Audit Object ****User ID****:" + auditObj.getRowUserID() +
//          ":****Business ID****:" + auditObj.getBusinessId() +
//          ":****User Role****:" + ((User) request.getSession().getAttribute("user")).getPermissionsMap() +
//          ":****Method****:" + getClass() + "saveAndSubmit()" +
//          ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//          ":****Viewable Region List****:" +
//          request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION) +
//          ":****Region ID in CPAR****:" + auditObj.getRegion_id());

            String appName = request.getSession().getAttribute("APPLICATION_NAME").toString();
            String returnStr = auditService.insertAudit(auditObj,appName);
            StringTokenizer st = new StringTokenizer(returnStr, ";");
            for (int i = 0; i < 2; i++) {
                if (i == 0) {
                    autoAuditNumber = st.nextToken();
                }
                if (i == 1) {
                    auditID = st.nextToken();
                }
            }
            //**Set the new auto-generated-audit-number and audit_id...
            auditForm.getAuditObj().setAuditNumber(autoAuditNumber);
            auditForm.getAuditObj().setAuditID(auditID);

            //**Some Form settings...
            auditForm.setRecordSavedMsg(true);
            //prevOperation = "submit";

            String s = auditObj.getLocationCode();
//      System.out.println("After inserting audit:s = " + s);
            sessionHelper.setFunctionLocation(request.getSession(), s);

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return mapping.findForward(MCASConstants.FALIURE);
        }
        //**************************************************************

        return mapping.findForward(MCASConstants.SUCCESS);
    }


    /**
     * Validations during main submit
     *
     * @param auditObj
     * @param request
     * @return String
     */
    boolean doSubmitValidation(AuditObject auditObj, HttpServletRequest request) {
        McasValidator validator = new McasValidator();
        ActionMessages errors = new ActionMessages();
        validator.validateAudit(auditObj, request, errors);
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            return false;
        }
        return true;

    }

    /**
     * To fill the Location-List in the combo-box
     *
     * @param request
     */
    void setLocationList(HttpServletRequest request) {

        //**To get the Location-List in the combo-box.......................
        try {
            String regionId = request.getParameter(AuditConstants.AUDIT_ENTRY_REGION);
            setLocationsBasedOnApplication(request, regionId);
        } catch (Exception ex) {
            MCASLogUtil.logError("Audit Action: Error getting the Location-List: ", ex);
        }
        //********************************************************************
    }

    void setRegionList(HttpServletRequest request, String userId, int businessId, String locale) {
        request.setAttribute(ActionHelperConstants.REGION_LIST,
                new RegionServiceImpl().getRegionList(userId, businessId, locale));
    }

    void setFunctionList(HttpServletRequest request) {
        sessionHelper.setEmptyFunctionList(request.getSession());
    }

    void setAuditTypeMap(HttpServletRequest request) {
        sessionHelper.setAuditTypeMap(request.getSession());
    }

    /**
     * Gets key for the action-button clicked...
     *
     * @param request
     * @return String
     */

    String getActionKey(HttpServletRequest request) {
        return request.getParameter(RECORD_ID);
    }

    private void performGeneralPostProcessing(HttpServletRequest request, AuditForm auditForm, User user) throws
            Exception {
        setLocationsBasedOnApplication(request, auditForm.getAuditObj().getRegion_id());
        filterLookupsBasedOnUserRegion(auditForm.getAuditObj(), user, request);
        setReadOnlyFlag(request.getSession(), user);
    }
}
