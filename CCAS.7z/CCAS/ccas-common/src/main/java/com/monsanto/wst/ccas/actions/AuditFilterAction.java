//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.AuditFilterForm;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exportTool.ExportClass;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.ExportBean;
import com.monsanto.wst.ccas.taglib.reportTag.ReportTag;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 06-20-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:action path="/auditFilter" name="auditFilterForm" scope="request"
 */
public class AuditFilterAction extends DispatchAction {

    private static final Category logger = Category.getInstance(AuditFilterAction.class.getName());
    private final CheckboxItemService functionalAreaService;
    private final CheckboxItemDao functionalAreaDAO;
    private final DataSource dataSource;
    private final BusinessService businessService;
    private final IActionHelper actionHelper;

    public AuditFilterAction() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionalAreaDAO = new FunctionalAreaDaoImpl(dataSource);
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        businessService = new BusinessServiceImpl();
        actionHelper = new ActionHelper();
    }

    public AuditFilterAction(CheckboxItemService functionalAreaService, CheckboxItemDao functionalAreaDAO, DataSource dataSource,
                             BusinessService businessService, IActionHelper actionHelper) {
        this.functionalAreaService = functionalAreaService;
        this.dataSource = dataSource;
        this.functionalAreaDAO = functionalAreaDAO;
        this.businessService = businessService;
        this.actionHelper = actionHelper;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        AuditFilterForm auditFilterForm = (AuditFilterForm) form;

        try {
            User user = (User) request.getSession().getAttribute(User.USER);
            int businessId = getUserBusinessId(user);
            actionHelper.setApplicationInfoMap(request, businessId, getServlet());
            getAuditFormDefaults(request);
            setBusinessRelatedFunctionalAreas(auditFilterForm, businessId, user.getLocale(), user.getPermissionsMap());
            request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Error getting location/region list.", ex);
        }

        return mapping.findForward("success");
    }

    void setBusinessRelatedFunctionalAreas(AuditFilterForm auditFilterForm, int businessId, String locale, Map<String, Boolean> roles) {
        functionalAreaService.setCheckboxGroupsForObject(businessId, false, "A", auditFilterForm.getAuditFilter(), null, locale, roles,"" );
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }


    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        AuditFilterForm auditFilterForm = (AuditFilterForm) form;

        //**1. Call the getCparReportList() Service/DAO to get HashMap of Data (hash)
        Map<String, RowBean> hash = new HashMap<String, RowBean>();
        String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        try {
            setBusinessRelatedFunctionalAreas(auditFilterForm, businessId, user.getLocale(), user.getPermissionsMap());
            AuditService as = (AuditService) ServiceLocator.locateService(AuditService.class);
            hash = as.getAuditReport(auditFilterForm.getAuditFilter(), businessId, request.getParameterMap(), applicationName, user.getLocale());
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

        //**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the cparFilter FormBean.
        auditFilterForm.setHash(hash);

        String file = "";
        InputStream xmlIn = null;
        try {
            if (businessId == MCASConstants.BUSINESS_ID_ROW_CROP)
                file = McasProperties.getMcasProperties().getString("audit.reportStructure");
            else if (businessId == MCASConstants.BUSINESS_ID_VEGETABLE&&!applicationName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_SBFAS))
                file = McasProperties.getMcasProperties().getString("audit.reportStructure2");
            else{
                file = McasProperties.getMcasProperties().getString("audit.reportStructure");
            }
            if(applicationName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_SBFAS)){
                file = McasProperties.getMcasProperties().getString("audit.reportStructure");
            }
            ClassLoader classLoader = CparFilterAction.class.getClassLoader();
            xmlIn = classLoader.getResourceAsStream(file);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        auditFilterForm.setXmlIn(xmlIn);

        auditFilterForm.setSortBy("col1");
        auditFilterForm.setSortOrder("asc");

        return mapping.findForward("success");
    }

    /**
     * Method export
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward export(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

//        logger.info("Export to Excel called...");

        //**The Export Functionality...

        ServletOutputStream sos = null;
        BufferedOutputStream bos = null;

        try {

            ExportBean exportBean = ReportTag.getExportData();

            String fileName = exportBean.getExcelFileName();
            String sheetName = exportBean.getExcelSheetName();

            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "filename=" + fileName);

            sos = response.getOutputStream();
            bos = new BufferedOutputStream(sos);

            ExportClass export2Excel = new ExportClass();

            //**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector...
            export2Excel.setSheetName(sheetName);
            export2Excel.setTotalFields(exportBean.getTotalFields());
            export2Excel.setColHeader(exportBean.getExportColHeader());
            export2Excel.setVector(exportBean.getExportDataVector());

            export2Excel.setBos(bos);

            export2Excel.exportExcel();

            bos = export2Excel.getBos();

            bos.flush();
        }
        catch (Exception ex) {
            MCASLogUtil.logError("-> Error exporting Audit Report.", ex);
        }
        finally {
            MCASResourceUtil.closeResource(bos);
            MCASResourceUtil.closeResource(sos);
        }

//        logger.info("-> Excel file created.");

        return mapping.findForward("success");
    }

    /**
     * List/Combo Box Filling method...
     *
     * @param request
     * @throws Exception
     */
    private void getAuditFormDefaults(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        session.setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, null);
        session.setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, null);
        session.setAttribute(ActionHelperConstants.CPAR_STATUS_LIST, null);
        if (session.getAttribute(ActionHelperConstants.LOCATION_LIST) == null)
            session.setAttribute(ActionHelperConstants.LOCATION_LIST, actionHelper.getLocationList(businessId, user.getLocale()));
        String userId = user.getUser_id();
        session.setAttribute(ActionHelperConstants.REGION_LIST, new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale()));
        SessionHelper sessionHelper = new SessionHelper();
        sessionHelper.setEmptyFunctionList(request.getSession());
    }
}
