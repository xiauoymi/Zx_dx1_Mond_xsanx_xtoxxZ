//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;


import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.AuditListForm;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.model.AuditListObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MyEclipse Struts
 * Creation date: 04-27-2005
 * <p/>
 * XDoclet definition:
 *
 * @struts:action path="/auditList" name="auditListForm" scope="request"
 */
public class AuditListAction extends DispatchAction {

    private static final Category logger = Category.getInstance(AuditListAction.class.getName());

    private String sortCriteria;
    private String sortOrder;
    private final AuditService auditService;
    private SessionHelper sessionHelper;
    protected ActionHelper actionHelper;
    private CheckboxItemService functionalAreaService;
    private CheckboxItemDao functionalAreaDAO;
    private DataSource dataSource;

    public AuditListAction() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionalAreaDAO = new FunctionalAreaDaoImpl(dataSource);
        auditService = new AuditServiceImpl();
        sessionHelper = new SessionHelper();
        actionHelper = new ActionHelper();
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
    }

    public AuditListAction(AuditService auditService) {
        this.auditService = auditService;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward auditListDisplay(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        AuditListForm auditListForm = (AuditListForm) form;

        //*****LocationList Filling...
        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        setLocationRegionList(request, auditListForm);
        sessionHelper.setEmptyFunctionList(session);
        session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        int businessId = getUserBusinessPreference(request);
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        if (auditListForm.getAuditFilterObj() != null) {
            if (!StringUtils.isNullOrEmpty(auditListForm.getAuditFilterObj().getLocationCode())) {
                sessionHelper.setFunctionLocation(session, auditListForm.getAuditFilterObj().getLocationCode());
            }
        }

        return mapping.findForward("success");
    }

    /**
     * Method sort
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward sort(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        AuditListForm auditListForm = (AuditListForm) form;

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        setLocationRegionList(request, auditListForm);
        session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        getSortValues(request);
        return mapping.findForward("success");
    }

    public ActionForward auditListReset(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        AuditListForm auditListForm = (AuditListForm) form;
        setLocationRegionList(request, auditListForm);
        session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        auditListForm.setAuditFilterObj(new AuditListObject());
        auditListForm.setAuditMap(new HashMap());
        sessionHelper.setEmptyFunctionList(session);
        sessionHelper.setAuditTypeMap(session);
        int businessId = getUserBusinessPreference(request);
        setBusinessRelatedFunctionalAreas(auditListForm, businessId, false, user.getLocale(), user.getPermissionsMap());
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        if (auditListForm.getAuditFilterObj() != null) {
            if (!StringUtils.isNullOrEmpty(auditListForm.getAuditFilterObj().getLocationCode())) {
                sessionHelper.setFunctionLocation(session, auditListForm.getAuditFilterObj().getLocationCode());
            }
        }

        //**Reset sort-order
        resetSortOrder(request);

        return mapping.findForward("success");
    }

    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward auditListSubmit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        AuditListForm auditListForm = (AuditListForm) form;
        String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        String selectedPage = request.getParameter("selectedPage");
        if (request.getParameter("pagination").equals("true")) {
            sortCriteria = request.getParameter("sortCriteria");
            sortOrder = request.getParameter("sortOrder");
            request.getSession().setAttribute("lastAuditSortCriteria", sortCriteria);
            request.getSession().setAttribute("lastAuditSortOrder", sortOrder);
        } else {
            getSortValues(request);
        }
        if (selectedPage != null) {
            request.getSession().setAttribute("selectedPage", selectedPage);
        } else {
            request.getSession().setAttribute("selectedPage", "1");
        }
        Map<String, Object> auditList = null;
        HttpSession session = request.getSession();
        String pageNumberString = request.getParameter("pageNumber");
        if (!StringUtils.isNullOrEmpty(pageNumberString) && request.getParameter("reset").equals("false")) {
            int pageNumber = Integer.parseInt(pageNumberString);
            int userBusinessPreferenceId = getUserBusinessPreference(request);
            auditList = getAuditList(request, auditListForm, applicationName, userBusinessPreferenceId);
            request.setAttribute(AuditAction.BUSINESS_ID, userBusinessPreferenceId);
            reloadDepartmentProcess(request, auditListForm);
            if (request.getParameter("getMax").equals("true")) {
                session.setAttribute("pageNumber", "1");
            } else {
                session.setAttribute("pageNumber", pageNumberString);
                if (pageNumber < 11 && pageNumber > 0) {
                    session.setAttribute("pageNumber", "1");
                }
            }
        }
        performPostProcessing(auditList, request);
        auditListForm.setAuditMap(null);
        if ((auditList != null) && auditList.size() > 0) {
            Object o = auditList.get("maxRows");
            float pages = Float.parseFloat(o.toString());
            auditList.remove("maxRows");
            if (auditList.size() > 0 && pages > 0) {
                auditListForm.setAuditMap(auditList);
                session.setAttribute("pages", pages / 10);
            }
        }

        User user = (User) session.getAttribute(User.USER);
        setLocationRegionList(request, auditListForm);
        session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));

        if (auditListForm.getAuditFilterObj() != null) {
            if (!StringUtils.isNullOrEmpty(auditListForm.getAuditFilterObj().getLocationCode())) {
                sessionHelper.setFunctionLocation(request.getSession(), auditListForm.getAuditFilterObj().getLocationCode());
            }
        }

        return (mapping.findForward("success"));

    }

    private void reloadDepartmentProcess(HttpServletRequest request, AuditListForm auditListForm) {
        List<SelectedIndex> selectedDepartmentProcess = new AuditRequestHelper().getCheckedIndexes(request.getParameterMap(), "auditFilterObj.functionalAreaList");
        auditListForm.retainSelectedOrChangedDepartmentProcess(selectedDepartmentProcess);
    }

    private void performPostProcessing(Map<String, Object> auditMap, HttpServletRequest request) throws DAOException {
        List<ApplicationAuditProcessor> applicationAuditProcessors = getApplicationAuditProcessor((String) request.getSession().getAttribute("APPLICATION_NAME"));
        for (ApplicationAuditProcessor processor : applicationAuditProcessors) {
            processor.processAuditCparRelation(auditMap);
        }
    }

    protected void setBusinessRelatedFunctionalAreas(AuditListForm auditListForm, int businessId, boolean edit, String locale, Map<String, Boolean> roles) {
        functionalAreaService.setCheckboxGroupsForObject(businessId, false, "A", auditListForm.getAuditFilterObj(), null, locale, roles,"" );
    }

    protected Map<String, Object> getAuditList(HttpServletRequest request, AuditListForm af, String applicationName, int userBusinessPreferenceId) throws ServiceException {
        return auditService.getAuditList(af.getAuditFilterObj(), request.getParameter("pageNumber"),
                Boolean.getBoolean(request.getParameter("getMax")), sortCriteria,
                sortOrder,
                userBusinessPreferenceId,
                applicationName, request.getParameterMap());
    }

    List<ApplicationAuditProcessor> getApplicationAuditProcessor(String applicationName) {
        return new ActionHelper().getApplicationAuditProcessors(applicationName);
    }

    /**
     * To fill the Location-List in the combo-box
     *
     * @param request
     * @param auditListForm
     */
    void setLocationRegionList(HttpServletRequest request, AuditListForm auditListForm) {

        //**To get the Location-List and Region-List in the combo-box.......................
        try {
            User user = (User) request.getSession().getAttribute(User.USER);
            int userBusinessPreferenceId = getUserBusinessPreference(request);
            //setLocationList(request, userBusinessPreferenceId);
            setRegionList(request, user, userBusinessPreferenceId);

            String regionId = request.getParameter(AuditConstants.AUDIT_FILTER_OBJ_REGION);
            if (StringUtils.isNullOrEmpty(regionId)) {
                regionId = auditListForm.getAuditFilterObj().getRegion();
            }
            request.getSession().setAttribute(AuditConstants.AUDIT_FILTER_OBJ_REGION, regionId);

            List<ApplicationAuditProcessor> applicationAuditProcessors = getApplicationAuditProcessor((String) request.getSession().getAttribute("APPLICATION_NAME"));
            for (ApplicationAuditProcessor processor : applicationAuditProcessors) {
                processor.setAuditDefaultValues(request);
            }
            request.getSession().setAttribute(AuditConstants.AUDIT_FILTER_OBJ_REGION, null);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Error getting the Location-List: ", ex);
        }
        //********************************************************************
    }

    protected int getUserBusinessPreference(HttpServletRequest request) throws Exception {
        User user = (User) request.getSession().getAttribute(User.USER);
        return new ActionHelper().getUserBusinessPreference(user);
    }

    protected void setRegionList(HttpServletRequest request, User user, int userBusinessPreferenceId) throws Exception {
        request.getSession().setAttribute(ActionHelperConstants.ALL_REGION_LIST, new ActionHelper().getRegionsForSearch(user.getUser_id(), userBusinessPreferenceId, false, user.getLocale()));
    }

    protected void setLocationList(HttpServletRequest request, int userBusinessPreferenceId) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        session.setAttribute(ActionHelperConstants.LOCATION_LIST, new ActionHelper().getLocationList(userBusinessPreferenceId, user.getLocale()));
    }

    /**
     * To get the sortCriteria and determine the sortOrder.
     *
     * @param request
     */
    private void getSortValues(HttpServletRequest request) {
//    System.out.println("Enter sort");
        sortOrder = "asc";
        sortCriteria = request.getParameter("sortCriteria");

        String lastSortCriteria = request.getSession().getAttribute("lastAuditSortCriteria") + "";
        if (lastSortCriteria == null) {
            sortOrder = "asc";
        } else {    // => Not_Null
            if (sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
                sortOrder = request.getSession().getAttribute("lastAuditSortOrder") + "";
                if (sortOrder == null) {
                    sortOrder = "asc";
                } else {    // => Not_Null
                    if (sortOrder.equalsIgnoreCase("asc")) {
                        sortOrder = "desc";
                    } else {
                        sortOrder = "asc";
                    }
                }
            } else {
                sortOrder = "asc";
            }
        }


        request.getSession().setAttribute("lastAuditSortCriteria", sortCriteria);
        request.getSession().setAttribute("lastAuditSortOrder", sortOrder);
//    System.out.println("Exit Sort");
//		logger.info("Sort Criteria = " + sortCriteria);		
//		logger.info("Sort Order = " + sortOrder);
    }

    /**
     * To reset the sortOrder after every submit or refresh(display).
     *
     * @param request
     */
    private void resetSortOrder(HttpServletRequest request) {
        request.getSession().setAttribute("lastAuditSortOrder", "dec");
    }

    public ActionForward auditDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String forward = "deleteSuccess";
        String auditNumber = request.getParameter("auditIdToDelete");
        if (!StringUtils.isNullOrEmpty(auditNumber)) {
            auditService.deleteAudit(auditNumber);
        }
        return mapping.findForward(forward);
    }
}
