/*
 * Created on Jan 13, 2005
 */
package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.ComplaintListForm;
import com.monsanto.wst.ccas.actionForms.UploadFileForm;
import com.monsanto.wst.ccas.app.*;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.complaints.claims.ClaimDao;
import com.monsanto.wst.ccas.complaints.claims.ClaimDaoImpl;
import com.monsanto.wst.ccas.complaints.claims.ClaimsService;
import com.monsanto.wst.ccas.complaints.claims.ClaimsServiceImpl;
import com.monsanto.wst.ccas.constants.ComplaintConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.dao.*;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLookupFilterUtil;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.importdata.ComplaintDataReaderUpdaterImpl;
import com.monsanto.wst.ccas.util.MCASUtil;


import org.apache.log4j.Logger;
import org.apache.struts.action.*;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.FormFile;


import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.InputStream;
import java.net.URL;
import java.util.*;

/**
 * @author jbrahmb
 */
public class ComplaintAction extends DispatchAction {
    private static final Logger logger = Logger.getLogger(ComplaintAction.class.getName());
    private String sortCriteria;
    private String sortOrder;
    private final ComplaintService complaintService;
    private final CheckboxItemService functionalAreaService;
    private final SessionHelper sessionHelper;
    private final BusinessService businessService;
    private final ActionHelper actionHelper;
    private final DataSource source;
    private final ClaimDao claimDao;
    private final LookUpService lookUpService;
    private final SalesOfficeService salesOfficeService;
    private CheckboxItemService nonconformanceCategoryService;
    private CheckboxItemService rootCauseService;
    private final CheckboxItemDao functionalAreaDAO;
    public static final String COMPLAINT_FORM = "complaintForm";
    public static final String BUSINESS_ID = "BUSINESS_ID";

    public ComplaintAction() throws ServiceException {

        complaintService = new ComplaintServiceImpl();
        source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionalAreaDAO = new FunctionalAreaDaoImpl(source);
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        sessionHelper = new SessionHelper();
        businessService = new BusinessServiceImpl();
        actionHelper = new ActionHelper();
        claimDao = new ClaimDaoImpl();
        lookUpService = new LookUpServiceImpl();
        salesOfficeService = new SalesOfficeServiceImpl(source);
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
    }

    public ComplaintAction(DataSource src, ComplaintService complaintService,
                           CheckboxItemService functionalAreaService, SessionHelper sessionHelper,
                           BusinessService businessService,
                           ActionHelper actionHelper, ClaimDao claimDao, LookUpService lookUpService,
                           SalesOfficeService salesOfficeService,
                           CheckboxItemDao functionalAreaDAO,
                           CheckboxItemService nonconformanceService, CheckboxItemService rootCauseService) {
        this.source = src;
        this.complaintService = complaintService;
        this.functionalAreaService = functionalAreaService;
        this.sessionHelper = sessionHelper;
        this.businessService = businessService;
        this.actionHelper = actionHelper;
        this.claimDao = claimDao;
        this.lookUpService = lookUpService;
        this.salesOfficeService = salesOfficeService;
        this.functionalAreaDAO = functionalAreaDAO;
        this.nonconformanceCategoryService = nonconformanceService;
        this.rootCauseService = rootCauseService;
    }

    public ActionForward complaintMain(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {
        User user = ((User) request.getSession().getAttribute(User.USER));
        int modifiedUserBusinessPreferenceId = actionHelper.getUserBusinessPreference(user);
        //Set the Visibility of Drop down based on the user preference
        actionHelper.setApplicationInfoMap(request, modifiedUserBusinessPreferenceId, getServlet());

        HttpSession session = request.getSession();
        session.setAttribute(BUSINESS_ID, "" + user.getBusinessId());

        if (displayRegionRelatedComplaintForm(request)) {
            return (mapping.findForward(MCASConstants.SUCCESS_MESSAGE));
        }
        //Load the default values
        request.setAttribute(AuditAction.BUSINESS_ID, user.getBusinessId());
        getComplaintFormDefaults(request, modifiedUserBusinessPreferenceId, false);

        ComplaintHTMLImporter importer = new ComplaintHTMLImporter(form, request, getFunctionalAreaImporter(request));
        ComplaintListForm complaintListForm = importer.setComplaintMainDefaults();
        sessionHelper.retainDropdownValues(request, complaintListForm, user.getLocale());

        performGeneralPostProcessing(request);

        return (mapping.findForward(MCASConstants.SUCCESS_MESSAGE));
    }

    private FunctionalAreaImporter getFunctionalAreaImporter(HttpServletRequest request) {
        return new FunctionalAreaHTMLImporter(request);
    }

    protected boolean displayRegionRelatedComplaintForm(HttpServletRequest request) throws Exception {
        if (!StringUtils.isNullOrEmpty(request.getParameter("region"))) {
            getComplaintFormStateByRegion(request);
            return true;
        }
        return false;
    }


    public ActionForward complaintList(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {
        //**Add selected page to session...
        String selectedPage = request.getParameter("selectedPage");
        selectedPage = (!StringUtils.isNullOrEmpty(selectedPage)) ? selectedPage : "1";
        request.getSession().setAttribute("selectedPage", selectedPage);

        if (request.getParameter("isPaging").equals("true")) {
            sortCriteria = request.getParameter("sortCriteria");
            sortOrder = request.getParameter("sortOrder");
            request.getSession().setAttribute("lastComplaintSortCriteria", sortCriteria);
            request.getSession().setAttribute("lastComplaintSortOrder", sortOrder);
        } else {
            getSortValues(request);
        }

        Map<String, Object> complaintsMap = null;
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        int modifiedUserBusinessPreferenceId = actionHelper.getUserBusinessPreference(user);
        //Reset the States List
        session.removeAttribute(ActionHelperConstants.STATE_LIST);
        getComplaintFormDefaults(request, modifiedUserBusinessPreferenceId, false);

        ComplaintListForm cf = (ComplaintListForm) form;

        int pageNumber;
        if (!(request.getParameter("pageNumber") == null) && request.getParameter("reset").equals("false")) {
            pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
            try {
                //For Listing Complaints based on the Business
                ComplaintForCriteria complaintForCriteria = createComplaintCriteria(request, modifiedUserBusinessPreferenceId, cf);
                complaintForCriteria.setUser(user);


                if(MCASConstants.APPLICATION_NAME_MCAS.equalsIgnoreCase(request.getSession().getAttribute("APPLICATION_NAME").toString())){
                    complaintsMap = complaintService.getComplaintsList(complaintForCriteria, user.getLocale());
                }
                else{
                    complaintsMap = complaintService.getComplaintsListWOClaims(complaintForCriteria, user.getLocale());
                }



                                request.setAttribute("region", cf.getRegion());
                String locationCode = cf.getResponsible_plant_code();
                SessionHelper sessionHelper = new SessionHelper();
                sessionHelper.setFunctionLocation(session, locationCode);

            }
            catch (Exception e) {
                throw new Exception(e);
            }
            if (request.getParameter("getMax").equals("true")) {
                session.setAttribute("pageNumber", "1");
            } else {
                if (pageNumber < 11 && pageNumber > 0) {
                    session.setAttribute("pageNumber", "1");
                } else {
                    session.setAttribute("pageNumber", request.getParameter("pageNumber"));
                }
            }
        }
        if (complaintsMap != null) {
            float pages = Float.parseFloat(complaintsMap.get("maxRows").toString());
            complaintsMap.remove("maxRows");
            if (complaintsMap.size() > 0 && pages > 0) {
                cf.setComplaintsList(complaintsMap);
                session.setAttribute("pages", pages / 10);
            } else {
                cf.setComplaintsList(null);
            }
        } else {
            cf.setComplaintsList(null);
        }
        SessionHelper sessionHelper = new SessionHelper();
        sessionHelper.retainDropdownValues(request, cf, user.getLocale());
        setAppSpecificReferenceData(request, false);

        return (mapping.findForward(MCASConstants.SUCCESS_MESSAGE));
    }

    private ComplaintForCriteria createComplaintCriteria(HttpServletRequest request, int modifiedUserBusinessPreferenceId, ComplaintListForm cf) {
        ComplaintForCriteria criteria = new ComplaintForCriteria(cf.getControlNumber(), cf.getCreateDate(), cf.getInitiatedBy(),
                cf.getSalesYr(), cf.getStatus(), cf.getRegion(), cf.getClaimNumber(), cf.getReporting_location_code(),
                cf.getResponsible_plant_code(), cf.getCrop(), cf.getBatch(), cf.getState(), cf.getVariety(),
                cf.getQualityissue(), request.getParameter("pageNumber"),
                Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder,
                cf.getComplaintBusinessId(),
                cf.getFeedbackCategoryId(), cf.getComplaintTypeId(), cf.getFunctionId(), cf.getSalesOfficeCode(),
                cf.getMaterialGroupCode(), cf.getMaterialGroupPricingCode(), modifiedUserBusinessPreferenceId,
                cf.getInitialAssesmentCode(),
                cf.getComplaintLitigationCategoryCode(), cf.getToDate(), cf.getComplaintEntryTypeId(),
                cf.getCustomerName(), cf.getSapCustomerId(), cf.getInvoiceNumber(), cf.getProgramId(),
                cf.getInvoiceDate(), cf.getFrom_communication_date(), cf.getTo_communication_date(), cf.getGrowerName(),
                cf.getDealerName(), cf.getSearchText(), cf.getClosingDate(),cf.getPerson_investigating());
        criteria.setClaimStatusIndicator(cf.getClaimStatusTypeIndicator());
        return criteria;
    }

    public ActionForward complaintNcrNew(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response) throws Exception {
        return complaintNew(mapping, form, request, response);
    }

    public ActionForward complaintDeviationNew(ActionMapping mapping,
                                               ActionForm form,
                                               HttpServletRequest request,
                                               HttpServletResponse response) throws Exception {
        return complaintNew(mapping, form, request, response);
    }

    public ActionForward complaintNew(ActionMapping mapping,
                                      ActionForm form,
                                      HttpServletRequest request,
                                      HttpServletResponse response)
            throws Exception {
        ClaimsService claimsService = getClaimsService();
        String complaintId = claimsService
                .lookUpComplaintRelatedToAClaim(request.getParameter(MCASConstants.REQUEST_PARAM_CLAIM_ID));
        if (complaintId != null) {
            request.setAttribute("complaint_id", complaintId);
            return mapping.findForward("complaintEdit");
        }
        User user = (User) request.getSession().getAttribute(User.USER);
        if (displayRegionRelatedComplaintForm(request)) {
            return (mapping.findForward(MCASConstants.SUCCESS_MESSAGE));
        }
        int userBusinessId = businessService.getBusinessId(user);
        //Set the Visibility of Drop down based on the user preference
        actionHelper.setApplicationInfoMap(request, userBusinessId, getServlet());
        //clear the existing drop downs if any
        sessionHelper.clearDropDowns(request.getSession());
        getComplaintFormDefaults(request, userBusinessId, true);
        ComplaintForm cf = (ComplaintForm) form;
        ComplaintHTMLImporter importer = new ComplaintHTMLImporter(cf, request, getFunctionalAreaImporter(request));
        String forward = importer.populateNewComplaintDefaults();
        setTeamLeadDispositionList(cf.getC(), user);
        generateComplaintId(cf, complaintService);
         setCheckboxGroupsForObject(cf.getC(), user, false,request.getSession().getAttribute("APPLICATION_NAME").toString() );
        setRequestAttributes(request, user);
        cf.getC().setClaim_number(request.getParameter(MCASConstants.REQUEST_PARAM_CLAIM_ID));

        performGeneralPostProcessing(request);

        return mapping.findForward(forward);
    }

    private void setTeamLeadDispositionList(Complaint complaint, User user) {
        complaint.setDispositionListForTeamLead(complaintService.getDispositionListForTeamLead(user.getLocale()));
    }

    protected ClaimsServiceImpl getClaimsService() {
        return new ClaimsServiceImpl(claimDao, lookUpService, salesOfficeService);
    }

    private void generateComplaintId(ComplaintForm cf, ComplaintService complaintService) throws ServiceException {
        cf.getC().setComplaint_id(complaintService.getComplaintPK());
    }

    public ActionForward complaintNcrEdit(ActionMapping mapping,
                                          ActionForm form,
                                          HttpServletRequest request,
                                          HttpServletResponse response) throws Exception {
        return complaintEdit(mapping, form, request, response);
    }

    public ActionForward complaintDeviationEdit(ActionMapping mapping,
                                                ActionForm form,
                                                HttpServletRequest request,
                                                HttpServletResponse response) throws Exception {
        return complaintEdit(mapping, form, request, response);
    }

    public ActionForward complaintEdit(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response)
            throws Exception {
//        logger.info("----------complaintEdit START---------");
        String forward = "";
        Complaint c;
        ComplaintForm cf = (ComplaintForm) form;
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        cf.setC(null);
        CparService cpars = (CparService) ServiceLocator.locateService(CparService.class);
        String complaintId = getComplaintId(request);
        c = complaintService.getComplaint(complaintId);
//    c.setEntryType(request.getParameter("entryType"));
        // Set new user.
        c.setRow_user_id(user.getUser_id());
        c.setOldStatusId(c.getStatus_id());
        c.setClosingPersonId(c.getClosingPersonId() == null ? "" : c.getClosingPersonId());
        c.setClosingDate(c.getClosingDate() == null ? "" : c.getClosingDate());
        setEntryType(request, c);
        cf.setC(c);

//        logger.info("-----------Before setting Complaint Categories and Audit Areas------------");
//        logger.info(c);
        setTeamLeadDispositionList(cf.getC(), user);
        setCheckboxGroupsForObject(c, user, true, request.getSession().getAttribute("APPLICATION_NAME").toString());
//        logger.info("-----------After setting Complaint Categories and Audit Areas------------");
//        logger.info(c);
        if (request.getParameter(CparConstants.FROM_CPAR) != null) {
            //If the user comes back from CAR/PAR back to Audit page, display the controls
            //If the user comes back from Attachment page , display the controls
            if (c.getBusinessId() != businessService.getBusinessId(user)) {
                request.setAttribute("canViewControls", "false");
            } else {
                request.setAttribute("canViewControls", "true");
            }
        }
        request.setAttribute(AuditAction.BUSINESS_ID, "" + c.getBusinessId());
        request.setAttribute("regionId", c.getRegion_id());
        request.setAttribute("programId", c.getProgram_id());

        // Repopulate the states list based on the complaint region.
        session.setAttribute(ActionHelperConstants.STATE_LIST,
                actionHelper.getRegionSpecificStatesList(user.getUser_id(), c.getRegion_id(), user.getLocale()));
        String locationCode = c.getResponsible_plant_code();

        getComplaintFormDefaults(request, c.getBusinessId(), true);
        actionHelper.setApplicationInfoMap(request, c.getBusinessId(), getServlet());
        SessionHelper sessionHelper = new SessionHelper();
        //Set the Functions List
        sessionHelper.setFunctionLocation(session, locationCode);
        //Set the Region Related Locations
        if (c.getRegion_id() != null) {
            sessionHelper.setSalesOffice(session, c.getRegion_id(), user.getLocale());
        }
        //Set the Material Group Drop Down Based on the crop Selected
        if (c.getCrop_id() != null) {
            sessionHelper.setCropRelatedMaterialGroup(session, c.getCrop_id());
        }
        //Set the Material Group Pricing Drop Down Based on the material Group Selected
        if (c.getMaterialGroupCode() != -1) {
            sessionHelper.setMaterialGroupRelatedMaterialGroupPricing(session, c.getMaterialGroupCode());
        }
        Map<String, String> cparMap = new HashMap<String, String>();

        Map<String, String> carMap = cpars.findCPAR(complaintId, "Y");
        populateCparMapForDisplay(cparMap, carMap);
        Map<String, String> parMap = cpars.findCPAR(complaintId, "N");
        populateCparMapForDisplay(cparMap, parMap);

        request.setAttribute("cparMap", cparMap);
        //Make a check whether the Save /Update buttons are viewable
        if (request.getAttribute("canViewControls") == null) {
            boolean displaySaveUpdateControl = isSaveUpdateControlsVisible(user, "complaintEdit");
            request.setAttribute("canViewControls", displaySaveUpdateControl);
        }
        actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(c.getRegion_id()), c.getBusinessId(), user);
        forward = complaintService.getForward((User) request.getSession().getAttribute(User.USER));

        request.setAttribute("complaintEdit", "true");
        session.setAttribute("complaintEdit", "true");
        request.setAttribute("showCAR", "true");

        request.setAttribute("displayReset", "false");
        filterLookupsBasedOnUserRegion(c, user, request);
        displaySendEmailControl(request);
//        logger.info("-----------complaintEdit END------------");
//        logger.info(user);
        displayReleaseClaims(request, user, c);
        String redirect = forward;

        performGeneralPostProcessing(request);

        return mapping.findForward(redirect);
    }

    private void setCheckboxGroupsForObject(Complaint c, User user, boolean isEdit, String app) {
        functionalAreaService.setCheckboxGroupsForObject(user.getBusinessId(), isEdit, c.getEntryType(), c, c.getComplaint_id(), user.getLocale(), user.getPermissionsMap(),"" );
        nonconformanceCategoryService.setCheckboxGroupsForObject(user.getBusinessId(), isEdit, c.getEntryType(), c, c.getComplaint_id(), user.getLocale(), user.getPermissionsMap(),"" );
        rootCauseService.setCheckboxGroupsForObject(user.getBusinessId(), isEdit, c.getEntryType(), c, c.getComplaint_id(), user.getLocale(), user.getPermissionsMap(),app );
    }

    private void setEntryType(HttpServletRequest request, Complaint c) {
        if (request.getParameter("entryType") == null) {
            c.setEntryType(MCASConstants.ENTRY_TYPE_DEFAULT);
        } else {
            c.setEntryType(request.getParameter("entryType"));
        }

    }

    private String getComplaintId(HttpServletRequest request) {
        String complaintId = request.getParameter("complaintId");
        if (complaintId == null) {
            ClaimsService claimsService = getClaimsService();
            return claimsService.lookUpComplaintRelatedToAClaim(request.getParameter(MCASConstants.REQUEST_PARAM_CLAIM_ID));
        }
        return complaintId;
    }

    private void populateCparMapForDisplay(Map<String, String> cparMap, Map<String, String> parMap) {
        if (!parMap.isEmpty()) {
            cparMap.putAll(parMap);
        }
    }

    /**
     * Private method to check for Save/ Update visibility on Complaint Entry page
     */
    private boolean isSaveUpdateControlsVisible(User user, String methodType) throws Exception {
        return actionHelper.isSaveUpdateControlsVisible(user, methodType);
    }

    protected void filterLookupsBasedOnUserRegion(Complaint complaint, User user, HttpServletRequest request) throws
            Exception {
        MCASLookupFilterUtil lookupUtil = new MCASLookupFilterUtil();
        lookupUtil
                .filterLocationLookup(complaint.getReporting_location_code(), MCASConstants.HELPER_VAR_USER_IN_REPORTING_LOC,
                        MCASConstants.HELPER_VAR_VIEWABLE_REPORTING_LOCATION, user, request, 0,
                        ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST);
        lookupUtil
                .filterLocationLookup(complaint.getResponsible_plant_code(), MCASConstants.HELPER_VAR_USER_IN_RESPONSIBLE_LOC,
                        MCASConstants.HELPER_VAR_VIEWABLE_RESPONSIBLE_LOCATION, user, request, 0,
                        ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST);
        lookupUtil.filterRegionLookup(complaint.getRegion_id(), MCASConstants.HELPER_VAR_USER_IN_COMPLAINT_REGION,
                MCASConstants.HELPER_VAR_VIEWABLE_COMPLAINT_REGION, user, request,
                ActionHelperConstants.REGION_LIST_FOR_NEW_COMPLAINTS);
    }

    public ActionForward complaintNcrSubmit(ActionMapping mapping,
                                            ActionForm form,
                                            HttpServletRequest request,
                                            HttpServletResponse response)
            throws Exception {
//    ComplaintService service = getComplaintService();
//        logger.info("--------------complaintSubmit START------------------");
        User user = (User) request.getSession().getAttribute(User.USER);
//        logger.info(user);

        ComplaintImporter complaintImporter = new ComplaintHTMLImporter(form, request, getFunctionalAreaImporter(request));
        return submitComplaint(mapping, request, this.complaintService, user, complaintImporter,
                (String) request.getSession().getAttribute("APPLICATION_NAME"), request.getParameterMap());
    }

    public ActionForward complaintDeviationSubmit(ActionMapping mapping,
                                                  ActionForm form,
                                                  HttpServletRequest request,
                                                  HttpServletResponse response)
            throws Exception {
//    ComplaintService service = getComplaintService();
//        logger.info("--------------complaintSubmit START------------------");
        User user = (User) request.getSession().getAttribute(User.USER);
//        logger.info(user);

        ComplaintImporter complaintImporter = new ComplaintHTMLImporter(form, request, getFunctionalAreaImporter(request));
        return submitComplaint(mapping, request, this.complaintService, user, complaintImporter,
                (String) request.getSession().getAttribute("APPLICATION_NAME"), request.getParameterMap());
    }


    public ActionForward complaintSubmit(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response)
            throws Exception {
//    ComplaintService service = getComplaintService();
//        logger.info("--------------complaintSubmit START------------------");
        User user = (User) request.getSession().getAttribute(User.USER);
//        logger.info(user);


        ComplaintImporter complaintImporter = new ComplaintHTMLImporter(form, request, getFunctionalAreaImporter(request));
        return submitComplaint(mapping, request, this.complaintService, user, complaintImporter,
                (String) request.getSession().getAttribute("APPLICATION_NAME"), request.getParameterMap());
    }

    private ActionForward submitComplaint(ActionMapping mapping, HttpServletRequest request, ComplaintService service,
                                          User user, ComplaintImporter complaintImporter, String applicationName,
                                          Map<String, String[]> requestParameterMap) throws Exception {
        Complaint complaint = service.getComplaint(complaintImporter);

        String forward = service.getForward(user);
//        logger.info(complaint);

        //Pre-processing
        performGeneralPreProcessing(complaint, request);
        ActionErrors actionErrors = service.performApplicationSpecificPreProcessing(complaint,
                applicationName,
                user,
                requestParameterMap);

        if (preProcessValidateComplaint(request, complaint, actionErrors, service)) {

            setCheckboxGroupsForObject(complaint, user, true,request.getSession().getAttribute("APPLICATION_NAME").toString() );
            return mapping.findForward("failure");
        } else {
//            logger.info("----------After preProcessValidateComplaint() --------------");
//            logger.info(complaint);
            //Complaint Submit -- Main Processing
            if (complaint != null) {
                forward = insertUpdateComplaint(request, user, forward, complaint, service);
                service.getVarietyBatch(complaint.getComplaint_id(),complaint);
                boolean isAddAttachment = processAttachments(request, complaint, service);
                if (isAddAttachment) {
                    return (mapping.findForward(MCASConstants.FORWARD_MAPPING_ADD_ATTACHMENT_PG));
                }
                filterLookupsBasedOnUserRegion(complaint, user, request);
            }
            performApplicationSpecificPostProcessing(request, user, complaint, service);
//            logger.info("--------------complaintSubmit END------------------");

            performGeneralPostProcessing(request);

            if(forward.equals("successPAR") || forward.equals("successCI")){
                return (mapping.findForward(forward));                
            }

            CparService cpars = (CparService) ServiceLocator.locateService(CparService.class);

            Map<String, String> cparMap = new HashMap<String, String>();
            Map<String, String> carMap = cpars.findCPAR(complaint.getComplaint_id(), "Y");
            populateCparMapForDisplay(cparMap, carMap);
            Map<String, String> parMap = cpars.findCPAR(complaint.getComplaint_id(), "N");
            populateCparMapForDisplay(cparMap, parMap);

            request.setAttribute("cparMap", cparMap);

            return (mapping.findForward(forward));
        }
    }

    private boolean processAttachments(HttpServletRequest request, Complaint complaint, ComplaintService service) {
        if (request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
                && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true")) {
            addRequiredParamsForAddAttachment(complaint, request, service);
            return true;
        }
        return false;
    }

    private String insertUpdateComplaint(HttpServletRequest request, User user, String forward, Complaint complaint,
                                         ComplaintService service) throws Exception {
        String forwardReturnValue = forward;
        if(request.getParameter("fromComplaint") != null){
            if(request.getParameter("fromComplaint").equals(MCASConstants.TRUE)){
                request.getSession().setAttribute("complaint_id", complaint.getComplaint_id());
                //request.getSession().setAttribute("complaintEntryType", complaint.getComplaintEntryTypeIdAsString());
                request.getSession().setAttribute("entryType", (String) request.getParameter("entryType"));
            }
        }
        if (MCASConstants.TRUE.equals(request.getSession().getAttribute("complaintEdit")) ||
                MCASConstants.TRUE.equals(request.getParameter("complaintEdit"))) {
            forwardReturnValue = processComplaintEdit(request, user, forward, complaint, complaint.getSelectedFunctionalAreas(),
                    complaint.getSelectedNonconformanceCategoryList(), service, (CparService) ServiceLocator.locateService(CparService.class));
            request.setAttribute("isComplaintInsert", "false");
            request.setAttribute("complaintEdit", "true");
            if((request.getParameter("createPAR")!= null) || (request.getParameter("createCI")!= null) || (request.getParameter("createCAR") != null)){
                if((request.getParameter("createCAR") != null) && request.getParameter("iscar").equals(MCASConstants.TRUE) && request.getParameter("fromComplaint").equals(MCASConstants.TRUE)){
                    forwardReturnValue = CparConstants.FORWARD_SUCCESS_CAR;
                }else if(request.getParameter("iscar").equals(MCASConstants.FALSE) && request.getParameter("fromComplaint").equals(MCASConstants.TRUE)){
                        if(request.getParameter("createPAR")!= null){
                            forwardReturnValue = CparConstants.FORWARD_SUCCESS_PAR;
                        }else if(request.getParameter("createCI")!= null){
                            forwardReturnValue = CparConstants.FORWARD_SUCCESS_CI;
                        }
                }
            }
        } else if (request.getParameter("createCAR") == null && request.getParameter("iscar") == null) {
            processComplaintInsert(request, user, complaint, complaint.getSelectedFunctionalAreas(), complaint.getSelectedNonconformanceCategoryList(), service);
            request.setAttribute("isComplaintInsert", "true");
        }else if ((request.getParameter("createCAR") != null) && request.getParameter("iscar").equals(MCASConstants.TRUE) && request.getParameter("fromComplaint").equals(MCASConstants.TRUE)) {
            processComplaintInsert(request, user, complaint, complaint.getSelectedFunctionalAreas(), complaint.getSelectedNonconformanceCategoryList(), service);
            request.setAttribute("isComplaintInsert", "true");
            forwardReturnValue = CparConstants.FORWARD_SUCCESS_CAR;
        }else if ((request.getParameter("createPAR") != null) && request.getParameter("iscar").equals(MCASConstants.FALSE) && request.getParameter("fromComplaint").equals(MCASConstants.TRUE)) {
            processComplaintInsert(request, user, complaint, complaint.getSelectedFunctionalAreas(), complaint.getSelectedNonconformanceCategoryList(), service);
            request.setAttribute("isComplaintInsert", "true");
            forwardReturnValue = CparConstants.FORWARD_SUCCESS_PAR;
        }else if ((request.getParameter("createCI") != null) && request.getParameter("iscar").equals(MCASConstants.FALSE) && request.getParameter("fromComplaint").equals(MCASConstants.TRUE)) {
            processComplaintInsert(request, user, complaint, complaint.getSelectedFunctionalAreas(), complaint.getSelectedNonconformanceCategoryList(), service);
            request.setAttribute("isComplaintInsert", "true");
            forwardReturnValue = CparConstants.FORWARD_SUCCESS_CI;
        }
        return forwardReturnValue;
    }

    private boolean preProcessValidateComplaint(HttpServletRequest request, Complaint complaint, ActionErrors errors,
                                                ComplaintService service) throws Exception {
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            request.setAttribute("SendEmailVisible", false);
            //Complaint Categories gets changed intermittently.Temp fix.
            User user = (User) request.getSession().getAttribute(User.USER);
//            logger.info("---------preProcessValidateComplaint : before setting request variables-------------");
//            logger.info(user);
            setRequestAttributes(request, user);
//            logger.info(user);
//            logger.info("---------preProcessValidateComplaint : after setting request variables-------------");
//
//            logger.info("---------preProcessValidateComplaint : Before setting Complaint categories-------------");
//            logger.info(complaint);
            setCheckboxGroupsForObject(complaint, user, false, request.getSession().getAttribute("APPLICATION_NAME").toString());

//            logger.info("---------preProcessValidateComplaint : After setting Complaint categories-------------");
//            logger.info(complaint);
            return true;
        }
        return false;
    }

    /**
     * method to set the request attributes
     */
    protected void setRequestAttributes(HttpServletRequest request, User user) throws Exception {
        boolean displaySaveUpdateControl = isSaveUpdateControlsVisible(user, "complaintSubmit");
        request.setAttribute("canViewControls", displaySaveUpdateControl);
        request.setAttribute(AuditAction.BUSINESS_ID, String.valueOf(businessService.getBusinessId(user)));
    }

    /**
     * Perform Application Specific Post Processing. List of Post processing done currenty --Sending Email upon
     * Complaint Creation / Status change
     */
    private void performApplicationSpecificPostProcessing(HttpServletRequest request, User user, Complaint complaint,
                                                          ComplaintService service) throws Exception {
        //Method used to set the selected complaint categories after submitting and re-submitting when
        //the user is on the same page
        setCheckboxGroupsForObject(complaint, user, true,request.getSession().getAttribute("APPLICATION_NAME").toString() );
        //Make a check whether the Save /Update buttons are viewable
        setRequestAttributes(request, user);
        setComplaintDropdowns(request, complaint);
        displaySendEmailControl(request);
        displayReleaseClaims(request, user, complaint);
        boolean isComplaintInsert = "true".equals(request.getAttribute("isComplaintInsert").toString());
        if(isComplaintInsert||complaint.getStatus_id().equalsIgnoreCase(MCASConstants.SBFAS_STATUS__REF_TYPE_1_CLOSED_EFFECTIVE)){
            handleEmails(request, complaint, isComplaintInsert);
        }
    }

    private void displayReleaseClaims(HttpServletRequest request, User user, Complaint complaint) {
        ClaimsService claimsService = getClaimsService();
        request.setAttribute("DisplayClaimReleaseButton",
                claimsService.canReleaseClaim(user, complaint.isEnvironmentalClaim()));
    }

    private void handleEmails(HttpServletRequest request, Complaint complaint, boolean complaintInsert) {
        try {
            sendComplaintEmail(request, complaint, complaintInsert);
        } catch (EmailAddressRetrievalException se) {
            request.setAttribute("WARNING_MESSAGE", se.getMessage());
        }
    }

    protected void sendComplaintEmail(HttpServletRequest request, Complaint complaint, boolean complaintInsert
    ) throws EmailAddressRetrievalException {
        ApplicationSpecificProcessorFactory applicationSpecificProcessorFactory =
                new ApplicationSpecificProcessorFactoryImpl();
        String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");

        boolean condensedEmail = false;

        if (complaintInsert) {
            condensedEmail = true;
        } else {
            if (request.getParameter("SEND_CONDENSED_EMAIL") != null &&
                    request.getParameter("SEND_CONDENSED_EMAIL").equalsIgnoreCase("on")) {
                condensedEmail = true;
            }
        }
        ComplaintProcessor processor = applicationSpecificProcessorFactory.getApplicationSpecificProcessor(applicationName)
                .getComplaintProcessor();
        //todo... Ram to fix this before internationalization goes to prod
        try{
        processor.sendComplaintEmail(request, request.getParameter("printPreviewSrc"), complaint, complaintInsert,
                request.getSession().getAttribute("complaintEdit").toString(), condensedEmail);
        }
        catch (EmailAddressRetrievalException ea){
            request.setAttribute("WARNING_MESSAGE", ea.getMessage());
        }

    }

    /**
     * Method to Display Send Email button
     *
     * @param request
     */
    protected void displaySendEmailControl(HttpServletRequest request) {
        request.setAttribute("SendEmailVisible", true);
    }

    /**
     * Method to Retain values in complaint Drop downs
     *
     * @param request
     * @param complaint
     * @throws Exception
     */
    protected void setComplaintDropdowns(HttpServletRequest request, Complaint complaint) throws Exception {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        sessionHelper.setFunctionLocation(session, complaint.getResponsible_plant_code());
        //Populate the Sales Office , Material Group and Material Group Pricing after submit.
        sessionHelper.setSalesOffice(request.getSession(), complaint.getRegion_id(), user.getLocale());
        sessionHelper.setRegionRelatedLocation(request.getSession(), complaint.getRegion_id());
        sessionHelper.setCropRelatedMaterialGroup(request.getSession(), complaint.getCrop_id());
        sessionHelper.setMaterialGroupRelatedMaterialGroupPricing(request.getSession(), complaint.getMaterialGroupCode());
        sessionHelper.setRegionRelatedStates(request.getSession(), complaint.getRegion_id());
        sessionHelper
                .setProgramRelatedSubFunctionsAndLocations(request.getSession(), String.valueOf(complaint.getProgram_id()));
        sessionHelper
                .setDispositionList(request.getSession(), complaintService.getDispositionListForDescription(user.getLocale()));
    }

    /**
     * Private method to insert a complaint
     *
     * @param request
     * @param user
     * @param c
     * @param functionalAreaList
     * @param cs
     * @throws Exception
     */
    private void processComplaintInsert(HttpServletRequest request, User user, Complaint c,
                                        List<CheckboxItem> functionalAreaList, List<CheckboxItem> nonconformanceCategoryList,
                                        ComplaintService cs) {

        c.setBusinessId(businessService.getBusinessId(user));
        cs.insertComplaint(c);
        request.setAttribute("msg", "true");
        HttpSession session = request.getSession();
        session.setAttribute("complaintEdit", "true");
        request.setAttribute("showCAR", "true");
    }

    /**
     * Private method to update a complaint
     *
     * @param request
     * @param user
     * @param forward
     * @param c
     * @param functionalAreaList
     * @param cs
     * @param cpars
     * @return
     * @throws Exception
     */
    private String processComplaintEdit(HttpServletRequest request, User user, String forward, Complaint c,
                                        List<CheckboxItem> functionalAreaList, List<CheckboxItem> nonconformanceCategoryList, ComplaintService cs, CparService cpars) throws
            Exception {

        //SBFAS allows the user to change the business ID
        if (!MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"))) {
            c.setBusinessId(businessService.getBusinessId(user));
        }

        cs.updateComplaint(c);

        request.setAttribute("msg", "true");
        //Send E-mail.
        HttpSession session = request.getSession();
        session.setAttribute("complaintEdit", "true");
        request.setAttribute("showCAR", "true");
        return (createAppSpecificCpar(request, c, cpars, forward));
        //return forward;
    }

    private String createAppSpecificCpar(HttpServletRequest request, Complaint complaint, CparService cpars,
                                         String forward) {
        String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        ApplicationSpecificProcessorFactory applicationSpecificProcessorFactory =
                new ApplicationSpecificProcessorFactoryImpl();
        ComplaintProcessor processor =
                applicationSpecificProcessorFactory.getApplicationSpecificProcessor(applicationName).getComplaintProcessor();
        return processor.createCpar(request, complaint, cpars, forward);
    }

    /**
     * Private method :Add Attachment
     *
     * @param complaint
     * @param request
     * @param service
     */
    private void addRequiredParamsForAddAttachment(Complaint complaint, HttpServletRequest request,
                                                   ComplaintService service) {
        addEntityIdToRequest(request, complaint.getComplaint_id());
        addEntityTypeToSession(request);
        addComplaintTypeToSession(request, service);
        request.setAttribute("entryType", complaint.getEntryType());
    }

    /**
     * Private method to add Type of complaint to Session (AFFINA/NON_AFFINA)
     *
     * @param request
     * @param service
     */
    private void addComplaintTypeToSession(HttpServletRequest request, ComplaintService service) {
        User user = (User) request.getSession().getAttribute(User.USER);
        if (MCASConstants.SUCCESS_AFFINA_MESSAGE.equalsIgnoreCase(service.getForward(user))) {
            request.getSession().setAttribute(MCASConstants.HELPER_VAR_IS_AFFINA_COMPLAINT, "true");
        } else {
            request.getSession().setAttribute(MCASConstants.HELPER_VAR_IS_AFFINA_COMPLAINT, "false");
        }
    }

    private void addEntityIdToRequest(HttpServletRequest request, String entityId) {
        request.setAttribute(MCASConstants.REQUEST_VAR_ENTITY_ID, entityId);
    }

    private void addEntityTypeToSession(HttpServletRequest request) {
        request.getSession()
                .setAttribute(MCASConstants.HELPER_VAR_ENTITY_TYPE, MCASConstants.STRATEGY_MAP_KEY_COMPLAINT_ENTITY);
    }

    public ActionForward complaintFindBatches(ActionMapping mapping,
                                              ActionForm form,
                                              HttpServletRequest request,
                                              HttpServletResponse response) {
        String batchNumber = request.getParameter("batchNumber");
        String batchID = request.getParameter("batchID");
        Complaint c = ((ComplaintForm) form).getC();
        User user = (User) request.getSession().getAttribute(User.USER);
        Map<String, String> batches = null;
        if (!StringUtils.isNullOrEmpty(batchNumber)) {
            String batch_number_trimmed = batchNumber.trim();
            batches = complaintService
                    .findBatches(batch_number_trimmed, c.getComplaint_id(), businessService.getBusinessId(user));
        }
        String forward = complaintService.getForward(user);
        request.getSession().setAttribute(batchID, batches);
        return (mapping.findForward(forward));
    }

    /**
     * Method sort
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward sort(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

        try {
            User user = ((User) request.getSession().getAttribute(User.USER));
            int modifiedUserBusinessPreferenceId = actionHelper.getUserBusinessPreference(user);
            getComplaintFormDefaults(request, modifiedUserBusinessPreferenceId, false);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Error getting Complaint default lists.", ex);
        }
        getSortValues(request);
        return mapping.findForward(MCASConstants.SUCCESS_MESSAGE);
    }

    private void getComplaintFormStateByRegion(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) request.getSession().getAttribute(User.USER);
        String userId = user.getUser_id();
        String region = request.getParameter("region");
        session.setAttribute(ActionHelperConstants.STATE_LIST,
                actionHelper.getRegionSpecificStatesList(userId, region, user.getLocale()));
        sessionHelper.setSalesOffice(request.getSession(), region, user.getLocale());
    }

    /**
     * Method to Obtain the Defaults for complaints
     *
     * @param request
     * @param currentBusinessId
     * @param activeOnly
     * @throws Exception
     */
    protected void getComplaintFormDefaults(HttpServletRequest request, int currentBusinessId, boolean activeOnly) throws
            Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        String userId = user.getUser_id();
        String region = request.getParameter("region");

        user.setUserBusinessPreference(currentBusinessId);

        //Obtain the Regions Based on the User's Business Preference Id
        if (session.getAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST) != null) {
            session.removeAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST);
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                    actionHelper.getRegionsForSearch(userId, currentBusinessId, false, user.getLocale()));
        } else {
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                    actionHelper.getRegionsForSearch(userId, currentBusinessId, false, user.getLocale()));
        }
        //Obtain the Crops Based on the User's Business Preference Id
        if (session.getAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST) != null) {
            session.removeAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST);
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST,
                    actionHelper.getBusinessPreferenceRelatedCropList(currentBusinessId, user.getLocale()));
        } else {
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST,
                    actionHelper.getBusinessPreferenceRelatedCropList(currentBusinessId, user.getLocale()));
        }

        session.setAttribute(ActionHelperConstants.COMPLAINT_ROLE_STATUS_LIST, null);
        session.setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, null);

        //Added an if condition so that code doest break in other flows
        if (!"complaintEdit".equalsIgnoreCase(request.getParameter("method"))) {
            if (region != null) {
                session.setAttribute(ActionHelperConstants.STATE_LIST, null);
            }
        }
        if (session.getAttribute(ActionHelperConstants.CROP_LIST) == null) {
            session.setAttribute(ActionHelperConstants.CROP_LIST, actionHelper.getCropList(user.getLocale()));
        }
        session.setAttribute(ActionHelperConstants.CROP_LIST_FOR_NEW_COMPLAINTS,
                actionHelper.getBusinessRelatedCrops(currentBusinessId, user.getLocale()));

        session.setAttribute(ActionHelperConstants.LOCATION_LIST,
                actionHelper.getLocationList(currentBusinessId, user.getLocale()));

        //This has to be moved to specific processors
        setAppSpecificReferenceData(request, activeOnly);


        if (session.getAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST) == null) {
            session
                    .setAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST, actionHelper.getQualityissueList(user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null) {
            session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.IL_TYPE_LIST) == null) {
            session.setAttribute(ActionHelperConstants.IL_TYPE_LIST, actionHelper.getIlTypes(user.getLocale()));
        }

        if (session.getAttribute(ActionHelperConstants.SEED_SIZE_LIST) == null) {
            session.setAttribute(ActionHelperConstants.SEED_SIZE_LIST, actionHelper.getSeedsizeList(user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.STATE_LIST) == null) {
            if (region != null && region.length() != 0)//Region was coming as a space char and thus have to check for length
            {
                session.setAttribute(ActionHelperConstants.STATE_LIST,
                        actionHelper.getRegionSpecificStatesList(userId, region, user.getLocale()));
            } else {
                //session.setAttribute(ActionHelper.STATE_LIST, ActionHelper.getRegionSpecificStatesList(userId));
                sessionHelper.setDefaultStates(session);
            }
        }
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_ROLE_STATUS_LIST) == null) {
            session
                    .setAttribute(ActionHelperConstants.COMPLAINT_ROLE_STATUS_LIST, actionHelper.getStatusListByRole("COMPLAINT", user.getLocale(), user.getPermissionsMap()));
        }
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST) == null) {
            session
                    .setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, actionHelper.getAllStatusList("COMPLAINT", user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.CLAIM_STATUS_LIST) == null&&MCASConstants.APPLICATION_NAME_MCAS.equals(request.getSession().getAttribute("APPLICATION_NAME"))) {
            session
                    .setAttribute(ActionHelperConstants.CLAIM_STATUS_LIST, actionHelper.getClaimStatusTypes("COMPLAINT", user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.UOM_LIST) == null) {
            session.setAttribute(ActionHelperConstants.UOM_LIST, actionHelper.getUomList(user.getLocale()));
        }

        session.setAttribute(ActionHelperConstants.REGION_LIST_FOR_NEW_COMPLAINTS,
                new RegionServiceImpl().getRegionList(userId, currentBusinessId, user.getLocale()));

        if (session.getAttribute(ActionHelperConstants.COMPLAINT_ASSESMENT_MAP) == null) {
            session.setAttribute(ActionHelperConstants.COMPLAINT_ASSESMENT_MAP,
                    actionHelper.getAssesmentMap(user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_LITIGATION_CATEGORY_MAP) == null) {
            session.setAttribute(ActionHelperConstants.COMPLAINT_LITIGATION_CATEGORY_MAP,
                    actionHelper.getLitigationCategoryMap(user.getLocale()));
        }

        if (session.getAttribute(ActionHelperConstants.ALL_REGION_LIST) == null) {
            session.setAttribute(ActionHelperConstants.ALL_REGION_LIST,
                    new RegionServiceImpl().getAllRegionList(user.getLocale()));
        }
        if (session.getAttribute(ActionHelperConstants.SALES_OFFICE_MAP) == null) {
            session.setAttribute(ActionHelperConstants.SALES_OFFICE_MAP, sessionHelper.setDefaultSalesOffices(session));
        }
        if (session.getAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP) == null) {
            session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP, sessionHelper.setDefaultMaterialGroups(session));
        }
        if (session.getAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP) == null) {
            session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP,
                    sessionHelper.setDefaultMaterrialGroupPricings(session));
        }

        ComplaintBusinessService complaintBusinessService = new ComplaintBusinessServiceImpl(source);
        Map<String, String> complaintBusinessReferenceDataMap = complaintBusinessService
                .getComplaintBusinessReferenceData(user.getLocale());
        session.setAttribute("complaintBusiness", complaintBusinessReferenceDataMap);

        ComplaintTypeService complaintTypeService = new ComplaintTypeServiceImpl(source);
        Map<String, String> complaintTypeReferenceMap = complaintTypeService
                .getComplaintTypeReferenceData(user.getLocale());
        session.setAttribute("complaintType", complaintTypeReferenceMap);
//    Map claim_category_ref_data = new LinkedHashMap();
        ClaimsService claimsService = getClaimsService();
        Map<String, String> claim_category_ref_data = claimsService.lookUpClaimCategoryRefData(user.getLocale());
//    claim_category_ref_data.put("","Select One");
//    claim_category_ref_data.put("1","Environmental");
        session.setAttribute("claim_category", claim_category_ref_data);
        sessionHelper.setEmptyFunctionList(session);
        ProgramService programService = new ProgramServiceImpl();
        session.setAttribute(ProgramConstants.PROGRAM_LIST, programService.lookupAllPrograms());
        //Set the complaint entry type list

        boolean isBioteccas = "biotechfas".equals(request.getSession().getAttribute("APPLICATION_NAME"));
        if (isBioteccas) {
            Map<String, String> entryTypeList = new LinkedHashMap<String, String>();
            entryTypeList = complaintService.getComplaintEntryTypeList();
            entryTypeList.remove(new String("1"));
            entryTypeList.put(new String("1"), new String("F"));
            entryTypeList = MCASUtil.sortByValue(entryTypeList);
            session.setAttribute(MCASConstants.COMPLAINT_ENTRY_TYPE_LIST, entryTypeList);
        } else {
            session.setAttribute(MCASConstants.COMPLAINT_ENTRY_TYPE_LIST, complaintService.getComplaintEntryTypeList());
        }
        //todo clean up

        IssueCategoryService issueCategoryService = new IssueCategoryServiceImpl(new IssueCategoryDaoImpl(source));
        //todo duplicate lines below

        Map map = issueCategoryService.lookUpIssueCategory(1, user.getLocale(), "C");
        session.setAttribute("ISSUE_CATEGORY", map);

        map = issueCategoryService.lookUpIssueCategory(2, user.getLocale(), "C");
        session.setAttribute("CATEGORY_LEVEL", map);

        RefugePlantedService refugePlantedService = new RefugePlantedServiceImpl(new RefugePlantedDaoImpl(source));
        Map rp = refugePlantedService.lookUpRefugePlanted(1, user.getLocale());
        session.setAttribute("REFUGE_PLANTED", rp);

        rp = refugePlantedService.lookUpRefugePlanted(2, user.getLocale());
        session.setAttribute("FIELD_DRP", rp);

        RootInjuryService rootInjuryService = new RootInjuryServiceImpl(new RootInjuryDaoImpl(source));
        Map ri = rootInjuryService.lookUpRootInjury(1, user.getLocale());
        session.setAttribute("ROOT_INJURY", ri);

        ri = rootInjuryService.lookUpRootInjury(2, user.getLocale());
        session.setAttribute("INJURY_RATING", ri);

        ComplaintInvestigationService complaintInvestigationService = new ComplaintInvestigationServiceImpl(
                new InitiatorSampleDaoImpl(source), new SiteSampleDaoImpl(source));
        session.setAttribute("INITIATOR_SAMPLE", complaintInvestigationService.lookupAllInitiatorSamples(user.getLocale()));
        session.setAttribute("SITE_SAMPLE", complaintInvestigationService.lookupAllSiteSamples(user.getLocale()));
    }

    private void setAppSpecificReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception {
        sessionHelper.setAppSpecificReferenceData(request, activeRecordsOnly);
    }

    /**
     * To get the sortCriteria and determine the sortOrder.
     *
     * @param request
     */
    private void getSortValues(HttpServletRequest request) {
        sortOrder = "asc";
        sortCriteria = request.getParameter("sortCriteria");
        String lastSortCriteria = request.getSession().getAttribute("lastComplaintSortCriteria") + "";
        if (!StringUtils.isNullOrEmpty(lastSortCriteria)) {
            if (sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
                sortOrder = request.getSession().getAttribute("lastComplaintSortOrder") + "";
                if (!StringUtils.isNullOrEmpty(sortOrder)) {
                    sortOrder = "asc".equalsIgnoreCase(sortOrder) ? "desc" : "asc";
                }
            }
        }
        request.getSession().setAttribute("lastComplaintSortCriteria", sortCriteria);
        request.getSession().setAttribute("lastComplaintSortOrder", sortOrder);

    }

    public ActionForward deleteComplaint(ActionMapping mapping, ActionForm form,
                                         HttpServletRequest request, HttpServletResponse response) {
        String forward = "deleteSuccess";
        String complaintId = request.getParameter("complaintIdToDelete");
        if (!StringUtils.isNullOrEmpty(complaintId)) {
            complaintService.markComplaintForDeletion(complaintId);
        }
        return mapping.findForward(forward);
    }

    private void performGeneralPreProcessing(Complaint complaint, HttpServletRequest request) {

        resetSelections(complaint, request);
        String regionId = request.getParameter(ComplaintConstants.COMPLAINT_FORM_ENTRY_REGION);
        SessionHelper.setSelectedRegion(request.getSession(), regionId);

        CheckboxItemServiceImpl.getSelectedCheckboxItems(complaint, (Map<String, String[]>) request.getParameterMap(), "functionalAreaList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(complaint, (Map<String, String[]>) request.getParameterMap(), "nonconformanceCategoryList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(complaint, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");
    }

    private void performGeneralPostProcessing(HttpServletRequest request) {
        setReadOnlyFlag(request.getSession(), (User) request.getSession().getAttribute(User.USER));
    }

    protected void setReadOnlyFlag(HttpSession session, User user) {
        ApplicationSpecificFactory factory = (new ApplicationSpecificProcessorFactoryImpl()).getApplicationSpecificProcessor((String) session.getAttribute(MCASConstants.APPLICATION_NAME));
        ApplicationSecurityProcessor securityProcessor = factory.getApplicationSecurityProcessor();

        final ComplaintForm form = (ComplaintForm) session.getAttribute(COMPLAINT_FORM);

        if (form == null || form.getC() == null)
            session.setAttribute(MCASConstants.READ_ONLY, false);
        else
            session.setAttribute(MCASConstants.READ_ONLY, securityProcessor.isComplaintReadOnly(form, user));
    }

    /**
     * To set/reset all the checkboxs again, and rectify the checkbox-reset error
     *
     * @param c       Complaint Object
     * @param request HttpServlet Request
     */
    protected void resetSelections(Complaint c, HttpServletRequest request) {

        if (request.getParameter("c.complianceNearMiss") != null) {
            c.setComplianceNearMiss(true);
        } else {
            c.setComplianceNearMiss(false);
        }
    }

    public ActionForward importExcelData(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response)
            throws Exception {
        User user = (User) request.getSession().getAttribute(User.USER);
        FormFile formFile = ((UploadFileForm) form).getLocalFilePath();
        ActionErrors actionErrors = new ActionErrors();
        String emailReport= ((UploadFileForm) form).getEmailReport();
        ActionForward forwardValidation=validateEmail(mapping,form,request,actionErrors,emailReport);
        if(forwardValidation!=null){
           return forwardValidation;
        }
        ComplaintDataReaderUpdaterImpl reader = new ComplaintDataReaderUpdaterImpl();
        List<ActionMessage> errorList = new ArrayList<ActionMessage>();

        InputStream baus= reader.uploadDataResult(formFile.getInputStream(), user.getLocale(), "IMPORT",mapping,form,request);


        for (ActionMessage error : errorList) {
            actionErrors.add("error", error);
        }

        try{
            sendCreateUpdateComplaintFromFile(emailReport,user.getLocale(),baus,"xls",formFile.getFileName());
            baus.close();
        }
        catch (EmailException e){

            actionErrors.add("error", new ActionMessage(e.getMessage(), false));
            MCASLogUtil.logError(e.getMessage(), e);
             // e.printStackTrace();
        }
        finally{

        }
        saveErrors(request, actionErrors);

        return mapping.findForward("complaintImport");
    }

    private void sendCreateUpdateComplaintFromFile(String emailReport, String locale,InputStream attachment,String fileType,String fileName) throws EmailException {

        IEmailService emailService = new EmailService();
        String adminEmailList="qm.team.sap@monsanto.com";
        String subject = fileName+" "+Calendar.getInstance().getTime().toString();
        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setFrom(actionHelper.getAdminEmail());
        emailInfo.setTo(emailReport);
        emailInfo.setCc(adminEmailList);
        emailInfo.setSubject(subject);
        emailInfo.setBody("");
        emailService.sendMailWithAttachment(emailInfo, attachment, fileType,fileName);

    }

    public ActionForward downloadTemplate (ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,
                                             HttpServletResponse response)
                throws Exception {


        String type = request.getParameter("type");
        URL url=null;
        if(type.equalsIgnoreCase("CREATE")){
             url= getServlet().getServletContext().getResource("/WEB-INF/classes/com/monsanto/wst/ccas/resources/New Create.xlsx");
            response.setHeader("Content-Disposition",
                    			"attachment; filename=New Create.xlsx");
        }
        else{
            url= getServlet().getServletContext().getResource("/WEB-INF/classes/com/monsanto/wst/ccas/resources/New Update.xlsx");
            response.setHeader("Content-Disposition",
                                			"attachment; filename=New Update.xlsx");
        }
        InputStream in = url.openStream();


        ServletOutputStream out = response.getOutputStream();

        byte[] outputByte = new byte[4096];
                    //copy binary content to output stream
        while(in.read(outputByte, 0, 4096) != -1){
             out.write(outputByte, 0, 4096);
             }
        in.close();
        out.flush();
        out.close();



              return null;

    }

    public ActionForward createExcelData(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response)
            throws Exception {
        User user = (User) request.getSession().getAttribute(User.USER);
        FormFile formFile = ((UploadFileForm) form).getLocalFilePath();
        ComplaintDataReaderUpdaterImpl reader = new ComplaintDataReaderUpdaterImpl();
        ActionErrors actionErrors = new ActionErrors();
        String emailReport= ((UploadFileForm) form).getEmailReport();
        ActionForward forwardValidation=validateEmail(mapping,form,request,actionErrors,emailReport);
        if(forwardValidation!=null){
            return forwardValidation;
        }

        InputStream baus=reader.uploadDataResult(formFile.getInputStream(), user.getLocale(), MCASConstants.CREATE_FROM_EXCEL,mapping,form,request);


        /*for (ActionMessage error : errorList) {
            actionErrors.add("error", error);
        } */

        try{
            sendCreateUpdateComplaintFromFile(emailReport,user.getLocale(),baus,"xls",formFile.getFileName());
            baus.close();
        }
        catch (EmailException e){
             e.printStackTrace();
            throw e;
        }


        saveErrors(request, actionErrors);

        return mapping.findForward("complaintImportCreate");
    }

    private  ActionForward validateEmail(ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,ActionErrors actionErrors, String emailReport){

                try {
                      InternetAddress emailAddr = new InternetAddress(emailReport);
                      emailAddr.validate();
                   } catch (AddressException ex) {
                      actionErrors.add("error", new ActionMessage("com.monsanto.wst.ccas.attachment.file.emailInvalid"));
                    saveErrors(request, actionErrors);
                    return mapping.findForward("complaintImport");
                   }
        return null;
    }

}
