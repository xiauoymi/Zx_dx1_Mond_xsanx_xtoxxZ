//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.ComplaintFilterForm;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exportTool.ExportClass;
import com.monsanto.wst.ccas.model.ComplaintFilter;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.ExportBean;
import com.monsanto.wst.ccas.taglib.reportTag.ReportTag;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.Map;

/**
 * MyEclipse Struts Creation date: 05-31-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/complaintFilter" name="complaintFilterForm" scope="request"
 */
public class ComplaintFilterAction extends DispatchAction {

    private static final Category logger = Category.getInstance(ComplaintFilterAction.class.getName());
    private static String fileName;
    private static String sheetName;
    private static final String COMPLAINT_FILTER_PAGE = "COMPLAINT FILTER";
    private final ComplaintService complaintService;
    private final CheckboxItemService functionalAreaService;
    private final CheckboxItemService nonconformanceCategoryService;
    private final CheckboxItemService rootCauseService;
    private final CheckboxItemDao functionalAreaDAO;
    private final DataSource dataSource;

    public ComplaintFilterAction() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        complaintService = new ComplaintServiceImpl();
        functionalAreaDAO = new FunctionalAreaDaoImpl(dataSource);
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) form;

        try {
            User user = (User) request.getSession().getAttribute(User.USER);
            int businessId = getUserBusinessId(user);
            new ActionHelper().setApplicationInfoMap(request, businessId, getServlet());
            getComplaintFormDefaults(request);

            populateCheckboxItems(complaintFilterForm, user, businessId,request.getSession().getAttribute("APPLICATION_NAME").toString() );
            request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return mapping.findForward("success");
    }

    private void populateCheckboxItems(ComplaintFilterForm complaintFilterForm, User user, int businessId, String appName) {

        rootCauseService.setCheckboxGroupsForObject(businessId, false, MCASConstants.ENTRY_TYPE_DEFAULT, complaintFilterForm.getComplaintFilter(), null, user.getLocale(), null, appName);
        nonconformanceCategoryService
                .setCheckboxGroupsForObject(businessId, false, MCASConstants.ENTRY_TYPE_DEFAULT, complaintFilterForm.getComplaintFilter(), null, user.getLocale(), null, appName);
        functionalAreaService.setCheckboxGroupsForObject(businessId, false, MCASConstants.ENTRY_TYPE_DEFAULT, complaintFilterForm.getComplaintFilter(), null,
                user.getLocale(), user.getPermissionsMap(), appName);
    }

    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) form;

        resetSelections(complaintFilterForm.getComplaintFilter(), request);
        Map<String, RowBean> hash;
        try {
            User user = (User) request.getSession().getAttribute(User.USER);
            int businessId = getUserBusinessId(user);
            populateCheckboxItems(complaintFilterForm, user, businessId, request.getSession().getAttribute("APPLICATION_NAME").toString());

            hash = complaintService
                    .getComplaintReport(complaintFilterForm.getComplaintFilter(), businessId, request.getParameterMap(),
                            user.getLocale());
        } catch (ServiceException e) {
            MCASLogUtil.logError("Exception thrown by ComplaintReportService:", e);
            throw new Exception(e);
        }
        //**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the ComplaintFilter Form Bean.
        complaintFilterForm.setHash(hash);
        String file = "";
        InputStream xmlIn = null;
        try {
            file = McasProperties.getMcasProperties().getString("complaint.reportStructure");
            ClassLoader classLoader = ComplaintFilterAction.class.getClassLoader();
            xmlIn = classLoader.getResourceAsStream(file);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Property Error: Problem getting the Complaint-Report-Structure.Xml filename.", ex);
            throw new Exception(ex);
        }
        complaintFilterForm.setXmlIn(xmlIn);
        complaintFilterForm.setSortBy("col1");
        complaintFilterForm.setSortOrder("asc");
        return mapping.findForward("success");
    }

    /**
     * Method export
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward export(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

//    logger.info("Export to Excel called...");

        //**The Export Functionality...
        ServletOutputStream sos = null;
        BufferedOutputStream bos = null;

        try {

            ExportBean exportBean = ReportTag.getExportData();

            fileName = exportBean.getExcelFileName();
            sheetName = exportBean.getExcelSheetName();

            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "filename=" + fileName);

            sos = response.getOutputStream();
            bos = new BufferedOutputStream(sos);

            ExportClass export2Excel = new ExportClass();

            //**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector...
            export2Excel.setSheetName(sheetName);
            export2Excel.setTotalFields(exportBean.getTotalFields());
            export2Excel.setColHeader(exportBean.getExportColHeader());
            export2Excel.setVector(exportBean.getExportDataVector());

            export2Excel.setBos(bos);

            export2Excel.exportExcel();

            bos = export2Excel.getBos();

            bos.flush();
        }
        catch (Exception ex) {
            MCASLogUtil.logError("-> Error exporting Complaint Report.", ex);
        }
        finally {
            MCASResourceUtil.closeResource(bos);
            MCASResourceUtil.closeResource(sos);
        }

//    logger.info("-> Excel file created.");

        return mapping.findForward("success");
    }

    //todo refactor this. This is a duplicate method present in Complaint action
    /**
     * List/Combo Box Filling method...
     *
     * @param request
     * @throws Exception
     */
    private void getComplaintFormDefaults(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        String userId = user.getUser_id();
        int businessId = getUserBusinessId(user);
        session.setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, null);
        ActionHelper actionHelper = new ActionHelper();
        if (session.getAttribute(ActionHelperConstants.CROP_LIST) == null)
            session.setAttribute(ActionHelperConstants.CROP_LIST, actionHelper.getCropList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.LOCATION_LIST) == null)
            session.setAttribute(ActionHelperConstants.LOCATION_LIST,
                    actionHelper.getLocationList(businessId, user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST) == null)
            session
                    .setAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST, actionHelper.getQualityissueList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
            session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST) == null)
            session
                    .setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, actionHelper.getAllStatusList("COMPLAINT", user.getLocale()));
//      if (session.getAttribute(ActionHelper.ALL_REGION_LIST) == null ){
//        session.setAttribute(ActionHelper.ALL_REGION_LIST, ActionHelper.getAllRegionList());
//      }
        //For seminis Users, display complaint assesment drop down and complaint category drop down
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_ASSESMENT_MAP) == null) {
            session.setAttribute(ActionHelperConstants.COMPLAINT_ASSESMENT_MAP,
                    actionHelper.getAssesmentMap(user.getLocale()));

        }
        if (session.getAttribute(ActionHelperConstants.COMPLAINT_LITIGATION_CATEGORY_MAP) == null) {
            session.setAttribute(ActionHelperConstants.COMPLAINT_LITIGATION_CATEGORY_MAP,
                    actionHelper.getLitigationCategoryMap(user.getLocale()));
        }
        if (businessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
            //Set the Material Group Map
            session.setAttribute(ActionHelperConstants.BUSINESS_RELATED_MATERIAL_GROUP_MAP,
                    actionHelper.getBusinessRelatedMaterialGroupMap(businessId, user.getLocale()));

            //Set the Material Pricing Group Map
            session.setAttribute(ActionHelperConstants.BUSINESS_RELATED_MATERIAL_PRICING_GROUP_MAP,
                    actionHelper.getBusinessRelatedMaterialPricingGroupMap(businessId, user.getLocale()));

            //Set the Sales Office Map
            session.setAttribute(ActionHelperConstants.BUSINESS_RELATED_SALES_OFFICE_MAP,
                    actionHelper.getBusinessRelatedSalesOfficeMap(businessId, user.getLocale()));
        }
        //Set the Region List Based on the User's Business
        //session.setAttribute(ActionHelper.USER_BUSINESS_PREFERENCE_REGION_LIST, ActionHelper.getRegionsForSearch(userId,businessId,false));
        session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale()));
        session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST,
                actionHelper.getBusinessPreferenceRelatedCropList(businessId, user.getLocale()));
        DataSource source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        ComplaintBusinessService complaintBusinessService = new ComplaintBusinessServiceImpl(source);
        Map<String, String> complaintBusinessReferenceDataMap = complaintBusinessService
                .getComplaintBusinessReferenceData(user.getLocale());
        session.setAttribute("complaintBusiness", complaintBusinessReferenceDataMap);
        LookUpService lookUpService = new LookUpServiceImpl();
        Map<String, String> nonconformanceCategoryReferenceMap = lookUpService
                .lookUpFeedbackCategories(false, user.getLocale());
        session.setAttribute("feedbackCategory", nonconformanceCategoryReferenceMap);
        ComplaintTypeService complaintTypeService = new ComplaintTypeServiceImpl(source);
        Map<String, String> complaintTypeReferenceMap = complaintTypeService
                .getComplaintTypeReferenceData(user.getLocale());
        session.setAttribute("complaintType", complaintTypeReferenceMap);
        SessionHelper sessionHelper = new SessionHelper();
        sessionHelper.setEmptyFunctionList(session);


    }

    private int getUserBusinessId(User user) throws ServiceException {
        BusinessService service = (BusinessService) ServiceLocator.locateService(BusinessService.class);
        return service.getBusinessId(user);
    }

    /**
     * To set/reset all the checkboxs again, and rectify the checkbox-reset error
     *
     * @param complaintFilter
     * @param request
     */
    private void resetSelections(ComplaintFilter complaintFilter, HttpServletRequest request) {

        if (request.getParameterMap().get("complaintFilter.driverPerformance") != null) {
            complaintFilter.setDriverPerformance(true);
        } else {
            complaintFilter.setDriverPerformance(false);
        }
        if (request.getParameterMap().get("complaintFilter.packagingCondition") != null) {
            complaintFilter.setPackagingCondition(true);
        } else {
            complaintFilter.setPackagingCondition(false);
        }
        if (request.getParameterMap().get("complaintFilter.incorrectShipment") != null) {
            complaintFilter.setIncorrectShipment(true);
        } else {
            complaintFilter.setIncorrectShipment(false);
        }
        if (request.getParameterMap().get("complaintFilter.tagError") != null) {
            complaintFilter.setTagError(true);
        } else {
            complaintFilter.setTagError(false);
        }
        if (request.getParameterMap().get("complaintFilter.deliveryOther") != null) {
            complaintFilter.setDeliveryOther(true);
        } else {
            complaintFilter.setDeliveryOther(false);
        }

        if (request.getParameterMap().get("complaintFilter.seedAppearance") != null) {
            complaintFilter.setSeedAppearance(true);
        } else {
            complaintFilter.setSeedAppearance(false);
        }
        if (request.getParameterMap().get("complaintFilter.seedVariability") != null) {
            complaintFilter.setSeedVariability(true);
        } else {
            complaintFilter.setSeedVariability(false);
        }
        if (request.getParameterMap().get("complaintFilter.emergenceConcerns") != null) {
            complaintFilter.setEmergenceConcerns(true);
        } else {
            complaintFilter.setEmergenceConcerns(false);
        }
        if (request.getParameterMap().get("complaintFilter.productPurity") != null) {
            complaintFilter.setProductPurity(true);
        } else {
            complaintFilter.setProductPurity(false);
        }
        if (request.getParameterMap().get("complaintFilter.earlySeasonOther") != null) {
            complaintFilter.setEarlySeasonOther(true);
        } else {
            complaintFilter.setEarlySeasonOther(false);
        }

        if (request.getParameterMap().get("complaintFilter.treatment") !=
                null) {    //Mcas Enhacement...added Treatment field
            complaintFilter.setTreatment(true);
        } else {
            complaintFilter.setTreatment(false);
        }

        if (request.getParameterMap().get("complaintFilter.growthDevelopment") != null) {
            complaintFilter.setGrowthDevelopment(true);
        } else {
            complaintFilter.setGrowthDevelopment(false);
        }
        if (request.getParameterMap().get("complaintFilter.herbicideInjury") != null) {
            complaintFilter.setHerbicideInjury(true);
        } else {
            complaintFilter.setHerbicideInjury(false);
        }
        if (request.getParameterMap().get("complaintFilter.diseaseDevelopment") != null) {
            complaintFilter.setDiseaseDevelopment(true);
        } else {
            complaintFilter.setDiseaseDevelopment(false);
        }
        if (request.getParameterMap().get("complaintFilter.insectOutbreaksInjury") != null) {
            complaintFilter.setInsectOutbreaksInjury(true);
        } else {
            complaintFilter.setInsectOutbreaksInjury(false);
        }
        if (request.getParameterMap().get("complaintFilter.pollinationProblems") != null) {
            complaintFilter.setPollinationProblems(true);
        } else {
            complaintFilter.setPollinationProblems(false);
        }
        if (request.getParameterMap().get("complaintFilter.stressSusceptability") != null) {
            complaintFilter.setStressSusceptability(true);
        } else {
            complaintFilter.setStressSusceptability(false);
        }
        if (request.getParameterMap().get("complaintFilter.midSeasonOther") != null) {
            complaintFilter.setMidSeasonOther(true);
        } else {
            complaintFilter.setMidSeasonOther(false);
        }

        if (request.getParameterMap().get("complaintFilter.lateSeasonDiseaseDevelopment") != null) {
            complaintFilter.setLateSeasonDiseaseDevelopment(true);
        } else {
            complaintFilter.setLateSeasonDiseaseDevelopment(false);
        }
        if (request.getParameterMap().get("complaintFilter.insectDevelopment") != null) {
            complaintFilter.setInsectDevelopment(true);
        } else {
            complaintFilter.setInsectDevelopment(false);
        }
        if (request.getParameterMap().get("complaintFilter.seedDevelopment") != null) {
            complaintFilter.setSeedDevelopment(true);
        } else {
            complaintFilter.setSeedDevelopment(false);
        }
        if (request.getParameterMap().get("complaintFilter.nonCompetitiveYield") != null) {
            complaintFilter.setNonCompetitiveYield(true);
        } else {
            complaintFilter.setNonCompetitiveYield(false);
        }
        if (request.getParameterMap().get("complaintFilter.maintainingSeedUntilHarvest") != null) {
            complaintFilter.setMaintainingSeedUntilHarvest(true);
        } else {
            complaintFilter.setMaintainingSeedUntilHarvest(false);
        }
        if (request.getParameterMap().get("complaintFilter.maturityDrydown") != null) {
            complaintFilter.setMaturityDrydown(true);
        } else {
            complaintFilter.setMaturityDrydown(false);
        }
        if (request.getParameterMap().get("complaintFilter.lateSeasonOther") != null) {
            complaintFilter.setLateSeasonOther(true);
        } else {
            complaintFilter.setLateSeasonOther(false);
        }
        if (request.getParameterMap().get("complaintFilter.complaintEntryTypeId") != null) {
            complaintFilter
                    .setComplaintEntryTypeId((String) request.getParameterMap().get("complaintFilter.complaintEntryTypeId"));
        } else {
            complaintFilter.setComplaintEntryTypeId("");
        }

    }

}
