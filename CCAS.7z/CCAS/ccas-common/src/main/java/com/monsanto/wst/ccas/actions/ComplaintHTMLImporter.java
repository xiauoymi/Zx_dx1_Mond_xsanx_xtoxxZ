package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.ComplaintListForm;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.User;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: May 26, 2009
 * Time: 11:10:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComplaintHTMLImporter implements ComplaintImporter {
    private final ActionForm form;
    private final HttpServletRequest httpServletRequest;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    private final FunctionalAreaImporter functionalAreaImporter;

    public ComplaintHTMLImporter(ActionForm form, HttpServletRequest httpServletRequest, FunctionalAreaImporter functionalAreaImporter) {
        this.form = form;
        this.httpServletRequest = httpServletRequest;
        this.functionalAreaImporter = functionalAreaImporter;
    }

    public Complaint getComplaint() {
        Complaint complaint = ((ComplaintForm) form).getC();
        boolean claimAmountFinal = httpServletRequest.getParameterMap().get("c.claimAmountFinal") != null;
//    String claimId = httpServletRequest.getParameter("id_claim_hidden");
//    if(claimId!=null){
//      complaint.setClaim_number(claimId);
//    }
        complaint.setClaimAmountFinal(claimAmountFinal);
//    complaint.setClaimId(claimId);
        String deliveryInfo = !StringUtils.isNullOrEmpty(httpServletRequest.getParameter("c.delivery_info")) ? httpServletRequest.getParameter("c.delivery_info") : "";
        complaint.setDelivery_info(deliveryInfo);
        String initiatorResponse = !StringUtils.isNullOrEmpty(httpServletRequest.getParameter("c.initiator_response")) ? httpServletRequest.getParameter("c.initiator_response") : "";
        complaint.setInitiator_response(initiatorResponse);
//        setSelectedNonconformanceCategories(complaint);
//        setSelectedRootCauses(complaint);
//        setSelectedFunctionalAreas(complaint);
        complaint.setEntryType(getComplaintEntryTypeFromRequest(httpServletRequest.getParameterMap()));
        return complaint;
    }

//    private void setSelectedFunctionalAreas(Complaint complaint) {
//
//        //FunctionalAreaService functionalAreaService = new FunctionalAreaServiceImpl(new FunctionalAreaDaoImpl());
//        //List<CheckboxItem> functionalAreasList = functionalAreaService.lookUpAllFunctionalAreas();
//        List<CheckboxItem> functionalAreasList = new ArrayList();
//
//        functionalAreaImporter.initializeFunctionalAreas(AuditConstants.C_AUDIT_AREA_LIST, complaint.getFunctionalAreaList(), functionalAreasList);
//        complaint.setSelectedFunctionalAreas(functionalAreasList);
//    }
//
//    private void setSelectedNonconformanceCategories(Complaint complaint) {
//        List<CheckboxItem> nonconformanceCategoryList = new ArrayList<CheckboxItem>();
//        functionalAreaImporter.initializeFunctionalAreas("c.nonconformanceCategoryList", complaint.getNonconformanceCategoryList(), nonconformanceCategoryList);
//        complaint.setSelectedNonconformanceList(nonconformanceCategoryList);
//    }
//
//    private void setSelectedRootCauses(Complaint complaint) {
//        List<CheckboxItem> rootCauseList = new ArrayList<CheckboxItem>();
//        functionalAreaImporter.initializeFunctionalAreas("rootCauseList", complaint.getRootCauseList(), rootCauseList);
//        complaint.setSelectedRootCauseList(rootCauseList);
//    }

    public String populateNewComplaintDefaults() {
        String forward = "";
        Complaint complaint = new Complaint();
        User user = (User) httpServletRequest.getSession().getAttribute(User.USER);
        complaint.setCreated_by(user.getUser_id());
        complaint.setRow_user_id(user.getUser_id());
        complaint.setRow_entry_date(sdf.format(new Date()));
        complaint.setClosingPersonId("");
        complaint.setClosingDate("");
//    complaint.setRootCauseDate(sdf.format(new Date()));
//    complaint.setLongTermDate(sdf.format(new Date()));
        complaint.setEntryType(getComplaintEntryTypeFromRequest(httpServletRequest.getParameterMap()));
        if (httpServletRequest.getParameter("affina").equals("true")) {
            forward = MCASConstants.SUCCESS_AFFINA_MESSAGE;
            complaint.setAffina_entry_flag("Y");
        } else {
            forward = MCASConstants.SUCCESS_MESSAGE;
            complaint.setAffina_entry_flag("N");
        }

        setAttributeDefaults(httpServletRequest);
        ((ComplaintForm) form).setC(complaint);
        return forward;
    }

    private String getComplaintEntryTypeFromRequest(Map<String, String[]> requestParameterMap) {
        String[] entryTypeArray = requestParameterMap.get(MCASConstants.ENTRY_TYPE);
        String entryType = (entryTypeArray != null && entryTypeArray.length > 0) ? entryTypeArray[0] : "";

        return MCASConstants.COMPLAINT_NCR.equals(entryType) || MCASConstants.COMPLAINT_DEV.equals(entryType) ? entryType :
                MCASConstants.ENTRY_TYPE_DEFAULT;
    }

    private void setAttributeDefaults(HttpServletRequest request) {
        request.getSession().setAttribute("complaintEdit", "false");
        request.setAttribute("showCAR", "false");
    }

    public ComplaintListForm setComplaintMainDefaults() {
        ComplaintListForm listForm = (ComplaintListForm) form;
        String resetCList = httpServletRequest.getParameter("resetCList");
        if (resetCList != null && resetCList.equals("true")) {
            listForm.setComplaintsList(null);
        }
        httpServletRequest.getSession().setAttribute("pageNumber", "1");
        httpServletRequest.setAttribute("selectedPage", "1");
        httpServletRequest.getSession().setAttribute("lastComplaintSortOrder", "desc");
        return listForm;
    }
}
