package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.ComplaintListForm;
import com.monsanto.wst.ccas.model.Complaint;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: May 26, 2009
 * Time: 11:08:23 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ComplaintImporter {
    Complaint getComplaint();

    public String populateNewComplaintDefaults();

    public ComplaintListForm setComplaintMainDefaults();
}
