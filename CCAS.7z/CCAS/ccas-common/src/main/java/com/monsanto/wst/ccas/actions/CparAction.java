/*
 * Created on Feb 23, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.CparForm;
import com.monsanto.wst.ccas.actionForms.CparListForm;
import com.monsanto.wst.ccas.actionForms.CparListObject;
import com.monsanto.wst.ccas.app.*;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASLookupFilterUtil;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jbrahmb
 */
public class CparAction extends DispatchAction {

    //**Log4j logger
    private static final Category logger = Category.getInstance(AuditAction.class.getName());
    private static final String SOY_BUSINESS = "-SOY-";
    private static final String MSP_BUSINESS = "-MSP-";
    private static final String PAT_BUSINESS = "-PAT-";
    private static final String COR_BUSINESS = "-COR-";
    private static final String COT_BUSINESS = "-COT-";
    private static final String CAN_BUSINESS = "-CAN-";
    private static final String WHE_BUSINESS = "-WHE-";
    private static final String SUG_BUSINESS = "-SUG-";
    private static final String BRE_BUSINESS = "-BRE-";

    private static final int CPAR_CI_TYPE= 4;

    private String sortCriteria;
    private String sortOrder;
    private final CparService cparService;
    private final ActionHelper actionHelper;
    private final DataSource dataSource;
    private final SessionHelper sessionHelper;
    private final BusinessService businessService;
    private final ComplaintService complaintService;
    private final CheckboxItemService functionalAreaService;
    private final CheckboxItemService nonconformanceCategoryService;
    private final CheckboxItemService rootCauseService;
    private final CheckboxItemDao functionalAreaDAO;
    private final IssueCategoryDao issueCategoryDAO;
    private final IssueService issueService;
    public static final String CPAR_FORM = "cparForm";
    private final IssueCategoryService issueCategoryService;
    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

    public CparAction() {
        cparService = new CparServiceImpl();
        issueService = new IssueServiceImpl();
        actionHelper = new ActionHelper();
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionalAreaDAO = new FunctionalAreaDaoImpl(dataSource);
        sessionHelper = new SessionHelper();
        businessService = new BusinessServiceImpl();
        complaintService = new ComplaintServiceImpl();
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
        issueCategoryDAO = new IssueCategoryDaoImpl(dataSource);
        issueCategoryService = new IssueCategoryServiceImpl(issueCategoryDAO);
    }

    public CparAction(ActionHelper actionHelper, CparService cparService, IssueService issueService,
                      DataSource dataSource, SessionHelper sessionHelper, BusinessService businessService,
                      ComplaintService complaintService, CheckboxItemService functionalAreaService, CheckboxItemDao functionalAreaDAO,
                      CheckboxItemService nonconformanceService, CheckboxItemService rootCauseService,
                      IssueCategoryDao issueCategoryDAO, IssueCategoryService issueCategoryService) {
        this.actionHelper = actionHelper;
        this.cparService = cparService;
        this.issueService = issueService;
        this.dataSource = dataSource;
        this.sessionHelper = sessionHelper;
        this.businessService = businessService;
        this.complaintService = complaintService;
        this.functionalAreaService = functionalAreaService;
        this.functionalAreaDAO = functionalAreaDAO;
        this.nonconformanceCategoryService = nonconformanceService;
        this.rootCauseService = rootCauseService;
        this.issueCategoryDAO = issueCategoryDAO;
        this.issueCategoryService = issueCategoryService;
    }

    public ActionForward cparList(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
            throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        session.setAttribute(AuditAction.BUSINESS_ID, "" + getUserBusinessId(user));

        Map<String, Object> cparsList = null;
        int pageNumber;
        CparListForm cf = (CparListForm) form;
        CparListObject co = cf.getCparListObject();
        initializeCparSortCriteria(request, session);
        request.setAttribute("displayAllGeneratorsAndFindingTypes", "true");
        String carFlag = initializeCparDefaults(request, session, cf, user.getLocale(), getUserBusinessId(user));

        nonconformanceCategoryService.setCheckboxGroupsForObject(getUserBusinessId(user), false, "P", co, null, user.getLocale(), user.getPermissionsMap(),request.getSession().getAttribute("APPLICATION_NAME").toString() );
        rootCauseService.setCheckboxGroupsForObject(getUserBusinessId(user), false, "P", co, null, user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        functionalAreaService.setCheckboxGroupsForObject(getUserBusinessId(user), false, "P", co, null, user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        reloadDepartmentProcess(request, cf);

        if (!StringUtils.isNullOrEmpty(request.getParameter("pageNumber")) &&
                "false".equalsIgnoreCase(request.getParameter("reset"))) {
            pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
            List<Integer> idList = null;
            if (!co.isFunctionalAreaIdListEmpty())
                idList = co.getFunctionalAreaIdList();
            cparsList = cparService.getCparsList(co.getControlNumber().trim(), co.getCreateDateFrom(), co.getCreateDateTo(),
                    co.getInitiatedBy().trim(), co.getStatus(), co.getRegion(), co.getClaimNumber().trim(), carFlag,
                    co.getFilingLocation(), co.getResponsibleLocation(), request.getParameter("pageNumber"),
                    Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder,
                    co.getComplaintBusinessId(), co.getFunctionId(), getUserBusinessPreferenceId(session), cf.getType(),
                    co.getFilingProgramId(),
                    co.getResponsibleProgramId(), co.getGenerator(), co.getFindingType(), co.getIsoElement(),
                    user.getLocale(), co.getSiteManager(), co.getSearchText(), co.getClosingDate(), idList, co.getCrop());

            setPageNumberForPagination(request, session, pageNumber);
        }
        setCparListForDisplay(session, cparsList, cf);
        return mapping.findForward("successList");
    }


    private void setPageNumberForPagination(HttpServletRequest request, HttpSession session, int pageNumber) {
        if (request.getParameter("getMax").equals("true")) {
            session.setAttribute("pageNumber", "1");
        } else {
            if (pageNumber < 11 && pageNumber > 0)
                session.setAttribute("pageNumber", "1");
            else
                session.setAttribute("pageNumber", request.getParameter("pageNumber"));
        }
    }

    private void setCparListForDisplay(HttpSession session, Map<String, Object> cparsList, CparListForm cf) {
        float pages;
        User user = (User) session.getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        if (cparsList != null) {
            pages = Float.parseFloat(cparsList.get("maxRows").toString());
            cparsList.remove("maxRows");
            if (cparsList.size() > 0 && pages > 0) {
                session.setAttribute("pages", pages / 10);
            } else {
                session.setAttribute("pages", 0f);
            }
        }
        cf.setCparsList(cparsList);
        sessionHelper.setFunctionLocation(session, cf.getCparListObject().getResponsibleLocation());
        session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST,
                actionHelper.getBusinessPreferenceRelatedCropList(businessId, user.getLocale()));
    }

    /**
     * Initialize Cpar defaults.
     *
     * @param request
     * @param session
     * @param cf
     * @return carFlag : Either CAR/PAR
     * @throws Exception
     */
    private String initializeCparDefaults(HttpServletRequest request, HttpSession session, CparListForm cf, String locale, int busId) throws
            Exception {
        getCparFormDefaults(request, getUserBusinessPreferenceId(session), cf.getType(), cf.getCparListObject().getRegion());
        if (session.getAttribute(CparConstants.IS_CAR_FLAG) != null &&
                !(session.getAttribute(CparConstants.IS_CAR_FLAG).equals(request.getParameter(CparConstants.IS_CAR_FLAG)))) {
            cf.getCparListObject().reset();
        }
        session.setAttribute(CparConstants.IS_CAR_FLAG, request.getParameter(CparConstants.IS_CAR_FLAG));
        session.setAttribute(ActionHelperConstants.CPAR_STATUS_LIST, actionHelper.getAllStatusList("CPAR", locale));
        session.setAttribute(MCASConstants.ORGANIZATION_LIST, actionHelper.getOrganizationList(locale, busId));
        session.setAttribute(MCASConstants.DEPARTMENT_AFFECTED_LIST, actionHelper.getDepartmentAffectedList(locale, busId));

        String carFlag;
        if ("true".equals(request.getParameter(CparConstants.IS_CAR_FLAG))) {
            carFlag = "Y";
            cf.setType(CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
        } else {
            carFlag = "N";
            setType(request, cf);
        }
        return carFlag;
    }

    private void setType(HttpServletRequest request, CparListForm cf) {
        if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CPAR_TYPE))) {
            cf.setType(Integer.parseInt(request.getParameter(CparConstants.CPAR_TYPE)));
        }
//storing in session is bad
        request.setAttribute(CparConstants.CPAR_TYPE, cf.getType());
    }

    /**
     * Initialize the page number and Sorting criteria for listing
     *
     * @param request
     * @param session
     */
    void initializeCparSortCriteria(HttpServletRequest request, HttpSession session) {
        String selectedPage =
                (!StringUtils.isNullOrEmpty(request.getParameter("selectedPage"))) ? request.getParameter("selectedPage") : "1";
        session.setAttribute("selectedPage", selectedPage);

        if (request.getParameter("isSorting") != null && request.getParameter("isSorting").equals("false")) {
            sortCriteria = request.getParameter("sortCriteria");
            sortOrder = request.getParameter("sortOrder");
            session.setAttribute(CparConstants.LAST_CPAR_SORT_CRITERIA, sortCriteria);
            session.setAttribute(CparConstants.LAST_CPAR_SORT_ORDER, sortOrder);
        } else {
            getSortValues(request);
        }
    }

    private int getUserBusinessPreferenceId(HttpSession session) {
        User user = ((User) session.getAttribute(User.USER));
        return actionHelper.getUserBusinessPreference(user);
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }

    public ActionForward cparNew(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
            throws Exception {

        CparForm cf = (CparForm) form;
        String forward = "";
        User user = (User) request.getSession().getAttribute(User.USER);
        String fromComplaint= (String) request.getParameter("fromComplaint");
        String complaint_id = (String) request.getSession().getAttribute("complaint_id");
        String complaintEntryType = (String) request.getSession().getAttribute("entryType");
        cf.getCpar().setComplaintEntryType(complaintEntryType);
        String[] complaintIdArr = {complaint_id};
        if(fromComplaint != null){
            if(fromComplaint.equals("true")){
                request.getSession().setAttribute(MCASConstants.DEPARTMENT_AFFECTED_LIST, actionHelper.getDepartmentAffectedList(user.getLocale(), user.getBusinessId()));
                request.getSession().setAttribute(MCASConstants.ORGANIZATION_LIST, actionHelper.getOrganizationList(user.getLocale(), user.getBusinessId()));
                cf.getCpar().setComplaint_id(complaintIdArr);
                request.setAttribute("msg", "false");
            }
        }
        //System.out.println("complaint_id:" + cf.getCpar().getComplaint_id()[0]);
        int businessId = getUserBusinessId(user);
        preProcessNewCpar(request, businessId, cf.getCpar().getRegion());

//        logger.error("START : ****User ID****:" + user.getUser_id() + ":****Business ID****:" + businessId +
//                ":****User Role****:" + user.getPermissionsMap() +
//                ":****Method****:" + getClass() + "cparNew()" +
//                ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//                ":****Viewable Region List****:" +
//                request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION));
        createNewCparObject(user, cf, false);
        Cpar cparObject = cf.getCpar();
        if(fromComplaint != null){
            if(fromComplaint.equals("true")){
                cparObject.setComplaint_id(complaintIdArr);
                cparObject.setComplaintEntryType(complaintEntryType);
            }
        }
        //System.out.println("complaint_id:" + cparObject.getComplaint_id()[0]);
        cparObject.setBusinessId(businessId);
        performApplicationSpecificPreProcessing(request, cparObject);

        getCparFormDefaults(request, businessId, getTypeFromRequest(request), cparObject.getRegion());

        if (request.getSession().getAttribute("selectedRegion") != null) {
            cparObject.setRegion((String) request.getSession().getAttribute("selectedRegion"));
            setCompleteIssueList(cparObject, user.getLocale());
        }

        forward = postProcessNewCpar(request, cf, user, businessId);


        return (mapping.findForward(forward));
    }

    private String postProcessNewCpar(HttpServletRequest request, CparForm cf, User user, int businessId) throws
            Exception {
        Cpar cpar = cf.getCpar();
        getAuditStopSaleNumber(cf, request);
        setCPAR(request, cpar);
        setEditValue(request, "cparNew");
        setRequestAttributes(request, user, businessId);
        setComplaintCategoriesList(cpar, businessId, false, user.getLocale(),request.getSession().getAttribute("APPLICATION_NAME").toString());

        rootCauseService.setCheckboxGroupsForObject(businessId, false, "P", cpar, cpar.getCpar_id(), user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        functionalAreaService.setCheckboxGroupsForObject(businessId, false, "P", cpar, cpar.getCpar_id(), user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        setRegionSpecificLocationList(cf.getCpar().getRegion(), request, cf.getCpar().getType());
        setFunctionDropdown(request, cf);
        //Calendar now = Calendar.getInstance();
        //now.add(Calendar.DAY_OF_MONTH,90);
        //SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        //String dateform=formatter.format(now.getTime());
        //cf.getCpar().setReport_due_date(dateform);


        //performGeneralPostProcessing(request, cf.getCpar(), cpar.getBusinessId(), user.getLocale());
        if ( cpar.getBusinessId() != 0 )
           performGeneralPostProcessing(request, cf.getCpar(), cpar.getBusinessId(), user.getLocale());
        else
           performGeneralPostProcessing(request, cf.getCpar(), businessId, user.getLocale());

        return "success";
    }

    private void setFunctionDropdown(HttpServletRequest request, CparForm cf) {
        sessionHelper.setFunctionLocation(request.getSession(), cf.getCpar().getResponsible_location());
        cf.getCpar().setFunctionId(request.getParameter(AuditConstants.AUDIT_OBJ_LOCATION_CODE));
    }

    private void setRegionSpecificLocationList(String region, HttpServletRequest request, int type) throws Exception {
        setApplicationSpecificData(request, type, region, null);
    }

    private void setRequestAttributes(HttpServletRequest request, User user, int businessId) throws Exception {
        boolean canViewSaveUpdateControls = isSaveUpdateControlsVisible(user, "cparNew");
        request.setAttribute("canViewControls", canViewSaveUpdateControls);
        request.setAttribute(AuditAction.BUSINESS_ID, "" + businessId);
    }

    private int getTypeFromRequest(HttpServletRequest request) {
        String parameter = request.getParameter(CparConstants.CPAR_TYPE);
        return Integer.parseInt(parameter == null ? "0" : parameter);
    }

    private void preProcessNewCpar(HttpServletRequest request, int businessId, String regionId) throws Exception {
        getCparFormDefaults(request, businessId, getTypeFromRequest(request), regionId);
        actionHelper.setApplicationInfoMap(request, businessId, getServlet());
        request.getSession().setAttribute(CparConstants.IS_CAR_FLAG, request.getParameter(CparConstants.IS_CAR_FLAG));
        SessionHelper.setSelectedRegionResponsible(request.getSession(), "");
    }

    private void createNewCparObject(User user, CparForm cf, boolean isParFromFinding) throws ServiceException {
        cf.createNewCpar(new Cpar(), user.getUser_id(), isParFromFinding);
    }

    private boolean isSaveUpdateControlsVisible(User user, String methodType) throws Exception {
        return actionHelper.isSaveUpdateControlsVisible(user, methodType);
    }

    public ActionForward cparFindingNew(ActionMapping mapping,
                                        ActionForm form,
                                        HttpServletRequest request,
                                        HttpServletResponse response)
            throws Exception {
        String forward;
        CparForm cf = (CparForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        actionHelper.setApplicationInfoMap(request, businessId, getServlet());

//        logger.info(
//                "START : Before getCparFormDefaults() method ****User ID****:" + cf.getCpar().getRow_user_id() +
//                        ":**** Users Business ID****:" + businessId + ":***CPAR Business ID***:" + cf.getCpar().getBusinessId() +
//                        ":****User Role****:" + ((User) request.getSession().getAttribute("user")).getPermissionsMap() +
//                        ":****Method****:" + getClass() + "cparFindingNew()" +
//                        ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//                        ":****Viewable Region List****:" +
//                        request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION) +
//                        ":****Region ID in CPAR****:" + cf.getCpar().getRegion());
        performApplicationSpecificPreProcessing(request, cf.getCpar());
        getCparFormDefaults(request, businessId, cf.getCpar().getType(), cf.getCpar().getRegion());
//        logger.info(
//                "START : After getCparFormDefaults() method ****User ID****:" + cf.getCpar().getRow_user_id() +
//                        ":****Business ID****:" + cf.getCpar().getBusinessId() +
//                        ":****User Role****:" + ((User) request.getSession().getAttribute("user")).getPermissionsMap() +
//                        ":****Method****:" + getClass() + "cparFindingNew()" +
//                        ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//                        ":****Viewable Region List****:" +
//                        request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION) +
//                        ":****Region ID in CPAR****:" + cf.getCpar().getRegion());
        final String isCar = (String) request.getAttribute(CparConstants.IS_CAR_FLAG);
        request.getSession().setAttribute(CparConstants.IS_CAR_FLAG, isCar);
        try {
            createNewCparObject(user, cf, "false".equals(isCar));
            if (isCar.equals("true")) {
                cf.getCpar().setCar_flag("Y");
                if (!(request.getAttribute("createCAR") == null || isCar == null) &&
                        request.getAttribute("createCAR").equals("true")) {
                    getCARFindingData(request, cf.getCpar());  //**Gets the audit-Finding details...for CAR
                    request.setAttribute("msg", "false");
                }
            } else {
                getCARFindingData(request, cf.getCpar()); //**Gets the audit-Finding details...also for PAR
                cf.getCpar().setCar_flag("N");
            }
        }
        catch (Exception e) {
            throw new Exception(e);
        }
        forward = postProcessNewCpar(request, cf, user, businessId);

        return (mapping.findForward(forward));
    }


    public ActionForward cparStopSaleNew(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response)
            throws Exception {
        String forward;
        User user = (User) request.getSession().getAttribute("user");
        int currentBusinessId = getUserBusinessId(user);
        CparForm cf = (CparForm) form;

        getCparFormDefaults(request, currentBusinessId, getTypeFromRequest(request), cf.getCpar().getRegion());
        request.getSession().setAttribute(CparConstants.IS_CAR_FLAG, request.getAttribute(CparConstants.IS_CAR_FLAG));

        try {
            createNewCparObject(user, cf, false);
            if (request.getAttribute(CparConstants.IS_CAR_FLAG).equals("true")) {
                cf.getCpar().setCar_flag("Y");
                if (!(request.getAttribute("createCAR") == null || request.getAttribute(CparConstants.IS_CAR_FLAG) == null) &&
                        request.getAttribute("createCAR").equals("true")) {
                    getCARStopSaleData(request, cf.getCpar());
                    request.setAttribute("msg", "false");
                }
            } else {
                getCARStopSaleData(request, cf.getCpar());
                cf.getCpar().setCar_flag("N");
            }
        }
        catch (Exception e) {
            throw new Exception(e);
        }
        forward = postProcessNewCpar(request, cf, user, currentBusinessId);
        return (mapping.findForward(forward));
    }

    public ActionForward sort(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        User user = ((User) request.getSession().getAttribute(User.USER));
        //????
        CparListForm cf = (CparListForm) form;
        getCparFormDefaults(request, actionHelper.getUserBusinessPreference(user), getTypeFromRequest(request), cf.getCparListObject().getRegion());
        getSortValues(request);
        return mapping.findForward("successList");
    }

    private void getCARFindingData(HttpServletRequest request, Cpar cpar) {
        Cpar cparReqObj = (Cpar) request.getAttribute(CparConstants.CPAR_FINDING_OBJ);
        cpar.populateCparFindingData(cpar, cparReqObj);
    }

    private void getCARStopSaleData(HttpServletRequest request, Cpar cpar) {
        Cpar cparReqObj = (Cpar) request.getAttribute("cparStopSaleObj");
        cpar.populateStopSaleData(cpar, cparReqObj);
    }

    /**
     * @param request
     */
    private void setEditValue(HttpServletRequest request, String method) {
        HttpSession session = request.getSession();
        if ("cparNew".equalsIgnoreCase(method) || "cparFindControlNumber".equalsIgnoreCase(method)) {
            session.setAttribute("cparEdit", "false");
            request.setAttribute("paramEditCAR", "false");
            session.setAttribute("paramEditCAR", "false");
        }
        if ("cparEdit".equalsIgnoreCase(method) || "cparSubmit".equalsIgnoreCase(method) || "ciSubmit".equalsIgnoreCase(method)) {
            session.setAttribute("cparEdit", "true");
            request.setAttribute("paramEditCAR", "true");
            session.setAttribute("paramEditCAR", "true");
        }
        User user = (User) session.getAttribute(User.USER);
        session.setAttribute(MCASConstants.ORGANIZATION_LIST, actionHelper.getOrganizationList(user.getLocale(), getUserBusinessId(user)));
    }

    public ActionForward cparEdit(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
            throws Exception {
        String forward = "";
        CparForm cf = (CparForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        boolean isBIOTECHFAS = MCASConstants.APPLICATION_NAME_BIOTECHFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
        Cpar c = cparService.getCpar(request.getParameter("cparId"),isBIOTECHFAS);
        boolean isSBFASCAS = MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
        String[] complaintIdArr = null;
        String complaintEntrytp = "";
        if(cf.getCpar().getComplaint_id() != null){
            if(c.getComplaint_id()!=null&&c.getComplaint_id().length!=cf.getCpar().getComplaint_id().length){
                complaintIdArr = c.getComplaint_id();
            }
            else{
                //complaintIdArr = cf.getCpar().getComplaint_id();
                complaintIdArr = c.getComplaint_id();
            }

            complaintEntrytp = cf.getCpar().getComplaintEntryType();
        }
        c.setOldStatusId(c.getStatus_id());
        c.setRow_user_id(user.getUser_id());
        c.setClosingPersonId(c.getClosingPersonId() == null ? "" : c.getClosingPersonId());
        c.setClosingDate(c.getClosingDate() == null ? "" : c.getClosingDate());
        setAssociatedComplaintEntryType(c);
        setCompleteIssueList(c, user.getLocale());
        cf.setCpar(c);
        setComplaintCategoriesList(c, c.getBusinessId(), true, user.getLocale(),request.getSession().getAttribute("APPLICATION_NAME").toString());
        setCparSubFunctions(c);

        rootCauseService.setCheckboxGroupsForObject(c.getBusinessId(), true, "P", c, c.getCpar_id(), user.getLocale(), user.getPermissionsMap(),request.getSession().getAttribute("APPLICATION_NAME").toString() );
        functionalAreaService.setCheckboxGroupsForObject(c.getBusinessId(), true, "P", c, c.getCpar_id(), user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        setCPAR(request, c);
        request.setAttribute(MCASConstants.CPAR_FILING_PROGRAM, c.getFilingProgramId());
        request.setAttribute(MCASConstants.CPAR_RESPONSIBLE_PROGRAM, c.getResponsibleProgramId());
        getCparFormDefaults(request, c.getBusinessId(), c.getType(), c.getRegion());
        actionHelper.setApplicationInfoMap(request, c.getBusinessId(), getServlet());
        getAuditStopSaleNumber(cf, request);
        forward = "success";
        setEditValue(request, "cparEdit");


        filterLookupsBasedOnUserRegion(c, user, request, getUserBusinessId(user), c.getType());


        String locationCode = c.getResponsible_location();
        sessionHelper.setFunctionLocation(request.getSession(), locationCode);
        if (request.getParameter("fromComplaintOrCpar") != null) {
            if (c.getBusinessId() != getUserBusinessId(user)) {
                request.setAttribute("canViewControls", "false");
            } else {
                request.setAttribute("canViewControls", "true");
            }
        }

        if (request.getAttribute("canViewControls") == null) {
            boolean canViewSaveUpdateControls = isSaveUpdateControlsVisible(user, "cparEdit");
            request.setAttribute("canViewControls", canViewSaveUpdateControls);
        }
        //Security Enhancement.
        if(c.getResponsibleRegionId()!=null){
            actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(c.getResponsibleRegionId()), c.getBusinessId(), user);
            if(request.getAttribute("canViewControls").toString().equalsIgnoreCase("false")){
                actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(c.getRegion()), c.getBusinessId(), user);
            }
        }
        else{
            actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(c.getRegion()), c.getBusinessId(), user);
        }
        request.setAttribute(AuditAction.BUSINESS_ID, c.getBusinessId());
        request.setAttribute("SendEmailVisible", true);

        performGeneralPostProcessing(request, c, c.getBusinessId(), user.getLocale());

        if(complaintIdArr != null){
            cf.getCpar().setComplaint_id(complaintIdArr);
            //cf.getCpar().setComplaintEntryType(complaintEntrytp);
        }
        if(isSBFASCAS == true){
            if(c.getControl_number().contains(SOY_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 1);
            }else if(c.getControl_number().contains(MSP_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 2);
            }else if(c.getControl_number().contains(PAT_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 3);
            }else if(c.getControl_number().contains(COR_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 4);
            }else if(c.getControl_number().contains(COT_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 5);
            }else if(c.getControl_number().contains(CAN_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 6);
            }else if(c.getControl_number().contains(WHE_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 7);
            }else if(c.getControl_number().contains(SUG_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 8);
            }else if(c.getControl_number().contains(BRE_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 9);
            }
            request.setAttribute("IS_EDIT_CPAR_PAGE", "yes");
        }else{
            request.setAttribute(AuditAction.BUSINESS_ID, c.getBusinessId());
        }
        verifyShowingOfModerateCarOption(request,c);

        return (mapping.findForward(forward));
    }

    private void verifyShowingOfModerateCarOption(HttpServletRequest request,Cpar cpar){
        String MODERATE_CAR_ID = "7";
        String MODERATE_CAR_DESC = "Moderate CAR";
        if(isOldRegistryWithModerateCarOption(cpar, MODERATE_CAR_ID)){
            addOldModerateCarOptionInList(request, MODERATE_CAR_ID, MODERATE_CAR_DESC);
        }
    }

    private void addOldModerateCarOptionInList(HttpServletRequest request, String MODERATE_CAR_ID, String MODERATE_CAR_DESC) {
        LinkedHashMap<String,String> map = (LinkedHashMap<String,String>) request.getSession().getAttribute("findingTypeList");
        map.put(MODERATE_CAR_ID,MODERATE_CAR_DESC);
        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST, map);
    }

    private boolean isOldRegistryWithModerateCarOption(Cpar cpar, String MODERATE_CAR_ID) {
        return cpar.getFinding_type().equals(MODERATE_CAR_ID);
    }

    private void setCompleteIssueList(Cpar cpar, String locale) {
        IssueList<Issue> allIssues = issueService.lookupIssuesForRegion(cpar.getRegion(), cpar.getBusinessId(), locale);
        IssueList<Issue> cparIssues = cpar.getIssues();
        for (Issue issue : allIssues) {
            for (Issue cpaIssue : cparIssues) {
                if (issue.getId().equals(cpaIssue.getId()) && cpaIssue.isSelected()) {
                    issue.setSelected(true);
                    break;
                }
            }
        }
        cpar.setIssues(allIssues);
    }

    private void setCparSubFunctions(Cpar c) {

    }

    private void setAssociatedComplaintEntryType(Cpar cpar) {
        if ((cpar.getComplaint_id() != null && cpar.getComplaint_id().length > 0) && !StringUtils.isNullOrEmpty(cpar.getComplaint_id()[0])) {
            cpar.setComplaintEntryType(complaintService.getComplaintEntryType(cpar.getComplaint_id()[0]));
        }
    }

    private void filterLookupsBasedOnUserRegion(Cpar cpar, User user, HttpServletRequest request, int currentBusinessId, int type) throws Exception {
        setApplicationSpecificData(request, type, cpar.getRegion(), null);
        MCASLookupFilterUtil lookupUtil = new MCASLookupFilterUtil();
        lookupUtil.filterLocationLookup(cpar.getFiling_location(), MCASConstants.HELPER_VAR_USER_IN_FILING_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_FILING_LOCATION, user, request, currentBusinessId, ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST);
        lookupUtil.filterLocationLookup(cpar.getResponsible_location(), MCASConstants.HELPER_VAR_USER_IN_RESPONSIBLE_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_RESPONSIBLE_LOCATION, user, request, currentBusinessId, ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST);
        lookupUtil.filterRegionLookup(cpar.getRegion(), MCASConstants.HELPER_VAR_USER_IN_CPAR_REGION,
                MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION, user, request, ActionHelperConstants.REGION_LIST_FOR_NEW_COMPLAINTS);
    }

    public ActionForward cparSubmit(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
            throws Exception {
        CparForm cf = (CparForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        boolean isSBFASCAS = MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
        boolean foundControlNumber = false;
        MCASLogUtil.logError("Found control number initial still false",new Exception());
        String[] complaintIdArr = null;
        if(cf.getCpar().getComplaint_id() != null){
            complaintIdArr = cf.getCpar().getComplaint_id();
        }
        Cpar cpar = initializeCpar(cf, user, (String) request.getSession().getAttribute("APPLICATION_NAME"));
        MCASLogUtil.logError("After initializeCpar foundControlNumber "+foundControlNumber,new Exception());
        setCompleteIssueList(cpar, user.getLocale());

        ActionErrors errors = performCparPreProcessing(request, cpar);
        if (!errors.isEmpty()) {
            int businessId = cpar.getBusinessId();
            getCparFormDefaults(request, businessId, cpar.getType(), cpar.getRegion());
            sessionHelper.setFunctionLocation(request.getSession(), cpar.getResponsible_location());
            return mapping.findForward("failure");
        }

        //reset things maps/lists that are specific to CAR vs. PAR
        //setApplicationSpecificData(request);

        CheckboxItemServiceImpl.getSelectedCheckboxItems(cf.getCpar(), (Map<String, String[]>) request.getParameterMap(), "cpar.functionalAreaList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(cf.getCpar(), (Map<String, String[]>) request.getParameterMap(), "cpar.nonconformanceCategoryList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(cf.getCpar(), (Map<String, String[]>) request.getParameterMap(), "rootCauseList");

//        logger.info(
//                "START : ****User ID****:" + user.getUser_id() + ":****Business ID****:" + cpar.getBusinessId() +
//                        ":****User Role****:" + user.getPermissionsMap() +
//                        ":****Method****:" + getClass() + "cparSubmit()" +
//                        ":****Drop Down Region List****:" + request.getSession().getAttribute(ActionHelperConstants.REGION_LIST) +
//                        ":****Viewable Region List****:" +
//                        request.getSession().getAttribute(MCASConstants.HELPER_VAR_VIEWABLE_CPAR_REGION));

        ControlNumberService cons = getControlNumberService();
        MCASLogUtil.logError("After getControlNumberService cons: "+cons,new Exception());
        if (cpar != null) {
            setSuppressOverDueNotice(request, cpar);
            setActionItemsComplete(request, cpar);
            if (request.getSession().getAttribute("cparEdit").equals("true")) {
                cparService.updateCpar(cpar);
                setComplaintCategoriesList(cpar, cpar.getBusinessId(), true, user.getLocale(),request.getSession().getAttribute("APPLICATION_NAME").toString());
                rootCauseService.setCheckboxGroupsForObject(cpar.getBusinessId(), true, "P", cpar, cpar.getCpar_id(), user.getLocale(), user.getPermissionsMap(),request.getSession().getAttribute("APPLICATION_NAME").toString() );
                functionalAreaService.setCheckboxGroupsForObject(cpar.getBusinessId(), true, "P", cpar, cpar.getCpar_id(), user.getLocale(), user.getPermissionsMap(), request.getSession().getAttribute("APPLICATION_NAME").toString());
            } else {

                boolean isMCAS = MCASConstants.APPLICATION_NAME_MCAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
                boolean isSBFAS = MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
                boolean isBIOTECHFAS = MCASConstants.APPLICATION_NAME_BIOTECHFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
                foundControlNumber = cons.generateControlNumber(cpar, isMCAS, isSBFAS, isBIOTECHFAS);
                MCASLogUtil.logError("After generateControlNumber : "+foundControlNumber,new Exception());
                if (!foundControlNumber) {
                    request.setAttribute("errorMsg", String.valueOf(foundControlNumber));
                    return mapping.findForward("failure");
                } else {
                    MCASLogUtil.logError("If found control number is false we never should get to this line" , new Exception());
                    //CIs are only type 4 (CI) in SBFAS and MCAS.  Otherwise they are type 2, PAR.
                    //That doesn't make much sense, but when entering/filtering, CI is just a flag on a PAR record for the other apps.
                    if (MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"))
                            || MCASConstants.APPLICATION_NAME_MCAS.equals(request.getSession().getAttribute("APPLICATION_NAME"))) {
                        if ("2".equals(request.getParameter("cpar.continual_Improvements")))
                            cpar.setType(CparConstants.GEN_FINDING_OBJ_TYPE_CI);
                    }

                    if (cpar.getType() == CparConstants.GEN_FINDING_OBJ_TYPE_CI) {
                        cpar.setReport_date(sdf.format(new java.util.Date()));
                    }

                    cparService.insertCpar(cpar);
                }
            }
            //If the CPAR was edited/created correctly and a new Investigation Findings Person was assign it sends and email
            boolean isBIOTECHFAS = MCASConstants.APPLICATION_NAME_BIOTECHFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
            if(isBIOTECHFAS){
                if(cpar.getType() != CPAR_CI_TYPE){
                    if (cpar.getInvestigation_findings_person() != null && !"".equals(cpar.getInvestigation_findings_person())) {
                        if (!cpar.getInvestigation_findings_person().equals(request.getParameter("oldInvestigationFindingsPerson")))
                            emailInvestigationFindingPerson(cpar, true);
                    }
                }
            }else{
                if (cpar.getInvestigation_findings_person() != null && !"".equals(cpar.getInvestigation_findings_person())) {
                        if (!cpar.getInvestigation_findings_person().equals(request.getParameter("oldInvestigationFindingsPerson")))
                            emailInvestigationFindingPerson(cpar, false);
                    }
            }
        }

        performGeneralPostProcessing(request, cpar, cpar.getBusinessId(), user.getLocale());

        performApplicationSpecificPostProcessing(cpar, request);
        getAuditStopSaleNumber(cf, request);
        if (foundControlNumber) {
            setEditValue(request, "cparSubmit");
             rootCauseService.setCheckboxGroupsForObject(cpar.getBusinessId(), true, "P", cpar, cpar.getCpar_id(), user.getLocale(), user.getPermissionsMap(),request.getSession().getAttribute("APPLICATION_NAME").toString() );
        }

        //System.out.println("+++++====>" + cf.getCpar().getComplaint_id()[0]);
        if(complaintIdArr != null){
            cf.getCpar().setComplaint_id(complaintIdArr);
            cpar.setComplaint_id(complaintIdArr);
        }
        if(isSBFASCAS == true){
            if(cpar.getControl_number().contains(SOY_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 1);
            }else if(cpar.getControl_number().contains(MSP_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 2);
            }else if(cpar.getControl_number().contains(PAT_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 3);
            }else if(cpar.getControl_number().contains(COR_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 4);
            }else if(cpar.getControl_number().contains(COT_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 5);
            }else if(cpar.getControl_number().contains(CAN_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 6);
            }else if(cpar.getControl_number().contains(WHE_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 7);
            }else if(cpar.getControl_number().contains(SUG_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 8);
            }else if(cpar.getControl_number().contains(BRE_BUSINESS)){
                request.setAttribute(AuditAction.BUSINESS_ID, 9);
            }
            request.setAttribute("IS_EDIT_CPAR_PAGE", "yes");
        }else{
            request.setAttribute(AuditAction.BUSINESS_ID, cpar.getBusinessId());
        }
        return isAttachmentAction(mapping, request, cpar);
    }

//    private void setSelectedFunctionalAreas(Cpar cpar, int businessId, boolean isEdit, User user) {
//
////        List<CheckboxItem> functionalAreasList = new ArrayList();
////
////        functionalAreaImporter.initializeFunctionalAreas(AuditConstants.C_AUDIT_AREA_LIST, complaint.getFunctionalAreaList(), functionalAreasList);
////        complaint.setSelectedFunctionalAreas(functionalAreasList);
//        functionalAreaService.setCheckboxGroupsForObject(cpar, cpar.getCpar_id(), businessId, isEdit, "P", user.getLocale(), user.getPermissionsMap());
//    }
//
//    private void setSelectedNonconformanceCategories(Cpar cpar, int businessId, boolean isEdit, User user) {
////        List<CheckboxItem> nonconformanceCategoryList = new ArrayList<CheckboxItem>();
////        functionalAreaImporter.initializeFunctionalAreas("c.nonconformanceCategoryList", complaint.getNonconformanceCategoryList(), nonconformanceCategoryList);
////        complaint.setSelectedNonconformanceList(nonconformanceCategoryList);
//        nonconformanceCategoryService.setCheckboxGroupsForObject(cpar, cpar.getCpar_id(), businessId, isEdit, "P", user.getLocale(), user.getPermissionsMap());
//
//    }

    protected ControlNumberService getControlNumberService() {
        return new ControlNumberServiceImpl();
    }

    private void setSuppressOverDueNotice(HttpServletRequest request, Cpar cpar) {
        boolean cparSuppressOverDueNotice =
                !StringUtils.isNullOrEmpty(request.getParameter("cpar.suppress_overdue_notice")) ? true : false;
        cpar.setSuppress_overdue_notice(cparSuppressOverDueNotice);
    }

    private void setActionItemsComplete(HttpServletRequest request, Cpar cpar) {
        boolean actionItemsComplete =
                !StringUtils.isNullOrEmpty(request.getParameter("cpar.long_term_corrective_action_items_complete")) ? true : false;
        cpar.setLong_term_corrective_action_items_complete(actionItemsComplete);
    }

    private ActionForward isAttachmentAction(ActionMapping mapping, HttpServletRequest request, Cpar cpar) {
        if (actionIsAddAttachment(request, cpar)) {
            return mapping.findForward(MCASConstants.FORWARD_MAPPING_ADD_ATTACHMENT_PG);
        } else {
            request.setAttribute("SendEmailVisible", true);
            if (request.getSession().getAttribute("cparEdit").equals("true")) {
                request.getSession().setAttribute("paramEditCAR", "true");
            } else {
                request.getSession().setAttribute("paramEditCAR", "false");
            }

            return (mapping.findForward("success"));
        }
    }

    private void performApplicationSpecificPostProcessing(Cpar cpar, HttpServletRequest request) {
        try {
            CparProcessor processor = getCparProcessor((String) request.getSession().getAttribute("APPLICATION_NAME"));
            try {
                processor.postProcessCpar(cpar, request);
            } catch (ServiceException se) {
                request.setAttribute("WARNING_MESSAGE", se.getMessage());
            }
            setRequestAttributes(request);
            request.setAttribute(MCASConstants.CPAR_FILING_PROGRAM, cpar.getFilingProgramId());
            request.setAttribute(MCASConstants.CPAR_RESPONSIBLE_PROGRAM, cpar.getResponsibleProgramId());
            performDefaultPostOperations(request, cpar);
            setReadOnlyFlag(request.getSession(), (User) request.getSession().getAttribute(User.USER));
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    private void performDefaultPostOperations(HttpServletRequest request, Cpar cpar) {
        setCPAR(request, cpar);
        sessionHelper.setFunctionLocation(request.getSession(), cpar.getResponsible_location());
    }

    private void setRequestAttributes(HttpServletRequest request) throws Exception {
        User user = (User) request.getSession().getAttribute(User.USER);
        request.setAttribute("msg", "true");
        request.setAttribute(AuditAction.BUSINESS_ID, "" + getUserBusinessId(user));
        boolean canViewSaveUpdateControls = isSaveUpdateControlsVisible(user, "cparSubmit");
        request.setAttribute("canViewControls", canViewSaveUpdateControls);
        request.setAttribute("isCparSaved", "true");
    }

    private Cpar initializeCpar(CparForm cf, User user, String appName) throws ServiceException {
        Cpar cpar = cf.getCpar();

        //SBFAS allows the user to select the business ID in the form.
        if (!MCASConstants.APPLICATION_NAME_SBFAS.equals(appName)) {
            cpar.setBusinessId(getUserBusinessId(user));
        }

        return cpar;
    }

    private ActionErrors performCparPreProcessing(HttpServletRequest request, Cpar cpar) throws Exception {

        if (cpar != null)
            performGeneralPreProcessing(request);

        ActionErrors errors = performApplicationSpecificPreProcessing(request, cpar);
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            request.setAttribute("SendEmailVisible", false);
        }
        return errors;
    }

    private ActionErrors performApplicationSpecificPreProcessing(HttpServletRequest request, Cpar cpar) throws Exception {
        final String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        CparProcessor processor = getCparProcessor(applicationName);
        ActionErrors allErrors = new ActionErrors();
        ActionErrors errors = processor.processCpar(cpar, getType(request), request);
        allErrors.add(errors);
        MCASLogUtil.logError("Exit perform Application Specific control number: "+cpar.getControl_number(),new Exception());
        return allErrors;
    }

    private int getType(HttpServletRequest request) {
        String type = request.getParameter(CparConstants.CPAR_CHANGE_TO);
        if (StringUtils.isNullOrEmpty(type)) {
            if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CPAR_TYPE))) {
                type = request.getParameter(CparConstants.CPAR_TYPE);
            } else if (!StringUtils.isNullOrEmpty(request.getParameter("cpar." + CparConstants.CPAR_TYPE))) {
                type = request.getParameter("cpar." + CparConstants.CPAR_TYPE);
            } else {
                return (Integer) request.getAttribute(CparConstants.CPAR_TYPE);
            }
        }
        return Integer.parseInt(type);
    }

    private CparProcessor getCparProcessor(String applicationName) throws ServiceException {
        return getApplicationProcessor().getApplicationSpecificProcessor(applicationName)
                .getCparProcessor();
    }

    protected ApplicationSpecificProcessorFactory getApplicationProcessor() {
        return new ApplicationSpecificProcessorFactoryImpl();
    }


    private boolean actionIsAddAttachment(HttpServletRequest request, Cpar cpar) {
        if (!StringUtils.isNullOrEmpty(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE)
                && "true".equalsIgnoreCase(request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE))) {
            request.setAttribute(MCASConstants.REQUEST_VAR_ENTITY_ID, cpar.getCpar_id());
            request.getSession()
                    .setAttribute(MCASConstants.HELPER_VAR_ENTITY_TYPE, MCASConstants.STRATEGY_MAP_KEY_CPAR_ENTITY);
            return true;
        }
        return false;
    }

    private void getCparFormDefaults(HttpServletRequest request, int currentBusinessId, int type, String regionId) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) request.getSession().getAttribute(User.USER);
        String userId = user.getUser_id();
        int businessPreferenceId = actionHelper.getUserBusinessPreference(user);
        session.setAttribute(ActionHelperConstants.CPAR_ROLE_STATUS_LIST, null);
        Map<String, String> map = actionHelper.getLocationList(currentBusinessId, user.getLocale());
        session.setAttribute(ActionHelperConstants.LOCATION_LIST, map);

        setApplicationSpecificData(request, type, regionId,null);

        if (session.getAttribute(ActionHelperConstants.EVALUATOR_LIST) == null)
            session.setAttribute(ActionHelperConstants.EVALUATOR_LIST, actionHelper.getEvaluatorList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
            session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));

        if (session.getAttribute(ActionHelperConstants.ISO_STANDARD_LIST) == null)
            session.setAttribute(ActionHelperConstants.ISO_STANDARD_LIST, actionHelper.getIsoStandardList(user.getLocale(), businessPreferenceId, null));
        if (session.getAttribute(ActionHelperConstants.QUALITY_STANDARD_LIST) == null)
            session.setAttribute(ActionHelperConstants.QUALITY_STANDARD_LIST, actionHelper.getQualityStandardList(user.getLocale(), businessPreferenceId));
        if (session.getAttribute(ActionHelperConstants.CPAR_ROLE_STATUS_LIST) == null)
            session.setAttribute(ActionHelperConstants.CPAR_ROLE_STATUS_LIST, actionHelper.getStatusListByRole("CPAR", user.getLocale(), user.getPermissionsMap()));
        //Obtain the Regions Based on the User's Business Preference Id
        if (session.getAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST) != null) {
            session.removeAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST);
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                    actionHelper.getRegionsForSearch(userId, businessPreferenceId, false, user.getLocale()));
        } else {
            session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                    actionHelper.getRegionsForSearch(userId, businessPreferenceId, false, user.getLocale()));
        }

        session.setAttribute(ActionHelperConstants.REGION_LIST,
                getRegionService().getRegionList(userId, currentBusinessId, user.getLocale()));
        session.setAttribute(ActionHelperConstants.ALL_REGION_LIST,
                getRegionService().getAllRegionList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.EVAL_EFFECTIVE_LIST) == null)
            session
                    .setAttribute(ActionHelperConstants.EVAL_EFFECTIVE_LIST, actionHelper.getEvalEffectiveList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.CONTINUAL_IMPROVEMENTS_LIST) == null)
            session.setAttribute(ActionHelperConstants.CONTINUAL_IMPROVEMENTS_LIST,
                    actionHelper.getContinualImprovementsList(user.getLocale()));

        ComplaintBusinessService complaintBusinessService = getComplaintBusinessService();
        Map<String, String> complaintBusinessReferenceDataMap = complaintBusinessService
                .getComplaintBusinessReferenceData(user.getLocale());
        session.setAttribute("complaintBusiness", complaintBusinessReferenceDataMap);


        Map mapIssues = issueCategoryService.lookUpIssueCategory(1, user.getLocale(), "P");
        session.setAttribute("ISSUE_CATEGORY", mapIssues);

        session.setAttribute(ActionHelperConstants.CROP_LIST_FOR_NEW_CPAR,
                actionHelper.getBusinessRelatedCrops(currentBusinessId, user.getLocale()));

        sessionHelper.setEmptyFunctionList(session);
    }

    protected ComplaintBusinessService getComplaintBusinessService() {
        return new ComplaintBusinessServiceImpl(dataSource);
    }

    protected RegionService getRegionService() {
        return new RegionServiceImpl();
    }

    public void setApplicationSpecificData(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {
        CparProcessor processor = getCparProcessor((String) request.getSession().getAttribute("APPLICATION_NAME"));
        if(request.getSession().getAttribute("APPLICATION_NAME").toString().equalsIgnoreCase("mcas")&&type==4){
           processor.setCparDefaultValues(request, type, regionId, regionId);
        }
        else if(regionResponsibleId==null||regionResponsibleId.equalsIgnoreCase("")){
             processor.setCparDefaultValues(request, type, regionId, regionId);
        }
        else{
            processor.setCparDefaultValues(request, type, regionId, regionResponsibleId);
        }
    }

    private void setCPAR(HttpServletRequest request, Cpar cpar) {
        processCparConversion(request, cpar);
        String cparFlag = "Y".equals(cpar.getCar_flag()) ? "true" : "false";
        request.getSession().setAttribute(CparConstants.IS_CAR_FLAG, cparFlag);
        request.getSession().setAttribute(CparConstants.CPAR_TYPE, cpar.getType());
    }

    private void processCparConversion(HttpServletRequest request, Cpar cpar) {
        String typeToConvert = request.getParameter("changeTo");
        if (!StringUtils.isNullOrEmpty(typeToConvert)) {
            cpar.setType(Integer.parseInt(typeToConvert));
            cpar.setGenerator("");
            cpar.setFinding_type("");
            ControlNumberService service = getControlNumberService();

            boolean isMCAS = MCASConstants.APPLICATION_NAME_MCAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
            boolean isSBFAS = MCASConstants.APPLICATION_NAME_SBFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
            boolean isBIOTECHFAS = MCASConstants.APPLICATION_NAME_BIOTECHFAS.equals(request.getSession().getAttribute("APPLICATION_NAME"));
            service.generateControlNumber(cpar, isMCAS, isSBFAS, isBIOTECHFAS);
        }
    }


    private void getAuditStopSaleNumber(CparForm cf, HttpServletRequest request) {
        if (!StringUtils.isNullOrEmpty(cf.getCpar().getAudit_finding_id())) {
            String tempAuditNo = "";
            try {
                AuditService as = (AuditService) ServiceLocator.locateService(AuditService.class);
                tempAuditNo = as.getAuditNumberFromFinding(Integer.parseInt(cf.getCpar().getAudit_finding_id()));
                cf.getCpar().setAudit_number(tempAuditNo);
            }
            catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
            request.getSession().setAttribute("tempAuditNo", tempAuditNo);
        }
        if (cf.getCpar().getStop_sale_id() != null && !cf.getCpar().getStop_sale_id().equals("")) {
            String tempStopSaleNo = "";
            try {
                StopSaleService ss = (StopSaleService) ServiceLocator.locateService(StopSaleService.class);
                tempStopSaleNo = ss.getStopSaleNumberFromID(Integer.parseInt(cf.getCpar().getStop_sale_id()));
                cf.getCpar().setStop_sale_number(tempStopSaleNo);
            }
            catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
            request.getSession().setAttribute("tempStopSaleNo", tempStopSaleNo);
        }
    }

    /**
     * To get the sortCriteria and determine the sortOrder.
     *
     * @param request
     */
    private void getSortValues(HttpServletRequest request) {
        sortOrder = "asc";
        sortCriteria = request.getParameter("sortCriteria");
        String lastSortCriteria = (String) request.getSession().getAttribute(CparConstants.LAST_CPAR_SORT_CRITERIA);
        if (!StringUtils.isNullOrEmpty(sortCriteria) && sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
            sortOrder = request.getSession().getAttribute(CparConstants.LAST_CPAR_SORT_ORDER) + "";
            sortOrder = "asc".equalsIgnoreCase(sortOrder) ? "desc" : "asc";
        }
        request.getSession().setAttribute(CparConstants.LAST_CPAR_SORT_CRITERIA, sortCriteria);
        request.getSession().setAttribute(CparConstants.LAST_CPAR_SORT_ORDER, sortOrder);
    }

    /**
     * Method used to set the complaint categories
     *
     * @param c
     * @param businessId
     * @param isEdit
     * @throws Exception
     */

//not really sure why this is needed.  Do I need to put root causes here??
    private void setComplaintCategoriesList(Cpar c, int businessId, boolean isEdit, String locale, String appName) {
        Map<Integer, NonconformanceType> nonconformanceTypeMap = new HashMap<Integer, NonconformanceType>();
        List<CheckboxGroup> nonconformanceCategoryList = nonconformanceCategoryService.lookupCheckboxGroups(businessId, isEdit, "P", c.getCpar_id(),
                locale, null, appName);

        if (nonconformanceCategoryList != null && nonconformanceCategoryList.size() > 0) {
            c.setNonconformanceCategoryList(nonconformanceCategoryList);
            for (CheckboxGroup aNonconformanceCategoryList : nonconformanceCategoryList) {
                c.setFunctionalArea(aNonconformanceCategoryList);
            }
        }
        //Method to Populate the Tab names and Description
        if (nonconformanceTypeMap != null && nonconformanceTypeMap.size() > 0) {
            c.setNonconformanceTypeMap(nonconformanceTypeMap);
        }
    }

    public ActionForward cparDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request,
                                    HttpServletResponse response) throws Exception {
        String forward = "deleteFailure";
        boolean isCparDeleted = false;
        String cparId = request.getParameter("cparIdToDelete");
        if (!StringUtils.isNullOrEmpty(cparId)) {
            Cpar cparObject = cparService.getCpar(cparId, false);
            isCparDeleted = cparService.deleteCpar(cparObject);
        }
        if (isCparDeleted) {
            forward = "deleteSuccess";
        }
        return mapping.findForward(forward);
    }

    private void emailInvestigationFindingPerson(Cpar cpar, boolean toAdmin) {
        EmailService emailService = new EmailService();
        try {

            emailService.sendEmailToCPARResponsible(cpar, toAdmin);
        }
        catch (EmailException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    private void performGeneralPreProcessing(HttpServletRequest request) {

        String regionId = request.getParameter(CparConstants.CPAR_ENTRY_REGION);
        SessionHelper.setSelectedRegion(request.getSession(), regionId);

        String regionResponsibleId = request.getParameter(CparConstants.CPAR_ENTRY_REGION_RESPONSIBLE);

        SessionHelper.setSelectedRegionResponsible(request.getSession(), regionResponsibleId);
    }

    private void performGeneralPostProcessing(HttpServletRequest request, Cpar cpar, int businessId, String locale) {
        setReadOnlyFlag(request.getSession(), (User) request.getSession().getAttribute(User.USER));
        request.getSession().setAttribute(ActionHelperConstants.ISO_STANDARD_LIST,
                actionHelper.getIsoStandardList(locale, businessId, cpar.getQuality_standard()));

        CparProcessor processor = getCparProcessor((String) request.getSession().getAttribute("APPLICATION_NAME"));
        try {
            processor.setCparDynamicValues(cpar, request);
        } catch (Exception e) {
            request.setAttribute("WARNING_MESSAGE", e.getMessage());
        }
    }

    protected void setReadOnlyFlag(HttpSession session, User user) {
        ApplicationSpecificFactory factory = (getApplicationProcessor()).getApplicationSpecificProcessor((String) session.getAttribute(MCASConstants.APPLICATION_NAME));
        ApplicationSecurityProcessor securityProcessor = factory.getApplicationSecurityProcessor();

        final CparForm form = (CparForm) session.getAttribute(CPAR_FORM);

        if (form == null || form.getCpar() == null) {
            session.setAttribute(MCASConstants.READ_ONLY, false);
            session.setAttribute(MCASConstants.CA_READ_ONLY, false);
            session.setAttribute(MCASConstants.RC_READ_ONLY, false);
            session.setAttribute(MCASConstants.LT_READ_ONLY, false);
            session.setAttribute(MCASConstants.EE_READ_ONLY, false);
        } else {
            Cpar cpar = form.getCpar();
            session.setAttribute(MCASConstants.READ_ONLY, securityProcessor.isCparReadOnly(form, user));
            session.setAttribute(MCASConstants.CA_READ_ONLY, securityProcessor.isActionItemReadOnly(form, cpar.getContainment_actions_person(), user));
            session.setAttribute(MCASConstants.RC_READ_ONLY, securityProcessor.isActionItemReadOnly(form, cpar.getRoot_cause_person(), user));
            session.setAttribute(MCASConstants.LT_READ_ONLY, securityProcessor.isActionItemReadOnly(form, cpar.getLong_term_corrective_action_person(), user));
            session.setAttribute(MCASConstants.EE_READ_ONLY, securityProcessor.isActionItemReadOnly(form, cpar.getEvaluation_person(), user));
        }
    }

    private void reloadDepartmentProcess(HttpServletRequest request, CparListForm cparListForm) {
        List<SelectedIndex> selectedDepartmentProcess = new AuditRequestHelper().getCheckedIndexes(request.getParameterMap(), "cparListObject.functionalAreaList");
        cparListForm.retainSelectedOrChangedDepartmentProcess(selectedDepartmentProcess);

        CheckboxItemServiceImpl.getSelectedCheckboxItems(cparListForm.getCparListObject(), (Map<String, String[]>) request.getParameterMap(), "cparListObject.functionalAreaList");
    }

    public ActionForward cparListReset(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        final HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        CparListForm cparListForm = (CparListForm) form;
        cparListForm.setCparListObject(new CparListObject());
        cparListForm.setCparsList(new HashMap());
        sessionHelper.setEmptyFunctionList(session);
        sessionHelper.setAuditTypeMap(session);
        int businessId = getUserBusinessId(user);

        functionalAreaService.setCheckboxGroupsForObject(businessId, false, "P", cparListForm.getCparListObject(), null, user.getLocale(), user.getPermissionsMap(),request.getSession().getAttribute("APPLICATION_NAME").toString() );

        //**Reset sort-order
        resetSortOrder(request);
        setType(request, cparListForm);
        return mapping.findForward("successList");
    }

    private void resetSortOrder(HttpServletRequest request) {
        request.getSession().setAttribute("lastAuditSortOrder", "dec");
    }
}
