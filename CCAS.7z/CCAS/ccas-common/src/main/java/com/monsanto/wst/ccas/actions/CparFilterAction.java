//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.CparFilterForm;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactory;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactoryImpl;
import com.monsanto.wst.ccas.app.CparProcessor;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exportTool.ExportClass;
import com.monsanto.wst.ccas.model.NonconformanceType;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.ExportBean;
import com.monsanto.wst.ccas.taglib.reportTag.ReportTag;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * MyEclipse Struts Creation date: 06-15-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/cparFilter" name="cparFilterForm"
 */
public class CparFilterAction extends DispatchAction {

    private static final Category logger = Category.getInstance(CparFilterAction.class.getName());
    private static String fileName;
    private static String sheetName;
    private final BusinessService service;
    private final IActionHelper actionHelper;
    private final SessionHelper sessionHelper;
    private final DataSource source;
    private final CheckboxItemDao functionalAreaDAO;
    private final CheckboxItemService functionalAreaService;
    private final CheckboxItemService nonconformanceCategoryService;
    private final CheckboxItemService rootCauseService;

    public CparFilterAction() {
        service = new BusinessServiceImpl();
        actionHelper = new ActionHelper();
        sessionHelper = new SessionHelper();
        source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionalAreaDAO = new FunctionalAreaDaoImpl(source);
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
    }

    public CparFilterAction(BusinessService service, ActionHelper actionHelper, SessionHelper sessionHelper,
                            DataSource source, CheckboxItemDao functionalAreaDAO, CheckboxItemService functionalAreaService,
                            ComplaintService complaintService, CheckboxItemService nonconformanceService, CheckboxItemService rootCauseService) {
        this.service = service;
        this.actionHelper = actionHelper;
        this.sessionHelper = sessionHelper;
        this.source = source;
        this.functionalAreaDAO = functionalAreaDAO;
        this.functionalAreaService = functionalAreaService;
        this.nonconformanceCategoryService = nonconformanceService;
        this.rootCauseService = rootCauseService;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        CparFilterForm cparFilterForm = (CparFilterForm) form;

//    logger.info("carReport = " + request.getParameter("carReport"));
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        actionHelper.setApplicationInfoMap(request, businessId, getServlet());
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        if (request.getParameter("carReport") != null) {
            request.getSession().setAttribute("carReport", request.getParameter("carReport"));
        } else {
            return mapping.findForward("faliure");  //**This will take it to reporting page where user can select car/par
        }

        try {
            String region = "";
            if (cparFilterForm.getCparFilter().getRegion() != null) {
                region = cparFilterForm.getCparFilter().getRegion()[0];
            }

            getCparFormDefaults(request, Integer.parseInt(request.getParameter(CparConstants.CPAR_TYPE)), region);
            populateCheckboxItems(cparFilterForm, user, businessId, request.getSession().getAttribute("APPLICATION_NAME").toString());

        }
        catch (Exception ex) {
            MCASLogUtil.logError("Error populating the lists", ex);
        }

        return mapping.findForward("success");
    }

    private void populateCheckboxItems(CparFilterForm cparFilterForm, User user, int businessId, String appName) {
        Map<Integer, NonconformanceType> nonconformanceTypeMap = new HashMap<Integer, NonconformanceType>();
        nonconformanceCategoryService.setCheckboxGroupsForObject(businessId, false, CparConstants.SOURCE_TYPE_CPAR, cparFilterForm.getCparFilter(), null, user.getLocale(), null,appName );
        rootCauseService.setCheckboxGroupsForObject(businessId, false, CparConstants.SOURCE_TYPE_CPAR, cparFilterForm.getCparFilter(), null, user.getLocale(), null, appName);
        functionalAreaService.setCheckboxGroupsForObject(businessId, false, MCASConstants.ENTRY_TYPE_DEFAULT, cparFilterForm.getCparFilter(), null,
                user.getLocale(), user.getPermissionsMap(), appName);
    }

    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        CparFilterForm cparFilterForm = (CparFilterForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        populateCheckboxItems(cparFilterForm, user, businessId,request.getSession().getAttribute("APPLICATION_NAME").toString() );

        //**Set the Car Flag...
        if (request.getSession().getAttribute("carReport").toString().equalsIgnoreCase("true")) {
            cparFilterForm.getCparFilter().setCarFlag("Y");
        } else {
            cparFilterForm.getCparFilter().setCarFlag("N");
        }

        //**1. Call the getCparReportList() Service/DAO to get HashMap of Data (hash)
        Map<String, RowBean> hash = new HashMap<String, RowBean>();

        try {
            CparService cs = (CparService) ServiceLocator.locateService(CparService.class);
            hash = cs.getCparReport(cparFilterForm.getCparFilter(), businessId, request.getParameterMap(), user.getLocale());
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

        //**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the cparFilter FormBean.
        cparFilterForm.setHash(hash);

        String file = "";
        InputStream xmlIn = null;
        try {
            file = McasProperties.getMcasProperties().getString("cpar.reportStructure");
            ClassLoader classLoader = CparFilterAction.class.getClassLoader();
            xmlIn = classLoader.getResourceAsStream(file);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        cparFilterForm.setXmlIn(xmlIn);

        cparFilterForm.setSortBy("col1");
        cparFilterForm.setSortOrder("asc");

        return mapping.findForward("success");
    }

    /**
     * Method export
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward export(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

//    logger.info("Export to Excel called...");

        //**The Export Functionality...
        ServletOutputStream sos = null;
        BufferedOutputStream bos = null;

        try {

            ExportBean exportBean = ReportTag.getExportData();

            fileName = exportBean.getExcelFileName();
            sheetName = exportBean.getExcelSheetName();

            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "filename=" + fileName);

            sos = response.getOutputStream();
            bos = new BufferedOutputStream(sos);

            ExportClass export2Excel = new ExportClass();

            //**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector...
            export2Excel.setSheetName(sheetName);
            export2Excel.setTotalFields(exportBean.getTotalFields());
            export2Excel.setColHeader(exportBean.getExportColHeader());
            export2Excel.setVector(exportBean.getExportDataVector());

            export2Excel.setBos(bos);

            export2Excel.exportExcel();

            bos = export2Excel.getBos();

            bos.flush();
        }
        catch (Exception ex) {
            MCASLogUtil.logError("-> Error exporting Cpar Report.", ex);
        }
        finally {
            MCASResourceUtil.closeResource(bos);
            MCASResourceUtil.closeResource(sos);
        }

//    logger.info("-> Excel file created.");

        return mapping.findForward("success");
    }

    private void getCparFormDefaults(HttpServletRequest request, int type, String regionId) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        session.setAttribute(ActionHelperConstants.CPAR_STATUS_LIST, null);
        if (session.getAttribute(ActionHelperConstants.LOCATION_LIST) == null)
            session.setAttribute(ActionHelperConstants.LOCATION_LIST,
                    actionHelper.getLocationList(businessId, user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.EVALUATOR_LIST) == null)
            session.setAttribute(ActionHelperConstants.EVALUATOR_LIST, actionHelper.getEvaluatorList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
            session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.ISO_STANDARD_LIST) == null)
            session.setAttribute(ActionHelperConstants.ISO_STANDARD_LIST, actionHelper.getIsoStandardList(user.getLocale(), businessId, null));
        if (session.getAttribute(ActionHelperConstants.CPAR_STATUS_LIST) == null)
            session.setAttribute(ActionHelperConstants.CPAR_STATUS_LIST, actionHelper.getAllStatusList("CPAR", user.getLocale()));
        if (session.getAttribute(ActionHelperConstants.QUALITY_STANDARD_LIST) == null)
                    session.setAttribute(ActionHelperConstants.QUALITY_STANDARD_LIST, actionHelper.getQualityStandardList(user.getLocale(), businessId));
                

        if (session.getAttribute(ActionHelperConstants.REGION_LIST) == null) {
            String userId = user.getUser_id();
            session.setAttribute(ActionHelperConstants.REGION_LIST,
                    new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale()));
        }
        ComplaintBusinessService complaintBusinessService = new ComplaintBusinessServiceImpl(source);
        Map<String, String> complaintBusinessReferenceDataMap = complaintBusinessService
                .getComplaintBusinessReferenceData(user.getLocale());
        session.setAttribute("complaintBusiness", complaintBusinessReferenceDataMap);
        setApplicationSpecificData(request, type, regionId);
        sessionHelper.setEmptyFunctionList(session);
    }

    private void setApplicationSpecificData(HttpServletRequest request, int type, String regionId) throws Exception {
        ApplicationSpecificProcessorFactory applicationSpecificProcessorFactory =
                new ApplicationSpecificProcessorFactoryImpl();
        String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        CparProcessor processor =
                applicationSpecificProcessorFactory.getApplicationSpecificProcessor(applicationName).getCparProcessor();
        processor.setCparDefaultValues(request, type, regionId,null);
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return service.getBusinessId(user);
    }
}
