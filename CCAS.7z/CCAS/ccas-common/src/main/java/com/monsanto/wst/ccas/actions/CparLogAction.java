//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.CparLogForm;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.exportTool.ExportClass;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.taglib.reportTag.ExportBean;
import com.monsanto.wst.ccas.taglib.reportTag.ReportTag;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;

/**
 * MyEclipse Struts Creation date: 07-14-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/cparLog" name="cparLogForm" scope="request"
 */
public class CparLogAction extends DispatchAction {

    private static final Category logger = Category.getInstance(CparFilterAction.class.getName());

    private static String fileName;
    private static String sheetName;
    private final BusinessService service;
    private final IActionHelper actionHelper;
    private final RegionService regionService;
    private final SessionHelper sessionHelper;
    private final CparService cparService;

    public CparLogAction() {
        service = new BusinessServiceImpl();
        actionHelper = new ActionHelper();
        regionService = new RegionServiceImpl();
        sessionHelper = new SessionHelper();
        cparService = new CparServiceImpl();
    }

    public CparLogAction(BusinessService service, IActionHelper actionHelper, RegionService regionService,
                         SessionHelper sessionHelper, CparService cparService) {
        this.service = service;
        this.actionHelper = actionHelper;
        this.regionService = regionService;
        this.sessionHelper = sessionHelper;
        this.cparService = cparService;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        CparLogForm cparLogForm = (CparLogForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        getCparFormDefaults(request, getUserBusinessId(user));
        cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
        return mapping.findForward("success");
    }

    /**
     * Method export
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward export(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        CparLogForm cparLogForm = (CparLogForm) form;

        //**The Export Functionality...
        ServletOutputStream sos = null;
        BufferedOutputStream bos = null;

        try {

            ExportBean exportBean = ReportTag.getExportData();

            fileName = exportBean.getExcelFileName();
            sheetName = exportBean.getExcelSheetName();

            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "filename=" + fileName);

            sos = response.getOutputStream();
            bos = new BufferedOutputStream(sos);

            ExportClass export2Excel = new ExportClass();

            //**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector...
            export2Excel.setSheetName(sheetName);
            export2Excel.setTotalFields(exportBean.getTotalFields());
            export2Excel.setColHeader(exportBean.getExportColHeader());
            export2Excel.setVector(exportBean.getExportDataVector());

            export2Excel.setBos(bos);

            export2Excel.exportExcel();

            bos = export2Excel.getBos();

            bos.flush();
        }
        catch (Exception ex) {
            MCASLogUtil.logError("-> Error exporting Cpar Log Report.", ex);
        }
        finally {
            MCASResourceUtil.closeResource(bos);
            MCASResourceUtil.closeResource(sos);
        }

//    logger.info("-> Excel file created.");

        cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
        return mapping.findForward("submit");
    }

    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

        User user = (User) request.getSession().getAttribute(User.USER);

        CparLogForm cparLogForm = (CparLogForm) form;
        Map<String, RowBean> hash = cparService.getCparLog(cparLogForm.getCparLog(), user.getLocale());
        cparLogForm.setHash(hash);
        String file = McasProperties.getMcasProperties().getString("cpar.logStructure");
        ClassLoader classLoader = CparFilterAction.class.getClassLoader();
        InputStream xmlIn = classLoader.getResourceAsStream(file);
        cparLogForm.setXmlIn(xmlIn);
        cparLogForm.setSortBy("col1");
        cparLogForm.setSortOrder("asc");
        cparLogForm.setCurrDate(new Date(System.currentTimeMillis()));
        return mapping.findForward("submit");
    }

    private void getCparFormDefaults(HttpServletRequest request, int businessId) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        session.setAttribute(ActionHelperConstants.COMPLAINT_STATUS_LIST, null);
        session.setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, null);
        session.setAttribute(ActionHelperConstants.CPAR_STATUS_LIST, null);
        if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
            session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
        session
                .setAttribute(ActionHelperConstants.LOCATION_LIST, actionHelper.getLocationList(businessId, user.getLocale()));
        //Fetch the Business related regions
        session.setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                regionService.getRegionList(user.getUser_id(), businessId, user.getLocale()));
        sessionHelper.setEmptyFunctionList(session);
    }

    private int getUserBusinessId(User user) throws ServiceException {

        return service.getBusinessId(user);
    }
}
