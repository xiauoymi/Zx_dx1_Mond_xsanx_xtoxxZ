package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 23, 2008
 * Time: 8:59:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmailAction extends DispatchAction {
    private final ActionHelper actionHelper;

    public EmailAction() {
        actionHelper = new ActionHelper();
    }

    public EmailAction(ActionHelper actionHelper) {
        this.actionHelper = actionHelper;
    }

    /**
     * Method to send Email on clicking Send Email button
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public ActionForward sendEmailOnUserClick(ActionMapping mapping,
                                              ActionForm form,
                                              HttpServletRequest request,
                                              HttpServletResponse response) {
        String forward = "successSendingEmail";
        try {
            actionHelper.sendEmailOnUserClick(request);
        } catch (EmailException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            forward = "failureSendingEmail";
        }

        return mapping.findForward(forward);
    }
}
