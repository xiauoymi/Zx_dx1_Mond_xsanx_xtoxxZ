package com.monsanto.wst.ccas.actions;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */


/*apparently the whole world sucks.  Somebody was having a bad day!*/
public class GlobalAbomination { //todo these globals were pulled from ActionHelper.  They need to be killed


/*HaHa!  I finally slew the beast!*/
//  public static final String ADMIN_EMAIL = null; //todo public static NON-FINAL!   Global variables!!! Nooooooooo!
//  public static String AFFINA_EMAIL = null; //todo public static NON-FINAL!   Global variables!!! Nooooooooo!
//  public static String CCAS_SUPPORT_EMAIL = null;
//  public static String DMPOS_EXCEPTION_CC_EMAIL_1 = null;
//  public static String DMPOS_EXCEPTION_CC_EMAIL_2 = null;
//  public static String DOCUMENTUM_DISTRIBUTION_LIST = null;
//  public static String SBFASCAS_QMS = null;

    /*and then resurrected it and subjugated it for my own purposes.*/
    public static Exception lastException = null;
}
