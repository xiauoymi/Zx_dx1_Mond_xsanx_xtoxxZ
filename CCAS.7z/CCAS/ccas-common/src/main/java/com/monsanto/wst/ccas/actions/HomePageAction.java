/*
 * Created on Mar 4, 2005
 *
 *
 */
package com.monsanto.wst.ccas.actions;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.applicationinfo.*;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.ServiceLocator;
import com.monsanto.wst.ccas.service.UserAccountService;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.documentutil.filetypeutil.AllowedAttachmentTypes;
import com.monsanto.wst.documentutil.filetypeutil.AttachmentTypeXMLParser;
import com.monsanto.wst.documentutil.filetypeutil.exception.FileTypeValidationException;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.xml.sax.SAXException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.util.Map;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class HomePageAction extends DispatchAction {
    private final ActionHelper actionHelper;

    public HomePageAction() {
        actionHelper = new ActionHelper();
    }

    public HomePageAction(ActionHelper actionHelper) {
        this.actionHelper = actionHelper;
    }

    public ActionForward homePageLogon(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {
        String forward = "success";
        setApplicationAndUerInformation(request);
        return (mapping.findForward(forward));
    }

    public ActionForward redirectCisComplaints(ActionMapping mapping,
                                               ActionForm form,
                                               HttpServletRequest request,
                                               HttpServletResponse response) throws Exception {
        setApplicationAndUerInformation(request);
        User user = (User) request.getSession().getAttribute(User.USER);
        request.setAttribute(MCASConstants.IS_AFFINA_USER, user.isAffinaUser());
        user.setHasSelectedBusinessFromDropdown(true);
        user.setBusinessId(MCASConstants.BUSINESS_ID_ROW_CROP);
        user.setUserBusinessPreference(MCASConstants.BUSINESS_PREF_ROW_CROP);
        ActionHelper actionHelper = new ActionHelper();
        actionHelper.updateUserBusiness(user, user.getBusinessId(), false);
        //Set user preference to Row Crop and
        //what do we need to do for multiple businesses.
        return (mapping.findForward("cis_complaint_view"));
    }

    private void setApplicationAndUerInformation(HttpServletRequest request) throws Exception {
        User user = new User(null);
        HttpSession session = request.getSession();
        if (!userInSession(session, request)) {
            if (McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.authorize").equals("true")) {
                getUserInfoFromADAndStoreInSession(request, user, session);
                if (userIsPresentInMCASDatabase(user)) {
                    actionHelper.reloadAllData();
                    //Check if User is associated to more than 1 Business.
                    //If yes, forward the user to a page where he can select a business from drop downs
                    user = (User) request.getSession().getAttribute(User.USER);
                    actionHelper.userBelongsToMultipleBusiness(user, request.getSession(), request);
                    request.getSession().setAttribute(User.USER, user);

                }
            }
            String contextPath = request.getContextPath();
            addAllowedFileTypeInfo(getServlet().getServletContext());
            String outputContextPath = contextPath.substring(1, contextPath.length());
            request.getSession().setAttribute("APPLICATION_NAME", outputContextPath);
            addApplicationInfo(getServlet().getServletContext(), request);
        }
    }


    private void addApplicationInfo(ServletContext servletContext, HttpServletRequest request) {
//    System.out.println("People picker server " + System.getProperty("xmlservice.peoplepicker.server"));
//    System.out.println("Adding application info to context.");
        DataSource source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        ApplicationInfoDao applicationInfoDao = new ApplicationInfoDaoImpl(source);
        ApplicationService applicationService = new ApplicationServiceImpl(applicationInfoDao);
        Map<String, ApplicationInfo> applicationInfoMap = applicationService.getApplicationInfoMap();
        servletContext.setAttribute("APPLICATION_INFO", applicationInfoMap);
        request.getSession().setAttribute("APPLICATION_INFO", applicationInfoMap);

    }

    protected boolean userIsPresentInMCASDatabase(User user) {
        return user.getPermissionsMap() != null && user.getPermissionsMap().size() > 0;
    }

    protected void getUserInfoFromADAndStoreInSession(HttpServletRequest request, User user, HttpSession session) throws Exception {
        KerberosSecurity sec = new KerberosSecurity();
        sec.init(request);

//DEBUG: For debugging purposes you can hardcode a User ID here to spoof a user.
        user.setUser_id(getkerberosUserIdInUpperCase(sec));
        user.setFull_name(sec.getFullName());

        UserAccountService us = (UserAccountService) ServiceLocator.locateService(UserAccountService.class);
        user = us.getUserInfo(user);

        user.setLocale(I18nServiceImpl.getBrowserLocale(request));

        session.setAttribute(User.USER, user);
    }

    private String getkerberosUserIdInUpperCase(KerberosSecurity sec) {
        String kerberosUserId = sec.getUserID();
        if (!StringUtils.isNullOrEmpty(kerberosUserId)) {
            return kerberosUserId.toUpperCase();
        }
        return kerberosUserId;
    }

    private boolean userInSession(HttpSession session, HttpServletRequest request) {
        boolean userInSession = false;
        User user = (User) session.getAttribute(User.USER);
        if (user != null) {
            boolean param = actionHelper.userBelongsToMultipleBusiness(user, session, request);
            if (param) {
                if (user.isHasSelectedBusinessFromDropdown()) {
                    request.setAttribute("hasMultipleBusiness", null);
                    return true;
                }
                return false;
            }
            userInSession = true;
        }
        return userInSession;
    }

    protected void addAllowedFileTypeInfo(ServletContext servletContext) throws ParserException, FileTypeValidationException, IOException, SAXException {
        if (!allowedAttachmentTypesPresent(servletContext)) {
            AttachmentTypeXMLParser attachmentTypeXmlParser = new AttachmentTypeXMLParser();
            AllowedAttachmentTypes allowedAttachmentTypes = attachmentTypeXmlParser.parseAllowedAttachmentTypes();
            servletContext.setAttribute(MCASConstants.HELPER_VAR_ALLOWED_ATTACHMENT_TYPES,
                    allowedAttachmentTypes);
        }
    }

    private boolean allowedAttachmentTypesPresent(ServletContext servletContext) {
        return servletContext.getAttribute(MCASConstants.HELPER_VAR_ALLOWED_ATTACHMENT_TYPES) != null;
    }
}
