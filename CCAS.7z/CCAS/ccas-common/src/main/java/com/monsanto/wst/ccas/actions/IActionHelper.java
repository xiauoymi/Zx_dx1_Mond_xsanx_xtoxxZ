package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;
import org.apache.struts.action.ActionServlet;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: vrbethi Date: Oct 9, 2009 Time: 10:12:25 AM To change this template use File |
 * Settings | File Templates.
 */
public interface IActionHelper {
    String getStatusDescription(String status_id, int statusTypeComplaint, String locale);

    String getEmptyRegion(String userId, String regionId, String region);

    Map<String, String> getRegionSpecificLocationList(String regionId, int locationType, String locale);
    Map<String, String> getRegionSpecificLocationListSearch(String regionId, int locationType, String locale);

    void setApplicationInfoMap(HttpServletRequest request, int businessId, ActionServlet servlet);

//    List<CheckboxItem> getSelectedCheckboxItems(ObjectWithCheckboxGroups filterObj, Map<String, String[]> requestMap,
//                                                String functionalAreaType);

    Map<String, String> getLocationList(int userBusinessPreferenceId, String locale);

    Map<String, String> getEvaluatorList(String locale);

    Map<String, String> getSalesyearList(String locale);

    Map<String, String> getIlTypes(String locale);

    Map<String, String> getIsoStandardList(String locale, int businessId, String qualityProgram);

    Map<String, String> getQualityStandardList(String locale, int busId);

    Map<String, String> getOrganizationList(String locale, int busId);

    Map<String, String> getDepartmentAffectedList(String locale, int busId);

    Map<String, String> getStatusListByRole(String type, String locale, Map<String, Boolean> roles);

    Map<String, String> getAllStatusList(String status, String locale);

    Map<String, String> getRegionSpecificStatesList(String userId, String region, String locale);

    Map<String, String> getClaimStatusTypes(String type, String locale);
}
