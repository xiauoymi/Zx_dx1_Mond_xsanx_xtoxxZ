package com.monsanto.wst.ccas.actions;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.ReferenceDataTablesDaoImpl;
import com.monsanto.wst.ccas.dao.ReferenceDataTablesDao;
import com.monsanto.wst.ccas.actionForms.ReferenceAdminForm;
import com.monsanto.wst.ccas.model.ReferenceDataRow;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 2, 2011
 * Time: 12:12:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceDataAdminAction extends DispatchAction {

    ReferenceDataTablesDao dao = new ReferenceDataTablesDaoImpl();
    private static final String REFERENCE_DATA_MAP = "refData";
    private static final String REFERENCE_DATA_TYPE_MAP = "refDataType";
    private static final String REFERENCE_TABLE_MAP = "refTable";
    private static final String ADD_NEW = "com.monsanto.wst.ccas.admin.add";


    public ActionForward findReferenceData(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String locale = ((User) request.getSession().getAttribute(User.USER)).getLocale();

        ReferenceAdminForm refForm = (ReferenceAdminForm) form;
        if (refForm == null)
            refForm = new ReferenceAdminForm();

        if (refForm.getRefTable() == null)
            refForm.setRefTable(dao.getReferenceTablesInfo());

        request.getSession().setAttribute(REFERENCE_TABLE_MAP, refForm.getRefTable());

        if (refForm.getRefTableSelected() != null)
            refForm.setRefData(dao.getReferenceTableMeta(Integer.parseInt(refForm.getRefTableSelected()),  Integer.parseInt(refForm.getBusiness())));
        else
            refForm.setRefData(dao.getReferenceTableMeta((Integer) refForm.getRefTable().keySet().toArray()[0],  -1));

        refForm.getRefData().put(-1, "-- " + (new I18nServiceImpl()).lookupProperty(locale, ADD_NEW) + " --");

        if (refForm.getRefTableSelected() != null && refForm.getRefDataSelected() != null) {
            ReferenceDataRow row = dao.getRowFromReferenceTable(Integer.parseInt(refForm.getRefTableSelected()),
                    Integer.parseInt(refForm.getRefDataSelected()));

            if (row != null) {
                refForm.setDataId(row.getDataId());
                refForm.setDataValue(row.getDataValue());
                refForm.setDataValue2(row.getDataValue2());
                refForm.setActive(row.isActive());

                if (dao.referenceDataHasTypes(refForm.getRefTableSelected())) {
                    refForm.setRefDataType(dao.getReferenceDataTypes(refForm.getRefTableSelected()));
                    refForm.setRefDataTypeSelected(row.getType());
                } else {
                    refForm.setRefDataType(null);
                    refForm.setRefDataTypeSelected(null);
                    row.setType(null);
                }
            } else {//new row
                refForm.setDataId(-1);
                refForm.setDataValue("");
                refForm.setDataValue2("");
                refForm.setActive(true);

                if (dao.referenceDataHasTypes(refForm.getRefTableSelected())) {
                    refForm.setRefDataType(dao.getReferenceDataTypes(refForm.getRefTableSelected()));
                } else {
                    refForm.setRefDataType(null);
                    refForm.setRefDataTypeSelected(null);
                }
            }

        } else {
            refForm.setDataId(-1);
            refForm.setDataValue("");
            refForm.setRefDataType(null);
            refForm.setActive(true);
        }

        refForm.setHasActiveFlag(dao.referenceTableHasActive(refForm.getRefTableSelected()));
        request.getSession().setAttribute(REFERENCE_DATA_MAP, refForm.getRefData());
        request.getSession().setAttribute(REFERENCE_DATA_TYPE_MAP, refForm.getRefDataType());

        return mapping.findForward(MCASConstants.SUCCESS);
    }

    public ActionForward saveReferenceData(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String locale = ((User) request.getSession().getAttribute(User.USER)).getLocale();

        ReferenceAdminForm refForm = (ReferenceAdminForm) form;
        ReferenceDataRow row = new ReferenceDataRow();

        //uncheck active if it is not checked.
        if (!"on".equals(request.getParameter("active")))
            refForm.setActive(false);

        row.setDataId(refForm.getDataId());
        row.setDataValue(refForm.getDataValue().equalsIgnoreCase("")?"DEFAULT ":refForm.getDataValue());
        row.setDataValue2(refForm.getDataValue2().equalsIgnoreCase("")?"DEFAULT ":refForm.getDataValue2());
        row.setType(refForm.getRefDataTypeSelected());
        row.setActive(refForm.isActive());



        int id = dao.saveReferenceDataRow(Integer.parseInt(refForm.getRefTableSelected()), row, Integer.parseInt(refForm.getBusiness()));
        refForm.setDataId(id);
        refForm.setRefDataSelected(Integer.toString(id));

        //update selectbox
        refForm.setRefData(dao.getReferenceTableMeta(Integer.parseInt(refForm.getRefTableSelected()), Integer.parseInt(refForm.getBusiness())));
        refForm.getRefData().put(-1, "-- " + (new I18nServiceImpl()).lookupProperty(locale, ADD_NEW) + " --");
        request.getSession().setAttribute(REFERENCE_DATA_MAP, refForm.getRefData());

        return mapping.findForward(MCASConstants.SUCCESS);
    }
}
