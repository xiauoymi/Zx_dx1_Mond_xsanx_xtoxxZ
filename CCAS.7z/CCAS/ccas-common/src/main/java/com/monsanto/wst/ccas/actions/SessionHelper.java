/*
 SessionHelper was created on Mar 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.ComplaintListForm;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactoryImpl;
import com.monsanto.wst.ccas.app.ReferenceDataProcessor;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.importdata.LocationService;
import com.monsanto.wst.ccas.importdata.LocationServiceImpl;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: SessionHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class SessionHelper {
    private final FunctionService functionService;
    private DataSource dataSource;
    private final SalesOfficeDao salesOfficeDao;
    private final LocationService locationService;
    private final MaterialGroupDao materialGroupDao;
    private final MaterialPricingGroupDao materialPricingGroupDao;
    private final ActionHelper actionHelper;
    private final LookUpService lookupService;

    public SessionHelper() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        functionService = new FunctionServiceImpl(dataSource);
        salesOfficeDao = new SalesOfficeDaoImpl(dataSource);
        locationService = new LocationServiceImpl();
        materialGroupDao = new MaterialGroupDaoImpl(dataSource);
        materialPricingGroupDao = new MaterialPricingGroupDaoImpl(dataSource);
        actionHelper = new ActionHelper();
        lookupService = new LookUpServiceImpl();
    }

    public SessionHelper(FunctionService functionService, SalesOfficeDao salesOfficeDAO, LocationService locationService,
                         MaterialGroupDao materialGroupDao, MaterialPricingGroupDao materialPricingGroupDao,
                         ActionHelper actionHelper, LookUpService lookupService) {
        this.functionService = functionService;
        this.salesOfficeDao = salesOfficeDAO;
        this.locationService = locationService;
        this.materialGroupDao = materialGroupDao;
        this.materialPricingGroupDao = materialPricingGroupDao;
        this.actionHelper = actionHelper;
        this.lookupService = lookupService;
    }

    public void setFunctionLocation(HttpSession session, String locationCode) {

        User user = (User) session.getAttribute(User.USER);

        Map<String, String> functionMap = functionService.getFunctionsForLocation(locationCode, user.getLocale());
        if (functionMap != null && functionMap.size() == 1) {
            functionMap.remove("");
            functionMap.put("", I18nServiceImpl.lookupProperty(user.getLocale(), "com.monsanto.wst.ccas.NA"));
        }
        session.setAttribute("functionList", functionMap);
    }

    public void setEmptyFunctionList(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();

        Map<String, String> hashMap = new HashMap<String, String>();
        String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectLocation");
        hashMap.put("", select);
        session.setAttribute("functionList", hashMap);
    }

    /**
     * Method to populate Sales Office Based on Region Selected on Reload of Page / Edit
     *
     * @param session
     * @param regionId
     * @throws Exception
     */
    public void setSalesOffice(HttpSession session, String regionId, String locale) throws Exception {
        List<String> regionIdList = new ArrayList<String>(1);
        regionIdList.add(regionId);
        Map<String, String> salesOfficeMap = salesOfficeDao.lookupSalesOfficeBasedOnRegion(regionIdList, locale);
        session.setAttribute(ActionHelperConstants.SALES_OFFICE_MAP, salesOfficeMap);
    }

    public void setRegionRelatedLocation(HttpSession session, String regionId) throws Exception {
        String locale = ((User) session.getAttribute(User.USER)).getLocale();

        Map<String, String> locationMap = locationService.getRegionRelatedLocationMap(regionId, locale);
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, locationMap);
    }

    public void setAppSpecificReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception {
        String appName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        ReferenceDataProcessor processor = new ApplicationSpecificProcessorFactoryImpl()
                .getApplicationSpecificProcessor(appName).getReferenceDataProcessor();
        processor.setReferenceData(request, activeRecordsOnly);
    }

    /**
     * Method to populate the material group drop down based on the crop selected
     *
     * @param session
     * @param cropId
     * @throws Exception
     */
    public void setCropRelatedMaterialGroup(HttpSession session, String cropId) throws Exception {
        Map<String, String> materialGroupMap;
        int cropIdInt = -1;
        if (cropId != null && !"".equals(cropId)) {
            cropIdInt = Integer.parseInt(cropId);
        }

        User user = (User) session.getAttribute(User.USER);

        List<String> cropIdList = new ArrayList<String>();
        cropIdList.add(Integer.toString(cropIdInt));
        materialGroupMap = materialGroupDao.lookupCropRelatedMaterialGroups(cropIdList, user.getLocale());
        session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP, materialGroupMap);
    }

    /**
     * Method to populate the material group pricing based on the material group selected
     *
     * @param session
     * @param materialGroupId
     * @throws Exception
     */
    public void setMaterialGroupRelatedMaterialGroupPricing(HttpSession session, int materialGroupId) throws Exception {

        User user = (User) session.getAttribute(User.USER);

        List<String> materialPricingGroupIdList = new ArrayList<String>(1);
        materialPricingGroupIdList.add(Integer.toString(materialGroupId));
        Map<String, String> materialGroupPricing = materialPricingGroupDao
                .lookupMaterialGroupRelatedPricing(materialPricingGroupIdList, user.getLocale());
        session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP, materialGroupPricing);
    }

    /**
     * Method to Populate the states list based on the region selected
     *
     * @param session
     * @param regionId
     * @throws Exception
     */
    public void setRegionRelatedStates(HttpSession session, String regionId) throws Exception {
        User user = (User) session.getAttribute(User.USER);
        session.setAttribute(ActionHelperConstants.STATE_LIST,
                actionHelper.getRegionSpecificStatesList(user.getUser_id(), regionId, user.getLocale()));
    }

    /**
     * Method to set business id related crop dropdown
     *
     * @param session
     * @throws Exception
     */
    public void setBusinessRelatedCrop(HttpSession session) throws Exception {
        User userObj = (User) session.getAttribute(User.USER);
        int businessId = userObj.getBusinessId();
        session.setAttribute(ActionHelperConstants.CROP_LIST,
                actionHelper.getBusinessRelatedCrops(businessId, userObj.getLocale()));
    }

    /**
     * Method to clear existing drop downs and populate with default values
     *
     * @param session
     */
    public void clearDropDowns(HttpSession session) {
        setDefaultSalesOffices(session);
        setDefaultMaterialGroups(session);
        setDefaultMaterrialGroupPricings(session);
        setDefaultStates(session);
    }

    /**
     * Method to populate default value to drop down
     *
     * @param session
     * @return
     */
    public Map<String, String> setDefaultStates(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> stateHashMap = new HashMap<String, String>();
        stateHashMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(ActionHelperConstants.STATE_LIST, stateHashMap);
        return stateHashMap;
    }

    /**
     * Method to populate default value to drop down
     *
     * @param session
     * @return
     */
    public Map<String, String> setDefaultMaterrialGroupPricings(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> materialPricingGroupHashMap = new HashMap<String, String>();
        materialPricingGroupHashMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP, materialPricingGroupHashMap);
        return materialPricingGroupHashMap;
    }

    /**
     * Method to populate default value to drop down
     *
     * @param session
     * @return
     */
    public Map<String, String> setDefaultMaterialGroups(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> materialGroupHashMap = new HashMap<String, String>();
        materialGroupHashMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP, materialGroupHashMap);
        return materialGroupHashMap;
    }

    /**
     * Method to populate default value to drop down
     *
     * @param session
     * @return
     */
    public Map<String, String> setDefaultSalesOffices(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> salesOfficeHashMap = new HashMap<String, String>();
        salesOfficeHashMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(ActionHelperConstants.SALES_OFFICE_MAP, salesOfficeHashMap);
        return salesOfficeHashMap;
    }

    /**
     * Method to populate default value to drop down
     *
     * @param session
     * @return
     */
    public Map<String, String> setDefaultRegions(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> regionMap = new HashMap<String, String>();
        regionMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(MCASConstants.HELPER_VAR_REGION_LIST, regionMap);
        return regionMap;
    }

    public Map<String, String> setDefaultLocations(HttpSession session) {

        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        Map<String, String> regionSpecificLocation = new HashMap<String, String>();
        regionSpecificLocation.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        session.setAttribute(MCASConstants.HELPER_VAR_REGION_RELATED_LOCATION_LIST, regionSpecificLocation);
        session.setAttribute(MCASConstants.HELPER_VAR_REGION_RELATED_LOCATION_LIST_SEARCH, regionSpecificLocation);
        return regionSpecificLocation;
    }

    /**
     * Method to Populate Default Values to Drop Downs
     *
     * @param request
     * @param cf
     * @throws Exception
     */
    public void retainDropdownValues(HttpServletRequest request, ComplaintListForm cf, String locale) throws Exception {
        //Populate the Sales Office , Material Group and Material Group Pricing after submit.
        String regionId = request.getParameter("region");
        String cropId = request.getParameter("crop");
        String materialGroupId = request.getParameter("materialGroupCode");
        String initialAssesmentCode = request.getParameter("initialAssesmentCode");
        String complaintLitigationCategoryCode = request.getParameter("complaintLitigationCategoryCode");
        if (StringUtils.isNullOrEmpty(regionId)) {
            regionId = cf.getRegion();
        }
        if (!StringUtils.isNullOrEmpty(regionId)) {
            setSalesOffice(request.getSession(), regionId, locale);
            setRegionRelatedStates(request.getSession(), regionId);
        } else {
            setDefaultSalesOffices(request.getSession());
            setDefaultRegions(request.getSession());
        }
        if (!StringUtils.isNullOrEmpty(cropId)) {
            setCropRelatedMaterialGroup(request.getSession(), cropId);
        } else {
            setDefaultMaterialGroups(request.getSession());
        }
        if (!StringUtils.isNullOrEmpty(materialGroupId)) {
            setMaterialGroupRelatedMaterialGroupPricing(request.getSession(), Integer.parseInt(materialGroupId));
        } else {
            setDefaultMaterrialGroupPricings(request.getSession());
        }

        if (!StringUtils.isNullOrEmpty(initialAssesmentCode)) {
            setInitialAssesment(request.getSession());
        }
        if (!StringUtils.isNullOrEmpty(complaintLitigationCategoryCode)) {
            setComplaintLitigationCategoryMap(request.getSession());
        }
        String programId = request.getParameter("programId");
        if (!StringUtils.isNullOrEmpty(programId)) {
            setProgramRelatedSubFunctionsAndLocations(request.getSession(), programId);
        }
    }

    /**
     * Custom method to populate the stop sale drop downs as all the request params are prefixed with stopSaleFilter. <eg
     * : stopSaleFilter.crop> In Stop Sale Entry page, request params are prefixed with stopSale. <eg : stopSale.cropID>
     *
     * @param request
     * @throws Exception
     */
    public void retainStopSaleDropdownValues(HttpServletRequest request, String methodName) throws Exception {
        //Populate the Sales Office , Material Group and Material Group Pricing after submit.
        String cropParam = "";
        String materialGroupParam = "";
        String regionParam = "";
        if ("display".equalsIgnoreCase(methodName)) {
            cropParam = "stopSale.cropID";
            materialGroupParam = "stopSale.materialGroupCode";
            regionParam = "stopSale.region";
        } else if ("submit".equalsIgnoreCase(methodName)) {
            cropParam = "stopSaleFilter.crop";
            materialGroupParam = "stopSaleFilter.materialGroupCode";
            regionParam = "stopSaleFilter.region";
        }
        String cropId = request.getParameter(cropParam);
        String materialGroupId = request.getParameter(materialGroupParam);
        String regionId = request.getParameter(regionParam);
        if (!StringUtils.isNullOrEmpty(cropId)) {
            setCropRelatedMaterialGroup(request.getSession(), cropId);
        } else {
            setDefaultMaterialGroups(request.getSession());
        }
        if (!StringUtils.isNullOrEmpty(materialGroupId)) {
            setMaterialGroupRelatedMaterialGroupPricing(request.getSession(), Integer.parseInt(materialGroupId));
        } else {
            setDefaultMaterrialGroupPricings(request.getSession());
        }
        if (!StringUtils.isNullOrEmpty(regionId)) {
            setRegionRelatedLocation(request.getSession(), regionId);
        } else {
            setDefaultLocations(request.getSession());
        }

    }


    /**
     * Method to populate the Initial Assesment
     *
     * @param session
     * @throws Exception
     */
    public void setInitialAssesment(HttpSession session) throws Exception {

        User user = (User) session.getAttribute(User.USER);

        session
                .setAttribute(ActionHelperConstants.COMPLAINT_ASSESMENT_MAP, lookupService.getAssesmentMap(user.getLocale()));
    }

    /**
     * Method to reload Complaint Litigation Category Map
     *
     * @param session
     * @throws Exception
     */
    public void setComplaintLitigationCategoryMap(HttpSession session) throws Exception {

        User user = (User) session.getAttribute(User.USER);

        session.setAttribute(ActionHelperConstants.COMPLAINT_LITIGATION_CATEGORY_MAP,
                lookupService.getLitigationCategoryMap(user.getLocale()));
    }

    public void setProgramRelatedSubFunctionsAndLocations(HttpSession session, String programSelected) {
        if ("0".equalsIgnoreCase(programSelected)) return;

        User user = (User) session.getAttribute(User.USER);
        ProgramService service = new ProgramServiceImpl();
        SubFunctionService subFunctionService = new SubFunctionServiceImpl();

        session.setAttribute(MCASConstants.SUBFUNCTION_LIST,
                subFunctionService.lookupAllSubFunctionsForAProgram(programSelected, user.getLocale()));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST,
                service.lookupLocationsForAProgram(programSelected));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST,
                service.lookupLocationsForAProgram(programSelected));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST_SEARCH,
                service.lookupLocationsForAProgramSearch(programSelected));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST_SEARCH,
                service.lookupLocationsForAProgramSearch(programSelected));


        session.setAttribute(MCASConstants.FEEDBACK_CATEGORY,
                service.lookupCategoryForAProgram(programSelected, user.getLocale()));
    }

    public void setDispositionList(HttpSession session, Map<String, String> dispositionList) {
        session.setAttribute(MCASConstants.DISPOSITION_LIST, dispositionList);
    }

    public void setAuditTypeMap(HttpSession session) {
        User user = (User) session.getAttribute(User.USER);
        String appName=session.getAttribute("APPLICATION_NAME").toString();
        if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_MCAS)){
            session.setAttribute(AuditConstants.AUDIT_TYPE_MAP, lookupService.getAuditTypeRef(user.getLocale(),user.getBusinessId() ));
        }
        else{
            session.setAttribute(AuditConstants.AUDIT_TYPE_MAP, lookupService.getAuditTypeRef(user.getLocale(),0 ));
        }
    }

    public static void setSelectedRegion(HttpSession session, final String regionId) {
        session.setAttribute(MCASConstants.SESSION_ATTRIBUTE_SELECTED_REGION, regionId);
    }

    public static void setSelectedRegionResponsible(HttpSession session, final String regionId) {
        session.setAttribute(MCASConstants.SESSION_ATTRIBUTE_SELECTED_REGION_RESPONSIBLE, regionId);
    }
}
