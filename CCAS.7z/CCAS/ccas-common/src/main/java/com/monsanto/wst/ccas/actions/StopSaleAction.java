//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.StopSaleForm;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactoryImpl;
import com.monsanto.wst.ccas.app.StopSaleProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.StopSaleConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASLookupFilterUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * MyEclipse Struts Creation date: 05-04-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/stopSale" name="stopSaleForm" scope="request"
 */
public class StopSaleAction extends DispatchAction {

    private static final Category logger = Category.getInstance(StopSaleAction.class.getName());

    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    private final SessionHelper sessionHelper;
    private final ActionHelper actionHelper;
    private final DataSource source;
    private final CheckboxItemService nonconformanceCategoryService;
    private final CheckboxItemService rootCauseService;
    private final ComplaintService complaintService;

    public StopSaleAction() {
        sessionHelper = new SessionHelper();
        actionHelper = new ActionHelper();
        source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        complaintService = new ComplaintServiceImpl();
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward stopSaleDisplay(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleForm stopSaleForm = (StopSaleForm) form;

        createNewStopSale(stopSaleForm);

        //**Filling the combo-boxes...
        //Clear the existing drop downs if any
        sessionHelper.clearDropDowns(request.getSession());
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        //Populate the Application Info Map based on the Business ID
        getStopSaleDefaultLists(request, businessId);
        actionHelper.setApplicationInfoMap(request, businessId, getServlet());
        String region = request.getParameter("region");

        stopSaleForm.getStopSale().setCreatedBy(user.getUser_id());
        stopSaleForm.getStopSale().setEntryDate(sdf.format(new Date()));
        stopSaleForm.getStopSale().setStatus("10");
        stopSaleForm.getStopSale().setRegion(region);
        setRequestAttributes(request, user, businessId);
        setTapRootCategories(stopSaleForm.getStopSale(), businessId, false, user,request.getSession().getAttribute("APPLICATION_NAME").toString() );
        request.setAttribute("SendEmailVisible", false);
        return mapping.findForward("success");
    }

    void setTapRootCategories(StopSaleObject stopSale, int businessId, boolean isEdit, User user, String appName) {

        nonconformanceCategoryService.setCheckboxGroupsForObject(businessId, isEdit, "S", stopSale, stopSale.getStopSaleID(), user.getLocale(), user.getPermissionsMap(),appName );
        rootCauseService.setCheckboxGroupsForObject(businessId, isEdit, "S", stopSale, stopSale.getStopSaleID(), user.getLocale(), user.getPermissionsMap(), appName);
    }

    /**
     * 04/24/2008 Method to validate the display of save / update method
     *
     * @param user
     * @param methodType
     * @return
     * @throws Exception
     */
    private boolean isSaveUpdateControlsVisible(User user, String methodType) throws Exception {
        return actionHelper.isSaveUpdateControlsVisible(user, methodType);
    }

    private int getUserBusinessId(User user) throws ServiceException {
        BusinessService service = (BusinessService) ServiceLocator.locateService(BusinessService.class);
        return service.getBusinessId(user);
    }

    private void createNewStopSale(StopSaleForm stopSaleForm) {
        if (stopSaleForm != null) {
            stopSaleForm.setStopSale(new StopSaleObject());
        }
    }

    /**
     * Method to view the stop sales
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward stopSaleView(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleForm stopSaleForm = (StopSaleForm) form;
        HttpSession session = request.getSession();
        User user = (User) request.getSession().getAttribute(User.USER);
        String region = request.getParameter("region");
        if (region != null) {
            session.setAttribute(ActionHelperConstants.STATE_LIST,
                    actionHelper.getRegionSpecificStatesList(user.getUser_id(), region, user.getLocale()));
            return mapping.findForward("success");
        }
        int stopSaleID = 0;
        try {
            stopSaleID = Integer.parseInt(request.getParameter("stopSaleId"));
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
//    logger.info("Req stop_sale_id for View: " + request.getParameter("stopSaleId"));
        StopSaleObject stopSaleObject = new StopSaleObject();
        String businessId = "";
        try {
            StopSaleServiceImpl ss = (StopSaleServiceImpl) ServiceLocator.locateService(StopSaleService.class);
            stopSaleObject = ss.getStopSale(stopSaleID);
            request.setAttribute("regionId", stopSaleObject.getRegion());
            //Set the Old Status
            stopSaleObject.setOldStatus(stopSaleObject.getStatus());
            businessId = String.valueOf(stopSaleObject.getStopSaleBusinessId());
            getStopSaleDefaultLists(request, Integer.parseInt(businessId));
            actionHelper.setApplicationInfoMap(request, stopSaleObject.getStopSaleBusinessId(), getServlet());
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        stopSaleForm.setStopSale(stopSaleObject);    //**Set it to the form...
        session.setAttribute("stopSaleId", request.getParameter("stopSaleId"));
        filterLookupsBasedOnUserRegion(stopSaleForm.getStopSale(), user, request);
        if (request.getParameter(CparConstants.FROM_CPAR) != null) {
            //If the user comes back from CAR/PAR back to Complaint page, display the controls
            //If the user comes back from Attachment page , display the controls
            if (!businessId.equals("" + getUserBusinessId(user))) {
                request.setAttribute("canViewControls", "false");
            } else {
                request.setAttribute("canViewControls", "true");
            }
        }
        if (request.getAttribute("canViewControls") == null) {
            boolean canViewSaveUpdateControls = isSaveUpdateControlsVisible(user, "stopSaleView");
            request.setAttribute("canViewControls", canViewSaveUpdateControls);
        }
        actionHelper.isUserAuthorizedToViewControls(request, Integer.parseInt(stopSaleForm.getStopSale().getRegion()),
                Integer.parseInt(businessId), user);
        //set the tap root categories
        setTapRootCategories(stopSaleForm.getStopSale(), Integer.parseInt(businessId), true, user,request.getSession().getAttribute("APPLICATION_NAME").toString() );
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        //populate all the default values
        populateFieldsOnSubmit(request, stopSaleObject);
        request.setAttribute("SendEmailVisible", true);
        return mapping.findForward("success");
    }

    private void filterLookupsBasedOnUserRegion(StopSaleObject stopSale, User user, HttpServletRequest request) throws
            Exception {
        MCASLookupFilterUtil lookupUtil = new MCASLookupFilterUtil();

        lookupUtil.filterLocationLookup(stopSale.getFillingLocation(), MCASConstants.HELPER_VAR_USER_IN_FILING_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_FILING_LOCATION, user, request, 0,
                ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST);
        lookupUtil.filterLocationLookup(stopSale.getResponsibleLocation(), MCASConstants.HELPER_VAR_USER_IN_RESPONSIBLE_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_RESPONSIBLE_LOCATION, user, request, 0,
                ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST);
        lookupUtil.filterLocationLookup(stopSale.getShippingLocation(), MCASConstants.HELPER_VAR_USER_IN_SHIPPING_LOC,
                MCASConstants.HELPER_VAR_VIEWABLE_SHIPPING_LOCATION, user, request, 0,
                ActionHelperConstants.REGION_SPECIFIC_SHIPPING_LOCATION_LIST);
        lookupUtil.filterRegionLookup(stopSale.getRegion(), MCASConstants.HELPER_VAR_USER_IN_STOP_SALE_REGION,
                MCASConstants.HELPER_VAR_VIEWABLE_STOP_SALE_REGION, user, request,
                ActionHelperConstants.REGION_LIST_FOR_NEW_COMPLAINTS);
    }

    /**
     * Method viewByNumber
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward stopSaleViewByNumber(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleForm stopSaleForm = (StopSaleForm) form;

        //**Filling the combo-boxes...
        getStopSaleDefaultLists(request, -1);

        String stopSaleNumber = request.getParameter("stopSaleNumber");

//    logger.info("Req stop_sale_no for View: " + stopSaleNumber);

        //**Call View Service...
        StopSaleObject returnObj = new StopSaleObject();
        try {
            StopSaleServiceImpl ss = (StopSaleServiceImpl) ServiceLocator.locateService(StopSaleService.class);
            returnObj = ss.getStopSaleByNumber(stopSaleNumber);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

        User user = (User) request.getSession().getAttribute(User.USER);

        //**Set it to the form...
        stopSaleForm.setStopSale(returnObj);
        setTapRootCategories(returnObj, returnObj.getStopSaleBusinessId(), true, user, request.getSession().getAttribute("APPLICATION_NAME").toString());
        return mapping.findForward("success");
    }

    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward stopSaleSubmit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        User user = (User) request.getSession().getAttribute("user");
        //Fetch the Business Id from the user object and set it to the StopSale Object
        int businessId = getUserBusinessId(user);
        StopSaleForm stopSaleForm = (StopSaleForm) form;

        //Pre Processing
        performGeneralPreProcessing(stopSaleForm.getStopSale(), request);
        performApplicationSpecificPreProcessing(request, stopSaleForm.getStopSale(), businessId);
//        List<CheckboxItem> tapRootCategoryList = actionHelper
//                .getSelectedTaprootCategories(stopSaleForm.getStopSale(), request.getParameterMap(),
//                        "stopSale.nonconformanceCategoryList");
//        stopSaleForm.getStopSale().setSelectedNonconformanceList(tapRootCategoryList);

//        CheckboxItemServiceImpl.getSelectedCheckboxItems(stopSaleForm.getStopSale(), (Map<String, String[]>) request.getParameterMap(), "rootCauseList");

        boolean attachFileAction = false;
        boolean isStopSaleInsert = false;

        //Main Processing
        if (stopSaleForm.getStopSale().getControlNumber() != null &&
                !stopSaleForm.getStopSale().getControlNumber().equals("")) {            //**Update Action...
            try {
                StopSaleServiceImpl ss = (StopSaleServiceImpl) ServiceLocator.locateService(StopSaleService.class);
                ss.updateStopSale(stopSaleForm.getStopSale());
//                insertTapRootCategory(tapRootCategoryList, stopSaleForm.getStopSale().getSelectedFunctionalAreas(), stopSaleForm.getStopSale().getStopSaleID());
                setTapRootCategories(stopSaleForm.getStopSale(), businessId, true, user,request.getSession().getAttribute("APPLICATION_NAME").toString() );
            }
            catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
            attachFileAction = performAttachFileAction(stopSaleForm, request);
        } else {
            String returnVal = "";

            StopSaleServiceImpl ss = (StopSaleServiceImpl) ServiceLocator.locateService(StopSaleService.class);
            returnVal = ss.insertStopSale(stopSaleForm.getStopSale());
            if(returnVal.equalsIgnoreCase(";")){
                request.setAttribute("WARNING_MESSAGE", "Empty Control Number, try again");
                return mapping.findForward("failure");
            }
            isStopSaleInsert = true;
            stopSaleForm = populateStopSaleIdAndControlNumber(stopSaleForm, returnVal);
//            insertTapRootCategory(tapRootCategoryList, stopSaleForm.getStopSale().getSelectedFunctionalAreas(), stopSaleForm.getStopSale().getStopSaleID());
            attachFileAction = performAttachFileAction(stopSaleForm, request);
        }
        //Post Processing
        performApplicationSpecificPostProcessing(request, stopSaleForm.getStopSale(), user, businessId, isStopSaleInsert,
                attachFileAction);
        if (attachFileAction) {
            return mapping.findForward(MCASConstants.FORWARD_MAPPING_ADD_ATTACHMENT_PG);
        } else {
            request.setAttribute("SendEmailVisible", true);
            return mapping.findForward("success");
        }
    }

    /**
     * Private method to Perform application specific Post Processing tasks. Currently implemented tasks --Send Email
     * upon stop sale creation/status change
     *
     * @param request
     * @param stopSale
     * @param user
     * @param businessId
     * @param stopSaleInsert
     * @param attachFileAction
     */
    private void performApplicationSpecificPostProcessing(HttpServletRequest request, StopSaleObject stopSale, User user,
                                                          int businessId,
                                                          boolean stopSaleInsert, boolean attachFileAction) throws
            Exception {
        request.setAttribute("recordSaved", "true");
        filterLookupsBasedOnUserRegion(stopSale, user, request);
        //Method to populate the drop downs after stop sale is submitted
        populateFieldsOnSubmit(request, stopSale);
        setRequestAttributes(request, user, businessId);
        String emailPreview = request.getParameter("printPreviewSrc");
        final String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        StopSaleProcessor processor =
                new ApplicationSpecificProcessorFactoryImpl().getApplicationSpecificProcessor(applicationName)
                        .getStopSaleProcessor();

        try {
            processor.sendStopSaleEmail(stopSale, emailPreview, stopSaleInsert, attachFileAction, user.getLocale());
        } catch (EmailAddressRetrievalException e) {
            request.setAttribute("WARNING_MESSAGE", e.getMessage());
        } catch (EmailException e) {
            request.setAttribute("WARNING_MESSAGE", e.getMessage());
        }
    }

    /**
     * Private method to set the Request Attributes
     *
     * @param request
     * @param user
     * @param businessId
     * @throws Exception
     */
    private void setRequestAttributes(HttpServletRequest request, User user, int businessId) throws Exception {
        boolean canViewSaveUpdateControls = isSaveUpdateControlsVisible(user, "stopSaleSubmit");
        request.setAttribute("canViewControls", canViewSaveUpdateControls);
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
    }

    /**
     * Method to Perform Seminis Specific Processing
     *
     * @param request
     * @param stopSale
     * @param businessId
     */
    private void performApplicationSpecificPreProcessing(HttpServletRequest request, StopSaleObject stopSale,
                                                         int businessId) throws
            ServiceException {
        resetSelections(stopSale, request);
        stopSale.setStopSaleBusinessId(businessId);
        User user = (User) request.getSession().getAttribute(User.USER);
        final String applicationName = (String) request.getSession().getAttribute("APPLICATION_NAME");
        StopSaleProcessor processor =
                new ApplicationSpecificProcessorFactoryImpl().getApplicationSpecificProcessor(applicationName)
                        .getStopSaleProcessor();
        processor.processStopSale(stopSale, user);
    }

    /**
     * 04/23/2008 <p/> Method to populate the drop downs after a stop sale has been created
     *
     * @param request
     * @param stopSaleObject
     * @throws Exception
     */
    private void populateFieldsOnSubmit(HttpServletRequest request, StopSaleObject stopSaleObject) throws Exception {
        //Populate the State,Sales Office,Material Group and Material Group Pricing selection Boxes.
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();

        if (stopSaleObject != null) {
            String regionId = stopSaleObject.getRegion();
            String cropId = stopSaleObject.getCropID();
            int materialGroupId = stopSaleObject.getMaterialGroupCode();
            sessionHelper.setRegionRelatedStates(request.getSession(), regionId);

            sessionHelper.setSalesOffice(session, regionId, locale);
            sessionHelper.setBusinessRelatedCrop(session);
            sessionHelper.setCropRelatedMaterialGroup(session, cropId);
            sessionHelper.setMaterialGroupRelatedMaterialGroupPricing(session, materialGroupId);
            sessionHelper.setRegionRelatedLocation(session, regionId);
        }
    }

    /**
     * Method to populate the Control Number and the stop sale ID to the form object
     *
     * @param stopSaleForm
     * @param returnVal
     */
    private StopSaleForm populateStopSaleIdAndControlNumber(StopSaleForm stopSaleForm, String returnVal) {
        StringTokenizer st = new StringTokenizer(returnVal, ";");   //**Set the stopSale ID and No...
        for (int i = 0; i < 2; i++) {
            if (st.hasMoreTokens() && i == 0) {
                stopSaleForm.getStopSale().setControlNumber(st.nextToken());
            }
            if (st.hasMoreTokens() && i == 1) {
                stopSaleForm.getStopSale().setStopSaleID(st.nextToken());
            }
        }
        return stopSaleForm;
    }

    private boolean performAttachFileAction(StopSaleForm stopSaleForm, HttpServletRequest request) {
        boolean attachFileAction = false;
        if (actionIsAddAttachment(request)) {
            addRequiredParamsForAddAttachment(stopSaleForm.getStopSale().getStopSaleID(), request);
            attachFileAction = true;
        }
        return attachFileAction;
    }

    private boolean actionIsAddAttachment(HttpServletRequest request) {
        return request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
                && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true");
    }

    private void addRequiredParamsForAddAttachment(String stopSaleId, HttpServletRequest request) {
        addEntityIdToRequest(request, stopSaleId);
        addStopSaleEntityTypeToSession(request);
    }

    private void addEntityIdToRequest(HttpServletRequest request, String entityId) {
        request.setAttribute(MCASConstants.REQUEST_VAR_ENTITY_ID, entityId);
    }

    private void addStopSaleEntityTypeToSession(HttpServletRequest request) {
        request.getSession()
                .setAttribute(MCASConstants.HELPER_VAR_ENTITY_TYPE, MCASConstants.STRATEGY_MAP_KEY_STOPSALE_ENTITY);
    }

    /**
     * Method createCar
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward stopSaleCreateCar(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        StopSaleForm stopSaleForm = (StopSaleForm) form;

        //logger.info("Create Car Method: Ctrl No=" + stopSaleForm.getStopSale().getControlNumber());
        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);

        StopSaleObject stopSale = stopSaleForm.getStopSale();

        if (stopSale.getCarID() != null && !stopSale.getCarID().equals("")) {

            String msg = I18nServiceImpl.lookupProperty(user.getLocale(), "com.monsanto.wst.ccas.error.duplicateCar");
            request.setAttribute("duplicateCarMsg", msg);
            request.setAttribute("cparId", stopSale.getCarID());

            return mapping.findForward("faliure");
        } else {
            Cpar cparStopSaleObj = getNewCparObject(stopSale);
            request.setAttribute("cparStopSaleObj", cparStopSaleObj);
            request.setAttribute("createCAR", "true");
            request.setAttribute("Generator", "Stop Sale");
            request.setAttribute("iscar", "true");
            //Set the Business ID as it will be used in CPAR.jsp
            request.setAttribute(AuditAction.BUSINESS_ID, businessId);
            return mapping.findForward(CparConstants.FORWARD_SUCCESS_CPAR);
        }
    }

    /**
     * Private method to create a new CPAR object
     *
     * @param stopSale
     * @return
     */
    private Cpar getNewCparObject(StopSaleObject stopSale) {
        Cpar cparStopSaleObj = new Cpar();
        cparStopSaleObj.setRegion(stopSale.getRegion());
        cparStopSaleObj.setFiling_location(stopSale.getFillingLocation());
        cparStopSaleObj.setResponsible_location(stopSale.getResponsibleLocation());
        cparStopSaleObj.setIssue_year(stopSale.getSalesYear());
        cparStopSaleObj.setInvestigation_findings(stopSale.getInvestigationFindings());
        cparStopSaleObj.setRoot_cause(stopSale.getRootCause());
        cparStopSaleObj.setContainment_actions(stopSale.getContainmentAction());
        cparStopSaleObj.setLong_term_corrective_action(stopSale.getLongTermCorrectiveAction());
        cparStopSaleObj.setStop_sale_id(stopSale.getStopSaleID());
        cparStopSaleObj.setStop_sale_number(stopSale.getControlNumber());
        cparStopSaleObj.setGenerator("5");
        cparStopSaleObj.setType(CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
        return cparStopSaleObj;
    }

    public ActionForward stopSaleFindBatches(ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,
                                             HttpServletResponse response)
            throws Exception {
        String forward = "success";

        StopSaleObject stopSale = ((StopSaleForm) form).getStopSale();
        Map<String, String> batches = null;

        try {

            if (!(request.getParameter("batchNumber") == null) && !(request.getParameter("batchNumber").equals(""))) {
                User user = (User) request.getSession().getAttribute(User.USER);
                if (stopSale.getStopSaleID() != null && !stopSale.getStopSaleID().equals("")) {
                    batches = complaintService.findBatches(request.getParameter("batchNumber").trim(), stopSale.getStopSaleID(),
                            getUserBusinessId(user));
                } else {
                    batches = complaintService
                            .findBatches(request.getParameter("batchNumber").trim(), "0", getUserBusinessId(user));
                }
            }
            forward = "success";
            request.getSession().setAttribute(request.getParameter("batchID"), batches);
        }
        catch (Exception e) {
            throw new Exception(e);
        }

        return (mapping.findForward(forward));
    }

    /**
     * To fill up the location, status, region list etc...
     */
    private void getStopSaleDefaultLists(HttpServletRequest request, int currentBusinessId) {
        try {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            String region = request.getParameter("region");
            session.setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, null);

            session.setAttribute(ActionHelperConstants.CROP_LIST,
                    actionHelper.getBusinessRelatedCrops(currentBusinessId, user.getLocale()));

            setLocationsForApplication(request);

            if (session.getAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST) == null)
                session
                        .setAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST, actionHelper.getQualityissueList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
                session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.SEED_SIZE_LIST) == null)
                session.setAttribute(ActionHelperConstants.SEED_SIZE_LIST, actionHelper.getSeedsizeList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.STATE_LIST) == null)
                session.setAttribute(ActionHelperConstants.STATE_LIST,
                        new RegionServiceImpl().getRegionSpecificStatesList(user.getUser_id(), user.getLocale()));
            if (region != null) {
                session.setAttribute(ActionHelperConstants.STATE_LIST,
                        actionHelper.getRegionSpecificStatesList(user.getUser_id(), region, user.getLocale()));
            }
            if (session.getAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST) == null)
                session
                        .setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, actionHelper.getAllStatusList("STOP SALE", user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.UOM_LIST) == null)
                session.setAttribute(ActionHelperConstants.UOM_LIST, actionHelper.getUomList(user.getLocale()));
            //Modified the Method call to include Business ID
            //if (session.getAttribute(ActionHelper.REGION_LIST) == null ){
            session.setAttribute(ActionHelperConstants.REGION_LIST,
                    new RegionServiceImpl().getRegionList(user.getUser_id(), currentBusinessId, user.getLocale()));
            //}
            //Place Holder for Sales Office Ids
            if (session.getAttribute(ActionHelperConstants.SALES_OFFICE_MAP) == null) {
                session.setAttribute(ActionHelperConstants.SALES_OFFICE_MAP, sessionHelper.setDefaultSalesOffices(session));
            }
            //Place Holder for Material Groups
            if (session.getAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP) == null) {
                session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_MAP, sessionHelper.setDefaultMaterialGroups(session));
            }
            //Place Holder for Material Group Pricing
            if (session.getAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP) == null) {
                session.setAttribute(ActionHelperConstants.MATERIAL_GROUP_PRICING_MAP,
                        sessionHelper.setDefaultMaterrialGroupPricings(session));
            }

        }
        catch (Exception ex) {
            MCASLogUtil.logError("Problem getting default lists for StopSale", ex);
        }
    }

    private void setLocationsForApplication(HttpServletRequest request) throws Exception {
        sessionHelper.setAppSpecificReferenceData(request, false);
    }

    /**
     * To set/reset all the checkboxs again, and rectify the checkbox-reset error
     *
     * @param stopSale Stop Sale Object
     * @param request  HttpServlet Request
     */
    protected void resetSelections(StopSaleObject stopSale, HttpServletRequest request) {

        if (request.getParameterMap().get("stopSale.seedCount") != null) {
            stopSale.setSeedCount(true);
        } else {
            stopSale.setSeedCount(false);
        }
        if (request.getParameterMap().get("stopSale.germination") != null) {
            stopSale.setGermination(true);
        } else {
            stopSale.setGermination(false);
        }
        if (request.getParameterMap().get("stopSale.purity") != null) {
            stopSale.setPurity(true);
        } else {
            stopSale.setPurity(false);
        }
        if (request.getParameterMap().get("stopSale.tagDate") != null) {
            stopSale.setTagDate(true);
        } else {
            stopSale.setTagDate(false);
        }
        if (request.getParameterMap().get("stopSale.otherReason") != null) {
            stopSale.setOtherReason(true);
        } else {
            stopSale.setOtherReason(false);
        }
        if (request.getParameterMap().get("stopSale.reLabel") != null) {
            stopSale.setReLabel(true);
        } else {
            stopSale.setReLabel(false);
        }
        if (request.getParameterMap().get("stopSale.dump") != null) {
            stopSale.setDump(true);
        } else {
            stopSale.setDump(false);
        }
        if (request.getParameterMap().get("stopSale.recount") != null) {
            stopSale.setRecount(true);
        } else {
            stopSale.setRecount(false);
        }
        if (request.getParameterMap().get("stopSale.restrict") != null) {
            stopSale.setRestrict(true);
        } else {
            stopSale.setRestrict(false);
        }
        if (request.getParameterMap().get("stopSale.otherActionFlag") != null) {
            stopSale.setOtherActionFlag(true);
        } else {
            stopSale.setOtherActionFlag(false);
        }
    }

    private void performGeneralPreProcessing(StopSaleObject ss, HttpServletRequest request) {

        String regionId = request.getParameter(StopSaleConstants.STOP_SALE_ENTRY_REGION);
        SessionHelper.setSelectedRegion(request.getSession(), regionId);

        CheckboxItemServiceImpl.getSelectedCheckboxItems(ss, (Map<String, String[]>) request.getParameterMap(), "functionalAreaList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(ss, (Map<String, String[]>) request.getParameterMap(), "nonconformanceCategoryList");
        CheckboxItemServiceImpl.getSelectedCheckboxItems(ss, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");
    }
}
