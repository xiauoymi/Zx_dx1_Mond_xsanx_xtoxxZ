//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.wst.ccas.actionForms.StopSaleFilterForm;
import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exportTool.ExportClass;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.ExportBean;
import com.monsanto.wst.ccas.taglib.reportTag.ReportTag;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.util.Map;

/**
 * MyEclipse Struts Creation date: 06-22-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/stopSaleFilter" name="stopSaleFilterForm" scope="request"
 */
public class StopSaleFilterAction extends DispatchAction {

    private static final Category logger = Category.getInstance(StopSaleFilterAction.class.getName());
    private static String fileName;
    private static String sheetName;
    private final ComplaintService complaintService;
    private final CheckboxItemService functionalAreaService;
    private final CheckboxItemService nonconformanceCategoryService;
    private final CheckboxItemService rootCauseService;
    private final CheckboxItemDao functionalAreaDAO;

    public StopSaleFilterAction() {
        functionalAreaDAO = new FunctionalAreaDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
        complaintService = new ComplaintServiceImpl();
        functionalAreaService = new CheckboxItemServiceImpl(functionalAreaDAO);
        nonconformanceCategoryService = new CheckboxItemServiceImpl(new NonconformanceCategoryDaoImpl());
        rootCauseService = new CheckboxItemServiceImpl(new RootCauseDaoImpl());
    }

    public StopSaleFilterAction(ComplaintService complaintService, CheckboxItemService functionalAreaService,
                                CheckboxItemDao functionalAreaDAO, CheckboxItemService nonconformanceService, CheckboxItemService rootCauseService) {
        this.complaintService = complaintService;
        this.functionalAreaService = functionalAreaService;
        this.functionalAreaDAO = functionalAreaDAO;
        this.nonconformanceCategoryService = nonconformanceService;
        this.rootCauseService = rootCauseService;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        User user = (User) request.getSession().getAttribute(User.USER);
        int businessId = getUserBusinessId(user);
        new ActionHelper().setApplicationInfoMap(request, businessId, getServlet());
        StopSaleFilterForm stopSaleFilterForm = (StopSaleFilterForm) form;
        getStopSaleDefaultLists(request);
        displayTapRootCause(businessId, stopSaleFilterForm, user.getLocale(), request.getSession().getAttribute("APPLICATION_NAME").toString());
        request.setAttribute(AuditAction.BUSINESS_ID, businessId);
        return mapping.findForward("success");
    }

    private void displayTapRootCause(int businessId, StopSaleFilterForm stopSaleFilterForm, String locale, String app) {
        nonconformanceCategoryService.setCheckboxGroupsForObject(businessId, false, MCASConstants.SOURCE_TYPE_STOP_SALE, stopSaleFilterForm.getStopSaleFilter(), null, locale, null,app );
        rootCauseService.setCheckboxGroupsForObject(businessId, false, MCASConstants.SOURCE_TYPE_STOP_SALE, stopSaleFilterForm.getStopSaleFilter(), null, locale, null, app);
    }

    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleFilterForm stopSaleFilterForm = (StopSaleFilterForm) form;
        //**1. Call the getCparReportList() Service/DAO to get HashMap of Data (hash)

        User user = (User) request.getSession().getAttribute(User.USER);

        Map<String, RowBean> hash;
        try {
            StopSaleService cs = (StopSaleService) ServiceLocator.locateService(StopSaleService.class);
//      logger.error("before get report");
            hash = cs.getStopSaleReport(stopSaleFilterForm.getStopSaleFilter(), request.getParameterMap(), user.getLocale());
//      logger.error("after get report" + hash.size());
        } catch (ServiceException e) {
            MCASLogUtil.logError("Exception thrown by 'getStopSaleReport()' Service.", e);
            throw new Exception(e);
        }
        //**2. Set the hash(data), xmlIn(report-struct), sortBy and sortOrder in the cparFilter FormBean.
        stopSaleFilterForm.setHash(hash);
        String file;
        InputStream xmlIn = null;
        try {
            file = McasProperties.getMcasProperties().getString("stopSale.reportStructure");
            ClassLoader classLoader = CparFilterAction.class.getClassLoader();
            xmlIn = classLoader.getResourceAsStream(file);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Property Error: Problem getting the StopSale-Report-Structure.Xml filename.", ex);
            throw new Exception(ex);
        }
        stopSaleFilterForm.setXmlIn(xmlIn);
        stopSaleFilterForm.setSortBy("col1");
        stopSaleFilterForm.setSortOrder("asc");
        return mapping.findForward("success");
    }

    /**
     * Method export
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward export(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {

//    logger.info("Export to Excel called...");

        //**The Export Functionality...

        ServletOutputStream sos = null;
        BufferedOutputStream bos = null;

        try {

            ExportBean exportBean = ReportTag.getExportData();

            fileName = exportBean.getExcelFileName();
            sheetName = exportBean.getExcelSheetName();

            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "filename=" + fileName);

            sos = response.getOutputStream();
            bos = new BufferedOutputStream(sos);

            ExportClass export2Excel = new ExportClass();

            //**Custom STEP: Set the sheetName, totalFields, colHeader(RowBean) and Data Vector...
            export2Excel.setSheetName(sheetName);
            export2Excel.setTotalFields(exportBean.getTotalFields());
            export2Excel.setColHeader(exportBean.getExportColHeader());
            export2Excel.setVector(exportBean.getExportDataVector());

            export2Excel.setBos(bos);

            export2Excel.exportExcel();

            bos = export2Excel.getBos();

            bos.flush();
        }
        catch (Exception ex) {
            MCASLogUtil.logError("-> Error exporting Stop Sale Report.", ex);
        }
        finally {
            MCASResourceUtil.closeResource(bos);
            MCASResourceUtil.closeResource(sos);
        }

//    logger.info("-> Excel file created.");

        return mapping.findForward("success");
    }

    /**
     * To fill up the location, status, region list etc...
     */
    private void getStopSaleDefaultLists(HttpServletRequest request) {
        try {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute(User.USER);
            int businessId = getUserBusinessId(user);
            session.setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, null);
            ActionHelper actionHelper = new ActionHelper();
            if (session.getAttribute(ActionHelperConstants.CROP_LIST) == null)
                session.setAttribute(ActionHelperConstants.CROP_LIST, actionHelper.getCropList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.LOCATION_LIST) == null)
                session.setAttribute(ActionHelperConstants.LOCATION_LIST,
                        actionHelper.getLocationList(businessId, user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST) == null)
                session
                        .setAttribute(ActionHelperConstants.QUALITY_ISSUE_LIST, actionHelper.getQualityissueList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.SALES_YEAR_LIST) == null)
                session.setAttribute(ActionHelperConstants.SALES_YEAR_LIST, actionHelper.getSalesyearList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.SEED_SIZE_LIST) == null)
                session.setAttribute(ActionHelperConstants.SEED_SIZE_LIST, actionHelper.getSeedsizeList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.STATE_LIST) == null)
                session.setAttribute(ActionHelperConstants.STATE_LIST, actionHelper.getStatesList());
            if (session.getAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST) == null)
                session
                        .setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, actionHelper.getAllStatusList("STOP SALE", user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.UOM_LIST) == null)
                session.setAttribute(ActionHelperConstants.UOM_LIST, actionHelper.getUomList(user.getLocale()));
            if (session.getAttribute(ActionHelperConstants.ALL_REGION_LIST) == null) {
                String userId = ((User) request.getSession().getAttribute("user")).getUser_id();
                session.setAttribute(ActionHelperConstants.ALL_REGION_LIST,
                        new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale()));
            }

        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    private int getUserBusinessId(User user) throws ServiceException {
        BusinessService service = (BusinessService) ServiceLocator.locateService(BusinessService.class);
        return service.getBusinessId(user);
    }

}
