//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.3/xslt/JavaClass.xsl

package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.StopSaleListForm;
import com.monsanto.wst.ccas.model.StopSaleListObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.StopSaleService;
import com.monsanto.wst.ccas.service.StopSaleServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * MyEclipse Struts Creation date: 05-17-2005 <p/> XDoclet definition:
 *
 * @struts:action path="/stopSaleList" name="stopSaleListForm"
 */
public class StopSaleListAction extends DispatchAction {

    private static final Category logger = Category.getInstance(StopSaleListAction.class.getName());

    private String sortCriteria;
    private String sortOrder;
    private final SessionHelper sessionHelper;
    private final ActionHelper actionHelper;
    private final StopSaleService stopSaleService;

    public StopSaleListAction() {
        sessionHelper = new SessionHelper();
        actionHelper = new ActionHelper();
        stopSaleService = new StopSaleServiceImpl();
    }

    public StopSaleListAction(StopSaleService stopSaleService, ActionHelper actionHelper, SessionHelper sessionHelper) {
        this.stopSaleService = stopSaleService;
        this.actionHelper = actionHelper;
        this.sessionHelper = sessionHelper;
    }

    /**
     * Method display
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward display(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        setRequiredList(request);
        sessionHelper.retainStopSaleDropdownValues(request, "display");
        return mapping.findForward("success");
    }


    /**
     * Method submit
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward submit(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
        User user = (User) request.getSession().getAttribute(User.USER);
        int userBusinessPreferenceId = actionHelper.getUserBusinessPreference(user);
        stopSaleListForm.getStopSaleFilter().setStopSaleBusinessId(Integer.toString(userBusinessPreferenceId));

        String selectedPage = request.getParameter("selectedPage");
        selectedPage = (!StringUtils.isNullOrEmpty(selectedPage)) ? selectedPage : "1";
        request.getSession().setAttribute("selectedPage", selectedPage);

        if (request.getParameter("isPaging").equals("true")) {
            sortCriteria = request.getParameter("sortCriteria");
            sortOrder = request.getParameter("sortOrder");
            request.getSession().setAttribute("lastStopSaleSortCriteria", sortCriteria);
            request.getSession().setAttribute("lastStopSaleSortOrder", sortOrder);
        } else {
            getSortValues(request);
        }

        Map<String, Object> stopSaleList = null;
        float pages = 0;
        HttpSession session = request.getSession();

        int pageNumber;
        if (!StringUtils.isNullOrEmpty(request.getParameter("pageNumber")) &&
                request.getParameter("reset").equals("false")) {
            pageNumber = Integer.parseInt(request.getParameter("pageNumber"));
            stopSaleList = stopSaleService
                    .getStopSaleList(stopSaleListForm.getStopSaleFilter(), request.getParameter("pageNumber"),
                            Boolean.getBoolean(request.getParameter("getMax")), sortCriteria, sortOrder, user.getLocale());

            if (request.getParameter("getMax").equals("true")) {
                session.setAttribute("pageNumber", "1");
            } else {
                if (pageNumber < 11 && pageNumber > 0)
                    session.setAttribute("pageNumber", "1");
                else
                    session.setAttribute("pageNumber", request.getParameter("pageNumber"));
            }
        }
        if (stopSaleList != null && !stopSaleList.isEmpty()) {
            pages = Float.parseFloat(stopSaleList.get("maxRows").toString());
            stopSaleList.remove("maxRows");
            if (stopSaleList.size() > 0 && pages > 0) {
                session.setAttribute("pages", pages / 10);
            }
        }
        stopSaleListForm.setStopSaleMap(stopSaleList);
        sessionHelper.retainStopSaleDropdownValues(request, "submit");
        return mapping.findForward("success");
    }


    /**
     * Method reset
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward reset(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        StopSaleListForm stopSaleListForm = (StopSaleListForm) form;
        User user = ((User) request.getSession().getAttribute(User.USER));
        int businessPreferenceId = actionHelper.getUserBusinessPreference(user);
        setRequiredList(request);
        StopSaleListObject stopSaleListObj = new StopSaleListObject();
        stopSaleListForm.setStopSaleFilter(stopSaleListObj);
        stopSaleListForm.setStopSaleMap(new HashMap());
        actionHelper.setApplicationInfoMap(request, businessPreferenceId, getServlet());
        resetSortOrder(request);
        return mapping.findForward("success");
    }

    /**
     * Method sort
     *
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return ActionForward
     */
    public ActionForward sort(
            ActionMapping mapping,
            ActionForm form,
            HttpServletRequest request,
            HttpServletResponse response) {
        setRequiredList(request);
        getSortValues(request);
        return mapping.findForward("success");
    }

    /**
     * To fill all the Lists in the combo-box
     *
     * @param request
     */
    void setRequiredList(HttpServletRequest request) {
        try {
            User user = (User) request.getSession().getAttribute(User.USER);
            String userId = user.getUser_id();
            int userBusinessPreferenceId = actionHelper.getUserBusinessPreference(user);
            request.setAttribute("userBusinessPreference", userBusinessPreferenceId + "");
            request.getSession().setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_REGION_LIST,
                    actionHelper.getRegionsForSearch(userId, userBusinessPreferenceId, false, user.getLocale()));
            request.getSession().setAttribute(ActionHelperConstants.STOP_SALE_STATUS_LIST, actionHelper.getAllStatusList("STOP SALE", user.getLocale()));
            request.getSession().setAttribute(ActionHelperConstants.USER_BUSINESS_PREFERENCE_CROP_LIST,
                    actionHelper.getBusinessPreferenceRelatedCropList(userBusinessPreferenceId, user.getLocale()));
            request.getSession().setAttribute("salesyearList", actionHelper.getSalesyearList(user.getLocale()));
            sessionHelper.setDefaultMaterialGroups(request.getSession());
            sessionHelper.setDefaultMaterrialGroupPricings(request.getSession());
            setLocationsForApplication(request);
        }
        catch (Exception ex) {
            MCASLogUtil.logError("Error getting the Lists: ", ex);
        }
    }

    private void setLocationsForApplication(HttpServletRequest request) throws Exception {
        sessionHelper.setAppSpecificReferenceData(request, false);
    }

    /**
     * To get the sortCriteria and determine the sortOrder.
     *
     * @param request
     */
    private void getSortValues(HttpServletRequest request) {
        sortOrder = "asc";
        sortCriteria = request.getParameter("sortCriteria");
        String lastSortCriteria = request.getSession().getAttribute("lastStopSaleSortCriteria") + "";
        if (!StringUtils.isNullOrEmpty(sortCriteria) && sortCriteria.equalsIgnoreCase(lastSortCriteria)) {
            sortOrder = request.getSession().getAttribute("lastStopSaleSortOrder") + "";
            if (!StringUtils.isNullOrEmpty(sortOrder)) {
                sortOrder = "asc".equalsIgnoreCase(sortOrder) ? "desc" : "asc";
            }
        }
        request.getSession().setAttribute("lastStopSaleSortCriteria", sortCriteria);
        request.getSession().setAttribute("lastStopSaleSortOrder", sortOrder);
    }

    /**
     * To reset the sortOrder after every submit or refresh(display).
     *
     * @param request
     */
    private void resetSortOrder(HttpServletRequest request) {
        request.getSession().setAttribute("lastStopSaleSortOrder", "desc");
    }
}
