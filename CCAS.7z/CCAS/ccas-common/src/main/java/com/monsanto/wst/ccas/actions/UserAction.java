package com.monsanto.wst.ccas.actions;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: bghale Date: Mar 25, 2009 Time: 4:09:35 PM To change this template use File |
 * Settings | File Templates.
 */
public class UserAction extends DispatchAction {
  public ActionForward updateUserBusiness(ActionMapping mapping, ActionForm form,
                                          HttpServletRequest request, HttpServletResponse response) throws Exception {
    String forward = "successBusinessUpdate";
    User user = (User) request.getSession().getAttribute(User.USER);
    String selectedBusinessId = request.getParameter("selectedBusiness");
    if (!StringUtils.isNullOrEmpty(selectedBusinessId)) {
      user.setBusinessId(Integer.parseInt(selectedBusinessId));
      //Set the user's preference same as the user's business Id
      user.setUserBusinessPreference(user.getBusinessId());
      if (businessUpdated(user)) {
        user.setHasSelectedBusinessFromDropdown(true);
      }
      //todo is this necessary ??? remove this.
      request.getSession().setAttribute(User.USER, user);
        request.getSession().setAttribute(AuditAction.BUSINESS_ID, "" +user.getBusinessId() );



    }
      request.getSession().setAttribute(MCASConstants.DEPARTMENT_AFFECTED_LIST, new ActionHelper().getDepartmentAffectedList(user.getLocale(), user.getBusinessId()));
      return mapping.findForward(forward);
  }

  protected boolean businessUpdated(User user) throws DAOException, MCASException {
    return new ActionHelper().updateUserBusiness(user, user.getBusinessId(), true);
  }
}
