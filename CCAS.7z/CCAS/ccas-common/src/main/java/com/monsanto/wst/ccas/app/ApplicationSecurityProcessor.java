package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.CparForm;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Oct 13, 2010
 * Time: 1:13:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ApplicationSecurityProcessor {

    boolean isAuditReadOnly(AuditForm form, User user);
    boolean isComplaintReadOnly(ComplaintForm form, User user);
    boolean isCparReadOnly(CparForm form, User user);
    boolean isActionItemReadOnly(CparForm form, String responsiblePerson, User user);
}
