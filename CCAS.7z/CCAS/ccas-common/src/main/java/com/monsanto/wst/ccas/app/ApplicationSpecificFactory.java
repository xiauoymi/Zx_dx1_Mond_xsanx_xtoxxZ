package com.monsanto.wst.ccas.app;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ApplicationSpecificFactory {
    ComplaintProcessor getComplaintProcessor();

    StopSaleProcessor getStopSaleProcessor();

    CparProcessor getCparProcessor();

    ReferenceDataProcessor getReferenceDataProcessor();

    ApplicationSecurityProcessor getApplicationSecurityProcessor();

}
