/*
 ApplicationComplaintProcessorFactoryImpl was created on Jan 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.app.biotechfas.BiotechfasAppSpecificFactory;
import com.monsanto.wst.ccas.app.btfas.BtfasAppSpecificFactory;
import com.monsanto.wst.ccas.app.mcas.McasAppSpecificFactory;
import com.monsanto.wst.ccas.app.sbfas.SbfasAppSpecificFactory;
import com.monsanto.wst.ccas.service.ServiceException;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: ApplicationSpecificProcessorFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ApplicationSpecificProcessorFactoryImpl implements ApplicationSpecificProcessorFactory {
    private final Map<String, ApplicationSpecificFactory> factoryMap = new HashMap<String, ApplicationSpecificFactory>();

    public ApplicationSpecificProcessorFactoryImpl() {
        addDefaultMappings();
    }

    void addDefaultMappings() {
        addAppMapping("btfas", new BtfasAppSpecificFactory());
        addAppMapping("mcas", new McasAppSpecificFactory());
        addAppMapping("sbfas", new SbfasAppSpecificFactory());
        addAppMapping("biotechfas", new BiotechfasAppSpecificFactory());
    }

    void addAppMapping(String appName, ApplicationSpecificFactory factory) {
        factoryMap.put(appName, factory);
    }

    public ApplicationSpecificFactory getApplicationSpecificProcessor(String applicationName) throws
            ServiceException {
        ApplicationSpecificFactory factory = factoryMap.get(applicationName);
        if (factory == null) {
            throw new RuntimeException("Unknown Application: " + applicationName);
        } else {
            return factory;
        }
    }
}
