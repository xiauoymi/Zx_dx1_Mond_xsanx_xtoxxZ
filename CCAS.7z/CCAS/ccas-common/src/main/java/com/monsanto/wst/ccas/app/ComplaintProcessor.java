package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.ServiceException;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;

public interface ComplaintProcessor {
    String createCpar(HttpServletRequest request, Complaint complaint, CparService cpars, String forward) throws ServiceException;

    ActionErrors processComplaint(Complaint complaint, User user) throws ServiceException;

    void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                            boolean complaintInsert, String complaintEditParam, boolean sendCondensedEmail) throws ServiceException,
        EmailAddressRetrievalException;

    String isClaimValidExcel(Complaint c, int businessId);

    /*void sendComplaintEmailCreateFromExcel(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                            boolean complaintInsert, String complaintEditParam, boolean sendCondensedEmail) throws ServiceException,
        EmailAddressRetrievalException;*/
}
