package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.service.ServiceException;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServlet;

public interface CparProcessor {
    ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request);

    void postProcessCpar(Cpar cpar, HttpServletRequest request) throws ServiceException;

    void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception;

    void setCparDynamicValues(Cpar cpar, HttpServletRequest request) throws Exception;

    void sendCparEmail(Cpar cpar, HttpServletRequest request) throws EmailException;
}
