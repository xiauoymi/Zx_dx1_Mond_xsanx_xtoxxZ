/*
 EntryTypeFactoryImpl was created on Oct 7, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.constants.MCASConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@SuppressWarnings({"JavaDoc"})
public class EntryTypeFactoryImpl implements EntryTypeFactory {

    private Map<String, EntryType> factory = new HashMap<String, EntryType>();

    public EntryTypeFactoryImpl() {
        addDefaultMappings();
    }

    void addDefaultMappings() {
        if (factory == null) {
            factory = new HashMap<String, EntryType>();
        }
        factory.put(MCASConstants.ENTRY_TYPE_DEFAULT, new FeedbackEntryType());
        factory.put(MCASConstants.COMPLAINT_NCR, new NCREntryType());
        factory.put(MCASConstants.COMPLAINT_DEV, new DEVEntryType());
    }

    public String getEntryType(String entryType) {
        return factory.get(entryType).getType();
    }

    public String getEntryTypeEmaiSubject(String entryType) {
        return factory.get(entryType).getEmailSubject();
    }
}
