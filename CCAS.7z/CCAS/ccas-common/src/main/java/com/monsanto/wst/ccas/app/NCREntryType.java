/*
 NCREntryType was created on Oct 7, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.resources.McasProperties;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class NCREntryType implements EntryType {
    public String getEmailSubject() {
        return McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.complaintNCREntrySubject");
    }

    public String getType() {
        return MCASConstants.COMPLAINT_NCR;
    }
}