package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.model.Cpar;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;

/**
 * User: BGHALE
 * Date: Jul 1, 2009
 * Time: 9:08:40 AM
 */
public class NoOpCparProcessor implements CparProcessor {
    public ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request) {
        return null;
    }

    public void postProcessCpar(Cpar cpar, HttpServletRequest request) {
    }

    public void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {
    }

    public void setCparDynamicValues(Cpar cpar, HttpServletRequest request) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendCparEmail(Cpar cpar, HttpServletRequest request) {
    }
}
