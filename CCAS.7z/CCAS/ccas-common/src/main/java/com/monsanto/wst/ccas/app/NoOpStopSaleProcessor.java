package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.model.User;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class NoOpStopSaleProcessor implements StopSaleProcessor {
    public void processStopSale(StopSaleObject complaint, User user) {
    }

    public void sendStopSaleEmail(StopSaleObject stopSale, String stopSalePreview, boolean stopSaleInsert, boolean attachFileAction, String locale) {
    }
}
