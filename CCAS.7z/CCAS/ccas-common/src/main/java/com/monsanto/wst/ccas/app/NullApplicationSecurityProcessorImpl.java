package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.CparForm;
import com.monsanto.wst.ccas.model.User;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Oct 13, 2010
 * Time: 1:15:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class NullApplicationSecurityProcessorImpl implements ApplicationSecurityProcessor {
    public boolean isAuditReadOnly(AuditForm form, User user) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isComplaintReadOnly(ComplaintForm form, User user) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isCparReadOnly(CparForm form, User user) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isActionItemReadOnly(CparForm form, String responsiblePerson, User user) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
