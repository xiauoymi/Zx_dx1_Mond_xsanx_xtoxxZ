package com.monsanto.wst.ccas.app;

import javax.servlet.http.HttpServletRequest;

public interface ReferenceDataProcessor {
    void setReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception;
}
