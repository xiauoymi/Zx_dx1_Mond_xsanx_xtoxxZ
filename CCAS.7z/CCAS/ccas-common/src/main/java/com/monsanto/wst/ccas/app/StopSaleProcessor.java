package com.monsanto.wst.ccas.app;

import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.model.User;

public interface StopSaleProcessor {
    void processStopSale(StopSaleObject complaint, User user);

    void sendStopSaleEmail(StopSaleObject stopSale, String stopSalePreview, boolean stopSaleInsert, boolean attachFileAction, String locale) throws EmailAddressRetrievalException, EmailException;
}
