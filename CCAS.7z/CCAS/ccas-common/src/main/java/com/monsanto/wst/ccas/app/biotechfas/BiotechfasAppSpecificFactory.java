package com.monsanto.wst.ccas.app.biotechfas;

import com.monsanto.wst.ccas.app.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class BiotechfasAppSpecificFactory implements ApplicationSpecificFactory {
    public ComplaintProcessor getComplaintProcessor() {
        return new BiotechfasComplaintProcessorImpl();
    }

    public StopSaleProcessor getStopSaleProcessor() {
        return new NoOpStopSaleProcessor();
    }

    public CparProcessor getCparProcessor() {
        return new BiotechfasCParProcessorImpl();
    }

    public ReferenceDataProcessor getReferenceDataProcessor() {
        return new BiotechfasReferenceDataProcessorImpl();
    }

    public ApplicationSecurityProcessor getApplicationSecurityProcessor() {
        return new NullApplicationSecurityProcessorImpl();
    }
}
