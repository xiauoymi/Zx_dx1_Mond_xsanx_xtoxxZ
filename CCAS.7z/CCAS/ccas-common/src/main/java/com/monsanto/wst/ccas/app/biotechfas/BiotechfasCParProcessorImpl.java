/*
 BiotechfasCParProcessorImpl was created on Aug 19, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app.biotechfas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.CparProcessor;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.actionForms.CparListForm;
import com.monsanto.wst.ccas.actionForms.CparListObject;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class BiotechfasCParProcessorImpl implements CparProcessor {
    private final ActionHelper actionHelper;
    private final ProgramService programService;
    private final SubFunctionService subFunctionService;
    private final IEmailService emailService;
    private final CCASEmailUtilImpl emailUtil;
    private final LookUpService lookupService;
    private final static int CAR_TYPE = 1;
    private final static int PAR_TYPE = 2;
    private final static int CI_TYPE = 4;

    public BiotechfasCParProcessorImpl() {
        emailService = new EmailService();
        actionHelper = new ActionHelper();
        programService = new ProgramServiceImpl();
        subFunctionService = new SubFunctionServiceImpl();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
        lookupService = new LookUpServiceImpl();
    }

    public BiotechfasCParProcessorImpl(ActionHelper actionHelper, ProgramService programService,
                                       SubFunctionService subFunctionService, IEmailService emailService,
                                       CCASEmailUtilImpl emailUtil, LookUpService lookupService) {
        this.actionHelper = actionHelper;
        this.programService = programService;
        this.subFunctionService = subFunctionService;
        this.emailService = emailService;
        this.emailUtil = emailUtil;
        this.lookupService = lookupService;
    }

    public ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        cpar.setFunctionId("");
        populateCparDetails(request, type, cpar);
        /*if (cpar.getType() != CparConstants.GEN_FINDING_OBJ_TYPE_CAR) {
            if (StringUtils.isNullOrEmpty(cpar.getContinual_Improvements())) {
                errors.add("continualImprovements", new ActionMessage("com.monsanto.wst.ccas.cpar.isContinualImprovement"));
            }
        }*/
        return errors;
    }

    private void populateCparDetails(HttpServletRequest request, int type, Cpar cparObject) {
        if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.IS_CAR_FLAG))) {
            cparObject.setType(type);
            actionHelper.getCARData(request, cparObject);
            cparObject.setGenerator("");
            cparObject.setRegion(MCASConstants.DEFAULT_REGION_ID);
            request.getSession().setAttribute(CparConstants.CPAR_TYPE, String.valueOf(cparObject.getType()));
            request.setAttribute(MCASConstants.CPAR_FILING_PROGRAM, cparObject.getFilingProgramId());
            request.setAttribute(MCASConstants.CPAR_RESPONSIBLE_PROGRAM, cparObject.getFilingProgramId());
        }
    }

    public void postProcessCpar(Cpar cpar, HttpServletRequest request) throws ServiceException {
        boolean autoSendEmail = true;
        EmailInfo emailInfo;
        String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.AppName");
        String cparControlNumber = cpar.getControl_number();
        String[] emails;
        String url = (request.getRequestURL().toString().split(request.getContextPath()))[0] + request.getContextPath();
        //String urlLink=url+"/cpar.do?method=cparEdit&cparId="+cparID;
        String cparStr = "";
        String type = "";
        String oldCparStatus = "";
        boolean isParEdit = request.getSession().getAttribute("cparEdit").equals("true") && cpar.getCar_flag().equals("N");

        //Only send email on Update action when is CAR  or new CAR/PAR - Client Request
        if (!isParEdit) {
            if (request.getSession().getAttribute("cparEdit").equals("true")) {
                oldCparStatus = cpar.getOldStatusId();
                if (request.getParameter("statusChanged").equals("true") ||
                        (!StringUtils.isNullOrEmpty(oldCparStatus) && !oldCparStatus.equals(cpar.getStatus_id()))) {
                    type = ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED;
                }
                cpar.setOldStatusId(cpar.getStatus_id());
            } else {
                type = ActionHelperConstants.EMAIL_TYPE_CPAR_NEW;
            }

            try {
                String initiatedBy = emailUtil.getEmailAddressForUser(cpar.getInitiated_by());
                StringBuffer emailBuffer = new StringBuffer();
                emailBuffer.append(initiatedBy).append(";");
                if (!StringUtils.isNullOrEmpty(cpar.getSite_manager())) {
                    emailBuffer.append(emailUtil.getEmailAddressForUser(cpar.getSite_manager())).append(";");
                }
                ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");

            String environment = System.getProperty("lsi.function");
            String adminEmailList=bundle.getString(environment+".admin.mail.account");

                emails = emailBuffer.toString().split(";");
                if (cpar.getCar_flag().equals("Y"))
                    cparStr = "CAR";
                else
                    cparStr = "PAR";

                boolean isCI = cpar.getControl_number().startsWith("CI");
                if(isCI){
                   cparStr = "CI";
                }
                
                if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW) && emails.length > 0) {
                    emailInfo = new EmailInfo();
                    String[] locationOwners = lookupService.getEmail(cpar.getResponsible_location());

                    emailInfo.setToArray(emails);
                    for(String locationOwner:locationOwners){
                    if(!StringUtils.isNullOrEmpty(locationOwner)){
                        emailInfo.appendTo((locationOwner));
                    }
                        emailInfo.appendTo(adminEmailList);
                }
                    if (emails.length > 1 && emails[1] != null)
                        emailInfo.setCc(emails[1]);
                    emailInfo.setFrom(lookupService.getEmail(MCASConstants.ADMIN_EMAIL)[0]);
                    String cparEmailBody =
                            "A new " + cparStr + " (" + cparStr + ": '" + cparControlNumber + "') has been entered into the " +
                                    appName + " system and is attached to this email. " +
                                    " For modifications and updates to the " + cparStr +
                                    " click here to logon to the " + appName + " system: " + url + "\n";//+emailFooter;
                    emailInfo.setSubject("New " + cparStr + ": '" + cparControlNumber + " has been created");
                    emailInfo.setBody(cparEmailBody + " " + request.getParameter("printPreviewSrc"));
                     emailInfo.appendTo(adminEmailList);
                    emailService.sendMailOnObjectCreate(emailInfo, autoSendEmail);
                }
            } catch (EmailAddressRetrievalException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new ServiceException(e.getMessage(), e);
            } catch (EmailException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new ServiceException(e.getMessage(), e);
            }
        }
    }

    public void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {

        User user = (User) request.getSession().getAttribute(User.USER);

        setGeneratorData(request, CparConstants.GEN_FINDING_OBJ_TYPE_CAR, type);
        setFindingTypeData(request, CparConstants.GEN_FINDING_OBJ_TYPE_CAR, type);
        String filingProgramId = getProgramId(request, MCASConstants.CPAR_FILING_PROGRAM);
        String responsibleProgramId = getProgramId(request, MCASConstants.CPAR_RESPONSIBLE_PROGRAM);

        if (filingProgramId == null && responsibleProgramId == null &&
                request.getSession().getAttribute("cparListForm") != null) {
            CparListForm form = (CparListForm) request.getSession().getAttribute("cparListForm");
            CparListObject obj = form.getCparListObject();
            filingProgramId = obj.getFilingProgramId();
            responsibleProgramId = obj.getResponsibleProgramId();
        }


        request.getSession().setAttribute(ActionHelperConstants.FILING_PROGRAM_LIST, programService.lookupAllPrograms());
        request.getSession()
                .setAttribute(ActionHelperConstants.RESPONSIBLE_PROGRAM_LIST, programService.lookupAllPrograms());
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST,
                programService.lookupLocationsForAProgram(filingProgramId));
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST,
                programService.lookupLocationsForAProgram(responsibleProgramId));
        request.getSession().setAttribute(MCASConstants.SUBFUNCTION_LIST,
                subFunctionService.lookupAllSubFunctionsForAProgram(responsibleProgramId, user.getLocale()));
    }

    public void setCparDynamicValues(Cpar cpar, HttpServletRequest request) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendCparEmail(Cpar cpar, HttpServletRequest request) {
    }

    private String getProgramId(HttpServletRequest request, String parameter) {
        String programID = request.getParameter(parameter);
        if (StringUtils.isNullOrEmpty(programID)) {
            if (request.getAttribute(parameter) != null) {
                programID = (String) request.getAttribute(parameter);
            }
        }
        return programID;
    }

    private void setFindingTypeData(HttpServletRequest request, int type, int cparType) {

        User user = (User) request.getSession().getAttribute(User.USER);
        Map findingTypeList = actionHelper.getFindingTypeList(type, true, user.getLocale(), false, MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED);
        Map finalMap = new HashMap();

        if(cparType == CAR_TYPE){

            finalMap = findingTypeList;
            finalMap.remove("2");
            finalMap.remove("3");
        }else if(cparType == PAR_TYPE){
            finalMap = findingTypeList;
            finalMap.remove("1");

        }else if(cparType == CI_TYPE){
            finalMap = findingTypeList;
            finalMap.remove("1");
            finalMap.remove("2");
            finalMap.remove("3");

        }
        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST, finalMap);
    }

    private void setGeneratorData(HttpServletRequest request, int type, int cparType) {

        User user = (User) request.getSession().getAttribute(User.USER);
        Map generatorMap = actionHelper.getGeneratorList(type, true, user.getLocale(), MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED);
        Map finalMap = new HashMap();
        finalMap = generatorMap;
        if(cparType == CI_TYPE){
            finalMap.remove("1");
        }

        request.getSession().setAttribute(ActionHelperConstants.GENERATOR_LIST, finalMap);
    }
}
