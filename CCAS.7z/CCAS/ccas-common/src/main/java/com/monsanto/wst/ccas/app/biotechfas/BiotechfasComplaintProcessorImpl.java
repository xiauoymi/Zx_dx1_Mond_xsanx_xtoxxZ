package com.monsanto.wst.ccas.app.biotechfas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.app.EntryTypeFactory;
import com.monsanto.wst.ccas.app.EntryTypeFactoryImpl;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.ComplaintConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Date: Jun 22, 2009 Time: 1:53:31 PM
 */
public class BiotechfasComplaintProcessorImpl implements ComplaintProcessor {
    private final ActionHelper actionHelper;
    private final EmailService emailService;
    private final ComplaintService complaintService;
    private final LookUpService lookupService;
    private final static String INVESTIGATOR_EMAIL = "INVESTIGATOR_EMAIL";
    private final static String FIELD_COMMUNICATOR_EMAIL = "FIELD_COMMUNICATOR_EMAIL";
    private final CCASEmailUtilImpl emailUtil;


    public BiotechfasComplaintProcessorImpl() {
        actionHelper = new ActionHelper();
        emailService = new EmailService();
        complaintService = new ComplaintServiceImpl();
        lookupService = new LookUpServiceImpl();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
    }

    public BiotechfasComplaintProcessorImpl(ActionHelper actionHelper, EmailService emailService,
                                            ComplaintService complaintService,
                                            LookUpService lookupService, CCASEmailUtilImpl emailUtil) {
        this.actionHelper = actionHelper;
        this.emailService = emailService;
        this.complaintService = complaintService;
        this.lookupService = lookupService;
        this.emailUtil = emailUtil;
    }

    public ActionErrors processComplaint(Complaint complaint, User user
    ) throws ServiceException {
        complaint.setRegion_id(MCASConstants.DEFAULT_REGION_ID);
        complaint.setState_id(MCASConstants.DEFAULT_STATE_ID);
        complaint.setReport_date(complaint.getRow_entry_date());
        if (!StringUtils.isNullOrEmpty(complaint.getRootCausePerson()) &&
                !StringUtils.isNullOrEmpty(complaint.getRootCauseDate())
                && !StringUtils.isNullOrEmpty(complaint.getRoot_cause())) {
            complaint.setStatus_id(MCASConstants.COMPLAINT_STATUS_APPROVED);
        }
        if (!StringUtils.isNullOrEmpty(complaint.getLongTermPerson()) &&
                !StringUtils.isNullOrEmpty(complaint.getLongTermDate())
                && !StringUtils.isNullOrEmpty(complaint.getLong_term_corrective_action())) {
            complaint.setStatus_id(MCASConstants.COMPLAINT_STATUS_CLOSED);
        }
        return null;
    }

    //todo refactor. Discuss do we need a SendComplaintEmail Method
    public void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                   boolean complaintInsert,
                                   String complaintEditParam, boolean sendCondensedEmail) throws ServiceException {
        try {
            EmailInfo email = new EmailInfo();
            EntryTypeFactory entryTypeFactory = new EntryTypeFactoryImpl();
            String complaintType = entryTypeFactory.getEntryTypeEmaiSubject(complaint.getEntryType());
            email.setFrom(lookupService.getEmail(MCASConstants.ADMIN_EMAIL)[0]);
            setReportInitiatorsEmailAddress(complaint);
            email.appendTo(complaint.getReport_initiator_email());
            ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");

            String environment = System.getProperty("lsi.function");
            String adminEmailList=bundle.getString(environment+".admin.mail.account");
            email.appendTo(adminEmailList);

            if (complaintInsert) {

                if (!StringUtils.isNullOrEmpty(request.getParameter(INVESTIGATOR_EMAIL))) {
                    email.appendTo(request.getParameter(INVESTIGATOR_EMAIL));
                }
                if (!StringUtils.isNullOrEmpty(request.getParameter(FIELD_COMMUNICATOR_EMAIL))) {
                    email.appendTo(request.getParameter(FIELD_COMMUNICATOR_EMAIL));
                }

                String subjectText = new StringBuffer(complaintType).append(" ID : ").append(complaint.getComplaint_id())
                        .append(" has been created").toString();
                String emailBody = new StringBuffer("A new ").append(complaintType).append(" ID : ")
                        .append(complaint.getComplaint_id()).append(" has been inserted into the Biotech FAS system")
                        .append(request.getParameter(MCASConstants.PRINT_PREVIEW_SOURCE)).toString();
                String[] locationOwners = lookupService.getEmail(complaint.getResponsible_plant_code());

                for(String locationOwner:locationOwners){
                    if(!StringUtils.isNullOrEmpty(locationOwner)){
                        email.appendTo((locationOwner));
                    }
                }
                sendMail(email, subjectText, emailBody);
            } else if (ComplaintConstants.COMPLAINT_ENTRY_DEV.equals(complaint.getEntryType())) {

                String teamLeadReviewChanged = request.getParameter("changedTeamLeadReview");
                if (teamLeadReviewChanged != null && MCASConstants.TRUE.equalsIgnoreCase(teamLeadReviewChanged)) {

                    String coordinator = request.getParameter("c.longTermPerson");
                    if (!StringUtils.isNullOrEmpty(coordinator))
                        email.appendTo(emailUtil.getEmailAddressForUser(coordinator));

                    String subjectText = new StringBuffer(complaintType).append(" ID : ").append(complaint.getComplaint_id())
                            .append(" has been Updated").toString();
                    String emailBody = new StringBuffer("A ").append(complaintType).append(" ID : ")
                            .append(complaint.getComplaint_id()).append(" has been updated by the Team Lead in the Biotech FAS system")
                            .append(request.getParameter(MCASConstants.PRINT_PREVIEW_SOURCE)).toString();

                    sendMail(email, subjectText, emailBody);
                }
            }


        } catch (EmailAddressRetrievalException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        } catch (EmailException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public String isClaimValidExcel(Complaint c, int businessId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    private void sendMail(EmailInfo email, String subjectText, String emailBody) throws EmailException {
        email.setSubject(subjectText);
        email.setBody(emailBody);
        emailService.sendMailOnObjectCreate(email, true);
    }

    private void setReportInitiatorsEmailAddress(Complaint complaint) throws EmailAddressRetrievalException {
        complaint.setReport_initiator_email(emailUtil.getEmailAddressForUser(complaint.getReport_initiator()));
    }

    public String createCpar(HttpServletRequest request, Complaint complaint, CparService cpars,
                             String paramForward) throws ServiceException {
        String forward = paramForward;
        Map<String, String> errorMap = new HashMap<String, String>();
        if (!(request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
                && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true"))) {
            Map<String, String> carMap = cpars.findCPAR(complaint.getComplaint_id(), "Y");
            Cpar cpar = populateCparDetails(carMap, errorMap, request);
            if (actionHelper.createCar(request)) {
                forward = setRequestVariables(request, cpar, forward);
            }
            //PAR logic
            clearCparMap(carMap);
            carMap = cpars.findCPAR(complaint.getComplaint_id(), "N");
            cpar = populateCparDetails(carMap, errorMap, request);
            if (actionHelper.createPar(request)) {
                forward = setRequestVariables(request, cpar, forward);
            }
        }
        request.setAttribute("cparMap", errorMap);
        return forward;
    }

    private String setRequestVariables(HttpServletRequest request, Cpar cpar, String forward) {

        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();

        if (cpar != null && !StringUtils.isNullOrEmpty(cpar.getCpar_id())) {
            request.setAttribute("cparId", cpar.getCpar_id());
            request.setAttribute("controlNumber", cpar.getControl_number());
            CparType cparType = CparType.getType(cpar.getType());
            request.setAttribute("errorMsg", cparType.getDuplicateErrorMessage(locale));
            return forward;
        }
        return CparConstants.FORWARD_SUCCESS_CPAR;

    }

    private void clearCparMap(Map<String, String> carMap) {
        if (!carMap.isEmpty()) {
            carMap.clear();
        }
    }

    private Cpar populateCparDetails(Map<String, String> carMap, Map<String, String> errorMap,
                                     HttpServletRequest request) {
        Cpar cparObject = null;
        if (!carMap.isEmpty()) {
            for (String id : carMap.keySet()) {
                errorMap.putAll(carMap);
                cparObject = new Cpar();
                cparObject.setCpar_id(id);
                cparObject.setControl_number(carMap.get(id));
                if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CPAR_TYPE))) {
                    cparObject.setType(Integer.parseInt(request.getParameter(CparConstants.CPAR_TYPE)));
                }
            }
        }
        return cparObject;
    }
}
