package com.monsanto.wst.ccas.app.biotechfas;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.ReferenceDataProcessor;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class BiotechfasReferenceDataProcessorImpl implements ReferenceDataProcessor {
    private final ComplaintService complaintService;
    private final ProgramService programService;
    private final SubFunctionService subFunctionService;

    public BiotechfasReferenceDataProcessorImpl(ComplaintService complaintService, ProgramService service,
                                                SubFunctionService subFunctionService
    ) {
        this.complaintService = complaintService;
        this.programService = service;
        this.subFunctionService = subFunctionService;
    }

    public BiotechfasReferenceDataProcessorImpl() {
        programService = new ProgramServiceImpl();
        subFunctionService = new SubFunctionServiceImpl();
        complaintService = new ComplaintServiceImpl();
    }

    public void setReferenceData(HttpServletRequest request, boolean activeRecordsOnly) {
        String programId = getProgramId(request);
        setComplaintDefaultLocations(request, programId);
        setProgramRelatedReferenceType(request, programId);
    }

    private void setProgramRelatedReferenceType(HttpServletRequest request, String programId) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        session.setAttribute(MCASConstants.FEEDBACK_CATEGORY,
                programService.lookupCategoryForAProgram(programId, user.getLocale()));
    }

    private void setComplaintDefaultLocations(HttpServletRequest request, String id) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        Map<String, String> locationList = programService.lookupLocationsForAProgram(id);
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST, locationList);
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST,
                programService.lookupLocationsForAProgram(id));
        request.getSession().setAttribute(MCASConstants.SUBFUNCTION_LIST,
                subFunctionService.lookupAllSubFunctionsForAProgram(id, user.getLocale()));
        request.getSession().setAttribute(MCASConstants.DISPOSITION_LIST,
                complaintService.getDispositionListForDescription(user.getLocale()));
        request.getSession().setAttribute(MCASConstants.DISPOSITION_LIST_TEAMLEAD,
                complaintService.getDispositionListForDescription(user.getLocale()));
    }

    private String getProgramId(HttpServletRequest request) {
        String programID = request.getParameter("c.program_id");
        if (StringUtils.isNullOrEmpty(programID)) {
            if (request.getAttribute("programId") != null) {
                programID = request.getAttribute("programId").toString();
            } else {
                programID = request.getParameter("programId");
            }
        }
        return programID;
    }
}
