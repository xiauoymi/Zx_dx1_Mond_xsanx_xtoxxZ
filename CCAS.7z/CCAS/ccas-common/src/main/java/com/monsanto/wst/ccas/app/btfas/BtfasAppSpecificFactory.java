package com.monsanto.wst.ccas.app.btfas;

import com.monsanto.wst.ccas.app.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class BtfasAppSpecificFactory implements ApplicationSpecificFactory {
    public ComplaintProcessor getComplaintProcessor() {
        return new BtfasComplaintProcessorImpl();
    }

    public StopSaleProcessor getStopSaleProcessor() {
        return new NoOpStopSaleProcessor();
    }

    public CparProcessor getCparProcessor() {
        return new BtfasCParProcessorImpl();
    }

    public ReferenceDataProcessor getReferenceDataProcessor() {
        return new BtfasReferenceDataProcessorImpl();
    }

    public ApplicationSecurityProcessor getApplicationSecurityProcessor() {
        return new NullApplicationSecurityProcessorImpl();
    }
}
