/*
 BtfasCParProcessorImpl was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app.btfas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.CparProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.EmailService;
import com.monsanto.wst.ccas.service.LookUpService;
import com.monsanto.wst.ccas.service.ServiceException;
import com.monsanto.wst.ccas.service.ServiceLocator;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Filename:    $RCSfile: BtfasCParProcessorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: bghale $    	 On:	$Date: 2009-03-17 19:29:00 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class BtfasCParProcessorImpl implements CparProcessor {
    private final ActionHelper actionHelper;
    private final EmailService emailService;
    private final CCASEmailUtilImpl emailUtil;
    private final BusinessService businessService;

    public BtfasCParProcessorImpl() {
        actionHelper = new ActionHelper();
        emailService = new EmailService();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
        businessService = new BusinessServiceImpl();
    }

    public ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request) {

        User user = (User) request.getSession().getAttribute(User.USER);
        ActionErrors errors = new ActionErrors();
        cpar.setIssue_year(actionHelper.getDefaultYear(user.getLocale()));
        cpar.setRegion(MCASConstants.CCAS_DEFAULT_REGION_STATE);
        populateCparDetails(request, type, cpar);
        errors = performContinualImprovementCheck(cpar, errors);
        return errors;
    }

    private void populateCparDetails(HttpServletRequest request, int type, Cpar cparObject) {
        if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.IS_CAR_FLAG))) {
            cparObject.setType(type);
            actionHelper.getCARData(request, cparObject);
            request.getSession().setAttribute(CparConstants.CPAR_TYPE, String.valueOf(cparObject.getType()));
        }
    }


    public void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {
        setCparDefaultLocations(request, actionHelper);
        setGeneratorData(request, CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
        setFindingTypeData(request, CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
    }

    public void setCparDynamicValues(Cpar cpar, HttpServletRequest request) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendCparEmail(Cpar cpar, HttpServletRequest request) {
    }

    private void setFindingTypeData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST,
                actionHelper.getFindingTypeList(type, true, user.getLocale(), false, MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
    }

    private void setGeneratorData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.GENERATOR_LIST,
                actionHelper.getGeneratorList(type, true, user.getLocale(), MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
    }

    private void setCparDefaultLocations(HttpServletRequest request, ActionHelper actionHelper) {
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST,
                actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_FILING, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST,
                actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }

    /**
     * BTFAS : Send Email on CPAR Create
     *
     * @param cpar
     * @param request
     */
    public void postProcessCpar(Cpar cpar, HttpServletRequest request) throws ServiceException {

        User user = (User) request.getSession().getAttribute(User.USER);

        boolean audotSendEmail = true;
        EmailInfo emailInfo;
        String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.AppName");

        //Internalization of the header/body email for BTFAS.
        String newEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.newEmailProperty"); //word: New
        String aNewEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.aNewEmailProperty"); //word: A New
        String changeEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.changeEmailProperty");   //has been created
        String enteredMcasEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.enteredMcasEmailProperty");   // ) has been entered into the MCAS system and is attached to this email.
        String statusChangeEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeEmailProperty");   //Status Change
        String statusEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusEmailProperty");   //The status on
        String statusChangeEmail2Property = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeEmail2Property");   //has been set to
        String statusOfEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusOfEmailProperty"); //Status of
        String statusChangeEmail3Property = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeEmail3Property"); //has been changed to
        String statusChangeEmail4Property = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeEmail4Property"); //Update
        String statusChangeEmail5Property = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeEmail5Property"); //  has been updated in the MCAS system and is attached to this email

        //News Keys
        String statusChangeBTFASEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeBTFASEmailProperty"); //  has been entered into the BTFAS system and is attached to this email.
        String statusChangeBTFAS1EmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.statusChangeBTFAS1EmailProperty"); //  For modifications and updates to the
        String actionBTFASEmailProperty = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.actionBTFASEmailProperty"); //  click here to logon to the BTFAS system


        String cparControlNumber = cpar.getControl_number();
        String[] emails;
        String url = (request.getRequestURL().toString().split(request.getContextPath()))[0] + request.getContextPath();
        //String urlLink=url+"/cpar.do?method=cparEdit&cparId="+cparID;
        String cparStr = "";
        String type = "";
        String oldCparStatus = cpar.getOldStatusId();
        if (request.getSession().getAttribute("cparEdit").equals("true")) {
            oldCparStatus = cpar.getOldStatusId();
            if (request.getParameter("statusChanged").equals("true") ||
                    (!StringUtils.isNullOrEmpty(oldCparStatus) && !oldCparStatus.equals(cpar.getStatus_id()))) {
                type = ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED;
            }
            cpar.setOldStatusId(cpar.getStatus_id());
        } else {
            type = ActionHelperConstants.EMAIL_TYPE_CPAR_NEW;
        }

        try {
            LookUpService lookupService = (LookUpService) ServiceLocator.locateService(LookUpService.class);
            emails = lookupService.getEmail(cpar.getResponsible_location());
            if (cpar.getCar_flag().equals("Y"))
                cparStr = "CAR";
            else
                cparStr = "PAR";
            if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW) && emails.length > 0) {
                emailInfo = new EmailInfo();
                emailInfo.setTo(emails[0]);
                if (emails.length > 1 && emails[1] != null)
                    emailInfo.setCc(emails[1]);
                emailInfo.setFrom(actionHelper.getAdminEmail());
                //String cparEmailBody = "A new " + cparStr + " (" + cparStr + ": '" + cparControlNumber +
                //    "') has been entered into the BTFAS system and is attached to this email. " +
                //    " For modifications and updates to the " + cparStr +
                //    " click here to logon to the BTFAS system: " + url + "\n";//+emailFooter;
                String cparEmailBody = aNewEmailProperty + " " + cparStr + " (" + cparStr + ": '" + cparControlNumber +
                        "') " + statusChangeBTFASEmailProperty + " " +
                        statusChangeBTFAS1EmailProperty + " " + cparStr +
                        actionBTFASEmailProperty + " : " + url + "\n";//+emailFooter;


                //Send an email containing a preview
                //emailInfo.setSubject("New " + cparStr + ": '" + cparControlNumber + " has been created");
                emailInfo.setSubject(newEmailProperty + " " + cparStr + ": '" + cparControlNumber + " " + changeEmailProperty);
                emailInfo.setBody(cparEmailBody + " " + request.getParameter("printPreviewSrc"));
                emailService.sendMailOnObjectCreate(emailInfo, audotSendEmail);
            } else if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)) {
                emailInfo = new EmailInfo();
                emailInfo.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                emailInfo.setFrom(actionHelper.getAdminEmail());
                //emailInfo.setSubject(cparStr + " Status Change: '" + cparControlNumber + "' - " + appName);
                emailInfo.setSubject(cparStr + " " + statusChangeEmailProperty + ": '" + cparControlNumber + "' - " + appName);

                //String cparEmailStatusChagedBody =
                //    "The status on " + cparStr + " '" + cparControlNumber + "' has been set to " +
                //        actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim() +
                //        ". Click here to logon to the BTFAS system: " + url + "\n";//+emailFooter;
                String cparEmailStatusChagedBody =
                        statusEmailProperty + " " + cparStr + " '" + cparControlNumber + "' " + statusChangeEmail2Property + " " +
                                actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim() +
                                actionBTFASEmailProperty + ": " + url + "\n";//+emailFooter;


                //emailInfo.setSubject("Status of :" + cparStr + " : " + cparControlNumber + " has been changed to  " +
                emailInfo.setSubject(statusOfEmailProperty + " :" + cparStr + " : " + cparControlNumber + " " + statusChangeEmail3Property + " " +
                        actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim());
                emailInfo.setBody(cparEmailStatusChagedBody + " " + request.getParameter("printPreviewSrc"));
                emailService.sendMailOnObjectCreate(emailInfo, audotSendEmail);
            }

        }
        catch (EmailException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Error Sending Email", e);
        } catch (EmailAddressRetrievalException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    private ActionErrors performContinualImprovementCheck(Cpar cpar, ActionErrors errors) {
        if (cpar.getType() != CparConstants.GEN_FINDING_OBJ_TYPE_CAR) {


            if (StringUtils.isNullOrEmpty(cpar.getContinual_Improvements())) {
                errors.add("continualImprovements", new ActionMessage("com.monsanto.wst.ccas.cpar.isContinualImprovement"));
            }
        }
        return errors;
    }
}
