/*
 BtfasComplaintProcessorImpl was created on Jan 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app.btfas;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.ServiceException;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: BtfasComplaintProcessorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: bghale $    	 On:	$Date: 2009-03-17 19:29:00 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class BtfasComplaintProcessorImpl implements ComplaintProcessor {
  private final ActionHelper actionHelper;

  public BtfasComplaintProcessorImpl() {
    actionHelper = new ActionHelper();
  }


  public ActionErrors processComplaint(Complaint complaint, User user) {
    complaint.setSales_year_id(actionHelper.getDefaultYear(user.getLocale()));
    complaint.setRegion_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    complaint.setState_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    complaint.setReporting_location_code("7032");
    return null;
  }

  public void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                 boolean complaintInsert,
                                 String complaintEditParam, boolean sendCondensedEmail) throws ServiceException {
  }

    public String isClaimValidExcel(Complaint c, int businessId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String createCpar(HttpServletRequest request, Complaint complaint, CparService cpars,
                           String paramForward) throws ServiceException {
    String forward = paramForward;
    Map<String, String> errorMap = new HashMap<String, String>();
    if (!(request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
        && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true"))) {
      //Create CAR logic
      Map<String, String> carMap;
      Cpar cpar = null;
      carMap = cpars.findCPAR(complaint.getComplaint_id(), "Y");
      cpar = populateCparDetails(carMap, errorMap);

      if (actionHelper.createCar(request)) {
        forward = setRequestVariables(request, cpar, forward, "CAR");
      }
      //PAR logic
      clearCparMap(carMap);
      carMap = cpars.findCPAR(complaint.getComplaint_id(), "N");
      cpar = populateCparDetails(carMap, errorMap);
      if (actionHelper.createPar(request)) {
        forward = setRequestVariables(request, cpar, forward, "PAR");
      }
    }
    request.setAttribute("cparMap", errorMap);
    return forward;
  }

  private String setRequestVariables(HttpServletRequest request, Cpar cpar, String forward, String cparType) {
    String locale = ((User)request.getSession().getAttribute(User.USER)).getLocale();  

    if (cpar != null && !StringUtils.isNullOrEmpty(cpar.getCpar_id())) {
      request.setAttribute("cparId", cpar.getCpar_id());
    }
    if (cpar != null && !StringUtils.isNullOrEmpty(cpar.getControl_number())) {
      request.setAttribute("controlNumber", cpar.getControl_number());
    }

    if (cpar != null && !StringUtils.isNullOrEmpty(cpar.getCpar_id())) {
      if ("PAR".equalsIgnoreCase(cparType)) {
        String msg = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicatePar");
        request.setAttribute("errorMsg", msg);
      } else {
        String msg = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicateCar");
        request.setAttribute("errorMsg", msg);
      }
      return forward;
    } else {
      return CparConstants.FORWARD_SUCCESS_CPAR;
    }
  }

  private void clearCparMap(Map<String, String> carMap) {
    if (!carMap.isEmpty()) {
      carMap.clear();
    }
  }

  private Cpar populateCparDetails(Map<String, String> carMap, Map<String, String> errorMap) {
    Cpar cparObject = null;
    if (!carMap.isEmpty()) {
      for (String id : carMap.keySet()) {
        errorMap.putAll(carMap);
        cparObject = new Cpar();
        cparObject.setCpar_id(id);
        cparObject.setControl_number(carMap.get(id));
      }
    }
    return cparObject;
  }

}
