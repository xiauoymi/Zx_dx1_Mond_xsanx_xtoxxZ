package com.monsanto.wst.ccas.app.btfas;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.ReferenceDataProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.LookUpService;
import com.monsanto.wst.ccas.service.LookUpServiceImpl;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class BtfasReferenceDataProcessorImpl implements ReferenceDataProcessor {
    private final LookUpService service;
    private final BusinessService businessService;

    public BtfasReferenceDataProcessorImpl() {
        service = new LookUpServiceImpl();
        businessService = new BusinessServiceImpl();
    }

    public void setReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception {
        setComplaintDefaultLocations(request);
        setFeedbackCategoryList(request, activeRecordsOnly);
    }

    private void setFeedbackCategoryList(HttpServletRequest request, boolean activeRecordsOnly) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);

        session.setAttribute("feedbackCategory", service.lookUpFeedbackCategories(activeRecordsOnly, user.getLocale()));
    }

    private void setComplaintDefaultLocations(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST, new ActionHelper().getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }

}
