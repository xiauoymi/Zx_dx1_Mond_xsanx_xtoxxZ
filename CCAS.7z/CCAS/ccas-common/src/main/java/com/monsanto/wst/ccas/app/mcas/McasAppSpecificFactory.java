package com.monsanto.wst.ccas.app.mcas;

import com.monsanto.wst.ccas.app.*;
import com.monsanto.wst.ccas.stopsale.McasStopSaleProcessorImpl;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class McasAppSpecificFactory implements ApplicationSpecificFactory {
    public ComplaintProcessor getComplaintProcessor() {
        return new McasComplaintProcessorImpl();
    }

    public StopSaleProcessor getStopSaleProcessor() {
        return new McasStopSaleProcessorImpl();
    }

    public CparProcessor getCparProcessor() {
        return new McasCparProcessorImpl();
    }

    public ReferenceDataProcessor getReferenceDataProcessor() {
        return new McasReferenceDataProcessorImpl();
    }

    public ApplicationSecurityProcessor getApplicationSecurityProcessor() {
        return new NullApplicationSecurityProcessorImpl();
    }
}
