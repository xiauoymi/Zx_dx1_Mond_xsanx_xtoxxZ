/*
 McasComplaintProcessorImpl was created on Mar 21, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.app.mcas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.actions.IActionHelper;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.complaints.SalesOfficeServiceImpl;
import com.monsanto.wst.ccas.complaints.claims.Claim;
import com.monsanto.wst.ccas.complaints.claims.ClaimDaoImpl;
import com.monsanto.wst.ccas.complaints.claims.ClaimsService;
import com.monsanto.wst.ccas.complaints.claims.ClaimsServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import org.apache.log4j.Category;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: McasComplaintProcessorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-03-17 19:29:00 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class McasComplaintProcessorImpl implements ComplaintProcessor {
    private final Category logger = Category.getInstance(McasComplaintProcessorImpl.class.getName());
    private final IActionHelper actionHelper;
    private final IEmailService emailService;
    private final ClaimsService claimsService;
    private final BusinessService businessService;
    private final CCASEmailUtilImpl emailUtil;

    public McasComplaintProcessorImpl() {
        actionHelper = new ActionHelper();
        emailService = new EmailService();
        this.claimsService = new ClaimsServiceImpl(new ClaimDaoImpl(), new LookUpServiceImpl(),
                new SalesOfficeServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource()));
        this.businessService = new BusinessServiceImpl();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
    }

    public McasComplaintProcessorImpl(IActionHelper actionHelper, IEmailService emailService,
                                      ClaimsService claimsService, BusinessService businessService, CCASEmailUtilImpl emailUtil) {
        this.actionHelper = actionHelper;
        this.emailService = emailService;
        this.claimsService = claimsService;
        this.businessService = businessService;
        this.emailUtil = emailUtil;
    }

    public ActionErrors processComplaint(Complaint complaint, User user) throws ServiceException {

//        logger.info("-----McasComplaintProcessorImpl.processComplaint START-------------");
//        logger.info(user);
//        logger.info(complaint);
        int businessId = getUserBusinessId(user);
        if (businessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
            String key = actionHelper.getEmptyRegion(user.getUser_id(), complaint.getRegion_id(), user.getLocale());
            if (!StringUtils.isNullOrEmpty(key)) {
                complaint.setState_id(key);
            } else {
                complaint.setState_id(MCASConstants.DEFAULT_REGION_ID);
            }
        }
        complaint.setComplaintEntryTypeId(MCASConstants.COMPLAINT_ENTRY_TYPE_ID_COMPLAINT);
//        logger.info("-----McasComplaintProcessorImpl.processComplaint END-------------");
        return validateComplaint(complaint, businessId);
    }

    private ActionErrors validateComplaint(Complaint complaint, int businessId) {
        ActionErrors actionErrors = validateIssueType(complaint);
        String claimErrorMessage = isClaimValid(complaint, businessId);
        boolean isClosedComplaintValid = isClosedComplaintValid(complaint);
        if (!isClosedComplaintValid) {
            actionErrors.add("closedComplaintError", new ActionError("com.monsanto.wst.ccas.complaint.closedcomplaint"));
        }
        if (claimErrorMessage != null && claimErrorMessage.length() > 0) {
            actionErrors.add("claimerror", new ActionError("com.monsanto.wst.ccas.complaint.claimerror"));
        }
        validateComplaintGrowerDealerGPS(complaint, actionErrors);
        return actionErrors;
    }

    private void validateComplaintGrowerDealerGPS(Complaint complaint, ActionErrors actionErrors) {
        if (!growerDealerGpsCoordinatesValid(complaint.getGrowerLatitude())) {
            actionErrors.add("growerGpsLatitudeError", new ActionMessage("com.monsanto.wst.ccas.complaint.growerGpsLatError"));
        }
        if (!growerDealerGpsCoordinatesValid(complaint.getGrowerLongitude())) {
            actionErrors.add("growerGpsLongitudeError", new ActionMessage("com.monsanto.wst.ccas.complaint.growerGpsLongError"));
        }
        if (!growerDealerGpsCoordinatesValid(complaint.getDealerLatitude())) {
            actionErrors.add("dealerGpsLatitudeError", new ActionMessage("com.monsanto.wst.ccas.complaint.dealerGpsLatError"));
        }
        if (!growerDealerGpsCoordinatesValid(complaint.getDealerLongitude())) {
            actionErrors.add("dealerGpsLongitudeError", new ActionMessage("com.monsanto.wst.ccas.complaint.dealerGpsLongError"));
        }
    }

    private boolean growerDealerGpsCoordinatesValid(String coordinate) {
        if (!StringUtils.isNullOrEmpty(coordinate)) {
            try {
                Double.parseDouble(coordinate);// check if characters are entered
                if (coordinate.indexOf(".") != -1 && coordinate.indexOf(".") > 3) {
                    return false;
                }
            } catch (NumberFormatException nfe) {
                return false;
            }
        }
        return true;
    }

    private boolean isClosedComplaintValid(Complaint complaint) {
        if ("1".equalsIgnoreCase(complaint.getStatus_id()) && "1".equalsIgnoreCase(complaint.getRegion_id())) {
            String qualityIssue = complaint.getQuality_issue();
            if (StringUtils.isNullOrEmpty(qualityIssue)) {
                return false;
            }
        }
        return true;
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }

    public void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                   boolean complaintInsert, String complaintEditParam, boolean sendCondensedEmail, boolean hasStatusChanged)
            throws ServiceException, EmailAddressRetrievalException {
        sendComplaintEmail(request, printPreviewSrc, complaint, complaintInsert, sendCondensedEmail, hasStatusChanged);
    }


    public void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                   boolean complaintInsert,
                                   String complaintEditParam, boolean sendCondensedEmail) throws ServiceException, EmailAddressRetrievalException {
        sendComplaintEmail(request, printPreviewSrc, complaint, complaintInsert, sendCondensedEmail, complaint.statusChanged());
    }

    private void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint, boolean complaintInsert, boolean sendCondensedEmail, boolean hasStatusChanged) throws EmailAddressRetrievalException {
        MCASUtil mcasUtil = new MCASUtil();
        String locale = MCASConstants.LANGUAGE_DEFAULT;
        if (request != null)
            locale = ((User) request.getSession().getAttribute(User.USER)).getLocale();

        if (complaint.getBusinessId() == 1) {
            printPreviewSrc = mcasUtil.getRidOfMCASAdminFieldsFromEmail(printPreviewSrc);
        }
        if (sendCondensedEmail) {
            printPreviewSrc = mcasUtil.getProcessedBody(printPreviewSrc);
        }        if(complaint.getStatus_id().equalsIgnoreCase("1")){
            printPreviewSrc=mcasUtil.getRidOfMCASComplaintClosedFromEmail(printPreviewSrc,complaint.getVarietyBatchList().size());
        }
        try {
            setReportInitiatorsEmailAddress(complaint);
            sendEMails(complaint, ActionHelperConstants.EMAIL_TYPE_COMPLAINT_NEW, printPreviewSrc, locale,
                    complaintInsert, hasStatusChanged, request == null);
        } catch (EmailException e) {
            throw new ServiceException("Error sending emails" + " : Reason : " + e.getMessage(), e);
        }
    }

    private void setReportInitiatorsEmailAddress(Complaint complaint) throws EmailAddressRetrievalException {
        complaint.setReport_initiator_email(emailUtil.getEmailAddressForUser(complaint.getReport_initiator()));
    }

    private boolean sendEMails(Complaint complaint, String type, String printPreviewSrc, String locale,
                               boolean isNew, boolean complaintStatusHasChanged, boolean isUpload)
            throws EmailException, EmailAddressRetrievalException {
        String statusDescription = actionHelper.getStatusDescription(complaint.getStatus_id(), MCASConstants.STATUS_TYPE_COMPLAINT, locale);
        if(complaint.getBusinessId()==1&&!complaint.getStatus_id().equalsIgnoreCase(MCASConstants.COMPLAINT_STATUS_CLOSED)){
            return false;
        }
        if(complaint.getBusinessId()==1&&complaint.getStatus_id().equalsIgnoreCase(MCASConstants.COMPLAINT_STATUS_CLOSED)&&StringUtils.isNullOrEmpty(complaint.getInitiator_response())){
            return false;
        }
        return emailService.sendEmailForComplaint(complaint, type, printPreviewSrc, statusDescription,
                isNew, complaintStatusHasChanged, isUpload);
    }

    public String createCpar(HttpServletRequest request, Complaint complaint, CparService cpars, String forward) throws ServiceException {
        String foundCAR = "";
        String strCPARControlNumber = "";
        if (!(request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
                && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true"))) {
            //Create CAR logic
            Map<String, String> carMap = cpars.findCPAR(complaint.getComplaint_id(), "Y");
            if (!carMap.isEmpty()) {
                for (String carId : carMap.keySet()) {
                    foundCAR = carId;
                    strCPARControlNumber = carMap.get(foundCAR);
                }
            }
            if (!StringUtils.isNullOrEmpty(foundCAR)) {
                request.setAttribute("cparId", foundCAR);
            }
            if (!StringUtils.isNullOrEmpty(strCPARControlNumber)) {
                request.setAttribute("controlNumber", strCPARControlNumber);
            }
            if (!(request.getParameter("createCAR") == null || request.getParameter("iscar") == null) &&
                    request.getParameter("createCAR").equals("true")) {
                /*if (!foundCAR.equals("")) {
                    request.setAttribute("errorMsg", "Duplicate CAR. CAR for this record already exists.");
                } else {
                    forward = CparConstants.FORWARD_SUCCESS_CPAR;
                    populateComplaintFieldsToCparObject(complaint, request);
                } */
                forward = CparConstants.FORWARD_SUCCESS_CPAR;
                populateComplaintFieldsToCparObject(complaint, request);

            }
            request.setAttribute("cparMap", carMap);
        }

        return forward;
    }

    private void populateComplaintFieldsToCparObject(Complaint complaint, HttpServletRequest request) {
        appendVarietyBatchInfoWithProblemDescription(complaint);
        Cpar cparObjWithComplaintFields = new Cpar();
        cparObjWithComplaintFields.setInvestigation_findings(getFieldValue(complaint.getProblem_description()));
        cparObjWithComplaintFields.setContainment_actions(getFieldValue(complaint.getContainment_actions()));
        cparObjWithComplaintFields.setRoot_cause(getFieldValue(complaint.getRoot_cause()));
        cparObjWithComplaintFields.setLong_term_corrective_action(complaint.getLong_term_corrective_action());
        request.setAttribute("cparWithComplaintFields", cparObjWithComplaintFields);
    }

    private void appendVarietyBatchInfoWithProblemDescription(Complaint complaint) {
        StringBuffer varietyBatchBuffer = new StringBuffer("\n");
        for (VarietyBatch varietyBatch : complaint.getVarietyBatchList()) {
            formatVarietyBatch(varietyBatchBuffer, varietyBatch.getVarietyDesc(), varietyBatch.getBatchNumber());
        }
        complaint.setProblem_description(complaint.getProblem_description() + "\r\n" + varietyBatchBuffer.toString());
    }

    private void formatVarietyBatch(StringBuffer varietyBatchBuffer, String variety, String batch) {
        varietyBatchBuffer.append(StringUtils.isNullOrEmpty(variety) ? "" : variety.trim()).append("\t").append(StringUtils.isNullOrEmpty(batch) ? "" : batch.trim());
        varietyBatchBuffer.append("\r\n");
    }

    private String getFieldValue(String value) {
        return StringUtils.isNullOrEmpty(value) ? "" : value.trim();
    }

    private ActionErrors validateIssueType(Complaint c) {
        ActionErrors errors = new ActionErrors();
        if ((isIssueTypeEmpty(c.getNonconformanceCategoryList())) && "N".equalsIgnoreCase(c.getAffina_entry_flag())) {
            if (StringUtils.isNullOrEmpty(c.getDelivery_info())) {
                errors.add("allOptionsUnchecked", new ActionError("com.monsanto.wst.ccas.complaint.checkBoxes"));
            }
        }
        return errors;
    }

    private boolean isIssueTypeEmpty(List categorySelectedList) {
        return categorySelectedList == null || categorySelectedList.isEmpty();

    }

    public String isClaimValidExcel(Complaint c, int businessId) {
        String regionId = c.getRegion_id();
                if (businessId == 1 && "1".equalsIgnoreCase(regionId)) {
                    String claimNumber = c.getClaim_number();
                    if (claimNumber != null && claimNumber.length() > 0 && !("Foundation".equalsIgnoreCase(claimNumber))) {
                        String currentComplaintId = c.getComplaint_id();
                        if (claimsService.isClaimAssociatedWithAnotherComplaint(claimNumber, currentComplaintId)) {
                            return "Claim already associated with another complaint";
                        }
                    }
                }
                return "";
    }
    private String isClaimValid(Complaint c, int businessId) {
//    int id = c.getBusinessId();
        String regionId = c.getRegion_id();
        if (businessId == 1 && "1".equalsIgnoreCase(regionId)) {
            String claimNumber = c.getClaim_number();
            if (claimNumber != null && claimNumber.length() > 0 && !("Foundation".equalsIgnoreCase(claimNumber) || claimNumber.contains("CA") || claimNumber.contains("CRF") || claimNumber.contains("crf"))) {
                Claim information = claimsService.getClaimsInformation(claimNumber);
                if (information == null) {
                    return "Enter a valid Claim Number";
                }
                String currentComplaintId = c.getComplaint_id();
                if (claimsService.isClaimAssociatedWithAnotherComplaint(claimNumber, currentComplaintId)) {
                    return "Claim already associated with another complaint";
                }
            }
        }
        return "";
    }

    public void sendComplaintEmailCreateFromExcel(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                   boolean complaintInsert, String complaintEditParam, boolean sendCondensedEmail, boolean hasStatusChanged)
            throws ServiceException {
        sendComplaintEmailCreateFromExcel(request, printPreviewSrc, complaint, complaintInsert, sendCondensedEmail, hasStatusChanged);
    }


    private void sendComplaintEmailCreateFromExcel(HttpServletRequest request, String printPreviewSrc, Complaint complaint, boolean complaintInsert, boolean sendCondensedEmail, boolean hasStatusChanged ) {
        MCASUtil mcasUtil = new MCASUtil();
        String locale = MCASConstants.LANGUAGE_DEFAULT;
        if (request != null)
            locale = ((User) request.getSession().getAttribute(User.USER)).getLocale();

        if (complaint.getBusinessId() == 1) {
            printPreviewSrc = mcasUtil.getRidOfMCASAdminFieldsFromEmail(printPreviewSrc);
        }
        if (sendCondensedEmail) {
            printPreviewSrc = mcasUtil.getProcessedBody(printPreviewSrc);
        }
        try {
            setReportInitiatorsEmailAddress(complaint);
            sendEMailsCreateFromExcel(complaint, ActionHelperConstants.EMAIL_TYPE_COMPLAINT_NEW, printPreviewSrc, locale,
                    complaintInsert, hasStatusChanged, request == null);
        } catch (EmailException e) {
            throw new ServiceException("Error sending emails" + " : Reason : " + e.getMessage(), e);
        } catch (EmailAddressRetrievalException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


    public boolean sendEMailsCreateFromExcel(Complaint complaint, String type, String printPreviewSrc, String locale,
                               boolean isNew, boolean complaintStatusHasChanged, boolean isUpload)
            throws EmailException, EmailAddressRetrievalException {
        String statusDescription = actionHelper.getStatusDescription(complaint.getStatus_id(), MCASConstants.STATUS_TYPE_COMPLAINT, locale);
        return emailService.sendEmailForComplaintCreateFromExcel(complaint, type, printPreviewSrc, statusDescription,
                isNew, complaintStatusHasChanged, isUpload, Boolean.TRUE);
    }

    public void sendComplaintEmailCreateFromExcel(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                   boolean complaintInsert,
                                   String complaintEditParam, boolean sendCondensedEmail) throws ServiceException {
        sendComplaintEmailCreateFromExcel(request, printPreviewSrc, complaint, complaintInsert, sendCondensedEmail, complaint.statusChanged());
    }

}

