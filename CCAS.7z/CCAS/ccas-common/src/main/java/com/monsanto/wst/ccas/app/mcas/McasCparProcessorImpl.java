package com.monsanto.wst.ccas.app.mcas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.CparProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Date: Sep 16, 2008
 * Time: 10:34:28 AM
 */
public class McasCparProcessorImpl implements CparProcessor {
    private final ActionHelper actionHelper;
    private final CCASEmailUtilImpl emailUtil;
    private final LookUpService lookupService;
    private IEmailService emailService;
    private final BusinessService businessService;

    public McasCparProcessorImpl() {
        actionHelper = new ActionHelper();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
        lookupService = new LookUpServiceImpl();
        emailService = new EmailService();
        businessService = new BusinessServiceImpl();
    }

    public McasCparProcessorImpl(ActionHelper actionHelper, CCASEmailUtilImpl emailUtil, LookUpService lookupService, IEmailService emailService, BusinessService businessService) {
        this.actionHelper = actionHelper;
        this.emailUtil = emailUtil;
        this.lookupService = lookupService;
        this.emailService = emailService;
        this.businessService = businessService;
    }

    public void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {
        setCparDefaultLocations(request, regionId,regionResponsibleId);
        //setGeneratorData(request, CparConstants.GEN_FINDING_OBJ_TYPE_CAR);
        setGeneratorData(request, type);

        setFindingTypeData(request, type);
    }

    public void setCparDynamicValues(Cpar cpar, HttpServletRequest request) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void sendCparEmail(Cpar cpar, HttpServletRequest request) throws EmailException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    private void setFindingTypeData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST, actionHelper.getFindingTypeList(type, true, user.getLocale(), true, user.getBusinessId()));
    }

    private void setGeneratorData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.GENERATOR_LIST, actionHelper.getGeneratorList(type, true, user.getLocale(), user.getBusinessId()));
    }

    private void setCparDefaultLocations(HttpServletRequest request, String regionId,String regionsResponsibleId) {
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionId, MCASConstants.LOCATION_TYPE_FILING, locale ));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionsResponsibleId, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale  ));

    }

    public ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        //set the default Function Value for CPAR.
        cpar.setFunctionId("");
        populateCparDetails(request, type, cpar);
        MCASLogUtil.logError("After populate Cpar details control number: "+cpar.getControl_number(),new Exception());
        populateCparFieldsFromComplaint(cpar, request);
        MCASLogUtil.logError("After populate Cpar fields control number: "+cpar.getControl_number(),new Exception());
        //if (cpar.getType() != CparConstants.GEN_FINDING_OBJ_TYPE_CAR && cpar.getType() != CparConstants.GEN_FINDING_OBJ_TYPE_CI) {
        //    if (StringUtils.isNullOrEmpty(cpar.getContinual_Improvements())) {
        //        errors.add("continualImprovements", new ActionMessage("com.monsanto.wst.ccas.cpar.isContinualImprovement"));
        //    }
        //}
        return errors;
    }

    private void populateCparFieldsFromComplaint(Cpar cpar, HttpServletRequest request) {
        Cpar cparWithComplaintFields = (Cpar) request.getAttribute("cparWithComplaintFields");
        if (cparWithComplaintFields != null) {
            cpar.setInvestigation_findings(getFieldValue(cparWithComplaintFields.getInvestigation_findings()));
            cpar.setContainment_actions(getFieldValue(cparWithComplaintFields.getContainment_actions()));
            cpar.setRoot_cause(getFieldValue(cparWithComplaintFields.getRoot_cause()));
            cpar.setLong_term_corrective_action(getFieldValue(cparWithComplaintFields.getLong_term_corrective_action()));
        }
    }

    private String getFieldValue(String fieldValue) {
        return StringUtils.isNullOrEmpty(fieldValue) ? "" : fieldValue.trim();
    }

    private void populateCparDetails(HttpServletRequest request, int type, Cpar cparObject) {
        cparObject.setType(type);
        if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.IS_CAR_FLAG))) {
            if ("true".equalsIgnoreCase(request.getParameter(CparConstants.IS_CAR_FLAG))) {
                actionHelper.getCARData(request, cparObject);
            }
            request.getSession().setAttribute(CparConstants.CPAR_TYPE, String.valueOf(cparObject.getType()));
        }
    }

    private boolean containsText(String str) {

        String[] section = str.split("</p");

        for (int i = 0; i < section.length; i++) {
            if (!section[i].substring(section[i].length() - 2).equals("'>"))
                return true;
        }

        return false;
    }

    /**
     * MCAS : method to send emails upon cpar create and edit
     *
     * @param cpar
     * @param request
     */
    public void postProcessCpar(Cpar cpar, HttpServletRequest request) throws ServiceException {
        boolean autoSendEmail = true;
        EmailInfo emailInfo = new EmailInfo();
        String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.AppName");
        User user = (User) request.getSession().getAttribute(User.USER);

        //Internalization of the header/body email for MCAS.
        String locale = user.getLocale();
        String newEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.newEmailProperty"); //word: New
        String aNewEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.aNewEmailProperty"); //word: A New
        String changeEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.changeEmailProperty");   //has been created
        String enteredMcasEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.enteredMcasEmailProperty");   // ) has been entered into the MCAS system and is attached to this email.
        String statusChangeEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusChangeEmailProperty");   //Status Change
        String statusEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusEmailProperty");   //The status on
        String statusChangeEmail2Property = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusChangeEmail2Property");   //has been set to
        String statusOfEmailProperty = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusOfEmailProperty"); //Status of
        String statusChangeEmail3Property = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusChangeEmail3Property"); //has been changed to
        String statusChangeEmail4Property = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusChangeEmail4Property"); //Update
        String statusChangeEmail5Property = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.statusChangeEmail5Property"); //  has been updated in the MCAS system and is attached to this email


        String cparControlNumber = cpar.getControl_number();
        String siteManagerName;

        //String urlLink=url+"/cpar.do?method=cparEdit&cparId="+cparID;
        String cparStr = "";
        String type = "";
        type = getCparEmailType(cpar, request, type);


        cparStr = getReportType(cpar);

        try {

            emailInfo.setFrom(actionHelper.getAdminEmail());

            /* changed Feb 16th
            Row Crop rules:
                Upon creation � email Site Manager; Initiator; and Site Owner
                At any update � email Initiator; and Site Owner, email Site Manager
                At adding root_cause_person, cointanment_actions_person, long_term_corrective_action_person or evaluation_person --> email them.

            Vegetable rules:
                Upon creation � email Site Manager; Initiator
                At any update � no emails, email Site Manager
                At adding root_cause_person, cointanment_actions_person, long_term_corrective_action_person or evaluation_person --> email them.
                Status changes � email Site Manager, Location Owner
             */

            if (cpar.getBusinessId() == 2) {

                if ( cpar.getType() == 4 ) {
                    //Nico - emailing modifications 08/26/2011
                    //emailInfo.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));

                    if ( !StringUtils.isNullOrEmpty(cpar.getReport_initiator_email()) ) {
                        if(type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)||type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED)){
                            emailInfo.setTo(cpar.getReport_initiator_email());
                        }

                    }else{
                        if(type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)||type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED)){
                            emailInfo.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                        }
                    }


                }else{
                    //Nico - emailing modifications 08/26/2011
                    //emailInfo.setTo(getSiteManagerEmail(cpar));
                    if ( !StringUtils.isNullOrEmpty(cpar.getSiteManagerUserId()) ) {
                        emailInfo.setTo(cpar.getSiteManagerUserId());
                    }else{
                        emailInfo.setTo(getSiteManagerEmail(cpar));
                    }

                }

                if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW)) {
                    //Nico - emailing modifications 08/26/2011
                    //emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                    String[] locationOwners = lookupService.getEmail(cpar.getResponsible_location());
                        for (int i = 0; i < locationOwners.length; i++) {
                            if (locationOwners[i] != null)
                                emailInfo.appendTo((locationOwners[i]));
                        }
                     if ( !StringUtils.isNullOrEmpty(cpar.getReport_initiator_email()) ) {
                        emailInfo.appendTo(cpar.getReport_initiator_email());
                     }else{
                        emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                     }
                } else {
                    try {
                        String[] locationOwners = lookupService.getEmail(cpar.getResponsible_location());
                        for (int i = 0; i < locationOwners.length; i++) {
                            if (locationOwners[i] != null)
                                emailInfo.appendTo((locationOwners[i]));
                        }
                        //If this does not exist, we still have to send the emails.
                    } catch (NullPointerException e) {
                        MCASLogUtil.logError(e.getMessage(), e);
                    }

                }

            } else {
                //Nico - emailing modifications 08/26/2011
                //emailInfo.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                if ( !StringUtils.isNullOrEmpty(cpar.getReport_initiator_email()) ) {
                    if(type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)||type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED)){
                        emailInfo.appendTo(cpar.getReport_initiator_email());
                    }
                }else{
                    if(type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)||type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED)){
                        emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
                    }
                }

                
                String[] locationOwners = lookupService.getEmail(cpar.getResponsible_location());
                if (locationOwners.length > 1 && !StringUtils.isNullOrEmpty(locationOwners[1])) {
                    emailInfo.appendTo((locationOwners[1]));
                }
                if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW) && !StringUtils.isNullOrEmpty(cpar.getSite_manager())) {
                    //Nico - emailing modifications 08/26/2011
                    //emailInfo.appendTo(getSiteManagerEmail(cpar));
                    //The property site manager user id already has the format @monsanto.com
                    if ( !StringUtils.isNullOrEmpty(cpar.getSiteManagerUserId()) ) {
                        emailInfo.appendTo(cpar.getSiteManagerUserId());
                    }else{
                        emailInfo.appendTo(getSiteManagerEmail(cpar));
                    }
                }
                if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW) && !StringUtils.isNullOrEmpty(cpar.getMgmt_approval_person())) {
                    emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getMgmt_approval_person()));
                }

            }

            //Req. Mariela Vilardo new rules for emailing ON UPDATE CPAR
            //At any update - email Site Manager
            //At adding root_cause_person, cointanment_actions_person, long_term_corrective_action_person or evaluation_person --> email them.
            if (!type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW)) {
                if (!StringUtils.isNullOrEmpty(cpar.getSite_manager()))
                    //Nico - emailing modifications 08/26/2011
                    //emailInfo.appendTo(getSiteManagerEmail(cpar));
                    //The property site manager user id already has the format @monsanto.com
                if ( !StringUtils.isNullOrEmpty(cpar.getSiteManagerUserId()) ) {
                    emailInfo.appendTo(cpar.getSiteManagerUserId());
                }else{
                    emailInfo.appendTo(getSiteManagerEmail(cpar));
                }
                if (!StringUtils.isNullOrEmpty(cpar.getRoot_cause_person()))
                    emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getRoot_cause_person()));
                if (!StringUtils.isNullOrEmpty(cpar.getContainment_actions_person()))
                    emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getContainment_actions_person()));
                if (!StringUtils.isNullOrEmpty(cpar.getLong_term_corrective_action_person()))
                    emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getLong_term_corrective_action_person()));
                if (!StringUtils.isNullOrEmpty(cpar.getEvaluation_person()))
                    emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getEvaluation_person()));
            }

            //CI
            if (cpar.getType() == 4 && (cpar.getMgmt_approval_person() !=null && cpar.getMgmt_approval_person().length()>0 ) ) {
                emailInfo.appendTo(emailUtil.getEmailAddressForUser(cpar.getMgmt_approval_person()));
            }


            String printPreviewHtml = request.getParameter("printPreviewSrc");
            if (printPreviewHtml != null) {
                String[] segment = printPreviewHtml.split("<li");
                printPreviewHtml = segment[0];

                for (int i = 1; i < segment.length - 1; i++) {
                    if (segment[i].contains("' checked >") || containsText(segment[i])) {
                        printPreviewHtml += "<li " + segment[i];
                    }
                }

                printPreviewHtml += "<li " + segment[segment.length - 1];

            }

            if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_NEW)) {
                //String cparEmailBody = "A new " + cparStr + " (" + cparStr + ": '" + cparControlNumber + "') has been entered into the MCAS system and is attached to this email." + "\n";
                String cparEmailBody = aNewEmailProperty + " " + cparStr + " (" + cparStr + ": '" + cparControlNumber + ") " + enteredMcasEmailProperty + "\n";
                //emailInfo.setSubject("New " + cparStr + ": '" + cparControlNumber + " has been created");
                emailInfo.setSubject(newEmailProperty + " " + cparStr + " : '" + cparControlNumber + " " + changeEmailProperty);
                emailInfo.setBody(cparEmailBody + " " + printPreviewHtml);
                emailService.sendMailOnObjectCreate(emailInfo, autoSendEmail);
            } else if (type.equals(ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED)) {
                //emailInfo.setSubject(cparStr + " Status Change: '" + cparControlNumber + "' - " + appName);
                emailInfo.setSubject(cparStr + " " + statusChangeEmailProperty + ": '" + cparControlNumber + "' - " + appName);
                //String cparEmailStatusChagedBody = "The status on " + cparStr + " '" + cparControlNumber + "' has been set to " + actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim() + "\n";
                String cparEmailStatusChagedBody = statusEmailProperty + " " + cparStr + " '" + cparControlNumber + "' " + statusChangeEmail2Property + " " + actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim() + "\n";
                //emailInfo.setSubject("Status of :" + cparStr + " : " + cparControlNumber + " has been changed to  " + actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim());
                emailInfo.setSubject(statusOfEmailProperty + " : " + cparStr + " : " + cparControlNumber + statusChangeEmail3Property + " " + actionHelper.getAllStatusList("CPAR", user.getLocale()).get(cpar.getStatus_id()).trim());
                emailInfo.setBody(cparEmailStatusChagedBody + " " + printPreviewHtml);
                emailService.sendMailOnObjectCreate(emailInfo, autoSendEmail);
            } else if (cpar.getBusinessId() == 1) {
                //emailInfo.setSubject(cparStr + " Update: '" + cparControlNumber + "' - " + appName);
                emailInfo.setSubject(cparStr + " " + statusChangeEmail4Property + " : '" + cparControlNumber + "' - " + appName);
                //String cparEmailBody = cparStr + " (" + cparStr + ": '" + cparControlNumber + "') has been updated in the MCAS system and is attached to this email." + "\n";
                String cparEmailBody = cparStr + " (" + cparStr + " : '" + cparControlNumber + "') " + statusChangeEmail5Property + "\n";
                emailInfo.setBody(cparEmailBody + " " + printPreviewHtml);
                emailService.sendMailOnObjectCreate(emailInfo, autoSendEmail);
            }
        }
        catch (EmailException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Warning! Error sending Email to Initiator", e);
        } catch (EmailAddressRetrievalException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    private String getSiteManagerEmail(Cpar cpar) throws EmailAddressRetrievalException {
        String siteManagerName;
        siteManagerName = (lookupService.getSiteManager(cpar.getCpar_id()))[0];
        CCASEmailUtilImpl util = new CCASEmailUtilImpl(new PeopleService());
        return util.getEmailAddressForUser(siteManagerName);
    }

    private String getReportType(Cpar cpar) {

        if (cpar.getType() == 1)
            return "CAR";
        else if (cpar.getType() == 2)
            return "PAR";
        else
            return "CI";
    }

    private EmailInfo setEmailRecipients(Cpar cpar, String[] emails) throws EmailAddressRetrievalException {
        EmailInfo emailInfo;
        emailInfo = new EmailInfo();
        emailInfo.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
        emailInfo.setFrom(actionHelper.getAdminEmail());
        if (emails.length > 1 && emails[1] != null) {
            emailInfo.setCc(emails[1]);
        }
        return emailInfo;
    }

    private String getCparEmailType(Cpar cpar, HttpServletRequest request, String type) {
        String oldCparStatus;
        if (request.getSession().getAttribute("cparEdit").equals("true")) {
            oldCparStatus = cpar.getOldStatusId();
            if (request.getParameter("statusChanged").equals("true") ||
                    (!StringUtils.isNullOrEmpty(oldCparStatus) && !oldCparStatus.equals(cpar.getStatus_id()))) {
                type = ActionHelperConstants.EMAIL_TYPE_CPAR_STATUS_CHANGED;
            }
            else if(request.getParameter("findingTypeChanged").equals("true")){
                   type = ActionHelperConstants.EMAIL_TYPE_CPAR_FINDING_TYPE_CHANGED;
            }
            cpar.setOldStatusId(cpar.getStatus_id());
        } else {
            type = ActionHelperConstants.EMAIL_TYPE_CPAR_NEW;
        }
        return type;
    }


     private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }
}
