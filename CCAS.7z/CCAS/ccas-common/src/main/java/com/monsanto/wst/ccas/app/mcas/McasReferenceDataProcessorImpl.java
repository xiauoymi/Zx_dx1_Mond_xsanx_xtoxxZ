package com.monsanto.wst.ccas.app.mcas;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.ReferenceDataProcessor;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class McasReferenceDataProcessorImpl implements ReferenceDataProcessor {
    public void setReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception {
        String regionId = getRegionId(request);
        populateLocations(request, regionId);
    }

    private void populateLocations(HttpServletRequest request, String regionId) {
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        ActionHelper actionHelper = new ActionHelper();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionId, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionId, MCASConstants.LOCATION_TYPE_REPORTING, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionId, MCASConstants.LOCATION_TYPE_FILING, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_SHIPPING_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(regionId, MCASConstants.LOCATION_TYPE_SHIPPING, locale));
    }

    private String getRegionId(HttpServletRequest request) {
        String region = request.getParameter("region");
        if (StringUtils.isNullOrEmpty(region)) {
            if (request.getAttribute("regionId") != null) {
                region = request.getAttribute("regionId").toString();
            }
        }
        return region;
    }


}
