package com.monsanto.wst.ccas.app.sbfas;

import com.monsanto.wst.ccas.app.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SbfasAppSpecificFactory implements ApplicationSpecificFactory {
    public ComplaintProcessor getComplaintProcessor() {
        return new SbfasComplaintProcessorImpl();
    }

    public StopSaleProcessor getStopSaleProcessor() {
        return new NoOpStopSaleProcessor();
    }

    public CparProcessor getCparProcessor() {
        return new SbfasCParProcessorImpl();
    }

    public ReferenceDataProcessor getReferenceDataProcessor() {
        return new SbfasReferenceDataProcessorImpl();
    }

    public ApplicationSecurityProcessor getApplicationSecurityProcessor() {
        return new SbfasApplicationSecurityProcessorImpl();
    }
}
