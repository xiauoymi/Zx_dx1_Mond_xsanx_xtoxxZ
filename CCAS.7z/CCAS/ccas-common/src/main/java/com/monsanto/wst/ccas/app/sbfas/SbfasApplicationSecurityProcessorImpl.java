package com.monsanto.wst.ccas.app.sbfas;

import com.monsanto.wst.ccas.app.ApplicationSecurityProcessor;
import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.CparForm;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.Cpar;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Oct 13, 2010
 * Time: 1:17:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class SbfasApplicationSecurityProcessorImpl implements ApplicationSecurityProcessor {

    public boolean isAuditReadOnly(AuditForm form, User user) {
        AuditObject audit = form.getAuditObj();

        //new Audit
        if(audit.getCreatedBy()==null)
            return false;

        String creatorId = audit.getCreatedBy().trim();
        String userId = user.getUser_id();
         /*PCR0515164:  Feedback Response tab is not accepting free text
        if(!creatorId.equalsIgnoreCase(userId) && !user.isAdmin()) {
            return true;
        }
        */
        return false;
    }

    public boolean isComplaintReadOnly(ComplaintForm form, User user) {

        //for some reason ComplaintAction gets called when filtering complaints
        if(form==null) return false;

        Complaint complaint = form.getC();

        //new Complaint
        if(complaint.getCreated_by()==null)
            return false;

        String creatorId = complaint.getCreated_by().trim();
        String userId = user.getUser_id();
          /* PCR0515164:  Feedback Response tab is not accepting free text
        if(!creatorId.equalsIgnoreCase(userId) && !user.isAdmin()) {
            return true;
        }   */
        return false;
    }

    public boolean isCparReadOnly(CparForm form, User user) {

        Cpar cpar = form.getCpar();

        //new Cpar
        if(cpar.getCreated_by()==null)
            return false;

        String creatorId = cpar.getCreated_by().trim();
        String userId = user.getUser_id();

       // if(!creatorId.equalsIgnoreCase(userId) && !user.isAdmin()) {
         //   return true;
        //}
        if(cpar.getStatus_id().equalsIgnoreCase(MCASConstants.SBFAS_STATUS__REF_TYPE_2_CLOSED_EFFECTIVE)||
           cpar.getStatus_id().equalsIgnoreCase(MCASConstants.SBFAS_STATUS__REF_TYPE_2_CLOSED_NOT_EFFECTIVE)||
           cpar.getStatus_id().equalsIgnoreCase(MCASConstants.SBFAS_STATUS__REF_TYPE_1_CLOSED_EFFECTIVE) ||
           cpar.getStatus_id().equalsIgnoreCase(MCASConstants.SBFAS_STATUS__REF_TYPE_1_CLOSED_NOT_EFFECTIVE) ){

                      return true;
        }
        return false;
    }

    public boolean isActionItemReadOnly(CparForm form, String responsiblePerson, User user) {

        if(!isCparReadOnly(form, user))
            return false;

        Cpar cpar = form.getCpar();

        //new Cpar
        if(cpar.getCreated_by()==null)
            return false;

        String userName = user.getFull_name();

        if(responsiblePerson==null || (!userName.contains(responsiblePerson) && !user.isAdmin())) {
            return true;
        }
        return false;
    }
}
