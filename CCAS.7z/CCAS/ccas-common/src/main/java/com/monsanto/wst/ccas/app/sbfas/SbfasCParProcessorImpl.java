package com.monsanto.wst.ccas.app.sbfas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.CparProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.dao.FindingTimelineDaoImpl;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * Date: Jun 1, 2009 Time: 2:58:01 PM
 */
public class SbfasCParProcessorImpl implements CparProcessor {
    private final LookUpService lookupService;
    private final ComplaintService complaintService;
    private final ActionHelper actionHelper;
    private final CCASEmailUtilImpl emailUtil;
    private final IEmailService emailService;
    private final BusinessService businessService;

    public SbfasCParProcessorImpl(LookUpService service, ComplaintService complaintService, ActionHelper actionHelper,
                                  CCASEmailUtilImpl emailUtil, IEmailService emailService, BusinessService businessService) {
        this.lookupService = service;
        this.complaintService = complaintService;
        this.actionHelper = actionHelper;
        this.emailUtil = emailUtil;
        this.emailService = emailService;
        this.businessService = businessService;
    }

    public SbfasCParProcessorImpl() throws ServiceException {
        lookupService = new LookUpServiceImpl();
        complaintService = new ComplaintServiceImpl();
        actionHelper = new ActionHelper();
        emailUtil = new CCASEmailUtilImpl(new PeopleService());
        emailService = new EmailService();
        businessService = new BusinessServiceImpl();
    }

    public ActionErrors processCpar(Cpar cpar, int type, HttpServletRequest request) {

        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();

        populateType(cpar, type, request);
        setCparDefaults(cpar, request);
        return validateRequiredFields(cpar, locale);
    }

    private void setCparDefaults(Cpar cpar, HttpServletRequest request) {

        User user = (User) request.getSession().getAttribute(User.USER);

        cpar.setRegion(MCASConstants.CCAS_DEFAULT_REGION_STATE);
        cpar.setIssue_year(actionHelper.getDefaultYear(user.getLocale()));
        cpar.setContinual_Improvements(CparConstants.DEFAULT_CPAR_CONTINUAL_IMPROVEMENTS);
        request.getSession().setAttribute(ActionHelperConstants.GENERATOR_LIST,
                lookupService.getGenerator(cpar.getType(), isGetActiveRecordsOnly(request), user.getLocale(), MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST,
                lookupService.getFindingTypes(cpar.getType(), isGetActiveRecordsOnly(request), user.getLocale(), false, MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
        actionHelper.getCARData(request, cpar);
    }

    private boolean isGetActiveRecordsOnly(HttpServletRequest request) {
        return (request.getAttribute("displayAllGeneratorsAndFindingTypes") != null) ? false : true;
    }


    private ActionErrors validateRequiredFields(Cpar cpar, String locale) {
        ActionErrors errors = new ActionErrors();
        if (StringUtils.isNullOrEmpty(cpar.getInvestigation_findings())) {
            errors.add("", new ActionMessage("com.wst.ccas.cpar.incidentDescriptionEmpty", cpar.getreplacementValue(locale)));
        }
        validateCparDataForDifferentStatus(cpar, errors, locale);
        return errors;
    }

    private void validateCparDataForDifferentStatus(Cpar cpar, ActionErrors errors, String locale) {
        CparStatus cparStatus = CparStatus.getStatus(cpar.getStatus_id());
        List<String> errorList = new ArrayList<String>();
        if (cparStatus != null) {
            cparStatus.validate(cpar, errorList);
        }
        populateErrors(errorList, errors, cpar.getType(), locale);
    }

    private void populateErrors(List<String> errorList, ActionErrors errors, int type, String locale) {
        CparType cparType = null;
        for (String errorMessage : errorList) {
            cparType = CparType.getType(type);
            errors.add("", new ActionMessage(errorMessage, cparType.getLongTermReplacementString(errorMessage, locale)));
        }
    }

    private void populateType(Cpar cpar, int type, HttpServletRequest request) {
        cpar.setType(type);
        request.getSession().setAttribute(CparConstants.CPAR_TYPE, type);
    }

    private void setFindingTypeData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.FINDING_TYPE_LIST,
                lookupService.getFindingTypes(type, isGetActiveRecordsOnly(request), user.getLocale(), false, MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
    }

    private void setGeneratorData(HttpServletRequest request, int type) {

        User user = (User) request.getSession().getAttribute(User.USER);

        request.getSession().setAttribute(ActionHelperConstants.GENERATOR_LIST,
                lookupService.getGenerator(type, isGetActiveRecordsOnly(request), user.getLocale(), MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED));
    }

    public void postProcessCpar(Cpar cpar, HttpServletRequest request) throws ServiceException {
        if ((cpar.getComplaint_id() != null && cpar.getComplaint_id().length > 0) && !StringUtils.isNullOrEmpty(cpar.getComplaint_id()[0])) {
            synchronizeComplaintCarStatus(cpar);
        }
        sendCparEmail(cpar, request);
    }

    public void sendCparEmail(Cpar cpar, HttpServletRequest request) {
        CparStatus cparStatus = CparStatus.getStatus(cpar.getStatus_id());
        if (cparStatus instanceof CparApprovedStatus) {
            try {
                EmailInfo email = new EmailInfo();
                configureEmailProperties(cpar, request, email, cparStatus);
                emailService.sendMailOnObjectCreate(email, true);
            } catch (EmailAddressRetrievalException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new ServiceException(e.getMessage(), e);
            } catch (EmailException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new ServiceException(e.getMessage(), e);
            }
        }
    }

    private void configureEmailProperties(Cpar cpar, HttpServletRequest request, EmailInfo email,
                                          CparStatus cparStatus) throws EmailAddressRetrievalException {

        User user = (User) request.getSession().getAttribute(User.USER);
        String appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.AppName");
        String cparControlNumber = cpar.getControl_number();
        email.setFrom(actionHelper.getAdminEmail());

        if ( !StringUtils.isNullOrEmpty(cpar.getReport_initiator_email()) ) {
           email.setTo(cpar.getReport_initiator_email());
           }else{
             email.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
               }

        //email.setTo(emailUtil.getEmailAddressForUser(cpar.getInitiated_by()));
        email.setCcArray(actionHelper.getSbfascasQms().split(";"));
        email.setSubject(appName + " Status Change Notification for : " + cparControlNumber);
        String cparEmailStatusChagedBody = "The status for '" + cparControlNumber + "' has been set to " +
                cparStatus.getStatusDescription(cpar.getStatus_id(), lookupService, user.getLocale()) + "\n";
        email.setBody(cparEmailStatusChagedBody + " " + request.getParameter("printPreviewSrc"));
    }

    private void synchronizeComplaintCarStatus(Cpar cpar) throws ServiceException {
        String newStatus = lookupService.getEquivalentStatus(MCASConstants.CPAR_STATUS_TYPE, cpar);
        if (!StringUtils.isNullOrEmpty(newStatus)) {
            complaintService.synchronizeComplaintStatusWithCarStatus(cpar, newStatus);
        }
    }

    public void setCparDefaultValues(HttpServletRequest request, int type, String regionId, String regionResponsibleId) throws Exception {
        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST,
                actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_FILING_LOCATION_LIST_SEARCH,
                actionHelper.getRegionSpecificLocationListSearch(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST,
                actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST_SEARCH,
                actionHelper.getRegionSpecificLocationListSearch(MCASConstants.CCAS_DEFAULT_REGION_STATE,
                        MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        setGeneratorData(request, type);
        setFindingTypeData(request, type);
        setCparTypesForConversion(request, type);
    }

    public void setCparDynamicValues(Cpar cpar, HttpServletRequest request) throws Exception {
        FindingTimelineService timelineService = new FindingTimelineServiceImpl(new FindingTimelineDaoImpl());
        HttpSession session = request.getSession();

        session.setAttribute(MCASConstants.DUE_DATE_INVESTIGATION_FINDINGS, timelineService.getInvestigationFindingsDueDate(cpar));
        session.setAttribute(MCASConstants.DUE_DATE_CONTAINMENT_ACTION, timelineService.getContainmentActionDueDate(cpar));
        session.setAttribute(MCASConstants.DUE_DATE_ROOT_CAUSE, timelineService.getRootCauseDueDate(cpar));
        session.setAttribute(MCASConstants.DUE_DATE_CORRECTIVE_ACTION, timelineService.getLongTermCorrectiveActionDueDate(cpar));
        session.setAttribute(MCASConstants.DUE_DATE_EVALUATION_EFFECTIVENESS, timelineService.getEvaluationOfEffectivenessDueDate(cpar));

    }

    private void setCparTypesForConversion(HttpServletRequest request, int type) {
        request.getSession().setAttribute(ActionHelperConstants.CPAR_TYPES_FOR_CONVERSION,
                lookupService.getCparTypesToChange(type));
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }
}
