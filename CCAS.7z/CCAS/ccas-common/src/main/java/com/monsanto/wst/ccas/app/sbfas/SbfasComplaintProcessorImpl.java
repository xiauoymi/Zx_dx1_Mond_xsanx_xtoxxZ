package com.monsanto.wst.ccas.app.sbfas;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.CparType;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.EmailService;
import com.monsanto.wst.ccas.service.IEmailService;
import com.monsanto.wst.ccas.service.ServiceException;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionErrors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * Date: Jun 1, 2009 Time: 2:57:52 PM
 */
public class SbfasComplaintProcessorImpl implements ComplaintProcessor {
  private final ActionHelper actionHelper;
  private final IEmailService emailService;
  private final CCASEmailUtilImpl emailUtil;

  public SbfasComplaintProcessorImpl() {
    emailService = new EmailService();
    actionHelper = new ActionHelper();
    emailUtil = new CCASEmailUtilImpl(new PeopleService());
  }

  public SbfasComplaintProcessorImpl(IEmailService emailService, ActionHelper actionHelper,
                                     CCASEmailUtilImpl emailUtil) {
    this.emailService = emailService;
    this.actionHelper = actionHelper;
    this.emailUtil = emailUtil;
  }

  public ActionErrors processComplaint(Complaint complaint, User user) throws ServiceException {
    complaint.setSales_year_id(actionHelper.getDefaultYear(user.getLocale()));
    complaint.setRegion_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    complaint.setState_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    return null;
  }

  public void sendComplaintEmail(HttpServletRequest request, String printPreviewSrc, Complaint complaint,
                                 boolean complaintInsert,
                                 String complaintEditParam, boolean sendCondensedEmail) throws
      EmailAddressRetrievalException {
    if (complaintInsert) {
      complaint.setReport_initiator_email(emailUtil.getEmailAddressForUser(complaint.getReport_initiator()));
      emailService.sendEmailForComplaint();
    }
  }

    public String isClaimValidExcel(Complaint c, int businessId) {
        return null;
    }

    public String createCpar(HttpServletRequest request, Complaint complaint, CparService cpars,
                           String paramForward) throws ServiceException {
    String forward = paramForward;
    Map<String, String> errorMap = new HashMap<String, String>();
    if (!(request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE) != null
        && request.getParameter(MCASConstants.REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE).equalsIgnoreCase("true"))) {
      Map<String, String> carMap = cpars.findCPAR(complaint.getComplaint_id(), "Y");
      Cpar cpar = populateCparDetails(carMap, errorMap, request);
      if (actionHelper.createCar(request)) {
        forward = setRequestVariables(request, cpar, forward);
      }
      //PAR logic
      clearCparMap(carMap);
      carMap = cpars.findCPAR(complaint.getComplaint_id(), "N");
      cpar = populateCparDetails(carMap, errorMap, request);
      if (actionHelper.createPar(request)) {
        forward = setRequestVariables(request, cpar, forward);
      }
    }
    request.setAttribute("cparMap", errorMap);
    return forward;
  }

  private String setRequestVariables(HttpServletRequest request, Cpar cpar, String forward) {

    HttpSession session = request.getSession();
    String locale = ((User) session.getAttribute(User.USER)).getLocale();

    if (cpar != null && !StringUtils.isNullOrEmpty(cpar.getCpar_id())) {
      request.setAttribute("cparId", cpar.getCpar_id());
      request.setAttribute("controlNumber", cpar.getControl_number());
      CparType cparType = CparType.getType(cpar.getType());
      request.setAttribute("errorMsg", cparType.getDuplicateErrorMessage(locale));
      return forward;
    }
    return CparConstants.FORWARD_SUCCESS_CPAR;

  }

  private void clearCparMap(Map<String, String> carMap) {
    if (!carMap.isEmpty()) {
      carMap.clear();
    }
  }

  private Cpar populateCparDetails(Map<String, String> carMap, Map<String, String> errorMap,
                                   HttpServletRequest request) {
    Cpar cparObject = null;
    if (!carMap.isEmpty()) {
      for (String id : carMap.keySet()) {
        errorMap.putAll(carMap);
        cparObject = new Cpar();
        cparObject.setCpar_id(id);
        cparObject.setControl_number(carMap.get(id));
        if (!StringUtils.isNullOrEmpty(request.getParameter(CparConstants.CPAR_TYPE))) {
          cparObject.setType(Integer.parseInt(request.getParameter(CparConstants.CPAR_TYPE)));
        }
      }
    }
    return cparObject;
  }

}
