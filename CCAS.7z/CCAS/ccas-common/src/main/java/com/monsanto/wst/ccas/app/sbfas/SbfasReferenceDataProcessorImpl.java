package com.monsanto.wst.ccas.app.sbfas;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.actions.IActionHelper;
import com.monsanto.wst.ccas.app.ReferenceDataProcessor;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.LookUpService;
import com.monsanto.wst.ccas.service.LookUpServiceImpl;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SbfasReferenceDataProcessorImpl implements ReferenceDataProcessor {
    private final IActionHelper actionHelper;
    private final LookUpService service;
    private final BusinessService businessService;

    public SbfasReferenceDataProcessorImpl() {
        actionHelper = new ActionHelper();
        service = new LookUpServiceImpl();
        businessService = new BusinessServiceImpl();
    }

    public void setReferenceData(HttpServletRequest request, boolean activeRecordsOnly) throws Exception {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(User.USER);
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_CUSTOMER, user.getLocale()));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_REPORTING_LOCATION_LIST_SEARCH, actionHelper.getRegionSpecificLocationListSearch(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_CUSTOMER, user.getLocale()));
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, user.getLocale()));
        request.getSession().setAttribute(ActionHelperConstants.REGION_SPECIFIC_RESPONSIBLE_LOCATION_LIST_SEARCH, actionHelper.getRegionSpecificLocationListSearch(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, user.getLocale()));
        setFeedbackCategoryList(request, activeRecordsOnly, user.getLocale());
    }

    private void setFeedbackCategoryList(HttpServletRequest request, boolean activeRecordsOnly, String locale) {
        request.getSession().setAttribute("feedbackCategory", service.lookUpFeedbackCategories(activeRecordsOnly, locale));
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }
}
