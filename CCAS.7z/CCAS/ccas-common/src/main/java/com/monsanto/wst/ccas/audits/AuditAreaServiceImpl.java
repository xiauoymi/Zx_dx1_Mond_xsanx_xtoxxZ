///*
// FunctionalAreaServiceImpl was created on Jan 29, 2008 using Monsanto
// resources and is the sole property of Monsanto.  Any duplication of the
// code and/or logic is a direct infringement of Monsanto's copyright.
//*/
//package com.monsanto.wst.ccas.audits;
//
//import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;
//import com.monsanto.wst.ccas.model.AuditObject;
//import com.monsanto.wst.ccas.service.CheckboxItemService;
//import com.monsanto.wst.ccas.dao.CheckboxItemDao;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import sun.reflect.generics.reflectiveObjects.NotImplementedException;
//
///**
// * Filename:    $RCSfile: FunctionalAreaServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
// *
// * @author vrbethi
// * @version $Revision: 1.1 $
// */
//public class FunctionalAreaServiceImpl implements CheckboxItemService {
//    private final CheckboxItemDao functionalAreaDAO;
//
//    public FunctionalAreaServiceImpl(CheckboxItemDao functionalAreaDAO) {
//        this.functionalAreaDAO = functionalAreaDAO;
//
//    }
//
//    public void insertSelectedItemsInDatabase(List<CheckboxItem> selectedFunctionalAreaList, int auditId, String type) {
//        functionalAreaDAO.insertCheckboxItemsForComplaint(auditId, type, selectedFunctionalAreaList);
//    }
//
////    public void setFunctionalAreas(AuditObject auditViewObj, String locale) {
////        Set<String> functionalAreasList = functionalAreaDAO.lookUpFunctionalAreasForAudit(Integer.parseInt(auditViewObj.getAuditID()), "A");
////        List<CheckboxItem> allFunctionalAreas = functionalAreaDAO.lookUpAllFunctionalAreas(locale);
////        for (CheckboxItem allFunctionalArea : allFunctionalAreas) {
////            CheckboxItem checkboxItem = allFunctionalArea;
////            int functionalAreaId = checkboxItem.getCheckboxItemId();
////            if (functionalAreasList.contains(Integer.toString(functionalAreaId))) {
////                checkboxItem.setCheckboxItemValue(true);
////            }
////        }
////        CheckboxGroup checkboxGroup = new CheckboxGroup(allFunctionalAreas);
////        checkboxGroup.createCheckboxRows();
////        auditViewObj.setFunctionalArea(checkboxGroup);
////    }
//
//    public Map<String, List<CheckboxItem>> lookupBusinessRelatedFunctionalAreas(int businessId, String entryType, String locale, Map<String, Boolean> roles) {
//        return functionalAreaDAO.lookupCheckboxGroups(businessId, entryType, locale, roles);
//    }
//
//    private Set<String> lookupFunctionalAreasForEdit(int auditId, String auditSourceType) {
//        return functionalAreaDAO.getSelectedItemsForRecord(auditId, auditSourceType);
//    }
//
//    public List<CheckboxGroup> lookupCheckboxGroups(int businessId, boolean isEdit,
//                                                    String auditSourceType, String objectId, String locale, Map<String, Boolean> roles) {
//
//        Map<String, List<CheckboxItem>> functionalAreaMap = lookupBusinessRelatedFunctionalAreas(businessId, auditSourceType, locale, roles);
//        List<CheckboxGroup> checkboxGroupList = null;
//        Set selectedNonconformanceCategorySet = null;
//        if (functionalAreaMap != null && functionalAreaMap.size() > 0) {
//            checkboxGroupList = createComplaintCategoriesOrFunctionalAreas(functionalAreaMap);
//        }
//        if (isEdit) {
//            if (objectId != null && !objectId.equals("-1")) {
//                selectedNonconformanceCategorySet = lookupFunctionalAreasForEdit(Integer.parseInt(
//                        objectId),
//                        auditSourceType);
//                retainSelectedComplaintCategoriesOrFunctionalAreas(functionalAreaMap, selectedNonconformanceCategorySet);
//            }
//        }
//        return checkboxGroupList;
//    }
//
//    private List<CheckboxGroup> createComplaintCategoriesOrFunctionalAreas(Map<String, List<CheckboxItem>> categoryMap) {
//        List<CheckboxGroup> objectList;
//        List<CheckboxItem> categoryList;
//        objectList = new ArrayList<CheckboxGroup>(categoryMap.size());
//        for (Object obj : categoryMap.keySet()) {
//            categoryList = categoryMap.get(obj.toString());
//            objectList.add(getFunctionalArea(categoryList));
//        }
//        return objectList;
//    }
//
//    protected CheckboxGroup getFunctionalArea(List<CheckboxItem> categoryList) {
//        CheckboxGroup checkboxGroup = new CheckboxGroup(categoryList);
//        checkboxGroup.createCheckboxRows();
//        return checkboxGroup;
//    }
//
//    private void retainSelectedComplaintCategoriesOrFunctionalAreas(Map<String, List<CheckboxItem>> categoryMap, Set selectedSet) {
//        List<CheckboxItem> categoryList;
//        for (String key : categoryMap.keySet()) {
//            categoryList = categoryMap.get(key);
//            for (CheckboxItem checkboxItem : categoryList) {
//                checkboxItem.setCheckboxItemValue(false);
//                int functionalAreaId = checkboxItem.getCheckboxItemId();
//                if (selectedSet.contains(Integer.toString(functionalAreaId))) {
//                    checkboxItem.setCheckboxItemValue(true);
//                }
//            }
//        }
//    }
//
//    public void updateSelectedItemsInDatabase(List<CheckboxItem> functionalAreaList, int objectId, String functionalAreaSourceType) {
////what the heck was all this for???
////        if (functionalAreaList != null && functionalAreaList.size() > 0) {
//        ObjectWithCheckboxGroups auditObj = new AuditObject();
////            auditObj.setAuditID(objectId);
////            auditObj.setSelectedFunctionalAreas(functionalAreaList);
//        auditObj.setSelectedFunctionalAreas(functionalAreaList);
////
////            int auditId = Integer.parseInt(auditObj.getAuditID());
//        functionalAreaDAO.deleteCheckboxItemsForRecord(objectId, functionalAreaSourceType);
//
//        if (functionalAreaList != null) {
//            insertSelectedItemsInDatabase(functionalAreaList, objectId, functionalAreaSourceType);
//        }
////        }
//    }
//
//    public void setCheckboxGroupsForObject(ObjectWithCheckboxGroups filter, String recordId, int businessId, boolean isEdit, String auditType, String locale, Map<String, Boolean> roles) {
//        List<CheckboxGroup> checkboxGroupList = lookupCheckboxGroups(businessId, isEdit, auditType, recordId, locale, roles);
//        if (checkboxGroupList != null && checkboxGroupList.size() > 0) {
//            filter.setFunctionalAreaList(checkboxGroupList);
//            for (CheckboxGroup obj : checkboxGroupList) {
//                filter.setFunctionalArea(obj);
//            }
//        }
//    }
//
//
//    public List<CheckboxItem> getSelectedFunctionalAreas(ObjectWithCheckboxGroups auditObj, List<SelectedIndex> selectedIndexes) {
//        List<CheckboxItem> functionalAreaList = new ArrayList<CheckboxItem>();
//        populateSelectedCheckboxItems(functionalAreaList, selectedIndexes, auditObj);
//        return functionalAreaList;
//    }
//
//    private void populateSelectedCheckboxItems(List<CheckboxItem> resultList, List<SelectedIndex> selectedAreas, ObjectWithCheckboxGroups record) {
//        if (selectedAreas != null && selectedAreas.size() > 0) {
//            CheckboxGroup checkboxGroupObject = null;
//            Object[] rowFunctionalAreaArray = null;
//            CheckboxRow checkboxRow = null;
//            Object[] rowFunctionalAreaObjectArray = null;
//            CheckboxItem checkboxItem = null;
//            for (SelectedIndex index : selectedAreas) {
//                checkboxGroupObject = record.getFunctionalAreaList().get(index.getFirstIndex());
//                rowFunctionalAreaArray = getRowFunctionalAreaArray(checkboxGroupObject);
//                checkboxRow = (CheckboxRow) rowFunctionalAreaArray[index.getSecondIndex()];
//                rowFunctionalAreaObjectArray = checkboxRow.getCheckboxItemList();
//                checkboxItem = (CheckboxItem) rowFunctionalAreaObjectArray[index.getThirdIndex()];
//                resultList.add(checkboxItem);
//            }
//        }
//    }
//
//    protected Object[] getRowFunctionalAreaArray(CheckboxGroup checkboxGroupObject) {
//        return checkboxGroupObject.getCheckboxRowList();
//    }
//
//    public Map<String, String> lookUpFeedbackCategories(boolean activeOnly, String locale) {
//        throw new NotImplementedException();
//    }
//
//    public String lookUpFeedbackCategoryById(String complaintBusinessId, String locale) {
//        throw new NotImplementedException();
//    }
//
//
//}
