package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 29, 2010
 * Time: 11:18:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class AuditFindingTypeFactory {

  public FindingTypeProcessor getFindingTypeProcessor(String findingType){
    if(AuditConstants.MAJOR.equalsIgnoreCase(findingType)){
      return new CarFindingTypeProcessorImpl();
    } else if(AuditConstants.OBSERVATION.equalsIgnoreCase(findingType)){
      return new ObservationFindingTypeProcessorImpl();
    }
      else if(AuditConstants.AUDIT_CI.equalsIgnoreCase(findingType)){
      return new CiFindingTypeProcessorImpl();
    }
    return new NullFindingTypeProcessorImpl();
  }

    public FindingTypeProcessor getFindingTypeProcessor(boolean isCar, int carType){
      if(isCar)
        return new CarFindingTypeProcessorImpl();
      else if(carType!= MCASConstants.MCAS_CI_TYPE){
        return new ObservationFindingTypeProcessorImpl();
      }
       else{
          return new CiFindingTypeProcessorImpl();
      }
    }


}
