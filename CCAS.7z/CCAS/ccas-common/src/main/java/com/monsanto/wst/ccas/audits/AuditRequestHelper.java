/*
 AuditRequestHelper was created on Jan 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.service.AuditService;
import com.monsanto.wst.ccas.service.ServiceException;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Filename:    $RCSfile: AuditRequestHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class AuditRequestHelper {

    public List<SelectedIndex> getCheckedIndexes(Map<String, String[]> requestParameterMap, String functionalAreaType) {
        List<SelectedIndex> selectedIndexList = new ArrayList<SelectedIndex>();
        Set<String> set = requestParameterMap.keySet();
        Iterator<String> keysIterator = set.iterator();
        SelectedIndex selectedIndex = null;
        while (keysIterator.hasNext()) {
            String key = keysIterator.next();
            if (StringUtils.contains(key, functionalAreaType)) {

                //these can be N/A for Row Crop root causes.  Those are handled by drop-downs, not rows of checkboxes.
                //I hate this, but these can be indicated by a negative third index.
                String secondIndex;
                String thirdIndex = "-1";
                int startIndexofFirstArray = StringUtils.indexOf(key, "[");
                int endIndexofFirstArray = StringUtils.indexOf(key, "]");
                String firstIndex = key.substring(startIndexofFirstArray + 1, endIndexofFirstArray);
                int startIndexofSecondArray = StringUtils.indexOf(key, "[", endIndexofFirstArray);
                int endIndexofSecondArray = StringUtils.indexOf(key, "]", startIndexofSecondArray);

                if (startIndexofSecondArray > 0 && endIndexofSecondArray > 0) {
                    secondIndex = key.substring(startIndexofSecondArray + 1, endIndexofSecondArray);
                    int startIndexofThirdArray = StringUtils.indexOf(key, "[", endIndexofSecondArray);
                    int endIndexofThirdArray = StringUtils.indexOf(key, "]", startIndexofThirdArray);
                    thirdIndex = key.substring(startIndexofThirdArray + 1, endIndexofThirdArray);
                } else {
                    String id[] = requestParameterMap.get(key);
                    secondIndex = id[0];
                }
                try {
                    selectedIndex = new SelectedIndex(Integer.parseInt(firstIndex), Integer.parseInt(secondIndex), Integer.parseInt(thirdIndex));
                    selectedIndexList.add(selectedIndex);
                }
                catch (NumberFormatException ignore) {
                }//select one
            }
        }
        return selectedIndexList;
    }

    public String insertFinding(String userId, AuditObject auditObj, String currentTab, Map<String, String> errorMap, AuditService auditService) throws ServiceException {

        if (auditObj.getEditFindingObj().getFindingDesc() == null || auditObj.getEditFindingObj().getFindingDesc().equals("")) {
            errorMap.put(AuditConstants.ERROR_FINDING_DESC_EMPTY, "errors.mcas.audit.FindingDesc.empty");
        }

        if (auditObj.getEditFindingObj().getFindingDesc() != null && auditObj.getEditFindingObj().getFindingDesc().length() > 4000) {
            errorMap.put("findingDescTooLarge", "errors.mcas.audit.FindingDesc.tooLarge");
        }
        if (!errorMap.isEmpty()) {
            return "failure";
        }
        auditObj.getEditFindingObj().setRowUserID(userId);

        AuditFindingTypeFactory auditFindingTypeFactory = new AuditFindingTypeFactory();
        FindingTypeProcessor findingProcessor = auditFindingTypeFactory.getFindingTypeProcessor(currentTab);
        findingProcessor.insertNewFinding(auditObj, auditService);

        return "success";
    }
}