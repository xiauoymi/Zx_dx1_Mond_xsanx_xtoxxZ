/*
 BiotechfasAuditProcessorImpl was created on Aug 20, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.ProgramConstants;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class BiotechfasAuditProcessorImpl implements ApplicationAuditProcessor {
  private final AuditRequestHelper auditrequestHelper;
  private final ProgramService programService;
  private final SubFunctionService subFunctionService;
  private AuditService service = null;


  public BiotechfasAuditProcessorImpl() {
    auditrequestHelper = new AuditRequestHelper();
    programService = new ProgramServiceImpl();
    subFunctionService = new SubFunctionServiceImpl();
    service = new AuditServiceImpl();
  }

  public BiotechfasAuditProcessorImpl(AuditRequestHelper auditrequestHelper, ProgramService programService,
                                      SubFunctionService subFunctionService, AuditService service) {
    this.auditrequestHelper = auditrequestHelper;
    this.programService = programService;
    this.subFunctionService = subFunctionService;
    this.service = service;
  }

  public void processAudit(AuditObject auditObj) {
    auditObj.setRegion_id(MCASConstants.DEFAULT_REGION_ID);
  }

  public void setAuditDefaultValues(HttpServletRequest request) throws Exception {

    HttpSession session = request.getSession();
    User user = (User) session.getAttribute(User.USER);
    String id = getProgramId(request);

    session.setAttribute(ProgramConstants.PROGRAM_LIST, programService.lookupAllPrograms());
    session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST,
        programService.lookupLocationsForAProgram(id));

    session.setAttribute(MCASConstants.SUBFUNCTION_LIST,
        subFunctionService.lookupAllSubFunctionsForAProgram(id, user.getLocale()));
  }

  public void processAuditCparRelation(Map<String, Object> auditMap) throws DAOException {
    service.processAuditCparRelation(auditMap);
  }

  public boolean processCreateCpar(String userId, AuditObject auditObj, String currentTab, Map<String, String> errorMap,
                                   AuditService auditService, FindingObject findingObject) throws ServiceException {
    if (findingObject.getCparID() != null && !findingObject.getCparID().equals("")) {
      auditObj.setEditFindingObj(findingObject);

      auditrequestHelper.insertFinding(userId, auditObj, currentTab, errorMap, auditService);
    }
    return false;
  }

  private String getProgramId(HttpServletRequest request) {

    String programID = request.getParameter("auditObj.program_id");
    if (StringUtils.isNullOrEmpty(programID)) {
      programID = request.getParameter("auditFilterObj.program_id");
    }

    if (StringUtils.isNullOrEmpty(programID)) {
      if (request.getAttribute("programId") != null) {
        programID = request.getAttribute("programId").toString();
      } else {
        programID = ProgramConstants.PROGRAM_ID_DEFAULT;
      }
    }
    return programID;
  }
}
