package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.AuditService;
import com.monsanto.wst.ccas.service.AuditServiceImpl;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ssanna
 * Date: Nov 7, 2008
 * Time: 2:04:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class BtfasAuditProcessorImpl implements ApplicationAuditProcessor {
    private final ActionHelper actionHelper;
    private final AuditService service;
    private final BusinessService businessService;

    public BtfasAuditProcessorImpl() {
        actionHelper = new ActionHelper();
        service = new AuditServiceImpl();
        businessService = new BusinessServiceImpl();
    }

    public void processAudit(AuditObject auditObj) {
        auditObj.setRegion_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    }

    public void setAuditDefaultValues(HttpServletRequest request) throws Exception {
        setDefaultLocations(request);
    }

    public void processAuditCparRelation(Map<String, Object> auditMap) throws DAOException {

        service.processAuditCparRelation(auditMap);
    }

    public boolean processCreateCpar(String userId, AuditObject auditObj, String currentTab, Map<String, String> errorMap, AuditService auditService, FindingObject findingObject) {
        return (findingObject.getCparID() != null && !findingObject.getCparID().equals(""));
    }

    private void setDefaultLocations(HttpServletRequest request) {

        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
    }


    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }
}
