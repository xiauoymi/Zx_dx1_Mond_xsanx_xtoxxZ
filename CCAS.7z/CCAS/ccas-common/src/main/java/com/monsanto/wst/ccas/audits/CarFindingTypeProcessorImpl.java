package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.AuditService;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 29, 2010
 * Time: 11:24:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class CarFindingTypeProcessorImpl implements FindingTypeProcessor {
    public void setDisplayTabAndTableInAuditForm(AuditForm auditForm) {
        auditForm.setDisplayTab(AuditConstants.MAJOR);
        auditForm.setDisplayCarTable2(true);
        auditForm.setDisplayParTable2(false);
        auditForm.setDisplayCiTable2(false);
    }

    public void setDisplayTabInAuditForm(AuditForm auditForm) {
        auditForm.setDisplayTab(AuditConstants.MAJOR);
    }

    public void setFindingDesc(AuditForm auditForm, String findingID, String findingDesc) {
        auditForm.getAuditObj().getFindingCarMap().get(findingID).setFindingDesc(findingDesc);
    }

    public String getFindingDesc(AuditForm auditForm, String findingID) {
        return auditForm.getAuditObj().getFindingCarMap().get(findingID).getFindingDesc();
    }

    public FindingObject getFindingObject(AuditForm auditForm, String findingID) {
        return auditForm.getAuditObj().getFindingCarMap().get(findingID);
    }

    public void removeFinding(AuditForm auditForm, String findingId) {
        auditForm.getAuditObj().getFindingCarMap().remove(findingId);
    }

    public void addFinding(AuditForm auditForm, AuditObject auditObj) {
        auditObj.getFindingCarMap().put(auditObj.getEditFindingObj().getFindingID(), auditObj.getEditFindingObj());
    }


    public String getDuplicateErrorKey() {
        return "duplicateCarMsg";
    }

    public String getDuplicateErrorMsg(String locale) {
        return I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicateCar");
    }

    public FindingObject insertNewFinding(AuditObject auditObj, AuditService auditService) {
        FindingObject resultObj;
        auditObj.getEditFindingObj().setCar_flag("Y");
        resultObj = auditService.insertFinding(auditObj.getAuditNumber(), auditObj.getEditFindingObj());
        resultObj.setCar_flag("Y");
        auditObj.getFindingCarMap().put(resultObj.getFindingID(), resultObj);
        auditObj.setFindingCarMapEmpty(false);
        auditObj.setAuditFindingID(resultObj.getFindingID());

        return resultObj;
    }
}
