/*
 CheckboxGroup was created on Jan 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: FunctionalArea.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class CheckboxGroup implements Serializable {

    private List<CheckboxRow> checkboxRowList;
    private List<CheckboxItem> checkboxItemList;


    public CheckboxGroup(List<CheckboxItem> checkboxItemList) {
        this.checkboxItemList = checkboxItemList;
        this.checkboxRowList = new ArrayList();
    }


    public CheckboxGroup() {
        this.checkboxRowList = new ArrayList<CheckboxRow>();

        //up to four rows
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
        checkboxRowList.add(new CheckboxRow());
    }

    public Object[] getCheckboxRowList() {
        return checkboxRowList.toArray();
    }

    public List<CheckboxRow> getCheckboxRowListAsList() {
        return checkboxRowList;
    }

    public List<CheckboxItem> getCheckboxItemList() {
        return checkboxItemList;
    }

//    public List<CheckboxRow> getCheckboxRowList() {
//        if (checkboxRowList == null) {
//            checkboxRowList = LazyList.decorate(
//                    new ArrayList(), FactoryUtils.instantiateFactory(CheckboxRow.class));
//        }
//        //max 20 tabs
//        for (int i = checkboxRowList.size(); i < 4; i++) {
//            checkboxRowList.add(new CheckboxRow());
//        }
//        return checkboxRowList;
//    }


    public void setCheckboxRowList(List<CheckboxRow> checkboxRowList) {
        this.checkboxRowList = checkboxRowList;
    }

    public void createCheckboxRows() {
//    Collections.sort(checkboxItemList);
        CheckboxRow checkboxRow = null;
        for (int i = 0; i < checkboxItemList.size(); i = i + 4) {
            int count = 1;
            checkboxRow = new CheckboxRow();
            List<CheckboxItem> columnCheckboxItem = new ArrayList<CheckboxItem>();
            columnCheckboxItem.add(checkboxItemList.get(i));
            if ((i + count) < checkboxItemList.size()) {
                columnCheckboxItem.add(checkboxItemList.get(i + 1));
                count++;
            }
            if ((i + count) < checkboxItemList.size()) {
                columnCheckboxItem.add(checkboxItemList.get(i + 2));
                count++;
            }
            if ((i + count) < checkboxItemList.size()) {
                columnCheckboxItem.add(checkboxItemList.get(i + 3));
                            count++;
                        }
            checkboxRow.setCheckboxItemList(columnCheckboxItem);
            checkboxRowList.add(checkboxRow);
        }
    }


    public void resetIndexes(ObjectWithCheckboxGroups auditObject, List<SelectedIndex> areas, List<CheckboxItem> selectedFunctionalAreaList) {

        List<CheckboxGroup> functionalAreasList = auditObject.getFunctionalAreaList();

        Object[] rowFunctionalAreaArray = null;
        CheckboxGroup checkboxGroupObj = null;
        CheckboxRow checkboxRow = null;
        Object[] rowFunctionalAreaObjectArray = null;
        CheckboxItem checkboxItem = null;
        if (functionalAreasList != null) {
            for (CheckboxGroup o : functionalAreasList) {
                checkboxGroupObj = o;
                rowFunctionalAreaArray = checkboxGroupObj.getCheckboxRowList();
                for (Object rowFunctionalAreaObj : rowFunctionalAreaArray) {
                    checkboxRow = (CheckboxRow) rowFunctionalAreaObj;
                    rowFunctionalAreaObjectArray = checkboxRow.getCheckboxItemList();
                    for (Object j : rowFunctionalAreaObjectArray) {
                        checkboxItem = (CheckboxItem) j;
                        checkboxItem.setCheckboxItemValue(false);
                    }
                }
            }
        }
        for (SelectedIndex selectedIndex : areas) {

            checkboxGroupObj = functionalAreasList.get(selectedIndex.getFirstIndex());
            rowFunctionalAreaArray = checkboxGroupObj.getCheckboxRowList();
            checkboxRow = (CheckboxRow) rowFunctionalAreaArray[selectedIndex.getSecondIndex()];
            rowFunctionalAreaObjectArray = checkboxRow.getCheckboxItemList();
            checkboxItem = (CheckboxItem) rowFunctionalAreaObjectArray[selectedIndex.getThirdIndex()];
            checkboxItem.setCheckboxItemValue(true);
            selectedFunctionalAreaList.add(checkboxItem);
        }
        auditObject.setFunctionalAreaList(functionalAreasList);
    }

}
