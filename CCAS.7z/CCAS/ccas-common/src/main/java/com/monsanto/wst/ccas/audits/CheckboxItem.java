/*
 AuditTestArea was created on Jan 28, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Filename:    $RCSfile: AreaAudited.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class CheckboxItem implements Comparator, Serializable {
    private String checkboxItemDisplay;
    private boolean checkboxItemValue;
    private final int checkboxItemId;
    private boolean inactive;
//    private int departmentId;


    public boolean isInactive() {
        return inactive;
    }

    public void setInactive(boolean inactive) {
        this.inactive = inactive;
    }

    public CheckboxItem(String checkboxItemDisplay, boolean checkboxItemValue, int checkboxItemId) {
        this.checkboxItemDisplay = checkboxItemDisplay;
        this.checkboxItemValue = checkboxItemValue;
        this.checkboxItemId = checkboxItemId;
    }

    public CheckboxItem(String checkboxItemDisplay, boolean checkboxItemValue, int checkboxItemId,boolean inactive) {
        this.checkboxItemDisplay = checkboxItemDisplay;
        this.checkboxItemValue = checkboxItemValue;
        this.checkboxItemId = checkboxItemId;
        this.inactive=inactive;
    }

//    public CheckboxItem(String checkboxItemDisplay, boolean checkboxItemValue, int checkboxItemId, int departmentId) {
//        this.checkboxItemDisplay = checkboxItemDisplay;
//        this.checkboxItemValue = checkboxItemValue;
//        this.checkboxItemId = checkboxItemId;
//        this.departmentId = departmentId;
//    }

//    public int getDepartmentId() {
//        return departmentId;
//    }
//
//    public void setDepartmentId(int departmentId) {
//        this.departmentId = departmentId;
//    }

    public String getCheckboxItemDisplay() {
        return checkboxItemDisplay;
    }

    public void setCheckboxItemDisplay(String checkboxItemDisplay) {
        this.checkboxItemDisplay = checkboxItemDisplay;
    }

    public boolean isCheckboxItemValue() {
        return checkboxItemValue;
    }

    public void setCheckboxItemValue(boolean checkboxItemValue) {
        this.checkboxItemValue = checkboxItemValue;
    }


    public int getCheckboxItemId() {
        return checkboxItemId;
    }

    public int compare(Object o1, Object o2) {
        int displayOrder1 = ((CheckboxItem) o1).getCheckboxItemId();
        int displayOrder2 = ((CheckboxItem) o2).getCheckboxItemId();
        if (displayOrder1 == displayOrder2) {
            return 0;
        }
        if (displayOrder1 > displayOrder2) {
            return 1;
        }
        return -1;
    }


    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("Checkbox Display :").append(checkboxItemDisplay);
        stringBuffer.append(" Checkbox Value :").append(checkboxItemValue);
        stringBuffer.append(" Checkbox Id :").append(checkboxItemId).append("\n");
        return stringBuffer.toString();
    }
}