/*
 CheckboxRow was created on Jan 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: RowFunctionalAreas.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class CheckboxRow implements Serializable {

    private List<CheckboxItem> checkboxItem;


    public CheckboxRow() {
        this.checkboxItem = new ArrayList<CheckboxItem>();

        //four per row
        //need to put something in here to prevent BeanUtils error.
        checkboxItem.add(new CheckboxItem("", true, -1));
        checkboxItem.add(new CheckboxItem("", true, -1));
        checkboxItem.add(new CheckboxItem("", true, -1));
        checkboxItem.add(new CheckboxItem("", true, -1));
    }

    public Object[] getCheckboxItemList() {
        return checkboxItem.toArray();
    }

    public List<CheckboxItem> getCheckboxItemListAsList() {
        return checkboxItem;
    }

    public void setCheckboxItemList(List<CheckboxItem> checkboxItem) {
        this.checkboxItem = checkboxItem;
    }
}
