package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.service.AuditService;

/**
 * Created by IntelliJ IDEA.
 * User: AOROZ
 * Date: 18/04/12
 * Time: 12:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class CiFindingTypeProcessorImpl implements FindingTypeProcessor {
    public void setDisplayTabInAuditForm(AuditForm auditForm) {
        auditForm.setDisplayTab(AuditConstants.AUDIT_CI);
    }

    public void setDisplayTabAndTableInAuditForm(AuditForm auditForm) {
        auditForm.setDisplayTab(AuditConstants.AUDIT_CI);
      auditForm.setDisplayParTable2(false);
      auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayCiTable2(true);
    }

    public void setFindingDesc(AuditForm auditForm, String findingID, String findingDesc) {
        auditForm.getAuditObj().getFindingCiMap().get(findingID).setFindingDesc(findingDesc);
    }

    public String getFindingDesc(AuditForm auditForm, String findingID) {
        return auditForm.getAuditObj().getFindingCiMap().get(findingID).getFindingDesc();
    }

    public FindingObject getFindingObject(AuditForm auditForm, String findingID) {
        return auditForm.getAuditObj().getFindingCiMap().get(findingID);
    }

    public void removeFinding(AuditForm auditForm, String findingId) {
        auditForm.getAuditObj().getFindingCiMap().remove(findingId);
    }

    public void addFinding(AuditForm auditForm, AuditObject auditObj) {
        auditObj.getFindingCiMap().put(auditObj.getEditFindingObj().getFindingID(), auditObj.getEditFindingObj());
    }

    public String getDuplicateErrorKey() {
        return "duplicateParMsg";
    }

    public String getDuplicateErrorMsg(String locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public FindingObject insertNewFinding(AuditObject auditObj, AuditService auditService) {
        FindingObject resultObj;
        auditObj.getEditFindingObj().setCar_flag("C");
        resultObj = auditService.insertFinding(auditObj.getAuditNumber(), auditObj.getEditFindingObj());
        resultObj.setCar_flag("C");
        auditObj.getFindingCiMap().put(resultObj.getFindingID(), resultObj);
        auditObj.setFindingCiMapEmpty(false);
        auditObj.setAuditFindingID(resultObj.getFindingID());

        return resultObj;
    }
}
