package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.AuditService;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 29, 2010
 * Time: 11:24:17 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FindingTypeProcessor {
  void setDisplayTabInAuditForm(AuditForm auditForm);
  void setDisplayTabAndTableInAuditForm(AuditForm auditForm);
  void setFindingDesc(AuditForm auditForm, String findingID, String findingDesc);
  String getFindingDesc(AuditForm auditForm, String findingID);
  FindingObject getFindingObject(AuditForm auditForm, String findingID);
  void removeFinding(AuditForm auditForm, String findingId);
  void addFinding(AuditForm auditForm, AuditObject auditObj);
  String getDuplicateErrorKey();
  String getDuplicateErrorMsg(String locale);
  FindingObject insertNewFinding(AuditObject auditObj, AuditService auditService);
}
