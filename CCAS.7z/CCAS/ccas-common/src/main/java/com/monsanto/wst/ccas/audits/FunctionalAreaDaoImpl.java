/*
 FunctionalAreaDaoImpl was created on Jan 29, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.exception.DatabaseException;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Filename:    $RCSfile: FunctionalAreaDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class FunctionalAreaDaoImpl implements CheckboxItemDao {
    private final DataSource source;

    public FunctionalAreaDaoImpl(DataSource source) {
        this.source = source;
    }

    public FunctionalAreaDaoImpl() {
        this.source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
    }

//    public List<CheckboxItem> lookUpAllFunctionalAreas(String locale) {
//        List<CheckboxItem> functionalAreasList = new ArrayList<CheckboxItem>();
//        Connection connection = null;
//        PreparedStatement preparedStatement = null;
//        ResultSet resultSet = null;
//        try {
//            connection = source.getConnection();
//            preparedStatement = connection.prepareStatement(
//                    "SELECT AAR.AREA_ID,AAR.DESCRIPTION,AAR.DISPLAY_ORDER FROM M_AUDIT_AREAS_REF AAR WHERE AAR.ACTIVE_FLAG='Y' ORDER BY DISPLAY_ORDER");
//            resultSet = preparedStatement.executeQuery();
//
//            I18nServiceImpl iService = new I18nServiceImpl();
//
//            while (resultSet.next()) {
//
//                int id = resultSet.getInt("AREA_ID");
//                String desc = iService.translate(locale, "M_AUDIT_AREAS_REF", id, resultSet.getString("DESCRIPTION"));
//                functionalAreasList.add(new CheckboxItem(desc, false, id));
//            }
//
//        } catch (Exception e) {
//            throw new DatabaseException("Error retrieving audit areas", e);
//        }
//        finally {
//            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
//        }
//        return functionalAreasList;
//    }

    public void insertCheckboxItemsForRecord(int auditId, String type, List<CheckboxItem> areasAuditedList) {

        if (areasAuditedList == null) return;

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        CheckboxItem checkboxItem = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "INSERT INTO M_AUDIT_AREAS (AUDIT_ID, AUDIT_AREA_ID, AUDIT_AREA_SOURCE) VALUES (?, ?, ?)");
            for (Object obj : areasAuditedList) {
                checkboxItem = (CheckboxItem) obj;
                preparedStatement.setInt(1, auditId);
                preparedStatement.setInt(2, checkboxItem.getCheckboxItemId());
                preparedStatement.setString(3, type);
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new DatabaseException("Error inserting audit areas", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, null);
        }
    }

    public Set<String> getSelectedItemsForRecord(int auditId, String auditSourceType) {
        Set<String> functionalAreasSet = new HashSet<String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT AUDIT_ID,AUDIT_AREA_ID FROM M_AUDIT_AREAS WHERE AUDIT_ID = ? AND AUDIT_AREA_SOURCE=? ");
            preparedStatement.setInt(1, auditId);
            preparedStatement.setString(2, auditSourceType);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int areaId = resultSet.getInt("AUDIT_AREA_ID");
                functionalAreasSet.add(Integer.toString(areaId));
            }

        } catch (SQLException e) {
            throw new DatabaseException("Error looking up audit areas for an audit", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return functionalAreasSet;
    }

    public Map<String, String> lookUpFunctionalAreasAndColumnNumbersForAudit(int businessId, String locale) {
        Map<String, String> functionalAreasMap = new HashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT AAR.DESCRIPTION, COLUMN_NUMBER FROM M_AUDIT_AREAS_REF AAR WHERE AAR.ACTIVE_FLAG='Y' " +
                            "AND BUSINESS_ID= " + businessId + " ORDER BY DISPLAY_ORDER");
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                String areaDescription = resultSet.getString("DESCRIPTION");
                String areaColNum = resultSet.getString("COLUMN_NUMBER");

                if (!StringUtils.isNullOrEmpty(areaColNum)) {
                    areaColNum = areaColNum.trim();
                }

                if (!StringUtils.isNullOrEmpty(areaDescription)) {
                    areaDescription = areaDescription.trim();
                }

                int id = Integer.parseInt(areaColNum.trim());
                areaDescription = iService.translate(locale, "M_AUDIT_AREAS_REF", id, areaDescription);

                functionalAreasMap.put(areaDescription, Integer.toString(id));
            }

        } catch (Exception e) {
            throw new DatabaseException("Error retrieving audit areas", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return functionalAreasMap;
    }

    public void deleteCheckboxItemsForRecord(int auditId, String entryType) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM M_AUDIT_AREAS WHERE AUDIT_ID=? and AUDIT_AREA_SOURCE=?");
            preparedStatement.setInt(1, auditId);
            preparedStatement.setString(2, entryType);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error deleting audit areas", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, null);
        }
    }

    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    private String getFunctionalAreaRoleClause(Map<String, Boolean> roles) {

        if (roles == null)
            return "";

        String clause = " and (";

        for (String key : roles.keySet()) {
            if (roles.get(key) == true) {
                clause += "role_id = " + key + " or ";
            }
        }

        clause += "role_id is null)";

        return clause;
    }

    public Map<String, List<CheckboxItem>> lookupCheckboxGroups(int businessId, String entryType, String locale, Map<String, Boolean> roles, String appName) {
        return lookupBusinessRelatedFunctionalAreas(businessId, entryType, locale, getFunctionalAreaRoleClause(roles));
    }

    private Map<String, List<CheckboxItem>> lookupBusinessRelatedFunctionalAreas(int businessId, String entryType, String locale, String roleClause) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List<CheckboxItem> functionalAreaList = null;
        Map<String, List<CheckboxItem>> functionalAreaMap = new LinkedHashMap<String, List<CheckboxItem>>();
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    " SELECT AREA_ID,DESCRIPTION,DEPARTMENT_ID FROM M_AUDIT_AREAS_REF " +
                            " WHERE active_flag = 'Y' and BUSINESS_ID = ?  " + roleClause +
                            " GROUP BY  AREA_ID,DESCRIPTION,DEPARTMENT_ID ORDER BY DEPARTMENT_ID ASC");
            preparedStatement.setInt(1, businessId);
            rs = preparedStatement.executeQuery();
            if (rs != null) {
                int areaId;
                int departmentId;
                int oldDepartmentId = -1;
                String description;
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    areaId = rs.getInt("AREA_ID");
                    description = rs.getString("DESCRIPTION");
                    if (!StringUtils.isNullOrEmpty(description)) {
                        description = description.trim();
                    }
                    departmentId = rs.getInt("DEPARTMENT_ID");
                    if (departmentId != oldDepartmentId) {
                        functionalAreaList = new ArrayList<CheckboxItem>();
                        //functionalAreaList.add(new CheckboxItem(description,false,areaId));
                        oldDepartmentId = departmentId;
                    }

                    description = iService.translate(locale, "M_AUDIT_AREAS_REF", areaId, description);

                    functionalAreaList.add(new CheckboxItem(description, false, areaId));
                    functionalAreaMap.put("" + departmentId, functionalAreaList);
                }
            }
        } catch (Exception e) {
            throw new DatabaseException("Error looking up audit areas", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, rs);
        }
        return functionalAreaMap;
    }

}