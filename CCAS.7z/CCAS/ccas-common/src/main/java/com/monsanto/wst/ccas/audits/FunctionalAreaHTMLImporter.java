package com.monsanto.wst.ccas.audits;

import com.monsanto.Util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Date: Nov 3, 2009
 * Time: 9:49:29 AM
 */
public class FunctionalAreaHTMLImporter implements FunctionalAreaImporter {
    private final HttpServletRequest request;
    private final AuditRequestHelper auditRequestHelper;

    public FunctionalAreaHTMLImporter(HttpServletRequest request) {
        this.request = request;
        auditRequestHelper = new AuditRequestHelper();
    }

    public FunctionalAreaHTMLImporter(HttpServletRequest request, AuditRequestHelper auditRequestHelper) {
        this.request = request;
        this.auditRequestHelper = auditRequestHelper;
    }

    /**
     * @param type             Audit Area Type
     * @param dataList         FunctionalAreaList / Complaint Issue List
     * @param selectedDataList
     */
//    public void initializeFunctionalAreas(String type, List<CheckboxGroup> dataList, List<CheckboxItem> selectedDataList) {
//        List<SelectedIndex> selectedIndexList = auditRequestHelper.getCheckedIndexes(request.getParameterMap(), type);
//        populateUserCheckedData(type, dataList, selectedIndexList, selectedDataList);
//    }


//    //todo:  Merge some of these methods scattered around.
//    private void populateUserCheckedData(String type, List<CheckboxGroup> dataList, List<SelectedIndex> selectedIndexList, List<CheckboxItem> functionalAreaList) {
//        SelectedIndex index = null;
//        if (selectedIndexList != null && selectedIndexList.size() > 0) {
//            CheckboxGroup checkboxGroupObject = null;
//            Object[] rowFunctionalAreaArray = null;
//            CheckboxRow checkboxRow = null;
//            Object[] rowFunctionalAreaObjectArray = null;
//            CheckboxItem checkboxItem = null;
//            for (SelectedIndex aSelectedIndexList : selectedIndexList) {
//                index = aSelectedIndexList;
//                if (!StringUtils.isNullOrEmpty(type)) {
//                    checkboxGroupObject = dataList.get(index.getFirstIndex());
//                }
//                rowFunctionalAreaArray = checkboxGroupObject.getCheckboxRowList();
//                checkboxRow = (CheckboxRow) rowFunctionalAreaArray[index.getSecondIndex()];
//                rowFunctionalAreaObjectArray = checkboxRow.getCheckboxItemList();
//                checkboxItem = (CheckboxItem) rowFunctionalAreaObjectArray[index.getThirdIndex()];
//                functionalAreaList.add(checkboxItem);
//            }
//        }
//    }
}
