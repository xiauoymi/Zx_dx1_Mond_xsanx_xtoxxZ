package com.monsanto.wst.ccas.audits;

import java.util.List;

/**
 * Date: Nov 3, 2009
 * Time: 9:42:37 AM
 */
public interface FunctionalAreaImporter {
    /**
     * @param type             Complaint Issues / Audit Areas
     * @param dataList         Complaint Category List or Audit Area List
     * @param selectedDataList Selected or Checked List
     */
//    public void initializeFunctionalAreas(String type, List<CheckboxGroup> dataList, List<CheckboxItem> selectedDataList);
}
