/*
 McasAuditProcessorImpl was created on Jan 21, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.actions.SessionHelper;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.AuditService;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Filename:    $RCSfile: McasAuditProcessorImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class McasAuditProcessorImpl implements ApplicationAuditProcessor {
    private final ActionHelper actionHelper;
    private final BusinessService businessService;

    public McasAuditProcessorImpl() {
        actionHelper = new ActionHelper();
        businessService = new BusinessServiceImpl();
    }

    public void processAudit(AuditObject auditObj) {

    }

    public void setAuditDefaultValues(HttpServletRequest request) throws Exception {
        setDefaultLocations(request);
    }

    public void processAuditCparRelation(Map<String, Object> auditMap) {
    }

    public boolean processCreateCpar(String userId, AuditObject auditObj, String currentTab, Map<String, String> errorMap, AuditService auditService, FindingObject findingObject) {
        return (findingObject.getCparID() != null && !findingObject.getCparID().equals(""));
    }

    private void setDefaultLocations(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String region = (String) session.getAttribute(AuditConstants.AUDIT_FILTER_OBJ_REGION);
        if (StringUtils.isNullOrEmpty(region)) {
            SessionHelper sessionHelper = new SessionHelper();
            sessionHelper.setDefaultLocations(session);
        } else {
            String locale = ((User) session.getAttribute(User.USER)).getLocale();
            session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(region, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        }
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }


}
