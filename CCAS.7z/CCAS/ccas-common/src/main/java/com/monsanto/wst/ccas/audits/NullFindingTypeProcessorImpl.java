package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.AuditService;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 29, 2010
 * Time: 11:25:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class NullFindingTypeProcessorImpl implements FindingTypeProcessor {
  public void setDisplayTabInAuditForm(AuditForm auditForm) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

    public void setFindingDesc(AuditForm auditForm, String findingID, String findingDesc) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getFindingDesc(AuditForm auditForm, String findingID) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public FindingObject getFindingObject(AuditForm auditForm, String findingID) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getDuplicateErrorMsg(String locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public FindingObject insertNewFinding(AuditObject auditObj, AuditService auditService) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getDuplicateErrorKey() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setDisplayTabAndTableInAuditForm(AuditForm auditForm) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addFinding(AuditForm auditForm, AuditObject auditObj) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeFinding(AuditForm auditForm, String findingId) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
