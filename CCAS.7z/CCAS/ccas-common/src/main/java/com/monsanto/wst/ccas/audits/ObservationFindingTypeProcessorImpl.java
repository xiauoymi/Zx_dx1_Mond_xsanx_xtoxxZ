package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actionForms.AuditForm;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.AuditService;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 29, 2010
 * Time: 11:24:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObservationFindingTypeProcessorImpl implements FindingTypeProcessor {
    public void setDisplayTabInAuditForm(AuditForm auditForm) {
        auditForm.setDisplayTab(AuditConstants.OBSERVATION);
    }

    public void setFindingDesc(AuditForm auditForm, String findingID, String findingDesc) {
        auditForm.getAuditObj().getFindingParMap().get(findingID).setFindingDesc(findingDesc);
    }

    public String getFindingDesc(AuditForm auditForm, String findingID) {
      return auditForm.getAuditObj().getFindingParMap().get(findingID).getFindingDesc();
    }

    public FindingObject getFindingObject(AuditForm auditForm, String findingID) {
      return auditForm.getAuditObj().getFindingParMap().get(findingID);
    }

    public void setDisplayTabAndTableInAuditForm(AuditForm auditForm) {
      auditForm.setDisplayTab(AuditConstants.OBSERVATION);
      auditForm.setDisplayParTable2(true);
      auditForm.setDisplayCarTable2(false);
        auditForm.setDisplayCiTable2(false);
    }

    public void addFinding(AuditForm auditForm, AuditObject auditObj) {
      auditObj.getFindingParMap().put(auditObj.getEditFindingObj().getFindingID(), auditObj.getEditFindingObj());
    }

    public void removeFinding(AuditForm auditForm, String findingId) {
      auditForm.getAuditObj().getFindingParMap().remove(findingId);
    }

    public String getDuplicateErrorKey() {
        return "duplicateParMsg";
    }

    public FindingObject insertNewFinding(AuditObject auditObj, AuditService auditService) {
        FindingObject resultObj;
        auditObj.getEditFindingObj().setCar_flag("N");
        resultObj = auditService.insertFinding(auditObj.getAuditNumber(), auditObj.getEditFindingObj());
        resultObj.setCar_flag("N");
        auditObj.getFindingParMap().put(resultObj.getFindingID(), resultObj);
        auditObj.setFindingParMapEmpty(false);
        auditObj.setAuditFindingID(resultObj.getFindingID());

        return resultObj;
    }

    public String getDuplicateErrorMsg(String locale) {
        return I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicatePar");
    }
}
