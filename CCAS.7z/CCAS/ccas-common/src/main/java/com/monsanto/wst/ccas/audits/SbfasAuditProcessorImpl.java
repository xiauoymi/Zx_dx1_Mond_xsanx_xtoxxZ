package com.monsanto.wst.ccas.audits;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.AuditService;
import com.monsanto.wst.ccas.service.AuditServiceImpl;
import com.monsanto.wst.ccas.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Date: Jul 6, 2009
 * Time: 11:00:05 AM
 */
public class SbfasAuditProcessorImpl implements ApplicationAuditProcessor {
    private ActionHelper actionHelper = null;
    private AuditService service = null;
    private final AuditRequestHelper auditrequestHelper;
    private final BusinessService businessService;

    public SbfasAuditProcessorImpl() {
        actionHelper = new ActionHelper();
        service = new AuditServiceImpl();
        businessService = new BusinessServiceImpl();
        auditrequestHelper = new AuditRequestHelper();
    }

    public SbfasAuditProcessorImpl(ActionHelper actionHelper, AuditServiceImpl auditServiceImpl, AuditRequestHelper auditrequestHelper, BusinessService businessServiceImpl) {
        this.actionHelper = actionHelper;
        this.service = auditServiceImpl;
        this.auditrequestHelper = auditrequestHelper;
        this.businessService = businessServiceImpl;
    }

    public void processAudit(AuditObject auditObj) {
        auditObj.setRegion_id(MCASConstants.CCAS_DEFAULT_REGION_STATE);
    }

    public void setAuditDefaultValues(HttpServletRequest request) throws Exception {

        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, actionHelper.getRegionSpecificLocationList(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
        session.setAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST_SEARCH, actionHelper.getRegionSpecificLocationListSearch(MCASConstants.CCAS_DEFAULT_REGION_STATE, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale));
    }

    public void processAuditCparRelation(Map<String, Object> auditMap) throws DAOException {
        service.processAuditCparRelation(auditMap);
    }

    public boolean processCreateCpar(String userId, AuditObject auditObj, String currentTab,
                                     Map<String, String> errorMap, AuditService auditService,
                                     FindingObject findingObject) throws ServiceException {
        if (findingObject.getCparID() != null && !findingObject.getCparID().equals("")) {
            auditObj.setEditFindingObj(findingObject);

            auditrequestHelper.insertFinding(userId, auditObj, currentTab, errorMap, auditService);
        }
        return false;
    }

    private int getUserBusinessId(User user) throws ServiceException {
        return businessService.getBusinessId(user);
    }

}
