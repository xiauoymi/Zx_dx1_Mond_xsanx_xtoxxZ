/*
 SelectedIndex was created on Jan 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.audits;

/**
 * Filename:    $RCSfile: SelectedIndex.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */

//checkbox index
public class SelectedIndex {
    private final int firstIndex;
    private final int secondIndex;
    private int thirdIndex;

    public SelectedIndex(int firstIndex, int secondIndex, int thirdIndex) {
        this.firstIndex = firstIndex;
        this.secondIndex = secondIndex;
        this.thirdIndex = thirdIndex;
    }

    public int getThirdIndex() {
        return thirdIndex;
    }

    public SelectedIndex(int firstIndex, int secondIndex) {
        this.firstIndex = firstIndex;
        this.secondIndex = secondIndex;
    }

    public int getFirstIndex() {
        return firstIndex;
    }

    public int getSecondIndex() {
        return secondIndex;
    }
}
