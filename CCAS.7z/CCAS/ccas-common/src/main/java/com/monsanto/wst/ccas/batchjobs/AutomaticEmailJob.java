package com.monsanto.wst.ccas.batchjobs;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.actions.GlobalAbomination;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.peoplepickerclientutil.PeoplePickerLookupService;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.dao.AutomatedEmailsDaoImpl;
import com.monsanto.wst.ccas.dao.CparEmailDaoImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.AutomatedEmailsDao;
import com.monsanto.wst.ccas.service.*;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.CCASEmailUtil;
import com.monsanto.PeoplePicker.PeopleService;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 14, 2010
 * Time: 12:48:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class AutomaticEmailJob {//extends TimerTask {

    private CCASEmailUtil emailUtil = new CCASEmailUtilImpl(new PeopleService());
    private IEmailService emailService;
    private final String urlLink;
    private static final String QSAP2_MONSANTO_COM = "qsap2@monsanto.com";
    //Hardcoding your email address in the code?  I guess you are planning on being around here for a while.
    private static final String TADIAL_MONSANTO_COM = "tadial@monsanto.com";

    ActionHelper actionHelper = new ActionHelper();

    //Internalized properties
    private String evaluationAndReportClosure = null;
    private String reportClosure = null;
    private String evaluation = null;
    private String longTermAction = null;
    private String rootCause = null;
    private String cointainmentAction = null;
    private String errorSendingEmail = null;
    private String contact = null;
    private String addressEmailsError = null;
    private String siteManager = null;
    private String responsibleArea = null;
    private String createdBy = null;
    private String warningDeadLine = null;
    private String delay = null;
    private String completed = null;
    private String incomplete = null;
    private String before = null;
    private String deadline = null;
    private String within = null;
    private String day = null;
    private String login = null;
    private String system = null;
    private String emailFooter = null;
    private String applicationContext = null;

    public static void main(String[] args) {
        AutomaticEmailJob job = new AutomaticEmailJob();
        job.run();
    }

    public CCASEmailUtil getEmailUtil() {
        return emailUtil;
    }

    public void setEmailUtil(CCASEmailUtil emailUtil) {
        this.emailUtil = emailUtil;
    }

    public AutomaticEmailJob(CCASEmailUtil emailUtil) {
        this.emailUtil = emailUtil;
        emailService = new EmailService();
        urlLink = "http://" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.emailServ.linkDomain") + "/" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext");
    }

    public AutomaticEmailJob() {
        emailService = new EmailService();
        urlLink = "http://" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.emailServ.linkDomain") + "/" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext");
    }

    public AutomaticEmailJob(IEmailService service) {
        emailService = service;
        urlLink = "http://" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.emailServ.linkDomain") + "/" + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext");
    }

    public String tryGetAddress(String person) throws EmailAddressRetrievalException {

        if (person == null || "".equals(person.trim())) return null;
        return emailUtil.getEmailAddressForUser(person);

    }

    public void run() {
        try {
            sendEmails();
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            System.err.println();
            System.err.println();
            e.printStackTrace();
        }
    }

    protected void sendEmails() throws SQLException, DAOException, EmailAddressRetrievalException, EmailException {
        new PeoplePickerLookupService();  // setup people lookup properties.. server endpoint etc..
        Connection con = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource().getConnection();
        final AutomatedEmailsDaoImpl emailSettingsDao = new AutomatedEmailsDaoImpl(con);
        CparEmailService emailService = new CparEmailServiceImpl(emailSettingsDao, new CparEmailDaoImpl(con));

        sendOverdueContainmentActionEmails(emailSettingsDao, emailService);
        sendOverdueRootCauseEmails(emailSettingsDao, emailService);
        sendOverdueLongTermCorrectiveActionEmails(emailSettingsDao, emailService);
        sendOverdueEvaluationOfEffectivenessEmails(emailSettingsDao, emailService);
        sendOverdueCloseEmails(emailSettingsDao, emailService);
        sendOverdueApprovedWarning(emailSettingsDao, emailService);
    }

    protected void sendOverdueApprovedWarning(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalWarning = emailSettingsDao.getEvaluationOfEffectivenessDays();
        Iterator<Cpar> overdueClose = emailService.getOverdueApprovedWarning();
        String locale = "en";
        while (overdueClose.hasNext()) {
            Cpar cpar = overdueClose.next();
            //generateCparEmail(cpar, cpar.getEvaluation_person(), "Evaluation of Effectiveness and Report Closure", cpar.getEvaluation_date(), intervalWarning, true);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            evaluationAndReportClosure = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.evaluationAndReportClosure");
            generateCparEmail(cpar, cpar.getEvaluation_person(), evaluationAndReportClosure, cpar.getEvaluation_date(), intervalWarning, true);
        }
    }

    protected void sendOverdueCloseEmails(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalClose = emailSettingsDao.getCloseDays();
        Iterator<Cpar> overdueClose = emailService.getOverdueClose();
        String locale = "en";
        while (overdueClose.hasNext()) {
            Cpar cpar = overdueClose.next();
            //generateCparEmail(cpar, cpar.getEvaluation_person(), "Report Closure", null, intervalClose, false);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            reportClosure = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.reportClosure");
            generateCparEmail(cpar, cpar.getEvaluation_person(), reportClosure, null, intervalClose, false);
        }
    }

    protected void sendOverdueEvaluationOfEffectivenessEmails(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalEvaluationOfEffectiveness = emailSettingsDao.getEvaluationOfEffectivenessDays();
        Iterator<Cpar> overdueEvaluationOfEffectiveness = emailService.getOverdueEvaluationOfEffectiveness();
        String locale = "en";
        while (overdueEvaluationOfEffectiveness.hasNext()) {
            Cpar cpar = overdueEvaluationOfEffectiveness.next();
            //generateCparEmail(cpar, cpar.getEvaluation_person(), "Evaluation of Effectiveness", cpar.getEvaluation_date(), intervalEvaluationOfEffectiveness, false);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            evaluation = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.evaluation");
            generateCparEmail(cpar, cpar.getEvaluation_person(), evaluation, cpar.getEvaluation_date(), intervalEvaluationOfEffectiveness, false);
        }
    }

    protected void sendOverdueLongTermCorrectiveActionEmails(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalLongTermCorrectiveAction = emailSettingsDao.getLongTermCorrectiveActionDays();
        Iterator<Cpar> overdueLongTermCorrectiveAction = emailService.getOverdueLongTermCorrectiveAction();
        String locale = "en";
        while (overdueLongTermCorrectiveAction.hasNext()) {
            Cpar cpar = overdueLongTermCorrectiveAction.next();
            //generateCparEmail(cpar, cpar.getLong_term_corrective_action_person(), "Long Term Corrective Action", cpar.getLong_term_corrective_action_date(), intervalLongTermCorrectiveAction, false);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            longTermAction = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.action");
            generateCparEmail(cpar, cpar.getLong_term_corrective_action_person(), longTermAction, cpar.getLong_term_corrective_action_date(), intervalLongTermCorrectiveAction, false);
        }
    }

    protected void sendOverdueRootCauseEmails(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalRootCause = emailSettingsDao.getRootCauseDays();
        Iterator<Cpar> overdueRootCause = emailService.getOverdueRootCause();
        String locale = "en";
        while (overdueRootCause.hasNext()) {
            Cpar cpar = overdueRootCause.next();
            //generateCparEmail(cpar, cpar.getRoot_cause_person(), "Root Cause", cpar.getRoot_cause_date(), intervalRootCause, false);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            rootCause = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.rootCause");
            generateCparEmail(cpar, cpar.getRoot_cause_person(), rootCause, cpar.getRoot_cause_date(), intervalRootCause, false);
        }
    }

    protected void sendOverdueContainmentActionEmails(AutomatedEmailsDao emailSettingsDao, CparEmailService emailService) throws DAOException, EmailAddressRetrievalException, EmailException {
        final int intervalContainmentAction = emailSettingsDao.getContainmentActionDays();
        Iterator<Cpar> overdueContainmentActions = emailService.getOverdueContainmentAction();
        String locale = "en";
        while (overdueContainmentActions.hasNext()) {
            Cpar cpar = overdueContainmentActions.next();
            //generateCparEmail(cpar, cpar.getContainment_actions_person(), "Containment Action", cpar.getContainment_actions_date(), intervalContainmentAction, false);
            if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
                locale = "es";

            cointainmentAction = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.cointainmentAction");
            generateCparEmail(cpar, cpar.getContainment_actions_person(), cointainmentAction, cpar.getContainment_actions_date(), intervalContainmentAction, false);
        }
    }

    private void generateCparEmail(Cpar cpar, String responsiblePersonName, String actionItem, String deadline, int intervalContainmentActions, boolean isWarning) {

        loadInternalizedProperties(cpar);
        EmailInfo email = setEmailRecipients(cpar, responsiblePersonName);
        StringBuffer b = new StringBuffer();
        b.append(email.getBody());
        email.setBody("");
        createEmailMessage(cpar, actionItem, deadline, intervalContainmentActions, isWarning, email);
        try {
            emailService.sendEmail(email);
        } catch (Exception e) {
            //String emailString = "Error sending email to " + email.getTo() + " & CC: " + email.getCc() + " & BCC: " + email.getBcc() + " : ";
            String emailString = errorSendingEmail + ": " + email.getTo() + " & CC: " + email.getCc() + " & BCC: " + email.getBcc() + " : ";
            email.setSubject(emailString + email.getSubject() + " ");
            //email.setBody(emailString + "\r\n\r\n" + e.getMessage() + "\r\n\r\n contact technical teams for more information. Here is the original email: \r\n\r\n" + email.getBody());
            email.setBody(emailString + "\r\n\r\n" + e.getMessage() + "\r\n\r\n " + contact + ":" + "\r\n\r\n" + email.getBody());
            email.setTo(actionHelper.getCcasSupportEmail() == null ? QSAP2_MONSANTO_COM : actionHelper.getCcasSupportEmail());
            email.setCc(TADIAL_MONSANTO_COM);

            try {
                emailService.sendEmail(email);
            } catch (Exception e1) {
                MCASLogUtil.logError(emailString + "\r\n" + e1.getMessage(), e1);
            }
            MCASLogUtil.logError(emailString + "\r\n" + e.getMessage(), e);
        }
        if (b.length() > 0 && b.indexOf("environment)") == -1) {
            email = new EmailInfo();
            email.setFrom(actionHelper.getAdminEmail() == null ? QSAP2_MONSANTO_COM : actionHelper.getAdminEmail());
            email.setTo(actionHelper.getCcasSupportEmail() == null ? QSAP2_MONSANTO_COM : actionHelper.getCcasSupportEmail());
            email.setCc(TADIAL_MONSANTO_COM);

            createEmailMessage(cpar, actionItem, deadline, intervalContainmentActions, isWarning, email);
            //email.setSubject("Error occured while looking up email addresses: " + email.getSubject());
            email.setSubject(addressEmailsError + email.getSubject());
            email.setBody(b.toString() + "\r\n" + email.getBody());
            try {
                emailService.sendEmail(email);
            } catch (EmailException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
    }

    private EmailInfo setEmailRecipients(Cpar cpar, String responsiblePersonName) {

        String siteManagerEmail = null;
        StringBuffer b = new StringBuffer(1024);
        try {
            if(cpar.getSiteManagerUserId()!=null&&!StringUtils.isNullOrEmpty(cpar.getSiteManagerUserId())) {
                siteManagerEmail=cpar.getSiteManagerUserId();
            }
            else{
               siteManagerEmail = tryGetAddress(cpar.getSite_manager());
            }

        } catch (EmailAddressRetrievalException e) {
            //b.append("\r\nCould not get email for Site Manager:\r\n").append(e.getMessage());
            b.append("\r\n" + " " + siteManager + " " + "\r\n").append(e.getMessage());
            MCASLogUtil.logError(e.getMessage(), e);
        }
        String responsiblePersonEmail = null;
        try {
            responsiblePersonEmail = tryGetAddress(responsiblePersonName);
        } catch (EmailAddressRetrievalException e) {
            b.append("\r\n" + " " + responsibleArea + " " + "\r\n").append(e.getMessage());
            MCASLogUtil.logError(e.getMessage(), e);
        }
        if (responsiblePersonEmail == null)
            responsiblePersonEmail = siteManagerEmail;
        if (responsiblePersonEmail == null)   // note that this means siteManagerEmail is null will be used as cc below..
            try {
                responsiblePersonEmail = tryGetAddress(cpar.getCreated_by());
            } catch (EmailAddressRetrievalException e) {
                //b.append("\r\nCould not get email for created by:\r\n").append(e.getMessage());
                b.append("\r\n" + " " + createdBy + " " + "\r\n").append(e.getMessage());
                MCASLogUtil.logError(e.getMessage(), e);
            }
        if (responsiblePersonEmail == null)
            responsiblePersonEmail = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.Email");

        String adminEmail = actionHelper.getAdminEmail();
        if (adminEmail == null)
            adminEmail = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.Email");

        EmailInfo emailInfo;
        emailInfo = new EmailInfo();
        emailInfo.setTo(responsiblePersonEmail);
        emailInfo.setFrom(adminEmail);

        if (!responsiblePersonEmail.equals(siteManagerEmail) && !StringUtils.isNullOrEmpty(siteManagerEmail))
//            emailInfo.setCc("");     // this causes illegal address exception.. we want to set it only when site manager is not same as responsible person..
//        else
            emailInfo.setCc(siteManagerEmail);

        emailInfo.setBody(b.toString());

        return emailInfo;
    }

    private void createEmailMessage(Cpar cpar, String actionItem, String deadline, int interval, boolean isWarning, EmailInfo email) {
        String type = "Y".equalsIgnoreCase(cpar.getCar_flag()) ? "CAR" : "PAR";


        String subject;
        if (isWarning)
            //subject = "Warning: deadline approaching - ";
            subject = warningDeadLine;
        else
            //subject = "Overdue: ";
            subject = delay;

        subject += " " + type + " '" + cpar.getControl_number() +
                "' - " + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.AppName");

        String body = type + " '" + cpar.getControl_number() + "' " + actionItem;

        if (isWarning)
            //body += " must be completed ";
            body += " " + completed;
        else
            //body += " has not been completed ";
            body += " " + incomplete;

        if (deadline != null && !"".equals(deadline))
            //body += "before " + deadline + " deadline";
            body += " " + before + " " + deadline + " " + this.deadline;
        else
            //body += "within " + interval + " day(s)";
            body += " " + within + " " + interval + " " + day;


        //body += ".  Click here to logon to the " +
        body += ". " + login + " " +
                //McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext") + " " +
                applicationContext + " " +
                //" system: " + urlLink + "\r\n\r\n\r\n\r\n\r\n" +
                system + " " + urlLink + "\r\n\r\n\r\n\r\n\r\n" +
                //McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.EmailFooter");
                emailFooter;
        email.setSubject(subject);
        email.setBody(body);
    }

    /**
     * It decides the language of the email based on its region. For ex: region: 2 - Argentina - Spanish.
     * Other regions will be just english.
     *
     * @param cpar
     */
    public void loadInternalizedProperties(Cpar cpar) {
        //Internalization of the header/body email for MCAS.
        String locale = "en";
        if (!StringUtils.isNullOrEmpty(cpar.getRegion()) && cpar.getRegion().equals("2"))
            locale = "es";

        evaluationAndReportClosure = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.evaluationAndReportClosure");
        reportClosure = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.reportClosure");
        evaluation = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.evaluation");
        longTermAction = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.action");
        rootCause = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.rootCause");
        cointainmentAction = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.cointainmentAction");
        errorSendingEmail = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.errorSendingEmail");
        contact = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.contact");
        addressEmailsError = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.addressEmailsError");
        siteManager = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.siteManager");
        responsibleArea = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.responsibleArea");
        createdBy = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.createdBy");
        warningDeadLine = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.warningDeadLine");
        delay = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.delay");
        completed = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.completed");
        incomplete = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.incompleted");
        before = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.before");
        deadline = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.deadline");
        within = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.within");
        day = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.day");
        login = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.login");
        system = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.term.system");
        applicationContext = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.applicationContext");
        emailFooter = McasProperties.getMcasProperties(locale).getString("com.monsanto.wst.ccas.EmailFooter");
        return;
    }


}
