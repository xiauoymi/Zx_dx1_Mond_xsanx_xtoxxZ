package com.monsanto.wst.ccas.batchjobs;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.importdata.ComplaintDataReaderImpl;
import com.monsanto.wst.ccas.importdata.DataReader;
import com.monsanto.wst.ccas.importdata.ImportComplaintDataImpl;
import com.monsanto.wst.ccas.importdata.McasImportData;
import com.monsanto.wst.ccas.util.MCASLogUtil;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Feb 12, 2009
 * Time: 12:55:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImportComplaintDriver {
    private static final String filePath = "Complaints.xls";
    private static final String sheetName = "Sheet1";

    public static void main(String[] s) {
        try {

            DataReader complaintReader = new ComplaintDataReaderImpl();
            McasImportData importComplaintData = new ImportComplaintDataImpl(complaintReader);
            importComplaintData.processData(filePath, sheetName, isComplaintDelete(), MCASConstants.LANGUAGE_ENGLISH);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    private static boolean isComplaintDelete() {
        String isDeleted = System.getProperty("complaint.delete");
        return "true".equalsIgnoreCase(isDeleted);
    }
}
