package com.monsanto.wst.ccas.batchjobs;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.importdata.DataReader;
import com.monsanto.wst.ccas.importdata.ImportUserDataImpl;
import com.monsanto.wst.ccas.importdata.McasImportData;
import com.monsanto.wst.ccas.importdata.UserDataReaderImpl;
//import com.monsanto.wst.ccas.importdata.test.ImportConstants;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jun 27, 2008
 * Time: 8:39:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportUserDriver {
    //private static final String filePath = "C:\\MONCRYPTJV\\btfas\\BTFAS_UserList.xls";
    //private static final String sheetName = "Users";
    private static final String filePath = "C:\\MONCRYPTJV\\sbfas\\Users.xls";
    private static final String sheetName = "Users";

    public static void main(String[] args) throws DAOException {
        DataReader userDataReader = new UserDataReaderImpl();
        McasImportData importUser = new ImportUserDataImpl(userDataReader, "SBFASCAS");
        importUser.processData(filePath, sheetName, true, MCASConstants.LANGUAGE_ENGLISH);
    }

}

