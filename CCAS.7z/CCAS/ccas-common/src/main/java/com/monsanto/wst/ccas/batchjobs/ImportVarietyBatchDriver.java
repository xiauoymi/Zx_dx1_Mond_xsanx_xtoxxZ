/*
 ImportVarietyBatch was created on Dec 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.batchjobs;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.VarietyBatchDAOImpl;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.service.*;

/**
 * Filename:    $RCSfile: ImportVarietyBatchDriver.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ImportVarietyBatchDriver {

    public static void main(String[] args) throws DAOException, ServiceException, MCASException {
        VarietyBatchDataReaderService varietyBatchDataReaderService = ServiceLocator.getVarietyBatchDataReaderService();
        VarietyBatchImportService varietyBatchImportService =
                new VarietyBatchImportServiceImpl(varietyBatchDataReaderService, new VarietyBatchDAOImpl());
        long startTime = System.currentTimeMillis();
        boolean wasSuccessful = varietyBatchImportService.importNewVarietyBatches();
        //varietyBatchImportService.inactivateOldVarietyBatches();
        long endTime = System.currentTimeMillis();
        System.out.println("Total Time taken for the Batch Process = " + (endTime - startTime) + " Milliseconds");
        if (wasSuccessful) {
            varietyBatchImportService.deleteDataFromVarietyBatchTempTable();
        }
    }
}