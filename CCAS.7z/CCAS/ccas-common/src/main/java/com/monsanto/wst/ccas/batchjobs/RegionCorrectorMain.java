package com.monsanto.wst.ccas.batchjobs;

import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Sep 10, 2008
 * Time: 1:36:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegionCorrectorMain {

    public static void main(String[] args) throws Exception {

        BufferedReader reader = null;
        Writer writer = null;

        try {
            String filePath = "C:\\Documents and Settings\\bghale\\Desktop\\WST\\MCAS\\CPAR-2.txt";
            String destFilePath = "C:\\Documents and Settings\\bghale\\Desktop\\WST\\MCAS\\QueryToCorrectRegions.txt";
            reader = new BufferedReader(new FileReader(new File(filePath)));
            writer = new BufferedWriter(new FileWriter(new File(destFilePath)));
            String controlNumber = "";
            List<String> controlNumberList = new ArrayList<String>(1);
            while ((controlNumber = reader.readLine()) != null) {
                controlNumberList.add("'" + controlNumber + "'");
            }
            StringBuffer queryBuffer = new StringBuffer();
            System.out.println("Size of the list = " + controlNumberList.size());
            queryBuffer.append("UPDATE ccas.cpar c\n" +
                    "   SET c.region_id =\n" +
                    "          (SELECT region_id\n" +
                    "             FROM ccas.region_ref r\n" +
                    "            WHERE r.region_description =  'Latin America - North'  AND b_user = 'MFG_USER')\n" +
                    "            WHERE control_number IN (");
            for (String s : controlNumberList) {
                queryBuffer.append(s);
                queryBuffer.append(",");
            }
            queryBuffer.deleteCharAt(queryBuffer.lastIndexOf(","));
            queryBuffer.append(")AND b_user = 'MFG_USER'");
            writer.write(queryBuffer.toString());
            writer.flush();
        }
        finally {
            MCASResourceUtil.closeResource(reader);
            MCASResourceUtil.closeResource(writer);
        }
    }
}
