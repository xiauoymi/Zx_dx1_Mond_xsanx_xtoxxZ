package com.monsanto.wst.ccas.common;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSServlet.POSErrorResponse;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ajax.AJAXException;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.w3c.dom.Document;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
/*
 AJAXUseCaseController was created on May 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public abstract class AJAXUseCaseController implements UseCaseController {
    public static final String POS_NAME_PARAMETER = "posName";
    public static final String INPUT_DOCUMENT_PARAMETER = "inputDocument";

    final public void run(UCCHelper helper) throws IOException {
        String posName = helper.getRequestParameterValue(POS_NAME_PARAMETER);
        throwExceptionIfNull(posName, POS_NAME_PARAMETER);
        String inputDocumentName = getInputDocumentName(helper);
        String inputDocumentString = getInputDocumentString(inputDocumentName, helper);

        Document inputDocument = null;
        try {
            inputDocument = DOMUtil.newDocument(new StringReader(inputDocumentString));
            helper.setContentType("text/xml");
            runAJAXImplementation(helper, posName, inputDocument);
        } catch (Exception e) {
            handleException(e, helper);
        }
    }

    private String getInputDocumentString(String inputDocumentName, UCCHelper helper) {
        String inputDocumentString = null;
        if (inputDocumentName != null) {
            try {
                inputDocumentString = URLDecoder.decode(inputDocumentName, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                handleException(e, helper);
                return "";
            }
        }
        return inputDocumentString;
    }

    private void handleException(Exception e, UCCHelper helper) {
        MCASLogUtil.logError(e.getMessage(), e);
        helper.writeXMLDocument(new POSErrorResponse(e).toXML());
    }

    private String getInputDocumentName(UCCHelper helper) {
        String inputDocumentName = null;
        try {
            inputDocumentName = helper.getRequestParameterValue(INPUT_DOCUMENT_PARAMETER);
        } catch (IOException e) {
            handleException(e, helper);
        }
        return inputDocumentName;
    }

    private void throwExceptionIfNull(Object objectToCheck, String parameterName) throws IOException {
        if (objectToCheck == null) {
            throw new IOException(parameterName + " cannot be null");
        }
    }

    abstract protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException;
}