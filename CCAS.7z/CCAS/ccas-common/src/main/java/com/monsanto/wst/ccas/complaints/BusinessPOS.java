package com.monsanto.wst.ccas.complaints;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 28, 2008
 * Time: 12:04:39 PM
 * To change this template use File | Settings | File Templates.
 */

/* DEAD CODE for reference only
public class BusinessPOS extends BasePOSController {
    //  ToDo: This class will be removed soon.  Use BaseSecurePOSController instead
    protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException,
            NoLogonInformationException {
        return null;
    }

    protected void runImplementation(UCCHelper helper, Document inputDocument) throws IOException {
        BusinessService businessService = new BusinessServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
        User user = (User) helper.getSessionParameter(User.USER);

        Document functionsForLocation = businessService.getBusinessRelatedEntities(inputDocument, user.getLocale());
        helper.writeXMLDocument(functionsForLocation);
    }
                                                                        protected String getXMLSchemaRelativeToServletContext() {
        return "com/monsanto/wst/ccas/complaints/test/business.xsd";
    }
}
*/
