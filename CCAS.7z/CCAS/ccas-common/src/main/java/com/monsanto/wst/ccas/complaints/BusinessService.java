package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ServiceException;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 27, 2008
 * Time: 3:17:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BusinessService {
//    public Document getBusinessRelatedEntities(Document businessXML);

//    public Map getBusinessRelatedFamilies(String businessCode);

    public boolean isSaveUpdateControlVisible(User user, String methodType);

    int getBusinessId(User user) throws ServiceException;

    int getBusinessPreference(User user) throws ServiceException;
}
