package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.dao.BusinessDao;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ServiceException;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 27, 2008
 * Time: 3:13:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessServiceImpl implements BusinessService {

    public BusinessServiceImpl() {
    }


    //todo Can we simpify this. Do we need to check for the method type.
    public boolean isSaveUpdateControlVisible(User userObj, String methodType) {
        int businessId = getBusinessId(userObj);
        int userBusinessPrefId = getBusinessPreference(userObj);
        boolean displaySaveUpdateButtons = true;
        if (businessId == userBusinessPrefId) {
            return true;
        }
        if (businessId == MCASConstants.BUSINESS_ID_ROW_CROP && userBusinessPrefId == MCASConstants.BUSINESS_PREF_VEGETABLE) {
            displaySaveUpdateButtons = MCASUtil.operationSupported(methodType);
        } else {
            if ("complaintEdit".equalsIgnoreCase(methodType)
                    || "stopSaleView".equalsIgnoreCase(methodType)
                    || "cparEdit".equalsIgnoreCase(methodType)
                    || AuditConstants.AUDIT_EDIT.equals(methodType)) {
                displaySaveUpdateButtons = false;
            }
        }
        return displaySaveUpdateButtons;
    }

    public int getBusinessId(User user) throws ServiceException {
        int businessId = -1;
        try {
            BusinessDao dao = (BusinessDao) DAOFactory.getDao(BusinessDao.class);
            businessId = dao.getBusinessId(user.getUser_id());
            user.setBusinessId(businessId);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Exception getting Business DAO", e);
        }
        return businessId;
    }

    public int getBusinessPreference(User user) throws ServiceException {
        int businessPreference = -1;
        try {
            BusinessDao dao = (BusinessDao) DAOFactory.getDao(BusinessDao.class);
            businessPreference = dao.getBusinessPreference(user.getUser_id());
            user.setUserBusinessPreference(businessPreference);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Exception getting Business DAO", e);
        }
        return businessPreference;
    }

}
