/*
 ComplaintBusinessDaoImpl was created on Jan 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: ComplaintBusinessDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ComplaintBusinessDaoImpl implements ComplaintBusinessDao {
    private DataSource source;

    public ComplaintBusinessDaoImpl(DataSource source) {
        if (source == null) {
            throw new NullPointerException("source cannot be null");
        }
        this.source = source;
    }

    public Map<String, String> lookUpComplaintBusinessReferenceData(String locale) {
        Map<String, String> complaintBusinessReferenceData = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT CB.COMPLAINT_BUSINESS_ID,CB.DESCRIPTION,CB.ACTIVE FROM COMPLAINT_BUSINESS CB ORDER BY DESCRIPTION ASC");
            resultSet = preparedStatement.executeQuery();

            String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
            complaintBusinessReferenceData.put("", selectOne);
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int complaintBusinessId = resultSet.getInt("COMPLAINT_BUSINESS_ID");
                String complaintBusinessDescription = resultSet.getString("DESCRIPTION");

                String description = iService.translate(locale, "COMPLAINT_BUSINESS", complaintBusinessId, complaintBusinessDescription);

                complaintBusinessReferenceData.put(Integer.toString(complaintBusinessId), description);
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return complaintBusinessReferenceData;
    }

    public String lookUpComplaintBusinessWithId(int complaintBusinessId, String locale) {
        String complaintBusinessDescription = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = source.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT CB.COMPLAINT_BUSINESS_ID,CB.DESCRIPTION,CB.ACTIVE FROM COMPLAINT_BUSINESS CB WHERE CB.COMPLAINT_BUSINESS_ID=?");
            preparedStatement.setInt(1, complaintBusinessId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                complaintBusinessDescription = iService.translate(locale, "COMPLAINT_BUSINESS", complaintBusinessId, resultSet.getString("DESCRIPTION"));
//        System.out.println("complaintBusinessDescription = " + complaintBusinessDescription);
            }

        } catch (Exception e) {//todo gobbled exception
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return complaintBusinessDescription;
    }
}