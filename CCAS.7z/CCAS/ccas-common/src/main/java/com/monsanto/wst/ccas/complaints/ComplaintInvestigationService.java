package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 16, 2010 Time: 10:47:30 AM To change this template use File |
 * Settings | File Templates.
 */
public interface ComplaintInvestigationService {
  Map<String, String> lookupAllInitiatorSamples(String locale);

  Map<String, String> lookupAllSiteSamples(String locale);
}
