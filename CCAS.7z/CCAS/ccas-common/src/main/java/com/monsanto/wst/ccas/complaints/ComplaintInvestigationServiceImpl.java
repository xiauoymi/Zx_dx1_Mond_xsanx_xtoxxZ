package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 16, 2010 Time: 10:47:04 AM To change this template use File |
 * Settings | File Templates.
 */
public class ComplaintInvestigationServiceImpl implements ComplaintInvestigationService {

  private InitiatorSampleDao initiatorSampleDao;
  private SiteSampleDao siteSampleDao;

  public ComplaintInvestigationServiceImpl(InitiatorSampleDao initiatorSampleDao, SiteSampleDao siteSampleDao) {
    this.initiatorSampleDao = initiatorSampleDao;
    this.siteSampleDao = siteSampleDao;
  }

  public Map<String, String> lookupAllInitiatorSamples(String locale) {
    return initiatorSampleDao.lookupAllInitiatorSamples(locale);
  }

  public Map<String, String> lookupAllSiteSamples(String locale) {
    return siteSampleDao.lookupAllSiteSamples(locale);
  }
}
