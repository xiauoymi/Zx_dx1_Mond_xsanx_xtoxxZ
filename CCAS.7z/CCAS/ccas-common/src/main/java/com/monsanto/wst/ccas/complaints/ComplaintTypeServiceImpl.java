/*
 ComplaintTypeServiceImpl was created on Jan 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Filename:    $RCSfile: ComplaintTypeServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ComplaintTypeServiceImpl implements ComplaintTypeService {
    private final DataSource source;

    public ComplaintTypeServiceImpl(
            DataSource source) {
        this.source = source;
    }

    public Map<String, String> getComplaintTypeReferenceData(String locale) {
        ComplaintTypeDao complaintTypeDao = new ComplaintTypeDaoImpl(source);
        return complaintTypeDao.lookUpComplaintTypeReferenceData(locale);
    }
}
