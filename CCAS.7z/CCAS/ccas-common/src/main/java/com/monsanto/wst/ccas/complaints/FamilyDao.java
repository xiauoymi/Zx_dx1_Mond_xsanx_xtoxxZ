package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 27, 2008
 * Time: 3:19:18 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FamilyDao {

    Crop lookUpCropWithSapId(String cropSAPId, String locale);

    void insertCrop(Crop crop);

    void insertBusinessCropReference(Crop crop);
}
