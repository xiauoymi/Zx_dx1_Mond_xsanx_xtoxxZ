package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 27, 2008
 * Time: 3:19:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class FamilyDaoImpl implements FamilyDao {
    private final DataSource dataSource;


    public FamilyDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Crop lookUpCropWithSapId(String cropSAPId, String locale) {
        Crop crop = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("SELECT CROP_ID, SHORT_DESCRIPTION FROM CROP_REF WHERE SAP_CROP_CODE=?");
            preparedStatement.setString(1, cropSAPId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {

                int id = resultSet.getInt("CROP_ID");
                String cropDescription = iService.translate(locale, "CROP_REF", id, resultSet.getString("SHORT_DESCRIPTION"));
                crop = new Crop(cropDescription, cropSAPId, null, null, null, null);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return crop;
    }

    public void insertCrop(Crop crop) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int cropId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT MAX(CROP_ID)+1 AS NEW_CROP_ID FROM CROP_REF");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                cropId = resultSet.getInt("NEW_CROP_ID");
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            preparedStatement = connection.prepareStatement
                    ("INSERT INTO CROP_REF (CROP_ID,SHORT_DESCRIPTION,LONG_DESCRIPTION,ACTIVE_FLAG,SAP_CROP_CODE) VALUES(?,?,'','Y',?)");
            preparedStatement.setInt(1, cropId);
            preparedStatement.setString(2, crop.getCropName());
            preparedStatement.setString(3, crop.getCropSAPId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }

    public void insertBusinessCropReference(Crop crop) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int businessCropId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT ID FROM BUSINESS_FAMILY_REF WHERE BUSINESS_ID=? AND COMPLAINT_FAMILY_ID=(SELECT CROP_ID FROM CROP_REF WHERE SAP_CROP_CODE=?)");
            preparedStatement.setInt(1, 2);
            preparedStatement.setString(2, crop.getCropSAPId());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                businessCropId = resultSet.getInt("ID");
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            if (businessCropId == 0) {
                preparedStatement = connection.prepareStatement
                        ("SELECT MAX(ID)+1 AS NEW_BUSINESS_CROP_ID FROM BUSINESS_FAMILY_REF");
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    businessCropId = resultSet.getInt("NEW_BUSINESS_CROP_ID");
                }
                if (businessCropId == 0) {
                    businessCropId = 1;
                }

                MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

                preparedStatement = connection.prepareStatement
                        ("INSERT INTO BUSINESS_FAMILY_REF (ID,BUSINESS_ID,COMPLAINT_FAMILY_ID,ACTIVE,MOD_USER,MOD_DATE,CROP_ID) VALUES(?,?,(SELECT CROP_ID FROM CROP_REF WHERE SAP_CROP_CODE=?),'Y','VRBETHI',SYSDATE,(SELECT CROP_ID FROM CROP_REF WHERE SAP_CROP_CODE=?))");
                preparedStatement.setInt(1, businessCropId);
                preparedStatement.setInt(2, 2);
                preparedStatement.setString(3, crop.getCropSAPId());
                preparedStatement.setString(4, crop.getCropSAPId());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }
}
