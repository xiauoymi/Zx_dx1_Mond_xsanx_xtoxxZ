/*
 FunctionDaoImpl was created on Mar 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: FunctionDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class FunctionDaoImpl implements FunctionDao {
    private final DataSource dataSource;

    public FunctionDaoImpl(DataSource dataSource) {

        this.dataSource = dataSource;
    }

    public Map<String, String> lookUpFunctionsForLocation(String locationCode, String locale) {
        Map<String, String> functionReferenceData = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT CF.FUNCTION_ID,CF.DESCRIPTION FROM CCAS_FUNCTION CF,FUNCTION_LOCATION FL WHERE CF.ACTIVE='Y' \n" +
                            "AND FL.FUNCTION_ID=CF.FUNCTION_ID AND FL.LOCATION_ID=? ORDER BY CF.DESCRIPTION ASC ");
            preparedStatement.setString(1, locationCode);
            resultSet = preparedStatement.executeQuery();

            String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
            functionReferenceData.put("", selectOne);
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int functionId = resultSet.getInt("FUNCTION_ID");

                String functionDescription = iService.translate(locale, "CCAS_FUNCTION", functionId, resultSet.getString("DESCRIPTION"));

                functionReferenceData.put(Integer.toString(functionId), functionDescription);
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return functionReferenceData;
    }

    public String lookUpFunctionWithId(int functionId, String locale) {
        String functionDescription = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT CF.FUNCTION_ID,CF.DESCRIPTION,CF.ACTIVE FROM CCAS_FUNCTION CF WHERE CF.FUNCTION_ID=?");
            preparedStatement.setInt(1, functionId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {

                functionDescription = iService.translate(locale, "CCAS_FUNCTION", functionId, resultSet.getString("DESCRIPTION"));
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return functionDescription;
    }

}
