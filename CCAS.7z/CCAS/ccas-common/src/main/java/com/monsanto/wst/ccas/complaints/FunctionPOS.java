/*
 FunctionPOS was created on Mar 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.ajax.AJAXException;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Filename:    $RCSfile: FunctionPOS.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class FunctionPOS extends AJAXUseCaseController {
//    //  ToDo: This class will be removed soon.  Use BaseSecurePOSController instead
//    protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException,
//            NoLogonInformationException {
//        return null;
//    }
//
//    protected void runImplementation(UCCHelper helper, Document inputDocument) throws IOException {
//
//        User user = (User) helper.getSessionParameter(User.USER);
//        FunctionService functionService = new FunctionServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
//        Document functionsForLocation = functionService.getFunctionsForLocation(inputDocument, user.getLocale());
//        helper.writeXMLDocument(functionsForLocation);
//    }
//
//    protected String getXMLSchemaRelativeToServletContext() {
//        return "/com/monsanto/wst/ccas/xsdResources/function.xsd";
//    }

    protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
        User user = (User) helper.getSessionParameter(User.USER);
        FunctionService functionService = new FunctionServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
        //added to get this on its own line to track down NullPointerException from logs.
        final String locale = user.getLocale();
        Document functionsForLocation = functionService.getFunctionsForLocation(inputDocument, locale);
        helper.writeXMLDocument(functionsForLocation);
    }
}
