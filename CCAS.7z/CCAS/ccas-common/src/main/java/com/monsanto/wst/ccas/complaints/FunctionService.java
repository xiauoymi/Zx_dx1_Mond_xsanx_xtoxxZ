/*
 FunctionService was created on Mar 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import org.w3c.dom.Document;

import java.util.Map;

/**
 * Filename:    $RCSfile: FunctionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface FunctionService {
    Document getFunctionsForLocation(Document locationCode, String locale);

    Map<String, String> getFunctionsForLocation(String locationCode, String locale);
}