/*
 FunctionServiceImpl was created on Mar 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.complaints;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Filename:    $RCSfile: FunctionServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class FunctionServiceImpl implements FunctionService {
    private final DataSource dataSource;

    public FunctionServiceImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Document getFunctionsForLocation(Document locationXML, String locale) {
        FunctionDao functionDao = new FunctionDaoImpl(dataSource);
        Document document = DOMUtil.newDocument();
        Element functionsElement = DOMUtil.addChildElement(document, "functions");

        NodeList list = DOMUtil.getNodeListByTagName(locationXML, "functionId");
        if (list == null || list.getLength() == 0)
            return document;
        String locationCode = list.item(0).getNodeValue();
        Map<String, String> map = functionDao.lookUpFunctionsForLocation(locationCode, locale);

        for (String s : map.keySet()) {
            String key = s;
            String description = map.get(key);
            Element functionElement = DOMUtil.addChildElement(functionsElement, "function");
            DOMUtil.addChildElement(functionElement, "functionId", key);
            DOMUtil.addChildElement(functionElement, "functionDescription", description);
        }
        return document;
    }

    public Map<String, String> getFunctionsForLocation(String locationCode, String locale) {
        FunctionDao functionDao = new FunctionDaoImpl(dataSource);
        return functionDao.lookUpFunctionsForLocation(locationCode, locale);
    }
}
