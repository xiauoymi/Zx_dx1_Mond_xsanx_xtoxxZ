package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 16, 2010 Time: 10:02:11 AM To change this template use File |
 * Settings | File Templates.
 */
public interface InitiatorSampleDao {
  Map<String, String> lookupAllInitiatorSamples(String locale);
}
