package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: May 4, 2010
 * Time: 11:11:25 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IssueCategoryDao {
  Map<String, String> lookUpIssueCategory(int level, String locale, String source);
}
