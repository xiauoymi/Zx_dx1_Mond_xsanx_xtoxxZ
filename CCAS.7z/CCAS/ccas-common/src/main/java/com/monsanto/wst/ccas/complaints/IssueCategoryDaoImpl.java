package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.actions.ComplaintAction;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import org.apache.log4j.Logger;

import javax.sql.DataSource;
import java.util.Map;
import java.util.LinkedHashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: May 4, 2010
 * Time: 11:11:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class IssueCategoryDaoImpl implements IssueCategoryDao {

    private static final Logger logger = Logger.getLogger(IssueCategoryDaoImpl.class.getName());
    
    private DataSource dataSource;

    public IssueCategoryDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookUpIssueCategory(int level, String locale, String source) {
        Map<String, String> issueCategoryMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM ISSUE_CATEGORY WHERE LEVEL_ID=? AND ISSUE_CATEGORY_SOURCE = ? ORDER BY DESCRIPTION");
            preparedStatement.setInt(1, level);
            preparedStatement.setString(2, source);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();
            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String issueCategoryId = new Integer(id).toString();
                String issueCategoryDescription = resultSet.getString("DESCRIPTION");
                String value = iService.translate(locale, "ISSUE_CATEGORY", id, issueCategoryDescription);
                issueCategoryMap.put(issueCategoryId, value);

            }

        } catch (SQLException e) {
            e.printStackTrace();

            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error looking for Issue Category DAO.");

        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return issueCategoryMap;

    }
}
