package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;
import com.monsanto.wst.ccas.importdata.MaterialGroup;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 28, 2008
 * Time: 1:05:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MaterialGroupDao {

    public Map<String, String> lookupCropRelatedMaterialGroups(List<String> cropIdList, String locale);

    MaterialGroup lookupMaterialGroupWithSapId(String materialGroupSAPId, String locale);

    void insertMaterialGroup(MaterialGroup materialGroup);

    void insertCropMaterialGroupReference(Crop crop);

    String lookupMaterialGroupWithId(int materialGroupId, String locale);
}
