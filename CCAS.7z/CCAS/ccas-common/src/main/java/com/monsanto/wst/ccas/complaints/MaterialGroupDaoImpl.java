package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;
import com.monsanto.wst.ccas.importdata.MaterialGroup;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 28, 2008
 * Time: 1:09:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupDaoImpl implements MaterialGroupDao {
    private final DataSource dataSource;

    public MaterialGroupDaoImpl(DataSource basicDataSource) {
        this.dataSource = basicDataSource;
    }

    /**
     * Method to Fetch Material Groups based on crop change
     *
     * @param cropIdList
     * @return Map <MaterialGrpId,List>
     */
    public Map<String, String> lookupCropRelatedMaterialGroups(List<String> cropIdList, String locale) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        Map<String, String> materialGroupCodeNameMap = new LinkedHashMap<String, String>();
        StringBuffer sqlBuf = new StringBuffer();
        sqlBuf.append("SELECT DISTINCT CMG.COMPLAINT_MATERIAL_GROUP_ID,CMG.COMPLAINT_MATERIAL_GROUP_NAME " +
                " FROM COMPLAINT_MATERIAL_GROUP CMG,CROP_REF CR,FAMILY_MATERIAL_GROUP_REF FMGR  " +
                " WHERE CR.CROP_ID IN (");

        for (String s : cropIdList) {
            sqlBuf.append(Integer.parseInt(s));
            sqlBuf.append(",");
        }
        sqlBuf.deleteCharAt(sqlBuf.length() - 1);
        sqlBuf.append(")AND CR.CROP_ID=FMGR.FAMILY_ID  AND CMG.COMPLAINT_MATERIAL_GROUP_ID=FMGR.MATERIAL_GROUP_ID ORDER BY CMG.COMPLAINT_MATERIAL_GROUP_NAME asc");
        try {
            conn = dataSource.getConnection();
            ps = conn.prepareStatement(sqlBuf.toString());
            rs = ps.executeQuery();
            if (rs != null) {

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                materialGroupCodeNameMap.put("", " " + selectOne + " ");
                I18nServiceImpl iService = new I18nServiceImpl();
                while (rs.next()) {

                    int id = rs.getInt("COMPLAINT_MATERIAL_GROUP_ID");
                    String materialGroupDescription = rs.getString("COMPLAINT_MATERIAL_GROUP_NAME");
                    String desc = iService.translate(locale, "COMPLAINT_MATERIAL_GROUP", id, materialGroupDescription);

                    materialGroupCodeNameMap.put(Integer.toString(id), desc);
                }

            }
        } catch (Exception e) {  //todo gobbled exception
            MCASLogUtil.logError(e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(conn, ps, rs);
        }
        return materialGroupCodeNameMap;

    }

    public MaterialGroup lookupMaterialGroupWithSapId(String materialGroupSAPId, String locale) {
        MaterialGroup materialGroup = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("SELECT CMG.COMPLAINT_MATERIAL_GROUP_ID,CMG.COMPLAINT_MATERIAL_GROUP_NAME," +
                    "CMG.SAP_CODE FROM COMPLAINT_MATERIAL_GROUP CMG WHERE CMG.SAP_CODE=?");
            preparedStatement.setString(1, materialGroupSAPId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();
            while (resultSet.next()) {

                int id = resultSet.getInt("COMPLAINT_MATERIAL_GROUP_ID");
                String materialGroupDescription = resultSet.getString("COMPLAINT_MATERIAL_GROUP_NAME");
                String desc = iService.translate(locale, "COMPLAINT_MATERIAL_GROUP", id, materialGroupDescription);

                materialGroup = new MaterialGroup(materialGroupSAPId, desc);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return materialGroup;
    }

    public String lookupMaterialGroupWithId(int materialGroupId, String locale) {
        String materialGroupName = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("SELECT CMG.COMPLAINT_MATERIAL_GROUP_NAME" +
                    " FROM COMPLAINT_MATERIAL_GROUP CMG WHERE CMG.COMPLAINT_MATERIAL_GROUP_ID=?");
            preparedStatement.setInt(1, materialGroupId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {

                I18nServiceImpl iService = new I18nServiceImpl();
                materialGroupName = iService.translate(locale, "COMPLAINT_MATERIAL_GROUP", materialGroupId, resultSet.getString("COMPLAINT_MATERIAL_GROUP_NAME"));

            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return materialGroupName;
    }

    public void insertMaterialGroup(MaterialGroup materialGroup) {
        Connection connection = null;
        int materialGroupId = 0;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT MAX(COMPLAINT_MATERIAL_GROUP_ID)+1 AS NEW_MATERIAL_GROUP_ID FROM COMPLAINT_MATERIAL_GROUP");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                materialGroupId = resultSet.getInt("NEW_MATERIAL_GROUP_ID");
            }
            if (materialGroupId == 0) {
                materialGroupId = 1;
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            preparedStatement = connection.prepareStatement
                    ("INSERT INTO COMPLAINT_MATERIAL_GROUP (COMPLAINT_MATERIAL_GROUP_ID,COMPLAINT_MATERIAL_GROUP_NAME" +
                            ",ACTIVE,MOD_USER,MOD_DATE,SAP_CODE) VALUES(?,?,'Y','VRBETHI',SYSDATE,?)");
            preparedStatement.setInt(1, materialGroupId);
            preparedStatement.setString(2, materialGroup.getMaterialGroupName());
            preparedStatement.setString(3, materialGroup.getMaterialGroupSAPId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }

    public void insertCropMaterialGroupReference(Crop crop) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int cropMaterialGroupId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT ID FROM FAMILY_MATERIAL_GROUP_REF WHERE FAMILY_ID=(SELECT CROP_ID FROM CROP_REF WHERE SAP_CROP_CODE=?) AND MATERIAL_GROUP_ID=(SELECT COMPLAINT_MATERIAL_GROUP_ID FROM COMPLAINT_MATERIAL_GROUP WHERE SAP_CODE=?)");
            preparedStatement.setString(1, crop.getCropSAPId());
            preparedStatement.setString(2, crop.getMaterialGroupSAPId());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                cropMaterialGroupId = resultSet.getInt("ID");
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            if (cropMaterialGroupId == 0) {
                preparedStatement = connection.prepareStatement
                        ("SELECT MAX(ID)+1 AS NEW_CROP_MG_ID FROM FAMILY_MATERIAL_GROUP_REF");
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    cropMaterialGroupId = resultSet.getInt("NEW_CROP_MG_ID");
                }
                if (cropMaterialGroupId == 0) {
                    cropMaterialGroupId = 1;
                }

                MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

                preparedStatement = connection.prepareStatement
                        ("INSERT INTO FAMILY_MATERIAL_GROUP_REF (ID,FAMILY_ID,MATERIAL_GROUP_ID,ACTIVE,MOD_USER,MOD_DATE) " +
                                "VALUES(?,(SELECT CROP_ID FROM CROP_REF WHERE SAP_CROP_CODE=?),(SELECT COMPLAINT_MATERIAL_GROUP_ID FROM COMPLAINT_MATERIAL_GROUP WHERE SAP_CODE=?),'Y','VRBETHI',SYSDATE)");
                preparedStatement.setInt(1, cropMaterialGroupId);
                preparedStatement.setString(2, crop.getCropSAPId());
                preparedStatement.setString(3, crop.getMaterialGroupSAPId());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }

}
