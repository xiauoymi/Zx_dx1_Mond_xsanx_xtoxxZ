package com.monsanto.wst.ccas.complaints;

import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.MaterialGroupService;
import com.monsanto.wst.ccas.service.MaterialGroupServiceImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.ajax.AJAXException;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 9, 2008
 * Time: 10:46:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupPOS extends AJAXUseCaseController {

  protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
    User user = (User) helper.getSessionParameter(User.USER);

    DOMUtil.outputXML(inputDocument);
    MaterialGroupDao materialGroupDao = new MaterialGroupDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
    MaterialGroupService materialGroupService = new MaterialGroupServiceImpl(materialGroupDao);
    Document functionsForLocation = materialGroupService.lookUpCropRelatedMaterialGroups(inputDocument, user.getLocale());
    helper.writeXMLDocument(functionsForLocation);

  }
}
