package com.monsanto.wst.ccas.complaints;

import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.MaterialGroupPricingService;
import com.monsanto.wst.ccas.service.MaterialGroupPricingServiceImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.ajax.AJAXException;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * Date: Apr 10, 2008
 * Time: 1:39:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupPricingPOS extends AJAXUseCaseController {
  protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
    User user = (User) helper.getSessionParameter(User.USER);

    DOMUtil.outputXML(inputDocument);
    MaterialGroupPricingService materialGroupPricingService = new MaterialGroupPricingServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
    Document functionsForLocation = materialGroupPricingService.lookupMaterialGroupRelatedPricing(inputDocument, user.getLocale());
    helper.writeXMLDocument(functionsForLocation);

  }
}
