package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;
import com.monsanto.wst.ccas.importdata.MaterialPricingGroup;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 28, 2008
 * Time: 2:28:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MaterialPricingGroupDao {
    /**
     * Method to find material group pricing based on material group id
     *
     * @param materialPricingGroupIdList
     * @return <ID,List>
     */
    Map<String, String> lookupMaterialGroupRelatedPricing(List<String> materialPricingGroupIdList, String locale);

    MaterialPricingGroup lookupMaterialPricingGroupWithSapId(String materialPricingGroupSAPId, String locale);

    void insertMaterialPricingGroup(MaterialPricingGroup materialPricingGroup);

    void insertMgMpgRef(Crop crop);

    String lookupMaterialPricingGroupWithId(int materialPricingGroupId, String locale);
}
