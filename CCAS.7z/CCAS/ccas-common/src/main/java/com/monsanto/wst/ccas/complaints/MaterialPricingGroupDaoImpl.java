package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.Crop;
import com.monsanto.wst.ccas.importdata.MaterialPricingGroup;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Mar 31, 2008
 * Time: 12:16:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialPricingGroupDaoImpl implements MaterialPricingGroupDao {
    private final DataSource dataSource;

    public MaterialPricingGroupDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Method to look up pricing group based on material group selection
     *
     * @param materialPricingGroupIdList
     * @return Map<Code,MaterialGroupPricingList>
     */
    public Map<String, String> lookupMaterialGroupRelatedPricing(List<String> materialPricingGroupIdList, String locale) {
        Map<String, String> materialPricingsMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        StringBuffer sqlBuf = new StringBuffer();
        sqlBuf.append(" select distinct mpg.complaint_mprg_id, mpg.complaint_mprg_name " +
                " from complaint_material_pricing_grp mpg, complaint_material_group mg, material_pg_material_group_ref mpmg " +
                " where mpmg.material_group_id = mg.COMPLAINT_MATERIAL_GROUP_ID " +
                " and mpmg.complaint_MPRG_ID=mpg.complaint_mprg_id " +
                " and mg.COMPLAINT_MATERIAL_GROUP_ID IN( ");
        try {
            for (String materialPricingGroupId : materialPricingGroupIdList) {
                sqlBuf.append(materialPricingGroupId);
                sqlBuf.append(",");
            }
            sqlBuf = sqlBuf.deleteCharAt(sqlBuf.length() - 1);
            sqlBuf.append(" ) order by mpg.complaint_mprg_name asc");
            connection = dataSource.getConnection();

            preparedStatement = connection.prepareStatement(sqlBuf.toString());
            //preparedStatement.setInt(1, materialPricingGroupIdList);
            resultSet = preparedStatement.executeQuery();
            if (resultSet != null) {
                int materialGroupId = -1;

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                materialPricingsMap.put("", selectOne);
                I18nServiceImpl service = new I18nServiceImpl();

                while (resultSet.next()) {

                    materialGroupId = resultSet.getInt("COMPLAINT_MPRG_ID");
                    String materialGroupDescription = service.translate(locale, "COMPLAINT_MATERIAL_PRICING_GRP", materialGroupId, resultSet.getString("COMPLAINT_MPRG_NAME"));
                    materialPricingsMap.put(Integer.toString(materialGroupId), materialGroupDescription);
                }

            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return materialPricingsMap;
    }


    public MaterialPricingGroup lookupMaterialPricingGroupWithSapId(String materialPricingGroupSAPId, String locale) {
        MaterialPricingGroup materialPricingGroup = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("SELECT CMPG.COMPLAINT_MPRG_ID,CMPG.COMPLAINT_MPRG_NAME,SAP_CODE FROM COMPLAINT_MATERIAL_PRICING_GRP CMPG WHERE CMPG.SAP_CODE=?");
            preparedStatement.setString(1, materialPricingGroupSAPId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {

                int materialGroupId = resultSet.getInt("COMPLAINT_MPRG_ID");
                String materialPricingGroupName = iService.translate(locale, "COMPLAINT_MATERIAL_PRICING_GRP", materialGroupId, resultSet.getString("COMPLAINT_MPRG_NAME"));
                materialPricingGroup = new MaterialPricingGroup(materialPricingGroupSAPId, materialPricingGroupName);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return materialPricingGroup;
    }

    public String lookupMaterialPricingGroupWithId(int materialPricingGroupId, String locale) {
        String materialPricingGroupName = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("SELECT CMPG.COMPLAINT_MPRG_ID," +
                    "CMPG.COMPLAINT_MPRG_NAME,SAP_CODE FROM COMPLAINT_MATERIAL_PRICING_GRP CMPG WHERE CMPG.COMPLAINT_MPRG_ID=?");
            preparedStatement.setInt(1, materialPricingGroupId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {

                materialPricingGroupName = iService.translate(locale, "COMPLAINT_MATERIAL_PRICING_GRP", materialPricingGroupId, resultSet.getString("COMPLAINT_MPRG_NAME"));
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return materialPricingGroupName;
    }

    public void insertMaterialPricingGroup(MaterialPricingGroup materialPricingGroup) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int materialPricingGroupid = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT MAX(COMPLAINT_MPRG_ID)+1 AS NEW_MATERIAL_P_GROUP_ID FROM COMPLAINT_MATERIAL_PRICING_GRP");
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                materialPricingGroupid = resultSet.getInt("NEW_MATERIAL_P_GROUP_ID");
            }
            if (materialPricingGroupid == 0) {
                materialPricingGroupid = 1;
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            preparedStatement = connection.prepareStatement
                    ("INSERT INTO COMPLAINT_MATERIAL_PRICING_GRP (COMPLAINT_MPRG_ID,COMPLAINT_MPRG_NAME" +
                            ",ACTIVE,MOD_USER,MOD_DATE,SAP_CODE) VALUES(?,?,'Y','VRBETHI',SYSDATE,?)");
            preparedStatement.setInt(1, materialPricingGroupid);
            preparedStatement.setString(2, materialPricingGroup.getMaterialPricingGroupName());
            preparedStatement.setString(3, materialPricingGroup.getMaterialPricingGroupSAPId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

    }

    public void insertMgMpgRef(Crop crop) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int cropMaterialGroupId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT ID FROM MATERIAL_PG_MATERIAL_GROUP_REF WHERE MATERIAL_GROUP_ID=(SELECT COMPLAINT_MATERIAL_GROUP_ID FROM COMPLAINT_MATERIAL_GROUP WHERE SAP_CODE=?)" +
                            " AND COMPLAINT_MPRG_ID=(SELECT COMPLAINT_MPRG_ID FROM COMPLAINT_MATERIAL_PRICING_GRP WHERE SAP_CODE=?)");
            preparedStatement.setString(1, crop.getMaterialGroupSAPId());
            preparedStatement.setString(2, crop.getMaterialPricingGroupSAPId());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                cropMaterialGroupId = resultSet.getInt("ID");
            }
            if (cropMaterialGroupId == 0) {

                MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

                preparedStatement = connection.prepareStatement
                        ("SELECT MAX(ID)+1 AS NEW_MG_MPG_REF_ID FROM MATERIAL_PG_MATERIAL_GROUP_REF");
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    cropMaterialGroupId = resultSet.getInt("NEW_MG_MPG_REF_ID");
                }
                if (cropMaterialGroupId == 0) {
                    cropMaterialGroupId = 1;
                }

                MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

                preparedStatement = connection.prepareStatement
                        ("INSERT INTO MATERIAL_PG_MATERIAL_GROUP_REF (ID,MATERIAL_GROUP_ID,COMPLAINT_MPRG_ID,ACTIVE,MOD_USER,MOD_DATE) " +
                                "VALUES(?,(SELECT COMPLAINT_MATERIAL_GROUP_ID FROM COMPLAINT_MATERIAL_GROUP WHERE SAP_CODE=?),(SELECT COMPLAINT_MPRG_ID FROM COMPLAINT_MATERIAL_PRICING_GRP WHERE SAP_CODE=?),'Y','VRBETHI',SYSDATE)");
                preparedStatement.setInt(1, cropMaterialGroupId);
                preparedStatement.setString(2, crop.getMaterialGroupSAPId());
                preparedStatement.setString(3, crop.getMaterialPricingGroupSAPId());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }
}
