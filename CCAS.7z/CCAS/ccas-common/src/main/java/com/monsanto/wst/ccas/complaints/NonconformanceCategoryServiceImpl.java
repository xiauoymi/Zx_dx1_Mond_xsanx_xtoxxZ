///*
// NonconformanceCategoryServiceImpl was created on Jan 17, 2008 using Monsanto
// resources and is the sole property of Monsanto.  Any duplication of the
// code and/or logic is a direct infringement of Monsanto's copyright.
//*/
//package com.monsanto.wst.ccas.complaints;
//
//import com.monsanto.wst.ccas.audits.CheckboxGroup;
//import com.monsanto.wst.ccas.audits.CheckboxItem;
//import com.monsanto.wst.ccas.audits.SelectedIndex;
//import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;
//import com.monsanto.wst.ccas.model.AuditObject;
//import com.monsanto.wst.ccas.service.ServiceException;
//import com.monsanto.wst.ccas.service.CheckboxItemService;
//import com.monsanto.wst.ccas.dao.DAOException;
//import com.monsanto.wst.ccas.dao.CheckboxItemDao;
//
//import java.util.*;
//
//import sun.reflect.generics.reflectiveObjects.NotImplementedException;
//
///**
// * Filename:    $RCSfile: NonconformanceCategoryServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
// *
// * @author vrbethi
// * @version $Revision: 1.1 $
// */
//public class NonconformanceCategoryServiceImpl implements CheckboxItemService {
//    private CheckboxItemDao nonconformanceCategoryDao;
//
//    public NonconformanceCategoryServiceImpl() {
//        nonconformanceCategoryDao = new NonconformanceCategoryDaoImpl();
//    }
//
//    public NonconformanceCategoryServiceImpl(CheckboxItemDao dao) {
//        nonconformanceCategoryDao = dao;
//    }
//
//    public void setCheckboxGroupsForObject(ObjectWithCheckboxGroups filter, String recordId, int businessId, boolean isEdit, String entryType, String locale, Map<String, Boolean> roles) {
//
//        List<CheckboxGroup> nonconformanceCategoryList = lookupCheckboxGroups(businessId, isEdit, entryType, recordId, locale, null);
//        if (nonconformanceCategoryList != null && nonconformanceCategoryList.size() > 0) {
//            filter.setNonconformanceCategoryList(nonconformanceCategoryList);
//            for (CheckboxGroup checkboxGroupObj : nonconformanceCategoryList) {
//                filter.setFunctionalArea(checkboxGroupObj);
//            }
//        }
//    }
//
//    public List<CheckboxGroup> lookupCheckboxGroups(int businessId, boolean isEdit, String entryType, String complaint_id,
//                                                    String locale, Map<String, Boolean> roles) {
//
//        Map<String, List<CheckboxItem>> categoryMap = getBusinessRelatedNonconformanceCategories(businessId, entryType, locale);
//
//
//        List<CheckboxGroup> nonconformanceCategoryList = null;
//        Set<String> selectedNonconformanceCategorySet = null;
//        if (categoryMap != null && categoryMap.size() > 0) {
//            nonconformanceCategoryList = createNonconformanceCategories(categoryMap);
//        }
//        if (isEdit) {
//            selectedNonconformanceCategorySet = getSelectedNonconformanceCategories(complaint_id, entryType);
//            retainSelectedNonconformanceCategories(categoryMap, selectedNonconformanceCategorySet);
//        }
//        return nonconformanceCategoryList;
//    }
//
//
//    private Set<String> getSelectedNonconformanceCategories(String complaint_id, String entryType) {
//        return nonconformanceCategoryDao.getSelectedItemsForRecord(Integer.parseInt(complaint_id), entryType);
//    }
//
//    private List<CheckboxGroup> createNonconformanceCategories(Map<String, List<CheckboxItem>> categoryMap) {
//        List<CheckboxGroup> objectList;
//        List<CheckboxItem> categoryList;
//        objectList = new ArrayList<CheckboxGroup>(categoryMap.size());
//        for (Object obj : categoryMap.keySet()) {
//            categoryList = categoryMap.get(obj.toString());
//            objectList.add(getFunctionalArea(categoryList));
//        }
//        return objectList;
//    }
//
//    protected CheckboxGroup getFunctionalArea(List<CheckboxItem> categoryList) {
//        CheckboxGroup checkboxGroup = new CheckboxGroup(categoryList);
//        checkboxGroup.createCheckboxRows();
//        return checkboxGroup;
//    }
//
//    private void retainSelectedNonconformanceCategories(Map<String, List<CheckboxItem>> categoryMap, Set selectedSet) {
//        List<CheckboxItem> categoryList;
//        for (String key : categoryMap.keySet()) {
//            categoryList = categoryMap.get(key);
//            for (CheckboxItem checkboxItem : categoryList) {
//                checkboxItem.setCheckboxItemValue(false);
//                int functionalAreaId = checkboxItem.getCheckboxItemId();
//                if (selectedSet.contains(Integer.toString(functionalAreaId))) {
//                    checkboxItem.setCheckboxItemValue(true);
//                }
//            }
//        }
//    }
//
//
//    public Map<String, List<CheckboxItem>> getBusinessRelatedNonconformanceCategories(int businessId, String entryType, String locale) throws ServiceException {
//        if (entryType.equalsIgnoreCase("S") || entryType.equalsIgnoreCase("P")) {
//            return nonconformanceCategoryDao.lookupCheckboxGroups(businessId, "C", locale, null);
//        }
//        return nonconformanceCategoryDao.lookupCheckboxGroups(businessId, entryType, locale, null);
//    }
//
//    public void deleteCategories(int objectId, String type) {
//        nonconformanceCategoryDao.deleteCheckboxItemsForRecord(objectId, type);
//    }
//
//    public void insertNonconformanceCategories(List<CheckboxItem> selectedIssueList, int objectId, String type) throws ServiceException {
//        nonconformanceCategoryDao.insertCheckboxItemsForComplaint(objectId, type, selectedIssueList);
//    }
//
//    public void updateSelectedItemsInDatabase(List<CheckboxItem> functionalAreaList, int objectId, String functionalAreaSourceType) {
////what is all this for???
////        if (functionalAreaList != null && functionalAreaList.size() > 0) {
////            AuditObject auditObj = new AuditObject();
////            auditObj.setAuditID(objectId);
////            auditObj.setSelectedFunctionalAreas(functionalAreaList);
////
////            int auditId = Integer.parseInt(auditObj.getAuditID());
//        this.nonconformanceCategoryDao.deleteCheckboxItemsForRecord(objectId, functionalAreaSourceType);
//
//        if (functionalAreaList != null) {
//            insertNonconformanceCategories(functionalAreaList, objectId, functionalAreaSourceType);
//        }
////        }
//    }
//
//    public List<CheckboxItem> getSelectedFunctionalAreas(ObjectWithCheckboxGroups record, List<SelectedIndex> selectedIndexes) {
//        throw new NotImplementedException();
//    }
//
//    public void insertSelectedItemsInDatabase(List<CheckboxItem> selectedFunctionalAreaList, int auditId, String type) {
//        throw new NotImplementedException();
//    }
//}
