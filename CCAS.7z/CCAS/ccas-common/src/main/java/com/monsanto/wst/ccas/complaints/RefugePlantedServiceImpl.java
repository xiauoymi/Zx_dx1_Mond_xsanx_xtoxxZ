package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: May 26, 2010
 * Time: 11:17:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class RefugePlantedServiceImpl implements RefugePlantedService {
    private RefugePlantedDao refugePlantedDao;

    public RefugePlantedServiceImpl(RefugePlantedDao refugePlantedDao) {
        this.refugePlantedDao = refugePlantedDao;
    }

    public Map<String, String> lookUpRefugePlanted(int field, String locale) {
        return refugePlantedDao.lookUpRefugePlanted(field, locale);
    }
}