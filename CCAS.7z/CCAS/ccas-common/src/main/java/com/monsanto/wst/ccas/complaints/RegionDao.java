package com.monsanto.wst.ccas.complaints;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 1, 2008
 * Time: 2:07:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RegionDao {
    McasRegion lookupRegion(String region, String locale);

    void insertRegion(McasRegion region);

    void insertBusinessRegion(McasRegion region);

}
