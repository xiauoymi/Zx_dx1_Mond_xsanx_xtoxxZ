package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import org.apache.commons.lang.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 1, 2008
 * Time: 2:07:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegionDaoImpl implements RegionDao {
    private final DataSource dataSource;

    public RegionDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public McasRegion lookupRegion(String regionDesc, String locale) {
        McasRegion mcasRegion = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
//      PreparedStatement ps = connection.prepareStatement("DELETE FROM REGION_REF WHERE REGION_ID=7");
//      int i = ps.executeUpdate();
//      System.out.println("i = " + i);
            I18nServiceImpl iService = new I18nServiceImpl();

            if (!MCASConstants.LANGUAGE_ENGLISH.equals(locale)) {

                int id = iService.lookupId(locale, "REGION_REF", regionDesc);
                mcasRegion = new McasRegion(Integer.toString(id), regionDesc);
            } else {

                preparedStatement = connection.prepareStatement
                        ("SELECT REGION_ID,REGION_DESCRIPTION FROM REGION_REF WHERE REGION_DESCRIPTION=?");
                preparedStatement.setString(1, StringUtils.rightPad(regionDesc, 25, ' '));
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    int id = resultSet.getInt("REGION_ID");
                    String desc = iService.translate(locale, "REGION_REF", id, resultSet.getString("REGION_DESCRIPTION"));

                    mcasRegion = new McasRegion(Integer.toString(id), desc);
                }

            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return mcasRegion;
    }

    public void insertRegion(McasRegion region) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int regionId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT MAX(REGION_ID)+1 AS NEW_REGION_ID FROM REGION_REF WHERE REGION_ID<>999");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                regionId = resultSet.getInt("NEW_REGION_ID");
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            preparedStatement = connection.prepareStatement
                    ("INSERT INTO REGION_REF(REGION_ID,REGION_DESCRIPTION) VALUES (?,?)");
            preparedStatement.setInt(1, regionId);
            preparedStatement.setString(2, region.getRegionDescription());
            preparedStatement.execute();
            region.setRegionId(regionId);
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }

    public void insertBusinessRegion(McasRegion region) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("INSERT INTO BUSINESS_REGION_REF(ID, BUSINESS_ID, REGION_ID, ACTIVE, MOD_USER, MOD_DATE) VALUES ((SELECT MAX(ID)+1 AS NEW_BUSINEE_REG_REF FROM BUSINESS_REGION_REF),?,?,'Y','VRBETHI',SYSDATE)");
            preparedStatement.setInt(1, 2);
            preparedStatement.setString(2, region.getRegionId());
            preparedStatement.execute();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, null);
        }
    }

}

