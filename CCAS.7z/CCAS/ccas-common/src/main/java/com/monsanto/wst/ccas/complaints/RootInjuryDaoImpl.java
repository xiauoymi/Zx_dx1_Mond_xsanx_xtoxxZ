package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.util.Map;
import java.util.LinkedHashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: Jun 5, 2010
 * Time: 7:53:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class RootInjuryDaoImpl implements RootInjuryDao {
    private DataSource dataSource;

    public RootInjuryDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookUpRootInjury(int rating, String locale) {
        Map<String, String> rootInjuryMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM ROOT_INJURY WHERE RATING_ID=?");
            preparedStatement.setInt(1, rating);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();
            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String rootInjuryId = Integer.toString(id);
                String rootInjuryDescription = resultSet.getString("DESCRIPTION");
                String value = iService.translate(locale, "ROOT_INJURY", id, rootInjuryDescription);
                rootInjuryMap.put(rootInjuryId, value);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return rootInjuryMap;
    }
}