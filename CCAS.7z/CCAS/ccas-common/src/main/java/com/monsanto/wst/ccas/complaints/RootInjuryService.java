package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: Jun 5, 2010
 * Time: 7:31:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RootInjuryService {
    Map<String, String> lookUpRootInjury(int rating, String locale);
}
