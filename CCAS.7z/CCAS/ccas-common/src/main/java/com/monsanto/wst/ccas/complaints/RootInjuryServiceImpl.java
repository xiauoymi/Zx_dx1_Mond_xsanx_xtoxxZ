package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: EKKUNG
 * Date: Jun 5, 2010
 * Time: 7:27:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class RootInjuryServiceImpl implements RootInjuryService {
    private RootInjuryDao rootInjuryDao;

    public RootInjuryServiceImpl(RootInjuryDao rootInjuryDao) {
        this.rootInjuryDao = rootInjuryDao;
    }

    public Map<String, String> lookUpRootInjury(int rating, String locale) {
        return rootInjuryDao.lookUpRootInjury(rating, locale);
    }
}