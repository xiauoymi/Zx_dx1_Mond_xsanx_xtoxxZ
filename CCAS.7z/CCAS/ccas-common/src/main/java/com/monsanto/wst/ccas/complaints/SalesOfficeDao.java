package com.monsanto.wst.ccas.complaints;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 1, 2008
 * Time: 2:19:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesOfficeDao {
    Map<String, String> lookupSalesOfficeBasedOnRegion(List<String> regionIdList, String locale);

    String lookupSalesOfficeWithId(String salesOfficeId);
}
