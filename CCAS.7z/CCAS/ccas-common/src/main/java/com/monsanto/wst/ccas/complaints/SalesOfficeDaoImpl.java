package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.importdata.SalesOffice;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import org.apache.commons.lang.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 1, 2008
 * Time: 2:19:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class SalesOfficeDaoImpl implements SalesOfficeDao {
    private final DataSource dataSource;

    public SalesOfficeDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookupSalesOfficeBasedOnRegion(List<String> regionIdList, String locale) {
        Map<String, String> salesOfficeMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        StringBuffer sqlBuf = new StringBuffer();
        sqlBuf.append(" select so.sales_office_id, so.sales_office_description from sales_office so, region_ref r, " +
                " region_sales_office_ref rs " +
                " where rs.sales_office_id = so.sales_office_id and rs.region_id = r.region_id and r.region_id IN ( ");
        for (String regionId : regionIdList) {
            sqlBuf.append(regionId);
            sqlBuf.append(",");
        }
        sqlBuf.deleteCharAt(sqlBuf.length() - 1);
        sqlBuf.append(" ) order by so.sales_office_description asc");
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(sqlBuf.toString());
            //preparedStatement.setString(1, regionId);
            resultSet = preparedStatement.executeQuery();

            String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
            salesOfficeMap.put("", selectOne);

            while (resultSet.next()) {
                String salesOfficeId = Integer.toString(resultSet.getInt("SALES_OFFICE_ID"));
                String salesOfficeDescription = resultSet.getString("SALES_OFFICE_DESCRIPTION");
                salesOfficeMap.put(salesOfficeId, salesOfficeDescription);
            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return salesOfficeMap;
    }


    public int insertSalesOffice(SalesOffice office) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int salesOfficeId = 0;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT MAX(SALES_OFFICE_ID)+1 AS NEW_SALES FROM SALES_OFFICE");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                salesOfficeId = resultSet.getInt("NEW_SALES");
            }
            if (salesOfficeId == 0) {
                salesOfficeId = 1;
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            preparedStatement = connection.prepareStatement
                    ("INSERT INTO SALES_OFFICE (SALES_OFFICE_ID,SALES_OFFICE_DESCRIPTION,ACTIVE,MOD_USER,MOD_DATE,SAP_CODE) VALUES(?,?,'Y','VRBETHI',SYSDATE,?)");
            preparedStatement.setInt(1, salesOfficeId);
            preparedStatement.setString(2, office.getSapSalesOfficeName());
            preparedStatement.setString(3, office.getSapSalesOfficeId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return salesOfficeId;
    }

    public void insertSalesOfficeRegionRef(int regionId, int salesOfficeId, SalesOffice salesOffice) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        int salesOfficeRefId = 0;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT ID FROM REGION_SALES_OFFICE_REF WHERE SALES_OFFICE_ID=(SELECT SALES_OFFICE_ID FROM SALES_OFFICE WHERE SAP_CODE=?) AND REGION_ID=(SELECT REGION_ID FROM REGION_REF WHERE REGION_DESCRIPTION=?)");
            preparedStatement.setString(1, salesOffice.getSapSalesOfficeId());
            preparedStatement.setString(2, StringUtils.rightPad(salesOffice.getRegion(), 25, ' '));

            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                salesOfficeRefId = resultSet.getInt("ID");
            }

            MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

            if (salesOfficeId == 0) {
                preparedStatement = connection.prepareStatement
                        ("SELECT MAX(ID)+1 AS NEW_SALES FROM REGION_SALES_OFFICE_REF");
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    salesOfficeRefId = resultSet.getInt("NEW_SALES");
                }
                if (salesOfficeRefId == 0) {
                    salesOfficeRefId = 1;
                }

                MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);

                preparedStatement = connection.prepareStatement
                        ("INSERT INTO REGION_SALES_OFFICE_REF (ID,REGION_ID,SALES_OFFICE_ID,ACTIVE,MOD_USER,MOD_DATE) VALUES(?,(SELECT REGION_ID FROM REGION_REF WHERE REGION_DESCRIPTION=?),(SELECT SALES_OFFICE_ID FROM SALES_OFFICE WHERE SAP_CODE=?),'Y','VRBETHI',SYSDATE)");
                preparedStatement.setInt(1, salesOfficeRefId);
                preparedStatement.setString(2, StringUtils.rightPad(salesOffice.getRegion(), 25, ' '));
                preparedStatement.setString(3, salesOffice.getSapSalesOfficeId());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
    }

    public SalesOffice lookupSalesOffice(SalesOffice office) {
        Connection connection = null;
        SalesOffice salesOffice = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT SALES_OFFICE_ID,SALES_OFFICE_DESCRIPTION,SAP_CODE FROM SALES_OFFICE WHERE SAP_CODE=?");
            preparedStatement.setString(1, office.getSapSalesOfficeId());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {

                String salesOfficeDescription = resultSet.getString("SALES_OFFICE_DESCRIPTION");
                String sapCode = resultSet.getString("SAP_CODE");
                salesOffice = new SalesOffice("", salesOfficeDescription, sapCode);
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return salesOffice;
    }

    public String lookupSalesOfficeWithId(String salesOfficeId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String salesOfficeDescription = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement
                    ("SELECT SALES_OFFICE_DESCRIPTION FROM SALES_OFFICE WHERE SALES_OFFICE_ID=?");
            preparedStatement.setString(1, salesOfficeId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
//        int salesOfficeId = resultSet.getInt("SALES_OFFICE_ID");
                salesOfficeDescription = resultSet.getString("SALES_OFFICE_DESCRIPTION");
//        String sapCode = resultSet.getString("SAP_CODE");
//        salesOffice = new SalesOffice("",salesOfficeDescription,sapCode);
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return salesOfficeDescription;
    }
}
