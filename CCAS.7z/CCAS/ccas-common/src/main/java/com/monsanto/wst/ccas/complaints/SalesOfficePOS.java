package com.monsanto.wst.ccas.complaints;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ajax.AJAXException;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA. User: rrmall Date: Apr 2, 2008 Time: 4:04:47 PM To change this template use File | Settings
 * | File Templates.
 */
public class SalesOfficePOS extends AJAXUseCaseController {

  protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
    String locale = ((User) helper.getSessionParameter(User.USER)).getLocale();

    DOMUtil.outputXML(inputDocument);
    SalesOfficeService salesOfficeService = new SalesOfficeServiceImpl(
        WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
    Document functionsForLocation = salesOfficeService.getRegionRelatedSalesOffices(inputDocument, locale);
  //  DOMUtil.outputXML(functionsForLocation);
    helper.writeXMLDocument(functionsForLocation);
  }
}
