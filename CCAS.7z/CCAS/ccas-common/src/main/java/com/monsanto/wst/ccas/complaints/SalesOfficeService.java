package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.actions.IActionHelper;
import com.monsanto.wst.ccas.importdata.SalesOffice;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 2, 2008
 * Time: 4:11:47 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesOfficeService {
    Document getRegionRelatedSalesOffices(Document inputDocument, String locale);

    boolean insertData(RegionDao regionDao, SalesOffice office);

    Document getDataRelatedToRegion(String regionId, Document document, IActionHelper actionHelper, String locale);
}
