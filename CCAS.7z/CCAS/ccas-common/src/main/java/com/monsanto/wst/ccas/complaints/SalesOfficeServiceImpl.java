package com.monsanto.wst.ccas.complaints;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.IActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.importdata.SalesOffice;
import com.monsanto.wst.ccas.service.RegionService;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.dao.LocationDAOImpl;
import com.monsanto.wst.ccas.dao.LocationDAO;
import org.apache.commons.dbcp.BasicDataSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: rrmall
 * Date: Apr 2, 2008
 * Time: 4:10:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class SalesOfficeServiceImpl implements SalesOfficeService, ImportData {
    private final SalesOfficeDaoImpl salesOfficeDao;
    private final LocationDAO locationDao;
    private final RegionService regionService;

    public SalesOfficeServiceImpl(DataSource dataSource) {
        salesOfficeDao = new SalesOfficeDaoImpl(dataSource);
        regionService = new RegionServiceImpl();
        locationDao = new LocationDAOImpl(dataSource);
    }

    /**
     * Constructor for Tests
     *
     * @param regionService
     * @param salesOfficeDao
     * @param locationDao
     */
    public SalesOfficeServiceImpl(RegionService regionService, SalesOfficeDaoImpl salesOfficeDao, LocationDAO locationDao) {
        this.regionService = regionService;
        this.salesOfficeDao = salesOfficeDao;
        this.locationDao = locationDao;
    }


    private void populateSalesOfficeIdList(String region, List<String> regionIdList) {
        if (!StringUtils.isNullOrEmpty(region)) {
            StringTokenizer tokenizer = new StringTokenizer(region, ":");
            while (tokenizer.hasMoreTokens()) {
                regionIdList.add(tokenizer.nextToken());
            }
        }

    }

    public Document getRegionRelatedSalesOffices(Document regionXML, String locale) {
        String regionId = getRegionId(regionXML);
        return getDataRelatedToRegion(regionId, DOMUtil.newDocument(), new ActionHelper(), locale);
    }

    public Document getDataRelatedToRegion(String regionId, Document document, IActionHelper actionHelper, String locale) {
        Map<String, String> stateMap;
        List<String> regionIdList = new ArrayList<String>();

        stateMap = actionHelper.getRegionSpecificStatesList(null, regionId, locale);

        Map<String, String> responsibleLocationMap = locationDao.lookupLocationBasedOnRegion(regionId, MCASConstants.LOCATION_TYPE_RESPONSIBLE, locale);
        Map<String, String> filingLocationMap = locationDao.lookupLocationBasedOnRegion(regionId, MCASConstants.LOCATION_TYPE_FILING, locale);
        Map<String, String> reportingLocationMap = locationDao.lookupLocationBasedOnRegion(regionId, MCASConstants.LOCATION_TYPE_REPORTING, locale);
        Map<String, String> shippingLocationMap = locationDao.lookupLocationBasedOnRegion(regionId, MCASConstants.LOCATION_TYPE_SHIPPING, locale);
        Map<String, String> customerLocationMap = locationDao.lookupLocationBasedOnRegion(regionId, MCASConstants.LOCATION_TYPE_CUSTOMER, locale);

        populateSalesOfficeIdList(regionId, regionIdList);
        Map<String, String> officeMap = salesOfficeDao.lookupSalesOfficeBasedOnRegion(regionIdList, locale);
        Element salesOfficesInfoElement = DOMUtil.addChildElement(document, MCASConstants.XMLTAG_SALES_OFFICES_INFO);

        addLocationToXML(MCASConstants.XMLTAG_SALES_OFFICES, MCASConstants.XMLTAG_SALES_OFFICE, officeMap, salesOfficesInfoElement);
        addLocationToXML(MCASConstants.XMLTAG_STATES, MCASConstants.XMLTAG_STATE, stateMap, salesOfficesInfoElement);

        addLocationToXML(MCASConstants.XMLTAG_RESPONSIBLE_LOCATIONS, MCASConstants.XMLTAG_LOCATION, responsibleLocationMap, salesOfficesInfoElement);
        addLocationToXML(MCASConstants.XMLTAG_FILING_LOCATIONS, MCASConstants.XMLTAG_LOCATION, filingLocationMap, salesOfficesInfoElement);
        addLocationToXML(MCASConstants.XMLTAG_REPORTING_LOCATIONS, MCASConstants.XMLTAG_LOCATION, reportingLocationMap, salesOfficesInfoElement);
        addLocationToXML(MCASConstants.XMLTAG_SHIPPING_LOCATIONS, MCASConstants.XMLTAG_LOCATION, shippingLocationMap, salesOfficesInfoElement);
        addLocationToXML(MCASConstants.XMLTAG_CUSTOMER_LOCATIONS, MCASConstants.XMLTAG_LOCATION, customerLocationMap, salesOfficesInfoElement);

        return document;
    }

    private void addLocationToXML(String parentElementName, String childElementName, Map<String, String> locationMap, Element salesOfficesInfoElement) {
        Element locationsElement = DOMUtil.addChildElement(salesOfficesInfoElement, parentElementName);
        String description;
        for (String key : locationMap.keySet()) {
            Element locationElement = DOMUtil.addChildElement(locationsElement, childElementName);
            DOMUtil.addChildElement(locationElement, childElementName + "ID", key);
            description = locationMap.get(key);
            if (!StringUtils.isNullOrEmpty(description)) {
                description = description.trim();
                DOMUtil.addChildElement(locationElement, childElementName + "Description", description);
            }

        }
    }

    private String getRegionId(Document regionXML) {
        String regionId = "-1";
        if (DOMUtil.getNodeListByTagName(regionXML, MCASConstants.XMLTAG_REGION_ID).item(0) != null) {
            regionId = DOMUtil.getNodeListByTagName(regionXML, MCASConstants.XMLTAG_REGION_ID).item(0).getNodeValue();
        }
        return regionId;
    }

    public boolean insertData(RegionDao regionDao, SalesOffice office) {
        regionService.insertBusinessRegion(regionDao, office);
        SalesOffice salesOffice = salesOfficeDao.lookupSalesOffice(office);
        int salesOfficeId = 0;
        if (salesOffice == null) {
            salesOfficeId = salesOfficeDao.insertSalesOffice(office);
//            salesOffice = salesOfficeDao.lookupSalesOffice(office);
        }
        salesOfficeDao.insertSalesOfficeRegionRef(salesOfficeId, salesOfficeId, office);
        return false;
    }

}
