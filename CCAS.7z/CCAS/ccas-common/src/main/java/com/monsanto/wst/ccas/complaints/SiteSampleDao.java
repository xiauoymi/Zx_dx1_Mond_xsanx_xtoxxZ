package com.monsanto.wst.ccas.complaints;

import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 20, 2010 Time: 3:56:04 PM To change this template use File |
 * Settings | File Templates.
 */
public interface SiteSampleDao {
  Map<String, String> lookupAllSiteSamples(String locale);
}
