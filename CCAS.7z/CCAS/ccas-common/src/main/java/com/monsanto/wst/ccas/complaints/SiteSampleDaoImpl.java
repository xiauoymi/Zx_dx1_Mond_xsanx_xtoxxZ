package com.monsanto.wst.ccas.complaints;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 20, 2010 Time: 3:55:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class SiteSampleDaoImpl implements SiteSampleDao {
    private static final Category logger = Category.getInstance(SiteSampleDaoImpl.class.getName());
    private DataSource dataSource;

    public SiteSampleDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookupAllSiteSamples(String locale) {
        Map<String, String> map = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM SITE_SAMPLE_REF WHERE ACTIVE = 'Y'");
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();
            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String idStr = Integer.toString(id);
                String value = iService.translate(locale, "SITE_SAMPLE_REF", id, resultSet.getString("VALUE"));
                map.put(idStr, value);
            }

        } catch (SQLException e) {
            MCASLogUtil.logError("Exception while getting lookupAllSiteSamples: ", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return map;
    }
}
