package com.monsanto.wst.ccas.complaints.claims;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 13, 2009
 * Time: 1:16:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class Claim {
    private final Long claimId;
    private final int claimYear;
    private final int retailerDealerAccountId;
    private final int retailerDealerSapId;
    private final String retailerDealerName;
    private final String retailerDealerAddress;
    private final String retailerDealerCityName;
    private final String retailerDealerState;
    private final int retailerDealerZip;
    private final String monsantoRepSignatureFlag;
    private final int growerAccountId;
    private final int growerSapId;
    private final String growerName;
    private final String growerAddress;
    private final String growerAddress2;
    private final String growerCity;
    private final int growerZip;
    private final String growerSignatureFlag;
    private final int sapOrderNumber;
    private final int sapDeliveryNumber;
    private final String cropName;
    private float totalSettlementValue;
    private final String claimStatusIndicator;
    private final String growerState;
    private final String holdReasonStatus;
    private final String problemDescription;

    public Claim(Long claimId, int claimYear, int retailerDealerAccountId, int retailerDealerSapId, String retailerDealerName,
                 String retailerDealerAddress, String retailerDealerCityName, String retailerDealerState, int retailerDealerZip,
                 String monsantoRepSignatureFlag, int growerAccountId, int growerSapId, String growerName, String growerAddress,
                 String growerAddress2, String growerCity, int growerZip, String growerSignatureFlag, int sapOrderNumber, int sapDeliveryNumber,
                 String cropName, float totalSettlementValue, String claimStatusIndicator, String growerState, String holdReasonStatus,String problemDescription) {


        this.claimId = claimId;
        this.claimYear = claimYear;
        this.retailerDealerAccountId = retailerDealerAccountId;
        this.retailerDealerSapId = retailerDealerSapId;
        this.retailerDealerName = retailerDealerName;
        this.retailerDealerAddress = retailerDealerAddress;
        this.retailerDealerCityName = retailerDealerCityName;
        this.retailerDealerState = retailerDealerState;
        this.retailerDealerZip = retailerDealerZip;
        this.monsantoRepSignatureFlag = monsantoRepSignatureFlag;
        this.growerAccountId = growerAccountId;
        this.growerSapId = growerSapId;
        this.growerName = growerName;
        this.growerAddress = growerAddress;
        this.growerAddress2 = growerAddress2;
        this.growerCity = growerCity;
        this.growerZip = growerZip;
        this.growerSignatureFlag = growerSignatureFlag;
        this.sapOrderNumber = sapOrderNumber;
        this.sapDeliveryNumber = sapDeliveryNumber;
        this.cropName = cropName;
        this.totalSettlementValue = totalSettlementValue;
        this.claimStatusIndicator = claimStatusIndicator;
        this.growerState = growerState;
        this.holdReasonStatus = holdReasonStatus;
        this.problemDescription=problemDescription;
    }


    public Long getClaimId() {
        return claimId;
    }

    public int getClaimYear() {
        return claimYear;
    }

    public int getRetailerDealerAccountId() {
        return retailerDealerAccountId;
    }

    public int getRetailerDealerSapId() {
        return retailerDealerSapId;
    }

    public String getRetailerDealerName() {
        return retailerDealerName;
    }

    public String getRetailerDealerAddress() {
        return retailerDealerAddress;
    }

    public String getRetailerDealerCityName() {
        return retailerDealerCityName;
    }

    public String getGrowerState() {
        return growerState;
    }

    public String getRetailerDealerState() {
        return retailerDealerState;
    }

    public int getRetailerDealerZip() {
        return retailerDealerZip;
    }

    public String getMonsantoRepSignatureFlag() {
        return monsantoRepSignatureFlag;
    }

    public int getGrowerAccountId() {
        return growerAccountId;
    }

    public int getGrowerSapId() {
        return growerSapId;
    }

    public String getGrowerName() {
        return growerName;
    }

    public String getGrowerAddress() {
        return growerAddress;
    }

    public String getGrowerAddress2() {
        return growerAddress2;
    }

    public String getGrowerCity() {
        return growerCity;
    }

    public int getGrowerZip() {
        return growerZip;
    }

    public String getGrowerSignatureFlag() {
        return growerSignatureFlag;
    }

    public int getSapOrderNumber() {
        return sapOrderNumber;
    }

    public int getSapDeliveryNumber() {
        return sapDeliveryNumber;
    }

    public String getCropName() {
        return cropName;
    }

    public float getTotalSettlementValue() {
        return totalSettlementValue;
    }

    public void setTotalSettlementValue(float totalSettlementValue) {
        this.totalSettlementValue = totalSettlementValue;
    }

    public String getClaimStatusIndicator() {
        return claimStatusIndicator;
    }


    public Document toXML() {
        Document document = DOMUtil.newDocument();
        Element claimElement = DOMUtil.addChildElement(document, "CLAIM");
        addElements(claimElement);
        return document;
    }

    public Document toXML(Document document) {
        Element claimElement = DOMUtil.addChildElement(document.getDocumentElement(), "CLAIM");
        addElements(claimElement);
        return document;
    }

    private void addElements(Element claimElement) {
        DOMUtil.addChildElement(claimElement, "CLAIM_ID", claimId);
        DOMUtil.addChildElement(claimElement, "CLAIM_YEAR", claimYear);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_ACCT_ID", retailerDealerAccountId);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_SAP_ID", retailerDealerSapId);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_NAME", retailerDealerName);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_ADDR", retailerDealerAddress);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_CITY_NAME", retailerDealerCityName);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_STATE", retailerDealerState);
        DOMUtil.addChildElement(claimElement, "RETAILER_DEALER_ZIP", retailerDealerZip);
        DOMUtil.addChildElement(claimElement, "MONSANTO_REP_SIGNATURE_FLAG", monsantoRepSignatureFlag);
        DOMUtil.addChildElement(claimElement, "GROWER_ACCT_ID", growerAccountId);
        DOMUtil.addChildElement(claimElement, "GROWER_SAP_ID", growerSapId);
        DOMUtil.addChildElement(claimElement, "GROWER_NAME", growerName);
        DOMUtil.addChildElement(claimElement, "GROWER_ADDRESS", growerAddress);
        DOMUtil.addChildElement(claimElement, "GROWER_ADDRESS_2", growerAddress2);
        DOMUtil.addChildElement(claimElement, "GROWER_CITY", growerCity);
        DOMUtil.addChildElement(claimElement, "GROWER_ZIP", growerZip);
        DOMUtil.addChildElement(claimElement, "GROWER_STATE", growerState);
        DOMUtil.addChildElement(claimElement, "GROWER_SIGNATURE_FLAG", growerSignatureFlag);
        DOMUtil.addChildElement(claimElement, "SAP_ORDER_NUMBER", sapOrderNumber);
        DOMUtil.addChildElement(claimElement, "SAP_DELIVERY_NUMBER", sapDeliveryNumber);
        DOMUtil.addChildElement(claimElement, "CROP_NAME", cropName);
        DOMUtil.addChildElement(claimElement, "TOT_SETTLEMENT_VALUE", totalSettlementValue);
        DOMUtil.addChildElement(claimElement, "CLAIM_STATUS_INDICATOR", claimStatusIndicator);
        DOMUtil.addChildElement(claimElement, "HOLD_REASON_STATUS", holdReasonStatus);
        DOMUtil.addChildElement(claimElement, "PROBLEM_DESCRIPTION", problemDescription);
    }

    public String getProblemDescription() {
        return problemDescription;
    }

}
