package com.monsanto.wst.ccas.complaints.claims;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 13, 2009
 * Time: 1:17:58 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ClaimDao {
    Claim getClaimsInformation(String claimId);

    ClaimResult releaseClaim(String claimId);

    List<String> lookUpComplaintIdForClaim(String claimId);

    List<ComplaintClaim> lookUpUnReleasedClaims(String locale);

    void bulkReleaseClaimsUpdateComplaint(String claimId);

    String getStatusForClaim(String claimNumber, String locale);

    Map<String, String> lookUpClaimCategoryRefData(String locale);

    String getClaimCategory(String claimNumber, String locale);

    List<String> getClaimStatusTypeIndicators();
}
