package com.monsanto.wst.ccas.complaints.claims;


import com.monsanto.claims.service.client.holdmanagement.*;
import com.monsanto.wst.ccas.applicationinfo.ApplicationInfo;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;


import javax.sql.DataSource;
import javax.xml.namespace.QName;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 13, 2009
 * Time: 1:23:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class ClaimDaoImpl implements ClaimDao {

    private final DataSource dataSource;

    public ClaimDaoImpl() {
        this.dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
    }

    /*
    private String lookUpClaimsWsURL() {
                                 String url="";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String wsUrl="";
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT APPLICATION_SCREEN FROM APPLICATION_INFO where application_field_id=500");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                wsUrl = resultSet.getString("APPLICATION_SCREEN");

            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return wsUrl;
    } */

    public List<String> getClaimStatusTypeIndicators(){
        ArrayList<String> strings = new ArrayList<String>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select distinct claim_status_indicator from claim_id_view");
            while (resultSet.next()){
                strings.add(resultSet.getString("claim_status_indicator"));
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, statement, resultSet);
        }
        return strings;
    }
      /*
    private HoldManagement getClaimWSClient(){
        HoldManagementClient client=new HoldManagementClient("ClaimsHoldManagementClientConfig");
        HoldManagement svcClient=null;
        //String wsdlUrl=lookUpClaimsWsURL();
        try {
            //URL baseUrl = HoldManagementService.class.getResource(".");
            //URL svcUrl = new URL(baseUrl, wsdlUrl);
            //QName svcName = new QName("http://monsanto.com/claims/definitions", "HoldManagementService");
            //HoldManagementService svc = new HoldManagementService(svcUrl, svcName);
            //svcClient = svc.getHoldManagementPort();

        }
        //catch (MalformedURLException e) {
          //  throw new IllegalArgumentException("Invalid URL", e);
        //}

        //return svcClient;
    }
        */
    private ReleaseHoldRequest getReleaseHoldRequest(long claimId, BigInteger year, HoldReasonType type){
        ObjectFactory objectFactory=new ObjectFactory();
       ReleaseHoldRequest releaseHoldRequest = objectFactory.createReleaseHoldRequest();
        releaseHoldRequest.setClaimId(claimId);
        releaseHoldRequest.setClaimYear(year);
        releaseHoldRequest.setHoldType(type);
        return  releaseHoldRequest;


    }

    public ClaimResult releaseClaim(String claimId) {
        //Connection connection = null;
        //CallableStatement callableStatement = null;
        //ResultSet resultSet = null;
        ClaimResult result = null;
        String status =null;
        String v_msg =null;
        try {
            //connection = dataSource.getConnection();
            //callableStatement = connection.prepareCall("call CLAIMS_PROC.MCAS_UPDATES@mfg_user.monsanto.com(?,?,?)");
            //callableStatement.setString(1, claimId);
            //callableStatement.registerOutParameter(2, Types.VARCHAR);
            //callableStatement.registerOutParameter(3, Types.VARCHAR);
            //callableStatement.execute();
            ReleaseHoldRequest releaseHoldRequest=getReleaseHoldRequest(new Long(claimId),new BigInteger("20"+claimId.substring(0,2)),HoldReasonType.SEEDPPI_INVESTIGATION_REQUIRED);
            HoldManagementClient client=new HoldManagementClient("com/monsanto/wst/ccas/servlet/ClaimsHoldManagementClientConfig.properties");
            ReleaseHoldResponse resp=client.releaseHold(releaseHoldRequest.getClaimYear().intValue(),releaseHoldRequest.getClaimId(),releaseHoldRequest.getHoldType());

          status =resp.isSuccess()?"Y":"N";
          v_msg =resp.getErrorMessage();
            result = new ClaimResult(status, v_msg);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            status ="N";
            v_msg =e.getMessage();
            result = new ClaimResult(status, v_msg);
        }

        return result;
    }





    public List<ComplaintClaim> lookUpUnReleasedClaims(String locale) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<ComplaintClaim> unreleaseClaimList = new ArrayList<ComplaintClaim>();
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement("select distinct complaint.complaint_id,claim_view.CLAIM_ID,claim_view.claim_year,seedppi_hold_reason_status,variety_batch.BATCH,variety_batch.VARIETY,status_ref.status_id,status_ref.STATUS_DESCRIPTION,\n" +
                    "complaint.ROW_ENTRY_DATE,claim_category.DESCRIPTION as claim_category_description from \n" +
                    "claim_view claim_view,\n" +
                    "complaint complaint,\n" +
                    "complaint_batch complaint_batch,\n" +
                    "variety_batch variety_batch,\n" +
                    "status_ref status_ref,\n" +
                    "claim_category  claim_category\n" +
                    "where claim_view.seedppi_hold_reason_status <>'R' \n" +
                    "AND CLAIM_STATUS_INDICATOR !='V' \n" +
                    "and claim_view.CLAIM_ID=complaint.claim_number \n" +
                    "and complaint_batch.COMPLAINT_ID(+)=complaint.complaint_id \n" +
                    "and complaint_batch.VARIETY_BATCH_ID=variety_batch.VARIETY_BATCH_ID(+)\n" +
                    "and status_ref.STATUS_ID= complaint.STATUS_ID\n" +
                    "and complaint.CLAIM_CATEGORY_ID = claim_category.ID(+)");
            resultSet = statement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                ComplaintClaim complaintClaim;
                String complaint_id = resultSet.getString("complaint_id");
                String claimId = resultSet.getString("CLAIM_ID");
                String claimYear = resultSet.getString("claim_year");
                String batchNumber = resultSet.getString("BATCH");
                String description = resultSet.getString("VARIETY");

                int id = resultSet.getInt("status_id");
                String statusDescription = iService.translate(locale, "STATUS_REF", id, resultSet.getString("STATUS_DESCRIPTION"));

                String entryDate = resultSet.getString("ROW_ENTRY_DATE");
                String claim_category_description = resultSet.getString("claim_category_description");
                complaintClaim = new ComplaintClaim(complaint_id, claimYear, claimId, batchNumber, description, statusDescription, entryDate, claim_category_description);
                unreleaseClaimList.add(complaintClaim);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, statement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return unreleaseClaimList;
    }

    public String getStatusForClaim(String claimNumber, String locale) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String status = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement("select status_ref.status_id, status_description from complaint complaint,status_ref status_ref where " +
                    "complaint.CLAIM_NUMBER=? and complaint.STATUS_ID=status_ref.status_id");
            statement.setString(1, claimNumber);
            resultSet = statement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {

                int id = resultSet.getInt("status_id");
                status = iService.translate(locale, "STATUS_REF", id, resultSet.getString("STATUS_DESCRIPTION"));
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, statement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return status;
    }

    public String getClaimCategory(String claimNumber, String locale) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String description = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement("select claim_category.id, description from complaint complaint,claim_category claim_category where\n" +
                    "complaint.CLAIM_NUMBER=? and complaint.claim_category_id=claim_category.id");
            statement.setString(1, claimNumber);
            resultSet = statement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                description = iService.translate(locale, "CLAIM_CATEGORY", id, resultSet.getString("description"));
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, statement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return description;
    }

    public Map<String, String> lookUpClaimCategoryRefData(String locale) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Map<String, String> claimCategoryRefMap = new LinkedHashMap<String, String>();
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement("select ID,DESCRIPTION from claim_category where active_flag = 'Y'");

            String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
            claimCategoryRefMap.put("", selectOne);

            resultSet = statement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");

                String description = iService.translate(locale, "CLAIM_CATEGORY", id, resultSet.getString("DESCRIPTION"));

                claimCategoryRefMap.put(Integer.toString(id), description);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, statement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return claimCategoryRefMap;

    }

    public List<String> lookUpComplaintIdForClaim(String claimId) {
        List<String> complaintList = new ArrayList<String>();
        Connection connection = null;
        String complaint_id;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement("select complaint_id from complaint where claim_number=? and region_id=1 \n" +
                    "and business_id=1");
            statement.setString(1, claimId);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                complaint_id = resultSet.getString("complaint_id");
                complaintList.add(complaint_id);
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, statement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return complaintList;
    }

    public Claim getClaimsInformation(String claimId) {
        Claim claim = null;
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("select * from claim_view where claim_id=?");
            preparedStatement.setString(1, claimId);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int claimYear = resultSet.getInt("CLAIM_YEAR");
                int retailerDealerAccountId = resultSet.getInt("RETAILER_DEALER_ACCT_ID");
                int retailerDealerSapId = resultSet.getInt("RETAILER_DEALER_SAP_ID");
                String retailerDealerName = resultSet.getString("RETAILER_DEALER_NAME");
                String retailerDealerAddress = resultSet.getString("RETAILER_DEALER_ADDR");
                String retailerDealerCityName = resultSet.getString("RETAILER_DEALER_CITY_NAME");
                String retailerDealerState = resultSet.getString("RETAILER_DEALER_STATE");
                int retailerDealerZip = resultSet.getInt("RETAILER_DEALER_ZIP");
                String monsantoRepSignatureFlag = resultSet.getString("MONSANTO_REP_SIGNATURE_FLAG");
                int growerAccountId = resultSet.getInt("GROWER_ACCT_ID");
                int growerSapId = resultSet.getInt("GROWER_SAP_ID");
                String growerName = resultSet.getString("GROWER_NAME");
                String growerAddress = resultSet.getString("GROWER_ADDRESS");
                String growerAddress2 = resultSet.getString("GROWER_ADDRESS_2");
                String growerCity = resultSet.getString("GROWER_CITY");
                int growerZip = resultSet.getInt("GROWER_ZIP");
                String growerState = resultSet.getString("GROWER_STATE");
                String growerSignatureFlag = resultSet.getString("GROWER_SIGNATURE_FLAG");
                int sapOrderNumber = resultSet.getInt("SAP_ORDER_NUMBER");
                int sapDeliveryNumber = resultSet.getInt("SAP_DELIVERY_NUMBER");
                String cropName = resultSet.getString("CROP_NAME");
                float totalSettlementValue = resultSet.getFloat("TOT_SETTLEMENT_VALUE");
                String claimStatusIndicator = resultSet.getString("CLAIM_STATUS_INDICATOR");
                String holdReasonStatus = resultSet.getString("SEEDPPI_HOLD_REASON_STATUS");
                String problemDescription=resultSet.getString("PROBLEM_DESCRIPTION");
                  cropName=cropName.toLowerCase();
                cropName=cropName.substring(0,1).toUpperCase()+cropName.substring(1,cropName.length());



//        String holdReasonStatus = "X";

                claim = new Claim(new Long(claimId), claimYear, retailerDealerAccountId,
                        retailerDealerSapId, retailerDealerName, retailerDealerAddress, retailerDealerCityName,
                        retailerDealerState, retailerDealerZip, monsantoRepSignatureFlag, growerAccountId,
                        growerSapId, growerName, growerAddress, growerAddress2, growerCity, growerZip, growerSignatureFlag, sapOrderNumber, sapDeliveryNumber, cropName,
                        totalSettlementValue, claimStatusIndicator, growerState, holdReasonStatus,problemDescription);
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, preparedStatement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return claim;
    }

    private String mapCropFromClaim(String corp,Connection connection)throws SQLException{
        String cropName="";
         ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try{

        connection = dataSource.getConnection();
        preparedStatement = connection.prepareStatement("select crop_id from crop_ref where upper(short_description)='CORN'");
               // preparedStatement.setString(1, corp);
                resultSet = preparedStatement.executeQuery();
                while(resultSet.next()){
                    cropName=resultSet.getString(1);
                }

    }   finally {
      MCASResourceUtil.closeDBResources(null, preparedStatement, resultSet);
    }
        return cropName;
    }

    private void closeResources(Connection connection, Statement stmt, ResultSet rs) throws SQLException {
        if (rs != null) rs.close();
        if (stmt != null) stmt.close();
        if (connection != null) connection.close();
    }

    public void bulkReleaseClaimsUpdateComplaint(String claimId) {
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("update complaint set status_id = 1, complaint_quality_issue_id=3  where claim_number =?");
            preparedStatement.setString(1, claimId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            try {
                closeResources(connection, preparedStatement, resultSet);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
    }


}
