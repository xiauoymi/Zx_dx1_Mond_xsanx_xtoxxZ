package com.monsanto.wst.ccas.complaints.claims;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Aug 20, 2009
 * Time: 11:00:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class ClaimResult {
    private final String status;
    private final String v_msg;

    public ClaimResult(String status, String v_msg) {
        //To change body of created methods use File | Settings | File Templates.
        this.status = status;
        this.v_msg = v_msg;
    }


    public String getStatus() {
        return status;
    }

    public String getV_msg() {
        return v_msg;
    }
}
