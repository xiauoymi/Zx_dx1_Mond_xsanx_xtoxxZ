package com.monsanto.wst.ccas.complaints.claims;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.complaints.SalesOfficeServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.LookUpServiceImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 14, 2009
 * Time: 2:23:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class ClaimsController implements UseCaseController {
    private final ClaimsServiceImpl claimsService;
    private final Category logger = Category.getInstance(ClaimsController.class.getName());

    public ClaimsController() {
        this.claimsService = new ClaimsServiceImpl(new ClaimDaoImpl(), new LookUpServiceImpl(),
                new SalesOfficeServiceImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource()));
    }

    public ClaimsController(ClaimsServiceImpl claimsService) {
        this.claimsService = claimsService;
    }

    public void run(UCCHelper helper) throws IOException {
        Document xml = null;
        try {
            User user = (User) helper.getSessionParameter(User.USER);
            String method = helper.getRequestParameterValue("method");
            if (method == null) {
                xml = this.claimsService.getClaimsInformationXML(helper.getRequestParameterValue("CLAIM_ID"),
                        helper.getRequestParameterValue("COMPLAINT_ID"), helper.getRequestParameterValue("REGION_ID"), user.getLocale());
            } else if (method.equalsIgnoreCase("release")) {
                xml = this.claimsService.releaseClaimCloseComplaints(helper.getRequestParameterValue("CLAIM_ID"), user);
            } else if (method.equalsIgnoreCase("all_unrelease_claims")) {
                xml = this.claimsService.getUnReleasedClaims(user);
            } else if (method.equalsIgnoreCase("releaseAll")) {
                String parameterValue = helper.getRequestParameterValue("CLAIM_ID");
                String[] strings = parameterValue.split(",");
                if (strings.length == 0) {
                    xml = DOMUtil.newDocument();
                } else {
                    xml = this.claimsService.releaseAllClaim(strings, user);
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            xml = DOMUtil.newDocument();
            DOMUtil.addChildElement(xml, "ERROR", "Unknown Exception. Please contact support");

        }
        helper.setContentType("text/xml");
//    DOMUtil.outputXML(xml);
        helper.writeXMLDocument(xml, MCASConstants.LATIN1_ENCODING);
    }
}
