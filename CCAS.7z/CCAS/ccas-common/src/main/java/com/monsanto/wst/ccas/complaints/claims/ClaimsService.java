package com.monsanto.wst.ccas.complaints.claims;

import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.model.User;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 13, 2009
 * Time: 1:16:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ClaimsService {
    Claim getClaimsInformation(String claimId);

    Document getClaimsInformationXML(String claimId, String complaintId, String regionId, String locale);

    String releaseClaimInCIS(String claimId);

    String lookUpComplaintRelatedToAClaim(String claimId);

    boolean isClaimAssociatedWithAnotherComplaint(String claimId, String complaintId);

    Map<String, String> lookUpClaimCategoryRefData(String locale);

    Document releaseClaimCloseComplaints(String claimId, User user) throws IOException, DAOException, ParserException;

    boolean canReleaseClaim(User user, boolean environmentalClaim);
}
