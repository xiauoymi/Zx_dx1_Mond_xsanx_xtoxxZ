package com.monsanto.wst.ccas.complaints.claims;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.complaints.SalesOfficeService;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.ComplaintDAO;
import com.monsanto.wst.ccas.dao.ComplaintDAOImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.LookUpService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Aug 13, 2009
 * Time: 1:16:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class ClaimsServiceImpl implements ClaimsService {
    private final ClaimDao claimDao;
    private final LookUpService lookUpService;
    private final SalesOfficeService salesOfficeService;

    public ClaimsServiceImpl(ClaimDao claimDao, LookUpService lookUpService,
                             SalesOfficeService salesOfficeService) {
        this.claimDao = claimDao;
        this.lookUpService = lookUpService;
        this.salesOfficeService = salesOfficeService;
    }

    public Claim getClaimsInformation(String claimId) {
        validateClaimId(claimId);
        return claimDao.getClaimsInformation(claimId);
    }

    public Document getClaimsInformationXML(String claimId, String complaintId, String regionId, String locale) {

        validateClaimId(claimId);
        boolean isCISClaim = isClaimCisClaim(regionId, claimId);

        if (!isCISClaim) {
            return getErrorDocument();
        }
        Claim claim = claimDao.getClaimsInformation(claimId);
        if (isClaimAssociatedWithAnotherComplaint(claimId, complaintId)) {
            Document document = DOMUtil.newDocument();
            DOMUtil.addChildElement(document, "ERROR", "Claim already associated with another complaint");
            return document;
        }
        if ( claim == null ){
            Document document = DOMUtil.newDocument();
            DOMUtil.addChildElement(document, "ERROR", "Enter a valid Claim Number");
            return document;
        }
        Document claimDocument = DOMUtil.newDocument();
        addStateInformation(claimDocument, locale);
        return claim.toXML(claimDocument);
    }

    private void addStateInformation(Document claimDocument, String locale) {
        Document document = salesOfficeService.getDataRelatedToRegion(
                "1", claimDocument, new ActionHelper(), locale);


        Map<String, String> map = lookUpService.getStatesByRegionSelected("1", MCASConstants.LANGUAGE_ENGLISH);

        Element statesElement = DOMUtil.addChildElement(document.getDocumentElement(), "STATES");
        for (String s : map.keySet()) {
            String key = s;
            String value = map.get(key);
            Element stateElement = DOMUtil.addChildElement(statesElement, "STATE");
            DOMUtil.addChildElement(stateElement, "ID", key);
            DOMUtil.addChildElement(stateElement, "DESCRIPTION", value.trim());
        }
    }

    private Document getErrorDocument() {
        Document document = DOMUtil.newDocument();
        DOMUtil.addChildElement(document, "ERROR", "Not a CIS Claim");
        return document;
    }

    private void validateClaimId(String claimId) {
        if (claimId == null) {
            throw new IllegalArgumentException("Claim Id cannot be null");
        }
    }

    public boolean isClaimAssociatedWithAnotherComplaint(String claimId, String complaintId) {
        List<String> complaintList = claimDao.lookUpComplaintIdForClaim(claimId);
        if (complaintList.size() == 0) {
            return false;
        }
        return !complaintList.contains(complaintId);
    }

    public Map<String, String> lookUpClaimCategoryRefData(String locale) {
        return claimDao.lookUpClaimCategoryRefData(locale);
    }

    public String releaseClaimInCIS(String claimId) {
        Set<String> statusSet = new HashSet<String>();
        statusSet.add("Y");
        statusSet.add("N");
        ClaimResult result = claimDao.releaseClaim(claimId);
        if (result == null) {
            return "An exception occured releasing claim";
        } else if (!statusSet.contains(result.getStatus())) {
            return "Unknown status returned from CIS";
        } else if (result.getStatus() != null && result.getStatus().equalsIgnoreCase("Y")) {
//      claimDao.bulkReleaseClaimsUpdateComplaint(claimId);
            return "Claim Successfully released";
        }
        return result.getV_msg();  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document releaseClaimCloseComplaints(String claimId, User user) throws IOException, DAOException, ParserException {
        String[] claimArr = {claimId};
        return releaseAllClaim(claimArr, user);
    }

    public String lookUpComplaintRelatedToAClaim(String claimId) {
        List<String> list = claimDao.lookUpComplaintIdForClaim(claimId);
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Document getUnReleasedClaims(User user) throws IOException, ParserException {
        List<ComplaintClaim> list = claimDao.lookUpUnReleasedClaims(user.getLocale());
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("<response>");
        stringBuffer.append("<data>");
        for (ComplaintClaim complaintClaim : list) {
            stringBuffer.append("<row>");
            stringBuffer.append("<control_number>");
            stringBuffer.append(complaintClaim.getComplaint_id());
            stringBuffer.append("</control_number>");
            stringBuffer.append("<claim_number>");
            stringBuffer.append(complaintClaim.getClaimId());
            stringBuffer.append("</claim_number>");
            stringBuffer.append("<variety>");
            stringBuffer.append(complaintClaim.getDescription());
            stringBuffer.append("</variety>");
            stringBuffer.append("<batch>");
            stringBuffer.append(complaintClaim.getBatchNumber());
            stringBuffer.append("</batch>");
            stringBuffer.append("<claim_category>");
            stringBuffer.append(complaintClaim.getClaim_category_description());
            stringBuffer.append("</claim_category>");
            stringBuffer.append("<status_description>");
            stringBuffer.append(complaintClaim.getStatusDescription());
            stringBuffer.append("</status_description>");
            stringBuffer.append("<entryDate>");
            stringBuffer.append(complaintClaim.getEntryDate());
            stringBuffer.append("</entryDate>");
            stringBuffer.append("<canReleaseClaim>");
            boolean canReleaseClaims = canReleaseClaim(user, complaintClaim.getClaim_category_description() != null && complaintClaim.getClaim_category_description().contains("Non-mfg"));
            stringBuffer.append(canReleaseClaims);
            stringBuffer.append("</canReleaseClaim>");
            stringBuffer.append("</row>");
        }
        stringBuffer.append("</data>");
        stringBuffer.append("</response>");
        Document document;
        document = DOMUtil.newDocumentFromXML(stringBuffer.toString());
        return document;
    }

    public Document releaseAllClaim(String[] claimsList, User user) throws DAOException, IOException, ParserException {
        Complaint complaint;
        ComplaintDAO complaintDAO;
        Document document;
        complaintDAO = (ComplaintDAOImpl) DAOFactory.getDao(ComplaintDAO.class);
        StringBuffer stringBuffer = new StringBuffer();
        Map<String, String> uniqueClaimSet = new HashMap<String, String>();

        stringBuffer.append("<RESULTS>");

        String result = null;
        for (String claimId : claimsList) {
            String category = claimDao.getClaimCategory(claimId, MCASConstants.LANGUAGE_DEFAULT);
            boolean isEnvironmentalClaim = category != null && category.contains("Non-mfg");
            if (canReleaseClaim(user, isEnvironmentalClaim)) {

                if (!uniqueClaimSet.containsKey(claimId)) {
                    result = releaseClaimInCIS(claimId);
                    uniqueClaimSet.put(claimId, result);
                }
//      String result = "Claim Successfully released";
                if (result != null && result.equalsIgnoreCase("Claim Successfully released")) {
                    if (isEnvironmentalClaim) {
                        claimDao.bulkReleaseClaimsUpdateComplaint(claimId);
                    }
                }
            } else {
                result = "Only Non-Environmental claims can be ";
                uniqueClaimSet.put(claimId, result);
            }

//      String result = "Released";
            complaint = complaintDAO.getComplaint(claimDao.lookUpComplaintIdForClaim(claimId).get(0));
            String status = claimDao.getStatusForClaim(claimId, user.getLocale());
            stringBuffer.append("<RESULT>");
            stringBuffer.append(uniqueClaimSet.get(claimId));
            stringBuffer.append("</RESULT>");
            stringBuffer.append("<CLAIM_ID>");
            stringBuffer.append(claimId);
            stringBuffer.append("</CLAIM_ID>");
            stringBuffer.append("<status_description>");
            stringBuffer.append(status);
            stringBuffer.append("</status_description>");
            stringBuffer.append("<status_id>");
            stringBuffer.append(complaint.getStatus_id());
            stringBuffer.append("</status_id>");
            stringBuffer.append("<qualityIssueId>");
            stringBuffer.append(complaint.getQuality_issue());
            stringBuffer.append("</qualityIssueId>");
            result = "";
        }
        stringBuffer.append("</RESULTS>");
        document = DOMUtil.newDocumentFromXML(stringBuffer.toString());
        return document;
    }

    private boolean isClaimCisClaim(String regionId, String claimId) {
        if (regionId != null && regionId.length() > 0 && !regionId.equalsIgnoreCase("1")) {
            return false;
        }
        return !("Foundation".equalsIgnoreCase(claimId) || claimId.contains("CA") || claimId.contains("CRF") || claimId.contains("crf"));
    }

    public boolean canReleaseClaim(User user, boolean environmentalClaim) {
        if (environmentalClaim) {
            return true;
        } else return !user.isAffinaUser();

    }
}
