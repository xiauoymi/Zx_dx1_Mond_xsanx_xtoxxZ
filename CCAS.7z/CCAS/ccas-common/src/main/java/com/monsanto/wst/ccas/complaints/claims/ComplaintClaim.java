package com.monsanto.wst.ccas.complaints.claims;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Sep 10, 2009
 * Time: 8:17:54 PM
 * To change this template use File | Settings | File Templates.
 */
class ComplaintClaim {
    private final String complaint_id;
    private final String claimYear;
    private final String claimId;
    private final String batchNumber;
    private final String description;
    private final String statusDescription;
    private final String entryDate;
    private final String claim_category_description;

    public ComplaintClaim(String complaint_id, String claimYear, String claimId,
                          String batchNumber, String description, String statusDescription, String entryDate, String claim_category_description) {
        //To change body of created methods use File | Settings | File Templates.
        this.complaint_id = complaint_id;
        this.claimYear = claimYear;
        this.claimId = claimId;
        this.batchNumber = batchNumber;
        this.description = description;
        this.statusDescription = statusDescription;
        this.entryDate = entryDate;
        this.claim_category_description = claim_category_description;
    }


    public String getComplaint_id() {
        return complaint_id;
    }

    public String getClaimYear() {
        return claimYear;
    }


    public String getClaimId() {
        return claimId;
    }

    public String getBatchNumber() {
        if (batchNumber == null) {
            return "";
        }
        return batchNumber;
    }

    public String getDescription() {
        if (description == null) {
            return "";
        }
        return description;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public String getClaim_category_description() {
        if (claim_category_description == null) {
            return "";
        }
        return claim_category_description;
    }
}
