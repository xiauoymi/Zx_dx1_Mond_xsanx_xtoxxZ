package com.monsanto.wst.ccas.constants;

/**
 * Date: Aug 25, 2009 Time: 10:39:14 AM
 */

public class AuditConstants {
    public static final String MAJOR = "major";
    public static final String OBSERVATION = "observation";
    public static final String AUDIT_CI = "audit_ci";
    public static final String CAN_VIEW_CONTROLS = "canViewControls";
    public static final String FINDING_ADD = "add";
    public static final String FINDING_EDIT = "edit";
    public static final String AUDIT_TYPE_MAP = "auditTypeMap";

    public static final String AUDIT_ENTRY_REGION = "auditObj.region_id";
    public static final String AUDIT_CREATE_CAR = "auditCreateCar";
    public static final String AUDIT_OBJ_AUDIT_AREA_LIST = "auditObj.functionalAreaList";
    public static final String C_AUDIT_AREA_LIST = "c.functionalAreaList";
    public static final String ERROR_FINDING_DESC_EMPTY = "findingDescEmpty";
    public static final String AUDIT_OBJ_LOCATION_CODE = "auditObj.locationCode";
    public static final String AUDIT_FILTER_OBJ_REGION = "auditFilterObj.region";
    public static final String AUDIT_EDIT = "auditEdit";
    public static final String AUDIT_SAVE_OR_UPDATE = "auditSaveOrUpdate";
    public static final String AUDIT_ADD_FINDING_CANCEL = "auditAddFindingCancel";
    public static final String AUDIT_NEW = "auditNew";
    public static final String AUDIT_VIEW_EDIT = "auditViewEdit";
    public static final String AUDIT_FINDING_SAVE = "auditFindingSave";
    public static final String ADD_NEW_AUDIT_FINDING = "addNewAuditFinding";
}
