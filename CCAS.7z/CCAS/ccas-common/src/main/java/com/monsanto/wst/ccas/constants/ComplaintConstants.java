package com.monsanto.wst.ccas.constants;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: May 19, 2010
 * Time: 11:18:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComplaintConstants {
    public static final String COMPLAINT_FORM_ENTRY_REGION = "c.region_id";
    public static final String COMPLAINT_FORM_POPULATE_REGION = "regionId";
    public static final String COMPLAINT_ENTRY_DEV = "DEV";
}
