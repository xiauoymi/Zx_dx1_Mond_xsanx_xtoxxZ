package com.monsanto.wst.ccas.constants;

/**
 * Date: Aug 21, 2009 Time: 9:25:38 AM
 */
public class CparConstants {

    public static final String CAR_CONTROL_NUMBER_PREFIX = "C-";
    public static final String CI_CONTROL_NUMBER_PREFIX = "CI-";
    public static final String PAR_CONTROL_NUMBER_PREFIX = "P-";
    public static final String NC_CONTROL_NUMBER_PREFIX = "NC-";
    public static final String CPAR_TYPE = "type";
    public static final String IS_CAR_FLAG = "iscar";
    public static final String DEFAULT_CPAR_CONTINUAL_IMPROVEMENTS = "1";
    public static final String CREATE_PAR = "createPAR";
    public static final String CREATE_CAR = "createCAR";
    public static final String CPAR_CHANGE_TO = "changeTo";
    public static final String CPAR_COMPLAINT_GENERATOR = "6";
    public static final String CPAR_INTERNAL_AUDIT_GENERATOR = "7";
    public static final int GEN_FINDING_OBJ_TYPE_PAR = 2;
    public static final int GEN_FINDING_OBJ_TYPE_NC = 3;
    public static final int GEN_FINDING_OBJ_TYPE_CI = 4;
    public static final int GEN_FINDING_OBJ_TYPE_CAR = 1;
    public static final String CPAR_CREATE_PAR = "Create Par";
    public static final String CPAR_CREATE_CAR = "Create Car";
    public static final String CPAR_CREATE_NC = "Create NC";
    public static final String CPAR_CREATE_CI = "Create CI";
    public static final String LAST_CPAR_SORT_ORDER = "lastCparSortOrder";
    public static final String LAST_CPAR_SORT_CRITERIA = "lastCparSortCriteria";
    public static final String CPAR_STATUS_APPROVED_EFFECTIVE = "7";
    public static final String CPAR_STATUS_AWAITING_EVALUATION = "6";
    public static final String CPAR_STATUS_APPROVED_NOT_EFFECTIVE = "18";
    public static final String SOURCE_TYPE_CPAR = "P";

    public static final String CPAR_ENTRY_REGION = "cpar.region";
    public static final String CPAR_ENTRY_REGION_RESPONSIBLE = "cpar.responsibleRegionId";
    public static final String CPAR_ID = "cparId";
    public static final String GENERATOR = "Generator";
    public static final String AUDIT = "Audit";
    public static final String FORWARD_SUCCESS_CPAR = "successCPAR";
    public static final String FORWARD_SUCCESS_CAR = "successCAR";
    public static final String FORWARD_SUCCESS_PAR = "successPAR";
    public static final String FORWARD_SUCCESS_CI = "successCI";
    public static final String CPAR_FINDING_OBJ = "cparFindingObj";
    public static final String FROM_CPAR = "fromCPAR";
}
