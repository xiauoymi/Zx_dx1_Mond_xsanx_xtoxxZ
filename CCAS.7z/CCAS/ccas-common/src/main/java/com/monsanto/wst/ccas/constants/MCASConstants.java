package com.monsanto.wst.ccas.constants;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 6, 2006 Time: 3:33:45 PM To change this template use File |
 * Settings | File Templates.
 */
public class MCASConstants {

    //**VarietyBatch Data Import Constants
    public static final String VM_PARAM_NAME_VARIETY_BATCH_IMPORT = "sapftp";
    public static final String FORWARD_VARIETY_BATCH_IMPORT_SUCCESS_PAGE = "/pages/varietyBatch/ImportSuccessPage.jsp";
    public static final String FORWARD_VARIETY_BATCH_IMPORT_FAILURE_PAGE = "/pages/varietyBatch/ImportFailurePage.jsp";

    public static final String PROJECT_SPECIFIC_FOLDER_MAPPING_NAME = "MCAS"; //for DocPOS_V2

    public static final int MAX_IMPORT_FILE_SIZE_IN_BYTES = 300 * 1024 * 1024;    //300mb...same as DocPOS_v2

    //Forwards...
    public static final String FORWARD_USER_ADMIN_PAGE = "/pages/admin/userAdmin.jsp";
    public static final String FORWARD_ADD_EDIT_USER_PAGE = "/pages/admin/addEditUser.jsp";
    public static final String FORWARD_ADD_ATTACHMENT_PAGE = "/pages/attachment/addAttachment.jsp";
    public static final String FORWARD_ERROR_PAGE = "/pages/error.jsp";
    public static final String FORWARD_LOCATION_ADMIN_PAGE = "/pages/location/locationAdmin.jsp";
    public static final String FORWARD_ADD_EDIT_LOCATION_PAGE = "/pages/location/addEditLocation.jsp";
    public static final String FORWARD_VARIETY_BATCH_POPUP_PAGE = "/pages/varietyBatch/varietyBatchPopup.jsp";

    public static final String FORWARD_VARIETY_BATCH_ADMIN_PAGE = "/pages/varietyBatch/VarietyBatchAdmin.jsp";
    public static final String FORWARD_VARIETY_BATCH_ADD_EDIT_PAGE = "/pages/varietyBatch/AddEditVarietyBatch.jsp";

    public static final String FORWARD_MAPPING_ADD_ATTACHMENT_PG = "successForwardToAddAttachmentPage";

    //Session Variable Names...
    public static final String SESSION_VAR_USER = "user";

    //Request Variable Names...
    public static final String REQUEST_VAR_ENTITY_ID = "entityId";
    public static final String REQUEST_VAR_FWD_ADD_ATTACHMENT_PAGE = "forwardToAddAttachmentPage";

    //Sort indexes...
    public static final String INDEX_USER_ADMIN_PG_USER_ID = "userAdminPage.userId";
    public static final String INDEX_USER_ADMIN_PG_USER_NAME = "userAdminPage.userName";
    public static final String INDEX_USER_ADMIN_PG_ROLE_DESC = "userAdminPage.roleDesc";
    public static final String INDEX_USER_ADMIN_PG_REGION_DESC = "userAdminPage.regionDesc";

    public static final String INDEX_LOCATION_ADMIN_PG_LOCATION_ID = "locationAdminPage.locationId";
    public static final String INDEX_LOCATION_ADMIN_PG_LOCATION_NAME = "locationAdminPage.locationName";
    public static final String INDEX_LOCATION_ADMIN_PG_REGION = "locationAdminPage.regionDesc";
    public static final String INDEX_LOCATION_ADMIN_PG_STATUS = "locationAdminPage.statusActive";

    public static final String INDEX_VARIETY_BATCH_ADMIN_PG_VARIETY_DESC = "varietyBatchAdminPage.varietyDesc";
    public static final String INDEX_VARIETY_BATCH_ADMIN_PG_BATCH_NUMBER = "varietyBatchAdminPage.batchNumber";

    public static final String STRATEGY_MAP_KEY_COMPLAINT_ENTITY = "complaintEntity";
    public static final String STRATEGY_MAP_KEY_AUDIT_ENTITY = "auditEntity";
    public static final String STRATEGY_MAP_KEY_STOPSALE_ENTITY = "stopSaleEntity";
    public static final String STRATEGY_MAP_KEY_CPAR_ENTITY = "cparEntity";

    public static final String ROLE_SYSTEM_ADMIN = "SYSTEM_ADMIN";      //As per values in database
    public static final String ROLE_REGIONAL_ADMIN = "REGIONAL_ADMIN";
    public static final String ROLE_USER = "USER";

    public static final int ROLE_ID_SYSTEM_ADMIN = 1;              //As per values in database
    public static final int ROLE_ID_REGIONAL_ADMIN = 2;
    public static final int ROLE_ID_USER = 3;
    public static final int ROLE_ID_AFFINA_USER = 4;
    public static final int ROLE_ID_USER_WITH_AFFINA_ACCESS = 5;


    public static final String CHECKBOX_ON = "on";

    public static final String REGEX_SIMPLE_EMAIL_VALIDATION = ".+\\@.+\\..+";    //This checks for oneOrMoreChar@oneOrMoreChar.oneOrMoreChar

    //Helper Variable Names...
    public static final String HELPER_VAR_REGION_LIST = "regionList";
    public static final String HELPER_VAR_ALL_REGION_LIST = "allRegionList";
    public static final String HELPER_VAR_ROLE_LIST = "roleList";
    public static final String HELPER_VAR_USER_MAP = "userMap";
    public static final String HELPER_VAR_USER_ID = "userId";
    public static final String HELPER_VAR_USER_NAME = "userName";
    public static final String HELPER_VAR_ERROR_MESSAGES = "errorMessages";
    public static final String HELPER_VAR_SELECTED_ROLE = "selectedRole";
    public static final String HELPER_VAR_SELECTED_REGION = "selectedRegion";
    public static final String HELPER_VAR_SELECTED_REGION_LIST = "selectedRegionList";

    public static final String HELPER_VAR_SORT_INDEX = "index";
    public static final String HELPER_VAR_PREV_SORT_INDEX = "prevSortIndex";
    public static final String HELPER_VAR_PREV_SORT_ORDER = "prevSortOrder";
    public static final String HELPER_VAR_EDIT_ACTION = "editAction";
    public static final String HELPER_VAR_EDIT_LOCATION_ACTION = "editLocationAction";
    public static final String HELPER_VAR_SELECTED_USER_ID = "selectedUserId";
    public static final String HELPER_VAR_SELECTED_LOCATION_ID = "selectedLocationId";
    public static final String HELPER_VAR_LOCAL_FILE_PATH = "localFilePath";
    public static final String HELPER_VAR_ALLOWED_ATTACHMENT_TYPES = "allowedAttachmentTypes";
    public static final String HELPER_VAR_ENTITY_ID = "entityId";
    public static final String HELPER_VAR_ENTITY_TYPE = "entityType";
    public static final String HELPER_VAR_ENTITY_NUMBER = "entityNumber";
    public static final String HELPER_VAR_DOC_ID = "docId";
    public static final String HELPER_VAR_DOC_NAME = "docName";
    public static final String HELPER_VAR_CAR_FLAG = "carFlag";
    public static final String HELPER_VAR_IS_AFFINA_COMPLAINT = "isAffinaComplaint";
    public static final String HELPER_VAR_LOCATION_MAP = "locationMap";
    public static final String HELPER_VAR_LOCATION_INFO = "locationInfo";
    public static final String HELPER_VAR_LOCATION_ID = "locationId";
    public static final String HELPER_VAR_LOCATION_NAME = "locationName";
    public static final String HELPER_VAR_LOCATION_STATUS = "statusActive";
    public static final String HELPER_VAR_LOCATION_LONG_NAME = "locationLongName";
    public static final String HELPER_VAR_LOCATION_EMAIL = "locationEmail";
    public static final String HELPER_VAR_LOCATION_OWNER_EMAIL2 = "locationOwnerEmail2";
    public static final String HELPER_VAR_LOCATION_OWNER_EMAIL3 = "locationOwnerEmail3";
    public static final String HELPER_VAR_LOCATION_OWNER_EMAIL4 = "locationOwnerEmail4";
    public static final String HELPER_VAR_LOCATION_OWNER_EMAIL = "locationOwnerEmail";
    public static final String HELPER_VAR_LOCATION_OWNER_EMAIL_STATUS = "ownerEmailStatusActive";
    public static final String HELPER_VAR_LOCATION_LIST = "locationList";
    public static final String HELPER_VAR_REGION_RELATED_LOCATION_LIST = "regionSpecificLocationList";
        public static final String HELPER_VAR_REGION_RELATED_LOCATION_LIST_SEARCH = "regionSpecificLocationListSearch";

    public static final String HELPER_VAR_USER_IN_REPORTING_LOC = "userInReportingLocationRegion";
    public static final String HELPER_VAR_USER_IN_RESPONSIBLE_LOC = "userInResponsibleLocationRegion";
    public static final String HELPER_VAR_USER_IN_SHIPPING_LOC = "userInShippingLocationRegion";
    public static final String HELPER_VAR_USER_IN_FILING_LOC = "userInFilingLocationRegion";
    public static final String HELPER_VAR_USER_IN_AUDIT_LOC = "userInAuditLocationRegion";

    public static final String HELPER_VAR_VIEWABLE_REPORTING_LOCATION = "viewableReportingLocation";
    public static final String HELPER_VAR_VIEWABLE_RESPONSIBLE_LOCATION = "viewableResponsibleLocation";
    public static final String HELPER_VAR_VIEWABLE_SHIPPING_LOCATION = "viewableShippingLocation";
    public static final String HELPER_VAR_VIEWABLE_FILING_LOCATION = "viewableFilingLocation";
    public static final String HELPER_VAR_VIEWABLE_AUDIT_LOCATION = "viewableAuditLocation";

    public static final String HELPER_VAR_USER_IN_COMPLAINT_REGION = "userInComplaintRegion";
    public static final String HELPER_VAR_USER_IN_AUDIT_REGION = "userInAuditRegion";
    public static final String HELPER_VAR_USER_IN_STOP_SALE_REGION = "userInStopSaleRegion";
    public static final String HELPER_VAR_USER_IN_CPAR_REGION = "userInCparRegion";

    public static final String HELPER_VAR_VIEWABLE_COMPLAINT_REGION = "viewableComplaintRegion";
    public static final String HELPER_VAR_VIEWABLE_AUDIT_REGION = "viewableAuditRegion";
    public static final String HELPER_VAR_VIEWABLE_STOP_SALE_REGION = "viewableStopSaleRegion";
    public static final String HELPER_VAR_VIEWABLE_CPAR_REGION = "viewableCparRegion";
    public static final String HELPER_VAR_VARIETY_BATCH_MAP = "varietyBatchMap";
    public static final String HELPER_VAR_VARIETY_PATTERN = "varietyPattern";
    public static final String HELPER_VAR_BATCH_PATTERN = "batchPattern";
    public static final String HELPER_VAR_CLAIM_NUMBER = "claim_number";
    public static final String HELPER_VAR_BATCH_CROP_NAME = "cropName";
    public static final String HELPER_VAR_VARIETY_BATCH_SELECTION = "varityBatchSelection";
    public static final String HELPER_VAR_SELECTED_VARIETY_DESC_FROM_POPUP = "selectedVarietyDescFromPopup";
    public static final String HELPER_VAR_SELECTED_VARIETY_ID_FROM_POPUP = "selectedVarietyIdFromPopup";
    public static final String HELPER_VAR_SELECTED_BATCH_NUMBER_FROM_POPUP = "selectedBatchNumberFromPopup";
    public static final String HELPER_VAR_VARIETY_DESC_TEXT_BOX_ID = "varietyDescTextId";
    public static final String HELPER_VAR_VARIETY_ID_TEXT_BOX_ID = "varietyIdTextId";
    public static final String HELPER_VAR_BATCH_NUMBER_TEXT_BOX_ID = "batchNumberTextId";
    public static final String HELPER_VAR_SELECTED_VARIETY_BATCH_ID = "selectedVarietyBatchId";
    public static final String HELPER_VAR_EDIT_VARIETY_BATCH_ACTION = "editVarietyBatchAction";
    public static final String HELPER_VAR_VARIETY_BATCH = "varietyBatch";
    public static final String HELPER_VAR_VARIETY_DESC = "varietyDesc";
    public static final String HELPER_VAR_BATCH_NUMBER = "batchNumber";
    public static final String HELPER_VAR_SUCCESS_MESSAGES = "successMessages";
    public static final String HELPER_VAR_IS_RESPONSIBLE_LOCATION = "isResponsibleLocation";
    public static final String HELPER_VAR_IS_FILING_LOCATION = "isFilingLocation";
    public static final String HELPER_VAR_IS_REPORTING_LOCATION = "isReportingLocation";
    public static final String HELPER_VAR_IS_SHIPPING_LOCATION = "isShippingLocation";
    public static final String HELPER_VAR_IS_CUSTOMER_LOCATION = "isCustomerLocation";

    public static final String STATUS_ACTIVE = "Y";
    public static final String STATUS_INACTIVE = "N";
    public static final String MOD_USER_FOR_AUTOMATED_PROCESSES = "APPLICATION";

    //Constant for Business Type
    public static final String BUSINESS_TYPE = "businessType";
    public static final String HELPER_VAR_SELECTED_BUSINESS = "selectedBusiness";
    public static final String HELPER_VAR_SELECTED_BUSINESS_PREFERENCE_ID = "preferenceId";
    public static final String BUSINESS_ID = "businessId";
    //Place holder for user company preference
    public static final String USER_COMPANY_PREFERENCE = "preference";
    public static final int BUSINESS_ID_ROW_CROP = 1;
    public static final int BUSINESS_ID_VEGETABLE = 2;
    public static final int BUSINESS_PREF_ROW_CROP = 1;
    public static final int BUSINESS_PREF_VEGETABLE = 2;


    //Constants for Drop Down Fields.
    //This must be same as that of APPLICATION_FIELD_ID in APPLICATION_INFO table
    public static final String COMPLAINT_STATE_DROPDOWN = "31";
    public static final String COMPLAINT_SALES_OFFICE_DROPDOWN = "32";
    public static final String COMPLAINT_MATERIAL_GROUP_DROPDOWN = "33";
    public static final String COMPLAINT_MATERIAL_GROUP_PRICING_DROPDOWN = "34";
    public static final String STOPSALE_STATE_DROPDOWN = "38";
    public static final String STOPSALE_MATERIAL_GROUP_DROPDOWN = "36";
    public static final String STOPSALE_MATERIAL_GROUP_PRICING_DROPDOWN = "37";
    //Error message for Invlaid entry for variety/batch
    public static final int STATUS_TYPE_COMPLAINT = 1;
    public static final int STATUS_TYPE_STOP_SALE = 3;
    public static final int ROLE_ID_READ_ONLY_USER = 6;
    public static final int DESCRIPTION_PREVIEW_LENGTH = 400;
    public static final String DEFAULT_REGION_ID = "1";
    public static final String APPLICATION_NAME_BTFAS = "btfas";


    public static final String LATIN1_ENCODING = "ISO-8859-1";
    public static final String HELPER_VAR_SELECTED_BUSINESS_LIST = "selectedBusinessList";
    public static final String APPLICATION_NAME_MCAS = "mcas";

    public static final int LOCATION_TYPE_RESPONSIBLE = 1;
    public static final int LOCATION_TYPE_FILING = 2;
    public static final int LOCATION_TYPE_REPORTING = 3;
    public static final int LOCATION_TYPE_SHIPPING = 4;
    public static final int LOCATION_TYPE_CUSTOMER = 5;
    public static final String CCAS_DEFAULT_REGION_STATE = "1";
    public static final String SUCCESS_MESSAGE = "success";
    public static final String SUCCESS_AFFINA_MESSAGE = "successAffina";
    public static final String APPLICATION_NAME_SBFAS = "sbfas";
    public static final String APPLICATION_NAME_BIOTECHFAS = "biotechfas";

    public static final int COMPLAINT_STATUS_TYPE = 1;
    public static final int CPAR_STATUS_TYPE = 2;
    public static final int STOP_SALE_STATUS_TYPE = 3;
    public static final int AUDIT_STATUS_TYPE = 4;

    public static final int COMPLAINT_ENTRY_TYPE_ID_COMPLAINT = 1;
    public static final String ENTRY_TYPE_DEFAULT = "C";
    public static final String ENTRY_TYPE_FEEDBACK = "F";
    public static final String COMPLAINT_NCR = "NCR";
    public static final String COMPLAINT_DEV = "DEV";
    public static final int COMPLAINT_DEV_TYPE = 3;
    public static final int COMPLAINT_NCR_TYPE = 2;
    public static final String COMPLAINT_ENTRY_TYPE_LIST = "complaintEntryTypeList";
    public static final String SUBFUNCTION_LIST = "subFunctionList";
    public static final String COMPLAINT_ENTRY_TYPE_ID = "complaintEntryTypeId";
    public static final String SESSION_ATTRIBUTE_USER = "user";
    public static final String IS_AFFINA_USER = "IS_AFFINA_USER";
    public static final String REQUEST_PARAM_CLAIM_ID = "claim_id";

    public static final String DEFAULT_STATE_ID = "999";
    public static final String COMPLAINT_STATUS_APPROVED = "13";
    public static final String COMPLAINT_STATUS_CLOSED = "1";
    public static final String DISPOSITION_LIST = "dispositionList";
    public static final String DISPOSITION_LIST_TEAMLEAD = "dispositionListForTeamLead";
    public static final String ENTRY_TYPE = "entryType";
    public static final String TAB_NAME = "tabName";
    public static final String COMMUNICATION_DATE = "date";
    public static final String YEAR_FORMAT = "MM/dd/yyyy";
    public static final String CPAR_FILING_PROGRAM = "cpar.filingProgramId";
    public static final String CPAR_RESPONSIBLE_PROGRAM = "cpar.responsibleProgramId";
    public static final String ADMIN_EMAIL = "ADMN";
    public static final String FEEDBACK_CATEGORY = "feedbackCategory";
    public static final String PRINT_PREVIEW_SOURCE = "printPreviewSrc";
    public static final String SOURCE_TYPE_STOP_SALE = "S";

    public static final String XMLTAG_RESPONSIBLE_LOCATIONS = "ResponsibleLocations";
    public static final String XMLTAG_FILING_LOCATIONS = "FilingLocations";
    public static final String XMLTAG_REPORTING_LOCATIONS = "ReportingLocations";
    public static final String XMLTAG_SHIPPING_LOCATIONS = "ShippingLocations";
    public static final String XMLTAG_CUSTOMER_LOCATIONS = "CustomerLocations";
    public static final String XMLTAG_STATE = "state";
    public static final String XMLTAG_SALES_OFFICE = "salesOffice";
    public static final String XMLTAG_LOCATION = "Location";
    public static final String XMLTAG_STATES = "states";
    public static final String XMLTAG_SALES_OFFICES = "salesOffices";
    public static final String XMLTAG_SALES_OFFICES_INFO = "salesOfficesInfo";
    public static final String XMLTAG_REGION_ID = "regionId";

    public static final String LANGUAGE_ENGLISH = "en";
    public static final String LANGUAGE_DEFAULT = LANGUAGE_ENGLISH;
    public static final String LANGUAGE_TEST = "zz";
    public static final String SESSION_ATTRIBUTE_SELECTED_REGION = "selectedRegion";
    public static final String SESSION_ATTRIBUTE_SELECTED_REGION_RESPONSIBLE = "selectedRegResponsible";
    public static final String APPLICATION_NAME = "APPLICATION_NAME";
    public static final String FALIURE = "faliure";
    public static final String SUCCESS = "success";
    public static final String TRUE = "true";
    public static final String PROGRAM_ID = "programId";
    public static final String FALSE = "false";
    public static final String FROM_ATTACH_FILE = "fromAttachFile";
    public static final String READ_ONLY = "READ_ONLY";
    public static final String CA_READ_ONLY = "CA_READ_ONLY";
    public static final String RC_READ_ONLY = "RC_READ_ONLY";
    public static final String LT_READ_ONLY = "LT_READ_ONLY";
    public static final String EE_READ_ONLY = "EE_READ_ONLY";
    public static final String DUE_DATE_INVESTIGATION_FINDINGS = "ddInvestigationFindings";
    public static final String DUE_DATE_CONTAINMENT_ACTION = "ddContainmentAction";
    public static final String DUE_DATE_ROOT_CAUSE = "ddRootCause";
    public static final String DUE_DATE_CORRECTIVE_ACTION = "ddCorrectiveAction";
    public static final String DUE_DATE_EVALUATION_EFFECTIVENESS = "ddEvaluationEffectiveness";

    public static final String SBFAS_STATUS__REF_TYPE_2_CLOSED_EFFECTIVE = "5";
    public static final String SBFAS_STATUS__REF_TYPE_2_CLOSED_NOT_EFFECTIVE = "19";
    public static final String SBFAS_STATUS__REF_TYPE_1_CLOSED_EFFECTIVE = "1";
    public static final String SBFAS_STATUS__REF_TYPE_1_CLOSED_NOT_EFFECTIVE = "17";

    public static final String MCAS_STATUS_REF_TYPE_CLOSED = "5";
    public static final String MCAS_PROPERTIES = "com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4";
    public static final String MCAS_LSI_FUNCTION = "lsi.function";
    public static final String MCAS_BO_REPORT_URL = ".BOReportURL";

    public static final String ORGANIZATION_LIST = "organizationList";
    public static final String DEPARTMENT_AFFECTED_LIST = "departmentAffectedList";

    public static final String IMPORT_FROM_EXCEL = "IMPORT";
    public static final String CREATE_FROM_EXCEL = "CREATE";

    public static final String COMPLAINT_STATUS_NEW = "3";

    public static final int SBFAS_CI_TYPE = 4;
    public static final int SBFAS_PAR_TYPE = 2;
    public static final int SBFAS_MIN_TEXT_AREA_LENGTH=100;
    public static final int SBFAS_MAX_TEXT_AREA_LENGTH=4000;
    public static final int SBFAS_DEFAULT_TEXT_AREA_LENGTH=-1;

    public static final int MCAS_CI_TYPE = 4;

    public static int MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED=0;
}
