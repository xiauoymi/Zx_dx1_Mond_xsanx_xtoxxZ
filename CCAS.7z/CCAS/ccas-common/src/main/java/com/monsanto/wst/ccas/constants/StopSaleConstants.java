package com.monsanto.wst.ccas.constants;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: May 21, 2010
 * Time: 9:14:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class StopSaleConstants {
    public static final String STOP_SALE_ENTRY_REGION = "stopSale.region";
}
