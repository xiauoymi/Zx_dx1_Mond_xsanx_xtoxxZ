/*
 ProgramListController was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.ProgramConstants;
import com.monsanto.wst.ccas.model.Program;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ProgramService;
import com.monsanto.wst.ccas.service.ProgramServiceImpl;
import com.monsanto.wst.ccas.service.SubFunctionService;
import com.monsanto.wst.ccas.service.SubFunctionServiceImpl;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ProgramListController extends AbstractDispatchController {
    protected void notSpecified(UCCHelper helper) throws IOException {

        User user = (User) helper.getSessionParameter(User.USER);

        String programId = helper.getRequestParameterValue(ProgramConstants.PROGRAM_ID);
        String b_user = (String)helper.getSessionParameter(MCASConstants.APPLICATION_NAME);

        b_user = searchApplicationByName(b_user);

        Program program = programService.lookupProgramByCriteria(programId);
        Map<String, String> subFunctionMap = subFunctionService.lookupAllSubFunctionsForAProgram(programId, user.getLocale());
        Map<String, String> locationMap = programService.lookupLocationsForAProgram(programId);
        Map<String, String> categoryMap = programService.lookupCategoryForAProgram(programId, user.getLocale());

        subFunctionMap = MCASUtil.sortByValue(subFunctionMap);
        locationMap = MCASUtil.sortByValue(locationMap);
        categoryMap = MCASUtil.sortByValue(categoryMap);

        Document responseDocument = createResponseDocument(program, subFunctionMap, locationMap, categoryMap);
        helper.setContentType("text/xml");
        helper.writeXMLDocument(responseDocument, MCASConstants.LATIN1_ENCODING);
    }

    public void getLocationsRelatedToPrograms(UCCHelper helper) throws IOException {
        String programId = helper.getRequestParameterValue(ProgramConstants.PROGRAM_ID);
        Program program = programService.lookupProgramByCriteria(programId);
        Map<String, String> locationMap = programService.lookupLocationsForAProgram(programId);

        locationMap = MCASUtil.sortByValue(locationMap);

        Document responseDocument = createResponseDocumentForLocation(program, locationMap);
        helper.setContentType("text/xml");
        helper.writeXMLDocument(responseDocument, MCASConstants.LATIN1_ENCODING);
    }

    private final ProgramService programService;
    private final SubFunctionService subFunctionService;

    public ProgramListController() {
        this(new ProgramServiceImpl(), new SubFunctionServiceImpl());
    }

    public ProgramListController(ProgramService programService, SubFunctionService subFunctionService) {
        this.programService = programService;
        this.subFunctionService = subFunctionService;
    }

    private Document createResponseDocumentForLocation(Program program, Map<String, String> locationMap) {
        Document document = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(document, "programs");
        Element programElement = DOMUtil.addChildElement(root, "program");
        programElement.setAttribute("id", program.getId().toString());
        Element locations = DOMUtil.addChildElement(programElement, "locations");

        locationMap = MCASUtil.sortByValue(locationMap);

        createXML(locationMap, locations, "location");
        return document;
    }


//  public void run(UCCHelper helper) throws IOException {
//    String programId = helper.getRequestParameterValue(ProgramConstants.PROGRAM_ID);
//    Program program = programService.lookupProgramByCriteria(programId);
//    Map<String, String> subFunctionMap = subFunctionService.lookupAllSubFunctionsForAProgram(programId);
//    Map<String, String> locationMap = programService.lookupLocationsForAProgram(programId);
//    Map<String, String> categoryMap = programService.lookupCategoryForAProgram(programId);
//    Document responseDocument = createResponseDocument(program, subFunctionMap, locationMap, categoryMap);
//    helper.setContentType("text/xml");
//    helper.writeXMLDocument(responseDocument, MCASConstants.LATIN1_ENCODING);
//  }

    private Document createResponseDocument(Program program, Map<String, String> subFunctionMap,
                                            Map<String, String> locationMap, Map<String, String> categoryMap) {
        Document document = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(document, "programs");
        Element programElement = DOMUtil.addChildElement(root, "program");
        programElement.setAttribute("id", program.getId().toString());
        Element subFunctions = DOMUtil.addChildElement(programElement, "subFunctions");
        //subFunctionMap = MCASUtil.sortByValue(subFunctionMap);
        createXML(subFunctionMap, subFunctions, "subFunction");
        Element locations = DOMUtil.addChildElement(programElement, "locations");
        //locationMap = MCASUtil.sortByValue(locationMap);
        createXML(locationMap, locations, "location");
        Element categories = DOMUtil.addChildElement(programElement, "categories");
        //categoryMap = MCASUtil.sortByValue(categoryMap);
        createXML(categoryMap, categories, "category");
        return document;
    }

    private void createXML(Map<String, String> map, Element rootElement, String tag) {
        for (String key : map.keySet()) {
            Element eachElement = DOMUtil.addChildElement(rootElement, tag);
            DOMUtil.addChildElement(eachElement, "id", key);
            DOMUtil.addChildElement(eachElement, "description", map.get(key));
        }
    }


    private String searchApplicationByName(String b_user)   {
        
        if (b_user != null && !b_user.equals("") ){
            if (b_user.equals("biotechfas") )
                return "BIOTECCAS";
            if (b_user.equals("sbfas") )
                return "SBFASCAS";
            if (b_user.equals("mcas") )
                return "MFG_USER";
            if (b_user.equals("btfas") )
                return "BTFAS_USER";
        }
        return "BIOTECCAS";
    }
}
