package com.monsanto.wst.ccas.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.CheckboxItemService;
import com.monsanto.wst.ccas.service.CheckboxItemServiceImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: AOROZ
 * Date: 11/12/13
 * Time: 9:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class RootCauseController implements UseCaseController {



    public void run(UCCHelper helper) throws IOException {
        CheckboxItemService rootCauseService=new CheckboxItemServiceImpl(new RootCauseDaoImpl());
        User user = (User) helper.getSessionParameter(User.USER);
        List<CheckboxItem> result=rootCauseService.getRootCauseBasedOnParentRootCause(Integer.parseInt(helper.getRequestParameterValue("ROOT_CAUSE_ID")), user.getLocale());
        Document claimDocument = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(claimDocument, "rootCausesList");
        for (CheckboxItem item : result) {
            Element eachElement = DOMUtil.addChildElement(root, "rootCause");
            DOMUtil.addChildElement(eachElement, "id", item.getCheckboxItemId());
            DOMUtil.addChildElement(eachElement, "description", item.getCheckboxItemDisplay());
        }
        helper.setContentType("text/xml");
//    DOMUtil.outputXML(xml);
        helper.writeXMLDocument(claimDocument, MCASConstants.LATIN1_ENCODING);

    }


}
