/*
 SearchUserController was created on Nov 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.controller;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.MCASPeopleService;
import com.monsanto.wst.ccas.service.MCASPeopleServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.naming.ServiceUnavailableException;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SearchUserController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class SearchUserController implements UseCaseController {
    private final MCASPeopleService service;

    public SearchUserController() {
        this(new MCASPeopleServiceImpl(new PeopleService()));
//    this.service = new MCASPeopleServiceImpl(new PeopleService());
    }

    public SearchUserController(MCASPeopleService service) {
        this.service = service;
    }

    public void run(UCCHelper helper) throws IOException {
        String userId = helper.getRequestParameterValue("userId");
        String firstName = helper.getRequestParameterValue("firstName");
        String lastName = helper.getRequestParameterValue("lastName");
        Document document = createInputDocumentFromRequestParameters(userId, firstName, lastName);
        try {
            Document outputDocument = this.service.getEmailAddressesForUsersMatchingCriteria(document);
            helper.setContentType("text/xml");
            helper.writeXMLDocument(outputDocument, MCASConstants.LATIN1_ENCODING);
        } catch (ServiceUnavailableException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    private Document createInputDocumentFromRequestParameters(String userId, String firstName, String lastName) {
        Document document = DOMUtil.newDocument();
        Element user = DOMUtil.addChildElement(document, "User");
        DOMUtil.addChildElement(user, "FirstName", firstName);
        DOMUtil.addChildElement(user, "LastName", lastName);
        DOMUtil.addChildElement(user, "UserId", userId);
        return document;
    }
}
