package com.monsanto.wst.ccas.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created with IntelliJ IDEA.
 * User: AOROZ
 * Date: 3/19/14
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class SessionValidationController implements UseCaseController {
    public void run(UCCHelper helper) throws IOException {



            helper.setContentType("text/html");

            PrintWriter out = helper.getPrintWriter();
            StringBuffer res = new StringBuffer();

            res.append(helper.getSessionParameter("APPLICATION_NAME"));

            out.print(res.toString());
            out.flush();
            out.close();



    }
}
