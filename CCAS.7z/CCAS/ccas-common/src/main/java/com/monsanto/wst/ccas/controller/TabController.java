/*
 TabController was created on Sep 3, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.IssueTypeService;
import com.monsanto.wst.ccas.service.IssueTypeServiceImpl;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.sql.CommonDataSource;
import javax.sql.DataSource;
import java.io.IOException;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
class TabController extends AbstractDispatchController {
    private final DataSource dataSource;
    private final IssueTypeService issueTypeService;


    public TabController(DataSource dataSource) {
      this.dataSource = dataSource;
      issueTypeService = new IssueTypeServiceImpl(dataSource);
    }

    public TabController(
        IssueTypeService issueTypeService, DataSource dataSource) {
        this.issueTypeService = issueTypeService;
        this.dataSource = dataSource;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {

        User user = (User) helper.getRequestAttributeValue(User.USER);

        String issueName = helper.getRequestParameterValue(MCASConstants.TAB_NAME);
        String type = helper.getRequestParameterValue("type");
        Map<String, String> referenceData = issueTypeService.lookupAllIssueTypesForAnIssue(issueName, type, user.getLocale());
        Document responseDocument = createResponseDocumentForLocation(referenceData);
        helper.setContentType("text/xml");
        helper.writeXMLDocument(responseDocument, MCASConstants.LATIN1_ENCODING);
    }

    private Document createResponseDocumentForLocation(Map<String, String> referenceData) {
        Document document = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(document, "issueTypes");
        for (String key : referenceData.keySet()) {
            Element issueType = DOMUtil.addChildElement(root, "issueType");
            DOMUtil.addChildElement(issueType, "id", key);
            DOMUtil.addChildElement(issueType, "description", referenceData.get(key));
        }
        return document;
    }
}
