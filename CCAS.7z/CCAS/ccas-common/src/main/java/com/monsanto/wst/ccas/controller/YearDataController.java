/*
 YearDataController was created on Sep 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.YearRefService;
import com.monsanto.wst.ccas.service.YearRefServiceImpl;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class YearDataController extends AbstractDispatchController {
    private YearRefService yearService = null;

    public YearDataController() {
        yearService = new YearRefServiceImpl();
    }

    public YearDataController(YearRefService yearService) {
        this.yearService = yearService;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
        String dateEntered = helper.getRequestParameterValue(MCASConstants.COMMUNICATION_DATE);
        Map<String, String> yearMap;
        SimpleDateFormat formatter = new SimpleDateFormat(MCASConstants.YEAR_FORMAT);

        try {
            if (dateEntered == null) {
                Date date = new Date();
                dateEntered = formatter.format(date);
            }
            yearMap = yearService.insertFiscalYearIfNotPresent(dateEntered);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        helper.setContentType("text/xml");
        helper.writeXMLDocument(createResponseDocumentForLocation(yearMap));
    }

    private Document createResponseDocumentForLocation(Map<String, String> referenceData) {
        Document document = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(document, "allYears");
        for (String key : referenceData.keySet()) {
            Element issueType = DOMUtil.addChildElement(root, "year");
            DOMUtil.addChildElement(issueType, "id", key);
            DOMUtil.addChildElement(issueType, "description", referenceData.get(key));
        }
        return document;
    }
}
