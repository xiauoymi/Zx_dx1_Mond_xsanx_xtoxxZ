package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.POSClient.InvalidMimeTypeException;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.actions.GlobalAbomination;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.service.EmailService;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.McasDocumentServiceClientUtil;
import com.monsanto.wst.ccas.validations.IMCASPageValidation;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;
import com.monsanto.wst.documentutil.documentposutil.DocumentServiceClientUtil;
import com.monsanto.wst.documentutil.documentposutil.exception.DocumentClientServiceException;
import com.monsanto.wst.documentutil.filetypeutil.AllowedAttachmentTypes;
import com.monsanto.wst.documentutil.filetypeutil.exception.FileTypeValidationException;
import org.ietf.jgss.GSSException;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 20, 2006 Time: 3:03:53 PM To change this template use File |
 * Settings | File Templates.
 */
public class AttachmentController implements UseCaseController {

    private final ActionHelper actionHelper;
    private List<String> errorMessages;
    private String entityId;
    private String entityNumber;
    private EntityStrategy entityStrategy;
    private final IMCASPageValidation imcasPageValidation;

    public AttachmentController() {
        actionHelper = new ActionHelper();
        errorMessages = new ArrayList<String>();
        imcasPageValidation = new MCASPageValidationUtil();
    }

    public AttachmentController(IMCASPageValidation imcasPageValidation) {
        actionHelper = new ActionHelper();
        this.imcasPageValidation = imcasPageValidation;
    }

    public void run(UCCHelper helper) throws IOException {
        try {
            resetMaxImportFileSize(helper);
            entityId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_ID);
            String entityType = (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_ENTITY_TYPE);
            entityNumber = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_NUMBER);
            //interface.method();
//      IMCASPageValidation imcasPageValidation = new MCASPageValidationUtil();
//      errorMessages = new MCASPageValidationUtil().validateAddAttachmentPage(helper);
            errorMessages = imcasPageValidation.validateAddAttachmentPage(helper);
            if (errorOnPage()) {
                performSubmitFailureActions(helper);
                return;
            }
            entityStrategy = getEntityStrategy(entityType);
            String documentId = insertDocumentIntoRepository(getFilePathOfUploadedFile(helper), helper);
            AttachmentInfo attachmentInfo = new AttachmentInfo(entityId, documentId,
                    DocumentServiceClientUtil.assignNameFromFileLocation(getFilePathOfUploadedFile(helper), true));
            entityStrategy.validateEntityNumber(entityNumber);
            entityStrategy.addInsertedDocumentInfoToDatabase(attachmentInfo);
            entityStrategy.forward(entityId, entityNumber, helper);
            populateHelperVariables(helper);
        } catch (Exception e) {
            if (isDuplicateFileNameError(e)) {

                String locale = MCASUtil.getUserLocale(helper);
                errorMessages.add(
                        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicateAttachmentName"));
                performSubmitFailureActions(helper);
                return;
            }
            sendDMPOSExceptionToCCASSupport(e, helper);
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    protected void sendDMPOSExceptionToCCASSupport(Exception e, UCCHelper helper) {
        if (e.toString().contains("DM_SESSION_E_") &&
                "prod".equalsIgnoreCase(System.getProperty("lsi.function"))) {//If its a DMPOS Error
            EmailInfo email = createExceptionEmail(e, helper);
            EmailService service = new EmailService();
            try {
                service.sendEmail(email);
                helper.setRequestAttributeValue("DMPOS_EXCEPTION_MESSAGE", "true");
            } catch (EmailException e1) {
                e1.printStackTrace();
            }
        }
    }

    private EmailInfo createExceptionEmail(Exception e, UCCHelper helper) {
        EmailInfo email = new EmailInfo();
        email.setBody(e.toString() + "\n\r***USER ID***" + helper.getAuthenticatedUserID() + "\n\r***User Name***" +
                helper.getAuthenticatedUserFullName());
        email.setTo(actionHelper.getCcasSupportEmail());
        email.setFrom(actionHelper.getAdminEmail());
        email.setCcArray(
                new String[]{actionHelper.getDmposExceptionCcEmail1(), actionHelper.getDmposExceptionCcEmail2(),
                        actionHelper.getDocumentumDistributionList()});
        email.setSubject("Exception Attaching Documents : DOCUMENTUM ERROR");
        return email;
    }

    String getFilePathOfUploadedFile(UCCHelper helper) throws IOException {
        return (String) helper.getClientFiles().get(0);
    }

    protected EntityStrategy getEntityStrategy(String entityType) throws MCASException {
        return EntityStrategyFactory.getConcreteStrategy(entityType);
    }

    protected String insertDocumentIntoRepository(String localFilePath, UCCHelper helper) throws MCASException,
            ParserException, GSSException, TransformerException, IOException, InvalidMimeTypeException, SAXException,
            POSCommunicationException, POSException, DocumentClientServiceException, FileTypeValidationException {
        McasDocumentServiceClientUtil documentServiceServiceClientUtil = new McasDocumentServiceClientUtil(helper,
                helper.getSystemSecurityProxy(), MCASConstants.PROJECT_SPECIFIC_FOLDER_MAPPING_NAME);
        final String absolutePath = new File(localFilePath).getAbsolutePath();
        return documentServiceServiceClientUtil
                .insertDocument(absolutePath, getMimeType(helper, localFilePath), getDocumentName(absolutePath));
    }

    private void resetMaxImportFileSize(UCCHelper helper) {
        helper.setMaxImportFileSize(MCASConstants.MAX_IMPORT_FILE_SIZE_IN_BYTES);
    }

    private String getDocumentName(String absolutePath) throws DocumentClientServiceException {
        return entityStrategy.getEntityName() + entityId + "_" +
                DocumentServiceClientUtil.assignNameFromFileLocation(absolutePath, true);
    }

    private boolean isDuplicateFileNameError(Exception e) {
        if (e != null && e.getMessage() != null) {
            return e.getMessage().indexOf(I18nServiceImpl.lookupProperty(MCASConstants.LANGUAGE_ENGLISH,
                    "com.monsanto.wst.ccas.error.duplicateFileName")) != -1;
        }
        return false;
    }

    private String getMimeType(UCCHelper helper, String localFilePath) throws FileTypeValidationException {
        AllowedAttachmentTypes allowedAttachmentTypes = (AllowedAttachmentTypes) helper
                .getContextAttribute(MCASConstants.HELPER_VAR_ALLOWED_ATTACHMENT_TYPES);
        return allowedAttachmentTypes.getMimeType(localFilePath.substring(localFilePath.lastIndexOf(".") + 1));
    }

    private void populateHelperVariables(UCCHelper helper) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
    }

    private void performSubmitFailureActions(UCCHelper helper) throws IOException {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ENTITY_ID, entityId);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ENTITY_NUMBER, entityNumber);
        helper.forward(MCASConstants.FORWARD_ADD_ATTACHMENT_PAGE);
    }


    private boolean errorOnPage() {
        return errorMessages != null && errorMessages.size() > 0;
    }
}
