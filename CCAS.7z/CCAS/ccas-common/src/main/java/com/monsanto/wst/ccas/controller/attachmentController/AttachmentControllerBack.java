package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.POSClient.InvalidMimeTypeException;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.service.EmailService;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.McasDocumentServiceClientUtil;
import com.monsanto.wst.ccas.validations.IMCASPageValidation;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;
import com.monsanto.wst.documentutil.documentposutil.DocumentServiceClientUtil;
import com.monsanto.wst.documentutil.documentposutil.exception.DocumentClientServiceException;
import com.monsanto.wst.documentutil.filetypeutil.AllowedAttachmentTypes;
import com.monsanto.wst.documentutil.filetypeutil.exception.FileTypeValidationException;
import org.ietf.jgss.GSSException;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: AOROZ
 * Date: 29/02/12
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class AttachmentControllerBack implements UseCaseController {

    private final ActionHelper actionHelper;
    private List<String> errorMessages;
    private String entityId;
    private String entityNumber;
    private EntityStrategy entityStrategy;
    private final IMCASPageValidation imcasPageValidation;

    public AttachmentControllerBack() {
        actionHelper = new ActionHelper();
        errorMessages = new ArrayList<String>();
        imcasPageValidation = new MCASPageValidationUtil();
    }

    public AttachmentControllerBack(IMCASPageValidation imcasPageValidation) {
        actionHelper = new ActionHelper();
        this.imcasPageValidation = imcasPageValidation;
    }

    public void run(UCCHelper helper) throws IOException {
        try {
            entityId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_ID);
            String entityType = (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_ENTITY_TYPE);
            entityNumber = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_NUMBER);
            entityStrategy = getEntityStrategy(entityType);
            entityStrategy.forward(entityId, entityNumber, helper);

        } catch (Exception e) {
             sendDMPOSExceptionToCCASSupport(e, helper);
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    protected void sendDMPOSExceptionToCCASSupport(Exception e, UCCHelper helper) {
        if (e.toString().contains("DM_SESSION_E_") &&
                "prod".equalsIgnoreCase(System.getProperty("lsi.function"))) {//If its a DMPOS Error
            EmailInfo email = createExceptionEmail(e, helper);
            EmailService service = new EmailService();
            try {
                service.sendEmail(email);
                helper.setRequestAttributeValue("DMPOS_EXCEPTION_MESSAGE", "true");
            } catch (EmailException e1) {
                e1.printStackTrace();
            }
        }
    }

    private EmailInfo createExceptionEmail(Exception e, UCCHelper helper) {
        EmailInfo email = new EmailInfo();
        email.setBody(e.toString() + "\n\r***USER ID***" + helper.getAuthenticatedUserID() + "\n\r***User Name***" +
                helper.getAuthenticatedUserFullName());
        email.setTo(actionHelper.getCcasSupportEmail());
        email.setFrom(actionHelper.getAdminEmail());
        email.setCcArray(
                new String[]{actionHelper.getDmposExceptionCcEmail1(), actionHelper.getDmposExceptionCcEmail2(),
                        actionHelper.getDocumentumDistributionList()});
        email.setSubject("Exception Attaching Documents : DOCUMENTUM ERROR");
        return email;
    }



    protected EntityStrategy getEntityStrategy(String entityType) throws MCASException {
        return EntityStrategyFactory.getConcreteStrategy(entityType);
    }



}
