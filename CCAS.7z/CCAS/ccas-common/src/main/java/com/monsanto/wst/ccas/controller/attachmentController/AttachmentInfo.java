package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.exception.MCASException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 21, 2006 Time: 11:17:43 AM To change this template use File |
 * Settings | File Templates.
 */
public class AttachmentInfo {

  private String entityId;
  private String documentId;
  private String documentName;

  public AttachmentInfo(String entityId, String documentId, String documenyName) throws MCASException {
    if (StringUtils.isNullOrEmpty(entityId) || StringUtils.isNullOrEmpty(documentId)
        || StringUtils.isNullOrEmpty(documenyName)) {
      throw new MCASException("Null arguments: entityId, documentId or documentName passed into AttachmentInfo");
    }
    this.entityId = entityId;
    this.documentId = documentId;
    this.documentName = documenyName;
  }

  public String getEntityId() {
    return entityId;
  }

  public String getDocumentId() {
    return documentId;
  }

  public String getDocumentName() {
    return documentName;
  }
}