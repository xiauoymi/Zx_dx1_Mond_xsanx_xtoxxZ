package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.dao.AuditDAO;
import com.monsanto.wst.ccas.dao.AuditDAOImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.actions.AuditAction;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 27, 2006
 * Time: 3:51:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteAuditStrategy implements EntityStrategy {

    public boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfo) throws DAOException {
        AuditDAO auditDAO = new AuditDAOImpl();
        return auditDAO.addAuditAttachmentInfo(attachmentInfo);
    }

    public boolean deleteAttachmentInfoFromDatabase(String documentId) throws DAOException {
        AuditDAO auditDAO = new AuditDAOImpl();
        return auditDAO.deleteAuditAttachmentInfo(documentId);
    }

    public void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException {
        User userObj = (User) helper.getSessionParameter(User.USER);
        int businessId = userObj.getBusinessId();
        helper.setRequestAttributeValue(AuditAction.BUSINESS_ID, businessId);
        helper.setRequestAttributeValue("canViewControls", "true");
        helper.setRequestAttributeValue(MCASConstants.FROM_ATTACH_FILE, "true");
        String forwardPath = "/audit.do?method=executeViewFromList&" + AuditAction.RECORD_ID + "=" + entityNumber;
        helper.forward(forwardPath);
    }

    public void validateEntityNumber(String entityNumber) throws MCASException {
        if (StringUtils.isNullOrEmpty(entityNumber)) {
            throw new MCASException("Audit number is null or empty");
        }
    }

    public String getEntityName() {
        return "Audit";
    }
}
