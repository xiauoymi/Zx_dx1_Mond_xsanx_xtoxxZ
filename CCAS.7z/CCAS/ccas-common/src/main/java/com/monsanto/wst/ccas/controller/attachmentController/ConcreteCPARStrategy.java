package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.ccas.dao.CparDAO;
import com.monsanto.wst.ccas.dao.CparDAOImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.actions.AuditAction;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 27, 2006
 * Time: 3:52:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteCPARStrategy implements EntityStrategy {

    public boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfo) throws DAOException {
        CparDAO cparDAO = new CparDAOImpl();
        return cparDAO.addCPARAttachmentInfo(attachmentInfo);
    }

    public boolean deleteAttachmentInfoFromDatabase(String documentId) throws DAOException {
        CparDAO cparDAO = new CparDAOImpl();
        return cparDAO.deleteCPARAttachmentInfo(documentId);
    }

    public void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException {
        User userObj = (User) helper.getSessionParameter(User.USER);
        int businessId = userObj.getBusinessId();
        helper.setRequestAttributeValue(AuditAction.BUSINESS_ID, businessId);
        helper.setRequestAttributeValue("canViewControls", "true");
        helper.forward("/cpar.do?method=cparEdit&cparId=" + entityId);
    }

    public void validateEntityNumber(String entityNumber) throws MCASException {
        //do nothing
    }

    public String getEntityName() {
        return "Cpar";
    }
}