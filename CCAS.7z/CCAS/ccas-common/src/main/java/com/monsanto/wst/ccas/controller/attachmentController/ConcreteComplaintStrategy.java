package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.dao.ComplaintDAO;
import com.monsanto.wst.ccas.dao.ComplaintDAOImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.actions.AuditAction;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 21, 2006
 * Time: 1:06:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteComplaintStrategy implements EntityStrategy {

    public boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfo) throws DAOException {
        ComplaintDAO complaintDAO = new ComplaintDAOImpl();
        return complaintDAO.addComplaintAttachmentInfo(attachmentInfo);
    }

    public boolean deleteAttachmentInfoFromDatabase(String documentId) throws DAOException {
        ComplaintDAO complaintDAO = new ComplaintDAOImpl();
        return complaintDAO.deleteComplaintAttachmentInfo(documentId);
    }

    public void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException {
        User userObj = (User) helper.getSessionParameter(User.USER);
        int businessId = userObj.getBusinessId();
        helper.setRequestAttributeValue(AuditAction.BUSINESS_ID, businessId);
        helper.setRequestAttributeValue("canViewControls", "true");
        helper.forward(getForwardURL(entityId, helper));
    }

    private String getForwardURL(String entityId, UCCHelper helper) throws IOException {
        String actionName = "/complaint.do";
        String entryType = helper.getRequestParameterValue("entryType");
        if (!StringUtils.isNullOrEmpty(entryType)) {
            if (!"C".equalsIgnoreCase(entryType)) {
                actionName = ("NCR".equalsIgnoreCase(entryType) ? "/complaintNcr.do" : "/complaintDeviation.do");
            }
        }
        return getForwardUrl(actionName, entityId, entryType);
    }

    private String getForwardUrl(String actionName, String entityId, String entryType) {
        entryType = StringUtils.isNullOrEmpty(entryType) ? "C" : entryType;
        return actionName + "?method=complaintEdit&complaintId=" + entityId + "&entryType=" + entryType;
    }

    public void validateEntityNumber(String entityNumber) throws MCASException {
        //do nothing
    }

    public String getEntityName() {
        return "Complaint";
    }
}