package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.StopSaleDAO;
import com.monsanto.wst.ccas.dao.StopSaleDAOImpl;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.actions.AuditAction;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 27, 2006
 * Time: 3:53:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteStopSaleStrategy implements EntityStrategy {

    public boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfo) throws DAOException {
        StopSaleDAO stopSaleDAO = new StopSaleDAOImpl();
        return stopSaleDAO.addStopSaleAttachmentInfo(attachmentInfo);
    }

    public boolean deleteAttachmentInfoFromDatabase(String documentId) throws DAOException {
        StopSaleDAO stopSaleDAO = new StopSaleDAOImpl();
        return stopSaleDAO.deleteStopSaleAttachmentInfo(documentId);
    }

    public void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException {
        User userObj = (User) helper.getSessionParameter(User.USER);
        int businessId = userObj.getBusinessId();
        helper.setRequestAttributeValue(AuditAction.BUSINESS_ID, businessId);
        helper.setRequestAttributeValue("canViewControls", "true");
        helper.forward("/stopSale.do?method=stopSaleView&stopSaleId=" + entityId);
    }

    public void validateEntityNumber(String entityNumber) throws MCASException {
        //do nothing
    }

    public String getEntityName() {
        return "StopSale";
    }
}