package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.exception.MCASException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 20, 2006
 * Time: 3:07:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EntityStrategy {

    boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfoh) throws DAOException;

    boolean deleteAttachmentInfoFromDatabase(String documentId) throws DAOException;

    void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException;

    void validateEntityNumber(String entityNumber) throws MCASException;

    String getEntityName();
}
