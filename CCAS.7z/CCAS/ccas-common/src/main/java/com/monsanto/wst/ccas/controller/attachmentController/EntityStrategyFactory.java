package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 21, 2006
 * Time: 12:52:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class EntityStrategyFactory {

    private static final Map<String, Class> strategyMap;

    static {
        strategyMap = new HashMap<String, Class>();
        strategyMap.put(MCASConstants.STRATEGY_MAP_KEY_COMPLAINT_ENTITY, ConcreteComplaintStrategy.class);
        strategyMap.put(MCASConstants.STRATEGY_MAP_KEY_AUDIT_ENTITY, ConcreteAuditStrategy.class);
        strategyMap.put(MCASConstants.STRATEGY_MAP_KEY_STOPSALE_ENTITY, ConcreteStopSaleStrategy.class);
        strategyMap.put(MCASConstants.STRATEGY_MAP_KEY_CPAR_ENTITY, ConcreteCPARStrategy.class);
    }

    public static EntityStrategy getConcreteStrategy(String entityType) throws MCASException {
        if (StringUtils.isNullOrEmpty(entityType)) {
            throw new MCASException("Cannot retrieve strategy implementation for null entityType");
        }
        EntityStrategy strategy;
        Class strategyClass = strategyMap.get(entityType);
        if (strategyClass != null) {
            try {
                strategy = (EntityStrategy) strategyClass.newInstance();
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new MCASException("Could not instantiate strategy for name '" + entityType + "': " + e.getMessage(), e);
            }
        } else {
            throw new MCASException("Could not find implementation class for name '" + entityType + "'");
        }
        return strategy;
    }
}
