package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.McasDocumentServiceClientUtil;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;
import com.monsanto.wst.documentutil.documentposutil.exception.DocumentClientServiceException;
import org.ietf.jgss.GSSException;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 24, 2006
 * Time: 1:40:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveAttachmentController implements UseCaseController {

    private String documentId;
    private String entityId;
    private String entityType;
    private String entityNumber;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            deleteDocumentFromRepository(helper);
            EntityStrategy entityStrategy = getEntityStrategy(entityType);
            entityStrategy.validateEntityNumber(entityNumber);
            entityStrategy.deleteAttachmentInfoFromDatabase(documentId);
            entityStrategy.forward(entityId, entityNumber, helper);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void getHelperParams(UCCHelper helper) throws IOException, MCASException {
        MCASPageValidationUtil mcasPageValidationUtil = new MCASPageValidationUtil();
        documentId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_DOC_ID);
        mcasPageValidationUtil.validateHelperParam("documentId", documentId);
        entityId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_ID);
        mcasPageValidationUtil.validateHelperParam("entityId", entityId);
        entityType = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_TYPE);
        mcasPageValidationUtil.validateHelperParam("entityType", entityType);
        entityNumber = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_ENTITY_NUMBER);
    }

    protected boolean deleteDocumentFromRepository(UCCHelper helper) throws MCASException, ParserException, GSSException, TransformerException, IOException, SAXException, POSCommunicationException, POSException, DocumentClientServiceException {
//    DocumentServiceClientUtil documentServiceClientUtil = new DocumentServiceClientUtil(helper.getSystemSecurityProxy(), MCASConstants.PROJECT_SPECIFIC_FOLDER_MAPPING_NAME);
        McasDocumentServiceClientUtil documentServiceServiceClientUtil = new McasDocumentServiceClientUtil(helper, helper.getSystemSecurityProxy(), MCASConstants.PROJECT_SPECIFIC_FOLDER_MAPPING_NAME);
        return documentServiceServiceClientUtil.deleteDocument(documentId);
    }

    protected EntityStrategy getEntityStrategy(String entityType) throws MCASException {
        return EntityStrategyFactory.getConcreteStrategy(entityType);
    }
}
