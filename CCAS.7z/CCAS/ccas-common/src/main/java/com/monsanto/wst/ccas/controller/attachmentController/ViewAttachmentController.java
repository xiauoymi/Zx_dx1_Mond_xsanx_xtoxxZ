package com.monsanto.wst.ccas.controller.attachmentController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.McasDocumentServiceClientUtil;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;
import com.monsanto.wst.documentutil.filetypeutil.AllowedAttachmentTypes;
import com.monsanto.wst.documentutil.filetypeutil.exception.FileTypeValidationException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 24, 2006
 * Time: 4:20:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class ViewAttachmentController implements UseCaseController {

    private String documentId;
    private String documentName;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            displayAttachmentInBrowser(documentId, documentName, helper);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void getHelperParams(UCCHelper helper) throws IOException, MCASException {
        MCASPageValidationUtil mcasPageValidationUtil = new MCASPageValidationUtil();
        documentId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_DOC_ID);
        mcasPageValidationUtil.validateHelperParam("DocumentId", documentId);
        documentName = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_DOC_NAME);
        mcasPageValidationUtil.validateHelperParam("documentName", documentName);
    }

    protected void displayAttachmentInBrowser(String documentId, String documentName, UCCHelper helper) throws Exception {
        try {
            helper.setContentType(getMimeType(helper, documentName));
            helper.setHeader("Content-Disposition", "attachment; filename=\"" + documentName + "\"");
            //    DocumentServiceClientUtil documentServiceClientUtil = new DocumentServiceClientUtil(helper.getSystemSecurityProxy(), MCASConstants.PROJECT_SPECIFIC_FOLDER_MAPPING_NAME);
            McasDocumentServiceClientUtil documentServiceServiceClientUtil = new McasDocumentServiceClientUtil(helper, helper.getSystemSecurityProxy(), MCASConstants.PROJECT_SPECIFIC_FOLDER_MAPPING_NAME);
            documentServiceServiceClientUtil.retrieveDocument(documentId, helper.getBinaryStream());
        }
        catch (Exception e) {
            MCASLogUtil.logError("Error retrieving document '" + documentName + "' with document ID: " + documentId, e);

            throw e;
        }
    }

    protected EntityStrategy getEntityStrategy(String entityType) throws MCASException {
        return EntityStrategyFactory.getConcreteStrategy(entityType);
    }

    private String getMimeType(UCCHelper helper, String documentName) throws FileTypeValidationException {
        AllowedAttachmentTypes allowedAttachmentTypes = (AllowedAttachmentTypes) helper.getContextAttribute(MCASConstants.HELPER_VAR_ALLOWED_ATTACHMENT_TYPES);
        return allowedAttachmentTypes.getMimeType(MCASUtil.getFileExtension(documentName));
    }
}
