package com.monsanto.wst.ccas.controller.attachmentController.tests;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.controller.attachmentController.EntityStrategy;
import com.monsanto.wst.ccas.exception.MCASException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 24, 2006
 * Time: 2:00:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockEntityStrategy implements EntityStrategy {

    public boolean addInsertedDocumentInfoToDatabase(AttachmentInfo attachmentInfoh) {
        return true;
    }

    public void forward(String entityId, String entityNumber, UCCHelper helper) throws IOException {
        helper.forward("testForward");
    }

    public void validateEntityNumber(String entityNumber) throws MCASException {
        //do nothing
    }

    public String getEntityName() {
        return "testEntity";
    }

    public boolean deleteAttachmentInfoFromDatabase(String documentId) {
        return true;
    }
}