package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.LocationAdminDAOImpl;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Aug 11, 2006 Time: 9:39:45 AM To change this template use File |
 * Settings | File Templates.
 */
public class AddEditLocationController implements UseCaseController {

  private List<String> errorMessages = new ArrayList<String>();
  private LocationInfo locationInfo = null;

  public void run(UCCHelper helper) throws IOException {
    try {
      User user = (User) helper.getSessionParameter(User.USER);
      int businessId = user.getBusinessId();
      setLocationInfo(helper);
      errorMessages = new MCASPageValidationUtil().validateLocationInfo(locationInfo, user.getLocale(), helper.getSessionParameter("appName").toString());
      if (isValidationError()) {
        populateErrorMessages(helper);
        return;
      }

      SaveLocationStrategy saveLocationStrategy = getLocationStrategy(
          (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_EDIT_LOCATION_ACTION));
        String appName=helper.getSessionParameter("appName").toString();
        boolean isProgram=false;
        if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_BIOTECHFAS)){
              isProgram=true;
            businessId=locationInfo.getRegionId();
        }

      saveLocationStrategy.saveToDatabase(locationInfo, businessId, new LocationAdminDAOImpl(), isProgram);

      if (!StringUtils.isNullOrEmpty(locationInfo.getErrorMessage())) {
        errorMessages.add(locationInfo.getErrorMessage());
        populateErrorMessages(helper);
        return;
      }
      addLocationToMap(helper);
      clearLocationListsFromSession(helper);
      findForward(helper, true);
    } catch (Exception e) {

        final String msg = e.getMessage();
        if(msg!=null && msg.contains("unique constraint")) {
            errorMessages.add("Location code already exists.");
            populateErrorMessages(helper);
            return;
        }
        else {
            MCASLogUtil.logError(msg, e);
            MCASUtil.displayErrorPage(helper);
        }
    }
  }

  private void populateErrorMessages(UCCHelper helper) throws IOException {
    populateErrorMessage(helper);
    populateHelperParams(helper);
    findForward(helper, false);
  }

  protected SaveLocationStrategy getLocationStrategy(String editLocationActionFlag) {
    return LocationStrategyFactory.getConcreteSaveLocationStrategy(editLocationActionFlag);
  }

  private void clearLocationListsFromSession(UCCHelper helper) {
    helper.setSessionParameter(ActionHelperConstants.LOCATION_LIST, null);
    helper.setSessionParameter(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST, null);
  }

  private void addLocationToMap(UCCHelper helper) {
    Map<String, LocationInfo> locationMap = (Map<String, LocationInfo>) helper
        .getSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP);
    locationMap.put(locationInfo.getLocationId(), locationInfo);
  }

  private void populateHelperParams(UCCHelper helper) {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_LOCATION_INFO, locationInfo);
  }

  private boolean isValidationError() {
    return errorMessages != null && errorMessages.size() > 0;
  }

  private void findForward(UCCHelper helper, boolean successForward) throws IOException {
    if (successForward) {
      helper.forward(MCASConstants.FORWARD_LOCATION_ADMIN_PAGE);
    } else {
      helper.forward(MCASConstants.FORWARD_ADD_EDIT_LOCATION_PAGE);
    }
  }

  private void populateErrorMessage(UCCHelper helper) {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
  }

  private void setLocationTypes(UCCHelper helper, LocationInfo locationInfo) throws IOException {

    String appName = (String) helper.getSessionParameter("APPLICATION_NAME");

    if ("btfas".equalsIgnoreCase(appName)) {
      locationInfo.setReportingLocation(false);
      locationInfo.setShippingLocation(false);
    } else if ("sbfas".equalsIgnoreCase(appName)) {
      locationInfo.setReportingLocation(false);
      locationInfo.setShippingLocation(false);

      locationInfo.setResponsibleLocation(getStatus(helper, MCASConstants.HELPER_VAR_IS_RESPONSIBLE_LOCATION));
      locationInfo.setFilingLocation(getStatus(helper, MCASConstants.HELPER_VAR_IS_FILING_LOCATION));
      locationInfo.setCustomerLocation(getStatus(helper, MCASConstants.HELPER_VAR_IS_CUSTOMER_LOCATION));
    }
  }

  private void setLocationInfo(UCCHelper helper) throws IOException {
    int regionId = getRegionId(helper);

    locationInfo = new LocationInfo(
        helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_ID),
        helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_NAME),
        helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_LONG_NAME),
        regionId,
        getRegionDesc(helper, regionId),
        getStatus(helper, MCASConstants.HELPER_VAR_LOCATION_STATUS),
        helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_EMAIL),
        helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL),
        getStatus(helper, MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL_STATUS),
        //Default display types.  Fix these in a minute...
        true,
        true,
        true,
        true,
        false,helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL2),helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL3),
            helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL4));
    locationInfo.setLocationOwnerEmail2(helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL2));
         locationInfo.setLocationOwnerEmail3(helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL3));
         locationInfo.setLocationOwnerEmail4(helper.getRequestParameterValue(MCASConstants.HELPER_VAR_LOCATION_OWNER_EMAIL4));

    setLocationTypes(helper, locationInfo);
  }

  private String getRegionDesc(UCCHelper helper, int regionId) {
    String regionDesc = "";
    Map<String, String> regionMap = (Map<String, String>) helper
        .getSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST);
    if (regionId != -1) {
      regionDesc = regionMap.get(String.valueOf(regionId));
    }
    return regionDesc;
  }

  private int getRegionId(UCCHelper helper) throws IOException {
    int regionId;
    String selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);
    try {
      regionId = Integer.parseInt(selectedRegion);
    } catch (NumberFormatException e) {
      MCASLogUtil.logError(e.getMessage(), e);
      regionId = -1;
    }
    return regionId;
  }

  private boolean getStatus(UCCHelper helper, String statusParam) throws IOException {
    boolean statusActive = false;
    String status = helper.getRequestParameterValue(statusParam);
    if (!StringUtils.isNullOrEmpty(status) && status.equalsIgnoreCase(MCASConstants.CHECKBOX_ON)) {
      statusActive = true;
    }
    return statusActive;
  }
}
