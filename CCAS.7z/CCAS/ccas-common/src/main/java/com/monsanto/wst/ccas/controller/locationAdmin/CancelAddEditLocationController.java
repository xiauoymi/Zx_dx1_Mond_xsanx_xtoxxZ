package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 11, 2006
 * Time: 10:00:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class CancelAddEditLocationController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        helper.forward(MCASConstants.FORWARD_LOCATION_ADMIN_PAGE);
    }
}