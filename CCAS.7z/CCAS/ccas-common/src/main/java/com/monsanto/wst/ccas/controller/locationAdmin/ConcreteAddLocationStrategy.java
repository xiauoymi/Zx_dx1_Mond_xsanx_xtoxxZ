package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.LocationAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 15, 2006
 * Time: 4:41:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteAddLocationStrategy implements SaveLocationStrategy {

    public void saveToDatabase(LocationInfo locationInfo, int businessId, LocationAdminDAO locationAdminDao, boolean isProgram) throws MCASException, DAOException {

        if(isProgram){
            locationInfo.setRegionId(1);
            locationInfo.setStatusActive(true);
            locationAdminDao.insertLocation(locationInfo);
            locationAdminDao.insertProgramLocationreference(locationInfo, businessId);
        }
        else{
            locationAdminDao.insertLocation(locationInfo);
            locationAdminDao.insertBusinessLocationreference(locationInfo, businessId);
        }



        ArrayList<Integer> displayParams = new ArrayList<Integer>();

        if (locationInfo.isResponsibleLocation())
            displayParams.add(1);
        if (locationInfo.isFilingLocation())
            displayParams.add(2);
        if (locationInfo.isReportingLocation())
            displayParams.add(3);
        if (locationInfo.isShippingLocation())
            displayParams.add(4);
        if (locationInfo.isCustomerLocation())
            displayParams.add(5);

        int[] disParams = new int[displayParams.size()];
        for (int i = 0; i < displayParams.size(); i++) {
            disParams[i] = displayParams.get(i);
        }

        locationAdminDao.insertOrUpdateLocationDisplayRef(locationInfo.getLocationId(), disParams, false);
    }
}
