package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.service.ProgramServiceImpl;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 8, 2006
 * Time: 1:39:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayAddNewLocationPageController implements UseCaseController {
    private BusinessService businessService;

    public void run(UCCHelper helper) throws IOException {
        try {
            businessService = new BusinessServiceImpl();
            populateRegionList(helper);
            setHelperParams(helper);
            helper.forward(MCASConstants.FORWARD_ADD_EDIT_LOCATION_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    Map<String, String> getRegionList(String userId, int businessId, String locale) {
        //return ActionHelper.getRegionList(userId,businessId);
        return new RegionServiceImpl().getRegionList(userId, businessId, locale);
    }

    Map<String, String> getRegionListforProgram() {
        return new ProgramServiceImpl().lookupAllPrograms();

    }

    private void setHelperParams(UCCHelper helper) {
        helper.setSessionParameter(MCASConstants.HELPER_VAR_EDIT_LOCATION_ACTION, "false");
    }

    private void populateRegionList(UCCHelper helper) throws MCASException {
        try {
            String userId = MCASUtil.getAuthenticatedUserID(helper);
            int businessId = MCASUtil.getUserBusiness(helper, businessService);
            String locale = MCASUtil.getUserLocale(helper);

            String appName=helper.getSessionParameter("appName").toString();

            Map<String, String> regionList =null;

            if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_BIOTECHFAS)){
                regionList = getRegionListforProgram();
            }
            else{
                regionList = getRegionList(userId, businessId, locale);
            }

           helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, regionList);
        }
        catch (Exception ex) {
            throw new MCASException("Error looking up the Region list: " + ex.getMessage(), ex);
        }
    }
}
