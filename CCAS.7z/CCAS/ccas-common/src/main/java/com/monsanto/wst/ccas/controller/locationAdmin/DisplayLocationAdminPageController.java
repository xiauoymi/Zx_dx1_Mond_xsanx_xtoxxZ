package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.ProgramListController;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ProgramServiceImpl;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 8, 2006
 * Time: 8:55:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayLocationAdminPageController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        try {
            populateAllRegionList(helper);
            clearLocationMap(helper);
            helper.forward(MCASConstants.FORWARD_LOCATION_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void clearLocationMap(UCCHelper helper) {
        Map<String, LocationInfo> locationMap = (Map<String, LocationInfo>) helper.getSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP);
        if (locationMap != null) {
            locationMap.clear();
        } else {
            locationMap = new LinkedHashMap<String, LocationInfo>();
            helper.setSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP, locationMap);
        }
    }

    private void populateAllRegionList(UCCHelper helper) throws MCASException {
        try {
            String userId = MCASUtil.getAuthenticatedUserID(helper);
            String locale = MCASUtil.getUserLocale(helper);

            String appName=helper.getSessionParameter("appName").toString();

            Map<String, String> regionList = null;
            if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_BIOTECHFAS)){
                regionList = getAllRegionListforFunctionalArea();
            }
            else{
                regionList = getAllRegionList(userId, getBusinessId(helper), locale);
            }

            // if (helper.getSessionParameter(MCASConstants.HELPER_VAR_ALL_REGION_LIST) == null) {
            helper.setSessionParameter(MCASConstants.HELPER_VAR_ALL_REGION_LIST, regionList);
            // }
        }
        catch (Exception ex) {
            throw new MCASException("Error looking up the Region list: " + ex.getMessage(), ex);
        }
    }

    private Map<String, String> getAllRegionListforFunctionalArea() {

        return new ProgramServiceImpl().lookupAllPrograms();
    }

    protected Map<String, String> getAllRegionList(String userId, int businessId, String locale) throws Exception {
        return new RegionServiceImpl().getRegionList(userId, businessId, locale);
    }

    int getBusinessId(UCCHelper helper) {
        return ((User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER)).getBusinessId();
    }
}
