package com.monsanto.wst.ccas.controller.locationAdmin;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 15, 2006
 * Time: 5:21:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationStrategyFactory {

    public static SaveLocationStrategy getConcreteSaveLocationStrategy(String editLocationActionFlag) {
        if (editLocationActionFlag != null && editLocationActionFlag.equalsIgnoreCase("true")) {
            return new ConcreteEditLocationStrategy();
        }
        return new ConcreteAddLocationStrategy();
    }
}