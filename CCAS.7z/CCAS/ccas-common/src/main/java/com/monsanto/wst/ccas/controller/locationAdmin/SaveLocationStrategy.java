package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.LocationAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 15, 2006
 * Time: 4:40:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SaveLocationStrategy {

    void saveToDatabase(LocationInfo locationInfo, int businessId, LocationAdminDAO locationAdminDao, boolean isProgram) throws MCASException, DAOException;
}
