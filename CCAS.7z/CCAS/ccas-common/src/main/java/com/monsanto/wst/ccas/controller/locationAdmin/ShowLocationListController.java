package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.LocationAdminDAOImpl;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 10:40:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class ShowLocationListController implements UseCaseController {

    private String selectedRegion = null;
   
    private Map<String, LocationInfo> locationMap = new LinkedHashMap();

    public void run(UCCHelper helper) throws IOException {
        try {
            selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);

            String appName=helper.getSessionParameter("appName").toString();
            if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_BIOTECHFAS)){
                locationMap = getLocationMap(getRegionId(selectedRegion));
            }
            else{
                locationMap = getLocationMapforProgram(getRegionId(selectedRegion));
            }
            setHelperParams(helper);



            helper.forward(MCASConstants.FORWARD_LOCATION_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    protected Map<String, LocationInfo> getLocationMap(int regionId) throws MCASException, DAOException {
        return new LocationAdminDAOImpl().getLocationList(regionId, false);
    }

    protected Map<String, LocationInfo> getLocationMapforProgram(int programId) throws MCASException, DAOException {
        return new LocationAdminDAOImpl().getLocationList(programId, true);
    }

    private int getRegionId(String selectedRegion) {
        int regionId;
        try {
            regionId = Integer.parseInt(selectedRegion);
        } catch (NumberFormatException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            regionId = -1;
        }
        return regionId;
    }

    private void setHelperParams(UCCHelper helper) {
        if (locationMap == null) {
            locationMap = new LinkedHashMap<String, LocationInfo>();
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP, locationMap);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION, selectedRegion);
    }
}
