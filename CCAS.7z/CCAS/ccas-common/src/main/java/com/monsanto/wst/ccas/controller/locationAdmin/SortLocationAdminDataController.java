package com.monsanto.wst.ccas.controller.locationAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.ComparatorFactory;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.SortUtil;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 2:09:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class SortLocationAdminDataController implements UseCaseController {

    private String index = null;
    private Map<String, LocationInfo> locationMap = new LinkedHashMap<String, LocationInfo>();
    private String selectedRegion = null;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            String sortOrder = SortUtil.determineCurrentSortOrder(index,
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_INDEX),
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_ORDER)
            );
            SortUtil.populatePrevSortOrderAndIndex(helper, index, sortOrder);
            sortLocationData(index, sortOrder, locationMap);
            populateHelperVariables(helper, locationMap);
            helper.forward(MCASConstants.FORWARD_LOCATION_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void getHelperParams(UCCHelper helper) throws IOException {
        selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);
        index = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SORT_INDEX);
        locationMap = (Map<String, LocationInfo>) helper.getSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP);
    }

    private void populateHelperVariables(UCCHelper helper, Map<String, LocationInfo> locationMap) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION, selectedRegion);
        if (locationMap == null) {
            locationMap = new LinkedHashMap<String, LocationInfo>();
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_LOCATION_MAP, locationMap);
    }

    private void sortLocationData(String index, String sortOrder, Map<String, LocationInfo> locationMap) throws MCASException {
        if (locationMap != null) {
            Vector<LocationInfo> dataVector = new Vector<LocationInfo>();
            for (String s : locationMap.keySet()) {
                dataVector.add(locationMap.get(s));
            }
            locationMap.clear();
            BaseComparator locationAdminComparator = (BaseComparator) ComparatorFactory.getComparator(index, sortOrder);
            Collections.sort(dataVector, locationAdminComparator);
            int size = dataVector.size();
            for (int i = 0; i < size; i++) {
                LocationInfo locationInfo = dataVector.get(i);
                locationMap.put(locationInfo.getLocationId(), locationInfo);
            }
        }
    }
}
