package com.monsanto.wst.ccas.controller.locationAdmin.comparators;

import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 2:47:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationAdminPageLocationIdComparator extends BaseComparator {

    public LocationAdminPageLocationIdComparator(String sortOrder) {
        super.sortOrder = sortOrder;
    }

    public int compare(Object obj1, Object obj2) {
        setTokens(obj1, obj2);
        return compareAlphaNumericTokens();
    }

    private void setTokens(Object obj1, Object obj2) {
        String tokenA;
        String tokenB;
        tokenA = ((LocationInfo) obj1).getLocationId() != null ?
                ((LocationInfo) obj1).getLocationId().trim() : "";
        tokenB = ((LocationInfo) obj2).getLocationId() != null ?
                ((LocationInfo) obj2).getLocationId().trim() : "";
        super.setaToken(tokenA);
        super.setbToken(tokenB);
    }
}