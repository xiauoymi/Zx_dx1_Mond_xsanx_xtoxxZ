package com.monsanto.wst.ccas.controller.locationAdmin.comparators;

import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 2:51:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationAdminPageLocationNameComparator extends BaseComparator {

    public LocationAdminPageLocationNameComparator(String sortOrder) {
        super.sortOrder = sortOrder;
    }

    public int compare(Object obj1, Object obj2) {
        setTokens(obj1, obj2);
        return compareTokens();
    }

    private void setTokens(Object obj1, Object obj2) {
        String tokenA;
        String tokenB;
        tokenA = ((LocationInfo) obj1).getLocationName() != null ?
                ((LocationInfo) obj1).getLocationName().trim() : "";
        tokenB = ((LocationInfo) obj2).getLocationName() != null ?
                ((LocationInfo) obj2).getLocationName().trim() : "";
        super.setaToken(tokenA);
        super.setbToken(tokenB);
    }
}