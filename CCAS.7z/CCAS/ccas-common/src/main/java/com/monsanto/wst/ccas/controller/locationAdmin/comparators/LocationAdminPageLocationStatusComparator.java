package com.monsanto.wst.ccas.controller.locationAdmin.comparators;

import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 2:51:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationAdminPageLocationStatusComparator extends BaseComparator {

    public LocationAdminPageLocationStatusComparator(String sortOrder) {
        super.sortOrder = sortOrder;
    }

    public int compare(Object obj1, Object obj2) {
        setTokens(obj1, obj2);
        return compareTokens();
    }

    private void setTokens(Object obj1, Object obj2) {
        String tokenA;
        String tokenB;
        tokenA = ((LocationInfo) obj1).isStatusActive() ? "Active" : "Inactive";
        tokenB = ((LocationInfo) obj2).isStatusActive() ? "Active" : "Inactive";
        super.setaToken(tokenA);
        super.setbToken(tokenB);
    }
}