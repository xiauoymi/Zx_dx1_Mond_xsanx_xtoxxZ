package com.monsanto.wst.ccas.controller.locationAdmin.comparators;

import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 9, 2006
 * Time: 2:51:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationAdminPageRegionDescComparator extends BaseComparator {

    public LocationAdminPageRegionDescComparator(String sortOrder) {
        super.sortOrder = sortOrder;
    }

    public int compare(Object obj1, Object obj2) {
        setTokens(obj1, obj2);
        return compareTokens();
    }

    private void setTokens(Object obj1, Object obj2) {
        String tokenA;
        String tokenB;
        tokenA = ((LocationInfo) obj1).getRegionDesc() != null ?
                ((LocationInfo) obj1).getRegionDesc().trim() : "";
        tokenB = ((LocationInfo) obj2).getRegionDesc() != null ?
                ((LocationInfo) obj2).getRegionDesc().trim() : "";
        super.setaToken(tokenA);
        super.setbToken(tokenB);
    }
}