package com.monsanto.wst.ccas.controller.mcasoutage;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: May 7, 2008
 * Time: 11:45:54 AM
 * To change this template use File | Settings | File Templates.
 */
class McasOutageController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {

        BufferedReader reader = null;
        PrintWriter pw = null;

        try {
            String outageFilePath = System.getProperty("MONCRYPTJV");
            String fileName = outageFilePath + "/ApplicationOutage.html";
            File outageFile = new File(fileName);
            if (outageFile.exists()) {
                reader = new BufferedReader(new FileReader(outageFile));
                StringBuffer buf = new StringBuffer();
                String tempData = "";
                while ((tempData = reader.readLine()) != null) {
                    buf.append(tempData);
                }
                pw = helper.getPrintWriter();
                pw.write(buf.toString());

                pw.close();
            } else {
                helper.redirect("outage.html");
            }
        }
        finally {
            MCASResourceUtil.closeResource(reader);
            MCASResourceUtil.closeResource(pw);
        }
    }
}
          
    

