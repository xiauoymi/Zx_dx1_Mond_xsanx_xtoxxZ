package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.UserAdminDAOImpl;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 13, 2006 Time: 3:31:28 PM To change this template use File |
 * Settings | File Templates.
 */
public class AddNewUserController implements UseCaseController {

  private List<String> errorMessages = null;
  private Map<String, UserDetails> userMap = null;
  private UserDetails userDetails = null;

  public void run(UCCHelper helper) throws IOException {
    try {
      String userId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_ID);
      String userName = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_NAME);
      String roleId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE);
      String locale = MCASUtil.getUserLocale(helper);

      //Support for Multiple Regions
      String[] regionIds = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_REGION);
      //Support for Multiple Business
      String[] businessIds = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_BUSINESS);
      String userBusinessPreference = helper
          .getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS_PREFERENCE_ID);
      errorMessages = new MCASPageValidationUtil()
          .validateUserDetailsForAdd(userId, roleId, businessIds, userBusinessPreference, regionIds, locale);
      if (errorOnPage()) {
        performSubmitFailureActions(helper, userId, userName, roleId, businessIds, userBusinessPreference, regionIds);
        return;
      }
      getNewUserDetails(userId, userName, roleId, helper, businessIds, userBusinessPreference, regionIds);

      if (!userAddedToPersistentStore(userDetails, helper)) {
        errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.userExists"));
        performSubmitFailureActions(helper, userId, userName, roleId, businessIds, userBusinessPreference, regionIds);
        return;
      }
      userMap = (Map<String, UserDetails>) helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
      populateRequestParams(helper);
      forwardSuccess(helper);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      MCASUtil.displayErrorPage(helper);
    }
  }

  protected boolean userAddedToPersistentStore(UserDetails userDetails, UCCHelper helper) throws DAOException,
      MCASException {
    String authenticatedUserID = MCASUtil.getAuthenticatedUserID(helper);
    return new UserAdminDAOImpl().addNewUser(userDetails, authenticatedUserID);
  }

  private void performSubmitFailureActions(UCCHelper helper, String userId, String userName, String roleId,
                                           String[] businessIds, String userBusinessPreference,
                                           String[] selectedRegions) throws Exception {
    UserControllerHelper
        .populateAlreadyEnteredFields(helper, userId, userName, roleId, businessIds, userBusinessPreference,
            selectedRegions);
    populateErrorMessages(helper);
    forwardFailure(helper);
  }

  private boolean errorOnPage() {
    return errorMessages != null && errorMessages.size() > 0;
  }

  private void forwardSuccess(UCCHelper helper) throws IOException {
    forward(helper, MCASConstants.FORWARD_USER_ADMIN_PAGE);
  }

  private void forwardFailure(UCCHelper helper) throws IOException {
    forward(helper, MCASConstants.FORWARD_ADD_EDIT_USER_PAGE);
  }

  private void getNewUserDetails(String userId, String userName, String roleId, UCCHelper helper, String[] businessIds,
                                 String userBusinessPreferenceId, String[] selectedRegions) {
    Map<String, String> roleList = (Map<String, String>) helper.getSessionParameter(MCASConstants.HELPER_VAR_ROLE_LIST);

    //Initially Set the default values.
    UserControllerHelper.setDefaultRegions(helper);

    int businessIdInt = -1;
    int userBusinessPreferenceIdInt = -1;

    if (userBusinessPreferenceId != null && userBusinessPreferenceId.length() != 0) {
      userBusinessPreferenceIdInt = Integer.parseInt(userBusinessPreferenceId);
    }


    UserRegion userRegion = new UserRegion(userId, selectedRegions);
    UserBusiness userBusiness = new UserBusiness(userId, businessIds);
    userDetails = new UserDetails(userId.trim().toUpperCase(), userName, Integer.parseInt(roleId), roleList.get(roleId),
        userRegion, "", businessIdInt, userBusinessPreferenceIdInt);
    userDetails.setUserBusiness(userBusiness);
  }

  private void populateParam(UCCHelper helper, String paramName, String paramValue) {
    UserControllerHelper.populateParam(helper, paramName, paramValue);
  }

  private void populateRequestParams(UCCHelper helper) {
    populateErrorMessages(helper);
    if (userMap == null) {
      userMap = new LinkedHashMap<String, UserDetails>();
    }
    userMap.put(userDetails.getUserId(), userDetails);
    helper.setSessionParameter(MCASConstants.HELPER_VAR_USER_MAP, userMap);
    populateParam(helper, MCASConstants.HELPER_VAR_SELECTED_ROLE, userDetails.getRoleId() + "");
    populateParam(helper, MCASConstants.HELPER_VAR_SELECTED_BUSINESS, "" + userDetails.getBusinessId());
  }

  private void forward(UCCHelper helper, String forwardPage) throws IOException {
    helper.forward(forwardPage);
  }

  private void populateErrorMessages(UCCHelper helper) {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
  }
}
