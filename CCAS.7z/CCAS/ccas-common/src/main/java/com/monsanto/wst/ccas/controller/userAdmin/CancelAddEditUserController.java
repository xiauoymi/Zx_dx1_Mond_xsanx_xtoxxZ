package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 11, 2006
 * Time: 10:15:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class CancelAddEditUserController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        populateRequestParams(helper);
        helper.forward(MCASConstants.FORWARD_USER_ADMIN_PAGE);
    }

    private void populateRequestParams(UCCHelper helper) throws IOException {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_ROLE, helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE));
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS, helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS));
    }
}