package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.dao.UserAdminDAOImpl;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 13, 2006
 * Time: 1:50:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteUserController implements UseCaseController {

    private UserDetails selectedUserDetails;
    private String selectedRole = null;
    private String selectedRegion = null;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            String selectedUserId = getSelectedUserId(helper);
            Map<String, UserDetails> userMap = getUserMap(helper);
            getSelectedUserDetails(userMap, selectedUserId);
            deleteUserRecordFromDatabase(selectedUserDetails);
            deleteUserRecordFromUserMap(userMap, selectedUserId);
            populateHelperVariables(helper);
            helper.forward(MCASConstants.FORWARD_USER_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void deleteUserRecordFromUserMap(Map<String, UserDetails> userMap, String selectedUserId) {
        userMap.remove(selectedUserId);
    }

    protected void deleteUserRecordFromDatabase(UserDetails selectedUserDetails) throws DAOException, MCASException {
        UserAdminDAO dao = new UserAdminDAOImpl();
        dao.deleteUser(selectedUserDetails);
    }

    private String getSelectedUserId(UCCHelper helper) throws MCASException, IOException {
        String selectedUserId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_USER_ID);
        if (StringUtils.isNullOrEmpty(selectedUserId)) {
            throw new MCASException("UserId for delete is null");
        }
        return selectedUserId;
    }

    private void getSelectedUserDetails(Map<String, UserDetails> userMap, String selectedUserId) throws MCASException {
        selectedUserDetails = userMap.get(selectedUserId);
        if (selectedUserDetails == null) {
            throw new MCASException("Selected User Details not found in User Map");
        }
    }

    private Map<String, UserDetails> getUserMap(UCCHelper helper) throws MCASException {
        Map<String, UserDetails> userMap = (Map<String, UserDetails>) helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
        if (userMap == null) {
            throw new MCASException("User Map is null");
        }
        return userMap;
    }

    private void getHelperParams(UCCHelper helper) throws IOException {
        selectedRole = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE);
        selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);
    }

    private void populateHelperVariables(UCCHelper helper) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_ROLE, selectedRole);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION, selectedRegion);
    }
}
