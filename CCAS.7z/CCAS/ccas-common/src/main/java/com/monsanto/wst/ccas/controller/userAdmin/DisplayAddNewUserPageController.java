package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 5:32:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayAddNewUserPageController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        try {
            helper.setSessionParameter(MCASConstants.HELPER_VAR_EDIT_ACTION, "false");
            UserControllerHelper.setDefaultRegions(helper);
            helper.forward(MCASConstants.FORWARD_ADD_EDIT_USER_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }
}