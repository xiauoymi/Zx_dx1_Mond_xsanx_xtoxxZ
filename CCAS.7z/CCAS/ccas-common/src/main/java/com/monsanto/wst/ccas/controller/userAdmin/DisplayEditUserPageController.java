package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 13, 2006
 * Time: 10:40:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayEditUserPageController implements UseCaseController {

    private UserDetails selectedUserDetails;

    public void run(UCCHelper helper) throws IOException {
        try {
            String selectedUserId = getSelectedUserId(helper);
            Map<String, User> userMap = getUserMap(helper);
            getSelectedUserDetails(userMap, selectedUserId);
            populateHelperParams(helper);
            populateRegionList(helper);
            forward(helper, MCASConstants.FORWARD_ADD_EDIT_USER_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    /**
     * Method to populate the region Drop down based on business selected
     *
     * @param helper
     * @throws Exception
     */
    void populateRegionList(UCCHelper helper) {
        Map<String, String> regionMap = new ActionHelper().getBusinessRelatedRegions(getSelectedBusinessIds());
        if (helper.getSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST) != null) {
            helper.removeSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST);
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, regionMap);
    }

    private List<String> getSelectedBusinessIds() {
        if (selectedUserDetails.getUserBusiness() != null )
            return new ActionHelper().getSelectedBusinessList(selectedUserDetails.getUserBusiness().getBusinessIds());
        else
            return new ActionHelper().getSelectedBusinessList(null);
    }

    private void getSelectedUserDetails(Map userMap, String selectedUserId) throws MCASException {
        selectedUserDetails = (UserDetails) userMap.get(selectedUserId);
        if (selectedUserDetails == null) {
            throw new MCASException("Selected User Details not found in User Map");
        }
    }

    private Map getUserMap(UCCHelper helper) throws MCASException {
        Map userMap = (Map) helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
        if (userMap == null) {
            throw new MCASException("User Map is null");
        }
        return userMap;
    }

    private String getSelectedUserId(UCCHelper helper) throws MCASException, IOException {
        String selectedUserId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_USER_ID);
        if (StringUtils.isNullOrEmpty(selectedUserId)) {
            throw new MCASException("UserId for edit is null");
        }
        return selectedUserId;
    }

    private void forward(UCCHelper helper, String forwardPage) throws IOException {
        helper.forward(forwardPage);
    }

    private void populateHelperParams(UCCHelper helper) throws Exception {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_USER_ID, selectedUserDetails.getUserId());
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_USER_NAME, selectedUserDetails.getUserName());
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_ROLE, String.valueOf(selectedUserDetails.getRoleId()));

        if ( selectedUserDetails.getUserRegion() != null )
            UserControllerHelper.populateSelectedRegions(helper, selectedUserDetails.getUserRegion().getUserRegionArray());
        else
            UserControllerHelper.populateSelectedRegions(helper, null);
        
        if ( selectedUserDetails.getUserBusiness() != null )
            UserControllerHelper.populateSelectedBusiness(helper, selectedUserDetails.getUserBusiness().getBusinessIds());
        else
            UserControllerHelper.populateSelectedBusiness(helper, null);

        String value = String.valueOf(selectedUserDetails.getBusinessId());
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS, value);

        String s = String.valueOf(selectedUserDetails.getBusinessPreferenceId());
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS_PREFERENCE_ID, s);

        helper.setSessionParameter(MCASConstants.HELPER_VAR_EDIT_ACTION, "true");
    }
}
