package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 6, 2006
 * Time: 9:36:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class DisplayUserAdminPageController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        try {
            populateBusinessList(helper);
            populateRegionsList(helper);
            populateRoleList(helper);

            clearRequiredSessionVaribles(helper);
            if (!MCASConstants.APPLICATION_NAME_MCAS.equals(helper.getSessionParameter("APPLICATION_NAME"))) {
                User user = (User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER);
                Map<String, String> regionsMap = new RegionServiceImpl().getRegionList(MCASUtil.getAuthenticatedUserID(helper), user.getBusinessId(), user.getLocale());
                helper.setSessionParameter(MCASConstants.HELPER_VAR_ALL_REGION_LIST, regionsMap);
            }
            helper.forward(MCASConstants.FORWARD_USER_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void populateRegionsList(UCCHelper helper) throws Exception {
        int businessId = getBusinessId(helper);
        String userId = MCASUtil.getAuthenticatedUserID(helper);
        String locale = MCASUtil.getUserLocale(helper);

        if (businessId != -1) {

            helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, new RegionServiceImpl().getRegionList(userId, businessId, locale));
        } else {
            UserControllerHelper.setDefaultRegions(helper);
        }
    }

    protected Map<String, String> getRegionList(String userId, int businessId, String locale) throws Exception {
        return new RegionServiceImpl().getRegionList(userId, businessId, locale);
    }

    protected Map<String, String> getAllRegionList(String locale) throws Exception {
        return new RegionServiceImpl().getAllRegionList(locale);
    }

    private void clearRequiredSessionVaribles(UCCHelper helper) {
        if (helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP) != null) {
            helper.removeSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
        }
        //Removing the session parameter as the region has to be populated based on the business selected.
        if (helper.getSessionParameter(MCASConstants.HELPER_VAR_ALL_REGION_LIST) != null) {
            helper.removeSessionParameter(MCASConstants.HELPER_VAR_ALL_REGION_LIST);
        }
    }

    protected Map<String, String> getRoleList(String userId, String locale) throws Exception {
        return new ActionHelper().getViewableRoleList(userId, locale);
    }


    private int getBusinessId(UCCHelper helper) throws IOException {
        String selectedBusiness = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS);
        int selectedBusinessIdInt = -1;
        if (selectedBusiness != null && !"".equals(selectedBusiness)) {
            selectedBusinessIdInt = Integer.parseInt(selectedBusiness);
        }
        return selectedBusinessIdInt;
    }

    private void populateRoleList(UCCHelper helper) throws MCASException {
        try {
            String userId = MCASUtil.getAuthenticatedUserID(helper);
            String userLocale = MCASUtil.getUserLocale(helper);
            Map<String, String> roleList = getRoleList(userId, userLocale);
            if (helper.getSessionParameter(MCASConstants.HELPER_VAR_ROLE_LIST) == null) {
                helper.setSessionParameter(MCASConstants.HELPER_VAR_ROLE_LIST, roleList);
            }
        }
        catch (Exception ex) {
            throw new MCASException("Error looking up the Role list: " + ex.getMessage(), ex);
        }
    }

    /**
     * Bhargava 04/10/08
     * Method to populate the business type into session variable
     *
     * @param helper
     * @throws Exception
     */
    private void populateBusinessList(UCCHelper helper) throws Exception {
        try {
            User user = (User) helper.getSessionParameter(User.USER);

            Map<String, String> businessTypeMap = new ActionHelper().getBusinessTypes(user.getLocale());
            if (helper.getSessionParameter(MCASConstants.BUSINESS_TYPE) == null) {
                helper.setSessionParameter(MCASConstants.BUSINESS_TYPE, businessTypeMap);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new MCASException("Exception in looking up Business Type :" + e.getMessage(), e);
        }
    }
}
