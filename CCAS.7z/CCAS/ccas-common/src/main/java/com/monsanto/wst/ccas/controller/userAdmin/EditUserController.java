package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.validations.MCASPageValidationUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 13, 2006 Time: 3:32:49 PM To change this template use File |
 * Settings | File Templates.
 */
public class EditUserController implements UseCaseController {

  private List<String> errorMessages = null;
  private Map<String, UserDetails> userMap = null;
  private UserDetails userDetails = null;

  public void run(UCCHelper helper) throws IOException {
    try {
      String userId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_ID);
      String userName = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_NAME);
      String roleId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE);
      String[] regionIds = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_REGION);
      String[] businessIds = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_BUSINESS);
      String locale = MCASUtil.getUserLocale(helper);

      //Get the User Preference
      String userBusinessPreference = helper
          .getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS_PREFERENCE_ID);
      Logger.log(new LoggableError("User Business Prefenece :" + userBusinessPreference));


      errorMessages = new MCASPageValidationUtil()
          .validateUserDetailsForEdit(roleId, regionIds, businessIds, userBusinessPreference, locale);
      if (errorMessages != null && errorMessages.size() > 0) {
        UserControllerHelper
            .populateAlreadyEnteredFields(helper, userId, userName, roleId, businessIds, userBusinessPreference,
                regionIds);
        populateErrorMessages(helper);
        forward(helper, MCASConstants.FORWARD_ADD_EDIT_USER_PAGE);
        return;
      }
      getEdittedUserDetails(userId, userName, roleId, regionIds, businessIds, helper, userBusinessPreference);
      editUserRecordInDatabase(userDetails, helper);
      userMap = (Map<String, UserDetails>) helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
      populateRequestParams(helper, userDetails);
      populateRegionDropdown(helper);
      UserControllerHelper.populateSelectedRegions(helper, regionIds);
      forward(helper, MCASConstants.FORWARD_USER_ADMIN_PAGE);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      MCASUtil.displayErrorPage(helper);
    }
  }

  /**
   * Method to populate the Region Drop down in Admin->user page
   *
   * @param helper
   *
   * @exception Exception
   */
  private void populateRegionDropdown(UCCHelper helper) throws Exception {
    User user = (User) helper.getSessionParameter(User.USER);
    String userId = user.getUser_id();
    int businessId = -1;
    String businessIdString = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS);
    if (businessIdString != null && !"".equals(businessIdString)) {
      businessId = Integer.parseInt(businessIdString);
      helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST,
          new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale()));
    } else {
      UserControllerHelper.setDefaultRegions(helper);
    }

  }

  protected void editUserRecordInDatabase(UserDetails userDetails, UCCHelper helper) throws DAOException,
      MCASException {
    UserAdminDAO dao = (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);
    dao.editUser(userDetails, MCASUtil.getAuthenticatedUserID(helper));
  }

  private void populateRequestParams(UCCHelper helper, UserDetails userDetails) {
    populateErrorMessages(helper);
    if (userMap == null) {
      userMap = new LinkedHashMap<String, UserDetails>();
    }
    userMap.put(this.userDetails.getUserId(), this.userDetails);
    helper.setSessionParameter(MCASConstants.HELPER_VAR_USER_MAP, userMap);
    populateParam(helper, MCASConstants.HELPER_VAR_SELECTED_ROLE, userDetails.getRoleId() + "");
    populateParam(helper, MCASConstants.HELPER_VAR_SELECTED_BUSINESS, "" + userDetails.getBusinessId());
  }

  private void getEdittedUserDetails(String userId, String userName, String roleId, String[] regionIds,
                                     String[] businessId, UCCHelper helper, String userBusinessPreference) {
    Map<String, String> roleList = (Map<String, String>) helper.getSessionParameter(MCASConstants.HELPER_VAR_ROLE_LIST);
    UserRegion userRegion = new UserRegion(userId, regionIds);
    UserBusiness userBusiness = new UserBusiness(userId, businessId);
    int businessIdInt = -1;
    int userBusinessPreferenceIdInt = -1;
    if (userBusinessPreference != null && userBusinessPreference.length() != 0) {
      userBusinessPreferenceIdInt = Integer.parseInt(userBusinessPreference);
    }
    if (userBusiness != null) {
      String[] businessIdArr = userBusiness.getBusinessIds();
      businessIdInt = Integer.parseInt(businessIdArr[0]);
    }
    userDetails = new UserDetails(userId.trim().toUpperCase(), userName, Integer.parseInt(roleId), roleList.get(roleId),
        userRegion, "", businessIdInt, userBusinessPreferenceIdInt);
    userDetails.setUserBusiness(userBusiness);
  }

  private void forward(UCCHelper helper, String forwardPage) throws IOException {
    helper.forward(forwardPage);
  }

  private void populateParam(UCCHelper helper, String paramName, String paramValue) {
    UserControllerHelper.populateParam(helper, paramName, paramValue);
  }

  private void populateErrorMessages(UCCHelper helper) {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
  }
}
