package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.wst.ccas.service.UserAdminService;
import com.monsanto.wst.ccas.service.UserAdminServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.ajax.AJAXException;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: Bhargava
 * Date: Apr 14, 2008
 * Time: 10:30:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class RegionBusinessPOS extends AJAXUseCaseController {

  protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
    DOMUtil.outputXML(inputDocument);

    UserAdminService userAdminService = new UserAdminServiceImpl();

    Document regionsForBusiness = null;
    try {
      regionsForBusiness = userAdminService.getRegionOnBusinessChange(inputDocument);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
//            throw new IOException(e.getMessage(), e);
    }
    helper.writeXMLDocument(regionsForBusiness);
  }
}
