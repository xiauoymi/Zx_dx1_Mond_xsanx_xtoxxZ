package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 10, 2006 Time: 9:57:22 AM To change this template use File |
 * Settings | File Templates.
 */
public class ShowUserController implements UseCaseController {

  private final List<String> errorMessages = new ArrayList();
  private final Map<String, UserDetails> userMap = new LinkedHashMap();
  private UserDetails userDetails = null;
  private String userName = null;
  private String userId = null;

  public void run(UCCHelper helper) throws IOException {
    try {
      userId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_ID);
      if (validateUserId(helper)) {
        return;
      } else {
        userId = userId.trim().toUpperCase();
      }
      userName = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_NAME);
      userDetails = getSpecificUserDetails(userId, helper);
      if (userNotFound(helper)) {
        return;
      }
      populateRequestParams(helper);
      forward(helper, MCASConstants.FORWARD_USER_ADMIN_PAGE);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      MCASUtil.displayErrorPage(helper);
    }
  }

  /**
   * Method to check for existence of the searched user
   *
   * @param helper
   *
   * @return
   *
   * @exception IOException
   */
  private boolean userNotFound(UCCHelper helper) throws IOException {
    boolean userNotFound = false;
    String locale = ((User) helper.getSessionParameter(User.USER)).getLocale();

    if (StringUtils.isNullOrEmpty(userDetails.getUserId())) {
      String msg = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.userNotFound");
      addErrorMessage(helper, msg);
      userNotFound = true;
    }
    return userNotFound;
  }

  /**
   * method to check if a user ID is input during a search
   *
   * @param helper
   *
   * @return
   *
   * @exception IOException
   */
  private boolean validateUserId(UCCHelper helper) throws IOException {
    boolean isUserIdEmpty = false;
    String locale = ((User) helper.getSessionParameter(User.USER)).getLocale();

    if (StringUtils.isNullOrEmpty(userId)) {
      String msg = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectUser");
      addErrorMessage(helper, msg);
      isUserIdEmpty = true;
    }
    return isUserIdEmpty;
  }

  /**
   * Private method to add Error messages
   *
   * @param helper
   * @param message
   *
   * @exception IOException
   */
  private void addErrorMessage(UCCHelper helper, String message) throws IOException {
    errorMessages.add(message);
    populateErrorMessages(helper);
    forward(helper, MCASConstants.FORWARD_USER_ADMIN_PAGE);
  }

  protected UserDetails getSpecificUserDetails(String queriedUserId, UCCHelper helper) throws MCASException {
    try {
      String loggedUserId = MCASUtil.getAuthenticatedUserID(helper);
      String locale = MCASUtil.getUserLocale(helper);
      UserAdminDAO userAdminDAO = (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);
      return userAdminDAO.getSpecificUserDetails(queriedUserId, loggedUserId, locale);
    } catch (DAOException e) {
      throw new MCASException("DAO Exception while getting user details: " + e.getMessage(), e);
    }
  }

  private void populateErrorMessages(UCCHelper helper) {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
  }

  private void forward(UCCHelper helper, String forwardPage) throws IOException {
    helper.forward(forwardPage);
  }

  private void populateRequestParams(UCCHelper helper) {
    populateErrorMessages(helper);
    if (userDetails != null) {
      userMap.put(userDetails.getUserId(), userDetails);
    }
    helper.setSessionParameter(MCASConstants.HELPER_VAR_USER_MAP, userMap);
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_USER_ID, userId);
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_USER_NAME, userName);
  }
}
