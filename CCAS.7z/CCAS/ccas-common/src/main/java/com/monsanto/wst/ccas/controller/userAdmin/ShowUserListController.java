package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 11, 2006
 * Time: 1:19:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class ShowUserListController implements UseCaseController {

    private String selectedRole = null;
    private String selectedRegion = null;
    private String[] selectedBusiness = null;
    private Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
    private Map<String, String> regionsMap = new LinkedHashMap<String, String>();

    public void run(UCCHelper helper) throws IOException {
        try {
            ActionHelper actionHelper = new ActionHelper();
            selectedBusiness = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_BUSINESS);
            regionsMap = actionHelper.getBusinessRelatedRegions(actionHelper.getSelectedBusinessList(selectedBusiness));
            selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);
            selectedRole = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE);
            String[] regionIds = helper.getRequestParameterValues(MCASConstants.HELPER_VAR_SELECTED_REGION);
            userMap = getUserList(selectedRole, regionIds, helper, selectedBusiness);
            populateRegionDropdown(helper);
            populateRequestParams(helper);
            UserControllerHelper.populateSelectedRegions(helper, regionIds);
            UserControllerHelper.populateSelectedBusiness(helper, selectedBusiness);
            forward(helper, MCASConstants.FORWARD_USER_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    Map<String, UserDetails> getUserList(String selectedRole, String[] selectedRegions, UCCHelper helper, String[] businessIds) throws MCASException {
        try {
            String userId = MCASUtil.getAuthenticatedUserID(helper);
            String userLocale = MCASUtil.getUserLocale(helper);
            UserAdminDAO userAdminDAO = (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);
            return userAdminDAO.getUserList(selectedRole, selectedRegions, userId, businessIds, regionsMap, userLocale);
        } catch (DAOException e) {
            throw new MCASException("DAO Exception while getting user details: " + e.getMessage(), e);
        }
    }

    private void populateRequestParams(UCCHelper helper) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS, selectedBusiness);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION, selectedRegion);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_ROLE, selectedRole);

        if (userMap == null) {
            userMap = new LinkedHashMap();
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_USER_MAP, userMap);

    }

    private void forward(UCCHelper helper, String forwardPage) throws IOException {
        helper.forward(forwardPage);
    }

    private void populateRegionDropdown(UCCHelper helper) throws MCASException {
        try {
            if (!UserControllerHelper.isBusinessNull(selectedBusiness) && !StringUtils.isNullOrEmpty(selectedRegion)) {
                helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, regionsMap);
            } else {
                UserControllerHelper.setDefaultRegions(helper);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new MCASException("Exception getting Business Specific Region List " + e.getMessage(), e);
        }
    }
}
