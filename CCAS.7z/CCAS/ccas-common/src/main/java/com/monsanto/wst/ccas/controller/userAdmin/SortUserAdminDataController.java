package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.ComparatorFactory;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.SortUtil;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 8:39:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class SortUserAdminDataController implements UseCaseController {

    private String index = null;
    private Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
    private String selectedRole = null;
    private String selectedRegion = null;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            String sortOrder = SortUtil.determineCurrentSortOrder(index,
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_INDEX),
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_ORDER)
            );
            SortUtil.populatePrevSortOrderAndIndex(helper, index, sortOrder);
            sortUserAdminData(index, sortOrder, userMap);
            populateHelperVariables(helper, userMap);
            helper.forward(MCASConstants.FORWARD_USER_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void getHelperParams(UCCHelper helper) throws IOException {
        selectedRole = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_ROLE);
        selectedRegion = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION);
        index = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SORT_INDEX);
        userMap = (Map<String, UserDetails>) helper.getSessionParameter(MCASConstants.HELPER_VAR_USER_MAP);
    }

    private void populateHelperVariables(UCCHelper helper, Map<String, UserDetails> userMap) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_ROLE, selectedRole);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION, selectedRegion);
        if (userMap == null) {
            userMap = new LinkedHashMap();
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_USER_MAP, userMap);
    }

    private void sortUserAdminData(String index, String sortOrder, Map<String, UserDetails> userMap) throws MCASException {
        if (userMap != null) {
            Vector<UserDetails> dataVector = new Vector<UserDetails>();
            for (String s : userMap.keySet()) {
                dataVector.add(userMap.get(s));
            }
            userMap.clear();
            BaseComparator userAdminComparator = (BaseComparator) ComparatorFactory.getComparator(index, sortOrder);
            Collections.sort(dataVector, userAdminComparator);
            int size = dataVector.size();
            for (int i = 0; i < size; i++) {
                UserDetails userDetails = dataVector.get(i);
                userMap.put(userDetails.getUserId(), userDetails);
            }
        }
    }
}
