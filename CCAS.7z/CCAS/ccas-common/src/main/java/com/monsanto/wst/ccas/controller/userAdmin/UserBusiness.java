package com.monsanto.wst.ccas.controller.userAdmin;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Mar 23, 2009
 * Time: 12:50:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserBusiness {

    private String userId;
    private String[] businessIds;

    public UserBusiness(String userId, String[] businessIds) {
        this.userId = userId;
        this.businessIds = businessIds;
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String[] getBusinessIds() {
        return businessIds;
    }

    public void setBusinessIds(String[] businessIds) {
        this.businessIds = businessIds;
    }


}
