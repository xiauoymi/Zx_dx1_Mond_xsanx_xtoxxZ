package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.util.*;

/**
 * Date: Aug 20, 2008
 * Time: 10:05:22 AM
 */
class UserControllerHelper {

    static void populateSelectedRegions(UCCHelper helper, String[] selectedRegions) {
        List<String> selectedRegionList = new ArrayList<String>(1);
        if (selectedRegions != null && selectedRegions.length > 0) {
            selectedRegionList.addAll(Arrays.asList(selectedRegions));
            helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_REGION_LIST, selectedRegionList);
        }
    }

    static void populateSelectedBusiness(UCCHelper helper, String[] businessIds) throws Exception {
        List<String> selectedBusinessList = new ArrayList<String>();
        if (businessIds != null && businessIds.length > 0) {
            selectedBusinessList.addAll(Arrays.asList(businessIds));
            helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SELECTED_BUSINESS_LIST, selectedBusinessList);
        }
        if (helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SELECTED_REGION) != null) {
            setBusinessRelatedRegionList(helper, selectedBusinessList);
        }
    }

    private static void setBusinessRelatedRegionList(UCCHelper helper, List<String> selectedBusinessList) {
        if (!selectedBusinessList.isEmpty()) {
            String[] selectedBusinessIds = new String[selectedBusinessList.size()];
            if (!isBusinessNull(selectedBusinessList.toArray(selectedBusinessIds))) {
                helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, new ActionHelper().getBusinessRelatedRegions(selectedBusinessList));
            } else {
                setDefaultRegions(helper);
            }
        }
    }

    static void setDefaultRegions(UCCHelper helper) {

        String locale = MCASUtil.getUserLocale(helper);
        Map<String, String> regionMap = new HashMap<String, String>();
        regionMap.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.NA"));
        helper.setSessionParameter(MCASConstants.HELPER_VAR_REGION_LIST, regionMap);

    }

    static void populateAlreadyEnteredFields(UCCHelper helper, String userId, String userName, String roleId, String[] businessIds, String userPref, String[] regionIds) throws Exception {
        populateParam(helper, MCASConstants.HELPER_VAR_USER_ID, userId);
        populateParam(helper, MCASConstants.HELPER_VAR_USER_NAME, userName);
        populateParam(helper, MCASConstants.HELPER_VAR_SELECTED_ROLE, roleId);
        populateSelectedBusiness(helper, businessIds);
        populateParam(helper, MCASConstants.USER_COMPANY_PREFERENCE, userPref);
        populateSelectedRegions(helper, regionIds);
    }

    static void populateParam(UCCHelper helper, String paramName, String paramValue) {
        if (!StringUtils.isNullOrEmpty(paramValue)) {
            helper.setRequestAttributeValue(paramName, paramValue);
        }
    }

    public static boolean isBusinessNull(String[] businessIds) {
        return businessIds == null || (businessIds.length == 1 && businessIds[0].equalsIgnoreCase(""));
    }
}
