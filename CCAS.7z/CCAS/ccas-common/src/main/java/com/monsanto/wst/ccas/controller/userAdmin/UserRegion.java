package com.monsanto.wst.ccas.controller.userAdmin;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 19, 2008
 * Time: 1:22:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserRegion {

    private final String userId;
    private String[] userRegionArray;
    private String multipleRegionsDescription;

    public UserRegion(String userId) {
        this.userId = userId;
    }

    public UserRegion(String userId, String[] userRegionArray) {
        this.userId = userId;
        this.userRegionArray = userRegionArray;
    }

    public String[] getUserRegionArray() {
        return userRegionArray;
    }

    public void setUserRegionArray(String[] userRegionArray) {
        this.userRegionArray = userRegionArray;
    }

    public String getUserId() {
        return userId;
    }

    public String getMultipleRegionsDescription() {
        return multipleRegionsDescription;
    }

    public void setMultipleRegionsDescription(String multipleRegionsDescription) {
        this.multipleRegionsDescription = multipleRegionsDescription;
    }
}
