package com.monsanto.wst.ccas.controller.userAdmin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.ProgramConstants;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.Program;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.service.ServiceLocator;
import com.monsanto.wst.ccas.service.UserAccountService;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 11, 2006
 * Time: 1:19:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidateUserInSystemController implements UseCaseController {

    private String selectedRole = null;
    private String selectedRegion = null;
    private String[] selectedBusiness = null;
    private Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
    private Map<String, String> regionsMap = new LinkedHashMap<String, String>();

    public void run(UCCHelper helper) throws IOException {
        try {

            String userId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_USER_ID);
            UserAccountService us = (UserAccountService) ServiceLocator.locateService(UserAccountService.class);
           String appName = (String)helper.getSessionParameter("APPLICATION_NAME");
            User userSystem= (User)helper.getSessionParameter(User.USER);
            boolean validate=true;
            if(!appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_MCAS)){
                validate=false;
            }
            else if(userSystem.getBusinessId()!=MCASConstants.BUSINESS_ID_VEGETABLE){
                validate=false;
            }
            User user= new User(null);
            user.setUser_id(userId);
             boolean isValid=true;
            if(validate){
                user = us.getUserInfo(user);
                if(user.getPermissionsMap().size()==0){
                    isValid=false;
                    }
                }



            Document responseDocument = createResponseDocument(isValid?"Y":"N");
            helper.setContentType("text/xml");
            helper.writeXMLDocument(responseDocument, MCASConstants.LATIN1_ENCODING);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }


   private Document createResponseDocument(String isValid) {
        Document document = DOMUtil.newDocument();
        Element root = DOMUtil.addChildElement(document, "response");
        Element issueType = DOMUtil.addChildElement(root, "valid");
            DOMUtil.addChildElement(issueType, "description", isValid);

        return document;
    }

}
