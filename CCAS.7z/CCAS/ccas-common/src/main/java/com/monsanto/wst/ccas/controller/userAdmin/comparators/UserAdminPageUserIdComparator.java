package com.monsanto.wst.ccas.controller.userAdmin.comparators;

import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 9:05:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserAdminPageUserIdComparator extends BaseComparator {

    public UserAdminPageUserIdComparator(String sortOrder) {
        super.sortOrder = sortOrder;
    }

    public int compare(Object obj1, Object obj2) {
        setTokens(obj1, obj2);
        return compareTokens();
    }

    private void setTokens(Object obj1, Object obj2) {
        String tokenA;
        String tokenB;

        tokenA = ((UserDetails) obj1).getUserId() != null ?
                ((UserDetails) obj1).getUserId().trim() : "";
        tokenB = ((UserDetails) obj2).getUserId() != null ?
                ((UserDetails) obj2).getUserId().trim() : "";

        super.setaToken(tokenA);
        super.setbToken(tokenB);
    }
}