/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.controller.varietyBatchController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.VarietyBatchDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: SaveUpdateVarietyBatchController.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class SaveUpdateVarietyBatchController implements UseCaseController {

  public void run(UCCHelper helper) throws IOException {
    try {

      String locale = MCASUtil.getUserLocale(helper);
      String varietyDesc = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_VARIETY_DESC);
      String batchNumber = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_NUMBER);
      if (StringUtils.isNullOrEmpty(varietyDesc) && StringUtils.isNullOrEmpty(batchNumber)) {
        List<String> errorMessages = new ArrayList<String>();
        errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.enterVarietyBatch"));
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
        helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_ADD_EDIT_PAGE);
        return;
      }
      VarietyBatch varietyBatch = new VarietyBatch(null, varietyDesc, batchNumber);
      insertUpdateVarietyBatch(varietyBatch);
      populateSucessMessage(helper);
      helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_ADD_EDIT_PAGE);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      MCASUtil.displayErrorPage(helper);
    }
  }

  private void populateSucessMessage(UCCHelper helper) {

    String locale = MCASUtil.getUserLocale(helper);
    List<String> successMessages = new ArrayList<String>();
    successMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.success.varietySaved"));
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_SUCCESS_MESSAGES, successMessages);
  }

  protected VarietyBatchDAO getVarietyBatchDAO() throws DAOException {
    return (VarietyBatchDAO) DAOFactory.getDao(VarietyBatchDAO.class);
  }

  private void insertUpdateVarietyBatch(VarietyBatch varietyBatch) throws DAOException, MCASException {
    VarietyBatchDAO dao = getVarietyBatchDAO();
    List<VarietyBatch> varietyBatchList = new ArrayList<VarietyBatch>();
    varietyBatchList.add(varietyBatch);
    dao.insertVarietyBatch(varietyBatchList);
  }
}
