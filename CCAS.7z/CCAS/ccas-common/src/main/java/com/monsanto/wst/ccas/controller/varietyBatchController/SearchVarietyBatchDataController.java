/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.controller.varietyBatchController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.VarietyBatchDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.ClaimsVerification;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: SearchVarietyBatchDataController.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class SearchVarietyBatchDataController implements UseCaseController {

    private String varietyPattern = null;
    private String batchPattern = null;
    private String cropName = null;
    private String business=null;
    private String region_id=null;
    private String claimNumber = null;

    private final List<String> errorMessages = new ArrayList<String>();

    public void run(UCCHelper helper) throws IOException {
        try {
            populateOpenerTextBoxIds(helper);
            varietyPattern = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN);
            batchPattern = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_PATTERN);
            cropName= helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_CROP_NAME);
            business=helper.getRequestParameterValue("business");
            region_id=helper.getRequestParameterValue("region_id");
            claimNumber=helper.getRequestParameterValue("claimNumber");
            if (neitherVarietyOrBatchPatternEntered()) {
                populateErrorMessage(helper);
                forward(helper);
                return;
            }
            //Check for "*" character in either of these.
            //If it contains only *, raise an error
            if (varietyOrBatchIsAsteriskOnly()) {
                populateErrorMessageForInvalidEntry(helper);
                forward(helper);
                return;
            }
            populateSearchResult(helper);
            repopulateSearchData(helper);
            forward(helper);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void populateErrorMessageForInvalidEntry(UCCHelper helper) {
        String locale = MCASUtil.getUserLocale(helper);
        errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.invalicSearchPattern"));
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
    }

    /**
     * Method to check for * entry in either variety or batch
     *
     * @return
     */
    private boolean varietyOrBatchIsAsteriskOnly() {

        if (!StringUtils.isNullOrEmpty(varietyPattern)) {
            if (varietyPattern.equals("*")) {
                return true;
            }
        }
        if (!StringUtils.isNullOrEmpty(batchPattern)) {
            if (batchPattern.equals("*")) {
                return true;
            }
        }
        return false;
    }

    private void forward(UCCHelper helper) throws IOException {
        helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_POPUP_PAGE);
    }

    private void populateErrorMessage(UCCHelper helper) {

        String locale = MCASUtil.getUserLocale(helper);
        errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.enterSearchPattern"));
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
    }

    private void repopulateSearchData(UCCHelper helper) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN, varietyPattern);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_BATCH_PATTERN, batchPattern);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_CLAIM_NUMBER, claimNumber);

    }

    private void populateSearchResult(UCCHelper helper) throws DAOException, MCASException {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_VARIETY_BATCH_MAP,
                getVarietyBatchData(getVarietyBatchDAOImpl()));
    }

    private boolean neitherVarietyOrBatchPatternEntered() {
        return StringUtils.isNullOrEmpty(varietyPattern) && StringUtils.isNullOrEmpty(batchPattern);
    }

    private void populateOpenerTextBoxIds(UCCHelper helper) throws IOException, MCASException {
        String openerVarietyDescTextBoxId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_VARIETY_DESC_TEXT_BOX_ID);
        String openerBatchNumberTextBoxId = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_NUMBER_TEXT_BOX_ID);
        validateParams(openerVarietyDescTextBoxId, openerBatchNumberTextBoxId);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_VARIETY_DESC_TEXT_BOX_ID,
                openerVarietyDescTextBoxId);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_BATCH_NUMBER_TEXT_BOX_ID,
                openerBatchNumberTextBoxId);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_CLAIM_NUMBER, claimNumber);
    }

    private void validateParams(String openerVarietyDescTextBoxId, String openerBatchNumberTextBoxId) throws MCASException {
        if (StringUtils.isNullOrEmpty(openerVarietyDescTextBoxId)) {
            throw new MCASException("Request parameter 'varietyDescTextId' not found (that is supposed to be sent " +
                    "from the popup-opener page).");
        }
        if (StringUtils.isNullOrEmpty(openerBatchNumberTextBoxId)) {
            throw new MCASException("Request parameters 'batchNumberTextId' not found (that is supposed to be sent " +
                    "from the popup-opener page).");
        }
    }

    protected VarietyBatchDAO getVarietyBatchDAOImpl() throws DAOException {
        return (VarietyBatchDAO) DAOFactory.getDao(VarietyBatchDAO.class);
    }

    private Map<String, VarietyBatch> getVarietyBatchData(VarietyBatchDAO varietyBatchDAO) throws DAOException, MCASException {
        if((business!=null&&business.equalsIgnoreCase(""+MCASConstants.BUSINESS_ID_ROW_CROP)
                && ClaimsVerification.isCropVarietyBatchConsult(claimNumber,region_id))){
            return varietyBatchDAO.getVarietyBatchDataValidCrop(varietyPattern, batchPattern,cropName);
        }
        else{
            return varietyBatchDAO.getVarietyBatchData(varietyPattern, batchPattern);
        }

    }


}