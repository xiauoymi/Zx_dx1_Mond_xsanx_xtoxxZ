/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.controller.varietyBatchController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.VarietyBatchDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ShowVarietyBatchListController.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class ShowVarietyBatchListController implements UseCaseController {

  private final List<String> errorMessages = new ArrayList<String>();

  public void run(UCCHelper helper) throws IOException {
    try {
      String varietyPattern = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN);
      String batchPattern = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_PATTERN);
      if (StringUtils.isNullOrEmpty(varietyPattern) && StringUtils.isNullOrEmpty(batchPattern)) {
        performValidationFailureAction(helper);
        return;
      }
      VarietyBatchDAO dao = getVarietyBatchDAOImpl();
      setHelperParams(helper, varietyPattern, batchPattern, dao);
      helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_ADMIN_PAGE);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      MCASUtil.displayErrorPage(helper);
    }
  }

  private void setHelperParams(UCCHelper helper, String varietyPattern, String batchPattern, VarietyBatchDAO dao) throws
      DAOException, MCASException {
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN, varietyPattern);
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_BATCH_PATTERN, batchPattern);
    helper.setSessionParameter(MCASConstants.HELPER_VAR_VARIETY_BATCH_MAP,
        dao.getVarietyBatchData(varietyPattern, batchPattern));
  }

  protected VarietyBatchDAO getVarietyBatchDAOImpl() throws DAOException {
    return (VarietyBatchDAO) DAOFactory.getDao(VarietyBatchDAO.class);
  }

  private void performValidationFailureAction(UCCHelper helper) throws IOException {

    String locale = MCASUtil.getUserLocale(helper);
    errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.enterSearchPattern"));
    helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_ERROR_MESSAGES, errorMessages);
    helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_ADMIN_PAGE);
  }
}
