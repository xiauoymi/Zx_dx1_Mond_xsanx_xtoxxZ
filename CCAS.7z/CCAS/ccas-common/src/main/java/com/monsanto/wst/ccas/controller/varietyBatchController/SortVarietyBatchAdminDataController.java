/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.controller.varietyBatchController;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.BaseComparator;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.ComparatorFactory;
import com.monsanto.wst.ccas.util.sortColumnDataUtil.SortUtil;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

/**
 * Filename:    $RCSfile: SortVarietyBatchAdminDataController.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class SortVarietyBatchAdminDataController implements UseCaseController {

    private String index = null;
    private Map<String, VarietyBatch> varietyBatchMap = new LinkedHashMap<String, VarietyBatch>();
    private String enteredVarietyDesc = null;
    private String enteredBatchNumber = null;

    public void run(UCCHelper helper) throws IOException {
        try {
            getHelperParams(helper);
            String sortOrder = SortUtil.determineCurrentSortOrder(index,
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_INDEX),
                    (String) helper.getSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_ORDER)
            );
            SortUtil.populatePrevSortOrderAndIndex(helper, index, sortOrder);
            sortVarietyBatchData(index, sortOrder, varietyBatchMap);
            populateHelperVariables(helper, varietyBatchMap);
            helper.forward(MCASConstants.FORWARD_VARIETY_BATCH_ADMIN_PAGE);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            MCASUtil.displayErrorPage(helper);
        }
    }

    private void getHelperParams(UCCHelper helper) throws IOException {
        enteredVarietyDesc = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN);
        enteredBatchNumber = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_BATCH_PATTERN);
        index = helper.getRequestParameterValue(MCASConstants.HELPER_VAR_SORT_INDEX);
        varietyBatchMap = (Map<String, VarietyBatch>) helper.getSessionParameter(MCASConstants.HELPER_VAR_VARIETY_BATCH_MAP);
    }

    private void populateHelperVariables(UCCHelper helper, Map<String, VarietyBatch> varietyBatchMap) {
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_VARIETY_PATTERN, enteredVarietyDesc);
        helper.setRequestAttributeValue(MCASConstants.HELPER_VAR_BATCH_PATTERN, enteredBatchNumber);
        if (varietyBatchMap == null) {
            varietyBatchMap = new LinkedHashMap<String, VarietyBatch>();
        }
        helper.setSessionParameter(MCASConstants.HELPER_VAR_VARIETY_BATCH_MAP, varietyBatchMap);
    }

    private void sortVarietyBatchData(String index, String sortOrder, Map<String, VarietyBatch> varietyBatchMap) throws MCASException {
        if (varietyBatchMap != null) {
            Vector<VarietyBatch> dataVector = new Vector<VarietyBatch>();
            for (String s : varietyBatchMap.keySet()) {
                dataVector.add(varietyBatchMap.get(s));
            }
            varietyBatchMap.clear();
            BaseComparator varietyBatchAdminComparator = (BaseComparator) ComparatorFactory.getComparator(index, sortOrder);
            Collections.sort(dataVector, varietyBatchAdminComparator);
            int size = dataVector.size();
            for (int i = 0; i < size; i++) {
                VarietyBatch varietyBatch = dataVector.get(i);
                varietyBatchMap.put(String.valueOf(i), varietyBatch);
            }
        }
    }
}
