package com.monsanto.wst.ccas.cpar;

import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.IsoStandardServiceImpl;
import com.monsanto.wst.ccas.service.IsoStandardService;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ajax.AJAXException;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jul 3, 2011
 * Time: 7:05:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class IsoStandardPOS extends AJAXUseCaseController {

  @Override
    protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
        String locale = ((User) helper.getSessionParameter(User.USER)).getLocale();

        DOMUtil.outputXML(inputDocument);
        IsoStandardService isoStandardService = new IsoStandardServiceImpl();
        //todo: figure out business
        Document standards = isoStandardService.getQualityProgramRelatedIsoStandard(inputDocument, 2, locale);
        //

        helper.writeXMLDocument(standards, MCASConstants.LATIN1_ENCODING);
    }
}
