package com.monsanto.wst.ccas.cpar;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ajax.AJAXException;
import com.monsanto.wst.ccas.common.AJAXUseCaseController;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.IssueService;
import com.monsanto.wst.ccas.service.IssueServiceImpl;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 6, 2010 Time: 3:19:50 PM To change this template use File |
 * Settings | File Templates.
 */
public class IssuesPOS extends AJAXUseCaseController {
    @Override
    protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
//    String locale = ((User) helper.getSessionParameter(User.USER)).getLocale();

        DOMUtil.outputXML(inputDocument);
//    IssueService salesOfficeService = new IssueServiceImpl();
//    Document functionsForLocation = salesOfficeService.getRegionRelatedSalesOffices(inputDocument, locale);
//    DOMUtil.outputXML(functionsForLocation);
//    helper.writeXMLDocument(functionsForLocation);

    }
}
