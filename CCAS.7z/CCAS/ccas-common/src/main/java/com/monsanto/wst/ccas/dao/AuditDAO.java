/*
 * Created on Apr 8, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.util.List;
import java.util.Map;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuditDAO {

    public String insertAudit(AuditObject auditObj,String appName) throws DAOException;

    public boolean updateAudit(AuditObject auditObj) throws DAOException;

    public FindingObject insertFinding(String auditNumber, FindingObject FindingObj) throws DAOException;

    public boolean updateFinding(FindingObject FindingObj) throws DAOException;

    public AuditObject getAudit(String findingID, String locale) throws DAOException;

    public AuditObject getAuditFromList(String auditNo, String locale) throws DAOException;

    public Map<String, Object> getAuditList(AuditListObject filterObj, String intPage, String sortCriteria,
                                            String sortOrder, int userBusinessPreferenceId, String applicationName) throws DAOException;

    public String getAuditNumberFromFinding(int findingID) throws DAOException;

    public Map<String, RowBean> getAuditReport(AuditFilter auditFilter, String locale) throws DAOException;

    boolean addAuditAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException;

    boolean deleteAuditAttachmentInfo(String documentId) throws DAOException;

    List<Cpar> getCARList(String auditId) throws DAOException;

    void deleteAudit(String auditNumber) throws DAOException;

    int deleteAuditFinding(String auditId, String findingId) throws DAOException;

    void closeFinding(FindingObject f) throws DAOException;

  void updateReasonForFinding(FindingObject f) throws DAOException;
}
