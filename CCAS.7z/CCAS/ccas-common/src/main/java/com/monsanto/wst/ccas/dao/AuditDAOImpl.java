/*
 * Created on Apr 8, 2005
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.LookUpServiceImpl;
import com.monsanto.wst.ccas.service.LookUpService;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author rdesai2
 */
public class AuditDAOImpl extends BaseDAOImpl implements AuditDAO {

  //**Log4j logger
  private static final Category logger = Category.getInstance(AuditDAOImpl.class.getName());
  FunctionalAreaDaoImpl aaDao = new FunctionalAreaDaoImpl();

  private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
  public static final String AUDIT_LOCATION_OTHER_INFO_ID_PREFIX = "A-";
  private static final String SBFAS_BUSINESS_QUERY = "SELECT TRIM(DESCRIPTION) AS DESCRIPTION FROM BUSINESS WHERE BUSINESS_ID=";


  /**
   * Constructor.
   *
   * @exception DAOException
   */
  public AuditDAOImpl() {

  }

  public FindingObject insertFinding(String auditNumber, FindingObject findingObj) throws DAOException {

//        logger.info("AuditDAO: Executing insertFinding() operation...");

    //**Imp Variables...
    Date oracleSysdate;
    String autoAuditNumber = auditNumber;
    int auditID = 0;
    int auditFindingID = 0;
    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try {
      conn = getConnection();
      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get audit-id for the given audit-number
      auditID = getAuditID(autoAuditNumber, conn);

      //**Get audit-finding-seq
      auditFindingID = getAuditFindingSeq(conn);

      //**Perform Insert-Operation...
      insertFindingObject(auditFindingID, auditID, oracleSysdate, findingObj, conn);
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, rs);
    }

    FindingObject resultObj = new FindingObject();

    resultObj.setFindingID(auditFindingID + "");
    resultObj.setFindingDesc(findingObj.getFindingDesc());
    resultObj.setCparID(findingObj.getCparID());
    resultObj.setControlNumber(findingObj.getControlNumber());
    resultObj.setRowUserID(findingObj.getRowUserID());
    resultObj.setShortFindingDesc(findingObj.getShortFindingDesc());

    return resultObj;
  }

  protected LocationOtherInfoDao getLocationOtherInfoDao(Connection con) {
    return new LocationOtherInfoDaoImpl(con);
  }


  public AuditObject getAudit(String findingID, String locale) throws DAOException {

//        logger.info("AuditDAO: Executing getAudit() operation...");

    //**Imp Variables...
    int auditID = 0;
    int auditFindingID = Integer.parseInt(findingID);

    Connection conn = null;

    //**Get Connection...
    try {
      conn = getConnection();

      AuditObject audit = new AuditObject();

      //**Get audit-id for the given audit-findig-id...
      auditID = getAuditFromFinding(auditFindingID, conn);

      //**Get audit-details...
      getAuditDetails(auditID, audit, conn);

      //**Get audit-areas...
      getFunctionalAreas(auditID, audit, conn);

      //**Get audit-finding-details...
      getFindingDetails(auditID, audit, conn, locale);

      getAdditionalAuditorsForThisAudit(audit, conn);
      getSubFunctionRelatedToThisAudit(audit, conn);
      audit.setLocationOtherInfo(
          getLocationOtherInfoDao(conn).read(AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + audit.getAuditID()));
      return audit;

    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, null, null);
    }
  }

  private void getAdditionalAuditorsForThisAudit(AuditObject audit, Connection conn) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    String auditorOne = "";
    String auditorTwo = "";
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_AUDITORS);
      ps.setString(1, audit.getAuditID());
      rs = ps.executeQuery();
      while (rs.next()) {
        auditorOne = rs.getString("AUDITOR_ONE");
        audit.setAuditorOne(StringUtils.isNullOrEmpty(auditorOne) ? "" : auditorOne);
        auditorTwo = rs.getString("AUDITOR_TWO");
        audit.setAuditorTwo(StringUtils.isNullOrEmpty(auditorTwo) ? "" : auditorTwo);
      }
    } catch (SQLException e) {
      MCASLogUtil.logError(e.getMessage(), e);
      throw new DAOException("Error in getAdditionalAuditorsForThisAudit()", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  private void getSubFunctionRelatedToThisAudit(AuditObject audit, Connection conn) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_SUBFUNCTION);
      ps.setInt(1, Integer.parseInt(audit.getAuditID()));

      rs = ps.executeQuery();
      StringBuffer subFunctionSelected = new StringBuffer();

      while (rs.next()) {
        subFunctionSelected.append(rs.getString(1)).append(",");
      }
      String[] subFunctions = subFunctionSelected.toString().split(",");
      audit.setSubFunctionsSelected(subFunctions);
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting sub function details: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }


  public AuditObject getAuditFromList(String auditNo, String locale) throws DAOException {
//        logger.info("AuditDAO: Executing getAuditFromList() operation...");
    int auditID = 0;
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      conn = getConnection();
      AuditObject audit = new AuditObject();
      auditID = getAuditID(auditNo, conn);
      getAuditDetails(auditID, audit, conn);
      getFunctionalAreas(auditID, audit, conn);
      getFindingDetails(auditID, audit, conn, locale);
      getAuditAttachments(auditID, audit, conn);
      getAdditionalAuditorsForThisAudit(audit, conn);
      getSubFunctionRelatedToThisAudit(audit, conn);
      audit.setLocationOtherInfo(
          getLocationOtherInfoDao(conn).read(AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + audit.getAuditID()));
      return audit;
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, rs);
    }
  }

  public String getAuditNumberFromFinding(int findingID) throws DAOException {

//        logger.info("AuditDAO: Executing getAuditFromList() operation...");

    //**Imp Variables...
    String auditNumber = "";

    Connection conn = null;

    PreparedStatement ps = null;
    ResultSet rs = null;


    //**Get Connection...
    try {
      conn = getConnection();
//            System.out.println("*********************** = " + findingID);
      auditNumber = getAuditNoFromFinding(findingID, conn);
//            System.out.println(" Audit Number************* " + auditNumber);
      return auditNumber;

    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, rs);
    }
  }


  public void closeFinding(FindingObject f) throws DAOException {

    Connection conn = null;
    PreparedStatement statement = null;
    try {
      conn = getConnection();
      statement = conn
          .prepareStatement("insert into closed_ofis (finding_id, audit_id, reason, user_id) values (?, ?, ?,?)");
      statement.setLong(1, Long.parseLong(f.getFindingID()));
      statement.setLong(2, Long.parseLong(f.getAuditId()));
      statement.setString(3, f.getAckAndCloseText());
      statement.setString(4, f.getUserNameOfPersonWhoClosedFinding());
      statement.executeUpdate();
      conn.commit();
    } catch (SQLException e) {
      MCASLogUtil.logError("Closing finding #" + f.getFindingID(), e);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, statement, null);
    }

  }

  public void updateReasonForFinding(FindingObject f) throws DAOException {

    Connection conn = null;
    PreparedStatement statement = null;
    try {
      conn = getConnection();
      statement = conn.prepareStatement("update closed_ofis set reason = ?, user_id = ? where finding_id = ? and audit_id = ?");
      statement.setString(1, f.getAckAndCloseText());
      statement.setString(2, f.getUserNameOfPersonWhoClosedFinding());
      statement.setLong(3, Long.parseLong(f.getFindingID()));
      statement.setLong(4, Long.parseLong(f.getAuditId()));
      statement.executeUpdate();
      conn.commit();
    } catch (SQLException e) {
      MCASLogUtil.logError("Updating finding #" + f.getFindingID(), e);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, statement, null);
    }

  }

  protected void deleteClosedFinding(FindingObject f, Connection conn) throws DAOException {

    PreparedStatement statement = null;

    try {
      statement = conn.prepareStatement("delete from closed_ofis where finding_id=? and audit_id=?");
      statement.setLong(1, Long.parseLong(f.getFindingID()));
      statement.setLong(2, Long.parseLong(f.getAuditId()));
      statement.executeUpdate();
    } catch (SQLException e) {
      MCASLogUtil.logError("deleting Closed finding #" + f.getFindingID(), e);
      throw new DAOException(e);
    } finally {
      closeDBResources(null, statement, null);
    }


  }

  public boolean updateFinding(FindingObject findingObj) throws DAOException {

//        logger.info("AuditDAO: Executing updateFinding() operation...");

    //**Imp Variables...
    Date oracleSysdate;

    Connection conn = null;

    //**Get Connection...
    try {
      conn = getConnection();

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Perform Insert-Operation...
      updateFindingObject(Integer.parseInt(findingObj.getFindingID()), oracleSysdate, findingObj, conn);

      //**CPAR MODIFY: Investigation Finding, iff cpar present...[NOT REQUIRED NOW...]
//			if(findingObj.getCparID() != null && !findingObj.getCparID().equals("")){
//				updateCparInvestigationFinding(Integer.parseInt(findingObj.getFindingID()), oracleSysdate, findingObj, conn);
//			}

      return true;
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, null, null);
    }
  }

  public boolean updateAudit(AuditObject auditObj) throws DAOException {

//        logger.info("AuditDAO: Executing updateAudit() operation...");

    //**Imp Variables...
    Date oracleSysdate;
    String autoAuditNumber = auditObj.getAuditNumber();
    int auditID = 0;

    Connection conn = null;

    //**Get Connection...
    try {
      conn = getConnection();

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get audit-id for the given audit-number
      auditID = getAuditID(autoAuditNumber, conn);

      //**Perform Insert-Operation...
      updateAuditObject(auditID, oracleSysdate, auditObj, conn);
      insertUpdateAuditSubfunction(auditID, auditObj, conn);
      insertUpdateAuditorsRelatedToThisAudit(auditID, auditObj, conn);

//            //**Delete the existing Audit-Areas...then add new selected ones...
//            deleteAuditedAreas(auditID, conn);
//
//            //**Insert the Areas Audited...
//            insertAuditedAreas(auditID, auditObj, conn);

      //**Update Area-Overview, if filled in...
      if (auditObj.getAuditOverview() != null && !auditObj.getAuditOverview().equals("")) {
        updateAuditOverview(auditObj.getAuditOverview(), auditID, conn);
      }

      //**Update Prepared-BY, if filled in...
      if (auditObj.getPreparedBy() != null && !auditObj.getPreparedBy().equals("")) {
        updatePreparedBy(auditObj.getPreparedBy(), auditID, conn);
      }

      //**Update Prepared_Date, if filled in...
      if (auditObj.getPreparedDate() != null && !auditObj.getPreparedDate().equals("")) {
        updatePreparedDate(auditObj.getPreparedDate(), auditID, conn);
      }

      //**Update ISO-Contact, if filled in...
      if (auditObj.getSiteISOContact() != null && !auditObj.getSiteISOContact().equals("")) {
        updateIsoContact(auditObj.getSiteISOContact(), auditID, conn);
      }
      updateAuditMemberProcess(auditObj, auditID, conn);

      aaDao.deleteCheckboxItemsForRecord(Integer.parseInt(auditObj.getAuditID()), "A");
      aaDao.insertCheckboxItemsForRecord(Integer.parseInt(auditObj.getAuditID()), "A",
          auditObj.getSelectedFunctionalAreas());
      if (auditObj.getLocationOtherInfo() != null && !auditObj.getLocationOtherInfo().isNotSet()) {
        System.out.println("auditObj = " + auditObj.getAuditID());
        auditObj.getLocationOtherInfo().setId(AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + auditObj.getAuditID());
        getLocationOtherInfoDao(conn).update(auditObj.getLocationOtherInfo());
      }

    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, null, null);
    }

    return true;
  }

  public String insertAudit(AuditObject auditObj, String appName) throws DAOException {

//        logger.info("AuditDAO: Executing insertAudit() operation...");
    //**Imp Variables...
    int auditSeqNextVal = 0;
    Date oracleSysdate;
    String autoAuditNumber = "";

    Connection conn = null;

    //**Get Connection...
    try {
      conn = getConnection();

      //**Get the audit_seq value...
      auditSeqNextVal = getAuditSeqValue(conn);

      //**Get the oracle sysdate...
      oracleSysdate = getOracleSysDate(conn);

      //**Get the auto-generated audit_no...
      autoAuditNumber = getAuditNumberMax(auditObj, conn, appName);


      //**Perform Insert-Operation...
      insertAuditObject(auditSeqNextVal, autoAuditNumber, oracleSysdate, auditObj, conn);

      //**Insert the Areas Audited...
      //insertAuditedAreas(auditSeqNextVal, auditObj, conn);

      //**Update Area-Overview, if filled in...
      if (auditObj.getAuditOverview() != null && !auditObj.getAuditOverview().equals("")) {
        updateAuditOverview(auditObj.getAuditOverview(), auditSeqNextVal, conn);
      }

      //**Update Prepared-BY, if filled in...
      if (auditObj.getPreparedBy() != null && !auditObj.getPreparedBy().equals("")) {
        updatePreparedBy(auditObj.getPreparedBy(), auditSeqNextVal, conn);
      }

      //**Update Prepared_Date, if filled in...
      if (auditObj.getPreparedDate() != null && !auditObj.getPreparedDate().equals("")) {
        updatePreparedDate(auditObj.getPreparedDate(), auditSeqNextVal, conn);
      }

      //**Update ISO-Contact, if filled in...
      if (auditObj.getSiteISOContact() != null && !auditObj.getSiteISOContact().equals("")) {
        updateIsoContact(auditObj.getSiteISOContact(), auditSeqNextVal, conn);
      }
      updateAuditMemberProcess(auditObj, auditSeqNextVal, conn);

//            ncDao.insertCheckboxItemsForComplaint(Integer.parseInt(auditObj.getAuditID()), "A", auditObj.getSelectedNonconformanceCategoryList());
      aaDao.insertCheckboxItemsForRecord(auditSeqNextVal, "A", auditObj.getSelectedFunctionalAreas());


    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting connection: ", e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, null, null);
    }

    //**Return both the audit-number and audit_id
    return autoAuditNumber + ";" + auditSeqNextVal;
  }


  public Map<String, Object> getAuditList(AuditListObject filterObj, String intPage, String sortCriteria,
                                          String sortOrder, int userBusinessPreferenceId, String applicationName) throws
      DAOException {
//        System.out.println("In get audit list");


    Connection conn = null;

    Map<String, Object> audits = null;
    try {
      conn = getConnection();

      //If the CAR/PAR number is the search criteria
      if (!(filterObj.getCparNumber() == null) && !(filterObj.getCparNumber().equals(""))) {
        return getAuditListForFindingOrCarPar(filterObj, conn);
      }//end if
      else {
        return getAuditListIfNotSearchingWithFinding(filterObj, intPage, sortCriteria, sortOrder,
            userBusinessPreferenceId, conn, audits, applicationName);

      }//end else
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_list: ", e);
    } finally {
      this.closeDBResources(conn, null, null);
    }

    return new LinkedHashMap();
  }

  private Map<String, Object> getAuditListIfNotSearchingWithFinding(AuditListObject filterObj, String intPage,
                                                                    String sortCriteria, String sortOrder,
                                                                    int userBusinessPreferenceId,
                                                                    Connection conn, Map<String, Object> audits,
                                                                    String applicationName) throws SQLException {

    PreparedStatement ps = null;
    ResultSet rs = null;
    String lastQuery = "";

    try {
      StringBuffer whereClause = new StringBuffer();
      StringBuffer functionalAreaBuffer = new StringBuffer();
      String orderBySort;

      int Page = Integer.parseInt(intPage);
      buildWhereClauseForAuditSearch(filterObj, whereClause);
      prepareFunctionalAreasInClause(filterObj, functionalAreaBuffer, false);
      whereClause.append(" AND A.BUSINESS_ID=").append(userBusinessPreferenceId);
      if (filterObj.getFunctionalAreaIdList() != null && filterObj.getFunctionalAreaIdList().size() > 0) {
        whereClause.append(functionalAreaBuffer);
      }

      addTextSearchConditions(whereClause, filterObj.getSearchText());

      if (appNotMcas(applicationName)) {
        lastQuery = AuditDAOSQLConstants.GET_AUDIT_LIST_COUNT + whereClause.toString();
        ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_LIST_COUNT + whereClause.toString());
//          logger.info(AuditDAOSQLConstants.GET_AUDIT_LIST_COUNT + whereClause.toString());
//            System.out.println("GET_AUDIT_LIST_COUNT = " + AuditDAOSQLConstants.GET_AUDIT_LIST_COUNT + whereClause.toString());
      }
      else if(MCASConstants.APPLICATION_NAME_BIOTECHFAS.equalsIgnoreCase(applicationName)){
        lastQuery = "SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS_BIOTECCAS +
            whereClause.toString() + "))";
        ps = conn.prepareStatement("SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS_BIOTECCAS +
            whereClause.toString() + "))");
      }

      else {
        lastQuery = "SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS +
            whereClause.toString() + "))";
        ps = conn.prepareStatement("SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS +
            whereClause.toString() + "))");
//            logger.info("SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS + whereClause.toString() + "))");
//            System.out.println("SELECT COUNT (*) COUNT FROM (" + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS + whereClause.toString() + "))");
      }
      rs = ps.executeQuery();
      if (rs.next()) {
        audits = new LinkedHashMap<String, Object>();
        audits.put("maxRows", rs.getString("COUNT"));
      }

      if (sortCriteria.equals("AUDIT_DATE"))
        orderBySort = ("  ORDER BY " + sortCriteria + " " + sortOrder);
      else
        orderBySort = ("  ORDER BY lower(" + sortCriteria + ") " + sortOrder);

      String _whereRanking = " WHERE RANKING BETWEEN " + ((Page * 10) - 9) + " AND " + Page * 10;

      MCASResourceUtil.closeDBResources(null, ps, rs);

      if (appNotMcas(applicationName)) {
        lastQuery = AuditDAOSQLConstants.GET_AUDIT_LIST + whereClause.toString() + orderBySort + " )) " + _whereRanking;
        ps = conn.prepareStatement(
            AuditDAOSQLConstants.GET_AUDIT_LIST + whereClause.toString() + orderBySort + " )) " + _whereRanking);
//            logger.info(
//                    AuditDAOSQLConstants.GET_AUDIT_LIST + whereClause.toString() + orderBySort + " ))" + _whereRanking);
//            System.out.println(
//                    AuditDAOSQLConstants.GET_AUDIT_LIST + whereClause.toString() + orderBySort + " )) " + _whereRanking);
      }
      else if(MCASConstants.APPLICATION_NAME_BIOTECHFAS.equalsIgnoreCase(applicationName)){
          lastQuery =
            AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER_BIOTECCAS + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS_BIOTECCAS +
                whereClause.toString() + orderBySort + "))" + _whereRanking;
        ps = conn.prepareStatement(
            AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER_BIOTECCAS + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS_BIOTECCAS +
                whereClause.toString() + orderBySort + "))" + _whereRanking);

      }

      else {
        lastQuery =
            AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS +
                whereClause.toString() + orderBySort + "))" + _whereRanking;
        ps = conn.prepareStatement(
            AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS +
                whereClause.toString() + orderBySort + "))" + _whereRanking);
//            logger.info(
//                    AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS + whereClause.toString() + orderBySort + ")" + _whereRanking);
//            System.out.println(
//                    AuditDAOSQLConstants.AUDIT_LIST_WITH_FINDING_WRAPPER + AuditDAOSQLConstants.GET_AUDIT_LIST_WITH_FINDINGS + whereClause.toString() + orderBySort + "))" + _whereRanking);
      }
      rs = ps.executeQuery();


      int rank = (Page * 10 - 9);
      String auditNumber = "";
      String cparNumber = "";
      while (rs.next()) {
        AuditListObject al = new AuditListObject();
        auditNumber = rs.getString("AUDIT_NUMBER").trim();
        al.setAuditNumber(auditNumber);

        al.setLocationCode(rs.getString("SITE"));
        al.setAuditDate(sdf.format(rs.getDate("AUDIT_DATE")));
        al.setAuditOverview(trimAuditOverviewText(rs.getString("AUDIT_OVERVIEW")));
        al.setAuditor(rs.getString("AUDITOR"));
        al.setPreparedBy(rs.getString("PREPARED_BY"));

        if(!MCASConstants.APPLICATION_NAME_BIOTECHFAS.equalsIgnoreCase(applicationName)){
            cparNumber = rs.getString("CONTROL_NUMBER");
        //if("N".equalsIgnoreCase(rs.getString("IS_DELETED"))){
        al.setCparNumber(cparNumber);
        //}
        if (rs.getString("CPAR_ID") != null && !rs.getString("CPAR_ID").equals("")) {
          al.setCparID(Integer.parseInt(rs.getString("CPAR_ID")));
        }
        }


        al.setAuditId(rs.getString("AUDIT_ID"));
        audits.put(rank + "", al);
        rank++;
      }
    } catch (SQLException e) {
      MCASLogUtil.logError(lastQuery, e);
      throw e;
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

    return audits;
  }

  private void addTextSearchConditions(StringBuffer buff, String searchText) {
    if (!StringUtils.isNullOrEmpty(searchText)) {
      buff.append(" and (lower(a.AUDIT_OVERVIEW) like lower('%");
      buff.append(searchText);
      buff.append(
          "%') or (select count(*) from M_AUDIT_FINDINGS f where f.AUDIT_ID = a.AUDIT_ID and lower(f.DESCRIPTION) like lower('%");
      buff.append(searchText);
      buff.append("%')) > 0)");
    }
  }

  private void prepareFunctionalAreasInClause(AuditListObject filterObj, StringBuffer functionalAreasBuffer,
                                              boolean searchWithFinding) {
    List<Integer> selectedFunctionalAreas = filterObj.getFunctionalAreaIdList();
    if (!filterObj.isFunctionalAreaIdListEmpty()) {
      functionalAreasBuffer.append("AND A.AUDIT_ID IN (SELECT AUDIT_ID FROM M_AUDIT_AREAS WHERE AUDIT_AREA_ID IN (");
      for (Integer functionalAreaId : selectedFunctionalAreas) {
        functionalAreasBuffer.append(Integer.parseInt(functionalAreaId.toString()));
        functionalAreasBuffer.append(",");
      }
      if (functionalAreasBuffer.lastIndexOf(",") != -1) {
        functionalAreasBuffer.deleteCharAt(functionalAreasBuffer.lastIndexOf(","));
      }
      functionalAreasBuffer.append(")");
      if (!searchWithFinding) {
        functionalAreasBuffer.append(")");
      }
    }
  }

  private boolean appNotMcas(String applicationName) {
    return MCASConstants.APPLICATION_NAME_BTFAS.equalsIgnoreCase(applicationName) ||
        MCASConstants.APPLICATION_NAME_SBFAS.equalsIgnoreCase(applicationName);
  }


  private Map<String, Object> getAuditListForFindingOrCarPar(AuditListObject filterObj, Connection conn) throws
      SQLException {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      Map<String, Object> audits = new LinkedHashMap<String, Object>();
      StringBuffer functionalAreasBuffer = new StringBuffer();
      StringBuffer whereClause = new StringBuffer();

      audits.put("maxRows", "1");
      buildWhereClauseForAuditSearch(filterObj, whereClause);
      prepareFunctionalAreasInClause(filterObj, functionalAreasBuffer, true);

      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_LIST_CPAR + whereClause.toString());
      ps.setString(1, filterObj.getCparNumber().toUpperCase().trim());
      rs = ps.executeQuery();
      while (rs.next()) {
        AuditListObject al = new AuditListObject();
        al.setAuditNumber(rs.getString("AUDIT_NUMBER").trim());
        al.setLocationCode(rs.getString("SITE"));
        al.setAuditDate(sdf.format(rs.getDate("AUDIT_DATE")));
        al.setAuditOverview(trimAuditOverviewText(rs.getString("AUDIT_OVERVIEW")));//Display Audit overview
        al.setAuditor(rs.getString("AUDITOR"));
        al.setPreparedBy(rs.getString("PREPARED_BY"));
        al.setCparNumber(rs.getString("CONTROL_NUMBER"));
        if (rs.getString("CPAR_ID") != null && !rs.getString("CPAR_ID").equals("")) {
          al.setCparID(Integer.parseInt(rs.getString("CPAR_ID")));
        }
        al.setAuditId(rs.getString("AUDIT_ID"));
        audits.put(rs.getString("AUDIT_NUMBER"), al);

      }

      return audits;
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

  }

  private void buildWhereClauseForAuditSearch(AuditListObject filterObj, StringBuffer whereClause) {
    if (notNullOrEmpty(filterObj.getProgram_id())) {
      whereClause.append(" AND A.PROGRAM_ID=" + "'").append(filterObj.getProgram_id()).append("'");
    }
    if (notNullOrEmpty(filterObj.getLocationCode())) {
      whereClause.append(" AND A.LOCATION_CODE=" + "'").append(filterObj.getLocationCode()).append("'");
    }
    if (notNullOrEmpty(filterObj.getAuditDate())) {
      whereClause.append(" AND A.AUDIT_DATE>=to_Date('").append(filterObj.getAuditDate().trim())
          .append("','MM-dd-YYYY')");
    }
    if (notNullOrEmpty(filterObj.getToDate())) {
      whereClause.append(" AND A.AUDIT_DATE<=to_Date('").append(filterObj.getToDate().trim()).append("','MM-dd-YYYY')");
    }
    if (notNullOrEmpty(filterObj.getAuditor())) {
      whereClause.append(" AND upper(A.AUDITOR) like" + "'").append(filterObj.getAuditor().toUpperCase().trim())
          .append("%'");
    }
    if (notNullOrEmpty(filterObj.getPreparedBy())) {
      whereClause.append(" AND upper(A.PREPARED_BY) like" + "'").append(filterObj.getPreparedBy().toUpperCase().trim())
          .append("%'");
    }
    if (notNullOrEmpty(filterObj.getRegion())) {
      whereClause.append(" AND upper(A.REGION_ID)=" + "'").append(filterObj.getRegion()).append("'");
    }
    if (notNullOrEmpty(filterObj.getAuditNumber())) {
      whereClause.append(" AND upper(A.AUDIT_NUMBER)=" + "'").append(filterObj.getAuditNumber().toUpperCase().trim())
          .append("'");
    }
    if (notNullOrEmpty(filterObj.getFunctionId())) {
      whereClause.append(" AND A.LOCATION_FUNCTION_ID=" + "'").append(filterObj.getFunctionId()).append("'");
    }
    if (notNullOrEmpty(filterObj.getAuditType())) {
      whereClause.append(" AND A.AUDIT_TYPE_ID=").append(Integer.parseInt(filterObj.getAuditType()));
    }
    if (notNullOrEmpty(filterObj.getIssue_year())) {
      whereClause.append(" AND A.ISSUE_YEAR_ID=").append(Integer.parseInt(filterObj.getIssue_year()));
    }
  }

  private boolean notNullOrEmpty(String data) {
    return !StringUtils.isNullOrEmpty(data);
  }

  private String trimAuditOverviewText(String auditOverView) {
    return MCASUtil.trimDescriptionText(auditOverView);
  }

  public Map<String, RowBean> getAuditReport(AuditFilter auditFilter, String locale) throws DAOException {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    StringBuffer whereClause = new StringBuffer();
    Map<String, RowBean> hash = new HashMap<String, RowBean>();

    try {
      conn = getConnection();

      if ((auditFilter.getAuditNumber() != null) && !(auditFilter.getAuditNumber().equals(""))) {
        whereClause.append(" AND UPPER(M_AUDIT.AUDIT_NUMBER) LIKE UPPER('").append(auditFilter.getAuditNumber().trim())
            .append("%') ");
      }
      if ((auditFilter.getAuditDate() != null) && !(auditFilter.getAuditDate().equals(""))) {
        whereClause.append(" AND M_AUDIT.AUDIT_DATE = TO_DATE('")
            .append(getDateFormat(new Date(new java.util.Date(auditFilter.getAuditDate()).getTime())))
            .append("', 'MM/DD/YYYY') ");
      }
      if ((auditFilter.getPreparedBy() != null) && !(auditFilter.getPreparedBy().equals(""))) {
        whereClause.append(" AND UPPER(M_AUDIT.PREPARED_BY) LIKE UPPER('").append(auditFilter.getPreparedBy().trim())
            .append("%') ");
      }
      if ((auditFilter.getPreparedDate() != null) && !(auditFilter.getPreparedDate().equals(""))) {
        whereClause.append(" AND M_AUDIT.PREPARED_DATE = TO_DATE('")
            .append(getDateFormat(new Date(new java.util.Date(auditFilter.getPreparedDate()).getTime())))
            .append("', 'MM/DD/YYYY') ");
      }
      if ((auditFilter.getAuditor() != null) && !(auditFilter.getAuditor().equals(""))) {
        whereClause.append(" AND UPPER(M_AUDIT.AUDITOR) LIKE UPPER('").append(auditFilter.getAuditor().trim())
            .append("%') ");
      }
      if ((auditFilter.getSiteIsoContact() != null) && !(auditFilter.getSiteIsoContact().equals(""))) {
        whereClause.append(" AND UPPER(M_AUDIT.ISO_CONTACT) LIKE UPPER('")
            .append(auditFilter.getSiteIsoContact().trim()).append("%') ");
      }
      if ((auditFilter.getCparNumber() != null) && !(auditFilter.getCparNumber().equals(""))) {
        whereClause.append(" AND UPPER(CPAR.CONTROL_NUMBER) LIKE UPPER('").append(auditFilter.getCparNumber().trim())
            .append("%') ");
      }
      if ((auditFilter.getSite() != null) && (auditFilter.getSite().length > 0)) {
        whereClause.append(getSelectedFields(" AND M_AUDIT.LOCATION_CODE IN ", auditFilter.getSite()));
      }
      if ((auditFilter.getRegion() != null) && (auditFilter.getRegion().length > 0)) {
        whereClause.append(getSelectedFields(" AND M_AUDIT.REGION_ID IN ", auditFilter.getRegion()));
      }
      if ((auditFilter.getFunctionId() != null) && !(auditFilter.getFunctionId().equals(""))) {
        whereClause.append(" AND M_AUDIT.LOCATION_FUNCTION_ID=" + "'").append(auditFilter.getFunctionId()).append("'");
      }
      //Selected Audit Areas
      if (!auditFilter.isFunctionalAreaIdListEmpty()) {
        whereClause.append(" AND M_AUDIT_AREAS_REF.AREA_ID IN ( ")
            .append(buildInClause(auditFilter.getFunctionalAreaIdList())).append(" )");
      }

//            logger.info(AuditDAOSQLConstants.GET_AUDIT_REPORT + whereClause.toString());
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_REPORT + whereClause.toString());

      rs = ps.executeQuery();
      I18nServiceImpl iService = new I18nServiceImpl();

      int rowCount = 0;
      while (rs.next()) {
//                System.out.println("rowCount = " + rowCount);
        rowCount++;

        //** Fill in the RowBean Object...
        RowBean rowBean = new RowBean();

        if (rs.getString("AUDIT_NUMBER") != null && !(rs.getString("AUDIT_NUMBER").trim().equals(""))) {
          rowBean.setCol(1, rs.getString("AUDIT_NUMBER"));
        } else {
          rowBean.setCol(1, "-");
        }
        if (rs.getString("LOCATION_CODE") != null && !(rs.getString("LOCATION_CODE").trim().equals(""))) {
          rowBean.setCol(2, rs.getString("LOCATION_CODE"));
        } else {
          rowBean.setCol(2, "-");
        }
        if (rs.getString("LOCATION_SHORT_NAME") != null && !(rs.getString("LOCATION_SHORT_NAME").trim().equals(""))) {
          rowBean.setCol(3, rs.getString("LOCATION_SHORT_NAME"));
        } else {
          rowBean.setCol(3, "-");
        }
        if (rs.getString("AUDIT_OVERVIEW") != null && !(rs.getString("AUDIT_OVERVIEW").trim().equals(""))) {
          rowBean.setCol(4, rs.getString("AUDIT_OVERVIEW"));
        } else {
          rowBean.setCol(4, "-");
        }
        if (rs.getString("CAR_PAR_NUMBER") != null && !(rs.getString("CAR_PAR_NUMBER").trim().equals(""))) {
          rowBean.setCol(5, rs.getString("CAR_PAR_NUMBER"));
        } else {
          rowBean.setCol(5, "-");
        }
        if (rs.getDate("AUDIT_DATE") != null) {
          rowBean.setCol(6, getDateFormat(rs.getDate("AUDIT_DATE")));
        } else {
          rowBean.setCol(6, "-");
        }
        if (rs.getString("AUDIT_AREA") != null && !(rs.getString("AUDIT_AREA").trim().equals(""))) {

          int id = rs.getInt("AREA_ID");
          String desc = iService.translate(locale, "M_AUDIT_AREAS_REF", id, rs.getString("AUDIT_AREA"));

          rowBean.setCol(7, desc);
        } else {
          rowBean.setCol(7, "-");
        }
        if (rs.getString("FINDING") != null && !(rs.getString("FINDING").trim().equals(""))) {
          rowBean.setCol(8, rs.getString("FINDING"));
        } else {
          rowBean.setCol(8, "-");
        }
        if (rs.getString("AUDITOR") != null && !(rs.getString("AUDITOR").trim().equals(""))) {
          rowBean.setCol(9, rs.getString("AUDITOR"));
        } else {
          rowBean.setCol(9, "-");
        }
        if (rs.getString("ISO_CONTACT") != null && !(rs.getString("ISO_CONTACT").trim().equals(""))) {
          rowBean.setCol(10, rs.getString("ISO_CONTACT"));
        } else {
          rowBean.setCol(10, "-");
        }
        if (rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))) {
          rowBean.setCol(11, rs.getString("REGION"));
        } else {
          rowBean.setCol(11, "-");
        }
        if (rs.getString("PREPARED_BY") != null && !(rs.getString("PREPARED_BY").trim().equals(""))) {
          rowBean.setCol(12, rs.getString("PREPARED_BY"));
        } else {
          rowBean.setCol(12, "-");
        }
        if (rs.getDate("PREPARED_DATE") != null) {
          rowBean.setCol(13, getDateFormat(rs.getDate("PREPARED_DATE")));
        } else {
          rowBean.setCol(13, "-");
        }
        if (rs.getString("LOCATION_FUNCTION_ID") != null) {
          String s = rs.getString("LOCATION_FUNCTION_ID");
          rowBean.setCol(14, s);
        } else {
          rowBean.setCol(14, "-");
        }
//                System.out.println("rowCount = " + rowCount);
        hash.put(rowCount + "", rowBean);
      }

      return hash;
    } catch (Exception e) {
//            System.out.println("e = " + e);
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, rs);
    }
  }

  public boolean addAuditAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(AuditDAOSQLConstants.ADD_AUDIT_ATTACHMENT);
      ps.setString(1, attachmentInfo.getDocumentId());
      ps.setInt(2, Integer.parseInt(attachmentInfo.getEntityId()));
      ps.setString(3, attachmentInfo.getDocumentName());
      ps.executeUpdate();
      conn.commit();
      return true;
    } catch (Exception e) {
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, null);
    }
  }

  public boolean deleteAuditAttachmentInfo(String documentId) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(AuditDAOSQLConstants.DELETE_AUDIT_ATTACHMENT);
      ps.setString(1, documentId);
      ps.executeUpdate();
      conn.commit();
      return true;
    } catch (Exception e) {
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, null);
    }
  }

  public List<Cpar> getCARList(String auditId) throws DAOException {
    Cpar cpar;
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    List<Cpar> cparList = new ArrayList<Cpar>();
    try {
      connection = getConnection();
      statement = connection.prepareStatement("SELECT C.CONTROL_NUMBER,C.CPAR_ID \n" +
          "FROM CPAR C,M_AUDIT A,M_AUDIT_FINDINGS F\n" +
          "WHERE \n" +
          "C.AUDIT_FINDING_ID = F.AUDIT_FINDING_ID AND A.AUDIT_ID=F.AUDIT_ID AND A.AUDIT_ID=?");
      statement.setString(1, auditId);
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        cpar = new Cpar();
        String cparNumber = resultSet.getString("CONTROL_NUMBER");
        String cparId = resultSet.getString("CPAR_ID");
        cpar.setCpar_id(cparId);
        cpar.setControl_number(cparNumber);
        cparList.add(cpar);
      }
    } catch (SQLException e) {
      MCASLogUtil.logError(e.getMessage(), e);
    } finally {
      MCASResourceUtil.closeDBResources(connection, statement, resultSet);
    }

    return cparList;
  }

  public void deleteAudit(String auditNumber) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(AuditDAOSQLConstants.DELETE_AUDIT);
      ps.setString(1, auditNumber);
      ps.executeUpdate();
      LocationOtherInfo loc = new LocationOtherInfo();
      loc.setId(AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + auditNumber);
      getLocationOtherInfoDao(conn).delete(loc);
      conn.commit();
    } catch (Exception e) {
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, null);
    }

  }

  public int deleteAuditFinding(String auditId, String findingId) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    int recordCount = 0;
    try {
      conn = getConnection();
      ps = conn.prepareStatement("DELETE FROM M_AUDIT_FINDINGS WHERE AUDIT_ID = ? AND AUDIT_FINDING_ID = ?");
      ps.setInt(1, Integer.parseInt(auditId));
      ps.setInt(2, Integer.parseInt(findingId));
      recordCount = ps.executeUpdate();
      FindingObject f = new FindingObject();
      f.setAckFindingId(findingId);
      f.setFindingID(findingId);
      f.setAuditId(auditId);
      deleteClosedFinding(f, conn);
      conn.commit();
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      throw new DAOException("Exception deleting Audit Finding in " + getClass().getName() + ".deleteAuditFinding", e);
    } finally {
      MCASResourceUtil.closeDBResources(conn, ps, null);
    }

    return recordCount;
  }

  /**
   * This method just makes a string out of selected fields like ('1744', '1745',...)
   *
   * @param strArray
   *
   * @return StringBuffer
   */
  private StringBuffer getSelectedFields(String query, String[] strArray) {

    int size = strArray.length;

    StringBuffer fieldClause = new StringBuffer();
    fieldClause.append("");

    //**To remove the null elements...
    for (int i = 0; i < size; i++) {

      if (strArray[i].equals("") || strArray[i].equals("0")) {
        size--;
      }
    }

    if (size == 0) {
      return fieldClause;
    }

    fieldClause.append(query).append("(");

    for (int i = 0; i < strArray.length; i++) {

      //**Skip null elements...
      if (strArray[i].equals("") || strArray[i].equals("0")) {
        continue;
      }

      fieldClause.append("'").append(strArray[i].trim()).append("'");

      if (i < strArray.length - 1) {
        fieldClause.append(",");
      }
    }

    fieldClause.append(")");

    return fieldClause;
  }

  String getAuditNumberMax(AuditObject auditObj, Connection conn, String appName) {

    PreparedStatement ps = null;
    ResultSet rs = null;
    String compareTo = "";
    String returnStr = "";
    String businessDescription = "";
    int max = 0;

    LookUpService lookup = new LookUpServiceImpl();

  try {

        if(appName.equals(MCASConstants.APPLICATION_NAME_SBFAS)){
            String businessQuery = SBFAS_BUSINESS_QUERY + auditObj.getBusinessId();
            businessDescription = getBusiness(conn, businessQuery);
            if((businessDescription != null) && (!businessDescription.isEmpty())){
                 businessDescription = businessDescription.substring(0,3).toUpperCase();
            }

            compareTo = AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + businessDescription + "-" + auditObj.getLocationCode() + "-" +
                        lookup.getYearDescription(Integer.parseInt(auditObj.getIssue_year())).substring(2)  + "-" + "%";
            ps = conn.prepareStatement(AuditDAOSQLConstants.AUTO_AUDIT_NUMBER_SBFAS);

        }else{

            compareTo = AUDIT_LOCATION_OTHER_INFO_ID_PREFIX +
            auditObj.getLocationCode() + "-" +
            lookup.getYearDescription(Integer.parseInt(auditObj.getIssue_year())).substring(2)
            + "-" + "%";
            ps = conn.prepareStatement(AuditDAOSQLConstants.AUTO_AUDIT_NUMBER);

        }


      ps.setString(1, compareTo);

      rs = ps.executeQuery();

      while (rs.next()) {
        max = rs.getInt("MAX");
      }

      if(appName.equals(MCASConstants.APPLICATION_NAME_SBFAS)){

          returnStr = AUDIT_LOCATION_OTHER_INFO_ID_PREFIX +
                      businessDescription + "-" +
                      auditObj.getLocationCode() + "-" +
                      lookup.getYearDescription(Integer.parseInt(auditObj.getIssue_year())).substring(2)
                      + "-" + (max + 1);

      }else{

           returnStr = AUDIT_LOCATION_OTHER_INFO_ID_PREFIX +
                                auditObj.getLocationCode() + "-" +
                                lookup.getYearDescription(Integer.parseInt(auditObj.getIssue_year())).substring(2)
                                + "-" +
                                (max + 1);

      }


      return returnStr;
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_no_max: ", e);
      return "";
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  private String getBusiness(Connection conn, String queryString) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(queryString);
            rs = ps.executeQuery();
            String business = "";
            if (rs != null) {
                rs.next();
                business = rs.getString(1);
            }
            return business;
        }
        finally {
            closeDBResources(null, ps, rs);
        }

    }

  void updatePreparedBy(String preparedBy, int auditID, Connection conn) {

    PreparedStatement ps = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_PREPARED_BY);

      ps.setString(1, preparedBy);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();
//
//            logger.info("AuditDAO: PreparedBy Inserted done.");
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while inserting PreparedBy: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  void updatePreparedDate(String preparedDate, int auditID, Connection conn) {

    PreparedStatement ps = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_PREPARED_DATE);

      ps.setDate(1, new Date(new java.util.Date(preparedDate).getTime()));
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

//            logger.info("AuditDAO: PreparedDate Inserted done.");
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while inserting PreparedDate: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  void updateIsoContact(String isoContact, int auditID, Connection conn) {

    PreparedStatement ps = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_ISO_CONTACT);

      ps.setString(1, isoContact);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();
//
//            logger.info("AuditDAO: IsoContact Inserted done.");
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while inserting IsoContact: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  private void updateAuditMemberProcess(AuditObject auditObj, int auditId, Connection conn) {

    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_AUDIT_PROCESS_MEMBER);
      ps.setString(1, auditObj.getAuditMembers());
      ps.setString(2, auditObj.getAuditProcess());
      ps.setString(3, auditObj.getAuditProcedure());
      ps.setString(4, auditObj.getPersonsAudited());
      ps.setInt(5, auditId);
      ps.executeUpdate();
      conn.commit();

//            logger.info("AuditDAO: Audit Overview Inserted done.");
    } catch (SQLException e) {
      MCASLogUtil.logError("SQLException while inserting Audit Overview: ", e);
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while inserting Audit Overview: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }


  void updateAuditOverview(String auditOverview, int auditID, Connection conn) {

    PreparedStatement ps = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_AUDIT_OVERVIEW);

      ps.setString(1, auditOverview);
      ps.setInt(2, auditID);

      ps.executeUpdate();

      conn.commit();

//            logger.info("AuditDAO: Audit Overview Inserted done.");
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while inserting Audit Overview: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  void insertFindingObject(int auditFindingID, int auditID, Date oracleSysdate, FindingObject findingObj,
                           Connection conn) {
    PreparedStatement ps = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.INSERT_AUDIT_FINDING_SQL);

      ps.setInt(1, auditFindingID);
      ps.setInt(2, auditID);
      ps.setString(3, findingObj.getFindingDesc());
      ps.setString(4, findingObj.getRowUserID());
      ps.setString(5, "Finding_Entry");
      ps.setDate(6, oracleSysdate);
      ps.setDate(7, oracleSysdate);
      ps.setString(8, findingObj.getCar_flag());
      ps.executeUpdate();
      conn.commit();
//            logger.info("AuditDAO: InsertFinding() operation done.");
    } catch (Exception e) {
      MCASLogUtil.logError("Exception inserting at insertFinding(): ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }


  void updateFindingObject(int auditFindingID, Date oracleSysdate, FindingObject findingObj, Connection conn) {
    PreparedStatement ps = null;

    //**Perform Insert-Operation...
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_AUDIT_FINDING_SQL);

      ps.setString(1, findingObj.getFindingDesc());
      ps.setString(2, findingObj.getRowUserID());
      ps.setString(3, "Finding_Modify");
      ps.setDate(4, oracleSysdate);
      ps.setInt(5, auditFindingID);

      ps.executeUpdate();

      conn.commit();

//            logger.info("AuditDAO: UpdateFinding() operation done.");


    } catch (Exception e) {
      MCASLogUtil.logError("Exception inserting at updateFinding(): ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }


  void insertAuditObject(int auditID, String autoAuditNumber, Date oracleSysdate, AuditObject auditObj,
                         Connection conn) {

    PreparedStatement ps = null;

//        logger.log(Priority.FATAL, "START : ****User ID****:" + auditObj.getRowUserID() + ":****Business ID****:" + auditObj.getBusinessId() +
//                ":****Method****:" + getClass() + "insertAuditObject()" +
//                ":****Audit Regiont****:" + auditObj.getRegion_id());
//        System.out.println("START : ****User ID****:" + auditObj.getRowUserID() + ":****Business ID****:" + auditObj.getBusinessId() +
//                ":****Method****:" + getClass() + "insertAuditObject()" +
//                ":****Audit Regiont****:" + auditObj.getRegion_id());
//        //**Perform Insert-Operation...
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.INSERT_AUDIT_SQL);

      ps.setInt(1, auditID);
      ps.setString(2, auditObj.getLocationCode());
      ps.setDate(3, new Date(new java.util.Date(auditObj.getAuditDate()).getTime()));
      ps.setString(4, autoAuditNumber);
      ps.setString(5, auditObj.getAuditor());
      ps.setInt(6, Integer.parseInt(auditObj.getRegion_id()));
      ps.setString(7, auditObj.getRowUserID());
      ps.setString(8, "Audit_Entry");
      ps.setDate(9, oracleSysdate);
      ps.setDate(10, oracleSysdate);
      ps.setString(11, auditObj.getFunctionId());
      ps.setInt(12, auditObj.getBusinessId());
      ps.setString(13, "N");
      ps.setString(14, auditObj.getAuditMembers());
      ps.setString(15, auditObj.getPersonsAudited());
      ps.setString(16, auditObj.getAuditProcess());
      ps.setString(17, auditObj.getAuditProcedure());
      ps.setString(18, auditObj.getProgram_id());
      ps.setString(19, auditObj.getAuditType());
      ps.setString(20, auditObj.getIssue_year());
      ps.setString(21, auditObj.getCreatedBy());

      int result = ps.executeUpdate();
      if (result > 0) {
        //insert subfunction related information.
        insertUpdateAuditSubfunction(auditID, auditObj, conn);
        insertUpdateAuditorsRelatedToThisAudit(auditID, auditObj, conn);
      }


      if (auditObj.getLocationOtherInfo() != null && !auditObj.getLocationOtherInfo().isNotSet()) {
        auditObj.getLocationOtherInfo().setId(AUDIT_LOCATION_OTHER_INFO_ID_PREFIX + auditID);
        getLocationOtherInfoDao(conn).create(auditObj.getLocationOtherInfo());
      }

      conn.commit();

//            logger.info("AuditDAO: InsertAudit() operation done.");


    } catch (Exception e) {
      MCASLogUtil.logError("Exception inserting at insertAudit(): ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  private void insertUpdateAuditorsRelatedToThisAudit(int auditId, AuditObject auditObj, Connection conn) throws
      DAOException {
    PreparedStatement ps = null;
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.DELETE_AUDITORS_FOR_AN_AUDIT);
      ps.setInt(1, auditId);
      ps.executeUpdate();
      MCASResourceUtil.closeDBResources(null, ps, null);

      ps = conn.prepareStatement(AuditDAOSQLConstants.INSERT_AUDITORS_FOR_AN_AUDIT);
      ps.setInt(1, auditId);
      ps.setString(2, auditObj.getAuditorOne());
      ps.setString(3, auditObj.getAuditorTwo());
      ps.executeUpdate();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  private void insertUpdateAuditSubfunction(int auditID, AuditObject auditObj, Connection conn) throws DAOException {
    PreparedStatement ps = null;
    try {
      if (auditObj.getSubFunctionsSelected() != null) {
        ps = conn.prepareStatement(AuditDAOSQLConstants.DELETE_AUDIT_SUBFUNCTION);
        ps.setInt(1, auditID);
        ps.executeUpdate();
        MCASResourceUtil.closeDBResources(null, ps, null);

        ps = conn.prepareStatement(AuditDAOSQLConstants.INSERT_AUDIT_SUBFUNCTION);
        for (String subfunctionId : auditObj.getSubFunctionsSelected()) {
          if (!StringUtils.isNullOrEmpty(subfunctionId) && !subfunctionId.equalsIgnoreCase("null")) {
            ps.setInt(1, auditID);
            ps.setString(2, subfunctionId);
            ps.executeUpdate();
          }
        }
      }
    } catch (SQLException sqlEx) {
      throw new DAOException(sqlEx);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);

    }

  }

  void updateAuditObject(int auditID, Date oracleSysdate, AuditObject auditObj, Connection conn) {

    PreparedStatement ps = null;

    //**Perform Insert-Operation...
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.UPDATE_AUDIT_SQL);

      ps.setString(1, auditObj.getLocationCode());
      ps.setDate(2, new Date(new java.util.Date(auditObj.getAuditDate()).getTime()));
      ps.setString(3, auditObj.getAuditor());
      ps.setInt(4, Integer.parseInt(auditObj.getRegion_id()));
      ps.setString(5, auditObj.getRowUserID());
      ps.setString(6, "Audit_Update");
      ps.setDate(7, oracleSysdate);
      ps.setString(8, auditObj.getFunctionId());
      ps.setString(9, auditObj.getProgram_id());
      ps.setString(10, auditObj.getAuditType());
      ps.setInt(11, auditID);

      ps.executeUpdate();

      conn.commit();
//
//            logger.info("AuditDAO: UpdateAudit() operation done.");


    } catch (Exception e) {
      MCASLogUtil.logError("Exception inserting at updateAudit(): ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  int getAuditSeqValue(Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditSeqNextVal = 0;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_SEQ_NEXTVAL);

      rs = ps.executeQuery();

      while (rs.next()) {
        auditSeqNextVal = rs.getInt("NEXTVAL");
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_seq: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }


    return auditSeqNextVal;
  }


  int getAuditFindingSeq(Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditFindingSeqNextVal = 0;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_FINDING_SEQ_NEXTVAL);

      rs = ps.executeQuery();

      while (rs.next()) {
        auditFindingSeqNextVal = rs.getInt("NEXTVAL");
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_finding_seq: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

    return auditFindingSeqNextVal;
  }


  int getAuditID(String auditNumber, Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditID = 0;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_ID);
      ps.setString(1, auditNumber);

      rs = ps.executeQuery();

      while (rs.next()) {
        auditID = rs.getInt("AUDIT_ID");
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_id: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }


    return auditID;
  }


  int getAuditFromFinding(int findingID, Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    int auditID = 0;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_FROM_FINDING);
      ps.setInt(1, findingID);

      rs = ps.executeQuery();

      while (rs.next()) {
        auditID = rs.getInt("AUDIT_ID");
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_id from finding_id: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }


    return auditID;
  }


  String getAuditNoFromFinding(int findingID, Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    String auditNumber = "";

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_NUMBER_FROM_FINDING);
      ps.setInt(1, findingID);
      rs = ps.executeQuery();

      while (rs.next()) {
        auditNumber = rs.getString("AUDIT_NUMBER");
      }

      return auditNumber;
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit_id from finding_id: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

    return "";
  }

  void getAuditDetails(int auditID, AuditObject audit, Connection conn) {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_DETAILS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();

      while (rs.next()) {
        //**Required Fields...
        audit.setAuditID(rs.getInt("AUDIT_ID") + "");
        audit.setLocationCode(rs.getString("LOCATION_CODE"));
        audit.setAuditDate(getDateFormat(rs.getDate("AUDIT_DATE")));
        audit.setAuditNumber(rs.getString("AUDIT_NUMBER"));
        audit.setAuditor(rs.getString("AUDITOR"));
        audit.setRowUserID(rs.getString("ROW_USER_ID"));
        audit.setRegion_id(rs.getInt("REGION_ID") + "");
        audit.setFunctionId(rs.getInt("LOCATION_FUNCTION_ID") + "");
        audit.setBusinessId(rs.getInt("BUSINESS_ID"));
        audit.setDeleted(rs.getString("IS_DELETED"));
        audit.setProgramId(rs.getString("PROGRAM_ID"));
        audit.setAuditType(rs.getString("AUDIT_TYPE_ID"));
        audit.setIssue_year(rs.getString("ISSUE_YEAR_ID"));
        audit.setCreatedBy(rs.getString("CREATED_BY"));

        //**Optional Fields...
        if (rs.getString("ISO_CONTACT") != null && !rs.getString("ISO_CONTACT").equals("")) {
          audit.setSiteISOContact(rs.getString("ISO_CONTACT"));
        }
        if (rs.getString("AUDIT_OVERVIEW") != null && !rs.getString("AUDIT_OVERVIEW").equals("")) {
          audit.setAuditOverview(rs.getString("AUDIT_OVERVIEW"));
        }
        if (rs.getString("PREPARED_BY") != null && !rs.getString("PREPARED_BY").equals("")) {
          audit.setPreparedBy(rs.getString("PREPARED_BY"));
        }
        if (rs.getString("PREPARED_DATE") != null && !rs.getString("PREPARED_DATE").equals("")) {
          audit.setPreparedDate(getDateFormat(rs.getDate("PREPARED_DATE")));
        }
        if (!StringUtils.isNullOrEmpty(rs.getString("AUDIT_MEMBERS"))) {
          audit.setAuditMembers(rs.getString("AUDIT_MEMBERS"));
        }
        if (!StringUtils.isNullOrEmpty(rs.getString("AUDIT_PROCESS"))) {
          audit.setAuditProcess(rs.getString("AUDIT_PROCESS"));
        }
        if (!StringUtils.isNullOrEmpty(rs.getString("AUDIT_PROCEDURE"))) {
          audit.setAuditProcedure(rs.getString("AUDIT_PROCEDURE"));
        }
        if (!StringUtils.isNullOrEmpty(rs.getString("PERSONS_AUDITED"))) {
          audit.setPersonsAudited(rs.getString("PERSONS_AUDITED"));
        }
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit details: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }


  void getFunctionalAreas(int auditID, AuditObject audit, Connection conn) {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_AREAS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();

      Vector<String> functionalAreas = new Vector<String>();

      while (rs.next()) {
        functionalAreas.add(rs.getInt("AUDIT_AREA_ID") + "");
      }

      for (String functionalArea : functionalAreas) {
        if (functionalArea.equals("1")) {
          audit.setConditioning(true);
        }
        if (functionalArea.equals("2")) {
          audit.setHarvest(true);
        }
        if (functionalArea.equals("3")) {
          audit.setPackaging(true);
        }
        if (functionalArea.equals("4")) {
          audit.setQaLab(true);
        }
        if (functionalArea.equals("5")) {
          audit.setWarehouseDistribution(true);
        }
        if (functionalArea.equals("6")) {
          audit.setField(true);
        }
        if (functionalArea.equals("7")) {
          audit.setPlanting(true);
        }
        if (functionalArea.equals("8")) {
          audit.setOffSiteFacilities(true);
        }
      }

    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting audit areas: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }


  protected HashMap<String, FindingObject> getClosedFindings(String auditId, Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;
    HashMap<String, FindingObject> closedFindingsMap = new HashMap<String, FindingObject>();

    try {
      ps = conn.prepareStatement("select finding_id, reason, user_id from closed_ofis where audit_id = ?");
      ps.setLong(1, Long.parseLong(auditId));

      rs = ps.executeQuery();

      while (rs.next()) {
        FindingObject findingObj = new FindingObject();

        findingObj.setAckFindingId(rs.getString("finding_id"));
        findingObj.setAckAndCloseText(rs.getString("reason"));
        findingObj.setUserNameOfPersonWhoClosedFinding(rs.getString("user_id"));
        closedFindingsMap.put(findingObj.getAckFindingId(), findingObj);
      }
    } catch (Exception e) {
      MCASLogUtil.logError("could not load closed findings", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

    return closedFindingsMap;
  }

  void getFindingDetails(int auditID, AuditObject audit, Connection conn, String locale) {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_FINDING_DETAILS);
      ps.setInt(1, auditID);

      rs = ps.executeQuery();
      I18nServiceImpl iService = new I18nServiceImpl();

      HashMap<String, FindingObject> closedFindings = getClosedFindings(audit.getAuditID(), conn);
      FindingObject f;
      while (rs.next()) {

        FindingObject findingObj = new FindingObject();

        int findingID = rs.getInt("AUDIT_FINDING_ID");

        findingObj.setFindingID(findingID + "");
        String desc = iService.translate(locale, "M_AUDIT_FINDINGS", findingID, rs.getString("DESCRIPTION"));

        findingObj.setFindingDesc(desc);
        findingObj.setRowUserID(rs.getString("ROW_USER_ID"));
        findingObj.setCar_flag(rs.getString("CAR_FLAG"));

        //**Get car_id/ctrl_no
        getCparDetails(findingID, findingObj, conn, locale);

        f = closedFindings.get(findingObj.getFindingID());

        if (f != null) {
          findingObj.setAckAndCloseText(f.getAckAndCloseText());
          findingObj.setAckFindingId(f.getAckFindingId());
          findingObj.setUserNameOfPersonWhoClosedFinding(f.getUserNameOfPersonWhoClosedFinding());
        }
        //CAR-Map
        if (rs.getString("CAR_FLAG").equals("Y")) {
          audit.getFindingCarMap().put(findingObj.getFindingID(), findingObj);
        }

        //PAR-Map
        if (rs.getString("CAR_FLAG").equals("N")) {
          audit.getFindingParMap().put(findingObj.getFindingID(), findingObj);
        }

        if (rs.getString("CAR_FLAG").equals("C")) {
          audit.getFindingCiMap().put(findingObj.getFindingID(), findingObj);
        }

      }

    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting finding details: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  void getAuditAttachments(int auditID, AuditObject audit, Connection conn) {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_AUDIT_ATTACHMENTS);
      ps.setInt(1, auditID);
      rs = ps.executeQuery();
      while (rs.next()) {
        String documentId = rs.getString("DOCUMENT_ID");
        String complaintId = rs.getString("AUDIT_ID");
        String documentName = rs.getString("DOCUMENT_NAME");
        AttachmentInfo attachmentInfo = new AttachmentInfo(complaintId, documentId, documentName);
        audit.getAuditAttachments().put(documentId, attachmentInfo);
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting Audit Attachments: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  public void getCparDetails(int findingID, FindingObject findingObj, Connection conn, String locale) {
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_CPAR_DETAILS);
      ps.setInt(1, findingID);

      rs = ps.executeQuery();
      I18nServiceImpl iService = new I18nServiceImpl();

      while (rs.next()) {
        findingObj.setCparID(rs.getInt("CPAR_ID") + "");
        findingObj.setControlNumber(rs.getString("CONTROL_NUMBER"));

        int id = rs.getInt("FINDING_TYPE_ID");
        String desc = iService.translate(locale, "FINDING_TYPE_REF", id, rs.getString("FINDING_TYPE"));

        findingObj.setFindingType(desc);
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting cpar details: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  Date getOracleSysDate(Connection conn) {

    PreparedStatement ps = null;
    ResultSet rs = null;

    Date oracleSysdate = new Date(System.currentTimeMillis());

    //**Get the oracle sysdate...
    try {
      ps = conn.prepareStatement(AuditDAOSQLConstants.GET_ORACLE_SYSDATE);

      rs = ps.executeQuery();

      while (rs.next()) {
        oracleSysdate = rs.getDate("SYSDATE");
      }
    } catch (Exception e) {
      MCASLogUtil.logError("Exception while getting sysdate: ", e);
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }

    return oracleSysdate;
  }

  private String getDateFormat(Date date) {
    try {
      return sdf.format(date);
    } catch (Exception e) {
      MCASLogUtil.logError(e.getMessage(), e);
      return "";
    }
  }

  /**
   * Private method to parse the selected Complaint Issue IDs
   *
   * @param idList
   *
   * @return
   */
  private String buildInClause(List<Integer> idList) {
    return MCASUtil.buildInClause(idList);
  }

}
