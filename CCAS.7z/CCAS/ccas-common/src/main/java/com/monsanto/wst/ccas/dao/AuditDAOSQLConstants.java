package com.monsanto.wst.ccas.dao;

abstract class AuditDAOSQLConstants {
    static final String INSERT_AUDIT_SQL = "INSERT INTO M_AUDIT " +
            "(AUDIT_ID, LOCATION_CODE, AUDIT_DATE, AUDIT_NUMBER, " +
            "AUDITOR, REGION_ID, ROW_USER_ID, ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE, LOCATION_FUNCTION_ID,BUSINESS_ID,IS_DELETED,AUDIT_MEMBERS," +
            "PERSONS_AUDITED,AUDIT_PROCESS,AUDIT_PROCEDURE, PROGRAM_ID,AUDIT_TYPE_ID, ISSUE_YEAR_ID, CREATED_BY) " +
            "VALUES " +
            "(?, ?, ?, ?, " +
            "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    static final String INSERT_AUDIT_FINDING_SQL = ("INSERT " +
            "INTO M_AUDIT_FINDINGS " +
            "(AUDIT_FINDING_ID, AUDIT_ID, " +
            "DESCRIPTION, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, " +
            "ROW_MODIFY_DATE, CAR_FLAG)" +
            "VALUES " +
            "(?, ?, " +
            "?, ?, " +
            "?, ?, " +
            "?, ?)");
    static final String UPDATE_AUDIT_FINDING_SQL = ("UPDATE " +
            "M_AUDIT_FINDINGS " +
            "SET " +
            "DESCRIPTION = ?, " +
            "ROW_USER_ID = ?, " +
            "ROW_TASK_ID = ?, " +
            "ROW_MODIFY_DATE = ? " +
            "WHERE " +
            "AUDIT_FINDING_ID = ?");
    static final String GET_AUDIT_SEQ_NEXTVAL = "SELECT AUDIT_SEQ.NEXTVAL FROM DUAL";
    static final String GET_AUDIT_FINDING_SEQ_NEXTVAL = "SELECT AUDIT_FINDING_SEQ.NEXTVAL FROM DUAL";
    static final String GET_ORACLE_SYSDATE = "SELECT SYSDATE FROM DUAL";
    static final String INSERT_AUDIT_AREAS = ("INSERT INTO M_AUDIT_AREAS " +
            "(AUDIT_ID, AUDIT_AREA_ID) " +
            "VALUES (?, ?)");
    static final String UPDATE_AUDIT_OVERVIEW = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "AUDIT_OVERVIEW = ? " +
            "WHERE " +
            "AUDIT_ID = ?");
    static final String UPDATE_AUDIT_PROCESS_MEMBER = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "AUDIT_MEMBERS = ?, AUDIT_PROCESS = ?, AUDIT_PROCEDURE = ?, PERSONS_AUDITED = ?  " +
            "WHERE " +
            "AUDIT_ID = ?");
    static final String UPDATE_PREPARED_BY = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "PREPARED_BY = ? " +
            "WHERE " +
            "AUDIT_ID = ?");
    static final String UPDATE_PREPARED_DATE = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "PREPARED_DATE = ? " +
            "WHERE AUDIT_ID = ?");
    static final String UPDATE_ISO_CONTACT = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "ISO_CONTACT = ? " +
            "WHERE " +
            "AUDIT_ID = ?");
    static final String AUTO_AUDIT_NUMBER = ("SELECT " +
            "MAX(TO_NUMBER(SUBSTR(AUDIT_NUMBER,LENGTH('A-XXXX-YY-')+1))) MAX " +
            "FROM " +
            "M_AUDIT " +
            "WHERE " +
            "AUDIT_NUMBER LIKE ?");

    static final String AUTO_AUDIT_NUMBER_SBFAS = ("SELECT " +
            "MAX(TO_NUMBER(SUBSTR(AUDIT_NUMBER,LENGTH('A-ZZZ-XXXX-YY-')+1))) MAX " +
            "FROM " +
            "M_AUDIT " +
            "WHERE " +
            "AUDIT_NUMBER LIKE ?");
    static final String GET_AUDIT_ID = ("SELECT AUDIT_ID FROM M_AUDIT WHERE AUDIT_NUMBER = ?");
    static final String UPDATE_AUDIT_SQL = ("UPDATE " +
            "M_AUDIT " +
            "SET " +
            "LOCATION_CODE = ?, " +
            "AUDIT_DATE = ?, " +
            "AUDITOR = ?, " +
            "REGION_ID = ?, " +
            "ROW_USER_ID = ?, " +
            "ROW_TASK_ID = ?, " +
            "ROW_MODIFY_DATE = ?," +
            "LOCATION_FUNCTION_ID = ?, PROGRAM_ID = ?, AUDIT_TYPE_ID = ? " +
            "WHERE " +
            "AUDIT_ID = ?");
    static final String GET_AUDIT_FROM_FINDING = ("SELECT AUDIT_ID FROM M_AUDIT_FINDINGS WHERE AUDIT_FINDING_ID = ?");
    static final String GET_AUDIT_DETAILS = ("SELECT * FROM M_AUDIT WHERE AUDIT_ID = ?");
    static final String GET_AUDIT_AREAS = ("SELECT AUDIT_AREA_ID FROM M_AUDIT_AREAS WHERE AUDIT_ID = ?");
    static final String GET_FINDING_DETAILS = ("SELECT * FROM M_AUDIT_FINDINGS WHERE AUDIT_ID = ?");
    static final String GET_CPAR_DETAILS = ("SELECT " +
            "C.CPAR_ID, " +
            "C.CONTROL_NUMBER, " +
            "(SELECT FT.DESCRIPTION " +
            "FROM FINDING_TYPE_REF FT " +
            "WHERE FT.FINDING_TYPE_ID = C.FINDING_TYPE_ID) FINDING_TYPE, " +
            "C.FINDING_TYPE_ID " +
            "FROM " +
            "CPAR C " +
            "WHERE C.IS_DELETED = 'N' AND " +
            "C.AUDIT_FINDING_ID = ?");
    static final String GET_AUDIT_LIST = (
            "SELECT  AUDIT_ID,AUDIT_NUMBER,SITE,AUDIT_DATE,AUDIT_OVERVIEW,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, RANKING FROM  " +
                    "(SELECT  AUDIT_ID,AUDIT_NUMBER,SITE,AUDIT_DATE,AUDIT_OVERVIEW,AUDITOR,PREPARED_BY,CONTROL_NUMBER, CPAR_ID, ROWNUM AS RANKING " +
                    " FROM " +
                    "( SELECT " +
                    "A.AUDIT_ID AUDIT_ID,A.AUDIT_NUMBER AUDIT_NUMBER, " +
                    "(SELECT L.LOCATION_SHORT_NAME " +
                    "FROM LOCATION_REF L " +
                    "WHERE L.LOCATION_CODE=A.LOCATION_CODE) SITE, " +
                    "A.AUDIT_DATE, " +
                    "A.AUDIT_OVERVIEW, " +
                    "A.AUDITOR, " +
                    "A.PREPARED_BY, " +
                    "NULL CONTROL_NUMBER, " +
                    "NUll CPAR_ID  " +
                    "FROM  M_AUDIT A  WHERE A.IS_DELETED <> 'Y'  ");
    static final String AUDIT_LIST_WITH_FINDING_WRAPPER_BIOTECCAS = "SELECT " +
            "RANKING," +
            "AUDIT_ID," +
            "AUDIT_NUMBER," +
            "SITE," +
            "AUDIT_DATE," +
            "AUDIT_OVERVIEW," +
            "AUDITOR," +
            "PREPARED_BY from ( ";
    static final String AUDIT_LIST_WITH_FINDING_WRAPPER = "SELECT " +
            "RANKING," +
            "AUDIT_ID," +
            "AUDIT_NUMBER," +
            "SITE," +
            "AUDIT_DATE," +
            "AUDIT_OVERVIEW," +
            "AUDITOR," +
            "PREPARED_BY," +
            "CONTROL_NUMBER, " +
            "CPAR_ID from ( ";
     static final String GET_AUDIT_LIST_WITH_FINDINGS = "SELECT ROWNUM AS RANKING, " +
            "AUDIT_ID," +
            "AUDIT_NUMBER," +
            "SITE," +
            "AUDIT_DATE," +
            "AUDIT_OVERVIEW," +
            "AUDITOR," +
            "PREPARED_BY," +
            "CONTROL_NUMBER," +
            "CPAR_ID from  " +
            "( select " +
            "a.audit_id,    " +
            "a.audit_number,    " +
            "a.audit_date,    " +
            "a.audit_overview,    " +
            "l.location_short_name as SITE," +
            "a.auditor," +
            "a.prepared_by," +
            "cf.control_number," +
            "cf.cpar_id " +
            "from M_AUDIT a, " +
            "location_ref l," +
            "(  select" +
            "   f.audit_id," +
            "   c.control_number," +
            "   c.cpar_id" +
            "   from " +
            "   M_AUDIT_FINDINGS f ,cpar c" +
            "   where         " +
            "   f.audit_finding_id = c.audit_finding_id) cf" +
            "   where a.is_deleted = 'N'" +
            "   and l.location_code = a.location_code " +
            "   AND a.audit_id = cf.audit_id (+) ";
    static final String GET_AUDIT_LIST_WITH_FINDINGS_BIOTECCAS = "SELECT ROWNUM AS RANKING, " +
            "AUDIT_ID," +
            "AUDIT_NUMBER," +
            "SITE," +
            "AUDIT_DATE," +
            "AUDIT_OVERVIEW," +
            "AUDITOR," +
            "PREPARED_BY from  " +
            "( select " +
            "a.audit_id,    " +
            "a.audit_number,    " +
            "a.audit_date,    " +
            "a.audit_overview,    " +
            "l.location_short_name as SITE," +
            "a.auditor," +
            "a.prepared_by " +
            "from M_AUDIT a, " +
            "location_ref l" +

            "   where a.is_deleted = 'N'" +
            "   and l.location_code = a.location_code " +
            " ";
    static final String GET_AUDIT_LIST_COUNT = ("SELECT " +
            "COUNT(*) COUNT " +
            "FROM " +
            "M_AUDIT A WHERE A.IS_DELETED <> 'Y'  ");
    static final String GET_AUDIT_LIST_CPAR = ("SELECT " +
            "A.AUDIT_ID AUDIT_ID, A.AUDIT_NUMBER AUDIT_NUMBER, " +
            "L.LOCATION_SHORT_NAME SITE, A.AUDIT_DATE, " +
            "A.AUDITOR, A.PREPARED_BY,A.AUDIT_OVERVIEW, " +
            "CP.CPAR_ID, " +
            "CP.CONTROL_NUMBER " +
            "FROM " +
            "M_AUDIT A, LOCATION_REF L, " +
            "M_AUDIT_FINDINGS F, CPAR CP " +
            "WHERE " +
            "A.LOCATION_CODE = L.LOCATION_CODE AND " +
            "A.AUDIT_ID = F.AUDIT_ID AND " +
            "F.AUDIT_FINDING_ID = CP.AUDIT_FINDING_ID AND " +
            "CP.IS_DELETED = 'N' AND A.IS_DELETED = 'N' AND " +
            "UPPER(CP.CONTROL_NUMBER) = ? ");
    static final String DELETE_AUDIT_AREAS = ("DELETE FROM M_AUDIT_AREAS WHERE AUDIT_ID = ?");
    static final String GET_AUDIT_NUMBER_FROM_FINDING = ("SELECT " +
            "A.AUDIT_NUMBER " +
            "FROM " +
            "M_AUDIT A, M_AUDIT_FINDINGS F " +
            "WHERE " +
            "A.AUDIT_ID = F.AUDIT_ID AND A.IS_DELETED = 'N' AND " +
            "F.AUDIT_FINDING_ID = ?");
    static final String GET_AUDIT_REPORT = "SELECT " +
            "M_AUDIT.AUDIT_NUMBER, " +
            "M_AUDIT.LOCATION_CODE, " +
            "LOCATION_REF.LOCATION_SHORT_NAME, " +
            "M_AUDIT.AUDIT_OVERVIEW, " +
            "CPAR.CONTROL_NUMBER AS CAR_PAR_NUMBER, " +
            "M_AUDIT.AUDIT_DATE, " +
            "M_AUDIT_AREAS_REF.AREA_ID, " +
            "M_AUDIT_AREAS_REF.DESCRIPTION AS AUDIT_AREA, " +
            "M_AUDIT_FINDINGS.DESCRIPTION AS FINDING, " +
            "M_AUDIT.AUDITOR, " +
            "M_AUDIT.ISO_CONTACT, " +
            "REGION_REF.REGION_DESCRIPTION AS REGION, " +
            "M_AUDIT.PREPARED_BY, " +
            "M_AUDIT.PREPARED_DATE, " +
            "M_AUDIT.LOCATION_FUNCTION_ID " +
            "FROM " +
            "M_AUDIT, " +
            "LOCATION_REF, " +
            "REGION_REF, " +
            "M_AUDIT_AREAS, " +
            "M_AUDIT_AREAS_REF, " +
            "M_AUDIT_FINDINGS, " +
            "CPAR " +
            "WHERE " +
            "LOCATION_REF.LOCATION_CODE = M_AUDIT.LOCATION_CODE    AND " +
            "REGION_REF.REGION_ID = M_AUDIT.REGION_ID    AND " +
            "M_AUDIT.AUDIT_ID = M_AUDIT_AREAS.AUDIT_ID(+)    AND " +
            "M_AUDIT_AREAS_REF.AREA_ID(+) = M_AUDIT_AREAS.AUDIT_AREA_ID    AND " +
            "M_AUDIT.AUDIT_ID = M_AUDIT_FINDINGS.AUDIT_ID(+) AND  M_AUDIT.IS_DELETED ='N' AND " +
            "M_AUDIT_FINDINGS.AUDIT_FINDING_ID = CPAR.AUDIT_FINDING_ID(+) ";
    static final String ADD_AUDIT_ATTACHMENT = "INSERT INTO audit_attachment aa " +
            "            (aa.document_id, aa.audit_id, aa.document_name " +
            "            ) " +
            "     VALUES (?, ?, ? " +
            "            ) ";
    static final String DELETE_AUDIT_ATTACHMENT = "DELETE FROM audit_attachment aa " +
            "      WHERE aa.document_id = ? ";
    static final String DELETE_AUDIT = "UPDATE M_AUDIT SET IS_DELETED = 'Y' WHERE AUDIT_NUMBER = ? ";
    static final String GET_AUDIT_ATTACHMENTS = "SELECT aa.document_id, aa.audit_id, aa.document_name " +
            "  FROM audit_attachment aa " +
            " WHERE aa.audit_id = ? ";
    static final String INSERT_AUDIT_SUBFUNCTION = "INSERT INTO M_AUDIT_SUBFUNCTION " +
            "(ID, AUDIT_ID, SUBFUNCTION_ID) " +
            "VALUES " +
            "(AUDIT_SEQ.NEXTVAL, ?, ?)";
    static final String GET_AUDIT_SUBFUNCTION = "SELECT SUBFUNCTION_ID FROM M_AUDIT_SUBFUNCTION where AUDIT_ID = ?";
    static final String GET_AUDIT_AUDITORS = "SELECT AUDITOR_ONE,AUDITOR_TWO FROM M_AUDIT_AUDITORS where AUDIT_ID = ?";
    public static final String DELETE_AUDIT_SUBFUNCTION = "DELETE FROM M_AUDIT_SUBFUNCTION WHERE AUDIT_ID = ?";
    public static final String INSERT_AUDITORS_FOR_AN_AUDIT = "INSERT INTO M_AUDIT_AUDITORS (ID, AUDIT_ID, AUDITOR_ONE, AUDITOR_TWO) VALUES (AUDIT_SEQ.NEXTVAL, ?, ?, ?)";
    public static final String DELETE_AUDITORS_FOR_AN_AUDIT = "DELETE FROM M_AUDIT_AUDITORS WHERE AUDIT_ID = ?";
}
