package com.monsanto.wst.ccas.dao;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 8, 2010
 * Time: 10:43:50 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AutomatedEmailsDao extends BaseDAOImpl {

    public abstract int getContainmentActionDays() throws DAOException;

    public abstract int getRootCauseDays() throws DAOException;

    public abstract int getLongTermCorrectiveActionDays() throws DAOException;

    public abstract int getEvaluationOfEffectivenessDays() throws DAOException;

    public abstract int getEvaluationOfEffectivenessWarningDays() throws DAOException;

    public abstract int getCloseDays() throws DAOException;

    public abstract String getBeginDate() throws DAOException;    
}
