package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 8, 2010
 * Time: 10:45:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class AutomatedEmailsDaoImpl extends AutomatedEmailsDao {

    private Connection con;

    private static String CONTAINMENT_ACTION_SQL = "select CONTAINMENT_ACTION_DAYS from AUTOMATED_EMAILS";
    private static String ROOT_CAUSE_SQL = "select ROOT_CAUSE_DAYS from AUTOMATED_EMAILS";
    private static String CORRECTIVE_ACTION_SQL = "select CORRECTIVE_ACTION_DAYS from AUTOMATED_EMAILS";
    private static String EVALUATION_EFFECTIVENESS_SQL = "select EVALUATION_EFFECTIVENESS_DAYS from AUTOMATED_EMAILS";
    private static String EVALUATION_EFFECTIVENESS_WARNING_SQL = "select EVALUATION_EFFECTIVENESS_WARNG from AUTOMATED_EMAILS";
    private static String CLOSE_SQL = "select CLOSE_DAYS from AUTOMATED_EMAILS";
    private static String BEGIN_SQL = "select to_char(BEGIN_DATE,'YYYY-MON-DD') from AUTOMATED_EMAILS";

    private int getDays(String sql) throws DAOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            rs.next();
            return rs.getInt(1);
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        } finally {
            MCASResourceUtil.closeDBResources(null, stmt, rs);
        }
    }

    private String getDate(String sql) throws DAOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            rs.next();
            return rs.getString(1);
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        } finally {
            MCASResourceUtil.closeDBResources(null, stmt, rs);

        }
    }

    public AutomatedEmailsDaoImpl(Connection connection) {
        con = connection;
    }

    public int getContainmentActionDays() throws DAOException {
        return getDays(CONTAINMENT_ACTION_SQL);
    }

    public int getRootCauseDays() throws DAOException {
        return getDays(ROOT_CAUSE_SQL);
    }

    public int getLongTermCorrectiveActionDays() throws DAOException {
        return getDays(CORRECTIVE_ACTION_SQL);
    }

    public int getEvaluationOfEffectivenessDays() throws DAOException {
        return getDays(EVALUATION_EFFECTIVENESS_SQL);
    }

    public int getEvaluationOfEffectivenessWarningDays() throws DAOException {
        return getDays(EVALUATION_EFFECTIVENESS_WARNING_SQL);
    }

    public int getCloseDays() throws DAOException {
        return getDays(CLOSE_SQL);
    }

    public String getBeginDate() throws DAOException {
        return getDate(BEGIN_SQL);
    }
}
