/*
 * Created on Mar 30, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.DatabaseException;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.*;

/**
 * @author jbrahmb
 */
public class BaseDAOImpl {
    protected DataSource datasource = null;

    /**
     * Constructor. Initialize the datasource.
     *
     * @throws SQLException if lookup of datasource fails
     */
    protected BaseDAOImpl() {
        init();
    }

    protected void init() { //todo what are they doing here?  Overriding something the base constructor is using is not a good idea
        //to answer the question, based on a quick search it appears it is only overridden in Mocks.
        //I'm not sure why the Mocks don't just override the constructor.

        //           // Lookup for the datasource from JNDI tree
        datasource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
    }

    protected Connection getConnection() {
        try {
            Connection conn = datasource.getConnection();
            conn.setAutoCommit(false);
            return conn;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public void closeDBResources(Connection connection, Statement preparedStatement, ResultSet resultSet) {
        MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
    }
}
