/*
 BusinessDao was created on Apr 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

/**
 * Filename:    $RCSfile: BusinessDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface BusinessDao {
    String lookupBusinessWithId(int businessId, String locale);

    int getBusinessId(String user_id) throws DAOException;

    int getBusinessPreference(String user_id) throws DAOException;
}