/*
 BusinessDaoImpl was created on Apr 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.*;

/**
 * Filename:    $RCSfile: BusinessDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class BusinessDaoImpl implements BusinessDao {
    private final DataSource dataSource;

    public BusinessDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public BusinessDaoImpl() {
        this.dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
    }
                                                                                                                                            
    public String lookupBusinessWithId(int businessId, String locale) {
        String businessName = null;
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = dataSource.getConnection();
            preparedStatement = connection.prepareStatement("select description from business where business_id=?");
            preparedStatement.setInt(1, businessId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                businessName = iService.translate(locale, "BUSINESS", businessId, resultSet.getString("description"));
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return businessName;
    }

    public int getBusinessId(String userId) throws DAOException {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        int businessId = -1;
        String query = "SELECT BUSINESS_ID FROM USER_ADMINISTRATION UA WHERE UA.USER_ID = '" + userId + "'";
        try {
            connection = dataSource.getConnection();
            stmt = connection.createStatement();
            rs = stmt.executeQuery(query);
            if (rs != null) {
                if (rs.next()) {
                    businessId = rs.getInt("BUSINESS_ID");
                }
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception getting Connection to Database " + e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, stmt, rs);
        }
        return businessId;
    }

    public int getBusinessPreference(String userId) throws DAOException {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        int businessPreference = -1;
        String query = "SELECT BUSINESS_PREFERENCE_ID FROM USER_ADMINISTRATION UA WHERE UA.USER_ID = '" + userId + "'";
        try {
            connection = dataSource.getConnection();
            stmt = connection.createStatement();
            rs = stmt.executeQuery(query);
            if (rs != null) {
                if (rs.next()) {
                    businessPreference = rs.getInt("BUSINESS_PREFERENCE_ID");
                }
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception getting Connection to Database " + e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, stmt, rs);
        }
        return businessPreference;
    }

}
