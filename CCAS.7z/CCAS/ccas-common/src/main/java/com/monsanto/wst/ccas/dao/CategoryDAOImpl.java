/*
 CategoryDAOImpl was created on Aug 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.service.I18nServiceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class CategoryDAOImpl extends BaseDAOImpl implements CategoryDAO {
    public Map<String, String> lookupCategoriesByCriteria(String programId, String locale) {
        Connection conn = getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        Map<String, String> map = new HashMap<String, String>();

        try {
            statement = conn.prepareStatement(ProgramConstants.LOOKUP_CATEGORIES_BY_CRITERIA);
            statement.setString(1, programId);
            rs = statement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (rs.next()) {

                int id = rs.getInt("CATEGORY_ID");
                String description = iService.translate(locale, "COMPLAINT_CATEGORY", id, rs.getString("DESCRIPTION"));
                map.put(Integer.toString(id), description);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            closeDBResources(conn, statement, rs);
        }
        return map;
    }
}