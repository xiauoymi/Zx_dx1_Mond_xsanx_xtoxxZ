/*
 CheckboxItemDao was created on Jan 29, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.audits.CheckboxItem;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: FunctionalAreaDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public interface CheckboxItemDao {

    public Map<String, List<CheckboxItem>> lookupCheckboxGroups(int businessId, String entryType, String locale, Map<String, Boolean> roles, String appName);

    public Set<String> getSelectedItemsForRecord(int objectId, String entryType);

    public void insertCheckboxItemsForRecord(int objectId, String entryType, List<CheckboxItem> selectedItemList);

    public void deleteCheckboxItemsForRecord(int objectId, String entryType);

    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale);
}