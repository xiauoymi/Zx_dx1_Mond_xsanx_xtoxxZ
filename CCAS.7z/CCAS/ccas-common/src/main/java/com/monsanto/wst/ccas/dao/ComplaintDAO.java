/*
 * Created on Jan 13, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @author jbrahmb
 */
public interface ComplaintDAO {
    String getComplaintPK() throws DAOException;

    void insertComplaint(Complaint c) throws DAOException;

    void updateComplaint(Complaint c) throws DAOException;

    Complaint getComplaint(String complaint_id) throws DAOException;

    Map<String, String> findBatches(String batch_number, String complaint_stopsale_id, int businessId) throws DAOException;

    void updateComplaintDocumentation(Cpar cpar, String complaintId) throws DAOException;

    void updateCParIdInComplaintTable(Cpar cpar, String complaintId) throws DAOException;

    Map<String, RowBean> getComplaintReport(ComplaintFilter complaintFilter, int businessId, String locale) throws DAOException;

    boolean addComplaintAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException;

    boolean deleteComplaintAttachmentInfo(String documentId) throws DAOException;

    void deleteComplaint(String complaint) throws DAOException;

    void processComplaintInsert(List<String> complaintIdList) throws SQLException;

    void processComplaintDelete(List<String> complaintIdList) throws SQLException;

    Map<String, Object> getComplaintsList(ComplaintForCriteria complaintForCriteria, String locale) throws DAOException;

    Map<String, Object> getComplaintsListWOClaims(ComplaintForCriteria complaintForCriteria, String locale) throws
      DAOException;

    Map<String, String> lookupComplaintEntryTypeList();

    Map<String, String> lookupDispositionListForDescription(String locale);

    String getComplaintEntryTypeAsString(String complaintId) throws DAOException;

    List<Disposition> lookupDispositionListForTeamLead(String locale);

    String[] getComplaintIdsFromCparId(String cparId);

    void insertCheckboxItemsForRecord(int complaintId, String sourceType, int complaint_issue_id) throws DAOException;

    int getVarietyBatchCombinationId(VarietyBatch varietyBatch);

     void getVarietyBatch(String complaint_id,Complaint c)throws DAOException;

     void deleteCheckboxItemsForComplaint(Complaint c) throws DAOException;



}
