package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.exception.DatabaseException;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.ServiceLocator;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class ComplaintDAOImpl extends BaseDAOImpl implements ComplaintDAO {
  private static final Category logger = Category.getInstance(ComplaintDAOImpl.class.getName());
  private final DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
  NonconformanceCategoryDaoImpl ncDao = new NonconformanceCategoryDaoImpl();
  RootCauseDaoImpl rcDao = new RootCauseDaoImpl();
  FunctionalAreaDaoImpl aaDao = new FunctionalAreaDaoImpl();

  private static final int CAR_TYPE = 1;
  private static final int PAR_TYPE = 2;
  private static final int CI_TYPE = 4;

  public ComplaintDAOImpl() {
    // need explict constructor since super() throws checked exception
  }

  public String getComplaintPK() throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_PK_SQL);
      rs = ps.executeQuery();
      rs.next();
      return rs.getString(1);
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

  public void insertComplaint(Complaint c) throws DAOException {
    insertUpdateComplaint(c, false);
  }

  public void updateComplaint(Complaint c) throws DAOException {
    insertUpdateComplaint(c, true);
  }

  private String determineStopSaleNumber(Connection conn, ResultSet rs) throws SQLException {
    if ("Stop Sale".equals(rs.getString("TYPE"))) {

      PreparedStatement ps2 = null;
      ResultSet rs2 = null;

      try {
        ps2 = conn.prepareStatement(ComplaintDAOSQLConstants.GET_STOP_SALE_NUMBER_FROM_ID);
        ps2.setString(1, rs.getString("ID"));

        rs2 = ps2.executeQuery();

        String stopSaleNumber = "";
        while (rs2.next()) {
          stopSaleNumber = rs2.getString(
              "STOP_SALE_NUMBER"); //todo why are we doing this loop?  Why do we only want the last stopSaleNumber?
        }

        return stopSaleNumber;

      } finally {
        MCASResourceUtil.closeDBResources(null, ps2, rs2);
      }


    } else {
      return rs.getString("ID");
    }
  }

  public Map<String, String> findBatches(String batch_number, String complaint_stopsale_id, int businessId) throws
      DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(
          ComplaintDAOSQLConstants.FIND_BATCHES + batch_number + "') and A.ID <> " + complaint_stopsale_id);
      ps.setInt(1, businessId);
      ps.setInt(2, businessId);
//      System.out.println(ComplaintDAOSQLConstants.FIND_BATCHES + batch_number + "') and A.ID <> " + complaint_stopsale_id);

      rs = ps.executeQuery();
      if (rs == null) {
        return null; //todo why null and not an empty map? I don't know.  That's the old behavior and not the refactoring I'm dealing with at the moment
      }

      Map<String, String> result = new HashMap<String, String>();
      while (rs.next()) {
        String stopSaleNumber = determineStopSaleNumber(conn, rs);
        result.put(rs.getString("ID"), stopSaleNumber + " - " + rs.getString("TYPE"));
      }
      return result;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

  private void appendToSQLIfNotNullOrBlank(StringBuffer whereClause, CharSequence value, String sqlFragment) {
    if (isNotNullOrBlank(value)) {
      whereClause.append(sqlFragment);
    }
  }

  private boolean isNotNullOrBlank(CharSequence value) {
    return value != null && value.length() > 0;
  }

  private void appendToSQLIfNotNullOrZero(StringBuffer whereClause, CharSequence value, String sqlFragment) {
    if (isNotNullOrBlank(value) && !"0".equals(value)) {
      whereClause.append(sqlFragment);
    }
  }

  private void appendToSQLIfNotZero(StringBuffer whereClause, int value, String sqlFragment) {
    if (value != 0) {
      whereClause.append(sqlFragment);
    }
  }

  public Map<String, Object> getComplaintsList(ComplaintForCriteria complaintForCriteria, String locale) throws
      DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    Map<String, Object> complaints = new LinkedHashMap<String, Object>();
    StringBuffer countQuery = new StringBuffer("SELECT COUNT(*) AS MAXROWS FROM ( ");
    String lastQuery = "";

    try {
      conn = getConnection();
      StringBuffer whereClause = buildWhereClause(complaintForCriteria);
      StringBuffer fromTablesBuffer = new StringBuffer(ComplaintDAOSQLConstants.FROM_TABLES_LIST);

      StringBuffer filterClauseBuffer = appendTableNames(complaintForCriteria);

      StringBuffer cisCropStateSalesYearBuffer = new StringBuffer();
      appendCropStateSalesYearFilterClause(cisCropStateSalesYearBuffer, complaintForCriteria, whereClause);

      getComplaintListQuery(complaintForCriteria, countQuery, whereClause, fromTablesBuffer, filterClauseBuffer,
          cisCropStateSalesYearBuffer, true).append(" ) )");

      try {
        lastQuery = countQuery.toString();
        ps = configureConnection(conn, countQuery, complaintForCriteria, ps);
        rs = ps.executeQuery();
        if (rs.next()) {
          complaints.put("maxRows", rs.getInt(1));
        }
      } finally {
        closeDBResources(null, ps, rs);
      }

      StringBuffer query = new StringBuffer();
      query = getComplaintListQuery(complaintForCriteria, query, whereClause, fromTablesBuffer, filterClauseBuffer,
          cisCropStateSalesYearBuffer, false).append(complaintForCriteria.getOrderByClause());

      lastQuery = query.toString();
      ps = configureConnection(conn, query, complaintForCriteria, ps);
      rs = ps.executeQuery();
      populateComplaintListMap(rs, complaints, locale);
      return complaints;
    } catch (SQLException e) {
      MCASLogUtil.logError(lastQuery, e);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

    public Map<String, Object> getComplaintsListWOClaims(ComplaintForCriteria complaintForCriteria, String locale) throws
      DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    Map<String, Object> complaints = new LinkedHashMap<String, Object>();
    StringBuffer countQuery = new StringBuffer("SELECT COUNT(*) AS MAXROWS FROM ( ");
    String lastQuery = "";

    try {
      conn = getConnection();
      StringBuffer whereClause = buildWhereClause(complaintForCriteria);
      StringBuffer fromTablesBuffer = new StringBuffer(ComplaintDAOSQLConstants.FROM_TABLES_LIST);

      StringBuffer filterClauseBuffer = appendTableNamesWOClaims(complaintForCriteria);

      StringBuffer cisCropStateSalesYearBuffer = new StringBuffer();
      appendCropStateSalesYearFilterClause(cisCropStateSalesYearBuffer, complaintForCriteria, whereClause);

      getComplaintListQueryWOClaim(complaintForCriteria, countQuery, whereClause, fromTablesBuffer, filterClauseBuffer,
          cisCropStateSalesYearBuffer, true).append(" ) )");

      try {
        lastQuery = countQuery.toString();
        ps = configureConnectionWOClaims(conn, countQuery, complaintForCriteria, ps);
        rs = ps.executeQuery();
        if (rs.next()) {
          complaints.put("maxRows", rs.getInt(1));
        }
      } finally {
        closeDBResources(null, ps, rs);
      }

      StringBuffer query = new StringBuffer();
      query = getComplaintListQueryWOClaim(complaintForCriteria, query, whereClause, fromTablesBuffer, filterClauseBuffer,
          cisCropStateSalesYearBuffer, false).append(complaintForCriteria.getOrderByClause());

      lastQuery = query.toString();
      ps = configureConnectionWOClaims(conn, query, complaintForCriteria, ps);
      rs = ps.executeQuery();
      populateComplaintListMap(rs, complaints, locale);
      return complaints;
    } catch (SQLException e) {
      MCASLogUtil.logError(lastQuery, e);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

  protected void populateComplaintListMap(ResultSet rs, Map<String, Object> complaints, String locale) throws
      SQLException, DAOException {
    I18nServiceImpl iService = new I18nServiceImpl();

    while (rs.next()) {
      int statusId = rs.getInt("STATUS_ID");
      String statusDesc = iService.translate(locale, "STATUS_REF", statusId, rs.getString("STATUS_DESCRIPTION"));
      int regionId = rs.getInt("REGION_ID");
      String regionDescription = iService.translate(locale, "REGION_REF", regionId, rs.getString("REGION_DESCRIPTION"));

      complaints.put(rs.getString("COMPLAINT_ID"),
          (new ComplaintSearchResult(rs.getString("COMPLAINT_ID"), sdf.format(rs.getDate("ROW_ENTRY_DATE")),
              rs.getString("REPORT_INITIATOR"), trimProblemDescriptionText(rs.getString("PROBLEM_DESCRIPTION")),
              rs.getString("SALES_YR"),
              statusDesc, regionDescription,
              rs.getString("CLAIM_NUMBER"), rs.getString("CUSTOMER"),
              lookupComplaintEntryTypeStringFromEntryTypeId(rs.getInt("COMPLAINT_ENTRY_TYPE_ID")),
              rs.getString("PROGRAM_DESCRIPTION"))));
    }
  }

  private PreparedStatement configureConnection(Connection conn, StringBuffer query,
                                                ComplaintForCriteria complaintForCriteria, PreparedStatement ps) throws
      SQLException {
    ps = conn.prepareStatement(query.toString());
    ps.setInt(1, complaintForCriteria.getModifiedUserBusinessPreferenceId());
    ps.setInt(2, complaintForCriteria.getModifiedUserBusinessPreferenceId());
    if (!isMCASRowCropUser(complaintForCriteria) ||
        StringUtils.isNullOrEmpty(complaintForCriteria.getClaimStatusIndicator()))
      ps.setInt(3, complaintForCriteria.getModifiedUserBusinessPreferenceId());
    return ps;
  }

    private PreparedStatement configureConnectionWOClaims(Connection conn, StringBuffer query,
                                                ComplaintForCriteria complaintForCriteria, PreparedStatement ps) throws
      SQLException {
    ps = conn.prepareStatement(query.toString());
    ps.setInt(1, complaintForCriteria.getModifiedUserBusinessPreferenceId());
    ps.setInt(2, complaintForCriteria.getModifiedUserBusinessPreferenceId());
    return ps;
  }

  private StringBuffer getComplaintListQuery(ComplaintForCriteria complaintForCriteria, StringBuffer countQuery,
                                             StringBuffer whereClause,
                                             StringBuffer fromTablesBuffer, StringBuffer filterClauseBuffer,
                                             StringBuffer cropFilterClause, boolean isMaxRowQry) {

    if (isMaxRowQry) {
      countQuery.append(ComplaintDAOSQLConstants.OUTER_SELECT_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.MAIN_SELECT_COLUMN_LIST).append(fromTablesBuffer)
          .append(filterClauseBuffer.toString()).append(ComplaintDAOSQLConstants.MAIN_SELECT_IN_CLAUSE)
          .append(ComplaintDAOSQLConstants.COMMON_OUTER_FILTER_CRITERIA);
      if (isMCASRowCropUser(complaintForCriteria) && !isGrowerAndDealerNameEmpty(complaintForCriteria)) {
        countQuery.append(" AND complaint.CLAIM_NUMBER = CV.CLAIM_ID(+) ");
      }
      countQuery.append(appendSalesYearFilter(complaintForCriteria)).append(" and complaint.complaint_id IN  ( ");
      if (!isMCASRowCropUser(complaintForCriteria) ||
          StringUtils.isNullOrEmpty(complaintForCriteria.getClaimStatusIndicator())) {
          if(validateUseNewView(complaintForCriteria)){
             countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS_NEW_VIEW)
            .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);
          }
          else{
            countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS)
            .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);
          }

      }
      countQuery.append(appendInnserSelectTableNames(complaintForCriteria))
          .append(getInnerSelectFilterClause(complaintForCriteria)).append(" )")
          .append(" ) ").append(whereClause);
    } else {
      countQuery.append(ComplaintDAOSQLConstants.OUTER_SELECT_ALL_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.OUTER_SELECT_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.MAIN_SELECT_COLUMN_LIST).append(fromTablesBuffer)
          .append(filterClauseBuffer.toString()).append(ComplaintDAOSQLConstants.MAIN_SELECT_IN_CLAUSE)
          .append(ComplaintDAOSQLConstants.COMMON_OUTER_FILTER_CRITERIA);
      if (isMCASRowCropUser(complaintForCriteria) && !isGrowerAndDealerNameEmpty(complaintForCriteria)) {
        countQuery.append(" AND complaint.CLAIM_NUMBER = CV.CLAIM_ID(+) ");
      }
      countQuery.append(appendSalesYearFilter(complaintForCriteria)).append(" and complaint.complaint_id IN  ( ");
      if (!isMCASRowCropUser(complaintForCriteria) ||
          StringUtils.isNullOrEmpty(complaintForCriteria.getClaimStatusIndicator())) {
          if(validateUseNewView(complaintForCriteria)){
            countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS_NEW_VIEW)
            .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);
          }
          else{
            countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS)
            .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);
          }

      }
      countQuery.append(appendInnserSelectTableNames(complaintForCriteria))
          .append(getInnerSelectFilterClause(complaintForCriteria)).append(" )")
          .append(" ) ").append(whereClause);
    }
    return countQuery;
  }

  private StringBuffer getComplaintListQueryWOClaim(ComplaintForCriteria complaintForCriteria, StringBuffer countQuery,
                                             StringBuffer whereClause,
                                             StringBuffer fromTablesBuffer, StringBuffer filterClauseBuffer,
                                             StringBuffer cropFilterClause, boolean isMaxRowQry) {

    if (isMaxRowQry) {
      countQuery.append(ComplaintDAOSQLConstants.OUTER_SELECT_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.MAIN_SELECT_COLUMN_LIST).append(fromTablesBuffer)
          .append(filterClauseBuffer.toString()).append(ComplaintDAOSQLConstants.MAIN_SELECT_IN_CLAUSE)
          .append(ComplaintDAOSQLConstants.COMMON_OUTER_FILTER_CRITERIA);

      countQuery.append(appendSalesYearFilter(complaintForCriteria)).append(" and complaint.complaint_id IN  ( ");
      countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS_NOT_MCAS)
      //      .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);
      //countQuery.append(appendInnserSelectTableNames(complaintForCriteria))

          .append(" ) ").append(whereClause);
    } else {
      countQuery.append(ComplaintDAOSQLConstants.OUTER_SELECT_ALL_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.OUTER_SELECT_COLUMN_LIST)
          .append(ComplaintDAOSQLConstants.MAIN_SELECT_COLUMN_LIST).append(fromTablesBuffer)
          .append(filterClauseBuffer.toString()).append(ComplaintDAOSQLConstants.MAIN_SELECT_IN_CLAUSE)
          .append(ComplaintDAOSQLConstants.COMMON_OUTER_FILTER_CRITERIA);

      countQuery.append(appendSalesYearFilter(complaintForCriteria)).append(" and complaint.complaint_id IN  ( ");

        countQuery.append(ComplaintDAOSQLConstants.INNER_SELECT_NOT_EXISTS_QUERY_CIS_NOT_MCAS)
        //    .append(cropFilterClause).append(ComplaintDAOSQLConstants.UNION_ALL);

//      countQuery.append(appendInnserSelectTableNames(complaintForCriteria))
          //.append(" )")
          .append(" ) ").append(whereClause);
    }
    return countQuery;
  }

  private boolean isGrowerAndDealerNameEmpty(ComplaintForCriteria complaintForCriteria) {
    return StringUtils.isNullOrEmpty(complaintForCriteria.getGrowerName()) &&
        StringUtils.isNullOrEmpty(complaintForCriteria.getDealerName());
  }

  private String appendSalesYearFilter(ComplaintForCriteria criteria) {
    return (StringUtils.isNullOrEmpty(criteria.getSalesYr())) ? " and complaint.sales_yr_id = year_ref.year_id  " : "";
  }

  private void appendCropStateSalesYearFilterClause(StringBuffer filterClause, ComplaintForCriteria criteria,
                                                    StringBuffer whereClause) {
    criteria.getCISFieldsFilterClause(filterClause, whereClause);
  }

  private String getInnerSelectFilterClause(ComplaintForCriteria criteria) {
    StringBuffer resultStringBuffer = new StringBuffer(ComplaintDAOSQLConstants.INNER_SELECT_FILTER_CLAUSE_CIS);
    criteria.getCISFieldsFilterClause(new StringBuffer(), resultStringBuffer);
      boolean useNewView=validateUseNewView(criteria);
      if (isMCASRowCropUser(criteria)) {
      if(useNewView){
            resultStringBuffer.append(ComplaintDAOSQLConstants.INNER_SELECT_EXISTS_QUERY_CIS_FOR_MCAS_NEW_VIEW);
        }
        else{
            resultStringBuffer.append(ComplaintDAOSQLConstants.INNER_SELECT_EXISTS_QUERY_CIS_FOR_MCAS);
        }
      if (!StringUtils.isNullOrEmpty(criteria.getClaimStatusIndicator())) {
        if (criteria.getClaimStatusIndicator().trim().length() > 0)
          resultStringBuffer
              .append("and claim_view.CLAIM_STATUS_INDICATOR = '" + criteria.getClaimStatusIndicator().trim() + "'");
      }
    } else {
      resultStringBuffer.append(ComplaintDAOSQLConstants.INNER_SELECT_EXISTS_QUERY_CIS);
    }
      if(criteria.getCrop()!=null&&!criteria.getCrop().equals("")&&!criteria.getCrop().equalsIgnoreCase("6")){
          appendToSQLIfNotNullOrBlank(resultStringBuffer, criteria.getCrop(),
        " AND lower(trim(crop_ref.SHORT_DESCRIPTION)) = lower(trim(claim_view.crop_name))");
      }
      else if(criteria.getCrop()!=null&&!criteria.getCrop().equals("")&&criteria.getCrop().equalsIgnoreCase("6")){
           appendToSQLIfNotNullOrBlank(resultStringBuffer, criteria.getCrop(),
        " AND (trim('SOYBEAN') = trim(claim_view.crop_name) or trim('Soybeans') = trim(claim_view.crop_name))");
      }
      else{
      appendToSQLIfNotNullOrBlank(resultStringBuffer, criteria.getCrop(),
        " AND trim(crop_ref.SHORT_DESCRIPTION) = trim(claim_view.crop_name)");
      }
    appendToSQLIfNotNullOrBlank(resultStringBuffer, criteria.getState(),
        " AND trim(state_ref.STATE_ABBR) = trim(claim_view.RETAILER_DEALER_STATE)");
    appendToSQLIfNotNullOrBlank(resultStringBuffer, criteria.getSalesYr(),
        " AND trim(year_ref.SHORT_DESCRIPTION) = trim(claim_view.CLAIM_YEAR) ");
    return resultStringBuffer.toString();
  }

   private boolean validateUseNewView(ComplaintForCriteria criteria){
        return true;
    }

  private boolean isMCASRowCropUser(ComplaintForCriteria criteria) {
    return criteria.getUser() != null && criteria.getUser().getBusinessId() == 1;
  }

  private StringBuffer appendInnserSelectTableNames(ComplaintForCriteria criteria) {
    StringBuffer result = new StringBuffer(ComplaintDAOSQLConstants.INNER_SELECT_FROM_TABLES);
    appendToSQLIfNotNullOrBlank(result, criteria.getCrop(), ",CROP_REF crop_ref ");
    appendToSQLIfNotNullOrBlank(result, criteria.getState(), ",STATE_REF state_ref ");
    appendToSQLIfNotNullOrBlank(result, criteria.getSalesYr(), ",YEAR_REF year_ref ");
    return result;
  }

  private StringBuffer appendTableNames(ComplaintForCriteria complaintForCriteria) {
    StringBuffer filterClauseBuffer = new StringBuffer();

    if (isNotNullOrBlank(complaintForCriteria.getBatch()) || isNotNullOrBlank(complaintForCriteria.getVariety()))
      filterClauseBuffer.append(",COMPLAINT_BATCH CB, VARIETY_BATCH VB ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getCrop(), ",CROP_REF crop_ref ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getState(), ",STATE_REF state_ref ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getGrowerName(), ",COMPLAINT_GROWER grower ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getDealerName(), ",COMPLAINT_DEALER dealer ");
    if (isMCASRowCropUser(complaintForCriteria) && !isGrowerAndDealerNameEmpty(complaintForCriteria)) {
      filterClauseBuffer.append(", claim_id_view cv ");
    }
    return filterClauseBuffer;
  }

  private StringBuffer appendTableNamesWOClaims(ComplaintForCriteria complaintForCriteria) {
    StringBuffer filterClauseBuffer = new StringBuffer();

    if (isNotNullOrBlank(complaintForCriteria.getBatch()) || isNotNullOrBlank(complaintForCriteria.getVariety()))
      filterClauseBuffer.append(",COMPLAINT_BATCH CB, VARIETY_BATCH VB ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getCrop(), ",CROP_REF crop_ref ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getState(), ",STATE_REF state_ref ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getGrowerName(), ",COMPLAINT_GROWER grower ");
    appendToSQLIfNotNullOrBlank(filterClauseBuffer, complaintForCriteria.getDealerName(), ",COMPLAINT_DEALER dealer ");
    return filterClauseBuffer;
  }

    private StringBuffer buildWhereClause(ComplaintForCriteria complaint) {
    StringBuffer whereClause = new StringBuffer("");
    //TODO: **WARNING** SQL Injection possible here
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getControlNumber(),
        " AND complaint.COMPLAINT_ID=" + complaint.getControlNumber());
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getFromDate(),
        " AND complaint.ROW_ENTRY_DATE >= to_Date('" + complaint.getFromDate() + "','MM-dd-YYYY')");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getToDate(),
        " AND complaint.ROW_ENTRY_DATE <= to_Date('" + complaint.getToDate() + "','MM-dd-YYYY')");

    appendToSQLIfNotNullOrBlank(whereClause, complaint.getClosingDate(),
        " AND complaint.CLOSING_DATE = to_Date('" + complaint.getClosingDate() + "','MM-dd-YYYY')");

    appendToSQLIfNotNullOrBlank(whereClause, complaint.getFrom_communication_date(),
        " AND complaint.COMMUNICATION_DATE >= to_Date('" + complaint.getFrom_communication_date() + "','MM-dd-YYYY')");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getTo_communication_date(),
        " AND complaint.COMMUNICATION_DATE <= to_Date('" + complaint.getTo_communication_date() + "','MM-dd-YYYY')");

    appendToSQLIfNotNullOrBlank(whereClause, complaint.getInitiatedBy(),
        " AND upper(complaint.REPORT_INITIATOR) like upper('" + complaint.getInitiatedBy() + "%')");
//    appendToSQLIfNotNullOrZero(whereClause, complaint.getSalesYr(), " AND complaint.SALES_YR_ID=" + complaint.getSalesYr());
    appendToSQLIfNotNullOrZero(whereClause, complaint.getStatus(), " AND complaint.STATUS_ID=" + complaint.getStatus());
    appendToSQLIfNotNullOrZero(whereClause, complaint.getRegion(), " AND complaint.REGION_ID=" + complaint.getRegion());
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getClaimNumber(),
        " AND complaint.CLAIM_NUMBER='" + complaint.getClaimNumber() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getReportingLocation(),
        " AND complaint.REPORTING_LOCATION_CODE='" + complaint.getReportingLocation() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getResponsibleLocation(),
        " AND complaint.RESPONSIBLE_PLANT_CODE='" + complaint.getResponsibleLocation() + "'");

    if (isNotNullOrBlank(complaint.getBatch()) && isNotNullOrBlank(complaint.getVariety())) {
      whereClause.append("AND CB.COMPLAINT_ID = complaint.COMPLAINT_ID and CB.VARIETY_BATCH_ID = VB.VARIETY_BATCH_ID "
          + "and upper(VB.BATCH) Like upper('%" + complaint.getBatch() +
          "%') and UPPER(VB.VARIETY) LIKE UPPER('%" + complaint.getVariety() + "%')");
    } else {
      appendToSQLIfNotNullOrBlank(whereClause, complaint.getBatch(),
          " AND CB.COMPLAINT_ID = complaint.COMPLAINT_ID and CB.VARIETY_BATCH_ID = VB.VARIETY_BATCH_ID and upper(VB.BATCH) Like upper('%" +
              complaint.getBatch() +
              "%')");
      appendToSQLIfNotNullOrBlank(whereClause, complaint.getVariety(),
          " AND CB.COMPLAINT_ID = complaint.COMPLAINT_ID AND CB.VARIETY_BATCH_ID = VB.VARIETY_BATCH_ID AND UPPER(VB.VARIETY) LIKE UPPER('%" +
              complaint.getVariety() + "%')");
    }

    appendToSQLIfNotNullOrZero(whereClause, complaint.getQualityIssue(),
        " AND complaint.COMPLAINT_QUALITY_ISSUE_ID = '" + complaint.getQualityIssue() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getComplaintBusinessId(),
        " AND complaint.COMPLAINT_BUSINESS_ID='" + complaint.getComplaintBusinessId() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getfeedbackCategoryId(),
        " AND complaint.COMPLAINT_CATEGORY_ID='" + complaint.getfeedbackCategoryId() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getComplaintTypeId(),
        " AND complaint.COMPLAINT_TYPE_ID='" + complaint.getComplaintTypeId() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getFunctionId(),
        " AND complaint.LOCATION_FUNCTION_ID='" + complaint.getFunctionId() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getSalesOfficeCode(),
        " AND complaint.SALES_OFFICE_ID='" + complaint.getSalesOfficeCode() + "'");
    appendToSQLIfNotZero(whereClause, complaint.getMaterialGroupCode(),
        " AND complaint.MATERIAL_GRP_ID =" + complaint.getMaterialGroupCode());
    appendToSQLIfNotZero(whereClause, complaint.getMaterialGroupPricingId(),
        " AND complaint.MATERIAL_GROUP_PRICING_ID =" + complaint.getMaterialGroupPricingId());
    appendToSQLIfNotZero(whereClause, complaint.getInitialAssesmentCode(),
        " AND complaint.INITIAL_ASSESMENT =" + complaint.getInitialAssesmentCode());
    appendToSQLIfNotZero(whereClause, complaint.getComplaintLitigationCategoryCode(),
        " AND complaint.LITIGATION_CATEGORY_ID =" + complaint.getComplaintLitigationCategoryCode());
    appendToSQLIfNotZero(whereClause, complaint.getComplaintEntryTypeId(),
        " AND complaint.COMPLAINT_ENTRY_TYPE_ID =" + complaint.getComplaintEntryTypeId());
    appendToSQLIfNotZero(whereClause, complaint.getProgramId(),
        " AND complaint.PROGRAM_ID =" + complaint.getProgramId());
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getSapCustomerId(),
        " AND complaint.SAP_CUSTOMER_ID='" + complaint.getSapCustomerId() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getCustomerName(),
        " AND complaint.CUSTOMER_NAME='" + complaint.getCustomerName() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getInvoiceNumber(),
        " AND complaint.INVOICE_NUMBER='" + complaint.getInvoiceNumber() + "'");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getInvoiceDate(),
        " AND complaint.INVOICE_DATE = to_Date('" + complaint.getInvoiceDate() + "','MM-dd-YYYY')");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getGrowerName(),
        " AND ( upper(grower.GROWER_NAME) like upper('%" + complaint.getGrowerName() + "%')" +
            getClaimGrowerClause(complaint) + ")" +
            " AND complaint.complaint_id = grower.complaint_id ");
    appendToSQLIfNotNullOrBlank(whereClause, complaint.getDealerName(),
        " AND (upper(dealer.DEALER_NAME) like upper('%" + complaint.getDealerName() + "%') " +
            getClaimDealerClause(complaint) + ")" +
            " AND complaint.complaint_id = dealer.complaint_id ");

    appendToSQLIfNotNullOrBlank(whereClause, complaint.getPerson_investigating(),
        " AND upper(complaint.PERSON_INVESTIGATING) like upper('" + complaint.getPerson_investigating() + "%')");

    whereClause.append(" AND complaint.COMPLAINT_BUSINESS_ID = complaint_business.COMPLAINT_BUSINESS_ID(+) ");

    addTextSearchConditions(whereClause, complaint.getSearchText());

    return whereClause;
  }

  private String getClaimDealerClause(ComplaintForCriteria complaint) {
    return isMCASRowCropUser(complaint) ?
        " or  UPPER (cv.RETAILER_DEALER_NAME) LIKE  UPPER ('%" + complaint.getDealerName() + "%')" : "";
  }

  private String getClaimGrowerClause(ComplaintForCriteria complaint) {
    return isMCASRowCropUser(complaint) ?
        " or  UPPER (cv.grower_name) LIKE  UPPER ('%" + complaint.getGrowerName() + "%')" : "";
  }

  private void addTextSearchConditions(StringBuffer buff, String searchText) {
    if (!StringUtils.isNullOrEmpty(searchText)) {
      buff.append(" and (lower(complaint_documentation.problem_description) like lower('%");
      buff.append(searchText);
      buff.append("%') or lower(complaint_documentation.long_term_correction_action) like lower('%");
      buff.append(searchText);
      buff.append("%') or lower(complaint_documentation.root_cause) like lower('%");
      buff.append(searchText);
      buff.append("%') or lower(complaint_documentation.containment_action) like lower('%");
      buff.append(searchText);
      buff.append("%'))");
    }
  }

  private void getComplaintSubFunctions(int complaint_id, Complaint c, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_SUBFUNCTION);
            ps.setInt(1, complaint_id);

            rs = ps.executeQuery();
            StringBuffer subFunctionSelected = new StringBuffer();

            while (rs.next()) {
                setSubfunction(rs, subFunctionSelected);
            }
            String[] subFunctions = subFunctionSelected.toString().split(",");
            c.setSubFunctionsSelected(subFunctions);
        } catch (SQLException e) {
            MCASLogUtil.logError("SQLException while sub function details: ", e);
        } catch (Exception e) {
            MCASLogUtil.logError("Exception while getting sub function details: ", e);
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

  private void setSubfunction(ResultSet rs, StringBuffer subFunctionSelected) throws SQLException {
        subFunctionSelected.append(rs.getString(1)).append(",");
    }


  private void insertComplaintSubFunction(Complaint c, Connection conn) throws DAOException {
        if (c.getSubFunctionsSelected() != null) {
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_SUBFUNCTION);
                ps.setString(1, c.getComplaint_id());
                ps.executeUpdate();

                closeDBResources(null, ps, null);

                ps = conn.prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_SUBFUNCTION);
                for (String subfunctionId : c.getSubFunctionsSelected()) {
                    ps.setString(1, c.getComplaint_id());
                    if (StringUtils.isNullOrEmpty(subfunctionId)) {
                        ps.setString(2, "0");
                    } else {
                        ps.setString(2, subfunctionId);
                    }
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                throw new DAOException(e);
            } finally {
                closeDBResources(null, ps, null);
            }
        }
    }

  public Complaint getComplaint(String complaint_id) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    Complaint c = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_MAIN);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();

      c = new Complaint();
      while (rs.next()) {
        c.setComplaint_id(Integer.toString(rs.getInt("COMPLAINT_ID")));
        c.setClaim_number(rs.getString("CLAIM_NUMBER"));
        c.setStatus_id(rs.getString("STATUS_ID"));
        c.setSales_year_id(rs.getString("SALES_YR_ID"));
        c.setState_id(rs.getString("STATE_ID"));
        c.setClaimStatusType(rs.getString("CLAIM_STATUS_INDICATOR"));
        c.setReport_initiator(rs.getString("REPORT_INITIATOR"));
        c.setReport_date(getDateFormat(rs.getDate("REPORT_DATE")));
        c.setCommunication_date(getDateFormat(rs.getDate("COMMUNICATION_DATE")));
        c.setField_communicator(rs.getString("FIELD_COMMUNICATOR"));
        c.setReporting_location_code(rs.getString("REPORTING_LOCATION_CODE"));
        c.setResponsible_plant_code(rs.getString("RESPONSIBLE_PLANT_CODE"));
        c.setCrop_id(rs.getString("CROP_ID"));
        c.setPerson_investigating(rs.getString("PERSON_INVESTIGATING"));
        c.setSeed_size_id(rs.getString("SEED_SIZE_ID"));
        c.setQuantity_affected(rs.getString("QTY_AFFECTED"));
        c.setQuantity_uom_id(rs.getString("QTY_UOM_ID"));
        c.setDelivery_info(rs.getString("DELIVERY_INFO"));
        c.setCreated_by(rs.getString("CREATED_BY"));
        c.setRegion_id(rs.getString("REGION_ID"));
        c.setQuality_issue(rs.getString("COMPLAINT_QUALITY_ISSUE_ID"));
        c.setRow_entry_date(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
        c.setRegion_id(rs.getString("REGION_ID"));
        c.setSettlement_value(rs.getString("SETTLEMENT_VALUE"));
        c.setAffina_entry_flag(rs.getString("AFFINA_ENTRY_FLAG"));
        c.setReport_initiator_email(rs.getString("REPORT_INITIATOR_EMAIL"));
        c.setRow_user_id(rs.getString("ROW_USER_ID"));
        c.setComplaintBusinessId(rs.getString("COMPLAINT_BUSINESS_ID"));
        c.setFeedbackCategoryId(rs.getString("COMPLAINT_CATEGORY_ID"));
        c.setComplaintTypeId(rs.getString("COMPLAINT_TYPE_ID"));
        c.setFunctionId(rs.getString("LOCATION_FUNCTION_ID"));
        c.setSalesOfficeCode(rs.getString("SALES_OFFICE_ID"));
        c.setMaterialGroupCode(rs.getInt("MATERIAL_GRP_ID"));
        c.setMaterialGroupPricingCode(rs.getInt("MATERIAL_GROUP_PRICING_ID"));

        c.setSalesOrderNumber(rs.getString("SALES_ORDER_NUMBER"));
        c.setShippingTransportNumber(rs.getString("SHIPPING_TRANSPORT_NUMBER"));
        c.setCustomerName(rs.getString("CUSTOMER_NAME"));
        c.setCustomerAddress(rs.getString("CUSTOMER_ADDRESS"));
        c.setCustomerPhoneNumber(rs.getString("CUST_PHONE_NUMBER"));
        c.setCustomerEmail(rs.getString("CUST_EMAIL"));
        c.setClaimAmount(rs.getString("CLAIM_AMOUNT"));
        c.setBusinessId(rs.getInt("BUSINESS_ID"));
        c.setInitialAssesmentCode(rs.getInt("INITIAL_ASSESMENT"));
        c.setComplaintLitigationCategoryCode(rs.getInt("LITIGATION_CATEGORY_ID"));
        c.setClaimCategoryId(rs.getString("CLAIM_CATEGORY_ID"));
        c.setInvoiceNumber(rs.getString("INVOICE_NUMBER"));
        c.setSapCustomerId(rs.getString("SAP_CUSTOMER_ID"));
        //Fixed Internal Representation error, cannot convert String to Boolean
        String claimStatus = rs.getString("CLAIM_STATUS");
        if ("1".equals(claimStatus) || "Y".equalsIgnoreCase(claimStatus)) {
          c.setClaimAmountFinal(true);
        } else {
          c.setClaimAmountFinal(false);
        }
        c.setComplaintEntryTypeId(rs.getInt("COMPLAINT_ENTRY_TYPE_ID"));
        c.setProgram_id(rs.getInt("PROGRAM_ID"));
        c.setSubFunction_id(rs.getInt("SUBFUNCTION_ID"));
        c.setInvoiceDate(getDateFormat(rs.getDate("INVOICE_DATE")));
        c.setIssueCategoryId(rs.getString("ISSUE_CATEGORY_ID"));
        c.setLowCategoryId(rs.getString("LOW_LEVEL_CATEGORY"));
        c.setRefugePlantedId(rs.getString("REFUGE_PLANTED_ID"));
        c.setTraitCheckId(rs.getString("TRAIT_CHECK_ID"));
        c.setComplianceNearMiss("Y".equalsIgnoreCase(rs.getString("COMPLIANCE_NEAR_MISS")));
        c.setRootInjuryId(rs.getString("ROOT_INJURY_ID"));
        c.setInjuryRatingId(rs.getString("INJURY_RATING_ID"));
        c.setClosingPersonId(rs.getString("CLOSING_PERSON"));
        c.setInitiator_response(rs.getString("INITIATOR_RESPONSE"));
        c.setClosingDate(getDateFormat(rs.getDate("CLOSING_DATE")));
        c.setCpar_id(rs.getString("CPAR_CONTROL_NUMBER"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);
     getComplaintSubFunctions(Integer.parseInt(complaint_id),c,conn);
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_DEALER);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setDealer_name(rs.getString("DEALER_NAME"));
        c.setDealer_address(rs.getString("DEALER_ADDRESS"));
        c.setDealer_city(rs.getString("DEALER_CITY"));
        c.setDealer_state(rs.getString("DEALER_STATE_ID"));
        if (!(rs.getString("DEALER_PHONE") == null)) {
          c.setDealer_phone(rs.getString("DEALER_PHONE").trim());
        } else {
          c.setDealer_phone(rs.getString("DEALER_PHONE"));
        }
        c.setDealer_ba_id(rs.getString("DEALER_BA_ID"));
        c.setDealerLatitude(rs.getString("GPS_LATITUDE"));
        c.setDealerLongitude(rs.getString("GPS_LONGITUDE"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_GROWER);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setGrower_name(rs.getString("GROWER_NAME"));
        c.setGrower_address(rs.getString("GROWER_ADDRESS"));
        c.setGrower_city(rs.getString("GROWER_CITY"));
        c.setGrower_state(rs.getString("GROWER_STATE_ID"));
        if (!(rs.getString("GROWER_PHONE") == null)) {
          c.setGrower_phone(rs.getString("GROWER_PHONE").trim());
        } else {
          c.setGrower_phone(rs.getString("GROWER_PHONE"));
        }
        c.setGrower_ba_id(rs.getString("GROWER_BA_ID"));
        c.setGrowerLatitude(rs.getString("GPS_LATITUDE"));
        c.setGrowerLongitude(rs.getString("GPS_LONGITUDE"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_DISEASE_INFO);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setDisease_observed(rs.getString("DISEASE_OBSERVED"));
        c.setHerbicide_type_current(rs.getString("HERBICIDE_TYPE_CY"));
        c.setHerbicide_rate_current(rs.getString("HERBICIDE_RATE_CY"));
        c.setHerbicide_timming_current(rs.getString("HERBICIDE_TIMING_CY"));
        c.setHerbicide_type_prev(rs.getString("HERBICIDE_TYPE_PY"));
        c.setHerbicide_rate_prev(rs.getString("HERBICIDE_RATE_PY"));
        c.setHerbicide_timming_prev(rs.getString("HERBICIDE_TIMING_PY"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_INSECT_INFO);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setInsects_observed(rs.getString("INSECTS_OBSERVED"));
        c.setInsecticide_type_current(rs.getString("INSECTICIDE_TYPE_CY"));
        c.setInsecticide_rate_current(rs.getString("INSECTICIDE_RATE_CY"));
        c.setInsecticide_timming_current(rs.getString("INSECTICIDE_TIMING_CY"));
        c.setInsecticide_type_prev(rs.getString("INSECTICIDE_TYPE_PY"));
        c.setInsecticide_rate_prev(rs.getString("INSECTICIDE_RATE_PY"));
        c.setInsecticide_timming_prev(rs.getString("INSECTICIDE_TIMING_PY"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_DOCUMENTATION);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setProblem_description(rs.getString("PROBLEM_DESCRIPTION"));
        c.setContainment_actions(rs.getString("CONTAINMENT_ACTION"));
        c.setRoot_cause(rs.getString("ROOT_CAUSE"));
        c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
      }

      loadComplaintOtherInfo(c, conn);

      MCASResourceUtil.closeDBResources(null, ps, rs);

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_PLANTING_INFO);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setTotal_acres(rs.getString("TOTAL_ACRES"));
        c.setAffected_areas(rs.getString("AFFECTED_ACRES"));
        c.setTechnology(rs.getString("TECHNOLOGY"));
        c.setPlanting_date(getDateFormat(rs.getDate("PLANTING_DATE")));
        c.setPlanter_type(rs.getString("PLANTER_TYPE"));
        c.setPlanter_depth(rs.getString("PLANTER_DEPTH"));
        c.setPopulation_planted(rs.getString("POPULATION_PLANTED"));
        c.setPopulation_observed(rs.getString("POPULATION_OBSERVED"));
        c.setTillage(rs.getString("TILLAGE"));
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);
      //====Get complaint cpar_id map
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_CPAR_CIS);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      List cparCIList = new ArrayList();
      String cparIdString = "";
      while (rs.next()) {
        cparCIList.add(rs.getLong("CPAR_ID"));
        cparIdString = cparIdString + rs.getLong("CPAR_ID") + ",";
      }

      MCASResourceUtil.closeDBResources(null, ps, rs);

      //Get cpar objects
      if(!cparCIList.isEmpty()){

          cparIdString = cparIdString.substring(0,cparIdString.length() - 1);
          int i = 1;
          String queryStr = ComplaintDAOSQLConstants.GET_COMPLAINT_CPAR_CIS_OBJECT;

          for(Object cparIdStr: cparCIList){
            queryStr = queryStr + "?,";
          }
          queryStr = queryStr.substring(0,queryStr.length() - 1);
          queryStr = queryStr + ") and IS_DELETED='N'";
          ps = conn.prepareStatement(queryStr);
          for(Object cparIdStr: cparCIList){
            ps.setString(i, cparIdStr.toString()); 
            i++;
          }

          rs = ps.executeQuery();
          List carObjectList = new ArrayList();
          List parObjectList = new ArrayList();
          List ciObjectList = new ArrayList();
          while (rs.next()) {
              Cpar cparTemp = new Cpar();
              cparTemp.setControl_number(rs.getString("CONTROL_NUMBER"));
              cparTemp.setReport_date(getDateFormat(rs.getDate("DATE_REPORTED")));
              cparTemp.setCpar_id(rs.getString("CPAR_ID"));
              cparTemp.setInitiated_by(rs.getString("REPORT_INITIATOR"));
              cparTemp.setType(rs.getInt("TYPE"));
              if(cparTemp.getType() == CAR_TYPE){
                carObjectList.add(cparTemp);
              }else if(cparTemp.getType() == PAR_TYPE){
                parObjectList.add(cparTemp);
              }else if(cparTemp.getType() == CI_TYPE){
                ciObjectList.add(cparTemp);
              }
          }
          c.setCarList(carObjectList);
          c.setParList(parObjectList);
          c.setCiList(ciObjectList);

          MCASResourceUtil.closeDBResources(null, ps, rs);

      }

      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_VARIETY_BATCH);
      ps.setLong(1, Long.parseLong(complaint_id));
//      ps.setString(2, complaint_id);
//      ps.setString(3, complaint_id);
      rs = ps.executeQuery();
      setVarietyBatch(rs, c);
      setComplaintResponsibility(c, conn);
      setComplaintInvestigation(c, conn);
      getComplaintAttachmentInfo(complaint_id, c, conn);
      return c;
    } catch (SQLException e) {
      throw new DAOException(e);
    } catch (MCASException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

    public void getVarietyBatch(String complaint_id,Complaint c)throws DAOException{
     PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
     try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_VARIETY_BATCH);
      ps.setLong(1, Long.parseLong(complaint_id));

      rs = ps.executeQuery();
      setVarietyBatch(rs, c);
        } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
    }

     private void deleteVarietyBatch(String complaintBatchSeq,Connection con)throws DAOException{
       PreparedStatement ps = null;

   // Connection conn = null;
     try {
      //conn = getConnection();
      ps = con.prepareStatement(ComplaintDAOSQLConstants.DELETE_VARIETY_BATCH);
      ps.setLong(1, Long.parseLong(complaintBatchSeq));

      ps.executeUpdate();
     //    commit(conn);

        } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, null);
    }

     }

  private void setVarietyBatch(ResultSet rs, Complaint c) throws SQLException {
    List<VarietyBatch> batchList = c.getVarietyBatchList();
    batchList.clear();
    while (rs.next()) {
      batchList.add(
          new VarietyBatch(rs.getString("VARIETY"), rs.getString("BATCH"), rs.getFloat("QTY_AFFECTED"),
              rs.getLong("ACRES_AFFECTED"), rs.getLong("UOM_ID"), rs.getLong("SEED_SIZE_ID"), rs.getLong("IL_TYPE"),
              rs.getLong("BATCH_CROP_YR_ID"),rs.getString("LOT_NUMBER"),rs.getString("COUNTRY_ORIGIN"),rs.getString("TREATMENT_TYPE"),rs.getLong("COMPLAINT_BATCH_SEQ")));
    }
  }

  private void setComplaintResponsibility(Complaint c, Connection conn) throws SQLException {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_RESPONSIBILITY);
      ps.setString(1, c.getComplaint_id());
      rs = ps.executeQuery();
      while (rs.next()) {
        c.setProblem_person(rs.getString("MGMT_APPROVAL_PERSON"));
        c.setProblem_date(getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
        c.setLongTermPerson(rs.getString("LONG_TERM_CORRECT_ACT_PERSON"));
        c.setLongTermDate(getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
        c.setRootCausePerson(rs.getString("ROOT_CAUSE_PERSON"));
        c.setRootCauseDate(getDateFormat(rs.getDate("ROOT_CAUSE_DATE")));
        c.setContainment_person(rs.getString("CONTAINMENT_ACTION_PERSON"));
        c.setContainment_date(getDateFormat(rs.getDate("CONTAINMENT_ACTION_DATE")));
        c.setDispositionId(rs.getInt("DISPOSITION_ID"));
        c.setDispositionIdForTeamLead(rs.getInt("TEAM_LEAD_DISPOSITION_ID"));
      }
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private void setComplaintInvestigation(Complaint c, Connection conn) throws SQLException {
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_INVESTIGATION);
      ps.setString(1, c.getComplaint_id());
      rs = ps.executeQuery();
      while (rs.next()) {
        ComplaintInvestigation investigation = c.getComplaintInvestigation();
        investigation.setId(rs.getLong("COMPLAINT_ID"));
        investigation.getInitiatorSample().setId(rs.getLong("INITIATOR_SAMPLE_ID"));
        investigation.setInitiatorComments(rs.getString("INITIATOR_SAMPLE_COMMENTS"));
        investigation.getSiteSample().setId(rs.getLong("SITE_SAMPLE_ID"));
        investigation.setSiteComments(rs.getString("SITE_SAMPLE_COMMENTS"));
        investigation.setQualityScores(rs.getString("QUALITY_SCORES"));
        investigation.setDeliveryInfo(rs.getString("DELIVERY_INFO"));
      }
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  public Map<String, RowBean> getComplaintReport(ComplaintFilter complaintFilter, int businessId, String locale) throws
      DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    try {
      conn = getConnection();
      StringBuffer whereClause = new StringBuffer();
      addAllFiltersToWhereClause(complaintFilter, whereClause, businessId);
      StringBuffer queryString = new StringBuffer();

      queryString.append(ComplaintDAOSQLConstants.GET_COMPLAINT_REPORT).append(whereClause.toString());

//      System.out.println("Complaint Report Query String****" + queryString);
//      logger.info(queryString);
      ps = conn.prepareStatement(queryString.toString());
      rs = ps.executeQuery();
      return createHashFromResultSet(rs, locale);
    } catch (Exception e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

  private void insertUpdateComplaint(Complaint c, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            int parameterIndx = 1;
            conn = getConnection();
            lookupComplaintEntryTypeIdFromRequest(c, conn);
            String nearMiss = "N";
            if (c.isComplianceNearMiss())
                nearMiss = "Y";
            if (isUpdate) {
                ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_SQL);
                ps.setLong(parameterIndx + 63, Long.parseLong(c.getComplaint_id()));
                ps.setInt(parameterIndx + 44, c.getComplaintEntryTypeId());
                ps.setInt(parameterIndx + 45, c.getProgram_id());
                ps.setInt(parameterIndx + 46, c.getSubFunction_id());
                ps.setString(parameterIndx + 59, c.getClosingPersonId());
                ps.setString(parameterIndx + 60, c.getInitiator_response());
            } else {
                ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_SQL);
                ps.setLong(parameterIndx, Long.parseLong(c.getComplaint_id()));
                parameterIndx++;
                ps.setInt(parameterIndx + 44, c.getComplaintEntryTypeId());
                ps.setInt(parameterIndx + 45, c.getProgram_id());
                ps.setInt(parameterIndx + 46, c.getSubFunction_id());
                ps.setString(parameterIndx + 59, null);
                ps.setString(parameterIndx + 60, c.getInitiator_response());
            }

            ps.setString(parameterIndx + 58, nearMiss);
//            ps.setString(parameterIndx + 57, c.getRootInjuryId());
//            ps.setString(parameterIndx + 58, c.getInjuryRatingId());
//            System.out.println (c.getRootInjuryId());


            setSalesOrderInformation(c, ps, parameterIndx);
            ps.setString(parameterIndx, c.getClaim_number());
            ps.setLong(parameterIndx + 1, Long.parseLong(c.getStatus_id()));
            ps.setLong(parameterIndx + 2, Long.parseLong(c.getSales_year_id()));
            ps.setInt(parameterIndx + 3, Integer.parseInt(c.getState_id()));
            ps.setString(parameterIndx + 4, c.getReport_initiator());
            ps.setDate(parameterIndx + 5, new Date(new java.util.Date(c.getReport_date()).getTime()));
            if (StringUtils.isNullOrEmpty(c.getCommunication_date())) {
                ps.setDate(parameterIndx + 6, null);
            } else {
                ps.setDate(parameterIndx + 6, new Date(new java.util.Date(c.getCommunication_date()).getTime()));
            }
            ps.setString(parameterIndx + 7, c.getField_communicator());
            String reporting_location_code = c.getReporting_location_code();

            ps.setString(parameterIndx + 8, reporting_location_code);
            String plant_code = c.getResponsible_plant_code();

            ps.setString(parameterIndx + 9, plant_code);
            if (StringUtils.isNullOrEmpty(c.getCrop_id())) {
                ps.setNull(parameterIndx + 10, Types.INTEGER);
            } else {
                ps.setInt(parameterIndx + 10, Integer.parseInt(c.getCrop_id()));
            }
            ps.setString(parameterIndx + 11, c.getPerson_investigating());
            if (StringUtils.isNullOrEmpty(c.getSeed_size_id())) {
                ps.setNull(parameterIndx + 12, Types.INTEGER);
            } else {
                ps.setLong(parameterIndx + 12, Long.parseLong(c.getSeed_size_id()));
            }
            if (StringUtils.isNullOrEmpty(c.getQuantity_affected())) {
                ps.setNull(parameterIndx + 13, Types.FLOAT);
            } else {
                ps.setFloat(parameterIndx + 13, Float.parseFloat(c.getQuantity_affected()));
            }
            if (StringUtils.isNullOrEmpty(c.getQuantity_uom_id())) {
                ps.setNull(parameterIndx + 14, Types.INTEGER);
            } else {
                ps.setLong(parameterIndx + 14, Long.parseLong(c.getQuantity_uom_id()));
            }
            ps.setString(parameterIndx + 15, c.getDelivery_info());
            ps.setDate(parameterIndx + 17, new Date(new java.util.Date().getTime()));

            setRowEntryDateQualityIssueForComplaintOrAffinaEntry(c, ps, parameterIndx, isUpdate);


            ps.setString(parameterIndx + 19, c.getRow_user_id());
            ps.setString(parameterIndx + 20, c.getCreated_by());
            ps.setInt(parameterIndx + 21, Integer.parseInt(c.getRegion_id()));

            if (!(c.getSettlement_value() == null ||
                    (c.getSettlement_value() != null && c.getSettlement_value().trim().equals("")))) {
                ps.setFloat(parameterIndx + 23, Float.parseFloat(c.getSettlement_value().trim()));
            } else {
                ps.setFloat(parameterIndx + 23, Types.INTEGER);
            }

            ps.setString(parameterIndx + 24, c.getAffina_entry_flag());
            ps.setString(parameterIndx + 25, c.getReport_initiator_email());
            ps.setString(parameterIndx + 26, c.getComplaintBusinessId());
            ps.setString(parameterIndx + 27, c.getFeedbackCategoryId());
            ps.setString(parameterIndx + 28, c.getComplaintTypeId());
            ps.setString(parameterIndx + 29, c.getFunctionId());
            ps.setString(parameterIndx + 30, c.getSalesOfficeCode());
            ps.setInt(parameterIndx + 31, c.getMaterialGroupCode());
            ps.setInt(parameterIndx + 32, c.getMaterialGroupPricingCode());

            ps.setString(parameterIndx + 33, c.getSalesOrderNumber());
            ps.setString(parameterIndx + 34, c.getShippingTransportNumber());
            ps.setString(parameterIndx + 35, c.getCustomerName());
            ps.setString(parameterIndx + 36, c.getCustomerAddress());
            ps.setString(parameterIndx + 37, c.getCustomerPhoneNumber());
            ps.setString(parameterIndx + 38, c.getCustomerEmail());
            ps.setInt(parameterIndx + 39, c.getBusinessId());
            String amount = c.getClaimAmount();
            ps.setString(parameterIndx + 40, amount);
            ps.setBoolean(parameterIndx + 41, c.isClaimAmountFinal());
            ps.setInt(parameterIndx + 42, c.getInitialAssesmentCode());
            ps.setInt(parameterIndx + 43, c.getComplaintLitigationCategoryCode());


            if (StringUtils.isNullOrEmpty(c.getClosingDate())) {
                ps.setDate(parameterIndx + 61, null);
            } else {
                ps.setDate(parameterIndx + 61, new Date(new java.util.Date(c.getClosingDate()).getTime()));
            }

      ps.setString(parameterIndx + 62, null);

            if (ps.executeUpdate() > 0) {
                insertComplaint_Grower(c, conn, isUpdate);
                insertComplaint_Dealer(c, conn, isUpdate);
                insertComplaint_Disease(c, conn, isUpdate);
                insertComplaint_Documentation(c, conn, isUpdate);
                insertComplaint_Insect(c, conn, isUpdate);
                insertComplaint_Planting(c, conn, isUpdate);
                insertUpdateComplaintInvestigation(c, conn);
                insertComplaintSubFunction(c,conn);
                saveComplaintOtherInfo(c, conn, isUpdate);
                //System.out.println("cpar:" + c.getCpar_id());
                String controlNumber = c.getCpar_id();
                if((controlNumber != null) && (!controlNumber.isEmpty())){
                    //System.out.println("inside::::");
                    controlNumber = controlNumber.trim();
                    //System.out.println("trimmee:" + controlNumber);
                    CparDAO cparDAO = (CparDAO) DAOFactory.getDao(CparDAO.class);
                    Cpar cparObj = cparDAO.getCparByControlNo(controlNumber, c.getBusinessId());
                    //System.out.println("cparObj::" + cparObj);
                    if(cparObj != null){
                        //System.out.println("complaint..." + c.getComplaint_id());
                       // System.out.println("cparObj:::" + cparObj.getCpar_id());
                        boolean isNewCartoAdd=true;
                        for(String complaint:cparObj.getComplaint_id()){
                            if(complaint.equalsIgnoreCase(c.getComplaint_id().toString())){
                                isNewCartoAdd=false;
                            }
                        }

                        //System.out.println("complaint..." + c.getComplaint_id());
                       // System.out.println("cparObj:::" + cparObj.getCpar_id());
                        if(isNewCartoAdd){
                        insertComplaintCparIdInComplaintCparXrefFromInsertComplaint(conn,cparObj,c.getComplaint_id());
                        c.setCarList(getComplaint(c.getComplaint_id()).getCarList());
                    }
                    }


                }
                
                if (isUpdate) {
                    //Not sure why this is here, but this is not correct, since after we delete the records
                    //we can not update them. Nico, January 11, 2012
                    //deleteBatches(c.getComplaint_id(), conn);
                    deleteCheckboxItemsForComplaint(c);
                    commit(conn);
                }

                if (isUpdate) {

                    updateComplaint_Batch(c, conn);

                    deleteCheckboxItemsForComplaint(c);
                    insertCheckboxItemsForComplaint(c);

                }else{
                    insertComplaint_Batch(c, conn);
                    insertCheckboxItemsForComplaint(c);
                }
                //insertCheckboxItemsForComplaint(c);

                insertComplaintResponsibility(c, conn, isUpdate);
            }
            getComplaintAttachmentInfo(c.getComplaint_id(), c, conn);
            commit(conn);
        }
        catch (Exception e) {
            rollback(conn);
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

  protected void insertCheckboxItemsForComplaint(Complaint c) {
    //for nonconformances, they differ for C, NCR, and DEV.
    ncDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), c.getEntryType(),
        c.getSelectedNonconformanceCategoryList());
    rcDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), c.getEntryType(),
        c.getSelectedRootCauseList());
    //audit areas are always C
    aaDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), "C", c.getSelectedFunctionalAreas());
  }

  public void deleteCheckboxItemsForComplaint(Complaint c) {
    ncDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), c.getEntryType());
    rcDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), c.getEntryType());
    aaDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getComplaint_id()), "C");
  }

  private void insertUpdateComplaintInvestigation(Complaint c, Connection conn) throws
      DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int paramIndx = 1;
    try {
      ComplaintInvestigation investigation = c.getComplaintInvestigation();
      if (investigation.getId() == null) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_INVESTIGATION);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        investigation.setId(Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_INVESTIGATION);
        ps.setLong(7, Long.parseLong(c.getComplaint_id()));
      }
      setLongIfNotNull(ps, paramIndx, investigation.getInitiatorSample().getId());
      ps.setString(paramIndx + 1, investigation.getInitiatorComments());
      setLongIfNotNull(ps, paramIndx + 2, investigation.getSiteSample().getId());
      ps.setString(paramIndx + 3, investigation.getSiteComments());
      ps.setString(paramIndx + 4, investigation.getQualityScores());
      ps.setString(paramIndx + 5, investigation.getDeliveryInfo());
      ps.executeUpdate();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private void setSalesOrderInformation(Complaint c, PreparedStatement ps, int parameterIndx) throws SQLException {
    ps.setString(parameterIndx + 47, c.getClaimId());
    ps.setString(parameterIndx + 48, c.getClaimCategoryId());
    ps.setString(parameterIndx + 49, c.getInvoiceNumber());
    ps.setString(parameterIndx + 50, c.getSapCustomerId());
    Date invoiceDate = StringUtils.isNullOrEmpty(c.getInvoiceDate()) ? null :
        new Date(new java.util.Date(c.getInvoiceDate()).getTime());
    ps.setDate(parameterIndx + 51, invoiceDate);
    ps.setString(parameterIndx + 52, c.getIssueCategoryId());
    ps.setString(parameterIndx + 53, c.getLowCategoryId());
    ps.setString(parameterIndx + 54, c.getRefugePlantedId());
    ps.setString(parameterIndx + 55, c.getTraitCheckId());
    ps.setString(parameterIndx + 56, c.getRootInjuryId());
    ps.setString(parameterIndx + 57, c.getInjuryRatingId());
  }

  private void lookupComplaintEntryTypeIdFromRequest(Complaint complaint, Connection conn) throws DAOException {
    PreparedStatement ps = null;
    ResultSet resultSet = null;
    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_ENTRY_TYPE_ID);
      ps.setString(1, complaint.getEntryType());
      resultSet = ps.executeQuery();
      while (resultSet.next()) {
        complaint.setComplaintEntryTypeId(resultSet.getInt(1));
      }
    } catch (SQLException e) {
      MCASLogUtil.logError(e.getMessage(), e);
      throw new DAOException(
          "Exception in " + getClass().getName() + ".lookupComplaintEntryTypeIdFromRequest()" + e.getMessage(), e);
    } finally {
      closeDBResources(null, ps, resultSet);
    }
  }

  private String lookupComplaintEntryTypeStringFromEntryTypeId(int id) throws DAOException {
    Connection conn = null;
    String description = null;
    PreparedStatement ps = null;
    ResultSet resultSet = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_ENTRY_TYPE);
      ps.setInt(1, id);
      resultSet = ps.executeQuery();
      while (resultSet.next()) {
        description = resultSet.getString(1);
      }
    } catch (SQLException e) {
      MCASLogUtil.logError(e.getMessage(), e);
      throw new DAOException(
          "Exception in " + getClass().getName() + ".lookupComplaintEntryTypeStringFromEntryTypeId()" + e.getMessage(),
          e);
    } finally {
      closeDBResources(conn, ps, resultSet);
    }
    return description;
  }

  private void setRowEntryDateQualityIssueForComplaintOrAffinaEntry(Complaint c, PreparedStatement ps,
                                                                    int parameterIndx,
                                                                    boolean isUpdate) throws
      SQLException {
    String entry;
    long date;

    if (isUpdate) {
      date = new java.util.Date(c.getRow_entry_date()).getTime();
      entry = "Y".equalsIgnoreCase(c.getAffina_entry_flag()) ? "AFFINA EDIT" : "COMPLAINT_EDIT";
    } else {
      entry = "Y".equalsIgnoreCase(c.getAffina_entry_flag()) ? "AFFINA_ENTRY" : "COMPLAINT_ENTRY";
      date = new java.util.Date().getTime();
    }
    ps.setDate(parameterIndx + 16, new Date(date));
    ps.setString(parameterIndx + 18, entry);
    setQualityIssue(c, ps, parameterIndx);
  }

  public boolean addComplaintAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.ADD_COMPLAINT_ATTACHMENT_SQL);
      ps.setString(1, attachmentInfo.getDocumentId());
      ps.setInt(2, Integer.parseInt(attachmentInfo.getEntityId()));
      ps.setString(3, attachmentInfo.getDocumentName());
      ps.executeUpdate();
      commit(conn);
      return true;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, null);
    }
  }

  public boolean deleteComplaintAttachmentInfo(String documentId) throws DAOException {
    PreparedStatement ps = null;
    Connection conn = null;
    try {
      conn = getConnection();
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_ATTACHMENT_SQL);
      ps.setString(1, documentId);
      ps.executeUpdate();
      commit(conn);
      return true;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, null);
    }
  }


  public void updateComplaintDocumentation(Cpar cpar, String complaintId) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    boolean update = false;
    String longTermCorrectiveAction = "";
    StringBuffer query = new StringBuffer(ComplaintDAOSQLConstants.UPDATE_CPAR_TO_COMPLAINT_DOCUMENTATION_SQL);

    try {
      if (!(cpar.getLong_term_corrective_action() == null) && !(cpar.getLong_term_corrective_action().equals(""))) {
        query.append(", LONG_TERM_CORRECTION_ACTION=? ");
        longTermCorrectiveAction = cpar.getLong_term_corrective_action();
        update = true;
      }
      if (update) {
        conn = getConnection();
        query.append(" WHERE COMPLAINT_ID=").append(complaintId);

        ps = conn.prepareStatement(query.toString());
        ps.setString(1, "APPLICATION");
        ps.setString(2, "CAR UPDATE");
        ps.setDate(3, new Date(new java.util.Date().getTime()));
        if (!StringUtils.isNullOrEmpty(longTermCorrectiveAction)) {
          ps.setString(4, longTermCorrectiveAction);
        }
        ps.executeUpdate();
        commit(conn);
//        System.out.println("Complaint Updated !");
      }
    } catch (Exception e) {
      rollback(conn);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }

    /**
     * Update cpar id in complaint table.
     * @param cpar
     * @param complaintId
     * @throws DAOException
     */
  public void updateCParIdInComplaintTable(Cpar cpar, String complaintId) throws DAOException {
    /*PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    StringBuffer query = new StringBuffer(ComplaintDAOSQLConstants.UPDATE_CPAR_ID_IN_COMPLAINT_TABLE_SQL);

    try {
        conn = getConnection();
        ps = conn.prepareStatement(query.toString());
        ps.setLong(1, Long.parseLong(cpar.getCpar_id()));
        ps.setLong(2, Long.parseLong(complaintId));

        ps.executeUpdate();
        commit(conn);

    } catch (Exception e) {
      rollback(conn);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    } */
    //insert complaint cpar values in complaint_cpar_xref
    insertComplaintCparIdInComplaintCparXref(cpar,complaintId);
  }


private void insertComplaintCparIdInComplaintCparXref(Cpar cpar, String complaintId) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    StringBuffer query = new StringBuffer(ComplaintDAOSQLConstants.INSERT_COMPLAINT_CPAR_ID_SQL);
    try {
        conn = getConnection();
        ps = conn.prepareStatement(query.toString());
        ps.setLong(1, Long.parseLong(complaintId));
        ps.setLong(2, Long.parseLong(cpar.getCpar_id()));        

        ps.executeUpdate();
        commit(conn);

    } catch (Exception e) {
      rollback(conn);
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, ps, rs);
    }
  }


private void insertComplaintCparIdInComplaintCparXrefFromInsertComplaint(Connection conn, Cpar cpar, String complaintId) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    StringBuffer query = new StringBuffer(ComplaintDAOSQLConstants.INSERT_COMPLAINT_CPAR_ID_SQL);
    try {
        //conn = getConnection();
        ps = conn.prepareStatement(query.toString());
        ps.setLong(1, Long.parseLong(complaintId));
        ps.setLong(2, Long.parseLong(cpar.getCpar_id()));

        ps.executeUpdate();
        commit(conn);

    } catch (Exception e) {
      rollback(conn);
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  /**
   * Method to Delete the complaint. Note: This just marks the IS_DELETED='Y' and does not delete the complaint from the
   * DB
   */
  public void deleteComplaint(String complaintId) throws DAOException {
    Statement statement = null;
    Connection conn = null;
    try {
      conn = getConnection();
      statement = conn.createStatement();
      statement.executeUpdate("UPDATE COMPLAINT SET IS_DELETED = 'Y' WHERE COMPLAINT_ID = " + complaintId);
      statement.executeUpdate("UPDATE CPAR SET COMPLAINT_ID = NULL WHERE COMPLAINT_ID = " + complaintId);
      conn.commit();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(conn, statement, null);
    }
  }

  public void processComplaintInsert(List<String> complaintIdList) throws SQLException {
    Connection conn = getConnection();

    PreparedStatement complaintDupStmt = null;
    PreparedStatement complaintInsectDupStmt = null;
    PreparedStatement complaintPlantingDupStmt = null;
    PreparedStatement complaintDiseaseDupStmt = null;
    PreparedStatement complaintBatchDupStmt = null;
    PreparedStatement complaintDealerDupStmt = null;
    PreparedStatement complaintGrowerDupStmt = null;
    PreparedStatement complaintDocumentationDupStmt = null;
    PreparedStatement complaintAttachmentDupStmt = null;
    PreparedStatement complaintInvestigationDupStmt = null;

    try {
      complaintDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_DUPLICATE_QUERY);
      complaintInsectDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_INSECT_DUPLICATE_QUERY);
      complaintPlantingDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_PLANTING_DUPLICATE_QUERY);
      complaintDiseaseDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_DISEASE_DUPLICATE_QUERY);
      complaintBatchDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_BATCH_DUPLICATE_QUERY);
      complaintDealerDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_DEALER_DUPLICATE_QUERY);
      complaintGrowerDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_GROWER_DUPLICATE_QUERY);
      complaintDocumentationDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_DOCUMENTATION_DUPLICATE_QUERY);
      complaintAttachmentDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_ATTACHMENT_DUPLICATE_QUERY);
      complaintInvestigationDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_INVESTIGATION_DUPLICATE_QUERY);

      long complaintIdLong = -1;
      for (String complaintId : complaintIdList) {
        complaintIdLong = Long.parseLong(complaintId);
        complaintDupStmt.setLong(1, complaintIdLong);
        complaintInsectDupStmt.setLong(1, complaintIdLong);
        complaintPlantingDupStmt.setLong(1, complaintIdLong);
        complaintDiseaseDupStmt.setLong(1, complaintIdLong);
        complaintBatchDupStmt.setLong(1, complaintIdLong);
        complaintDealerDupStmt.setLong(1, complaintIdLong);
        complaintGrowerDupStmt.setLong(1, complaintIdLong);
        complaintDocumentationDupStmt.setLong(1, complaintIdLong);
        complaintAttachmentDupStmt.setLong(1, complaintIdLong);
        complaintInvestigationDupStmt.setLong(1, complaintIdLong);

        addBatches(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
            complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
            complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);
      }

      executeInsertBatches(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
          complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
          complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);


      closeResources(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
          complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
          complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);
      conn.commit();
    } finally {
      closeDBResources(conn, null, null);

      closeDBResources(null, complaintDupStmt, null);
      closeDBResources(null, complaintInsectDupStmt, null);
      closeDBResources(null, complaintPlantingDupStmt, null);
      closeDBResources(null, complaintDiseaseDupStmt, null);
      closeDBResources(null, complaintBatchDupStmt, null);
      closeDBResources(null, complaintDealerDupStmt, null);
      closeDBResources(null, complaintGrowerDupStmt, null);
      closeDBResources(null, complaintDocumentationDupStmt, null);
      closeDBResources(null, complaintAttachmentDupStmt, null);
      closeDBResources(null, complaintInvestigationDupStmt, null);
    }
  }

  public void processComplaintDelete(List<String> complaintIdList) throws SQLException {

    Connection conn = getConnection();

    PreparedStatement complaintDupStmt = null;
    PreparedStatement complaintInsectDupStmt = null;
    PreparedStatement complaintPlantingDupStmt = null;
    PreparedStatement complaintDiseaseDupStmt = null;
    PreparedStatement complaintBatchDupStmt = null;
    PreparedStatement complaintDealerDupStmt = null;
    PreparedStatement complaintGrowerDupStmt = null;
    PreparedStatement complaintDocumentationDupStmt = null;
    PreparedStatement complaintAttachmentDupStmt = null;
    PreparedStatement complaintInvestigationDupStmt = null;

    try {
      complaintDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_DUPLICATE_QUERY);
      complaintInsectDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_INSECT_DUPLICATE_QUERY);
      complaintPlantingDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_PLANTING_DUPLICATE_QUERY);
      complaintDiseaseDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_DISEASE_DUPLICATE_QUERY);
      complaintBatchDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_BATCH_DUPLICATE_QUERY);
      complaintDealerDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_DEALER_DUPLICATE_QUERY);
      complaintGrowerDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_GROWER_DUPLICATE_QUERY);
      complaintDocumentationDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_DOCUMENTATION_DUPLICATE_QUERY);
      complaintAttachmentDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_ATTACHMENT_DUPLICATE_QUERY);
      complaintInvestigationDupStmt = conn
          .prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_INVESTIGATION_DUPLICATE_QUERY);

      long complaintIdLong = -1;
      for (String complaintId : complaintIdList) {
        complaintIdLong = Long.parseLong(complaintId);
        complaintDupStmt.setLong(1, complaintIdLong);
        complaintInsectDupStmt.setLong(1, complaintIdLong);
        complaintPlantingDupStmt.setLong(1, complaintIdLong);
        complaintDiseaseDupStmt.setLong(1, complaintIdLong);
        complaintBatchDupStmt.setLong(1, complaintIdLong);
        complaintDealerDupStmt.setLong(1, complaintIdLong);
        complaintGrowerDupStmt.setLong(1, complaintIdLong);
        complaintDocumentationDupStmt.setLong(1, complaintIdLong);
        complaintAttachmentDupStmt.setLong(1, complaintIdLong);

        addBatches(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
            complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
            complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);
      }
      executeDeleteBatches(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
          complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
          complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);


      closeResources(complaintDupStmt, complaintInsectDupStmt, complaintPlantingDupStmt, complaintDiseaseDupStmt,
          complaintBatchDupStmt, complaintDealerDupStmt, complaintDocumentationDupStmt,
          complaintAttachmentDupStmt, complaintGrowerDupStmt, complaintInvestigationDupStmt);
      conn.commit();
    } finally {
      closeDBResources(conn, null, null);

      closeDBResources(null, complaintDupStmt, null);
      closeDBResources(null, complaintInsectDupStmt, null);
      closeDBResources(null, complaintPlantingDupStmt, null);
      closeDBResources(null, complaintDiseaseDupStmt, null);
      closeDBResources(null, complaintBatchDupStmt, null);
      closeDBResources(null, complaintDealerDupStmt, null);
      closeDBResources(null, complaintGrowerDupStmt, null);
      closeDBResources(null, complaintDocumentationDupStmt, null);
      closeDBResources(null, complaintAttachmentDupStmt, null);
      closeDBResources(null, complaintInvestigationDupStmt, null);
    }
  }

  protected void commit(Connection conn) throws SQLException {
    conn.commit();
  }

  private void rollback(Connection conn) throws DAOException {
    try {
      conn.rollback();
    } catch (SQLException ex) {
      throw new DAOException(ex);
    }
  }

  private void setQualityIssue(Complaint c, PreparedStatement ps, int parameterIndx) throws SQLException {
    if (c != null && !StringUtils.isNullOrEmpty(c.getQuality_issue())) {
      ps.setInt(parameterIndx + 22, Integer.parseInt(c.getQuality_issue()));
    } else {
      ps.setNull(parameterIndx + 22, Types.INTEGER);
    }
  }

  private void deleteBatches(String complaint_id, Connection conn) throws SQLException {
    PreparedStatement ps = null;
    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.DELETE_COMPLAINT_BATCH_SQL);
      ps.setLong(1, Long.parseLong(complaint_id));
      ps.executeUpdate();
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, null);
    }
  }

  private String trimProblemDescriptionText(String problemDescription) {
    return MCASUtil.trimDescriptionText(problemDescription);
  }


  private void getComplaintAttachmentInfo(String complaint_id, Complaint c, Connection conn) throws SQLException,
      MCASException {

    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_ATTACHMENTS);
      ps.setString(1, complaint_id);
      rs = ps.executeQuery();
      while (rs.next()) {
        String documentId = rs.getString("DOCUMENT_ID");
        String complaintId = rs.getString("COMPLAINT_ID");
        String documentName = rs.getString("DOCUMENT_NAME");
        AttachmentInfo attachmentInfo = new AttachmentInfo(complaintId, documentId, documentName);
        c.getComplaintAttachments().put(documentId, attachmentInfo);
      }
    } finally {
      MCASResourceUtil.closeDBResources(null, ps, rs);
    }
  }

  private Map<String, RowBean> createHashFromResultSet(ResultSet rs, String locale) throws Exception {
    Map<String, RowBean> hash = new HashMap<String, RowBean>();
    int rowCount = 0;
    I18nServiceImpl iService = new I18nServiceImpl();

    while (rs.next()) {
      rowCount++;
      RowBean rowBean = new RowBean();
      //**Oracle9i Bug Solution...
      //The "LONG" and "LONGRAW" fields needs to be accessed first to avoid the
      //"java.sql.SQLException: Stream has already been closed" error.
      String deliveryInfo = rs.getString("DELIVERY_INFO");
      if (deliveryInfo == null) {
        deliveryInfo = "-";
      }

      //We need to Pair based on Control Number and Audit Area ID
      int reportComplaintId = rs.getInt("CONTROL_NUMBER");
      rowBean.setCol(1, Integer.toString(reportComplaintId));
     // int complaintBatchSeq = rs.getInt("COMPLAINT_BATCH_SEQ");
     // String complaintBatchSeqString = complaintBatchSeq + "";
     // if ((complaintBatchSeqString != null) && (!complaintBatchSeqString.equals("0")) && (!complaintBatchSeqString.equals(""))) {    //**This can be null...
      //  rowBean.setCol(87, complaintBatchSeqString);
     // } else {
      //  rowBean.setCol(87, "-");
      //}
      if (rs.getString("CLAIM_NUMBER") != null &&
          !(rs.getString("CLAIM_NUMBER").trim().equals(""))) {    //**This can be null...
        rowBean.setCol(2, rs.getString("CLAIM_NUMBER"));
      } else {
        rowBean.setCol(2, "-");
      }
      if (rs.getString("STATUS_DESCRIPTION") != null &&
          !(rs.getString("STATUS_DESCRIPTION").trim().equals(""))) {

        int id = rs.getInt("status_id");
        String desc = iService.translate(locale, "STATUS_REF", id, rs.getString("STATUS_DESCRIPTION"));
        rowBean.setCol(3, desc);
      } else {
        rowBean.setCol(3, rs.getString("-"));
      }
      if (rs.getString("SALES_YR") != null && !(rs.getString("SALES_YR").trim().equals(""))) {
        rowBean.setCol(4, rs.getString("SALES_YR"));
      } else {
        rowBean.setCol(4, "-");
      }
      if (rs.getString("STATE") != null && !(rs.getString("STATE").trim().equals(""))) {
        rowBean.setCol(5, rs.getString("STATE"));
      } else {
        rowBean.setCol(5, "-");
      }
      if (rs.getString("INITIATED_BY") != null && !(rs.getString("INITIATED_BY").trim().equals(""))) {
        rowBean.setCol(6, rs.getString("INITIATED_BY"));
      } else {
        rowBean.setCol(6, "-");
      }
      if (rs.getDate("REPORTED_DATE") != null) {
        rowBean.setCol(7, getDateFormat(rs.getDate("REPORTED_DATE")));
      } else {
        rowBean.setCol(7, "-");
      }
      if (rs.getDate("COMMUNICATION_DATE") != null) {
        rowBean.setCol(8, getDateFormat(rs.getDate("COMMUNICATION_DATE")));
      } else {
        rowBean.setCol(8, "-");
      }
      if (rs.getString("FIELD_COMMUNICATOR") != null &&
          !(rs.getString("FIELD_COMMUNICATOR").trim().equals(""))) {
        rowBean.setCol(9, rs.getString("FIELD_COMMUNICATOR"));
      } else {
        rowBean.setCol(9, "-");
      }
      if (rs.getString("REPORTING_LOCATION_CODE") != null &&
          !(rs.getString("REPORTING_LOCATION_CODE").trim().equals(""))) {
        rowBean.setCol(10, rs.getString("REPORTING_LOCATION_CODE"));
      } else {
        rowBean.setCol(10, "-");
      }

      if (rs.getString("REPORTING_LOCATION") != null &&
          !(rs.getString("REPORTING_LOCATION").trim().equals(""))) {
        rowBean.setCol(11, rs.getString("REPORTING_LOCATION"));
      } else {
        rowBean.setCol(11, "-");
      }
      if (rs.getString("RESPONSIBLE_PLANT_CODE") != null &&
          !(rs.getString("RESPONSIBLE_PLANT_CODE").trim().equals(""))) {
        rowBean.setCol(12, rs.getString("RESPONSIBLE_PLANT_CODE"));
      } else {
        rowBean.setCol(12, "-");
      }
      if (rs.getString("RESPONSIBLE_LOCATION") != null &&
          !(rs.getString("RESPONSIBLE_LOCATION").trim().equals(""))) {
        rowBean.setCol(13, rs.getString("RESPONSIBLE_LOCATION"));
      } else {
        rowBean.setCol(13, "-");
      }
      if (rs.getString("CROP") != null && !(rs.getString("CROP").trim().equals(""))) {

        int id = rs.getInt("CROP_ID");
        String cropDescription = iService.translate(locale, "CROP_REF", id, rs.getString("CROP"));

        rowBean.setCol(14, cropDescription);
      } else {
        rowBean.setCol(14, "-");
      }
      if (rs.getString("PERSON_INVESTIGATING") != null &&
          !(rs.getString("PERSON_INVESTIGATING").trim().equals(""))) {
        rowBean.setCol(15, rs.getString("PERSON_INVESTIGATING"));
      } else {
        rowBean.setCol(15, "-");
      }
      if (rs.getString("SEED_SIZE") != null && !(rs.getString("SEED_SIZE").trim().equals(""))) {

        int id = rs.getInt("SEED_SIZE_ID");
        String desc = iService.translate(locale, "SEED_SIZE_REF", id, rs.getString("SEED_SIZE"));

        rowBean.setCol(16, desc);
      } else {
        rowBean.setCol(16, "-");
      }
      if (rs.getString("QTY_AFFECTED") != null && !(rs.getString("QTY_AFFECTED").trim().equals(""))) {
        rowBean.setCol(17, rs.getString("QTY_AFFECTED"));
      } else {
        rowBean.setCol(17, "-");
      }
      if (rs.getString("QTY_UOM") != null && !(rs.getString("QTY_UOM").trim().equals(""))) {

        int id = rs.getInt("QTY_UOM_ID");
        String desc = iService.translate(locale, "QTY_UOM_REF", id, rs.getString("QTY_UOM"));

        rowBean.setCol(18, desc);
      } else {
        rowBean.setCol(18, "-");
      }

      rowBean.setCol(19, deliveryInfo);

      if (rs.getString("CREATED_BY") != null && !(rs.getString("CREATED_BY").trim().equals(""))) {
        rowBean.setCol(20, rs.getString("CREATED_BY"));
      } else {
        rowBean.setCol(20, "-");
      }
      if (rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))) {

        int id = rs.getInt("REGION_ID");
        String desc = iService.translate(locale, "REGION_REF", id, rs.getString("REGION"));
        rowBean.setCol(21, desc);
      } else {
        rowBean.setCol(21, "-");
      }
      if (rs.getString("COMPLAINT_QUALITY_ISSUE") != null &&
          !(rs.getString("COMPLAINT_QUALITY_ISSUE").trim().equals(""))) {

        int id = rs.getInt("COMPLAINT_QUALITY_ISSUE_ID");
        String desc = iService
            .translate(locale, "COMPLAINT_QUALITY_ISSUE_REF", id, rs.getString("COMPLAINT_QUALITY_ISSUE"));

        rowBean.setCol(22, desc);
      } else {
        rowBean.setCol(22, "-");
      }
      if (rs.getString("SETTLEMENT_VALUE") != null && !(rs.getString("SETTLEMENT_VALUE").trim().equals(""))) {
        rowBean.setCol(23, rs.getString("SETTLEMENT_VALUE"));
      } else {
        rowBean.setCol(23, "-");
      }
      if (rs.getString("BATCH") != null && !(rs.getString("BATCH").trim().equals(""))) {
        rowBean.setCol(24, rs.getString("BATCH"));
      } else {
        rowBean.setCol(24, "-");
      }
      if (rs.getString("PROBLEM_DESCRIPTION") != null &&
          !(rs.getString("PROBLEM_DESCRIPTION").trim().equals(""))) {
        rowBean.setCol(25, rs.getString("PROBLEM_DESCRIPTION"));
      } else {
        rowBean.setCol(25, "-");
      }
      if (rs.getString("CONTAINMENT_ACTION") != null &&
          !(rs.getString("CONTAINMENT_ACTION").trim().equals(""))) {
        rowBean.setCol(26, rs.getString("CONTAINMENT_ACTION"));
      } else {
        rowBean.setCol(26, "-");
      }
      if (rs.getString("ROOT_CAUSE") != null && !(rs.getString("ROOT_CAUSE").trim().equals(""))) {
        rowBean.setCol(27, rs.getString("ROOT_CAUSE"));
      } else {
        rowBean.setCol(27, "-");
      }
      if (rs.getString("LONG_TERM_CORRECTION_ACTION") != null &&
          !(rs.getString("LONG_TERM_CORRECTION_ACTION").trim().equals(""))) {
        rowBean.setCol(28, rs.getString("LONG_TERM_CORRECTION_ACTION"));
      } else {
        rowBean.setCol(28, "-");
      }
      if (rs.getString("DISEASE_OBSERVED") != null && !(rs.getString("DISEASE_OBSERVED").trim().equals(""))) {
        rowBean.setCol(29, rs.getString("DISEASE_OBSERVED"));
      } else {
        rowBean.setCol(29, "-");
      }
      if (rs.getString("HERBICIDE_TYPE_CY") != null && !(rs.getString("HERBICIDE_TYPE_CY").trim().equals(""))) {
        rowBean.setCol(30, rs.getString("HERBICIDE_TYPE_CY"));
      } else {
        rowBean.setCol(30, "-");
      }

      if (rs.getString("HERBICIDE_RATE_CY") != null && !(rs.getString("HERBICIDE_RATE_CY").trim().equals(""))) {
        rowBean.setCol(31, rs.getString("HERBICIDE_RATE_CY"));
      } else {
        rowBean.setCol(31, "-");
      }
      if (rs.getString("HERBICIDE_TIMING_CY") != null &&
          !(rs.getString("HERBICIDE_TIMING_CY").trim().equals(""))) {
        rowBean.setCol(32, rs.getString("HERBICIDE_TIMING_CY"));
      } else {
        rowBean.setCol(32, "-");
      }
      if (rs.getString("HERBICIDE_TYPE_PY") != null && !(rs.getString("HERBICIDE_TYPE_PY").trim().equals(""))) {
        rowBean.setCol(33, rs.getString("HERBICIDE_TYPE_PY"));
      } else {
        rowBean.setCol(33, "-");
      }
      if (rs.getString("HERBICIDE_RATE_PY") != null && !(rs.getString("HERBICIDE_RATE_PY").trim().equals(""))) {
        rowBean.setCol(34, rs.getString("HERBICIDE_RATE_PY"));
      } else {
        rowBean.setCol(34, "-");
      }
      if (rs.getString("HERBICIDE_TIMING_PY") != null &&
          !(rs.getString("HERBICIDE_TIMING_PY").trim().equals(""))) {
        rowBean.setCol(35, rs.getString("HERBICIDE_TIMING_PY"));
      } else {
        rowBean.setCol(35, "-");
      }
      if (rs.getString("INSECTS_OBSERVED") != null && !(rs.getString("INSECTS_OBSERVED").trim().equals(""))) {
        rowBean.setCol(36, rs.getString("INSECTS_OBSERVED"));
      } else {
        rowBean.setCol(36, "-");
      }
      if (rs.getString("INSECTICIDE_TYPE_CY") != null &&
          !(rs.getString("INSECTICIDE_TYPE_CY").trim().equals(""))) {
        rowBean.setCol(37, rs.getString("INSECTICIDE_TYPE_CY"));
      } else {
        rowBean.setCol(37, "-");
      }
      if (rs.getString("INSECTICIDE_RATE_CY") != null &&
          !(rs.getString("INSECTICIDE_RATE_CY").trim().equals(""))) {
        rowBean.setCol(38, rs.getString("INSECTICIDE_RATE_CY"));
      } else {
        rowBean.setCol(38, "-");
      }
      if (rs.getString("INSECTICIDE_TIMING_CY") != null &&
          !(rs.getString("INSECTICIDE_TIMING_CY").trim().equals(""))) {
        rowBean.setCol(39, rs.getString("INSECTICIDE_TIMING_CY"));
      } else {
        rowBean.setCol(39, "-");
      }
      if (rs.getString("INSECTICIDE_TYPE_PY") != null &&
          !(rs.getString("INSECTICIDE_TYPE_PY").trim().equals(""))) {
        rowBean.setCol(40, rs.getString("INSECTICIDE_TYPE_PY"));
      } else {
        rowBean.setCol(40, "-");
      }

      if (rs.getString("INSECTICIDE_RATE_PY") != null &&
          !(rs.getString("INSECTICIDE_RATE_PY").trim().equals(""))) {
        rowBean.setCol(41, rs.getString("INSECTICIDE_RATE_PY"));
      } else {
        rowBean.setCol(41, "-");
      }
      if (rs.getString("INSECTICIDE_TIMING_PY") != null &&
          !(rs.getString("INSECTICIDE_TIMING_PY").trim().equals(""))) {
        rowBean.setCol(42, rs.getString("INSECTICIDE_TIMING_PY"));
      } else {
        rowBean.setCol(42, "-");
      }
      if (rs.getString("TOTAL_ACRES") != null && !(rs.getString("TOTAL_ACRES").trim().equals(""))) {
        rowBean.setCol(43, rs.getString("TOTAL_ACRES"));
      } else {
        rowBean.setCol(43, "-");
      }
      if (rs.getString("AFFECTED_ACRES") != null && !(rs.getString("AFFECTED_ACRES").trim().equals(""))) {
        rowBean.setCol(44, rs.getString("AFFECTED_ACRES"));
      } else {
        rowBean.setCol(44, "-");
      }
      if (rs.getString("TECHNOLOGY") != null && !(rs.getString("TECHNOLOGY").trim().equals(""))) {
        rowBean.setCol(45, rs.getString("TECHNOLOGY"));
      } else {
        rowBean.setCol(45, "-");
      }
      if (rs.getDate("PLANTING_DATE") != null) {
        rowBean.setCol(46, getDateFormat(rs.getDate("PLANTING_DATE")));
      } else {
        rowBean.setCol(46, "-");
      }
      if (rs.getString("PLANTER_TYPE") != null && !(rs.getString("PLANTER_TYPE").trim().equals(""))) {
        rowBean.setCol(47, rs.getString("PLANTER_TYPE"));
      } else {
        rowBean.setCol(47, "-");
      }
      if (rs.getString("PLANTER_DEPTH") != null && !(rs.getString("PLANTER_DEPTH").trim().equals(""))) {
        rowBean.setCol(48, rs.getString("PLANTER_DEPTH"));
      } else {
        rowBean.setCol(48, "-");
      }
      if (rs.getString("POPULATION_PLANTED") != null &&
          !(rs.getString("POPULATION_PLANTED").trim().equals(""))) {
        rowBean.setCol(49, rs.getString("POPULATION_PLANTED"));
      } else {
        rowBean.setCol(49, "-");
      }
      if (rs.getString("POPULATION_OBSERVED") != null &&
          !(rs.getString("POPULATION_OBSERVED").trim().equals(""))) {
        rowBean.setCol(50, rs.getString("POPULATION_OBSERVED"));
      } else {
        rowBean.setCol(50, "-");
      }

      if (rs.getString("TILLAGE") != null && !(rs.getString("TILLAGE").trim().equals(""))) {
        rowBean.setCol(51, rs.getString("TILLAGE"));
      } else {
        rowBean.setCol(51, "-");
      }
      if (rs.getString("COMPLAINT_ISSUE_DESCRIPTION") != null &&
          !(rs.getString("COMPLAINT_ISSUE_DESCRIPTION").trim().equals(""))) {
        rowBean.setCol(52, rs.getString("COMPLAINT_ISSUE_DESCRIPTION"));
      } else {
        rowBean.setCol(52, "-");
      }
      if (rs.getString("ISSUE_TYPE") != null && !(rs.getString("ISSUE_TYPE").trim().equals(""))) {
        rowBean.setCol(53, rs.getString("ISSUE_TYPE"));
      } else {
        rowBean.setCol(53, "-");
      }
      if (rs.getString("GROWER_NAME") != null && !(rs.getString("GROWER_NAME").trim().equals(""))) {
        rowBean.setCol(54, rs.getString("GROWER_NAME"));
      } else {
        rowBean.setCol(54, "-");
      }
      if (rs.getString("GROWER_ADDRESS") != null && !(rs.getString("GROWER_ADDRESS").trim().equals(""))) {
        rowBean.setCol(55, rs.getString("GROWER_ADDRESS"));
      } else {
        rowBean.setCol(55, "-");
      }
      if (rs.getString("GROWER_CITY") != null && !(rs.getString("GROWER_CITY").trim().equals(""))) {
        rowBean.setCol(56, rs.getString("GROWER_CITY"));
      } else {
        rowBean.setCol(56, "-");
      }
      if (rs.getString("GROWER_PHONE") != null && !(rs.getString("GROWER_PHONE").trim().equals(""))) {
        rowBean.setCol(57, rs.getString("GROWER_PHONE"));
      } else {
        rowBean.setCol(57, "-");
      }
      if (rs.getString("GROWER_BA_ID") != null && !(rs.getString("GROWER_BA_ID").trim().equals(""))) {
        rowBean.setCol(58, rs.getString("GROWER_BA_ID"));
      } else {
        rowBean.setCol(58, "-");
      }
      if (rs.getString("DEALER_NAME") != null && !(rs.getString("DEALER_NAME").trim().equals(""))) {
        rowBean.setCol(59, rs.getString("DEALER_NAME"));
      } else {
        rowBean.setCol(59, "-");
      }
      if (rs.getString("DEALER_ADDRESS") != null && !(rs.getString("DEALER_ADDRESS").trim().equals(""))) {
        rowBean.setCol(60, rs.getString("DEALER_ADDRESS"));
      } else {
        rowBean.setCol(60, "-");
      }

      if (rs.getString("DEALER_CITY") != null && !(rs.getString("DEALER_CITY").trim().equals(""))) {
        rowBean.setCol(61, rs.getString("DEALER_CITY"));
      } else {
        rowBean.setCol(61, "-");
      }
      if (rs.getString("DEALER_PHONE") != null && !(rs.getString("DEALER_PHONE").trim().equals(""))) {
        rowBean.setCol(62, rs.getString("DEALER_PHONE"));
      } else {
        rowBean.setCol(62, "-");
      }
      if (rs.getString("DEALER_BA_ID") != null && !(rs.getString("DEALER_BA_ID").trim().equals(""))) {
        rowBean.setCol(63, rs.getString("DEALER_BA_ID"));
      } else {
        rowBean.setCol(63, "-");
      }
      if (rs.getString("VARIETY") != null && !(rs.getString("VARIETY").trim().equals(""))) {
        rowBean.setCol(64, rs.getString("VARIETY"));
      } else {
        rowBean.setCol(64, "-");
      }
      if (rs.getString("BUSINESS_ID") != null && !(rs.getString("BUSINESS_ID").trim().equals(""))) {
        rowBean.setCol(69, rs.getString("BUSINESS_ID"));
      } else {
        rowBean.setCol(69, "-");
      }
      if (rs.getString("SALES_OFFICE_ID") != null && !(rs.getString("SALES_OFFICE_ID").trim().equals(""))) {
        rowBean.setCol(70, rs.getString("SALES_OFFICE_ID"));
      } else {
        rowBean.setCol(70, "-");
      }
      if (rs.getString("MATERIAL_GRP_ID") != null && !(rs.getString("MATERIAL_GRP_ID").trim().equals(""))) {
        rowBean.setCol(71, rs.getString("MATERIAL_GRP_ID"));
      } else {
        rowBean.setCol(71, "-");
      }
      if (rs.getString("MATERIAL_GROUP_PRICING_ID") != null &&
          !(rs.getString("MATERIAL_GROUP_PRICING_ID").trim().equals(""))) {
        rowBean.setCol(72, rs.getString("MATERIAL_GROUP_PRICING_ID"));
      } else {
        rowBean.setCol(72, "-");
      }
      if (rs.getString("SHIPPING_TRANSPORT_NUMBER") != null &&
          !(rs.getString("SHIPPING_TRANSPORT_NUMBER").trim().equals(""))) {
        rowBean.setCol(73, rs.getString("SHIPPING_TRANSPORT_NUMBER"));
      } else {
        rowBean.setCol(73, "-");
      }
      if (rs.getString("CUSTOMER_NAME") != null && !(rs.getString("CUSTOMER_NAME").trim().equals(""))) {
        rowBean.setCol(74, rs.getString("CUSTOMER_NAME"));
      } else {
        rowBean.setCol(74, "-");
      }
      if (rs.getString("CUSTOMER_ADDRESS") != null && !(rs.getString("CUSTOMER_ADDRESS").trim().equals(""))) {
        rowBean.setCol(75, rs.getString("CUSTOMER_ADDRESS"));
      } else {
        rowBean.setCol(75, "-");
      }
      if (rs.getString("CUST_PHONE_NUMBER") != null && !(rs.getString("CUST_PHONE_NUMBER").trim().equals(""))) {
        rowBean.setCol(76, rs.getString("CUST_PHONE_NUMBER"));
      } else {
        rowBean.setCol(76, "-");
      }
      if (rs.getString("CUST_EMAIL") != null && !(rs.getString("CUST_EMAIl").trim().equals(""))) {
        rowBean.setCol(77, rs.getString("CUST_EMAIl"));
      } else {
        rowBean.setCol(77, "-");
      }
      if (rs.getString("SALES_ORDER_NUMBER") != null && !(rs.getString("SALES_ORDER_NUMBER").trim().equals(""))) {
        rowBean.setCol(78, rs.getString("SALES_ORDER_NUMBER"));
      } else {
        rowBean.setCol(78, "-");
      }
      if (rs.getString("CLAIM_STATUS") != null && !(rs.getString("CLAIM_STATUS").trim().equals(""))) {
        rowBean.setCol(79, rs.getString("CLAIM_STATUS"));
      } else {
        rowBean.setCol(79, "-");
      }
      //Initial Assesment

      ActionHelper actionHelper = new ActionHelper();
      //Note, ASSESMENT_DESCRIPTION is not the actual description, but the ID.
      if (rs.getString("ASSESSMENT_DESCRIPTION") != null && !"0".equals(rs.getString("ASSESSMENT_DESCRIPTION")) &&
          !"null".equals(rs.getString("ASSESSMENT_DESCRIPTION")) &&
          !("".equals(rs.getString("ASSESSMENT_DESCRIPTION").trim()))) {
        try {
          rowBean.setCol(80, actionHelper.getAssesmentMap(locale).get(rs.getString("ASSESSMENT_DESCRIPTION")));
        } catch (Exception e) {
          MCASLogUtil.logError(e.getMessage(), e);
          rowBean.setCol(80, "-");
        }
      } else {
        rowBean.setCol(80, "-");
      }
      //Complaint Category
      if (rs.getString("LITIGATION_DESCRIPTION") != null && !"0".equals(rs.getString("LITIGATION_DESCRIPTION")) &&
          !"null".equals(rs.getString("LITIGATION_DESCRIPTION")) &&
          !("".equals(rs.getString("LITIGATION_DESCRIPTION").trim()))) {
        try {
          rowBean.setCol(81, actionHelper.getLitigationCategoryMap(locale).get(rs.getString("LITIGATION_DESCRIPTION")));
        } catch (Exception e) {
          MCASLogUtil.logError(e.getMessage(), e);
          rowBean.setCol(81, "-");
        }
      } else {
        rowBean.setCol(81, "-");
      }
      //Audit Area
      if (rs.getString("AUDIT_AREA_DESCRIPTION") != null && !"0".equals(rs.getString("AUDIT_AREA_DESCRIPTION")) &&
          !"null".equals(rs.getString("AUDIT_AREA_DESCRIPTION")) &&
          !("".equals(rs.getString("AUDIT_AREA_DESCRIPTION").trim()))) {
        try {
          rowBean.setCol(82, rs.getString("AUDIT_AREA_DESCRIPTION"));
        } catch (Exception e) {
          MCASLogUtil.logError(e.getMessage(), e);
          rowBean.setCol(82, "-");
        }
      } else {
        rowBean.setCol(82, "-");
      }

      //Material Group
      if (rs.getString("MATERIAL_GROUP_NAME") != null && !"0".equals(rs.getString("MATERIAL_GROUP_NAME")) &&
          !"null".equals(rs.getString("MATERIAL_GROUP_NAME")) &&
          !("".equals(rs.getString("MATERIAL_GROUP_NAME").trim()))) {
        try {
          rowBean.setCol(83, rs.getString("MATERIAL_GROUP_NAME"));
        } catch (Exception e) {
          MCASLogUtil.logError(e.getMessage(), e);
          rowBean.setCol(83, "-");
        }
      } else {
        rowBean.setCol(83, "-");
      }
      //Material Group
      if (rs.getString("MATERIAL_PRICING_DESC") != null && !"0".equals(rs.getString("MATERIAL_PRICING_DESC")) &&
          !"null".equals(rs.getString("MATERIAL_PRICING_DESC")) &&
          !("".equals(rs.getString("MATERIAL_PRICING_DESC").trim()))) {
        try {
          rowBean.setCol(84, rs.getString("MATERIAL_PRICING_DESC"));
        } catch (Exception e) {
          MCASLogUtil.logError(e.getMessage(), e);
          rowBean.setCol(83, "-");
        }
      } else {
        rowBean.setCol(84, "-");
      }
      if (rs.getDate("CREATED_DATE") != null) {
        rowBean.setCol(85, getDateFormat(rs.getDate("CREATED_DATE")));
      }
      if (rs.getString("CLAIM_AMOUNT") != null) {
        rowBean.setCol(86, rs.getString("CLAIM_AMOUNT"));
      } else {
        rowBean.setCol(86, "-");
      }
      hash.put(rowCount + "", rowBean);
    }

    return hash;
  }

  private void addAllFiltersToWhereClause(ComplaintFilter complaintFilter, StringBuffer whereClause, int businessId) {
    if ((complaintFilter.getControlNumber() != null) && !(complaintFilter.getControlNumber().equals(""))) {
      whereClause.append(" AND COMPLAINT.COMPLAINT_ID = '").append(complaintFilter.getControlNumber().trim())
          .append("' ");
    }
    if ((complaintFilter.getCreatedDate() != null) && !(complaintFilter.getCreatedDate().equals(""))) {
      whereClause.append(" AND COMPLAINT.REPORT_DATE = TO_DATE('")
          .append(getDateFormat(new Date(new java.util.Date(complaintFilter.getCreatedDate()).getTime())))
          .append("', 'MM/DD/YYYY') ");
    }
    if ((complaintFilter.getInitiatedBy() != null) && !(complaintFilter.getInitiatedBy().equals(""))) {
      whereClause.append(" AND UPPER(COMPLAINT.REPORT_INITIATOR) lIKE UPPER('")
          .append(complaintFilter.getInitiatedBy().trim()).append("%') ");
    }
    if ((complaintFilter.getClaimNumber() != null) && !(complaintFilter.getClaimNumber().equals(""))) {
      whereClause.append(" AND UPPER(COMPLAINT.CLAIM_NUMBER) LIKE UPPER('")
          .append(complaintFilter.getClaimNumber().trim()).append("%') ");
    }
    if ((complaintFilter.getReportingLocation() != null) && (complaintFilter.getReportingLocation().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.REPORTING_LOCATION_CODE IN ",
          complaintFilter.getReportingLocation()));
    }
    if ((complaintFilter.getResponsibleLocation() != null) &&
        (complaintFilter.getResponsibleLocation().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.RESPONSIBLE_PLANT_CODE IN ",
          complaintFilter.getResponsibleLocation()));
    }
    if ((complaintFilter.getStatus() != null) && (complaintFilter.getStatus().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.STATUS_ID IN ", complaintFilter.getStatus()));
    }
    if ((complaintFilter.getRegion() != null) && (complaintFilter.getRegion().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.REGION_ID IN ", complaintFilter.getRegion()));
    }
    if ((complaintFilter.getCrop() != null) && (complaintFilter.getCrop().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.CROP_ID IN ", complaintFilter.getCrop()));
    }
    if ((complaintFilter.getSalesYear() != null) && (complaintFilter.getSalesYear().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.SALES_YR_ID IN ", complaintFilter.getSalesYear()));
    }
    if ((complaintFilter.getQualityIssue() != null) && (complaintFilter.getQualityIssue().length > 0)) {
      whereClause.append(getSelectedFields(" AND COMPLAINT.COMPLAINT_QUALITY_ISSUE_ID IN ",
          complaintFilter.getQualityIssue()));
    }
    //TODO:Place holder to add Audit Areas in Future when the user selects from the Complaint Report Filter
    whereClause.append(" AND (COMPLAINT.COMPLAINT_ID = M_AUDIT_AREAS.AUDIT_ID(+) ) " +
        " AND (M_AUDIT_AREAS.AUDIT_AREA_ID = M_AUDIT_AREAS_REF.AREA_ID(+)) " +
        " AND (COMPLAINT.MATERIAL_GRP_ID = COMPLAINT_MATERIAL_GROUP.COMPLAINT_MATERIAL_GROUP_ID(+) ) " +
        " AND (COMPLAINT.MATERIAL_GROUP_PRICING_ID = COMPLAINT_MATERIAL_PRICING_GRP.COMPLAINT_MPRG_ID(+) ) " +
        " AND (COMPLAINT.INITIAL_ASSESMENT = COMPLAINT_ASSESMENT.ASSESMENT_ID(+) ) " +
        " AND (COMPLAINT.LITIGATION_CATEGORY_ID = COMPLAINT_LITIGATION_CATEGORY.LITIGATION_ID(+) ) " +
        " AND ('C' = M_AUDIT_AREAS.AUDIT_AREA_SOURCE (+) ) ");
    if (businessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
      //Initial Assesment
      if ((complaintFilter.getInitialAssesmentCode() != null) &&
          (complaintFilter.getInitialAssesmentCode().length > 0)) {
        //whereClause.append(" AND COMPLAINT.INITIAL_ASSESMENT = COMPLAINT_ASSESMENT.ASSESMENT_ID  ");
        whereClause.append(getSelectedFields(" AND COMPLAINT_ASSESMENT.ASSESMENT_ID IN ",
            complaintFilter.getInitialAssesmentCode()));
      }
      //Complaint Litigation Category
      if ((complaintFilter.getComplaintLitigationCategoryCode() != null) &&
          (complaintFilter.getComplaintLitigationCategoryCode().length > 0)) {
        // whereClause.append(" AND COMPLAINT.LITIGATION_CATEGORY_ID = COMPLAINT_LITIGATION_CATEGORY.LITIGATION_ID ");
        whereClause.append(getSelectedFields(" AND COMPLAINT_LITIGATION_CATEGORY.LITIGATION_ID IN ",
            complaintFilter.getComplaintLitigationCategoryCode()));
      }
      //Material Group Selected
      if (complaintFilter.getComplaintMaterialGroup() != null &&
          complaintFilter.getComplaintMaterialGroup().length > 0) {
        whereClause.append(getSelectedFields(" AND COMPLAINT_MATERIAL_GROUP.COMPLAINT_MATERIAL_GROUP_ID IN ",
            complaintFilter.getComplaintMaterialGroup()));
      }
      //Material Pricing Group Selected
      if (complaintFilter.getComplaintMaterialPricingGroup() != null &&
          complaintFilter.getComplaintMaterialPricingGroup().length > 0) {
        whereClause.append(getSelectedFields(" AND COMPLAINT_MATERIAL_PRICING_GRP.COMPLAINT_MPRG_ID IN ",
            complaintFilter.getComplaintMaterialPricingGroup()));
      }

      //Sales Office Selected
      if (complaintFilter.getSalesOffice() != null && complaintFilter.getSalesOffice().length > 0) {
        whereClause.append(getSelectedFields(" AND COMPLAINT.SALES_OFFICE_ID IN ",
            complaintFilter.getSalesOffice()));
      }
    }
    whereClause.append(" AND COMPLAINT.BUSINESS_ID = ").append(businessId);
    //Fetch the Audit Areas for all complaints
    if (batchPatternEntered(complaintFilter)) {
      whereClause.append(
          " AND UPPER(VARIETY_BATCH.BATCH) LIKE UPPER('%" + complaintFilter.getBatch().trim() + "%') ");
    }
    if (!StringUtils.isNullOrEmpty(complaintFilter.getVariety())) {
      whereClause
          .append(" AND UPPER(VARIETY_BATCH.VARIETY) LIKE UPPER('%" + complaintFilter.getVariety().trim() + "%')");
    }
    if ((complaintFilter.getComplaintBusinessId() != null) && !(complaintFilter.getComplaintBusinessId().equals(""))) {
      whereClause.append(" AND COMPLAINT.COMPLAINT_BUSINESS_ID = '")
          .append(complaintFilter.getComplaintBusinessId().trim()).append("' ");
    }

    if ((complaintFilter.getFeedbackCategoryId() != null) && !(complaintFilter.getFeedbackCategoryId().equals(""))) {
      whereClause.append(" AND COMPLAINT.COMPLAINT_CATEGORY_ID = '")
          .append(complaintFilter.getFeedbackCategoryId().trim()).append("' ");
    }

    if ((complaintFilter.getComplaintTypeId() != null) && !(complaintFilter.getComplaintTypeId().equals(""))) {
      whereClause.append(" AND COMPLAINT.COMPLAINT_TYPE_ID = '").append(complaintFilter.getComplaintTypeId().trim())
          .append("' ");
    }
    if ((complaintFilter.getFunctionId() != null) && !(complaintFilter.getFunctionId().equals(""))) {
      whereClause.append(" AND COMPLAINT.LOCATION_FUNCTION_ID = '").append(complaintFilter.getFunctionId().trim())
          .append("' ");
    }
    //If the Claim Value Final is selected
    if (complaintFilter.isClaimAmountFinal()) {
      whereClause
          .append(" AND COMPLAINT.CLAIM_AMOUNT IS NOT NULL ");
    }
    //Complaint Issues
    if (!complaintFilter.isNonconformanceCategoryIdListEmpty()) {
      whereClause.append(" AND COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID IN ( ")
          .append(buildInClause(complaintFilter.getNonconformanceCategoryIdList())).append(" )");
    }
    //Audit Areas
    if (!complaintFilter.isFunctionalAreaIdListEmpty()) {
      whereClause.append(" AND M_AUDIT_AREAS_REF.AREA_ID IN ( ")
          .append(buildInClause(complaintFilter.getFunctionalAreaIdList())).append(" )");
    }
  }

  /**
   * Private method to parse the selected Complaint Issue IDs
   */
  private String buildInClause(List<Integer> idList) {
    return MCASUtil.buildInClause(idList);
  }

  private boolean batchPatternEntered(ComplaintFilter complaintFilter) {
    return !StringUtils.isNullOrEmpty(complaintFilter.getBatch());
  }

  /**
   * This method just makes a string out of selected fields like ('1744', '1745',...)
   */
  private StringBuffer getSelectedFields(String query, String[] strArray) {

    int size = strArray.length;

    StringBuffer fieldClause = new StringBuffer();
    fieldClause.append("");

    //**To remove the null elements...
    for (int i = 0; i < size; i++) {

      if (strArray[i].equals("") || strArray[i].equals("0")) {
        size--;
      }
    }

    if (size == 0) {
      return fieldClause;
    }

    fieldClause.append(query).append("(");

    for (int i = 0; i < strArray.length; i++) {

      //**Skip null elements...
      if (strArray[i].equals("") || strArray[i].equals("0")) {
        continue;
      }

      fieldClause.append("'").append(strArray[i].trim()).append("'");

      if (i < strArray.length - 1) {
        fieldClause.append(",");
      }
    }

    fieldClause.append(")");

    return fieldClause;
  }

  private int insertComplaint_Grower(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int paramIndx = 1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_GROWER_SQL);
        ps.setLong(13, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_GROWER_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }

      ps.setString(paramIndx, c.getGrower_name());
      ps.setString(paramIndx + 1, c.getGrower_address());
      ps.setString(paramIndx + 2, c.getGrower_city());
      if (!(c.getGrower_state() == null) && !(c.getGrower_state().equals(""))) {
        ps.setInt(paramIndx + 3, Integer.parseInt(c.getGrower_state()));
      } else {
        ps.setNull(paramIndx + 3, Types.INTEGER);
      }
      ps.setString(paramIndx + 4, c.getGrower_phone());
      ps.setString(paramIndx + 5, c.getGrower_ba_id());
      if (StringUtils.isNullOrEmpty(c.getGrowerLatitude())) {
        ps.setNull(paramIndx + 6, Types.INTEGER);
      } else {
        ps.setDouble(paramIndx + 6, Double.parseDouble(c.getGrowerLatitude()));
      }
      if (StringUtils.isNullOrEmpty(c.getGrowerLongitude())) {
        ps.setNull(paramIndx + 7, Types.INTEGER);
      } else {
        ps.setDouble(paramIndx + 7, Double.parseDouble(c.getGrowerLongitude()));
      }
      ps.setString(paramIndx + 8, "APPLICATION");
      ps.setString(paramIndx + 9, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 11, new Date(new java.util.Date().getTime()));
      return ps.executeUpdate();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private int insertComplaint_Batch(Complaint c, Connection conn) throws DAOException {
        long complaint_id = Long.parseLong(c.getComplaint_id());
        PreparedStatement ps = null;
        try {
            int rows = 0;
            for (VarietyBatch varietyBatch : c.getVarietyBatchList()) {
                rows+=insertComplaint_SingleBatch(complaint_id,varietyBatch,conn);
            }
            return rows;
        } finally {
            closeDBResources(null, ps, null);
        }
    }


    private int insertComplaint_SingleBatch(long complaint_id,VarietyBatch varietyBatch, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        try {
            int rows = 0;
            if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_BATCH_SQL);
                    ps.setLong(1, complaint_id);
                    ps.setString(2, varietyBatch.getVarietyDesc());
                    ps.setString(3, varietyBatch.getBatchNumber());
                    setFloatIfNotNull(ps, 4, varietyBatch.getQuantityAffected());
                    setLongIfNotNull(ps, 5, varietyBatch.getAcresAffected());
                    setLongIfNotNull(ps, 6, varietyBatch.getUomId());
                    setLongIfNotNull(ps, 7, varietyBatch.getSeedSizeId());
                    setLongIfNotNull(ps, 8, varietyBatch.getIlType());
                    setLongIfNotNull(ps, 9, varietyBatch.getBatchCropYrId());
                    ps.setString(10, varietyBatch.getLotNumber());
                ps.setString(11, varietyBatch.getCountryOrigin());
                ps.setString(12, varietyBatch.getTreatmentType());

                    rows += ps.executeUpdate();
                } else if (StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_BATCH_NULL_VARIETY_SQL);
                    ps.setLong(1, complaint_id);
                    ps.setString(2, varietyBatch.getBatchNumber());
                    setFloatIfNotNull(ps, 3, varietyBatch.getQuantityAffected());
                    setLongIfNotNull(ps, 4, varietyBatch.getAcresAffected());
                    setLongIfNotNull(ps, 5, varietyBatch.getUomId());
                    setLongIfNotNull(ps, 6, varietyBatch.getSeedSizeId());
                    setLongIfNotNull(ps, 7, varietyBatch.getIlType());
                    setLongIfNotNull(ps, 8, varietyBatch.getBatchCropYrId());
                ps.setString(9, varietyBatch.getLotNumber());
                ps.setString(10, varietyBatch.getCountryOrigin());
                ps.setString(11, varietyBatch.getTreatmentType());

                    rows += ps.executeUpdate();
                } else if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_BATCH_NULL_BATCH_SQL);
                    ps.setLong(1, complaint_id);
                    ps.setString(2, varietyBatch.getVarietyDesc());
                    setFloatIfNotNull(ps, 3, varietyBatch.getQuantityAffected());
                    setLongIfNotNull(ps, 4, varietyBatch.getAcresAffected());
                    setLongIfNotNull(ps, 5, varietyBatch.getUomId());
                    setLongIfNotNull(ps, 6, varietyBatch.getSeedSizeId());
                    setLongIfNotNull(ps, 7, varietyBatch.getIlType());
                    setLongIfNotNull(ps, 8, varietyBatch.getBatchCropYrId());
                ps.setString(9, varietyBatch.getLotNumber());
                ps.setString(10, varietyBatch.getCountryOrigin());
                ps.setString(11, varietyBatch.getTreatmentType());

                    rows += ps.executeUpdate();
                }

            return rows;
        } catch (SQLException e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }

    private int updateComplaint_Batch(Complaint c, Connection conn) throws DAOException {
        long complaint_id = Long.parseLong(c.getComplaint_id());
        PreparedStatement ps = null;
        String query = null;
        try {
            int rows = 0;


            for (VarietyBatch varietyBatch : c.getVarietyBatchList()) {
                int pos = 2;
                 int posQuan = 3;
                int posAcres = 4;
                int posUom = 5;
                int posSeedSize = 5;
                int posIlType = 5;
                int posBatchCropYear = 5;
                int posLotNumber = 5;
                int posCountryOrigin = 5;
                int posTreatmentType = 5;

                if(!StringUtils.isNullOrEmpty(varietyBatch.getVarietyActiveFlag())&& varietyBatch.getVarietyActiveFlag().equalsIgnoreCase("N")){
                   deleteVarietyBatch(varietyBatch.getComplaintBatchSeq().toString(),conn);
                   continue;
                }

                if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                     logger.info("updating variety batch "+complaint_id+", batch #="+varietyBatch.getBatchNumber()+", variety descrption:="+varietyBatch.getVarietyDesc());
                    query =  ComplaintDAOSQLConstants.UPDATE_COMPLAINT_BATCH_PART;

                     if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        query = query + "," + ComplaintDAOSQLConstants.UPDATE_QTY_AFFECTED_SQL;
                       pos++;
                       posQuan = pos;
                     }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                        query = query + "," + ComplaintDAOSQLConstants.UPDATE_ACRES_AFFECTED_SQL;
                       pos++;
                       posAcres = pos;
                     }

                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_UOM_ID_SQL;
                       pos++;
                       posUom = pos;
                    }

                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_SEED_SIZE_ID_SQL;
                       pos++;
                       posSeedSize = pos;
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_IL_TYPE_SQL;
                       pos++;
                       posIlType = pos;
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_CROP_YR_SQL;
                       pos++;
                       posBatchCropYear = pos;
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_LOT_NUMBER_SQL;
                       pos++;
                       posLotNumber = pos;
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_COUNTRY_ORIGIN_SQL;
                       pos++;
                       posCountryOrigin = pos;
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_TREATMENT_TYPE_SQL ;
                       pos++;
                       posTreatmentType = pos;
                    }

                    query = query + ComplaintDAOSQLConstants.UPDATE_WHERE_CLASE_SQL;
                    ps = conn.prepareStatement(query);
                    logger.info("executing query: "+query);


                    if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        setFloatIfNotNull(ps, posQuan, varietyBatch.getQuantityAffected());

                     }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                        setLongIfNotNull(ps, posAcres, varietyBatch.getAcresAffected());
                     }

                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                        ps.setLong(posUom, varietyBatch.getUomId());
                    }
                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                        ps.setLong(posSeedSize, varietyBatch.getSeedSizeId());
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                        ps.setLong(posIlType, varietyBatch.getIlType());
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                        ps.setLong(posBatchCropYear, varietyBatch.getBatchCropYrId());
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                        ps.setString(posLotNumber, varietyBatch.getLotNumber());
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                        ps.setString(posCountryOrigin, varietyBatch.getCountryOrigin());
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                        ps.setString(posTreatmentType, varietyBatch.getTreatmentType());
                    }

                    ps.setString(1, varietyBatch.getVarietyDesc());
                    if ( StringUtils.isNullOrEmpty(varietyBatch.getBatchNumberToBeUpdated() )){
                       ps.setString(2, varietyBatch.getBatchNumber());
                    }else{
                       ps.setString(2, varietyBatch.getBatchNumberToBeUpdated());
                    }
                    //setFloatIfNotNull(ps, 3, varietyBatch.getQuantityAffected());
                    //setLongIfNotNull(ps, 4, varietyBatch.getAcresAffected());

                    ps.setLong(++pos, complaint_id);
                    int row=0;
                    if(!(varietyBatch.getComplaintBatchSeq()==null)){
                    ps.setLong(++pos, varietyBatch.getComplaintBatchSeq());
                    //ps.setString(++pos, varietyBatch.getVarietyDesc());
                    //ps.setString(++pos, varietyBatch.getBatchNumber());
                    row=ps.executeUpdate();
                    rows +=row;
                    }
                    if(row==0){
                       rows+=insertComplaint_SingleBatch(complaint_id,varietyBatch, conn);
                    }
                } else if (StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    pos = 1;
                    //TODO -- this could result in overrides within a complaint, so has to throw an error..
                    //silently log issue since multiple records are being updated..
                    //logger.error("variety description and batch are required to update/insert records "+complaint_id+", batch #="+varietyBatch.getBatchNumber());
                    query =  ComplaintDAOSQLConstants.UPDATE_COMPLAINT_BATCH_NULL_PART;

                    if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        query = query + "," + ComplaintDAOSQLConstants.UPDATE_QTY_AFFECTED_SQL;
                                           pos++;
                                           posQuan = pos;
                                         }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                                            query = query + "," + ComplaintDAOSQLConstants.UPDATE_ACRES_AFFECTED_SQL;
                                           pos++;
                                           posAcres = pos;
                                         }


                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_UOM_ID_SQL;
                       pos++;
                       posUom = pos;
                    }

                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_SEED_SIZE_ID_SQL;
                       pos++;
                       posSeedSize = pos;
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_IL_TYPE_SQL;
                       pos++;
                       posIlType = pos;
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_CROP_YR_SQL;
                       pos++;
                       posBatchCropYear = pos;
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_LOT_NUMBER_SQL;
                       pos++;
                       posLotNumber = pos;
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_COUNTRY_ORIGIN_SQL;
                       pos++;
                       posCountryOrigin = pos;
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_TREATMENT_TYPE_SQL ;
                       pos++;
                       posTreatmentType = pos;
                    }

                    query = query + ComplaintDAOSQLConstants.UPDATE_WHERE_CLAUSE_FOR_NULL_VARIETY_SQL ;

                    logger.info("executing query: "+query);

                    ps = conn.prepareStatement(query);

                    if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        setFloatIfNotNull(ps, posQuan, varietyBatch.getQuantityAffected());

                     }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                        setLongIfNotNull(ps, posAcres, varietyBatch.getAcresAffected());
                     }

                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                        ps.setLong(posUom, varietyBatch.getUomId());
                    }
                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                        ps.setLong(posSeedSize, varietyBatch.getSeedSizeId());
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                       ps.setLong(posIlType, varietyBatch.getIlType());
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                       ps.setLong(posBatchCropYear, varietyBatch.getBatchCropYrId());
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                        ps.setString(posLotNumber, varietyBatch.getLotNumber());
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                        ps.setString(posCountryOrigin, varietyBatch.getCountryOrigin());
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                        ps.setString(posTreatmentType, varietyBatch.getTreatmentType());
                    }

                    ps.setString(1, varietyBatch.getBatchNumber());
                    //setFloatIfNotNull(ps, 2, varietyBatch.getQuantityAffected());
                    //setLongIfNotNull(ps, 3, varietyBatch.getAcresAffected());
                    ps.setLong(++pos, complaint_id);
                    int row=0;
                    if(!(varietyBatch.getComplaintBatchSeq()==null)){
                    ps.setLong(++pos, varietyBatch.getComplaintBatchSeq());
                    //ps.setString(++pos, varietyBatch.getBatchNumber());

                    row=ps.executeUpdate();
                    rows +=row;
                    }
                    if(row==0){
                        rows+=insertComplaint_SingleBatch(complaint_id,varietyBatch, conn);

                    }
                } else if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    pos = 1;
                    //logger.info("variety description and batch are required to update/insert records  "+complaint_id
                    //        +", batch using batch to be updated #="+varietyBatch.getBatchNumberToBeUpdated()+" , variety description=" +varietyBatch.getVarietyDesc()
                    //);
                    query =  ComplaintDAOSQLConstants.UPDATE_VARIETY_BATCH_BATCH_NULL_PART;


                    if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        query = query + "," + ComplaintDAOSQLConstants.UPDATE_QTY_AFFECTED_SQL;
                                           pos++;
                                           posQuan = pos;
                                         }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                                            query = query + "," + ComplaintDAOSQLConstants.UPDATE_ACRES_AFFECTED_SQL;
                                           pos++;
                                           posAcres = pos;
                                         }

                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_UOM_ID_SQL;
                       pos++;
                       posUom = pos;
                    }

                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_SEED_SIZE_ID_SQL;
                       pos++;
                       posSeedSize = pos;
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_IL_TYPE_SQL;
                       pos++;
                       posIlType = pos;
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_CROP_YR_SQL;
                       pos++;
                       posBatchCropYear = pos;
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_LOT_NUMBER_SQL ;
                       pos++;
                       posLotNumber = pos;
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_COUNTRY_ORIGIN_SQL ;
                       pos++;
                       posCountryOrigin = pos;
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                       query = query + "," + ComplaintDAOSQLConstants.UPDATE_BATCH_TREATMENT_TYPE_SQL  ;
                       pos++;
                       posTreatmentType = pos;
                    }

                    query = query + ComplaintDAOSQLConstants.UPDATE_WHERE_CLASE_SQL ;

                    logger.info("executing query: "+query);

                    ps = conn.prepareStatement(query);

                    if(varietyBatch.getQuantityAffected()!=null&&!(varietyBatch.getQuantityAffected().toString().equals("0") )){
                        setFloatIfNotNull(ps, posQuan, varietyBatch.getQuantityAffected());

                     }

                    if(varietyBatch.getAcresAffected()!=null&&!(varietyBatch.getAcresAffected().toString().equals("0") )){
                        setLongIfNotNull(ps, posAcres, varietyBatch.getAcresAffected());
                     }

                    if ( varietyBatch.getUomId() != null && !(varietyBatch.getUomId().toString().equals("0") ) ){
                        ps.setLong(posUom, varietyBatch.getUomId());
                    }
                    if ( varietyBatch.getSeedSizeId() != null && !(varietyBatch.getSeedSizeId().toString().equals("0") ) ){
                        ps.setLong(posSeedSize, varietyBatch.getSeedSizeId());
                    }

                    if ( varietyBatch.getIlType() != null && !(varietyBatch.getIlType().toString().equals("0") ) ){
                       ps.setLong(posIlType, varietyBatch.getIlType());
                    }

                    if ( varietyBatch.getBatchCropYrId() != null && !(varietyBatch.getBatchCropYrId().toString().equals("0") ) ){
                       ps.setLong(posBatchCropYear, varietyBatch.getBatchCropYrId());
                    }

                    if ( varietyBatch.getLotNumber() != null && !(varietyBatch.getLotNumber().equals("") ) ){
                       ps.setString(posLotNumber, varietyBatch.getLotNumber());
                    }

                    if ( varietyBatch.getCountryOrigin() != null && !(varietyBatch.getCountryOrigin().equals("") ) ){
                       ps.setString(posCountryOrigin, varietyBatch.getCountryOrigin());
                    }

                    if ( varietyBatch.getTreatmentType() != null && !(varietyBatch.getTreatmentType().equals("") ) ){
                       ps.setString(posTreatmentType, varietyBatch.getTreatmentType());
                    }

                    ps.setString(1, varietyBatch.getVarietyDesc());
                    //ps.setString(2, varietyBatch.getBatchNumberToBeUpdated());
                    //setFloatIfNotNull(ps, 2, varietyBatch.getQuantityAffected());
                    //setLongIfNotNull(ps, 3, varietyBatch.getAcresAffected());
                    ps.setLong(++pos, complaint_id);
                    int row=0;
                    if(!(varietyBatch.getComplaintBatchSeq()==null)){
                        ps.setLong(++pos, varietyBatch.getComplaintBatchSeq());
                        //ps.setString(++pos, varietyBatch.getVarietyDesc());
                    //ps.setString(9, varietyBatch.getBatchNumber());

                        row=ps.executeUpdate();
                        rows +=row;
                    }
                    if(row==0){
                       rows+=insertComplaint_SingleBatch(complaint_id,varietyBatch, conn);
                    }
                }
            }
            return rows;
        } catch (SQLException e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }




  private void setLongIfNotNull(PreparedStatement ps, int parameterIndex, Long value) throws SQLException {
    if (value == null || (value == 0)) {
      ps.setNull(parameterIndex, Types.INTEGER);
    } else {
      ps.setLong(parameterIndex, value);
    }
  }

  private void setFloatIfNotNull(PreparedStatement ps, int parameterIndex, Float value) throws SQLException {
        if (value == null || (value == 0)) {
            ps.setNull(parameterIndex, Types.FLOAT);
        } else {
            ps.setFloat(parameterIndex, value);
        }
    }

  private int insertComplaint_Dealer(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int rows = 0;
    int paramIndx = 1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_DEALER_SQL);
        ps.setLong(13, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_DEALER_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      ps.setString(paramIndx, c.getDealer_name());
      ps.setString(paramIndx + 1, c.getDealer_address());
      ps.setString(paramIndx + 2, c.getDealer_city());
      if (StringUtils.isNullOrEmpty(c.getDealer_state())) {
        ps.setNull(paramIndx + 3, Types.INTEGER);
      } else {
        ps.setInt(paramIndx + 3, Integer.parseInt(c.getDealer_state()));
      }
      ps.setString(paramIndx + 4, c.getDealer_phone());
      ps.setString(paramIndx + 5, c.getDealer_ba_id());
      if (StringUtils.isNullOrEmpty(c.getDealerLatitude())) {
        ps.setNull(paramIndx + 6, Types.INTEGER);
      } else {
        ps.setDouble(paramIndx + 6, Double.parseDouble(c.getDealerLatitude()));
      }
      if (StringUtils.isNullOrEmpty(c.getDealerLongitude())) {
        ps.setNull(paramIndx + 7, Types.INTEGER);
      } else {
        ps.setDouble(paramIndx + 7, Double.parseDouble(c.getDealerLongitude()));
      }
      ps.setString(paramIndx + 8, "APPLICATION");
      ps.setString(paramIndx + 9, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 11, new Date(new java.util.Date().getTime()));
      rows = ps.executeUpdate();
      return rows;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private int insertComplaint_Disease(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int rows = 0;
    int paramIndx = 1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_DISEASE_SQL);
        ps.setLong(12, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_DISEASE_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      ps.setString(paramIndx, c.getDisease_observed());
      ps.setString(paramIndx + 1, c.getHerbicide_type_current());
      ps.setString(paramIndx + 2, c.getHerbicide_rate_current());
      ps.setString(paramIndx + 3, c.getHerbicide_timming_current());
      ps.setString(paramIndx + 4, c.getHerbicide_type_prev());
      ps.setString(paramIndx + 5, c.getHerbicide_rate_prev());
      ps.setString(paramIndx + 6, c.getHerbicide_timming_prev());
      ps.setString(paramIndx + 7, "APPLICATION");
      ps.setString(paramIndx + 8, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
      rows = ps.executeUpdate();
      return rows;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }


  private void loadComplaintOtherInfo(Complaint c, Connection conn) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      ps = conn.prepareStatement(ComplaintDAOSQLConstants.SELECT_COMPLAINT_OTHER_INFO_SQL);
      ps.setString(1, c.getComplaint_id());
      rs = ps.executeQuery();
      if (rs.next()) {
        c.setFeedbackCategoryInfo(rs.getString("category_other_info"));
        c.setResponsibleLocationInfo(rs.getString("responsible_loc_other_info"));
        c.setCustomerLocationInfo(rs.getString("customer_loc_other_info"));
      }

    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private int saveComplaintOtherInfo(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int updateResults = -1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.SELECT_COMPLAINT_OTHER_INFO_SQL);
        ps.setLong(1, Long.parseLong(c.getComplaint_id()));
        ResultSet resultSet = ps.executeQuery();
        if (resultSet.next()) {
          closeDBResources(null, ps, resultSet);
          ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_OTHER_INFO_SQL);
          ps.setString(1, c.getFeedbackCategoryInfo());
          ps.setString(2, c.getResponsibleLocationInfo());
          ps.setString(3, c.getCustomerLocationInfo());
          ps.setLong(4, Long.parseLong(c.getComplaint_id()));
          updateResults = ps.executeUpdate();
        }
      }
      if (updateResults == -1) {
        updateResults = 0;
        if (c.isOtherInfoEntered()) {
          ps = conn.prepareStatement(ComplaintDAOSQLConstants.INSERT_COMPLAINT_OTHER_INFO_SQL);
          ps.setLong(1, Long.parseLong(c.getComplaint_id()));
          ps.setString(2, c.getFeedbackCategoryInfo());
          ps.setString(3, c.getResponsibleLocationInfo());
          ps.setString(4, c.getCustomerLocationInfo());
          updateResults = ps.executeUpdate();
        }
      }
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
    return updateResults;
  }

  private int insertComplaint_Documentation(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      int paramIndx = 1;
      if (isUpdate && complaintDocumentationExists(c, conn)) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_DOCUMENTATION_SQL);
        ps.setLong(9, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_DOCUMENTATION_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      ps.setString(paramIndx, c.getProblem_description());
      ps.setString(paramIndx + 1, c.getContainment_actions());
      ps.setString(paramIndx + 2, c.getRoot_cause());
      ps.setString(paramIndx + 3, c.getLong_term_corrective_action());
      ps.setString(paramIndx + 4, "APPLICATION");
      ps.setString(paramIndx + 5, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 6, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 7, new Date(new java.util.Date().getTime()));
      return ps.executeUpdate();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private int insertComplaintResponsibility(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      int paramIndx = 1;
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_RESPONSIBILITY_SQL);
        ps.setLong(15, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_RESPONSIBILITY_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      setParameters(ps, c, isUpdate);
      return ps.executeUpdate();
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private void setParameters(PreparedStatement ps, Complaint c, boolean isUpdate) throws SQLException {
    int paramIndex = 1;
    if (!isUpdate) {
      paramIndex++;
    }
    ps.setString(paramIndex++, c.getProblem_person());
    setDateParameterInQuery(paramIndex++, ps, c.getProblem_date());
    ps.setString(paramIndex++, c.getContainment_person());
    setDateParameterInQuery(paramIndex++, ps, c.getContainment_date());
    ps.setString(paramIndex++, c.getRootCausePerson());
    setDateParameterInQuery(paramIndex++, ps, c.getRootCauseDate());
    ps.setString(paramIndex++, c.getLongTermPerson());
    setDateParameterInQuery(paramIndex++, ps, c.getLongTermDate());
    ps.setString(paramIndex++, "APPLICATION");
    ps.setString(paramIndex++, "COMPLAINT ENTRY");
    ps.setDate(paramIndex++, new Date(new java.util.Date().getTime()));
    ps.setDate(paramIndex++, new Date(new java.util.Date().getTime()));
    ps.setInt(paramIndex++, c.getDispositionId());
    ps.setInt(paramIndex++, c.getDispositionIdForTeamLead());
  }

  private void setDateParameterInQuery(int parameterIndex, PreparedStatement ps, String date) throws SQLException {
    if (!StringUtils.isNullOrEmpty(date)) {
      ps.setDate(parameterIndex, new Date(new java.util.Date(date).getTime()));
    } else {
      ps.setDate(parameterIndex, null);
    }
  }

  private boolean complaintDocumentationExists(Complaint c, Connection conn) throws SQLException {
    PreparedStatement statement = null;
    ResultSet result = null;

    try {
      statement = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_DOCUMENTATION_EXISTS);
      statement.setString(1, c.getComplaint_id());
      result = statement.executeQuery();
      String theString = "";
      if (result.next()) {
        theString = result.getString(1);
      }
      cleanup(result, statement);
      return "1".equals(theString);
    } finally {
      this.closeDBResources(null, statement, result);
    }
  }

  private void cleanup(ResultSet result, PreparedStatement statement) throws SQLException {
    result.close();
    statement.close();
  }

  private int insertComplaint_Insect(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int rows = 0;
    int paramIndx = 1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_INSECT_SQL);
        ps.setLong(12, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_INSECT_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      ps.setString(paramIndx, c.getInsects_observed());
      ps.setString(paramIndx + 1, c.getInsecticide_type_current());
      ps.setString(paramIndx + 2, c.getInsecticide_rate_current());
      ps.setString(paramIndx + 3, c.getInsecticide_timming_current());
      ps.setString(paramIndx + 4, c.getInsecticide_type_prev());
      ps.setString(paramIndx + 5, c.getInsecticide_rate_prev());
      ps.setString(paramIndx + 6, c.getInsecticide_timming_prev());
      ps.setString(paramIndx + 7, "APPLICATION");
      ps.setString(paramIndx + 8, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 9, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 10, new Date(new java.util.Date().getTime()));
      rows = ps.executeUpdate();
      return rows;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private int insertComplaint_Planting(Complaint c, Connection conn, boolean isUpdate) throws DAOException {
    PreparedStatement ps = null;
    ResultSet rs = null;
    int rows = 0;
    int paramIndx = 1;
    try {
      if (isUpdate) {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.UPDATE_COMPLAINT_PLANTING_SQL);
        ps.setLong(14, Long.parseLong(c.getComplaint_id()));
      } else {
        ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_PLANTING_SQL);
        ps.setLong(paramIndx, Long.parseLong(c.getComplaint_id()));
        paramIndx++;
      }
      if (!(c.getTotal_acres() == null) && !(c.getTotal_acres().equals(""))) {
        ps.setFloat(paramIndx, Float.parseFloat(c.getTotal_acres()));
      } else {
        ps.setNull(paramIndx, Types.FLOAT);
      }
      if (!(c.getAffected_areas() == null) && !(c.getAffected_areas().equals(""))) {
        ps.setFloat(paramIndx + 1, Float.parseFloat(c.getAffected_areas()));
      } else {
        ps.setNull(paramIndx + 1, Types.FLOAT);
      }
      ps.setString(paramIndx + 2, c.getTechnology());
      if (!(c.getPlanting_date() == null) && !(c.getPlanting_date().equals(""))) {
        ps.setDate(paramIndx + 3, new Date(new java.util.Date(c.getPlanting_date()).getTime()));
      } else {
        ps.setDate(paramIndx + 3, null);
      }
      ps.setString(paramIndx + 4, c.getPlanter_type());
      if (!(c.getPlanter_depth() == null) && !(c.getPlanter_depth().equals(""))) {
        ps.setFloat(paramIndx + 5, Float.parseFloat(c.getPlanter_depth()));
      } else {
        ps.setNull(paramIndx + 5, Types.INTEGER);
      }
      if (!(c.getPopulation_planted() == null) && !(c.getPopulation_planted().equals(""))) {
        ps.setFloat(paramIndx + 6, Float.parseFloat(c.getPopulation_planted()));
      } else {
        ps.setNull(paramIndx + 6, Types.FLOAT);
      }
      if (!(c.getPopulation_observed() == null) && !(c.getPopulation_observed().equals(""))) {
        ps.setFloat(paramIndx + 7, Float.parseFloat(c.getPopulation_observed()));
      } else {
        ps.setNull(paramIndx + 7, Types.FLOAT);
      }
      ps.setString(paramIndx + 8, c.getTillage());
      ps.setString(paramIndx + 9, "APPLICATION");
      ps.setString(paramIndx + 10, "COMPLAINT ENTRY");
      ps.setDate(paramIndx + 11, new Date(new java.util.Date().getTime()));
      ps.setDate(paramIndx + 12, new Date(new java.util.Date().getTime()));
      rows = ps.executeUpdate();
      return rows;
    } catch (SQLException e) {
      throw new DAOException(e);
    } finally {
      closeDBResources(null, ps, rs);
    }
  }

  private void addIfNotNullOrEmpty(Collection<String> coll, String st) {
    if (!StringUtils.isNullOrEmpty(st)) {
      coll.add(st);
    }
  }

  private String getDateFormat(java.util.Date date) {
    try {
      return sdf.format(date);
    } catch (RuntimeException e) {
//      MCASLogUtil.logError(e.getMessage(), e);
      return "";
    }
  }

  private void closeResources(PreparedStatement complaintDupStmt, PreparedStatement complaintInsectDupStmt,
                              PreparedStatement complaintPlantingDupStmt, PreparedStatement complaintDiseaseDupStmt,
                              PreparedStatement complaintBatchDupStmt,
                              PreparedStatement complaintDealerDupStmt, PreparedStatement complaintDocumentationDupStmt,
                              PreparedStatement complaintAttachmentDupStmt,
                              PreparedStatement complaintGrowerDupStmt,
                              PreparedStatement complaintInvestigationDupStmt) throws SQLException {

    closePreparedStatement(complaintDupStmt);
    closePreparedStatement(complaintInsectDupStmt);
    closePreparedStatement(complaintPlantingDupStmt);
    closePreparedStatement(complaintDiseaseDupStmt);
    closePreparedStatement(complaintBatchDupStmt);
    closePreparedStatement(complaintDealerDupStmt);
    closePreparedStatement(complaintDocumentationDupStmt);
    closePreparedStatement(complaintAttachmentDupStmt);
    closePreparedStatement(complaintGrowerDupStmt);
    closePreparedStatement(complaintInvestigationDupStmt);
  }

  private void closePreparedStatement(Statement stmt) throws SQLException {
    if (stmt != null) {
      stmt.close();
    }
  }

  private void executeInsertBatches(Statement complaintDupStmt, Statement complaintInsectDupStmt,
                                    Statement complaintPlantingDupStmt, Statement complaintDiseaseDupStmt,
                                    Statement complaintBatchDupStmt,
                                    Statement complaintDealerDupStmt, Statement complaintDocumentationDupStmt,
                                    Statement complaintAttachmentDupStmt, Statement complaintGrowerDupStmt,
                                    Statement complaintInvestigationDupStmt) throws
      SQLException {
    complaintDupStmt.executeBatch();
    complaintInsectDupStmt.executeBatch();
    complaintPlantingDupStmt.executeBatch();
    complaintDiseaseDupStmt.executeBatch();
    complaintBatchDupStmt.executeBatch();
    complaintDealerDupStmt.executeBatch();
    complaintDocumentationDupStmt.executeBatch();
    complaintAttachmentDupStmt.executeBatch();
    complaintGrowerDupStmt.executeBatch();
    complaintInvestigationDupStmt.executeBatch();
  }

  private void executeDeleteBatches(Statement complaintDupStmt,
                                    Statement complaintInsectDupStmt,
                                    Statement complaintPlantingDupStmt, Statement complaintDiseaseDupStmt,
                                    Statement complaintBatchDupStmt,
                                    Statement complaintDealerDupStmt, Statement complaintDocumentationDupStmt,
                                    Statement complaintAttachmentDupStmt, Statement complaintGrowerDupStmt,
                                    Statement complaintInvestigationDupStmt) throws
      SQLException {
    complaintAttachmentDupStmt.executeBatch();
    complaintDocumentationDupStmt.executeBatch();
    complaintDealerDupStmt.executeBatch();
    complaintGrowerDupStmt.executeBatch();
    complaintBatchDupStmt.executeBatch();
    complaintDiseaseDupStmt.executeBatch();
    complaintPlantingDupStmt.executeBatch();
    complaintInsectDupStmt.executeBatch();
    complaintInvestigationDupStmt.executeBatch();
    complaintDupStmt.executeBatch();
  }


  public Map<String, String> lookupComplaintEntryTypeList() {
    Map<String, String> entryTypeList = new LinkedHashMap<String, String>();
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement statement = null;
    try {
      connection = getConnection();
      statement = connection.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_COMPLAINT_ENTRY_TYPES);
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        entryTypeList.put(resultSet.getString(1), resultSet.getString(2));
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    } finally {
      closeDBResources(connection, statement, resultSet);
    }
    return entryTypeList;
  }

  public Map<String, String> lookupDispositionListForDescription(String locale) {
    Map<String, String> entryTypeList = new LinkedHashMap<String, String>();
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement statement = null;
    try {
      connection = getConnection();
      statement = connection.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_DISPOSITION_LIST_FOR_DESCRIPTION);
      resultSet = statement.executeQuery();
      while (resultSet.next()) {

        int id = resultSet.getInt("ID");
        String desc = (new I18nServiceImpl())
            .translate(locale, "DISPOSITION_REF", id, resultSet.getString("DESCRIPTION"));

        entryTypeList.put(Integer.toString(id), desc);
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    } finally {
      closeDBResources(connection, statement, resultSet);
    }
    return entryTypeList;
  }

  public List<Disposition> lookupDispositionListForTeamLead(String locale) {
    List<Disposition> dispositions = new ArrayList<Disposition>();
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement statement = null;
    try {
      connection = getConnection();
      statement = connection.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_DISPOSITION_LIST_FOR_TEAMLEAD);
      resultSet = statement.executeQuery();
      I18nServiceImpl iService = new I18nServiceImpl();

      while (resultSet.next()) {

        int id = resultSet.getInt("ID");
        boolean rootCauseReqd = "Y".equalsIgnoreCase(resultSet.getString("ROOT_CAUSE_REQD"));
        String desc = iService.translate(locale, "DISPOSITION_REF", id, resultSet.getString("DESCRIPTION"));

        Disposition disposition = new Disposition();
        disposition.setId((long) id);
        disposition.setDescription(desc);
        disposition.setRootCauseRequired(rootCauseReqd);
        dispositions.add(disposition);
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    } finally {
      closeDBResources(connection, statement, resultSet);
    }
    return dispositions;
  }

  public String getComplaintEntryTypeAsString(String complaintId) throws DAOException {
    String complaintEntryType = "";
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement statement = null;
    try {
      connection = getConnection();
      statement = connection.prepareStatement(ComplaintDAOSQLConstants.LOOKUP_COMPLAINT_ENTRY_TYPE_BY_ID);
      statement.setLong(1, Long.parseLong(complaintId));
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        complaintEntryType = resultSet.getString("TYPE");
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    } finally {
      closeDBResources(connection, statement, resultSet);
    }
    return complaintEntryType;
  }

  private void addBatches(PreparedStatement complaintDupStmt, PreparedStatement complaintInsectDupStmt,
                          PreparedStatement complaintPlantingDupStmt, PreparedStatement complaintDiseaseDupStmt,
                          PreparedStatement complaintBatchDupStmt,
                          PreparedStatement complaintDealerDupStmt, PreparedStatement complaintDocumentationDupStmt,
                          PreparedStatement complaintAttachmentDupStmt, PreparedStatement complaintGrowerDupStmt,
                          PreparedStatement complaintInvestigationDupStmt) throws
      SQLException {

    complaintDupStmt.addBatch();
    complaintInsectDupStmt.addBatch();
    complaintPlantingDupStmt.addBatch();
    complaintDiseaseDupStmt.addBatch();
    complaintBatchDupStmt.addBatch();
    complaintDealerDupStmt.addBatch();
    complaintDocumentationDupStmt.addBatch();
    complaintAttachmentDupStmt.addBatch();
    complaintGrowerDupStmt.addBatch();
    complaintInvestigationDupStmt.addBatch();

  }

  public String[] getComplaintIdsFromCparId(String cparId) {

    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement statement = null;
    ArrayList<String> idList = new ArrayList<String>();
    try {
      connection = getConnection();
      statement = connection.prepareStatement(ComplaintDAOSQLConstants.GET_COMPLAINT_ID_FROM_CPAR_ID);
      statement.setString(1, cparId);
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        idList.add(resultSet.getString(1));
      }
    } catch (SQLException e) {
      throw new RuntimeException(e);
    } finally {
      closeDBResources(connection, statement, resultSet);
    }

    String[] ids = new String[idList.size()];
    for (int i = 0; i < idList.size(); i++) {
      ids[i] = idList.get(i);
    }

    return ids;
  }

  public int getVarietyBatchCombinationId(VarietyBatch varietyBatch){
       PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {

            ps = conn.prepareStatement(ComplaintDAOSQLConstants.SELECT_VARIETY_BATCH_ID_SQL);


          ps.setString(1, varietyBatch.getVarietyDesc());
          ps.setString(2, varietyBatch.getBatchNumber());

          rs=ps.executeQuery();
          while(rs.next()){
             return rs.getInt("VARIETY_BATCH_ID");
          }
            return -1;

        } catch (SQLException e) {
            throw new DatabaseException("Error validating Variety Batch combination", e);
        } finally {
            closeDBResources(conn, ps, rs);
        }

  }


  public void insertCheckboxItemsForRecord(int complaint_id, String sourceType,
                                            int complaint_issue_id) {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {

            ps = conn.prepareStatement(ComplaintDAOSQLConstants.COMPLAINT_ISSUES_SQL);

            ps.setInt(1, complaint_issue_id);
            ps.setInt(2, complaint_id);
            ps.setString(3, "APPLICATION");
            ps.setString(4, "COMPLAINT ENTRY");
            ps.setDate(5, new java.sql.Date(new java.util.Date().getTime()));
            ps.setDate(6, new java.sql.Date(new java.util.Date().getTime()));
            ps.setString(7, sourceType);
            ps.executeUpdate();


            conn.commit();
        } catch (SQLException e) {
            throw new DatabaseException("Error inserting nonconformance category", e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


}
