package com.monsanto.wst.ccas.dao;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"UtilityClass", "AbstractClassNeverImplemented"})
abstract class ComplaintDAOSQLConstants {




    private ComplaintDAOSQLConstants() {
    }

    static final String COMPLAINT_PK_SQL = "select COMPLAINT_SEQ.nextval from dual";


    static final String UPDATE_COMPLAINT_OTHER_INFO_SQL = "update ccas.complaint_other_info set category_other_info=?, responsible_loc_other_info=?, customer_loc_other_info=? where complaint_id = ?";

    static final String INSERT_COMPLAINT_OTHER_INFO_SQL = "insert into ccas.complaint_other_info (complaint_id, category_other_info, responsible_loc_other_info, customer_loc_other_info) values (?,?,?,?)";

    static final String SELECT_COMPLAINT_OTHER_INFO_SQL = "select category_other_info, responsible_loc_other_info, customer_loc_other_info from ccas.complaint_other_info where complaint_id = ?";

    static final String UPDATE_COMPLAINT_SQL = "UPDATE COMPLAINT SET " +
            "CLAIM_NUMBER=?, STATUS_ID=?, " +
            "SALES_YR_ID=?, STATE_ID=?, " +
            "REPORT_INITIATOR=?, REPORT_DATE=?, COMMUNICATION_DATE=?, " +
            "FIELD_COMMUNICATOR=?, REPORTING_LOCATION_CODE=?, RESPONSIBLE_PLANT_CODE=?, " +
            "CROP_ID=?, PERSON_INVESTIGATING=?, SEED_SIZE_ID=?, " +
            "QTY_AFFECTED=?, QTY_UOM_ID=?, DELIVERY_INFO=?, " +
            "ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=?, ROW_TASK_ID=?, " +
            "ROW_USER_ID=?, CREATED_BY=?, REGION_ID=?, " +
            "COMPLAINT_QUALITY_ISSUE_ID=?, SETTLEMENT_VALUE=?, AFFINA_ENTRY_FLAG=?, REPORT_INITIATOR_EMAIL=?, " +
            "COMPLAINT_BUSINESS_ID=? , COMPLAINT_CATEGORY_ID=? , COMPLAINT_TYPE_ID=?, LOCATION_FUNCTION_ID=?, " +
            "SALES_OFFICE_ID=?,MATERIAL_GRP_ID=?, MATERIAL_GROUP_PRICING_ID=?, " +
            "SALES_ORDER_NUMBER=?,SHIPPING_TRANSPORT_NUMBER=?,CUSTOMER_NAME=?,CUSTOMER_ADDRESS=?,CUST_PHONE_NUMBER=?,CUST_EMAIL=?,BUSINESS_ID=?," +
            "CLAIM_AMOUNT=?,CLAIM_STATUS=?, INITIAL_ASSESMENT= ?, LITIGATION_CATEGORY_ID=?, COMPLAINT_ENTRY_TYPE_ID = ?, " +
            "PROGRAM_ID = ?, SUBFUNCTION_ID = ?,CLAIM_ID = ?,CLAIM_CATEGORY_ID=?,INVOICE_NUMBER=?,SAP_CUSTOMER_ID=?," +
            "INVOICE_DATE=?,ISSUE_CATEGORY_ID=?,LOW_LEVEL_CATEGORY=?,REFUGE_PLANTED_ID=?,TRAIT_CHECK_ID=?,ROOT_INJURY_ID=?,INJURY_RATING_ID=?,COMPLIANCE_NEAR_MISS=?,  " +
            " CLOSING_PERSON = ?, INITIATOR_RESPONSE = ?, CLOSING_DATE = ?, cpar_id = (select cpar_id from cpar where control_number = ?) " +
            "WHERE COMPLAINT_ID=?";
    static final String DELETE_COMPLAINT_BATCH_SQL = "DELETE FROM COMPLAINT_BATCH WHERE COMPLAINT_ID=? ";
    static final String UPDATE_COMPLAINT_DEALER_SQL = "UPDATE COMPLAINT_DEALER SET " +
            "DEALER_NAME=?, DEALER_ADDRESS=?, " +
            "DEALER_CITY=?, DEALER_STATE_ID=?, DEALER_PHONE=?, " +
            "DEALER_BA_ID=?, GPS_LATITUDE = ?, GPS_LONGITUDE = ?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
            "ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
            "WHERE COMPLAINT_ID=?";
    static final String UPDATE_COMPLAINT_DISEASE_SQL = "UPDATE COMPLAINT_DISEASE_INFO SET " +
            "DISEASE_OBSERVED=?, HERBICIDE_TYPE_CY=?,	" +
            "HERBICIDE_RATE_CY=?, HERBICIDE_TIMING_CY=?, HERBICIDE_TYPE_PY=?, " +
            "HERBICIDE_RATE_PY=?, HERBICIDE_TIMING_PY=?, ROW_USER_ID=?, " +
            "ROW_TASK_ID=?, ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
            "WHERE COMPLAINT_ID=?";
    static final String UPDATE_COMPLAINT_DOCUMENTATION_SQL = "UPDATE COMPLAINT_DOCUMENTATION SET " +
            "PROBLEM_DESCRIPTION=?, CONTAINMENT_ACTION=?, " +
            "ROOT_CAUSE=?, LONG_TERM_CORRECTION_ACTION=?, ROW_USER_ID=?, " +
            "ROW_TASK_ID=?, ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=? " +
            "WHERE COMPLAINT_ID=?";
    static final String UPDATE_CPAR_TO_COMPLAINT_DOCUMENTATION_SQL = "UPDATE COMPLAINT_DOCUMENTATION SET " +
            "ROW_USER_ID=?, ROW_TASK_ID=?, ROW_MODIFY_DATE=? ";
    static final String UPDATE_COMPLAINT_GROWER_SQL = "UPDATE COMPLAINT_GROWER SET " +
            "GROWER_NAME=?, GROWER_ADDRESS=?, " +
            "GROWER_CITY=?, GROWER_STATE_ID=?, GROWER_PHONE=?, " +
            "GROWER_BA_ID=?, GPS_LATITUDE = ?, GPS_LONGITUDE = ?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
            "ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=?  " +
            "WHERE COMPLAINT_ID=?";
    static final String UPDATE_COMPLAINT_INSECT_SQL = "UPDATE COMPLAINT_INSECT_INFO SET " +
            "INSECTS_OBSERVED=?, INSECTICIDE_TYPE_CY=?, " +
            "INSECTICIDE_RATE_CY=?, INSECTICIDE_TIMING_CY=?, INSECTICIDE_TYPE_PY=?, " +
            "INSECTICIDE_RATE_PY=?, INSECTICIDE_TIMING_PY=?, ROW_USER_ID=?, " +
            "ROW_TASK_ID=?, ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=? " +
            "WHERE COMPLAINT_ID=?";
    static final String UPDATE_COMPLAINT_PLANTING_SQL = "UPDATE COMPLAINT_PLANTING_INFO SET " +
            "TOTAL_ACRES=?, AFFECTED_ACRES=?, " +
            "TECHNOLOGY=?, PLANTING_DATE=?, PLANTER_TYPE=?, " +
            "PLANTER_DEPTH=?, POPULATION_PLANTED=?, POPULATION_OBSERVED=?, " +
            "TILLAGE=?, ROW_USER_ID=?, ROW_TASK_ID=?, " +
            "ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=? " +
            "WHERE COMPLAINT_ID=?";
    //    static final String DELETE_COMPLAINT_VARIETY_SQL = "DELETE FROM COMPLAINT_VARIETY WHERE COMPLAINT_ID=?";
    static final String COMPLAINT_SQL = "INSERT INTO COMPLAINT (" +
            "COMPLAINT_ID, CLAIM_NUMBER, STATUS_ID, " +
            "SALES_YR_ID, STATE_ID, " +
            "REPORT_INITIATOR, REPORT_DATE, COMMUNICATION_DATE, " +
            "FIELD_COMMUNICATOR, REPORTING_LOCATION_CODE, RESPONSIBLE_PLANT_CODE, " +
            "CROP_ID, PERSON_INVESTIGATING, SEED_SIZE_ID, " +
            "QTY_AFFECTED, QTY_UOM_ID, DELIVERY_INFO, " +
            "ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROW_TASK_ID, " +
            "ROW_USER_ID, CREATED_BY, REGION_ID, " +
            "COMPLAINT_QUALITY_ISSUE_ID, SETTLEMENT_VALUE, AFFINA_ENTRY_FLAG, REPORT_INITIATOR_EMAIL, " +
            "COMPLAINT_BUSINESS_ID, COMPLAINT_CATEGORY_ID, COMPLAINT_TYPE_ID, LOCATION_FUNCTION_ID, " +
            "SALES_OFFICE_ID,MATERIAL_GRP_ID,MATERIAL_GROUP_PRICING_ID," +
            "SALES_ORDER_NUMBER,SHIPPING_TRANSPORT_NUMBER,CUSTOMER_NAME,CUSTOMER_ADDRESS,CUST_PHONE_NUMBER," +
            "CUST_EMAIL,BUSINESS_ID,CLAIM_AMOUNT,CLAIM_STATUS,INITIAL_ASSESMENT,LITIGATION_CATEGORY_ID," +
            "IS_DELETED, COMPLAINT_ENTRY_TYPE_ID, " +
            "PROGRAM_ID, SUBFUNCTION_ID,CLAIM_ID,CLAIM_CATEGORY_ID," +
            "INVOICE_NUMBER, SAP_CUSTOMER_ID,INVOICE_DATE,ISSUE_CATEGORY_ID,LOW_LEVEL_CATEGORY,REFUGE_PLANTED_ID," +
            "TRAIT_CHECK_ID,ROOT_INJURY_ID,INJURY_RATING_ID,COMPLIANCE_NEAR_MISS, CLOSING_PERSON, INITIATOR_RESPONSE, CLOSING_DATE, cpar_id) " +
            "VALUES (? ,? ,? ," +
            "? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? , ?," +
            "?, ?, ?, ?, ? ," +
            "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'N', ?, ?, ?, ?, ?, " +
            "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,(select cpar_id from cpar where control_number = ?))";

    static final String SELECT_VARIETY_BATCH_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH = ?) ";
    static final String SELECT_VARIETY_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH is null) ";
    static final String SELECT_BATCH_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY is null AND BATCH = ?) ";

    private static final String COMPLAINT_BATCH_PART = "INSERT INTO COMPLAINT_BATCH (COMPLAINT_BATCH_SEQ," +
            "COMPLAINT_ID, VARIETY_BATCH_ID, QTY_AFFECTED, ACRES_AFFECTED, UOM_ID, SEED_SIZE_ID, IL_TYPE, BATCH_CROP_YR_ID,LOT_NUMBER,COUNTRY_ORIGIN,TREATMENT_TYPE) VALUES (COMPLAINT_BATCH_SEQUENCE.nextval, ?, ";

    static final String UPDATE_COMPLAINT_BATCH_PART = "UPDATE COMPLAINT_BATCH SET VARIETY_BATCH_ID = (SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH = ?)";//,QTY_AFFECTED=?, ACRES_AFFECTED=? ";
    static final String UPDATE_COMPLAINT_BATCH_NULL_PART = "UPDATE COMPLAINT_BATCH SET VARIETY_BATCH_ID = (SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY IS NULL AND BATCH = ?)";//,QTY_AFFECTED=?, ACRES_AFFECTED=? ";
    static final String UPDATE_VARIETY_BATCH_BATCH_NULL_PART = "UPDATE COMPLAINT_BATCH SET VARIETY_BATCH_ID = (SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH IS NULL)";//,QTY_AFFECTED=?, ACRES_AFFECTED=? ";




    static final String UPDATE_UOM_ID_SQL = "UOM_ID = ? ";
    static final String UPDATE_QTY_AFFECTED_SQL = "QTY_AFFECTED = ? ";
    static final String UPDATE_ACRES_AFFECTED_SQL = "ACRES_AFFECTED=? ";
    static final String UPDATE_SEED_SIZE_ID_SQL = "SEED_SIZE_ID = ?";
    static final String UPDATE_IL_TYPE_SQL = "IL_TYPE = ?";
    static final String UPDATE_BATCH_CROP_YR_SQL = "BATCH_CROP_YR_ID = ?";
    static final String UPDATE_BATCH_LOT_NUMBER_SQL = "LOT_NUMBER = ?";
    static final String UPDATE_BATCH_COUNTRY_ORIGIN_SQL = "COUNTRY_ORIGIN = ?";
    static final String UPDATE_BATCH_TREATMENT_TYPE_SQL = "TREATMENT_TYPE = ?";

    static final String UPDATE_WHERE_CLASE_SQL = " WHERE COMPLAINT_ID = ? AND COMPLAINT_BATCH_SEQ = ? ";
    static final String UPDATE_WHERE_CLAUSE_FOR_NULL_VARIETY_SQL = " WHERE COMPLAINT_ID = ? AND COMPLAINT_BATCH_SEQ = ? ";
    static final String UPDATE_COMPLAINT_ID_BATCH_WHERE_CLAUSE_SQL = "  WHERE COMPLAINT_ID = ?";
    static final String UPDATE_COMPLAINT_ID_VARIETY_BATCH_WHERE_CLAUSE_SQL = "  WHERE COMPLAINT_ID = ?";

    static final String COMPLAINT_BATCH_SQL = COMPLAINT_BATCH_PART + SELECT_VARIETY_BATCH_ID_SQL + ", ?, ?, ?, ?, ?, ?,?,?,?)";
    static final String COMPLAINT_BATCH_NULL_BATCH_SQL = COMPLAINT_BATCH_PART + SELECT_VARIETY_ID_SQL + ", ?, ?, ?, ?, ?, ?,?,?,?)";
    static final String COMPLAINT_BATCH_NULL_VARIETY_SQL = COMPLAINT_BATCH_PART + SELECT_BATCH_ID_SQL + ", ?, ?, ?, ?, ?, ?,?,?,?)";



    static final String COMPLAINT_DEALER_SQL = "INSERT INTO COMPLAINT_DEALER ( " +
            "COMPLAINT_ID, DEALER_NAME, DEALER_ADDRESS, " +
            "DEALER_CITY, DEALER_STATE_ID, DEALER_PHONE, " +
            "DEALER_BA_ID, GPS_LATITUDE, GPS_LONGITUDE, ROW_USER_ID, ROW_TASK_ID, " +
            "ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?,? )";
    static final String COMPLAINT_DISEASE_SQL = "INSERT INTO COMPLAINT_DISEASE_INFO ( " +
            "COMPLAINT_ID, DISEASE_OBSERVED, HERBICIDE_TYPE_CY,	" +
            "HERBICIDE_RATE_CY, HERBICIDE_TIMING_CY, HERBICIDE_TYPE_PY, " +
            "HERBICIDE_RATE_PY, HERBICIDE_TIMING_PY, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?,? )";
    static final String COMPLAINT_DOCUMENTATION_SQL = "INSERT INTO COMPLAINT_DOCUMENTATION ( " +
            "COMPLAINT_ID, PROBLEM_DESCRIPTION, CONTAINMENT_ACTION, " +
            "ROOT_CAUSE, LONG_TERM_CORRECTION_ACTION, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?,? )";
    static final String COMPLAINT_GROWER_SQL = "INSERT INTO COMPLAINT_GROWER ( " +
            "COMPLAINT_ID, GROWER_NAME, GROWER_ADDRESS, " +
            "GROWER_CITY, GROWER_STATE_ID, GROWER_PHONE, " +
            "GROWER_BA_ID, GPS_LATITUDE, GPS_LONGITUDE, ROW_USER_ID, ROW_TASK_ID, " +
            "ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, ?)";
    static final String COMPLAINT_INSECT_SQL = "INSERT INTO COMPLAINT_INSECT_INFO ( " +
            "COMPLAINT_ID, INSECTS_OBSERVED, INSECTICIDE_TYPE_CY, " +
            "INSECTICIDE_RATE_CY, INSECTICIDE_TIMING_CY, INSECTICIDE_TYPE_PY, " +
            "INSECTICIDE_RATE_PY, INSECTICIDE_TIMING_PY, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?)";

    static final String COMPLAINT_PLANTING_SQL = "INSERT INTO COMPLAINT_PLANTING_INFO ( " +
            "COMPLAINT_ID, TOTAL_ACRES, AFFECTED_ACRES, " +
            "TECHNOLOGY, PLANTING_DATE, PLANTER_TYPE, " +
            "PLANTER_DEPTH, POPULATION_PLANTED, POPULATION_OBSERVED, " +
            "TILLAGE, ROW_USER_ID, ROW_TASK_ID, " +
            "ROW_MODIFY_DATE, ROW_ENTRY_DATE) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?)";
    //    static final String COMPLAINT_VARIETY_SQL = "INSERT INTO COMPLAINT_VARIETY ( " +
    //            "COMPLAINT_ID, VARIETY_ID) " +
    //            "VALUES ( ?, ?)";
    static final String GET_COMPLAINT_MAIN = "SELECT c.*, CW.CLAIM_STATUS_INDICATOR, cp.control_number as CPAR_CONTROL_NUMBER FROM COMPLAINT c, cpar cp, claim_id_view cw  WHERE  CW.CLAIM_ID(+) = c.CLAIM_NUMBER  and c.COMPLAINT_ID=? and cp.cpar_id(+) = c.cpar_id "; //todo fix this (remove *)

    static final String GET_COMPLAINT_DEALER = "SELECT * FROM COMPLAINT_DEALER WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_GROWER = "SELECT * FROM COMPLAINT_GROWER WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_DISEASE_INFO = "SELECT * FROM COMPLAINT_DISEASE_INFO WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_DOCUMENTATION = "SELECT * FROM COMPLAINT_DOCUMENTATION WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_INSECT_INFO = "SELECT * FROM COMPLAINT_INSECT_INFO WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_PLANTING_INFO = "SELECT * FROM COMPLAINT_PLANTING_INFO WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_VARIETY_BATCH =
            "select vb.batch, vb.variety, cb.qty_affected, cb.acres_affected, cb.uom_id, cb.seed_size_id, cb.IL_TYPE, cb.BATCH_CROP_YR_ID,cb.LOT_NUMBER,cb.COUNTRY_ORIGIN,cb.TREATMENT_TYPE,cb.COMPLAINT_BATCH_SEQ from variety_batch vb, complaint_batch cb where vb.variety_batch_id = cb.variety_batch_id and cb.complaint_id = ?";
    static final String GET_COMPLAINT_CPAR_CIS = "SELECT * FROM COMPLAINT_CPAR_XREF WHERE COMPLAINT_ID=?"; //todo fix this (remove *)
    static final String GET_COMPLAINT_CPAR_CIS_OBJECT = "SELECT * FROM CPAR WHERE CPAR_ID IN ("; //todo fix this (remove *)

    static final String GET_COMPLAINT_SUBFUNCTION = "SELECT SUBFUNCTION_ID FROM COMPLAINT_SUBFUNCTION where COMPLAINT_ID = ?";
    public static final String DELETE_COMPLAINT_SUBFUNCTION = "DELETE FROM COMPLAINT_SUBFUNCTION WHERE COMPLAINT_ID = ?";
    static final String INSERT_COMPLAINT_SUBFUNCTION = "INSERT INTO COMPLAINT_SUBFUNCTION " +
            "(ID, COMPLAINT_ID, SUBFUNCTION_ID) " +
            "VALUES " +
            "(COMPLAINT_SUBFUNCTION_SEQUENCE.NEXTVAL, ?, ?)";

    public static final String GET_COMPLAINT_RESPONSIBILITY = "SELECT COMPLAINT_ID, " +
            "MGMT_APPROVAL_PERSON, MGMT_APPROVAL_DATE, LONG_TERM_CORRECT_ACT_PERSON, LONG_TERM_CORRECT_ACT_DATE," +
            "ROOT_CAUSE_PERSON, ROOT_CAUSE_DATE, CONTAINMENT_ACTION_PERSON, CONTAINMENT_ACTION_DATE, " +
            "ROW_USER_ID, ROW_TASK_ID, ROW_MODIFY_DATE, ROW_ENTRY_DATE,DISPOSITION_ID, TEAM_LEAD_DISPOSITION_ID FROM COMPLAINT_RESPONSIBILITY WHERE COMPLAINT_ID = ?";
    static final String GET_COMPLAINT_ATTACHMENTS = "SELECT ca.document_id, ca.complaint_id, ca.document_name " +
            "  FROM complaint_attachment ca " +
            " WHERE ca.complaint_id = ?";
    static final String FIND_BATCHES = "SELECT A.ID,A.TYPE FROM " +
            "(SELECT VB.BATCH BATCH_NUMBER,CB.COMPLAINT_ID ID,'Complaint' TYPE " +
            " FROM COMPLAINT_BATCH CB, COMPLAINT CP, VARIETY_BATCH VB" +
            " where CB.VARIETY_BATCH_ID = VB.VARIETY_BATCH_ID and CP.COMPLAINT_ID = CB.COMPLAINT_ID and CP.BUSINESS_ID =?" +
            " UNION ALL " +
            " SELECT VB.BATCH BATCH_NUMBER,SB.STOP_SALE_ID ID,'Stop Sale' TYPE " +
            " FROM STOP_SALE_BATCH SB, STOP_SALE SS, VARIETY_BATCH VB" +
            " where SB.VARIETY_BATCH_ID = VB.VARIETY_BATCH_ID and SS.STOP_SALE_ID = SB.STOP_SALE_ID and SS.STOP_SALE_BUSINESS_ID = ? ) A " +
            " WHERE upper(A.BATCH_NUMBER)=upper('";
    static final String GET_STOP_SALE_NUMBER_FROM_ID =
            "SELECT S.CONTROL_NUMBER STOP_SALE_NUMBER FROM STOP_SALE S WHERE S.STOP_SALE_ID = ?";

    static final String GET_COMPLAINT_REPORT =
            "SELECT complaint.complaint_id control_number, complaint.claim_number, " +
                    "       complaint.COMPLAINT_BUSINESS_ID, complaint.COMPLAINT_CATEGORY_ID, complaint.COMPLAINT_TYPE_ID, complaint.LOCATION_FUNCTION_ID, \n" +
                    "       complaint.BUSINESS_ID, complaint.SALES_OFFICE_ID, complaint.MATERIAL_GRP_ID, complaint.MATERIAL_GROUP_PRICING_ID, \n" +
                    "       complaint.SHIPPING_TRANSPORT_NUMBER, complaint.CUSTOMER_NAME, complaint.CUSTOMER_ADDRESS, complaint.CUST_PHONE_NUMBER, complaint.CUST_EMAIL, \n" +
                    "       complaint.SALES_ORDER_NUMBER, complaint.CLAIM_STATUS, \n" +
                    "       status_ref.status_id,\n" +
                    "       status_ref.status_description, year_ref.short_description sales_yr,\n" +
                    "       complaint_state.state_abbr state,\n" +
                    "       complaint.report_initiator initiated_by,\n" +
                    "       complaint.report_date reported_date, complaint.communication_date,\n" +
                    "       complaint.field_communicator, complaint.reporting_location_code,\n" +
                    "       reporting.location_short_name reporting_location,\n" +
                    "       complaint.responsible_plant_code,\n" +
                    "       responsible.location_short_name responsible_location,\n" +
                    "       crop_ref.crop_id,\n" +
                    "       crop_ref.short_description crop, complaint.person_investigating,\n" +
                    "       seed_size_ref.seed_size_id,\n" +
                    "       seed_size_ref.description seed_size, complaint.qty_affected,\n" +
                    "       qty_uom_ref.qty_uom_id, " +
                    "       qty_uom_ref.qty_description qty_uom, complaint.delivery_info,\n" +
                    "       complaint.created_by, region_ref.region_description region,\n" +
                    "       region_ref.region_id,\n" +
                    "       complaint_quality_issue_ref.complaint_quality_issue_id,\n" +
                    "       complaint_quality_issue_ref.complaint_quality_issue,\n" +
                    "       complaint.settlement_value, variety_batch.batch,\n" +
                    "       complaint_documentation.problem_description,\n" +
                    "       complaint_documentation.containment_action,\n" +
                    "       complaint_documentation.root_cause,\n" +
                    "       complaint_documentation.long_term_correction_action,\n" +
                    "       complaint_disease_info.disease_observed,\n" +
                    "       complaint_disease_info.herbicide_type_cy,\n" +
                    "       complaint_disease_info.herbicide_rate_cy,\n" +
                    "       complaint_disease_info.herbicide_timing_cy,\n" +
                    "       complaint_disease_info.herbicide_type_py,\n" +
                    "       complaint_disease_info.herbicide_rate_py,\n" +
                    "       complaint_disease_info.herbicide_timing_py,\n" +
                    "       complaint_insect_info.insects_observed,\n" +
                    "       complaint_insect_info.insecticide_type_cy,\n" +
                    "       complaint_insect_info.insecticide_rate_cy,\n" +
                    "       complaint_insect_info.insecticide_timing_cy,\n" +
                    "       complaint_insect_info.insecticide_type_py,\n" +
                    "       complaint_insect_info.insecticide_rate_py,\n" +
                    "       complaint_insect_info.insecticide_timing_py,\n" +
                    "       complaint_planting_info.total_acres,\n" +
                    "       complaint_planting_info.affected_acres,\n" +
                    "       complaint_planting_info.technology,\n" +
                    "       complaint_planting_info.planting_date,\n" +
                    "       complaint_planting_info.planter_type,\n" +
                    "       complaint_planting_info.planter_depth,\n" +
                    "       complaint_planting_info.population_planted,\n" +
                    "       complaint_planting_info.population_observed,\n" +
                    "       complaint_planting_info.tillage,\n" +
                    "       complaint_issue_ref.complaint_issue_description,\n" +
                    "       complaint_issue_type_ref.description issue_type,\n" +
                    "       complaint_grower.grower_name, complaint_grower.grower_address,\n" +
                    "       complaint_grower.grower_city, complaint_grower.grower_phone,\n" +
                    "       complaint_grower.grower_ba_id, complaint_dealer.dealer_name,\n" +
                    "       complaint_dealer.dealer_address, complaint_dealer.dealer_city,\n" +
                    "       complaint_dealer.dealer_phone, complaint_dealer.dealer_ba_id,\n" +
                    "       variety_batch.variety,M_AUDIT_AREAS_REF.AREA_ID,M_AUDIT_AREAS_REF.DESCRIPTION AUDIT_AREA_DESCRIPTION," +
                    "       COMPLAINT.INITIAL_ASSESMENT ASSESSMENT_DESCRIPTION,COMPLAINT.LITIGATION_CATEGORY_ID LITIGATION_DESCRIPTION, \n" +
                    "       COMPLAINT_MATERIAL_GROUP.COMPLAINT_MATERIAL_GROUP_NAME MATERIAL_GROUP_NAME," +
                    "       COMPLAINT_MATERIAL_PRICING_GRP.COMPLAINT_MPRG_NAME MATERIAL_PRICING_DESC," +
                    "       complaint.row_entry_date created_date,complaint.claim_amount CLAIM_AMOUNT \n" +
                    "  FROM complaint,\n" +
                    "       M_AUDIT_AREAS_REF,M_AUDIT_AREAS,\n" +
                    "       COMPLAINT_ASSESMENT,COMPLAINT_LITIGATION_CATEGORY, \n" +
                    "       complaint_dealer,\n" +
                    "       complaint_disease_info,\n" +
                    "       complaint_documentation,\n" +
                    "       complaint_grower,\n" +
                    "       complaint_insect_info,\n" +
                    "       complaint_issues,\n" +
                    "       complaint_planting_info,\n" +
                    "       status_ref,\n" +
                    "       year_ref,\n" +
                    "       location_ref reporting,\n" +
                    "       location_ref responsible,\n" +
                    "       state_ref complaint_state,\n" +
                    "       crop_ref,\n" +
                    "       seed_size_ref,\n" +
                    "       qty_uom_ref,\n" +
                    "       region_ref,\n" +
                    "       complaint_issue_ref,\n" +
                    "       complaint_issue_type_ref,\n" +
                    "       complaint_batch,\n" +
                    "       variety_batch,\n" +
                    "       complaint_quality_issue_ref,\n" +
                    "       COMPLAINT_MATERIAL_GROUP,COMPLAINT_MATERIAL_PRICING_GRP\n" +
                    " WHERE complaint.is_deleted = 'N' AND status_ref.status_id = complaint.status_id\n" +
                    "   AND year_ref.year_id = complaint.sales_yr_id\n" +
                    "   AND complaint.complaint_id = complaint_dealer.complaint_id(+)\n" +
                    "   AND complaint.complaint_id = complaint_disease_info.complaint_id(+)\n" +
                    "   AND complaint.complaint_id = complaint_documentation.complaint_id(+)\n" +
                    "   AND complaint.complaint_id = complaint_grower.complaint_id(+)\n" +
                    "   AND complaint.complaint_id = complaint_insect_info.complaint_id(+)\n" +
                    "   AND complaint.complaint_id = complaint_issues.complaint_id(+)\n" +
                    "   AND complaint_issues.COMPLAINT_ISSUE_SOURCE(+)= 'C' " + //todo: C or NCR or DEV???
                    "   AND complaint.complaint_id = complaint_planting_info.complaint_id(+)\n" +
                    "   AND reporting.location_code(+) = complaint.reporting_location_code\n" +
                    "   AND responsible.location_code(+) = complaint.responsible_plant_code\n" +
                    "   AND complaint_state.state_id(+) = complaint.state_id\n" +
                    "   AND crop_ref.crop_id(+) = complaint.crop_id\n" +
                    "   AND seed_size_ref.seed_size_id(+) = complaint.seed_size_id\n" +
                    "   AND qty_uom_ref.qty_uom_id(+) = complaint.qty_uom_id\n" +
                    "   AND region_ref.region_id(+) = complaint.region_id\n" +
                    "   AND complaint_issue_ref.complaint_issue_id(+) =\n" +
                    "                                           complaint_issues.complaint_issue_id\n" +
                    "   AND complaint_issue_type_ref.complaint_issue_type_id(+) =\n" +
                    "                                   complaint_issue_ref.complaint_issue_type_id\n" +
                    "   AND complaint_quality_issue_ref.complaint_quality_issue_id(+) =\n" +
                    "                                          complaint.complaint_quality_issue_id\n" +
                    "   AND variety_batch.variety_batch_id(+) = complaint_batch.variety_batch_id\n" +
                    "   AND complaint.complaint_id = complaint_batch.complaint_id(+)\n";

    static final String UNION_ALL = " UNION ALL \n";

    static final String ADD_COMPLAINT_ATTACHMENT_SQL =
            "INSERT INTO complaint_attachment ca " +
                    "            (ca.document_id, ca.complaint_id, ca.document_name " +
                    "            ) " +
                    "     VALUES (?, ?, ? " +
                    "            )";
    static final String DELETE_COMPLAINT_ATTACHMENT_SQL =
            "DELETE FROM complaint_attachment ca WHERE ca.document_id = ? ";
    static final String COMPLAINT_DOCUMENTATION_EXISTS = "SELECT (1) FROM COMPLAINT_DOCUMENTATION WHERE COMPLAINT_ID = ?";
    static final String DELETE_COMPLAINT_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT where complaint_id = ?";
    static final String INSERT_COMPLAINT_DUPLICATE_QUERY = "Insert into CCAS.COMPLAINT_DUPLICATE (COMPLAINT_ID,CLAIM_NUMBER,STATUS_ID,SALES_YR_ID,STATE_ID,REPORT_INITIATOR,REPORT_DATE,COMMUNICATION_DATE,FIELD_COMMUNICATOR,REPORTING_LOCATION_CODE,\n" +
            "RESPONSIBLE_PLANT_CODE,CROP_ID,PERSON_INVESTIGATING,SEED_SIZE_ID,QTY_AFFECTED,QTY_UOM_ID,DELIVERY_INFO,ROW_ENTRY_DATE,ROW_MODIFY_DATE,\n" +
            "ROW_TASK_ID,ROW_USER_ID,CREATED_BY,REGION_ID,COMPLAINT_QUALITY_ISSUE_ID,SETTLEMENT_VALUE,AFFINA_ENTRY_FLAG,REPORT_INITIATOR_EMAIL,\n" +
            "COMPLAINT_BUSINESS_ID,COMPLAINT_CATEGORY_ID,COMPLAINT_TYPE_ID,LOCATION_FUNCTION_ID,B_USER,SALES_OFFICE_ID,MATERIAL_GRP_ID,MATERIAL_GROUP_PRICING_ID,\n" +
            "SALES_ORDER_NUMBER,SHIPPING_TRANSPORT_NUMBER,CUSTOMER_NAME,CUSTOMER_ADDRESS,CUST_PHONE_NUMBER,CUST_EMAIL,BUSINESS_ID,CLAIM_STATUS,CLAIM_AMOUNT,\n" +
            "INITIAL_ASSESMENT,LITIGATION_CATEGORY_ID)\n" +
            "(\n" +
            "select COMPLAINT_ID,CLAIM_NUMBER,STATUS_ID,SALES_YR_ID,STATE_ID,REPORT_INITIATOR,REPORT_DATE,COMMUNICATION_DATE,FIELD_COMMUNICATOR,REPORTING_LOCATION_CODE,\n" +
            "RESPONSIBLE_PLANT_CODE,CROP_ID,PERSON_INVESTIGATING,SEED_SIZE_ID,QTY_AFFECTED,QTY_UOM_ID,NULL,ROW_ENTRY_DATE,ROW_MODIFY_DATE,\n" +
            "ROW_TASK_ID,ROW_USER_ID,CREATED_BY,REGION_ID,COMPLAINT_QUALITY_ISSUE_ID,SETTLEMENT_VALUE,AFFINA_ENTRY_FLAG,REPORT_INITIATOR_EMAIL,\n" +
            "COMPLAINT_BUSINESS_ID,COMPLAINT_CATEGORY_ID,COMPLAINT_TYPE_ID,LOCATION_FUNCTION_ID,B_USER,SALES_OFFICE_ID,MATERIAL_GRP_ID,MATERIAL_GROUP_PRICING_ID,\n" +
            "SALES_ORDER_NUMBER,SHIPPING_TRANSPORT_NUMBER,CUSTOMER_NAME,CUSTOMER_ADDRESS,CUST_PHONE_NUMBER,CUST_EMAIL,BUSINESS_ID,CLAIM_STATUS,CLAIM_AMOUNT,\n" +
            "INITIAL_ASSESMENT,LITIGATION_CATEGORY_ID from CCAS.complaint where complaint_id = ?)";
    static final String DELETE_COMPLAINT_ATTACHMENT_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_ATTACHMENT where complaint_id = ?";
    static final String INSERT_COMPLAINT_ATTACHMENT_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_ATTACHMENT_DUPLICATE (select * from CCAS.COMPLAINT_ATTACHMENT where complaint_id = ?)"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_DOCUMENTATION_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_DOCUMENTATION_DUP (select * from CCAS.COMPLAINT_DOCUMENTATION where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_DOCUMENTATION_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_DOCUMENTATION where complaint_id = ?"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_GROWER_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_GROWER_DUP (select * from CCAS.COMPLAINT_GROWER where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_GROWER_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_GROWER where complaint_id = ?"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_DEALER_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_DEALER where complaint_id = ?"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_DEALER_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_DEALER_DUPLICATE (select * from CCAS.COMPLAINT_DEALER where complaint_id = ?)"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_BATCH_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_BATCH_DUP (select * from CCAS.COMPLAINT_BATCH where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_BATCH_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_BATCH where complaint_id = ?"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_DISEASE_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_DISEASE_INFO_DUP (select * from CCAS.COMPLAINT_DISEASE_INFO where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_DISEASE_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_DISEASE_INFO where complaint_id = ?"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_PLANTING_DUPLICATE_QUERY = "Insert into CCAS.COMPLAINT_PLANTING_INFO_DUP (select * from CCAS.COMPLAINT_PLANTING_INFO where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_PLANTING_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_PLANTING_INFO where complaint_id = ?"; //todo fix this (remove *)
    static final String INSERT_COMPLAINT_INSECT_DUPLICATE_QUERY = "Insert into CCAS.COMPLAINT_INSECT_INFO_DUP (select * from CCAS.COMPLAINT_INSECT_INFO where complaint_id = ?)"; //todo fix this (remove *)
    static final String DELETE_COMPLAINT_INSECT_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_INSECT_INFO where complaint_id = ?"; //todo fix this (remove *)
    static final String LOOKUP_COMPLAINT_ENTRY_TYPES = "select id, type from complaint_entry_type";
    static final String COMPLAINT_RESPONSIBILITY_SQL = "INSERT INTO COMPLAINT_RESPONSIBILITY ( " +
            "complaint_id, mgmt_approval_person,  mgmt_approval_date, containment_action_person, containment_action_date," +
            "root_cause_person, root_cause_date, " +
            "long_term_correct_act_person, long_term_correct_act_date, " +
            "row_user_id, row_task_id, row_modify_date, row_entry_date, disposition_id, team_lead_disposition_id) " +
            "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    static final String UPDATE_COMPLAINT_RESPONSIBILITY_SQL = "UPDATE COMPLAINT_RESPONSIBILITY SET mgmt_approval_person=?, mgmt_approval_date=?, " +
            "containment_action_person = ?, containment_action_date= ?, root_cause_person=?, " +
            "root_cause_date=?, long_term_correct_act_person=?, long_term_correct_act_date=?,  ROW_USER_ID=?, ROW_TASK_ID=?, " +
            "ROW_ENTRY_DATE=?, ROW_MODIFY_DATE=?, disposition_id=?, team_lead_disposition_id=? WHERE COMPLAINT_ID=?";
    static final String LOOKUP_DISPOSITION_LIST_FOR_DESCRIPTION = "SELECT ID, DESCRIPTION FROM DISPOSITION_REF WHERE ACTIVE = 'Y' and TAB_NAME = 'DESCRIPTION' order by DESCRIPTION ASC";
    static final String LOOKUP_DISPOSITION_LIST_FOR_TEAMLEAD = "SELECT ID, DESCRIPTION, ROOT_CAUSE_REQD FROM DISPOSITION_REF WHERE ACTIVE = 'Y' and TAB_NAME = 'TEAMLEAD' order by DESCRIPTION ASC";
    public static final String LOOKUP_ENTRY_TYPE_ID = "SELECT ID FROM COMPLAINT_ENTRY_TYPE WHERE TYPE=?";
    public static final String LOOKUP_ENTRY_TYPE = "SELECT TYPE FROM COMPLAINT_ENTRY_TYPE WHERE ID=?";
    public static final String LOOKUP_COMPLAINT_ENTRY_TYPE_BY_ID = "SELECT CET.TYPE FROM COMPLAINT_ENTRY_TYPE CET, COMPLAINT C WHERE " +
            " C.COMPLAINT_ID = ? AND C.COMPLAINT_ENTRY_TYPE_ID=CET.ID ";

    static final String OUTER_SELECT_COLUMN_LIST = "select ROWNUM as rw,RANKING,complaint_id,row_entry_date,report_initiator,problem_description,short_description as SALES_YR,status_id,status_description, region_id, region_description,claim_number,DESCRIPTION as CUSTOMER,COMPLAINT_ENTRY_TYPE_ID,PROGRAM_DESC as PROGRAM_DESCRIPTION  from (";
    static final String OUTER_SELECT_ALL_COLUMN_LIST = "select * from (";
    static final String MAIN_SELECT_COLUMN_LIST = " select ROWNUM AS RANKING,complaint.complaint_id,complaint.row_entry_date,complaint.report_initiator,complaint_documentation.problem_description,year_ref.short_description,status_ref.status_id,status_ref.status_description, " +
            " region_ref.region_id, region_ref.region_description,complaint.claim_number,complaint_business.DESCRIPTION,complaint.COMPLAINT_ENTRY_TYPE_ID,PROGRAM_DESC ";
    static final String FROM_TABLES_LIST = " from COMPLAINT complaint,COMPLAINT_DOCUMENTATION complaint_documentation,year_ref year_ref,STATUS_REF status_ref,REGION_REF region_ref,PROGRAM_REF program_ref,COMPLAINT_BUSINESS complaint_business  ";
    static final String MAIN_SELECT_IN_CLAUSE = " where  ";
    static final String INNER_SELECT_NOT_EXISTS_QUERY_CIS = " select complaint.complaint_id from COMPLAINT complaint " +
            " where complaint.is_deleted <>'Y' " +
            " and not exists (select claim_view.claim_id from claim_id_view claim_view " +
            " where claim_view.claim_id=trim(complaint.claim_number)) and complaint.business_id = ?  ";

    static final String INNER_SELECT_NOT_EXISTS_QUERY_CIS_NEW_VIEW = " select complaint.complaint_id from COMPLAINT complaint " +
            " where complaint.is_deleted <>'Y' " +
            " and not exists (select claim_view.claim_id from claim_id_view claim_view " +
            " where claim_view.claim_id=trim(complaint.claim_number)) and complaint.business_id = ?  ";

     static final String INNER_SELECT_NOT_EXISTS_QUERY_CIS_NOT_MCAS = " select complaint.complaint_id from COMPLAINT complaint " +
            " where complaint.is_deleted <>'Y' " +
            " and complaint.business_id = ?  ";

    static final String INNER_SELECT_FROM_TABLES = " select complaint.complaint_id from COMPLAINT complaint ";

    static final String INNER_SELECT_FILTER_CLAUSE_CIS = "where complaint.is_deleted <>'Y'  and complaint.business_id = ?  ";
    static final String INNER_SELECT_EXISTS_QUERY_CIS = " AND exists (select claim_view.claim_id from claim_id_view claim_view where claim_view.claim_id =trim(complaint.claim_number) and claim_view.CLAIM_STATUS_INDICATOR <> 'V' ";
    static final String INNER_SELECT_EXISTS_QUERY_CIS_FOR_MCAS = " AND exists (select claim_view.claim_id from claim_id_view claim_view where claim_view.claim_id =trim(complaint.claim_number) ";
    static final String INNER_SELECT_EXISTS_QUERY_CIS_FOR_MCAS_NEW_VIEW = " AND exists (select claim_view.claim_id from claim_id_view claim_view where claim_view.claim_id =trim(complaint.claim_number) ";
    static final String COMMON_OUTER_FILTER_CRITERIA = "  complaint.business_id = ? " +
            " and complaint.complaint_id = complaint_documentation.complaint_id " +
            " and complaint.status_id = status_ref.status_id " +
            " and complaint.region_id = region_ref.region_id " +
            " and complaint.program_id = program_ref.program_id ";

    static final String INSERT_COMPLAINT_INVESTIGATION = " INSERT INTO COMPLAINT_INVESTIGATION (COMPLAINT_ID, INITIATOR_SAMPLE_ID, INITIATOR_SAMPLE_COMMENTS, SITE_SAMPLE_ID, SITE_SAMPLE_COMMENTS, QUALITY_SCORES, DELIVERY_INFO) VALUES" +
            " (?, ?, ?, ?, ? ,? ,?) ";

    static final String UPDATE_COMPLAINT_INVESTIGATION = " UPDATE COMPLAINT_INVESTIGATION SET INITIATOR_SAMPLE_ID = ?, INITIATOR_SAMPLE_COMMENTS = ?, SITE_SAMPLE_ID = ?, SITE_SAMPLE_COMMENTS = ?, QUALITY_SCORES = ?, DELIVERY_INFO = ? WHERE COMPLAINT_ID = ?";

    static final String GET_COMPLAINT_INVESTIGATION = "SELECT * FROM COMPLAINT_INVESTIGATION WHERE COMPLAINT_ID=?";

    static final String INSERT_COMPLAINT_INVESTIGATION_DUPLICATE_QUERY = "insert into CCAS.COMPLAINT_INVESTIGATION_DUP (select * from CCAS.COMPLAINT_INVESTIGATION where complaint_id = ?)";

    static final String DELETE_COMPLAINT_INVESTIGATION_DUPLICATE_QUERY = "delete from CCAS.COMPLAINT_INVESTIGATION_DUP where complaint_id = ?";

    //static final String GET_COMPLAINT_ID_FROM_CPAR_ID = "select complaint_id from complaint where cpar_id = ?";
    static final String GET_COMPLAINT_ID_FROM_CPAR_ID = "select complaint_id from complaint_cpar_xref where cpar_id = ?";

    static final String UPDATE_CPAR_ID_IN_COMPLAINT_TABLE_SQL  = "UPDATE COMPLAINT SET CPAR_ID = ? WHERE COMPLAINT_ID = ? ";

    static final String INSERT_COMPLAINT_CPAR_ID_SQL  = "INSERT INTO COMPLAINT_CPAR_XREF(COMPLAINT_ID,CPAR_ID) VALUES(?,?)";

    static final String COMPLAINT_ISSUES_SQL = "INSERT INTO COMPLAINT_ISSUES ( " +
            "COMPLAINT_ISSUE_ID, COMPLAINT_ID, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE, COMPLAINT_ISSUE_SOURCE) " +
            "VALUES ( ?, ?, ?, ?, ?, ?, ?)";

    static final String DELETE_VARIETY_BATCH = "DELETE complaint_batch where complaint_batch_seq=?";

}
