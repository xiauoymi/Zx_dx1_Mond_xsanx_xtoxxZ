package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Complaint;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: May 9, 2011
 * Time: 8:05:32 PM
 * To change this template use File | Settings | File Templates.
 */

//as you see, this DAO prevents the updating of checkboxes when saving complaints.
//that was needed for the Excel Upload because of the screwy way the checkboxes work.
//they have to be submitted in a HTML form to get updated correctly.
public class ComplaintDaoLeaveCheckboxesAloneImpl extends ComplaintDAOImpl {
    @Override
    /*protected void deleteCheckboxItemsForComplaint(Complaint c) {
    } */


    protected void insertCheckboxItemsForComplaint(Complaint c) {
    }
}
