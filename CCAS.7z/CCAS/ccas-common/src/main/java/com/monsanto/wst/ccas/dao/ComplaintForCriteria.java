package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.model.User;

public class ComplaintForCriteria {
    private final String controlNumber;
    private final String fromDate;
    private final String initiatedBy;
    private final String salesYr;
    private final String status;
    private final String region;
    private final String claimNumber;
    private final String reportingLocation;
    private final String responsibleLocation;
    private final String crop;
    private final String batch;
    private final String state;
    private final String variety;
    private final String qualityIssue;
    private final String intPage;
    private final boolean getMax;
    private final String sortCrit;
    private final String sortOrd;
    private final String complaintBusinessId;
    private final String feedbackCategoryId;
    private final String complaintTypeId;
    private final String functionId;
    private final String salesOfficeCode;
    private final int materialGroupCode;
    private final int materialGroupPricingId;
    private final int modifiedUserBusinessPreferenceId;
    private final int initialAssesmentCode;
    private final int complaintLitigationCategoryCode;
    private final String toDate;
    private final int complaintEntryTypeId;
    private final String customerName;
    private final String sapCustomerId;
    private final String invoiceNumber;
    private int programId;
    private String invoiceDate;
    private String from_communication_date;
    private String to_communication_date;
    private String growerName;
    private String dealerName;
    private String searchText;
    private String claimStatusIndicator;
    private User user;
    private String closingDate;
    private String person_investigating;

    public String getPerson_investigating() {
        return person_investigating;
    }

    public void setPerson_investigating(String person_investigating) {
        this.person_investigating = person_investigating;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getClaimStatusIndicator() {
        return claimStatusIndicator;
    }

    public void setClaimStatusIndicator(String claimStatusIndicator) {
        this.claimStatusIndicator = claimStatusIndicator;
    }

    public ComplaintForCriteria(String controlNumber, String fromDate, String initiatedBy, String salesYr,
                                String status,
                                String region, String claimNumber, String reportingLocation, String responsibleLocation,
                                String crop, String batch, String state, String variety, String qualityIssue,
                                String intPage, boolean getMax, String sortCrit, String sortOrd,
                                String complaintBusinessId, String feedbackCategoryId, String complaintTypeId,
                                String functionId, String salesOfficeCode, int materialGroupCode,
                                int materialGroupPricingId, int modifiedUserBusinessPreferenceId,
                                int initialAssesmentCode, int complaintLitigationCategoryCode, String toDate,
                                int complaintEntryTypeId, String customerName, String sapCustomerId,
                                String invoiceNumber, int programId, String invoiceDate, String from_communication_date,
                                String to_communication_date, String growerName, String dealerName, String searchText, String closingDate,String person_investigating) {
        this.controlNumber = controlNumber;
        this.fromDate = fromDate;
        this.initiatedBy = initiatedBy;
        this.salesYr = salesYr;
        this.status = status;
        this.region = region;
        this.claimNumber = claimNumber;
        this.reportingLocation = reportingLocation;
        this.responsibleLocation = responsibleLocation;
        this.crop = crop;
        this.batch = batch;
        this.state = state;
        this.variety = variety;
        this.qualityIssue = qualityIssue;
        this.intPage = intPage;
        this.getMax = getMax;
        this.sortCrit = sortCrit;
        this.sortOrd = sortOrd;
        this.complaintBusinessId = complaintBusinessId;
        this.feedbackCategoryId = feedbackCategoryId;
        this.complaintTypeId = complaintTypeId;
        this.functionId = functionId;
        this.salesOfficeCode = salesOfficeCode;
        this.materialGroupCode = materialGroupCode;
        this.materialGroupPricingId = materialGroupPricingId;
        this.modifiedUserBusinessPreferenceId = modifiedUserBusinessPreferenceId;
        this.initialAssesmentCode = initialAssesmentCode;
        this.complaintLitigationCategoryCode = complaintLitigationCategoryCode;
        this.toDate = toDate;
        this.complaintEntryTypeId = complaintEntryTypeId;
        this.customerName = customerName;
        this.sapCustomerId = sapCustomerId;
        this.invoiceNumber = invoiceNumber;
        this.programId = programId;
        this.invoiceDate = invoiceDate;
        this.from_communication_date = from_communication_date;
        this.to_communication_date = to_communication_date;
        this.growerName = growerName;
        this.dealerName = dealerName;
        this.searchText = searchText;
        this.closingDate = closingDate;
        this.person_investigating=person_investigating;
    }

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    public String getFrom_communication_date() {
        return from_communication_date;
    }

    public String getTo_communication_date() {
        return to_communication_date;
    }

    public String getControlNumber() {
        return controlNumber;
    }

    public String getFromDate() {
        return fromDate;
    }

    public String getInitiatedBy() {
        return initiatedBy;
    }

    public String getSalesYr() {
        return salesYr;
    }

    public String getStatus() {
        return status;
    }

    public String getRegion() {
        return region;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public String getReportingLocation() {
        return reportingLocation;
    }

    public String getResponsibleLocation() {
        return responsibleLocation;
    }

    public String getCrop() {
        return crop;
    }

    public String getBatch() {
        return batch;
    }

    public String getState() {
        return state;
    }

    public String getVariety() {
        return variety;
    }

    public String getQualityIssue() {
        return qualityIssue;
    }

    String getIntPage() {
        return intPage;
    }

    public boolean isGetMax() {
        return getMax;
    }

    public String getSortCrit() {
        return sortCrit;
    }

    public String getSortOrd() {
        return sortOrd;
    }

    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public String getfeedbackCategoryId() {
        return feedbackCategoryId;
    }

    public String getComplaintTypeId() {
        return complaintTypeId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public String getSalesOfficeCode() {
        return salesOfficeCode;
    }

    public int getMaterialGroupCode() {
        return materialGroupCode;
    }

    public int getMaterialGroupPricingId() {
        return materialGroupPricingId;
    }

    public int getModifiedUserBusinessPreferenceId() {
        return modifiedUserBusinessPreferenceId;
    }

    public int getInitialAssesmentCode() {
        return initialAssesmentCode;
    }

    public int getComplaintLitigationCategoryCode() {
        return complaintLitigationCategoryCode;
    }

    public String getToDate() {
        return toDate;
    }

    public int getComplaintEntryTypeId() {
        return complaintEntryTypeId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getSapCustomerId() {
        return sapCustomerId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }


    public int getProgramId() {
        return programId;
    }

    public void setProgramId(int programId) {
        this.programId = programId;
    }

    public String getGrowerName() {
        return growerName;
    }

    public String getDealerName() {
        return dealerName;
    }

    String getOrderByClause() {
        int page = Integer.parseInt(getIntPage());

        if ("ROW_ENTRY_DATE".equals(sortCrit) || "COMPLAINT_ID".equals(sortCrit) || "SALES_YR".equals(sortCrit)) {
            return " ORDER BY " + sortCrit + " " + sortOrd + " )) WHERE rw BETWEEN " + ((page * 10) - 9) + " and " +
                    page * 10;
        }
        return " ORDER BY Lower(" + sortCrit + ") " + sortOrd + " ))  WHERE RANKING BETWEEN " + ((page * 10) - 9) +
                " and " + page * 10;
    }

    void getCISFieldsFilterClause(StringBuffer filterClause, StringBuffer whereClause) {
        if (!StringUtils.isNullOrEmpty(crop)) {
            filterClause.append(" AND complaint.crop_id = ").append(Integer.parseInt(crop));
            whereClause.append(" AND  crop_ref.CROP_ID= ").append(Integer.parseInt(crop));
        }
        if (!StringUtils.isNullOrEmpty(state)) {
            filterClause.append(" AND complaint.state_id = ").append(Integer.parseInt(state));
            whereClause.append(" AND  state_ref.state_id= ").append(Integer.parseInt(state));
        }
        if (!StringUtils.isNullOrEmpty(salesYr)) {
            filterClause.append(" AND complaint.sales_yr_id = ").append(Integer.parseInt(salesYr));
            whereClause.append(" AND  year_ref.year_id= ").append(Integer.parseInt(salesYr));
        }
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

     public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }
}
