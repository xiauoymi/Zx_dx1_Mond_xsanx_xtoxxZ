/*
 ComplaintSearchResult was created on Aug 28, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ComplaintSearchResult implements Serializable {
  private final String complaintId;
  private final String date;
  private final String reportInitiator;
  private final String problemDesc;
  private final String salesYear;
  private final String status;
  private final String regionDesc;
  private final String claimNumber;
  private final String customer;
  private final String entryTypeString;

  public String getProgramDesc() {
    return programDesc;
  }

  public void setProgramDesc(String programDesc) {
    this.programDesc = programDesc;
  }

  private String programDesc;

  public ComplaintSearchResult(String complaintId, String date, String reportInitiator, String problemDesc,
                               String salesYear, String status, String regionDesc, String claimNumber, String customer,
                               String entryTypeString, String programDesc) {
    this.complaintId = complaintId;
    this.date = date;
    this.reportInitiator = reportInitiator;
    this.problemDesc = problemDesc;
    this.salesYear = salesYear;
    this.status = status;
    this.regionDesc = regionDesc;
    this.claimNumber = claimNumber;
    this.customer = customer;
    this.entryTypeString = entryTypeString;
    this.programDesc = programDesc;
  }

  public String getComplaintId() {
    return complaintId;
  }

  public String getDate() {
    return date;
  }

  public String getReportInitiator() {
    return reportInitiator;
  }

  public String getProblemDesc() {
    return problemDesc;
  }

  public String getSalesYear() {
    return salesYear;
  }

  public String getStatus() {
    return status;
  }

  public String getRegionDesc() {
    return regionDesc;
  }

  public String getClaimNumber() {
    return claimNumber;
  }

  public String getCustomer() {
    return customer;
  }

  public String getEntryTypeString() {
    return entryTypeString;
  }

}
