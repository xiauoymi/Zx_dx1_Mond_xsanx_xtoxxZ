/*
 * Created on Mar 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface ControlNumberDAO {
    public boolean generateControlNumber(Object o, boolean isMCAS, boolean isSBFAS, boolean isBIOTECHFAS) throws DAOException;
}
