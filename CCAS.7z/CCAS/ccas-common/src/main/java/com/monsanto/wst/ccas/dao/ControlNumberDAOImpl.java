/*
 * Created on Mar 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlNumberDAOImpl extends BaseDAOImpl implements ControlNumberDAO {
    private final ActionHelper actionHelper;
    private static final String SBFAS_SYMBOL = "=";
    private static final String SBFAS_BUSINESS_QUERY = "SELECT TRIM(DESCRIPTION) AS DESCRIPTION FROM BUSINESS WHERE BUSINESS_ID=";

    /**
     * Constructor. Initialize the datasource.
     *
     * @throws SQLException if lookup of datasource fails
     */
    public ControlNumberDAOImpl() {
        actionHelper = new ActionHelper();
    }

    public ControlNumberDAOImpl(ActionHelper actionHelper) {
        this.actionHelper = actionHelper;
    }

    public boolean generateControlNumber(Object o, boolean isMCAS, boolean isSBFAS, boolean isBIOTECHFAS) throws DAOException {
        Connection conn = null;
        StringBuffer controlSeq;
        String businessDescription = null;
        boolean result = false;
        try {
            if (o != null) {
                conn = getConnection();

                if (o instanceof Cpar) {
                    Cpar cpar = (Cpar) o;
                    controlSeq = cpar.getControlSequence(isMCAS , isSBFAS, isBIOTECHFAS);
                    MCASLogUtil.logError("Control sequence for CPAR : "+controlSeq,new Exception());
                    if(controlSeq.toString().contains(SBFAS_SYMBOL)){

                        controlSeq.deleteCharAt(controlSeq.length() - 1);
                        String businessQuery = SBFAS_BUSINESS_QUERY + cpar.getBusinessId();
                        businessDescription = getBusiness(conn, businessQuery);
                        if((businessDescription != null) && (!businessDescription.isEmpty())){
                            businessDescription = businessDescription.substring(0,3).toUpperCase();
                            int indexOfChar = controlSeq.indexOf("-") + 1;
                            controlSeq.insert(indexOfChar, businessDescription + "-");
                            controlSeq.append('-');
                        }
                        MCASLogUtil.logError("It have SBFAS symbol result controlSeq: "+controlSeq , new Exception());
                    }
                    if(isBIOTECHFAS){
                        String year = actionHelper.getSalesyearList(MCASConstants.LANGUAGE_DEFAULT).get(cpar.getIssue_year()).substring(2).trim();
                        Calendar calendar = new GregorianCalendar();
                        int month = Calendar.getInstance().get(Calendar.MONTH);
                        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                        String currentYrStr = currentYear + "";
                        currentYrStr = currentYrStr.substring(2).trim();
                        currentYear =  Integer.parseInt(currentYrStr);
                        int selectedYear = Integer.parseInt(year);
                        if(currentYear < selectedYear){
                            if(month <= 8){
                                controlSeq.append(Integer.parseInt(year) - 1);
                            }else{
                                controlSeq.append(Integer.parseInt(year));
                            }

                        }else if(currentYear == selectedYear){
                            if(month <= 8){
                                controlSeq.append(Integer.parseInt(year));
                            }else{
                                controlSeq.append(Integer.parseInt(year) + 1);
                            }
                        }else{
                            if(month <= 8){
                                controlSeq.append(currentYear);
                            }else{
                                controlSeq.append(currentYear + 1);
                            }
                            System.out.println("controlSeq:" + controlSeq);
                        }
                        MCASLogUtil.logError("It is Biotechas controlSeq: "+controlSeq , new Exception());
                    }else{
                        controlSeq.append(actionHelper.getSalesyearList(MCASConstants.LANGUAGE_DEFAULT).get(cpar.getIssue_year())
                            .substring(2).trim());
                        MCASLogUtil.logError("It is MCAS controlSeq: "+controlSeq , new Exception());
                    }
                    controlSeq.append("-");
                    String queryString = getQueryString(controlSeq.toString(), "cpar");
                    controlSeq.append(getControlSequence(conn, queryString));
                    MCASLogUtil.logError("After adding the control sequence: "+controlSeq , new Exception());
                    cpar.setControl_number(controlSeq.toString());
                    MCASLogUtil.logError("Control Seq empty or less than 2: "+controlSeq.toString().equalsIgnoreCase("")+"&&"+controlSeq.length() , new Exception());
                    if(controlSeq.toString().equalsIgnoreCase("")||controlSeq.length()<2){
                        MCASLogUtil.logError("Returning false because no control number was generated" , new Exception());
                       return false;
                    }
                    else{
                        result = true;
                        }
                }
            }
            return result;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, null, null);
        }
    }

    private long getControlSequence(Connection conn, String queryString) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(queryString);
            rs = ps.executeQuery();
            long controlSeq = 1;
            if (rs != null) {
                rs.next();
                controlSeq = (rs.getLong(1)) + 1;
            }

            return controlSeq;
        }
        finally {
            closeDBResources(null, ps, rs);
        }

    }

    private String getBusiness(Connection conn, String queryString) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(queryString);
            rs = ps.executeQuery();
            String business = "";
            if (rs != null) {
                rs.next();
                business = rs.getString(1);
            }
            return business;
        }
        finally {
            closeDBResources(null, ps, rs);
        }

    }

    private String getQueryString(String seqNo, String tblName) {
        StringBuffer query = new StringBuffer();
        query.append("select");
        query.append(" max(to_number(substr(control_number,length('");
        query.append(seqNo);
        query.append("')+1))) ");
        query.append("from ");
        query.append(tblName);
        query.append(" where control_number like '");
        query.append(seqNo);
        query.append("%'");
//        System.out.println(query.toString());
        return query.toString();


    }
}
