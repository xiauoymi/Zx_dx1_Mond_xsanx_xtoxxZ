/*
 * Created on Feb 21, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.CparFilter;
import com.monsanto.wst.ccas.model.CparLog;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.util.Map;
import java.util.List;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface CparDAO {
    public String getCparPK() throws DAOException;

    public void insertCpar(Cpar cpar) throws DAOException;

    public void updateCpar(Cpar cpar) throws DAOException;

    public boolean deleteCpar(Cpar cpar) throws DAOException;

    public Map<String, Object> getCparsList(String controlNumber, String createDateFrom, String createDateTo,
                                            String initiatedBy, String status, String region, String claimNumber,
                                            String carFlag, String filingLoc, String responsibleLoc, String intPage,
                                            String sortCriteria, String sortOrder, String cparBusinessId,
                                            String functionId, int businessPreferenceId, int type, String filingProgramId,
                                            String responsibleProgramId, String generator, String findingType,
                                            String isoStandardId, String locale, String siteManager, String searchText,
                                            String closingDate, List<Integer> functionalAreaIdList, String cropId)
            throws DAOException;

    public Cpar getCpar(String Cpar_id,boolean isBIOTECHFAS) throws DAOException;

    public Cpar getCparByControlNo(String control_no, int business_id) throws DAOException;

    public boolean findControlNumber(String control_number) throws DAOException;

    public Map<String, String> findCAR(String complaint_id, String carFlag) throws DAOException;

    public String findControlNumberText(String complaint_id) throws DAOException;

    public Map<String, RowBean> getCparReport(CparFilter cparFilter, int businessId, String locale) throws DAOException;

    public Map<String, RowBean> getCparLog(CparLog cparLog) throws DAOException;

    boolean addCPARAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException;

    boolean deleteCPARAttachmentInfo(String documentId) throws DAOException;

}
