/*
 * Created on Feb 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.service.ComplaintService;
import com.monsanto.wst.ccas.service.ComplaintServiceImpl;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author jbrahmb <p/> TODO To change the template for this generated type comment go to Window - Preferences - Java -
 *         Code Style - Code Templates
 */
public class CparDAOImpl extends BaseDAOImpl implements CparDAO {

    private static final Category logger = Category.getInstance(CparDAOImpl.class.getName());


    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    NonconformanceCategoryDaoImpl ncDao = new NonconformanceCategoryDaoImpl();
    RootCauseDaoImpl rcDao = new RootCauseDaoImpl();
    FunctionalAreaDaoImpl aaDao = new FunctionalAreaDaoImpl();

    public CparDAOImpl() {

    }

    protected LocationOtherInfoDao getLocationOtherInfoDao(Connection con) {
        return new LocationOtherInfoDaoImpl(con);
    }

    public String getCparPK() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.CPAR_PK_SQL);
            rs = ps.executeQuery();
            rs.next();
            return rs.getString(1);
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private void insertUpdateCpar(Cpar c, boolean isUpdate) throws DAOException {
//        logger.info("Enter insertUpdateCpar");
//        logger.info(
//                "START : ****User ID****:" + c.getRow_user_id() + ":****Business ID****:" + c.getBusinessId() +
//                        ":****Method****:" + getClass() + "insertUpdateCpar()" +
//                        ":****Cpar Region****:" + c.getRegion());
//        System.out.println("START : ****User ID****:" + c.getRow_user_id() + ":****Business ID****:" + c.getBusinessId() +
//                ":****Method****:" + getClass() + "insertUpdateCpar()" +
//                ":****Cpar Region****:" + c.getRegion() + "****CPAR ID****" + c.getCpar_id());
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        int parameterIndx = 1;
        double costOfQuality;
        try {
            conn = getConnection();


            if (isUpdate) {
                ps = conn.prepareStatement(CparDAOSQLConstants.UPDATE_CPAR_SQL);
                ps.setLong(42, Long.parseLong(c.getCpar_id()));
            } else {
                ps = conn.prepareStatement(CparDAOSQLConstants.CPAR_SQL);
                ps.setLong(parameterIndx, Long.parseLong(c.getCpar_id()));
                parameterIndx++;
            }
            setDefaultIntegerIfNull(c.getStop_sale_id(), ps, parameterIndx, 0);
            setDefaultIntegerIfNull(c.getAudit_finding_id(), ps, parameterIndx, 1);
            //complaint ID in Cpar isn't going to be used anymore
//            if (c.getComplaint_id() != null && c.getComplaint_id().length > 0 && !StringUtils.isNullOrEmpty(c.getComplaint_id()[0]))
//                setDefaultIntegerIfNull(c.getComplaint_id()[0], ps, parameterIndx, 2);
            setDefaultIntegerIfNull(null, ps, parameterIndx, 2);
            setDefaultIntegerIfNull(c.getGenerator(), ps, parameterIndx, 3);
            ps.setString(parameterIndx + 4, c.getCar_flag());
            ps.setString(parameterIndx + 5, c.getClaim_number());
            setDefaultIntegerIfNull(c.getStatus_id(), ps, parameterIndx, 6);
            ps.setString(parameterIndx + 7, c.getInitiated_by());
            ps.setString(parameterIndx + 8, c.getFiling_location());
            ps.setString(parameterIndx + 9, c.getResponsible_location());
            setDefaultIntegerIfNull(c.getFinding_type(), ps, parameterIndx, 10);
            setDefaultIntegerIfNull(c.getIso_standard(), ps, parameterIndx, 11);
            setDefaultIntegerIfNull(c.getIssue_year(), ps, parameterIndx, 12);
            setDefaultDateIfNull(c.getReport_date(), ps, parameterIndx, 13);
            ps.setString(parameterIndx + 14, c.getSite_manager());
            ps.setString(parameterIndx + 15, c.getRow_user_id());
            setParametersOnUpdate(c, isUpdate, ps, parameterIndx);
            ps.setDate(parameterIndx + 18, new Date(new java.util.Date().getTime()));
            setDefaultIntegerIfNull(c.getRegion(), ps, parameterIndx, 19);
            ps.setString(parameterIndx + 20, c.getControl_number());
            ps.setString(parameterIndx + 21, c.getCreated_by());
            ps.setString(parameterIndx + 22, c.getReport_initiator_email());
            ps.setBoolean(parameterIndx + 23, c.isSuppress_overdue_notice());
            setDefaultIntegerIfNull(c.getCostOfQualityNumeric(), ps, parameterIndx, 24);
            ps.setString(parameterIndx + 25, c.getCostOfQuality());
            setDefaultIntegerIfNull(c.getComplaintBusinessId(), ps, parameterIndx, 26);
            setDefaultIntegerIfNull(c.getFunctionId(), ps, parameterIndx, 27);
            ps.setInt(parameterIndx + 28, c.getBusinessId());

            ps.setString(33, c.getResponsibleRegionId());
            setDefaultIntegerIfNull(c.getIssueCategoryId(), ps, 0, 34);
            setDefaultIntegerIfNull(c.getOrganization(), ps, 0, 35);
            setDefaultDateIfNull(c.getExpectedDate(), ps, 0, 36);
            setDefaultIntegerIfNull(c.getDepartmentAffectedId(), ps, 0, 37);
            ps.setString(38, c.getInitiatedByUserId());
            ps.setString(39, c.getSiteManagerUserId());

            setDefaultIntegerIfNull(c.getCrop_id(), ps, 0, 40);
            setDefaultDateIfNull(c.getReport_due_date(), ps, 0, 41);

            if (ps.executeUpdate() > 0) {
                insertCparDocumentation(c, conn, isUpdate);
                insertCparResponsibility(c, conn, isUpdate);
                insertCparProgram(c, conn, isUpdate);
                insertIssues(c, conn, isUpdate);
                insertCparSubFunction(c, conn);

                if (c.getComplaint_id() != null && c.getComplaint_id().length > 0 && !StringUtils.isNullOrEmpty(c.getComplaint_id()[0])) {
                    for (int i = 0; i < c.getComplaint_id().length; i++) {
                        String complaintId = c.getComplaint_id()[i];
                        if (!StringUtils.isNullOrEmpty(complaintId)) {
                            if(!isUpdate){
                                ComplaintDAO complaintDao = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
                                complaintDao.updateCParIdInComplaintTable(c, complaintId);
                            }
                        }
                    }
                }
            }
            c.setComplaint_id(getComplaintIds(c.getCpar_id()));
            if (c.getComplaint_id() != null) {
                for (int i = 0; i < c.getComplaint_id().length; i++) {
                    String complaintId = c.getComplaint_id()[i];
                    if (!StringUtils.isNullOrEmpty(complaintId)
                            && 2 != c.getBusinessId()) {
                        ComplaintDAO complaintDao = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
                        complaintDao.updateComplaintDocumentation(c, complaintId);
                    }
                }
            }
            if (isUpdate) {
                ncDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P");
                rcDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P");
                aaDao.deleteCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P");
            }
            ncDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P",
                    c.getSelectedNonconformanceCategoryList());
            rcDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P", c.getSelectedRootCauseList());
            aaDao.insertCheckboxItemsForRecord(Integer.parseInt(c.getCpar_id()), "P", c.getSelectedFunctionalAreas());

            if (c.getLocationOtherInfo() != null && !c.getLocationOtherInfo().isNotSet()) {
                c.getLocationOtherInfo().setId(c.getCpar_id());
                if (isUpdate)
                    getLocationOtherInfoDao(conn).update(c.getLocationOtherInfo());
                else
                    getLocationOtherInfoDao(conn).create(c.getLocationOtherInfo());
            }
            conn.commit();
        } catch (Exception e) {
            MCASLogUtil.logError("Error creating / udpating cpar", e);
            try {
                conn.rollback();
            } catch (Exception ex) {
                throw new DAOException(ex);
            }
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private void insertCparSubFunction(Cpar c, Connection conn) throws DAOException {
        if (c.getSubFunctionsSelected() != null) {
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement(CparDAOSQLConstants.DELETE_CPAR_SUBFUNCTION);
                ps.setString(1, c.getCpar_id());
                ps.executeUpdate();

                closeDBResources(null, ps, null);

                ps = conn.prepareStatement(CparDAOSQLConstants.INSERT_CPAR_SUBFUNCTION);
                for (String subfunctionId : c.getSubFunctionsSelected()) {
                    ps.setString(1, c.getCpar_id());
                    if (StringUtils.isNullOrEmpty(subfunctionId)) {
                        ps.setString(2, "0");
                    } else {
                        ps.setString(2, subfunctionId);
                    }
                    ps.executeUpdate();
                }
            } catch (SQLException e) {
                throw new DAOException(e);
            } finally {
                closeDBResources(null, ps, null);
            }
        }
    }

    private void insertCparProgram(Cpar cpar, Connection conn, boolean update) throws DAOException {
        PreparedStatement ps = null;
        try {
            if (update) {
                ps = conn.prepareStatement(CparDAOSQLConstants.UPDATE_CPAR_PROGRAM);
            } else {
                ps = conn.prepareStatement(CparDAOSQLConstants.INSERT_CPAR_PROGRAM);
            }
            ps.setInt(1, Integer.parseInt(cpar.getFilingProgramId()));
            ps.setInt(2, Integer.parseInt(cpar.getResponsibleProgramId()));
            ps.setInt(3, 0);
            ps.setLong(4, Long.parseLong(cpar.getCpar_id()));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException("Exception in inserting CPAR_PROGRAM in " + getClass().getName() + ".insertCparProgram()",
                    e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }

    private void insertIssues(Cpar cpar, Connection conn, boolean update) throws DAOException {
        PreparedStatement ps = null;
        try {
            if (update) {
                ps = conn.prepareStatement(CparDAOSQLConstants.DELETE_CPAR_ISSUES);
                ps.setString(1, cpar.getCpar_id());
                ps.executeUpdate();
            }
            for (Issue issue : cpar.getIssues()) {
                if (issue.isSelected()) {
                    ps = conn.prepareStatement(CparDAOSQLConstants.INSERT_CPAR_ISSUES);
                    ps.setLong(1, issue.getId());
                    ps.setLong(2, Long.parseLong(cpar.getCpar_id()));
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Exception in inserting CPAR_ISSUES in " + getClass().getName() + ".insertIssues()",
                    e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }

    public void insertCpar(Cpar c) throws DAOException {
        insertUpdateCpar(c, false);
        updateStopSaleDoc(c.getRoot_cause(), c.getLong_term_corrective_action(), Integer.parseInt(c.getCpar_id()));
        }


    public void updateCpar(Cpar c) throws DAOException {
        insertUpdateCpar(c, true);
        updateStopSaleDoc(c.getRoot_cause(), c.getLong_term_corrective_action(), Integer.parseInt(c.getCpar_id()));
    }

    void updateStopSaleDoc(String rootCause, String longTermCorrAction, int cparID) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.UPDATE_STOP_SALE_DOC);
            ps.setString(1, rootCause);
            ps.setString(2, longTermCorrAction);
            ps.setInt(3, cparID);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            MCASLogUtil.logError("SQLException while getting connection: ", e);
        } catch (Exception e) {
            MCASLogUtil.logError("Exception while getting connection: ", e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    public boolean deleteCpar(Cpar cpar) throws DAOException {
        PreparedStatement ps = null;
        Connection conn = null;
        boolean isCparDeleted = false;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.DELETE_CPAR);
            ps.setLong(1, Long.parseLong(cpar.getCpar_id()));
            int numRecordsUpdated = ps.executeUpdate();
            if (numRecordsUpdated > 0) {
                isCparDeleted = true;
            }
            LocationOtherInfo loc = new LocationOtherInfo();
            loc.setId(cpar.getCpar_id());
            getLocationOtherInfoDao(conn).delete(loc);
            conn.commit();
            return isCparDeleted;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }


    public boolean findControlNumber(String control_number) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        boolean result = false;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.FIND_CONTROL_NUMBER + control_number + "')");
            rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getLong("RECORDS") > 0)
                    result = true;
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> findCAR(String complaint_id, String carFlag) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        Map<String, String> carMap = new HashMap<String, String>();
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.FIND_CAR);
            ps.setString(1, carFlag);
            ps.setString(2, complaint_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                String cparId = rs.getString("CPAR_ID");
                String controlNumber = rs.getString("CONTROL_NUMBER");
                carMap.put(cparId, controlNumber);
            }
            return carMap;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public String findControlNumberText(String complaint_id) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        String result = "";
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.FIND_CONTROL_NUMBER_TEXT + complaint_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                result = rs.getString("CONTROL_NUMBER");
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, Object> getCparsList(String controlNumber, String createDateFrom, String createDateTo,
                                            String initiatedBy, String status, String region, String claimNumber,
                                            String carFlag,
                                            String filingLoc, String responsibleLoc, String intPage,
                                            String sortCrit,
                                            String sortOrd, String complaintBusinessId, String functionId,
                                            int businessPreferenceId, int type, String filingProgramId,
                                            String responsibleProgramId, String generator, String findingType,
                                            String isoStandardId, String locale, String siteManager, String searchText,
                                            String closingDate, List<Integer> functionalAreaIdList, String cropId)
            throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause;
        String lastSQL = "";
        List<String> paramList = new ArrayList<String>();
        Map<String, Object> cpars = null;
        try {
            int Page = Integer.parseInt(intPage);
            if (controlNumber != null && !(controlNumber.equals("")))
                paramList.add("controlNumber");
            if (createDateFrom != null && !(createDateFrom.equals("")))
                paramList.add("createDateFrom");
            if (createDateTo != null && !(createDateTo.equals("")))
                paramList.add("createDateTo");
            if (initiatedBy != null && !(initiatedBy.equals("")))
                paramList.add("initiatedBy");
            if (status != null && !(status.equals("")) && !(status.equals("0")))
                paramList.add("status");
            if (region != null && !(region.equals("")) && !(region.equals("0")))
                paramList.add("region");
            if (claimNumber != null && !(claimNumber.equals("")))
                paramList.add("claimNumber");
            if (filingLoc != null && !(filingLoc.equals("")))
                paramList.add("filingLoc");
            if (responsibleLoc != null && !(responsibleLoc.equals("")))
                paramList.add("responsibleLoc");
            if (carFlag != null && !(carFlag.equals("")))
                paramList.add("carFlag");
            if (complaintBusinessId != null && !(complaintBusinessId.equals(""))) {
                paramList.add("complaintBusinessId");
            }
            if (!(generator == null) && !(generator.equals(""))) {
                paramList.add("generator");
            }
            if (!(findingType == null) && !(findingType.equals(""))) {
                paramList.add("findingType");
            }
            if (!(functionId == null) && !(functionId.equals(""))) {
                paramList.add("functionId");
            }
            if (!(filingProgramId == null) && !(filingProgramId.equals(""))) {
                paramList.add("filingProgramId");
            }
            if (!(responsibleProgramId == null) && !(responsibleProgramId.equals(""))) {
                paramList.add("responsibleProgramId");
            }
            if (!(isoStandardId == null) && !(isoStandardId.equals(""))) {
                paramList.add("isoStandardId");
            }
            if (!(siteManager == null) && !(siteManager.equals(""))) {
                paramList.add("siteManager");
            }

            if (closingDate != null && !(closingDate.equals("")))
                paramList.add("closingDate");

            if (!StringUtils.isNullOrEmpty(cropId)){
                paramList.add("crop_id");
            }

            conn = getConnection();
            whereClause = new StringBuffer();
            for (String aParamList : paramList) {
                whereClause.append(" and ");
                if (aParamList.equals("controlNumber")) {
                    whereClause.append("upper(C.CONTROL_NUMBER)=upper('" + controlNumber + "')");
                }
                if (aParamList.equals("createDateFrom")) {
                    whereClause.append("C.DATE_REPORTED>=to_Date('" + createDateFrom + "','MM-dd-YYYY')");
                }
                if (aParamList.equals("createDateTo")) {
                    whereClause.append("C.DATE_REPORTED<=to_Date('" + createDateTo + "','MM-dd-YYYY')");
                }
                if (aParamList.equals("initiatedBy")) {
                    whereClause.append("upper(C.REPORT_INITIATOR) like upper('" + initiatedBy + "%')");
                }
                if (aParamList.equals("status")) {
                    whereClause.append("C.STATUS_ID=" + status);
                }
                if (aParamList.equals("region")) {
                    whereClause.append("(C.REGION_ID=" + region + " OR C.RESPONSIBLE_REGION_ID=" + region + ")");
                }
                if (aParamList.equals("claimNumber")) {
                    whereClause.append("C.CLAIM_NUMBER='" + claimNumber + "'");
                }
                if (aParamList.equals("filingLoc")) {
                    whereClause.append("C.REPORTING_LOCATION_CODE='" + filingLoc + "'");
                }
                if (aParamList.equals("responsibleLoc")) {
                    whereClause.append("C.RESPONSIBLE_PLANT_CODE='" + responsibleLoc + "'");
                }
                if (aParamList.equals("carFlag")) {
                    whereClause.append("C.CAR_FLAG='" + carFlag + "'");
                }
                if (aParamList.equals("complaintBusinessId")) {
                    whereClause.append("C.COMPLAINT_BUSINESS_ID=" + complaintBusinessId);
                }
                if (aParamList.equals("functionId")) {
                    whereClause.append("C.LOCATION_FUNCTION_ID=" + functionId);
                }
                if (aParamList.equals("generator")) {
                    whereClause.append("C.CPAR_SOURCE_TYPE_ID=" + Integer.parseInt(generator));
                }
                if (aParamList.equals("findingType")) {
                    whereClause.append("C.FINDING_TYPE_ID=" + Integer.parseInt(findingType));
                }
                if (aParamList.equals("filingProgramId") && !StringUtils.isNullOrEmpty(filingProgramId)) {
                    whereClause.append("CPP.FILING_PROGRAM=" + Integer.parseInt(filingProgramId));
                }
                if (aParamList.equals("responsibleProgramId") && !StringUtils.isNullOrEmpty(responsibleProgramId)) {
                    whereClause.append("CPP.RESPONSIBLE_PROGRAM=").append(Integer.parseInt(responsibleProgramId));
                }
                if (aParamList.equals("isoStandardId") && !StringUtils.isNullOrEmpty(isoStandardId)) {
                    whereClause.append("C.ISO_STANDARD_ID=").append(isoStandardId);
                }
                if (aParamList.equals("siteManager") && !StringUtils.isNullOrEmpty(siteManager)) {
                    whereClause.append("C.SITE_MANAGER like upper('" + siteManager + "%')");
                }

                if (aParamList.equals("closingDate")) {
                    whereClause.append("C.CLOSING_DATE<=to_Date('" + closingDate + "','MM-dd-YYYY')");
                }

                if (aParamList.equals("crop_id")) {
                    whereClause.append("C.CROP_ID=").append(cropId);
                }
            }

            if (functionalAreaIdList != null) {
                whereClause.append(" AND aa.AUDIT_AREA_ID IN ( ")
                        .append(buildInClause(functionalAreaIdList)).append(" )");
            }

            addTextSearchConditions(whereClause, searchText);
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_COUNT_CPARS_LIST + whereClause.toString());
            ps.setInt(1, businessPreferenceId);
            ps.setInt(2, type);
            lastSQL =
                    CparDAOSQLConstants.GET_COUNT_CPARS_LIST + whereClause.toString() + ": 1=" + businessPreferenceId + " 2=" +
                            type;
//            System.err.println(lastSQL);
            rs = ps.executeQuery();
            if (rs.next()) {
                cpars = new LinkedHashMap<String, Object>();
                cpars.put("maxRows", rs.getString(1));
            }


            //This appends to second query GET_CPARS_LIST
            if ("DATE_REPORTED".equals(sortCrit)) {
                whereClause.append(" ORDER BY ").append(sortCrit).append(" ").append(sortOrd)
                        .append(" ))  WHERE RANKING BETWEEN ").append((Page * 10) - 9).append(" and ").append(Page * 10);
            } else {
                whereClause.append(" ORDER BY Lower(").append(sortCrit).append(") ").append(sortOrd)
                        .append(" ))  WHERE RANKING BETWEEN ").append((Page * 10) - 9).append(" and ").append(Page * 10);
            }

            closeDBResources(null, ps, rs);

            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPARS_LIST + whereClause.toString());
            ps.setInt(1, businessPreferenceId);
            ps.setInt(2, type);
            lastSQL =
                    CparDAOSQLConstants.GET_CPARS_LIST + whereClause.toString() + ": 1=" + businessPreferenceId + " 2=" + type;
            System.err.println(lastSQL);
            rs = ps.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (rs.next()) {
                CparList cparList = new CparList();
                cparList.setCparId(rs.getString("CPAR_ID"));

                cparList.setControlNumber(rs.getString("CONTROL_NUMBER"));

                Date date = rs.getDate("DATE_REPORTED");
                String dateString = null;
                if (date != null) dateString = sdf.format(date);
                cparList.setCreatedDate(dateString);

                Date closedDate = rs.getDate("CLOSING_DATE");
                String dateStringClosed = null;
                if (closedDate != null) dateStringClosed = sdf.format(closedDate);
                cparList.setClosingDate(dateStringClosed);

                cparList.setInitiatedBy(rs.getString("REPORT_INITIATOR"));
                cparList.setInvestigationFindings(trimInvestigationText(
                        rs.getString("INVESTIGATION_FINDINGS")));//Display the Investigation Findings description

                int statusId = rs.getInt("STATUS_ID");
                String statusDesc = iService.translate(locale, "STATUS_REF", statusId, rs.getString("STATUS_DESCRIPTION"));
                cparList.setStatus(statusDesc);

                int regionId = rs.getInt("REGION_ID");
                String regionDesc = iService.translate(locale, "REGION_REF", regionId, rs.getString("REGION_DESCRIPTION"));
                cparList.setRegion(regionDesc);

                cparList.setFilingProgram(rs.getString("FILING_PROGRAM"));
                cparList.setResponsibleProgram(rs.getString("RESPONSIBLE_PROGRAM"));
                cparList.setBusinessId(Integer.toString(businessPreferenceId));
                if (rs.getString("CLAIM_NUMBER") != null) {
                    cparList.setClaimNumber(rs.getString("CLAIM_NUMBER"));
                } else {
                    cparList.setClaimNumber("");
                }
                cpars.put(rs.getString("CPAR_ID"), cparList);

            }
            return cpars;
        } catch (SQLException e) {
            MCASLogUtil.logError(lastSQL, e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private String trimInvestigationText(String investigationFindings) {
        return MCASUtil.trimDescriptionText(investigationFindings);
    }

    public void getCparMain(int cpar_id, Cpar c, Connection conn) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_MAIN);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                setCparMain(c, rs);
                c.setLocationOtherInfo(getLocationOtherInfoDao(conn).read(c.getCpar_id()));
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void addTextSearchConditions(StringBuffer buff, String searchText) {

        if (!StringUtils.isNullOrEmpty(searchText)) {
            buff.append(" and (lower(cd.investigation_findings) like lower('%");
            buff.append(searchText);
            buff.append("%') or lower(cd.long_term_correction_action) like lower('%");
            buff.append(searchText);
            buff.append("%') or lower(cd.root_cause) like lower('%");
            buff.append(searchText);
            buff.append("%') or lower(cd.containment_action) like lower('%");
            buff.append(searchText);
            buff.append("%') or lower(cd.evaluation_comments) like lower('%");
            buff.append(searchText);
            buff.append("%') or lower(cd.mgmt_approval_comments) like lower('%");
            buff.append(searchText);
            buff.append("%'))");
        }
    }

    private String[] getComplaintIds(String cparId) {
        ComplaintService complaintService = new ComplaintServiceImpl();
        return complaintService.getComplaintIdsFromCparId(cparId);
    }

    private void setCparMain(Cpar c, ResultSet rs) throws SQLException {
        c.setCpar_id(rs.getString("CPAR_ID"));
        c.setResponsibleRegionId(rs.getString("RESPONSIBLE_REGION_ID"));
        c.setStop_sale_id(rs.getString("STOP_SALE_ID"));
        c.setAudit_finding_id(rs.getString("AUDIT_FINDING_ID"));
        //todo: get these from complaint
        c.setComplaint_id(getComplaintIds(c.getCpar_id()));
        //c.setComplaint_id(rs.getString("COMPLAINT_ID"));
        c.setCreated_by(rs.getString("CREATED_BY"));
        c.setGenerator(rs.getString("CPAR_SOURCE_TYPE_ID"));
        c.setCar_flag(rs.getString("CAR_FLAG"));
        c.setClaim_number(rs.getString("CLAIM_NUMBER"));
        c.setStatus_id(rs.getString("STATUS_ID"));
        c.setInitiated_by(rs.getString("REPORT_INITIATOR"));
        c.setFiling_location(rs.getString("REPORTING_LOCATION_CODE"));
        c.setResponsible_location(rs.getString("RESPONSIBLE_PLANT_CODE"));
        c.setFinding_type(rs.getString("FINDING_TYPE_ID"));
        c.setIso_standard(rs.getString("ISO_STANDARD_ID"));
        c.setQuality_standard(rs.getString("QUALITY_PROGRAM_ID"));
        c.setIssue_year(rs.getString("ISSUE_YEAR_ID"));
        c.setReport_date(getDateFormat(rs.getDate("DATE_REPORTED")));
        c.setEvaluation_date(getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
        c.setEffectiveness_evaluator(rs.getString("EVAL_FOR_EFFECT_TYPE_ID"));
        c.setSite_manager(rs.getString("SITE_MANAGER"));
        c.setRow_entry_date(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
        c.setRegion(rs.getString("REGION_ID"));
        c.setControl_number(rs.getString("CONTROL_NUMBER"));
        c.setSuppress_overdue_notice(rs.getBoolean("SUPPRESS_OVERDUE_NOTICE"));
        if (StringUtils.isNullOrEmpty(c.getResponsibleRegionId())) {
            c.setResponsibleRegionId(c.getRegion());
        }
        c.setReport_initiator_email(rs.getString("REPORT_INITIATOR_EMAIL"));
        c.setRow_user_id(rs.getString("ROW_USER_ID"));
        c.setCostOfQuality(rs.getString("COST_OF_QUALITY_COMMENTS"));
        c.setCostOfQualityNumeric(rs.getString("COST_OF_QUALITY"));
        c.setComplaintBusinessId(rs.getString("COMPLAINT_BUSINESS_ID"));
        c.setFunctionId(rs.getString("LOCATION_FUNCTION_ID"));
        c.setBusinessId(rs.getInt("BUSINESS_ID"));
        c.setDeleted(rs.getString("IS_DELETED"));
        c.setType(rs.getInt("TYPE"));
        c.setClosingPersonId(rs.getString("CLOSING_PERSON"));
        c.setClosingDate(getDateFormat(rs.getDate("CLOSING_DATE")));
        c.setIssueCategoryId(rs.getString("ISSUE_CATEGORY_ID"));
        c.setOrganization(rs.getString("ORGANIZATION_ID"));
        c.setDepartmentAffectedId(rs.getString("DEPARTMENT_ID"));
        c.setExpectedDate(getDateFormat(rs.getDate("ESTIMATED_COMPLETION")));
        c.setSourceCparId(rs.getString("SOURCE_CPAR_ID"));
        c.setSourceControlNumber(rs.getString("SOURCE_CONTROL_NUMBER"));
        c.setCrop_id(rs.getString("CROP_ID"));
        c.setReport_due_date(getDateFormat(rs.getDate("DATE_DUE_REPORTED")));
        //String dueDateExt=rs.getString("DUE_DATE_EXT");
        c.setMgt_app_extension(c.isSuppress_overdue_notice()?"true":"false");
        c.setSiteManagerUserId(rs.getString("SITE_MANAGER_USER_ID"));
        c.setReport_initiator_id(rs.getString("REPORT_INITIATOR_USER_ID"));

        setContinualImprovements(rs, c);
    }

    public void getCparResponsibility(int cpar_id, Cpar c, Connection conn) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_RESPONSIBILITY);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                setCparResponsibility(c, rs);
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setCparResponsibility(Cpar c, ResultSet rs) throws SQLException {
        c.setMgmt_approval_person(rs.getString("MGMT_APPROVAL_PERSON"));
        c.setMgmt_approval_date(getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
        c.setLong_term_corrective_action_person(rs.getString("LONG_TERM_CORRECT_ACT_PERSON"));
        c.setLong_term_corrective_action_date(getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
        c.setLong_term_corrective_action_items_complete(
                "Y".equalsIgnoreCase(rs.getString("LONG_TERM_ACTION_ITEMS_COMP")));
        c.setRoot_cause_person(rs.getString("ROOT_CAUSE_PERSON"));
        c.setRoot_cause_date(getDateFormat(rs.getDate("ROOT_CAUSE_DATE")));
        c.setContainment_actions_person(rs.getString("CONTAINMENT_ACTION_PERSON"));
        c.setContainment_actions_date(getDateFormat(rs.getDate("CONTAINMENT_ACTION_DATE")));
        c.setEvaluation_person(rs.getString("EVAL_RESPONSIBLE_PERSON"));
        c.setEvaluation_date(getDateFormat(rs.getDate("EVAL_DATE")));
        c.setEvaluation_effective(rs.getString("EVAL_EFFECTIVE"));
        c.setEvaluation_not_applicable(rs.getBoolean("EVAL_PERSON_NOTAPPLICABLE"));
        c.setInvestigation_findings_person(rs.getString("INV_FINDINGS_ASSIGN_PERSON"));
        c.setInvestigation_findings_date(getDateFormat(rs.getDate("INV_FINDINGS_ASSIGN_DATE")));
    }

    public void getCparDocumentation(int cpar_id, Cpar c, Connection conn) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_DOCUMENTATION);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                setCparDocumentation(c, rs);
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void getCparDocumentationForBiotech(int cpar_id, Cpar c, Connection conn) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_DOCUMENTATION);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                setCparDocumentationForBiotech(c, rs);
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setCparDocumentation(Cpar c, ResultSet rs) throws SQLException {

        c.setInvestigation_findings(rs.getString("INVESTIGATION_FINDINGS"));
        c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
        c.setLong_term_implemented_action(rs.getString("LONG_TERM_IMPLEMENTED_ACTION"));
        c.setRoot_cause(rs.getString("ROOT_CAUSE"));
        c.setContainment_actions(rs.getString("CONTAINMENT_ACTION"));
        c.setEvaluation_comments(rs.getString("EVALUATION_COMMENTS"));
        c.setMgmt_approval_comments(rs.getString("MGMT_APPROVAL_COMMENTS"));
    }

    private void setCparDocumentationForBiotech(Cpar c, ResultSet rs) throws SQLException {

        if(c.getType() == 4){
        //For CI

            if((rs.getString("INVESTIGATION_FINDINGS") != null) && (rs.getString("INVESTIGATION_FINDINGS").contains("IF:"))){
                c.setInvestigation_findings(rs.getString("INVESTIGATION_FINDINGS")==null?"":rs.getString("INVESTIGATION_FINDINGS"));
                c.setRoot_cause(rs.getString("ROOT_CAUSE")==null?"":rs.getString("ROOT_CAUSE"));
                c.setContainment_actions(rs.getString("CONTAINMENT_ACTION")==null?"":rs.getString("CONTAINMENT_ACTION"));

            }else{
                c.setInvestigation_findings(rs.getString("INVESTIGATION_FINDINGS"));
            }

            if((rs.getString("LONG_TERM_CORRECTION_ACTION") != null) && (rs.getString("LONG_TERM_CORRECTION_ACTION").contains("LTCA:"))){
                c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION")==null?"":rs.getString("LONG_TERM_CORRECTION_ACTION"));
                c.setEvaluation_comments(rs.getString("EVALUATION_COMMENTS")==null?"":rs.getString("EVALUATION_COMMENTS"));
                c.setMgmt_approval_comments(rs.getString("MGMT_APPROVAL_COMMENTS")==null?"":rs.getString("MGMT_APPROVAL_COMMENTS"));

            }else{
                c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
            }
        }else{
        //not CI, this for CAR & PAR
          c.setInvestigation_findings(rs.getString("INVESTIGATION_FINDINGS"));
          c.setLong_term_corrective_action(rs.getString("LONG_TERM_CORRECTION_ACTION"));
          c.setRoot_cause(rs.getString("ROOT_CAUSE"));
          c.setContainment_actions(rs.getString("CONTAINMENT_ACTION"));
          c.setEvaluation_comments(rs.getString("EVALUATION_COMMENTS"));
          c.setMgmt_approval_comments(rs.getString("MGMT_APPROVAL_COMMENTS"));
        }
        c.setLong_term_implemented_action(rs.getString("LONG_TERM_IMPLEMENTED_ACTION"));
    }

    public void getCparAttachment(int cpar_id, Cpar c, Connection conn) throws SQLException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_ATTACHMENT);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                setCparAttachment(c, rs);
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setCparAttachment(Cpar c, ResultSet rs) throws SQLException, MCASException {
        String documentId = rs.getString("DOCUMENT_ID");
        String complaintId = rs.getString("CPAR_ID");
        String documentName = rs.getString("DOCUMENT_NAME");
        AttachmentInfo attachmentInfo = new AttachmentInfo(complaintId, documentId, documentName);
        c.getCparAttachments().put(documentId, attachmentInfo);
    }

    public void getCparProgram(int cpar_id, Cpar c, Connection conn) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_PROGRAM);
            ps.setInt(1, cpar_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                setCparProgram(c, rs);
            }
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setCparProgram(Cpar c, ResultSet rs) throws SQLException {
        c.setFilingProgramId(rs.getString("FILING_PROGRAM"));
        c.setResponsibleProgramId(rs.getString("RESPONSIBLE_PROGRAM"));
//        c.setSubFunctionId(rs.getInt("SUBFUNCTION_ID"));
    }


    public Cpar getCpar(String cpar_id, boolean isBIOTECHFAS) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Cpar c = new Cpar();

        int id = Integer.parseInt(cpar_id);

        try {
            conn = getConnection();

            getCparMain(id, c, conn);
            getCparResponsibility(id, c, conn);
            if(c.getType()==4 && isBIOTECHFAS)
                getCparDocumentationForBiotech(id, c, conn);
            else
                getCparDocumentation(id, c, conn);
            getCparAttachment(id, c, conn);
            getCparProgram(id, c, conn);
            getCparSubFunctions(id, c, conn);
            getIssues(id, c, conn);

            return c;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Cpar getCparByControlNo(String control_no, int business_id) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Cpar c = new Cpar();


        try {
            conn = getConnection();

            ps = conn.prepareStatement("select cpar_id from cpar where control_number = ? and business_id = ?");
            ps.setString(1, control_no);
            ps.setInt(2, business_id);
            rs = ps.executeQuery();

            if (rs.next()) {
                int id = rs.getInt(1);
                getCparMain(id, c, conn);
                getCparResponsibility(id, c, conn);
                getCparDocumentation(id, c, conn);
                getCparAttachment(id, c, conn);
                getCparProgram(id, c, conn);
                getCparSubFunctions(id, c, conn);
                getIssues(id, c, conn);

                return c;
            }

            return null;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    private void getIssues(int cpar_id, Cpar cpar, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_ISSUES);
            ps.setInt(1, (cpar_id));

            rs = ps.executeQuery();
            IssueList<Issue> issues = new IssueList<Issue>();
            while (rs.next()) {
                setIssues(rs, issues);
            }
            cpar.setIssues(issues);
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setIssues(ResultSet rs, List<Issue> issues) throws SQLException {
        issues.add(new Issue(rs.getLong("QUALITY_PROGRAM_ID"), rs.getString("DESCRIPTION"), true));
    }

    private void setContinualImprovements(ResultSet rs, Cpar cpar) throws SQLException {
        cpar.setContinual_Improvements("1");
        if (CparConstants.GEN_FINDING_OBJ_TYPE_PAR == cpar.getType()) {
            if ((rs.getString("CONTROL_NUMBER")).startsWith("CI-")) {
                cpar.setContinual_Improvements("2");
            }
        }
    }

    private void getCparSubFunctions(int cpar_id, Cpar c, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_SUBFUNCTION);
            ps.setInt(1, cpar_id);

            rs = ps.executeQuery();
            StringBuffer subFunctionSelected = new StringBuffer();

            while (rs.next()) {
                setSubfunction(rs, subFunctionSelected);
            }
            String[] subFunctions = subFunctionSelected.toString().split(",");
            c.setSubFunctionsSelected(subFunctions);
        } catch (SQLException e) {
            MCASLogUtil.logError("SQLException while sub function details: ", e);
        } catch (Exception e) {
            MCASLogUtil.logError("Exception while getting sub function details: ", e);
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void setSubfunction(ResultSet rs, StringBuffer subFunctionSelected) throws SQLException {
        subFunctionSelected.append(rs.getString(1)).append(",");
    }

    public Map<String, RowBean> getCparReport(CparFilter cparFilter, int businessId, String locale) throws DAOException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause = new StringBuffer();
        Map<String, RowBean> hash = new HashMap<String, RowBean>();

        try {
            conn = getConnection();

            whereClause.append(" AND CPAR.CAR_FLAG = '").append(cparFilter.getCarFlag().trim()).append("' ");

            if ((cparFilter.getControlNumber() != null) && !(cparFilter.getControlNumber().equals(""))) {
                whereClause.append(" AND UPPER(CPAR.CONTROL_NUMBER) LIKE UPPER('").append(cparFilter.getControlNumber().trim())
                        .append("%') ");
            }
            if ((cparFilter.getClaimNumber() != null) && !(cparFilter.getClaimNumber().equals(""))) {
                whereClause.append(" AND UPPER(CPAR.CLAIM_NUMBER) LIKE UPPER('").append(cparFilter.getClaimNumber().trim())
                        .append("%') ");
            }
            if ((cparFilter.getInitiatedBy() != null) && !(cparFilter.getInitiatedBy().equals(""))) {
                whereClause.append(" AND UPPER(CPAR.REPORT_INITIATOR) LIKE UPPER('").append(cparFilter.getInitiatedBy().trim())
                        .append("%') ");
            }
            if ((cparFilter.getFilingLocation() != null) && (cparFilter.getFilingLocation().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.REPORTING_LOCATION_CODE IN ", cparFilter.getFilingLocation()));
            }
            if ((cparFilter.getResponsibleLocation() != null) && (cparFilter.getResponsibleLocation().length > 0)) {
                whereClause
                        .append(getSelectedFields(" AND CPAR.RESPONSIBLE_PLANT_CODE IN ", cparFilter.getResponsibleLocation()));
            }
            if ((cparFilter.getStatus() != null) && (cparFilter.getStatus().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.STATUS_ID IN ", cparFilter.getStatus()));
            }
            if ((cparFilter.getYearOfIssue() != null) && (cparFilter.getYearOfIssue().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.ISSUE_YEAR_ID IN ", cparFilter.getYearOfIssue()));
            }
            if ((cparFilter.getRegion() != null) && (cparFilter.getRegion().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.REGION_ID IN ", cparFilter.getRegion()));
            }
            if ((cparFilter.getGenerator() != null) && (cparFilter.getGenerator().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.CPAR_SOURCE_TYPE_ID IN ", cparFilter.getGenerator()));
            }
            if ((cparFilter.getEffectivenessEvaluation() != null) && (cparFilter.getEffectivenessEvaluation().length > 0)) {
                whereClause.append(
                        getSelectedFields(" AND CPAR.EVAL_FOR_EFFECT_TYPE_ID IN ", cparFilter.getEffectivenessEvaluation()));
            }
            if ((cparFilter.getFindingType() != null) && (cparFilter.getFindingType().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.FINDING_TYPE_ID IN ", cparFilter.getFindingType()));
            }
            if ((cparFilter.getIsoElement() != null) && (cparFilter.getIsoElement().length > 0)) {
                whereClause.append(getSelectedFields(" AND CPAR.ISO_STANDARD_ID IN ", cparFilter.getIsoElement()));
            }
            if ((cparFilter.getComplaintBusinessId() != null) && !(cparFilter.getComplaintBusinessId().equals(""))) {
                whereClause.append(" AND CPAR.COMPLAINT_BUSINESS_ID = '").append(cparFilter.getComplaintBusinessId().trim())
                        .append("' ");
            }
            if ((cparFilter.getFunctionId() != null) && !(cparFilter.getFunctionId().equals(""))) {
                whereClause.append(" AND CPAR.LOCATION_FUNCTION_ID = '").append(cparFilter.getFunctionId().trim()).append("' ");
            }
            //Selected Complaint Categories
            if (!cparFilter.isNonconformanceCategoryIdListEmpty()) {
                whereClause.append(" AND COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID IN ( ")
                        .append(buildInClause(cparFilter.getNonconformanceCategoryIdList())).append(" )");
            }
            //Selected Audit Areas
            if (!cparFilter.isFunctionalAreaIdListEmpty()) {
                whereClause.append(" AND M_AUDIT_AREAS_REF.AREA_ID IN ( ")
                        .append(buildInClause(cparFilter.getFunctionalAreaIdList())).append(" )");
            }
            whereClause.append(" AND CPAR.BUSINESS_ID = ").append(businessId);
            whereClause.append(" ) ORDER BY CONTROL_NUMBER ");

//            logger.info(CparDAOSQLConstants.GET_CPAR_REPORT + whereClause.toString());

            String outputString = CparDAOSQLConstants.GET_CPAR_REPORT + whereClause.toString();
//            System.out.println("outputString = " + outputString);
            ps = conn.prepareStatement(outputString);

            rs = ps.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            int rowCount = 0;
            while (rs.next()) {

                rowCount++;

                //** Fill in the RowBean Object...
                RowBean rowBean = new RowBean();

                if (rs.getString("CONTROL_NUMBER") != null && !(rs.getString("CONTROL_NUMBER").trim().equals(""))) {
                    rowBean.setCol(1, rs.getString("CONTROL_NUMBER"));
                } else {
                    rowBean.setCol(1, "-");
                }
                if (rs.getString("GENERATOR") != null && !(rs.getString("GENERATOR").trim().equals(""))) {

                    int id = rs.getInt("CPAR_SOURCE_TYPE_ID");
                    String desc = iService.translate(locale, "CPAR_SOURCE_TYPE_REF", id, rs.getString("GENERATOR"));

                    rowBean.setCol(2, desc);

                } else {
                    rowBean.setCol(2, "-");
                }
                if (rs.getString("CAR_FLAG") != null && !(rs.getString("CAR_FLAG").trim().equals(""))) {
                    rowBean.setCol(3, rs.getString("CAR_FLAG"));
                } else {
                    rowBean.setCol(3, "-");
                }
                if (rs.getString("STATUS") != null && !(rs.getString("STATUS").trim().equals(""))) {
                    rowBean.setCol(4, rs.getString("STATUS"));
                } else {
                    rowBean.setCol(4, "-");
                }
                if (rs.getString("INITIATED_BY") != null && !(rs.getString("INITIATED_BY").trim().equals(""))) {
                    rowBean.setCol(5, rs.getString("INITIATED_BY"));
                } else {
                    rowBean.setCol(5, "-");
                }
                if (rs.getString("REPORTING_LOCATION_CODE") != null &&
                        !(rs.getString("REPORTING_LOCATION_CODE").trim().equals(""))) {
                    rowBean.setCol(6, rs.getString("REPORTING_LOCATION_CODE"));
                } else {
                    rowBean.setCol(6, "-");
                }
                if (rs.getString("RESPONSIBLE_PLANT_CODE") != null &&
                        !(rs.getString("RESPONSIBLE_PLANT_CODE").trim().equals(""))) {
                    rowBean.setCol(7, rs.getString("RESPONSIBLE_PLANT_CODE"));
                } else {
                    rowBean.setCol(7, "-");
                }
                if (rs.getString("FINDING_TYPE") != null && !(rs.getString("FINDING_TYPE").trim().equals(""))) {

                    int id = rs.getInt("FINDING_TYPE_ID");
                    String desc = iService.translate(locale, "FINDING_TYPE_REF", id, rs.getString("FINDING_TYPE"));

                    rowBean.setCol(8, desc);
                } else {
                    rowBean.setCol(8, "-");
                }
                if (rs.getString("ISO_STANDARD_NUMBER") != null && !(rs.getString("ISO_STANDARD_NUMBER").trim().equals(""))) {
                    rowBean.setCol(9, rs.getString("ISO_STANDARD_NUMBER"));
                } else {
                    rowBean.setCol(9, "-");
                }
                if (rs.getString("ISO_ELEMENT") != null && !(rs.getString("ISO_ELEMENT").trim().equals(""))) {

                    int id = rs.getInt("ISO_STANDARD_ID");

                    String desc = iService.translate(locale, "ISO_STANDARD_REF", id, rs.getString("ISO_ELEMENT"));

                    rowBean.setCol(10, desc);
                } else {
                    rowBean.setCol(10, "-");
                }

                if (rs.getString("YEAR_OF_ISSUE") != null && !(rs.getString("YEAR_OF_ISSUE").trim().equals(""))) {
                    rowBean.setCol(11, rs.getString("YEAR_OF_ISSUE"));
                } else {
                    rowBean.setCol(11, "-");
                }
                if (rs.getDate("DATE_REPORTED") != null) {
                    rowBean.setCol(12, getDateFormat(rs.getDate("DATE_REPORTED")));
                } else {
                    rowBean.setCol(12, "-");
                }
                if (rs.getDate("EVAL_FOR_EFFECT_DATE") != null) {
                    rowBean.setCol(13, getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
                } else {
                    rowBean.setCol(13, "-");
                }
                if (rs.getString("EFFECT_EVAL") != null && !(rs.getString("EFFECT_EVAL").trim().equals(""))) {

                    int id = rs.getInt("EVAL_FOR_EFFECT_TYPE_ID");

                    String desc = iService.translate(locale, "EVAL_FOR_EFFECT_TYPE_REF", id, rs.getString("EFFECT_EVAL"));

                    rowBean.setCol(14, desc);
                } else {
                    rowBean.setCol(14, "-");
                }
                if (rs.getString("SITE_MANAGER") != null && !(rs.getString("SITE_MANAGER").trim().equals(""))) {
                    rowBean.setCol(15, rs.getString("SITE_MANAGER"));
                } else {
                    rowBean.setCol(15, "-");
                }
                if (rs.getString("REGION") != null && !(rs.getString("REGION").trim().equals(""))) {
                    rowBean.setCol(16, rs.getString("REGION"));
                } else {
                    rowBean.setCol(16, "-");
                }
                if (rs.getString("CLAIM_NUMBER") != null && !(rs.getString("CLAIM_NUMBER").trim().equals(""))) {
                    rowBean.setCol(17, rs.getString("CLAIM_NUMBER"));
                } else {
                    rowBean.setCol(17, "-");
                }
                if (rs.getString("CREATED_BY") != null && !(rs.getString("CREATED_BY").trim().equals(""))) {
                    rowBean.setCol(18, rs.getString("CREATED_BY"));
                } else {
                    rowBean.setCol(18, "-");
                }
                if (rs.getString("REPORT_INITIATOR_EMAIL") != null &&
                        !(rs.getString("REPORT_INITIATOR_EMAIL").trim().equals(""))) {
                    rowBean.setCol(19, rs.getString("REPORT_INITIATOR_EMAIL"));
                } else {
                    rowBean.setCol(19, "-");
                }
                if (rs.getString("ROW_USER_ID") != null && !(rs.getString("ROW_USER_ID").trim().equals(""))) {
                    rowBean.setCol(20, rs.getString("ROW_USER_ID"));
                } else {
                    rowBean.setCol(20, "-");
                }

                if (rs.getString("ROW_TASK_ID") != null && !(rs.getString("ROW_TASK_ID").trim().equals(""))) {
                    rowBean.setCol(21, rs.getString("ROW_TASK_ID"));
                } else {
                    rowBean.setCol(21, "-");
                }
                if (rs.getDate("ROW_ENTRY_DATE") != null) {
                    rowBean.setCol(22, getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
                } else {
                    rowBean.setCol(22, "-");
                }
                if (rs.getDate("ROW_MODIFY_DATE") != null) {
                    rowBean.setCol(23, getDateFormat(rs.getDate("ROW_MODIFY_DATE")));
                } else {
                    rowBean.setCol(23, "-");
                }
                if (rs.getString("INVESTIGATION_FINDINGS") != null &&
                        !(rs.getString("INVESTIGATION_FINDINGS").trim().equals(""))) {
                    rowBean.setCol(24, rs.getString("INVESTIGATION_FINDINGS"));
                } else {
                    rowBean.setCol(24, "-");
                }
                if (rs.getString("CONTAINMENT_ACTION") != null && !(rs.getString("CONTAINMENT_ACTION").trim().equals(""))) {
                    rowBean.setCol(25, rs.getString("CONTAINMENT_ACTION"));
                } else {
                    rowBean.setCol(25, "-");
                }
                if (rs.getString("ROOT_CAUSE") != null && !(rs.getString("ROOT_CAUSE").trim().equals(""))) {
                    rowBean.setCol(26, rs.getString("ROOT_CAUSE"));
                } else {
                    rowBean.setCol(26, "-");
                }
                if (rs.getString("LONG_TERM_CORRECTION_ACTION") != null &&
                        !(rs.getString("LONG_TERM_CORRECTION_ACTION").trim().equals(""))) {
                    rowBean.setCol(27, rs.getString("LONG_TERM_CORRECTION_ACTION"));
                } else {
                    rowBean.setCol(27, "-");
                }
                if (rs.getString("EVALUATION_COMMENTS") != null && !(rs.getString("EVALUATION_COMMENTS").trim().equals(""))) {
                    rowBean.setCol(28, rs.getString("EVALUATION_COMMENTS"));
                } else {
                    rowBean.setCol(28, "-");
                }

                if (rs.getString("MGMT_APPROVAL_PERSON") != null && !(rs.getString("MGMT_APPROVAL_PERSON").trim().equals(""))) {
                    rowBean.setCol(29, rs.getString("MGMT_APPROVAL_PERSON"));
                } else {
                    rowBean.setCol(29, "-");
                }
                if (rs.getDate("MGMT_APPROVAL_DATE") != null) {
                    rowBean.setCol(30, getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
                } else {
                    rowBean.setCol(30, "-");
                }
                if (rs.getString("CONTAINMENT_ACTION_PERSON") != null &&
                        !(rs.getString("CONTAINMENT_ACTION_PERSON").trim().equals(""))) {
                    rowBean.setCol(31, rs.getString("CONTAINMENT_ACTION_PERSON"));
                } else {
                    rowBean.setCol(31, "-");
                }
                if (rs.getDate("CONTAINMENT_ACTION_DATE") != null) {
                    rowBean.setCol(32, getDateFormat(rs.getDate("CONTAINMENT_ACTION_DATE")));
                } else {
                    rowBean.setCol(32, "-");
                }
                if (rs.getString("ROOT_CAUSE_PERSON") != null && !(rs.getString("ROOT_CAUSE_PERSON").trim().equals(""))) {
                    rowBean.setCol(33, rs.getString("ROOT_CAUSE_PERSON"));
                } else {
                    rowBean.setCol(33, "-");
                }
                if (rs.getDate("ROOT_CAUSE_DATE") != null) {
                    rowBean.setCol(34, getDateFormat(rs.getDate("ROOT_CAUSE_DATE")));
                } else {
                    rowBean.setCol(34, "-");
                }
                if (rs.getString("LONG_TERM_CORRECT_ACT_PERSON") != null &&
                        !(rs.getString("LONG_TERM_CORRECT_ACT_PERSON").trim().equals(""))) {
                    rowBean.setCol(35, rs.getString("LONG_TERM_CORRECT_ACT_PERSON"));
                } else {
                    rowBean.setCol(35, "-");
                }

                if (rs.getDate("LONG_TERM_CORRECT_ACT_DATE") != null) {
                    rowBean.setCol(36, getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
                } else {
                    rowBean.setCol(36, "-");
                }
                if (rs.getString("EVAL_RESPONSIBLE_PERSON") != null &&
                        !(rs.getString("EVAL_RESPONSIBLE_PERSON").trim().equals(""))) {
                    rowBean.setCol(37, rs.getString("EVAL_RESPONSIBLE_PERSON"));
                } else {
                    rowBean.setCol(37, "-");
                }
                if (rs.getDate("EVAL_DATE") != null) {
                    rowBean.setCol(38, getDateFormat(rs.getDate("EVAL_DATE")));
                } else {
                    rowBean.setCol(38, "-");
                }

                //MCAS Enhancement: Added Cost_Of_Quality to CAR/PAR report
                if (!StringUtils.isNullOrEmpty(rs.getString("COST_OF_QUALITY"))) {
                    rowBean.setCol(39, rs.getString("COST_OF_QUALITY"));
                } else {
                    rowBean.setCol(39, "-");
                }
                if (!StringUtils.isNullOrEmpty(rs.getString("COMPLAINT_BUSINESS_ID"))) {
                    rowBean.setCol(40, rs.getString("COMPLAINT_BUSINESS_ID"));
                } else {
                    rowBean.setCol(40, "-");
                }
                if (!StringUtils.isNullOrEmpty(rs.getString("LOCATION_FUNCTION_ID"))) {
                    rowBean.setCol(41, rs.getString("LOCATION_FUNCTION_ID"));
                } else {
                    rowBean.setCol(41, "-");
                }
                if (rs.getString("BUSINESS_ID") != null && !(rs.getString("BUSINESS_ID").trim().equals(""))) {
                    rowBean.setCol(42, rs.getString("BUSINESS_ID"));
                } else {
                    rowBean.setCol(42, "-");
                }
                //For Displaying Audit Areas
                if (rs.getString("DESCRIPTION") != null && !(rs.getString("DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol(43, rs.getString("DESCRIPTION"));
                } else {
                    rowBean.setCol(43, "-");
                }
                //For Displaying Complaint Categories
                if (rs.getString("COMPLAINT_ISSUE_DESCRIPTION") != null &&
                        !(rs.getString("COMPLAINT_ISSUE_DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol(44, rs.getString("COMPLAINT_ISSUE_DESCRIPTION"));
                } else {
                    rowBean.setCol(44, "-");
                }
                rowBean.setCol(45, rs.getString("SUPPRESS_OVERDUE_NOTICE"));

                if(rs.getString("DATE_DUE_REPORTED")!=null){
                    rowBean.setCol(51,getDateFormat(rs.getDate("DATE_DUE_REPORTED")));
                    }
                else{
                    rowBean.setCol(51, "-");
                    }
                if(rs.getString("SUPPRESS_OVERDUE_NOTICE")!=null){
                    rowBean.setCol(52,rs.getBoolean("SUPPRESS_OVERDUE_NOTICE")?"Y":"Ns4");
                    }
                else{
                    rowBean.setCol(52, "-");
                    }

                //        if(rs.getString("SUPPRESS_OVERDUE_NOTICE") == null || "0".equalsIgnoreCase(rs.getString("SUPPRESS_OVERDUE_NOTICE")))
//          rowBean.setCol45("N");
//        else
//          rowBean.setCol45("Y");
                //System.out.println("rowCount = " + rowCount);
                hash.put(rowCount + "", rowBean);

            }

            return hash;
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, RowBean> getCparLog(CparLog cparLog) throws DAOException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause = new StringBuffer();
        Map<String, RowBean> hash = new HashMap<String, RowBean>();

        List<String> paramList = new ArrayList<String>();

        try {
            if (cparLog.getCparFlag() != null && !(cparLog.getCparFlag().equals("")) &&
                    !(cparLog.getCparFlag().equals("0"))) {
                paramList.add("cparFlag");
            }
            if (cparLog.getResponsibleLocation() != null && cparLog.getResponsibleLocation().length > 0) {
                paramList.add("responsibleLocation");
            }
            if ((cparLog.getYearOfIssue() != null) && (cparLog.getYearOfIssue().length > 0)) {
                paramList.add("yearOfIssue");
            }
            if ((cparLog.getFunctionId() != null) && !(cparLog.getFunctionId().equals(""))) {
                paramList.add("functionId");
            }
            if (cparLog.getRegion() != null && cparLog.getRegion().length > 0) {
                paramList.add("regionId");
            }

            for (String aParamList : paramList) {
                if (aParamList.equals("cparFlag")) {
                    if (cparLog.getCparFlag().equals("1")) {
                        whereClause.append("AND CPAR.CAR_FLAG = 'Y' ");
                    }
                    if (cparLog.getCparFlag().equals("2")) {
                        whereClause.append(" AND CPAR.CAR_FLAG = 'N' ");
                    }
                }
                if (aParamList.equals("responsibleLocation")) {
                    whereClause
                            .append(getSelectedFields(" AND CPAR.RESPONSIBLE_PLANT_CODE IN ", cparLog.getResponsibleLocation()));
                }
                if (aParamList.equals("yearOfIssue")) {
                    whereClause.append(getSelectedFields(" AND CPAR.ISSUE_YEAR_ID IN ", cparLog.getYearOfIssue()));
                }
                if (aParamList.equals("regionId")) {
                    whereClause.append(getSelectedFields(" AND CPAR.REGION_ID IN ", cparLog.getRegion()));
                }
                if (aParamList.equals("functionId")) {
                    whereClause.append(" AND CPAR.LOCATION_FUNCTION_ID = '").append(cparLog.getFunctionId()).append("' ");
                }
            }

            conn = getConnection();

            if (paramList.size() > 0) {
                String s = CparDAOSQLConstants.GET_CPAR_LOG + whereClause.toString();
//                logger.info(s);
//                System.out.println("s = " + s);
                ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_LOG + whereClause.toString());
            } else {
//                logger.info(CparDAOSQLConstants.GET_CPAR_LOG);
                ps = conn.prepareStatement(CparDAOSQLConstants.GET_CPAR_LOG);
            }

            rs = ps.executeQuery();

            int rowCount = 0;
            while (rs.next()) {

                rowCount++;

                //** Fill in the RowBean Object...
                RowBean rowBean = new RowBean();

                if (rs.getString("CONTROL_NUMBER") != null && !(rs.getString("CONTROL_NUMBER").trim().equals(""))) {
                    rowBean.setCol(1, rs.getString("CONTROL_NUMBER"));
                } else {
                    rowBean.setCol(1, "-");
                }
                if (rs.getDate("DATE_REPORTED") != null) {
                    rowBean.setCol(2, getDateFormat(rs.getDate("DATE_REPORTED")));
                } else {
                    rowBean.setCol(2, "-");
                }
                if (rs.getString("INVESTIGATION_FINDINGS") != null &&
                        !(rs.getString("INVESTIGATION_FINDINGS").trim().equals(""))) {
                    rowBean.setCol(3, rs.getString("INVESTIGATION_FINDINGS"));
                } else {
                    rowBean.setCol(3, "-");
                }
                if (rs.getDate("MGMT_APPROVAL_DATE") != null) {
                    rowBean.setCol(4, getDateFormat(rs.getDate("MGMT_APPROVAL_DATE")));
                } else {
                    rowBean.setCol(4, "-");
                }
                if (rs.getDate("LONG_TERM_CORRECT_ACT_DATE") != null) {
                    rowBean.setCol(5, getDateFormat(rs.getDate("LONG_TERM_CORRECT_ACT_DATE")));
                } else {
                    rowBean.setCol(5, "-");
                }
                if (rs.getDate("EVAL_FOR_EFFECT_DATE") != null) {
                    rowBean.setCol(6, getDateFormat(rs.getDate("EVAL_FOR_EFFECT_DATE")));
                } else {
                    rowBean.setCol(6, "-");
                }
                if (rs.getString("STATUS_DESCRIPTION") != null && !(rs.getString("STATUS_DESCRIPTION").trim().equals(""))) {
                    rowBean.setCol(7, rs.getString("STATUS_DESCRIPTION"));
                } else {
                    rowBean.setCol(7, "-");
                }
                if (rs.getString("AUDIT_NUMBER") != null && !(rs.getString("AUDIT_NUMBER").trim().equals(""))) {
                    rowBean.setCol(8, rs.getString("AUDIT_NUMBER"));
                } else {
                    rowBean.setCol(8, "-");
                }
                if (rs.getString("LOCATION_FUNCTION_ID") != null && !(rs.getString("LOCATION_FUNCTION_ID").trim().equals(""))) {
                    rowBean.setCol(9, rs.getString("LOCATION_FUNCTION_ID"));
                } else {
                    rowBean.setCol(9, "-");
                }
                if (rs.getString("BUSINESS_ID") != null && !(rs.getString("BUSINESS_ID").trim().equals(""))) {
                    rowBean.setCol(10, rs.getString("BUSINESS_ID"));
                } else {
                    rowBean.setCol(10, "-");
                }

                hash.put(rowCount + "", rowBean);

            }

            return hash;
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public boolean addCPARAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException {
        PreparedStatement ps = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.ADD_CPAR_ATTACHMENT);
            ps.setString(1, attachmentInfo.getDocumentId());
            ps.setInt(2, Integer.parseInt(attachmentInfo.getEntityId()));
            ps.setString(3, attachmentInfo.getDocumentName());
            ps.executeUpdate();
            conn.commit();
            return true;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    public boolean deleteCPARAttachmentInfo(String documentId) throws DAOException {
        PreparedStatement ps = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CparDAOSQLConstants.DELETE_CPAR_ATTACHMENT);
            ps.setString(1, documentId);
            ps.executeUpdate();
            conn.commit();
            return true;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    /**
     * This method just makes a string out of selected fields like ('1744', '1745',...)
     *
     * @param strArray
     * @return StringBuffer
     */
    private StringBuffer getSelectedFields(String query, String[] strArray) {

        int size = strArray.length;

        StringBuffer fieldClause = new StringBuffer();
        fieldClause.append("");

        //**To remove the null elements...
        for (int i = 0; i < size; i++) {

            if (strArray[i].equals("") || strArray[i].equals("0")) {
                size--;
            }
        }

        if (size == 0) {
            return fieldClause;
        }

        fieldClause.append(query).append("(");

        for (int i = 0; i < strArray.length; i++) {

            //**Skip null elements...
            if (strArray[i].equals("") || strArray[i].equals("0")) {
                continue;
            }

            fieldClause.append("'").append(strArray[i].trim()).append("'");

            if (i < strArray.length - 1) {
                fieldClause.append(",");
            }
        }

        fieldClause.append(")");

        return fieldClause;
    }


    private int insertCparDocumentation(Cpar c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(CparDAOSQLConstants.UPDATE_CPAR_DOCUMENTATION_SQL);
                ps.setLong(12, Long.parseLong(c.getCpar_id()));
            } else {
                ps = conn.prepareStatement(CparDAOSQLConstants.CPAR_DOCUMENTATION_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getCpar_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getInvestigation_findings());
            ps.setString(paramIndx + 1, c.getLong_term_corrective_action());
            ps.setString(paramIndx + 2, c.getRoot_cause());
            ps.setString(paramIndx + 3, c.getContainment_actions());
            ps.setString(paramIndx + 4, c.getEvaluation_comments());
            ps.setString(paramIndx + 5, "APPLICATION");
            ps.setString(paramIndx + 6, "CPAR ENTRY");
            ps.setDate(paramIndx + 7, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 8, new Date(new java.util.Date().getTime()));
            ps.setString(paramIndx + 9, c.getMgmt_approval_comments());
            ps.setString(paramIndx + 10, c.getLong_term_implemented_action());
            rows = ps.executeUpdate();
            conn.commit();
            return rows;
        } catch (Exception e) {

            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    private int insertCparResponsibility(Cpar c, Connection conn, boolean isUpdate) throws DAOException {
        PreparedStatement ps = null;

        int rows = 0;
        int paramIndx = 1;
        try {
            if (isUpdate) {
                ps = conn.prepareStatement(CparDAOSQLConstants.UPDATE_CPAR_RESPONSIBILITY_SQL);
                ps.setLong(20, Long.parseLong(c.getCpar_id()));
            } else {
                ps = conn.prepareStatement(CparDAOSQLConstants.CPAR_RESPONSIBILITY_SQL);
                ps.setLong(paramIndx, Long.parseLong(c.getCpar_id()));
                paramIndx++;
            }
            ps.setString(paramIndx, c.getMgmt_approval_person());
            setDefaultDateIfNull(c.getMgmt_approval_date(), ps, paramIndx, 1);
            ps.setString(paramIndx + 2, c.getLong_term_corrective_action_person());
            setDefaultDateIfNull(c.getLong_term_corrective_action_date(), ps, paramIndx, 3);
            ps.setString(paramIndx + 4, c.isLong_term_corrective_action_items_complete() ? "Y" : "N");
            ps.setString(paramIndx + 5, c.getRoot_cause_person());
            setDefaultDateIfNull(c.getRoot_cause_date(), ps, paramIndx, 6);
            ps.setString(paramIndx + 7, c.getContainment_actions_person());
            setDefaultDateIfNull(c.getContainment_actions_date(), ps, paramIndx, 8);
            ps.setString(paramIndx + 9, c.getEvaluation_person());
            setDefaultDateIfNull(c.getEvaluation_date(), ps, paramIndx, 10);
            ps.setString(paramIndx + 11, c.getEvaluation_effective());
            ps.setBoolean(paramIndx + 12, c.isEvaluation_not_applicable());
            ps.setString(paramIndx + 13, "APPLICATION");
            if (c.getCar_flag().equals("Y")) {
                ps.setString(paramIndx + 14, "CAR ENTRY");
            } else {
                ps.setString(paramIndx + 14, "PAR ENTRY");
            }
            ps.setDate(paramIndx + 15, new Date(new java.util.Date().getTime()));
            ps.setDate(paramIndx + 16, new Date(new java.util.Date().getTime()));

            ps.setString(paramIndx + 17, c.getInvestigation_findings_person());
            setDefaultDateIfNull(c.getInvestigation_findings_date(), ps, paramIndx, 18);

            rows = ps.executeUpdate();
            conn.commit();
            return rows;
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }

    private String getDateFormat(Date date) {
        try {

            if (date == null) return "";

            return sdf.format(date);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }


    /**
     * Private method to parse the selected Complaint Issue IDs
     *
     * @param idList
     * @return
     */
    private String buildInClause(List<Integer> idList) {
        return MCASUtil.buildInClause(idList);
    }

    private void setDefaultIntegerIfNull(String data, PreparedStatement ps, int parameterIndx, int i) throws
            SQLException {
        if (!StringUtils.isNullOrEmpty(data)) {
            ps.setLong(parameterIndx + i, Long.parseLong(data));
        } else {
            ps.setNull(parameterIndx + i, Types.INTEGER);
        }
    }


    private void setDefaultDateIfNull(String data, PreparedStatement ps, int paramIndx, int i) throws SQLException {
        if (!StringUtils.isNullOrEmpty(data)) {
            ps.setDate(paramIndx + i, new Date(new java.util.Date(data).getTime()));
        } else {
            ps.setDate(paramIndx + i, null);
        }
    }

    private void setParametersOnUpdate(Cpar cpar, boolean isUpdate, PreparedStatement ps, int parameterIndx) throws
            SQLException {
        String cparInsertEditFlag = "";
        Date cparDate = null;
        if (isUpdate) {
            cparInsertEditFlag = "Y".equalsIgnoreCase(cpar.getCar_flag()) ? "CAR EDIT" : "PAR EDIT";
            cparDate = new Date(new java.util.Date(cpar.getRow_entry_date()).getTime());
            //ps.setInt(parameterIndx + 28, cpar.getType());
            //ps.setString(parameterIndx + 29, cpar.getClosingPersonId());
            ps.setInt(parameterIndx + 29, cpar.getType());
            ps.setString(parameterIndx + 30, cpar.getClosingPersonId());
            setDefaultDateIfNull(cpar.getClosingDate(), ps, parameterIndx, 31);
        } else {
            cparInsertEditFlag = "Y".equalsIgnoreCase(cpar.getCar_flag()) ? "CAR ENTRY" : "PAR ENTRY";
            cparDate = new Date(new java.util.Date().getTime());
            ps.setString(parameterIndx + 29, "N");
            ps.setInt(parameterIndx + 30, cpar.getType());
        }
        ps.setString(parameterIndx + 16, cparInsertEditFlag);
        ps.setDate(parameterIndx + 17, cparDate);
    }
}
