package com.monsanto.wst.ccas.dao;

/**
 * Date: Aug 12, 2009 Time: 12:20:30 PM To change this template use File | Settings | File Templates.
 */
class CparDAOSQLConstants {
    public static final String GET_CPAR_PROGRAM = "select FILING_PROGRAM, RESPONSIBLE_PROGRAM FROM CPAR_PROGRAM WHERE CPAR_ID = ?";

    static final String CPAR_PK_SQL = "select CPAR_SEQ.nextval from dual";

    static final String UPDATE_CPAR_SQL = "UPDATE CPAR SET " +
            "STOP_SALE_ID=?, AUDIT_FINDING_ID=?," +
            " COMPLAINT_ID=?, CPAR_SOURCE_TYPE_ID=?," +
            " CAR_FLAG=?, CLAIM_NUMBER=?,STATUS_ID=?, REPORT_INITIATOR=?," +
            " REPORTING_LOCATION_CODE=?, RESPONSIBLE_PLANT_CODE=?, FINDING_TYPE_ID=?," +
            " ISO_STANDARD_ID=?, ISSUE_YEAR_ID=?, DATE_REPORTED=?, SITE_MANAGER=?," +
            " ROW_USER_ID=?, ROW_TASK_ID=?, ROW_ENTRY_DATE=?," +
            " ROW_MODIFY_DATE=?, REGION_ID=?, CONTROL_NUMBER=?, CREATED_BY=?, REPORT_INITIATOR_EMAIL=?, " +
            " SUPPRESS_OVERDUE_NOTICE=?, COST_OF_QUALITY=?, COST_OF_QUALITY_COMMENTS=?, COMPLAINT_BUSINESS_ID=?, " +
            " LOCATION_FUNCTION_ID=? , BUSINESS_ID=?,TYPE=?, CLOSING_PERSON = ?, CLOSING_DATE = ?, " +
            " RESPONSIBLE_REGION_ID=?, ISSUE_CATEGORY_ID = ?, ORGANIZATION_ID = ?, ESTIMATED_COMPLETION = ?, DEPARTMENT_ID = ?, REPORT_INITIATOR_USER_ID = ?, SITE_MANAGER_USER_ID = ?,  " +
            " CROP_ID=?,DATE_DUE_REPORTED=? "  +
            " WHERE CPAR_ID=?";

    static final String UPDATE_CPAR_DOCUMENTATION_SQL = "UPDATE CPAR_DOCUMENTATION SET " +
            "INVESTIGATION_FINDINGS=?, LONG_TERM_CORRECTION_ACTION=?, " +
            "ROOT_CAUSE=?, CONTAINMENT_ACTION=?, EVALUATION_COMMENTS=?, ROW_USER_ID=?, " +
            "ROW_TASK_ID=?, ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=?, MGMT_APPROVAL_COMMENTS=?, LONG_TERM_IMPLEMENTED_ACTION=?" +
            "WHERE CPAR_ID=?";


    static final String UPDATE_CPAR_RESPONSIBILITY_SQL = "UPDATE CPAR_RESPONSIBILITY SET " +
            "MGMT_APPROVAL_PERSON=?, MGMT_APPROVAL_DATE=?, " +
            "LONG_TERM_CORRECT_ACT_PERSON=?, LONG_TERM_CORRECT_ACT_DATE=?, LONG_TERM_ACTION_ITEMS_COMP = ?, ROOT_CAUSE_PERSON=?,  " +
            "ROOT_CAUSE_DATE=?, CONTAINMENT_ACTION_PERSON=?, CONTAINMENT_ACTION_DATE=?, " +
            "EVAL_RESPONSIBLE_PERSON=?, EVAL_DATE=?, EVAL_EFFECTIVE=?, EVAL_PERSON_NOTAPPLICABLE=?, " +
            "ROW_USER_ID=?, ROW_TASK_ID=?, ROW_MODIFY_DATE=?, ROW_ENTRY_DATE=?, INV_FINDINGS_ASSIGN_PERSON=?, " +
            "INV_FINDINGS_ASSIGN_DATE=? " +
            "WHERE CPAR_ID=?";


    static final String  CPAR_SQL = "INSERT INTO CPAR (" +
            " CPAR_ID, STOP_SALE_ID, AUDIT_FINDING_ID, " +
            "COMPLAINT_ID, CPAR_SOURCE_TYPE_ID, " +
            "CAR_FLAG, CLAIM_NUMBER,STATUS_ID, REPORT_INITIATOR, " +
            "REPORTING_LOCATION_CODE, RESPONSIBLE_PLANT_CODE, FINDING_TYPE_ID,  " +
            "ISO_STANDARD_ID, ISSUE_YEAR_ID, DATE_REPORTED, SITE_MANAGER, " +
            "ROW_USER_ID, ROW_TASK_ID, ROW_ENTRY_DATE, " +
            "ROW_MODIFY_DATE, REGION_ID, CONTROL_NUMBER, CREATED_BY, REPORT_INITIATOR_EMAIL," +
            " SUPPRESS_OVERDUE_NOTICE, COST_OF_QUALITY, COST_OF_QUALITY_COMMENTS, COMPLAINT_BUSINESS_ID, " +
            " LOCATION_FUNCTION_ID, BUSINESS_ID,IS_DELETED,TYPE, RESPONSIBLE_REGION_ID, ISSUE_CATEGORY_ID, " +
            " ORGANIZATION_ID, ESTIMATED_COMPLETION, DEPARTMENT_ID, REPORT_INITIATOR_USER_ID, SITE_MANAGER_USER_ID,CROP_ID,DATE_DUE_REPORTED) " +
            "VALUES (? ,? ,? ," +
            "? ,? ," +
            "? ,? ,? , ?," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? ,? ," +
            "? ,? , ? ,?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?, ?,?,?)";

    static final String CPAR_DOCUMENTATION_SQL = "INSERT INTO CPAR_DOCUMENTATION ( " +
            "CPAR_ID, INVESTIGATION_FINDINGS, LONG_TERM_CORRECTION_ACTION, " +
            "ROOT_CAUSE, CONTAINMENT_ACTION, EVALUATION_COMMENTS, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_MODIFY_DATE, ROW_ENTRY_DATE, MGMT_APPROVAL_COMMENTS,LONG_TERM_IMPLEMENTED_ACTION) " +
            "VALUES ( ?, ?, ?, " +
            "?, ?, ?, " +
            "?, ?, ?, ?, ?, ?)";

    static final String CPAR_RESPONSIBILITY_SQL = "INSERT INTO CPAR_RESPONSIBILITY ( " +
            "CPAR_ID, MGMT_APPROVAL_PERSON, MGMT_APPROVAL_DATE, " +
            "LONG_TERM_CORRECT_ACT_PERSON, LONG_TERM_CORRECT_ACT_DATE, LONG_TERM_ACTION_ITEMS_COMP, ROOT_CAUSE_PERSON, " +
            "ROOT_CAUSE_DATE, CONTAINMENT_ACTION_PERSON, CONTAINMENT_ACTION_DATE, " +
            "EVAL_RESPONSIBLE_PERSON, EVAL_DATE, EVAL_EFFECTIVE, EVAL_PERSON_NOTAPPLICABLE, " +
            "ROW_USER_ID, ROW_TASK_ID, ROW_MODIFY_DATE, " +
            "ROW_ENTRY_DATE, INV_FINDINGS_ASSIGN_PERSON, INV_FINDINGS_ASSIGN_DATE) " +
            "VALUES ( ?, ?, ?," +
            " ?, ?, ?, ?," +
            " ?, ?, ?," +
            " ?, ?, ?, ?," +
            " ?, ?, ?," +
            " ?, ?, ?)";

    static final String GET_CPAR_MAIN = "SELECT distinct cp.*, st.quality_program_id FROM cpar cp left outer join iso_standard_ref ST on ST.iso_standard_id = cp.iso_standard_id where cp.cpar_id = ?";

    static final String GET_CPAR_DOCUMENTATION = "SELECT * FROM CPAR_DOCUMENTATION WHERE CPAR_ID=?";
    static final String GET_CPAR_RESPONSIBILITY = "SELECT * FROM CPAR_RESPONSIBILITY WHERE CPAR_ID=?";
    static final String GET_CPARS_LIST =
            "          SELECT  Ranking, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, STATUS_ID, STATUS_DESCRIPTION, REPORT_INITIATOR, DATE_REPORTED, CLOSING_DATE, " +
                    "          REGION_ID, REGION_DESCRIPTION,INVESTIGATION_FINDINGS, FILING_PROGRAM, RESPONSIBLE_PROGRAM FROM " +
                    "          (" +
                    "          SELECT ROWNUM as RANKING, CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, " +
                    "          STATUS_ID, STATUS_DESCRIPTION, REPORT_INITIATOR, DATE_REPORTED, CLOSING_DATE,  " +
                    "          REGION_ID, REGION_DESCRIPTION,INVESTIGATION_FINDINGS, FILING_PROGRAM, RESPONSIBLE_PROGRAM FROM " +
                    "            (" +
                    "              SELECT C.CPAR_ID, CONTROL_NUMBER, CLAIM_NUMBER, C.STATUS_ID, " +
                    "              (SELECT S.STATUS_DESCRIPTION FROM STATUS_REF S WHERE S.STATUS_ID=C.STATUS_ID) STATUS_DESCRIPTION, REPORT_INITIATOR, DATE_REPORTED, CLOSING_DATE, REGION_ID," +
                    "              (SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=C.REGION_ID) REGION_DESCRIPTION," +
                    "              (SELECT CD.INVESTIGATION_FINDINGS FROM CPAR_DOCUMENTATION CD WHERE CD.CPAR_ID=C.CPAR_ID) INVESTIGATION_FINDINGS," +
                    "              (SELECT PROGRAM_DESC FROM PROGRAM_REF P, CPAR_PROGRAM CP WHERE CP.FILING_PROGRAM = P.PROGRAM_ID AND C.CPAR_ID = CP.CPAR_ID(+)) FILING_PROGRAM," +
                    "              (SELECT PROGRAM_DESC FROM PROGRAM_REF P, CPAR_PROGRAM CP WHERE CP.RESPONSIBLE_PROGRAM = P.PROGRAM_ID AND C.CPAR_ID = CP.CPAR_ID(+)) RESPONSIBLE_PROGRAM " +
                    "              FROM M_AUDIT_AREAS aa, CPAR_DOCUMENTATION CD, CPAR C, CPAR_PROGRAM CPP WHERE c.cpar_id = CPP.cpar_id(+) and c.BUSINESS_ID=? AND c.IS_DELETED='N' AND c.TYPE =? " +
                    "                   and CD.cpar_id = c.cpar_id and c.cpar_id = aa.AUDIT_ID(+)";

    static final String GET_COUNT_CPARS_LIST = "SELECT COUNT(C.CPAR_ID) FROM M_AUDIT_AREAS aa, CPAR_DOCUMENTATION cd, CPAR C, CPAR_PROGRAM CPP \n" +
            "where CPP.CPAR_ID(+) = C.CPAR_ID and IS_DELETED = 'N' AND BUSINESS_ID=? AND TYPE=? and cd.cpar_id = c.cpar_id " +
            "and c.cpar_id = aa.AUDIT_ID(+)";
    //static final String GET_COUNT_CPARS_LIST = "SELECT COUNT(C.CPAR_ID) FROM CPAR C WHERE IS_DELETED = 'N' AND BUSINESS_ID=? AND TYPE=? ";


    static final String FIND_CONTROL_NUMBER = "SELECT COUNT(CPAR_ID) RECORDS FROM CPAR C WHERE IS_DELETED = 'N' AND upper(CONTROL_NUMBER)=upper('";

    static final String FIND_CAR = "SELECT c.CPAR_ID,cp.CONTROL_NUMBER FROM CPAR cp, complaint c WHERE c.cpar_id = cp.cpar_id and cp.IS_DELETED = 'N' AND cp.CAR_FLAG = ? AND c.COMPLAINT_ID = ?";

    static final String FIND_CONTROL_NUMBER_TEXT = "SELECT CONTROL_NUMBER FROM CPAR WHERE IS_DELETED = 'N' AND COMPLAINT_ID = ";

    static final String UPDATE_STOP_SALE_DOC =
            "UPDATE " +
                    "STOP_SALE_DOCUMENTATION " +
                    "SET " +
                    "ROOT_CAUSE = ?, " +
                    "LONG_TERM_CORRECTION_ACTION = ? " +
                    "WHERE " +
                    "STOP_SALE_ID = (SELECT STOP_SALE_ID FROM CPAR WHERE CPAR_ID = ?)";

    static final String GET_CPAR_REPORT =
            "SELECT " +
                    "CPAR.CONTROL_NUMBER, " +
                    "CPAR_SOURCE_TYPE_REF.CPAR_SOURCE_TYPE_ID," +
                    "CPAR_SOURCE_TYPE_REF.DESCRIPTION GENERATOR, " +
                    "CPAR.CAR_FLAG," +
                    "STATUS_REF.STATUS_DESCRIPTION STATUS, " +
                    "CPAR.REPORT_INITIATOR INITIATED_BY, " +
                    "CPAR.REPORTING_LOCATION_CODE, " +
                    "CPAR.RESPONSIBLE_PLANT_CODE, " +
                    "CPAR.FINDING_TYPE_ID, " +
                    "FINDING_TYPE_REF.DESCRIPTION FINDING_TYPE, " +
                    "ISO_STANDARD_REF.ISO_STANDARD_ID, " +
                    "ISO_STANDARD_REF.STANDARD_NUMBER ISO_STANDARD_NUMBER, " +
                    "ISO_STANDARD_REF.DESCRIPTION ISO_ELEMENT, " +
                    "YEAR_REF.SHORT_DESCRIPTION YEAR_OF_ISSUE, " +
                    "CPAR.DATE_REPORTED, " +
                    "CPAR.EVAL_FOR_EFFECT_DATE, " +
                    "CPAR.EVAL_FOR_EFFECT_TYPE_ID, " +
                    "EVAL_FOR_EFFECT_TYPE_REF.DESCRIPTION EFFECT_EVAL, " +
                    "CPAR.SITE_MANAGER, " +
                    "REGION_REF.REGION_DESCRIPTION REGION, " +
                    "CPAR.CLAIM_NUMBER, " +
                    "CPAR.CREATED_BY, " +
                    "CPAR.REPORT_INITIATOR_EMAIL, " +
                    "CPAR.ROW_USER_ID, " +
                    "CPAR.ROW_TASK_ID, " +
                    "CPAR.ROW_ENTRY_DATE, " +
                    "CPAR.ROW_MODIFY_DATE, " +
                    "CPAR.COST_OF_QUALITY, " +
                    "CPAR.COMPLAINT_BUSINESS_ID, " +
                    "CPAR.LOCATION_FUNCTION_ID, " +
                    "CPAR.BUSINESS_ID, " +
                    "CPAR_DOCUMENTATION.INVESTIGATION_FINDINGS, " +
                    "CPAR_DOCUMENTATION.LONG_TERM_IMPLEMENTED_ACTION, " +
                    "CPAR_DOCUMENTATION.CONTAINMENT_ACTION, " +
                    "CPAR_DOCUMENTATION.ROOT_CAUSE, " +
                    "CPAR_DOCUMENTATION.LONG_TERM_CORRECTION_ACTION, " +
                    "CPAR_DOCUMENTATION.EVALUATION_COMMENTS, " +
                    "CPAR_RESPONSIBILITY.MGMT_APPROVAL_PERSON, " +
                    "CPAR_RESPONSIBILITY.MGMT_APPROVAL_DATE, " +
                    "CPAR_RESPONSIBILITY.CONTAINMENT_ACTION_PERSON, " +
                    "CPAR_RESPONSIBILITY.CONTAINMENT_ACTION_DATE, " +
                    "CPAR_RESPONSIBILITY.ROOT_CAUSE_PERSON, " +
                    "CPAR_RESPONSIBILITY.ROOT_CAUSE_DATE, " +
                    "CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_PERSON, " +
                    "CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_DATE, " +
                    "CPAR_RESPONSIBILITY.EVAL_RESPONSIBLE_PERSON, " +
                    "CPAR_RESPONSIBILITY.EVAL_DATE,  " +
                    "M_AUDIT_AREAS_REF.DESCRIPTION, " +
                    "COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_DESCRIPTION, " +
                    "CPAR.SUPPRESS_OVERDUE_NOTICE,  " +
                    "CPAR.DATE_DUE_REPORTED  " +
                    "  " +

                    "FROM " +

                    "CPAR, " +
                    "CPAR_DOCUMENTATION, " +
                    "CPAR_RESPONSIBILITY, " +
                    "CPAR_SOURCE_TYPE_REF, " +
                    "STATUS_REF, " +
                    "FINDING_TYPE_REF, " +
                    "ISO_STANDARD_REF, " +
                    "YEAR_REF, " +
                    "EVAL_FOR_EFFECT_TYPE_REF, " +
                    "REGION_REF,  " +
                    "M_AUDIT_AREAS," +
                    "M_AUDIT_AREAS_REF," +
                    "COMPLAINT_ISSUE_REF," +
                    "COMPLAINT_ISSUES " +
                    "WHERE ( " +
                    "(CPAR.CPAR_ID = CPAR_DOCUMENTATION.CPAR_ID(+)) " +
                    "AND CPAR.IS_DELETED = 'N' " +
                    "AND (CPAR.CPAR_ID = CPAR_RESPONSIBILITY.CPAR_ID(+)) " +
                    "AND (CPAR_SOURCE_TYPE_REF.CPAR_SOURCE_TYPE_ID(+) =CPAR.CPAR_SOURCE_TYPE_ID) " +
                    "AND (STATUS_REF.STATUS_ID(+) = CPAR.STATUS_ID) " +
                    "AND (FINDING_TYPE_REF.FINDING_TYPE_ID(+) = CPAR.FINDING_TYPE_ID) " +
                    "AND (ISO_STANDARD_REF.ISO_STANDARD_ID(+) = CPAR.ISO_STANDARD_ID) " +
                    "AND (YEAR_REF.YEAR_ID(+) = CPAR.ISSUE_YEAR_ID) " +
                    "AND (EVAL_FOR_EFFECT_TYPE_REF.EVAL_FOR_EFFECT_TYPE_ID(+) =CPAR.EVAL_FOR_EFFECT_TYPE_ID) " +
                    "AND (REGION_REF.REGION_ID(+) = CPAR.REGION_ID) " +
                    "AND (CPAR.CPAR_ID = M_AUDIT_AREAS.AUDIT_ID(+))" +
                    "AND (M_AUDIT_AREAS.AUDIT_AREA_ID = M_AUDIT_AREAS_REF.AREA_ID(+)) " +
                    "AND (CPAR.CPAR_ID = COMPLAINT_ISSUES.COMPLAINT_ID(+)) " +
                    "AND (COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID = COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_ID(+))" +
                    "AND ('P' = M_AUDIT_AREAS.AUDIT_AREA_SOURCE(+)) " +
                    "AND ('P' = COMPLAINT_ISSUES.COMPLAINT_ISSUE_SOURCE(+))";

    static final String GET_CPAR_LOG =
            "SELECT " +
                    "CPAR.CONTROL_NUMBER,STATUS_REF.STATUS_DESCRIPTION, CPAR.DATE_REPORTED, CPAR.BUSINESS_ID," +
                    "CPAR_DOCUMENTATION.INVESTIGATION_FINDINGS, CPAR_RESPONSIBILITY.MGMT_APPROVAL_DATE, " +
                    "CPAR_RESPONSIBILITY.LONG_TERM_CORRECT_ACT_DATE, CPAR.EVAL_FOR_EFFECT_DATE, CPAR.LOCATION_FUNCTION_ID, M_AUDIT.AUDIT_NUMBER " +
                    "FROM " +
                    "CPAR, CPAR_DOCUMENTATION, CPAR_RESPONSIBILITY, M_AUDIT, M_AUDIT_FINDINGS,STATUS_REF " +
                    "WHERE " +
                    "CPAR.CPAR_ID = CPAR_DOCUMENTATION.CPAR_ID(+) " +
                    "AND CPAR.IS_DELETED = 'N' " +
                    "AND CPAR.CPAR_ID = CPAR_RESPONSIBILITY.CPAR_ID(+) " +
                    "AND M_AUDIT.AUDIT_ID(+) = M_AUDIT_FINDINGS.AUDIT_ID " +
                    "AND M_AUDIT_FINDINGS.AUDIT_FINDING_ID(+) = CPAR.AUDIT_FINDING_ID " +
                    "AND STATUS_REF.STATUS_ID = CPAR.STATUS_ID ";


    static final String ADD_CPAR_ATTACHMENT =
            "INSERT INTO cpar_attachment cpa " +
                    "            (cpa.document_id, cpa.cpar_id, cpa.document_name " +
                    "            ) " +
                    "     VALUES (?, ?, ? " +
                    "            ) ";

    static final String DELETE_CPAR_ATTACHMENT =
            "DELETE FROM cpar_attachment cpa " +
                    "      WHERE cpa.document_id = ? ";

    static final String DELETE_CPAR = "UPDATE CPAR SET IS_DELETED='Y',AUDIT_FINDING_ID = NULL WHERE CPAR_ID = ?";

    static final String GET_CPAR_ATTACHMENT =
            "SELECT cpa.document_id, cpa.cpar_id, cpa.document_name " +
                    "  FROM cpar_attachment cpa " +
                    " WHERE cpa.cpar_id = ? ";
    static final String INSERT_CPAR_PROGRAM = "INSERT INTO CPAR_PROGRAM (FILING_PROGRAM,RESPONSIBLE_PROGRAM,SUBFUNCTION_ID,CPAR_ID) VALUES(?, ?, ?, ?)";
    static final String UPDATE_CPAR_PROGRAM = "UPDATE CPAR_PROGRAM SET FILING_PROGRAM=?,RESPONSIBLE_PROGRAM=?,SUBFUNCTION_ID=?  WHERE CPAR_ID = ?";
    static final String INSERT_CPAR_SUBFUNCTION = "INSERT INTO CPAR_SUBFUNCTION " +
            "(ID, CPAR_ID, SUBFUNCTION_ID) " +
            "VALUES " +
            "(AUDIT_SEQ.NEXTVAL, ?, ?)";
    static final String GET_CPAR_SUBFUNCTION = "SELECT SUBFUNCTION_ID FROM CPAR_SUBFUNCTION where CPAR_ID = ?";
    public static final String GET_CPAR_ISSUES = "select iso.quality_program_id, iso.description from iso_standard_ref iso, cpar c where c.iso_standard_id = iso.iso_standard_id and c.cpar_id = ?";
    public static final String DELETE_CPAR_ISSUES = "DELETE FROM CPAR_ISSUE WHERE CPAR_ID = ?";
    public static final String INSERT_CPAR_ISSUES = "INSERT INTO CPAR_ISSUE (ISSUE_ID, CPAR_ID) VALUES (?, ?)";
    public static final String DELETE_CPAR_SUBFUNCTION = "DELETE FROM CPAR_SUBFUNCTION WHERE CPAR_ID = ?";
}
