package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Cpar;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 7, 2010
 * Time: 10:40:01 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class CparEmailDao extends BaseDAOImpl {

    public abstract Iterator<Cpar> getOverdueContainmentAction(int days, String startDate) throws DAOException;

    public abstract Iterator<Cpar> getOverdueRootCause(int days, String startDate) throws DAOException;

    public abstract Iterator<Cpar> getOverdueLongTermCorrectiveAction(int days, String startDate) throws DAOException;

    public abstract Iterator<Cpar> getOverdueEvaluationOfEffectiveness(int days, String startDate) throws DAOException;

    public abstract Iterator<Cpar> getOverdueClose(int days) throws DAOException;

    public abstract Iterator<Cpar> getOverdueApprovedWarning(int days, int overdueInterval, String startDate) throws DAOException;
}
