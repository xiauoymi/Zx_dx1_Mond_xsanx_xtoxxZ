package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.util.Iterator;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 7, 2010
 * Time: 10:45:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class CparEmailDaoImpl extends CparEmailDao {

    Connection con;
    private static final String CONTAINMENT_ACTION_SQL = "select c.cpar_id from cpar c, cpar_documentation cd, " +
            "cpar_responsibility r, status_ref where c.cpar_id = cd.cpar_id and c.cpar_id=r.cpar_id and c.car_flag='Y' and " +
            "c.is_deleted <> 'Y' and c.suppress_overdue_notice <> '1' and trim(cd.CONTAINMENT_ACTION) is null and " +
            "c.status_id = status_ref.status_id AND status_ref.status_description NOT LIKE 'Closed%' and " +
            "((r.containment_action_date is null and sysdate > c.row_entry_date + ?) or " +
            "(sysdate > r.containment_action_date)) and c.row_entry_date > to_date(?,'YYYY-MON-DD')";

    private static final String ROOT_CAUSE_SQL = "select c.cpar_id from cpar c, cpar_documentation cd, "
            + "cpar_responsibility r, status_ref where c.cpar_id = cd.cpar_id and c.cpar_id=r.cpar_id and c.car_flag='Y' and " +
            "c.status_id = status_ref.status_id AND status_ref.status_description NOT LIKE 'Closed%' and " +
            "c.is_deleted <> 'Y' and c.suppress_overdue_notice <> '1' and trim(cd.ROOT_CAUSE) is null and " +
            "((r.root_cause_date is null and sysdate > c.row_entry_date + ?) or (sysdate > r.root_cause_date))" +
            " and c.row_entry_date > to_date(?,'YYYY-MON-DD')";

    private static final String CORRECTIVE_ACTION_SQL = "select c.cpar_id from cpar c, cpar_documentation cd, " +
            "cpar_responsibility r, status_ref where c.cpar_id = cd.cpar_id and c.cpar_id=r.cpar_id and c.car_flag='Y' and " +
            "c.status_id = status_ref.status_id AND status_ref.status_description NOT LIKE 'Closed%' and " +
            "c.is_deleted <> 'Y' and c.suppress_overdue_notice <> '1' and trim(cd.LONG_TERM_CORRECTION_ACTION) is null and "
            + "((r.long_term_correct_act_date is null and sysdate > c.row_entry_date + ?) or " +
            "(sysdate > r.long_term_correct_act_date)) and c.row_entry_date > to_date(?,'YYYY-MON-DD')";

    private static final String EVALUATION_EFFECTIVENESS_SQL = "select c.cpar_id from cpar c, cpar_documentation cd, " +
            "cpar_responsibility r, status_ref where c.cpar_id = cd.cpar_id and c.cpar_id=r.cpar_id and c.car_flag='Y' and " +
            "c.status_id = status_ref.status_id AND status_ref.status_description NOT LIKE 'Closed%' and " +
            "c.is_deleted <> 'Y' and c.suppress_overdue_notice <> '1' and trim(cd.EVALUATION_COMMENTS) is null and " +
            "((r.eval_date is null and sysdate > c.row_entry_date + ?) or (sysdate > r.eval_date)) and " +
            "c.row_entry_date > to_date(?,'YYYY-MON-DD')";

    private static final String IS_CLOSED_SQL = "select c.cpar_id from cpar c, status_ref sr where \n" +
            "c.status_id = sr.status_id and c.car_flag='Y' and c.is_deleted <> 'Y' and c.suppress_overdue_notice <> '1'"
            + "and sr.status_description not like 'Closed%' and sysdate > c.row_entry_date + ?";

    private static final String OVERDUE_APPROVAL_SQL = "select c.cpar_id from cpar c, cpar_documentation cd, " +
            "cpar_responsibility r, status_ref where c.cpar_id = cd.cpar_id and c.cpar_id=r.cpar_id and c.car_flag='Y' and " +
            "c.status_id = status_ref.status_id AND status_ref.status_description NOT LIKE 'Closed%' and " +
            "c.is_deleted <> 'Y' and c.suppress_overdue_notice = '1' and trim(cd.EVALUATION_COMMENTS) is null and " +
            "((r.eval_date is null and c.row_entry_date + ? = sysdate + ?) or (sysdate + ? = r.eval_date))" +
            " and c.row_entry_date > to_date(?,'YYYY-MON-DD')";

    public CparEmailDaoImpl(Connection connection) {
        con = connection;
    }

    private Iterator<Cpar> getOverdue(String sql, int days, String startDate) throws DAOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, days);
            if (startDate != null)
                stmt.setString(2, startDate);
            rs = stmt.executeQuery();
            ArrayList<Cpar> cpars = new ArrayList<Cpar>();

            CparDAO cparDao = new CparDAOImpl();

            while (rs.next()) {
                cpars.add(cparDao.getCpar(rs.getString(1),false));
            }
            return cpars.iterator();
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, stmt, rs);
        }
    }

    private Iterator<Cpar> getOverdue(String sql, int days, int warningInterval, String startDate) throws DAOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, days);
            stmt.setInt(2, warningInterval);
            stmt.setInt(3, warningInterval);
            stmt.setString(4, startDate);
            rs = stmt.executeQuery();
            ArrayList<Cpar> cpars = new ArrayList<Cpar>();

            CparDAO cparDao = new CparDAOImpl();

            while (rs.next()) {
                cpars.add(cparDao.getCpar(rs.getString(1),false));
            }
            return cpars.iterator();
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, stmt, rs);
        }
    }


    public Iterator<Cpar> getOverdueContainmentAction(int days, String startDate) throws DAOException {
        return getOverdue(CONTAINMENT_ACTION_SQL, days, startDate);
    }

    public Iterator<Cpar> getOverdueRootCause(int days, String startDate) throws DAOException {
        return getOverdue(ROOT_CAUSE_SQL, days, startDate);
    }

    public Iterator<Cpar> getOverdueLongTermCorrectiveAction(int days, String startDate) throws DAOException {
        return getOverdue(CORRECTIVE_ACTION_SQL, days, startDate);
    }

    public Iterator<Cpar> getOverdueEvaluationOfEffectiveness(int days, String startDate) throws DAOException {
        return getOverdue(EVALUATION_EFFECTIVENESS_SQL, days, startDate);
    }

    public Iterator<Cpar> getOverdueClose(int days) throws DAOException {
        return getOverdue(IS_CLOSED_SQL, days, null);
    }

    public Iterator<Cpar> getOverdueApprovedWarning(int days, int warningPeriod, String startDate) throws DAOException {
        return getOverdue(OVERDUE_APPROVAL_SQL, days, warningPeriod, startDate);
    }
}
