/*
 * Created on Jan 19, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

/**
 * @author jbrahmb
 */
public class DAOException extends Exception {
    public DAOException(String errMsg) {
        super(errMsg);
    }

    public DAOException(Throwable err) {
        super(err);
    }

    public DAOException(String errMsg, Throwable err) {
        super(errMsg, err);
    }
}