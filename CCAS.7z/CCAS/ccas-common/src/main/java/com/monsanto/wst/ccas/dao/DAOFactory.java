/*
 * Created on Jan 19, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.DatabaseException;

import java.util.HashMap;
import java.util.Map;


/**
 * @author jbrahmb
 */
public class DAOFactory { //todo look at this more to see if it can be replaced
    private static final Map<Class<?>, Class<?>> daoMap;

    static {
        daoMap = new HashMap<Class<?>, Class<?>>();
        daoMap.put(ComplaintDAO.class, ComplaintDAOImpl.class);
        daoMap.put(LookUpDAO.class, LookUpDAOImpl.class);
        daoMap.put(CparDAO.class, CparDAOImpl.class);
        daoMap.put(UserAccountDAO.class, UserAccountDAOImpl.class);
        daoMap.put(ControlNumberDAO.class, ControlNumberDAOImpl.class);
        daoMap.put(AuditDAO.class, AuditDAOImpl.class);
        daoMap.put(StopSaleDAO.class, StopSaleDAOImpl.class);
        daoMap.put(VarietyBatchDAO.class, VarietyBatchDAOImpl.class);
        daoMap.put(MockVarietyBatchDAOImpl.class, MockVarietyBatchDAOImpl.class);
        daoMap.put(UserAdminDAO.class, UserAdminDAOImpl.class);
        daoMap.put(BusinessDao.class, BusinessDaoImpl.class);
        daoMap.put(ProgramDAO.class, ProgramDAOImpl.class);
        daoMap.put(IssueDAO.class, IssueDAOImpl.class);
        daoMap.put(SubFunctionDAO.class, SubFunctionDAOImpl.class);
        daoMap.put(LocationDAO.class, LocationDAOImpl.class);
        daoMap.put(CategoryDAO.class, CategoryDAOImpl.class);
    }

    public static Object getDao(Class<?> type) throws DAOException {
        Class<?> clazz = getImplementationClass(type);

        try {
            return clazz.newInstance();
        } catch (IllegalAccessException e) {
            throw new DatabaseException(e);
        } catch (InstantiationException e) {
            throw new DatabaseException(e);
        }
    }

    private static Class<?> getImplementationClass(Class<?> type) throws DAOException {
        if (type == null) {
            throw new NullPointerException("cannot retrieve DAO implementation for null name");
        }

        Class<?> clazz = daoMap.get(type);
        if (clazz == null) {
            throw new DAOException("could not find implementation class for name '" + type + "'");
        } else {
            return clazz;
        }
    }
}
