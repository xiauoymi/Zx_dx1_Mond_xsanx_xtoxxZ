package com.monsanto.wst.ccas.dao;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Nov 15, 2010
 * Time: 1:21:23 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class FindingTimelineDao extends BaseDAOImpl {

    public abstract String getInvestigationFindingsDueDate(String creationDate) throws DAOException;

    public abstract String getContainmentActionDueDate(String creationDate) throws DAOException;

    public abstract String getRootCauseDueDate(String creationDate) throws DAOException;

    public abstract String getLongTermCorrectiveActionDueDate(String creationDate) throws DAOException;

    public abstract String getEvaluationOfEffectivenessDueDate(String creationDate) throws DAOException;

    public abstract String getExtendedInvestigationFindingsDueDate(String extensionDueDate) throws DAOException;

    public abstract String getExtendedContainmentActionDueDate(String extensionDueDate) throws DAOException;

    public abstract String getExtendedRootCauseDueDate(String extensionDueDate) throws DAOException;

    public abstract String getExtendedLongTermCorrectiveActionDueDate(String extensionDueDate) throws DAOException;
}
