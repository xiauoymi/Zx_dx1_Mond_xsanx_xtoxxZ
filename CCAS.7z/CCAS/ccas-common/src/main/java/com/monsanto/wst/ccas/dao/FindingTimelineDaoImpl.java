package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA. User: DRMANS Date: Nov 15, 2010 Time: 1:20:18 PM To change this template use File |
 * Settings | File Templates.
 */
public class FindingTimelineDaoImpl extends FindingTimelineDao {

  private static String INVESTIGATION_FINDINGS_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + INVESTIGATION_FINDINGS_DAYS, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String CONTAINMENT_ACTION_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + CONTAINMENT_ACTION_DAYS, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String ROOT_CAUSE_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + ROOT_CAUSE_DAYS, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String CORRECTIVE_ACTION_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + CORRECTIVE_ACTION_DAYS, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String EVALUATION_EFFECTIVENESS_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + EVALUATION_EFFECTIVENESS_DAYS, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String EXTENDED_INVESTIGATION_FINDINGS_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + EXTENDED_INVESTIGATION_FINDING, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String EXTENDED_CONTAINMENT_ACTION_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + EXTENDED_CONTAINMENT_ACTION, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String EXTENDED_ROOT_CAUSE_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + EXTENDED_ROOT_CAUSE, 'MM/DD/YYYY') from FINDING_TIMELINE";
  private static String EXTENDED_CORRECTIVE_ACTION_SQL = "select to_char(to_date(?,'MM/DD/YYYY') + EXTENDED_CORRECTIVE_ACTION, 'MM/DD/YYYY') from FINDING_TIMELINE";

  private String getDate(String sql, String date) throws DAOException {
    PreparedStatement stmt = null;
    ResultSet rs = null;
    Connection con = getConnection();
    try {
      stmt = con.prepareStatement(sql);
      stmt.setString(1, date);
      rs = stmt.executeQuery();

      rs.next();
      return rs.getString(1);
    } catch (SQLException e) {
      throw new DAOException(e.getMessage(), e);
    } catch (Exception e) {
      throw new DAOException(e);
    } finally {
      MCASResourceUtil.closeDBResources(con, stmt, rs);
    }
  }
  public FindingTimelineDaoImpl() {
  }

  public String getInvestigationFindingsDueDate(String creationDate) throws DAOException {
    return getDate(INVESTIGATION_FINDINGS_SQL, creationDate);
  }

  public String getContainmentActionDueDate(String creationDate) throws DAOException {
    return getDate(CONTAINMENT_ACTION_SQL, creationDate);
  }

  public String getRootCauseDueDate(String creationDate) throws DAOException {
    return getDate(ROOT_CAUSE_SQL, creationDate);
  }

  public String getLongTermCorrectiveActionDueDate(String creationDate) throws DAOException {
    return getDate(CORRECTIVE_ACTION_SQL, creationDate);
  }

  public String getEvaluationOfEffectivenessDueDate(String creationDate) throws DAOException {
    return getDate(EVALUATION_EFFECTIVENESS_SQL, creationDate);
  }


  public String getExtendedInvestigationFindingsDueDate(String extensionDueDate) throws DAOException {
    return getDate(EXTENDED_INVESTIGATION_FINDINGS_SQL, extensionDueDate);
  }

  public String getExtendedContainmentActionDueDate(String extensionDueDate) throws DAOException {
    return getDate(EXTENDED_CONTAINMENT_ACTION_SQL, extensionDueDate);
  }

  public String getExtendedRootCauseDueDate(String extensionDueDate) throws DAOException {
    return getDate(EXTENDED_ROOT_CAUSE_SQL, extensionDueDate);
  }

  public String getExtendedLongTermCorrectiveActionDueDate(String extensionDueDate) throws DAOException {
    return getDate(EXTENDED_CORRECTIVE_ACTION_SQL, extensionDueDate);
  }
}
