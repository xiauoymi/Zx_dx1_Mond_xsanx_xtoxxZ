package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Apr 6, 2010
 * Time: 10:23:08 AM
 * To change this template use File | Settings | File Templates.
 */
public interface InternationalizationDAO {
    public String translateFromTable(String locale, String tableName, int id) throws DAOException, MCASException;

    public Integer lookupId(String locale, String tableName, String desc) throws DAOException, MCASException;
}
