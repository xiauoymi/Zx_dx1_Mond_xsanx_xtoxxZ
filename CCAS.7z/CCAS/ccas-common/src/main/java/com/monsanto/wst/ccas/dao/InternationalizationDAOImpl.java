package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Apr 6, 2010
 * Time: 10:24:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class InternationalizationDAOImpl extends BaseDAOImpl implements InternationalizationDAO {

    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private Connection conn = null;

    private static final String I18N_TRANSLATE_QUERY = "SELECT DESCRIPTION FROM LANGUAGE_BASED_REF_DATA WHERE LOCALE = ? AND TABLE_NAME = ? AND TABLE_ID = ? AND ACTIVE_FLAG = 'Y'";
    private static final String I18N_LOOKUP_QUERY = "SELECT TABLE_ID FROM LANGUAGE_BASED_REF_DATA WHERE LOCALE = ? AND TABLE_NAME = ? AND DESCRIPTION = ? AND ACTIVE_FLAG = 'Y'";

    public InternationalizationDAOImpl() {
    }

    public String translateFromTable(String locale, String tableName, int id) throws DAOException, MCASException {

        try {
            conn = getConnection();
            String showLocationListQuery = I18N_TRANSLATE_QUERY;
            ps = conn.prepareStatement(showLocationListQuery);

            ps.setString(1, locale);
            ps.setString(2, tableName);
            ps.setInt(3, id);

            rs = ps.executeQuery();
            if (rs != null) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }

        return null;
    }

    public Integer lookupId(String locale, String tableName, String desc) throws DAOException, MCASException {

        try {
            conn = getConnection();
            String showLocationListQuery = I18N_LOOKUP_QUERY;
            ps = conn.prepareStatement(showLocationListQuery);

            ps.setString(1, locale);
            ps.setString(2, tableName);
            ps.setString(3, desc);

            rs = ps.executeQuery();
            if (rs != null) {
                if (rs.next()) {
                    int id = rs.getInt(1);

                    if (rs.wasNull())
                        return null;

                    return id;
                }
            }

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }

        return null;

    }

}
