package com.monsanto.wst.ccas.dao;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 2:06:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class IssueConstants {
  public static final String ISSUE_ID = "ID";
  public static final String DESCRIPTION = "DESCRIPTION";
  public static final String LOOKUP_ISSUES_BY_REGION = "SELECT i.id, i.description FROM issue_ref i, region_issue ri, business_region_ref br WHERE i.id = ri.issue_id AND ri.region_id = br.region_id AND ri.active = 'Y' AND i.active = 'Y' AND ri.region_id = ? AND br.business_id = ?";
}
