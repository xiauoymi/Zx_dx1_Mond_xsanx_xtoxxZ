package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Issue;
import com.monsanto.wst.ccas.model.IssueList;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 1:49:00 PM To change this template use File |
 * Settings | File Templates.
 */
public interface IssueDAO {
    IssueList<Issue> lookupIssuesByRegion(String regionId, int businessId, String locale) throws SQLException, DAOException;
}
