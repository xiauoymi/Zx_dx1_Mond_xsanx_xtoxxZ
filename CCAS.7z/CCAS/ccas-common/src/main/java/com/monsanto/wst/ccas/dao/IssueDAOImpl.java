package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Issue;
import com.monsanto.wst.ccas.model.IssueList;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 1:48:52 PM To change this template use File |
 * Settings | File Templates.
 */
public class IssueDAOImpl extends BaseDAOImpl implements IssueDAO {
    public IssueList<Issue> lookupIssuesByRegion(String regionId, int businessId, String locale) throws SQLException,
            DAOException {

        Connection conn = getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = conn.prepareStatement(IssueConstants.LOOKUP_ISSUES_BY_REGION);
            ps.setString(1, regionId);
            ps.setInt(2, businessId);
            resultSet = ps.executeQuery();
            IssueList<Issue> issues = new IssueList<Issue>();
            I18nServiceImpl iService = new I18nServiceImpl();
            while (resultSet.next()) {
                long issueId = (long) resultSet.getInt(IssueConstants.ISSUE_ID);
                String description = resultSet.getString(IssueConstants.DESCRIPTION);
                String translatedDesc = iService.translate(locale, "ISSUE_REF", (int) issueId, description);
                issues.add(new Issue(issueId, translatedDesc, false));
            }
            return issues;
        }
        finally {
            closeDBResources(conn, ps, resultSet);
        }
    }
}
