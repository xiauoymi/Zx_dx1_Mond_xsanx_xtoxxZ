/*
 IssueTypeDAOImpl was created on Sep 3, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class IssueTypeDAOImpl implements IssueTypeDAO {
    private final DataSource dataSource;

    public IssueTypeDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookupAllIssuesTypesForAnIssue(String issueName, String type, String locale) {

        Map<String, String> referenceData = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            connection = dataSource.getConnection();
            String queryString = "select cir.* from ccas.complaint_issue_ref cir, ccas.complaint_issue_type_ref cref \n" +
                    "where cref.description= ? and cref.complaint_issue_type_id = cir.complaint_issue_type_id\n" +
                    "and cref.entry_type_id = ? and cir.active_flag = 'Y'";
            ps = connection.prepareStatement(
                    queryString);
            ps.setString(1, issueName);
            ps.setString(2, type);
            rs = ps.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (rs.next()) {
                int id = rs.getInt("COMPLAINT_ISSUE_ID");
                String description = iService.translate(locale, "COMPLAINT_ISSUE_REF", id, rs.getString("COMPLAINT_ISSUE_DESCRIPTION"));
                referenceData.put(Integer.toString(id), description);
            }

            return referenceData;
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new RuntimeException(e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, ps, rs);
        }
    }
}
