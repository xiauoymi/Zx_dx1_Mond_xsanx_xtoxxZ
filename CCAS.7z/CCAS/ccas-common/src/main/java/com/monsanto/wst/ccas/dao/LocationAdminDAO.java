package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 16, 2006
 * Time: 2:06:46 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LocationAdminDAO {

    Map<String, LocationInfo> getLocationList(int id, boolean isRegion) throws MCASException, DAOException;

    void updateLocation(LocationInfo locationInfo) throws DAOException, MCASException;

    void insertLocation(LocationInfo locationInfo) throws DAOException, MCASException;

    void insertOrUpdateLocationDisplayRef(String locationId, int[] displayTypes, boolean isUpdate) throws DAOException, MCASException;

    public void insertBusinessLocationreference(LocationInfo locationInfo, int businessId) throws DAOException, MCASException;

    public void insertProgramLocationreference(LocationInfo locationInfo, int businessId) throws DAOException, MCASException;

    public void updateBusinessLocationRefTable(LocationInfo locationInfo, int businessId) throws DAOException, MCASException;

    public void updateProgramLocationRefTable(LocationInfo locationInfo, int programId) throws DAOException, MCASException;
}
