package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 16, 2006
 * Time: 4:27:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationAdminDAOImpl extends BaseDAOImpl implements LocationAdminDAO {

    //why were these class variables if they are always used as locals?
//    private PreparedStatement ps = null;
//    private ResultSet rs = null;
//    private Connection conn = null;


    public LocationAdminDAOImpl() {
    }

    private static final String GET_LOCATION_LIST_QUERY =
            "SELECT l.location_code location_id, l.location_short_name location_name, " +
                    "       l.location_long_name location_long_name, blr.active_flag status, " +
                    "       l.e_mail location_email, l.owner_email location_owner_email, " +
                    "       l.email_owner_flag owner_email_status, l.region_id region_id, " +
                    "       r.region_description region_description, l.owner_email2 location_owner_email2," +
                    "l.owner_email3 location_owner_email3,l.owner_email4 location_owner_email4" +
                    " FROM location_ref l, region_ref r, business_location_ref blr  " +
                    " WHERE blr.region_id = r.region_id AND " +
                    " blr.location_code = l.location_code ";

    private static final String GET_LOCATION_LIST_QUERY_PROGRAM =
            "SELECT l.location_code location_id, l.location_short_name location_name, " +
                    "       l.location_long_name location_long_name, 'Y' status, " +
                    "       l.e_mail location_email, l.owner_email location_owner_email, " +
                    "       l.email_owner_flag owner_email_status, pl.program_id region_id, " +
                    "       p.program_desc region_description, l.owner_email2 location_owner_email2," +
                    "l.owner_email3 location_owner_email3,l.owner_email4 location_owner_email4,pl.active_flag active_flag_program" +
                    " from location_ref l, program_ref p," +
            "program_location pl  " +
                    " WHERE p.PROGRAM_ID=pl.PROGRAM_ID  and l.location_code = pl.location_code " +
            "and l.active_flag = 'Y'";



    private static final String UPDATE_LOCATION_QUERY =
            "UPDATE location_ref l " +
                    "   SET l.location_short_name = ?, " +
                    "       l.region_id = ?, " +
                    "       l.active_flag = ?, " +
                    "       l.location_long_name = ?, " +
                    "       l.e_mail = ?, " +
                    "       l.owner_email = ?, " +
                    "       l.email_owner_flag = ?," +
                    "l.owner_email2 = ?, " +
                    "l.owner_email3 = ?," +
                    "l.owner_email4 = ?" +
                    " WHERE l.location_code = ? ";

    private static final String UPDATE_BUSINESS_LOCATION_REF_QUERY =
            " UPDATE BUSINESS_LOCATION_REF BLR " +
                    " SET BLR.region_id = ?, " +
                    " BLR.active_flag = ? " +
                    " WHERE BLR.location_code = ? " +
                    " AND BLR.BUSINESS_ID = ?";


    private static final String UPDATE_PROGRAM_LOCATION_REF_QUERY =
            " UPDATE PROGRAM_LOCATION PLR " +
                    " SET PLR.PROGRAM_ID = ?, " +
                    " PLR.LOCATION_CODE = ? ," +
                    " PLR.ACTIVE_FLAG= ? "+
                    " WHERE PLR.PROGRAM_ID = ? " +
                    " AND PLR.LOCATION_CODE = ?";

    private static final String INSERT_LOCATION_QUERY =
            "INSERT INTO location_ref l " +
                    "            (l.location_code, l.location_short_name, l.active_flag, " +
                    "             l.region_id, l.location_long_name, l.e_mail, l.owner_email, " +
                    "             l.email_owner_flag, l.owner_email2, l.owner_email3, l.owner_email4 " +
                    "            ) " +
                    "     VALUES (?, ?, ?, " +
                    "             ?, ?, ?, ?, " +
                    "             ?, ?, ?, ? " +
                    "            ) ";

    private static final String INSERT_LOCATION_DISPLAY_QUERY =
            "INSERT INTO location_display_type ld (ld.location_id, ld.display_type) VALUES(?,?)";
    private static final String DELETE_LOCATION_DISPLAY =
            "DELETE FROM location_display_type ld where ld.location_id = ?";

    private static final String SELECT_LOCATION_DISPLAY =
            "SELECT '1' FROM location_display_type ld where ld.location_id = ? and ld.display_type = ?";

    private static final String SELECT_LOCATION_REF_TABLE = "SELECT COUNT(*) COUNT FROM LOCATION_REF WHERE LOCATION_CODE = ?";
    private static final String SELECT_BUSINESS_LOCATION_REF_TABLE = "SELECT COUNT(*) COUNT FROM BUSINESS_LOCATION_REF WHERE LOCATION_CODE = ? AND BUSINESS_ID = ? ";
    private static final String SELECT_PROGRAM_LOCATION_REF_TABLE = "SELECT COUNT(*) COUNT FROM PROGRAM_LOCATION WHERE LOCATION_CODE = ? AND PROGRAM_ID = ? ";
    private static final String SELECT_PROGRAM_LOCATION_MAX_ID = "SELECT MAX(ID)+1 ID FROM PROGRAM_LOCATION";
    private static final String INSERT_INTO_BUSINESS_LOCATION_REF = "INSERT INTO BUSINESS_LOCATION_REF (BUSINESS_ID,LOCATION_CODE,REGION_ID,ACTIVE_FLAG) VALUES (?, ?, ?, ?)";
    private static final String INSERT_INTO_PROGRAM_LOCATION_REF = "INSERT INTO PROGRAM_LOCATION (ID,PROGRAM_ID,LOCATION_CODE,ACTIVE_FLAG) VALUES (?,?, ?,?)";


    public Map<String, LocationInfo> getLocationList(int id, boolean isRegion) throws MCASException, DAOException {
        Map<String, LocationInfo> locationMap = new LinkedHashMap<String, LocationInfo>();
        LocationInfo locationInfo;

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            String showLocationListQuery = "";
            if(isRegion){
                showLocationListQuery=   getShowLocationListDynamicQuery(id);
            }
            else{
                showLocationListQuery=getShowLocationListDynamicQueryforProgram(id);
            }
            ps = conn.prepareStatement(showLocationListQuery);
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    locationInfo = getLocationInfoRecord(rs, isRegion);
                    locationMap.put(locationInfo.getLocationId(), locationInfo);
                }
            }
            return locationMap;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private LocationInfo getLocationInfoRecord(ResultSet rs, boolean isRegion) throws SQLException {
        String locId = rs.getString("LOCATION_ID");
        String locationName = rs.getString("LOCATION_NAME");
        boolean status = false;
        if(isRegion){
            status = getStatus(rs, "STATUS");
        }
        else{
           status = getStatus(rs, "active_flag_program");
        }
        int regionId = rs.getInt("REGION_ID");
        String locationLongName = rs.getString("LOCATION_LONG_NAME");
        String locationEmail = rs.getString("LOCATION_EMAIL");
        String locationOwnerEmail = rs.getString("LOCATION_OWNER_EMAIL");
        String locationOwnerEmail2 = rs.getString("LOCATION_OWNER_EMAIL2");
        String locationOwnerEmail3 = rs.getString("LOCATION_OWNER_EMAIL3");
        String locationOwnerEmail4 = rs.getString("LOCATION_OWNER_EMAIL4");
        boolean ownerEmailStatus = getStatus(rs, "OWNER_EMAIL_STATUS");
        String regionDesc = rs.getString("REGION_DESCRIPTION");

        return new LocationInfo(locId, locationName, locationLongName, regionId, regionDesc, status, locationEmail,
                locationOwnerEmail, ownerEmailStatus,
                locationIsResponsible(locId), locationIsFiling(locId), locationIsReporting(locId), locationIsShipping(locId), locationIsCustomer(locId),
                locationOwnerEmail2,locationOwnerEmail3,locationOwnerEmail4);
    }

    private boolean isLocationType(String locationId, int type) throws SQLException {

        boolean exists = false;

        PreparedStatement stmt = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SELECT_LOCATION_DISPLAY);
            stmt.setString(1, locationId);
            stmt.setInt(2, type);
            rs = stmt.executeQuery();

            if (rs.next())
                exists = true;

            return exists;
        }
        finally {
            closeDBResources(conn, stmt, rs);
        }
    }

    private boolean locationIsCustomer(String locationId) throws SQLException {
        return isLocationType(locationId, 5);
    }

    private boolean locationIsShipping(String locationId) throws SQLException {
        return isLocationType(locationId, 4);
    }

    private boolean locationIsReporting(String locationId) throws SQLException {
        return isLocationType(locationId, 3);
    }

    private boolean locationIsFiling(String locationId) throws SQLException {
        return isLocationType(locationId, 2);
    }

    private boolean locationIsResponsible(String locationId) throws SQLException {
        return isLocationType(locationId, 1);
    }

    private boolean getStatus(ResultSet rs, String statusColumn) throws SQLException {
        boolean status = false;
        String locationStatus = rs.getString(statusColumn);
        if (locationStatus != null && locationStatus.equalsIgnoreCase("Y")) {
            status = true;
        }
        return status;
    }

    private String getShowLocationListDynamicQuery(int regionId) {
        StringBuffer query = new StringBuffer(GET_LOCATION_LIST_QUERY);
        if (regionId != -1) {
            query.append(" AND r.region_id = ").append(regionId);
        }
        
        return query.append(" ORDER BY l.location_short_name ").toString();
    }

    private String getShowLocationListDynamicQueryforProgram(int programId) {
        StringBuffer query = new StringBuffer(GET_LOCATION_LIST_QUERY_PROGRAM);
         query.append(" and pl.program_id = ").append(programId);
        return query.append(" ORDER BY l.location_short_name ").toString();
    }

    public void updateLocation(LocationInfo locationInfo) throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            ps = conn.prepareStatement(UPDATE_LOCATION_QUERY);
            ps.setString(1, locationInfo.getLocationName());
            ps.setInt(2, locationInfo.getRegionId());
            ps.setString(3, getStatus(locationInfo.isStatusActive()));
            ps.setString(4, locationInfo.getLocationLongName());
            ps.setString(5, locationInfo.getLocationEmail());
            ps.setString(6, locationInfo.getLocationOwnerEmail());
            ps.setString(7, getStatus(locationInfo.isOwnerEmailStatusActive()));

            ps.setString(8, locationInfo.getLocationOwnerEmail2());
            ps.setString(9, locationInfo.getLocationOwnerEmail3());
            ps.setString(10, locationInfo.getLocationOwnerEmail4());
            ps.setString(11, locationInfo.getLocationId());
            ps.executeUpdate();

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public void updateBusinessLocationRefTable(LocationInfo locationInfo, int businessId) throws DAOException, MCASException {

        PreparedStatement ps = null;
        Connection conn = null;

        try {
            conn = getConnection();

            ps = conn.prepareStatement(UPDATE_BUSINESS_LOCATION_REF_QUERY);
            ps.setInt(1, locationInfo.getRegionId());
            ps.setString(2, getStatus(locationInfo.isStatusActive()));
            ps.setString(3, locationInfo.getLocationId());
            ps.setInt(4, businessId);
            ps.executeUpdate();
            ps.close();

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    public void updateProgramLocationRefTable(LocationInfo locationInfo, int programId) throws DAOException, MCASException {

        PreparedStatement ps = null;
        Connection conn = null;

        try {
            conn = getConnection();

            ps = conn.prepareStatement(UPDATE_PROGRAM_LOCATION_REF_QUERY);
            ps.setInt(1, programId);
            ps.setString(2, locationInfo.getLocationId());
            ps.setString(3, locationInfo.isStatusActive()?"Y":"N");
            ps.setInt(4, programId);
            ps.setString(5, locationInfo.getLocationId());
            ps.executeUpdate();
            ps.close();

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    private String getStatus(boolean statusBooleanValue) {
        String status = "N";
        if (statusBooleanValue) {
            status = "Y";
        }
        return status;
    }

    public void insertLocation(LocationInfo locationInfo) throws DAOException, MCASException {

        PreparedStatement ps = null;
        Connection conn = null;

        try {
            conn = getConnection();
            boolean locationExists = checkForLocationExistence(conn, locationInfo.getLocationId());

            if (!locationExists) {
                ps = conn.prepareStatement(INSERT_LOCATION_QUERY);
                ps.setString(1, locationInfo.getLocationId());
                ps.setString(2, locationInfo.getLocationName());
                ps.setString(3, getStatus(locationInfo.isStatusActive()));
                ps.setInt(4, locationInfo.getRegionId());
                ps.setString(5, locationInfo.getLocationLongName());
                ps.setString(6, locationInfo.getLocationEmail());
                ps.setString(7, locationInfo.getLocationOwnerEmail());
                ps.setString(8, getStatus(locationInfo.isOwnerEmailStatusActive()));
                ps.setString(9, locationInfo.getLocationOwnerEmail2());
                ps.setString(10, locationInfo.getLocationOwnerEmail3());
                ps.setString(11, locationInfo.getLocationOwnerEmail4());
                ps.executeUpdate();
                conn.commit();
            }
        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    public void insertOrUpdateLocationDisplayRef(String locationId, int[] displayTypes, boolean isUpdate) throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();

            if (isUpdate) {
                ps = conn.prepareStatement(DELETE_LOCATION_DISPLAY);
                ps.setString(1, locationId);
                ps.executeUpdate();
                ps.close();
            }

            ps = conn.prepareStatement(INSERT_LOCATION_DISPLAY_QUERY);

            for (int displayType : displayTypes) {

                ps.setString(1, locationId);
                ps.setInt(2, displayType);
                ps.executeUpdate();
            }

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, null);
        }
    }

    public void insertProgramLocationreference(LocationInfo locationInfo, int programId) throws DAOException, MCASException{
                   PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();

            boolean busLocationExists = checkForBusinessLocationExistence(locationInfo, programId, conn);

            if (!busLocationExists) {
                insertIntoProgramLocationRef(locationInfo, programId, conn);
            } else {
                String errorMessage = "Location [" + locationInfo.getLocationName() + ", " + locationInfo.getLocationId() + "] already exists.";
                locationInfo.setErrorMessage(errorMessage);
            }

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public void insertBusinessLocationreference(LocationInfo locationInfo, int businessId) throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();

            boolean busLocationExists = checkForBusinessLocationExistence(locationInfo, businessId, conn);

            if (!busLocationExists) {
                insertIntoBusinessLocationRef(locationInfo, businessId, conn);
            } else {
                String errorMessage = "Location [" + locationInfo.getLocationName() + ", " + locationInfo.getLocationId() + "] already exists.";
                locationInfo.setErrorMessage(errorMessage);
            }

            conn.commit();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private void insertIntoBusinessLocationRef(LocationInfo locationInfo, int businessId, Connection conn) throws SQLException {

        PreparedStatement insertPs = null;

        try {
            insertPs = conn.prepareStatement(INSERT_INTO_BUSINESS_LOCATION_REF);
            insertPs.setInt(1, businessId);
            insertPs.setString(2, locationInfo.getLocationId());
            insertPs.setInt(3, locationInfo.getRegionId());
            insertPs.setString(4, getStatus(locationInfo.isStatusActive()));
            int recordCount = insertPs.executeUpdate();
            //        System.out.println("Record Inserted ************ " + recordCount);
            insertPs.close();
        }
        finally {
            closeDBResources(null, insertPs, null);
        }
    }

    private void insertIntoProgramLocationRef(LocationInfo locationInfo, int programId, Connection conn) throws SQLException {

            PreparedStatement insertPs = null;

            try {
                insertPs = conn.prepareStatement(INSERT_INTO_PROGRAM_LOCATION_REF);
                insertPs.setInt(1, getMaxProgramLocatioId(conn));
                insertPs.setInt(2, programId);
                insertPs.setString(3, locationInfo.getLocationId());
                insertPs.setString(4, locationInfo.isStatusActive()?"Y":"N");
                int recordCount = insertPs.executeUpdate();
                //        System.out.println("Record Inserted ************ " + recordCount);
                insertPs.close();
            }
            finally {
                closeDBResources(null, insertPs, null);
            }
        }

    private int getMaxProgramLocatioId(Connection conn) throws SQLException{
         PreparedStatement selectPs = null;
        ResultSet rs = null;
         int id=-1;
            try {
                selectPs = conn.prepareStatement(SELECT_PROGRAM_LOCATION_MAX_ID);
                rs=selectPs.executeQuery();
                while (rs.next()) {
                    id = rs.getInt("ID");
                }
                return id;
            }
            finally {
                closeDBResources(null, selectPs, null);
            }
    }


    private boolean checkForBusinessLocationExistence(LocationInfo locationInfo, int businessId, Connection conn) throws SQLException {
        boolean locationExists = false;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(SELECT_BUSINESS_LOCATION_REF_TABLE);
            ps.setString(1, locationInfo.getLocationId());
            ps.setInt(2, businessId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int count = rs.getInt("COUNT");
                if (count > 0) {
                    locationExists = true;
                    break;
                }
            }
            return locationExists;
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }

    private boolean checkForProgramLocationExistence(LocationInfo locationInfo, int programId, Connection conn) throws SQLException {
        boolean locationExists = false;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(SELECT_PROGRAM_LOCATION_REF_TABLE);
            ps.setString(1, locationInfo.getLocationId());
            ps.setInt(2, programId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int count = rs.getInt("COUNT");
                if (count > 0) {
                    locationExists = true;
                    break;
                }
            }
            return locationExists;
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }


    private boolean checkForLocationExistence(Connection conn, String locationId) throws SQLException {
        boolean locationExists = false;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(SELECT_LOCATION_REF_TABLE);
            ps.setString(1, locationId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int count = rs.getInt("COUNT");
                if (count > 0) {
                    locationExists = true;
                    break;
                }
            }
            return locationExists;
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }


}
