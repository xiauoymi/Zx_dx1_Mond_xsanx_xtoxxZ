/*
 LocationConstants was created on Aug 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
class LocationConstants {
    public static final String LOOKUP_LOCATIONS_BY_CRITERIA = "select lr.location_code, lr.location_short_name from location_ref lr, program_ref p," +
            "program_location pl " +
            "where  p.PROGRAM_ID=pl.PROGRAM_ID  and lr.location_code = pl.location_code " +
            "and lr.active_flag = 'Y' and pl.active_flag='Y' and pl.program_id = ? order by lr.location_short_name asc";

    public static final String LOOKUP_LOCATIONS_BY_CRITERIA_SEARCH = "select lr.location_code, lr.location_short_name from location_ref lr, program_ref p," +
            "program_location pl " +
            "where  p.PROGRAM_ID=pl.PROGRAM_ID  and lr.location_code = pl.location_code " +
            " and pl.active_flag='Y' and pl.program_id = ? order by lr.location_short_name asc";
}
