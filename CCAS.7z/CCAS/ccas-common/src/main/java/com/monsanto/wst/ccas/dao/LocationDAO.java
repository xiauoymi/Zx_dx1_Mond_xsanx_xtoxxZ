/*
 LocationDAO was created on Aug 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface LocationDAO {
    Map<String, String> lookupLocationBasedOnRegion(String region, String locale);

    Map<String, String> lookupLocationBasedOnRegion(String regionId, int locationType, String locale);
    Map<String, String> lookupLocationBasedOnRegionSearch(String regionId, int locationType, String locale);

    Map<String, String> lookupAllLocationsByCriteria(String programId);
    Map<String, String> lookupAllLocationsByCriteriaSearch(String programId);
}