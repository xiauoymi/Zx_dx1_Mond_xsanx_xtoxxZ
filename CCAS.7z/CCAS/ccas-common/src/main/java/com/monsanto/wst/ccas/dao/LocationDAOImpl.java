/*
 LocationDAOImpl was created on Aug 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.Util.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class LocationDAOImpl extends BaseDAOImpl implements LocationDAO {

    private static final String REGION_LOCATION_REF_QUERY = " select lr.location_code,lr.location_short_name from LOCATION_REF lr," +
            " BUSINESS_LOCATION_REF blr " +
            " where " +
            " blr.location_code = lr.location_code AND " +
            " blr.active_flag ='Y' " +
            " AND blr.region_id IN ";

    private static final String REGION_LOCATION_TYPE_REF_QUERY = " select lr.location_code,lr.location_short_name from LOCATION_REF lr," +
            " BUSINESS_LOCATION_REF blr,location_display_type ld  " +
            " where " +
            " blr.location_code = lr.location_code AND " +
            " blr.active_flag ='Y' and lr.active_flag='Y' AND ld.location_id = lr.location_code and ld.display_type = ?  " +
            " AND blr.region_id IN ";

    private static final String REGION_LOCATION_TYPE_REF_QUERY_SEARCH = " select lr.location_code,lr.location_short_name from LOCATION_REF lr," +
            " BUSINESS_LOCATION_REF blr,location_display_type ld  " +
            " where " +
            " blr.location_code = lr.location_code AND " +
            "  ld.location_id = lr.location_code and ld.display_type = ?  " +
            " AND blr.region_id IN ";

    //explicitly add constructor from BaseDAOImpl so it is not overridden
    public LocationDAOImpl() {
        super();
    }

    public LocationDAOImpl(DataSource dataSource) {
        this.datasource = dataSource;
    }

    public Map<String, String> lookupLocationBasedOnRegion(String regionId, String locale) {
        Map<String, String> locationReferenceMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String inClause = parseRegionIds(regionId);
            String orderByClause = " ORDER BY LR.LOCATION_SHORT_NAME ASC ";
            connection = datasource.getConnection();
            preparedStatement = connection.prepareStatement(REGION_LOCATION_REF_QUERY + inClause + orderByClause);
            
//      System.out.println("Query************* = " + REGION_LOCATION_REF_QUERY+inClause+orderByClause);
            resultSet = preparedStatement.executeQuery();
            populateLocationMap(locationReferenceMap, resultSet, locale);

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return locationReferenceMap;
    }

    private void populateLocationMap(Map<String, String> locationReferenceMap, ResultSet resultSet, String locale) throws SQLException {
        String locationCode;
        String locationDescription;

        String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
        locationReferenceMap.put("", selectOne);

        while (resultSet.next()) {
            locationCode = resultSet.getString("LOCATION_CODE");
            locationDescription = resultSet.getString("LOCATION_SHORT_NAME");
            locationDescription = MCASUtil.escapeXML(locationDescription);
            locationReferenceMap.put(locationCode, locationDescription);
        }
    }

    public Map<String, String> lookupLocationBasedOnRegion(String regionId, int locationType, String locale) {
        Map<String, String> locationReferenceMap = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String inClause = parseRegionIds(regionId);
            String orderByClause = " ORDER BY LR.LOCATION_SHORT_NAME ASC ";
            connection = datasource.getConnection();
            preparedStatement = connection.prepareStatement(REGION_LOCATION_TYPE_REF_QUERY + inClause + orderByClause);
                preparedStatement.setInt(1, locationType);

//      System.out.println("Query************* = " + REGION_LOCATION_TYPE_REF_QUERY+inClause+orderByClause);
            resultSet = preparedStatement.executeQuery();
            populateLocationMap(locationReferenceMap, resultSet, locale);

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return locationReferenceMap;
    }

    public Map<String, String> lookupLocationBasedOnRegionSearch(String regionId, int locationType, String locale) {
            Map<String, String> locationReferenceMap = new LinkedHashMap<String, String>();
            Connection connection = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            try {
                String inClause = parseRegionIds(regionId);
                String orderByClause = " ORDER BY LR.LOCATION_SHORT_NAME ASC ";
                connection = datasource.getConnection();
                preparedStatement = connection.prepareStatement(REGION_LOCATION_TYPE_REF_QUERY_SEARCH + inClause + orderByClause);
                    preparedStatement.setInt(1, locationType);

//      System.out.println("Query************* = " + REGION_LOCATION_TYPE_REF_QUERY+inClause+orderByClause);
                resultSet = preparedStatement.executeQuery();
                populateLocationMap(locationReferenceMap, resultSet, locale);

            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
            finally {
                MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
            }
            return locationReferenceMap;
        }


    private String parseRegionIds(String regionId) {
        StringBuffer inClause = new StringBuffer("(");
        if (!StringUtils.isNullOrEmpty(regionId)) {
            StringTokenizer tokenizer = new StringTokenizer(regionId, ":");
            while (tokenizer.hasMoreTokens()) {
                inClause.append(tokenizer.nextToken());
                inClause.append(",");
            }
            inClause.deleteCharAt(inClause.lastIndexOf(","));
            inClause.append(")");
        }

        return inClause.toString();
    }

    public Map<String, String> lookupAllLocationsByCriteria(String programId) {
        Connection conn = getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;

        Map<String, String> map = new HashMap<String, String>();
        try {
            statement = conn.prepareStatement(LocationConstants.LOOKUP_LOCATIONS_BY_CRITERIA);
            statement.setString(1, programId);
            rs = statement.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("LOCATION_CODE"), rs.getString("LOCATION_SHORT_NAME"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            closeDBResources(conn, statement, rs);
        }
        return map;
    }

    public Map<String, String> lookupAllLocationsByCriteriaSearch(String programId) {
        Connection conn = getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;

        Map<String, String> map = new HashMap<String, String>();
        try {
            statement = conn.prepareStatement(LocationConstants.LOOKUP_LOCATIONS_BY_CRITERIA);
            statement.setString(1, programId);
            rs = statement.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("LOCATION_CODE"), rs.getString("LOCATION_SHORT_NAME"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            closeDBResources(conn, statement, rs);
        }
        return map;
    }
}