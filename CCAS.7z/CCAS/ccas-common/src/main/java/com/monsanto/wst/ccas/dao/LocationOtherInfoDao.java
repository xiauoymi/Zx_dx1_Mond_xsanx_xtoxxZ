package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.LocationOtherInfo;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Apr 4, 2011
 * Time: 12:49:19 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LocationOtherInfoDao {
    void delete(LocationOtherInfo loc);

    void create(LocationOtherInfo loc);

    void update(LocationOtherInfo loc);

    LocationOtherInfo read(String id);
}
