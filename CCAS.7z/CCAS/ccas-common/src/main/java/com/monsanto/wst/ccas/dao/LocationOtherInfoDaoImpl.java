package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.LocationOtherInfo;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Apr 4, 2011
 * Time: 10:08:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocationOtherInfoDaoImpl implements LocationOtherInfoDao {

    private static Logger log = Logger.getLogger(LocationOtherInfoDaoImpl.class);

    private Connection con;

    public LocationOtherInfoDaoImpl(Connection con) {
        this.con = con;
    }

    public void delete(LocationOtherInfo loc) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("delete CCAS.LOCATION_OTHER_INFO where id=?");
            ps.setString(1, loc.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.error("error while delete location_other_info " + loc.toString(), e);
        } finally {
            closeDBResources(ps, rs);
        }
    }

    private void closeDBResources(PreparedStatement ps, ResultSet rs) {
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
                log.error("could not close statement: ", e);
            }
        }

        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                log.error("could not close statement: ", e);
            }
        }
    }

    public void create(LocationOtherInfo loc) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("insert into CCAS.LOCATION_OTHER_INFO (ID,RESPONSIBLE_LOC_OTHER_INFO,FILLING_LOC_OTHER_INFO) values (?,?,?)");
            ps.setString(1, loc.getId());
            ps.setString(2, loc.getResponsibleLocationDetail());
            ps.setString(3, loc.getFillingLocationDetail());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.error("error while inserting location_other_info " + loc.toString(), e);
        } finally {
            closeDBResources(ps, rs);
        }

    }

    public void update(LocationOtherInfo loc) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("update CCAS.LOCATION_OTHER_INFO set RESPONSIBLE_LOC_OTHER_INFO=?,FILLING_LOC_OTHER_INFO=? where ID=?");
            ps.setString(1, loc.getResponsibleLocationDetail());
            ps.setString(2, loc.getFillingLocationDetail());
            ps.setString(3, loc.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            log.error("error while updating location_other_info " + loc.toString(), e);
        } finally {
            closeDBResources(ps, rs);
        }

    }

    public LocationOtherInfo read(String id) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        LocationOtherInfo locationOtherInfo = new LocationOtherInfo();
        try {
            ps = con.prepareStatement("select * from LOCATION_OTHER_INFO where id = ?");
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                locationOtherInfo = new LocationOtherInfo();
                locationOtherInfo.setId(rs.getString("ID"));
                locationOtherInfo.setFillingLocationDetail(rs.getString("FILLING_LOC_OTHER_INFO"));
                locationOtherInfo.setResponsibleLocationDetail(rs.getString("RESPONSIBLE_LOC_OTHER_INFO"));
            }
        } catch (SQLException e) {
            log.error("error while reading location_other_info id#" + id, e);
        } finally {
            closeDBResources(ps, rs);
        }
        return locationOtherInfo;
    }


}
