/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.Cpar;

import java.util.List;
import java.util.Map;

/**
 * @author jbrahmb
 */
public interface LookUpDAO {

    Map<String, String> getAllStatesByRegion() throws DAOException, MCASException;

    Map<String, String> getStates() throws DAOException;

    Map<String, String> getStatusByRole(String type, String locale, Map<String, Boolean> roles) throws DAOException;

    Map<String, String> getAllStatus(String type, String locale) throws DAOException;

    Map<String, String> getLocations(int userBusiness, String locale) throws DAOException, MCASException;
    Map<String, String> getLocationsSearch(int userBusiness, String locale) throws DAOException, MCASException;

    Map<String, String> getQualityIssues(String locale) throws DAOException;

    Map<String, String> getYear(String locale) throws DAOException;

    String getYearDescription(int yearId) throws DAOException;

    Map<String, String> getCrops(String locale) throws DAOException;

    Map<String, String> getBusinessRelatedCrops(int businessId, String locale) throws DAOException;

    Map<String, String> getSeedSize(String locale) throws DAOException;

    Map<String, String> getUOM(String locale) throws DAOException;

    Map<String, String> getBrands(String locale) throws DAOException;

    Map<String, String> getRegions(String userId, int businessId, boolean filterByUserRole, String locale) throws
            DAOException;

    Map<String, String> getViewableRoleList(String userId, String locale) throws DAOException;

    Map<String, String> getGenerator(int type, boolean getAll, String locale, int businessId) throws DAOException;

    Map<String, String> getEffectivenessEvaluator(String locale) throws DAOException;

    Map<String, String> getFindingTypes(int type, boolean getActiveOnly, String locale, boolean isMCAS, int businessId) throws DAOException;

    Map<String, String> getISOStandards(String locale, int businessId, String qualityProgram) throws DAOException;

    Map<String, String> getQualityStandards(String locale, int busId) throws DAOException;

    Map<String, String> getOrganizations(String locale, int busId) throws DAOException;

    Map<String, String> getDepartmentAffected(String locale, int busId) throws DAOException;

    String[] getEmail(String locationCode) throws DAOException;

    String[] getSiteManager(String cparId) throws DAOException;

    String getLocationRegion(String locationId) throws DAOException;

    Map<String, String> getStatesByUserRegion(String userId, String locale) throws DAOException;

    Map<String, String> getStateByRegionSelected(List<String> regionIdList, String locale) throws DAOException;

    Map<String, String> getBusinessTypeMap(String locale) throws DAOException;

    int getModifiedUserBusinessPreference(String userId) throws DAOException;

    Map<String, String> getAssesmentMap(String locale) throws DAOException;

    Map<String, String> getLitigationCategoryMap(String locale) throws DAOException;

    Map<String, String> lookupBusinessRelatedMaterialGroupMap(int businessId, String locale) throws DAOException;

    Map<String, String> lookupBusinessRelatedMaterialPricingGroupMap(int businessId, String locale) throws DAOException;

    Map<String, String> lookupBusinessRelatedSalesOfficeMap(int businessId, String locale) throws DAOException;

    String lookupStatusDescription(int statusId, int statusType, String locale) throws DAOException;

    String getEquivalentStatus(Cpar cpar, int sourceStatusType) throws DAOException;

    Map<String, String> getCparTypes(int typeCar) throws DAOException;

    Map<String, String> getAuditTypes(String locale, int businessId) throws DAOException;

    Map<String, String> getClaimStatusTypes() throws DAOException;

    Map<String, String> lookUpFeedbackCategories(boolean activeOnly, String locale);

    String lookUpFeedbackCategoryById(String complaintBusinessId, String locale);

    Map<String, String> lookUpIlTypes(String locale);

    Map<String, String> lookUpAllIssueForComplaint(String locale);

    Map<String, String> getLocationsCreateExcel() throws DAOException, MCASException;

    

}
