/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.util.resultsetHandlers.LocationsMapResultSetHandler;
import com.monsanto.wst.ccas.util.resultsetHandlers.ResultMapHandler;
import com.monsanto.wst.ccas.util.resultsetHandlers.StateByRegionMapResultSetHandler;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Look
 *
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class LookUpDAOImpl extends BaseDAOImpl implements LookUpDAO {

    private static final String STATES_LKP = "select state_id, state_abbr from state_ref order by state_abbr asc";
    private static final String STATES_BY_REGION_LKP = "select state_id, state_abbr,region_id from state_ref order by state_abbr asc";
    private static final String REGION_SPECIFIC_STATE_LKP =
            "SELECT   s.state_id, s.state_abbr " +
                    "    FROM state_ref s, user_administration ua, region_ref r " +
                    "    WHERE ua.user_id = ? " +
                    "     AND r.region_id = ua.region_id " +
                    "     AND s.region_id = r.region_id " +
                    "ORDER BY s.state_abbr asc";
    private static final String DIFF_REGION_SPECIFIC_STATE_LKP =
            "SELECT   s.state_id, s.state_abbr " +
                    "    FROM state_ref s, region_ref r " +
                    "    WHERE s.region_id = r.region_id " +
                    "    AND r.region_id IN (999,";

    private static final String STATUS_LKP =
            "select s.status_id, s.status_description from status_ref s, status_type_ref st " +
                    "where s.status_type_id = st.status_type_id ";

    private static final String LOCATION_LKP =
            "select location_code, location_short_name from location_ref lr, region_ref rr, business_region_ref brr\n" +
                    " where  brr.business_id= ? and brr.REGION_ID=rr.REGION_ID and rr.REGION_ID=lr.REGION_ID\n" +
                    "  and lr.active_flag = 'Y' order by lr.location_short_name asc";

    private static final String LOCATION_LKP_SEARCH =
            "select location_code, location_short_name from location_ref lr, region_ref rr, business_region_ref brr\n" +
                    " where  brr.business_id= ? and brr.REGION_ID=rr.REGION_ID and rr.REGION_ID=lr.REGION_ID\n" +
                    "   order by lr.location_short_name asc";
    /*
    private static final String LOCATION_CREATE_EXCEL_LKP =
             "select location_code, location_short_name from location_ref lr, region_ref rr, business_region_ref brr\n" +
                    " where brr.REGION_ID=rr.REGION_ID and rr.REGION_ID=lr.REGION_ID\n" +
                    "  and lr.active_flag = 'Y' order by lr.location_short_name asc";

    */

    private static final String LOCATION_CREATE_EXCEL_LKP =
            " SELECT l.location_code location_id, l.location_short_name location_name,r.region_id region_id" +
            " FROM location_ref l, region_ref r, business_location_ref blr" +
            " WHERE blr.region_id = r.region_id AND  blr.location_code = l.location_code";



    private static final String QUALITY_ISSUE_LKP =
            "select complaint_quality_issue_id, complaint_quality_issue from complaint_quality_issue_ref " +
                    "order by complaint_quality_issue_id asc";

    private static final String EMAIL_LKP = " from location_ref " +
            "where location_code = ?";

    private static final String OWNER_EMAIL_FLAG_LKP = "select email_owner_flag from location_ref " +
            "where location_code = ?";

    private static final String GENERATOR_LKP = "SELECT CPAR_SOURCE_TYPE_ID, DESCRIPTION, ACTIVE_FLAG FROM CPAR_SOURCE_TYPE_REF WHERE GEN_FINDING_TYPE = ? ";

    private static final String EFFECT_EVALUATOR_LKP = "SELECT EVAL_FOR_EFFECT_TYPE_ID, DESCRIPTION, ACTIVE_FLAG FROM EVAL_FOR_EFFECT_TYPE_REF WHERE ACTIVE_FLAG = ? ORDER BY DESCRIPTION";

    private static final String FINDING_TYPE_LKP = "SELECT FINDING_TYPE_ID, DESCRIPTION, ACTIVE_FLAG, SORT_ORDER FROM FINDING_TYPE_REF WHERE GEN_FINDING_TYPE = ? ";

    private static final String ISO_STANDARD_LKP_PROGRAM = "SELECT ISO_STANDARD_ID, STANDARD_NUMBER, DESCRIPTION, ACTIVE_FLAG, REPORT_STATUS_FLAG FROM ISO_STANDARD_REF WHERE ACTIVE_FLAG = ? and business_id = ? and quality_program_id = ? ORDER BY ISO_STANDARD_ID";

    private static final String ISO_STANDARD_LKP_NO_PROGRAM = "SELECT ISO_STANDARD_ID, STANDARD_NUMBER, DESCRIPTION, ACTIVE_FLAG, REPORT_STATUS_FLAG FROM ISO_STANDARD_REF WHERE ACTIVE_FLAG = ? and business_id = ? and quality_program_id is null ORDER BY ISO_STANDARD_ID";

    private static final String ORGANIZATION_LKP = "SELECT ORGANIZATION_ID, DESCRIPTION FROM ORGANIZATION where business_id = ?";

    private static final String DEPARTMENT_AFFECTED_LKP = "SELECT * FROM M_AUDIT_AREAS_REF WHERE BUSINESS_ID=? ORDER BY DISPLAY_ORDER";


    private static final String QUALITY_STANDARD_LKP = "SELECT QUALITY_PROGRAM_ID, DESCRIPTION FROM QUALITY_PROGRAM where business_id = ?";

    private static final String YEAR_LKP = "select year_id, short_description from year_ref order by short_description desc";

    private static final String YEAR_DESC_LKP = "select short_description from year_ref where year_id = ?";

    private static final String CROP_LKP = "select crop_id, short_description from crop_ref where active_flag = ? order by short_description asc";

    private static final String CROP_LKP_FOR_NEW_COMPLAINT =
            "select distinct c.crop_id,c.short_description from crop_ref c,business b,business_family_ref bf\n" +
                    " where c.crop_id = bf.crop_id\n" +
                    " and b.business_id = bf.business_id\n" +
                    " and bf.business_id=?" +
                    " and c.active_flag=?\n" +
                    " order by c.short_description asc";

    private static final String SEEDSIZE_LKP = "select seed_size_id, description from seed_size_ref where active_flag = ? order by description asc";

    private static final String QTYUOM_LKP = "select qty_uom_id, qty_description from qty_uom_ref where active_flag = ? order by qty_description asc";

    private static final String BRAND_LKP = "select brand_id, description from brand_ref where active_flag = ?";

    private static final String ALL_REGION_LKP_DEFAULT = "select * from region_ref where region_id <> 999 order by region_description asc";
    //Modified the query to fetch the regions based on the Business Selected by the user
    private static final String ALL_REGION_LKP =
            "select distinct rr.region_id,rr.region_description from region_ref rr," +
                    " BUSINESS_REGION_REF brf\n" +
                    " where rr.region_id=brf.region_id\n" +
                    " and brf.business_id=? " +
                    " order by rr.region_description asc";

    private static final String REGION_LKP_FILTERED_BY_USER_ID =
            "SELECT   rr.region_id, rr.region_description " +
                    "   FROM region_ref rr, user_region ur,BUSINESS_REGION_REF br " +
                    "   WHERE rr.region_id = ur.region_id " +
                    "   AND ur.region_id = br.region_id " +
                    "   AND ur.user_id = ? " +
                    "   AND br.business_id = ? " +
                    "   ORDER BY region_description ASC";

    private static final String ROLE_LKP_FOR_SYSTEM_ADMIN =
            "SELECT r.role_id, r.role_description " +
                    "  FROM ROLE r where r.IS_HIDDEN <> 'Y'";

    private static final String ROLE_LKP_FOR_REGIONAL_ADMIN =
            "SELECT   r.role_id, r.role_description \n" +
                    "    FROM ROLE r \n" +
                    "   WHERE  r.is_hidden <> 'Y' and r.role_id NOT IN (SELECT r.role_id \n" +
                    "                             FROM ROLE r \n" +
                    "                            WHERE r.role_description = '" + MCASConstants.ROLE_SYSTEM_ADMIN + "') \n" +
                    "ORDER BY role_description ";

    private static final String GET_USER_ROLE_QUERY =
            "SELECT r.role_description ROLE " +
                    "  FROM user_administration ua, ROLE r " +
                    " WHERE ua.role_id = r.role_id AND ua.user_id = ? ";

    private static final String GET_LOCATION_REGION_QUERY =
            "SELECT l.region_id region_id " +
                    "  FROM location_ref l " +
                    " WHERE l.location_code = ? ";

    private static final Log logger = LogFactory.getLog(LookUpDAOImpl.class);

    private static final String GET_BUSINESS_TYPE_SQL = "SELECT B.BUSINESS_ID,B.DESCRIPTION FROM BUSINESS B WHERE ACTIVE='Y' ORDER BY B.BUSINESS_ID ASC";
    private static final String CPAR_EQUIV_STATUS = " select status_id from status_ref  where status_type_id = ? " +
            "  and trim(status_description) like " +
            "  (select trim(status_description) from status_ref where status_type_id= ?  and  status_id = ?)";

    private static final int MCAS_CPAR_OVERDUE_INTERVAL_1 = 14;
    private static final int MCAS_CPAR_OVERDUE_INTERVAL_2 = 30;
    private static final int MCAS_CPAR_OVERDUE_INTERVAL_3 = 45;
    private static final int MCAS_CPAR_OVERDUE_INTERVAL_4 = 85;

    public Map<String, String> getClaimStatusTypes() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = new HashMap<String, String>();
        try {
            conn = getConnection();
            ps = conn.prepareStatement("select distinct claim_status_indicator from claim_id_view");
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    result.put(rs.getString("claim_status_indicator"), rs.getString("claim_status_indicator"));
                }
            }
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
        return result;
    }

    public Map<String, String> getStates() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(STATES_LKP);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", " ");
                while (rs.next()) {
                    result.put(rs.getString(1), rs.getString(2));
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    //






    public Map<String, String> getStatusByRole(String type, String locale, Map<String, Boolean> roles) throws DAOException {
        return getStatus(type, locale, getStatusRoleClause(roles));
    }

    public Map<String, String> getAllStatus(String type, String locale) throws DAOException {
        return getStatus(type, locale, "");
    }

    private Map<String, String> getStatus(String type, String locale, String roleClause) throws DAOException {
        if (logger.isDebugEnabled())
            logger.debug(this);
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            StringBuffer whereClause = new StringBuffer(STATUS_LKP);
            whereClause.append("and st.status_type_description ='").append(type.toUpperCase()).append("'");
            whereClause.append(" and s.active_flag = 'Y'");
            whereClause.append(roleClause);
            ps = conn.prepareStatement(whereClause.toString());
//            System.out.println(whereClause);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new HashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("STATUS_ID");
                    String desc = iService.translate(locale, "STATUS_REF", id, rs.getString("STATUS_DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private String getStatusRoleClause(Map<String, Boolean> roles) {

        String clause = " and (";

        for (String key : roles.keySet()) {
            if (roles.get(key) == true) {
                clause += "role_id = " + key + " or ";
            }
        }

        clause += "role_id is null)";

        return clause;
    }


    public Map<String, String> getLocations(int userBusiness, String locale) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(LOCATION_LKP);
            ps.setInt(1, userBusiness);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectLocation");
                result.put("", select);

                while (rs.next()) {
                    String locationShortDescription = rs.getString(2);
                    String inLowerCase = MCASUtil.getModifiedLocationNames(locationShortDescription.trim());
                    result.put(rs.getString(1), inLowerCase);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getLocationsSearch(int userBusiness, String locale) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(LOCATION_LKP_SEARCH);
            ps.setInt(1, userBusiness);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectLocation");
                result.put("", select);

                while (rs.next()) {
                    String locationShortDescription = rs.getString(2);
                    String inLowerCase = MCASUtil.getModifiedLocationNames(locationShortDescription.trim());
                    result.put(rs.getString(1), inLowerCase);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    public Map<String, String> getQualityIssues(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(QUALITY_ISSUE_LKP);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                result.put("", selectOne);
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("complaint_quality_issue_id");
                    String desc = iService
                            .translate(locale, "COMPLAINT_QUALITY_ISSUE_REF", id, rs.getString("complaint_quality_issue"));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getYear(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(YEAR_LKP);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String year = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.year");
                //result.put("", year);
                while (rs.next()) {
                    result.put(rs.getString(1), rs.getString(2));
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public String getYearDescription(int yearId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(YEAR_DESC_LKP);
            ps.setInt(1, yearId);
            rs = ps.executeQuery();
            if (rs != null) {

                if (rs.next()) {
                    return rs.getString(1);
                }
            }
            return null;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    public Map<String, String> getCrops(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CROP_LKP);
            ps.setString(1, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("CROP_ID");
                    String desc = iService.translate(locale, "CROP_REF", id, rs.getString("SHORT_DESCRIPTION"));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    /**
     * Bhargava 04/15/2008 <p/> Method to fetch crops based on business selected
     *
     * @param businessId
     * @return
     * @throws DAOException
     */
    public Map<String, String> getBusinessRelatedCrops(int businessId, String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CROP_LKP_FOR_NEW_COMPLAINT);
            ps.setInt(1, businessId);
            ps.setString(2, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                result.put("", selectOne);
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("CROP_ID");
                    String desc = iService.translate(locale, "CROP_REF", id, rs.getString("SHORT_DESCRIPTION"));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getSeedSize(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(SEEDSIZE_LKP);
            ps.setString(1, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                result.put("", selectOne);
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("SEED_SIZE_ID");
                    String desc = iService.translate(locale, "SEED_SIZE_REF", id, rs.getString("DESCRIPTION"));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    public Map<String, String> getUOM(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(QTYUOM_LKP);
            ps.setString(1, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectUOM");
                result.put("", select);

                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("QTY_UOM_ID");
                    String desc = iService.translate(locale, "QTY_UOM_REF", id, rs.getString("qty_description"));

                    result.put(rs.getString(1), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getBrands(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(BRAND_LKP);
            ps.setString(1, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new HashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt(1);
                    String desc = iService.translate(locale, "BRAND_REF", id, rs.getString(2));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getRegions(String userId, int businessId, boolean filterByUserRole, String locale) throws
            DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = new LinkedHashMap<String, String>();
        try {
            conn = getConnection();
            ps = getPreparedStatementForRegionLookup(userId, businessId, filterByUserRole, conn);
            rs = ps.executeQuery();
            if (rs != null) {

                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectRegion"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("REGION_ID");
                    String desc = iService.translate(locale, "REGION_REF", id, rs.getString("REGION_DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public String getLocationRegion(String locationId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        String regionId = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(GET_LOCATION_REGION_QUERY);
            ps.setString(1, locationId);
            rs = ps.executeQuery();
            while (rs.next()) {
                regionId = rs.getString("REGION_ID");
            }
            return regionId;
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getStatesByUserRegion(String userId, String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(REGION_SPECIFIC_STATE_LKP);
            ps.setString(1, userId);
            rs = ps.executeQuery();
            if (rs != null) {

                result = new LinkedHashMap<String, String>();
                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectState");
                result.put("", select);

                while (rs.next()) {
                    result.put(rs.getString(1), rs.getString(2));
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getStateByRegionSelected(List<String> regionIdList, String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        StringBuffer sqlBuf = new StringBuffer();
        sqlBuf.append(DIFF_REGION_SPECIFIC_STATE_LKP);
        for (String regionId : regionIdList) {
            sqlBuf.append(regionId);
            sqlBuf.append(",");
        }
        sqlBuf = sqlBuf.deleteCharAt(sqlBuf.length() - 1);
        sqlBuf.append(" ) ");
        sqlBuf.append(" ORDER BY s.state_abbr asc ");
        try {
            conn = getConnection();
            ps = conn.prepareStatement(sqlBuf.toString());
            rs = ps.executeQuery();
            if (rs != null) {

                result = new LinkedHashMap<String, String>();
                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectState");
                result.put("", select);

                while (rs.next()) {
                    result.put(rs.getString(1), rs.getString(2));
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }


    public Map<String, String> getViewableRoleList(String userId, String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = getPreparedStatementForRoleLookup(userId, conn);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectRole"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("ROLE_ID");
                    String desc = iService.translate(locale, "ROLE", id, rs.getString("ROLE_DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private PreparedStatement getPreparedStatementForRegionLookup(String userId, int businessId, boolean filterByUserRole,
                                                                  Connection conn) throws DAOException, MCASException,
            SQLException {
        String queryStringForRegion;
        PreparedStatement ps;
        if (filterByUserRole && StringUtils.isNullOrEmpty(userId)) {
            throw new MCASException("Region can not be filtered by user role if userId is null or empty.");
        }

        if (filterByUserRole && isBasicUser(userId, conn)) { //!isSystemAdmin(userId, conn)) {
            queryStringForRegion = REGION_LKP_FILTERED_BY_USER_ID;
            ps = conn.prepareStatement(queryStringForRegion);
            ps.setString(1, userId);
            ps.setInt(2, businessId);

        } else {
            if (businessId == -1) {
                queryStringForRegion = ALL_REGION_LKP_DEFAULT;
            } else {
                queryStringForRegion = ALL_REGION_LKP;
            }
            ps = conn.prepareStatement(queryStringForRegion);
            if (businessId != -1) {
                ps.setInt(1, businessId);
            }
        }
        return ps;
    }

    private PreparedStatement getPreparedStatementForRoleLookup(String userId, Connection conn) throws DAOException,
            MCASException, SQLException {
        //Only Sys_Admin and Reg_Admin can view the role-lookup on UserAdmin Screen...
        String queryStringForRole;
        PreparedStatement ps;
        if (isSystemAdmin(userId, conn)) {
            queryStringForRole = ROLE_LKP_FOR_SYSTEM_ADMIN;
            ps = conn.prepareStatement(queryStringForRole);
        } else {
            queryStringForRole = ROLE_LKP_FOR_REGIONAL_ADMIN;
            ps = conn.prepareStatement(queryStringForRole);
        }
        return ps;
    }

    private boolean isSystemAdmin(String userId, Connection conn) throws DAOException, MCASException {
        String role = getRole(userId, conn);
        return role != null && role.equalsIgnoreCase(MCASConstants.ROLE_SYSTEM_ADMIN);
    }

    private boolean isBasicUser(String userId, Connection conn) throws DAOException, MCASException {
        String role = getRole(userId, conn);
        return role != null && role.equalsIgnoreCase(MCASConstants.ROLE_USER);
    }


    public String getRole(String userId, Connection conn) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        String result = "";
        try {
            ps = conn.prepareStatement(GET_USER_ROLE_QUERY);
            ps.setString(1, userId);
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    result = rs.getString("ROLE");
                }
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("SQL Exception while looking up Role for the user: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException("Exception while looking up Role for the user: " + e.getMessage(), e);
        } finally {
            closeDBResources(null, ps, rs);
        }
    }

    public Map<String, String> getGenerator(int type, boolean getActiveOnly, String locale, int businessId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        StringBuffer queryBuffer = new StringBuffer(GENERATOR_LKP);
        String orderByClause = " ORDER BY DESCRIPTION";
        int queryIndex=2;
        try {
            if (getActiveOnly) {
                queryBuffer.append(" AND ACTIVE_FLAG =? ");
            }
            conn = getConnection();

            if(businessId!=MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED){
                queryBuffer.append(" AND CPAR_SOURCE_TYPE_ID IN (SELECT ID_TABLE FROM DROPDOWN_BY_BUSINESS_VIEW WHERE TABLE_NAME='CPAR_SOURCE_TYPE_REF' AND BUSINESS_ID=?) ");
            }

            ps = conn.prepareStatement((queryBuffer.append(orderByClause)).toString());
            ps.setInt(1, type);
            if (getActiveOnly) {
                ps.setString(2, "Y");
                queryIndex++;
            }

             if(businessId!=MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED){
                ps.setInt(queryIndex, businessId);
             }

            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectGenerator"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("CPAR_SOURCE_TYPE_ID");
                    String desc = iService.translate(locale, "CPAR_SOURCE_TYPE_REF", id, rs.getString("DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getEffectivenessEvaluator(String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(EFFECT_EVALUATOR_LKP);
            ps.setString(1, "Y");
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectEvaluator"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {

                    int id = rs.getInt("EVAL_FOR_EFFECT_TYPE_ID");
                    String desc = iService.translate(locale, "EVAL_FOR_EFFECT_TYPE_REF", id, rs.getString("DESCRIPTION"));

                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getFindingTypes(int type, boolean getActiveOnly, String locale, boolean isMCAS, int businessId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        StringBuffer queryBuffer = new StringBuffer(FINDING_TYPE_LKP);
        int queryIndex=2;

        String showMCAS = (isMCAS == true) ? "MFG_USER" : "";
        String orderByClause = " ORDER BY SORT_ORDER";
        try {
            if (getActiveOnly) {
                queryBuffer.append(" AND ACTIVE_FLAG =? ");
            }

            if (isMCAS) {
                queryBuffer.append(" AND B_USER =? ");
            }

             if(businessId!=MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED){
                queryBuffer.append(" AND FINDING_TYPE_ID IN (SELECT ID_TABLE FROM DROPDOWN_BY_BUSINESS_VIEW WHERE TABLE_NAME='FINDING_TYPE_REF' AND BUSINESS_ID=?) ");
                }

            conn = getConnection();
            ps = conn.prepareStatement((queryBuffer.append(orderByClause)).toString());
            ps.setInt(1, type);
            if (getActiveOnly) {
                ps.setString(2, "Y");
                queryIndex++;
                if (isMCAS) {
                    ps.setString(3, showMCAS);
                    queryIndex++;
                }
            } else {
                if (isMCAS) {
                    ps.setString(2, showMCAS);
                    queryIndex++;
                }
            }


            if(businessId!=MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED){
                ps.setInt(queryIndex, businessId);
            }

            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectFindingType"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("FINDING_TYPE_ID");
                    String desc = iService.translate(locale, "FINDING_TYPE_REF", id, rs.getString("DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
                if (locale.equals("es") || locale.equals("pt")) {
                    result = MCASUtil.sortByValue(result);
                }
            }


            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getISOStandards(String locale, int business_id, String qualityProgram) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();

            if (StringUtils.isNullOrEmpty(qualityProgram)) {
                ps = conn.prepareStatement(ISO_STANDARD_LKP_NO_PROGRAM);
                ps.setString(1, "Y");
                ps.setInt(2, business_id);
            } else {
                ps = conn.prepareStatement(ISO_STANDARD_LKP_PROGRAM);
                ps.setString(1, "Y");
                ps.setInt(2, business_id);
                ps.setString(3, qualityProgram);
            }

            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectStandard"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("ISO_STANDARD_ID");
                    String desc = iService.translate(locale, "ISO_STANDARD_REF", id, rs.getString("DESCRIPTION"));
                    result.put(rs.getString("ISO_STANDARD_ID"), rs.getString("STANDARD_NUMBER") + "   - " + desc);
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getQualityStandards(String locale, int busId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(QUALITY_STANDARD_LKP);
            ps.setInt(1, busId);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectOtherStandard"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("QUALITY_PROGRAM_ID");
                    String desc = iService.translate(locale, "QUALITY_STANDARD", id, rs.getString("DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getOrganizations(String locale, int busId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(ORGANIZATION_LKP);
            ps.setInt(1, busId);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.cpar.selectOtherOrganization"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("ORGANIZATION_ID");
                    String desc = iService.translate(locale, "ORGANIZATION", id, rs.getString("DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

     public Map<String, String> getDepartmentAffected(String locale, int busId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(DEPARTMENT_AFFECTED_LKP);

            ps.setInt(1, busId);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new LinkedHashMap<String, String>();
                result.put("", I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne"));
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    int id = rs.getInt("AREA_ID");
                    String desc = iService.translate(locale, "M_AUDIT_AREAS_REF", id, rs.getString("DESCRIPTION"));
                    result.put(Integer.toString(id), desc);
                }
            }
            return result;
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public String[] getEmail(String locationCode) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(OWNER_EMAIL_FLAG_LKP);
            ps.setString(1, locationCode);
            rs = ps.executeQuery();
            String flag;
            if (rs != null && rs.next()) {
                flag = rs.getString("EMAIL_OWNER_FLAG");
            } else {
                flag = "";
            }

            closeDBResources(null, ps, rs);

            if ("Y".equals(flag)) {
                ps = conn.prepareStatement("Select e_mail,owner_email,owner_email2,owner_email3,owner_email4" + EMAIL_LKP);
            } else {
                ps = conn.prepareStatement("Select e_mail" + EMAIL_LKP);
            }
            ps.setString(1, locationCode);
            rs = ps.executeQuery();
            String[] result = new String[5];
            if (rs != null) {
                while (rs.next()) {
                    if (rs.getString("E_MAIL") != null)
                        result[0] = rs.getString("E_MAIL").trim();
                    if ("Y".equals(flag)) {
                        int index=1;
                        if (rs.getString("OWNER_EMAIL") != null){
                            result[index] = rs.getString("OWNER_EMAIL").trim();
                            index++;
                        }
                        if (rs.getString("OWNER_EMAIL2") != null){
                            result[index] = rs.getString("OWNER_EMAIL2").trim();
                            index++;
                        }
                        if (rs.getString("OWNER_EMAIL3") != null){
                            result[index] = rs.getString("OWNER_EMAIL3").trim();
                            index++;
                        }
                        if (rs.getString("OWNER_EMAIL4") != null){
                            result[index] = rs.getString("OWNER_EMAIL4").trim();
                            index++;
                        }
                    }
                }
            }
            return result;
        }
        catch (SQLException e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public String[] getSiteManager(String cparId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            ps = conn.prepareStatement("Select site_manager from cpar where cpar_id = ?");
            ps.setString(1, cparId);
            rs = ps.executeQuery();
            String[] result = new String[1];
            if (rs != null) {
                while (rs.next()) {
                    if (rs.getString("SITE_MANAGER") != null) {
                        result[0] = rs.getString("SITE_MANAGER").trim();
                    }
                }
            }
            return result;
        }
        catch (SQLException e) {
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

    /**
     * Bhargava 04/11/08 Method to fetch the business Type
     *
     * @param
     * @return Map <BusinessTypeId : BusinessTypeName>
     * @throws DAOException
     */
    public Map<String, String> getBusinessTypeMap(String locale) throws DAOException {
        Map<String, String> businessTypeMap = new LinkedHashMap<String, String>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(GET_BUSINESS_TYPE_SQL);
            //ps.setString(1,userId);
            rs = ps.executeQuery();
            if (rs != null) {
                int businessTypeId;
                String description = "";

                String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
                businessTypeMap.put("", selectOne);
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    businessTypeId = rs.getInt("BUSINESS_ID");
                    description = iService.translate(locale, "BUSINESS", businessTypeId, rs.getString("DESCRIPTION"));
                    businessTypeMap.put(Integer.toString(businessTypeId), description);
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception in :" + getClass() + ".getBusinessTypeMap() method :" + e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return businessTypeMap;
    }

    /**
     * Bhargava 04/16/2008 <p/> Method to get the updated business preference ID
     *
     * @param userId
     * @return
     * @throws DAOException
     */
    public int getModifiedUserBusinessPreference(String userId) throws DAOException {
        int businessPreferenceId = -1;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("SELECT BUSINESS_PREFERENCE_ID FROM USER_ADMINISTRATION UA " +
                    "WHERE UA.USER_ID=? ");
            ps.setString(1, userId);
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    businessPreferenceId = rs.getInt("BUSINESS_PREFERENCE_ID");
                }
            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(
                    "Exception fetching the business preference in " + getClass() + ":getModifiedUserBusinessPreference" +
                            e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return businessPreferenceId;
    }

    /**
     * Bhargava Method to load the assesments
     *
     * @return
     * @throws DAOException
     */
    public Map<String, String> getAssesmentMap(String locale) throws DAOException {
        Map<String, String> assesmentMap = null;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("SELECT ASSESMENT_ID,DESCRIPTION FROM COMPLAINT_ASSESMENT ORDER BY ASSESMENT_ID ASC ");
            rs = ps.executeQuery();
            if (rs != null) {
                assesmentMap = new LinkedHashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectAssessment");
                assesmentMap.put("", select);

                while (rs.next()) {

                    int id = rs.getInt("ASSESMENT_ID");
                    String desc = iService.translate(locale, "COMPLAINT_ASSESMENT", id, rs.getString("DESCRIPTION"));
                    assesmentMap.put(Integer.toString(id), desc);
                }
            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception fetching the Assesments in " + getClass() + ":getAssesmentMap" + e.getMessage(),
                    e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return assesmentMap;
    }

    /**
     * Bhargava 06/09/2008 Method to fetch the Complaint Litigation Category
     *
     * @return
     * @throws DAOException
     */
    public Map<String, String> getLitigationCategoryMap(String locale) throws DAOException {
        Map<String, String> categorytMap = null;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(
                    "SELECT LITIGATION_ID,DESCRIPTION FROM COMPLAINT_LITIGATION_CATEGORY ORDER BY LITIGATION_ID ASC ");
            rs = ps.executeQuery();
            if (rs != null) {
                categorytMap = new LinkedHashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectComplaintLitigationCategory");
                categorytMap.put("", select);

                while (rs.next()) {

                    int id = rs.getInt("LITIGATION_ID");
                    String description = iService
                            .translate(locale, "COMPLAINT_LITIGATION_CATEGORY", id, rs.getString("DESCRIPTION"));
                    categorytMap.put(Integer.toString(id), description);
                }
            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(
                    "Exception fetching the complaint litigation categories in " + getClass() + ":getCategoryMap" +
                            e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return categorytMap;
    }

    /**
     * Method to Fetch Business Related Material Group
     *
     * @param businessId
     * @return
     * @throws DAOException
     */
    public Map<String, String> lookupBusinessRelatedMaterialGroupMap(int businessId, String locale) throws DAOException {
        Map<String, String> businessRelatedMaterialGroupMap = null;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("select complaint_material_group_id,complaint_material_group_name" +
                    " from complaint_material_group" +
                    " where complaint_material_group_id in" +
                    " (select material_group_id from family_material_group_ref " +
                    " where family_id in (select crop_id from business_family_ref where business_id = ?) )");
            ps.setInt(1, businessId);
            rs = ps.executeQuery();
            if (rs != null) {
                businessRelatedMaterialGroupMap = new LinkedHashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectMaterialGroup");
                businessRelatedMaterialGroupMap.put("", select);

                while (rs.next()) {

                    int id = rs.getInt("complaint_material_group_id");
                    String desc = iService
                            .translate(locale, "COMPLAINT_MATERIAL_GROUP", id, rs.getString("complaint_material_group_name"));
                    businessRelatedMaterialGroupMap.put(Integer.toString(id), desc);
                }
            }

        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(
                    "Exception fetching the material groups in " + getClass() + ":lookupBusinessRelatedMaterialGroupMap" +
                            e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return businessRelatedMaterialGroupMap;
    }

    /**
     * Method to fetch Business Related Material Pricing Map . TODO : Assuming material pricing group is required only for
     * seminis users.have to change it in future if Row Crop users require too.
     *
     * @param businessId : This has to be considered in future if Row Crop users use Material Pricing Group
     * @return
     * @throws DAOException
     */
    public Map<String, String> lookupBusinessRelatedMaterialPricingGroupMap(int businessId, String locale) throws
            DAOException {
        Map<String, String> businessRelatedMaterialPricingGroupMap = null;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("select complaint_mprg_id,complaint_Mprg_name from complaint_material_pricing_grp ");
            rs = ps.executeQuery();
            if (rs != null) {
                businessRelatedMaterialPricingGroupMap = new LinkedHashMap<String, String>();
                I18nServiceImpl iService = new I18nServiceImpl();

                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectMaterialPricingGroup");
                businessRelatedMaterialPricingGroupMap.put("", select);

                while (rs.next()) {

                    int id = rs.getInt("complaint_mprg_id");
                    String materialPricingGroupName = iService
                            .translate(locale, "COMPLAINT_MATERIAL_PRICING_GRP", id, rs.getString("complaint_Mprg_name"));
                    businessRelatedMaterialPricingGroupMap.put(Integer.toString(id), materialPricingGroupName);
                }
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception fetching the material pricing group in " + getClass() +
                    ":lookupBusinessRelatedMaterialPricingGroupMap" + e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return businessRelatedMaterialPricingGroupMap;
    }


    /**
     * Method to fetch Business Related Sales office  Map . TODO : Assuming sales office is required only for seminis
     * users.have to change it in future if Row Crop users require too.
     *
     * @param businessId
     * @return
     * @throws DAOException
     */
    public Map<String, String> lookupBusinessRelatedSalesOfficeMap(int businessId, String locale) throws DAOException {
        Map<String, String> businessRelatedSalesOfficeMap = null;
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("SELECT SALES_OFFICE_ID,SALES_OFFICE_DESCRIPTION FROM SALES_OFFICE ");
            rs = ps.executeQuery();
            if (rs != null) {
                businessRelatedSalesOfficeMap = new LinkedHashMap<String, String>();
                String select = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectSalesOffice");
                businessRelatedSalesOfficeMap.put("", select);
                while (rs.next()) {
                    businessRelatedSalesOfficeMap
                            .put(Integer.toString(rs.getInt("SALES_OFFICE_ID")), rs.getString("SALES_OFFICE_DESCRIPTION"));
                }
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(
                    "Exception fetching the sales office in " + getClass() + ":lookupBusinessRelatedSalesOfficeMap" +
                            e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return businessRelatedSalesOfficeMap;
    }

    /**
     * Method to Look up the status description given the status id and the type
     *
     * @param statusId
     * @param statusType
     * @return
     * @throws DAOException
     */
    public String lookupStatusDescription(int statusId, int statusType, String locale) throws DAOException {
        String statusDescription = "";
        PreparedStatement ps = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("SELECT STATUS_DESCRIPTION FROM STATUS_REF WHERE STATUS_ID=? AND STATUS_TYPE_ID = ? ");
            ps.setInt(1, statusId);
            ps.setInt(2, statusType);
            rs = ps.executeQuery();
            if (rs != null) {
                if (rs.next()) {
                    statusDescription = (new I18nServiceImpl())
                            .translate(locale, "STATUS_REF", statusId, rs.getString("STATUS_DESCRIPTION"));
                }
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(
                    "Exception fetching the sales office in " + getClass() + ":lookupBusinessRelatedSalesOfficeMap" +
                            e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return statusDescription;
    }

    public String getEquivalentStatus(Cpar cparObj, int sourceStatusType) throws DAOException {
        String cparStatus = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(CPAR_EQUIV_STATUS);
            ps.setInt(1, MCASConstants.COMPLAINT_STATUS_TYPE);
            ps.setInt(2, sourceStatusType);
            ps.setInt(3, Integer.parseInt(cparObj.getStatus_id()));
            rs = ps.executeQuery();
            if (rs.next()) {
                cparStatus = rs.getString("status_id");
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception getting Status Type " + getClass().getName() + ".getEquivalentStatus()", e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (SQLException sqlEx) {
                throw new DAOException("Unable to close resources in " + getClass().getName() + ".getEquivalentStatus()",
                        sqlEx);
            }
        }
        return cparStatus;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) throws SQLException {
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        if (conn != null) conn.close();
    }

    public Map<String, String> getCparTypes(int type) throws DAOException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Map<String, String> cparTypeMap = new LinkedHashMap<String, String>();
        try {
            conn = getConnection();
            ps = conn.prepareStatement("SELECT TYPE,DESCRIPTION FROM GEN_FINDING_OBJ_TYPE WHERE TYPE <> ?");
            ps.setInt(1, type);
            rs = ps.executeQuery();
            cparTypeMap.put("", "Change To");
            while (rs.next()) {
                cparTypeMap.put(String.valueOf(rs.getInt("TYPE")), rs.getString("DESCRIPTION").trim());
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception getting cpar types in " + getClass().getName() + ".getCparTypes() method ", e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (SQLException e) {
                throw new DAOException("Unable to close resources in " + getClass().getName() + ".getCparTypes()", e);
            }
        }
        return cparTypeMap;
    }

    public Map<String, String> getAuditTypes(String locale, int businessId) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> auditTypeMap = new HashMap<String, String>();
        try {
            conn = getConnection();
            if(businessId!=MCASConstants.MCAS_DROPDOWN_BY_BUSSINES_NOT_REQUIRED){
                ps = conn.prepareStatement("SELECT ID,AUDIT_TYPE FROM M_AUDIT_TYPE_REF WHERE ID IN (SELECT ID_TABLE FROM DROPDOWN_BY_BUSINESS_VIEW WHERE TABLE_NAME='CPAR_SOURCE_TYPE_REF' AND BUSINESS_ID=?)");

                ps.setInt(1,businessId);
            }
            else{
                ps = conn.prepareStatement("SELECT ID,AUDIT_TYPE FROM M_AUDIT_TYPE_REF");
            }

            rs = ps.executeQuery();
            while (rs.next()) {
                final int id = rs.getInt("ID");
                String desc = new I18nServiceImpl().translate(locale, "M_AUDIT_TYPE_REF", id, rs.getString("AUDIT_TYPE"));
                auditTypeMap.put(Integer.toString(id), desc);
            }
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException("Exception in getting Audit Types :" + e.getMessage(), e);
        } finally {
            try {
                closeResources(conn, ps, rs);
            } catch (SQLException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new DAOException("Unable to close resources in " + getClass().getName() + ".getAuditTypes()", e);
            }
        }
        return auditTypeMap;
    }

    public Map<String, String> lookUpFeedbackCategories(boolean activeOnly, String locale) {
        Map<String, String> nonconformanceCategoryReferenceData = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            String queryString = "SELECT CB.COMPLAINT_CATEGORY_ID,CB.DESCRIPTION,CB.ACTIVE FROM COMPLAINT_CATEGORY CB ";
            if (activeOnly) {
                queryString += " WHERE CB.ACTIVE <> 'N' ";
            }
            queryString += " ORDER BY CB.DESCRIPTION ASC ";
            preparedStatement = connection.prepareStatement(
                    queryString);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int nonconformanceCategoryId = resultSet.getInt("COMPLAINT_CATEGORY_ID");

                String nonconformanceCategoryDescription = (iService.translate(locale, "COMPLAINT_CATEGORY", nonconformanceCategoryId, resultSet.getString("DESCRIPTION")));
                nonconformanceCategoryReferenceData.put(Integer.toString(nonconformanceCategoryId), nonconformanceCategoryDescription);
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return nonconformanceCategoryReferenceData;
    }

    public String lookUpFeedbackCategoryById(String nonconformanceCategoryId, String locale) {
        String nonconformanceCategoryDescription = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT CB.COMPLAINT_CATEGORY_ID,CB.DESCRIPTION,CB.ACTIVE FROM COMPLAINT_CATEGORY CB WHERE CB.COMPLAINT_CATEGORY_ID=?");
            preparedStatement.setString(1, nonconformanceCategoryId);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int id = resultSet.getInt("COMPLAINT_CATEGORY_ID");
                nonconformanceCategoryDescription = iService.translate(locale, "COMPLAINT_CATEGORY", id, resultSet.getString("DESCRIPTION"));
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return nonconformanceCategoryDescription;
    }

    public Map<String, String> lookUpIlTypes(String locale) {
        Map<String, String> ilTypes = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
        ilTypes.put("", selectOne);

        try {
            connection = getConnection();
            String queryString = "SELECT TYPE_ID,DESCRIPTION FROM IL_TYPE where active <> 'N' "
                    + " ORDER BY TYPE_ID ";
            preparedStatement = connection.prepareStatement(
                    queryString);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int typeId = resultSet.getInt("TYPE_ID");

                String desc = (iService.translate(locale, "IL_TYPE", typeId, resultSet.getString("DESCRIPTION")));
                ilTypes.put(Integer.toString(typeId), desc);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return ilTypes;
    }

    public Map<String, String> lookUpAllIssueForComplaint(String locale) {
        Map<String, String> allIssueForComplaint = new LinkedHashMap<String, String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String selectOne = I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.selectOne");
        allIssueForComplaint.put("", selectOne);

        try {
            connection = getConnection();
            String queryString = "SELECT COMPLAINT_ISSUE_ID, COMPLAINT_ISSUE_DESCRIPTION FROM COMPLAINT_ISSUE_REF WHERE ACTIVE_FLAG = 'Y' and complaint_issue_type_id in (1,2,3,4) ORDER BY COMPLAINT_ISSUE_ID";
            preparedStatement = connection.prepareStatement(
                    queryString);
            resultSet = preparedStatement.executeQuery();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int COMPLAINT_ISSUE_ID = resultSet.getInt("COMPLAINT_ISSUE_ID");

                String desc = (iService.translate(locale, "COMPLAINT_ISSUE_REF", COMPLAINT_ISSUE_ID, resultSet.getString("COMPLAINT_ISSUE_DESCRIPTION")));
                allIssueForComplaint.put(Integer.toString(COMPLAINT_ISSUE_ID), desc);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }

        return allIssueForComplaint;
    }
    /*
    public Map<String, String> getLocationsCreateExcel() throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            Map<String, String> result = new HashMap<String, String>();
            conn = getConnection();
            ps = conn.prepareStatement(LOCATION_CREATE_EXCEL_LKP);

            rs = ps.executeQuery();
            if (rs != null) {

                while (rs.next()) {
                    String locationId = rs.getString(1);
                    String locationShortDescription = rs.getString(2);
                    String regionId = rs.getString(3);
                    String mapKey = locationShortDescription.trim()+"-"+regionId.trim();

                    result.put(mapKey, locationId.trim());
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, String> getAllStatesByRegion() throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, String> result = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(STATES_BY_REGION_LKP);
            rs = ps.executeQuery();
            if (rs != null) {
                result = new HashMap<String, String>();

                while (rs.next()) {
                    String stateAbbr = rs.getString(2);
                    String regionId = rs.getString(3);
                    String stateId = rs.getString(1);
                    result.put(stateAbbr.trim()+"-"+regionId.trim(),stateId.trim());
                }
            }
            return result;
        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }
      */
    ///////////////

    public Map<String, String> getLocationsCreateExcel() throws DAOException, MCASException {
        return genericMapConstructor(LOCATION_CREATE_EXCEL_LKP,new LocationsMapResultSetHandler());
    }

    public Map<String, String> getAllStatesByRegion() throws DAOException, MCASException {
        return genericMapConstructor(STATES_BY_REGION_LKP,new StateByRegionMapResultSetHandler());
    }


    private Map<String, String> genericMapConstructor(String query,ResultMapHandler resultSetHandler) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            return resultSetHandler.getMap(rs);

        }
        catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

}
