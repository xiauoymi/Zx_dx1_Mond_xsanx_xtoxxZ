/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.testUtil.MCASTestUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockVarietyBatchDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockVarietyBatchDAOImpl extends VarietyBatchDAOImpl {
    protected void init() {
        //do nothing
    }

    public Map<String, VarietyBatch> getVarietyBatchData(String varietyPattern, String batchPattern) {
        return MCASTestUtil.getVarietyBatchData(varietyPattern, batchPattern);
    }

    public boolean insertVarietyBatch(List varietyBatchListParam) {
        return true;
    }

    public List getNewVarietyBatchData() throws MCASException {
        List varietyBatchList = new ArrayList();
        VarietyBatch vb = null;
        for (int i = 1; i <= 10; i++) {
            vb = new VarietyBatch(i, "Variety-" + i, "Batch-" + i);
            varietyBatchList.add(vb);
        }
        return varietyBatchList;
    }

    public List getInactivatedVarietyBatchData() throws MCASException {
        List varietyBatchList = new ArrayList();
        VarietyBatch vb = null;
        for (int i = 1; i <= 10; i++) {
            vb = new VarietyBatch(i, "Variety-" + i, "Batch-" + i);
            varietyBatchList.add(vb);
        }
        return varietyBatchList;
    }


    public void deleteDataFromVarietyBatchTempTable() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}