/*
 NonconformanceCategoryDaoImpl was created on Jan 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.exception.DatabaseException;

import java.sql.*;
import java.util.*;

/**
 * Filename:    $RCSfile: NonconformanceCategoryDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class NonconformanceCategoryDaoImpl extends BaseDAOImpl implements CheckboxItemDao {
    private static final String DELETE_COMPLAINT_ISSUES_SQL = "DELETE FROM COMPLAINT_ISSUES WHERE COMPLAINT_ID=? AND COMPLAINT_ISSUE_SOURCE=? ";
    static final String COMPLAINT_ISSUES_SQL = "INSERT INTO COMPLAINT_ISSUES ( " +
            "COMPLAINT_ISSUE_ID, COMPLAINT_ID, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE, COMPLAINT_ISSUE_SOURCE) " +
            "VALUES ( ?, ?, ?, ?, ?, ?, ?)";

    public NonconformanceCategoryDaoImpl() {
        // need explict constructor since super() throws checked exception
    }

    /**
     * Method to Display complaint category Based on the user's business
     *
     *
     * @param businessId
     * @param entryType
     * @param roles
     * @param appName
     * @return
     * @throws DAOException
     */
    public Map<String, List<CheckboxItem>> lookupCheckboxGroups(int businessId, String entryType, String locale, Map<String, Boolean> roles, String appName) {

        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
//        NonconformanceType nonconformanceTypeObj = null;
        Map<String, List<CheckboxItem>> categoryMap = new LinkedHashMap<String, List<CheckboxItem>>();
        String sqlQuery = "  select cit.complaint_issue_type_id,cit.description,ci.complaint_issue_id,ci.complaint_issue_description\n" +
                " from COMPLAINT_ISSUE_TYPE_REF cit, Complaint_issue_ref ci where cit.business_id = ? and cit.complaint_issue_type_id = ci.complaint_issue_type_id" +
                " and ci.active_flag = 'Y' and cit.entry_type_id = (select id from complaint_entry_type where type = ?) and cit.issue_type = 1\n" +
                " group by cit.complaint_issue_type_id,cit.description,ci.complaint_issue_id,complaint_issue_description\n" +
                " order by cit.complaint_issue_type_id asc";

        try {
            connection = getConnection();
            ps = connection.prepareStatement(sqlQuery);
            ps.setInt(1, businessId);
            ps.setString(2, entryType);
            rs = ps.executeQuery();
            if (rs != null) {
                int oldId = -1;
                int nonconformanceTypeId = -1;
                String nonconformanceTypeDescription = "";
                int nonconformanceCategoryId = -1;
                String nonconformanceCategoryDescription = "";
                List<CheckboxItem> nonconformanceCategoryList = null;
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    nonconformanceTypeId = rs.getInt("complaint_issue_type_id");
                    if (nonconformanceTypeId != oldId) {

                        nonconformanceTypeDescription = iService.translate(locale, "COMPLAINT_ISSUE_TYPE_REF", nonconformanceTypeId, rs.getString("description"));

                        if (!StringUtils.isNullOrEmpty(nonconformanceTypeDescription)) {
                            nonconformanceTypeDescription = nonconformanceTypeDescription.trim();
                        }
//                        nonconformanceTypeObj = new NonconformanceType(nonconformanceTypeId, nonconformanceTypeDescription);
//                        nonconformanceTypeMap.put(nonconformanceTypeId, nonconformanceTypeObj);
                        nonconformanceCategoryList = new ArrayList<CheckboxItem>();
                        oldId = nonconformanceTypeId;
                    }

                    nonconformanceCategoryId = rs.getInt("complaint_issue_id");
                    nonconformanceCategoryDescription = iService.translate(locale, "COMPLAINT_ISSUE_REF", nonconformanceCategoryId, rs.getString("complaint_issue_description"));

                    if (!StringUtils.isNullOrEmpty(nonconformanceCategoryDescription)) {
                        nonconformanceCategoryDescription = nonconformanceCategoryDescription.trim();
                    }
                    nonconformanceCategoryList.add(new CheckboxItem(nonconformanceCategoryDescription, false, nonconformanceCategoryId));
                    categoryMap.put(Integer.toString(nonconformanceTypeId), nonconformanceCategoryList);
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, ps, rs);
        }
        return categoryMap;

    }

    /**
     * Bhargava 05/21/2008
     * Method to Retreive issue ids for a complaint
     *
     * @param complaintId
     * @param entryType
     * @return
     */
    public Set<String> getSelectedItemsForRecord(int complaintId, String entryType) {
        Set<String> nonconformanceCategorySet = new HashSet<String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT COMPLAINT_ISSUE_ID FROM COMPLAINT_ISSUES WHERE COMPLAINT_ID = ? AND COMPLAINT_ISSUE_SOURCE = ?");
            preparedStatement.setInt(1, complaintId);
            preparedStatement.setString(2, entryType);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int nonconformanceCategoryId = resultSet.getInt("COMPLAINT_ISSUE_ID");
                nonconformanceCategorySet.add(Integer.toString(nonconformanceCategoryId));
            }

        } catch (SQLException e) {
            throw new DatabaseException("Error looking up audit areas for an audit", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return nonconformanceCategorySet;
    }

    public void insertCheckboxItemsForRecord(int complaint_id, String sourceType,
                                             List<CheckboxItem> selectedNonconformanceCategoryList) {

        PreparedStatement ps = null;
        ResultSet rs = null;
//        int rows = 0;

        Connection conn = getConnection();
        try {
            if (selectedNonconformanceCategoryList != null && selectedNonconformanceCategoryList.size() > 0) {
                ps = conn.prepareStatement(COMPLAINT_ISSUES_SQL);
                for (CheckboxItem item : selectedNonconformanceCategoryList) {
                    ps.setInt(1, item.getCheckboxItemId());
                    ps.setInt(2, complaint_id);
                    ps.setString(3, "APPLICATION");
                    ps.setString(4, "COMPLAINT ENTRY");
                    ps.setDate(5, new java.sql.Date(new java.util.Date().getTime()));
                    ps.setDate(6, new java.sql.Date(new java.util.Date().getTime()));
                    ps.setString(7, sourceType);
                    ps.executeUpdate();
                }
            }
            conn.commit();
//            return rows;
        } catch (SQLException e) {
            throw new DatabaseException("Error inserting nonconformance category", e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public void deleteCheckboxItemsForRecord(int cparId, String entryType) {
        Connection connection = null;
        try {
            connection = getConnection();
            deleteIssues(Integer.toString(cparId), connection, entryType);
            connection.commit();
        } catch (SQLException e) {
            throw new DatabaseException("Error inserting audit areas", e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, null, null);
        }
    }

    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    private void deleteIssues(String complaint_id, Connection conn, String entryType) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(DELETE_COMPLAINT_ISSUES_SQL);
            ps.setString(1, complaint_id);
            ps.setString(2, entryType);
            ps.executeUpdate();
        } finally {
            closeDBResources(null, ps, null);
        }
    }
}
