/*
/*
 ProgramConstants was created on Aug 12, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ProgramConstants {

    public static final String LOOKUP_ALL_PROGRAMS = "SELECT PROGRAM_ID, PROGRAM_DESC FROM PROGRAM_REF order by program_desc asc";
    public static final String PROGRAM_ID = "PROGRAM_ID";
    public static final String PROGRAM_DESC = "PROGRAM_DESC";
    public static final String LOOKUP_PROGRAM_BY_CRITERIA = "SELECT PROGRAM_ID, PROGRAM_DESC FROM PROGRAM_REF WHERE PROGRAM_ID = ?";
    public static final String PROGRAM_LIST = "programList";
    public static final String PROGRAM_ID_DEFAULT = "0";
    public static final String LOOKUP_CATEGORIES_BY_CRITERIA = "SELECT COMPLAINT_CATEGORY_ID as CATEGORY_ID , DESCRIPTION FROM COMPLAINT_CATEGORY CAT, PROGRAM_CATEGORY PC" +
            " WHERE CAT.COMPLAINT_CATEGORY_ID = PC.CATEGORY_ID AND CAT.ACTIVE = 'Y' AND PC.PROGRAM_ID = ?";
}