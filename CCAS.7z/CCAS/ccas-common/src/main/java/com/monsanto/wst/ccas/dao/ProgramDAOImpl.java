/*
 ProgramDAOImpl was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.Program;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ProgramDAOImpl extends BaseDAOImpl implements ProgramDAO {

    public Map<String, String> lookupAllPrograms() throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = conn.prepareStatement(ProgramConstants.LOOKUP_ALL_PROGRAMS);
            resultSet = ps.executeQuery();
            Map<String, String> programList = new LinkedHashMap<String, String>();
            programList.put("", I18nServiceImpl.lookupProperty("en", "com.monsanto.wst.ccas.selectOne"));
            while (resultSet.next()) {
                programList.put(Integer.toString(resultSet.getInt(ProgramConstants.PROGRAM_ID)),
                        resultSet.getString(ProgramConstants.PROGRAM_DESC));
            }
            return programList;
        }
        finally {
            closeDBResources(conn, ps, resultSet);
        }
    }

    public Program lookupProgramByCriteria(String programId) throws SQLException {
        Program program = null;
        Connection conn = getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = conn.prepareStatement(ProgramConstants.LOOKUP_PROGRAM_BY_CRITERIA);
            ps.setString(1, programId);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                program = new Program(resultSet.getLong(ProgramConstants.PROGRAM_ID),
                        resultSet.getString(ProgramConstants.PROGRAM_DESC));
            }
            return program;
        }
        finally {
            closeDBResources(conn, ps, resultSet);
        }
    }
}
