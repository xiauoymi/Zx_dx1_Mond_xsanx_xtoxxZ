package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.ReferenceDataRow;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 3, 2011
 * Time: 9:55:23 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ReferenceDataTablesDao {
    Map<Integer, String> getReferenceTablesInfo() throws DAOException, MCASException;

    Map<Integer, String> getReferenceTableMeta(int referenceTableId, int businessId) throws DAOException, MCASException;

    ReferenceDataRow getRowFromReferenceTable(int referenceTableId, int dataId) throws DAOException, MCASException;

    int saveReferenceDataRow(int referenceTableId, ReferenceDataRow row, int businessId) throws DAOException, MCASException;

    public boolean referenceTableHasActive(String referenceTableId) throws DAOException, MCASException;

    public boolean referenceTableHasSecondDescription(String referenceTableId) throws DAOException, MCASException;

    public Map<Integer, String> getReferenceDataTypes(String referenceTableId) throws DAOException, MCASException;

    public boolean referenceDataHasTypes(String referenceTableId) throws DAOException, MCASException;
}
