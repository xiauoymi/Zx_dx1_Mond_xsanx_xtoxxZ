package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.ReferenceDataRow;
import com.monsanto.wst.ccas.exception.MCASException;

import java.util.Map;
import java.util.TreeMap;
import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 2, 2011
 * Time: 6:27:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceDataTablesDaoImpl extends BaseDAOImpl implements ReferenceDataTablesDao {

    public Map<Integer, String> getReferenceTablesInfo() throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        Map<Integer, String> map = new TreeMap<Integer, String>();

        try {
            conn = getConnection();
            String query = "select id, pretty_table_name from reference_data_tables where enabled != 'N'";
            ps = conn.prepareStatement(query);

            rs = ps.executeQuery();
            while (rs.next()) {
                map.put(rs.getInt(1), rs.getString(2));
            }

            return map;

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<Integer, String> getReferenceTableMeta(int referenceTableId, int businessId) throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        Map<Integer, String> map = new TreeMap<Integer, String>();

        try {
            String tableName;
            String idCol;
            String descCol;
            String descCol2 = null;
            String activeCol;
            String dataQuery = null;
            String metaQuery =
                    "select actual_table_name, data_id_col, data_description_col1, data_description_col2, active_flag_col, use_business" +
                            " from reference_data_tables where id = ? and enabled != 'N'";
            String use_business="";
            conn = getConnection();
            ps = conn.prepareStatement(metaQuery);
            ps.setInt(1, referenceTableId);

            rs = ps.executeQuery();
            if (rs.next()) {
                tableName = rs.getString("ACTUAL_TABLE_NAME");
                idCol = rs.getString("DATA_ID_COL");
                descCol = rs.getString("DATA_DESCRIPTION_COL1");
                descCol2 = rs.getString("DATA_DESCRIPTION_COL2");
                activeCol = rs.getString("ACTIVE_FLAG_COL");
                 use_business=rs.getString("USE_BUSINESS");
                dataQuery = "SELECT " + idCol + ", " + descCol;
                if (descCol2 != null)
                    dataQuery += ", " + descCol2;
                dataQuery += ", " + activeCol + " FROM " + tableName + "";
                if(use_business!=null&&use_business.equalsIgnoreCase("Y")&&businessId!=-1){
                           dataQuery +=" where BUSINESS_ID="+businessId;
                }
            }

            if (dataQuery != null) {
                closeDBResources(null, ps, rs);

                ps = conn.prepareStatement(dataQuery);
                rs = ps.executeQuery();

                while (rs.next()) {
                    String desc = rs.getString(2).trim();

                    if (descCol2 != null)
                        desc += " " + rs.getString(3).trim();

                    map.put(rs.getInt(1), desc);
                }
            }

            return map;

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public ReferenceDataRow getRowFromReferenceTable(int referenceTableId, int dataId) throws DAOException, MCASException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        ReferenceDataRow row = null;

        try {
            String tableName;
            String idCol;
            String descCol;
            String descCol2 = null;
            String typeCol = null;
            String activeCol = null;
            String dataQuery = null;
            String metaQuery =
                    "select actual_table_name, data_id_col, data_description_col1, data_description_col2, active_flag_col, " +
                            "type_col from reference_data_tables where id = ? and enabled != 'N'";

            conn = getConnection();
            ps = conn.prepareStatement(metaQuery);
            ps.setInt(1, referenceTableId);

            rs = ps.executeQuery();
            if (rs.next()) {
                tableName = rs.getString("ACTUAL_TABLE_NAME");
                idCol = rs.getString("DATA_ID_COL");
                descCol = rs.getString("DATA_DESCRIPTION_COL1");
                descCol2 = rs.getString("DATA_DESCRIPTION_COL2");
                typeCol = rs.getString("TYPE_COL");
                activeCol = rs.getString("ACTIVE_FLAG_COL");

                dataQuery = "SELECT " + idCol + ", " + descCol;

                if (descCol2 != null)
                    dataQuery += ", " + descCol2;

                if (typeCol != null)
                    dataQuery += ", " + typeCol;

                if (activeCol != null)
                    dataQuery += ", " + activeCol;

                dataQuery += " FROM " + tableName + " WHERE " + idCol + " = " + dataId;
            }

            if (dataQuery != null) {
                closeDBResources(null, ps, rs);

                ps = conn.prepareStatement(dataQuery);
                rs = ps.executeQuery();

                if (rs.next()) {
                    int i = 3;
                    row = new ReferenceDataRow();
                    row.setDataId(rs.getInt(1));
                    row.setDataValue(rs.getString(2));

                    if (descCol2 != null) {
                        row.setDataValue2(rs.getString(i));
                        i++;
                    }

                    if (typeCol != null) {

                        row.setType(rs.getString(i));
                        i++;
                    }

                    if (activeCol == null)
                        row.setActive(true);
                    else
                        row.setActive("Y".equals(rs.getString(i)));
                }
            }

            return row;

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public int saveReferenceDataRow(int referenceTableId, ReferenceDataRow row, int businessId) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            String tableName;
            String idCol;
            String descCol;
            String descCol2 = null;
            String typeCol = null;
            String activeCol;
            String use_business=null;
            String metaQuery =
                    "select actual_table_name, data_id_col, data_description_col1, data_description_col2, active_flag_col,use_business, " +
                            "type_col from reference_data_tables where id = ? and enabled != 'N'";

            conn = getConnection();
            ps = conn.prepareStatement(metaQuery);
            ps.setInt(1, referenceTableId);

            rs = ps.executeQuery();
            if (rs.next()) {
                tableName = rs.getString("ACTUAL_TABLE_NAME");
                idCol = rs.getString("DATA_ID_COL");
                descCol = rs.getString("DATA_DESCRIPTION_COL1");
                descCol2 = rs.getString("DATA_DESCRIPTION_COL2");
                typeCol = rs.getString("TYPE_COL");
                activeCol = rs.getString("ACTIVE_FLAG_COL");
                use_business=rs.getString("USE_BUSINESS");
                closeDBResources(null, ps, rs);

                //update
                //note: we do not update type field.
                if (row.getDataId() >= 0) {

                    String activeUpdate = null;
                    String desc2Update = null;
                    String descUpdate = "UPDATE " + tableName + " SET " + descCol + " = '" + row.getDataValue()
                            + "' WHERE " + idCol + " = " + row.getDataId();

                    if (descCol2 != null) {
                        desc2Update = "UPDATE " + tableName + " SET " + descCol2 + " = '" + row.getDataValue2()
                                + "' WHERE " + idCol + " = " + row.getDataId();
                    }

                    if (activeCol != null) {
                        activeUpdate = "UPDATE " + tableName + " SET " + activeCol + " = '" + row.getActiveLetter()
                                + "' WHERE " + idCol + " = " + row.getDataId();
                    }

                    ps = conn.prepareStatement(descUpdate);
                    ps.executeUpdate();

                    if (descCol2 != null) {
                        closeDBResources(null, ps, rs);
                        ps = conn.prepareStatement(desc2Update);
                        ps.executeUpdate();
                    }

                    if (activeUpdate != null) {
                        closeDBResources(null, ps, rs);
                        ps = conn.prepareStatement(activeUpdate);
                        ps.executeUpdate();
                    }
                }
                //insert
                else {
                    String idQuery = "SELECT MAX(" + idCol + ")+1 FROM " + tableName;

                    ps = conn.prepareStatement(idQuery);
                    rs = ps.executeQuery();

                    rs.next();
                    row.setDataId(rs.getInt(1));

                    String insert = "INSERT INTO " + tableName + " (" + idCol + "," + descCol;

                    if (descCol2 != null) {
                        insert += "," + descCol2;
                    }

                    if (typeCol != null) {
                        insert += "," + typeCol;
                    }

                    if (activeCol != null) {
                        insert += "," + activeCol;
                    }

                    if(use_business!=null&&use_business.equalsIgnoreCase("Y")&&businessId!=-1){

                       insert+=",business_id";
                    }

                    insert += ") values (" + row.getDataId() + ", '" + row.getDataValue() + "'";

                    if (descCol2 != null) {
                        insert += ", '" + row.getDataValue2() + "'";
                    }

                    if (typeCol != null) {
                        insert += ", '" + row.getType() + "'";
                    }

                    if (activeCol != null) {
                        insert += ", '" + row.getActiveLetter() + "'";
                    }

                    if(use_business!=null&&use_business.equalsIgnoreCase("Y")&&businessId!=-1){

                       insert+=","+businessId;
                    }

                    insert += ")";

                    closeDBResources(null, ps, rs);
                    ps = conn.prepareStatement(insert);
                    ps.executeUpdate();
                }
            }

            conn.commit();
            return row.getDataId();

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public boolean referenceTableHasActive(String referenceTableId) throws DAOException, MCASException {

        try {
            Integer.parseInt(referenceTableId);
        }
        catch (Exception e) {
            return true;
        }

        return referenceTableHas(referenceTableId,
                "select active_flag_col from reference_data_tables where id = ? and enabled != 'N'");
    }

    public boolean referenceTableHasSecondDescription(String referenceTableId) throws DAOException, MCASException {

        return referenceTableHas(referenceTableId,
                "select data_description_col2 from reference_data_tables where id = ? and enabled != 'N'");
    }

    private boolean referenceTableHas(String referenceTableId, String query) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, referenceTableId);

            rs = ps.executeQuery();
            rs.next();
            return rs.getString(1) != null;

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<Integer, String> getReferenceDataTypes(String referenceTableId) throws DAOException, MCASException {

        String typeId = getReferenceDataType(referenceTableId);

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        Map<Integer, String> map = new TreeMap<Integer, String>();

        try {
            String table;
            String id;
            String desc;

            conn = getConnection();
            String query = "select actual_table_name, data_id_col, data_description_col1 from reference_data_type where id = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, typeId);

            rs = ps.executeQuery();
            if (rs.next()) {
                table = rs.getString(1);
                id = rs.getString(2);
                desc = rs.getString(3);

                String dataQuery = "select " + id + ", " + desc + " from " + table;

                closeDBResources(null, ps, rs);
                ps = conn.prepareStatement(dataQuery);
                rs = ps.executeQuery();

                while (rs.next()) {
                    map.put(rs.getInt(1), rs.getString(2));
                }
            }

            return map;

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public boolean referenceDataHasTypes(String referenceTableId) throws DAOException, MCASException {
        return getReferenceDataType(referenceTableId) != null;
    }

    private String getReferenceDataType(String referenceTableId) throws DAOException, MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        String type = null;

        try {
            String query = "select type_id from reference_data_tables where id = ? and enabled != 'N'";

            conn = getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, referenceTableId);

            rs = ps.executeQuery();
            rs.next();
            type = rs.getString("type_id");

        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);
            else
                throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
        return type;
    }
}