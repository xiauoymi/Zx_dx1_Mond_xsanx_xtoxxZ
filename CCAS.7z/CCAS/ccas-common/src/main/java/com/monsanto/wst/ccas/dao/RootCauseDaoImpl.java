package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.exception.DatabaseException;
import com.monsanto.Util.StringUtils;

import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Mar 30, 2011
 * Time: 10:38:17 AM
 * To change this template use File | Settings | File Templates.
 */
public class RootCauseDaoImpl extends BaseDAOImpl implements CheckboxItemDao {
    private static final String DELETE_ROOT_CAUSES_SQL = "DELETE FROM ROOT_CAUSES WHERE RECORD_ID=? AND ROOT_CAUSE_SOURCE=? ";
    static final String ROOT_CAUSES_SQL = "INSERT INTO ROOT_CAUSES ( " +
            "ROOT_CAUSE_ID, RECORD_ID, ROW_USER_ID, " +
            "ROW_TASK_ID, ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROOT_CAUSE_SOURCE) " +
            "VALUES ( ?, ?, ?, ?, ?, ?, ?)";

    public RootCauseDaoImpl() {
        // need explict constructor since super() throws checked exception
    }

    public Map<String, List<CheckboxItem>> lookupCheckboxGroups(int businessId, String entryType, String locale, Map<String, Boolean> roles, String appName) {

        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Map<String, List<CheckboxItem>> causeMap = new LinkedHashMap<String, List<CheckboxItem>>();
        String sqlQuery =null;
        if(appName.equalsIgnoreCase("MCAS")){
        sqlQuery = "  select rct.root_cause_type_id,rct.description,rc.root_cause_id,rc.root_cause_description,rc.active_flag\n" +
                " from ROOT_CAUSE_TYPE_REF rct, ROOT_CAUSE_ref rc where rct.business_id = ? and rct.root_cause_type_id = rc.root_cause_type_id" +
                "  and rct.entry_type_id = (select id from complaint_entry_type where type = ?)  and rct.description in ('Rootcause 1','Rootcause 2') \n" +
                " group by rct.root_cause_type_id,rct.description,rc.root_cause_id,root_cause_description,rc.active_flag\n" +
                " order by rct.root_cause_type_id,rc.root_cause_description asc";
        }
        else{
            sqlQuery = "  select rct.root_cause_type_id,rct.description,rc.root_cause_id,rc.root_cause_description\n" +
                    " from ROOT_CAUSE_TYPE_REF rct, ROOT_CAUSE_ref rc where rct.business_id = ? and rct.root_cause_type_id = rc.root_cause_type_id" +
                    " and rc.active_flag = 'Y' and rct.entry_type_id = (select id from complaint_entry_type where type = ?)\n" +
                    " group by rct.root_cause_type_id,rct.description,rc.root_cause_id,root_cause_description\n" +
                    " order by rct.root_cause_type_id,rc.root_cause_description asc";

        }

        try {
            connection = getConnection();
            ps = connection.prepareStatement(sqlQuery);
            ps.setInt(1, businessId);
            ps.setString(2, entryType);
            rs = ps.executeQuery();
            if (rs != null) {
                int oldId = -1;
                int causeTypeId;
                int rootCauseId;
                String rootCauseDescription;
                List<CheckboxItem> rootCauseList = new ArrayList<CheckboxItem>();
                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    causeTypeId = rs.getInt("root_cause_type_id");
                    if (causeTypeId != oldId) {
                        rootCauseList = new ArrayList<CheckboxItem>();
                        oldId = causeTypeId;
                    }

                    rootCauseId = rs.getInt("root_cause_id");
                    rootCauseDescription = iService.translate(locale, "ROOT_CAUSE_REF", rootCauseId, rs.getString("root_cause_description"));
                    boolean inactive=false;
                    if(appName.equalsIgnoreCase("MCAS")){
                        inactive=rs.getString("active_flag").equalsIgnoreCase("N")?true:false;
                    }
                    if (!StringUtils.isNullOrEmpty(rootCauseDescription)) {
                        rootCauseDescription = rootCauseDescription.trim();
                    }
                    rootCauseList.add(new CheckboxItem(rootCauseDescription, false, rootCauseId,inactive));
                    causeMap.put(Integer.toString(causeTypeId), rootCauseList);
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, ps, rs);
        }
        return causeMap;
    }

    public Set<String> getSelectedItemsForRecord(int recordId, String entryType) {
        Set<String> rootCauseSet = new HashSet<String>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(
                    "SELECT ROOT_CAUSE_ID FROM ROOT_CAUSES WHERE RECORD_ID = ? AND ROOT_CAUSE_SOURCE = ?");
            preparedStatement.setInt(1, recordId);
            preparedStatement.setString(2, entryType);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                rootCauseSet.add(Integer.toString(resultSet.getInt("ROOT_CAUSE_ID")));
            }

        } catch (SQLException e) {
            throw new DatabaseException("Error looking up Root Cause", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, preparedStatement, resultSet);
        }
        return rootCauseSet;
    }

    public void insertCheckboxItemsForRecord(int recordId, String sourceType,
                                             List<CheckboxItem> selectedRootCauseList) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        Connection conn = getConnection();
        try {
            if (selectedRootCauseList != null && selectedRootCauseList.size() > 0) {
                ps = conn.prepareStatement(ROOT_CAUSES_SQL);
                for (CheckboxItem item : selectedRootCauseList) {
                    ps.setInt(1, item.getCheckboxItemId());
                    ps.setInt(2, recordId);
                    ps.setString(3, "APPLICATION");
                    ps.setString(4, "COMPLAINT ENTRY");
                    ps.setDate(5, new java.sql.Date(new java.util.Date().getTime()));
                    ps.setDate(6, new java.sql.Date(new java.util.Date().getTime()));
                    ps.setString(7, sourceType);
                    ps.executeUpdate();
                }
            }
            conn.commit();

        } catch (SQLException e) {
            throw new DatabaseException("Error inserting Root Cause", e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public void deleteCheckboxItemsForRecord(int recordId, String entryType) {
        Connection connection = null;
        try {
            connection = getConnection();
            deleteIssues(Integer.toString(recordId), connection, entryType);
            connection.commit();
        } catch (SQLException e) {
            throw new DatabaseException("Error inserting Root Causes", e);
        } finally {
            MCASResourceUtil.closeDBResources(connection, null, null);
        }
    }

    private void deleteIssues(String recordId, Connection conn, String entryType) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(DELETE_ROOT_CAUSES_SQL);
            ps.setString(1, recordId);
            ps.setString(2, entryType);
            ps.executeUpdate();
        } finally {
            closeDBResources(null, ps, null);
        }
    }


    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale){
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Map<String, List<CheckboxItem>> causeMap = new LinkedHashMap<String, List<CheckboxItem>>();
        String sqlQuery = "  select rc.root_cause_description\n,rc.root_cause_id,rc.active_flag" +
                " from ROOT_CAUSE_ref rc where parent_root_cause_id=?" +
                " " +

                " order by rc.root_cause_description asc";
        List<CheckboxItem> rootCauseList = new ArrayList<CheckboxItem>();

        try {
                connection = getConnection();
            ps = connection.prepareStatement(sqlQuery);
            ps.setInt(1, parentRootCause);
            rs = ps.executeQuery();
            if (rs != null) {
                int oldId = -1;
                int causeTypeId;
                int rootCauseId;
                String rootCauseDescription;

                I18nServiceImpl iService = new I18nServiceImpl();

                while (rs.next()) {
                    rootCauseId = rs.getInt("root_cause_id");
                    rootCauseDescription = iService.translate(locale, "ROOT_CAUSE_REF", rootCauseId, rs.getString("root_cause_description"));

                    if (!StringUtils.isNullOrEmpty(rootCauseDescription)) {
                        rootCauseDescription = rootCauseDescription.trim();
                    }
                    rootCauseList.add(new CheckboxItem(rootCauseDescription, false, rootCauseId));

                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            rootCauseList.add(new CheckboxItem(e.getMessage(), false, 1));
        } finally {
            MCASResourceUtil.closeDBResources(connection, ps, rs);
        }

        return rootCauseList;
    }

}
