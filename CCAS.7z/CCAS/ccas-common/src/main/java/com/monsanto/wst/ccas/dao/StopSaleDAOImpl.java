/*
 * Created on May 9, 2005
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.model.StopSaleFilter;
import com.monsanto.wst.ccas.model.StopSaleListObject;
import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import org.apache.log4j.Category;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author rdesai2
 */
public class StopSaleDAOImpl extends BaseDAOImpl implements StopSaleDAO {

    private static final Category logger = Category.getInstance(StopSaleDAOImpl.class.getName());

    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    NonconformanceCategoryDaoImpl ncDao = new NonconformanceCategoryDaoImpl();
    RootCauseDaoImpl rcDao = new RootCauseDaoImpl();
    FunctionalAreaDaoImpl aaDao = new FunctionalAreaDaoImpl();

    /**
     * Constructor.
     *
     * @throws DAOException
     */
    public StopSaleDAOImpl() {

    }

    public String insertStopSale(StopSaleObject stopSale) throws DAOException {

//    logger.info("StopSaleDAO: Executing insertStopSale() operation...");

        //**Imp Variables...
        int stopSaleID = 0;
        String stopSaleNumber = "";

        Date oracleSysdate = new Date(System.currentTimeMillis());

        Connection conn = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            //**Get Connection...
            conn = getConnection();

            //**Get the oracle sysdate...
            //oracleSysdate = getOracleSysDate(conn);

            //**Get the stopSale_seq value...
            stopSaleID = getStopSaleSeqValue(conn);
            stopSale.setStopSaleID(String.valueOf(stopSaleID));
            //**Get the auto-generated stopSale_no...
            stopSaleNumber = createStopSaleNumber(stopSale, conn);

            //**Perform Insert-Operation...dynamic query...
            insertStopSaleObject(stopSaleID, stopSaleNumber, oracleSysdate, stopSale, conn);

            //**Insert StopSale Doc...dynamic query...
            insertStopSaleDoc(stopSaleID, oracleSysdate, stopSale, conn);

            //**Insert StopSale Variety/Batch...
            insertStopSaleVarietyBatch(stopSaleID, stopSale, conn);

            //****Insert Reasons...
            if (stopSale.isSeedCount()) {
                insertStopSaleRef(stopSaleID, "1", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isGermination()) {
                insertStopSaleRef(stopSaleID, "2", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isPurity()) {
                insertStopSaleRef(stopSaleID, "3", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isTagDate()) {
                insertStopSaleRef(stopSaleID, "4", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isOtherReason()) {
                insertStopSaleRef(stopSaleID, "5", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }

            //****Insert Action Flags...
            if (stopSale.isReLabel()) {
                insertStopSaleRef(stopSaleID, "1", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isRecount()) {
                insertStopSaleRef(stopSaleID, "2", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isDump()) {
                insertStopSaleRef(stopSaleID, "3", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isRestrict()) {
                insertStopSaleRef(stopSaleID, "4", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isOtherActionFlag()) {
                insertStopSaleRef(stopSaleID, "5", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }

            ncDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedNonconformanceCategoryList());
            rcDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedRootCauseList());
            aaDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedFunctionalAreas());


//      logger.info("Stop Sale Insert done...!!!");

            //**Return both the stopsale-number and stopSale_id
            return stopSaleNumber + ";" + stopSaleID;

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting connection: ", e);
            throw new DAOException(e);
        }
        finally {
            try {
                //**Close the result sets, statement and connection.
                if (rs != null)
                    rs.close();

                if (ps != null)
                    ps.close();

                closeDBResources(conn, null, null);
            }
            catch (SQLException ex) {
                MCASLogUtil.logError("SQLException while closing: ", ex);
                throw new DAOException(ex);
            }
        }
    }


    public boolean updateStopSale(StopSaleObject stopSale) throws DAOException {

//    logger.info("StopSaleDAO: Executing updateStopSale() operation...");

        int stopSaleID = 0;

        //**Imp Variables...
        if (stopSale.getStopSaleID() != null) {
            stopSaleID = Integer.parseInt(stopSale.getStopSaleID());
        }

        Date oracleSysdate = new Date(System.currentTimeMillis());

        Connection conn = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            //**Get Connection...
            conn = getConnection();

            //**Get the oracle sysdate...
            //oracleSysdate = getOracleSysDate(conn);

            //**Perform Update-Operation...dynamic query...
            updateStopSaleObject(stopSaleID, oracleSysdate, stopSale, conn);

            //**Update StopSale Doc...dynamic query...
            updateStopSaleDoc(stopSaleID, oracleSysdate, stopSale, conn);


            //**Delete existing variety, batch, reason and action-flag...
            deleteStopSaleRef(stopSaleID, conn);

            //**Insert StopSale Variety/Batch...
            insertStopSaleVarietyBatch(stopSaleID, stopSale, conn);

            //****Insert Reasons...
            if (stopSale.isSeedCount()) {
                insertStopSaleRef(stopSaleID, "1", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isGermination()) {
                insertStopSaleRef(stopSaleID, "2", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isPurity()) {
                insertStopSaleRef(stopSaleID, "3", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isTagDate()) {
                insertStopSaleRef(stopSaleID, "4", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }
            if (stopSale.isOtherReason()) {
                insertStopSaleRef(stopSaleID, "5", StopSaleDAOSQLConstants.INSERT_STOP_SALE_REASON, conn);
            }

            //****Insert Action Flags...
            if (stopSale.isReLabel()) {
                insertStopSaleRef(stopSaleID, "1", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isRecount()) {
                insertStopSaleRef(stopSaleID, "2", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isDump()) {
                insertStopSaleRef(stopSaleID, "3", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isRestrict()) {
                insertStopSaleRef(stopSaleID, "4", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }
            if (stopSale.isOtherActionFlag()) {
                insertStopSaleRef(stopSaleID, "5", StopSaleDAOSQLConstants.INSERT_STOP_SALE_ACTION_FLAG, conn);
            }

            ncDao.deleteCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S");
            rcDao.deleteCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S");
            aaDao.deleteCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S");
            ncDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedNonconformanceCategoryList());
            rcDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedRootCauseList());
            aaDao.insertCheckboxItemsForRecord(Integer.parseInt(stopSale.getStopSaleID()), "S", stopSale.getSelectedFunctionalAreas());


//      logger.info("Stop Sale Update done...!!!");

            //**Return boolean
            return true;

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting connection: ", e);
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private int insertStopSaleVarietyBatch(int stopSaleID, StopSaleObject stopSale, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        try {
            int rows = 0;
            for (VarietyBatch varietyBatch : stopSale.getVarietyBatchList()) {
                if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(StopSaleDAOSQLConstants.INSERT_STOP_SALE_BATCH_SQL);
                    ps.setLong(1, stopSaleID);
                    ps.setString(2, varietyBatch.getVarietyDesc());
                    ps.setString(3, varietyBatch.getBatchNumber());

                    rows += ps.executeUpdate();
                } else if (StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        !StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(StopSaleDAOSQLConstants.INSERT_STOP_SALE_BATCH_NULL_VARIETY_SQL);
                    ps.setLong(1, stopSaleID);
                    ps.setString(2, varietyBatch.getBatchNumber());

                    rows += ps.executeUpdate();

                } else if (!StringUtils.isNullOrEmpty(varietyBatch.getVarietyDesc()) &&
                        StringUtils.isNullOrEmpty(varietyBatch.getBatchNumber())) {
                    ps = conn.prepareStatement(StopSaleDAOSQLConstants.INSERT_STOP_SALE_BATCH_NULL_BATCH_SQL);
                    ps.setLong(1, stopSaleID);
                    ps.setString(2, varietyBatch.getVarietyDesc());

                    rows += ps.executeUpdate();
                }
            }
            conn.commit();
            return rows;
        } catch (SQLException e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(null, ps, null);
        }
    }

    private void setLongIfNotNull(PreparedStatement ps, int parameterIndex, Long value) throws SQLException {
        if (value == null || (value == 0)) {
            ps.setNull(parameterIndex, Types.INTEGER);
        } else {
            ps.setLong(parameterIndex, value);
        }
    }

    public StopSaleObject getStopSale(int stopSaleID) throws DAOException {

//    logger.info("StopSaleDAO: Executing getStopSale() for stop_Sale_id: " + stopSaleID);

        Connection conn = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        StopSaleObject stopSale = new StopSaleObject();

        try {
            //**Get Connection...
            conn = getConnection();

            //**Implement View Table: Stop_Sale (each function sets diff parts of stopSale...)
            getStopSaleObj(stopSaleID, stopSale, conn);

            //**Implement View Table: Stop_Sale_DOC
            getStopSaleDoc(stopSaleID, stopSale, conn);

            getStopSaleVarietyBatch(stopSaleID, stopSale, conn);

            //**Implement View Table: Stop_Sale_REASON
            getStopSaleReason(stopSaleID, stopSale, conn);

            //**Implement View Table: Stop_Sale_ACTION_FLAG
            getStopSaleAction(stopSaleID, stopSale, conn);

            //**Implement View Table: CPAR
            getStopSaleCar(stopSaleID, stopSale, conn);

            getStopSaleAttachments(stopSaleID, stopSale, conn);

//      logger.info("GET Stop_Sale done...!!!");

            //**Return boolean
            return stopSale;

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting connection: ", e);
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws DAOException {

        Connection conn = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        int stopSaleID = 0;

        try {
            conn = getConnection();

            ps = conn.prepareStatement("SELECT STOP_SALE_ID FROM STOP_SALE WHERE CONTROL_NUMBER = '" + stopSaleNumber + "'");

            rs = ps.executeQuery();

            while (rs.next()) {
                stopSaleID = rs.getInt("STOP_SALE_ID");
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }

        return getStopSale(stopSaleID);
    }

    public String getStopSaleNumberFromID(int stopSaleID) throws DAOException {
        Connection conn = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        String stopSaleNumber = "";

        try {
            //**Get Connection...
            conn = getConnection();

            try {
                ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_NO);
                ps.setInt(1, stopSaleID);

                rs = ps.executeQuery();

                while (rs.next()) {
                    stopSaleNumber = rs.getString("STOP_SALE_NUMBER");
                }
            }
            catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
            finally {
                closeDBResources(conn, ps, rs);
            }

            return stopSaleNumber;

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting connection: ", e);
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, Object> getStopSaleList(StopSaleListObject stopSale, String intPage, String sortCrit,
                                               String sortOrd, String locale) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        StringBuffer whereClause = new StringBuffer();
        List<String> paramList = new ArrayList<String>();
        Map<String, Object> stopSaleMap = new LinkedHashMap<String, Object>();

        try {
            int Page = Integer.parseInt(intPage);

            if ((stopSale.getControlNumber() != null) && !(stopSale.getControlNumber().equals("")))
                paramList.add("controlNumber");
            if ((stopSale.getStatus() != null) && !(stopSale.getStatus().equals("")) && !(stopSale.getStatus().equals("0")))
                paramList.add("status");
            if ((stopSale.getResponsibleLocation() != null) && !(stopSale.getResponsibleLocation().equals("")))
                paramList.add("responsibleLocation");
            if ((stopSale.getRegion() != null) && !(stopSale.getRegion().equals("")) && !(stopSale.getRegion().equals("0")))
                paramList.add("region");
            if ((stopSale.getCrop() != null) && !(stopSale.getCrop().equals("")))
                paramList.add("crop");
            if ((stopSale.getDealer() != null) && !(stopSale.getDealer().equals("")))
                paramList.add("dealer");
            if ((stopSale.getFillingLocation() != null) && !(stopSale.getFillingLocation().equals("")))
                paramList.add("fillingLocation");
            if ((stopSale.getShippingLocation() != null) && !(stopSale.getShippingLocation().equals("")))
                paramList.add("shippingLocation");
            if ((stopSale.getSalesYear() != null) && !(stopSale.getSalesYear().equals("")) &&
                    !(stopSale.getSalesYear().equals("0")))
                paramList.add("salesYear");
            if ((stopSale.getInitiatedBy() != null) && !(stopSale.getInitiatedBy().equals("")))
                paramList.add("initiatedBy");
            //Add a stop_sale_business_id column
            if ((stopSale.getStopSaleBusinessId() != null) && !("".equals(stopSale.getStopSaleBusinessId()))) {
                paramList.add("stopSaleBusinssId");
            }
            if ((stopSale.getMaterialGroupCode() != 0)) {
                paramList.add("materialGroupCode");
            }
            if ((stopSale.getMaterialGroupPricingCode() != 0)) {
                paramList.add("materialGroupPricingCode");
            }

            conn = getConnection();

            if (paramList.size() > 0) {
                whereClause.append(" WHERE ");
            }

            for (int i = 0; i < paramList.size(); i++) {
                if (paramList.get(i).equals("controlNumber")) {
                    whereClause.append("UPPER(S.CONTROL_NUMBER) = UPPER('").append(stopSale.getControlNumber().trim())
                            .append("')");
                }
                if (paramList.get(i).equals("status")) {
                    whereClause.append("S.STATUS_ID = '").append(stopSale.getStatus()).append("'");
                }
                if (paramList.get(i).equals("responsibleLocation")) {
                    whereClause.append("S.RESPONSIBLE_PLANT_CODE = '").append(stopSale.getResponsibleLocation()).append("'");
                }
                if (paramList.get(i).equals("region")) {
                    whereClause.append("S.REGION_ID = '").append(stopSale.getRegion()).append("'");
                }
                if (paramList.get(i).equals("crop")) {
                    whereClause.append("S.CROP_ID = '").append(stopSale.getCrop()).append("'");
                }
                if (paramList.get(i).equals("dealer")) {
                    whereClause.append("UPPER(S.DEALER) LIKE UPPER('").append(stopSale.getDealer()).append("%')");
                }
                if (paramList.get(i).equals("fillingLocation")) {
                    whereClause.append("S.REPORTING_LOCATION_CODE = '").append(stopSale.getFillingLocation()).append("'");
                }
                if (paramList.get(i).equals("shippingLocation")) {
                    whereClause.append("S.SHIPPING_LOCATION_CODE = '").append(stopSale.getShippingLocation()).append("'");
                }
                if (paramList.get(i).equals("salesYear")) {
                    whereClause.append("S.SALES_YEAR_ID = '").append(stopSale.getSalesYear()).append("'");
                }
                if (paramList.get(i).equals("initiatedBy")) {
                    whereClause.append("UPPER(S.REPORT_INITIATOR) LIKE UPPER('").append(stopSale.getInitiatedBy()).append("%')");
                }
                if (paramList.get(i).equals("stopSaleBusinssId")) {
                    int stopSaleBusinessId = Integer.parseInt(stopSale.getStopSaleBusinessId());
                    whereClause.append("S.STOP_SALE_BUSINESS_ID = ").append(stopSaleBusinessId);
                }
                if (paramList.get(i).equals("materialGroupCode")) {
                    int materialGroupCode = stopSale.getMaterialGroupCode();
                    whereClause.append("S.MATERIAL_GROUP_ID = ").append(materialGroupCode);
                }
                if (paramList.get(i).equals("materialGroupPricingCode")) {
                    int materialGroupPricingCode = stopSale.getMaterialGroupPricingCode();
                    whereClause.append("S.MATERIAL_GROUP_PRICING_ID = ").append(materialGroupPricingCode);
                }
                if (i < paramList.size() - 1)
                    whereClause.append(" AND ");
            }

            whereClause.append(" AND " + StopSaleDAOSQLConstants.DELETE_STOP_SALE_DUPLICATES);

            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_LIST_COUNT + whereClause.toString());

//      logger.info(StopSaleDAOSQLConstants.GET_STOP_SALE_LIST_COUNT + whereClause.toString());

            rs = ps.executeQuery();

            if (rs.next()) {
                stopSaleMap.put("maxRows", rs.getString("MAX_ROWS"));
            }

            whereClause.append(" ORDER BY Lower(").append(sortCrit).append(") ").append(sortOrd)
                    .append(" )) WHERE RANKING BETWEEN ").append((Page * 10) - 9).append(" AND ").append(Page * 10);


            MCASResourceUtil.closeDBResources(null, ps, rs);

            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_LIST + whereClause.toString());

//      logger.info(StopSaleDAOSQLConstants.GET_STOP_SALE_LIST + whereClause.toString());

            rs = ps.executeQuery();

            while (rs.next()) {

                StopSaleListObject stopSaleRow = new StopSaleListObject();

                stopSaleRow.setStopSaleID(rs.getString("STOP_SALE_ID"));
                stopSaleRow.setControlNumber(rs.getString("CONTROL_NUMBER"));

                int statusId = rs.getInt("STATUS_ID");
                I18nServiceImpl iService = new I18nServiceImpl();
                String statusDesc = iService.translate(locale, "STATUS_REF", statusId, rs.getString("STATUS"));
                stopSaleRow.setStatus(statusDesc);

                stopSaleRow.setResponsibleLocation(rs.getString("RESPONSIBLE_LOCATION"));
                stopSaleRow.setInvestigationFindings(
                        trimInvestigationText(rs.getString("INVESTIGATION_FINDINGS")));//Display Investigation Findings

                int regionId = rs.getInt("REGION_ID");
                String regionDesc = iService.translate(locale, "REGION_REF", regionId, rs.getString("REGION"));
                stopSaleRow.setRegion(regionDesc);

                int cropId = rs.getInt("CROP_ID");
                String cropDesc = iService.translate(locale, "CROP_REF", cropId, rs.getString("CROP"));
                stopSaleRow.setCrop(cropDesc);

                stopSaleRow.setDealer(rs.getString("DEALER"));
                stopSaleRow.setStopSaleBusinessId(rs.getString("STOP_SALE_BUSINESS_ID"));
                //Set the Stop Sale Business ID
                // stopSaleRow.setStopSaleBusinessId(Integer.toString(rs.getInt("STOP_SALE_BUSINESS_ID")));

                stopSaleMap.put(rs.getString("STOP_SALE_ID"), stopSaleRow);

            }

            return stopSaleMap;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private String trimInvestigationText(String investigationFindings) {
        return MCASUtil.trimDescriptionText(investigationFindings);
    }

    public Map<String, RowBean> getStopSaleReport(StopSaleFilter stopSaleFilter, String locale) throws DAOException {
        StringBuffer whereClause = new StringBuffer();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            addFiltersToWhereClause(stopSaleFilter, whereClause);
            String sql = getStopSaleQuerySQL(stopSaleFilter, whereClause.toString());
//      logger.info(sql);
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            int rowCount = 0;
            Map<String, RowBean> hash = new HashMap<String, RowBean>();
            while (rs.next()) {
                rowCount++;
                RowBean rowBean = getRowBeanFromResultSet(rs, locale);
                hash.put(Integer.toString(rowCount), rowBean);
            }
            return hash;
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private String getStopSaleQuerySQL(StopSaleFilter stopSaleFilter, String whereClause) {
        StringBuffer queryString = new StringBuffer();
        queryString.append(StopSaleDAOSQLConstants.GET_STOP_SALE_REPORT).append(whereClause);
        return queryString.toString();
    }

    private String getFieldOrDashForEmpty(ResultSet rs, String tableName, String fieldId, String fieldName,
                                          String locale) throws Exception {

        String value = StringUtils.trimNullable(rs.getString(fieldName));

        if (locale != null) {
            int id = rs.getInt(fieldId);
            value = (new I18nServiceImpl()).translate(locale, tableName, id, value);
        }

        if (StringUtils.isNullOrEmpty(value)) {
            return "-";
        } else {
            return value;
        }
    }

    private void setRowBeanColumnFromResultSet(RowBean rowBean, int col, ResultSet rs, String fieldName) throws
            Exception {
        rowBean.setCol(col, getFieldOrDashForEmpty(rs, null, null, fieldName, null));
    }

    private void setInternationalizedRowBeanColumnFromResultSet(RowBean rowBean, int col, ResultSet rs, String fieldName,
                                                                String fieldId, String tableName, String locale) throws
            Exception {
        rowBean.setCol(col, getFieldOrDashForEmpty(rs, tableName, fieldId, fieldName, locale));
    }

    private RowBean getRowBeanFromResultSet(ResultSet rs, String locale) throws Exception {
        RowBean rowBean = new RowBean();
        setRowBeanColumnFromResultSet(rowBean, 1, rs, "CONTROL_NUMBER");
        setRowBeanColumnFromResultSet(rowBean, 2, rs, "YEAR");
        setRowBeanColumnFromResultSet(rowBean, 3, rs, "STATUS");
        setRowBeanColumnFromResultSet(rowBean, 4, rs, "REPORT_INITIATOR");
        setRowBeanColumnFromResultSet(rowBean, 5, rs, "PERSON_INVESTIGATING");
        setRowBeanColumnFromResultSet(rowBean, 6, rs, "FIELD_COMMUNICATOR");

        setInternationalizedRowBeanColumnFromResultSet(rowBean, 7, rs, "CROP", "CROP_ID", "CROP_REF", locale);
        setInternationalizedRowBeanColumnFromResultSet(rowBean, 8, rs, "SEED_SIZE", "SEED_SIZE_ID", "SEED_SIZE_REF",
                locale);

        setRowBeanColumnFromResultSet(rowBean, 9, rs, "QTY_AFFECTED");

        setInternationalizedRowBeanColumnFromResultSet(rowBean, 10, rs, "UOM", "QTY_UOM_ID", "QTY_UOM_REF", locale);

        setRowBeanColumnFromResultSet(rowBean, 11, rs, "QUALITY_ISSUE_FLAG");
        setRowBeanColumnFromResultSet(rowBean, 12, rs, "DEALER");
        setRowBeanColumnFromResultSet(rowBean, 13, rs, "DEALER_PHONE_NO");
        setRowBeanColumnFromResultSet(rowBean, 14, rs, "STATE_VALUE");
        setRowBeanColumnFromResultSet(rowBean, 15, rs, "STATE_RETEST");
        setRowBeanColumnFromResultSet(rowBean, 16, rs, "STATE_REPORT_NUMBER");
        setRowBeanColumnFromResultSet(rowBean, 17, rs, "STATE_CONTACT");
        setRowBeanColumnFromResultSet(rowBean, 18, rs, "STATE_PHONE_NUMBER");
        setRowBeanColumnFromResultSet(rowBean, 19, rs, "DATE_REPORTED");
        setRowBeanColumnFromResultSet(rowBean, 20, rs, "MONSANTO_VALUE");
        setRowBeanColumnFromResultSet(rowBean, 21, rs, "LABEL_VALUE");
        setRowBeanColumnFromResultSet(rowBean, 22, rs, "ACTION_COMMENTS");

        setInternationalizedRowBeanColumnFromResultSet(rowBean, 23, rs, "REGION_DESCRIPTION", "REGION_ID", "REGION_REF",
                locale);

        setRowBeanColumnFromResultSet(rowBean, 24, rs, "STATE_LONG_NAME");
        setRowBeanColumnFromResultSet(rowBean, 25, rs, "REPORTING_LOCATION");
        setRowBeanColumnFromResultSet(rowBean, 26, rs, "SHIPPING_LOCATION");
        setRowBeanColumnFromResultSet(rowBean, 27, rs, "RESPONSIBLE_LOCATION");

        setInternationalizedRowBeanColumnFromResultSet(rowBean, 28, rs, "ACTION", "STOP_SALE_ACTION_ID",
                "STOP_SALE_ACTION_REF", locale);
        setInternationalizedRowBeanColumnFromResultSet(rowBean, 29, rs, "REASON", "STOP_SALE_REASON_ID",
                "STOP_SALE_REASON_REF", locale);

        setRowBeanColumnFromResultSet(rowBean, 30, rs, "VARIETY");
        setRowBeanColumnFromResultSet(rowBean, 31, rs, "BATCH");
        setRowBeanColumnFromResultSet(rowBean, 32, rs, "INVESTIGATION_FINDINGS");
        setRowBeanColumnFromResultSet(rowBean, 33, rs, "LONG_TERM_CORRECTION_ACTION");
        setRowBeanColumnFromResultSet(rowBean, 34, rs, "ROOT_CAUSE");
        setRowBeanColumnFromResultSet(rowBean, 35, rs, "CONTAINMENT_ACTION");
        setRowBeanColumnFromResultSet(rowBean, 36, rs, "MATERIAL_GROUP_ID");
        setRowBeanColumnFromResultSet(rowBean, 37, rs, "MATERIAL_GROUP_PRICING_ID");
        setRowBeanColumnFromResultSet(rowBean, 38, rs, "STOP_SALE_BUSINESS_ID");
        return rowBean;
    }

    private void addFiltersToWhereClause(StopSaleFilter stopSaleFilter, StringBuffer whereClause) {
        if ((stopSaleFilter.getControlNumber() != null) && !(stopSaleFilter.getControlNumber().equals(""))) {
            whereClause.append(" AND UPPER(STOP_SALE.CONTROL_NUMBER) LIKE UPPER('")
                    .append(stopSaleFilter.getControlNumber().trim()).append("%') ");
        }
        if ((stopSaleFilter.getInitiatedBy() != null) && !(stopSaleFilter.getInitiatedBy().equals(""))) {
            whereClause.append(" AND UPPER(STOP_SALE.REPORT_INITIATOR) LIKE UPPER('")
                    .append(stopSaleFilter.getInitiatedBy().trim()).append("%') ");
        }
        if ((stopSaleFilter.getDateReported() != null) && !(stopSaleFilter.getDateReported().equals(""))) {
            whereClause.append(" AND STOP_SALE.DATE_REPORTED = TO_DATE('")
                    .append(getDateFormat(new Date(new java.util.Date(stopSaleFilter.getDateReported()).getTime())))
                    .append("', 'MM/DD/YYYY') ");
        }
        if ((stopSaleFilter.getInvestigator() != null) && !(stopSaleFilter.getInvestigator().equals(""))) {
            whereClause.append(" AND UPPER(STOP_SALE.PERSON_INVESTIGATING) LIKE UPPER('")
                    .append(stopSaleFilter.getInvestigator().trim()).append("%') ");
        }
        if ((stopSaleFilter.getStatus() != null) && (stopSaleFilter.getStatus().length > 0)) {
            whereClause.append(getSelectedFields(" AND STOP_SALE.STATUS_ID IN ", stopSaleFilter.getStatus()));
        }
        if ((stopSaleFilter.getRegion() != null) && (stopSaleFilter.getRegion().length > 0)) {
            whereClause.append(getSelectedFields(" AND STOP_SALE.REGION_ID IN ", stopSaleFilter.getRegion()));
        }
        if ((stopSaleFilter.getSalesYear() != null) && (stopSaleFilter.getSalesYear().length > 0)) {
            whereClause.append(getSelectedFields(" AND STOP_SALE.SALES_YEAR_ID IN ", stopSaleFilter.getSalesYear()));
        }
        if ((stopSaleFilter.getState() != null) && (stopSaleFilter.getState().length > 0)) {
            whereClause.append(getSelectedFields(" AND STOP_SALE.STATE_ID IN ", stopSaleFilter.getState()));
        }
        if ((stopSaleFilter.getCrop() != null) && (stopSaleFilter.getCrop().length > 0)) {
            whereClause.append(getSelectedFields(" AND STOP_SALE.CROP_ID IN ", stopSaleFilter.getCrop()));
        }
        if ((stopSaleFilter.getFilingLocation() != null) && (stopSaleFilter.getFilingLocation().length > 0)) {
            whereClause
                    .append(getSelectedFields(" AND STOP_SALE.REPORTING_LOCATION_CODE IN ", stopSaleFilter.getFilingLocation()));
        }
        if ((stopSaleFilter.getResponsibleLocation() != null) && (stopSaleFilter.getResponsibleLocation().length > 0)) {
            whereClause.append(
                    getSelectedFields(" AND STOP_SALE.RESPONSIBLE_PLANT_CODE IN ", stopSaleFilter.getResponsibleLocation()));
        }
        if ((stopSaleFilter.getShippingLocation() != null) && (stopSaleFilter.getShippingLocation().length > 0)) {
            whereClause
                    .append(getSelectedFields(" AND STOP_SALE.SHIPPING_LOCATION_CODE IN ", stopSaleFilter.getShippingLocation()));
        }
        whereClause.append(getStopSaleReason(stopSaleFilter));
        whereClause.append(getStopSaleAction(stopSaleFilter));

        if (!StringUtils.isNullOrEmpty(stopSaleFilter.getVariety())) {
            whereClause
                    .append(" AND UPPER(variety_batch.variety) LIKE UPPER('%" + stopSaleFilter.getVariety().trim() + "%') ");
        }
        if (batchFilterEntered(stopSaleFilter)) {
            whereClause
                    .append(" AND UPPER(STOP_SALE_BATCH.BATCH) LIKE UPPER('%" + stopSaleFilter.getBatchNumber().trim() + "%') ");
        }
        //Selected Tap Root causes
        if (!stopSaleFilter.isNonconformanceCategoryIdListEmpty()) {
            whereClause.append(" AND COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID IN ( ")
                    .append(buildInClause(stopSaleFilter.getNonconformanceCategoryIdList())).append(" )");
        }
    }

    private String buildInClause(List<Integer> tapRootCausesIssue) {
        return MCASUtil.buildInClause(tapRootCausesIssue);
    }

    private boolean batchFilterEntered(StopSaleFilter stopSaleFilter) {
        return !StringUtils.isNullOrEmpty(stopSaleFilter.getBatchNumber());
    }

    public boolean addStopSaleAttachmentInfo(AttachmentInfo attachmentInfo) throws DAOException {
        PreparedStatement ps = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.ADD_STOP_SALE_ATTACHMENT);
            ps.setString(1, attachmentInfo.getDocumentId());
            ps.setInt(2, Integer.parseInt(attachmentInfo.getEntityId()));
            ps.setString(3, attachmentInfo.getDocumentName());
            ps.executeUpdate();
            conn.commit();
            return true;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, null);
        }
    }

    public boolean deleteStopSaleAttachmentInfo(String documentId) throws DAOException {
        PreparedStatement ps = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.DELETE_STOP_SALE_ATTACHMENT);
            ps.setString(1, documentId);
            ps.executeUpdate();
            conn.commit();
            return true;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new DAOException(e);
        }
        finally {
            closeDBResources(conn, ps, null);
        }
    }


    /**
     * Method to set the ss_reason fields...
     *
     * @param
     * @return
     */
    private StringBuffer getStopSaleReason(StopSaleFilter stopSaleFilter) {

        StringBuffer issuesClause = new StringBuffer();

        List<String> paramList = new ArrayList<String>();

        if (stopSaleFilter.isSeedCount()) {
            paramList.add("1");
        }
        if (stopSaleFilter.isGermination()) {
            paramList.add("2");
        }
        if (stopSaleFilter.isPurity()) {
            paramList.add("3");
        }
        if (stopSaleFilter.isTagDate()) {
            paramList.add("4");
        }
        if (stopSaleFilter.isOtherReason()) {
            paramList.add("5");
        }

        int size = paramList.size();

        if (size > 0) {
            issuesClause.append(" AND STOP_SALE_REASON.STOP_SALE_REASON_ID IN ");
        } else {
            issuesClause.append("");
            return issuesClause;
        }

        issuesClause.append("(");

        for (int i = 0; i < size; i++) {

            issuesClause.append("'").append(paramList.get(i)).append("'");

            if (i < size - 1) {
                issuesClause.append(",");
            }
        }

        issuesClause.append(")");

        return issuesClause;
    }

    /**
     * Method to set the ss_action fields...
     *
     * @param
     * @return
     */
    private StringBuffer getStopSaleAction(StopSaleFilter stopSaleFilter) {

        StringBuffer issuesClause = new StringBuffer();


        List<String> paramList = new ArrayList<String>();

        if (stopSaleFilter.isReLabel()) {
            paramList.add("1");
        }
        if (stopSaleFilter.isRecount()) {
            paramList.add("2");
        }
        if (stopSaleFilter.isDump()) {
            paramList.add("3");
        }
        if (stopSaleFilter.isRestrict()) {
            paramList.add("4");
        }
        if (stopSaleFilter.isOtherActionFlag()) {
            paramList.add("5");
        }

        int size = paramList.size();

        if (size > 0) {
            issuesClause.append(" AND STOP_SALE_ACTION.STOP_SALE_ACTION_ID IN ");
        } else {
            issuesClause.append("");
            return issuesClause;
        }

        issuesClause.append("(");

        for (int i = 0; i < size; i++) {

            issuesClause.append("'").append(paramList.get(i)).append("'");

            if (i < size - 1) {
                issuesClause.append(",");
            }
        }

        issuesClause.append(")");

        return issuesClause;
    }

    /**
     * This method just makes a string out of selected fields like ('1744', '1745',...)
     *
     * @param strArray
     * @return
     */
    private StringBuffer getSelectedFields(String query, String[] strArray) {

        int size = strArray.length;

        StringBuffer fieldClause = new StringBuffer();
        fieldClause.append("");

        //**To remove the null elements...
        for (int i = 0; i < size; i++) {

            if (strArray[i].equals("") || strArray[i].equals("0")) {
                size--;
            }
        }

        if (size == 0) {
            return fieldClause;
        }

        fieldClause.append(query).append("(");

        for (int i = 0; i < strArray.length; i++) {

            //**Skip null elements...
            if (strArray[i].equals("") || strArray[i].equals("0")) {
                continue;
            }

            fieldClause.append("'").append(strArray[i].trim()).append("'");

            if (i < strArray.length - 1) {
                fieldClause.append(",");
            }
        }

        fieldClause.append(")");

        return fieldClause;
    }

    /**
     * To get the data from main table...
     *
     * @param conn
     * @return
     */
    private void getStopSaleObj(int stopSaleID, StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();

            while (rs.next()) {
                stopSale.setStopSaleID(rs.getString("STOP_SALE_ID"));
                stopSale.setControlNumber(rs.getString("CONTROL_NUMBER"));
                stopSale.setReportDate(getDateFormat(rs.getDate("REPORT_DATE")));
                stopSale.setInvestigator(rs.getString("INVESTIGATOR"));
                stopSale.setRegion(rs.getString("REGION"));
                stopSale.setInitiatedBy(rs.getString("INITIATED_BY"));
                stopSale.setFillingLocation(rs.getString("FILLING_LOCATION"));
                stopSale.setSalesYear(rs.getString("SALES_YEAR_ID"));
                stopSale.setStateID(rs.getString("STATE_ID"));
                stopSale.setStatus(rs.getString("STATUS_ID"));
                stopSale.setCreatedBy(rs.getString("CREATED_BY"));
                stopSale.setResponsibleLocation(rs.getString("RESPONSIBLE_LOCATION"));
                stopSale.setFieldCommunicator(rs.getString("FIELD_COMMUNICATOR"));
                stopSale.setShippingLocation(rs.getString("SHIPPING_LOCATION"));
                stopSale.setDealer(rs.getString("DEALER"));
                stopSale.setDealerPhone(rs.getString("DEALER_PHONE_NO"));
                stopSale.setStateReportNumber(rs.getString("STATE_REPORT_NUMBER"));
                stopSale.setStateValue(rs.getString("STATE_VALUE"));
                stopSale.setStateContact(rs.getString("STATE_CONTACT"));
                stopSale.setStatePhone(rs.getString("STATE_PHONE_NUMBER"));
                stopSale.setStateRetest(rs.getString("STATE_RETEST"));
                stopSale.setMonsantoValue(rs.getString("MONSANTO_VALUE"));
                stopSale.setCropID(rs.getString("CROP_ID"));
                stopSale.setLabelValue(rs.getString("LABEL_VALUE"));
                stopSale.setQualityIssue(rs.getString("QUALITY_ISSUE_FLAG"));
                stopSale.setQuantityAffected(rs.getString("QTY_AFFECTED"));
                stopSale.setQualityUomID(rs.getString("QTY_UOM_ID"));
                stopSale.setSeedSizeID(rs.getString("SEED_SIZE_ID"));
                stopSale.setActionComments(rs.getString("ACTION_COMMENTS"));
                stopSale.setEntryDate(getDateFormat(rs.getDate("ROW_ENTRY_DATE")));
                stopSale.setStopSaleBusinessId(rs.getInt("STOP_SALE_BUSINESS_ID"));
                stopSale.setSalesOfficeCode(rs.getInt("SALES_OFFICE_ID"));
                stopSale.setMaterialGroupCode(rs.getInt("MATERIAL_GROUP_ID"));
                stopSale.setMaterialGroupPricingCode(rs.getInt("MATERIAL_GROUP_PRICING_ID"));
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting StopSaleObj: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }


    /**
     * To get the data from Doc table...
     *
     * @param conn
     * @return
     */
    private void getStopSaleDoc(int stopSaleID, StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_DOC);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();

            while (rs.next()) {
                stopSale.setInvestigationFindings(rs.getString("INVESTIGATION_FINDINGS"));
                stopSale.setRootCause(rs.getString("ROOT_CAUSE"));
                stopSale.setContainmentAction(rs.getString("CONTAINMENT_ACTION"));
                stopSale.setLongTermCorrectiveAction(rs.getString("LONG_TERM_CORRECTION_ACTION"));
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting StopSaleDoc: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }

    /**
     * To get the data from Cpar table...
     *
     * @param conn
     * @return
     */
    private void getStopSaleCar(int stopSaleID, StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_CAR);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();

            while (rs.next()) {
                stopSale.setCarID(rs.getString("CAR_ID"));
                stopSale.setCarNumber(rs.getString("CAR_NUMBER"));
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting Car: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void getStopSaleAttachments(int stopSaleID, StopSaleObject stopSale, Connection conn) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_ATTACHMENT);
            ps.setInt(1, stopSaleID);
            rs = ps.executeQuery();
            while (rs.next()) {
                String documentId = rs.getString("DOCUMENT_ID");
                String stopSaleId = rs.getString("STOP_SALE_ID");
                String documentName = rs.getString("DOCUMENT_NAME");
                AttachmentInfo attachmentInfo = new AttachmentInfo(stopSaleId, documentId, documentName);
                stopSale.getStopSaleAttachments().put(documentId, attachmentInfo);
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting stop sale attachments: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }
    }

    private void getStopSaleVarietyBatch(int stopSaleID, StopSaleObject stopSale, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_VARIETY_BATCH);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();
            List<VarietyBatch> batchList = stopSale.getVarietyBatchList();
            batchList.clear();
            while (rs.next()) {
                batchList.add(
                        new VarietyBatch(null, rs.getString("VARIETY"), rs.getString("BATCH")));
            }

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting Variety: ", e);
            throw new DAOException(e);
        }
        finally {
            MCASResourceUtil.closeDBResources(null, ps, rs);
        }
    }

    /**
     * To get the data from Reason table...
     *
     * @param conn
     * @return
     */
    private void getStopSaleReason(int stopSaleID, StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_REASON);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();

            while (rs.next()) {

                if (rs.getString("STOP_SALE_REASON_ID").trim().equals("1")) {
                    stopSale.setSeedCount(true);
                }
                if (rs.getString("STOP_SALE_REASON_ID").trim().equals("2")) {
                    stopSale.setGermination(true);
                }
                if (rs.getString("STOP_SALE_REASON_ID").trim().equals("3")) {
                    stopSale.setPurity(true);
                }
                if (rs.getString("STOP_SALE_REASON_ID").trim().equals("4")) {
                    stopSale.setTagDate(true);
                }
                if (rs.getString("STOP_SALE_REASON_ID").trim().equals("5")) {
                    stopSale.setOtherReason(true);
                }

            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting Reason: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }

    }


    /**
     * To get the data from Action table...
     *
     * @param conn
     * @return
     */
    private void getStopSaleAction(int stopSaleID, StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_ACTION);
            ps.setInt(1, stopSaleID);

            rs = ps.executeQuery();

            while (rs.next()) {

                if (rs.getString("STOP_SALE_ACTION_ID").trim().equals("1")) {
                    stopSale.setReLabel(true);
                }
                if (rs.getString("STOP_SALE_ACTION_ID").trim().equals("2")) {
                    stopSale.setRecount(true);
                }
                if (rs.getString("STOP_SALE_ACTION_ID").trim().equals("3")) {
                    stopSale.setDump(true);
                }
                if (rs.getString("STOP_SALE_ACTION_ID").trim().equals("4")) {
                    stopSale.setRestrict(true);
                }
                if (rs.getString("STOP_SALE_ACTION_ID").trim().equals("5")) {
                    stopSale.setOtherActionFlag(true);
                }

            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting Action: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }

    }

    /**
     * To update reqd/optional fields into the STOP_SALE (main) Table.
     *
     * @param stopSaleID
     * @param oracleSysdate
     * @param stopSale
     * @param conn
     */
    private void updateStopSaleObject(int stopSaleID, Date oracleSysdate, StopSaleObject stopSale, Connection conn) {

        //**Dynamic Query Formation...
        PreparedStatement ps = null;

        StringBuffer setClause = new StringBuffer();
        setClause.append(" ");

        try {

            if (stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")) {
                setClause.append(" ,QTY_AFFECTED = ? WHERE STOP_SALE_ID = ?");
            } else {
                setClause.append(" WHERE STOP_SALE_ID = ?");
            }

//      logger.info(StopSaleDAOSQLConstants.UPDATE_STOP_SALE + setClause.toString());

            ps = conn.prepareStatement(StopSaleDAOSQLConstants.UPDATE_STOP_SALE + setClause.toString());

            ps.setString(1, stopSale.getStatus());
            ps.setString(2, stopSale.getRegion());
            ps.setString(3, stopSale.getFillingLocation());
            ps.setString(4, stopSale.getInitiatedBy());
            ps.setString(5, getDateFormat(new Date(new java.util.Date(stopSale.getReportDate()).getTime())));
            ps.setString(6, stopSale.getSalesYear());
            ps.setString(7, stopSale.getResponsibleLocation());
            ps.setString(8, stopSale.getFieldCommunicator());
            ps.setString(9, stopSale.getStateID());
            ps.setString(10, stopSale.getShippingLocation());
            ps.setString(11, stopSale.getDealer());
            ps.setString(12, stopSale.getDealerPhone());
            ps.setString(13, stopSale.getStateReportNumber());
            ps.setString(14, stopSale.getStateValue());
            ps.setString(15, stopSale.getStateContact());
            ps.setString(16, stopSale.getStatePhone());
            ps.setString(17, stopSale.getStateRetest());
            ps.setString(18, stopSale.getMonsantoValue());
            ps.setString(19, stopSale.getInvestigator());
            ps.setString(20, stopSale.getCropID());
            ps.setString(21, stopSale.getLabelValue());
            ps.setString(22, stopSale.getQualityIssue());
            ps.setString(23, stopSale.getQualityUomID());
            ps.setString(24, stopSale.getSeedSizeID());
            ps.setString(25, stopSale.getActionComments());
            ps.setDate(26, oracleSysdate);
            ps.setString(27, "SS_MODIFY");
            ps.setString(28, stopSale.getCreatedBy());
            //SET VALUES FOR STOP_SALE_BUSINESS_ID,SALES_OFFICE_ID,MATERIAL_GROUP_ID,MATERIAL_GROUP_PRICING_ID
            ps.setInt(29, stopSale.getStopSaleBusinessId());
            ps.setInt(30, stopSale.getSalesOfficeCode());
            ps.setInt(31, stopSale.getMaterialGroupCode());
            ps.setInt(32, stopSale.getMaterialGroupPricingCode());

            if (stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")) {
                ps.setFloat(33, Float.parseFloat(stopSale.getQuantityAffected()));
                ps.setString(34, stopSale.getStopSaleID());
            } else {
                ps.setString(33, stopSale.getStopSaleID());
            }

            ps.executeUpdate();

            conn.commit();
        }
        catch (SQLException e) {
            logger.error("FileName: com.monsanto.wst.ccas.dao.StopSaleDAOImpl, MethodName: updateStopSale(obj, conn)...");
            logger.error("SQLException while updating: " + e.getMessage());
        }
        catch (Exception e) {
            logger.error("FileName: com.monsanto.wst.ccas.dao.StopSaleDAOImpl, MethodName: updateStopSale(obj, conn)...");
            logger.error("Exception while updating: " + e.getMessage());
        }
        finally {
            closeDBResources(null, ps, null);
        }

    }

    private void deleteStopSaleRef(int stopSaleID, Connection conn) {
        PreparedStatement ps = null;

        //**Delete Variety...
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.DELETE_STOP_SALE_VARIETY);
            ps.setInt(1, stopSaleID);
            ps.executeUpdate();
            conn.commit();

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while deleting variety: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }

        //**Delete Batch...
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.DELETE_STOP_SALE_BATCH);
            ps.setInt(1, stopSaleID);
            ps.executeUpdate();
            conn.commit();

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while deleting batch: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }

        //**Delete Reason...
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.DELETE_STOP_SALE_REASON);
            ps.setInt(1, stopSaleID);
            ps.executeUpdate();
            conn.commit();

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while deleting reason: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }

        //**Delete Action-Flag...
        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.DELETE_STOP_SALE_ACTION_FLAG);
            ps.setInt(1, stopSaleID);
            ps.executeUpdate();
            conn.commit();

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while deleting action flags: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }

//    logger.info("Ref table data for this record deleted...");
    }


    /**
     * To update the stop_sale_documentation table...
     *
     * @param stopSaleID
     * @param stopSale
     * @param conn
     */
    private void updateStopSaleDoc(int stopSaleID, Date oracleSysdate, StopSaleObject stopSale, Connection conn) {
        PreparedStatement ps = null;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.UPDATE_STOP_SALE_DOC);

            ps.setString(1, stopSale.getInvestigationFindings());
            ps.setString(2, stopSale.getRootCause());
            ps.setString(3, stopSale.getContainmentAction());
            ps.setString(4, stopSale.getLongTermCorrectiveAction());
            ps.setString(5, stopSale.getCreatedBy());
            ps.setString(6, "SS_DOC_MODIFY");
            ps.setDate(7, oracleSysdate);
            ps.setInt(8, stopSaleID);

            ps.executeUpdate();

            conn.commit();
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while updating doc: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }
    }

    /**
     * To insert reqd/optional fields into the STOP_SALE (main) Table.
     *
     * @param stopSaleID
     * @param stopSaleNumber
     * @param oracleSysdate
     * @param stopSale
     * @param conn
     */
    private void insertStopSaleObject(int stopSaleID, String stopSaleNumber, Date oracleSysdate, StopSaleObject stopSale,
                                      Connection conn)throws Exception{

        //**Dynamic Query Formation...
        PreparedStatement ps = null;
        List<String> paramList = new ArrayList<String>();
        StringBuffer fieldClause = new StringBuffer();
        StringBuffer valueClause = new StringBuffer();
        fieldClause.append(" ");

        try {
            paramList = buildSelectFields(stopSale, paramList, fieldClause);
            fieldClause.append(" ");
            valueClause.append(") VALUES (");
            //Build the Insert SQL
            valueClause = buildInsertQuery(stopSaleID, stopSaleNumber, oracleSysdate, stopSale, valueClause, paramList);
//      logger.info(StopSaleDAOSQLConstants.INSERT_STOP_SALE + fieldClause.toString() + valueClause.toString());
            ps = conn
                    .prepareStatement(StopSaleDAOSQLConstants.INSERT_STOP_SALE + fieldClause.toString() + valueClause.toString());
            ps.executeUpdate();
            conn.commit();
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while inserting: ", e);
            throw e;
        }
        finally {
            closeDBResources(null, ps, null);
        }

    }

    /**
     * Bhargava 04/22/2008 <p/> Method to Build optional fields in insert SQL
     *
     * @param stopSale
     * @param paramList
     * @param valueClause
     */
    private StringBuffer buildOptionalFieldsSQL(StopSaleObject stopSale, List<String> paramList,
                                                StringBuffer valueClause) {

        for (String aParamList : paramList) {
            if (aParamList.equals("ResponsibleLoc")) {
                valueClause.append(",'" + stopSale.getResponsibleLocation() + "'");
            }
            if (aParamList.equals("FieldCommunicator")) {
                valueClause.append(",'" + stopSale.getFieldCommunicator() + "'");
            }
            if (aParamList.equals("ShippingLoc")) {
                valueClause.append(",'" + stopSale.getShippingLocation() + "'");
            }
            if (aParamList.equals("Dealer")) {
                valueClause.append(",'" + stopSale.getDealer() + "'");
            }
            if (aParamList.equals("DealerPhone")) {
                valueClause.append(",'" + stopSale.getDealerPhone() + "'");
            }
            if (aParamList.equals("StateRepNo")) {
                valueClause.append(",'" + stopSale.getStateReportNumber() + "'");
            }
            if (aParamList.equals("StateVal")) {
                valueClause.append(",'" + stopSale.getStateValue() + "'");
            }
            if (aParamList.equals("StateContact")) {
                valueClause.append(",'" + stopSale.getStateContact() + "'");
            }
            if (aParamList.equals("StatePhone")) {
                valueClause.append(",'" + stopSale.getStatePhone() + "'");
            }
            if (aParamList.equals("StateRetest")) {
                valueClause.append(",'" + stopSale.getStateRetest() + "'");
            }
            if (aParamList.equals("MonsantoVal")) {
                valueClause.append(",'" + stopSale.getMonsantoValue() + "'");
            }
            if (aParamList.equals("Crop")) {
                valueClause.append(",'" + stopSale.getCropID() + "'");
            }
            if (aParamList.equals("LabelVal")) {
                valueClause.append(",'" + stopSale.getLabelValue() + "'");
            }
            if (aParamList.equals("QualityIssue")) {
                valueClause.append(",'" + stopSale.getQualityIssue() + "'");
            }
            if (aParamList.equals("QuantityAffected")) {
                valueClause.append("," + stopSale.getQuantityAffected());
            }
            if (aParamList.equals("QualityUom")) {
                valueClause.append(",'" + stopSale.getQualityUomID() + "'");
            }
            if (aParamList.equals("SeedSize")) {
                valueClause.append(",'" + stopSale.getSeedSizeID() + "'");
            }
            if (aParamList.equals("ActionComments")) {  //TODO Modify SQLUtil to PreparedStatement
                valueClause.append(",'" + SQLUtil.escapeString(stopSale.getActionComments()) + "'");
            }
            if (aParamList.equals("BusinessId")) {
                valueClause.append("," + stopSale.getStopSaleBusinessId());
            }
            if (aParamList.equals("SalesOfficeCode")) {
                valueClause.append("," + stopSale.getSalesOfficeCode());
            }
            if (aParamList.equals("MaterialGroup")) {
                valueClause.append("," + stopSale.getMaterialGroupCode());
            }
            if (aParamList.equals("MaterialGroupPricing")) {
                valueClause.append(",").append(stopSale.getMaterialGroupPricingCode());
            }
        }

        valueClause.append(")");
        return valueClause;
    }

    /**
     * Bhargava 04/22/2008 Method used to Build SQL query with Required fields
     *
     * @param stopSaleID
     * @param stopSaleNumber
     * @param oracleSysdate
     * @param stopSale
     * @param valueClause
     * @return
     */
    private StringBuffer buildInsertQuery(int stopSaleID, String stopSaleNumber, Date oracleSysdate,
                                          StopSaleObject stopSale, StringBuffer valueClause, List<String> paramList) {
        valueClause.append(stopSaleID);
        valueClause.append(",'").append(stopSaleNumber).append("'");
        valueClause.append(",to_date('")
                .append(getDateFormat(new Date(new java.util.Date(stopSale.getReportDate()).getTime())))
                .append("','mm/dd/yyyy')");
        valueClause.append(",'").append(stopSale.getInvestigator()).append("'");
        valueClause.append(",'").append(stopSale.getRegion()).append("'");
        valueClause.append(",'").append(stopSale.getInitiatedBy()).append("'");
        valueClause.append(",'").append(stopSale.getFillingLocation()).append("'");
        valueClause.append(",'").append(stopSale.getSalesYear()).append("'");
        //States List Default
        if (!StringUtils.isNullOrEmpty(stopSale.getStateID())) {
            valueClause.append(",'").append(stopSale.getStateID()).append("'");
        } else {
            String key = new ActionHelper().getEmptyRegion("", stopSale.getRegion(), MCASConstants.LANGUAGE_ENGLISH);
            if (!StringUtils.isNullOrEmpty(key)) {
                valueClause.append(",'").append(key).append("'");
            }
        }
        valueClause.append(",'").append(stopSale.getStatus()).append("'");
        valueClause.append(",to_date('").append(getDateFormat(oracleSysdate)).append("','mm/dd/yyyy')");
        valueClause.append(",to_date('").append(getDateFormat(oracleSysdate)).append("','mm/dd/yyyy')");
        valueClause.append(",'" + "STOP_SALE_ENTRY" + "'");
        valueClause.append(",'").append(stopSale.getCreatedBy()).append("'");
        //Build the Optional Fields in SQl
        valueClause = buildOptionalFieldsSQL(stopSale, paramList,
                valueClause); //todo WHY are they doing this?  It's a STRINGBUFFER they could just change it if thats what they wanted to do

        return valueClause;
    }

    /**
     * Bhargava 04/22/08 <p/> Method to Build the SQL Select clause.Contains only the select columns
     *
     * @param stopSale
     * @param paramList
     * @param fieldClause
     * @return
     */
    private List<String> buildSelectFields(StopSaleObject stopSale, List<String> paramList, StringBuffer fieldClause) {
        if (stopSale.getResponsibleLocation() != null && !stopSale.getResponsibleLocation().equals("")) {
            paramList.add("ResponsibleLoc");
            fieldClause.append(",RESPONSIBLE_PLANT_CODE ");
        }
        if (stopSale.getFieldCommunicator() != null && !stopSale.getFieldCommunicator().equals("")) {
            paramList.add("FieldCommunicator");
            fieldClause.append(",FIELD_COMMUNICATOR ");
        }
        if (stopSale.getShippingLocation() != null && !stopSale.getShippingLocation().equals("")) {
            paramList.add("ShippingLoc");
            fieldClause.append(",SHIPPING_LOCATION_CODE ");
        }
        if (stopSale.getDealer() != null && !stopSale.getDealer().equals("")) {
            paramList.add("Dealer");
            fieldClause.append(",DEALER ");
        }
        if (stopSale.getDealerPhone() != null && !stopSale.getDealerPhone().equals("")) {
            paramList.add("DealerPhone");
            fieldClause.append(",DEALER_PHONE_NO ");
        }
        if (stopSale.getStateReportNumber() != null && !stopSale.getStateReportNumber().equals("")) {
            paramList.add("StateRepNo");
            fieldClause.append(",STATE_REPORT_NUMBER ");
        }
        if (stopSale.getStateValue() != null && !stopSale.getStateValue().equals("")) {
            paramList.add("StateVal");
            fieldClause.append(",STATE_VALUE ");
        }
        if (stopSale.getStateContact() != null && !stopSale.getStateContact().equals("")) {
            paramList.add("StateContact");
            fieldClause.append(",STATE_CONTACT ");
        }
        if (stopSale.getStatePhone() != null && !stopSale.getStatePhone().equals("")) {
            paramList.add("StatePhone");
            fieldClause.append(",STATE_PHONE_NUMBER ");
        }
        if (stopSale.getStateRetest() != null && !stopSale.getStateRetest().equals("")) {
            paramList.add("StateRetest");
            fieldClause.append(",STATE_RETEST ");
        }
        if (stopSale.getMonsantoValue() != null && !stopSale.getMonsantoValue().equals("")) {
            paramList.add("MonsantoVal");
            fieldClause.append(",MONSANTO_VALUE ");
        }
        if (stopSale.getCropID() != null && !stopSale.getCropID().equals("")) {
            paramList.add("Crop");
            fieldClause.append(",CROP_ID ");
        }
        if (stopSale.getLabelValue() != null && !stopSale.getLabelValue().equals("")) {
            paramList.add("LabelVal");
            fieldClause.append(",LABEL_VALUE ");
        }
        if (stopSale.getQualityIssue() != null && !stopSale.getQualityIssue().equals("")) {
            paramList.add("QualityIssue");
            fieldClause.append(",QUALITY_ISSUE_FLAG ");
        }
        if (stopSale.getQuantityAffected() != null && !stopSale.getQuantityAffected().equals("")) {
            paramList.add("QuantityAffected");
            fieldClause.append(",QTY_AFFECTED ");
        }
        if (stopSale.getQualityUomID() != null && !stopSale.getQualityUomID().equals("")) {
            paramList.add("QualityUom");
            fieldClause.append(",QTY_UOM_ID ");
        }
        if (stopSale.getSeedSizeID() != null && !stopSale.getSeedSizeID().equals("")) {
            paramList.add("SeedSize");
            fieldClause.append(",SEED_SIZE_ID ");
        }
        if (stopSale.getActionComments() != null && !stopSale.getActionComments().equals("")) {
            paramList.add("ActionComments");
            fieldClause.append(",ACTION_COMMENTS ");
        }
        //Code to Insert the Business ID as well
        if (stopSale.getStopSaleBusinessId() != -1) {
            paramList.add("BusinessId");
            fieldClause.append(",STOP_SALE_BUSINESS_ID");
        }
        //Code to Insert the Sales office ID
        if (stopSale.getSalesOfficeCode() != -1) {
            paramList.add("SalesOfficeCode");
            fieldClause.append(",SALES_OFFICE_ID");
        }

        //Code to Insert Material Group Code
        if (stopSale.getMaterialGroupCode() != -1) {
            paramList.add("MaterialGroup");
            fieldClause.append(",MATERIAL_GROUP_ID");
        }
        //Code to Insert Material Group Pricing Code
        if (stopSale.getMaterialGroupPricingCode() != -1) {
            paramList.add("MaterialGroupPricing");
            fieldClause.append(",MATERIAL_GROUP_PRICING_ID");
        }

        return paramList;
    }


    /**
     * To insert reqd/optional fields into the STOP_SALE_DOCUMENTATION Table.
     *
     * @param stopSaleID
     * @param oracleSysdate
     * @param stopSale
     * @param conn
     */
    private void insertStopSaleDoc(int stopSaleID, Date oracleSysdate, StopSaleObject stopSale, Connection conn) throws
            DAOException {

        //**Dynamic Query Formation...
        PreparedStatement ps = null;
        List<String> paramList = new ArrayList<String>();


        StringBuffer fieldClause = new StringBuffer();
        fieldClause.append(" ");

        try {
            //conn = getConnection();

            if (stopSale.getRootCause() != null && !stopSale.getRootCause().equals("")) {
                paramList.add("RootCause");
                fieldClause.append(",ROOT_CAUSE ");
            }
            if (stopSale.getContainmentAction() != null && !stopSale.getContainmentAction().equals("")) {
                paramList.add("ContainmentAction");
                fieldClause.append(",CONTAINMENT_ACTION ");
            }
            if (stopSale.getLongTermCorrectiveAction() != null && !stopSale.getLongTermCorrectiveAction().equals("")) {
                paramList.add("LongTermCorrectiveAction");
                fieldClause.append(",LONG_TERM_CORRECTION_ACTION ");
            }

            StringBuffer valueClause = new StringBuffer();
            fieldClause.append(" ");

            valueClause.append(") VALUES (");

            //**Required Fields...
            valueClause.append(stopSaleID);
            valueClause.append(",to_date('").append(getDateFormat(oracleSysdate)).append("','mm/dd/yyyy')");
            valueClause.append(",'").append(stopSale.getCreatedBy()).append("'");
            valueClause.append(",'" + "SS_DOC_ENTRY" + "'");
            valueClause.append(",to_date('").append(getDateFormat(oracleSysdate)).append("','mm/dd/yyyy')");
            valueClause.append(",'").append(SQLUtil.escapeString(stopSale.getInvestigationFindings()))
                    .append("'"); //TODO SQLUtil to PreparedStatement


            //**Optional Fields...
            for (String aParamList : paramList) {
                if (aParamList.equals("RootCause")) {
                    valueClause.append(",'" + SQLUtil.escapeString(stopSale.getRootCause()) + "'");
                }
                if (aParamList.equals("ContainmentAction")) {
                    valueClause.append(",'" + SQLUtil.escapeString(stopSale.getContainmentAction()) + "'");
                }
                if (aParamList.equals("LongTermCorrectiveAction")) {
                    valueClause.append(",'").append(SQLUtil.escapeString(stopSale.getLongTermCorrectiveAction())).append("'");
                }
            }

            valueClause.append(")");

//      logger.info(StopSaleDAOSQLConstants.INSERT_STOP_SALE_DOC + fieldClause.toString() + valueClause.toString());

            ps = conn.prepareStatement(
                    StopSaleDAOSQLConstants.INSERT_STOP_SALE_DOC + fieldClause.toString() + valueClause.toString());

            ps.executeUpdate();

            conn.commit();
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while inserting: ", e);
            throw new DAOException(e);
        }
        finally {
            closeDBResources(null, ps, null);
        }
    }

    private boolean isStringNullEmptyOrSayNull(String st) {
        return StringUtils.isNullOrEmpty(st) || "null".equalsIgnoreCase(st);
    }

    private String getVariety(String varietyBatchPair) {
        String varietyDesc = null;
        if (!StringUtils.isNullOrEmpty(varietyBatchPair)) {
            int index = varietyBatchPair.indexOf(":");
            varietyDesc = varietyBatchPair.substring(0, index);
            if (isStringNullEmptyOrSayNull(varietyDesc)) {
                return null;
            }
        }
        return varietyDesc;
    }

    private String getBatchNumber(String varietyBatchString) {
        String batchNumber = null;
        if (!StringUtils.isNullOrEmpty(varietyBatchString)) {
            int index = varietyBatchString.indexOf(":");
            batchNumber = varietyBatchString.substring(index + 1);
            if (isStringNullEmptyOrSayNull(batchNumber)) {
                return null;
            }
        }
        return batchNumber;
    }

    /**
     * To insert each variety/batch/reason/action-flag, if present...
     *
     * @param stopSaleID
     * @param valueStr
     * @param queryStr
     * @param conn
     */
    private void insertStopSaleRef(int stopSaleID, String valueStr, String queryStr, Connection conn) {
        PreparedStatement ps = null;

        //**Perform Insert-Variety-Operation...
        try {
            ps = conn.prepareStatement(queryStr);

            ps.setInt(1, stopSaleID);
            ps.setString(2, valueStr);

            ps.executeUpdate();

            conn.commit();

        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while inserting ref: ", e);
        }
        finally {
            closeDBResources(null, ps, null);
        }
    }

    /**
     * Creates a new Stop_Sale_Number: [S-FillingLocation-Sales_Year(last 2 digits)-Seq-No]
     *
     * @param stopSale
     * @param conn
     * @return
     */
    private String createStopSaleNumber(StopSaleObject stopSale, Connection conn) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        String sales_year = "";

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_YEAR);
            ps.setString(1, stopSale.getSalesYear());

            rs = ps.executeQuery();

            while (rs.next()) {
                sales_year = rs.getString("YEAR");
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting stopSale_sales_year: ", e);
        }
        finally {
            MCASResourceUtil.closeDBResources(null, ps, rs);
        }


        int max = 0;

        StringBuffer controlBuffer = new StringBuffer();

        controlBuffer.append("S-");
        if (!"".equals(stopSale.getFillingLocation()) && stopSale.getFillingLocation() != null) {
            controlBuffer.append(stopSale.getFillingLocation());
            controlBuffer.append("-");
        }
        if (!"".equals(sales_year) && sales_year != null) {
            controlBuffer.append(sales_year.substring(sales_year.length() - 2, sales_year.length()));
            controlBuffer.append("-");
            controlBuffer.append("%");
        }
        /*String compareTo = "S-" +
        stopSale.getFillingLocation() + "-" +
        sales_year.substring(sales_year.length() - 2, sales_year.length()) + "-" +
        "%";*/

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.AUTO_STOP_SALE_NUMBER);
            // ps.setString(1, compareTo);
            ps.setString(1, controlBuffer.toString());

            rs = ps.executeQuery();

            while (rs.next()) {
                max = rs.getInt("MAX");
            }

            StringBuffer returnControlBuffer = new StringBuffer();

            returnControlBuffer.append("S-");
            if (!"".equals(stopSale.getFillingLocation()) && stopSale.getFillingLocation() != null) {
                returnControlBuffer.append(stopSale.getFillingLocation());
                returnControlBuffer.append("-");
            }
            if (!"".equals(sales_year) && sales_year != null) {
                returnControlBuffer.append(sales_year.substring(sales_year.length() - 2, sales_year.length()));
                returnControlBuffer.append("-");
                returnControlBuffer.append(max + 1);
            }
            /*String returnStr = "S-" +
          stopSale.getFillingLocation() +
          "-" +
          sales_year.substring(sales_year.length() - 2, sales_year.length()) +
          "-" +
          (max + 1);*/

            return returnControlBuffer.toString();
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting stopSale_no: ", e);
            return "";
        }
        finally {
            MCASResourceUtil.closeDBResources(null, ps, rs);
        }

    }

    /**
     * Gets the next-seq value for stop_sale...
     *
     * @param conn
     * @return
     */
    private int getStopSaleSeqValue(Connection conn) {
        PreparedStatement ps = null;
        ResultSet rs = null;

        int stopsaleSeqNextVal = 0;

        try {
            ps = conn.prepareStatement(StopSaleDAOSQLConstants.GET_STOP_SALE_SEQ_NEXTVAL);

            rs = ps.executeQuery();

            while (rs.next()) {
                stopsaleSeqNextVal = rs.getInt("NEXTVAL");
            }
        }
        catch (Exception e) {
            MCASLogUtil.logError("Exception while getting stopsale_seq: ", e);
        }
        finally {
            closeDBResources(null, ps, rs);
        }

        return stopsaleSeqNextVal;
    }

    /**
     * Converts to MM/DD/YYYY String...
     *
     * @param date
     * @return
     */
    private String getDateFormat(Date date) {
        try {
            return sdf.format(date);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }

}
