package com.monsanto.wst.ccas.dao;

/**
 * Date: Dec 22, 2009
 * Time: 2:06:50 PM
 */
class StopSaleDAOSQLConstants {

    static final String GET_ORACLE_SYSDATE =
            "SELECT SYSDATE FROM DUAL";
    static final String GET_STOP_SALE_SEQ_NEXTVAL =
            "SELECT STOP_SALE_SEQ.NEXTVAL FROM DUAL";
    static final String AUTO_STOP_SALE_NUMBER =
            "SELECT MAX(TO_NUMBER(SUBSTR(CONTROL_NUMBER,LENGTH('S-XXXX-YY-')+1))) MAX FROM STOP_SALE WHERE CONTROL_NUMBER LIKE ?";
    static final String INSERT_STOP_SALE =
            "INSERT INTO STOP_SALE " +
                    "(STOP_SALE_ID, CONTROL_NUMBER, DATE_REPORTED,  " +
                    "PERSON_INVESTIGATING, REGION_ID, REPORT_INITIATOR, " +
                    "REPORTING_LOCATION_CODE,  SALES_YEAR_ID, STATE_ID, STATUS_ID, " +
                    "ROW_ENTRY_DATE, ROW_MODIFY_DATE, ROW_TASK_ID, ROW_USER_ID ";
    static final String INSERT_STOP_SALE_DOC =
            "INSERT INTO STOP_SALE_DOCUMENTATION " +
                    "(STOP_SALE_ID, ROW_ENTRY_DATE, ROW_USER_ID, " +
                    "ROW_TASK_ID, ROW_MODIFY_DATE ,INVESTIGATION_FINDINGS ";

    static final String SELECT_VARIETY_BATCH_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH = ?) ";
    static final String SELECT_VARIETY_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH is null) ";
    static final String SELECT_BATCH_ID_SQL = "(SELECT VARIETY_BATCH_ID FROM VARIETY_BATCH WHERE VARIETY is null AND BATCH = ?) ";

    static final String INSERT_STOP_SALE_BATCH_PART =
            "INSERT INTO STOP_SALE_BATCH (STOPSALE_BATCH_SEQ,STOP_SALE_ID, VARIETY_BATCH_ID) " +
                    " VALUES (STOPSALE_BATCH_SEQUENCE.nextval,?, ";

    static final String INSERT_STOP_SALE_BATCH_SQL = INSERT_STOP_SALE_BATCH_PART + SELECT_VARIETY_BATCH_ID_SQL + ")";
    static final String INSERT_STOP_SALE_BATCH_NULL_BATCH_SQL = INSERT_STOP_SALE_BATCH_PART + SELECT_VARIETY_ID_SQL + ")";
    static final String INSERT_STOP_SALE_BATCH_NULL_VARIETY_SQL = INSERT_STOP_SALE_BATCH_PART + SELECT_BATCH_ID_SQL + ")";

    static final String INSERT_STOP_SALE_REASON =
            "INSERT INTO STOP_SALE_REASON (STOP_SALE_ID, STOP_SALE_REASON_ID) VALUES (?, ?)";
    static final String INSERT_STOP_SALE_ACTION_FLAG =
            "INSERT INTO STOP_SALE_ACTION (STOP_SALE_ID, STOP_SALE_ACTION_ID) VALUES (?, ?)";
    static final String UPDATE_STOP_SALE =
            "UPDATE " +
                    "STOP_SALE " +
                    "SET " +
                    "STATUS_ID = ?, REGION_ID = ?, " +
                    "REPORTING_LOCATION_CODE = ?, REPORT_INITIATOR = ?, " +
                    "DATE_REPORTED = to_date(?, 'mm/dd/yyyy'), SALES_YEAR_ID = ?, " +
                    "RESPONSIBLE_PLANT_CODE = ?, FIELD_COMMUNICATOR = ?, " +
                    "STATE_ID = ?, SHIPPING_LOCATION_CODE = ?, " +
                    "DEALER = ?, DEALER_PHONE_NO = ?, " +
                    "STATE_REPORT_NUMBER = ?, STATE_VALUE = ?, " +
                    "STATE_CONTACT = ?, STATE_PHONE_NUMBER = ?, " +
                    "STATE_RETEST = ?, MONSANTO_VALUE = ?, " +
                    "PERSON_INVESTIGATING = ?, " +
                    "CROP_ID = ?, LABEL_VALUE = ?, " +
                    "QUALITY_ISSUE_FLAG = ?, QTY_UOM_ID = ?, " +
                    "SEED_SIZE_ID = ?, ACTION_COMMENTS = ?, " +
                    "ROW_MODIFY_DATE = ? , " +
                    "ROW_TASK_ID = ?, " +
                    "ROW_USER_ID = ?," +
                    "STOP_SALE_BUSINESS_ID = ? , " +
                    "SALES_OFFICE_ID = ? , " +
                    "MATERIAL_GROUP_ID = ? , " +
                    "MATERIAL_GROUP_PRICING_ID = ?  ";
    static final String UPDATE_STOP_SALE_DOC =
            "UPDATE " +
                    "STOP_SALE_DOCUMENTATION " +
                    "SET " +
                    "INVESTIGATION_FINDINGS = ?, ROOT_CAUSE = ?, " +
                    "CONTAINMENT_ACTION = ?, LONG_TERM_CORRECTION_ACTION = ?, " +
                    "ROW_USER_ID = ?, ROW_TASK_ID = ?, " +
                    "ROW_MODIFY_DATE = ? " +
                    "WHERE " +
                    "STOP_SALE_ID = ?";
    static final String DELETE_STOP_SALE_VARIETY =
            "DELETE FROM STOP_SALE_VARIETY WHERE STOP_SALE_ID = ?";
    static final String DELETE_STOP_SALE_BATCH =
            "DELETE FROM STOP_SALE_BATCH WHERE STOP_SALE_ID = ?";
    static final String DELETE_STOP_SALE_REASON =
            "DELETE FROM STOP_SALE_REASON WHERE STOP_SALE_ID = ?";
    static final String DELETE_STOP_SALE_ACTION_FLAG =
            "DELETE FROM STOP_SALE_ACTION WHERE STOP_SALE_ID = ?";
    static final String GET_STOP_SALE =
            "SELECT " +
                    " STOP_SALE_ID, CONTROL_NUMBER, DATE_REPORTED REPORT_DATE, PERSON_INVESTIGATING INVESTIGATOR, " +
                    " REGION_ID REGION, REPORT_INITIATOR INITIATED_BY, REPORTING_LOCATION_CODE FILLING_LOCATION, " +
                    " SALES_YEAR_ID, STATE_ID, STATUS_ID, ROW_USER_ID CREATED_BY, RESPONSIBLE_PLANT_CODE RESPONSIBLE_LOCATION, " +
                    " FIELD_COMMUNICATOR, SHIPPING_LOCATION_CODE SHIPPING_LOCATION, DEALER, DEALER_PHONE_NO, " +
                    " STATE_REPORT_NUMBER, STATE_VALUE, STATE_CONTACT, STATE_PHONE_NUMBER, STATE_RETEST, MONSANTO_VALUE, " +
                    " CROP_ID, LABEL_VALUE, QUALITY_ISSUE_FLAG, QTY_AFFECTED, QTY_UOM_ID, SEED_SIZE_ID, ACTION_COMMENTS, ROW_ENTRY_DATE,STOP_SALE_BUSINESS_ID, SALES_OFFICE_ID, " +
                    " MATERIAL_GROUP_ID, MATERIAL_GROUP_PRICING_ID " +
                    " FROM " +
                    " STOP_SALE " +
                    " WHERE " +
                    " STOP_SALE_ID = ?";
    static final String GET_STOP_SALE_DOC =
            "SELECT " +
                    "INVESTIGATION_FINDINGS, ROOT_CAUSE, " +
                    "CONTAINMENT_ACTION, LONG_TERM_CORRECTION_ACTION " +
                    "FROM " +
                    "STOP_SALE_DOCUMENTATION " +
                    "WHERE " +
                    "STOP_SALE_ID = ?";
    static final String GET_STOP_SALE_VARIETY_BATCH =
            "select vb.batch,vb.variety from stop_sale_batch sb, variety_batch vb " +
                    "where sb.stop_sale_id = ? " +
                    "and sb.variety_batch_id = vb.variety_batch_id ";
    static final String GET_STOP_SALE_REASON =
            "SELECT " +
                    "STOP_SALE_REASON_ID " +
                    "FROM " +
                    "STOP_SALE_REASON " +
                    "WHERE " +
                    "STOP_SALE_ID = ?";
    static final String GET_STOP_SALE_ACTION =
            "SELECT " +
                    "STOP_SALE_ACTION_ID " +
                    "FROM " +
                    "STOP_SALE_ACTION " +
                    "WHERE " +
                    "STOP_SALE_ID = ?";
    static final String GET_STOP_SALE_CAR =
            "SELECT " +
                    "CPAR_ID CAR_ID, " +
                    "CONTROL_NUMBER CAR_NUMBER " +
                    "FROM " +
                    "CPAR " +
                    "WHERE " +
                    "STOP_SALE_ID = ? AND IS_DELETED = 'N'";
    static final String GET_STOP_SALE_NO =
            "SELECT " +
                    "CONTROL_NUMBER STOP_SALE_NUMBER " +
                    "FROM " +
                    "STOP_SALE " +
                    "WHERE " +
                    "STOP_SALE_ID = ?";
    static final String GET_STOP_SALE_LIST_COUNT =
            "SELECT COUNT(*) MAX_ROWS FROM STOP_SALE S ";
    static final String GET_STOP_SALE_LIST =
            " SELECT RANKING, STOP_SALE_ID,CONTROL_NUMBER, STATUS_ID, STATUS,RESPONSIBLE_LOCATION, REGION_ID, REGION, CROP_ID, CROP,DEALER," +
                    " STOP_SALE_BUSINESS_ID,INVESTIGATION_FINDINGS  FROM " +
                    " (SELECT ROWNUM AS RANKING, STOP_SALE_ID,CONTROL_NUMBER, STATUS_ID, STATUS,RESPONSIBLE_LOCATION, REGION_ID, REGION, CROP_ID, CROP,DEALER," +
                    " STOP_SALE_BUSINESS_ID,INVESTIGATION_FINDINGS  FROM  " +
                    " (SELECT " +
                    "S.STOP_SALE_ID, S.CONTROL_NUMBER, S.STATUS_ID, " +
                    "(SELECT SR.STATUS_DESCRIPTION FROM STATUS_REF SR WHERE SR.STATUS_ID=S.STATUS_ID) STATUS, " +
                    "(SELECT L.LOCATION_SHORT_NAME FROM LOCATION_REF L WHERE L.LOCATION_CODE=S.RESPONSIBLE_PLANT_CODE) RESPONSIBLE_LOCATION, S.REGION_ID,  " +
                    "(SELECT R.REGION_DESCRIPTION FROM REGION_REF R WHERE R.REGION_ID=S.REGION_ID) REGION, S.CROP_ID, " +
                    "(SELECT C.SHORT_DESCRIPTION FROM CROP_REF C WHERE C.CROP_ID=S.CROP_ID) CROP, " +
                    "S.DEALER,S.STOP_SALE_BUSINESS_ID, (SELECT SD.INVESTIGATION_FINDINGS FROM STOP_SALE_DOCUMENTATION SD WHERE SD.STOP_SALE_ID = S.STOP_SALE_ID)INVESTIGATION_FINDINGS " +
                    "FROM " +
                    "STOP_SALE S ";
    static final String GET_YEAR =
            "SELECT SHORT_DESCRIPTION YEAR FROM YEAR_REF WHERE YEAR_ID = ?";

    static final String GET_STOP_SALE_REPORT =
            "SELECT   stop_sale.control_number, year_ref.short_description AS YEAR,\n" +
                    "         status_ref.status_description AS status, stop_sale.report_initiator,\n" +
                    "         stop_sale.person_investigating, stop_sale.field_communicator,\n" +
                    "         crop_ref.crop_id,\n" +
                    "         crop_ref.short_description AS crop,stop_sale.MATERIAL_GROUP_ID,stop_sale.MATERIAL_GROUP_PRICING_ID,stop_sale.STOP_SALE_BUSINESS_ID,\n" +
                    "         seed_size_ref.seed_size_id,\n" +
                    "         seed_size_ref.description AS seed_size, stop_sale.qty_affected,\n" +
                    "         qty_uom_ref.qty_uom_id,\n " +
                    "         qty_uom_ref.qty_description AS uom, stop_sale.quality_issue_flag,\n" +
                    "         stop_sale.dealer, stop_sale.dealer_phone_no, stop_sale.state_value,\n" +
                    "         stop_sale.state_retest, stop_sale.state_report_number,\n" +
                    "         stop_sale.state_contact, stop_sale.state_phone_number,\n" +
                    "         stop_sale.date_reported, stop_sale.monsanto_value,\n" +
                    "         stop_sale.label_value, stop_sale.action_comments,\n" +
                    "         region_ref.region_id,\n" +
                    "         region_ref.region_description, state_ref.state_long_name,\n" +
                    "         reporting.location_short_name AS reporting_location,\n" +
                    "         shipping.location_short_name AS shipping_location,\n" +
                    "         responsible.location_short_name AS responsible_location,\n" +
                    "         action.stop_sale_action_id,\n" +
                    "         action.description AS action,\n" +
                    "         stop_sale_reason_ref.stop_sale_reason_id,\n" +
                    "         stop_sale_reason_ref.description AS reason, variety_batch.batch,\n" +
                    "         variety_batch.variety,\n" +
                    "         stop_sale_documentation.investigation_findings,\n" +
                    "         stop_sale_documentation.long_term_correction_action,\n" +
                    "         stop_sale_documentation.root_cause,\n" +
                    "         stop_sale_documentation.containment_action\n" +
                    "    FROM stop_sale,\n" +
                    "         year_ref,\n" +
                    "         status_ref,\n" +
                    "         crop_ref,\n" +
                    "         seed_size_ref,\n" +
                    "         qty_uom_ref,\n" +
                    "         region_ref,\n" +
                    "         state_ref,\n" +
                    "         location_ref reporting,\n" +
                    "         location_ref shipping,\n" +
                    "         location_ref responsible,\n" +
                    "         stop_sale_action,\n" +
                    "         stop_sale_action_ref action,\n" +
                    "         stop_sale_batch,\n" +
                    "         variety_batch,\n" +
                    "         stop_sale_documentation,\n" +
                    "         stop_sale_reason,\n" +
                    "         stop_sale_reason_ref, COMPLAINT_ISSUES,COMPLAINT_ISSUE_REF " +
                    "   WHERE year_ref.year_id = stop_sale.sales_year_id\n" +
                    "     AND status_ref.status_id = stop_sale.status_id\n" +
                    "     AND region_ref.region_id = stop_sale.region_id\n" +
                    "     AND crop_ref.crop_id(+) = stop_sale.crop_id\n" +
                    "     AND seed_size_ref.seed_size_id(+) = stop_sale.seed_size_id\n" +
                    "     AND qty_uom_ref.qty_uom_id(+) = stop_sale.qty_uom_id\n" +
                    "     AND state_ref.state_id(+) = stop_sale.state_id\n" +
                    "     AND stop_sale.reporting_location_code = reporting.location_code(+)\n" +
                    "     AND stop_sale.shipping_location_code = shipping.location_code(+)\n" +
                    "     AND stop_sale.responsible_plant_code = responsible.location_code(+)\n" +
                    "     AND stop_sale_action.stop_sale_id(+) = stop_sale.stop_sale_id\n" +
                    "     AND stop_sale_action.stop_sale_action_id = action.stop_sale_action_id(+)\n" +
                    "     AND variety_batch.variety_batch_id(+) = stop_sale_batch.variety_batch_id\n" +
                    "     AND stop_sale.stop_sale_id = stop_sale_batch.stop_sale_id(+)\n" +
                    "     AND stop_sale.stop_sale_id = stop_sale_documentation.stop_sale_id(+)\n" +
                    "     AND stop_sale.stop_sale_id = stop_sale_reason.stop_sale_id(+)\n" +
                    "     AND stop_sale_reason_ref.stop_sale_reason_id(+) =\n" +
                    "                                          stop_sale_reason.stop_sale_reason_id\n" +
                    "     AND (STOP_SALE.STOP_SALE_ID = COMPLAINT_ISSUES.COMPLAINT_ID(+))\n" +
                    "     AND (COMPLAINT_ISSUES.COMPLAINT_ISSUE_ID = COMPLAINT_ISSUE_REF.COMPLAINT_ISSUE_ID(+))" +
                    "     AND ('S' = COMPLAINT_ISSUES.COMPLAINT_ISSUE_SOURCE(+))";

    static final String UNION_ALL = " UNION ALL \n";

    static final String ADD_STOP_SALE_ATTACHMENT =
            "INSERT INTO stop_sale_attachment sa " +
                    "            (sa.document_id, sa.stop_sale_id, sa.document_name " +
                    "            ) " +
                    "     VALUES (?, ?, ? " +
                    "            ) ";
    static final String GET_STOP_SALE_ATTACHMENT =
            "SELECT sa.document_id, sa.stop_sale_id, sa.document_name " +
                    "  FROM stop_sale_attachment sa " +
                    " WHERE sa.stop_sale_id = ? ";
    static final String DELETE_STOP_SALE_ATTACHMENT =
            "DELETE FROM stop_sale_attachment sa " +
                    "      WHERE sa.document_id = ? ";

    static final String DELETE_STOP_SALE_DUPLICATES = " (UPPER(S.IS_DELETED) = 'N' OR UPPER(S.IS_DELETED) is null) ";
}
