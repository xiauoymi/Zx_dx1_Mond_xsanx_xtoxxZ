/*
 SubFunctionConstants was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
class SubFunctionConstants {
    public static final String LOOKUP_SUBFUNCTION_BY_PROGRAM_ID =
            "SELECT SF.SUBFUNCTION_ID, SF.SUBFUNCTION_DESC FROM SUBFUNCTION_REF SF, PROGRAM_SUBFUNCTION PS WHERE SF.SUBFUNCTION_ID = PS.SUBFUNCTION_ID AND\n" +
                    "PS.PROGRAM_ID = ? AND SF.ACTIVE='Y'";
    public static final String SUB_FUNCTION_ID = "SUBFUNCTION_ID";
    public static final String SUB_FUNCTION_DESC = "SUBFUNCTION_DESC";
}