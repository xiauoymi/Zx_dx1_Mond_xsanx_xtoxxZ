/*
 SubFunctionDAO was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import java.sql.SQLException;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface SubFunctionDAO {
    Map<String, String> lookupSubFunctionForAProgram(String programId, String locale) throws Exception;

    int getSubfunctionIdFromString(String subFunctionDesc) throws SQLException;
}