/*
 SubFunctionDAOImpl was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class SubFunctionDAOImpl extends BaseDAOImpl implements SubFunctionDAO {
    public Map<String, String> lookupSubFunctionForAProgram(String programId, String locale) throws Exception {
        Connection connection = getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = connection.prepareStatement(SubFunctionConstants.LOOKUP_SUBFUNCTION_BY_PROGRAM_ID);
            ps.setString(1, programId);
            resultSet = ps.executeQuery();
            Map<String, String> subFunctionList = new HashMap<String, String>();
            I18nServiceImpl iService = new I18nServiceImpl();

            while (resultSet.next()) {
                int subFunctionId = resultSet.getInt(SubFunctionConstants.SUB_FUNCTION_ID);
                String desc = iService.translate(locale, "SUBFUNCTION_REF", subFunctionId, resultSet.getString(SubFunctionConstants.SUB_FUNCTION_DESC));
                subFunctionList.put(Integer.toString(subFunctionId), desc);
            }

            return subFunctionList;
        }
        finally {
            closeDBResources(connection, ps, resultSet);
        }
    }

    public int getSubfunctionIdFromString(String subFunctionDesc) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            int subFunctionId = 0;
            if (!StringUtils.isNullOrEmpty(subFunctionDesc)) {
                conn = getConnection();
                ps = conn.prepareStatement("SELECT SUBFUNCTION_ID FROM SUBFUNCTION_REF WHERE trim(SUBFUNCTION_DESC) = trim(?)");
                ps.setString(1, subFunctionDesc.trim());
                rs = ps.executeQuery();
                while (rs.next()) {
                    subFunctionId = rs.getInt("SUBFUNCTION_ID");
                }
            }
            return subFunctionId;

        }
        finally {
            closeDBResources(conn, ps, rs);
        }
    }

}