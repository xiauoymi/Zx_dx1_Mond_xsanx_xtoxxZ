/*
 * Created on Mar 4, 2005
 *
 *
 */
package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class UserAccountDAOImpl extends BaseDAOImpl implements UserAccountDAO {

    private final String USER_ROLES_LKP =
            "SELECT distinct p.permission_id, p.description, ua.business_id, ua.business_preference_id, R.ROLE_ID, R.ROLE_DESCRIPTION " +
                    " FROM permission_ref p, role_permission rp, ROLE r, user_administration ua " +
                    " WHERE p.permission_id = rp.permission_id " +
                    " AND rp.role_id = r.role_id " +
                    " AND r.role_id = ua.role_id " +
                    " AND ua.user_id = '";

    /**
     * Constructor. Initialize the datasource.
     *
     * @throws DAOException if lookup of datasource fails
     */
    public UserAccountDAOImpl() {

    }


    public User getUserInfo(User user) throws DAOException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        Map<String, Boolean> roleMap = new HashMap<String, Boolean>();
        Map<String, Boolean> permissionMap = new HashMap<String, Boolean>();
        try {
            conn = getConnection();
            ps = conn.prepareStatement(USER_ROLES_LKP + user.getUser_id().toUpperCase().trim() + "'");
            rs = ps.executeQuery();
            if (rs != null) {

                roleMap = new TreeMap<String, Boolean>();
                while (rs.next()) {
                    permissionMap.put(rs.getString("PERMISSION_ID"), true);
                    roleMap.put(rs.getString("role_id"), true);
                    user.setUserBusinessPreference(rs.getInt("BUSINESS_PREFERENCE_ID"));

                }
            }
            user.setPermissionsMap(permissionMap);
            user.setRolesMap(roleMap);
            return user;
        }
        catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new DAOException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }

    }
}
