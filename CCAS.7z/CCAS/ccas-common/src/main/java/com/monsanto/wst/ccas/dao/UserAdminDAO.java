package com.monsanto.wst.ccas.dao;

import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;

import java.util.List;
import java.util.Map;

/**
 * User: rdesai2
 * Date: Jul 11, 2006
 * Time: 9:17:44 AM
 */
public interface UserAdminDAO {

    UserDetails getSpecificUserDetails(String queriedUserId, String loggedUserId, String locale) throws DAOException, MCASException;

    Map<String, UserDetails> getUserList(String selectedRole, String[] selectedRegion, String userId, String[] businessIds, Map<String, String> regionsMap, String locale) throws DAOException, MCASException;

    boolean addNewUser(UserDetails userDetails, String modUser) throws DAOException, MCASException;

    boolean editUser(UserDetails userDetails, String modUser) throws DAOException, MCASException;

    boolean deleteUser(UserDetails userDetails) throws DAOException, MCASException;

    boolean validateUserPresentinSystem(String userId)throws DAOException, MCASException;

    boolean validateUserPresentinSystemByName(String userName)throws DAOException, MCASException;

    List<String> getUserId(String userName)throws DAOException, MCASException;



}