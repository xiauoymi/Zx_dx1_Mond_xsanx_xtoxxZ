package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.userAdmin.UserBusiness;
import com.monsanto.wst.ccas.controller.userAdmin.UserRegion;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 11, 2006
 * Time: 9:18:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserAdminDAOImpl extends BaseDAOImpl implements UserAdminDAO {

    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private Connection conn = null;

    private static final String SHOW_SPECIFIC_USER_DETAILS_QUERY =
            " SELECT ua.user_id, ua.user_name, ua.role_id, " +
                    " r.role_description, ur.region_id, ua.business_id, ua.business_preference_id, " +
                    " reg.region_description " +
                    " FROM user_administration ua, ROLE r, region_ref reg,user_region ur " +
                    " WHERE ua.user_id = ur.user_id " +
                    " AND ua.role_id = r.role_id " +
                    " AND ur.region_id = reg.region_id " +
                    " AND ua.user_id = ? ";

    private static final String FIND_USER_BY_NAME=" SELECT USER_ID from USER_ADMINISTRATION WHERE trim(USER_NAME)=trim(?)";


    private static final String SHOW_USER_LIST_QUERY =
            "SELECT ua.user_id, ua.user_name, ua.role_id, r.role_description, ur.region_id, " +
                    " reg.region_description,ub.BUSINESS_ID,ua.BUSINESS_PREFERENCE_ID " +
                    " FROM user_administration ua, ROLE r, region_ref reg,user_region ur, USER_BUSINESS ub " +
                    " WHERE ua.role_id = r.role_id AND ur.region_id = reg.region_id ";


    private static final String FIND_NUMBER_OF_USER_RECORDS_QUERY =
            "SELECT COUNT (*) user_record_count " +
                    "  FROM user_business ub " +
                    " WHERE ub.user_id = ?";

    private static final String FIND_NUMBER_OF_USER_BY_NAME_RECORDS_QUERY =
            "SELECT COUNT (*) user_record_count " +
                    "  FROM user_business ub " +
                    " WHERE ub.user_id = (select user_id from user_administration where user_name like ";


    private static final String ADD_NEW_USER_QUERY =
            "INSERT INTO user_administration ua \n" +
                    "            (ua.user_id, ua.user_name, ua.role_id, ua.mod_user, \n" +
                    "             ua.mod_date, ua.business_id, ua.business_preference_id \n" +
                    "            ) \n" +
                    "     VALUES (?, ?, ?, ?, \n" +
                    "             SYSDATE, ?, ? \n" +
                    "            )";


    private static final String EDIT_USER_QUERY =
            "UPDATE user_administration ua " +
                    "   SET ua.role_id = ?, " +
                    "   ua.MOD_USER = ?, " +
                    "   ua.business_id = ?, " +
                    "   ua.business_preference_id = ?, " +
                    "   ua.MOD_DATE = SYSDATE " +
                    "   WHERE ua.user_id = ?";

    private static final String DELETE_USER_QUERY =
            "DELETE FROM USER_ADMINISTRATION ua " +
                    " WHERE ua.user_id = ? ";

    private static final String INSERT_USER_REGION = "INSERT INTO USER_REGION(USER_ID,REGION_ID)VALUES(?,?)";
    private static final String DELETE_USER_REGION = "DELETE FROM USER_REGION WHERE USER_ID = ?";

    private static final String SELECT_REGION_FROM_USER_REGION = "SELECT REGION_ID FROM USER_REGION WHERE USER_ID = ?";
    private static final String SELECT_BUSINESS_FROM_USER_REGION = "SELECT BUSINESS_ID FROM USER_BUSINESS WHERE USER_ID = ?";

    private static final String INSERT_USER_BUSINESS = "INSERT INTO USER_BUSINESS(USER_ID,BUSINESS_ID)VALUES(?,?)";
    private static final String DELETE_USER_BUSINESS = "DELETE FROM USER_BUSINESS WHERE USER_ID = ?";

    public List<String> getUserId(String userName)throws DAOException, MCASException{
        List <String> userIds=new ArrayList<String>();
        try {
            conn = getConnection();

            ps = conn.prepareStatement(FIND_USER_BY_NAME);
            ps.setString(1, userName);
            rs = ps.executeQuery();
            while (rs.next()) {
                userIds.add(rs.getString("USER_ID"));
            }

            return userIds;
        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);

            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }

    }

    public UserDetails getSpecificUserDetails(String queriedUserId, String loggedUserId, String locale) throws DAOException, MCASException {
        UserDetails userDetails = null;
        List<Integer> regionIdList = new ArrayList<Integer>(1);
        boolean isSingleUser = true;
        try {
            conn = getConnection();
            String showUserQuery = getDynamicShowUserQuery(loggedUserId, conn, SHOW_SPECIFIC_USER_DETAILS_QUERY);
            ps = conn.prepareStatement(showUserQuery);
            ps.setString(1, queriedUserId);
            rs = ps.executeQuery();
            if (rs != null) {
                userDetails = getSpecificUserRecord(rs, regionIdList, locale);
            }
            populateUserRegions(userDetails, regionIdList, new HashMap<String, String>(), isSingleUser);
            createUserBusinessRelationship(userDetails, conn);
            return userDetails;
        } catch (Exception e) {
            if (e instanceof SQLException)
                throw new DAOException(e.getMessage(), e);

            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    /**
     * Method to populate User Regions
     *
     * @param userDetails
     * @param regionIdList
     * @param regionsMap
     * @param singleUser
     */
    private void populateUserRegions(UserDetails userDetails, List<Integer> regionIdList, Map<String, String> regionsMap, boolean singleUser) {
        if (regionIdList != null && regionIdList.size() > 0) {
            UserRegion userRegion = new UserRegion(userDetails.getUserId());
            String[] regions = getSelectedRegionsArray(regionIdList, regionsMap, userRegion);
            userRegion.setUserRegionArray(regions);
            userDetails.setUserRegion(userRegion);
            if (!singleUser) {
                userDetails.setRegionDesc(userRegion.getMultipleRegionsDescription());
            }
        }
    }

    private String getDynamicShowUserQuery(String loggedUserId, Connection conn, String showUserQuery) throws DAOException, MCASException {
        return restrictViewableRolesBasedOnUserRole(loggedUserId, conn, showUserQuery);
    }

    public Map<String, UserDetails> getUserList(String selectedRole, String[] selectedRegion, String userId, String[] businessIds, Map<String, String> regionsMap, String locale) throws DAOException, MCASException {
        Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
        try {
            conn = getConnection();
            String showUserListQuery = getShowUserListDynamicQuery(selectedRole, selectedRegion, userId, conn, businessIds);
            ps = conn.prepareStatement(showUserListQuery);
            rs = ps.executeQuery();
            if (rs != null) {
                populateUserRecord(rs, userMap, conn, regionsMap, locale);
            }
            return userMap;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);

        }
    }

    private boolean userHasRole(String userRole, String userId, Connection conn) throws DAOException, MCASException {
        return new LookUpDAOImpl().getRole(userId, conn).equalsIgnoreCase(userRole);
    }

    public boolean addNewUser(UserDetails userDetails, String modUser) throws DAOException, MCASException {
        try {
            conn = getConnection();
            final String userId = userDetails.getUserId();
            if (userPresentInSystem(userId, conn)) {
                return false;
            }
            ps = conn.prepareStatement(ADD_NEW_USER_QUERY);
            ps.setString(1, userDetails.getUserId().trim().toUpperCase());
            ps.setString(2, userDetails.getUserName());
            ps.setInt(3, userDetails.getRoleId());
            //ps.setInt(4, userDetails.getRegionId());
            ps.setString(4, modUser.trim().toUpperCase());
            ps.setInt(5, userDetails.getBusinessId());
            ps.setInt(6, userDetails.getBusinessPreferenceId());
            ps.executeUpdate();
            insertUpdateUserRegion(userDetails, conn);
            insertUpdateUserBusiness(userDetails, conn);
            conn.commit();
//            System.out.println("userId = " + userId + " inserted successful\n");
            return true;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private void insertUpdateUserBusiness(UserDetails userDetails, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        String[] businessIds = userDetails.getUserBusiness().getBusinessIds();
        try {
            ps = conn.prepareStatement(INSERT_USER_BUSINESS);
            if (businessIds != null && businessIds.length > 0) {
                for (String businessId : businessIds) {
                    ps.setString(1, userDetails.getUserId());
                    ps.setInt(2, Integer.parseInt(businessId));
                    ps.addBatch();
                }
            }
            ps.executeBatch();

        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }

    private void insertUpdateUserRegion(UserDetails userDetails, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        String[] regionArray = userDetails.getUserRegion().getUserRegionArray();
        try {
            ps = conn.prepareStatement(INSERT_USER_REGION);
            if (regionArray != null && regionArray.length > 0) {
                for (String region : regionArray) {
                    ps.setString(1, userDetails.getUserId());
                    ps.setInt(2, Integer.parseInt(region));
                    ps.addBatch();
                }
            }
            ps.executeBatch();

        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }

    public boolean validateUserPresentinSystem(String userId)throws DAOException, MCASException{
      conn = getConnection();
      boolean isInSystem=userPresentInSystem(userId,  conn);
        closeDBResources(conn, null, null);
        return  isInSystem;
    }

    public boolean validateUserPresentinSystemByName(String userName)throws DAOException, MCASException{
      conn = getConnection();
      boolean isInSystem=userPresentInSystemByName(userName,  conn);
        closeDBResources(conn, null, null);
        return  isInSystem;
    }

    private boolean userPresentInSystem(String userId, Connection conn) throws DAOException, MCASException {
        try {
            int numberOfRecords = -1;
            ps = conn.prepareStatement(FIND_NUMBER_OF_USER_RECORDS_QUERY);
            ps.setString(1, userId.trim().toUpperCase());
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    numberOfRecords = rs.getInt("USER_RECORD_COUNT");
                }
            }
            return numberOfRecords > 0;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }

    private boolean userPresentInSystemByName(String userName, Connection conn) throws DAOException, MCASException {
        try {
            int numberOfRecords = -1;
            ps = conn.prepareStatement(FIND_NUMBER_OF_USER_BY_NAME_RECORDS_QUERY+"'%"+userName+"%')");
            //ps.setString(1, userName.trim().toUpperCase());
            rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    numberOfRecords = rs.getInt("USER_RECORD_COUNT");
                }
            }
            return numberOfRecords > 0;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }




    public boolean editUser(UserDetails userDetails, String modUser) throws DAOException, MCASException {
        try {
            conn = getConnection();
            ps = conn.prepareStatement(EDIT_USER_QUERY);
            ps.setInt(1, userDetails.getRoleId());
            ps.setString(2, modUser.trim().toUpperCase());
            ps.setInt(3, userDetails.getBusinessId());
            ps.setInt(4, userDetails.getBusinessPreferenceId());
            ps.setString(5, userDetails.getUserId().trim().toUpperCase());
            ps.executeUpdate();
            //Delete entries from USER_REGION table
            deleteUserFromUserRegion(userDetails, conn);
            //Insert entries into USER_REGION table
            insertUpdateUserRegion(userDetails, conn);

            //Delete the user's Business Ids
            deleteUserBusiness(userDetails, conn);
            //Insert User's Business Ids
            insertUpdateUserBusiness(userDetails, conn);
            conn.commit();
            return true;
        } catch (Exception e) {
            if (e instanceof SQLException) {
                throw new DAOException(e.getMessage(), e);
            } else {
                throw new MCASException(e.getMessage(), e);
            }
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    /**
     * Private method to delete records from User_Business Tables
     *
     * @param userDetails
     * @param conn
     * @throws DAOException
     */
    private void deleteUserBusiness(UserDetails userDetails, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(DELETE_USER_BUSINESS);
            ps.setString(1, userDetails.getUserId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }

    /**
     * Method to delete users from USER_REGION table before an update is done.
     *
     * @param userDetails
     * @param conn
     * @throws DAOException
     */
    private void deleteUserFromUserRegion(UserDetails userDetails, Connection conn) throws DAOException {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(DELETE_USER_REGION);
            ps.setString(1, userDetails.getUserId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                throw new DAOException(ex.getMessage(), ex);
            }
        }
    }


    public boolean deleteUser(UserDetails userDetails) throws DAOException, MCASException {
        try {
            conn = getConnection();
            deleteUserFromUserRegion(userDetails, conn);
            deleteUserBusiness(userDetails, conn);

            ps = conn.prepareStatement(DELETE_USER_QUERY);
            ps.setString(1, userDetails.getUserId().trim().toUpperCase());
            ps.executeUpdate();
            conn.commit();
            return true;
        } catch (SQLException e) {
            throw new DAOException(e.getMessage(), e);
        } catch (Exception e) {
            throw new MCASException(e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    private UserDetails populateUserRecord(ResultSet rs, Map<String, UserDetails> userMap, Connection conn, Map<String, String> regionsMap, String locale) throws Exception {
        UserDetails userDetails = null;
        I18nServiceImpl iService = new I18nServiceImpl();

        while (rs.next()) {
            String userId = rs.getString("USER_ID");
            String userName = rs.getString("USER_NAME");
            int userRoleId = rs.getInt("ROLE_ID");
            String userRoleDesc = iService.translate(locale, "ROLE", userRoleId, rs.getString("ROLE_DESCRIPTION"));

            int businessId = rs.getInt("BUSINESS_ID");
            int businessPreferenceId = rs.getInt("BUSINESS_PREFERENCE_ID");
            userDetails = createUserRegionRelationship(conn, regionsMap, userId, userName, userRoleId, userRoleDesc, businessId, businessPreferenceId);
            userDetails = createUserBusinessRelationship(userDetails, conn);
            userMap.put(userId, userDetails);
        }
        return userDetails;
    }

    private UserDetails createUserBusinessRelationship(UserDetails userDetails, Connection conn) throws SQLException {
        List<Integer> businessIdList = new ArrayList<Integer>(1);
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(SELECT_BUSINESS_FROM_USER_REGION);
            ps.setString(1, userDetails.getUserId());
            rs = ps.executeQuery();
            while (rs.next()) {
                businessIdList.add(rs.getInt("BUSINESS_ID"));
            }
            populateUserBusiness(userDetails, businessIdList);
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } finally {
            closeDBResources(null, ps, rs);
        }
        return userDetails;
    }

    private void populateUserBusiness(UserDetails userDetails, List<Integer> businessIdList) {
        String[] businessIdArr = new String[businessIdList.size()];
        int i = 0;
        for (Integer businessId : businessIdList) {
            businessIdArr[i++] = businessId.toString();
        }
        UserBusiness userBusiness = new UserBusiness(userDetails.getUserId(), businessIdArr);
        userDetails.setUserBusiness(userBusiness);
    }

    /**
     * Method  used to create user details object and associate more than 1 regions to the user
     *
     * @param conn                 DB Connection
     * @param regionsMap           Map that contains "regionID:Description" pair
     * @param userId               User ID
     * @param userName             Name
     * @param userRoleId           User Role
     * @param userRoleDesc         Role Description
     * @param businessId           Business ID of the user (Vegetable | Rowcrop)
     * @param businessPreferenceId Business Preference
     * @return User Details
     * @throws SQLException
     */
    private UserDetails createUserRegionRelationship(Connection conn, Map<String, String> regionsMap, String userId, String userName, int userRoleId, String userRoleDesc, int businessId, int businessPreferenceId) throws SQLException {
        UserDetails userDetails;
        userDetails = new UserDetails(userId, userName, userRoleId, userRoleDesc, null, "",
                businessId, businessPreferenceId);
        populateUserDetailsWithUserRegion(userId, userDetails, conn, regionsMap);
        return userDetails;
    }

    /**
     * Method to populate User Details with multiple regions if associated
     *
     * @param userId
     * @param userDetails
     * @param conn
     * @param regionsMap
     * @throws SQLException
     */
    private void populateUserDetailsWithUserRegion(String userId, UserDetails userDetails, Connection conn, Map<String, String> regionsMap) throws SQLException {
        List<Integer> regionList = new ArrayList<Integer>(1);
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean isSingleUser = false;
        try {
            ps = conn.prepareStatement(SELECT_REGION_FROM_USER_REGION);
            ps.setString(1, userId);
            rs = ps.executeQuery();
            while (rs.next()) {
                regionList.add(rs.getInt("REGION_ID"));
            }
            populateUserRegions(userDetails, regionList, regionsMap, isSingleUser);
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            closeDBResources(null, ps, rs);
        }


    }

    private UserDetails getSpecificUserRecord(ResultSet rs, List<Integer> regionsList, String locale) throws Exception {
        UserDetails userDetails;
        String userId = "";
        String userName = "";
        int userRoleId = -1;
        String userRoleDesc = "";
        int userRegionId = -1;
        String userRegionDesc = "";
        int businessId = -1;
        int businessPreferenceId = -1;
        StringBuffer regionDescriptionBuffer = new StringBuffer();
        String regionDesc = "";
        I18nServiceImpl iService = new I18nServiceImpl();

        while (rs.next()) {
            userId = rs.getString("USER_ID");
            userName = rs.getString("USER_NAME");

            userRoleId = rs.getInt("ROLE_ID");
            userRoleDesc = iService.translate(locale, "ROLE", userRoleId, rs.getString("ROLE_DESCRIPTION"));

            userRegionId = rs.getInt("REGION_ID");
            userRegionDesc = iService.translate(locale, "REGION_REF", userRegionId, rs.getString("REGION_DESCRIPTION"));

            businessId = rs.getInt("BUSINESS_ID");
            businessPreferenceId = rs.getInt("BUSINESS_PREFERENCE_ID");
            regionsList.add(userRegionId);
            regionDescriptionBuffer.append(userRegionDesc).append(",");
        }
        regionDesc = parseRegionDescription(regionDescriptionBuffer, regionDesc);

        userDetails = new UserDetails(userId, userName, userRoleId, userRoleDesc, null, regionDesc, businessId, businessPreferenceId);
        return userDetails;
    }

    private String parseRegionDescription(StringBuffer regionDescriptionBuffer, String regionDesc) {
        if (!StringUtils.isNullOrEmpty(regionDescriptionBuffer.toString())) {
            regionDesc = regionDescriptionBuffer.substring(0, regionDescriptionBuffer.lastIndexOf(","));
        }
        return regionDesc;
    }


    private String[] getSelectedRegionsArray(List<Integer> regionIdList, Map<String, String> regionsMap, UserRegion userRegion) {

        Object[] selectedRegionsObjectArr = regionIdList.toArray();
        String[] regionsArr = null;
        int index = 0;
        StringBuffer regionDescriptionBuffer = new StringBuffer(regionIdList.size());
        if (selectedRegionsObjectArr != null && selectedRegionsObjectArr.length > 0) {
            regionsArr = new String[selectedRegionsObjectArr.length];
            for (Object region : selectedRegionsObjectArr) {
                if (regionsMap.containsKey(region.toString())) {
                    regionDescriptionBuffer.append(regionsMap.get(region.toString())).append(",");
                }
                regionsArr[index++] = region.toString();
            }
            userRegion.setMultipleRegionsDescription(regionDescriptionBuffer.toString());
        }
        return regionsArr;
    }

    private String getShowUserListDynamicQuery(String selectedRole, String[] selectedRegions, String userId, Connection conn, String[] businessIds) throws DAOException, MCASException {
        String showUserListQuery = SHOW_USER_LIST_QUERY;
        showUserListQuery = appendClause(showUserListQuery, selectedRole, " AND r.role_id = ");
        //todo: BUG?  businessIds is an array, don't call toString() on it.
//        showUserListQuery = appendClause(showUserListQuery, businessIds + "", " AND UA.BUSINESS_ID = ");

//this should be able to be removed.  It checks business ID elsewhere.
//        if ( businessIds != null )
//            showUserListQuery = appendClause(showUserListQuery, businessIds[0] + "", " AND UA.BUSINESS_ID = ");


        showUserListQuery = appendRegionIdInclause(showUserListQuery, selectedRegions);
        showUserListQuery = appendBusinessIdInclause(showUserListQuery, businessIds);
        showUserListQuery = restrictViewableRolesBasedOnUserRole(userId, conn, showUserListQuery);
        showUserListQuery += " AND UA.USER_ID = UR.USER_ID AND UB.USER_ID = UA.USER_ID ORDER BY ua.user_id";
        return showUserListQuery;
    }

    private String appendRegionIdInclause(String showUserListQuery, String[] selectedRegions) {
        StringBuffer queryClauseToAppend = new StringBuffer(" AND UR.REGION_ID IN ( ");
        StringBuffer regionIdBuffer = new StringBuffer();
        if (selectedRegions != null && selectedRegions.length > 0) {
            for (String regionId : selectedRegions) {
                if (!StringUtils.isNullOrEmpty(regionId)) {
                    regionIdBuffer.append(Integer.parseInt(regionId));
                    regionIdBuffer.append(",");
                }
            }
            if (!StringUtils.isNullOrEmpty(regionIdBuffer.toString())) {
                showUserListQuery += queryClauseToAppend.append(regionIdBuffer.substring(0, regionIdBuffer.lastIndexOf(","))) + " )";
            }
        }
        return showUserListQuery;
    }

    private boolean isBusinessNull(String[] businessIds) {
        return (businessIds == null || (businessIds.length == 1 && businessIds[0].equalsIgnoreCase("")));
    }

    private String appendBusinessIdInclause(String showUserListQuery, String[] selectedBusinessIds) {
        if (!isBusinessNull(selectedBusinessIds)) {
            StringBuffer queryClauseToAppend = new StringBuffer(" AND UB.BUSINESS_ID IN ( ");
            StringBuffer businessIdBuffer = new StringBuffer();
            for (String businessId : selectedBusinessIds) {
                if (!StringUtils.isNullOrEmpty(businessId)) {
                    businessIdBuffer.append(Integer.parseInt(businessId));
                    businessIdBuffer.append(",");
                }
            }
            if (!StringUtils.isNullOrEmpty(businessIdBuffer.toString())) {
                showUserListQuery += queryClauseToAppend.append(businessIdBuffer.substring(0, businessIdBuffer.lastIndexOf(","))) + " )";
            }

        }
        return showUserListQuery;
    }

    private String restrictViewableRolesBasedOnUserRole(String loggedUserId, Connection conn, String showUserListQuery) throws DAOException, MCASException {
        if (userHasRole(MCASConstants.ROLE_REGIONAL_ADMIN, loggedUserId, conn)) {
            showUserListQuery += " AND r.role_id NOT IN (" + MCASConstants.ROLE_ID_SYSTEM_ADMIN + ") ";
        }
        return showUserListQuery;
    }

    private String appendClause(String showUserListQuery, String selectedAttribute, String queryClauseToAppend) {
        int selectedAttributeId;
        if (!StringUtils.isNullOrEmpty(selectedAttribute) && !("-1".equals(selectedAttribute))) {
            try {
                selectedAttributeId = Integer.parseInt(selectedAttribute);
                showUserListQuery += queryClauseToAppend + selectedAttributeId;
            } catch (NumberFormatException e) {
                MCASLogUtil.logError(e.getMessage(), e);
                //need not append any clause
            }
        }
        return showUserListQuery;
    }
}
