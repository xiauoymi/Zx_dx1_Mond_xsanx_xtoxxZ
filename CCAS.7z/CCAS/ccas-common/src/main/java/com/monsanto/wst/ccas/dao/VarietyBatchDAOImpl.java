/*
Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.documentutil.logutil.DocumentLogUtil;
import oracle.jdbc.OracleConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * @author rdesai2
 */
public class VarietyBatchDAOImpl extends VarietyBatchDAO {

    private static final String VARIETY_BATCH_EXISTS =
            "SELECT COUNT(*) FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH = ?";

    private static final String VARIETY_BATCH_INSERT =
            "INSERT INTO VARIETY_BATCH (VARIETY_BATCH_ID, VARIETY, BATCH, ACTIVE_FLAG) " +
                    "VALUES(?,UPPER(?),UPPER(?),'Y')";

    private static final String BATCH_EXISTS =
            "SELECT COUNT(*) FROM VARIETY_BATCH WHERE VARIETY IS NULL AND BATCH = ?";

    private static final String BATCH_INSERT =
            "INSERT INTO VARIETY_BATCH (VARIETY_BATCH_ID, VARIETY, BATCH, ACTIVE_FLAG) " +
                    "VALUES(?,NULL,UPPER(?),'Y')";

    private static final String VARIETY_EXISTS =
            "SELECT COUNT(*) FROM VARIETY_BATCH WHERE VARIETY = ? AND BATCH IS NULL";

    private static final String VARIETY_INSERT =
            "INSERT INTO VARIETY_BATCH (VARIETY_BATCH_ID, VARIETY, BATCH, ACTIVE_FLAG) " +
                    "VALUES(?,UPPER(?),NULL,'Y')";


    private static final String VARIETY_BATCH_SEQ =
            "SELECT CCAS.VARIETY_BATCH_SEQ.NEXTVAL FROM DUAL";

    private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_PATTERN =
            "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM VARIETY_BATCH WHERE VARIETY LIKE UPPER(?) ORDER BY VARIETY, BATCH";

    private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_BATCH_PATTERN =
            "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM VARIETY_BATCH WHERE BATCH LIKE UPPER(?) ORDER BY VARIETY, BATCH";

    private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_AND_BATCH_PATTERN =
            "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM VARIETY_BATCH WHERE VARIETY LIKE UPPER(?) AND BATCH LIKE UPPER(?) ORDER BY VARIETY, BATCH";

    private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_PATTERN_CROP_NAME =
                "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM claim_crop_variety_view WHERE VARIETY LIKE UPPER(?) and crop_name=? ORDER BY VARIETY, BATCH";

        private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_BATCH_PATTERN_CROP_NAME =
                "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM claim_crop_variety_view WHERE BATCH LIKE UPPER(?)  and crop_name=? ORDER BY VARIETY, BATCH";

        private static final String SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_AND_BATCH_PATTERN_CROP_NAME =
                "SELECT VARIETY_BATCH_ID, VARIETY, BATCH FROM claim_crop_variety_view WHERE VARIETY LIKE UPPER(?) AND BATCH LIKE UPPER(?) and crop_name=? ORDER BY VARIETY, BATCH";

    private static final String GET_NEW_VARIETY_BATCH_DATA =
            "SELECT TRIM(REPLACE(DESCRIPTION, CHR(13))) AS VARIETY, TRIM(REPLACE(BATCH_NUMBER, CHR(13))) AS BATCH FROM VARIETY_BATCH_TEMP " +
                    "MINUS SELECT VARIETY, BATCH FROM VARIETY_BATCH WHERE ACTIVE_FLAG='Y'";

    private static final String GET_INACTIVATED_VARIETY_BATCH_DATA =
            "SELECT VARIETY, BATCH FROM VARIETY_BATCH WHERE ACTIVE_FLAG='Y' " +
                    "MINUS TRIM(REPLACE(DESCRIPTION, CHR(13))) AS VARIETY, TRIM(REPLACE(BATCH_NUMBER, CHR(13))) AS BATCH FROM VARIETY_BATCH_TEMP ";

    private static final String VARIETY_BATCH_INACTIVATE =
            "UPDATE VAREITY_BATCH SET ACTIVE_FLAG = 'N' WHERE VARIETY_BATCH_ID = ?";

    private static final int ROW_PREFETCH_COUNT = 1000;

    //this returns a map indexed by strings so that the JSPs can handle them easily.
    public Map<String, VarietyBatch> getVarietyBatchData(String varietyPattern, String batchPattern) throws DAOException, MCASException {
        if (!patternEntered(varietyPattern) && !patternEntered(batchPattern)) {
            throw new DAOException("VarietyBatchDAOImpl: getVarietyBatchData() - " +
                    "Atleast one of the variety/batch pattern has to be entered for search");
        }

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = setPreparedStatementDependingUponNumberOfPatternsEntered(conn, varietyPattern, batchPattern,"");
            rs = ps.executeQuery();

            int varietyBatchRecordNumber = 0;
            String oldVarietyDesc = "";
            String oldBatchNumber = "";
            Map<String, VarietyBatch> varietyBatchMap = new LinkedHashMap<String, VarietyBatch>();
            while (rs.next()) {
                int varietyBatchNo = rs.getInt("VARIETY_BATCH_ID");
                String varietyDesc = rs.getString("VARIETY");
                String batchNumber = rs.getString("BATCH");
                varietyDesc = stripCarriageReturnChar(varietyDesc);
                //To make sure that Variety/Batch pairs are not repeated
                if (!(isVarietyIdentical(oldVarietyDesc, varietyDesc) && isBatchIdentical(oldBatchNumber, batchNumber))) {
                    VarietyBatch varietyBatch = new VarietyBatch(varietyBatchNo, varietyDesc, batchNumber);
                    varietyBatchMap.put(String.valueOf(varietyBatchRecordNumber), varietyBatch);
                    varietyBatchRecordNumber++;
                    oldVarietyDesc = varietyDesc;
                    oldBatchNumber = batchNumber;
                }
            }
            return varietyBatchMap;
        } catch (SQLException e) {
            throw new MCASException(e);
        } finally {
            MCASResourceUtil.closeDBResources(conn, ps, rs);
        }
    }

    public Map<String, VarietyBatch> getVarietyBatchDataValidCrop(String varietyPattern, String batchPattern,String cropName) throws DAOException, MCASException {
            if (!patternEntered(varietyPattern) && !patternEntered(batchPattern)) {
                throw new DAOException("VarietyBatchDAOImpl: getVarietyBatchData() - " +
                        "Atleast one of the variety/batch pattern has to be entered for search");
            }

            PreparedStatement ps = null;
            ResultSet rs = null;
            Connection conn = null;
            try {
                conn = getConnection();
                ps = setPreparedStatementDependingUponNumberOfPatternsEntered(conn, varietyPattern, batchPattern,cropName);
                rs = ps.executeQuery();

                int varietyBatchRecordNumber = 0;
                String oldVarietyDesc = "";
                String oldBatchNumber = "";
                Map<String, VarietyBatch> varietyBatchMap = new LinkedHashMap<String, VarietyBatch>();
                while (rs.next()) {
                    int varietyBatchNo = rs.getInt("VARIETY_BATCH_ID");
                    String varietyDesc = rs.getString("VARIETY");
                    String batchNumber = rs.getString("BATCH");
                    varietyDesc = stripCarriageReturnChar(varietyDesc);
                    //To make sure that Variety/Batch pairs are not repeated
                    if (!(isVarietyIdentical(oldVarietyDesc, varietyDesc) && isBatchIdentical(oldBatchNumber, batchNumber))) {
                        VarietyBatch varietyBatch = new VarietyBatch(varietyBatchNo, varietyDesc, batchNumber);
                        varietyBatchMap.put(String.valueOf(varietyBatchRecordNumber), varietyBatch);
                        varietyBatchRecordNumber++;
                        oldVarietyDesc = varietyDesc;
                        oldBatchNumber = batchNumber;
                    }
                }
                return varietyBatchMap;
            } catch (SQLException e) {
                throw new MCASException(e);
            } finally {
                MCASResourceUtil.closeDBResources(conn, ps, rs);
            }
        }

    private boolean isBatchIdentical(String oldBatchNumber, String batchNumber) {
        return StringUtils.areEqual(oldBatchNumber, batchNumber);
    }

    private boolean isVarietyIdentical(String oldVarietyDesc, String varietyDesc) {
        return oldVarietyDesc.equalsIgnoreCase(varietyDesc);
    }

    private String stripCarriageReturnChar(String varietyDesc) {
        String returnStr = varietyDesc;
        if (!StringUtils.isNullOrEmpty(varietyDesc) && varietyDesc.contains("\r")) {
            returnStr = varietyDesc.substring(0, varietyDesc.indexOf("\r"));
        }
        return returnStr;
    }

    public boolean insertVarietyBatch(List<VarietyBatch> varietyBatchListParam) throws DAOException, MCASException {
        if (varietyBatchListParam == null) {
            throw new IllegalArgumentException("VarietyBatch List cannot be null.");
        }

        List<VarietyBatch> varietyBatchList = varietyBatchListParam;
        PreparedStatement varietyBatchExistsStmt = null;
        PreparedStatement varietyBatchInsertStmt = null;
        PreparedStatement batchExistsStmt = null;
        PreparedStatement batchInsertStmt = null;
        PreparedStatement varietyExistsStmt = null;
        PreparedStatement varietyInsertStmt = null;
        PreparedStatement seqStmt = null;
        Connection conn = null;
        try {
            conn = getConnection();
            setFetchSize(conn);

            //fix for NULLS!
            varietyBatchExistsStmt = conn.prepareStatement(VARIETY_BATCH_EXISTS);
            varietyBatchInsertStmt = conn.prepareStatement(VARIETY_BATCH_INSERT);
            batchExistsStmt = conn.prepareStatement(BATCH_EXISTS);
            batchInsertStmt = conn.prepareStatement(BATCH_INSERT);
            varietyExistsStmt = conn.prepareStatement(VARIETY_EXISTS);
            varietyInsertStmt = conn.prepareStatement(VARIETY_INSERT);


            seqStmt = conn.prepareStatement(VARIETY_BATCH_SEQ);

            for (VarietyBatch varietyBatch : varietyBatchList) {

                try {
                    String variety = varietyBatch.getVarietyDesc();
                    String batch = varietyBatch.getBatchNumber();

                    if ("".equals(variety)) variety = null;
                    if ("".equals(batch)) batch = null;

                    if (variety != null && batch != null) {
                        if (!varietyBatchFound(varietyBatchExistsStmt, variety, batch)) {
                            insertVarietyBatch(seqStmt, varietyBatchInsertStmt, variety, batch);
                        }
                    } else if (variety == null) {
                        if (!varietyBatchFoundWithNull(batchExistsStmt, batch)) {
                            insertVarietyBatchWithNull(seqStmt, batchInsertStmt, batch);
                        }
                    } else if (batch == null) {
                        if (!varietyBatchFoundWithNull(varietyExistsStmt, variety)) {
                            insertVarietyBatchWithNull(seqStmt, varietyInsertStmt, variety);
                        }
                    }
                }
                catch (SQLException e) {
                    throw new DAOException("SQLException while checking for Batch presense.", e);
                } catch (Exception e) {
                    throw new MCASException("Exception while checking for Batch presense.", e);
                }
            }
            conn.commit();
            return true;
        } catch (Exception e) {
            DocumentLogUtil.logError("Exception while inserting Variety/Batch Data.", e);
            e.printStackTrace();
            throw new MCASException(e);
        } finally {
            closeDBResources(null, varietyBatchExistsStmt, null);
            closeDBResources(null, varietyBatchInsertStmt, null);
            closeDBResources(null, batchExistsStmt, null);
            closeDBResources(null, batchInsertStmt, null);
            closeDBResources(null, varietyExistsStmt, null);
            closeDBResources(null, varietyInsertStmt, null);
            closeDBResources(null, seqStmt, null);

            closeDBResources(conn, null, null);
        }
    }

    public boolean inactivateVarietyBatch(List<VarietyBatch> varietyBatchListParam) throws DAOException, MCASException {
        if (varietyBatchListParam == null) {
            throw new IllegalArgumentException("VarietyBatch List cannot be null.");
        }

        List<VarietyBatch> varietyBatchList = varietyBatchListParam;
        PreparedStatement varietyBatchUpdateStmt = null;
        Connection conn = null;
        try {
            conn = getConnection();
            setFetchSize(conn);
            varietyBatchUpdateStmt = conn.prepareStatement(VARIETY_BATCH_INACTIVATE);

            for (VarietyBatch varietyBatch : varietyBatchList) {

                try {
                    inactivateVarietyBatch(varietyBatchUpdateStmt, varietyBatch);
                }
                catch (SQLException e) {
                    throw new DAOException("SQLException while checking for Batch presense.", e);
                } catch (Exception e) {
                    throw new MCASException("Exception while checking for Batch presense.", e);
                }
            }
            conn.commit();
            return true;
        } catch (Exception e) {
            DocumentLogUtil.logError("Exception while inserting Variety/Batch Data.", e);
            e.printStackTrace();
            throw new MCASException(e);
        } finally {
            closeDBResources(conn, varietyBatchUpdateStmt, null);
        }
    }


    private void setFetchSize(Connection conn) throws SQLException {
        try {
            ((OracleConnection) conn).setDefaultRowPrefetch(ROW_PREFETCH_COUNT);
        } catch (ClassCastException IGNORE) {
            // just live with the default if this isn't an OracleConnection
        }
    }

    private boolean varietyBatchFound(PreparedStatement varietyBatchExistsStmt, final String variety, final String batch)
            throws SQLException {

        ResultSet rs = null;
        try {
            varietyBatchExistsStmt.setString(1, variety);
            varietyBatchExistsStmt.setString(2, batch);
            rs = varietyBatchExistsStmt.executeQuery();

            rs.next();
            return rs.getInt(1) > 0;

        } finally {
            closeResultSetIfNotNull(rs);
        }
    }

    private boolean varietyBatchFoundWithNull(PreparedStatement varietyOrBatchExistStmt, final String varietyOrBatch)
            throws SQLException {

        ResultSet rs = null;
        try {
            varietyOrBatchExistStmt.setString(1, varietyOrBatch);
            rs = varietyOrBatchExistStmt.executeQuery();

            rs.next();
            return rs.getInt(1) > 0;

        } finally {
            closeResultSetIfNotNull(rs);
        }
    }

    private void insertVarietyBatch(PreparedStatement seqStmt, PreparedStatement varietyBatchInsertStmt, final String variety, final String batch)
            throws SQLException {

        varietyBatchInsertStmt.setLong(1, getVarietyBatchSeq(seqStmt));
        varietyBatchInsertStmt.setString(2, variety);
        varietyBatchInsertStmt.setString(3, batch);
        varietyBatchInsertStmt.executeUpdate();
    }

    private void insertVarietyBatchWithNull(PreparedStatement seqStmt, PreparedStatement varietyOrBatchInsertStmt, final String varietyOrBatch)
            throws SQLException {

        varietyOrBatchInsertStmt.setLong(1, getVarietyBatchSeq(seqStmt));
        varietyOrBatchInsertStmt.setString(2, varietyOrBatch);
        varietyOrBatchInsertStmt.executeUpdate();
    }


    private long getVarietyBatchSeq(PreparedStatement seqStmt) throws SQLException {
        ResultSet rs = null;
        try {
            rs = seqStmt.executeQuery();

            rs.next();
            return rs.getLong(1);
        }
        finally {
            if (rs != null) rs.close();
        }
    }

    private void inactivateVarietyBatch(PreparedStatement varietyBatchExistsStmt, VarietyBatch varietyBatch)
            throws SQLException {

        varietyBatchExistsStmt.setInt(1, varietyBatch.getVarietyBatchId());
        varietyBatchExistsStmt.executeUpdate();
    }

    private PreparedStatement setPreparedStatementDependingUponNumberOfPatternsEntered(Connection conn, String varietyPattern, String batchPattern,String cropName) throws SQLException {
        if (patternEntered(varietyPattern) && !patternEntered(batchPattern)) {

            PreparedStatement ps =null;

            if(cropName!=null&&!cropName.equalsIgnoreCase("")){
                ps = conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_PATTERN_CROP_NAME);
                ps.setString(1, getLikeStringInUpperCase(varietyPattern));
                ps.setString(2, cropName);
            }
            else{
                ps = conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_PATTERN);
                ps.setString(1, getLikeStringInUpperCase(varietyPattern));
            }

            return ps;
        } else if (patternEntered(batchPattern) && !patternEntered(varietyPattern)) {
            PreparedStatement ps = null;
            if(cropName!=null&&!cropName.equalsIgnoreCase("")){
                ps=conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_BATCH_PATTERN_CROP_NAME);
                ps.setString(1, getLikeStringInUpperCase(batchPattern));
                ps.setString(2, cropName);
            }
            else{
                ps=conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_BATCH_PATTERN);
                ps.setString(1, getLikeStringInUpperCase(batchPattern));
            }
            return ps;
        } else {

            PreparedStatement ps = null;
            if(cropName!=null&&!cropName.equalsIgnoreCase("")){
                ps=conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_AND_BATCH_PATTERN_CROP_NAME);
                ps.setString(1, getLikeStringInUpperCaseForVarietyEntered(varietyPattern));
                ps.setString(2, getLikeStringInUpperCase(batchPattern));
                ps.setString(3, cropName);

            }
            else{
                ps=conn.prepareStatement(SELECT_ACTIVE_VARIETY_BATCH_BY_VARIETY_AND_BATCH_PATTERN);
                ps.setString(1, getLikeStringInUpperCaseForVarietyEntered(varietyPattern));
                ps.setString(2, getLikeStringInUpperCase(batchPattern));
            }
            return ps;
        }
    }

    private String getLikeStringInUpperCaseForVarietyEntered(String pattern) {
        if (pattern.contains("*")) {
            return replaceAsteriskWithModulus(pattern);
        } else {
            return pattern.trim() + "%";
        }
    }

    private String getLikeStringInUpperCase(String pattern) {
        if (pattern.contains("*")) {
            return replaceAsteriskWithModulus(pattern);
        } else {
            return pattern.trim();
        }
    }

    private String replaceAsteriskWithModulus(String pattern) {
        return pattern.replaceAll("\\*", "%").trim();
    }

    private boolean patternEntered(String varietyPattern) {
        return !StringUtils.isNullOrEmpty(varietyPattern);
    }

    private void closeStatementifNotNull(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException e) {
            // ignore error on close
        }
    }

    private void closeResultSetIfNotNull(ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
        } catch (SQLException e) {
            // ignore error on close
        }
    }

    public List getNewVarietyBatchData() throws MCASException {
        return getDifferentialVarietyBatchData(GET_NEW_VARIETY_BATCH_DATA);
    }

    public List getInactivatedVarietyBatchData() throws MCASException {
        return getDifferentialVarietyBatchData(GET_INACTIVATED_VARIETY_BATCH_DATA);
    }

    private List getDifferentialVarietyBatchData(String differentialSQL) throws MCASException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            List<VarietyBatch> varietyBatchList = new ArrayList<VarietyBatch>();
            conn = getConnection();
            ps = conn.prepareStatement(differentialSQL);
            rs = ps.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    String varietyDesc = rs.getString("VARIETY");
                    String batchNumber = rs.getString("BATCH");
                    VarietyBatch varietyBatch = new VarietyBatch(null, varietyDesc, batchNumber);
                    varietyBatchList.add(varietyBatch);
                }
            }
            System.out.println("GET_NEW_VARIETY_BATCH_DATA returned " + varietyBatchList.size() + " records.");
            return varietyBatchList;
        } catch (Exception e) {
            throw new MCASException("Exception while getting variety-batch data: " + e.getMessage(), e);
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }

    public void deleteDataFromVarietyBatchTempTable() {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement("DELETE FROM VARIETY_BATCH_TEMP");
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeDBResources(conn, ps, rs);
        }
    }
}