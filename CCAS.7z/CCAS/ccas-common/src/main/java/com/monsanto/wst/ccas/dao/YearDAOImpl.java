/*
 YearDAOImpl was created on Sep 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class YearDAOImpl implements YearDAO {
    private final DataSource dataSource;
    private static final String INSERT_YEAR_SQL = "insert into year_ref values (complaint_seq.nextval, ?, ?)";
    private static final String FIND_ALL_SQL = "select year_id, short_description from year_ref order by short_description desc";
    private static final String LOOKUP_SPECIFIC_YEAR = "select count(short_description) from year_ref where  short_description = ?";


    public YearDAOImpl(DataSource source) {
        dataSource = source;
    }

    public void insertYearForNewFiscalYear(int year) throws SQLException {
        Connection connection = null;
        PreparedStatement ps = null;

        try {
            connection = dataSource.getConnection();
            ps = connection
                    .prepareStatement(INSERT_YEAR_SQL);
            ps.setString(1, String.valueOf(year));
            ps.setString(2, String.valueOf(year));
            ps.executeUpdate();
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, ps, null);
        }

    }

    public Map<String, String> findAll() throws SQLException {

        Connection connection = dataSource.getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = connection.prepareStatement(FIND_ALL_SQL);
            resultSet = ps.executeQuery();
            Map<String, String> yearMap = new LinkedHashMap<String, String>();
            while (resultSet.next()) {
                yearMap.put(resultSet.getString(1), resultSet.getString(2));
            }
            return yearMap;
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, ps, resultSet);
        }
    }

    public boolean doesYearExistInDB(int year) throws SQLException {

        Connection connection = dataSource.getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        try {
            ps = connection.prepareStatement(LOOKUP_SPECIFIC_YEAR);
            ps.setString(1, String.valueOf(year));
            resultSet = ps.executeQuery();

            MCASResourceUtil.closeDBResources(null, ps, resultSet);


            ps = connection.prepareStatement(LOOKUP_SPECIFIC_YEAR);
            ps.setString(1, String.valueOf(year));
            resultSet = ps.executeQuery();
            boolean entryExists = false;
            while (resultSet.next()) {
                int count = resultSet.getInt(1);
                entryExists = count > 0;
            }

            return entryExists;
        }
        finally {
            MCASResourceUtil.closeDBResources(connection, ps, resultSet);
        }
    }
}
