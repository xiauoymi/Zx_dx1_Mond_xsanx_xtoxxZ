package com.monsanto.wst.ccas.exception;

/**
 * Date: Jan 4, 2010
 * Time: 11:23:37 AM
 */
public class EmailAddressRetrievalException extends Exception {

    public EmailAddressRetrievalException(String exceptionMessage) {
        super(exceptionMessage);
    }

    public EmailAddressRetrievalException(String exceptionMessage, Exception e) {
        super(exceptionMessage, e);
    }
}
