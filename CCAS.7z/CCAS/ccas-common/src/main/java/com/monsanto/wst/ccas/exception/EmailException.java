package com.monsanto.wst.ccas.exception;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Oct 6, 2009
 * Time: 3:44:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class EmailException extends Exception {

    public EmailException(String message, Throwable cause) {
        super(message, cause);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
