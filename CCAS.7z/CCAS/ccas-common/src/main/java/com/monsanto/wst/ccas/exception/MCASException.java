package com.monsanto.wst.ccas.exception;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 6, 2006
 * Time: 1:55:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class MCASException extends Exception {

    public MCASException(String errorMessage, Exception exception) {
        super(errorMessage, exception);
    }

    public MCASException(String errorMessage) {
        super(errorMessage);
    }

    public MCASException(Exception exception) {
        super(exception);
    }
}
