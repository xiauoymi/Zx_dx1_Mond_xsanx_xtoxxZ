/*
 * Created on Feb 16, 2005
 *
 *
 */
package com.monsanto.wst.ccas.exception;

import org.apache.log4j.Category;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;

import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.util.MCASResourceUtil;
import com.monsanto.wst.ccas.actions.GlobalAbomination;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class McasExceptionHandler extends ExceptionHandler {

    private static final Category logger = Category.getInstance(McasExceptionHandler.class.getName());

    public ActionForward execute(
            Exception ex,
            ExceptionConfig ae,
            ActionMapping mapping,
            ActionForm formInstance,
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException {
//		      request.setAttribute("myException",ex);
//		      request.setAttribute("myForm",formInstance);
//		      request.setAttribute("myKey",ae.getKey());

        Date errorDate = new Date(System.currentTimeMillis());

        GlobalAbomination.lastException = ex;
        ex.printStackTrace();

        String userId = null;
        User user = (User) request.getSession().getAttribute(User.USER);
        if (user != null)
            userId = user.getUser_id();

        logger.error("Application : " + McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext") + " User : " + userId);

        logger.error("Error Date : " + errorDate.getMonth() + ":" + errorDate.getDate() + ":" + errorDate.getYear() + " Error Time : " + errorDate.getHours() + ":" + errorDate.getMinutes() + ":" + errorDate.getSeconds());

        logger.error("Error Type..." + ex.getClass());

        //***Priniting the entire stack trace to logger file...
        logger.error("Detailed Error Stack Trace...");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        PrintStream stream1 = null;
        try {
            stream1 = new PrintStream(stream);
            ex.printStackTrace(stream1);
        }
        finally {
            MCASResourceUtil.closeResource(stream1);
        }
        String errorText = stream.toString();
        request.setAttribute("errorText", errorText);
        logger.error(errorText);


        return new ActionForward(ae.getPath());
    }

}
