/*
 * Created on Jun 29, 2005
 *
 *
 */
package com.monsanto.wst.ccas.exception;

import org.apache.log4j.Category;
import org.xml.sax.SAXParseException;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class XmlExceptionHandler implements org.xml.sax.ErrorHandler {

    private static final Category logger = Category.getInstance(XmlExceptionHandler.class.getName());

    public static boolean ERROR_FLAG = false;

    public static String ERROR_MSG;

    public void warning(SAXParseException ex) {
        // stop processing on warnings
        logger.warn("Xml Validating or Parsing warning.");
    }

    public void error(SAXParseException ex) {
        // stop processing on errors
        String msg = "Xml Schema Validation Error(Line: " + ex.getLineNumber() + "): " + ex.getMessage();
        logger.error(msg);
        ERROR_FLAG = true;
        ERROR_MSG = msg;
    }

    public void fatalError(SAXParseException ex) {
        // stop processing on fatal errors
        String msg = "Fatal Error while Xml Validating or Parsing.";
        logger.error(msg);
        ERROR_FLAG = true;
    }
}
