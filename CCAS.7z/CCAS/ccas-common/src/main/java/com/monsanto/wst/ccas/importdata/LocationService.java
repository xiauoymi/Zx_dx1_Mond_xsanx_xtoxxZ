/*
 LocationService was created on Apr 21, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.importdata;

import com.monsanto.wst.ccas.model.LocationInfo;

import java.util.Map;

/**
 * Filename:    $RCSfile: LocationService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface LocationService {
    void insertLocation(LocationInfo locationInfo);

    Map getDefaultLocationMap();

    Map<String, String> getRegionRelatedLocationMap(String regionId, String locale);

    Map<String, String> getRegionRelatedLocations(String regionId, int locationType, String locale);
    Map<String, String> getRegionRelatedLocationsSearch(String regionId, int locationType, String locale);
}
