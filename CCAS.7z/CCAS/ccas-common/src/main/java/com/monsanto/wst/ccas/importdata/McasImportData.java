package com.monsanto.wst.ccas.importdata;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jun 23, 2008
 * Time: 9:51:28 AM
 * To change this template use File | Settings | File Templates.
 */
public interface McasImportData {
    public void processData(String filePath, String sheetName, boolean isDelete, String locale);
}
