/*
 * Created on Apr 27, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditListObject extends ObjectWithCheckboxGroups implements Serializable {

    private String auditNumber;

    private String locationCode;

    private String auditDate;

    private String auditor;
    private String auditorEmail;

    private String preparedBy;
    private String preparedByEmail;

    private String cparNumber;

    private int cparID;

    private String region;

    private String functionId;
    private String auditOverview;
    private Map cparMap;
    private String auditId;
    private List<Cpar> cparList;
    private String toDate;
    private String program_id;
    private String auditType;
    private String issue_year;

    private String searchText;
    private String closingDate;

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    /**
     * @return Returns the region.
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return Returns the cparID.
     */
    public int getCparID() {
        return cparID;
    }

    /**
     * @param cparID The cparID to set.
     */
    public void setCparID(int cparID) {
        this.cparID = cparID;
    }

    /**
     * @return Returns the auditorEmail.
     */
    public String getAuditorEmail() {
        return auditorEmail;
    }

    /**
     * @param auditorEmail The auditorEmail to set.
     */
    public void setAuditorEmail(String auditorEmail) {
        this.auditorEmail = auditorEmail;
    }

    /**
     * @return Returns the preparedByEmail.
     */
    public String getPreparedByEmail() {
        return preparedByEmail;
    }

    /**
     * @param preparedByEmail The preparedByEmail to set.
     */
    public void setPreparedByEmail(String preparedByEmail) {
        this.preparedByEmail = preparedByEmail;
    }

    /**
     * @return Returns the auditDate.
     */
    public String getAuditDate() {
        return auditDate;
    }

    /**
     * @param auditDate The auditDate to set.
     */
    public void setAuditDate(String auditDate) {
        this.auditDate = auditDate;
    }

    /**
     * @return Returns the auditNumber.
     */
    public String getAuditNumber() {
        return auditNumber;
    }

    /**
     * @param auditNumber The auditNumber to set.
     */
    public void setAuditNumber(String auditNumber) {
        this.auditNumber = auditNumber;
    }

    /**
     * @return Returns the auditor.
     */
    public String getAuditor() {
        return auditor;
    }

    /**
     * @param auditor The auditor to set.
     */
    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    /**
     * @return Returns the cparNumber.
     */
    public String getCparNumber() {
        return cparNumber;
    }

    /**
     * @param cparNumber The cparNumber to set.
     */
    public void setCparNumber(String cparNumber) {
        this.cparNumber = cparNumber;
    }

    /**
     * @return Returns the locationCode.
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * @param locationCode The locationCode to set.
     */
    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    /**
     * @return Returns the preparedBy.
     */
    public String getPreparedBy() {
        return preparedBy;
    }

    /**
     * @param preparedBy The preparedBy to set.
     */
    public void setPreparedBy(String preparedBy) {
        this.preparedBy = preparedBy;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }


    public void setAuditOverview(String auditOverview) {
        this.auditOverview = auditOverview;
    }

    public String getAuditOverview() {
        return auditOverview;
    }

    public void setCparMap(Map cparMap) {
        this.cparMap = cparMap;
    }

    public Map getCparMap() {
        return cparMap;
    }

    public String getAuditId() {
        return auditId;
    }

    public void setAuditId(String auditId) {
        this.auditId = auditId;
    }

    public void setCparList(List<Cpar> cparList) {
        this.cparList = cparList;
    }

    public List<Cpar> getCparList() {
        return cparList;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getProgram_id() {
        return program_id;
    }

    public void setProgram_id(String program_id) {
        this.program_id = program_id;
    }

    public String getAuditType() {
        return auditType;
    }

    public void setAuditType(String auditType) {
        this.auditType = auditType;
    }

    public String getIssue_year() {
        return issue_year;
    }

    public void setIssue_year(String issue_year) {
        this.issue_year = issue_year;
    }

     public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

}
