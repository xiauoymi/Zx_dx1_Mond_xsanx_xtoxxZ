/*
 * Created on Apr 8, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;

import java.io.Serializable;
import java.util.*;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditObject extends ObjectWithCheckboxGroups implements Serializable {

    private String locationCode;
    private String functionId;

    private String auditDate;

    private String auditNumber;

    private String auditID;

    private String auditor;
    private String auditorEmail;

    public String getAuditorId() {
        return auditorId;
    }

    public void setAuditorId(String auditorId) {
        this.auditorId = auditorId;
    }

    private String auditorId;

    private String ackAndCloseFindingReason;

    public String getAckAndCloseFindingReason() {
        return ackAndCloseFindingReason;
    }

    public void setAckAndCloseFindingReason(String ackAndCloseFindingReason) {
        this.ackAndCloseFindingReason = ackAndCloseFindingReason;
    }

    private LocationOtherInfo locationOtherInfo;

    public LocationOtherInfo getLocationOtherInfo() {
        if (locationOtherInfo==null) locationOtherInfo = new LocationOtherInfo();
        return locationOtherInfo;
    }

    public void setLocationOtherInfo(LocationOtherInfo locationOtherInfo) {
        this.locationOtherInfo = locationOtherInfo;
    }

    private String siteISOContact;
    private String siteISOContactEmail;
    private String siteISOContactId;

    private boolean conditioning;
    private boolean field;
    private boolean harvest;
    private boolean packaging;

    private boolean planting;
    private boolean qaLab;
    private boolean warehouseDistribution;
    private boolean offSiteFacilities;

    private String auditOverview;

    private String preparedBy;
    private String preparedByEmail;


    public String getSiteISOContactId() {
        return siteISOContactId;
    }

    public void setSiteISOContactId(String siteISOContactId) {
        this.siteISOContactId = siteISOContactId;
    }

    public String getPreparedById() {
        return preparedById;
    }

    public void setPreparedById(String preparedById) {
        this.preparedById = preparedById;
    }

    private String preparedById;

    private String preparedDate;

    private String submitString = "1";
    private String resetString = "Reset";
    private String cancelString = "-2";


    private String region_id;

    private String rowUserID;

    private String createdBy;

    private Map<String, FindingObject> findingCarMap = new HashMap<String, FindingObject>();

    private Map<String, FindingObject> findingParMap = new HashMap<String, FindingObject>();

    public Map<String, FindingObject> getFindingCiMap() {
        return findingCiMap;
    }

    public void setFindingCiMap(Map<String, FindingObject> findingCiMap) {
        this.findingCiMap = findingCiMap;
    }

    private Map<String, FindingObject> findingCiMap = new HashMap<String, FindingObject>();


    private FindingObject editFindingObj = new FindingObject();

    private boolean findingCarMapEmpty = true;

    private boolean findingParMapEmpty = true;

    private boolean findingCiMapEmpty = true;


    private String deleted;
    private String auditFindingID;
    private String auditMembers;
    private String personsAudited;
    private String auditProcess;
    private String auditProcedure;

    private String program_id;
    private String subFunction_id;

    private String[] subFunctionsSelected;
    private String auditorOne;
    private String auditorTwo;
    private String auditType;

    private String issue_year;

    public String getCreatedBy() {
        return createdBy;
    }

    public boolean isFindingCiMapEmpty() {
        return findingCiMapEmpty;
    }

    public void setFindingCiMapEmpty(boolean findingCiMapEmpty) {
        this.findingCiMapEmpty = findingCiMapEmpty;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }


    public String getAuditorOneEmail() {
        return auditorOneEmail;
    }

    public void setAuditorOneEmail(String auditorOneEmail) {
        this.auditorOneEmail = auditorOneEmail;
    }

    public String getAuditorTwoEmail() {
        return auditorTwoEmail;
    }

    public void setAuditorTwoEmail(String auditorTwoEmail) {
        this.auditorTwoEmail = auditorTwoEmail;
    }

    private String auditorOneEmail;
    private String auditorTwoEmail;

    public String[] getSubFunctionsSelected() {
        return subFunctionsSelected;
    }

    public void setSubFunctionsSelected(String[] subFunctionsSelected) {
        this.subFunctionsSelected = subFunctionsSelected;
    }

    public String getSubFunction_id() {
        return subFunction_id;
    }

    public void setSubFunction_id(String subFunction_id) {
        this.subFunction_id = subFunction_id;
    }


    public String getProgram_id() {
        return program_id;
    }

    public void setProgram_id(String program_id) {
        this.program_id = program_id;
    }

    //private String currentTab;

    //**MCAS Enhancements...
    private Map<String, AttachmentInfo> auditAttachments = new LinkedHashMap<String, AttachmentInfo>();
    private int businessId;

    public Map<String, AttachmentInfo> getAuditAttachments() {
        return auditAttachments;
    }

    public void setAuditAttachments(Map<String, AttachmentInfo> auditAttachments) {
        this.auditAttachments = auditAttachments;
    }

    /**
     * @return Returns the currentTab.
     */
//	public String getCurrentTab() {
//		return currentTab;
//	}
    /**
     * @param currentTab The currentTab to set.
     */
//	public void setCurrentTab(String currentTab) {
//		this.currentTab = currentTab;

    //	}

    /**
     * @return Returns the editFindingObj.
     */
    public FindingObject getEditFindingObj() {
        return editFindingObj;
    }

    /**
     * @param editFindingObj The editFindingObj to set.
     */
    public void setEditFindingObj(FindingObject editFindingObj) {
        this.editFindingObj = editFindingObj;
    }

    /**
     * @return Returns the findingCarMap.
     */
    public Map<String, FindingObject> getFindingCarMap() {
        return findingCarMap;
    }

    /**
     * @param findingCarMap The findingCarMap to set.
     */
    public void setFindingCarMap(Map<String, FindingObject> findingCarMap) {
        this.findingCarMap = findingCarMap;
    }

    /**
     * @return Returns the findingParMap.
     */
    public Map<String, FindingObject> getFindingParMap() {
        return findingParMap;
    }

    /**
     * @param findingParMap The findingParMap to set.
     */
    public void setFindingParMap(Map<String, FindingObject> findingParMap) {
        this.findingParMap = findingParMap;
    }

    /**
     * @return Returns the rowUserID.
     */
    public String getRowUserID() {
        return rowUserID;
    }

    /**
     * @param rowUserID The rowUserID to set.
     */
    public void setRowUserID(String rowUserID) {
        this.rowUserID = rowUserID;
    }

    /**
     * @return Returns the region_id.
     */
    public String getRegion_id() {
        return region_id;
    }

    /**
     * @param region_id The region_id to set.
     */
    public void setRegion_id(String region_id) {
        this.region_id = region_id;
    }

    /**
     * @return Returns the preparedByEmail.
     */
    public String getPreparedByEmail() {
        return preparedByEmail;
    }

    /**
     * @param preparedByEmail The preparedByEmail to set.
     */
    public void setPreparedByEmail(String preparedByEmail) {
        this.preparedByEmail = preparedByEmail;
    }

    /**
     * @return Returns the resetString.
     */
    public String getResetString() {
        return resetString;
    }

    /**
     * @param resetString The resetString to set.
     */
    public void setResetString(String resetString) {
        this.resetString = resetString;
    }

    /**
     * @return Returns the submitString.
     */
    public String getSubmitString() {
        return submitString;
    }

    /**
     * @param submitString The submitString to set.
     */
    public void setSubmitString(String submitString) {
        this.submitString = submitString;
    }

    /**
     * @return Returns the auditNumber.
     */
    public String getAuditNumber() {
        return auditNumber;
    }

    /**
     * @param auditNumber The auditNumber to set.
     */
    public void setAuditNumber(String auditNumber) {
        this.auditNumber = auditNumber;
    }

    /**
     * @return Returns the conditioning.
     */
    public boolean isConditioning() {
        return conditioning;
    }

    /**
     * @param conditioning The conditioning to set.
     */
    public void setConditioning(boolean conditioning) {
        this.conditioning = conditioning;
    }

    /**
     * @return Returns the field.
     */
    public boolean isField() {
        return field;
    }

    /**
     * @param field The field to set.
     */
    public void setField(boolean field) {
        this.field = field;
    }

    /**
     * @return Returns the harvest.
     */
    public boolean isHarvest() {
        return harvest;
    }

    /**
     * @param harvest The harvest to set.
     */
    public void setHarvest(boolean harvest) {
        this.harvest = harvest;
    }

    /**
     * @return Returns the offSiteFacilities.
     */
    public boolean isOffSiteFacilities() {
        return offSiteFacilities;
    }

    /**
     * @param offSiteFacilities The offSiteFacilities to set.
     */
    public void setOffSiteFacilities(boolean offSiteFacilities) {
        this.offSiteFacilities = offSiteFacilities;
    }

    /**
     * @return Returns the packaging.
     */
    public boolean isPackaging() {
        return packaging;
    }

    /**
     * @param packaging The packaging to set.
     */
    public void setPackaging(boolean packaging) {
        this.packaging = packaging;
    }

    /**
     * @return Returns the planting.
     */
    public boolean isPlanting() {
        return planting;
    }

    /**
     * @param planting The planting to set.
     */
    public void setPlanting(boolean planting) {
        this.planting = planting;
    }

    /**
     * @return Returns the qaLab.
     */
    public boolean isQaLab() {
        return qaLab;
    }

    /**
     * @param qaLab The qaLab to set.
     */
    public void setQaLab(boolean qaLab) {
        this.qaLab = qaLab;
    }

    /**
     * @return Returns the warehouseDistribution.
     */
    public boolean isWarehouseDistribution() {
        return warehouseDistribution;
    }

    /**
     * @param warehouseDistribution The warehouseDistribution to set.
     */
    public void setWarehouseDistribution(boolean warehouseDistribution) {
        this.warehouseDistribution = warehouseDistribution;
    }

    /**
     * @return Returns the auditOverview.
     */
    public String getAuditOverview() {
        return auditOverview;
    }

    /**
     * @param auditOverview The auditOverview to set.
     */
    public void setAuditOverview(String auditOverview) {
        this.auditOverview = auditOverview;
    }

    /**
     * @return Returns the auditDate.
     */
    public String getAuditDate() {
        return auditDate;
    }

    /**
     * @param auditDate The auditDate to set.
     */
    public void setAuditDate(String auditDate) {
        this.auditDate = auditDate;
    }

    /**
     * @return Returns the auditor.
     */
    public String getAuditor() {
        return auditor;
    }

    /**
     * @param auditor The auditor to set.
     */
    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    /**
     * @return Returns the auditorEmail.
     */
    public String getAuditorEmail() {
        return auditorEmail;
    }

    /**
     * @param auditorEmail The auditorEmail to set.
     */
    public void setAuditorEmail(String auditorEmail) {
        this.auditorEmail = auditorEmail;
    }


    /**
     * @return Returns the preparedBy.
     */
    public String getPreparedBy() {
        return preparedBy;
    }

    /**
     * @param preparedBy The preparedBy to set.
     */
    public void setPreparedBy(String preparedBy) {
        this.preparedBy = preparedBy;
    }

    /**
     * @return Returns the preparedDate.
     */
    public String getPreparedDate() {
        return preparedDate;
    }

    /**
     * @param preparedDate The preparedDate to set.
     */
    public void setPreparedDate(String preparedDate) {
        this.preparedDate = preparedDate;
    }

    /**
     * @return Returns the locationCode.
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * @param locationCode The locationCode to set.
     */
    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    /**
     * @return Returns the siteISOContact.
     */
    public String getSiteISOContact() {
        return siteISOContact;
    }

    /**
     * @param siteISOContact The siteISOContact to set.
     */
    public void setSiteISOContact(String siteISOContact) {
        this.siteISOContact = siteISOContact;
    }

    /**
     * @return Returns the siteISOContactEmail.
     */
    public String getSiteISOContactEmail() {
        return siteISOContactEmail;
    }

    /**
     * @param siteISOContactEmail The siteISOContactEmail to set.
     */
    public void setSiteISOContactEmail(String siteISOContactEmail) {
        this.siteISOContactEmail = siteISOContactEmail;
    }

    /**
     * @return Returns the cancelString.
     */
    public String getCancelString() {
        return cancelString;
    }

    /**
     * @param cancelString The cancelString to set.
     */
    public void setCancelString(String cancelString) {
        this.cancelString = cancelString;
    }


    /**
     * @return Returns the findingCarMapEmpty.
     */
    public boolean isFindingCarMapEmpty() {
        return findingCarMapEmpty;
    }

    /**
     * @param findingCarMapEmpty The findingCarMapEmpty to set.
     */
    public void setFindingCarMapEmpty(boolean findingCarMapEmpty) {
        this.findingCarMapEmpty = findingCarMapEmpty;
    }

    /**
     * @return Returns the findingParMapEmpty.
     */
    public boolean isFindingParMapEmpty() {
        return findingParMapEmpty;
    }

    /**
     * @param findingParMapEmpty The findingParMapEmpty to set.
     */
    public void setFindingParMapEmpty(boolean findingParMapEmpty) {
        this.findingParMapEmpty = findingParMapEmpty;
    }

    /**
     * @return Returns the auditID.
     */
    public String getAuditID() {
        return auditID;
    }

    /**
     * @param auditID The auditID to set.
     */
    public void setAuditID(String auditID) {
        this.auditID = auditID;
    }

    public String getFunctionId() {
//        System.out.println("getter functionId = " + functionId);
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public void setBusinessId(int businessId) {
        this.businessId = businessId;
    }

    public int getBusinessId() {
        return businessId;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public void setAuditFindingID(String auditFindingID) {
        this.auditFindingID = auditFindingID;
    }

    public String getAuditFindingID() {
        return auditFindingID;
    }

    public void setAuditMembers(String auditMembers) {
        this.auditMembers = auditMembers;
    }

    public String getAuditMembers() {
        return auditMembers;
    }

    public void setPersonsAudited(String personsAudited) {
        this.personsAudited = personsAudited;
    }

    public String getPersonsAudited() {
        return personsAudited;
    }

    public void setAuditProcess(String auditProcess) {
        this.auditProcess = auditProcess;
    }

    public String getAuditProcess() {
        return auditProcess;
    }

    public void setAuditProcedure(String auditProcedure) {
        this.auditProcedure = auditProcedure;
    }

    public String getAuditProcedure() {
        return auditProcedure;
    }

    public void setProgramId(String programId) {
        this.program_id = programId;
    }

    public void setSubFunctionId(String subFunctionId) {
        this.subFunction_id = subFunctionId;
    }

    public String getAuditorOne() {
        return auditorOne;
    }

    public void setAuditorOne(String auditorOne) {
        this.auditorOne = auditorOne;
    }

    public String getAuditorTwo() {
        return auditorTwo;
    }

    public void setAuditorTwo(String auditorTwo) {
        this.auditorTwo = auditorTwo;
    }

    public void setAuditType(String auditType) {
        this.auditType = auditType;
    }

    public String getAuditType() {
        return auditType;
    }

    public String getIssue_year() {
        return issue_year;
    }

    public void setIssue_year(String issue_year) {
        this.issue_year = issue_year;
    }
}
