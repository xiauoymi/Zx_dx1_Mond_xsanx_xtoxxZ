/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
class Batch {
    private String batch;

    public Batch(String batchStr) {
        batch = batchStr;
    }

    /**
     * @return Returns the batch.
     */
    public String getBatch() {
        return batch;
    }

    /**
     * @param batch The batch to set.
     */
    public void setBatch(String batch) {
        this.batch = batch;
    }
}
