package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

/**
 * Date: Aug 18, 2009 Time: 1:30:57 PM
 */
public class CIType extends CparType {
  public CIType() {
  }

  public String getControlNumberPrefix() {
    return CparConstants.CI_CONTROL_NUMBER_PREFIX;
  }

  public String getLongTermReplacementString(String errorMessage, String ignore) {
    return errorMessage;
  }

  public String getDuplicateErrorMessage(String locale) {
    return I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicateCI");
  }
}
