

/*
 * Created on Jan 13, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.audits.CheckboxGroup;
import com.monsanto.wst.ccas.audits.CheckboxRow;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.service.LookUpService;
import com.monsanto.wst.ccas.service.LookUpServiceImpl;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.complaints.claims.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import org.apache.commons.collections.FactoryUtils;
import org.apache.commons.collections.list.LazyList;
import org.apache.log4j.Category;

import javax.sql.DataSource;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * @author jbrahmb <p/> . Window - Preferences - Java - Code Style - Code Templates
 */
public class Complaint extends ObjectWithCheckboxGroups implements Serializable {
    private static Category logger = Category.getInstance(Complaint.class.getName());

    private String complaint_id;
    private String claim_number;
    private String status_id;
    private String oldStatusId;
    private String sales_year_id;
    private String state_id;
    private String report_initiator;
    private String report_initiator_email;
    private String report_initiator_id;
    private String report_date;
    private String communication_date;
    private String region_id;
    private String field_communicator;
    private String field_communicator_id;
    private String reporting_location_code;
    private String responsible_plant_code;
    private String person_investigating;
    private String person_investigating_id;
    private String crop_id;
    private String quality_issue;
    private String quantity_affected;
    private String quantity_uom_id;
    private String seed_size_id;
    private String initiator_response;
    private String cpar_id;
    private List carList;
    private List parList;
    private List ciList;



    public String[] getSubFunctionsSelected() {
        return subFunctionsSelected;
    }

    public void setSubFunctionsSelected(String[] subFunctionsSelected) {
        this.subFunctionsSelected = subFunctionsSelected;
    }

    public String getCpar_id() {
        return cpar_id;
    }

    public void setCpar_id(String cpar_id) {
        this.cpar_id = cpar_id;
    }

    public String getFeedbackCategoryInfo() {
        return feedbackCategoryInfo;
    }

    public void setFeedbackCategoryInfo(String feedbackCategoryInfo) {
        this.feedbackCategoryInfo = feedbackCategoryInfo;
    }

    public String getCustomerLocationInfo() {
        return customerLocationInfo;
    }

    public void setCustomerLocationInfo(String customerLocationInfo) {
        this.customerLocationInfo = customerLocationInfo;
    }

    public String getResponsibleLocationInfo() {
        return responsibleLocationInfo;
    }

    public void setResponsibleLocationInfo(String responsibleLocationInfo) {
        this.responsibleLocationInfo = responsibleLocationInfo;
    }

    private String feedbackCategoryInfo;
    private String customerLocationInfo;
    private String responsibleLocationInfo;

    //used by Complaint JSPs to store related batch info
    //not sure why it is done here, but it is.
    private String foundBatch0;
    private String foundBatch1;
    private String foundBatch2;
    private String foundBatch3;

    private String problem_description;
    private String containment_actions;
    private String root_cause;
    private String long_term_corrective_action;
    private boolean driver_performance;
    private boolean incorrect_shipment;
    private boolean delivery_other;
    private boolean packaging_condition;
    private boolean tag_error;
    private boolean seed_appearance;
    private boolean seed_variability;
    private boolean emergence_concerns;
    private boolean product_purity;
    private boolean early_season_other;
    private boolean treatment;
    private boolean growth_development;
    private boolean pollination_problems;
    private boolean herbicide_injury;
    private boolean stress_susceptability;
    private boolean disease_development;
    private boolean midseason_other;
    private boolean insect_outbreaks_injury;
    private boolean lateseason_disease_development;
    private boolean maintaining_seed_until_harvest;
    private boolean insect_development;
    private boolean maturity_drydown;
    private boolean seed_development;
    private boolean late_season_other;
    private boolean noncompetitive_yield;
    private String delivery_info;
    private String total_acres;
    private String affected_areas;
    private String technology;
    private String population_planted;
    private String population_observed;
    private String tillage;
    private String planting_date;
    private String planter_type;
    private String planter_depth;
    private String disease_observed;
    private String herbicide_type_current;
    private String herbicide_timming_current;
    private String herbicide_rate_current;
    private String herbicide_type_prev;
    private String herbicide_timming_prev;
    private String herbicide_rate_prev;
    private String insects_observed;
    private String insecticide_type_current;
    private String insecticide_timming_current;
    private String insecticide_rate_current;
    private String insecticide_type_prev;
    private String insecticide_timming_prev;
    private String insecticide_rate_prev;
    private String grower_name;
    private String grower_address;
    private String grower_city;
    private String grower_state;
    private String grower_phone;
    private String grower_ba_id;
    private String growerLatitude;
    private String dealerLatitude;
    private String growerLongitude;
    private String dealerLongitude;
    private String dealer_name;
    private String dealer_address;
    private String dealer_city;
    private String dealer_state;
    private String dealer_phone;
    private String dealer_ba_id;
    private String created_by;
    private String row_entry_date;
    private String row_modify_date;
    private String row_task_id;
    private String row_user_id;
    private String settlement_value;
    private String affina_entry_flag;

    private String complaintBusinessId;
    private String feedbackCategoryId;
    private String issueCategoryId;
    private String lowCategoryId;
    private String complaintTypeId;
    private String functionId;

    //**MCAS Enhancements...
    private Map<String, AttachmentInfo> complaintAttachments = new LinkedHashMap<String, AttachmentInfo>();
    private String salesOfficeCode;


    private int materialGroupCode;
    private int materialGroupPricingCode;
    private String salesOrderNumber;
    private String shippingTransportNumber;
    private String sapCustomerId;
    private String invoiceNumber;
    private String customerName;
    private String customerAddress;
    private String customerPhoneNumber;
    private String customerEmail;
    private int businessId;
    private String claimAmount;
    private boolean claimAmountFinal;
    private Map nonconformanceTypeMap;
    private int initialAssesmentCode;
    private int complaintLitigationCategoryCode;

    private int program_id;
    private int subFunction_id;
    private String[] subFunctionsSelected;
    private String claimId;
    private String claimCategoryId;
    private String claimStatusType;
    private boolean environmentalClaim;
    private String invoiceDate;
    private String refugePlantedId;
    private String traitCheckId;
    private boolean complianceNearMiss;
    private String rootInjuryId;
    private String injuryRatingId;
    private String closingPersonId;
    private String closingDate;

    private List<VarietyBatch> varietyBatchList;

    private ComplaintInvestigation complaintInvestigation;

    public String getClaimStatusType() {
        return claimStatusType;
    }


    public boolean statusChanged() {
        return !(status_id != null ? status_id.equalsIgnoreCase(oldStatusId) : oldStatusId == null);
    }

    public void setClaimStatusType(String claimStatusType) {
        this.claimStatusType = claimStatusType;
    }

    public List<VarietyBatch> getVarietyBatchList() {
        if (varietyBatchList == null) {
            varietyBatchList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(VarietyBatch.class));
        }
        for (int i = varietyBatchList.size(); i < 4; i++) {
            varietyBatchList.add(new VarietyBatch());
        }
        return varietyBatchList;
    }

//  public VarietyBatch getVarietyBatchList(int index) {
//    while (index >= varietyBatchList.size()) {
    //    varietyBatchList.add(new VarietyBatch());
    // }
    //  return varietyBatchList.get(index);
    // }

    // public void setVarietyBatchList(int index, VarietyBatch object) {
    // if (index < varietyBatchList.size()) {
    //   varietyBatchList.set(index, object);
    // } else {
    //   varietyBatchList.add(object);
    // }
    // }

    public void setVarietyBatchList(List<VarietyBatch> varietyBatchList) {
        this.varietyBatchList = varietyBatchList;
    }

    public ComplaintInvestigation getComplaintInvestigation() {
        return complaintInvestigation;
    }

    public void setComplaintInvestigation(ComplaintInvestigation complaintInvestigation) {
        this.complaintInvestigation = complaintInvestigation;
    }

    public boolean isComplianceNearMiss() {
        return complianceNearMiss;
    }

    public void setComplianceNearMiss(boolean complianceNearMiss) {
        this.complianceNearMiss = complianceNearMiss;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    private String entryType;
    private Map<String, String> dispositionList;
    private int dispositionId;
    private List<Disposition> dispositionListForTeamLead;
    private int dispositionIdForTeamLead;
    private boolean teamLeadRootCauseRequired;

    public boolean isTeamLeadRootCauseRequired() {
        return teamLeadRootCauseRequired;
    }

    public void setTeamLeadRootCauseRequired(boolean teamLeadRootCauseRequired) {
        this.teamLeadRootCauseRequired = teamLeadRootCauseRequired;
    }

    public int getDispositionId() {
        return dispositionId;
    }

    public void setDispositionId(int dispositionId) {
        this.dispositionId = dispositionId;
    }

    public List<Disposition> getDispositionListForTeamLead() {
        return dispositionListForTeamLead;
    }

    public void setDispositionListForTeamLead(List<Disposition> dispositionListForTeamLead) {
        this.dispositionListForTeamLead = dispositionListForTeamLead;
    }

    public int getDispositionIdForTeamLead() {
        return dispositionIdForTeamLead;
    }

    public void setDispositionIdForTeamLead(int dispositionIdForTeamLead) {
        this.dispositionIdForTeamLead = dispositionIdForTeamLead;
    }

    public static Category getLogger() {
        return logger;
    }

    public static void setLogger(Category logger) {
        Complaint.logger = logger;
    }

    public String getProblem_person() {
        return problem_person;
    }

    public void setProblem_person(String problem_person) {
        this.problem_person = problem_person;
    }

    public String getProblem_date() {
        return problem_date;
    }

    public void setProblem_date(String problem_date) {
        this.problem_date = problem_date;
    }

    public String getContainment_person() {
        return containment_person;
    }

    public void setContainment_person(String containment_person) {
        this.containment_person = containment_person;
    }

    public String getContainment_date() {
        return containment_date;
    }

    public void setContainment_date(String containment_date) {
        this.containment_date = containment_date;
    }

    public String getRootCausePerson() {
        return rootCausePerson;
    }

    public void setRootCausePerson(String rootCausePerson) {
        this.rootCausePerson = rootCausePerson;
    }

    public String getRootCauseDate() {
        return rootCauseDate;
    }

    public void setRootCauseDate(String rootCauseDate) {
        this.rootCauseDate = rootCauseDate;
    }

    public String getLongTermPerson() {
        return longTermPerson;
    }

    public void setLongTermPerson(String longTermPerson) {
        this.longTermPerson = longTermPerson;
    }

    public String getLongTermDate() {
        return longTermDate;
    }

    public void setLongTermDate(String longTermDate) {
        this.longTermDate = longTermDate;
    }

    private String problem_person;
    private String problem_date;

    private String containment_person;
    private String containment_date;


    private String rootCausePerson;
    private String rootCauseDate;


    private String longTermPerson;
    private String longTermDate;


    public int getSubFunction_id() {
        return subFunction_id;
    }

    public void setSubFunction_id(int subFunction_id) {
        this.subFunction_id = subFunction_id;
    }

    public int getProgram_id() {
        return program_id;
    }

    public void setProgram_id(int program_id) {
        this.program_id = program_id;
    }


    private int complaintEntryTypeId;

    public int getComplaintLitigationCategoryCode() {
        return complaintLitigationCategoryCode;
    }

    public void setComplaintLitigationCategoryCode(int complaintLitigationCategoryCode) {
        this.complaintLitigationCategoryCode = complaintLitigationCategoryCode;
    }


    public int getInitialAssesmentCode() {
        return initialAssesmentCode;
    }

    public void setInitialAssesmentCode(int initialAssesmentCode) {
        this.initialAssesmentCode = initialAssesmentCode;
    }

    public Map getNonconformanceTypeMap() {
        return nonconformanceTypeMap;
    }

    public void setNonconformanceTypeMap(Map nonconformanceTypeMap) {
        this.nonconformanceTypeMap = nonconformanceTypeMap;
    }

    public int getMaterialGroupPricingCode() {
        return materialGroupPricingCode;
    }

    public void setMaterialGroupPricingCode(int materialGroupPricingCode) {
        this.materialGroupPricingCode = materialGroupPricingCode;
    }


    public Complaint() {
        initialize();
    }

    /**
     *
     */
    private void initialize() {
//TODO Delete this line after testing action logic.		
//		this.setAffina_entry_flag("N");
        //This is temporary
        this.setSettlement_value("0");
        this.complaintInvestigation = new ComplaintInvestigation();
    }

    public Map<String, AttachmentInfo> getComplaintAttachments() {
        return complaintAttachments;
    }

    public void setComplaintAttachments(Map<String, AttachmentInfo> complaintAttachments) {
        this.complaintAttachments = complaintAttachments;
    }

    public boolean isTreatment() {
        return treatment;
    }

    public void setTreatment(boolean treatment) {
        this.treatment = treatment;
    }

    /**
     * @return Returns the containment_actions.
     */
    public String getContainment_actions() {
        return containment_actions;
    }

    /**
     * @param containment_actions The containment_actions to set.
     */
    public void setContainment_actions(String containment_actions) {
        this.containment_actions = containment_actions;
    }

    /**
     * @return Returns the long_term_corrective_action.
     */
    public String getLong_term_corrective_action() {
        return long_term_corrective_action;
    }

    /**
     * @param long_term_corrective_action The long_term_corrective_action to set.
     */
    public void setLong_term_corrective_action(
            String long_term_corrective_action) {
        this.long_term_corrective_action = long_term_corrective_action;
    }

    /**
     * @return Returns the problem_description.
     */
    public String getProblem_description() {
        return problem_description;
    }

    /**
     * @param problem_description The problem_description to set.
     */
    public void setProblem_description(String problem_description) {
        this.problem_description = problem_description;
    }

    /**
     * @return Returns the root_cause.
     */
    public String getRoot_cause() {
        return root_cause;
    }

    /**
     * @param root_cause The root_cause to set.
     */
    public void setRoot_cause(String root_cause) {
        this.root_cause = root_cause;
    }


    /**
     * @return Returns the claim_number.
     */
    public String getClaim_number() {
        return claim_number;
    }

    /**
     * @param claim_number The claim_number to set.
     */
    public void setClaim_number(String claim_number) {
        this.claim_number = claim_number;
    }

    /**
     * @return Returns the communication_date.
     */
    public String getCommunication_date() {
        return communication_date;
    }

    /**
     * @param communication_date The communication_date to set.
     */
    public void setCommunication_date(String communication_date) {
        this.communication_date = communication_date;
    }

    /**
     * @return Returns the complaint_id.
     */
    public String getComplaint_id() {
        return complaint_id;
    }

    /**
     * @param complaint_id The complaint_id to set.
     */
    public void setComplaint_id(String complaint_id) {
        this.complaint_id = complaint_id;
    }

    /**
     * @return Returns the crop_id.
     */
    public String getCrop_id() {
        return crop_id;
    }

    /**
     * @param crop_id The crop_id to set.
     */
    public void setCrop_id(String crop_id) {
        this.crop_id = crop_id;
    }

    /**
     * @return Returns the delivery_info.
     */
    public String getDelivery_info() {
        return delivery_info;
    }

    /**
     * @param delivery_info The delivery_info to set.
     */
    public void setDelivery_info(String delivery_info) {
        this.delivery_info = delivery_info;
    }

    /**
     * @return Returns the field_communicator.
     */
    public String getField_communicator() {
        return field_communicator;
    }

    /**
     * @param field_communicator The field_communicator to set.
     */
    public void setField_communicator(String field_communicator) {
        this.field_communicator = field_communicator;
    }

    /**
     * @return Returns the person_investigating.
     */
    public String getPerson_investigating() {
        return person_investigating;
    }

    /**
     * @param person_investigating The person_investigating to set.
     */
    public void setPerson_investigating(String person_investigating) {
        this.person_investigating = person_investigating;
    }

    /**
     * @return Returns the quality_issue.
     */
    public String getQuality_issue() {
        return quality_issue;
    }

    /**
     * @param quality_issue The quality_issue to set.
     */
    public void setQuality_issue(String quality_issue) {
        this.quality_issue = quality_issue;
    }

    /**
     * @return Returns the quantity_affected.
     */
    public String getQuantity_affected() {
        return quantity_affected;
    }

    /**
     * @param quantity_affected The quantity_affected to set.
     */
    public void setQuantity_affected(String quantity_affected) {
        this.quantity_affected = quantity_affected;
    }

    /**
     * @return Returns the quantity_uom_id.
     */
    public String getQuantity_uom_id() {
        return quantity_uom_id;
    }

    /**
     * @param quantity_uom_id The quantity_uom_id to set.
     */
    public void setQuantity_uom_id(String quantity_uom_id) {
        this.quantity_uom_id = quantity_uom_id;
    }

    /**
     * @return Returns the report_date.
     */
    public String getReport_date() {
        return report_date;
    }

    /**
     * @param report_date The report_date to set.
     */
    public void setReport_date(String report_date) {
        this.report_date = report_date;
    }

    /**
     * @return Returns the report_initiator.
     */
    public String getReport_initiator() {
        return report_initiator;
    }

    /**
     * @param report_initiator The report_initiator to set.
     */
    public void setReport_initiator(String report_initiator) {
        this.report_initiator = report_initiator;
    }

    /**
     * @return Returns the reporting_location_code.
     */
    public String getReporting_location_code() {
        return reporting_location_code;
    }

    /**
     * @param reporting_location_code The reporting_location_code to set.
     */
    public void setReporting_location_code(String reporting_location_code) {
        this.reporting_location_code = reporting_location_code;
    }

    /**
     * @return Returns the responsible_plant_code.
     */
    public String getResponsible_plant_code() {
        return responsible_plant_code;
    }

    /**
     * @param responsible_plant_code The responsible_plant_code to set.
     */
    public void setResponsible_plant_code(String responsible_plant_code) {
        this.responsible_plant_code = responsible_plant_code;
    }

    /**
     * @return Returns the row_entry_date.
     */
    public String getRow_entry_date() {
        return row_entry_date;
    }

    /**
     * @param row_entry_date The row_entry_date to set.
     */
    public void setRow_entry_date(String row_entry_date) {
        this.row_entry_date = row_entry_date;
    }

    /**
     * @return Returns the row_modify_date.
     */
    public String getRow_modify_date() {
        return row_modify_date;
    }

    /**
     * @param row_modify_date The row_modify_date to set.
     */
    public void setRow_modify_date(String row_modify_date) {
        this.row_modify_date = row_modify_date;
    }

    /**
     * @return Returns the row_task_id.
     */
    public String getRow_task_id() {
        return row_task_id;
    }

    /**
     * @param row_task_id The row_task_id to set.
     */
    public void setRow_task_id(String row_task_id) {
        this.row_task_id = row_task_id;
    }

    /**
     * @return Returns the row_user_id.
     */
    public String getRow_user_id() {
        return row_user_id;
    }

    /**
     * @param row_user_id The row_user_id to set.
     */
    public void setRow_user_id(String row_user_id) {
        this.row_user_id = row_user_id;
    }

    /**
     * @return Returns the sales_year_id.
     */
    public String getSales_year_id() {
        return sales_year_id;
    }

    /**
     * @param sales_year_id The sales_year_id to set.
     */
    public void setSales_year_id(String sales_year_id) {
        this.sales_year_id = sales_year_id;
    }

    /**
     * @return Returns the seed_size_id.
     */
    public String getSeed_size_id() {
        return seed_size_id;
    }

    /**
     * @param seed_size_id The seed_size_id to set.
     */
    public void setSeed_size_id(String seed_size_id) {
        this.seed_size_id = seed_size_id;
    }

    /**
     * @return Returns the state_id.
     */
    public String getState_id() {
        return state_id;
    }

    /**
     * @param state_id The state_id to set.
     */
    public void setState_id(String state_id) {
        this.state_id = state_id;
    }

    /**
     * @return Returns the status_id.
     */
    public String getStatus_id() {
        return status_id;
    }


    public boolean isClosed() {
        return status_id != null && status_id.startsWith("1");
    }


    /**
     * @param status_id The status_id to set.
     */
    public void setStatus_id(String status_id) {
        this.status_id = status_id;
    }


//	/**
//	 * @return Returns the varity_list.
//	 */
//	public Map getVarity_list() {
//		return varity_list;
//	}
//	/**
//	 * @param varity_list The varity_list to set.
//	 */
//	public void setVarity_list(Map varity_list) {
//		this.varity_list = varity_list;
//	}
//
//	
//	/**
//	 * @return Returns the batch_list.
//	 */
//	public List getBatch_list() {
//		return batch_list;
//	}
//	/**
//	 * @param batch_list The batch_list to set.
//	 */
//	public void setBatch_list(List batch_list) {
//		this.batch_list = batch_list;
//	}


    /**
     * @return Returns the affected_areas.
     */
    public String getAffected_areas() {
        return affected_areas;
    }

    /**
     * @param affected_areas The affected_areas to set.
     */
    public void setAffected_areas(String affected_areas) {
        this.affected_areas = affected_areas;
    }

    /**
     * @return Returns the dealer_address.
     */
    public String getDealer_address() {
        return dealer_address;
    }

    /**
     * @param dealer_address The dealer_address to set.
     */
    public void setDealer_address(String dealer_address) {
        this.dealer_address = dealer_address;
    }

    /**
     * @return Returns the dealer_ba_id.
     */
    public String getDealer_ba_id() {
        return dealer_ba_id;
    }

    /**
     * @param dealer_ba_id The dealer_ba_id to set.
     */
    public void setDealer_ba_id(String dealer_ba_id) {
        this.dealer_ba_id = dealer_ba_id;
    }

    /**
     * @return Returns the dealer_city.
     */
    public String getDealer_city() {
        return dealer_city;
    }

    /**
     * @param dealer_city The dealer_city to set.
     */
    public void setDealer_city(String dealer_city) {
        this.dealer_city = dealer_city;
    }

    /**
     * @return Returns the dealer_name.
     */
    public String getDealer_name() {
        return dealer_name;
    }

    /**
     * @param dealer_name The dealer_name to set.
     */
    public void setDealer_name(String dealer_name) {
        this.dealer_name = dealer_name;
    }

    /**
     * @return Returns the dealer_phone.
     */
    public String getDealer_phone() {
        if (dealer_phone != null && dealer_phone.startsWith("+")) {
            if (dealer_phone.equals("+")) {
                return dealer_phone;
            }
            return dealer_phone.substring(1);
        }
        return dealer_phone;
    }

    /**
     * @param dealer_phone The dealer_phone to set.
     */
    public void setDealer_phone(String dealer_phone) {
        this.dealer_phone = dealer_phone;
    }

    /**
     * @return Returns the dealer_state.
     */
    public String getDealer_state() {
        return dealer_state;
    }

    /**
     * @param dealer_state The dealer_state to set.
     */
    public void setDealer_state(String dealer_state) {
        this.dealer_state = dealer_state;
    }

    /**
     * @return Returns the delivery_other.
     */
    public boolean isDelivery_other() {
        return delivery_other;
    }

    /**
     * @param delivery_other The delivery_other to set.
     */
    public void setDelivery_other(boolean delivery_other) {
        this.delivery_other = delivery_other;
    }

    /**
     * @return Returns the driver_performance.
     */
    public boolean isDriver_performance() {
        return driver_performance;
    }

    /**
     * @param driver_performance The driver_performance to set.
     */
    public void setDriver_performance(boolean driver_performance) {
        this.driver_performance = driver_performance;
    }

    /**
     * @return Returns the disease_development.
     */
    public boolean isDisease_development() {
        return disease_development;
    }

    /**
     * @param disease_development The disease_development to set.
     */
    public void setDisease_development(boolean disease_development) {
        this.disease_development = disease_development;
    }

    /**
     * @return Returns the disease_observed.
     */
    public String getDisease_observed() {
        return disease_observed;
    }

    /**
     * @param disease_observed The disease_observed to set.
     */
    public void setDisease_observed(String disease_observed) {
        this.disease_observed = disease_observed;
    }

    /**
     * @return Returns the early_season_other.
     */
    public boolean isEarly_season_other() {
        return early_season_other;
    }

    /**
     * @param early_season_other The early_season_other to set.
     */
    public void setEarly_season_other(boolean early_season_other) {
        this.early_season_other = early_season_other;
    }

    /**
     * @return Returns the emergence_concerns.
     */
    public boolean isEmergence_concerns() {
        return emergence_concerns;
    }

    /**
     * @param emergence_concerns The emergence_concerns to set.
     */
    public void setEmergence_concerns(boolean emergence_concerns) {
        this.emergence_concerns = emergence_concerns;
    }

    /**
     * @return Returns the grower_address.
     */
    public String getGrower_address() {
        return grower_address;
    }

    /**
     * @param grower_address The grower_address to set.
     */
    public void setGrower_address(String grower_address) {
        this.grower_address = grower_address;
    }

    /**
     * @return Returns the grower_ba_id.
     */
    public String getGrower_ba_id() {
        return grower_ba_id;
    }

    /**
     * @param grower_ba_id The grower_ba_id to set.
     */
    public void setGrower_ba_id(String grower_ba_id) {
        this.grower_ba_id = grower_ba_id;
    }

    /**
     * @return Returns the grower_city.
     */
    public String getGrower_city() {
        return grower_city;
    }

    /**
     * @param grower_city The grower_city to set.
     */
    public void setGrower_city(String grower_city) {
        this.grower_city = grower_city;
    }

    /**
     * @return Returns the grower_name.
     */
    public String getGrower_name() {
        return grower_name;
    }

    /**
     * @param grower_name The grower_name to set.
     */
    public void setGrower_name(String grower_name) {
        this.grower_name = grower_name;
    }

    /**
     * @return Returns the grower_phone.
     */
    public String getGrower_phone() {
        if (grower_phone != null && grower_phone.startsWith("+")) {
            if (grower_phone.equalsIgnoreCase("+")) {
                return grower_phone;
            } else {
                return grower_phone.substring(1);
            }
        }
        return grower_phone;
    }

    /**
     * @param grower_phone The grower_phone to set.
     */
    public void setGrower_phone(String grower_phone) {
        this.grower_phone = grower_phone;
    }

    /**
     * @return Returns the grower_state.
     */
    public String getGrower_state() {
        return grower_state;
    }

    /**
     * @param grower_state The grower_state to set.
     */
    public void setGrower_state(String grower_state) {
        this.grower_state = grower_state;
    }

    /**
     * @return Returns the growth_development.
     */
    public boolean isGrowth_development() {
        return growth_development;
    }

    /**
     * @param growth_development The growth_development to set.
     */
    public void setGrowth_development(boolean growth_development) {
        this.growth_development = growth_development;
    }

    /**
     * @return Returns the herbicide_injury.
     */
    public boolean isHerbicide_injury() {
        return herbicide_injury;
    }

    /**
     * @param herbicide_injury The herbicide_injury to set.
     */
    public void setHerbicide_injury(boolean herbicide_injury) {
        this.herbicide_injury = herbicide_injury;
    }

    /**
     * @return Returns the herbicide_rate_current.
     */
    public String getHerbicide_rate_current() {
        return herbicide_rate_current;
    }

    /**
     * @param herbicide_rate_current The herbicide_rate_current to set.
     */
    public void setHerbicide_rate_current(String herbicide_rate_current) {
        this.herbicide_rate_current = herbicide_rate_current;
    }

    /**
     * @return Returns the herbicide_rate_prev.
     */
    public String getHerbicide_rate_prev() {
        return herbicide_rate_prev;
    }

    /**
     * @param herbicide_rate_prev The herbicide_rate_prev to set.
     */
    public void setHerbicide_rate_prev(String herbicide_rate_prev) {
        this.herbicide_rate_prev = herbicide_rate_prev;
    }

    /**
     * @return Returns the herbicide_timming_current.
     */
    public String getHerbicide_timming_current() {
        return herbicide_timming_current;
    }

    /**
     * @param herbicide_timming_current The herbicide_timming_current to set.
     */
    public void setHerbicide_timming_current(String herbicide_timming_current) {
        this.herbicide_timming_current = herbicide_timming_current;
    }

    /**
     * @return Returns the herbicide_timming_prev.
     */
    public String getHerbicide_timming_prev() {
        return herbicide_timming_prev;
    }

    /**
     * @param herbicide_timming_prev The herbicide_timming_prev to set.
     */
    public void setHerbicide_timming_prev(String herbicide_timming_prev) {
        this.herbicide_timming_prev = herbicide_timming_prev;
    }

    /**
     * @return Returns the herbicide_type_current.
     */
    public String getHerbicide_type_current() {
        return herbicide_type_current;
    }

    /**
     * @param herbicide_type_current The herbicide_type_current to set.
     */
    public void setHerbicide_type_current(String herbicide_type_current) {
        this.herbicide_type_current = herbicide_type_current;
    }

    /**
     * @return Returns the herbicide_type_prev.
     */
    public String getHerbicide_type_prev() {
        return herbicide_type_prev;
    }

    /**
     * @param herbicide_type_prev The herbicide_type_prev to set.
     */
    public void setHerbicide_type_prev(String herbicide_type_prev) {
        this.herbicide_type_prev = herbicide_type_prev;
    }

    /**
     * @return Returns the incorrect_shipment.
     */
    public boolean isIncorrect_shipment() {
        return incorrect_shipment;
    }

    /**
     * @param incorrect_shipment The incorrect_shipment to set.
     */
    public void setIncorrect_shipment(boolean incorrect_shipment) {
        this.incorrect_shipment = incorrect_shipment;
    }

    /**
     * @return Returns the insect_development.
     */
    public boolean isInsect_development() {
        return insect_development;
    }

    /**
     * @param insect_development The insect_development to set.
     */
    public void setInsect_development(boolean insect_development) {
        this.insect_development = insect_development;
    }

    /**
     * @return Returns the insect_outbreaks_injury.
     */
    public boolean isInsect_outbreaks_injury() {
        return insect_outbreaks_injury;
    }

    /**
     * @param insect_outbreaks_injury The insect_outbreaks_injury to set.
     */
    public void setInsect_outbreaks_injury(boolean insect_outbreaks_injury) {
        this.insect_outbreaks_injury = insect_outbreaks_injury;
    }

    /**
     * @return Returns the insecticide_rate_current.
     */
    public String getInsecticide_rate_current() {
        return insecticide_rate_current;
    }

    /**
     * @param insecticide_rate_current The insecticide_rate_current to set.
     */
    public void setInsecticide_rate_current(String insecticide_rate_current) {
        this.insecticide_rate_current = insecticide_rate_current;
    }

    /**
     * @return Returns the insecticide_rate_prev.
     */
    public String getInsecticide_rate_prev() {
        return insecticide_rate_prev;
    }

    /**
     * @param insecticide_rate_prev The insecticide_rate_prev to set.
     */
    public void setInsecticide_rate_prev(String insecticide_rate_prev) {
        this.insecticide_rate_prev = insecticide_rate_prev;
    }

    /**
     * @return Returns the insecticide_timming_current.
     */
    public String getInsecticide_timming_current() {
        return insecticide_timming_current;
    }

    /**
     * @param insecticide_timming_current The insecticide_timming_current to set.
     */
    public void setInsecticide_timming_current(
            String insecticide_timming_current) {
        this.insecticide_timming_current = insecticide_timming_current;
    }

    /**
     * @return Returns the insecticide_timming_prev.
     */
    public String getInsecticide_timming_prev() {
        return insecticide_timming_prev;
    }

    /**
     * @param insecticide_timming_prev The insecticide_timming_prev to set.
     */
    public void setInsecticide_timming_prev(String insecticide_timming_prev) {
        this.insecticide_timming_prev = insecticide_timming_prev;
    }

    /**
     * @return Returns the insecticide_type_current.
     */
    public String getInsecticide_type_current() {
        return insecticide_type_current;
    }

    /**
     * @param insecticide_type_current The insecticide_type_current to set.
     */
    public void setInsecticide_type_current(String insecticide_type_current) {
        this.insecticide_type_current = insecticide_type_current;
    }

    /**
     * @return Returns the insecticide_type_prev.
     */
    public String getInsecticide_type_prev() {
        return insecticide_type_prev;
    }

    /**
     * @param insecticide_type_prev The insecticide_type_prev to set.
     */
    public void setInsecticide_type_prev(String insecticide_type_prev) {
        this.insecticide_type_prev = insecticide_type_prev;
    }

    /**
     * @return Returns the insects_observed.
     */
    public String getInsects_observed() {
        return insects_observed;
    }

    /**
     * @param insects_observed The insects_observed to set.
     */
    public void setInsects_observed(String insects_observed) {
        this.insects_observed = insects_observed;
    }

    /**
     * @return Returns the late_season_other.
     */
    public boolean isLate_season_other() {
        return late_season_other;
    }

    /**
     * @param late_season_other The late_season_other to set.
     */
    public void setLate_season_other(boolean late_season_other) {
        this.late_season_other = late_season_other;
    }

    /**
     * @return Returns the lateseason_disease_development.
     */
    public boolean isLateseason_disease_development() {
        return lateseason_disease_development;
    }

    /**
     * @param lateseason_disease_development The lateseason_disease_development to set.
     */
    public void setLateseason_disease_development(
            boolean lateseason_disease_development) {
        this.lateseason_disease_development = lateseason_disease_development;
    }

    /**
     * @return Returns the maintaining_seed_until_harvest.
     */
    public boolean isMaintaining_seed_until_harvest() {
        return maintaining_seed_until_harvest;
    }

    /**
     * @param maintaining_seed_until_harvest The maintaining_seed_until_harvest to set.
     */
    public void setMaintaining_seed_until_harvest(
            boolean maintaining_seed_until_harvest) {
        this.maintaining_seed_until_harvest = maintaining_seed_until_harvest;
    }

    /**
     * @return Returns the maturity_drydown.
     */
    public boolean isMaturity_drydown() {
        return maturity_drydown;
    }

    /**
     * @param maturity_drydown The maturity_drydown to set.
     */
    public void setMaturity_drydown(boolean maturity_drydown) {
        this.maturity_drydown = maturity_drydown;
    }

    /**
     * @return Returns the midseason_other.
     */
    public boolean isMidseason_other() {
        return midseason_other;
    }

    /**
     * @param midseason_other The midseason_other to set.
     */
    public void setMidseason_other(boolean midseason_other) {
        this.midseason_other = midseason_other;
    }

    /**
     * @return Returns the noncompetitive_yield.
     */
    public boolean isNoncompetitive_yield() {
        return noncompetitive_yield;
    }

    /**
     * @param noncompetitive_yield The noncompetitive_yield to set.
     */
    public void setNoncompetitive_yield(boolean noncompetitive_yield) {
        this.noncompetitive_yield = noncompetitive_yield;
    }

    /**
     * @return Returns the packaging_condition.
     */
    public boolean isPackaging_condition() {
        return packaging_condition;
    }

    /**
     * @param packaging_condition The packaging_condition to set.
     */
    public void setPackaging_condition(boolean packaging_condition) {
        this.packaging_condition = packaging_condition;
    }

    /**
     * @return Returns the planter_depth.
     */
    public String getPlanter_depth() {
        return planter_depth;
    }

    /**
     * @param planter_depth The planter_depth to set.
     */
    public void setPlanter_depth(String planter_depth) {
        this.planter_depth = planter_depth;
    }

    /**
     * @return Returns the planter_type.
     */
    public String getPlanter_type() {
        return planter_type;
    }

    /**
     * @param planter_type The planter_type to set.
     */
    public void setPlanter_type(String planter_type) {
        this.planter_type = planter_type;
    }

    /**
     * @return Returns the planting_date.
     */
    public String getPlanting_date() {
        return planting_date;
    }

    /**
     * @param planting_date The planting_date to set.
     */
    public void setPlanting_date(String planting_date) {
        this.planting_date = planting_date;
    }

    /**
     * @return Returns the pollination_problems.
     */
    public boolean isPollination_problems() {
        return pollination_problems;
    }

    /**
     * @param pollination_problems The pollination_problems to set.
     */
    public void setPollination_problems(boolean pollination_problems) {
        this.pollination_problems = pollination_problems;
    }

    /**
     * @return Returns the population_observed.
     */
    public String getPopulation_observed() {
        return population_observed;
    }

    /**
     * @param population_observed The population_observed to set.
     */
    public void setPopulation_observed(String population_observed) {
        this.population_observed = population_observed;
    }

    /**
     * @return Returns the population_planted.
     */
    public String getPopulation_planted() {
        return population_planted;
    }

    /**
     * @param population_planted The population_planted to set.
     */
    public void setPopulation_planted(String population_planted) {
        this.population_planted = population_planted;
    }

    /**
     * @return Returns the product_purity.
     */
    public boolean isProduct_purity() {
        return product_purity;
    }

    /**
     * @param product_purity The product_purity to set.
     */
    public void setProduct_purity(boolean product_purity) {
        this.product_purity = product_purity;
    }

    /**
     * @return Returns the seed_appearance.
     */
    public boolean isSeed_appearance() {
        return seed_appearance;
    }

    /**
     * @param seed_appearance The seed_appearance to set.
     */
    public void setSeed_appearance(boolean seed_appearance) {
        this.seed_appearance = seed_appearance;
    }

    /**
     * @return Returns the seed_development.
     */
    public boolean isSeed_development() {
        return seed_development;
    }

    /**
     * @param seed_development The seed_development to set.
     */
    public void setSeed_development(boolean seed_development) {
        this.seed_development = seed_development;
    }

    /**
     * @return Returns the seed_variability.
     */
    public boolean isSeed_variability() {
        return seed_variability;
    }

    /**
     * @param seed_variability The seed_variability to set.
     */
    public void setSeed_variability(boolean seed_variability) {
        this.seed_variability = seed_variability;
    }

    /**
     * @return Returns the stress_susceptability.
     */
    public boolean isStress_susceptability() {
        return stress_susceptability;
    }

    /**
     * @param stress_susceptability The stress_susceptability to set.
     */
    public void setStress_susceptability(boolean stress_susceptability) {
        this.stress_susceptability = stress_susceptability;
    }

    /**
     * @return Returns the tag_error.
     */
    public boolean isTag_error() {
        return tag_error;
    }

    /**
     * @param tag_error The tag_error to set.
     */
    public void setTag_error(boolean tag_error) {
        this.tag_error = tag_error;
    }

    /**
     * @return Returns the technology.
     */
    public String getTechnology() {
        return technology;
    }

    /**
     * @param technology The technology to set.
     */
    public void setTechnology(String technology) {
        this.technology = technology;
    }

    /**
     * @return Returns the tillage.
     */
    public String getTillage() {
        return tillage;
    }

    /**
     * @param tillage The tillage to set.
     */
    public void setTillage(String tillage) {
        this.tillage = tillage;
    }

    /**
     * @return Returns the total_acres.
     */
    public String getTotal_acres() {
        return total_acres;
    }

    /**
     * @param total_acres The total_acres to set.
     */
    public void setTotal_acres(String total_acres) {
        this.total_acres = total_acres;
    }

    /**
     * @return Returns the created_by.
     */
    public String getCreated_by() {
        return created_by;
    }

    /**
     * @param created_by The created_by to set.
     */
    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    /**
     * @return Returns the region_id.
     */
    public String getRegion_id() {
        return region_id;
    }


    public boolean isANorthAmericanComplaint() {
        return "1".equalsIgnoreCase(region_id);
    }

    /**
     * @param region_id The region_id to set.
     */
    public void setRegion_id(String region_id) {
        this.region_id = region_id;
    }

    /**
     * @return Returns the affina_entry_flag.
     */
    public String getAffina_entry_flag() {
        return affina_entry_flag;
    }

    /**
     * @param affina_entry_flag The affina_entry_flag to set.
     */
    public void setAffina_entry_flag(String affina_entry_flag) {
        this.affina_entry_flag = affina_entry_flag;
    }

    /**
     * @return Returns the settlement_value.
     */
    public String getSettlement_value() {
        return settlement_value;
    }

    /**
     * @param settlement_value The settlement_value to set.
     */
    public void setSettlement_value(String settlement_value) {
        this.settlement_value = settlement_value;
    }

    /**
     * @return Returns the foundBatch4.
     */
    public String getFoundBatch0() {
        return foundBatch0;
    }

    /**
     * @param foundBatch0 The foundBatch4 to set.
     */
    public void setFoundBatch0(String foundBatch0) {
        this.foundBatch0 = foundBatch0;
    }

    /**
     * @return Returns the foundBatch1.
     */
    public String getFoundBatch1() {
        return foundBatch1;
    }

    /**
     * @param foundBatch1 The foundBatch1 to set.
     */
    public void setFoundBatch1(String foundBatch1) {
        this.foundBatch1 = foundBatch1;
    }

    /**
     * @return Returns the foundBatch2.
     */
    public String getFoundBatch2() {
        return foundBatch2;
    }

    /**
     * @param foundBatch2 The foundBatch2 to set.
     */
    public void setFoundBatch2(String foundBatch2) {
        this.foundBatch2 = foundBatch2;
    }

    /**
     * @return Returns the foundBatch3.
     */
    public String getFoundBatch3() {
        return foundBatch3;
    }

    /**
     * @param foundBatch3 The foundBatch3 to set.
     */
    public void setFoundBatch3(String foundBatch3) {
        this.foundBatch3 = foundBatch3;
    }

    /**
     * @return Returns the report_initiator_email.
     */
    public String getReport_initiator_email() {
        return report_initiator_email;
    }

    /**
     * @param report_initiator_email The report_initiator_email to set.
     */
    public void setReport_initiator_email(String report_initiator_email) {
        this.report_initiator_email = report_initiator_email;
    }

    public String getFeedbackCategoryId() {
        return feedbackCategoryId;
    }

    public void setFeedbackCategoryId(String feedbackCategoryId) {
        this.feedbackCategoryId = feedbackCategoryId;
    }

    public String getComplaintTypeId() {
        return complaintTypeId;
    }

    public void setComplaintTypeId(String complaintTypeId) {
        this.complaintTypeId = complaintTypeId;
    }

    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public void setSalesOfficeCode(String salesOffice) {
        this.salesOfficeCode = salesOffice;
    }

    public String getSalesOfficeCode() {
        return salesOfficeCode;
    }

    public int getMaterialGroupCode() {
        return materialGroupCode;
    }

    public void setMaterialGroupCode(int materialGroupCode) {
        this.materialGroupCode = materialGroupCode;
    }

    public String toHtml() {

        LookUpService lookup = new LookUpServiceImpl();

        return " <html><head>\n" +
                "<style type='text/css'>\n" +
                "<!-- body \n" +
                " {  margin: 5px;  font: 100% verdana, arial, sans-serif;} \n" +
                "body#left_nav{  margin: 0px;  padding: 0px;  background-color: #CCCCCC;}\n" +
                "body#complaint{  margin-top: 0px;  padding: 0px;  font: 100% verdana, arial, sans-serif; }\n" +
                "body#admin{  margin-top: 0px;  padding: 0px;  font: 100% verdana, arial, sans-serif; }\n" +
                "body#header{  margin: 0px;  padding: 0px;  background-color: #003366; }\n" +
                "div#header_sub{  margin: 0px;  padding: 0px;  background-color: #CCCCCC;  width: 100%; }\n" +
                "body#top_btn{  margin: 0px;  padding: 0px;  background-color: #FFFFFF; }\n" +
                "body#ftr_bkgd{  margin: 0px;  padding: 0px;  background-color: #003366; }\n" +
                "table{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                "hr{  height: 1px;  color: #CCCCCC;  clear: both;}br{  line-height: 11px; }\n" +
                "div{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                ".pg_width{  width: 100%; }\n" +
                "input{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                "select{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                "textarea{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                "a:link{  color: #000000;  text-decoration: underline; }\n" +
                "a:visited{  color: #000000;  text-decoration: underline; }\n" +
                "a:hover{  color: #000000;  text-decoration: none; }\n" +
                "ul#tabnav {  font: 11px arial, sans-serif;  list-style-type: none;  padding-bottom: 19px;  border-bottom: 1px solid #999999;  margin: 0px; }\n" +
                "ul#tabnav li {  float: left;  height: 16px;  background-color: #EAEAEA;  margin: 0px 2px 0px 2px;  border: 1px solid #999999; }\n" +
                "div#audit_01 li#tab_on, div#audit_02 li#tab_on, div#audit_03 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#comp_01 li#tab_on, div#comp_02 li#tab_on, div#comp_03 li#tab_on, div#comp_04 li#tab_on, div#comp_05 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#comp1_01 li#tab_on, div#comp1_02 li#tab_on, div#comp1_03 li#tab_on, div#comp1_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#cpar_01 li#tab_on, div#cpar_02 li#tab_on, div#cpar_03 li#tab_on, div#cpar_04 li#tab_on, div#cpar_05 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF;}div#comp2_01 li#tab_on, div#comp2_02 li#tab_on, div#comp2_03 li#tab_on, div#comp2_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#stop_01 li#tab_on, div#stop_02 li#tab_on, div#stop_03 li#tab_on, div#stop_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#stop1_01 li#tab_on, div#stop1_02 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#car_01 li#tab_on, div#car_02 li#tab_on, div#car_03 li#tab_on, div#car_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "div#par_01 li#tab_on, div#par_02 li#tab_on, div#par_03 li#tab_on, div#par_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                "#tabnav a, #tabnav2 a, #tabnav3 a {  float: left;  display: block;  color: #000000;  text-decoration: none;  padding: 2px 4px 2px 4px; }\n" +
                "#tabnav a:hover, #tabnav2 a:hover, #tabnav3 a:hover {  background: #CCCCCC; }\n" +
                ".report_table{  overflow: scroll }\n" +
                ".comments_cell{  border-bottom: 1px solid #999999;  border-left: 1px solid #999999;  border-right: 1px solid #999999;  padding: 8px;  background-color: #F2F8FF; }\n" +
                ".rgt_align{  text-align: right;  padding-left: 1px; }\n" +
                ".form_head{  text-align: center;  font-weight: bold;  padding-bottom: 10px; }\n" +
                ".form_align{  padding-left: 4px;  padding-right: 10px;  padding-top: 1px;  padding-bottom: 1px; }\n" +
                "#seed_info{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 700px; }\n" +
                "#error_info{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 700px; }\n" +
                "#error_info_for_popup{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 350px; }\n" +
                "#brand{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 205px;  float: left;  background-color: #F2F8FF;/*overflow: scroll;*/  height: 100px; }\n" +
                "#batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 350px;  /*width: 555px;*/  float: left;  background-color: #F2F8FF;  overflow: scroll;  height: 100px; }\n" +
                "#complaint_batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                "#complaint_affina{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                "#stopsale_batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                "#findings{  border: 1px solid #999999;  margin-left: 2px;  padding: 5px;  width: 650px;  float: left;  background-color: #FFFFFF;  overflow: scroll;  height: 100px; }\n" +
                "#attach_file_div{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 700px;  background-color: #F2F8FF;  clear: both; }\n" +
                "#button{  float: left;  padding-left: 5px; }\n" +
                ".tbl_pad{  padding-left: 3px;  padding-right: 3px; }\n" +
                ".div_pad{  width: 100%;  padding-left: 3px;  padding-right: 3px; }\n" +
                "#gen_info{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 700px;  background-color: #FBE7BE;  clear: both; }\n" +
                "#add_edit_user_div{  border: 1px solid #CCCCCC;  margin: 3px;  padding: 5px;  width: 300px;  background-color: #FBE7BE;  clear: both; }\n" +
                "#add_attachment_div{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 350px;  background-color: #FBE7BE;  clear: both; }\n" +
                "h1{  font-size: 14px;  margin: 0px;  color: #003366; }\n" +
                "h2{  font-size: 10px;  margin: 0px;  color: #003366; }\n" +
                ".hdr_rule{  background-color: #003366;  height: 1px; }\n" +
                ".date{  text-align: right;  color: #003366; }\n" +
                ".foot{  font-size: 9px;  text-align: center;  color: #FFFFFF; }\n" +
                ".footer{  font-size: 11px;  vertical-align: middle;  color: #FFFFFF; }\n" +
                "#list_hdr{  background-color: #597A9B;  padding: 2px;  padding-left: 4px;  color: #FFFFFF;  font-weight: bold; }\n" +
                "#list_hdr a:link{  color: #FFFFFF;  text-decoration: underline; }\n" +
                "#list_hdr a:visited{  color: #FFFFFF;  text-decoration: underline; }\n" +
                "#list_hdr a:active{  color: #FFFFFF;  text-decoration: none; }\n" +
                "#list_hdr a:hover{  color: #FFFFFF;  text-decoration: underline; }\n" +
                "#list_foot{  background-color: #597A9B;  padding: 2px;  padding-left: 4px;  color: #FFFFFF;  font-weight: bold;  text-align: center; }\n" +
                "#list_foot a:link{  color: #FFFFFF;  text-decoration: underline; }\n" +
                "#list_foot a:visited{  color: #FFFFFF;  text-decoration: underline; }\n" +
                "#list_foot a:active{  color: #FFFFFF;  text-decoration: none; }\n" +
                "#list_foot a:hover{  color: #FFFFFF;  text-decoration: underline; }\n" +
                ".cn_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                ".date_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                ".name_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                ".status_col{  text-align: center;  vertical-align: middle;  padding: 1px; }\n" +
                ".region_col{  text-align: center;  vertical-align: middle;  padding-left: 4px; }\n" +
                ".allLocation_col{  text-align: left;  vertical-align: middle;  padding-left: 4px; }\n" +
                ".allVarietyBatchAdmin_col{  text-align: left;  vertical-align: middle;  padding-left: 4px; }\n" +
                ".role_col{  text-align: center;  vertical-align: middle;  padding-left: 4px; }\n" +
                ".claim_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                ".edit_col{  text-align: center;  vertical-align: middle;  padding-top: 2px;  padding-bottom: 2px; }\n" +
                ".delete_col{  text-align: center;  vertical-align: middle;  padding-top: 2px;  padding-bottom: 2px; }\n" +
                "tr#b{  background-color: #EAEAEA; }\n" +
                "tr#c{  background-color: #FBE7BE; }\n" +
                ".comp_top_nav{  padding-bottom: 5px;  vertical-align: middle;  width: 700px; }\n" +
                ".top_nav_return{  text-align: right;  width: 100%; }\n" +
                ".tab_spacer{  width: 35px; }\n" +
                ".filterLabel {  border:0;  background:#FBE7BE; }\n" +
                ".userIdLabelForAddScreen {  background:#FBE7BE; }\n" +
                ".locationIdLabel {  background:#FBE7BE; }\n" +
                " -->\n" +
                "</style>\n" +
                "</head>\n" +
                "<body width='680' margin='0' '>" +
                "<br>" +
                "<table cellspacing=0 cellpadding=0  border=0 width=650><tbody>" +
                "<tr><td id='headerId' colspan=1<td colspan=1 class='date'>"+nvl(this.row_entry_date)+" </td></tr>" +
                "<tr><td colspan=2 class='hdr_rule'></td></tr></tbody></table>" +
                "<div style='width:650'><p name='c.initiator_response' style='padding: 5px 5px 5px 5px;border: 1px solid #003366;background-color: #FFF;font-family: Arial, Helvetica, sans-serif;  font-size: 20px;'>" +
                "Response to Initiator:&nbsp;<br><strong>" + nvl(this.initiator_response) + "</strong></p></div>" +

                "<div id='gen_info' style='width:650;overflow: visible;'>" +
                "<table cellspacing=0 cellpadding=0  class='tbl_pad' border=0 width=650><tbody><tr><td colspan=1>Entry Date:</td>" +
                "<td colspan=1><label name='c.row_entry_date' size=16 type='text'>[" + nvl(this.row_entry_date) + "]</label></td>" +
                "<td colspan=1>Created By:</td><td colspan=1>" +
                "<label name='c.created_by' size=16 type='text'>[" + nvl(this.created_by) + "]</label></td>" +
                "<td colspan=1>Status:</td><td id='id_status' colspan=1><select name='c.status_id' type='select-one' disabled >" +
                "<option selected>" + nvl(getStatus(lookup)) + "</option></select></td>" +
                "<td colspan=1>Region:</td>" +
                "<td id='id_region' colspan=1><select id='region_id' name='c.region_id' type='select-one' disabled >" +
                "<option selected> " + nvl(getRegion(lookup)) + "</option></select> </td></tr><tr><td colspan=1>Claim No.:</td>" +
                "<td id='id_claim' colspan=1><label name='c.claim_number' size=16 type='text'>" + nvl(this.claim_number) + "</label></td>" +

//                "<td colspan=1>Claim Category</td><td colspan=1><select name='c.claimCategoryId' type='select-one' disabled >" +
//                "<option selected>" + getClaimCategory(lookup, source) + "</option></select> </td>" +
                "</tr>" +
//                "<tr><td colspan=1>CIS Claim Status:</td><td id='id_claim_status' colspan=1>" +
//                "<label name='c.claimStatusType' size=16 type='text'>[" + this.claimStatusType + "]</label></td></tr>" +
//                "<tr><td colspan=1>Closed Date:</td><td colspan=1>" +
//                "<label name='c.closingDate' size=16 type='text'>[" + this.closingDate + "]</label></td></tr>" +
//                "<tr id='feedbackCategoryInfo_row'><td colspan=3>�</td><td colspan=3>" +
//                "<label id='feedbackCategoryInfo' name='c.feedbackCategoryInfo' size=60 type='text'>[" + this.feedbackCategoryInfo + "]" +
//                "</label> </td></tr>" +
                "</tbody></table></div>" +
                "<div id='seed_info' style='width:650;overflow: visible;'><table cellspacing=0 cellpadding=0  class='tbl_pad' border=0 width=650><tbody>" +
                "<tr><td colspan=1>Control Number:</td><td colspan=1>Reporting Location</td><td colspan=1>Loc. ID:</td><td colspan=1>Initiated By:</td>" +
                "<td colspan=1>Date Reported:</td><td colspan=1>Sales Yr.:</td></tr>" +
                "<tr><td id='id_control_number' colspan=1>" +
                "<label name='c.complaint_id' size=7 type='text'>[" + nvl(this.complaint_id) + "]</label></td>" +
                "<td id='reportLocation' colspan=1><select id='reporting_location_code' name='c.reporting_location_code' type='select-one' disabled >" +
                "<option selected>" + nvl(getLocation(lookup, this.reporting_location_code)) + "</option></select> </td><td colspan=1>" +
                "<label id='reporting_location_code_txt' name='c.reporting_location_code' size=5 type='text'>[" + nvl(this.reporting_location_code) + "]" +
                "</label></td><td colspan=1>" +
                "<label id='reportInitiator' name='c.report_initiator' size=13 type='text'>[" + nvl(this.report_initiator) + "]" +
                "</label><a></a>  </td><td colspan=1>" +
                "<label id='reportDate' name='c.report_date' size=14 type='text'>[" + nvl(this.report_date) + "]</label>  </td>" +
                "<td id='id_sales_year' colspan=1>" +
                "<select id='sales_year_id' name='c.sales_year_id' type='select-one' disabled >" +
                "<option selected>" + nvl(getYear(lookup, this.sales_year_id)) + "</option></select></td></tr>" +
                "<tr id='customerLocationInfo_row'><td colspan=1></td><td colspan=5>" +
                "<label id='customerLocationInfo' name='c.customerLocationInfo' size=100 type='text'>[" + nvl(this.customerLocationInfo) + "]" +
                "</label></td></tr>" +
//                "<tr><td colspan=1>Communication Date:</td><td colspan=1>Field Communicator</td><td colspan=1>State:</td></tr>" +
//                "<tr><td colspan=1>" +
//                "<label id='communicationDate' name='c.communication_date' size=7 type='text'>[" + this.communication_date + "]" +
//                "</label> �  </td><td colspan=1>" +
//                "<label id='fieldCommunicator' name='c.field_communicator' size=13 type='text'>[" + this.field_communicator + "]" +
//                "</label> �<a></a>  </td><td id='state' colspan=1><select id='state_id' name='c.state_id' type='select-one' disabled >" +
//                "<option selected>" + getState(lookup, this.state_id) + "</option></select> </td></tr>" +
//                "<tr id='responsibleLocationInfo_row'><td colspan=1>�</td><td colspan=5>" +
//                "<label id='responsibleLocationInfo' name='c.responsibleLocationInfo' size=100 type='text'>[" + this.responsibleLocationInfo + "]" +
//                "</label></td></tr><tr><td colspan=1>Initial Assessment:</td><td colspan=1>Complaint Category:</td></tr>" +
//                "<tr><td id='initialAssesment' colspan=1><select name='c.initialAssesmentCode' type='select-one' disabled >" +
//                "<option selected>" + getAssessment(lookup) + "</option></select> </td>" +
//                "<td id='complaintLitigationCategory' colspan=1>" +
//                "<select name='c.complaintLitigationCategoryCode' type='select-one' disabled >" +
//                "<option selected>" + this.complaintLitigationCategoryCode + "</option></select> </td></tr>" +
                "</tbody></table></div>" +
//                "<div id='seed_info' style='width:650;overflow: visible;'><table cellspacing=0 cellpadding=0  border=0 width=650><tbody>" +
//                "<tr><td colspan=1>Investigator</td><td colspan=1>Crop:</td>" +
//                "<td colspan=1><div id='valid_quality_issue_label' style='overflow: visible;' >Valid Quality Issue: </div></td></tr><tr>" +
//                "<td colspan=1> �<a>" + this.person_investigating + "</a>  </td>" +
//                "<td id='id_crop' colspan=1><select id='crop_id' name='c.crop_id' type='select-one' disabled >" +
//                "<option selected>" + getCrop(lookup) + "</option></select> </td><td colspan=1>" + this.quality_issue + "</td></tr>" +
//                "<tr><td colspan=1>High Level Category:</td><td colspan=1>Low Level Category:</td><td colspan=1>Responsible Location:</td>" +
//                "<td colspan=1>Loc. ID:</td></tr>" +
//                "<tr><td colspan=1>" + getHighCategory(source) + "</td><td colspan=1>" + getLowCategory(source) + "</td>" +
//                "<td id='responsibleLocationtd' colspan=1>" + getLocation(lookup, this.responsible_plant_code) + "</td>" +
//                "<td colspan=1> " + this.responsible_plant_code + "</td></tr>" +
//                "<tr><td colspan=1>Initiator Sample:</td><td colspan=1>Comments:</td><td colspan=1>Site Sample:</td><td colspan=1>Comments:</td></tr>" +
//                "<tr><td colspan=1>" + this.getComplaintInvestigation().getInitiatorSample() + "</td>" +
//                "<td colspan=1>" + this.getComplaintInvestigation().getInitiatorComments() + "</td>" +
//                "<td colspan=1>" + this.getComplaintInvestigation().getSiteSample() + "</td>" +
//                "<td colspan=2>" + this.getComplaintInvestigation().getSiteComments() + "</td></tr>" +
//                "<tr><td colspan=2>Quality Scores:</td><td colspan=2>Delivery Info:</td></tr>" +
//                "<tr><td colspan=2>" + this.getComplaintInvestigation().getQualityScores() + "</td>" +
//                "<td colspan=2>" + this.getComplaintInvestigation().getDeliveryInfo() + "</td></tr><tr></tr>" +
//                "<tr></tr></tbody></table></div><br></br>" +
                "<div id='seed-info' style='overflow: visible;' ><div id=''complaint_batch' style='width:650;overflow: visible;'> " +
                "<table cellspacing=0 cellpadding=0  id='varietyBatchTable' width=650><tbody><tr><td colspan=1></td><td colspan=1>Variety:</td>" +
                "<td colspan=1>Batch:</td><td colspan=1>Qty Affected:</td><td colspan=1>Affected Acres:</td><td colspan=1>UOM:</td><td colspan=1>Seed Size:</td>" +
//                "<td colspan=1>IL TYpe:</td><td colspan=1>Crop Batch Year:</td><td colspan=1>Search</td><td colspan=1>Find related Information</td>" +
                "</tr>" +
                nvl(this.getVarietyBatchHtml(lookup)) + "</tbody></table> </div></div><div id='endComplaintBatchId'/>" +
                "<div id='problemDescId' style='overflow: visible;' ><div id='comp_01' style='overflow: visible;' >" +
                "<table cellspacing=0 cellpadding=0  border=0 width=650><tbody><tr>" +
                "<td colspan=1><ul id='tabnav'><li id='tab_on'><a>Problem Description</a> </li></ul></td></tr>" +
                "<tr><td colspan=1 class='comments_cell'>" +
                "<p name='c.problem_description' style='padding: 5px 5px 5px 5px;border: 1px solid #003366;background-color: #FFF;'>"
                + nvl(this.problem_description) + "<cr></p>" +
                " </td></tr></tbody></table>" +
//                "<table cellspacing=0 cellpadding=0  border=0 width=650><tbody><tr><td colspan=1>Refuge Planted:</td><td colspan=1>Trait Check Completed:</td>" +
//                "<td colspan=1>Traited acres Root Injury:</td><td colspan=1>Refuge Root Injury Rating:</td></tr>" +
//                "<tr><td colspan=1>" + getRefugePlanted(source) + "</td><td colspan=1>" + getTraitCheck(source) + "</td>" +
//                "<td colspan=1>" + getRootInjury(source) + "</td><td colspan=1>" + getRootInjuryRating(source) + "</td></tr></tbody></table></div>" +
//                getNonconformanceHtml() +
                getClaimInfo(this.claim_number,this) +
                "<br></br>\n" +
                "</body>\n" +
                "</html>";
    }

    private Object nvl(Object str) {
        if (str == null)
            return "";
        return str;
    }

    private String getClaimInfo(String claimId,Complaint complaint) {
       /*
       if (StringUtils.isNullOrEmpty(claimId))
            return "";

        ClaimDao claimDao = new ClaimDaoImpl();
        Claim claim = claimDao.getClaimsInformation(claimId);

        if (claim == null)
            return "";*/

        return "<div id='comp2_04' style='overflow: visible;' ><table cellspacing=0 cellpadding=0  border=0 width=650><tbody>" +
                "<tr><td colspan=1><ul id='tabnav'><li id='tab_on'><a>Grower / Dealer</a> </li></ul></td></tr>" +
                "<tr><td colspan=1 class='comments_cell'><table cellspacing=0 cellpadding=0  border=0><tbody>" +
                "<tr><td colspan=1></td><td colspan=1></td><td colspan=1></td><td colspan=1></td><td colspan=1></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1></td></tr>" +
                "<tr><td colspan=1 class='rgt_align' width=150>Grower Name: </td>" +
                "<td id='id_grower_name' colspan=1 class='form_align'>" +
                "<label name='c.grower_name' size=20 type='text'>[" + nvl(complaint.getGrower_name()) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align' width=150>Dealer Name: </td>" +
                "<td id='id_dealer_name' colspan=1 class='form_align'>" +
                "<label name='c.dealer_name' size=20 type='text'>[" + nvl(complaint.getDealer_name()) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td></tr><tr><td colspan=1 class='rgt_align'>Address:</td>" +
                "<td id='id_grower_address' colspan=1 class='form_align'>" +
                "<label name='c.grower_address' size=20 type='text'>[" + nvl(complaint.getGrower_address()) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align'>Address:</td>" +
                "<td id='id_dealer_address' colspan=1 class='form_align'>" +
                "<label name='c.dealer_address' size=20 type='text'>[" + nvl(complaint.getDealer_address()) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td></tr><tr><td colspan=1 class='rgt_align'>City:</td>" +
                "<td id='id_grower_city' colspan=1 class='form_align'>" +
                "<label name='c.grower_city' size=20 type='text'>[" + nvl(complaint.getGrower_city()) + "]</label></td>" +
                "<td colspan=1 class='rgt_align'>State:</td><td id='growerState' colspan=1 class='form_align'>" +
                "<select name='c.grower_state' type='select-one' disabled >" +
                "<option selected>" + nvl(complaint.getGrower_state()) + "</option></select> </td>" +
                "<td colspan=1 class='rgt_align'>City:</td><td id='id_dealer_city' colspan=1 class='form_align'>" +
                "<label name='c.dealer_city' size=20 type='text'>[" + nvl(complaint.getDealer_city()) + "]</label></td>" +
                "<td colspan=1 class='rgt_align'>State:</td>" +
                "<td id='dealerState' colspan=1 class='form_align'><select name='c.dealer_state' type='select-one' disabled >" +
                "<option selected>" + nvl(this.dealer_state) + "</option></select> </td></tr>" +
                "<tr><td colspan=1 class='rgt_align'>Phone:</td><td colspan=1 class='form_align'>" +
                "<label name='c.grower_phone' size=20 type='text'>[" + nvl(this.grower_phone) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align'>Phone:</td>" +
                "<td colspan=1 class='form_align'>" +
                "<label name='c.dealer_phone' size=20 type='text'>[" + nvl(this.dealer_phone) + "]</label></td><td colspan=1></td>" +
                "<td colspan=1></td></tr><tr><td colspan=1 class='rgt_align'>BA Id:</td>" +
                "<td id='id_grower_ba_id' colspan=1 class='form_align'>" +
                "<label name='c.grower_ba_id' size=20 type='text'>[" + this.grower_ba_id + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align'>BA Id:</td>" +
                "<td id='id_dealer_ba_id' colspan=1 class='form_align'>" +
                "<label name='c.dealer_ba_id' size=20 type='text'>[" + this.dealer_ba_id + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td></tr><tr><td colspan=1 class='rgt_align'>Grower GPS Coordinates Latitude: </td>" +
                "<td id='id_grower_gps_lat' colspan=1 class='form_align'>" +
                "<label name='c.growerLatitude' size=20 type='text'>[" + nvl(this.growerLatitude) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align'>Dealer GPS Coordinates Latitude: </td>" +
                "<td id='id_dealer_gps_lat' colspan=1 class='form_align'>" +
                "<label name='c.dealerLatitude' size=20 type='text'>[" + nvl(this.dealerLatitude) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td></tr><tr><td colspan=1 class='rgt_align'>Grower GPS Coordinates Longitude: </td>" +
                "<td id='id_grower_gps_long' colspan=1 class='form_align'>" +
                "<label name='c.growerLongitude' size=20 type='text'>[" + nvl(this.growerLongitude) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td><td colspan=1 class='rgt_align'>Dealer GPS Coordinates Longitude: </td>" +
                "<td id='id_dealer_gps_long' colspan=1 class='form_align'>" +
                "<label name='c.dealerLongitude' size=20 type='text'>[" + nvl(this.dealerLongitude) + "]</label></td>" +
                "<td colspan=1></td><td colspan=1></td></tr></tbody></table></td></tr></tbody></table></div>";
    }

    private String getClaimCategory(LookUpService lookup, DataSource source) {
        if (StringUtils.isNullOrEmpty(claimCategoryId))
            return "";

        ClaimsService claimsService = new ClaimsServiceImpl(new ClaimDaoImpl(), lookup, new SalesOfficeServiceImpl(source));
        return claimsService.lookUpClaimCategoryRefData(MCASConstants.LANGUAGE_DEFAULT).get(claimCategoryId);
    }

    private String getRootInjuryRating(DataSource source) {
        if (StringUtils.isNullOrEmpty(injuryRatingId))
            return "";
        RootInjuryService rootInjuryService = new RootInjuryServiceImpl(new RootInjuryDaoImpl(source));
        return rootInjuryService.lookUpRootInjury(2, MCASConstants.LANGUAGE_DEFAULT).get(injuryRatingId);
    }

    private String getTraitCheck(DataSource source) {
        if (StringUtils.isNullOrEmpty(traitCheckId))
            return "";
        RefugePlantedService refugePlantedService = new RefugePlantedServiceImpl(new RefugePlantedDaoImpl(source));
        return refugePlantedService.lookUpRefugePlanted(2, MCASConstants.LANGUAGE_DEFAULT).get(traitCheckId);
    }

    private String getRootInjury(DataSource source) {
        if (StringUtils.isNullOrEmpty(this.rootInjuryId))
            return "";

        RootInjuryService rootInjuryService = new RootInjuryServiceImpl(new RootInjuryDaoImpl(source));
        return rootInjuryService.lookUpRootInjury(1, MCASConstants.LANGUAGE_DEFAULT).get(rootInjuryId);
    }

    private String getRefugePlanted(DataSource source) {
        if (StringUtils.isNullOrEmpty(refugePlantedId))
            return "";

        RefugePlantedService refugePlantedService = new RefugePlantedServiceImpl(new RefugePlantedDaoImpl(source));
        return refugePlantedService.lookUpRefugePlanted(1, MCASConstants.LANGUAGE_DEFAULT).get(refugePlantedId);
    }

    private String getLocation(LookUpService lookup, String locCode) {
        if (StringUtils.isNullOrEmpty(locCode))
            return "";

        return lookup.getLocations(false, 1, MCASConstants.LANGUAGE_DEFAULT).get(locCode);
    }

    private String getLowCategory(DataSource source) {
        if (StringUtils.isNullOrEmpty(lowCategoryId))
            return "";

        IssueCategoryService issueCategoryService = new IssueCategoryServiceImpl(new IssueCategoryDaoImpl(source));
        return issueCategoryService.lookUpIssueCategory(2, MCASConstants.LANGUAGE_DEFAULT, "C").get(lowCategoryId);
    }

    private String getHighCategory(DataSource source) {
        if (StringUtils.isNullOrEmpty(issueCategoryId))
            return "";

        IssueCategoryService issueCategoryService = new IssueCategoryServiceImpl(new IssueCategoryDaoImpl(source));
        return issueCategoryService.lookUpIssueCategory(1, MCASConstants.LANGUAGE_DEFAULT, "C").get(issueCategoryId);
    }

    private String getCrop(LookUpService lookup) {
        if (StringUtils.isNullOrEmpty(crop_id))
            return "";

        return lookup.getCrops(MCASConstants.LANGUAGE_DEFAULT).get(this.crop_id);
    }

    private String getAssessment(LookUpService lookup) {
        return lookup.getAssesmentMap(MCASConstants.LANGUAGE_DEFAULT).get(initialAssesmentCode);
    }

    private String getRegion(LookUpService lookup) {

        if (StringUtils.isNullOrEmpty(region_id))
            return "";

        return lookup.getRegions(null, 1, false, MCASConstants.LANGUAGE_DEFAULT).get(region_id);
    }

    private String getStatus(LookUpService lookup) {

        if (StringUtils.isNullOrEmpty(status_id))
            return "";

        final int i = Integer.parseInt(status_id);
        return lookup.getStatusDescription(i, 1, MCASConstants.LANGUAGE_DEFAULT);
    }

    private String getState(LookUpService lookup, String id) {

        if (StringUtils.isNullOrEmpty(id))
            return "";

        return lookup.getStates().get(id);
    }

    private String getYear(LookUpService lookup, String id) {

        if (StringUtils.isNullOrEmpty(id))
            return "";

        final int i = Integer.parseInt(id);
        return lookup.getYearDescription(i);
    }

    private String getUOM(LookUpService lookup, Long id) {

        if (id == null)
            return "";

        return lookup.getUOM(MCASConstants.LANGUAGE_DEFAULT).get(Long.toString(id));
    }

    private String getSeedSize(LookUpService lookup, Long id) {

        if (id == null)
            return "";

        return lookup.getSeedSize(MCASConstants.LANGUAGE_DEFAULT).get(Long.toString(id));
    }

    private String getIlType(LookUpService lookup, Long id) {

        if (id == null)
            return "";

        return lookup.lookUpIlTypes(MCASConstants.LANGUAGE_DEFAULT).get(Long.toString(id));
    }

    private String getVarietyBatchHtml(LookUpService lookup) {

        if (varietyBatchList == null) return "";

        StringBuffer str = new StringBuffer();
        for (int i = 0; i < this.varietyBatchList.size(); i++) {

            if (this.varietyBatchList.get(i).getVarietyDesc() == null)
                continue;

            str.append("<tr><td colspan=1></td><td colspan=1>" +
                    "<label id='varietyDesc0' name='c.varietyBatchList[0].varietyDesc' size=20 type='text'>["
                    + nvl(this.varietyBatchList.get(i).getVarietyDesc()) + "</label> </td><td colspan=1>" +
                    "<label id='batchNumber0' name='c.varietyBatchList[0].batchNumber' size=20 type='text'>["
                    + nvl(this.varietyBatchList.get(i).getBatchNumber()) + "]</label> </td>" +
                    "<td colspan=1><label name='c.varietyBatchList[0].quantityAffected' size=10 type='text'>["
                    + nvl(this.varietyBatchList.get(i).getQuantityAffected()) + "]</label></td><td colspan=1>" +
                    "<label name='c.varietyBatchList[0].acresAffected' size=10 type='text'>["
                    + nvl(this.varietyBatchList.get(i).getAcresAffected()) + "]</label></td><td colspan=1>" +
                    "<label name='c.varietyBatchList[0].uomId' size=10 type='text'>["

                     + nvl(getUOM(lookup, this.varietyBatchList.get(i).getUomId())) + "]</label> </td><td colspan=1>" +
                    "<label name='c.varietyBatchList[0].seedSizeId' size=10 type='text'>["
                    +

                     nvl(getSeedSize(lookup, this.varietyBatchList.get(i).getSeedSizeId())) + "]</label> </td>" +
//                    "<td colspan=1><select name='c.varietyBatchList[0].ilType' type='select-one' disabled >" +
//                    "<option selected>" + getIlType(lookup, this.varietyBatchList.get(i).getIlType()) + "</option></select> </td>" +
//                    "<td colspan=1><select name='c.varietyBatchList[0].batchCropYrId' type='select-one' disabled >" +
//                    "<option selected>" + getYear(lookup, this.varietyBatchList.get(i).getBatchCropYrId().toString()) +
//                    "</option></select> </td>" +
//                    "<td colspan=1> </td><td colspan=1> </td>" +
                    "</tr>");
        }
        return str.toString();
    }

//    private String getNonconformanceHtml() {
//
//        StringBuilder str = new StringBuilder();
//
//        final List<CheckboxGroup> groupList = this.getNonconformanceCategoryList();
//        for (int i = 0; i < groupList.size(); i++) {
//            str.append("<div id='comp1_01' style='overflow: visible;' ><table cellspacing=0 cellpadding=0  border=0 width=650><tbody>" +
//                    "<tr><td colspan=1><ul id='tabnav'><li id='tab_on'></li></ul></td></tr>");
//            final List<CheckboxRow> rowList = groupList.get(i).getCheckboxRowListAsList();
//            for (int j = 0; j < rowList.size(); j++) {
//                str.append("<tr>");
//                final List<CheckboxItem> itemList = rowList.get(j).getCheckboxItemListAsList();
//                for (int k = 0; k < itemList.size(); k++) {
//                    str.append("<td colspan=1>" + itemList.get(k).getCheckboxItemDisplay() + "</td><td colspan=1>" +
//                            "<input name='c.nonconformanceCategoryList[0].checkboxRowList[0].checkboxItemList[0].checkboxItemValue' size=20 type='checkbox'>");
//                    if (itemList.get(k).isCheckboxItemValue())
//                        str.append("X");
//                    else
//                        str.append(" ");
//                    str.append("</td>");
//                }
//                str.append("</tr>");
//            }
//            str.append(" </td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div>");
//        }
//
//        return str.toString();
//    }


    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("---------------Complaint Start--------------------");
        buffer.append(super.toString()).append(",\n");
        buffer.append("complaint_id =").append(complaint_id).append(",\n");
        buffer.append("claim_number =").append(claim_number).append(",\n");
        buffer.append("status_id =").append(status_id).append(",\n");
        buffer.append("sales_year_id =").append(sales_year_id).append(",\n");
        buffer.append("state_id = ").append(state_id).append(",\n");
        buffer.append("report_initiator =").append(report_initiator).append(",\n");
        buffer.append("report_initiator_email =").append(report_initiator_email).append(",\n");
        buffer.append("report_date =").append(report_date).append(",\n");
        buffer.append("communication_date =").append(communication_date).append(",\n");
        buffer.append("region_id =").append(region_id).append(",\n");
        buffer.append("field_communicator =").append(field_communicator).append(",\n");
        buffer.append("reporting_location_code =").append(reporting_location_code).append(",\n");
        buffer.append("responsible_plant_code =").append(responsible_plant_code).append(",\n");
        buffer.append("person_investigating =").append(person_investigating).append(",\n");
        buffer.append("crop_id =").append(crop_id).append(",\n");
        buffer.append("quality_issue =").append(quality_issue).append(",\n");
        buffer.append("quantity_affected =").append(quantity_affected).append(",\n");
        buffer.append("quantity_uom_id =").append(quantity_uom_id).append(",\n");
        buffer.append("seed_size_id =").append(seed_size_id).append(",\n");
        buffer.append("foundBatch0 =").append(foundBatch0).append(",\n");
        buffer.append("foundBatch1 =").append(foundBatch1).append(",\n");
        buffer.append("foundBatch2 =").append(foundBatch2).append(",\n");
        buffer.append("foundBatch3 =").append(foundBatch3).append(",\n");
        buffer.append("problem_description =").append(problem_description).append(",\n");
        buffer.append("containment_actions =").append(containment_actions).append(",\n");
        buffer.append("root_cause =").append(root_cause).append(",\n");
        buffer.append("long_term_corrective_action =").append(long_term_corrective_action).append(",\n");
        buffer.append("driver_performance =").append(driver_performance).append(",\n");
        buffer.append("incorrect_shipment =").append(incorrect_shipment).append(",\n");
        buffer.append("delivery_other =").append(delivery_other).append(",\n");
        buffer.append("packaging_condition =").append(packaging_condition).append(",\n");
        buffer.append("tag_error =").append(tag_error).append(",\n");
        buffer.append("seed_appearance =").append(seed_appearance).append(",\n");
        buffer.append("seed_variability =").append(seed_variability).append(",\n");
        buffer.append("emergence_concerns =").append(emergence_concerns).append(",\n");
        buffer.append("product_purity =").append(product_purity).append(",\n");
        buffer.append("product_purity =").append(product_purity).append(",\n");
        buffer.append("early_season_other =").append(early_season_other).append(",\n");
        buffer.append("treatment =").append(treatment).append(",\n");
        buffer.append("growth_development =").append(growth_development).append(",\n");
        buffer.append("pollination_problems =").append(pollination_problems).append(",\n");
        buffer.append("herbicide_injury =").append(herbicide_injury).append(",\n");
        buffer.append("stress_susceptability =").append(stress_susceptability).append(",\n");
        buffer.append("disease_development =").append(disease_development).append(",\n");
        buffer.append("midseason_other =").append(midseason_other).append(",\n");
        buffer.append("insect_outbreaks_injury =").append(insect_outbreaks_injury).append(",\n");
        buffer.append("lateseason_disease_development =").append(lateseason_disease_development).append(",\n");
        buffer.append("maintaining_seed_until_harvest =").append(maintaining_seed_until_harvest).append(",\n");
        buffer.append("insect_development =").append(insect_development).append(",\n");
        buffer.append("maturity_drydown =").append(maturity_drydown).append(",\n");
        buffer.append("seed_development =").append(seed_development).append(",\n");
        buffer.append("late_season_other =").append(late_season_other).append(",\n");
        buffer.append("noncompetitive_yield =").append(noncompetitive_yield).append(",\n");
        buffer.append("delivery_info =").append(delivery_info).append(",\n");
        buffer.append("total_acres =").append(total_acres).append(",\n");
        buffer.append("affected_areas =").append(affected_areas).append(",\n");
        buffer.append("technology =").append(technology).append(",\n");
        buffer.append("population_planted =").append(population_planted).append(",\n");
        buffer.append("population_observed =").append(population_observed).append(",\n");
        buffer.append("tillage =").append(tillage).append(",\n");
        buffer.append("planting_date =").append(planting_date).append(",\n");
        buffer.append("planter_type =").append(planter_type).append(",\n");
        buffer.append("planter_depth =").append(planter_depth).append(",\n");
        buffer.append("disease_observed =").append(disease_observed).append(",\n");
        buffer.append("herbicide_type_current =").append(herbicide_type_current).append(",\n");
        buffer.append("herbicide_timming_current =").append(herbicide_timming_current).append(",\n");
        buffer.append("herbicide_rate_current =").append(herbicide_rate_current).append(",\n");
        buffer.append("herbicide_type_prev =").append(herbicide_type_prev).append(",\n");
        buffer.append("herbicide_timming_prev =").append(herbicide_timming_prev).append(",\n");
        buffer.append("herbicide_rate_prev = ").append(herbicide_rate_prev).append(",\n");
        buffer.append("insects_observed =").append(insects_observed).append(",\n");
        buffer.append("insecticide_type_current =").append(insecticide_type_current).append(",\n");
        buffer.append("insecticide_timming_current =").append(insecticide_timming_current).append(",\n");
        buffer.append("insecticide_rate_current =").append(insecticide_rate_current).append(",\n");
        buffer.append("insecticide_rate_current =").append(insecticide_rate_current).append(",\n");
        buffer.append("insecticide_type_prev =").append(insecticide_type_prev).append(",\n");
        buffer.append("insecticide_timming_prev =").append(insecticide_timming_prev).append(",\n");
        buffer.append("insecticide_rate_prev =").append(insecticide_rate_prev).append(",\n");
        buffer.append("grower_name =").append(grower_name).append(",\n");
        buffer.append("grower_address =").append(grower_address).append(",\n");
        buffer.append("grower_city =").append(grower_city).append(",\n");
        buffer.append("grower_state =").append(grower_state).append(",\n");
        buffer.append("grower_phone =").append(grower_phone).append(",\n");
        buffer.append("grower_ba_id =").append(grower_ba_id).append(",\n");
        buffer.append("dealer_name =").append(dealer_name).append(",\n");
        buffer.append("dealer_address =").append(dealer_address).append(",\n");
        buffer.append("dealer_city =").append(dealer_city).append(",\n");
        buffer.append("dealer_state =").append(dealer_state).append(",\n");
        buffer.append("dealer_phone =").append(dealer_phone).append(",\n");
        buffer.append("dealer_ba_id =").append(dealer_ba_id).append(",\n");
        buffer.append("created_by =").append(created_by).append(",\n");
        buffer.append("row_entry_date =").append(row_entry_date).append(",\n");
        buffer.append("row_modify_date =").append(row_modify_date).append(",\n");
        buffer.append("row_task_id =").append(row_task_id).append(",\n");
        buffer.append("settlement_value =").append(settlement_value).append(",\n");
        buffer.append("affina_entry_flag =").append(affina_entry_flag).append(",\n");
        buffer.append("complaintBusinessId =").append(complaintBusinessId).append(",\n");
        buffer.append("feedbackCategoryId =").append(feedbackCategoryId).append(",\n");
        buffer.append("complaintTypeId =").append(complaintTypeId).append(",\n");
        buffer.append("functionId =").append(functionId).append(",\n");
        buffer.append("Business ID = ").append(businessId).append(",\n");
        buffer.append("---------------End of Complaint--------------------");
        return buffer.toString();
    }

    public void setSalesOrderNumber(String salesOrderNumber) {
        this.salesOrderNumber = salesOrderNumber;
    }

    public void setShippingTransportNumber(String shippingTransportNumber) {
        this.shippingTransportNumber = shippingTransportNumber;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public void setCustomerPhoneNumber(String customerPhoneNumber) {
        this.customerPhoneNumber = customerPhoneNumber;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getSalesOrderNumber() {
        return salesOrderNumber;
    }

    public String getShippingTransportNumber() {
        return shippingTransportNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerPhoneNumber() {
        return customerPhoneNumber;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setBusinessId(int businessId) {
        this.businessId = businessId;
    }

    public int getBusinessId() {
        return businessId;
    }

    public void setClaimAmount(String claimAmount) {
//    logger.info("Claim Amount :" + claimAmount);
        this.claimAmount = claimAmount;
    }

    public void setClaimAmountFinal(boolean claimAmountFinal) {
//    logger.info("Claim Final Amount :" + claimAmountFinal);
        this.claimAmountFinal = claimAmountFinal;
    }

    public String getClaimAmount() {
//    logger.info("Claim Amount :" + claimAmount);
        return claimAmount;
    }

    public boolean isClaimAmountFinal() {
//    logger.info("Claim Final Amount :" + claimAmountFinal);
        return claimAmountFinal;
    }

    public String getOldStatusId() {
        return oldStatusId;
    }

    public void setOldStatusId(String oldStatusId) {
        this.oldStatusId = oldStatusId;
    }

    public void setComplaintEntryTypeId(int entryType) {
        this.complaintEntryTypeId = entryType;
    }

    public int getComplaintEntryTypeId() {
        return complaintEntryTypeId;
    }

    public String getComplaintEntryTypeIdAsString() {
        return complaintEntryTypeId == 1 ? MCASConstants.ENTRY_TYPE_DEFAULT : complaintEntryTypeId == 2 ?
                MCASConstants.COMPLAINT_NCR : complaintEntryTypeId == 3 ? MCASConstants.COMPLAINT_DEV : "";
    }

    public void setDispositionList(Map<String, String> dispositionList) {
        this.dispositionList = dispositionList;
    }

    public Map<String, String> getDispositionList() {
        return dispositionList;
    }

    public String getClaimId() {
        return claimId;
    }

    public String getClaimCategoryId() {
        return claimCategoryId;
    }


    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

    public void setClaimCategoryId(String claimCategoryId) {
        this.claimCategoryId = claimCategoryId;
    }


    public String getSapCustomerId() {
        return sapCustomerId;
    }

    public void setSapCustomerId(String sapCustomerId) {
        this.sapCustomerId = sapCustomerId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public boolean isEnvironmentalClaim() {
        return claimCategoryId != null && !(claimCategoryId.equalsIgnoreCase("5") || claimCategoryId.equalsIgnoreCase(""));
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public String getGrowerLatitude() {
        return growerLatitude;
    }

    public void setGrowerLatitude(String growerLatitude) {
        this.growerLatitude = growerLatitude;
    }

    public String getGrowerLongitude() {
        return growerLongitude;
    }

    public void setGrowerLongitude(String growerLongitude) {
        this.growerLongitude = growerLongitude;
    }

    public String getDealerLatitude() {
        return dealerLatitude;
    }

    public void setDealerLatitude(String dealerLatitude) {
        this.dealerLatitude = dealerLatitude;
    }

    public String getDealerLongitude() {
        return dealerLongitude;
    }

    public void setDealerLongitude(String dealerLongitude) {
        this.dealerLongitude = dealerLongitude;
    }

    public String getIssueCategoryId() {
        return issueCategoryId;
    }

    public void setIssueCategoryId(String issueCategoryId) {
        this.issueCategoryId = issueCategoryId;
    }

    public String getLowCategoryId() {
        return lowCategoryId;  //To change body of created methods use File | Settings | File Templates.
    }

    public void setLowCategoryId(String lowCategoryId) {
        this.lowCategoryId = lowCategoryId;
    }

    public String getRefugePlantedId() {
        return refugePlantedId;
    }

    public void setRefugePlantedId(String refugePlantedId) {
        this.refugePlantedId = refugePlantedId;
    }

    public String getTraitCheckId() {
        return traitCheckId;
    }

    public void setTraitCheckId(String traitCheckId) {
        this.traitCheckId = traitCheckId;
    }

    public String getRootInjuryId() {
        return rootInjuryId;
    }

    public void setRootInjuryId(String rootInjuryId) {
        this.rootInjuryId = rootInjuryId;
    }

//    public void setRootInjury(String rootInjuryId) {
//        this.rootInjuryId = rootInjuryId;
//    }

    public String getInjuryRatingId() {
        return injuryRatingId;
    }

    public void setInjuryRatingId(String injuryRatingId) {
        this.injuryRatingId = injuryRatingId;
    }

    public boolean isOtherInfoEntered() {
        return !(StringUtils.isNullOrEmpty(feedbackCategoryInfo) && StringUtils.isNullOrEmpty(customerLocationInfo) && StringUtils.isNullOrEmpty(responsibleLocationInfo));
    }

    public String getClosingPersonId() {
        return closingPersonId;
    }

    public void setClosingPersonId(String closingPersonId) {
        this.closingPersonId = closingPersonId;
    }

    public String getInitiator_response() {
        return initiator_response;
    }

    public void setInitiator_response(String initiator_response) {
        this.initiator_response = initiator_response;
    }

    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

    public List getCarList() {
        return carList;
    }

    public void setCarList(List carList) {
        this.carList = carList;
    }

    public List getParList() {
        return parList;
    }

    public void setParList(List parList) {
        this.parList = parList;
    }

    public List getCiList() {
        return ciList;
    }

    public void setCiList(List ciList) {
        this.ciList = ciList;
    }


    public String getReport_initiator_id() {
        return report_initiator_id;
    }

    public void setReport_initiator_id(String report_initiator_id) {
        this.report_initiator_id = report_initiator_id;
    }

    public String getField_communicator_id() {
        return field_communicator_id;
    }

    public void setField_communicator_id(String field_communicator_id) {
        this.field_communicator_id = field_communicator_id;
    }

    public String getPerson_investigating_id() {
        return person_investigating_id;
    }

    public void setPerson_investigating_id(String person_investigating_id) {
        this.person_investigating_id = person_investigating_id;
    }

}
