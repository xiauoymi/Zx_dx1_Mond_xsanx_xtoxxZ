/*
 * Created on May 31, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.CheckboxGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class ComplaintFilter extends ObjectWithCheckboxGroups implements Serializable {

    private String controlNumber;
    private String createdDate;
    private String initiatedBy;
    private String[] region;
    private String[] salesYear;

    private String[] reportingLocation;
    private String[] responsibleLocation;
    private String[] status;
    private String claimNumber;
    private String[] crop;

    private String batch;
    private String variety;

    private String[] qualityIssue;

    private boolean driverPerformance;
    private boolean packagingCondition;
    private boolean incorrectShipment;
    private boolean tagError;
    private boolean deliveryOther;

    private boolean seedAppearance;
    private boolean seedVariability;
    private boolean emergenceConcerns;
    private boolean productPurity;
    private boolean earlySeasonOther;
    private boolean treatment;

    private boolean growthDevelopment;
    private boolean herbicideInjury;
    private boolean diseaseDevelopment;
    private boolean insectOutbreaksInjury;
    private boolean pollinationProblems;
    private boolean stressSusceptability;
    private boolean midSeasonOther;

    private boolean lateSeasonDiseaseDevelopment;
    private boolean insectDevelopment;
    private boolean seedDevelopment;
    private boolean nonCompetitiveYield;
    private boolean maintainingSeedUntilHarvest;
    private boolean maturityDrydown;
    private boolean lateSeasonOther;

    private String complaintBusinessId;
    private String feedbackCategoryId;
    private String complaintTypeId;
    private String functionId;


    private String[] initialAssesmentCode;
    private String[] complaintLitigationCategoryCode;
    private String[] complaintMaterialGroup;
    private String[] complaintMaterialPricingGroup;
    private String[] salesOffice;
    private boolean claimAmountFinal;
    private String complaintEntryTypeId;

    public String getComplaintBatchSeq() {
        return complaintBatchSeq;
    }

    public void setComplaintBatchSeq(String complaintBatchSeq) {
        this.complaintBatchSeq = complaintBatchSeq;
    }

    private String complaintBatchSeq;

    public String[] getSalesOffice() {
        return salesOffice;
    }

    public void setSalesOffice(String[] salesOffice) {
        this.salesOffice = salesOffice;
    }

    public boolean isClaimAmountFinal() {
        return claimAmountFinal;
    }

    public void setClaimAmountFinal(boolean claimAmountFinal) {
        this.claimAmountFinal = claimAmountFinal;
    }


    public void setComplaintMaterialPricingGroup(String[] complaintMaterialPricingGroup) {
        this.complaintMaterialPricingGroup = complaintMaterialPricingGroup;
    }

    public String[] getComplaintMaterialPricingGroup() {
        return complaintMaterialPricingGroup;
    }

    public String[] getComplaintMaterialGroup() {
        return complaintMaterialGroup;
    }

    public void setComplaintMaterialGroup(String[] complaintMaterialGroup) {
        this.complaintMaterialGroup = complaintMaterialGroup;
    }


    public String[] getInitialAssesmentCode() {
        return initialAssesmentCode;
    }

    public void setInitialAssesmentCode(String[] initialAssesmentCode) {
        this.initialAssesmentCode = initialAssesmentCode;
    }

    public String[] getComplaintLitigationCategoryCode() {
        return complaintLitigationCategoryCode;
    }

    public void setComplaintLitigationCategoryCode(String[] complaintLitigationCategoryCode) {
        this.complaintLitigationCategoryCode = complaintLitigationCategoryCode;
    }

    public boolean isTreatment() {
        return treatment;
    }

    public void setTreatment(boolean treatment) {
        this.treatment = treatment;
    }

    /**
     * @return Returns the deliveryOther.
     */
    public boolean isDeliveryOther() {
        return deliveryOther;
    }

    /**
     * @param deliveryOther The deliveryOther to set.
     */
    public void setDeliveryOther(boolean deliveryOther) {
        this.deliveryOther = deliveryOther;
    }

    /**
     * @return Returns the diseaseDevelopment.
     */
    public boolean isDiseaseDevelopment() {
        return diseaseDevelopment;
    }

    /**
     * @param diseaseDevelopment The diseaseDevelopment to set.
     */
    public void setDiseaseDevelopment(boolean diseaseDevelopment) {
        this.diseaseDevelopment = diseaseDevelopment;
    }

    /**
     * @return Returns the driverPerformance.
     */
    public boolean isDriverPerformance() {
        return driverPerformance;
    }

    /**
     * @param driverPerformance The driverPerformance to set.
     */
    public void setDriverPerformance(boolean driverPerformance) {
        this.driverPerformance = driverPerformance;
    }

    /**
     * @return Returns the earlySeasonOther.
     */
    public boolean isEarlySeasonOther() {
        return earlySeasonOther;
    }

    /**
     * @param earlySeasonOther The earlySeasonOther to set.
     */
    public void setEarlySeasonOther(boolean earlySeasonOther) {
        this.earlySeasonOther = earlySeasonOther;
    }

    /**
     * @return Returns the emergenceConcerns.
     */
    public boolean isEmergenceConcerns() {
        return emergenceConcerns;
    }

    /**
     * @param emergenceConcerns The emergenceConcerns to set.
     */
    public void setEmergenceConcerns(boolean emergenceConcerns) {
        this.emergenceConcerns = emergenceConcerns;
    }

    /**
     * @return Returns the growthDevelopment.
     */
    public boolean isGrowthDevelopment() {
        return growthDevelopment;
    }

    /**
     * @param growthDevelopment The growthDevelopment to set.
     */
    public void setGrowthDevelopment(boolean growthDevelopment) {
        this.growthDevelopment = growthDevelopment;
    }

    /**
     * @return Returns the herbicideInjury.
     */
    public boolean isHerbicideInjury() {
        return herbicideInjury;
    }

    /**
     * @param herbicideInjury The herbicideInjury to set.
     */
    public void setHerbicideInjury(boolean herbicideInjury) {
        this.herbicideInjury = herbicideInjury;
    }

    /**
     * @return Returns the incorrectShipment.
     */
    public boolean isIncorrectShipment() {
        return incorrectShipment;
    }

    /**
     * @param incorrectShipment The incorrectShipment to set.
     */
    public void setIncorrectShipment(boolean incorrectShipment) {
        this.incorrectShipment = incorrectShipment;
    }

    /**
     * @return Returns the insectDevelopment.
     */
    public boolean isInsectDevelopment() {
        return insectDevelopment;
    }

    /**
     * @param insectDevelopment The insectDevelopment to set.
     */
    public void setInsectDevelopment(boolean insectDevelopment) {
        this.insectDevelopment = insectDevelopment;
    }

    /**
     * @return Returns the insectOutbreaksInjury.
     */
    public boolean isInsectOutbreaksInjury() {
        return insectOutbreaksInjury;
    }

    /**
     * @param insectOutbreaksInjury The insectOutbreaksInjury to set.
     */
    public void setInsectOutbreaksInjury(boolean insectOutbreaksInjury) {
        this.insectOutbreaksInjury = insectOutbreaksInjury;
    }

    /**
     * @return Returns the lateSeasonDiseaseDevelopment.
     */
    public boolean isLateSeasonDiseaseDevelopment() {
        return lateSeasonDiseaseDevelopment;
    }

    /**
     * @param lateSeasonDiseaseDevelopment The lateSeasonDiseaseDevelopment to set.
     */
    public void setLateSeasonDiseaseDevelopment(
            boolean lateSeasonDiseaseDevelopment) {
        this.lateSeasonDiseaseDevelopment = lateSeasonDiseaseDevelopment;
    }

    /**
     * @return Returns the lateSeasonOther.
     */
    public boolean isLateSeasonOther() {
        return lateSeasonOther;
    }

    /**
     * @param lateSeasonOther The lateSeasonOther to set.
     */
    public void setLateSeasonOther(boolean lateSeasonOther) {
        this.lateSeasonOther = lateSeasonOther;
    }

    /**
     * @return Returns the maintainingSeedUntilHarvest.
     */
    public boolean isMaintainingSeedUntilHarvest() {
        return maintainingSeedUntilHarvest;
    }

    /**
     * @param maintainingSeedUntilHarvest The maintainingSeedUntilHarvest to set.
     */
    public void setMaintainingSeedUntilHarvest(
            boolean maintainingSeedUntilHarvest) {
        this.maintainingSeedUntilHarvest = maintainingSeedUntilHarvest;
    }

    /**
     * @return Returns the maturityDrydown.
     */
    public boolean isMaturityDrydown() {
        return maturityDrydown;
    }

    /**
     * @param maturityDrydown The maturityDrydown to set.
     */
    public void setMaturityDrydown(boolean maturityDrydown) {
        this.maturityDrydown = maturityDrydown;
    }

    /**
     * @return Returns the midSeasonOther.
     */
    public boolean isMidSeasonOther() {
        return midSeasonOther;
    }

    /**
     * @param midSeasonOther The midSeasonOther to set.
     */
    public void setMidSeasonOther(boolean midSeasonOther) {
        this.midSeasonOther = midSeasonOther;
    }

    /**
     * @return Returns the nonCompetitiveYield.
     */
    public boolean isNonCompetitiveYield() {
        return nonCompetitiveYield;
    }

    /**
     * @param nonCompetitiveYield The nonCompetitiveYield to set.
     */
    public void setNonCompetitiveYield(boolean nonCompetitiveYield) {
        this.nonCompetitiveYield = nonCompetitiveYield;
    }

    /**
     * @return Returns the packagingCondition.
     */
    public boolean isPackagingCondition() {
        return packagingCondition;
    }

    /**
     * @param packagingCondition The packagingCondition to set.
     */
    public void setPackagingCondition(boolean packagingCondition) {
        this.packagingCondition = packagingCondition;
    }

    /**
     * @return Returns the pollinationProblems.
     */
    public boolean isPollinationProblems() {
        return pollinationProblems;
    }

    /**
     * @param pollinationProblems The pollinationProblems to set.
     */
    public void setPollinationProblems(boolean pollinationProblems) {
        this.pollinationProblems = pollinationProblems;
    }

    /**
     * @return Returns the productPurity.
     */
    public boolean isProductPurity() {
        return productPurity;
    }

    /**
     * @param productPurity The productPurity to set.
     */
    public void setProductPurity(boolean productPurity) {
        this.productPurity = productPurity;
    }

    /**
     * @return Returns the seedAppearance.
     */
    public boolean isSeedAppearance() {
        return seedAppearance;
    }

    /**
     * @param seedAppearance The seedAppearance to set.
     */
    public void setSeedAppearance(boolean seedAppearance) {
        this.seedAppearance = seedAppearance;
    }

    /**
     * @return Returns the seedDevelopment.
     */
    public boolean isSeedDevelopment() {
        return seedDevelopment;
    }

    /**
     * @param seedDevelopment The seedDevelopment to set.
     */
    public void setSeedDevelopment(boolean seedDevelopment) {
        this.seedDevelopment = seedDevelopment;
    }

    /**
     * @return Returns the seedVariability.
     */
    public boolean isSeedVariability() {
        return seedVariability;
    }

    /**
     * @param seedVariability The seedVariability to set.
     */
    public void setSeedVariability(boolean seedVariability) {
        this.seedVariability = seedVariability;
    }

    /**
     * @return Returns the stressSusceptability.
     */
    public boolean isStressSusceptability() {
        return stressSusceptability;
    }

    /**
     * @param stressSusceptability The stressSusceptability to set.
     */
    public void setStressSusceptability(boolean stressSusceptability) {
        this.stressSusceptability = stressSusceptability;
    }

    /**
     * @return Returns the tagError.
     */
    public boolean isTagError() {
        return tagError;
    }

    /**
     * @param tagError The tagError to set.
     */
    public void setTagError(boolean tagError) {
        this.tagError = tagError;
    }

    /**
     * @return Returns the batch.
     */
    public String getBatch() {
        return batch;
    }

    /**
     * @param batch The batch to set.
     */
    public void setBatch(String batch) {
        this.batch = batch;
    }

    /**
     * @return Returns the claimNumber.
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * @param claimNumber The claimNumber to set.
     */
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the createdDate.
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate The createdDate to set.
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return Returns the crop.
     */
    public String[] getCrop() {
        return crop;
    }

    /**
     * @param crop The crop to set.
     */
    public void setCrop(String[] crop) {
        this.crop = crop;
    }

    /**
     * @return Returns the initiatedBy.
     */
    public String getInitiatedBy() {
        return initiatedBy;
    }

    /**
     * @param initiatedBy The initiatedBy to set.
     */
    public void setInitiatedBy(String initiatedBy) {
        this.initiatedBy = initiatedBy;
    }

    /**
     * @return Returns the region.
     */
    public String[] getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String[] region) {
        this.region = region;
    }

    /**
     * @return Returns the reportingLocation.
     */
    public String[] getReportingLocation() {
        return reportingLocation;
    }

    /**
     * @param reportingLocation The reportingLocation to set.
     */
    public void setReportingLocation(String[] reportingLocation) {
        this.reportingLocation = reportingLocation;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String[] getResponsibleLocation() {
        return responsibleLocation;
    }

    /**
     * @param responsibleLocation The responsibleLocation to set.
     */
    public void setResponsibleLocation(String[] responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    /**
     * @return Returns the salesYear.
     */
    public String[] getSalesYear() {
        return salesYear;
    }

    /**
     * @param salesYear The salesYear to set.
     */
    public void setSalesYear(String[] salesYear) {
        this.salesYear = salesYear;
    }

    /**
     * @return Returns the status.
     */
    public String[] getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String[] status) {
        this.status = status;
    }

    /**
     * @return Returns the variety.
     */
    public String getVariety() {
        return variety;
    }

    /**
     * @param variety The variety to set.
     */
    public void setVariety(String variety) {
        this.variety = variety;
    }


    public String[] getQualityIssue() {
        return qualityIssue;
    }

    public void setQualityIssue(String[] qualityIssue) {
        this.qualityIssue = qualityIssue;
    }


    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }

    public String getFeedbackCategoryId() {
        return feedbackCategoryId;
    }

    public void setFeedbackCategoryId(String feedbackCategoryId) {
        this.feedbackCategoryId = feedbackCategoryId;
    }

    public String getComplaintTypeId() {
        return complaintTypeId;
    }

    public void setComplaintTypeId(String complaintTypeId) {
        this.complaintTypeId = complaintTypeId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getComplaintEntryTypeId() {
        return complaintEntryTypeId;
    }

    public void setComplaintEntryTypeId(String complaintEntryTypeId) {
        this.complaintEntryTypeId = complaintEntryTypeId;
    }
}
