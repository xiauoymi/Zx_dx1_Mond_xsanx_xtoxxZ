package com.monsanto.wst.ccas.model;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 15, 2010 Time: 4:46:00 PM To change this template use File |
 * Settings | File Templates.
 */
public class ComplaintInvestigation implements Serializable{
  private Long id;
  private InitiatorSample initiatorSample;
  private SiteSample siteSample;
  private String initiatorComments;
  private String siteComments;
  private String qualityScores;
  private String deliveryInfo;

  public ComplaintInvestigation() {
    this.initiatorSample = new InitiatorSample();
    this.siteSample = new SiteSample();
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public InitiatorSample getInitiatorSample() {
    return initiatorSample;
  }

  public void setInitiatorSample(InitiatorSample initiatorSample) {
    this.initiatorSample = initiatorSample;
  }

  public SiteSample getSiteSample() {
    return siteSample;
  }

  public void setSiteSample(SiteSample siteSample) {
    this.siteSample = siteSample;
  }

  public String getInitiatorComments() {
    return initiatorComments;
  }

  public void setInitiatorComments(String initiatorComments) {
    this.initiatorComments = initiatorComments;
  }

  public String getSiteComments() {
    return siteComments;
  }

  public void setSiteComments(String siteComments) {
    this.siteComments = siteComments;
  }

  public String getQualityScores() {
    return qualityScores;
  }

  public void setQualityScores(String qualityScores) {
    this.qualityScores = qualityScores;
  }

  public String getDeliveryInfo() {
    return deliveryInfo;
  }

  public void setDeliveryInfo(String deliveryInfo) {
    this.deliveryInfo = deliveryInfo;
  }
}
