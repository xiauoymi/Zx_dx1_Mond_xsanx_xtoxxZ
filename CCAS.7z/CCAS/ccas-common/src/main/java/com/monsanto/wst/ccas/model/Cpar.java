/*
 * Created on Feb 18, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.audits.CheckboxGroup;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.controller.attachmentController.AttachmentInfo;
import com.monsanto.wst.ccas.dao.ProgramConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.io.Serializable;

import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

/**
 * @author jbrahmb <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class Cpar extends ObjectWithCheckboxGroups implements Serializable {

    private String cpar_id;

    private String[] complaint_id;

    private String stop_sale_id;

    private String stop_sale_number;

    private String audit_finding_id;

    private String audit_id;

    private String audit_number;

    private String control_number;
    private String claim_number;

    private String status_id;

    private boolean suppress_overdue_notice;

    private String created_by;

    private String issue_year;

    private String initiated_by;

    private String report_initiator_email;
    private String report_initiator_id;

    private String report_date;

    private String report_due_date;

    private String finding_type;

    private String iso_standard;

    private String quality_standard;

    private String generator;

    private String mgmt_approval_person;
    private String mgmt_approval_person_id;


    private String mgmt_approval_date;

    private String mgmt_approval_comments;

    private String site_manager;

    private String effectiveness_evaluator;

    private String filing_location;

    private String responsible_location;

    private String investigation_findings;

    private String investigation_findings_person;

    private String investigation_findings_date;

    private String containment_actions_person;
    private String containment_actions_person_id;

    private String containment_actions_date;

    private String containment_actions;

    private String root_cause_person;
    private String root_cause_person_id;

    private String root_cause_date;

    private String root_cause;

    private String long_term_corrective_action_person;
    private String long_term_corrective_action_person_id;

    private String long_term_corrective_action_date;

    private String long_term_corrective_action;

    private boolean long_term_corrective_action_items_complete;

    private String evaluation_person;
    private String evaluation_person_id;

    private String evaluation_date;

    private String evaluation_comments;

    private String evaluation_effective;

    private boolean evaluation_not_applicable;

    private String mgt_app_extension;

    private String car_flag;

    private String region;

    private String responsibleRegionId;

    private String continual_Improvements;

    private String row_entry_date;

    private String row_modify_date;

    private String row_task_id;

    private String row_user_id;

    private String complaintBusinessId;

    private String functionId;

    private Map<String, AttachmentInfo> cparAttachments = new LinkedHashMap<String, AttachmentInfo>();


    private String costOfQuality;

    private String costOfQualityNumeric;

    private int businessId;

    private Map nonconformanceTypeMap;

    private String oldStatusId;

    private String deleted;

    private int type;

    private String complaintEntryType;

    private String filingProgramId;

    private String responsibleProgramId;

    private int subFunctionId;
    private String[] subFunctionsSelected;

    private IssueList<Issue> issues;

    private String closingPersonId;

    private String closingDate;

    private String expectedDate;

    private String organization;

    private String issueCategoryId;

    private LocationOtherInfo locationOtherInfo;

    private String long_term_implemented_action;

    private String departmentAffectedId;

    private String sourceCparId;

    private String sourceControlNumber;

    private String initiatedByUserId;

    private String siteManagerUserId;
    private String siteManagerUserMId;

    private String crop_id;

    public String getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(String crop_id) {
        this.crop_id = crop_id;
    }


    public String getInitiatedByUserId() {
        return initiatedByUserId;
    }

    public void setInitiatedByUserId(String initiatedByUserId) {
        this.initiatedByUserId = initiatedByUserId;
    }

    public String getSiteManagerUserId() {
        return siteManagerUserId;
    }

    public void setSiteManagerUserId(String siteManagerUserId) {
        this.siteManagerUserId = siteManagerUserId;
    }




    public String getLong_term_implemented_action() {
        return long_term_implemented_action;
    }

    public void setLong_term_implemented_action(String long_term_implemented_action) {
        this.long_term_implemented_action = long_term_implemented_action;
    }

    public LocationOtherInfo getLocationOtherInfo() {
        if (locationOtherInfo == null) locationOtherInfo = new LocationOtherInfo();
        return locationOtherInfo;
    }

    public void setLocationOtherInfo(LocationOtherInfo locationOtherInfo) {
        this.locationOtherInfo = locationOtherInfo;
    }

    public String getResponsibleRegionId() {
        return responsibleRegionId;
    }

    public void setResponsibleRegionId(String responsibleRegionId) {
        this.responsibleRegionId = responsibleRegionId;
    }

    public String getFilingProgramId() {
        return StringUtils.isNullOrEmpty(filingProgramId) ? ProgramConstants.PROGRAM_ID_DEFAULT : filingProgramId;
    }

    public void setFilingProgramId(String filingProgramId) {
        this.filingProgramId = filingProgramId;
    }

    public String getResponsibleProgramId() {
        return StringUtils.isNullOrEmpty(responsibleProgramId) ? ProgramConstants.PROGRAM_ID_DEFAULT : responsibleProgramId;
    }

    public void setResponsibleProgramId(String responsibleProgramId) {
        this.responsibleProgramId = responsibleProgramId;
    }

    public int getSubFunctionId() {
        return subFunctionId;
    }

    public void setSubFunctionId(int subFunctionId) {
        this.subFunctionId = subFunctionId;
    }

    public String getCostOfQuality() {
        return costOfQuality;
    }


    public void setCostOfQuality(String costOfQuality) {
        this.costOfQuality = costOfQuality;
    }

    public Map<String, AttachmentInfo> getCparAttachments() {
        return cparAttachments;
    }

    public void setCparAttachments(Map<String, AttachmentInfo> cparAttachments) {
        this.cparAttachments = cparAttachments;
    }

    public Cpar() {
    }

    /**
     * @return Returns the stop_sale_number.
     */
    public String getStop_sale_number() {
        return stop_sale_number;
    }

    /**
     * @param stop_sale_number The stop_sale_number to set.
     */
    public void setStop_sale_number(String stop_sale_number) {
        this.stop_sale_number = stop_sale_number;
    }

    /**
     * @return Returns the audit_number.
     */
    public String getAudit_number() {
        return audit_number;
    }

    /**
     * @param audit_number The audit_number to set.
     */
    public void setAudit_number(String audit_number) {
        this.audit_number = audit_number;
    }

    /**
     * @return Returns the audit_id.
     */
    public String getAudit_id() {
        return audit_id;
    }

    /**
     * @param audit_id The audit_id to set.
     */
    public void setAudit_id(String audit_id) {
        this.audit_id = audit_id;
    }

    /**
     * @return Returns the audit_finding_id.
     */
    public String getAudit_finding_id() {
        return audit_finding_id;
    }

    /**
     * @param audit_finding_id The audit_finding_id to set.
     */
    public void setAudit_finding_id(String audit_finding_id) {
        this.audit_finding_id = audit_finding_id;
    }

    /**
     * @return Returns the car_flag.
     */
    public String getCar_flag() {
        return car_flag;
    }

    /**
     * @param car_flag The car_flag to set.
     */
    public void setCar_flag(String car_flag) {
        this.car_flag = car_flag;
    }

    /**
     * @return Returns the claim_number.
     */
    public String getClaim_number() {
        return claim_number;
    }

    /**
     * @param claim_number The claim_number to set.
     */
    public void setClaim_number(String claim_number) {
        this.claim_number = claim_number;
    }

    /**
     * @return Returns the complaint_id.
     */
    public String[] getComplaint_id() {
        return complaint_id;
    }

    /**
     * @param complaint_id The complaint_id to set.
     */
    public void setComplaint_id(String[] complaint_id) {
        this.complaint_id = complaint_id;
    }

    /**
     * @return Returns the containment_actions.
     */
    public String getContainment_actions() {
        return containment_actions;
    }


    /**
     * @param containment_actions The containment_actions to set.
     */
    public void setContainment_actions(String containment_actions) {
        this.containment_actions = containment_actions;
    }

    /**
     * @return Returns the control_number.
     */
    public String getControl_number() {
        return control_number;
    }

    /**
     * @param control_number The control_number to set.
     */
    public void setControl_number(String control_number) {
        this.control_number = control_number;
    }

    /**
     * @return Returns the cpar_id.
     */
    public String getCpar_id() {
        return cpar_id;
    }

    /**
     * @param cpar_id The cpar_id to set.
     */
    public void setCpar_id(String cpar_id) {
        this.cpar_id = cpar_id;
    }

    /**
     * @return Returns the created_by.
     */
    public String getCreated_by() {
        return created_by;
    }

    /**
     * @param created_by The created_by to set.
     */
    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    /**
     * @return Returns the effectiveness_evaluator.
     */
    public String getEffectiveness_evaluator() {
        return effectiveness_evaluator;
    }

    /**
     * @param effectiveness_evaluator The effectiveness_evaluator to set.
     */
    public void setEffectiveness_evaluator(String effectiveness_evaluator) {
        this.effectiveness_evaluator = effectiveness_evaluator;
    }

    /**
     * @return Returns the evaluation_date.
     */
    public String getEvaluation_date() {
        return evaluation_date;
    }

    /**
     * @param evaluation_date The evaluation_date to set.
     */
    public void setEvaluation_date(String evaluation_date) {
        this.evaluation_date = evaluation_date;
    }

    /**
     * @return Returns the filing_location.
     */
    public String getFiling_location() {
        return filing_location;
    }

    /**
     * @param filing_location The filing_location to set.
     */
    public void setFiling_location(String filing_location) {
        this.filing_location = filing_location;
    }

    /**
     * @return Returns the finding_type.
     */
    public String getFinding_type() {
        return finding_type;
    }

    /**
     * @param finding_type The finding_type to set.
     */
    public void setFinding_type(String finding_type) {
        this.finding_type = finding_type;
    }

    /**
     * @return Returns the generator.
     */
    public String getGenerator() {
        return generator;
    }

    /**
     * @param generator The generator to set.
     */
    public void setGenerator(String generator) {
        this.generator = generator;
    }

    /**
     * @return Returns the initiated_by.
     */
    public String getInitiated_by() {
        return initiated_by;
    }

    /**
     * @param initiated_by The initiated_by to set.
     */
    public void setInitiated_by(String initiated_by) {
        this.initiated_by = initiated_by;
    }

    /**
     * @return Returns the investigation_findings.
     */
    public String getInvestigation_findings() {
        return investigation_findings;
    }

    /**
     * @param investigation_findings The investigation_findings to set.
     */
    public void setInvestigation_findings(String investigation_findings) {
        this.investigation_findings = investigation_findings;
    }

    /**
     * @return Returns the investigation_findings_person.
     */
    public String getInvestigation_findings_person() {
        return investigation_findings_person;
    }

    /**
     * @param investigation_findings_person The investigation_findings_person to set.
     */
    public void setInvestigation_findings_person(String investigation_findings_person) {
        this.investigation_findings_person = investigation_findings_person;
    }

    /**
     * @return Returns the investigation_findings_date.
     */
    public String getInvestigation_findings_date() {
        return investigation_findings_date;
    }

    /**
     * @param investigation_findings_date The investigation_findings_date to set.
     */
    public void setInvestigation_findings_date(String investigation_findings_date) {
        this.investigation_findings_date = investigation_findings_date;
    }

    /**
     * @return Returns the iso_standard.
     */
    public String getIso_standard() {
        return iso_standard;
    }

    /**
     * @param iso_standard The iso_standard to set.
     */
    public void setIso_standard(String iso_standard) {
        this.iso_standard = iso_standard;
    }


    public String getQuality_standard() {
        return quality_standard;
    }

    public void setQuality_standard(String quality_standard) {
        this.quality_standard = quality_standard;
    }

    /**
     * @return Returns the issue_year.
     */
    public String getIssue_year() {
        return issue_year;
    }

    /**
     * @param issue_year The issue_year to set.
     */
    public void setIssue_year(String issue_year) {
        this.issue_year = issue_year;
    }

    /**
     * @return Returns the long_term_corrective_action.
     */
    public String getLong_term_corrective_action() {
        return long_term_corrective_action;
    }

    /**
     * @param long_term_corrective_action The long_term_corrective_action to set.
     */
    public void setLong_term_corrective_action(
            String long_term_corrective_action) {
        this.long_term_corrective_action = long_term_corrective_action;
    }

    public String getEvaluation_comments() {
        return evaluation_comments;
    }

    public void setEvaluation_comments(String evaluation_comments) {
        this.evaluation_comments = evaluation_comments;
    }

    /**
     * @return Returns the evaluation_person
     */
    public String getEvaluation_person() {
        return evaluation_person;
    }


    public void setEvaluation_person(
            String eval_person) {
        this.evaluation_person = eval_person;
    }

    /**
     * @return Returns the evaluation_effective
     */
    public String getEvaluation_effective() {
        return evaluation_effective;
    }


    public void setEvaluation_effective(
            String eval_effective) {
        this.evaluation_effective = eval_effective;
    }

    public String getContinual_Improvements() {
        return continual_Improvements;
    }

    /**
     * @param continual_Improvements The continual_Improvements to set.
     */

    public void setContinual_Improvements(String continual_Improvements) {
        this.continual_Improvements = continual_Improvements;
    }

    public boolean isEvaluation_not_applicable() {
        return evaluation_not_applicable;
    }


    public void setEvaluation_not_applicable(boolean evaluation_not_applicable) {
        this.evaluation_not_applicable = evaluation_not_applicable;
    }

    public String getMgt_app_extension() {
        return mgt_app_extension;
    }

    public void setMgt_app_extension(String mgt_app_extension) {
        this.mgt_app_extension = mgt_app_extension;
    }

    /**
     * @return Returns the mgmt_approval_date.
     */
    public String getMgmt_approval_date() {
        return mgmt_approval_date;
    }

    /**
     * @param mgmt_approval_date The mgmt_approval_date to set.
     */
    public void setMgmt_approval_date(String mgmt_approval_date) {
        this.mgmt_approval_date = mgmt_approval_date;
    }

    public String getMgmt_approval_comments() {
        return mgmt_approval_comments;
    }

    public void setMgmt_approval_comments(String mgmt_approval_comments) {
        this.mgmt_approval_comments = mgmt_approval_comments;
    }

    /**
     * @return Returns the region.
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return Returns the report_date.
     */
    public String getReport_date() {
        return report_date;
    }

    /**
     * @param report_date The report_date to set.
     */
    public void setReport_date(String report_date) {
        this.report_date = report_date;
    }

    public String getReport_due_date() {
        return report_due_date;
    }

    public void setReport_due_date(String report_due_date) {
        this.report_due_date = report_due_date;
    }

    /**
     * @return Returns the responsible_location.
     */
    public String getResponsible_location() {
        return responsible_location;
    }

    /**
     * @param responsible_location The responsible_location to set.
     */
    public void setResponsible_location(String responsible_location) {
        this.responsible_location = responsible_location;
    }

    public boolean isSuppress_overdue_notice() {
        return suppress_overdue_notice;
    }

    public void setSuppress_overdue_notice(boolean suppress_overdue_notice) {
        this.suppress_overdue_notice = suppress_overdue_notice;
    }

    /**
     * @return Returns the root_cause.
     */
    public String getRoot_cause() {
        return root_cause;
    }

    /**
     * @param root_cause The root_cause to set.
     */
    public void setRoot_cause(String root_cause) {
        this.root_cause = root_cause;
    }

    /**
     * @return Returns the row_entry_date.
     */
    public String getRow_entry_date() {
        return row_entry_date;
    }

    /**
     * @param row_entry_date The row_entry_date to set.
     */
    public void setRow_entry_date(String row_entry_date) {
        this.row_entry_date = row_entry_date;
    }

    /**
     * @return Returns the row_modify_date.
     */
    public String getRow_modify_date() {
        return row_modify_date;
    }

    /**
     * @param row_modify_date The row_modify_date to set.
     */
    public void setRow_modify_date(String row_modify_date) {
        this.row_modify_date = row_modify_date;
    }

    /**
     * @return Returns the row_task_id.
     */
    public String getRow_task_id() {
        return row_task_id;
    }

    /**
     * @param row_task_id The row_task_id to set.
     */
    public void setRow_task_id(String row_task_id) {
        this.row_task_id = row_task_id;
    }

    /**
     * @return Returns the row_user_id.
     */
    public String getRow_user_id() {
        return row_user_id;
    }

    /**
     * @param row_user_id The row_user_id to set.
     */
    public void setRow_user_id(String row_user_id) {
        this.row_user_id = row_user_id;
    }

    /**
     * @return Returns the site_manager.
     */
    public String getSite_manager() {
        return site_manager;
    }

    /**
     * @param site_manager The site_manager to set.
     */
    public void setSite_manager(String site_manager) {
        this.site_manager = site_manager;
    }

    /**
     * @return Returns the status_id.
     */
    public String getStatus_id() {
        return status_id;
    }

    /**
     * @param status_id The status_id to set.
     */
    public void setStatus_id(String status_id) {
        this.status_id = status_id;
    }

    /**
     * @return Returns the stop_sale_id.
     */
    public String getStop_sale_id() {
        return stop_sale_id;
    }

    /**
     * @param stop_sale_id The stop_sale_id to set.
     */
    public void setStop_sale_id(String stop_sale_id) {
        this.stop_sale_id = stop_sale_id;
    }

    /**
     * @return Returns the containment_actions_date.
     */
    public String getContainment_actions_date() {
        return containment_actions_date;
    }

    /**
     * @param containment_actions_date The containment_actions_date to set.
     */
    public void setContainment_actions_date(String containment_actions_date) {
        this.containment_actions_date = containment_actions_date;
    }

    /**
     * @return Returns the containment_actions_person.
     */
    public String getContainment_actions_person() {
        return containment_actions_person;
    }

    /**
     * @param containment_actions_person The containment_actions_person to set.
     */
    public void setContainment_actions_person(String containment_actions_person) {
        this.containment_actions_person = containment_actions_person;
    }

    /**
     * @return Returns the long_term_corrective_action_date.
     */
    public String getLong_term_corrective_action_date() {
        return long_term_corrective_action_date;
    }

    /**
     * @param long_term_corrective_action_date
     *         The long_term_corrective_action_date to set.
     */
    public void setLong_term_corrective_action_date(
            String long_term_corrective_action_date) {
        this.long_term_corrective_action_date = long_term_corrective_action_date;
    }

    /**
     * @return Returns the long_term_corrective_action_person.
     */
    public String getLong_term_corrective_action_person() {
        return long_term_corrective_action_person;
    }

    /**
     * @param long_term_corrective_action_person
     *         The long_term_corrective_action_person to set.
     */
    public void setLong_term_corrective_action_person(
            String long_term_corrective_action_person) {
        this.long_term_corrective_action_person = long_term_corrective_action_person;
    }

    public boolean isLong_term_corrective_action_items_complete() {
        return long_term_corrective_action_items_complete;
    }

    public void setLong_term_corrective_action_items_complete(boolean long_term_corrective_action_items_complete) {
        this.long_term_corrective_action_items_complete = long_term_corrective_action_items_complete;
    }

    /**
     * @return Returns the mgmt_approval_person.
     */
    public String getMgmt_approval_person() {
        return mgmt_approval_person;
    }

    /**
     * @param mgmt_approval_person The mgmt_approval_person to set.
     */
    public void setMgmt_approval_person(String mgmt_approval_person) {
        this.mgmt_approval_person = mgmt_approval_person;
    }

    /**
     * @return Returns the root_cause_date.
     */
    public String getRoot_cause_date() {
        return root_cause_date;
    }

    /**
     * @param root_cause_date The root_cause_date to set.
     */
    public void setRoot_cause_date(String root_cause_date) {
        this.root_cause_date = root_cause_date;
    }

    /**
     * @return Returns the root_cause_person.
     */
    public String getRoot_cause_person() {
        return root_cause_person;
    }

    /**
     * @param root_cause_person The root_cause_person to set.
     */
    public void setRoot_cause_person(String root_cause_person) {
        this.root_cause_person = root_cause_person;
    }

    /**
     * @return Returns the report_initiator_email.
     */
    public String getReport_initiator_email() {
        return report_initiator_email;
    }

    /**
     * @param report_initiator_email The report_initiator_email to set.
     */
    public void setReport_initiator_email(String report_initiator_email) {
        this.report_initiator_email = report_initiator_email;
    }


    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String toString() {

        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("cpar_id :").append(cpar_id).append("\n");
        stringBuffer.append("complaint_id :").append(complaint_id).append("\n");
        stringBuffer.append("stop_sale_id :").append(stop_sale_id).append("\n");
        stringBuffer.append("stop_sale_number :").append(stop_sale_number).append("\n");
        stringBuffer.append("audit_finding_id :").append(audit_finding_id).append("\n");
        stringBuffer.append("audit_id :").append(audit_id).append("\n");
        stringBuffer.append("audit_number :").append(audit_number).append("\n");
        stringBuffer.append("control_number :").append(control_number).append("\n");
        stringBuffer.append("claim_number :").append(claim_number).append("\n");
        stringBuffer.append("status_id :").append(status_id).append("\n");
        stringBuffer.append("suppress_overdue_notice :").append(suppress_overdue_notice).append("\n");
        stringBuffer.append("created_by :").append(created_by).append("\n");
        stringBuffer.append("issue_year :").append(issue_year).append("\n");
        stringBuffer.append("initiated_by :").append(initiated_by).append("\n");
        stringBuffer.append("report_initiator_email :").append(report_initiator_email).append("\n");
        stringBuffer.append("report_date :").append(report_date).append("\n");
        stringBuffer.append("finding_type :").append(finding_type).append("\n");
        stringBuffer.append("iso_standard :").append(iso_standard).append("\n");
        stringBuffer.append("generator :").append(generator).append("\n");
        stringBuffer.append("mgmt_approval_person :").append(mgmt_approval_person).append("\n");
        stringBuffer.append("mgmt_approval_date :").append(mgmt_approval_date).append("\n");
        stringBuffer.append("mgmt_approval_comments :").append(mgmt_approval_comments).append("\n");
        stringBuffer.append("site_manager :").append(site_manager).append("\n");
        stringBuffer.append("effectiveness_evaluator :").append(effectiveness_evaluator).append("\n");
        stringBuffer.append("filing_location :").append(filing_location).append("\n");
        stringBuffer.append("responsible_location :").append(responsible_location).append("\n");
        stringBuffer.append("investigation_findings :").append(investigation_findings).append("\n");
        stringBuffer.append("investigation_findings_person :").append(investigation_findings_person).append("\n");
        stringBuffer.append("investigation_findings_date :").append(investigation_findings_date).append("\n");
        stringBuffer.append("containment_actions_person :").append(containment_actions_person).append("\n");
        stringBuffer.append("containment_actions_date :").append(containment_actions_date).append("\n");
        stringBuffer.append("containment_actions :").append(containment_actions).append("\n");
        stringBuffer.append("root_cause_person :").append(root_cause_person).append("\n");
        stringBuffer.append("root_cause_date :").append(root_cause_date).append("\n");
        stringBuffer.append("long_term_corrective_action_person :").append(long_term_corrective_action_person).append("\n");
        stringBuffer.append("long_term_corrective_action_date :").append(long_term_corrective_action_date).append("\n");
        stringBuffer.append("long_term_corrective_action :").append(long_term_corrective_action).append("\n");
        stringBuffer.append("evaluation_person :").append(evaluation_person).append("\n");
        stringBuffer.append("evaluation_date :").append(evaluation_date).append("\n");
        stringBuffer.append("evaluation_comments :").append(evaluation_comments).append("\n");
        stringBuffer.append("evaluation_effective :").append(root_cause_person).append("\n");
        stringBuffer.append("evaluation_not_applicable :").append(root_cause_person).append("\n");
        stringBuffer.append("car_flag :").append(root_cause_person).append("\n");
        stringBuffer.append("region :").append(root_cause_person).append("\n");
        stringBuffer.append("continual_Improvements :").append(root_cause_person).append("\n");
        stringBuffer.append("row_entry_date :").append(root_cause_person).append("\n");
        stringBuffer.append("row_modify_date :").append(root_cause_person).append("\n");
        stringBuffer.append("row_task_id :").append(row_task_id).append("\n");
        stringBuffer.append("row_user_id :").append(row_user_id).append("\n");
        stringBuffer.append("costOfQuality :").append(costOfQualityNumeric).append("\n");
        stringBuffer.append("costOfQualityComments :").append(costOfQuality).append("\n");
        stringBuffer.append("functionId :").append(functionId).append("\n");
        stringBuffer.append("closingPersonId :").append(closingPersonId).append("\n");
        return stringBuffer.toString();
    }

    public void setBusinessId(int businessId) {
        this.businessId = businessId;
    }

    public int getBusinessId() {
        return businessId;
    }

    public void setNonconformanceTypeMap(Map nonconformanceTypeMap) {
        this.nonconformanceTypeMap = nonconformanceTypeMap;
    }

    public Map getNonconformanceTypeMap() {
        return nonconformanceTypeMap;
    }

    public void setOldStatusId(String oldStatusId) {
        this.oldStatusId = oldStatusId;
    }

    public String getOldStatusId() {
        return oldStatusId;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public int getType() {
        return type;
    }

    public IssueList<Issue> getIssues() {
        return issues == null ? new IssueList<Issue>() : issues;
    }

    public void setIssues(IssueList<Issue> issues) {
        this.issues = issues;
    }

    public void setType(int type) {
        this.type = type;
        String cparFlag = (type == CparConstants.GEN_FINDING_OBJ_TYPE_CAR) ? "Y" : "N";
        setCar_flag(cparFlag);
    }

    public StringBuffer getControlSequence(boolean isMCAS, boolean isSBFAS, boolean isBIOTECHFAS) {
        StringBuffer controlSeq = new StringBuffer();
        CparType cparType = CparType.getType(getType());
        String prefix = cparType.getControlNumberPrefix();
        performContinualImprovementCheck(controlSeq, prefix);
        MCASLogUtil.logError("After performContinualImprovement check" , new Exception());


        if (isMCAS)                                                         {
            controlSeq.append(getResponsible_location().trim()).append("-");
        MCASLogUtil.logError("After appending responsible location "+controlSeq , new Exception());
        }
        else if(isSBFAS)
            controlSeq.append(getFiling_location().trim()).append("=");
        else if(isBIOTECHFAS)
            controlSeq.append(getResponsible_location().trim()).append("-");
        else
            controlSeq.append(getFiling_location().trim()).append("-");

        return controlSeq;
    }

    private void performContinualImprovementCheck(StringBuffer controlSeq, String prefix) {
        String continualImprovements = getContinual_Improvements();
        if (!StringUtils.isNullOrEmpty(continualImprovements) && "2".equalsIgnoreCase(continualImprovements)) {
            if (CparConstants.PAR_CONTROL_NUMBER_PREFIX.equalsIgnoreCase(prefix)) {
                prefix = CparConstants.CI_CONTROL_NUMBER_PREFIX;
            }
        }
        controlSeq.append(prefix);
    }

    public String getComplaintEntryType() {
        return complaintEntryType;
    }

    public void setComplaintEntryType(String complaintEntryType) {
        this.complaintEntryType = complaintEntryType;
    }

    public void populateCparFindingData(Cpar cpar, Cpar cparReqObj) {
        cpar.setRegion(cparReqObj.getRegion());
        cpar.setFiling_location(cparReqObj.getFiling_location());
        cpar.setResponsible_location(cparReqObj.getResponsible_location());
        cpar.setReport_date(cparReqObj.getReport_date());
        cpar.setInitiated_by(cparReqObj.getInitiated_by());
        cpar.setInitiatedByUserId(cparReqObj.getInitiatedByUserId());
        cpar.setSiteManagerUserId(cparReqObj.getSiteManagerUserId());
        cpar.setAudit_finding_id(cparReqObj.getAudit_finding_id());
        cpar.setAudit_number(cparReqObj.getAudit_number());
        cpar.setAudit_id(cparReqObj.getAudit_id());
        cpar.setFunctionId(cparReqObj.getFunctionId());
        cpar.setInvestigation_findings(cparReqObj.getInvestigation_findings());
        cpar.setType(cparReqObj.getType());
        cpar.setClosingPersonId(cparReqObj.getClosingPersonId());
        cpar.setClosingDate(cparReqObj.getClosingDate());
        cpar.setSourceControlNumber(cparReqObj.getSourceControlNumber());
        cpar.setSourceCparId(cparReqObj.getSourceCparId());
    }

    public void populateStopSaleData(Cpar cpar, Cpar cparReqObj) {
        cpar.setRegion(cparReqObj.getRegion());
        cpar.setFiling_location(cparReqObj.getFiling_location());
        cpar.setResponsible_location(cparReqObj.getResponsible_location());
        cpar.setIssue_year(cparReqObj.getIssue_year());
        cpar.setInvestigation_findings(cparReqObj.getInvestigation_findings());
        cpar.setRoot_cause(cparReqObj.getRoot_cause());
        cpar.setContainment_actions(cparReqObj.getContainment_actions());
        cpar.setLong_term_corrective_action(cparReqObj.getLong_term_corrective_action());
        cpar.setStop_sale_id(cparReqObj.getStop_sale_id());
        cpar.setStop_sale_number(cparReqObj.getStop_sale_number());
        cpar.setGenerator(cparReqObj.getGenerator());
        cpar.setType(cparReqObj.getType());
    }

    public String[] getSubFunctionsSelected() {
        return subFunctionsSelected;
    }

    public void setSubFunctionsSelected(String[] subFunctionsSelected) {
        this.subFunctionsSelected = subFunctionsSelected;
    }

    public String getreplacementValue(String locale) {
        if (CparConstants.GEN_FINDING_OBJ_TYPE_CI == type)
            return " " + I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.project") + " ";
        else
            return " " + I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.incident") + " ";
    }

    public String getClosingPersonId() {
        return closingPersonId;
    }

    public void setClosingPersonId(String closingPersonId) {
        this.closingPersonId = closingPersonId;
    }

    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

    public String getExpectedDate() {
        return expectedDate;
    }

    public void setExpectedDate(String expectedDate) {
        this.expectedDate = expectedDate;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String org) {
        this.organization = org;
    }

    public String getIssueCategoryId() {
        return issueCategoryId;
    }

    public void setIssueCategoryId(String issueCategoryId) {
        this.issueCategoryId = issueCategoryId;
    }

    public String getCostOfQualityNumeric() {
        return costOfQualityNumeric;
    }

    public void setCostOfQualityNumeric(String costOfQualityNumeric) {
        this.costOfQualityNumeric = costOfQualityNumeric;
    }

    public String getDepartmentAffectedId() {
        return departmentAffectedId;
    }

    public void setDepartmentAffectedId(String departmentAffectedId) {
        this.departmentAffectedId = departmentAffectedId;
    }

    public String getSourceCparId() {
        return sourceCparId;
    }

    public void setSourceCparId(String sourceCparId) {
        this.sourceCparId = sourceCparId;
    }

    public String getSourceControlNumber() {
        return sourceControlNumber;
    }

    public void setSourceControlNumber(String sourceControlNumber) {
        this.sourceControlNumber = sourceControlNumber;
    }

    public String getMgmt_approval_person_id() {
        return mgmt_approval_person_id;
    }

    public void setMgmt_approval_person_id(String mgmt_approval_person_id) {
        this.mgmt_approval_person_id = mgmt_approval_person_id;
    }

    public String getContainment_actions_person_id() {
        return containment_actions_person_id;
    }

    public void setContainment_actions_person_id(String containment_actions_person_id) {
        this.containment_actions_person_id = containment_actions_person_id;
    }

    public String getRoot_cause_person_id() {
        return root_cause_person_id;
    }

    public void setRoot_cause_person_id(String root_cause_person_id) {
        this.root_cause_person_id = root_cause_person_id;
    }

    public String getLong_term_corrective_action_person_id() {
        return long_term_corrective_action_person_id;
    }

    public void setLong_term_corrective_action_person_id(String long_term_corrective_action_person_id) {
        this.long_term_corrective_action_person_id = long_term_corrective_action_person_id;
    }

    public String getEvaluation_person_id() {
        return evaluation_person_id;
    }

    public void setEvaluation_person_id(String evaluation_person_id) {
        this.evaluation_person_id = evaluation_person_id;
    }

    public String getSiteManagerUserMId() {
        return siteManagerUserMId;
    }

    public void setSiteManagerUserMId(String siteManagerUserMId) {
        this.siteManagerUserMId = siteManagerUserMId;
    }

    public String getReport_initiator_id() {
        return report_initiator_id;
    }

    public void setReport_initiator_id(String report_initiator_id) {
        this.report_initiator_id = report_initiator_id;
    }
    }
