package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;

import java.util.List;

/**
 * Date: Aug 7, 2009
 * Time: 9:15:23 AM
 */
public class CparApprovedStatus extends CparStatus {
    public void validate(Cpar cpar, List<String> errorList) {
        if (!isNonConformance(cpar)) {
            if (isContinualImprovement(cpar))
                checkForEmpty(cpar.getInvestigation_findings(), errorList, getInvestigationFindingsKey(cpar));
            checkForEmpty(cpar.getRoot_cause(), errorList, getRootCauseKey(cpar));
            checkForEmpty(cpar.getLong_term_corrective_action(), errorList, getLongTermActionKey(cpar));
            //Commented for PCR0437462
            //if (!isContinualImprovement(cpar))
            //    checkForEmpty(cpar.getEvaluation_comments(), errorList, getEvalForEffectiveKey(cpar));
        }
    }

    private boolean isContinualImprovement(Cpar cpar) {
        return cpar.getType() == CparConstants.GEN_FINDING_OBJ_TYPE_CI;
    }

    private boolean isNonConformance(Cpar cpar) {
        return cpar.getType() == CparConstants.GEN_FINDING_OBJ_TYPE_NC;
    }

    private String getInvestigationFindingsKey(Cpar cpar) {
        return "com.wst.ccas.cpar.projectTestEmpty";
    }

    private String getRootCauseKey(Cpar cpar) {
        return isContinualImprovement(cpar) ? "com.wst.ccas.cpar.projectresultsEmpty" : "com.wst.ccas.cpar.rootCauseEmpty";
    }

    private String getLongTermActionKey(Cpar cpar) {
        return isContinualImprovement(cpar) ? "com.wst.ccas.cpar.projectEvalEmpty" : "com.wst.ccas.cpar.longTermActionEmpty";
    }

    private String getEvalForEffectiveKey(Cpar cpar) {
        return "com.wst.ccas.cpar.EvalForEffectiveEmpty";
    }
}
