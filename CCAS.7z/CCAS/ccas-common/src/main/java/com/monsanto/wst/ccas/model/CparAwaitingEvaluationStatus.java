package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;

import java.util.List;

/**
 * Date: Aug 7, 2009
 * Time: 9:11:03 AM
 */
public class CparAwaitingEvaluationStatus extends CparStatus {
    public void validate(Cpar cpar, List<String> errorList) {
        if (isCAR(cpar) || isPAR(cpar)) {
            checkForEmpty(cpar.getRoot_cause(), errorList, "com.wst.ccas.cpar.rootCauseEmpty");
            checkForEmpty(cpar.getLong_term_corrective_action(), errorList, "com.wst.ccas.cpar.longTermActionEmpty");
        }
    }

    private boolean isPAR(Cpar cpar) {
        return cpar.getType() == CparConstants.GEN_FINDING_OBJ_TYPE_PAR;
    }

    private boolean isCAR(Cpar cpar) {
        return cpar.getType() == CparConstants.GEN_FINDING_OBJ_TYPE_CAR;
    }
}
