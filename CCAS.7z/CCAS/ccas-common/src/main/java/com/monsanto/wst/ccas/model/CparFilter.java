/*
 * Created on Jun 15, 2005
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.CheckboxGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

/**
 * @author rdesai2
 */
public class CparFilter extends ObjectWithCheckboxGroups implements Serializable {

    private String controlNumber;
    private String claimNumber;
    private String initiatedBy;
    private String complaintBusinessId;
    private String functionId;

    private String[] filingLocation;
    private String[] responsibleLocation;
    private String[] status;
    private String[] yearOfIssue;
    private String[] region;


    private String[] generator;
    private String[] effectivenessEvaluation;
    private String[] findingType;
    private String[] isoElement;



    private String[] iso_standard;
    private String[] quality_standard;


    private String carFlag;


     public String[] getIso_standard() {
        return iso_standard;
    }

    public void setIso_standard(String[] iso_standard) {
        this.iso_standard = iso_standard;
    }

    public String[] getQuality_standard() {
        return quality_standard;
    }

    public void setQuality_standard(String[] quality_standard) {
        this.quality_standard = quality_standard;
    }


    /**
     * @return Returns the carFlag.
     */
    public String getCarFlag() {
        return carFlag;
    }

    /**
     * @param carFlag The carFlag to set.
     */
    public void setCarFlag(String carFlag) {
        this.carFlag = carFlag;
    }

    /**
     * @return Returns the claimNumber.
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * @param claimNumber The claimNumber to set.
     */
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the effectivenessEvaluation.
     */
    public String[] getEffectivenessEvaluation() {
        return effectivenessEvaluation;
    }

    /**
     * @param effectivenessEvaluation The effectivenessEvaluation to set.
     */
    public void setEffectivenessEvaluation(String[] effectivenessEvaluation) {
        this.effectivenessEvaluation = effectivenessEvaluation;
    }

    /**
     * @return Returns the filingLocation.
     */
    public String[] getFilingLocation() {
        return filingLocation;
    }

    /**
     * @param filingLocation The filingLocation to set.
     */
    public void setFilingLocation(String[] filingLocation) {
        this.filingLocation = filingLocation;
    }

    /**
     * @return Returns the findingType.
     */
    public String[] getFindingType() {
        return findingType;
    }

    /**
     * @param findingType The findingType to set.
     */
    public void setFindingType(String[] findingType) {
        this.findingType = findingType;
    }

    /**
     * @return Returns the generator.
     */
    public String[] getGenerator() {
        return generator;
    }

    /**
     * @param generator The generator to set.
     */
    public void setGenerator(String[] generator) {
        this.generator = generator;
    }

    /**
     * @return Returns the initiatedBy.
     */
    public String getInitiatedBy() {
        return initiatedBy;
    }

    /**
     * @param initiatedBy The initiatedBy to set.
     */
    public void setInitiatedBy(String initiatedBy) {
        this.initiatedBy = initiatedBy;
    }

    /**
     * @return Returns the isoElement.
     */
    public String[] getIsoElement() {
        return isoElement;
    }

    /**
     * @param isoElement The isoElement to set.
     */
    public void setIsoElement(String[] isoElement) {
        this.isoElement = isoElement;
    }

    /**
     * @return Returns the region.
     */
    public String[] getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String[] region) {
        this.region = region;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String[] getResponsibleLocation() {
        return responsibleLocation;
    }

    /**
     * @param responsibleLocation The responsibleLocation to set.
     */
    public void setResponsibleLocation(String[] responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    /**
     * @return Returns the status.
     */
    public String[] getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String[] status) {
        this.status = status;
    }

    /**
     * @return Returns the yearOfIssue.
     */
    public String[] getYearOfIssue() {
        return yearOfIssue;
    }

    /**
     * @param yearOfIssue The yearOfIssue to set.
     */
    public void setYearOfIssue(String[] yearOfIssue) {
        this.yearOfIssue = yearOfIssue;
    }


    public String getComplaintBusinessId() {
        return complaintBusinessId;
    }

    public void setComplaintBusinessId(String complaintBusinessId) {
        this.complaintBusinessId = complaintBusinessId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }
}
