/*
 * Created on Jul 14, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import java.io.Serializable;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class CparLog implements Serializable {

    private String cparFlag;
    private String[] yearOfIssue;
    private String[] responsibleLocation;
    private String functionId;
    private String[] region;


    /**
     * @return Returns the cparFlag.
     */
    public String getCparFlag() {
        return cparFlag;
    }

    /**
     * @param cparFlag The cparFlag to set.
     */
    public void setCparFlag(String cparFlag) {
        this.cparFlag = cparFlag;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String[] getResponsibleLocation() {
        return responsibleLocation;
    }

    /**
     * @param responsibleLocation The responsibleLocation to set.
     */
    public void setResponsibleLocation(String[] responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    /**
     * @return Returns the yearOfIssue.
     */
    public String[] getYearOfIssue() {
        return yearOfIssue;
    }

    /**
     * @param yearOfIssue The yearOfIssue to set.
     */
    public void setYearOfIssue(String[] yearOfIssue) {
        this.yearOfIssue = yearOfIssue;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public void setRegion(String[] region) {
        this.region = region;
    }

    public String[] getRegion() {
        return region;
    }
}
