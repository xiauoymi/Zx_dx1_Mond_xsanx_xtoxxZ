package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.LookUpService;

import java.util.List;

/**
 * Date: Aug 7, 2009
 * Time: 9:09:23 AM
 */
public abstract class CparStatus {
    CparStatus() {
    }

    public static CparStatus getStatus(String status) {
        if (CparConstants.CPAR_STATUS_AWAITING_EVALUATION.equals(status)) {
            return new CparAwaitingEvaluationStatus();
        }
        if (CparConstants.CPAR_STATUS_APPROVED_EFFECTIVE.equals(status) || CparConstants.CPAR_STATUS_APPROVED_NOT_EFFECTIVE.equals(status)) {
            return new CparApprovedStatus();
        }
        return null;
    }

    public abstract void validate(Cpar cpar, List<String> errorList);

    void checkForEmpty(String field, List<String> errorList, String errorString) {
        if (StringUtils.isNullOrEmpty(field)) {
            errorList.add(errorString);
        }
    }

    public String getStatusDescription(String statusId, LookUpService lookupService, String locale) {
        return lookupService.getStatusDescription(Integer.parseInt(statusId), MCASConstants.CPAR_STATUS_TYPE, locale);
    }
}
