package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: Aug 18, 2009 Time: 1:14:05 PM
 */
public abstract class CparType {
  private static Map<Integer, CparType> typeMap;

  CparType() {
  }

  private static void populateTypeMap() {
    if (typeMap == null) {

      Map<Integer, CparType> temp = new HashMap<Integer, CparType>();
      temp.put(CparConstants.GEN_FINDING_OBJ_TYPE_CAR, new CarType());
      temp.put(CparConstants.GEN_FINDING_OBJ_TYPE_PAR, new ParType());
      temp.put(CparConstants.GEN_FINDING_OBJ_TYPE_CI, new CIType());
      temp.put(CparConstants.GEN_FINDING_OBJ_TYPE_NC, new NCType());

      typeMap = temp;
    }
  }

  public static CparType getType(int type) {
    populateTypeMap();
    return typeMap.get(type);
  }

  public abstract String getControlNumberPrefix();

  public abstract String getLongTermReplacementString(String errorMessage, String locale);

  public abstract String getDuplicateErrorMessage(String locale);
}
