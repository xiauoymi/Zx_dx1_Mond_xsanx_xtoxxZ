package com.monsanto.wst.ccas.model;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Apr 27, 2010 Time: 4:42:42 PM To change this template use File |
 * Settings | File Templates.
 */
public class Disposition {
  private Long id;
  private String description;
  private boolean isRootCauseRequired;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public boolean isRootCauseRequired() {
    return isRootCauseRequired;
  }

  public void setRootCauseRequired(boolean rootCauseRequired) {
    isRootCauseRequired = rootCauseRequired;
  }
}
