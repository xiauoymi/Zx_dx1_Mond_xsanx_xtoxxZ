package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.resources.McasProperties;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Date: Aug 13, 2009
 * Time: 10:11:25 AM
 */
public class EmailInfo {
    private String from = "";
    private String body = "";
    private String subject = "";
    private ArrayList<String> toList = new ArrayList<String>();
    private ArrayList<String> ccList = new ArrayList<String>();
    private ArrayList<String> bccList = new ArrayList<String>();
    private final String host;
    private static final String SEPARATOR = ";";

    public EmailInfo() {
        host = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.mail.host");
    }

    private String getAddressString(ArrayList<String> list) {

        String str = "";

        for (int i = 0; i < list.size(); i++) {
            if (i > 0)
                str += SEPARATOR;
            str += list.get(i);
        }

        return str;
    }

    public String getFrom() {
        return from;
    }

    /**
     * @param from The from to set.
     */
    public void setFrom(String from) {
        this.from = from;
    }

    /**
     * @return Returns the to.
     */
    public String getTo() {
        return getAddressString(toList);
    }


    /**
     * @param to The to to set.
     */
    public void setTo(String to) {
        this.toList = new ArrayList<String>();
        this.toList.add(to);
    }

    /**
     * @param to The to to set.
     */
    public void appendTo(String to) {
        String[] separatedEmailsAddresses = to.split(";");
        int i = 0;
        while (separatedEmailsAddresses.length > i) {
            if (!this.toList.contains(separatedEmailsAddresses[i]))
                this.toList.add(separatedEmailsAddresses[i]);
            i++;
        }
    }

    /**
     * @return Returns the subject.
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject The subject to set.
     */
    public void setSubject(String subject) {

        String environment = System.getProperty("lsi.function");
        if (!"prod".equalsIgnoreCase(environment)) {
            this.subject = "(" + environment.toUpperCase() + " environment)  " + subject;
        } else {
            this.subject = subject;
        }
    }

    /**
     * @return Returns the body.
     */
    public String getBody() {
        return body;
    }

    /**
     * @param body The body to set.
     */
    public void setBody(String body) {

        String environment = System.getProperty("lsi.function");
        if (!"prod".equalsIgnoreCase(environment)) {
            this.body = "(" + environment.toUpperCase() + " environment)\r\n\r\n" +
                    "<b>This email is from a Test system.  " +
                    "Unless you are testing the application on a Non-Production system or your are on the development team, please disregard this email.</b><br><br>\r\n\r\n"
                    + body;
        } else {
            this.body = body;
        }
    }

    /**
     * @return Returns the bcc.
     */
    public String getBcc() {
        return getAddressString(bccList);
    }

    /**
     * @param bcc The bcc to set.
     */
    public void setBcc(String bcc) {
        this.bccList = new ArrayList<String>();
        this.bccList.add(bcc);
    }

    /**
     * @return Returns the cc.
     */
    public String getCc() {
        return getAddressString(ccList);
    }

    /**
     * @param cc The cc to set.
     */
    public void setCc(String cc) {
        this.ccList = new ArrayList<String>();
        this.ccList.add(cc);
    }

    public void appendCC(String cc) {
        String[] separatedEmailsAddresses = cc.split(";");
        int i = 0;
        while (separatedEmailsAddresses.length > i) {
            if (!this.ccList.contains(separatedEmailsAddresses[i]))
                this.ccList.add(separatedEmailsAddresses[i]);
            i++;
        }
    }


    public void appendBCC(String bcc) {
        bccList.add(bcc);
    }

    public void setToArray(String[] toArray) {
        toList = new ArrayList<String>();
        for (int i = 0; i < toArray.length; i++)
            toList.add(toArray[i]);
    }

    public String[] getToArray() {
        return toList.toArray(new String[toList.size()]);
    }

    public void setCcArray(String[] ccArray) {
        ccList = new ArrayList<String>();
        for (int i = 0; i < ccArray.length; i++) toList.add(ccArray[i]);
    }

    public String[] getCcArray() {
        return ccList.toArray(new String[ccList.size()]);

    }

    public String[] getBccArray() {
        return bccList.toArray(new String[bccList.size()]);
    }

    public Object getHost() {
        return host;
    }

    /**
     * This method takes a string of email Id's seperated by a seperator and create's a To Array.
     *
     * @param toEmail
     * @param seperator
     */
    public void setToArray(StringBuffer toEmail, String seperator) {
        setToArray(toEmail.toString().split(seperator));
    }

    @Override
    public String toString() {
        return "SUBJECT: " + subject + "\r\n" +
                "FROM:    " + from + "\r\n" +
                "TO:      " + getTo() + "\r\n" +
                "CC:      " + getCc() + "\r\n" +
                "BCC:     " + getBcc() + "\n" +
                "BODY:    " + body + "\r\n\r\n";
    }
}
