/*
 * Created on Apr 15, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;

import java.io.Serializable;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class FindingObject implements Serializable {

    private String findingID;

    private String findingDesc;

    private String auditId;

    public String getAuditId() {
        return auditId;
    }

    public void setAuditId(String auditId) {
        this.auditId = auditId;
    }

    private String ackAndCloseText;
    private String readOnly = "false";

    public String getReadOnly() {
        return StringUtils.isNullOrEmpty(ackFindingId)?"false":"true";
    }

    public void setReadOnly(String readOnly) {
        this.readOnly = readOnly;
    }

    private String ackFindingId;
    private String userNameOfPersonWhoClosedFinding;

    public String getAckFindingId() {
        return ackFindingId;
    }

    public void setAckFindingId(String ackFindingId) {
        this.ackFindingId = ackFindingId;
    }

    public String getUserNameOfPersonWhoClosedFinding() {
        return userNameOfPersonWhoClosedFinding;
    }

    public void setUserNameOfPersonWhoClosedFinding(String userNameOfPersonWhoClosedFinding) {
        this.userNameOfPersonWhoClosedFinding = userNameOfPersonWhoClosedFinding;
    }

    public String getAckAndCloseText() {
        return ackAndCloseText;
    }

    public void setAckAndCloseText(String ackAndCloseText) {
        this.ackAndCloseText = ackAndCloseText;
    }

    private String shortFindingDesc;

    private String cparID;

    private String controlNumber; //**Actually the cpar-id

    private String findingType;

    private String rowUserID;

    private String car_flag;


    /**
     * @return Returns the findingType.
     */
    public String getFindingType() {
        return findingType;
    }

    /**
     * @param findingType The findingType to set.
     */
    public void setFindingType(String findingType) {
        this.findingType = findingType;
    }

    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the cparID.
     */
    public String getCparID() {
        return cparID;
    }

    /**
     * @param cparID The cparID to set.
     */
    public void setCparID(String cparID) {
        this.cparID = cparID;
    }

    /**
     * @return Returns the car_flag.
     */
    public String getCar_flag() {
        return car_flag;
    }

    /**
     * @param car_flag The car_flag to set.
     */
    public void setCar_flag(String car_flag) {
        this.car_flag = car_flag;
    }

    /**
     * @return Returns the rowUserID.
     */
    public String getRowUserID() {
        return rowUserID;
    }

    /**
     * @param rowUserID The rowUserID to set.
     */
    public void setRowUserID(String rowUserID) {
        this.rowUserID = rowUserID;
    }

    /**
     * @param shortFindingDesc The shortFindingDesc to set.
     */
    public void setShortFindingDesc(String shortFindingDesc) {
        this.shortFindingDesc = shortFindingDesc;
    }

    /**
     * @return Returns the shortFindingDesc.
     */
    public String getShortFindingDesc() {
        if (findingDesc.length() > 70) {
            return findingDesc.substring(0, 70) + "...";
        }
        return findingDesc;

    }

    /**
     * @return Returns the findingDesc.
     */
    public String getFindingDesc() {
        return findingDesc;
    }

    /**
     * @param findingDesc The findingDesc to set.
     */
    public void setFindingDesc(String findingDesc) {
        this.findingDesc = findingDesc;
    }

    /**
     * @return Returns the findingID.
     */
    public String getFindingID() {
        return findingID;
    }

    /**
     * @param findingID The findingID to set.
     */
    public void setFindingID(String findingID) {
        this.findingID = findingID;
    }


}
