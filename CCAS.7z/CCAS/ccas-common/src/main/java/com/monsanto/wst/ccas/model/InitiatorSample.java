package com.monsanto.wst.ccas.model;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 15, 2010 Time: 4:57:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class InitiatorSample implements Serializable {
    private Long id;
    private String value;

    public InitiatorSample() {
    }

    public InitiatorSample(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
