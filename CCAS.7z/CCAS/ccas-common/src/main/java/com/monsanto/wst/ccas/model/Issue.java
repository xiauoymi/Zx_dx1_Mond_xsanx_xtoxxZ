package com.monsanto.wst.ccas.model;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 1:55:29 PM To change this template use File |
 * Settings | File Templates.
 */
public class Issue {
  private final Long id;
  private final String description;
  private boolean selected;

  public Issue(Long id, String description, boolean selected) {
    this.id = id;
    this.description = description;
    this.selected = selected;
  }

  public Long getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }

  public boolean isSelected() {
    return selected;
  }

  public void setSelected(boolean selected) {
    this.selected = selected;
  }
}
