package com.monsanto.wst.ccas.model;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Dec 17, 2010
 * Time: 10:01:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class IssueList<Issue> extends ArrayList<Issue> {

    @Override
    //work around Struts1 BeanUtils throwing an IndexOutOfBoundsException
    public Issue get(int index) {


        for (long i = 0; size() <= index; i++) {
            add((Issue) new com.monsanto.wst.ccas.model.Issue(i, "", false));
        }

        return super.get(index);
    }
}
