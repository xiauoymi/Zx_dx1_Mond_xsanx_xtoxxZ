package com.monsanto.wst.ccas.model;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Aug 8, 2006
 * Time: 1:06:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationInfo {

    private String locationId = null;
    private String locationName = null;
    private String locationLongName = null;
    private int regionId = -1;
    private String regionDesc = null;

    public void setStatusActive(boolean statusActive) {
        this.statusActive = statusActive;
    }

    private boolean statusActive = false;
    private String locationEmail = null;
    public String getLocationOwnerEmail2() {
        return locationOwnerEmail2;
    }

    public void setLocationOwnerEmail2(String locationOwnerEmail2) {
        this.locationOwnerEmail2 = locationOwnerEmail2;
    }

    public String getLocationOwnerEmail3() {
        return locationOwnerEmail3;
    }

    public void setLocationOwnerEmail3(String locationOwnerEmail3) {
        this.locationOwnerEmail3 = locationOwnerEmail3;
    }

    public String getLocationOwnerEmail4() {
        return locationOwnerEmail4;
    }

    public void setLocationOwnerEmail4(String locationOwnerEmail4) {
        this.locationOwnerEmail4 = locationOwnerEmail4;
    }

    private String locationOwnerEmail2 = null;
    private String locationOwnerEmail3 = null;
    private String locationOwnerEmail4 = null;
    private String locationOwnerEmail = null;
    private boolean ownerEmailStatusActive = false;
    private String errorMessage;

    private boolean responsibleLocation;
    private boolean filingLocation;
    private boolean reportingLocation;
    private boolean shippingLocation;
    private boolean customerLocation;


    public LocationInfo(String locationId, String locationName) {
        this.locationId = locationId;
        this.locationName = locationName;
    }

    public LocationInfo(String locationId, String locationName, String locationLongName, int regionId, String regionDesc, boolean statusActive, String locationEmail, String locationOwnerEmail, boolean ownerEmailStatusActive, boolean isResponsibleLocation, boolean isFilingLocation, boolean isReportingLocation, boolean isShippingLocation, boolean isCustomerLocation) {
        this.locationId = locationId;
        this.locationName = locationName;
        this.locationLongName = locationLongName;
        this.regionId = regionId;
        this.regionDesc = regionDesc;
        this.statusActive = statusActive;
        this.locationEmail = locationEmail;
        this.locationOwnerEmail = locationOwnerEmail;
        this.ownerEmailStatusActive = ownerEmailStatusActive;
        this.responsibleLocation = isResponsibleLocation;
        this.filingLocation = isFilingLocation;
        this.reportingLocation = isReportingLocation;
        this.shippingLocation = isShippingLocation;
        this.customerLocation = isCustomerLocation;
    }

public LocationInfo(String locationId, String locationName, String locationLongName, int regionId, String regionDesc, boolean statusActive, String locationEmail, String locationOwnerEmail, boolean ownerEmailStatusActive, boolean isResponsibleLocation, boolean isFilingLocation, boolean isReportingLocation, boolean isShippingLocation, boolean isCustomerLocation,
                        String locationOwnerEmail2,String locationOwnerEmail3,String locationOwnerEmail4) {
        this.locationId = locationId;
        this.locationName = locationName;
        this.locationLongName = locationLongName;
        this.regionId = regionId;
        this.regionDesc = regionDesc;
        this.statusActive = statusActive;
        this.locationEmail = locationEmail;
        this.locationOwnerEmail = locationOwnerEmail;
        this.ownerEmailStatusActive = ownerEmailStatusActive;
        this.responsibleLocation = isResponsibleLocation;
        this.filingLocation = isFilingLocation;
        this.reportingLocation = isReportingLocation;
        this.shippingLocation = isShippingLocation;
        this.customerLocation = isCustomerLocation;

        this.locationOwnerEmail2=locationOwnerEmail2;
        this.locationOwnerEmail3=locationOwnerEmail3;
        this.locationOwnerEmail4=locationOwnerEmail4;
    }


    public String getLocationId() {
        return locationId;
    }

    public String getLocationName() {
        return locationName;
    }

    public String getLocationLongName() {
        return locationLongName;
    }

    public int getRegionId() {
        return regionId;
    }

    public String getRegionDesc() {
        return regionDesc;
    }

    public String getLocationEmail() {
        return locationEmail;
    }

    public String getLocationOwnerEmail() {
        return locationOwnerEmail;
    }

    public boolean isStatusActive() {
        return statusActive;
    }

    public boolean isOwnerEmailStatusActive() {
        return ownerEmailStatusActive;
    }

    public void setRegionId(int regionId) {
        this.regionId = regionId;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public boolean isResponsibleLocation() {
        return responsibleLocation;
    }

    public boolean isFilingLocation() {
        return filingLocation;
    }

    public boolean isReportingLocation() {
        return reportingLocation;
    }

    public boolean isShippingLocation() {
        return shippingLocation;
    }

    public boolean isCustomerLocation() {
        return customerLocation;
    }

    public void setResponsibleLocation(boolean responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    public void setFilingLocation(boolean filingLocation) {
        this.filingLocation = filingLocation;
    }

    public void setReportingLocation(boolean reportingLocation) {
        this.reportingLocation = reportingLocation;
    }

    public void setShippingLocation(boolean shippingLocation) {
        this.shippingLocation = shippingLocation;
    }

    public void setCustomerLocation(boolean customerLocation) {
        this.customerLocation = customerLocation;
    }
}