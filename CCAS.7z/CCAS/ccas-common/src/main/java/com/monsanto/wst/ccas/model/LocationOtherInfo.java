package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Apr 4, 2011
 * Time: 10:01:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocationOtherInfo implements Serializable{
    private String id;
    private String responsibleLocationDetail;
    private String fillingLocationDetail;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getResponsibleLocationDetail() {
        return responsibleLocationDetail;
    }

    public void setResponsibleLocationDetail(String responsibleLocationDetail) {
        this.responsibleLocationDetail = responsibleLocationDetail;
    }

    public String getFillingLocationDetail() {
        return fillingLocationDetail;
    }

    public void setFillingLocationDetail(String fillingLocationDetail) {
        this.fillingLocationDetail = fillingLocationDetail;
    }

    public boolean isNotSet(){
        return StringUtils.isNullOrEmpty(fillingLocationDetail) &&
                StringUtils.isNullOrEmpty(responsibleLocationDetail);
    }

    @Override
    public String toString() {
        StringBuffer b = new StringBuffer(141);
        b.append("{<id=").append(getId()).append(">,").append("<fillingLocationDetail=").append(getFillingLocationDetail()).append(">,")
                .append("<responsibleLocationDetail=").append(getResponsibleLocationDetail()).append(">}");
        return b.toString();
    }
}
