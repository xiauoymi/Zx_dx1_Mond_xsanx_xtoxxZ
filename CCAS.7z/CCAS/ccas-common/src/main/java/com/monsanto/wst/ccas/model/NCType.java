package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

/**
 * Date: Aug 18, 2009 Time: 1:31:18 PM
 */
public class NCType extends CparType {
  public NCType() {
  }

  public String getControlNumberPrefix() {
    return CparConstants.NC_CONTROL_NUMBER_PREFIX;
  }

  public String getLongTermReplacementString(String errorMessage, String ignore) {
    return errorMessage;
  }

  public String getDuplicateErrorMessage(String locale) {
    return I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicateNCR");
  }
}
