package com.monsanto.wst.ccas.model;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: BGHALE Date: May 16, 2008 Time: 11:04:45 AM To change this template use File |
 * Settings | File Templates.
 */
public class NonconformanceType implements Serializable {

    private final int nonconformanceTypeId;
    private final String nonconformanceTypeDescription;

    public NonconformanceType(int nonconformanceTypeId, String nonconformanceTypeDescription) {
        this.nonconformanceTypeId = nonconformanceTypeId;
        this.nonconformanceTypeDescription = nonconformanceTypeDescription;
    }

    public int getNonconformanceTypeId() {
        return nonconformanceTypeId;
    }

    public String getNonconformanceTypeDescription() {
        return nonconformanceTypeDescription;
    }
}
