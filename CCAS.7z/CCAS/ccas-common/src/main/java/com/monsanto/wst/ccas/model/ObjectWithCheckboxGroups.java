package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.CheckboxGroup;
import com.monsanto.wst.ccas.audits.CheckboxRow;
import com.monsanto.wst.ccas.actionForms.*;

import java.util.List;
import java.util.ArrayList;

import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 12, 2008
 * Time: 11:40:37 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ObjectWithCheckboxGroups {

    private List<Integer> functionalAreaIdList;
    private List<Integer> nonconformanceCategoryIdList;
    private List<Integer> rootCauseIdList;
    private List<CheckboxGroup> functionalAreaList;
    private List<CheckboxGroup> nonconformanceCategoryList;
    private List<CheckboxGroup> rootCauseList;
    private List<CheckboxItem> selectedFunctionalAreas;
    private List<CheckboxItem> selectedNonconformanceCategoryList;
    private List<CheckboxItem> selectedRootCauseList;
    private CheckboxGroup checkboxGroup;

    //maximum number of checkbox group tabs in all apps
    private static final int MAX_TABS = 26;

    public void setFunctionalArea(CheckboxGroup checkboxGroup) {
        this.checkboxGroup = checkboxGroup;
    }

    public CheckboxGroup getFunctionalArea() {
        return checkboxGroup;
    }

    public void setFunctionalAreaList(List<CheckboxGroup> functionalAreaList) {
        this.functionalAreaList = functionalAreaList;
    }

    public List<CheckboxGroup> getFunctionalAreaList() {
        if (functionalAreaList == null) {
            functionalAreaList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(CheckboxGroup.class));
        }
        //max 20 tabs
        for (int i = functionalAreaList.size(); i < MAX_TABS; i++) {
            functionalAreaList.add(new CheckboxGroup());
        }
        return functionalAreaList;
    }

    public void setNonconformanceCategoryList(List<CheckboxGroup> checkboxGroupList) {
        this.nonconformanceCategoryList = checkboxGroupList;
    }

    public List<CheckboxGroup> getNonconformanceCategoryList() {
        if (nonconformanceCategoryList == null) {
            nonconformanceCategoryList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(CheckboxGroup.class));
        }
        //max 20 tabs
        for (int i = nonconformanceCategoryList.size(); i < MAX_TABS; i++) {
            nonconformanceCategoryList.add(new CheckboxGroup());
        }
        return nonconformanceCategoryList;
    }

    public void setRootCauseList(List<CheckboxGroup> checkboxGroupList) {
        this.rootCauseList = checkboxGroupList;
    }

    public List<CheckboxGroup> getRootCauseList() {
        if (rootCauseList == null) {
            rootCauseList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(CheckboxGroup.class));
        }
        //max 20 tabs
        for (int i = rootCauseList.size(); i < MAX_TABS; i++) {
            rootCauseList.add(new CheckboxGroup());
        }
        return rootCauseList;
    }

//    public void setFunctionalAreaIdList(List<Integer> functionalAreaIdList) {
//        this.functionalAreaIdList = functionalAreaIdList;
//    }

    public List<Integer> getFunctionalAreaIdList() {
        if (functionalAreaIdList == null) {
            functionalAreaIdList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(Integer.class));
        }
        //max 20 tabs
        for (int i = functionalAreaIdList.size(); i < MAX_TABS; i++) {
            functionalAreaIdList.add(new Integer(-1));
        }
        return functionalAreaIdList;
    }

//    public void setNonconformanceCategoryIdList(List<Integer> nonconformanceCategoryIdList) {
//        this.nonconformanceCategoryIdList = nonconformanceCategoryIdList;
//    }

    public List<Integer> getNonconformanceCategoryIdList() {
        if (nonconformanceCategoryIdList == null) {
            nonconformanceCategoryIdList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(Integer.class));
        }
        //max 20 tabs
        for (int i = nonconformanceCategoryIdList.size(); i < MAX_TABS; i++) {
            nonconformanceCategoryIdList.add(new Integer(-1));
        }

        return nonconformanceCategoryIdList;
    }

//    public void setRootCauseIdList(List<Integer> rootCauseIdList) {
//        this.rootCauseIdList = rootCauseIdList;
//    }

    public List<Integer> getRootCauseIdList() {
        if (rootCauseIdList == null) {
            rootCauseIdList = LazyList.decorate(
                    new ArrayList(), FactoryUtils.instantiateFactory(Integer.class));
        }
        //max 20 tabs
        for (int i = rootCauseIdList.size(); i < MAX_TABS; i++) {
            rootCauseIdList.add(new Integer(-1));
        }

        return rootCauseIdList;
    }

    public void setSelectedFunctionalAreas(List<CheckboxItem> selectedFunctionalAreas) {
        this.selectedFunctionalAreas = selectedFunctionalAreas;
        functionalAreaIdList = updateCheckboxIdList(selectedFunctionalAreas, functionalAreaList);
    }

    public List<CheckboxItem> getSelectedFunctionalAreas() {
        return selectedFunctionalAreas;
    }

    public void setSelectedNonconformanceList(List<CheckboxItem> selectedCategoryList) {
        this.selectedNonconformanceCategoryList = selectedCategoryList;
        nonconformanceCategoryIdList = updateCheckboxIdList(selectedCategoryList, nonconformanceCategoryList);
    }

    public List<CheckboxItem> getSelectedNonconformanceCategoryList() {
        return selectedNonconformanceCategoryList;
    }

    public void setSelectedRootCauseList(List<CheckboxItem> selectedCauseList) {
        this.selectedRootCauseList = selectedCauseList;
        rootCauseIdList = updateCheckboxIdList(selectedCauseList, rootCauseList);
    }

    public List<CheckboxItem> getSelectedRootCauseList() {
        return selectedRootCauseList;
    }

    private List<Integer> updateCheckboxIdList(List<CheckboxItem> selectedList, List<CheckboxGroup> groupList) {
        List<Integer> idList = new ArrayList<Integer>();
        for (CheckboxItem checkboxItem : selectedList) {
            idList.add(checkboxItem.getCheckboxItemId());
        }

        return idList;
    }

    public void populateFunctionalAreas(List<CheckboxGroup> checkboxGroupList) {
        if (checkboxGroupList != null && checkboxGroupList.size() > 0) {
            setFunctionalAreaList(checkboxGroupList);
            for (Object obj : checkboxGroupList) {
                setFunctionalArea((CheckboxGroup) obj);
            }
        }
    }

    public void populateNonconformanceCategories(List<CheckboxGroup> nonconformanceCategoryList) {
        if (nonconformanceCategoryList != null && nonconformanceCategoryList.size() > 0) {
            setNonconformanceCategoryList(nonconformanceCategoryList);
            for (CheckboxGroup checkboxGroupObj : nonconformanceCategoryList) {
                setFunctionalArea(checkboxGroupObj);
            }
        }
    }

    public void populateRootCauses(List<CheckboxGroup> rootCauseList) {
        if (rootCauseList != null && rootCauseList.size() > 0) {
            setRootCauseList(rootCauseList);
            for (CheckboxGroup checkboxGroupObj : rootCauseList) {
                setFunctionalArea(checkboxGroupObj);
            }
        }
    }

//    public void populateSelectedFunctionalAreaList(List<CheckboxItem> selectedFunctionalAreas) {
//        List<Integer> functionalAreaIdList = new ArrayList<Integer>();
//        for (CheckboxItem checkboxItem : selectedFunctionalAreas) {
//            functionalAreaIdList.add(checkboxItem.getCheckboxItemId());
//        }
//        setFunctionalAreaIdList(functionalAreaIdList);
//    }

//    public void populateSelectedRootCauseList(List<CheckboxItem> rootCauseList) {
//        List<Integer> rootCauseIdList = new ArrayList<Integer>();
//        for (CheckboxItem checkboxItem : rootCauseList) {
//            rootCauseIdList.add(checkboxItem.getCheckboxItemId());
//        }
//        setRootCauseIdList(rootCauseIdList);
//    }

    public boolean isFunctionalAreaIdListEmpty() {

        if (functionalAreaIdList == null || functionalAreaIdList.size() == 0)
            return true;

        for (Integer a : functionalAreaIdList) {
            if (a != -1)
                return false;
        }
        return true;
    }

    public boolean isNonconformanceCategoryIdListEmpty() {

        if (nonconformanceCategoryIdList == null || nonconformanceCategoryIdList.size() == 0)
            return true;

        for (Integer a : nonconformanceCategoryIdList) {
            if (a != -1)
                return false;
        }
        return true;
    }

    public boolean isRootCauseIdListEmpty() {

        if (rootCauseIdList == null || rootCauseIdList.size() == 0)
            return true;

        for (Integer a : rootCauseIdList) {
            if (a != -1)
                return false;
        }
        return true;
    }

    public static ObjectWithCheckboxGroups getObjectFromFormInSession(HttpServletRequest request) {

        HttpSession session = request.getSession();

        CparForm cparForm = (CparForm) session.getAttribute("cparForm");
        if (cparForm != null) {
            return cparForm.getCpar();
        }
        ComplaintForm complaintForm = (ComplaintForm) session.getAttribute("complaintForm");
        if (complaintForm != null) {
            return complaintForm.getC();
        }
        StopSaleForm stopSaleForm = (StopSaleForm) session.getAttribute("stopSaleForm");
        if (stopSaleForm != null) {
            return stopSaleForm.getStopSale();
        }
        AuditForm auditForm = (AuditForm) session.getAttribute("auditForm");
        if (auditForm != null) {
            return auditForm.getAuditObj();
        }
        CparFilterForm cparFilterForm = (CparFilterForm) request.getAttribute("cparFilterForm");
        if (cparFilterForm != null) {
            return cparFilterForm.getCparFilter();
        }
        ComplaintFilterForm complaintFilterForm = (ComplaintFilterForm) request.getAttribute("complaintFilterForm");
        if (complaintFilterForm != null) {
            return complaintFilterForm.getComplaintFilter();
        }
        StopSaleFilterForm stopSaleFilterForm = (StopSaleFilterForm) request.getAttribute("stopSaleFilterForm");
        if (stopSaleFilterForm != null) {
            return stopSaleFilterForm.getStopSaleFilter();
        }

        return null;
    }
}