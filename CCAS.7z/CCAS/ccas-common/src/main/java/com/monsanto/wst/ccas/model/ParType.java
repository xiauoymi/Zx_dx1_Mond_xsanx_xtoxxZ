package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.CparConstants;
import com.monsanto.wst.ccas.service.I18nServiceImpl;

/**
 * Date: Aug 18, 2009 Time: 1:30:50 PM
 */
public class ParType extends CparType {
  public String getControlNumberPrefix() {
    return CparConstants.PAR_CONTROL_NUMBER_PREFIX;
  }

  public String getLongTermReplacementString(String errorMessage, String locale) {
    return " " + I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.corrective") + " ";
  }

  public String getDuplicateErrorMessage(String locale) {
    return I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.duplicatePar");
  }

}
