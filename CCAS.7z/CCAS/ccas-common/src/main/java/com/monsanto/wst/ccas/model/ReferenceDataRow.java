package com.monsanto.wst.ccas.model;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 2, 2011
 * Time: 6:44:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceDataRow {

    private int dataId;
    private String dataValue;
    private String dataValue2;
    private String type;
    boolean active;

    public int getDataId() {
        return dataId;
    }

    public void setDataId(int dataId) {
        this.dataId = dataId;
    }

    public String getDataValue() {
        return dataValue;
    }

    public void setDataValue(String dataValue) {
        this.dataValue = dataValue;
    }

    public String getDataValue2() {
        return dataValue2;
    }

    public void setDataValue2(String dataValue) {
        this.dataValue2 = dataValue;
    }

    public String getType() {
        return type;
    }

    public void setType(String i) {
        this.type = i;
    }

    public boolean isActive() {
        return active;
    }

    public String getActiveLetter() {
        if (active)
            return "Y";
        return "N";
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
