package com.monsanto.wst.ccas.model;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 2, 2011
 * Time: 6:23:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceDataTables {

    private int id;
    private String actualTableName;
    private String prettyTableName;
    private String dataIdCol;
    private String dataDescriptionCol;
    private String activeFlagCol;
    private String enabled;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getActualTableName() {
        return actualTableName;
    }

    public void setActualTableName(String actualTableName) {
        this.actualTableName = actualTableName;
    }

    public String getPrettyTableName() {
        return prettyTableName;
    }

    public void setPrettyTableName(String prettyTableName) {
        this.prettyTableName = prettyTableName;
    }

    public String getDataIdCol() {
        return dataIdCol;
    }

    public void setDataIdCol(String dataIdCol) {
        this.dataIdCol = dataIdCol;
    }

    public String getDataDescriptionCol() {
        return dataDescriptionCol;
    }

    public void setDataDescriptionCol(String dataDescriptionCol) {
        this.dataDescriptionCol = dataDescriptionCol;
    }

    public String getActiveFlagCol() {
        return activeFlagCol;
    }

    public void setActiveFlagCol(String activeFlagCol) {
        this.activeFlagCol = activeFlagCol;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
}
