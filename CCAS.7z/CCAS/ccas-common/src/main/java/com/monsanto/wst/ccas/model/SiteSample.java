package com.monsanto.wst.ccas.model;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 15, 2010 Time: 4:58:40 PM To change this template use File |
 * Settings | File Templates.
 */
public class SiteSample implements Serializable {
    private Long id;
    private String value;

    public SiteSample() {
    }

    public SiteSample(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
