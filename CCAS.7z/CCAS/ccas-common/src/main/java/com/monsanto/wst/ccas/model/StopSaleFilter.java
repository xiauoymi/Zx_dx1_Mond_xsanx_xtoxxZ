/*
 * Created on Jun 22, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.CheckboxGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.list.LazyList;
import org.apache.commons.collections.FactoryUtils;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class StopSaleFilter extends ObjectWithCheckboxGroups implements Serializable {

    private String controlNumber;
    private String initiatedBy;
    private String dateReported;
    private String investigator;
    private String batchNumber;

    private String[] status;
    private String[] region;
    private String[] salesYear;
    private String[] state;
    private String[] crop;

    private String[] filingLocation;
    private String[] responsibleLocation;
    private String[] shippingLocation;
    private String variety;

    private boolean seedCount;
    private boolean germination;
    private boolean purity;
    private boolean tagDate;
    private boolean otherReason;

    private boolean reLabel;
    private boolean recount;
    private boolean dump;
    private boolean restrict;
    private boolean otherActionFlag;

    /**
     * @return Returns the batchNumber.
     */
    public String getBatchNumber() {
        return batchNumber;
    }

    /**
     * @param batchNumber The batchNumber to set.
     */
    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    /**
     * @return Returns the controlNumber.
     */
    public String getControlNumber() {
        return controlNumber;
    }

    /**
     * @param controlNumber The controlNumber to set.
     */
    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    /**
     * @return Returns the crop.
     */
    public String[] getCrop() {
        return crop;
    }

    /**
     * @param crop The crop to set.
     */
    public void setCrop(String[] crop) {
        this.crop = crop;
    }

    /**
     * @return Returns the dateReported.
     */
    public String getDateReported() {
        return dateReported;
    }

    /**
     * @param dateReported The dateReported to set.
     */
    public void setDateReported(String dateReported) {
        this.dateReported = dateReported;
    }

    /**
     * @return Returns the dump.
     */
    public boolean isDump() {
        return dump;
    }

    /**
     * @param dump The dump to set.
     */
    public void setDump(boolean dump) {
        this.dump = dump;
    }

    /**
     * @return Returns the filingLocation.
     */
    public String[] getFilingLocation() {
        return filingLocation;
    }

    /**
     * @param filingLocation The filingLocation to set.
     */
    public void setFilingLocation(String[] filingLocation) {
        this.filingLocation = filingLocation;
    }

    /**
     * @return Returns the germination.
     */
    public boolean isGermination() {
        return germination;
    }

    /**
     * @param germination The germination to set.
     */
    public void setGermination(boolean germination) {
        this.germination = germination;
    }

    /**
     * @return Returns the initiatedBy.
     */
    public String getInitiatedBy() {
        return initiatedBy;
    }

    /**
     * @param initiatedBy The initiatedBy to set.
     */
    public void setInitiatedBy(String initiatedBy) {
        this.initiatedBy = initiatedBy;
    }

    /**
     * @return Returns the investigator.
     */
    public String getInvestigator() {
        return investigator;
    }

    /**
     * @param investigator The investigator to set.
     */
    public void setInvestigator(String investigator) {
        this.investigator = investigator;
    }

    /**
     * @return Returns the otherActionFlag.
     */
    public boolean isOtherActionFlag() {
        return otherActionFlag;
    }

    /**
     * @param otherActionFlag The otherActionFlag to set.
     */
    public void setOtherActionFlag(boolean otherActionFlag) {
        this.otherActionFlag = otherActionFlag;
    }

    /**
     * @return Returns the otherReason.
     */
    public boolean isOtherReason() {
        return otherReason;
    }

    /**
     * @param otherReason The otherReason to set.
     */
    public void setOtherReason(boolean otherReason) {
        this.otherReason = otherReason;
    }

    /**
     * @return Returns the purity.
     */
    public boolean isPurity() {
        return purity;
    }

    /**
     * @param purity The purity to set.
     */
    public void setPurity(boolean purity) {
        this.purity = purity;
    }

    /**
     * @return Returns the recount.
     */
    public boolean isRecount() {
        return recount;
    }

    /**
     * @param recount The recount to set.
     */
    public void setRecount(boolean recount) {
        this.recount = recount;
    }

    /**
     * @return Returns the region.
     */
    public String[] getRegion() {
        return region;
    }

    /**
     * @param region The region to set.
     */
    public void setRegion(String[] region) {
        this.region = region;
    }

    /**
     * @return Returns the reLabel.
     */
    public boolean isReLabel() {
        return reLabel;
    }

    /**
     * @param reLabel The reLabel to set.
     */
    public void setReLabel(boolean reLabel) {
        this.reLabel = reLabel;
    }

    /**
     * @return Returns the responsibleLocation.
     */
    public String[] getResponsibleLocation() {
        return responsibleLocation;
    }

    /**
     * @param responsibleLocation The responsibleLocation to set.
     */
    public void setResponsibleLocation(String[] responsibleLocation) {
        this.responsibleLocation = responsibleLocation;
    }

    /**
     * @return Returns the restrict.
     */
    public boolean isRestrict() {
        return restrict;
    }

    /**
     * @param restrict The restrict to set.
     */
    public void setRestrict(boolean restrict) {
        this.restrict = restrict;
    }

    /**
     * @return Returns the salesYear.
     */
    public String[] getSalesYear() {
        return salesYear;
    }

    /**
     * @param salesYear The salesYear to set.
     */
    public void setSalesYear(String[] salesYear) {
        this.salesYear = salesYear;
    }

    /**
     * @return Returns the seedCount.
     */
    public boolean isSeedCount() {
        return seedCount;
    }

    /**
     * @param seedCount The seedCount to set.
     */
    public void setSeedCount(boolean seedCount) {
        this.seedCount = seedCount;
    }

    /**
     * @return Returns the shippingLocation.
     */
    public String[] getShippingLocation() {
        return shippingLocation;
    }

    /**
     * @param shippingLocation The shippingLocation to set.
     */
    public void setShippingLocation(String[] shippingLocation) {
        this.shippingLocation = shippingLocation;
    }

    /**
     * @return Returns the state.
     */
    public String[] getState() {
        return state;
    }

    /**
     * @param state The state to set.
     */
    public void setState(String[] state) {
        this.state = state;
    }

    /**
     * @return Returns the status.
     */
    public String[] getStatus() {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String[] status) {
        this.status = status;
    }

    /**
     * @return Returns the tagDate.
     */
    public boolean isTagDate() {
        return tagDate;
    }

    /**
     * @param tagDate The tagDate to set.
     */
    public void setTagDate(boolean tagDate) {
        this.tagDate = tagDate;
    }

    /**
     * @return Returns the variety.
     */
    public String getVariety() {
        return variety;
    }

    /**
     * @param variety The variety to set.
     */
    public void setVariety(String variety) {
        this.variety = variety;
    }
}
