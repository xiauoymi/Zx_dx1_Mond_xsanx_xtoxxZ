/*
 * Created on Mar 4, 2005
 *
 *
 */
package com.monsanto.wst.ccas.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.service.RegionServiceImpl;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author jbrahmb
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class User {

    private String user_id;
    private String full_name;
    private String email;
    private Map<String, Boolean> permissionsMap;  //This is actually the "Permission" Map.
    private static final String AFFINA_ROLE_ID = "4";
    private static final String ADMIN_ROLE_ID = "1";
     private static final String REGIONAL_ADMIN_ROLE_ID = "2";
    //private static final int ADMIN_ROLE_WITH_UPLOAD_ID = 0;
    private static final String ADMIN_ROLE_WITH_UPLOAD_ID = "0";

    
    public void setRolesMap(Map<String, Boolean> rolesMap) {
        this.rolesMap = rolesMap;
    }

    private Map<String, Boolean> rolesMap;

    private boolean hasSelectedBusinessFromDropdown;

    //Non-oersisitent field Business Id. Field present in User_Administration table
    private int businessId;
    //Place holder for preference
    private int userBusinessPreference;
    public static final String USER = "user";
    private String locale = MCASConstants.LANGUAGE_DEFAULT;

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public int getUserBusinessPreference() {
        return userBusinessPreference;
    }

    public void setUserBusinessPreference(int userBusinessPreference) {
        this.userBusinessPreference = userBusinessPreference;
    }

    public int getBusinessId() {
        return businessId;
    }

    public void setBusinessId(int businessId) {
        this.businessId = businessId;
    }

    public User(Map<String, Boolean> rolesMap) {
        super();
        this.rolesMap = rolesMap;
        this.permissionsMap = new TreeMap<String, Boolean>();
    }

    public User(String user_id, String full_name, String email, Map<String, Boolean> permissionsMap, Map<String, Boolean> rolesMap) {
        this.user_id = user_id;
        this.full_name = full_name;
        this.email = email;
        this.permissionsMap = permissionsMap;
        this.rolesMap = rolesMap;
    }

    public boolean isUserInLocationRegion(String locationId, int businessId) throws Exception {
        if (StringUtils.isNullOrEmpty(locationId)) {
            return true;
        }
        if (!StringUtils.isNullOrEmpty(locationId) && !StringUtils.isNullOrEmpty(user_id)) {
            String entityRegionId = new ActionHelper().getLocationRegion(locationId);
            for (String s : new RegionServiceImpl().getRegionList(user_id, businessId, MCASConstants.LANGUAGE_DEFAULT).keySet()) {
                String userRegionId = s;
                if (userRegionId.equalsIgnoreCase(entityRegionId)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @return Returns the email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email The email to set.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return Returns the permissionsMap.
     */
    public Map<String, Boolean> getPermissionsMap() {
        return permissionsMap;
    }

    /**
     * @param permissionsMap The permissionsMap to set.
     */
    public void setPermissionsMap(Map<String, Boolean> permissionsMap) {
        this.permissionsMap = permissionsMap;
    }

    /**
     * @param permissionId The permissionsMap to set.
     */
    public boolean hasPermission(String permissionId) {
        return this.permissionsMap.containsKey(permissionId);
    }

    /**
     * @return Returns the user_id.
     */
    public String getUser_id() {
        return user_id;
    }

    /**
     * @param user_id The user_id to set.
     */
    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    /**
     * @return Returns the full_name.
     */
    public String getFull_name() {
        return full_name;
    }

    /**
     * @param full_name The full_name to set.
     */
    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public boolean isHasSelectedBusinessFromDropdown() {
        return hasSelectedBusinessFromDropdown;
    }

    public void setHasSelectedBusinessFromDropdown(boolean hasSelectedBusinessFromDropdown) {
        this.hasSelectedBusinessFromDropdown = hasSelectedBusinessFromDropdown;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("-----------------User Start-----------------");
        buffer.append("User ID = ").append(user_id).append(",\n");
        buffer.append("Business ID = ").append(businessId).append(",\n");
        buffer.append("Business Preference = ").append(userBusinessPreference);
        buffer.append("-----------------End of User-----------------");
        return buffer.toString();
    }

    public boolean isAffinaUser() {
        return rolesMap.get(AFFINA_ROLE_ID) != null;
    }

    public boolean isAdmin() {
        return rolesMap.get(ADMIN_ROLE_ID) != null || rolesMap.get(ADMIN_ROLE_WITH_UPLOAD_ID) != null||rolesMap.get(REGIONAL_ADMIN_ROLE_ID) != null;
    }
}
