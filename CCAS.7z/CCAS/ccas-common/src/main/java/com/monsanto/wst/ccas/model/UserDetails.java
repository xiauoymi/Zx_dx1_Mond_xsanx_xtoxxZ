package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.controller.userAdmin.UserBusiness;
import com.monsanto.wst.ccas.controller.userAdmin.UserRegion;
import com.monsanto.wst.ccas.importdata.DataObj;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 10, 2006
 * Time: 11:13:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserDetails implements DataObj {

    private String userId = null;
    private String userName = null;
    private int roleId = -1;
    private int businessId = -1;
    private int regionId = -1;
    private String roleDesc = null;
    private String regionDesc = null;

    private int businessPreferenceId = -1;
    private UserRegion userRegion = null;
    private UserBusiness userBusiness;

    public UserDetails(String userId, String userName, int roleId, int regionId, String roleDesc, String regionDesc,
                       int businessId, int businessPreferenceId) {
        this.userId = userId;
        this.userName = userName;
        this.roleId = roleId;
        this.regionId = regionId;
        this.roleDesc = roleDesc;
        this.regionDesc = regionDesc;
        this.businessId = businessId;
        this.businessPreferenceId = businessPreferenceId;
    }

    /**
     * New constructor to be used for assigning a user to more than 1 region
     *
     * @param userId
     * @param userName
     * @param roleId
     * @param roleDesc
     * @param userRegion
     * @param regionDescription
     * @param businessId
     * @param businessPreferenceId
     */
    public UserDetails(String userId, String userName, int roleId, String roleDesc, UserRegion userRegion,
                       String regionDescription, int businessId, int businessPreferenceId) {
        this.userId = userId;
        this.userName = userName;
        this.roleId = roleId;
        this.roleDesc = roleDesc;
        this.businessId = businessId;
        this.businessPreferenceId = businessPreferenceId;
        this.userRegion = userRegion;
        this.regionDesc = regionDescription;
    }

    public int getBusinessPreferenceId() {
        return businessPreferenceId;
    }

    public void setBusinessPreferenceId(int businessPreferenceId) {
        this.businessPreferenceId = businessPreferenceId;
    }

    public int getBusinessId() {
        return businessId;
    }

    public void setBusinessId(int businessId) {
        this.businessId = businessId;
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public int getRoleId() {
        return roleId;
    }

    public int getRegionId() {
        return regionId;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public String getRegionDesc() {
        return regionDesc;
    }

    public void setRegionDesc(String regionDesc) {
        this.regionDesc = regionDesc;
    }

    public UserRegion getUserRegion() {
        return userRegion;
    }

    public void setUserRegion(UserRegion userRegion) {
        this.userRegion = userRegion;
    }

    public void setUserBusiness(UserBusiness userBusiness) {
        this.userBusiness = userBusiness;
    }

    public UserBusiness getUserBusiness() {
        return userBusiness;
    }
}