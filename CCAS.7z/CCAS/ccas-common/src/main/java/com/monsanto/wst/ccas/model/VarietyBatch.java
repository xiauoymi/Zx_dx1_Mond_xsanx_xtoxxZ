/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.model;

import com.monsanto.wst.ccas.constants.MCASConstants;

import java.io.Serializable;

/**
 * Filename:    $RCSfile: VarietyBatch.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class VarietyBatch implements Serializable {

    private Integer varietyBatchId = null;
    private String varietyDesc = null;
    private String batchNumber = null;
    private Float quantityAffected;
    private Long acresAffected;
    private Long uomId;
    private Long seedSizeId;
    private Long ilType;
    private Long batchCropYrId;
    private String varietyActiveFlag = MCASConstants.STATUS_ACTIVE;
    private String batchNumberToBeUpdated = null;
    private Long complaintBatchSeq = null;

    public String getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    private String lotNumber = null;

    public String getCountryOrigin() {
        return countryOrigin;
    }

    public void setCountryOrigin(String countryOrigin) {
        this.countryOrigin = countryOrigin;
    }

    public String getTreatmentType() {
        return treatmentType;
    }

    public void setTreatmentType(String treatmentType) {
        this.treatmentType = treatmentType;
    }

    private String countryOrigin = null;
    private String treatmentType = null;

    public VarietyBatch() {
    }

    public VarietyBatch(Integer varietyBatchId, String varietyDesc, String batchNumber) {
        this.varietyBatchId = varietyBatchId;
        this.varietyDesc = varietyDesc;
        this.batchNumber = batchNumber;
    }

    public VarietyBatch(String varietyDesc, String batchNumber, Float quantityAffected, Long acresAffected, Long uomId,
                        Long seedSizeId, Long ilType, Long batchCropYrId) {
        this.varietyDesc = varietyDesc;
        this.batchNumber = batchNumber;
        this.quantityAffected = quantityAffected;
        this.acresAffected = acresAffected;
        this.uomId = uomId;
        this.seedSizeId = seedSizeId;
        this.ilType = ilType;
        this.batchCropYrId = batchCropYrId;
    }

    public VarietyBatch(String varietyDesc, String batchNumber, Float quantityAffected, Long acresAffected, Long uomId,
                        Long seedSizeId, Long ilType, Long batchCropYrId,String lotNumber,String countryOrigin, String treatmentType) {
        this.varietyDesc = varietyDesc;
        this.batchNumber = batchNumber;
        this.quantityAffected = quantityAffected;
        this.acresAffected = acresAffected;
        this.uomId = uomId;
        this.seedSizeId = seedSizeId;
        this.ilType = ilType;
        this.batchCropYrId = batchCropYrId;
        this.lotNumber=lotNumber;
        this.countryOrigin=countryOrigin;
        this.treatmentType=treatmentType;
    }

    public VarietyBatch(String varietyDesc, String batchNumber, Float quantityAffected, Long acresAffected, Long uomId,
                        Long seedSizeId, Long ilType, Long batchCropYrId,String lotNumber,String countryOrigin, String treatmentType, Long complaintBatchSeq) {
        this.varietyDesc = varietyDesc;
        this.batchNumber = batchNumber;
        this.quantityAffected = quantityAffected;
        this.acresAffected = acresAffected;
        this.uomId = uomId;
        this.seedSizeId = seedSizeId;
        this.ilType = ilType;
        this.batchCropYrId = batchCropYrId;
        this.lotNumber=lotNumber;
        this.countryOrigin=countryOrigin;
        this.treatmentType=treatmentType;
        this.complaintBatchSeq = complaintBatchSeq;
    }

    public Long getIlType() {
        return ilType;
    }

    public void setIlType(Long ilType) {
        this.ilType = ilType;
    }

    public Long getBatchCropYrId() {
        return batchCropYrId;
    }

    public void setBatchCropYrId(Long batchCropYrId) {
        this.batchCropYrId = batchCropYrId;
    }

    public String getVarietyDesc() {
        return varietyDesc;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public Integer getVarietyBatchId() {
        return varietyBatchId;
    }

    public String getVarietyActiveFlag() {
        return varietyActiveFlag;
    }

    public void setVarietyActiveFlag(String varietyActiveFlag) {
        this.varietyActiveFlag=varietyActiveFlag;
    }

    public Float getQuantityAffected() {
        return quantityAffected;
    }

    public Long getAcresAffected() {
        return acresAffected;
    }

    public Long getUomId() {
        return uomId;
    }

    public Long getSeedSizeId() {
        return seedSizeId;
    }

    public void setVarietyBatchId(Integer varietyBatchId) {
        this.varietyBatchId = varietyBatchId;
    }

    public void setVarietyDesc(String varietyDesc) {
        this.varietyDesc = varietyDesc;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public void setQuantityAffected(Float quantityAffected) {
        this.quantityAffected = quantityAffected;
    }

    public void setAcresAffected(Long acresAffected) {
        this.acresAffected = acresAffected;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public void setSeedSizeId(Long seedSizeId) {
        this.seedSizeId = seedSizeId;
    }

     public String getBatchNumberToBeUpdated() {
        return batchNumberToBeUpdated;
    }

     public void setBatchNumberToBeUpdated(String batchNumberToBeUpdated) {
        this.batchNumberToBeUpdated = batchNumberToBeUpdated;
    }

    public Long getComplaintBatchSeq() {
        return complaintBatchSeq;
    }

    public void setComplaintBatchSeq(Long complaintBatchSeq) {
        this.complaintBatchSeq = complaintBatchSeq;
    }
}