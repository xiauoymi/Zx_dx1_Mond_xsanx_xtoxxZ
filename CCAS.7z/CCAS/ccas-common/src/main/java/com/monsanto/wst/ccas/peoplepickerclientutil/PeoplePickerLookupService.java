/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.peoplepickerclientutil;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.Util.StringUtils;

/**
 * Filename:    $RCSfile: PeoplePickerLookupService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class PeoplePickerLookupService {

    public PeoplePickerLookupService() {
        setSystemProperties();
    }

    public String lookupFullName(String userid) throws Exception {
        try {
            PeopleService peopleService = new PeopleService();
            PersonInfo[] person = peopleService.GetPeople("", "", "", "", userid, "", "");
            for (int i = 0; person != null && i < person.length; i++) {
                PersonInfo personInfo = person[i];
                if (personInfo.getUserId().equalsIgnoreCase(userid)) {
                    return getFullName(personInfo);
                }
            }
        } catch (Exception e) {
            throw new Exception(e);
        }
        return null;
    }

    private String getFullName(PersonInfo personInfo) {
        StringBuffer fullName = new StringBuffer();
        fullName.append(personInfo.getLastName()).append(", ").append(personInfo.getFirstName());
        String middleInitial = personInfo.getMiddleName();
        if (!StringUtils.isNullOrEmpty(middleInitial)) {
            fullName.append(" ").append(middleInitial);
        }
        return fullName.toString();
    }

    private void setSystemProperties() {
        System.setProperty("xmlservice.peoplepicker.server", "w3.ent.monsanto.com");
        System.setProperty("xmlservice.peoplepicker.vdir", "/ccca/pps");
        System.setProperty("xmlservice.peoplepicker.endpoint", "PeoplePicker.rem");
    }
}