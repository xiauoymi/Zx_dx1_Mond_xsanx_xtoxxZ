/*
 * Created on Feb 21, 2005
 *
 *
 */
package com.monsanto.wst.ccas.resources;

import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.util.ResourceBundle;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class McasProperties {
    private static ResourceBundle myResource = null;

    public static ResourceBundle getMcasProperties() {
        if (myResource == null) {
            try {
                myResource = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");
            }
            catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return myResource;
    }


    public static ResourceBundle getMcasProperties(String locale) {
        if (myResource != null && !myResource.getLocale().equals(locale)) {
            try {
                if ( locale.equals("es")) {
                   return ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources_es");
                } else{
                        if (locale.equals("pt") ){
                            return ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources_pt");
                        } else {
                              return ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");
                        }
                    }
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
            }
        }
        return myResource;
    }

}
