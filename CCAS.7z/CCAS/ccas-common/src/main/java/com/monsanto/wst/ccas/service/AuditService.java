/*
 * Created on Apr 11, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.model.AuditFilter;
import com.monsanto.wst.ccas.model.AuditListObject;
import com.monsanto.wst.ccas.model.AuditObject;
import com.monsanto.wst.ccas.model.FindingObject;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.util.Map;


/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuditService {

    public String insertAudit(AuditObject auditObj, String appName) throws ServiceException;

    public boolean updateAudit(AuditObject auditObj) throws ServiceException;

    public FindingObject insertFinding(String auditNumber, FindingObject FindingObj) throws ServiceException;

    public boolean updateFinding(FindingObject FindingObj) throws ServiceException;

    public AuditObject getAuditFromList(String auditNo, String locale) throws ServiceException;

    public Map<String, Object> getAuditList(AuditListObject filterObj, String intPage, boolean getMax, String sortCriteria,
                                            String sortOrder, int userBusinessPreferenceId, String applicationName,
                                            Map<String, String[]> requestParamMap) throws ServiceException;


    public String getAuditNumberFromFinding(int findingID) throws ServiceException;

    public Map<String, RowBean> getAuditReport(AuditFilter auditFilter, int businessId, Map<String, String[]> requestMap, String applicationName, String locale) throws ServiceException;

    void deleteAudit(String auditNumber) throws ServiceException;

    public void processAuditCparRelation(Map<String, Object> auditMap) throws DAOException;

    int deleteAuditFinding(String auditId, String findingId) throws DAOException;

    void closeFinding(FindingObject f) throws ServiceException;

  void updateReasonForFinding(FindingObject f) throws ServiceException;
}
