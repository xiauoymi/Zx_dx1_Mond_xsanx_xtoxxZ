/*
 * Created on Apr 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.AuditAction;
import com.monsanto.wst.ccas.actions.IActionHelper;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.FunctionalAreaDaoImpl;
import com.monsanto.wst.ccas.complaints.FunctionDao;
import com.monsanto.wst.ccas.complaints.FunctionDaoImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.AuditDAO;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;

import javax.sql.DataSource;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author rdesai2
 *         <p/>
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class AuditServiceImpl implements AuditService {

    private static final Category logger = Category.getInstance(AuditAction.class.getName());
    private AuditDAO auditDAO;
    private IActionHelper actionHelper;

    public AuditServiceImpl() {
        try {
            auditDAO = (AuditDAO) DAOFactory.getDao(AuditDAO.class);
            actionHelper = new ActionHelper();
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    public AuditServiceImpl(AuditDAO auditDAO, IActionHelper actionHelper) {
        this.auditDAO = auditDAO;
        this.actionHelper = actionHelper;
    }


    public String insertAudit(AuditObject auditObj, String appName) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO service...");

        try {
            return auditDAO.insertAudit(auditObj, appName);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public boolean updateAudit(AuditObject auditObj) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO service...");

        try {
            return auditDAO.updateAudit(auditObj);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public String getAuditNumberFromFinding(int findingID) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO service...");

        try {
            return auditDAO.getAuditNumberFromFinding(findingID);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public AuditObject getAuditFromList(String auditNo, String locale) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO (getAuditFromList) service...");

        try {
            return auditDAO.getAuditFromList(auditNo, locale);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


    public FindingObject insertFinding(String auditNumber, FindingObject findingObj) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO (insertFinding) service...");

        try {
            return auditDAO.insertFinding(auditNumber, findingObj);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public boolean updateFinding(FindingObject findingObj) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO (updateFinding) service...");

        try {
            return auditDAO.updateFinding(findingObj);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }

    }

    public void closeFinding(FindingObject f) throws ServiceException {
        try {
            auditDAO.closeFinding(f);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public void updateReasonForFinding(FindingObject f) throws ServiceException {
        try {
            auditDAO.updateReasonForFinding(f);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


    public Map<String, Object> getAuditList(AuditListObject filterObj, String intPage, boolean getMax, String sortCriteria,
                                            String sortOrder, int userBusinessPreferenceId, String applicationName, Map<String, String[]> requestParamMap) throws ServiceException {

//        logger.info("AuditService: Locating Audit DAO (getAuditList) service...");
        try {
            CheckboxItemServiceImpl.getSelectedCheckboxItems(filterObj, requestParamMap, "auditFilterObj.functionalAreaList");
            return auditDAO.getAuditList(filterObj, intPage, sortCriteria, sortOrder, userBusinessPreferenceId, applicationName);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }

    }


    public Map<String, RowBean> getAuditReport(AuditFilter auditFilter, int businessId, Map<String, String[]> requestMap, String applicationName, String locale) throws ServiceException {
//        logger.info("AuditService: Locating Audit DAO (getAuditReport) service...");

        try {
            FunctionDao functionDao = getFunctionDao();
            //Obtain a list of selected audit areas and set it to complaint filter object
            CheckboxItemServiceImpl.getSelectedCheckboxItems(auditFilter, requestMap, "auditFilter.functionalAreaList");
            Map<String, RowBean> report = getReportMap(auditFilter, locale);
//            System.out.println("report.size() = " + report.size());
            for (String s : report.keySet()) {
                String key = s;
//                System.out.println("key = " + key);
                RowBean rowBean = report.get(key);
                String col14 = "";
                if (rowBean != null) {
                    col14 = rowBean.getCol14();
                    if (!StringUtils.isNullOrEmpty(col14) && !col14.equalsIgnoreCase("-")) {
                        rowBean.setCol(14, functionDao.lookUpFunctionWithId(Integer.parseInt(col14), locale));
                    }
                }

            }
            // Following method added to fix  MCAS Issue 0183386

            if (MCASConstants.APPLICATION_NAME_MCAS.equalsIgnoreCase(applicationName)) {
                modifyFunctionalAreasInReport(report, businessId, locale);
            }
            return report;
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }

    public void deleteAudit(String auditNumber) throws ServiceException {
        try {
            auditDAO.deleteAudit(auditNumber);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }


    private void modifyFunctionalAreasInReport(Map<String, RowBean> report, int businessId, String locale) {
        Map<String, ArrayList> tempRowBeanMap = new HashMap<String, ArrayList>();
        Map<String, HashSet> tempFunctionalAreaMap = new HashMap<String, HashSet>();
        modifyReportBasedOnCarParNumberAndFunctionalAreas(report, tempRowBeanMap, tempFunctionalAreaMap);
        report.clear();
        reArrangeColumnsInAuditReport(report, tempRowBeanMap, tempFunctionalAreaMap, businessId, locale);
    }

    private void modifyReportBasedOnCarParNumberAndFunctionalAreas(Map<String, RowBean> report, Map<String, ArrayList> tempRowBeanMap, Map<String, HashSet> tempFunctionalAreaMap) {
        for (RowBean row : report.values()) {
            String auditNumber = row.getCol1();
            if (tempRowBeanMap.containsKey(auditNumber)) {
                boolean carParNumExists = false;
                tempFunctionalAreaMap.get(auditNumber).add(row.getCol7().trim());
                ArrayList<RowBean> tempRowBeanList = tempRowBeanMap.get(auditNumber);
                for (RowBean rowBean : tempRowBeanList) {
                    if (rowBean.getCol5().equalsIgnoreCase(row.getCol5())) {
                        carParNumExists = true;
                        break;
                    }
                }
                if (!carParNumExists)
                    tempRowBeanList.add(row);
            } else {
                addAuditToMapIfNotPresentInMap(tempRowBeanMap, tempFunctionalAreaMap, row, auditNumber);
            }
        }
    }

    private void addAuditToMapIfNotPresentInMap(Map<String, ArrayList> tempRowBeanMap, Map<String, HashSet> tempFunctionalAreaMap, RowBean row, String auditNumber) {
        ArrayList<RowBean> tempRowBeanList = new ArrayList<RowBean>();
        tempRowBeanList.add(row);
        tempRowBeanMap.put(auditNumber, tempRowBeanList);
        HashSet<String> tempFunctionalAreaSet = new HashSet<String>();
        tempFunctionalAreaSet.add(row.getCol7());
        tempFunctionalAreaMap.put(auditNumber, tempFunctionalAreaSet);
    }

    private void reArrangeColumnsInAuditReport(Map<String, RowBean> report, Map<String, ArrayList> tempRowBeanMap,
                                               Map<String, HashSet> tempFunctionalAreaMap, int businessId, String locale) {
        int rowCount = 0;
        String yes = "Y";
        String no = "N";
        for (ArrayList<RowBean> rowBeansList : tempRowBeanMap.values()) {
            for (RowBean rowBean : rowBeansList) {
                rowCount++;
                rowBean.setCol(7, rowBean.getCol8());
                rowBean.setCol(8, rowBean.getCol9());
                rowBean.setCol(9, rowBean.getCol10());
                rowBean.setCol(10, rowBean.getCol11());
                rowBean.setCol(11, rowBean.getCol12());
                rowBean.setCol(12, rowBean.getCol13());
                rowBean.setCol(13, rowBean.getCol14());
                HashSet<String> tempFunctionalAreaSet = tempFunctionalAreaMap.get(rowBean.getCol1());
                DataSource source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
                FunctionalAreaDaoImpl functionalAreaDAO = new FunctionalAreaDaoImpl(source);
                Map<String, String> functionalAreasMap = functionalAreaDAO.lookUpFunctionalAreasAndColumnNumbersForAudit(businessId, locale);
                String colCount = "";
                try {
                    //What??? why????  There is a getCol() why use reflection???
                    for (String functionalAreaDesc : functionalAreasMap.keySet()) {
                        boolean invokeMethd = false;
                        String methodName = "setCol";
                        colCount = functionalAreasMap.get(functionalAreaDesc);
                        Method method = RowBean.class.getMethod(methodName, Integer.class, String.class);
                        for (String tempFunctionalArea : tempFunctionalAreaSet) {
                            if (functionalAreaDesc.equalsIgnoreCase(tempFunctionalArea)) {
                                invokeMethd = true;
                                break;
                            }
                        }
                        if (invokeMethd)
                            method.invoke(rowBean, Integer.parseInt(colCount), yes);
                        else
                            method.invoke(rowBean, Integer.parseInt(colCount), no);
                    }
                } catch (NoSuchMethodException e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                } catch (InvocationTargetException e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                } catch (IllegalAccessException e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                }
                report.put("" + rowCount, rowBean);
            }
        }
    }


    protected FunctionDao getFunctionDao() {
        return new FunctionDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
    }

    Map<String, RowBean> getReportMap(AuditFilter auditFilter, String locale) throws DAOException {
        return auditDAO.getAuditReport(auditFilter, locale);
    }

    /**
     * Method to set a list of CAR/PAR's for an Audit.
     * Required for BTFAS and SBFAS applications
     *
     * @param auditMap
     * @throws DAOException
     */
    public void processAuditCparRelation(Map<String, Object> auditMap) throws DAOException {
        AuditListObject auditListObject;
        Iterator<Object> iterator = auditMap.values().iterator();
        String auditId = "";
        while (iterator.hasNext()) {
            Object object = iterator.next();
            if (object instanceof AuditListObject) {
                auditListObject = (AuditListObject) object;
                auditId = auditListObject.getAuditId();
                List<Cpar> cparList = auditDAO.getCARList(auditId);
                auditListObject.setCparList(cparList);
            }
        }

    }

    public int deleteAuditFinding(String auditId, String findingId) throws DAOException {
        return auditDAO.deleteAuditFinding(auditId, findingId);
    }
}
