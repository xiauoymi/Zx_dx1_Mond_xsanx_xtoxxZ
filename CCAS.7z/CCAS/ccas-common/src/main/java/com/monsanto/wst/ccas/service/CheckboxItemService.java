package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.audits.CheckboxGroup;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Mar 4, 2011
 * Time: 12:07:36 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CheckboxItemService {

    public List<CheckboxGroup> lookupCheckboxGroups(int businessId, boolean isEdit, String sourceRecordType, String objectId, String locale, Map<String, Boolean> roles, String appName);

    public void setCheckboxGroupsForObject(int businessId, boolean isEdit, String sourceRecordType, ObjectWithCheckboxGroups filter, String recordId, String locale, Map<String, Boolean> roles, String appName);

    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale);
}
