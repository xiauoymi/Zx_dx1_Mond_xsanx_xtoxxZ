package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.audits.*;
import com.monsanto.wst.ccas.dao.CheckboxItemDao;
import com.monsanto.wst.ccas.dao.NonconformanceCategoryDaoImpl;
import com.monsanto.wst.ccas.dao.RootCauseDaoImpl;
import com.monsanto.wst.ccas.model.ObjectWithCheckboxGroups;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Mar 29, 2011
 * Time: 12:54:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckboxItemServiceImpl implements CheckboxItemService {

    private CheckboxItemDao checkboxItemDao;

    public CheckboxItemServiceImpl(CheckboxItemDao dao) {
        checkboxItemDao = dao;
    }

    public List<CheckboxGroup> lookupCheckboxGroups(int businessId, boolean isEdit,
                                                    String auditSourceType, String objectId, String locale, Map<String, Boolean> roles, String appName) {

        Map<String, List<CheckboxItem>> checkboxItemMap = lookupBusinessRelatedCheckboxGroups(businessId, auditSourceType, locale, roles, appName);
        List<CheckboxGroup> checkboxGroupList = null;
        Set selectedCheckboxItemSet = null;
        if (checkboxItemMap != null && checkboxItemMap.size() > 0) {
            checkboxGroupList = createCheckboxItems(checkboxItemMap);
        }
        if (isEdit) {
            if (objectId != null && !objectId.equals("-1")) {
                selectedCheckboxItemSet = lookupCheckboxItemsForEdit(Integer.parseInt(
                        objectId),
                        auditSourceType);
                retainSelectedCheckboxItems(checkboxItemMap, selectedCheckboxItemSet);
            }
        }
        return checkboxGroupList;
    }

    public void setCheckboxGroupsForObject(int businessId, boolean isEdit, String auditType, ObjectWithCheckboxGroups filter, String recordId, String locale, Map<String, Boolean> roles, String appName) {
        List<CheckboxGroup> checkboxGroupList = lookupCheckboxGroups(businessId, isEdit, auditType, recordId, locale, roles,appName );
        if (checkboxGroupList != null && checkboxGroupList.size() > 0) {
            if (this.isFunctionalArea()) {
                filter.setFunctionalAreaList(checkboxGroupList);
            } else if (this.isNonconformanceCategory()) {
                filter.setNonconformanceCategoryList(checkboxGroupList);
            } else if (this.isRootCause()) {
                filter.setRootCauseList(checkboxGroupList);
            }
            for (CheckboxGroup obj : checkboxGroupList) {
                filter.setFunctionalArea(obj);
            }
        }
    }

    public List<CheckboxItem> getRootCauseBasedOnParentRootCause(int parentRootCause, String locale) {
        return checkboxItemDao.getRootCauseBasedOnParentRootCause(parentRootCause, locale) ;
    }

    /*Fix this later*/
    private boolean isNonconformanceCategory() {
        return checkboxItemDao instanceof NonconformanceCategoryDaoImpl;
    }

    private boolean isRootCause() {
        return checkboxItemDao instanceof RootCauseDaoImpl;
    }

    private boolean isFunctionalArea() {
        return checkboxItemDao instanceof FunctionalAreaDaoImpl;
    }

    protected Map<String, List<CheckboxItem>> lookupBusinessRelatedCheckboxGroups(int businessId, String entryType, String locale, Map<String, Boolean> roles, String appName) throws ServiceException {
        if ((isNonconformanceCategory() || isRootCause()) && (entryType.equalsIgnoreCase("S") || entryType.equalsIgnoreCase("P"))) {
            return checkboxItemDao.lookupCheckboxGroups(businessId, "C", locale, roles,appName );
        }
        return checkboxItemDao.lookupCheckboxGroups(businessId, entryType, locale, roles, appName);
    }

    private Set<String> lookupCheckboxItemsForEdit(int auditId, String auditSourceType) {
        return checkboxItemDao.getSelectedItemsForRecord(auditId, auditSourceType);
    }

    private void retainSelectedCheckboxItems(Map<String, List<CheckboxItem>> checkboxMap, Set selectedSet) {
        List<CheckboxItem> checkboxList;
        for (String key : checkboxMap.keySet()) {
            checkboxList = checkboxMap.get(key);
            for (CheckboxItem checkboxItem : checkboxList) {
                checkboxItem.setCheckboxItemValue(false);
                int functionalAreaId = checkboxItem.getCheckboxItemId();
                if (selectedSet.contains(Integer.toString(functionalAreaId))) {
                    checkboxItem.setCheckboxItemValue(true);
                }
            }
        }
    }

    public static void getSelectedCheckboxItems(ObjectWithCheckboxGroups filter,
                                                Map<String, String[]> requestParamMap,
                                                String checkboxNames) {
        List<CheckboxItem> checkboxItemList = new ArrayList<CheckboxItem>();
        AuditRequestHelper helper = new AuditRequestHelper();
        List<SelectedIndex> list = helper.getCheckedIndexes(requestParamMap, checkboxNames);
        SelectedIndex index = null;
        if (list != null && list.size() > 0) {
            CheckboxGroup checkboxGroupObject;
            Object[] checkboxRowArray;
            CheckboxRow checkboxRow;
            Object[] checkboxRowObjectArray;
            CheckboxItem checkboxItem;
            for (SelectedIndex aList : list) {
                index = aList;
                if (isNonconformanceCategorySelected(checkboxNames)) {
                    checkboxGroupObject = filter.getNonconformanceCategoryList().get(index.getFirstIndex());
                } else if (isFunctionalAreaSelected(checkboxNames)) {
                    checkboxGroupObject = filter.getFunctionalAreaList().get(index.getFirstIndex());
                } else {
                    checkboxGroupObject = filter.getRootCauseList().get(index.getFirstIndex());
                }

                if (aList.getThirdIndex() < 0) {

                    List<CheckboxItem> items = checkboxGroupObject.getCheckboxItemList();
                    for (CheckboxItem item : items) {
                        if (item.getCheckboxItemId() == aList.getSecondIndex())
                            checkboxItemList.add(item);
                    }
                } else {
                    checkboxRowArray = checkboxGroupObject.getCheckboxRowList();
                    checkboxRow = (CheckboxRow) checkboxRowArray[index.getSecondIndex()];
                    checkboxRowObjectArray = checkboxRow.getCheckboxItemList();
                    checkboxItem = (CheckboxItem) checkboxRowObjectArray[index.getThirdIndex()];
                    checkboxItemList.add(checkboxItem);
                }
            }
        }

        if (isNonconformanceCategorySelected(checkboxNames)) {
            filter.setSelectedNonconformanceList(checkboxItemList);
        } else if (isFunctionalAreaSelected(checkboxNames)) {
            filter.setSelectedFunctionalAreas(checkboxItemList);
        } else {
            filter.setSelectedRootCauseList(checkboxItemList);
        }
    }

    private static boolean isNonconformanceCategorySelected(String nonconformanceCategoryName) {
        return nonconformanceCategoryName != null && nonconformanceCategoryName.contains("nonconformanceCategoryList");
    }

    private static boolean isFunctionalAreaSelected(String functionalAreaName) {
        return functionalAreaName != null && functionalAreaName.contains("functionalAreaList");
    }


    private List<CheckboxGroup> createCheckboxItems(Map<String, List<CheckboxItem>> categoryMap) {
        List<CheckboxGroup> objectList;
        List<CheckboxItem> categoryList;
        objectList = new ArrayList<CheckboxGroup>(categoryMap.size());
        for (Object obj : categoryMap.keySet()) {
            categoryList = categoryMap.get(obj.toString());
            objectList.add(getCheckboxItem(categoryList));
        }
        return objectList;
    }

    protected CheckboxGroup getCheckboxItem(List<CheckboxItem> categoryList) {
        CheckboxGroup checkboxGroup = new CheckboxGroup(categoryList);
        checkboxGroup.createCheckboxRows();
        return checkboxGroup;
    }
}
