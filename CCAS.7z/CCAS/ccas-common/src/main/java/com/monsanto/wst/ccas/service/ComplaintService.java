/*
 * Created on Jan 13, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.actions.ComplaintImporter;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.dao.ComplaintForCriteria;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import org.apache.struts.action.ActionErrors;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface ComplaintService {
    String getComplaintPK() throws ServiceException;

    void insertComplaint(Complaint c) throws ServiceException;

    void updateComplaint(Complaint c) throws ServiceException;

    void deleteComplaint(List<String> complaintIdList) throws ServiceException;

    Complaint getComplaint(String complaint_id) throws ServiceException;

    Map<String, String> findBatches(String batch_number, String complaint_stopsale_id, int businessId) throws ServiceException;

    Map<String, RowBean> getComplaintReport(ComplaintFilter complaintFilter, int businessId, Map<String, String[]> requestMap, String locale) throws ServiceException;

    void storeInTempTables(List<String> complaintIdList);

    void markComplaintForDeletion(String complaint) throws ServiceException;

    Complaint getComplaint(ComplaintImporter complaintImporter);

    String getForward(User user);

    /**
     * Perform Complaint Specific PRE processing.
     * List of  current pre-processing
     * --Check for Non entered mandatory Fields
     * --Check for State ID for Seminis Regions
     */
    ActionErrors performApplicationSpecificPreProcessing(
            Complaint complaint, String applicationName,
            User user,
            Map<String, String[]> requestParameterMap) throws ServiceException;

    void synchronizeComplaintStatusWithCarStatus(Cpar cpar, String newStatus) throws ServiceException;

    Map<String, Object> getComplaintsList(ComplaintForCriteria complaint, String locale) throws ServiceException;

    Map<String, Object> getComplaintsListWOClaims(ComplaintForCriteria complaint, String locale) throws ServiceException;

    Map<String, String> getComplaintEntryTypeList();

    Map<String, String> getDispositionListForDescription(String locale);

    String getComplaintEntryType(String complaint_id) throws ServiceException;

    List<Disposition> getDispositionListForTeamLead(String locale);

    String[] getComplaintIdsFromCparId(String cparId);

    void setCheckboxGroupsForObject(int i, String s, int complaint_issue_id) throws ServiceException;

    public int getVarietyBatchCombinationId(VarietyBatch varietyBatch);

    public void getVarietyBatch(String complaint_id,Complaint c)throws ServiceException;

    void deleteCheckboxItemsForComplaint(Complaint c);

    /*public void deleteVarietyBatch(String complaintBatchSeq)throws ServiceException;*/
}
