/*
 * Created on Jan 20, 2005
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.actions.ActionHelper;
import com.monsanto.wst.ccas.actions.ComplaintImporter;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactory;
import com.monsanto.wst.ccas.app.ApplicationSpecificProcessorFactoryImpl;
import com.monsanto.wst.ccas.app.ComplaintProcessor;
import com.monsanto.wst.ccas.complaints.*;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.*;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.struts.action.ActionErrors;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author jbrahmb
 */

public class ComplaintServiceImpl implements ComplaintService {
    private final ComplaintDAO complaintDAO;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

    public ComplaintServiceImpl() throws ServiceException {
        complaintDAO = new ComplaintDAOImpl();
    }

    public ComplaintServiceImpl(ComplaintDAO complaintDAO) {
        this.complaintDAO = complaintDAO;
    }

    public String getComplaintPK() throws ServiceException {
        try {
            return complaintDAO.getComplaintPK();
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public void insertComplaint(Complaint c) throws ServiceException {
        try {
            complaintDAO.insertComplaint(c);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }

     public int getVarietyBatchCombinationId(VarietyBatch varietyBatch){
          try {
            return complaintDAO.getVarietyBatchCombinationId(varietyBatch);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
     }

    public void updateComplaint(Complaint c) throws ServiceException {
        try {
            //check if status = closed
            if (c.getStatus_id() != null && (c.getStatus_id().equals(MCASConstants.SBFAS_STATUS__REF_TYPE_1_CLOSED_EFFECTIVE) ||
                    c.getStatus_id().equals(MCASConstants.SBFAS_STATUS__REF_TYPE_1_CLOSED_NOT_EFFECTIVE))) {
                c.setClosingPersonId(c.getRow_user_id());
                c.setClosingDate(sdf.format(new Date()));
            } else {
                c.setClosingPersonId(null);
                c.setClosingDate(null);
            }
            complaintDAO.updateComplaint(c);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
        catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, Object> getComplaintsList(ComplaintForCriteria complaint, String locale) throws ServiceException {
        try {
            return complaintDAO.getComplaintsList(complaint, locale);
        }
        catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, Object> getComplaintsListWOClaims(ComplaintForCriteria complaint, String locale) throws ServiceException {
        try {
            return complaintDAO.getComplaintsListWOClaims(complaint, locale);
        }
        catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public Complaint getComplaint(String complaint_id) throws ServiceException {
        try {
            return complaintDAO.getComplaint(complaint_id);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

     public void getVarietyBatch(String complaint_id,Complaint c)throws ServiceException{
          try {
            complaintDAO.getVarietyBatch(complaint_id,c);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
     }

    /*public void deleteVarietyBatch(String complaintBatchSeq) throws ServiceException {
        try {
            complaintDAO.deleteVarietyBatch(complaintBatchSeq);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    } */

    public Map<String, String> findBatches(String batch_number, String complaint_stopsale_id, int businessId) throws ServiceException {
        try {
            return complaintDAO.findBatches(batch_number, complaint_stopsale_id, businessId);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }

    }

    public Map<String, RowBean> getComplaintReport(ComplaintFilter complaintFilter, int businessId, Map<String, String[]> requestMap, String locale) throws ServiceException {
        try {
            DataSource source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
            ComplaintBusinessDao complaintBusinessDao = new ComplaintBusinessDaoImpl(source);
            LookUpService lookUpService = new LookUpServiceImpl();
            ComplaintTypeDao complaintTypeDao = new ComplaintTypeDaoImpl(source);
            FunctionDao functionDao = new FunctionDaoImpl(source);
            MaterialGroupDao materialGroupDao = new MaterialGroupDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            MaterialPricingGroupDao materialPricingGroupDao = new MaterialPricingGroupDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            BusinessDao businessDao = new BusinessDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            SalesOfficeDao salesOfficeDao = new SalesOfficeDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            //Obtain a list of all the selected complaint Issues and set it to Complaint Filter Object
            ActionHelper actionHelper = new ActionHelper();

            CheckboxItemServiceImpl.getSelectedCheckboxItems(complaintFilter, requestMap, "complaintFilter.nonconformanceCategoryList");
            CheckboxItemServiceImpl.getSelectedCheckboxItems(complaintFilter, requestMap, "rootCauseList");
            CheckboxItemServiceImpl.getSelectedCheckboxItems(complaintFilter, requestMap, "complaintFilter.functionalAreaList");

            Map<String, RowBean> report = complaintDAO.getComplaintReport(complaintFilter, businessId, locale);
            for (String s : report.keySet()) {
                String key = s;
                RowBean rowBean = report.get(key);
                String col65 = rowBean.getCol65();
                if (col65 != null && !col65.equalsIgnoreCase("-")) {
                    rowBean.setCol(65, complaintBusinessDao.lookUpComplaintBusinessWithId(Integer.parseInt(col65), locale));
                }
                String col66 = rowBean.getCol66();
                if (col66 != null && !col66.equalsIgnoreCase("-")) {
                    rowBean.setCol(66, lookUpService.lookUpFeedbackCategoryById(col66, locale));
                }
                String col67 = rowBean.getCol67();
                if (col67 != null && !col67.equalsIgnoreCase("-")) {
                    rowBean.setCol(67, complaintTypeDao.lookUpComplaintTypeWithId(Integer.parseInt(col67), locale));
                }
                String col68 = rowBean.getCol68();
                if (col68 != null && !col68.equalsIgnoreCase("-")) {
                    rowBean.setCol(68, functionDao.lookUpFunctionWithId(Integer.parseInt(col68), locale));
                }
                String col69 = rowBean.getCol69();
                if (col69 != null && !col69.equalsIgnoreCase("-")) {
                    String businessid = businessDao.lookupBusinessWithId(Integer.parseInt(col69), locale);
                    if (businessid != null) {
                        rowBean.setCol(69, businessid);
                    } else {
                        rowBean.setCol(69, "-");
                    }
                }

                String col70 = rowBean.getCol70();
                if (col70 != null && !col70.equalsIgnoreCase("-")) {
                    String salesOfficeId = salesOfficeDao.lookupSalesOfficeWithId(col70);
                    if (salesOfficeId != null) {
                        rowBean.setCol(70, salesOfficeId);
                    } else {
                        rowBean.setCol(70, "-");
                    }
                }

                String col71 = rowBean.getCol71();
                if (col71 != null && !col71.equalsIgnoreCase("-")) {
                    String materialGroupId = materialGroupDao.lookupMaterialGroupWithId(Integer.parseInt(col71), locale);
                    if (materialGroupId != null) {
                        rowBean.setCol(71, materialGroupId);
                    } else {
                        rowBean.setCol(71, "-");
                    }
                }

                String col72 = rowBean.getCol72();
                if (col72 != null && !col72.equalsIgnoreCase("-")) {
                    String materialPricingGroupId = materialPricingGroupDao.lookupMaterialPricingGroupWithId(Integer.parseInt(col72), locale);
                    if (materialPricingGroupId != null) {
                        rowBean.setCol(72, materialPricingGroupId);
                    } else {
                        rowBean.setCol(72, "-");
                    }
                }

                String col78 = rowBean.getCol78();
                if (col78 != null && !col78.equalsIgnoreCase("-")) {
//          String materialPricingGroupId = materialPricingGroupDao.lookupMaterialPricingGroupWithId(col72);
                    if (col78.equalsIgnoreCase(Integer.toString(1))) {
                        rowBean.setCol(72, "Y");
                    }
                    if (col78.equalsIgnoreCase(Integer.toString(0))) {
                        rowBean.setCol(72, "N");
                    }
                }
            }
            return report;
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


//    private void populateSelectedNonconformanceCategories(ComplaintFilter complaintFilter, List<CheckboxItem> selectedNonconformanceCategories) {
//        List<Integer> nonconformanceCategoryIdList = new ArrayList<Integer>();
//        for (CheckboxItem checkboxItem : selectedNonconformanceCategories) {
//            nonconformanceCategoryIdList.add(checkboxItem.getCheckboxItemId());
//        }
//        complaintFilter.setNonconformanceCategoryIdList(nonconformanceCategoryIdList);
//    }

    public void storeInTempTables(List<String> complaintIdList) {
        try {
            ComplaintDAO complaintDAO = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
            complaintDAO.processComplaintInsert(complaintIdList);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    public void markComplaintForDeletion(String complaintId) throws ServiceException {
        try {
            ComplaintDAO complaintDAO = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
            complaintDAO.deleteComplaint(complaintId);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Error Deleting complaint....." + e.getMessage(), e);
        }

    }

    public Complaint getComplaint(ComplaintImporter complaintImporter) {
        return complaintImporter.getComplaint();
    }

    public void deleteComplaint(List<String> complaintIdList) throws ServiceException {
        try {
            ComplaintDAO complaintDAO = (ComplaintDAO) DAOFactory.getDao(ComplaintDAO.class);
            complaintDAO.processComplaintDelete(complaintIdList);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        } catch (SQLException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    public String getForward(User user) {
        boolean canWriteComplaint = user.hasPermission("6");
        boolean canWriteAffinaComplaint = user.hasPermission("3");
        boolean canReadComplaint = user.hasPermission("5");
        boolean canReadAffinaComplaint = user.hasPermission("2");

        if (canWriteComplaint) {
            return MCASConstants.SUCCESS_MESSAGE;
        } else if (canWriteAffinaComplaint) {
            return MCASConstants.SUCCESS_AFFINA_MESSAGE;
        } else if (canReadComplaint) {
            return MCASConstants.SUCCESS_MESSAGE;
        } else if (canReadAffinaComplaint) {
            return MCASConstants.SUCCESS_AFFINA_MESSAGE;
        } else {
            return "";
        }
    }

    /**
     * Perform Complaint Specific PRE processing.
     * <List of  current pre-processing>
     * --Check for Non entered mandatory Fields
     * --Check for State ID for Seminis Regions
     *
     * @param complaint
     * @param applicationName
     * @param user
     * @param requestParameterMap
     * @return
     */
    public ActionErrors performApplicationSpecificPreProcessing(
            Complaint complaint, String applicationName,
            User user,
            Map<String, String[]> requestParameterMap) throws ServiceException {
        //Change for Application Specific things

        ApplicationSpecificProcessorFactory applicationSpecificProcessorFactory =
                new ApplicationSpecificProcessorFactoryImpl();
        ComplaintProcessor processor =
                applicationSpecificProcessorFactory.getApplicationSpecificProcessor(applicationName).getComplaintProcessor();
        ActionErrors allErrors = new ActionErrors();
        ActionErrors errors = processor.processComplaint(complaint,
                user);
        allErrors.add(errors);

        return allErrors;
    }

    public void synchronizeComplaintStatusWithCarStatus(Cpar cpar, String newStatus) throws ServiceException {

        if (cpar.getComplaint_id() == null) return;

        for (int i = 0; i < cpar.getComplaint_id().length; i++) {
            String complaintId = cpar.getComplaint_id()[i];
            Complaint complaint = getComplaint(complaintId);
            if (complaint != null) {
                complaint.setStatus_id(newStatus);
                updateComplaint(complaint);
            }
        }
    }

    public Map<String, String> getComplaintEntryTypeList() {
        return complaintDAO.lookupComplaintEntryTypeList();
    }

    public Map<String, String> getDispositionListForDescription(String locale) {
        return complaintDAO.lookupDispositionListForDescription(locale);
    }

    public List<Disposition> getDispositionListForTeamLead(String locale) {
        return complaintDAO.lookupDispositionListForTeamLead(locale);
    }

    public String getComplaintEntryType(String complaintId) throws ServiceException {
        try {
            return complaintDAO.getComplaintEntryTypeAsString(complaintId);
        } catch (DAOException e) {
            throw new ServiceException("Exception getting Complaint Entry type associated to Cpar in " + getClass().getName() + ".getComplaintEntryType()", e);
        }
    }

    public String[] getComplaintIdsFromCparId(String cparId) {
        return complaintDAO.getComplaintIdsFromCparId(cparId);
    }

    public void deleteCheckboxItemsForComplaint(Complaint c){
        try {
                    complaintDAO.deleteCheckboxItemsForComplaint(c);
                }
                catch (DAOException e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                    throw new ServiceException(e);
                }
                catch (Exception e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                    throw new ServiceException(e);
                }
            }


    public void setCheckboxGroupsForObject(int complaintId, String sourceType, int complaint_issue_id) throws ServiceException {
        try {
            complaintDAO.insertCheckboxItemsForRecord(complaintId, sourceType,
                                            complaint_issue_id);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }
}
