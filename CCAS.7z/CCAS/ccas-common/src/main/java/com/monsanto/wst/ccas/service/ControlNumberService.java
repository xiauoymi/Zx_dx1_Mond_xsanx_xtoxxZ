/*
 * Created on Mar 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;


/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface ControlNumberService {
    public boolean generateControlNumber(Object o, boolean isMCAS, boolean isSBFAS, boolean isBIOTECHFAS) throws ServiceException;
}
