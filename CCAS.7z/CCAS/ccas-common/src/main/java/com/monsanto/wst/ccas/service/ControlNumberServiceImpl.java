/*
 * Created on Mar 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.ControlNumberDAO;
import com.monsanto.wst.ccas.dao.ControlNumberDAOImpl;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.util.MCASLogUtil;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class ControlNumberServiceImpl implements ControlNumberService {
    private final ControlNumberDAO controlNumDAO;

    public ControlNumberServiceImpl() {
        controlNumDAO = new ControlNumberDAOImpl();
    }

    public boolean generateControlNumber(Object o, boolean isMCAS,boolean isSBFAS, boolean isBIOTECHFAS) throws ServiceException {
        try {
            return controlNumDAO.generateControlNumber(o, isMCAS, isSBFAS, isBIOTECHFAS);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }
}
