package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.dao.DAOException;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 7, 2010
 * Time: 10:43:27 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CparEmailService {

    public Iterator<Cpar> getOverdueContainmentAction() throws DAOException;

    public Iterator<Cpar> getOverdueRootCause() throws DAOException;

    public Iterator<Cpar> getOverdueLongTermCorrectiveAction() throws DAOException;

    public Iterator<Cpar> getOverdueEvaluationOfEffectiveness() throws DAOException;

    public Iterator<Cpar> getOverdueClose() throws DAOException;

    public Iterator<Cpar> getOverdueApprovedWarning() throws DAOException;
}
