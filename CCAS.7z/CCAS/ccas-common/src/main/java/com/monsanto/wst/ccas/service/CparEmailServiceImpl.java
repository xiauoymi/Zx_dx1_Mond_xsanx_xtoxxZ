package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.dao.AutomatedEmailsDao;
import com.monsanto.wst.ccas.dao.CparEmailDao;
import com.monsanto.wst.ccas.dao.AutomatedEmailsDaoImpl;
import com.monsanto.wst.ccas.dao.DAOException;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Sep 7, 2010
 * Time: 10:47:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class CparEmailServiceImpl implements CparEmailService{

    AutomatedEmailsDao emailSettingsDao;
    CparEmailDao overdueCparDao;

    public CparEmailServiceImpl(AutomatedEmailsDao automatedEmailsDao, CparEmailDao cparEmailDao) {
        emailSettingsDao = automatedEmailsDao;
        overdueCparDao = cparEmailDao;
    }

    public Iterator<Cpar> getOverdueContainmentAction() throws DAOException {
        return overdueCparDao.getOverdueContainmentAction(emailSettingsDao.getContainmentActionDays(), emailSettingsDao.getBeginDate());
    }

    public Iterator<Cpar> getOverdueRootCause() throws DAOException {
        return overdueCparDao.getOverdueRootCause(emailSettingsDao.getRootCauseDays(), emailSettingsDao.getBeginDate());
    }

    public Iterator<Cpar> getOverdueLongTermCorrectiveAction() throws DAOException {
        return overdueCparDao.getOverdueLongTermCorrectiveAction(emailSettingsDao.getLongTermCorrectiveActionDays(), emailSettingsDao.getBeginDate());
    }

    public Iterator<Cpar> getOverdueEvaluationOfEffectiveness() throws DAOException {
        return overdueCparDao.getOverdueEvaluationOfEffectiveness(emailSettingsDao.getEvaluationOfEffectivenessDays(), emailSettingsDao.getBeginDate());
    }

    public Iterator<Cpar> getOverdueClose() throws DAOException {
        return overdueCparDao.getOverdueClose(emailSettingsDao.getCloseDays());        
    }

    //warning for Pars with overdue approval 5 days before evaluation of effectiveness deadline.
    public Iterator<Cpar> getOverdueApprovedWarning() throws DAOException {
        return overdueCparDao.getOverdueApprovedWarning(emailSettingsDao.getCloseDays(), emailSettingsDao.getEvaluationOfEffectivenessWarningDays(), emailSettingsDao.getBeginDate());
    }
}
