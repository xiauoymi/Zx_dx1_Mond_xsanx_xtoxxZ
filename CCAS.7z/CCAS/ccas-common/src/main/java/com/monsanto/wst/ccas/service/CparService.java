/*
 * Created on Feb 21, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.CparFilter;
import com.monsanto.wst.ccas.model.CparLog;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.util.Map;
import java.util.List;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface CparService {
    public String getCparPK() throws ServiceException;

    public void insertCpar(Cpar cpar) throws ServiceException;

    public void updateCpar(Cpar cpar) throws ServiceException;

    public boolean deleteCpar(Cpar cpar) throws ServiceException;

    public Map<String, Object> getCparsList(String controlNumber, String createDateFrom, String createDateTo,
                                            String initiatedBy, String status, String region, String claimNumber,
                                            String carFlag, String filingLoc, String responsibleLoc, String intPage,
                                            boolean getMax, String criteria, String order, String cparBusinessId,
                                            String functionId, int businessPreferenceId, int type, String filingProgramId,
                                            String responsibleProgramId, String generator, String findingType,
                                            String isoStandardId, String locale, String siteManager, String searchText,
                                            String closingDate, List<Integer> functionalAreaIdList, String cropId)
            throws ServiceException;

    public Cpar getCpar(String Cpar_id,boolean isBiotech) throws ServiceException;

    public Cpar getCparByControlNo(String control_no, int business_id) throws ServiceException;

    public Map<String, String> findCPAR(String complaint_id, String carFlag) throws ServiceException;

    public Map<String, RowBean> getCparReport(CparFilter cparFilter, int businessId, Map<String, String[]> requestMap, String locale) throws ServiceException;

    public Map<String, RowBean> getCparLog(CparLog cparLog, String locale) throws ServiceException;
}
