/*
 * Created on Feb 21, 2005
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.complaints.ComplaintBusinessDao;
import com.monsanto.wst.ccas.complaints.ComplaintBusinessDaoImpl;
import com.monsanto.wst.ccas.complaints.FunctionDao;
import com.monsanto.wst.ccas.complaints.FunctionDaoImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.*;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.model.CparFilter;
import com.monsanto.wst.ccas.model.CparLog;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;


public class CparServiceImpl implements CparService {
    private CparDAO cparDao;
    private DataSource source;

    public CparServiceImpl(CparDAO cparDao) {
        this.cparDao = cparDao;
    }

    public CparServiceImpl() {
        try {
            cparDao = (CparDAO) DAOFactory.getDao(CparDAO.class);
            source = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    public String getCparPK() throws ServiceException {
        try {
            return cparDao.getCparPK();
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public void insertCpar(Cpar c) throws ServiceException {
        try {
            cparDao.insertCpar(c);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
        catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public void updateCpar(Cpar c) throws ServiceException {
        try {
            //check if status = closed
            if (c.getStatus_id() != null && (c.getStatus_id().equals(MCASConstants.SBFAS_STATUS__REF_TYPE_2_CLOSED_EFFECTIVE) ||
                    c.getStatus_id().equals(MCASConstants.SBFAS_STATUS__REF_TYPE_2_CLOSED_NOT_EFFECTIVE))) {
                c.setClosingPersonId(c.getRow_user_id());
            } else {
                c.setClosingPersonId(null);
            }
            //check if status = closed
            if (c.getStatus_id() != null && (c.getStatus_id().equals(MCASConstants.MCAS_STATUS_REF_TYPE_CLOSED))) {
                c.setClosingDate(MCASUtil.getDateFormat(new java.util.Date(System.currentTimeMillis())));
            } else {
                c.setClosingDate(null);
            }

            cparDao.updateCpar(c);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
        catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public boolean deleteCpar(Cpar cpar) throws ServiceException {
        boolean isCparDeleted = false;
        try {
            isCparDeleted = cparDao.deleteCpar(cpar);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("Unable to Obtain Implementation class for CparDAO", e);
        }
        return isCparDeleted;
    }

    public Map<String, Object> getCparsList(String controlNumber, String createDateFrom, String createDateTo,
                                            String initiatedBy, String status, String region, String claimNumber,
                                            String carFlag, String filingLoc, String responsibleLoc, String intPage,
                                            boolean getMax, String criteria, String order, String cparBusinessId,
                                            String functionId, int businessPreferenceId, int type, String filingProgramId,
                                            String responsibleProgramId, String generator, String findingType,
                                            String isoStandardId, String locale, String siteManager, String searchText,
                                            String closingDate, List<Integer> functionalAreaIdList, String cropId)
            throws ServiceException {
        Map<String, Object> CparsMap = null;

        try {
            CparsMap = cparDao
                    .getCparsList(controlNumber, createDateFrom, createDateTo, initiatedBy, status, region, claimNumber,
                            carFlag, filingLoc, responsibleLoc, intPage, criteria, order, cparBusinessId, functionId,
                            businessPreferenceId, type, filingProgramId, responsibleProgramId, generator, findingType,
                            isoStandardId, locale, siteManager, searchText, closingDate, functionalAreaIdList, cropId);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return CparsMap;
    }

    public Cpar getCpar(String Cpar_id, boolean isBIOTECHFAS) throws ServiceException {
        try {
            return cparDao.getCpar(Cpar_id, isBIOTECHFAS);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public Cpar getCparByControlNo(String control_no, int business_id) throws ServiceException {
        try {
            return cparDao.getCparByControlNo(control_no, business_id);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


    public Map<String, String> findCPAR(String complaint_id, String carFlag) throws ServiceException {
        try {
            return cparDao.findCAR(complaint_id, carFlag);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }

    }

    public Map<String, RowBean> getCparReport(CparFilter cparFilter, int businessId, Map<String, String[]> requestMap,
                                              String locale) throws ServiceException {
        try {

            ComplaintBusinessDao complaintBusinessDao = new ComplaintBusinessDaoImpl(source);
            FunctionDao functionDao = getFunctionDao();
            BusinessDao businessDao = new BusinessDaoImpl(source);

            //Obtain the Selected Complaint Category
            CheckboxItemServiceImpl.getSelectedCheckboxItems(cparFilter, requestMap, "cparFilter.nonconformanceCategoryList");
            CheckboxItemServiceImpl.getSelectedCheckboxItems(cparFilter, requestMap, "rootCauseList");
            CheckboxItemServiceImpl.getSelectedCheckboxItems(cparFilter, requestMap, "cparFilter.functionalAreaList");

            Map<String, RowBean> cparReport = getCparReportMap(cparFilter, businessId, locale);
//      System.out.println("cparReport.size() = " + cparReport.size());
            for (String s : cparReport.keySet()) {
                String key = s;
                RowBean rowBean = cparReport.get(key);
                String col40 = rowBean.getCol40();
                if (col40 != null && !col40.equalsIgnoreCase("-")) {
                    rowBean.setCol(40, complaintBusinessDao.lookUpComplaintBusinessWithId(Integer.parseInt(col40), locale));
                }
                String col41 = rowBean.getCol41();
                if (col41 != null && !col41.equalsIgnoreCase("-")) {
                    rowBean.setCol(41, functionDao.lookUpFunctionWithId(Integer.parseInt(col41), locale));
                }
                String col42 = rowBean.getCol42();
                if (col42 != null && !col42.equalsIgnoreCase("-")) {
                    rowBean.setCol(42, businessDao.lookupBusinessWithId(Integer.parseInt(col42), locale));
                }
                String col45 = rowBean.getCol45();
                if (col45 == null || "0".equalsIgnoreCase(col45))
                    rowBean.setCol(45, "N");
                else
                    rowBean.setCol(45, "Y");
            }

            return cparReport;
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public Map<String, RowBean> getCparReportMap(CparFilter cparFilter, int businessId, String locale) throws
            DAOException {
        return cparDao.getCparReport(cparFilter, businessId, locale);
    }

    protected FunctionDao getFunctionDao() {
        return new FunctionDaoImpl(source);
    }

    public Map<String, RowBean> getCparLog(CparLog cparLog, String locale) throws ServiceException {

        try {
            FunctionDao functionDao = new FunctionDaoImpl(source);
            BusinessDao businessDao = new BusinessDaoImpl(source);
            Map<String, RowBean> report = cparDao.getCparLog(cparLog);
            for (String s : report.keySet()) {
                String key = s;
//        System.out.println("key = " + key);
                RowBean rowBean = report.get(key);
                String col9 = rowBean.getCol9();
                if (col9 != null && !col9.equalsIgnoreCase("-")) {
                    rowBean.setCol(9, functionDao.lookUpFunctionWithId(Integer.parseInt(col9), locale));
                }
                String col10 = rowBean.getCol10();
                if (col10 != null && !col10.equalsIgnoreCase("-")) {
                    rowBean.setCol(10, businessDao.lookupBusinessWithId(Integer.parseInt(col10), locale));
                }
            }
            return report;
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }


}
