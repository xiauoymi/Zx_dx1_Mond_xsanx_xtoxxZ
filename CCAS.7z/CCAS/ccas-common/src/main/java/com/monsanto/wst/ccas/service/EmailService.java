/*
 * Created on Mar 22, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.ctc.wstx.util.StringUtil;
import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;
import com.monsanto.wst.ccas.app.EntryTypeFactory;
import com.monsanto.wst.ccas.app.EntryTypeFactoryImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.EmailInfo;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.resources.McasProperties;
import com.monsanto.wst.ccas.util.CCASEmailUtilImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class EmailService implements IEmailService {
    static Category logger = Category.getInstance(EmailService.class.getName());
    private final String appName;
    private String feedbackOrComplaint;
    private final LookUpService lookupService;

    public EmailService() {
        appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext");
        feedbackOrComplaint = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.complaintOrFeedback");
        lookupService = new LookUpServiceImpl();
    }

    public EmailService(LookUpService lookupService) {
        appName = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.applicationContext");
        feedbackOrComplaint = McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.complaintOrFeedback");
        this.lookupService = lookupService;
    }


    public boolean sendEmailForComplaint(Complaint complaint, String type, String printPreviewSrc,
                                         String statusDescription, boolean isNew, boolean complaintStatusHasChanged, boolean isUpload)
            throws EmailException, EmailAddressRetrievalException {

        boolean isClosed = complaint.isClosed();
        /*
        if (complaint.getBusinessId() == 1 && !(isNew || (complaintStatusHasChanged && isClosed))) {
            if (complaint.isANorthAmericanComplaint()) return true;
        } */

        EntryTypeFactory entryTypeFactory = new EntryTypeFactoryImpl();
        feedbackOrComplaint = entryTypeFactory.getEntryTypeEmaiSubject(complaint.getEntryType());
        EmailInfo email = new EmailInfo();
        boolean audotSendEmail = true;
        CCASEmailUtilImpl emailUtil = new CCASEmailUtilImpl(new PeopleService());
        StringBuffer toEmail = new StringBuffer(emailUtil.getEmailAddressForUser(complaint.getReport_initiator())).append(";");

        if (isUpload)
            try{
            toEmail.append(emailUtil.getEmailAddressForUser(complaint.getPerson_investigating())).append(";");
            }
            catch(EmailAddressRetrievalException e){

            }

        email.setFrom(lookupService.getEmail(MCASConstants.ADMIN_EMAIL)[0]);
        email.setToArray(toEmail, ";");
        email.setSubject(getEmailSubject(complaint.getComplaint_id(), type, statusDescription, isNew));

        if(complaint.isClosed()){
             email.setBody(getEmailBodyClosedComplaint(complaint.getComplaint_id(), complaint.getClaim_number()) + " " + printPreviewSrc);
        }
       else if (isNewComplaint(type)) {
            email.setBody(getEmailBody(complaint.getComplaint_id(), isNew) + " " + printPreviewSrc);
        } else if (complaint.statusChanged()) {
            email.setBody(printPreviewSrc);
        }
        return sendMailOnObjectCreate(email, audotSendEmail);

    }


    private boolean isNewComplaint(String type) {
        return type.equals(ActionHelperConstants.EMAIL_TYPE_COMPLAINT_NEW);
    }

    private String getEmailSubject(String complaintId, String type, String statusDescription, boolean isNew) {
        return isNewComplaint(type) ? getCreateSubject(complaintId, isNew) : getStatusChangeSubject(complaintId, statusDescription);
    }

    private String getStatusChangeSubject(String complaintId, String statusDescription) {
        return " The status of " + feedbackOrComplaint + " " + complaintId + " has changed to " +
                statusDescription;
    }

    private String getCreateSubject(String complaintId, boolean isNew) {
        if (isNew) {
            return feedbackOrComplaint + " ID:" + complaintId + " has been created.";
        } else {
            return feedbackOrComplaint + " ID:" + complaintId + " has been updated.";
        }
    }

    private String getEmailBody(String id, boolean isNew) {
        if (isNew) {
            return "A new " + feedbackOrComplaint + " (ID :" + id +
                    ") has been entered into the " + appName + " system." + "\n";
        } else {
            return "A " + feedbackOrComplaint + " (ID :" + id +
                    ") has been updated in the " + appName + " system." + "\n";
        }

    }

    private String getEmailBodyClosedComplaint(String id, String claimNo) {
        if(StringUtils.isNullOrEmpty(claimNo)){
            return "A " + feedbackOrComplaint + " (ID :" + id +
                                ")  has been updated in the " + appName + " system." + "\n";

        }
        else{
            return "A " + feedbackOrComplaint + " (ID :" + id +
                                ") with claim no: "+claimNo +" has been updated in the " + appName + " system." + "\n";

        }


    }

    public boolean sendEmailForComplaint(
    ) {
        return false;
    }

    /**
     * Once an Investigation Finding is assigned a CPAR an email is sent to that person.
     *
     *
     * @param cpar
     * @param toAdmin
     * @throws EmailException
     */
    public void sendEmailToCPARResponsible(Cpar cpar, boolean toAdmin) throws EmailException {
        try {
            CCASEmailUtilImpl util = new CCASEmailUtilImpl(new PeopleService());
            String userName = cpar.getInvestigation_findings_person();
            String emailAddress = util.getEmailAddressForUser(userName);
            boolean isCI = cpar.getControl_number().startsWith("CI");
            String cparType = "Y".equals(cpar.getCar_flag()) ? "CAR" : (isCI ? "CI" : "PAR");
            ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");

            String environment = System.getProperty("lsi.function");
            String adminEmailList=bundle.getString(environment+".admin.mail.account");
            String subject = cparType + " " + McasProperties.getMcasProperties().
                    getString("com.monsanto.wst.ccas.cpar.EmailEntryPart") + " " + cpar.getControl_number() + " " +
                    McasProperties.getMcasProperties().getString("com.monsanto.wst.ccas.cpar.EmailAssignPart");

            String body = subject + McasProperties.getMcasProperties().
                    getString("com.monsanto.wst.ccas.cpar.EmailDaysPart");

            EmailInfo info = new EmailInfo();
            info.setFrom("administrator.biotech-qms@monsanto.com");
            info.setTo(emailAddress);

            if(toAdmin){
                info.appendTo(adminEmailList);
            }

            info.setSubject(subject);
            info.setBody(body);
            sendEmail(info);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new EmailException("Error sending email", e);
        }
    }


    private void addSingleRecipient(String address, Message.RecipientType type, MimeMessage message) throws MessagingException {
        message.addRecipient(type, new InternetAddress(address));

    }

    private void addRecipients(MimeMessage message, String[] emailAddress, Message.RecipientType recipientType) throws MessagingException {
        if (emailAddress != null && emailAddress.length > 0) {
            for (String emailAddr : emailAddress) {
                if (!StringUtils.isNullOrEmpty(emailAddr))
                    message.addRecipient(recipientType, new InternetAddress(emailAddr));
            }
        }
    }

    private MimeMessage setEmailMessageProperties(boolean autoSendEmail, Session session, EmailInfo email) throws MessagingException {
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(email.getFrom()));
        addRecipients(message, email.getToArray(), Message.RecipientType.TO);
        addRecipients(message, email.getCcArray(), Message.RecipientType.CC);
        addRecipients(message, email.getBccArray(), Message.RecipientType.BCC);
        message.setSubject(email.getSubject(),"UTF-8");
        return message;
    }

    public MimeMessage configureEmailProperties(boolean autoSendEmail, EmailInfo email) throws MessagingException {
        Properties props = System.getProperties();
        props.put("mail.smtp.host", email.getHost());
        Session session = Session.getDefaultInstance(props, null);
        return setEmailMessageProperties(autoSendEmail, session, email);
    }

    public void sendEmail(EmailInfo email) throws EmailException {
        try {
            MimeMessage message = configureEmailProperties(false, email);
            message.setText(email.getBody());
            Transport.send(message);
        }
        catch (MessagingException me) {
            throw new RuntimeException(me);
        }
        catch (Exception e) {
            throw new EmailException("Error sending email", e);
        }
    }


    private MimeMultipart createMultipartMimeMessage(EmailInfo email) throws MessagingException {
        MimeMultipart multipart = new MimeMultipart("alternative");
        MimeBodyPart htmlPart = new MimeBodyPart();
        htmlPart.setContent(email.getBody(), "text/html;charset=UTF-8");
        multipart.addBodyPart(htmlPart);
        return multipart;
    }

    private MimeMultipart createMultipartMimeMessageAttachment(EmailInfo email,InputStream attachment,String fileType,String fileName) throws MessagingException, IOException {
        MimeMultipart multipart = new MimeMultipart("alternative");
        MimeBodyPart htmlPart = new MimeBodyPart();
        MimeBodyPart attachmentPart = new MimeBodyPart();
        htmlPart.setContent(email.getBody(), "text/html;charset=UTF-8");
        multipart.addBodyPart(htmlPart);

// Part two is attachment

                ByteArrayDataSource ds = new ByteArrayDataSource(attachment, "application/"+fileType);
                attachmentPart.setDataHandler(new DataHandler(ds));
                attachmentPart.setFileName(fileName);
                multipart.addBodyPart(attachmentPart);




        return multipart;
    }

    public boolean sendMailOnObjectCreate(EmailInfo email, boolean autoSendEmail) throws EmailException {
        boolean result = true;
        try {
            MimeMessage message = configureEmailProperties(autoSendEmail, email);
            MimeMultipart multipart = createMultipartMimeMessage(email);
            message.setContent(multipart);
            message.saveChanges();
            Transport.send(message);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new EmailException("Error sending email", e);
        }
        return result;
    }

    public boolean sendMailWithAttachment(EmailInfo email,InputStream attachment,String fileType,String fileName) throws EmailException {
        boolean result = true;
        try {
            MimeMessage message = configureEmailProperties(false, email);
            MimeMultipart multipart = createMultipartMimeMessageAttachment(email, attachment, fileType, fileName);
            message.setContent(multipart);
            message.saveChanges();
            Transport.send(message);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new EmailException("Error sending email", e);
        }
        return result;
    }





    public boolean sendEmailForComplaintCreateFromExcel(Complaint complaint, String type, String printPreviewSrc,
                                         String statusDescription, boolean isNew, boolean complaintStatusHasChanged, boolean isUpload, boolean isCreate)
            throws EmailException, EmailAddressRetrievalException {

        boolean isClosed = complaint.isClosed();
        if (complaint.getBusinessId() == 1 && !(isNew || (complaintStatusHasChanged && isClosed))) {
            if (complaint.isANorthAmericanComplaint()) return true;
        }

        EntryTypeFactory entryTypeFactory = new EntryTypeFactoryImpl();
        feedbackOrComplaint = entryTypeFactory.getEntryTypeEmaiSubject(complaint.getEntryType());
        EmailInfo email = new EmailInfo();
        boolean audotSendEmail = true;
        CCASEmailUtilImpl emailUtil = new CCASEmailUtilImpl(new PeopleService());
        StringBuffer toEmail = new StringBuffer(emailUtil.getEmailAddressForUser(complaint.getReport_initiator())).append(";");

        if (isUpload && !isCreate)
            toEmail.append(emailUtil.getEmailAddressForUser(complaint.getPerson_investigating())).append(";");

        email.setFrom(lookupService.getEmail(MCASConstants.ADMIN_EMAIL)[0]);
        email.setToArray(toEmail, ";");
        email.setSubject(getEmailSubject(complaint.getComplaint_id(), type, statusDescription, isNew));

        if (isNewComplaint(type)) {
            email.setBody(getEmailBody(complaint.getComplaint_id(), isNew) + " " + printPreviewSrc);
        } else if (complaint.statusChanged()) {
            email.setBody(printPreviewSrc);
        }
        return sendMailOnObjectCreate(email, audotSendEmail);

    }

}
