package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.model.Cpar;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Nov 30, 2010
 * Time: 10:45:32 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FindingTimelineService {

    public String getInvestigationFindingsDueDate(Cpar c) throws DAOException;

    public String getContainmentActionDueDate(Cpar c) throws DAOException;

    public String getRootCauseDueDate(Cpar c) throws DAOException;

    public String getLongTermCorrectiveActionDueDate(Cpar c) throws DAOException;

    public String getEvaluationOfEffectivenessDueDate(Cpar c) throws DAOException;    
}
