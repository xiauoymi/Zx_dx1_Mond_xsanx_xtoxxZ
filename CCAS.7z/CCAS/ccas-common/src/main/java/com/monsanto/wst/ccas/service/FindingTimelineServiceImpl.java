package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.FindingTimelineDao;
import com.monsanto.wst.ccas.model.Cpar;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Nov 30, 2010
 * Time: 10:45:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class FindingTimelineServiceImpl implements FindingTimelineService {

    FindingTimelineDao timelineDao;

    public FindingTimelineServiceImpl(FindingTimelineDao dao) {
        timelineDao = dao;
    }

    public String   getInvestigationFindingsDueDate(Cpar c) throws DAOException {

        if (c.getMgmt_approval_date() == null || c.getMgmt_approval_date().equals("")) {
            return timelineDao.getInvestigationFindingsDueDate(c.getRow_entry_date());
        } else {
            return c.getMgmt_approval_date();
        }
    }

    public String getContainmentActionDueDate(Cpar c) throws DAOException {

        if (c.getMgmt_approval_date() == null || c.getMgmt_approval_date().equals("")) {
            return timelineDao.getContainmentActionDueDate(c.getRow_entry_date());
        } else {
            return c.getMgmt_approval_date();
        }
    }

    public String getRootCauseDueDate(Cpar c) throws DAOException {

        if (c.getMgmt_approval_date() == null || c.getMgmt_approval_date().equals("")) {
            return timelineDao.getRootCauseDueDate(c.getRow_entry_date());
        } else {
            return c.getMgmt_approval_date();
        }
    }

    public String getLongTermCorrectiveActionDueDate(Cpar c) throws DAOException {

        if (c.getMgmt_approval_date() == null || c.getMgmt_approval_date().equals("")) {
            return timelineDao.getLongTermCorrectiveActionDueDate(c.getRow_entry_date());
        } else {
            return c.getMgmt_approval_date();
        }
    }

    public String getEvaluationOfEffectivenessDueDate(Cpar c) throws DAOException {

        if (c.getMgmt_approval_date() == null || c.getMgmt_approval_date().equals("")) {
            return timelineDao.getEvaluationOfEffectivenessDueDate(c.getRow_entry_date());
        } else {
            return c.getMgmt_approval_date();
        }
    }
}
