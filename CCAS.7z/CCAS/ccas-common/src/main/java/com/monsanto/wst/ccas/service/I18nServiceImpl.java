package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.InternationalizationDAO;
import com.monsanto.wst.ccas.dao.InternationalizationDAOImpl;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Apr 6, 2010
 * Time: 12:18:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class I18nServiceImpl implements InternationalizationService {

    private InternationalizationDAO dao;

    public I18nServiceImpl(){
        dao = new InternationalizationDAOImpl();
    }

    public I18nServiceImpl(InternationalizationDAO d) {
        dao = d;
    }

    public String translate(String locale, String tableName, int id, String original) throws ServiceException {

        if (!MCASConstants.LANGUAGE_ENGLISH.equalsIgnoreCase(locale)) {
            try {
                String desc = dao.translateFromTable(locale, tableName, id);

                if (desc != null)
                    return desc;
            }
            catch (Exception e) {
                throw new ServiceException(e);
            }
        }

        return original;
    }

    public Integer lookupId(String locale, String tableName, String desc) throws ServiceException {

        if (!MCASConstants.LANGUAGE_ENGLISH.equalsIgnoreCase(locale)) {
            try {
                Integer id = dao.lookupId(locale, tableName, desc);

                if (id != null)
                    return id;
            }
            catch (Exception e) {
                throw new ServiceException(e);
            }
        }

        return null;
    }

    public static String lookupProperty(String locale, String key) {
        ResourceBundle bundle;
        Locale l = new Locale(locale);

        if (locale.equals(MCASConstants.LANGUAGE_ENGLISH))
            bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources");
        else
            bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources", l);

        return bundle.getString(key);
    }

    public static String getBrowserLocale(HttpServletRequest request) {

        Enumeration<Locale> locales = request.getLocales();

        do {
            Locale locale = locales.nextElement();

            if (ResourceBundle.getBundle("com.monsanto.wst.ccas.resources.ApplicationResources", locale) != null)
                return locale.getLanguage();

        } while (locales.hasMoreElements());

        return MCASConstants.LANGUAGE_DEFAULT;
    }

}
