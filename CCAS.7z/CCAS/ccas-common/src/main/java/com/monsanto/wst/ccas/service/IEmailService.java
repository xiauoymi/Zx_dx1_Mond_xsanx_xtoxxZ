package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;
import com.monsanto.wst.ccas.exception.EmailException;
import com.monsanto.wst.ccas.model.Complaint;
import com.monsanto.wst.ccas.model.EmailInfo;

import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Oct 9, 2009
 * Time: 9:56:49 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IEmailService {
    boolean sendEmailForComplaint(
    );

    boolean sendMailOnObjectCreate(EmailInfo emailInfo, boolean auditSendEmail) throws EmailException;

    boolean sendMailWithAttachment(EmailInfo email,InputStream attachment,String fileType,String fileName) throws EmailException;

    boolean sendEmailForComplaint(Complaint complaint, String type, String printPreviewSrc, String statusDescription, boolean isNew, boolean complaintStatusHasChanged, boolean isUpload) throws EmailException, EmailAddressRetrievalException;

    boolean sendEmailForComplaintCreateFromExcel(Complaint complaint, String type, String printPreviewSrc, String statusDescription, boolean isNew, boolean complaintStatusHasChanged, boolean isUpload, boolean isCreate) throws EmailException, EmailAddressRetrievalException;

    public void sendEmail(EmailInfo email) throws EmailException;

}
