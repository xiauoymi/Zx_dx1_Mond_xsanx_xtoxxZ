package com.monsanto.wst.ccas.service;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Apr 6, 2010
 * Time: 12:27:23 PM
 * To change this template use File | Settings | File Templates.
 */
public interface InternationalizationService {

    public String translate(String locale, String tableName, int id, String original) throws ServiceException;

    public Integer lookupId(String locale, String tableName, String desc) throws ServiceException;
}
