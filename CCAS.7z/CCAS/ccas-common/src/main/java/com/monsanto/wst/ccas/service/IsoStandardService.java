package com.monsanto.wst.ccas.service;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jul 3, 2011
 * Time: 7:06:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IsoStandardService {

    Document getQualityProgramRelatedIsoStandard(Document inputDocument, int businessId, String locale);
}
