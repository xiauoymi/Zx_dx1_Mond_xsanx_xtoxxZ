package com.monsanto.wst.ccas.service;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.monsanto.wst.ccas.complaints.FunctionDao;
import com.monsanto.wst.ccas.complaints.FunctionDaoImpl;
import com.monsanto.wst.ccas.dao.LookUpDAOImpl;
import com.monsanto.wst.ccas.dao.LookUpDAO;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.XMLUtil.DOMUtil;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jul 3, 2011
 * Time: 7:08:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class IsoStandardServiceImpl implements IsoStandardService {

    public Document getQualityProgramRelatedIsoStandard(Document inputDocument, int businessId, String locale) {

        LookUpDAO dao = new LookUpDAOImpl();
        Document document = DOMUtil.newDocument();
        Element functionsElement = DOMUtil.addChildElement(document, "standards");

        NodeList list = DOMUtil.getNodeListByTagName(inputDocument, "programId");
        if (list == null || list.getLength() == 0)
            return document;
        String programId = list.item(0) == null ? null : list.item(0).getNodeValue();
        Map<String, String> map;
        try {
            map = dao.getISOStandards(locale, businessId, programId);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return document;
        }

        for (String s : map.keySet()) {
            String key = s;
            String description = map.get(key);
            Element functionElement = DOMUtil.addChildElement(functionsElement, "standard");
            DOMUtil.addChildElement(functionElement, "standardId", key);
            DOMUtil.addChildElement(functionElement, "standardDescription", description);
        }
        return document;
    }
}
