package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Issue;
import com.monsanto.wst.ccas.model.IssueList;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 2:19:51 PM To change this template use File |
 * Settings | File Templates.
 */
public interface IssueService {
    IssueList<Issue> lookupIssuesForRegion(String regionId, int businessId, String locale);
}
