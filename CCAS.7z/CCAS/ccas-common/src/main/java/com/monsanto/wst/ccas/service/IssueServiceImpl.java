package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.IssueDAO;
import com.monsanto.wst.ccas.model.Issue;
import com.monsanto.wst.ccas.model.IssueList;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 5, 2010 Time: 2:19:32 PM To change this template use File |
 * Settings | File Templates.
 */
public class IssueServiceImpl implements IssueService {
    private IssueDAO issueDAO;

    public IssueServiceImpl() {
        try {
            this.issueDAO = (IssueDAO) DAOFactory.getDao(IssueDAO.class);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public IssueServiceImpl(IssueDAO issueDAO) {
        this.issueDAO = issueDAO;
    }

    public IssueList<Issue> lookupIssuesForRegion(String regionId, int businessId, String locale) {
        try {
            return issueDAO.lookupIssuesByRegion(regionId, businessId, locale);
        } catch (SQLException e) {
            throw new ServiceException(e);
        } catch (DAOException e) {
            throw new ServiceException(e);
        }
    }
}
