/*
 IssueTypeServiceImpl was created on Sep 3, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.IssueTypeDAO;
import com.monsanto.wst.ccas.dao.IssueTypeDAOImpl;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class IssueTypeServiceImpl implements IssueTypeService {

    private final DataSource dataSource;

    public IssueTypeServiceImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, String> lookupAllIssueTypesForAnIssue(String issueName, String type, String locale) {
        IssueTypeDAO dao = new IssueTypeDAOImpl(dataSource);
        return dao.lookupAllIssuesTypesForAnIssue(issueName, type, locale);
    }
}
