/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Cpar;

import java.util.Map;


/**
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public interface LookUpService {
    public Map<String, String> getStates() throws ServiceException;

    public Map<String, String> getStatusByRole(String type, String locale, Map<String, Boolean> roles) throws ServiceException;

    public Map<String, String> getAllStatus(String type, String locale) throws ServiceException;

    public Map<String, String> getLocations(boolean filterByUserRegion, int userBusiness, String locale) throws
            ServiceException;

    public Map<String, String> getLocationsSearch(boolean filterByUserRegion, int userBusiness, String locale) throws
            ServiceException;

    public Map<String, String> getQualityIssues(String locale) throws ServiceException;

    public Map<String, String> getYear(String locale) throws ServiceException;

    public Map<String, String> getCrops(String locale) throws ServiceException;

    //New method for fetching Crops based on Business Id
    public Map<String, String> getBusinessRelatedCrops(int businessId, String locale) throws ServiceException;

    public Map<String, String> getSeedSize(String locale) throws ServiceException;

    public Map<String, String> getUOM(String locale) throws ServiceException;

    public Map<String, String> getBrands(String locale) throws ServiceException;

    public Map<String, String> getRegions(String userId, int businessId, boolean filterByUserRole, String locale) throws
            ServiceException;

    public Map<String, String> getViewableRoleList(String userId, String locale) throws ServiceException;

    public Map<String, String> getGenerator(int type, boolean getActiveOnly, String locale, int businessId) throws ServiceException;

    public Map<String, String> getEffectivenessEvaluator(String locale) throws ServiceException;

    public Map<String, String> getFindingTypes(int type, boolean getActiveOnly, String locale, boolean isMCAS, int businessId) throws ServiceException;

    public Map<String, String> getISOStandards(String locale, int businessId, String qualityProgram) throws ServiceException;

    public Map<String, String> getQualityStandards(String locale, int busId) throws ServiceException;

    public Map<String, String> getOrganizations(String locale, int busId) throws ServiceException;

    public Map<String, String> getDepartmentAffected(String locale, int busId) throws ServiceException;

    public String[] getEmail(String locationCode) throws ServiceException;

    public String[] getSiteManager(String cparId) throws ServiceException;

    public Map<String, String> getStatesByUserRegion(String userId, String locale) throws ServiceException;

    public Map<String, String> getStatesByRegionSelected(String region, String locale) throws ServiceException;

    public Map<String, String> getBusinessTypeMap(String locale) throws ServiceException;

    // public Map getBusinessPreferenceRelatedRegionList(String userId,int businessId,int userBusinessPreferenceId,boolean filterByClause) throws ServiceException;
    public int getModifiedUserBusinessPreference(String userId) throws ServiceException;

    public Map<String, String> getAssesmentMap(String locale) throws ServiceException;

    Map<String, String> getLitigationCategoryMap(String locale) throws ServiceException;

    Map<String, String> lookupBusinessRelatedMaterialGroups(int businessId, String locale) throws ServiceException;

    Map<String, String> lookupBusinessRelatedMaterialPricingGroups(int businessId, String locale) throws ServiceException;

    Map<String, String> lookupBusinessRelatedSalesOffices(int businessId, String locale) throws ServiceException;

    public String getStatusDescription(int statusId, int statusType, String locale) throws ServiceException;

    public String getYearDescription(int yearId);

    String getEquivalentStatus(int cparStatusType, Cpar cpar) throws ServiceException;

    Map<String, String> getCparTypesToChange(int typeCar) throws ServiceException;

    Map<String, String> getAuditTypeRef(String locale, int businessId) throws ServiceException;

    Map<String, String> getClaimStatusTypes(String type, String locale) throws ServiceException;

    Map<String, String> lookUpFeedbackCategories(boolean activeOnly, String locale);

    String lookUpFeedbackCategoryById(String complaintBusinessId, String locale);

    Map<String, String> lookUpIlTypes(String locale);
}
