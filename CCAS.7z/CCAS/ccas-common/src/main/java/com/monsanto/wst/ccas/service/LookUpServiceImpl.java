/*
 * Created on Jan 25, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.LookUpDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.Cpar;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author jbrahmb <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */
public class LookUpServiceImpl implements LookUpService {
    private LookUpDAO lookUpDao;

    public LookUpServiceImpl() {
        try {
            lookUpDao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    public LookUpServiceImpl(LookUpDAO lookupDao) {
        this.lookUpDao = lookupDao;
    }

    public Map<String, String> getStates() throws ServiceException {
        try {
            return lookUpDao.getStates();
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }


    public Map<String, String> getStatusByRole(String type, String locale, Map<String, Boolean> roles) throws ServiceException {
        try {
            return lookUpDao.getStatusByRole(type, locale, roles);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getClaimStatusTypes(String type, String locale) throws ServiceException {
        try {
            return lookUpDao.getClaimStatusTypes();
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getAllStatus(String type, String locale) throws ServiceException {
        try {
            return lookUpDao.getAllStatus(type, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }


    public Map<String, String> getLocations(boolean filterByUserRegion, int userBusiness, String locale) throws
            ServiceException {
        try {
            return lookUpDao.getLocations(userBusiness, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        } catch (MCASException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> getLocationsSearch(boolean filterByUserRegion, int userBusiness, String locale) throws
            ServiceException {
        try {
            return lookUpDao.getLocationsSearch(userBusiness, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        } catch (MCASException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> getQualityIssues(String locale) throws ServiceException {
        try {
            return lookUpDao.getQualityIssues(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getYear(String locale) throws ServiceException {
        try {
            return lookUpDao.getYear(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public String getYearDescription(int yearId) throws ServiceException {
        try {
            return lookUpDao.getYearDescription(yearId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getCrops(String locale) throws ServiceException {
        try {
            return lookUpDao.getCrops(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    /**
     * @param businessId
     * @return
     * @throws ServiceException
     */
    public Map<String, String> getBusinessRelatedCrops(int businessId, String locale) throws ServiceException {
        try {
            return lookUpDao.getBusinessRelatedCrops(businessId, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getSeedSize(String locale) throws ServiceException {
        try {
            return lookUpDao.getSeedSize(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }


    public Map<String, String> getUOM(String locale) throws ServiceException {
        try {
            return lookUpDao.getUOM(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getBrands(String locale) throws ServiceException {
        try {
            return lookUpDao.getBrands(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getRegions(String userId, int businessId, boolean filterByUserRole, String locale) throws
            ServiceException {
        try {
            return lookUpDao.getRegions(userId, businessId, filterByUserRole, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getViewableRoleList(String userId, String locale) throws ServiceException {
        try {
            return lookUpDao.getViewableRoleList(userId, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getGenerator(int type, boolean getActiveOnly, String locale, int businessId) throws ServiceException {
        try {
            return lookUpDao.getGenerator(type, getActiveOnly, locale, businessId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getEffectivenessEvaluator(String locale) throws ServiceException {
        try {
            return lookUpDao.getEffectivenessEvaluator(locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getFindingTypes(int type, boolean getActiveOnly, String locale, boolean isMCAS, int businessId) throws ServiceException {
        try {
            return lookUpDao.getFindingTypes(type, getActiveOnly, locale, isMCAS, businessId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getISOStandards(String locale, int businessId, String qualityProgram) throws ServiceException {
        try {
            return lookUpDao.getISOStandards(locale, businessId, qualityProgram);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getQualityStandards(String locale, int busId) throws ServiceException {
        try {
            return lookUpDao.getQualityStandards(locale, busId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getOrganizations(String locale, int busId) throws ServiceException {
        try {
            return lookUpDao.getOrganizations(locale, busId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }


    public Map<String, String> getDepartmentAffected(String locale, int busId) throws ServiceException {
        try {
            return lookUpDao.getDepartmentAffected(locale, busId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public String[] getEmail(String locationCode) throws ServiceException {
        try {
            LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
            return lookupdao.getEmail(locationCode);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public String[] getSiteManager(String cparId) throws ServiceException {
        try {
            LookUpDAO lookupdao = (LookUpDAO) DAOFactory.getDao(LookUpDAO.class);
            return lookupdao.getSiteManager(cparId);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getStatesByUserRegion(String userId, String locale) throws ServiceException {
        try {
            return lookUpDao.getStatesByUserRegion(userId, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> getStatesByRegionSelected(String region, String locale) throws ServiceException {
        try {
            List<String> regionIdList = new ArrayList<String>();
            populateSalesOfficeIdList(region, regionIdList);
            return lookUpDao.getStateByRegionSelected(regionIdList, locale);
        }
        catch (DAOException e) {
            throw new ServiceException(e);
        }
    }

    /**
     * Method to tokenize a : seperated list of region ids
     *
     * @param region
     * @param regionIdList
     */
    private void populateSalesOfficeIdList(String region, List<String> regionIdList) {
        if (!StringUtils.isNullOrEmpty(region)) {
            StringTokenizer tokenizer = new StringTokenizer(region, ":");
            while (tokenizer.hasMoreTokens()) {
                regionIdList.add(tokenizer.nextToken());
            }
        }

    }

    /**
     * @return
     * @throws ServiceException
     */
    public Map<String, String> getBusinessTypeMap(String locale) throws ServiceException {
        try {
            return lookUpDao.getBusinessTypeMap(locale);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public int getModifiedUserBusinessPreference(String userId) throws ServiceException {
        try {
            return lookUpDao.getModifiedUserBusinessPreference(userId);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(
                    "Exception getting the Business Preference in " + getClass() + " getModifiedUserBusinessPreference()" +
                            e.getMessage(), e);
        }
    }

    /**
     * Bhargava 06/09/2008 Method to return the assesments
     *
     * @return
     * @throws ServiceException
     */
    public Map<String, String> getAssesmentMap(String locale) throws ServiceException {
        try {
            return lookUpDao.getAssesmentMap(locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public Map<String, String> getLitigationCategoryMap(String locale) throws ServiceException {
        try {
            return lookUpDao.getLitigationCategoryMap(locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    /**
     * Method to get busines related material Group
     *
     * @param businessId
     * @return
     * @throws ServiceException
     */
    public Map<String, String> lookupBusinessRelatedMaterialGroups(int businessId, String locale) throws
            ServiceException {
        try {
            return lookUpDao.lookupBusinessRelatedMaterialGroupMap(businessId, locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    /**
     * @param businessId
     * @return
     * @throws ServiceException
     */
    public Map<String, String> lookupBusinessRelatedMaterialPricingGroups(int businessId, String locale) throws
            ServiceException {
        try {
            return lookUpDao.lookupBusinessRelatedMaterialPricingGroupMap(businessId, locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    /**
     * @param businessId
     * @return
     * @throws ServiceException
     */
    public Map<String, String> lookupBusinessRelatedSalesOffices(int businessId, String locale) throws ServiceException {
        try {
            return lookUpDao.lookupBusinessRelatedSalesOfficeMap(businessId, locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public String getStatusDescription(int statusId, int statusType, String locale) throws ServiceException {
        try {
            return lookUpDao.lookupStatusDescription(statusId, statusType, locale);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }

    public String getEquivalentStatus(int sourceStatusType, Cpar cpar) throws ServiceException {
        try {
            return lookUpDao.getEquivalentStatus(cpar, sourceStatusType);
        } catch (DAOException e) {
            throw new ServiceException("Exception in " + getClass().getName() + ".getEquivalentStatus() method ", e);
        }
    }

    public Map<String, String> getCparTypesToChange(int typeCar) {
        try {
            return lookUpDao.getCparTypes(typeCar);
        } catch (DAOException e) {
            throw new ServiceException("Exception in " + getClass().getName() + ".getCparTypesToChange() method", e);
        }
    }

    public Map<String, String> getAuditTypeRef(String locale, int businessId) throws ServiceException {
        try {
            return lookUpDao.getAuditTypes(locale, businessId);
        } catch (DAOException e) {
            throw new ServiceException("Exception in " + getClass().getName() + ".getAuditTypeRef() method", e);
        }
    }

    public Map<String, String> lookUpFeedbackCategories(boolean activeOnly, String locale) {
        return lookUpDao.lookUpFeedbackCategories(activeOnly, locale);
    }

    public String lookUpFeedbackCategoryById(String complaintBusinessId, String locale) {
        return lookUpDao.lookUpFeedbackCategoryById(complaintBusinessId, locale);
    }

    public Map<String, String> lookUpIlTypes(String locale) {
        return lookUpDao.lookUpIlTypes(locale);
    }
}
