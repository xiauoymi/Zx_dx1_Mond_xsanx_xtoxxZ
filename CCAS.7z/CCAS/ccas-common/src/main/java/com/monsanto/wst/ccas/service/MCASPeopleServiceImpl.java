/*
 PeopleServiceImpl was created on Nov 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.naming.ServiceUnavailableException;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: MCASPeopleServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MCASPeopleServiceImpl implements MCASPeopleService {
    private final PeopleService service;

    public MCASPeopleServiceImpl(PeopleService peopleService) {
        this.service = peopleService;
    }

    public Document getEmailAddressesForUsersMatchingCriteria(Document requestDoc) throws ServiceUnavailableException {
        Document outputDocument = DOMUtil.newDocument();
        try {
            String vdir = System.getProperty("xmlservice.peoplepicker.vdir");
//            System.out.println("outputString = " + vdir);

            String endPoint = System.getProperty("xmlservice.peoplepicker.endpoint");
//            System.out.println("outputString = " + endPoint);

            String server = System.getProperty("xmlservice.peoplepicker.server");
//            System.out.println("outputString = " + server);
            String lastName = getLastNameFromRequestDocument(requestDoc);
            String firstName = getFirstNameFromRequestDocument(requestDoc);
            String userId = getUserIdFromRequestDocument(requestDoc);
            PersonInfo[] personInfos = service.GetPeople(lastName, firstName, "", "", userId, "", "");
            return getOutputDocumentForUserEntriesMatchCriteria(outputDocument, personInfos);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceUnavailableException("Unable to connect to PeoplePicker Service : " + e.getMessage());
        }
    }

    private Document getOutputDocumentForUserEntriesMatchCriteria(Document outputDocument, PersonInfo[] personInfos) {
        Map<String, String> map = new HashMap<String, String>();
        if (personInfos != null && personInfos.length > 0) {
            for (PersonInfo person : personInfos) {
                map.put(person.getUserId(), person.getEmail());
            }
            return outputAsXml(map);
        }
        return outputDocument;
    }

    public Map<String, String> getEmailInputMap() {
        return null;
    }

    private Document outputAsXml(Map<String, String> map) {
        Document responseDoc = DOMUtil.newDocument();
        Element emailAddresses = DOMUtil.addChildElement(responseDoc, "emailAddresses");
        for (String userEmail : map.values()) {
            DOMUtil.addChildElement(emailAddresses, "emailAddress", userEmail);
        }
        return responseDoc;
    }

    private String getUserIdFromRequestDocument(Document document) {
        try {
            return (DOMUtil.getNodeListByTagName(document, "UserId").item(0).getNodeValue());
        } catch (NullPointerException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }

    private String getFirstNameFromRequestDocument(Document document) {
        try {
            return (DOMUtil.getNodeListByTagName(document, "FirstName").item(0).getNodeValue());
        } catch (NullPointerException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }

    private String getLastNameFromRequestDocument(Document document) {
        try {
            return (DOMUtil.getNodeListByTagName(document, "LastName").item(0).getNodeValue());
        } catch (NullPointerException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }
}
