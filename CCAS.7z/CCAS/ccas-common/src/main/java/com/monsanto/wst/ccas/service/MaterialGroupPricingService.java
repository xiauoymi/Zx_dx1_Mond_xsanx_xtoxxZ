package com.monsanto.wst.ccas.service;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: Bhargava
 * Date: Apr 10, 2008
 * Time: 1:24:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MaterialGroupPricingService {

    public Document lookupMaterialGroupRelatedPricing(Document requestDoc, String locale);
}
