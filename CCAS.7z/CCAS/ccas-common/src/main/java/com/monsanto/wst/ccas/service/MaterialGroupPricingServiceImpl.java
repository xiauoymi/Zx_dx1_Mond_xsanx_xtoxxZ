package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.complaints.MaterialPricingGroupDao;
import com.monsanto.wst.ccas.complaints.MaterialPricingGroupDaoImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: Bhargava
 * Date: Apr 10, 2008
 * Time: 1:24:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupPricingServiceImpl implements MaterialGroupPricingService {
    private final DataSource datasource;

    public MaterialGroupPricingServiceImpl(DataSource datasource) {
        this.datasource = datasource;
    }

    /**
     * Method to fetch related material pricing group based on material group selected
     *
     * @param requestDoc request document
     * @return Document response document
     */
    public Document lookupMaterialGroupRelatedPricing(Document requestDoc, String locale) {
        Document responseDoc = null;
        MaterialPricingGroupDao dao = new MaterialPricingGroupDaoImpl(datasource);
        String materialGroupId = getMaterialGroupId(requestDoc);

        Map<String, String> materialPricingIdDescriptionMap;
        if (materialGroupId != null) {
            materialPricingIdDescriptionMap = getMaterialPricingGroupMap(dao, materialGroupId, locale);
            responseDoc = getResponseDocument(responseDoc, materialPricingIdDescriptionMap);
        }
        return responseDoc;
    }

    /**
     * Response Document Generator
     *
     * @param responseDoc
     * @param materialPricingIdDescriptionMap
     *
     * @return
     */
    private Document getResponseDocument(Document responseDoc, Map<String, String> materialPricingIdDescriptionMap) {
        if (materialPricingIdDescriptionMap != null && materialPricingIdDescriptionMap.size() != 0) {
            responseDoc = DOMUtil.newDocument();
            Element materialPricingGroupsRootElement = DOMUtil.addChildElement(responseDoc, "MaterialPricingGroups");
            for (String materialGrpId : materialPricingIdDescriptionMap.keySet()) {
                String description = materialPricingIdDescriptionMap.get(materialGrpId);
                Element materialGroupPricingElement = DOMUtil.addChildElement(materialPricingGroupsRootElement, "MaterialPricingGroup");
                DOMUtil.addChildElement(materialGroupPricingElement, "MaterialPricingGroupID", materialGrpId);
                DOMUtil.addChildElement(materialGroupPricingElement, "Description", description);
            }
        }
        return responseDoc;
    }

    /**
     * Method to Parse the String Material Group and get a Map of Material Group
     *
     * @param dao
     * @param materialGroupId
     * @return
     */
    private Map<String, String> getMaterialPricingGroupMap(MaterialPricingGroupDao dao, String materialGroupId, String locale) {
        Map<String, String> materialPricingIdDescriptionMap;
        List<String> materialGroupIdList = new ArrayList<String>();
        populateMaterialPricingGroupIdList(materialGroupId, materialGroupIdList);
        materialPricingIdDescriptionMap = dao.lookupMaterialGroupRelatedPricing(materialGroupIdList, locale);
        return materialPricingIdDescriptionMap;
    }

    /**
     * Method to prepare and populate a list of material pricing group ID list
     *
     * @param materialGroupId
     * @param materialGroupIdList
     */
    private void populateMaterialPricingGroupIdList(String materialGroupId, List<String> materialGroupIdList) {
        if (!StringUtils.isNullOrEmpty(materialGroupId)) {
            //materialGroupIdList = new ArrayList<String>();
            StringTokenizer tokenizer = new StringTokenizer(materialGroupId, ":");
            while (tokenizer.hasMoreTokens()) {
                materialGroupIdList.add(tokenizer.nextToken());
            }
        }

    }


    private String getMaterialGroupId(Document requestDoc) {
        String materialGroupId = "-1";
        try {
            return DOMUtil.getNodeListByTagName(requestDoc, "MaterialGroupID").item(0).getNodeValue();
        } catch (NullPointerException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return materialGroupId;
        }
    }
}
