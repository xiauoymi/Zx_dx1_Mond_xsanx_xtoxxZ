package com.monsanto.wst.ccas.service;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Apr 8, 2008
 * Time: 12:29:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MaterialGroupService {
    public Document lookUpCropRelatedMaterialGroups(Document requestDoc, String locale);
}
