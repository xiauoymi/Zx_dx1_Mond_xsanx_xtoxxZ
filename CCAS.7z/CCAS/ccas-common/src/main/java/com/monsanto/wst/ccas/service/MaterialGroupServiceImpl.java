package com.monsanto.wst.ccas.service;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.complaints.MaterialGroupDao;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Created by IntelliJ IDEA.
 * User: Bhargava
 * Date: Apr 8, 2008
 * Time: 12:29:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupServiceImpl implements MaterialGroupService {

    private final MaterialGroupDao dao;

    public MaterialGroupServiceImpl(MaterialGroupDao dao) {
        this.dao = dao;
    }

    /**
     * Method to fetch related meterial group based on crop id
     * Bhargava 04/09/2008
     *
     * @param requestDocument Request String as XML document
     * @return org.w3c.Document Response Document
     */

    public Document lookUpCropRelatedMaterialGroups(Document requestDocument, String locale) {
        Document responseDoc = null;
        Map<String, String> materialGroupMap;
        List<String> cropIdList = new ArrayList<String>();
        String cropId = getCropId(requestDocument);
        if (cropId != null) {
            parseCropIds(cropIdList, cropId);
            materialGroupMap = dao.lookupCropRelatedMaterialGroups(cropIdList, locale);
            responseDoc = buildMaterialGroupDocument(responseDoc, materialGroupMap);
        }
        return responseDoc;
    }

    /**
     * Private Method to parse : delimited crops ids and store it to List
     *
     * @param cropIdList
     * @param cropId
     */
    private void parseCropIds(List<String> cropIdList, String cropId) {
        StringTokenizer tokenizer = new StringTokenizer(cropId, ":");
        while (tokenizer.hasMoreTokens()) {
            cropIdList.add(tokenizer.nextToken());
        }
    }

    private String getCropId(Document requestDocument) {
        try {
            return (DOMUtil.getNodeListByTagName(requestDocument, "CropID").item(0).getNodeValue());
        } catch (NullPointerException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "-1";
        }
    }

    private Document buildMaterialGroupDocument(Document responseDoc, Map<String, String> materialGroupMap) {
        if (materialGroupMap != null && materialGroupMap.size() != 0) {
            responseDoc = DOMUtil.newDocument();
            Element materialGroupsRootElement = DOMUtil.addChildElement(responseDoc, "MaterialGroups");
            for (String materialId : materialGroupMap.keySet()) {
                String description = materialGroupMap.get(materialId);
                Element materialGroupElement = DOMUtil.addChildElement(materialGroupsRootElement, "MaterialGroup");
                DOMUtil.addChildElement(materialGroupElement, "MaterialGroupID", materialId);
                DOMUtil.addChildElement(materialGroupElement, "Description", description);
            }
        }
        return responseDoc;
    }
}
