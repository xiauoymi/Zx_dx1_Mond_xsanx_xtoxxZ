/*
 ProgramService was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.Program;

import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface ProgramService {
    Map<String, String> lookupAllPrograms() throws ServiceException;

    Program lookupProgramByCriteria(String id) throws ServiceException;

    Map<String, String> lookupLocationsForAProgram(String programId);
    Map<String, String> lookupLocationsForAProgramSearch(String programId);

    Map<String, String> lookupCategoryForAProgram(String programId, String locale);
}