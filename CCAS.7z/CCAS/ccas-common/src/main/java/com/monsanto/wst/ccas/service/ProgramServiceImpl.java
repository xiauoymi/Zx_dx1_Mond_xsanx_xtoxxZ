/*
 ProgramServiceImpl was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.*;
import com.monsanto.wst.ccas.model.Program;

import java.sql.SQLException;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ProgramServiceImpl implements ProgramService {
    private ProgramDAO programDAO;
    private LocationDAO locationDAO;
    private CategoryDAO categoryDAO;

    public ProgramServiceImpl(ProgramDAO programDAO, LocationDAO locationDAO, CategoryDAO categoryDAO) {
        this.programDAO = programDAO;
        this.locationDAO = locationDAO;
        this.categoryDAO = categoryDAO;
    }

    public ProgramServiceImpl() {
        try {
            programDAO = (ProgramDAO) DAOFactory.getDao(ProgramDAO.class);
            locationDAO = (LocationDAO) DAOFactory.getDao(LocationDAO.class);
            categoryDAO = (CategoryDAO) DAOFactory.getDao(CategoryDAO.class);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> lookupAllPrograms() throws ServiceException {
        try {
            return programDAO.lookupAllPrograms();
        } catch (SQLException e) {
            throw new ServiceException(e);
        }
    }

    public Program lookupProgramByCriteria(String id) throws ServiceException {
        try {
            return programDAO.lookupProgramByCriteria(id);
        } catch (SQLException e) {
            throw new ServiceException(e);
        }
    }

    public Map<String, String> lookupLocationsForAProgram(String programId) {
        return locationDAO.lookupAllLocationsByCriteria(programId);
    }

    public Map<String, String> lookupLocationsForAProgramSearch(String programId) {
        return locationDAO.lookupAllLocationsByCriteriaSearch(programId);
    }

    public Map<String, String> lookupCategoryForAProgram(String programId, String locale) {
        return categoryDAO.lookupCategoriesByCriteria(programId, locale);
    }
}