/*
 RegionService was created on Apr 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.complaints.RegionDao;
import com.monsanto.wst.ccas.importdata.SalesOffice;

import java.util.Map;

/**
 * Filename:    $RCSfile: RegionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface RegionService {
    void insertBusinessRegion(RegionDao regionDao, SalesOffice office);

    Map<String, String> getRegionList(String userId, int businessId, String locale);

    Map<String, String> getRegionSpecificStatesList(String userId, String locale);

    Map<String, String> getAllRegionList(String locale);
}