/*
 RegionServiceImpl was created on Apr 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.complaints.McasRegion;
import com.monsanto.wst.ccas.complaints.RegionDao;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.importdata.SalesOffice;

import java.util.Map;

/**
 * Filename:    $RCSfile: RegionServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:29 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class RegionServiceImpl implements RegionService {

    private final LookUpService lookupService;

    public RegionServiceImpl() {
        lookupService = new LookUpServiceImpl();
    }

    //TODO:use either of the constructor
    public RegionServiceImpl(LookUpService lookupService) {
        this.lookupService = lookupService;
    }

    public void insertBusinessRegion(RegionDao regionDao, SalesOffice office) {
        McasRegion mcasRegion = regionDao.lookupRegion(office.getRegion(), MCASConstants.LANGUAGE_DEFAULT);
        if (mcasRegion == null) {
            McasRegion region = new McasRegion(null, office.getRegion());
            regionDao.insertRegion(region);
            regionDao.insertBusinessRegion(region);
        }
    }

    public Map<String, String> getRegionList(String userId, int businessId, String locale) {
        return getRegionBusinessRelatedRegionMap(userId, businessId, locale);
    }

    private Map<String, String> getRegionBusinessRelatedRegionMap(String userId, int businessId, String locale) {
        boolean filterByUserRole = !StringUtils.isNullOrEmpty(userId);
        return lookupService.getRegions(userId, businessId, filterByUserRole, locale);
    }

    public Map<String, String> getRegionSpecificStatesList(String userId, String locale) {
        return lookupService.getStatesByUserRegion(userId, locale);
    }

    public Map<String, String> getAllRegionList(String locale) {
        return lookupService.getRegions(null, -1, false, locale);
    }

}
