/*
 * Created on Jan 20, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class ServiceException extends RuntimeException {
    public ServiceException(String errMsg) {
        super(errMsg);
    }

    public ServiceException(Throwable err) {
        super(err);
    }

    public ServiceException(String msg, Throwable err) {
        super(msg, err);
    }
}
