/**
 * @author jbrahmb
 *
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */

package com.monsanto.wst.ccas.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.spreadsheet.SpreadsheetFactory;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.complaints.claims.ClaimsService;
import com.monsanto.wst.ccas.complaints.claims.ClaimsServiceImpl;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.VarietyBatchDAO;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.HashMap;
import java.util.Map;


public class ServiceLocator {
    private static final Map<Class, Class> serviceMap;

    private static final Log logger = LogFactory.getLog(ServiceLocator.class);

    //**Implementing caching...
    static {
        serviceMap = new HashMap<Class, Class>();
        serviceMap.put(ComplaintService.class, ComplaintServiceImpl.class);
        serviceMap.put(LookUpService.class, LookUpServiceImpl.class);
        serviceMap.put(CparService.class, CparServiceImpl.class);
        serviceMap.put(UserAccountService.class, UserAccountServiceImpl.class);
        serviceMap.put(ControlNumberService.class, ControlNumberServiceImpl.class);
        serviceMap.put(AuditService.class, AuditServiceImpl.class);
        serviceMap.put(StopSaleService.class, StopSaleServiceImpl.class);
        serviceMap.put(BusinessService.class, BusinessServiceImpl.class);
        serviceMap.put(ClaimsService.class, ClaimsServiceImpl.class);
    }

    /**
     * This method looks up and returns the implentation class for a given service class type.
     *
     * @param type
     * @return Object
     * @throws ServiceException
     */
    public static Object locateService(Class type) throws ServiceException {
        if (logger.isTraceEnabled())
            logger.trace("Entering - clazz=" + type);
        if (type == null) {
            throw new ServiceException("cannot retrieve Service implementation for null name");
        }
        Object service;
        Class clazz = serviceMap.get(type);
        if (clazz != null) {
            try {
                service = clazz.newInstance();
                if (logger.isDebugEnabled()) {
                    logger.debug("found Service implementation '" + service.getClass() + "' for name '" + type + "'");
                }
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new ServiceException("could not instantiate Service for name '" + type + "': " + e.getMessage(), e);
            }
        } else {
            throw new ServiceException("could not find Service implementation class for name '" + type + "'");
        }
        if (logger.isTraceEnabled())
            logger.trace("Exiting");
        return service;
    }

    public static VarietyBatchDataReaderService getVarietyBatchDataReaderService() {
        return new VarietyBatchCSVDataReader(SpreadsheetFactory.newSpreadsheet(SpreadsheetFactory.TYPE_CSV));
    }

    public static VarietyBatchImportService getVarietyBatchImportService() throws ServiceException {
        try {
            return new VarietyBatchImportServiceImpl(getVarietyBatchDataReaderService(),
                    (VarietyBatchDAO) DAOFactory.getDao(VarietyBatchDAO.class));
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw new ServiceException("ServiceLocator: Exception locating Variety Batch Import Service.", e);
        }
    }
}
