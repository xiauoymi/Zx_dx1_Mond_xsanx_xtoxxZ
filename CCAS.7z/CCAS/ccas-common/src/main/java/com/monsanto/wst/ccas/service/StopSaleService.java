/*
 * Created on May 9, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.StopSaleFilter;
import com.monsanto.wst.ccas.model.StopSaleListObject;
import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;

import java.util.Map;

/**
 * @author rdesai2
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface StopSaleService {

    public String insertStopSale(StopSaleObject stopSale) throws ServiceException;

    public boolean updateStopSale(StopSaleObject stopSale) throws ServiceException;

    public StopSaleObject getStopSale(int stopSaleID) throws ServiceException;

    public String getStopSaleNumberFromID(int stopSaleID) throws ServiceException;

    public Map<String, Object> getStopSaleList(StopSaleListObject stopSale, String intPage, boolean getMax, String sortCriteria, String sortOrder, String locale) throws ServiceException;

    public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws ServiceException;

    public Map<String, RowBean> getStopSaleReport(StopSaleFilter stopSaleFilter, Map<String, String[]> parameterMap, String locale) throws ServiceException;
}
