/*
 * Created on May 9, 2005
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.actions.AuditAction;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.complaints.MaterialGroupDao;
import com.monsanto.wst.ccas.complaints.MaterialGroupDaoImpl;
import com.monsanto.wst.ccas.complaints.MaterialPricingGroupDao;
import com.monsanto.wst.ccas.complaints.MaterialPricingGroupDaoImpl;
import com.monsanto.wst.ccas.dao.*;
import com.monsanto.wst.ccas.model.StopSaleFilter;
import com.monsanto.wst.ccas.model.StopSaleListObject;
import com.monsanto.wst.ccas.model.StopSaleObject;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.taglib.reportTag.RowBean;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author rdesai2
 */
public class StopSaleServiceImpl implements StopSaleService {

    private static final Category logger = Category.getInstance(AuditAction.class.getName());
    private StopSaleDAO stopSaleDAO;

    public StopSaleServiceImpl() {
        try {
            stopSaleDAO = (StopSaleDAOImpl) DAOFactory.getDao(StopSaleDAO.class);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    public StopSaleServiceImpl(StopSaleDAO stopSaleDAO) {
        this.stopSaleDAO = stopSaleDAO;
    }

    public String insertStopSale(StopSaleObject stopSale) throws ServiceException {
        try {
            return stopSaleDAO.insertStopSale(stopSale);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating insertStopSale DAO.");
            throw new ServiceException(e.getMessage());
        }

    }

    public Map<String, Object> getStopSaleList(StopSaleListObject stopSale, String intPage, boolean getMax, String sortCriteria, String sortOrder, String locale) throws ServiceException {

        try {
            return stopSaleDAO.getStopSaleList(stopSale, intPage, sortCriteria, sortOrder, locale);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating insertStopSale DAO.");
        }
        return new LinkedHashMap<String, Object>();
    }

    public boolean updateStopSale(StopSaleObject stopSale) throws ServiceException {
        try {
            return stopSaleDAO.updateStopSale(stopSale);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating insertStopSale DAO.");
        }
        return false;
    }

    public StopSaleObject getStopSale(int stopSaleID) throws ServiceException {
        try {
            return stopSaleDAO.getStopSale(stopSaleID);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating getStopSale DAO.");
        }
        return new StopSaleObject();
    }


    public StopSaleObject getStopSaleByNumber(String stopSaleNumber) throws ServiceException {

        try {
            return stopSaleDAO.getStopSaleByNumber(stopSaleNumber);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating getStopSaleByNo DAO.");
        }
        return new StopSaleObject();
    }

    public String getStopSaleNumberFromID(int stopSaleID) throws ServiceException {
        try {
            return stopSaleDAO.getStopSaleNumberFromID(stopSaleID);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            logger.error("Error locating getStopSaleNo DAO.");
        }
        return "";
    }

    public Map<String, RowBean> getStopSaleReport(StopSaleFilter stopSaleFilter, Map<String, String[]> parameterMap, String locale) throws ServiceException {
        try {
            MaterialGroupDao materialGroupDao = new MaterialGroupDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            MaterialPricingGroupDao materialPricingGroupDao = new MaterialPricingGroupDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            BusinessDao businessDao = new BusinessDaoImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
            //Obtain the Selected Complaint Category
            CheckboxItemServiceImpl.getSelectedCheckboxItems(stopSaleFilter, parameterMap, "stopSaleFilter.nonconformanceCategoryList");
            CheckboxItemServiceImpl.getSelectedCheckboxItems(stopSaleFilter, parameterMap, "rootCauseList");

            Map<String, RowBean> report = stopSaleDAO.getStopSaleReport(stopSaleFilter, locale);
            for (String s : report.keySet()) {
                String key = s;
                RowBean rowBean = report.get(key);
                String col36 = rowBean.getCol36();
                if (col36 != null && !col36.equalsIgnoreCase("-")) {
//                    logger.info("col 36" + col36);
                    if (materialGroupDao.lookupMaterialGroupWithId(Integer.parseInt(col36), locale) != null) {
                        rowBean.setCol(36, materialGroupDao.lookupMaterialGroupWithId(Integer.parseInt(col36), locale));
                    } else {
                        rowBean.setCol(36, "-");
                    }
                }
                String col37 = rowBean.getCol37();
                if (col37 != null && !col37.equalsIgnoreCase("-")) {
                    String materialPricingGroupId = materialPricingGroupDao.lookupMaterialPricingGroupWithId(Integer.parseInt(col37), locale);
                    if (materialPricingGroupId != null) {
                        rowBean.setCol(37, materialPricingGroupId);
                    } else {
                        rowBean.setCol(37, "-");
                    }
                }
                String col38 = rowBean.getCol38();
                if (col38 != null && !col38.equalsIgnoreCase("-")) {
                    String businessid = businessDao.lookupBusinessWithId(Integer.parseInt(col38), locale);
                    if (businessid != null) {
                        rowBean.setCol(38, businessid);
                    } else {
                        rowBean.setCol(38, "-");
                    }
                }
            }
            return report;
        } catch (DAOException e) {
            logger.error("Exception thrown by StopSaleReportDAO.", e);
            throw new ServiceException(e);
        }
    }

//    private void populateSelectedNonconformanceCategories(StopSaleFilter stopSaleFilter, List<CheckboxItem> selectedTapRootCauses) {
//        stopSaleFilter.setSelectedNonconformanceList(selectedTapRootCauses);
////        List<Integer> nonconformanceCategoryIdList = new ArrayList<Integer>();
////        for (CheckboxItem checkboxItem : selectedTapRootCauses) {
////            nonconformanceCategoryIdList.add(checkboxItem.getCheckboxItemId());
////        }
////        stopSaleFilter.setNonconformanceCategoryIdList(nonconformanceCategoryIdList);
//    }

}
