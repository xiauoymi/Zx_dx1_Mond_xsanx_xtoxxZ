/*
 SubFunctionServiceImpl was created on Aug 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.SubFunctionDAO;

import java.sql.SQLException;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class SubFunctionServiceImpl implements SubFunctionService {
    private SubFunctionDAO subFunctionDAO;

    public SubFunctionServiceImpl(SubFunctionDAO subFunctionDAO) {

        this.subFunctionDAO = subFunctionDAO;
    }

    public SubFunctionServiceImpl() {
        try {
            subFunctionDAO = (SubFunctionDAO) DAOFactory.getDao(SubFunctionDAO.class);
        } catch (DAOException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, String> lookupAllSubFunctionsForAProgram(String programId, String locale) {
        try {
            return subFunctionDAO.lookupSubFunctionForAProgram(programId, locale);
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public int getSubfunctionIdFromString(String subFunctionDesc) {
        try {
            return subFunctionDAO.getSubfunctionIdFromString(subFunctionDesc);
        } catch (SQLException e) {
            throw new ServiceException(e);
        }
    }
}