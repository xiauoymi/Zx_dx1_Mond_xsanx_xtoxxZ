/*
 * Created on Mar 4, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.User;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public interface UserAccountService {
    public User getUserInfo(User user) throws ServiceException;
}
