/*
 * Created on Mar 4, 2005
 *
 *
 */
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAccountDAO;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.util.MCASLogUtil;

/**
 * @author jbrahmb
 *         <p/>
 *         <p/>
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class UserAccountServiceImpl implements UserAccountService {
    public User getUserInfo(User user) throws ServiceException {
        try {
            UserAccountDAO uad = (UserAccountDAO) DAOFactory.getDao(UserAccountDAO.class);
            return uad.getUserInfo(user);
        }
        catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e.getMessage(), e);
        }
    }
}
