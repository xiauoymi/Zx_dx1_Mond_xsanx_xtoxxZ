package com.monsanto.wst.ccas.service;

import org.w3c.dom.Document;

import java.util.Map;

/**
 * User: Bhargava
 * Date: Apr 14, 2008
 * Time: 8:53:33 AM
 */
public interface UserAdminService {

    public Document getRegionOnBusinessChange(Document requestDoc) throws Exception;

    Map<String, String> getRegionsForSelectedBusiness(String[] businessIdArr);
}
