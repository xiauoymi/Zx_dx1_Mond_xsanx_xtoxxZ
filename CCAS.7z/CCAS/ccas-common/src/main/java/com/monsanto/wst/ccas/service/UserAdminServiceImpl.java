package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;
import com.monsanto.wst.ccas.usernameupdateservice.dao.UserAdministrationDAOImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.Map;

/**
 * User: Bhargava
 * Date: Apr 14, 2008
 * Time: 8:53:50 AM
 */
public class UserAdminServiceImpl implements UserAdminService {

    public UserAdminServiceImpl() {
    }

    public Document getRegionOnBusinessChange(Document requestDocument) throws Exception {
        Document responseDoc = null;
        Map<String, String> regionMap;
        UserAdministrationDAOImpl daoImpl = new UserAdministrationDAOImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
        String businessId = DOMUtil.getNodeListByTagName(requestDocument, "BusinessId").item(0).getNodeValue();

        String[] selectedBusinessIds = parseBusinessIds(businessId);
        regionMap = daoImpl.getRegionListOnBusinessChange(selectedBusinessIds);
        responseDoc = getResponseDocument(responseDoc, regionMap);
        return responseDoc;
    }

    public Map<String, String> getRegionsForSelectedBusiness(String[] businessIdArr) {
        UserAdministrationDAOImpl daoImpl = new UserAdministrationDAOImpl(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource());
        try {
            return daoImpl.getRegionListOnBusinessChange(businessIdArr);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String[] parseBusinessIds(String businessId) {
        String[] businessIds = null;
        if (!StringUtils.isNullOrEmpty(businessId)) {
            businessIds = StringUtils.tokenize(businessId, ":", false);
        }
        return businessIds;
    }

    /**
     * Bhargava 04/24/2008
     * Method to Build and Return the Response Document
     *
     * @param responseDoc
     * @param regionMap
     * @return
     */
    private Document getResponseDocument(Document responseDoc, Map<String, String> regionMap) {
        if (regionMap != null && !regionMap.isEmpty()) {
            Document newResponseDoc = DOMUtil.newDocument();
            Element regionsRootElement = DOMUtil.addChildElement(newResponseDoc, "Regions");
            for (String regionDesc : regionMap.keySet()) {
                Element regionElement = DOMUtil.addChildElement(regionsRootElement, "Region");
                DOMUtil.addChildElement(regionElement, "RegionId", regionDesc);
                DOMUtil.addChildElement(regionElement, "Description", regionMap.get(regionDesc));
            }
            return newResponseDoc;
        } else {
            return responseDoc;
        }
    }
}
