/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.spreadsheet.ContentSet;
import com.monsanto.spreadsheet.EmptyFileException;
import com.monsanto.spreadsheet.Spreadsheet;
import com.monsanto.spreadsheet.exception.SpreadsheetException;
import com.monsanto.wst.ccas.model.VarietyBatch;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: VarietyBatchCSVDataReader.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class VarietyBatchCSVDataReader implements VarietyBatchDataReaderService {

    private final Spreadsheet spreadsheet;

    public VarietyBatchCSVDataReader(Spreadsheet spreadsheet) {
        this.spreadsheet = spreadsheet;
    }

    public List<VarietyBatch> getVarietyBatchList(String filePath) throws ServiceException {
        List<VarietyBatch> varietyBatchList = new ArrayList<VarietyBatch>();
        try {
            ContentSet contentSet = spreadsheet.getContent(filePath, true);
            while (contentSet.next()) {
                String varietyDesc = contentSet.getString(0);
                String batchNumber = contentSet.getString(1);
                varietyBatchList.add(new VarietyBatch(null, varietyDesc, batchNumber));
            }
            contentSet.close();
        } catch (IOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException("IOException occured while reading variety batch data from csv file.", e);
        } catch (EmptyFileException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        } catch (SpreadsheetException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return varietyBatchList;
    }
}
