/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.wst.ccas.model.VarietyBatch;

import java.util.List;

/**
 * Filename:    $RCSfile: VarietyBatchDataReaderService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface VarietyBatchDataReaderService {

    List<VarietyBatch> getVarietyBatchList(String filePath) throws ServiceException;
}