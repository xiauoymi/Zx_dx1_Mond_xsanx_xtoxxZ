/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.VarietyBatchDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.util.List;

/**
 * @author rdesai2
 */
public class VarietyBatchImportServiceImpl implements VarietyBatchImportService {
    private VarietyBatchDataReaderService readerService;
    private VarietyBatchDAO dao;

    public VarietyBatchImportServiceImpl(VarietyBatchDataReaderService readerService, VarietyBatchDAO dao) {
        this.readerService = readerService;
        this.dao = dao;
    }

    public boolean importVarietyBatchData(String fileName) throws ServiceException {
        List varietyBatchList = readVarietyBatchData(fileName);
        return saveVarietyBatchData(varietyBatchList);
    }


    private boolean saveVarietyBatchData(List varietyBatchList) throws ServiceException {
        try {
            return dao.insertVarietyBatch(varietyBatchList);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        } catch (MCASException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }

    private boolean inactivateVarietyBatchData(List varietyBatchList) throws ServiceException {
        try {
            return dao.inactivateVarietyBatch(varietyBatchList);
        } catch (DAOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        } catch (MCASException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServiceException(e);
        }
    }

    private List readVarietyBatchData(String fileName) throws ServiceException {
        List varietyBatchList;
        try {
            varietyBatchList = readerService.getVarietyBatchList(fileName);
        } catch (ServiceException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw e;
        }
        return varietyBatchList;
    }

    public boolean importNewVarietyBatches() throws MCASException, DAOException, ServiceException {
        List varietyBatchList = dao.getNewVarietyBatchData();
        return saveVarietyBatchData(varietyBatchList);
    }

    public boolean inactivateOldVarietyBatches() throws MCASException, DAOException, ServiceException {
        List varietyBatchList = dao.getInactivatedVarietyBatchData();
        return inactivateVarietyBatchData(varietyBatchList);
    }

    public void deleteDataFromVarietyBatchTempTable() {
        dao.deleteDataFromVarietyBatchTempTable();
    }


}