/*
 YearRefServiceImpl was created on Sep 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.ccas.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.dao.YearDAO;
import com.monsanto.wst.ccas.dao.YearDAOImpl;
import com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4PersistentStoreFactory;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class YearRefServiceImpl implements YearRefService {
    private final DataSource dataSource;
    private final YearDAO yearDAO;

    public YearRefServiceImpl() {
        dataSource = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getDataSource();
        yearDAO = new YearDAOImpl(dataSource);
    }

    public YearRefServiceImpl(DataSource basicDataSource) {
        dataSource = basicDataSource;
        yearDAO = new YearDAOImpl(dataSource);

    }

    public Map<String, String> insertFiscalYearIfNotPresent(String dateEntered) throws ServiceException {
        if (StringUtils.isNullOrEmpty(dateEntered)) {
            throw new ServiceException("Communicate date is null or empty");
        }

        SimpleDateFormat formatter = new SimpleDateFormat(MCASConstants.YEAR_FORMAT);
        Date date = null;
        try {
            date = formatter.parse(dateEntered);
            String formattedDate = formatter.format(date);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        Calendar calendarForDateEntered = new GregorianCalendar();
        calendarForDateEntered.setTime(date);

        Calendar nextFiscalYearCalendar = new GregorianCalendar();
        nextFiscalYearCalendar.set(calendarForDateEntered.get(Calendar.YEAR), Calendar.SEPTEMBER, 1);
        if (calendarForDateEntered.get(Calendar.MONTH) >= Calendar.SEPTEMBER) {
            nextFiscalYearCalendar.add(Calendar.YEAR, 1);
        }

        int newFiscalYear = nextFiscalYearCalendar.get(Calendar.YEAR);
        try {
            if (!yearDAO.doesYearExistInDB(calendarForDateEntered.get(Calendar.YEAR))) {
                insertNewYearIfNeeded(yearDAO, calendarForDateEntered);
            } else if (nextFiscalYearCalendar.get(Calendar.YEAR) != calendarForDateEntered.get(Calendar.YEAR) &&
                    !newFiscalYearDoesNotExistInDB(newFiscalYear)) {

                insertNewYearIfNeeded(yearDAO, nextFiscalYearCalendar);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            return yearDAO.findAll();
        } catch (SQLException e) {
            throw new ServiceException(e);
        }
    }

    private boolean newFiscalYearDoesNotExistInDB(int newFiscalYear) throws SQLException {
        return yearDAO.doesYearExistInDB(newFiscalYear);
    }

    private void insertNewYearIfNeeded(YearDAO yearDAO, Calendar year) {
        try {
            yearDAO.insertYearForNewFiscalYear(year.get(Calendar.YEAR));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
