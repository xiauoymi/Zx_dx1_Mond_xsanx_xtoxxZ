package com.monsanto.wst.ccas.servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreContainerManaged;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType4;
import com.monsanto.wst.ccas.exception.DatabaseException;
import com.monsanto.AbstractLogging.Logger;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Category;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static com.monsanto.AbstractLogging.Logger.log;

public class WST_MANUFACT_COMPL_TOM4PersistentStoreFactory {
  private static BasicDataSource basicDataSource;
  private static DataSource dataSource;
  private static final String PREDEFINED_CONTEXT = "java:/comp/env/";
  private static final Category logger = Category.getInstance(WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.class.getName());

  /**
   * Returns a Persistent Store.
   *
   * @param cstrResourceBundleName The name of the resource bundle that points
   *                               to the correct database.
   * @return A PersistentStore object.
   * @throws WrappingException
   */
  public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException{
    Logger.traceEntry();
    ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
    PersistentStore RetVal = null;
    try {
      String jndi = bundle.getString("jndi-name");
      RetVal = new PersistentStoreContainerManaged(jndi);
    } catch (NamingException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
    return (PersistentStore) Logger.traceExit(RetVal);
  }

  public static DataSource getDataSource() {
    ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4");
    String jndiDataSourceName = bundle.getString("jndi-name");
    DataSource basicDataSource = null;
    try {
      InitialContext ctx = new InitialContext();
//          dataSource = (DataSource) ctx.
//                lookup(PREDEFINED_CONTEXT + jndiDataSourceName);
      dataSource = (DataSource) ctx.
          lookup(jndiDataSourceName);
      logger.info("DataSource: " + dataSource);
    } catch (NamingException ne) {
      logger.info("Unable to locate datasource " + jndiDataSourceName, ne);
      //throw new DatabaseException("Unable to locate datasource " + jndiDataSourceName, ne);
        return getBasicDataSource();
    }
    return dataSource;
  }


    public static BasicDataSource getBasicDataSource() {
        if (basicDataSource == null) {
            try {


 // Class.forName("com.mysql.jdbc.Driver");
//con = DriverManager.getConnection(
//"jdbc:mysql://localhost:3306/komal", "root", "root");
                ResourceBundle bundle = ResourceBundle.getBundle("com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4");
                String environment = System.getProperty("lsi.function");
               // if ("win".equalsIgnoreCase(environment)) environment = "test"; // force lsi.function to point to test..
                String applicationname = bundle.getString("applicationname");
                String userName = bundle.getString(environment + ".UserName");
                String datasource = bundle.getString(environment + ".DataSource");
                String password = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", applicationname, "CipherValue.hex", "KeyValue.hex");
                BasicDataSource temp = new BasicDataSource();
                temp.setDriverClassName("oracle.jdbc.driver.OracleDriver");
                temp.setUrl("jdbc:oracle:thin:@" + datasource + ".monsanto.com:1521:" + datasource);
                temp.setUsername(userName);
                temp.setPassword(password);
                temp.setRemoveAbandoned(true);
                temp.setLogAbandoned(true);

                basicDataSource = temp;

            } catch (EncryptorException e) {
                throw new DatabaseException("Exception retrieving the password", e);
            }
        }
        return basicDataSource;

    }

  public Connection getConnection(){
    Connection connection = null;
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      connection = DriverManager.getConnection("url", "username", "password");
    } catch (ClassNotFoundException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } catch (SQLException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
    return connection;
  }

}
