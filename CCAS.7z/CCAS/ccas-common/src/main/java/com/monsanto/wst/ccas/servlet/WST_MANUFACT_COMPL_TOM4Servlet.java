package com.monsanto.wst.ccas.servlet;


import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * <p>Title: WST_MANUFACT_COMPL_TOM4Servlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: WST_MANUFACT_COMPL_TOM4Servlet.java,v 1.1 2009-03-10 16:14:30 kjjohn2 Exp $
 */
public class WST_MANUFACT_COMPL_TOM4Servlet extends GatewayServlet {
    public static final String s_cstrResourceBundle = "com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4";

    public WST_MANUFACT_COMPL_TOM4Servlet() {
        super();
    }

    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);

        Logger.traceEntry();

        try {
            com.monsanto.wst.ccas.servlet.WST_MANUFACT_COMPL_TOM4LoggerFactory loggerFactory = new WST_MANUFACT_COMPL_TOM4LoggerFactory();
            loggerFactory.setupLogging();
        }
        catch (LogRegistrationException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServletException(e.toString(), e);
        }
        catch (IOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new ServletException(e.toString(), e);
        }

        Logger.traceExit();
    }

    public void destroy() {
        Logger.traceEntry();

        try {
            PersistentStore.registerInstance(null);
        }
        catch (WrappingException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

        super.destroy();

        Logger.traceExit();
    }

    /**
     * This static method will create an instance of the desired PersistentStore based on
     * data within a property file.
     *
     * @param request  - The HttpServlet Request from the servlet container
     * @param response - The HttpServletResponse to be sent back to the servlet container.
     * @throws java.io.IOException
     * @throws javax.servlet.ServletException
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Logger.traceEntry();

        UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

        try {

            /*  Register the persistent store with this servlet instance.  */
            PersistentStore ps = WST_MANUFACT_COMPL_TOM4PersistentStoreFactory.getStore(s_cstrResourceBundle);
            PersistentStore.registerInstance(ps);

            /*  Pass the doGet along.  */
            super.doGet(request, response);
        }
        catch (WrappingException we) {
            helper.reportError("Error accessing database.  Please notify your technical support contact or try again later.\n" + we.toString());
            helper.closeSession();
        }

        Logger.traceExit();
    }
}
