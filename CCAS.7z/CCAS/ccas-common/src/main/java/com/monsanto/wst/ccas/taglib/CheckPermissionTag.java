package com.monsanto.wst.ccas.taglib;

import javax.servlet.jsp.JspTagException;


/**
 * Allows the tag body to be processed, based on whether the user has the
 * specified permission.
 * <P>The taglib mapping file is irdSecurity.tld<BR>
 * The signature definition is:
 * <pre>
 * &lt;tag&gt;
 *     &lt;name&gt;checkPermission&lt;/name&gt;
 *     &lt;tagclass&gt;com.monsanto.ag_it.ird.gui.taglib.CheckPermissionTag&lt;/tagclass&gt;
 *     &lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 *     &lt;attribute&gt;
 *       &lt;name&gt;permissionId&lt;/name&gt;
 *       &lt;required&gt;true&lt;/required&gt;
 *     &lt;/attribute&gt;
 * &lt;/tag&gt;
 * </pre>
 *
 * @author IRD Web Team
 */
public class CheckPermissionTag extends PermissionIdTag {
    //~ Methods �����������������������������������������������������������������

    /**
     * Checks if user has the specified permission and evaluate body if true.
     *
     * @return SKIP_BODY if user doesn't have the permission or EVAL_BODY_INCLUDE otherwise.
     * @throws JspTagException if a serious error occurs or if an
     *                         unexpected session name is requested.
     */
    public int doStartTag() throws JspTagException {
        int iRet = SKIP_BODY;

        if (checkPermission()) {
            iRet = EVAL_BODY_INCLUDE;
        }

        return iRet;
    }
}