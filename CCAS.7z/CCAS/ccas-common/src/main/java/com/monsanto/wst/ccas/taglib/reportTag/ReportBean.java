/**
 * Reporting Tool(ReportBean) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto. 
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.wst.ccas.taglib.reportTag;

import java.util.Vector;

/**
 * ReportBean: This is the class/object used to fill in the report/table formatting instructions by the XmlParser
 * after it parses the report structure file.
 *
 * @author Rasesh Desai
 */
public class ReportBean {

    private String width;

    private String title;

    private String cellPadding;

    private String cellSpacing;

    private String border;

    private String headerHeight;

    private String rowHeight;

    private Vector<ColumnBean> columns;

    private String tableClass;

    private String titleColor;
    private String titleFont;
    private String titleBold;
    private String titleUnderline;

    private String headerAlign;
    private String headerValign;
    private String headerTextColor;
    private String headerTextSize;
    private String headerBgColor;
    private String headerFont;
    private String headerBold;
    private String headerUnderline;
    private String headerClass;
    private String headerNowrap;

    private String excelFileName;
    private String excelSheetName;

    private boolean errorFlag;

    private String errorMsg;


    /**
     * Constructor
     */
    public ReportBean() {
        columns = new Vector<ColumnBean>();
    }


    /**
     * @return Returns the errorFlag.
     */
    public boolean isErrorFlag() {
        return errorFlag;
    }

    /**
     * @param errorFlag The errorFlag to set.
     */
    public void setErrorFlag(boolean errorFlag) {
        this.errorFlag = errorFlag;
    }

    /**
     * @return Returns the errorMsg.
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * @param errorMsg The errorMsg to set.
     */
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    /**
     * @return Returns the excelFileName.
     */
    public String getExcelFileName() {
        return excelFileName;
    }

    /**
     * @param excelFileName The excelFileName to set.
     */
    public void setExcelFileName(String excelFileName) {
        this.excelFileName = excelFileName;
    }

    /**
     * @return Returns the excelSheetName.
     */
    public String getExcelSheetName() {
        return excelSheetName;
    }

    /**
     * @param excelSheetName The excelSheetName to set.
     */
    public void setExcelSheetName(String excelSheetName) {
        this.excelSheetName = excelSheetName;
    }

    /**
     * @return Returns the headerAlign.
     */
    public String getHeaderAlign() {
        return headerAlign;
    }

    /**
     * @param headerAlign The headerAlign to set.
     */
    public void setHeaderAlign(String headerAlign) {
        this.headerAlign = headerAlign;
    }

    /**
     * @return Returns the headerBgColor.
     */
    public String getHeaderBgColor() {
        return headerBgColor;
    }

    /**
     * @param headerBgColor The headerBgColor to set.
     */
    public void setHeaderBgColor(String headerBgColor) {
        this.headerBgColor = headerBgColor;
    }

    /**
     * @return Returns the headerBold.
     */
    public String getHeaderBold() {
        return headerBold;
    }

    /**
     * @param headerBold The headerBold to set.
     */
    public void setHeaderBold(String headerBold) {
        this.headerBold = headerBold;
    }

    /**
     * @return Returns the headerClass.
     */
    public String getHeaderClass() {
        return headerClass;
    }

    /**
     * @param headerClass The headerClass to set.
     */
    public void setHeaderClass(String headerClass) {
        this.headerClass = headerClass;
    }

    /**
     * @return Returns the headerFont.
     */
    public String getHeaderFont() {
        return headerFont;
    }

    /**
     * @param headerFont The headerFont to set.
     */
    public void setHeaderFont(String headerFont) {
        this.headerFont = headerFont;
    }

    /**
     * @return Returns the headerNowrap.
     */
    public String getHeaderNowrap() {
        return headerNowrap;
    }

    /**
     * @param headerNowrap The headerNowrap to set.
     */
    public void setHeaderNowrap(String headerNowrap) {
        this.headerNowrap = headerNowrap;
    }

    /**
     * @return Returns the headerTextColor.
     */
    public String getHeaderTextColor() {
        return headerTextColor;
    }

    /**
     * @param headerTextColor The headerTextColor to set.
     */
    public void setHeaderTextColor(String headerTextColor) {
        this.headerTextColor = headerTextColor;
    }

    /**
     * @return Returns the headerTextSize.
     */
    public String getHeaderTextSize() {
        return headerTextSize;
    }

    /**
     * @param headerTextSize The headerTextSize to set.
     */
    public void setHeaderTextSize(String headerTextSize) {
        this.headerTextSize = headerTextSize;
    }

    /**
     * @return Returns the headerUnderline.
     */
    public String getHeaderUnderline() {
        return headerUnderline;
    }

    /**
     * @param headerUnderline The headerUnderline to set.
     */
    public void setHeaderUnderline(String headerUnderline) {
        this.headerUnderline = headerUnderline;
    }

    /**
     * @return Returns the headerValign.
     */
    public String getHeaderValign() {
        return headerValign;
    }

    /**
     * @param headerValign The headerValign to set.
     */
    public void setHeaderValign(String headerValign) {
        this.headerValign = headerValign;
    }

    /**
     * @return Returns the tableClass.
     */
    public String getTableClass() {
        return tableClass;
    }

    /**
     * @param tableClass The tableClass to set.
     */
    public void setTableClass(String tableClass) {
        this.tableClass = tableClass;
    }

    /**
     * @return Returns the titleBold.
     */
    public String getTitleBold() {
        return titleBold;
    }

    /**
     * @param titleBold The titleBold to set.
     */
    public void setTitleBold(String titleBold) {
        this.titleBold = titleBold;
    }

    /**
     * @return Returns the titleColor.
     */
    public String getTitleColor() {
        return titleColor;
    }

    /**
     * @param titleColor The titleColor to set.
     */
    public void setTitleColor(String titleColor) {
        this.titleColor = titleColor;
    }

    /**
     * @return Returns the titleFont.
     */
    public String getTitleFont() {
        return titleFont;
    }

    /**
     * @param titleFont The titleFont to set.
     */
    public void setTitleFont(String titleFont) {
        this.titleFont = titleFont;
    }

    /**
     * @return Returns the titleUnderline.
     */
    public String getTitleUnderline() {
        return titleUnderline;
    }

    /**
     * @param titleUnderline The titleUnderline to set.
     */
    public void setTitleUnderline(String titleUnderline) {
        this.titleUnderline = titleUnderline;
    }

    /**
     * @param columns The columns to set.
     */
    public void setColumns(Vector<ColumnBean> columns) {
        this.columns = columns;
    }

    /**
     * @return Returns the border.
     */
    public String getBorder() {
        return border;
    }

    /**
     * @param border The border to set.
     */
    public void setBorder(String border) {
        this.border = border;
    }

    /**
     * @return Returns the cellPadding.
     */
    public String getCellPadding() {
        return cellPadding;
    }

    /**
     * @param cellPadding The cellPadding to set.
     */
    public void setCellPadding(String cellPadding) {
        this.cellPadding = cellPadding;
    }

    /**
     * @return Returns the cellSpacing.
     */
    public String getCellSpacing() {
        return cellSpacing;
    }

    /**
     * @param cellSpacing The cellSpacing to set.
     */
    public void setCellSpacing(String cellSpacing) {
        this.cellSpacing = cellSpacing;
    }

    /**
     * @return Returns the headerHeight.
     */
    public String getHeaderHeight() {
        return headerHeight;
    }

    /**
     * @param headerHeight The headerHeight to set.
     */
    public void setHeaderHeight(String headerHeight) {
        this.headerHeight = headerHeight;
    }

    /**
     * @return Returns the rowHeight.
     */
    public String getRowHeight() {
        return rowHeight;
    }

    /**
     * @param rowHeight The rowHeight to set.
     */
    public void setRowHeight(String rowHeight) {
        this.rowHeight = rowHeight;
    }

    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title The title to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return Returns the width.
     */
    public String getWidth() {
        return width;
    }

    /**
     * @param width The width to set.
     */
    public void setWidth(String width) {
        this.width = width;
    }

    public void addColumn(ColumnBean col) {
        columns.addElement(col);
    }

    /**
     * @return Returns the columns.
     */
    public Vector<ColumnBean> getColumns() {
        return columns;
    }

    public String toString() {
        String newline = System.getProperty("line.separator");
        StringBuffer buf = new StringBuffer();

        buf.append("--- ###Report --- Width: ").append(width).append(" Title: ").append(title).append(" hh: ").append(headerHeight).append(" rh: ").append(rowHeight).append(
                newline);
        for (int i = 0; i < columns.size(); i++) {
            buf.append(columns.elementAt(i)).append(newline);
        }

        return buf.toString();
    }
}
