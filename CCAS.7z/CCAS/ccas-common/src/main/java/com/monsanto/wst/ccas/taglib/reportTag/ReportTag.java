/**
 * Reporting Tool (ReportTag) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto.
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.wst.ccas.taglib.reportTag;

import com.monsanto.wst.ccas.util.MCASLogUtil;
import org.apache.log4j.Category;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Vector;


/**
 * Reporting Tool: This is a tool to generate custom report. It mainly consists of a custom tag
 * <tags:reportTag .../> which takes in 4 attributes:
 * 1. InputStream (which is the XML file that takes the formatting instructions)
 * 2. HashMap (that contains the data)
 * 3. SortBy (field by which the report needs to be sorted, Currently supported sorting by col1, col2 and col3)
 * 4. SortOrder (asc/des order)
 * 5. ExportSupport: true/false. (It will accordingly provide the data for export.)
 * <p/>
 * The report tag looks like this:
 * <p/>
 * <tags:reportTag xmlIn="${complaintFilterForm.xmlIn}" hash="${complaintFilterForm.hash}"
 * sortBy="${complaintFilterForm.sortBy}" sortOrder="${complaintFilterForm.sortOrder}"
 * exportSupport="true" />
 * <p/>
 * The variables can also be present in request/session scope Eg: hash="${requestScope.hash}"
 *
 * @author Rasesh Desai
 */
public class ReportTag extends SimpleTagSupport {
    //todo this has strange mix of static and instance var/methods, has huge methods, severely needs to be refactored
    private static final Category logger = Category.getInstance(ReportTag.class.getName());

    private InputStream xmlIn;
    private Map<String, RowBean> hash;
    private String sortBy;
    private String sortOrder;
    private boolean exportSupport;
    private final Vector<String> exportColHeader = new Vector<String>();

    private static final ExportBean exportBean = new ExportBean();
//    private static boolean PARSING_ERROR = false; //todo non-final, public, and static, fix this

    private Vector<RowBean> dataVector;

    public void setExportSupport(boolean exportSupport) {
        this.exportSupport = exportSupport;
    }

    public void setDataVector(Vector<RowBean> dataVector) {
        this.dataVector = dataVector;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public void setXmlIn(InputStream xmlIn) {
        this.xmlIn = xmlIn;
    }

    public void setHash(Map<String, RowBean> coll) {
        this.hash = coll;
    }


    //**Step2: doTag() Method...
    public void doTag() throws JspException, IOException {
        //todo gaaaa, "do" method, 14 pages long, fix this
        //**Call the report Parser...
        XmlParser parser = new XmlParser();

        ReportBean report = parser.getParsedXmlBean(xmlIn);

        if (report == null) {
            getJspContext().getOut().write("<Br><Font color=\"#003366\" face=\"Arial, Helvetica, sans-serif\" size=\"3px\">Xml Parser Error</Font>");
//            PARSING_ERROR = true;
        } else {

            if (report.isErrorFlag()) {
                getJspContext().getOut().write("<Br><Font color=\"#003366\" face=\"Arial, Helvetica, sans-serif\" size=\"3px\">" + report.getErrorMsg() + "</Font>");
//                PARSING_ERROR = true;
            } else {

                //**Display the body as it is...
                StringWriter sw = new StringWriter();
                getJspBody().invoke(sw);
                getJspContext().getOut().print(sw.toString());

                //**  NOTE: A subsequent call to the reset method repositions this stream at the last marked position
                //**  (or since the start of the file, if mark has not been called)so that subsequent reads
                //**  re-read the same bytes. [Also see mark(int readlimit) and markSupported(), if reqd...]

                if (xmlIn.markSupported()) {
                    xmlIn.reset();
                }

                PageBuilder builder = new PageBuilder();

                if (report != null) {
                    //**Report Title...
                    String title = "";
                    String titleColor = "";
                    String titleFont = "";
                    String titleBold = "";
                    String titleUnderline = "";

                    if (report.getTitle() != null) {
                        title = report.getTitle();
                    }
                    if (report.getTitleColor() != null) {
                        titleColor = report.getTitleColor();
                    }
                    if (report.getTitleFont() != null) {
                        titleFont = report.getTitleFont();
                    }
                    if (report.getTitleBold() != null) {
                        titleBold = report.getTitleBold();
                    }
                    if (report.getTitleUnderline() != null) {
                        titleUnderline = report.getTitleUnderline();
                    }

                    getJspContext().getOut().write(builder.reportTitle(title, titleColor, titleFont, titleBold, titleUnderline));

                    //**<TABLE>
                    //**Default Values...
                    String border = "1";
                    String cellSpacing = "0";
                    String cellPadding = "0";
                    String width = "";
                    String tableClass = "";

                    if (report.getBorder() != null) {
                        border = report.getBorder();
                    }
                    if (report.getCellPadding() != null) {
                        cellPadding = report.getCellPadding();
                    }
                    if (report.getCellSpacing() != null) {
                        cellSpacing = report.getCellSpacing();
                    }
                    if (report.getTableClass() != null) {
                        tableClass = report.getTableClass();
                    }

                    getJspContext().getOut().write(builder.startTable(width, border, cellPadding, cellSpacing, tableClass));


                    //Header Row...
                    //**<TR>
                    if (report.getHeaderHeight() != null) {
                        getJspContext().getOut().write(builder.startRow(report.getHeaderHeight()));
                    } else {
                        getJspContext().getOut().write(builder.startRow(""));    //**OR Some default value...
                    }

                    for (int i = 0; i < report.getColumns().size(); i++) {
                        //**<TD>
                        getJspContext().getOut().write(
                                builder.startHeaderCol(report.getColumns().get(i).getName(),
                                        report.getColumns().get(i).getColWidth(), report.getColumns().get(i).getAlign(),
                                        report.getHeaderValign(), report.getHeaderTextColor(), report.getHeaderTextSize(),
                                        report.getHeaderBgColor(), report.getHeaderFont(), report.getHeaderBold(),
                                        report.getHeaderUnderline(), report.getHeaderNowrap())
                        );
                        //**</TD>
                        getJspContext().getOut().write(builder.endCol());

                        if (exportSupport) {
                            exportColHeader.add(report.getColumns().get(i).getName());
                        }
                    }

                    //**</TR>
                    getJspContext().getOut().write(builder.endRow());


                    //Data Row...(hashMap loop)
                    //Iterator it = hash.keySet().iterator();

                    if (sortBy != null) {
                        if (sortOrder != null) {
                            sortHashMap(hash, sortBy, sortOrder);
                        } else {
                            sortHashMap(hash, sortBy, "asc");
                        }
                    } else {
                        sortHashMap(hash, "col1", "asc"); //default
                    }

                    //**If export functionality os supported...
                    if (exportSupport) {
                        //todo Setting static here
                        exportBean.setExportColHeader(exportColHeader);
                        exportBean.setTotalFields(report.getColumns().size());
                        exportBean.setExcelFileName(report.getExcelFileName());
                        exportBean.setExcelSheetName(report.getExcelSheetName());
                    }

                    Vector<RowBean> dataVectorForExport = new Vector<RowBean>();

                    for (Object aDataVector : dataVector) {

                        RowBean row = (RowBean) aDataVector;
                        RowBean rowForExport = new RowBean();
                        //**<TR>
                        if (report.getHeaderHeight() != null) {
                            getJspContext().getOut().write(builder.startRow(report.getRowHeight()));
                        } else {
                            getJspContext().getOut().write(builder.startRow(""));    //**OR Some default value...
                        }

                        for (int i = 0; i < report.getColumns().size(); i++) {

                            String mappingField = report.getColumns().get(i).getMappingField();
                            String strDesc = "";
                            int dataLength = -1;

                            if (mappingField.equalsIgnoreCase("col1")) {
                                strDesc = row.getCol1();
                            }
                            if (mappingField.equalsIgnoreCase("col2")) {
                                strDesc = row.getCol2();
                            }
                            if (mappingField.equalsIgnoreCase("col3")) {
                                strDesc = row.getCol3();
                            }
                            if (mappingField.equalsIgnoreCase("col4")) {
                                strDesc = row.getCol4();
                            }
                            if (mappingField.equalsIgnoreCase("col5")) {
                                strDesc = row.getCol5();
                            }
                            if (mappingField.equalsIgnoreCase("col6")) {
                                strDesc = row.getCol6();
                            }
                            if (mappingField.equalsIgnoreCase("col7")) {
                                strDesc = row.getCol7();
                            }
                            if (mappingField.equalsIgnoreCase("col8")) {
                                strDesc = row.getCol8();
                            }
                            if (mappingField.equalsIgnoreCase("col9")) {
                                strDesc = row.getCol9();
                            }
                            if (mappingField.equalsIgnoreCase("col10")) {
                                strDesc = row.getCol10();
                            }

                            if (mappingField.equalsIgnoreCase("col11")) {
                                strDesc = row.getCol11();
                            }
                            if (mappingField.equalsIgnoreCase("col12")) {
                                strDesc = row.getCol12();
                            }
                            if (mappingField.equalsIgnoreCase("col13")) {
                                strDesc = row.getCol13();
                            }
                            if (mappingField.equalsIgnoreCase("col14")) {
                                strDesc = row.getCol14();
                            }
                            if (mappingField.equalsIgnoreCase("col15")) {
                                strDesc = row.getCol15();
                            }
                            if (mappingField.equalsIgnoreCase("col16")) {
                                strDesc = row.getCol16();
                            }
                            if (mappingField.equalsIgnoreCase("col17")) {
                                strDesc = row.getCol17();
                            }
                            if (mappingField.equalsIgnoreCase("col18")) {
                                strDesc = row.getCol18();
                            }
                            if (mappingField.equalsIgnoreCase("col19")) {
                                strDesc = row.getCol19();
                            }
                            if (mappingField.equalsIgnoreCase("col20")) {
                                strDesc = row.getCol20();
                            }

                            if (mappingField.equalsIgnoreCase("col21")) {
                                strDesc = row.getCol21();
                            }
                            if (mappingField.equalsIgnoreCase("col22")) {
                                strDesc = row.getCol22();
                            }
                            if (mappingField.equalsIgnoreCase("col23")) {
                                strDesc = row.getCol23();
                            }
                            if (mappingField.equalsIgnoreCase("col24")) {
                                strDesc = row.getCol24();
                            }
                            if (mappingField.equalsIgnoreCase("col25")) {
                                strDesc = row.getCol25();
                            }
                            if (mappingField.equalsIgnoreCase("col26")) {
                                strDesc = row.getCol26();
                            }
                            if (mappingField.equalsIgnoreCase("col27")) {
                                strDesc = row.getCol27();
                            }
                            if (mappingField.equalsIgnoreCase("col28")) {
                                strDesc = row.getCol28();
                            }
                            if (mappingField.equalsIgnoreCase("col29")) {
                                strDesc = row.getCol29();
                            }
                            if (mappingField.equalsIgnoreCase("col30")) {
                                strDesc = row.getCol30();
                            }

                            if (mappingField.equalsIgnoreCase("col31")) {
                                strDesc = row.getCol31();
                            }
                            if (mappingField.equalsIgnoreCase("col32")) {
                                strDesc = row.getCol32();
                            }
                            if (mappingField.equalsIgnoreCase("col33")) {
                                strDesc = row.getCol33();
                            }
                            if (mappingField.equalsIgnoreCase("col34")) {
                                strDesc = row.getCol34();
                            }
                            if (mappingField.equalsIgnoreCase("col35")) {
                                strDesc = row.getCol35();
                            }
                            if (mappingField.equalsIgnoreCase("col36")) {
                                strDesc = row.getCol36();
                            }
                            if (mappingField.equalsIgnoreCase("col37")) {
                                strDesc = row.getCol37();
                            }
                            if (mappingField.equalsIgnoreCase("col38")) {
                                strDesc = row.getCol38();
                            }
                            if (mappingField.equalsIgnoreCase("col39")) {
                                strDesc = row.getCol39();
                            }
                            if (mappingField.equalsIgnoreCase("col40")) {
                                strDesc = row.getCol40();
                            }

                            if (mappingField.equalsIgnoreCase("col41")) {
                                strDesc = row.getCol41();
                            }
                            if (mappingField.equalsIgnoreCase("col42")) {
                                strDesc = row.getCol42();
                            }
                            if (mappingField.equalsIgnoreCase("col43")) {
                                strDesc = row.getCol43();
                            }
                            if (mappingField.equalsIgnoreCase("col44")) {
                                strDesc = row.getCol44();
                            }
                            if (mappingField.equalsIgnoreCase("col45")) {
                                strDesc = row.getCol45();
                            }
                            if (mappingField.equalsIgnoreCase("col46")) {
                                strDesc = row.getCol46();
                            }
                            if (mappingField.equalsIgnoreCase("col47")) {
                                strDesc = row.getCol47();
                            }
                            if (mappingField.equalsIgnoreCase("col48")) {
                                strDesc = row.getCol48();
                            }
                            if (mappingField.equalsIgnoreCase("col49")) {
                                strDesc = row.getCol49();
                            }
                            if (mappingField.equalsIgnoreCase("col50")) {
                                strDesc = row.getCol50();
                            }

                            if (mappingField.equalsIgnoreCase("col51")) {
                                strDesc = row.getCol51();
                            }
                            if (mappingField.equalsIgnoreCase("col52")) {
                                strDesc = row.getCol52();
                            }
                            if (mappingField.equalsIgnoreCase("col53")) {
                                strDesc = row.getCol53();
                            }
                            if (mappingField.equalsIgnoreCase("col54")) {
                                strDesc = row.getCol54();
                            }
                            if (mappingField.equalsIgnoreCase("col55")) {
                                strDesc = row.getCol55();
                            }
                            if (mappingField.equalsIgnoreCase("col56")) {
                                strDesc = row.getCol56();
                            }
                            if (mappingField.equalsIgnoreCase("col57")) {
                                strDesc = row.getCol57();
                            }
                            if (mappingField.equalsIgnoreCase("col58")) {
                                strDesc = row.getCol58();
                            }
                            if (mappingField.equalsIgnoreCase("col59")) {
                                strDesc = row.getCol59();
                            }
                            if (mappingField.equalsIgnoreCase("col60")) {
                                strDesc = row.getCol60();
                            }

                            if (mappingField.equalsIgnoreCase("col61")) {
                                strDesc = row.getCol61();
                            }
                            if (mappingField.equalsIgnoreCase("col62")) {
                                strDesc = row.getCol62();
                            }
                            if (mappingField.equalsIgnoreCase("col63")) {
                                strDesc = row.getCol63();
                            }
                            if (mappingField.equalsIgnoreCase("col64")) {
                                strDesc = row.getCol64();
                            }
                            if (mappingField.equalsIgnoreCase("col65")) {
                                strDesc = row.getCol65();
                            }
                            if (mappingField.equalsIgnoreCase("col66")) {
                                strDesc = row.getCol66();
                            }
                            if (mappingField.equalsIgnoreCase("col67")) {
                                strDesc = row.getCol67();
                            }
                            if (mappingField.equalsIgnoreCase("col68")) {
                                strDesc = row.getCol68();
                            }
                            if (mappingField.equalsIgnoreCase("col69")) {
                                strDesc = row.getCol69();
                            }
                            if (mappingField.equalsIgnoreCase("col70")) {
                                strDesc = row.getCol70();
                            }

                            if (mappingField.equalsIgnoreCase("col71")) {
                                strDesc = row.getCol71();
                            }
                            if (mappingField.equalsIgnoreCase("col72")) {
                                strDesc = row.getCol72();
                            }
                            if (mappingField.equalsIgnoreCase("col73")) {
                                strDesc = row.getCol73();
                            }
                            if (mappingField.equalsIgnoreCase("col74")) {
                                strDesc = row.getCol74();
                            }
                            if (mappingField.equalsIgnoreCase("col75")) {
                                strDesc = row.getCol75();
                            }
                            if (mappingField.equalsIgnoreCase("col76")) {
                                strDesc = row.getCol76();
                            }
                            if (mappingField.equalsIgnoreCase("col77")) {
                                strDesc = row.getCol77();
                            }
                            if (mappingField.equalsIgnoreCase("col78")) {
                                strDesc = row.getCol78();
                            }
                            if (mappingField.equalsIgnoreCase("col79")) {
                                strDesc = row.getCol79();
                            }
                            if (mappingField.equalsIgnoreCase("col80")) {
                                strDesc = row.getCol80();
                            }

                            if (mappingField.equalsIgnoreCase("col81")) {
                                strDesc = row.getCol81();
                            }
                            if (mappingField.equalsIgnoreCase("col82")) {
                                strDesc = row.getCol82();
                            }
                            if (mappingField.equalsIgnoreCase("col83")) {
                                strDesc = row.getCol83();
                            }
                            if (mappingField.equalsIgnoreCase("col84")) {
                                strDesc = row.getCol84();
                            }
                            if (mappingField.equalsIgnoreCase("col85")) {
                                strDesc = row.getCol85();
                            }
                            if (mappingField.equalsIgnoreCase("col86")) {
                                strDesc = row.getCol86();
                            }
                            if (mappingField.equalsIgnoreCase("col87")) {
                                strDesc = row.getCol87();
                            }
                            if (mappingField.equalsIgnoreCase("col88")) {
                                strDesc = row.getCol88();
                            }
                            if (mappingField.equalsIgnoreCase("col89")) {
                                strDesc = row.getCol89();
                            }
                            if (mappingField.equalsIgnoreCase("col90")) {
                                strDesc = row.getCol90();
                            }

                            if (mappingField.equalsIgnoreCase("col91")) {
                                strDesc = row.getCol91();
                            }
                            if (mappingField.equalsIgnoreCase("col92")) {
                                strDesc = row.getCol92();
                            }
                            if (mappingField.equalsIgnoreCase("col93")) {
                                strDesc = row.getCol93();
                            }
                            if (mappingField.equalsIgnoreCase("col94")) {
                                strDesc = row.getCol94();
                            }
                            if (mappingField.equalsIgnoreCase("col95")) {
                                strDesc = row.getCol95();
                            }
                            if (mappingField.equalsIgnoreCase("col96")) {
                                strDesc = row.getCol96();
                            }
                            if (mappingField.equalsIgnoreCase("col97")) {
                                strDesc = row.getCol97();
                            }
                            if (mappingField.equalsIgnoreCase("col98")) {
                                strDesc = row.getCol98();
                            }
                            if (mappingField.equalsIgnoreCase("col99")) {
                                strDesc = row.getCol99();
                            }
                            if (mappingField.equalsIgnoreCase("col100")) {
                                strDesc = row.getCol100();
                            }

                            if (report.getColumns().get(i).getDataLength() != null) {
                                try {
                                    dataLength = Integer.parseInt(report.getColumns().get(i).getDataLength());
                                }
                                catch (Exception e) {
                                    logger.info("Integer expected in the DataLength attribute found in " + mappingField);
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }
                            }

                            if (dataLength != -1 && strDesc.length() > dataLength) {
                                strDesc = strDesc.substring(0, dataLength) + "...";
                            }

                            // The following code is added to ensure that the data exported via the ExportBean
                            // is set according to the column order mentioned in each of the corresponding
                            // XXXXReportStructure.xml files
                            if (exportSupport) {
//                String methodName = "setCol" + (i + 1);
                                String methodName = "setCol";
                                try {

                                    Method method = RowBean.class.getMethod(methodName, Integer.class, String.class);
                                    method.invoke(rowForExport, i + 1, strDesc);
                                } catch (NoSuchMethodException e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                } catch (InvocationTargetException e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                } catch (IllegalAccessException e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }
                            }

                            getJspContext().getOut().write(builder.startCol(report.getColumns().get(i), strDesc));
                            getJspContext().getOut().write(builder.endCol());
                        }

                        if (exportSupport)
                            dataVectorForExport.add(rowForExport);

                        //**</TR>
                        getJspContext().getOut().write(builder.endRow());
                    }

                    if (exportSupport) {
                        //todo setting static here
                        exportBean.setExportDataVector(dataVectorForExport);
                    }

                    //**</TR>
                    getJspContext().getOut().write(builder.endRow());

                    //**</TABLE>
                    getJspContext().getOut().write(builder.endTable());
                }

            }//END ELSE (ERROR_MSG)

        }// END ELSE (REPORT == NULL)

    }

    /**
     * Sorts HashMap based on any 3 fields col1/col2/col3 and in reqd order.
     */
    void sortHashMap(Map<String, RowBean> hash, String field, String order) {
        //todo fix this monstrosity
        dataVector = new Vector<RowBean>();

        for (String o : hash.keySet()) {
            dataVector.add(hash.get(o));
        }

        //**No Sorting
        if (field.equals("")) {
            return;
        }

        if (order.equals("")) {
            order = "asc";  //default...
        }

        if (field.equalsIgnoreCase("col1") && order.equalsIgnoreCase("asc")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol1().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol1().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return 1;
                                    }
                                    if (aVal < bVal) {
                                        return -1;
                                    }
                                }
                                catch (NumberFormatException e) {

                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return 1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return -1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }

                            return 0;
                        }
                    }

            );
        }

        if (field.equalsIgnoreCase("col1") && order.equalsIgnoreCase("dec")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol1().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol1().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return -1;
                                    }
                                    if (aVal < bVal) {
                                        return 1;
                                    }
                                }
                                catch (NumberFormatException e) {
                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return -1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return 1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }
                            return 0;
                        }
                    }

            );
        }

        if (field.equalsIgnoreCase("col2") && order.equalsIgnoreCase("asc")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol2().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol2().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return 1;
                                    }
                                    if (aVal < bVal) {
                                        return -1;
                                    }
                                }
                                catch (NumberFormatException e) {
                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return 1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return -1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }

                            return 0;
                        }
                    }

            );
        }

        if (field.equalsIgnoreCase("col2") && order.equalsIgnoreCase("dec")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol2().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol2().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return -1;
                                    }
                                    if (aVal < bVal) {
                                        return 1;
                                    }
                                }
                                catch (NumberFormatException e) {
                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return -1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return 1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }
                            return 0;
                        }
                    }

            );
        }

        if (field.equalsIgnoreCase("col3") && order.equalsIgnoreCase("asc")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol3().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol3().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return 1;
                                    }
                                    if (aVal < bVal) {
                                        return -1;
                                    }
                                }
                                catch (NumberFormatException e) {
                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return 1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return -1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }

                            return 0;
                        }
                    }

            );
        }

        if (field.equalsIgnoreCase("col3") && order.equalsIgnoreCase("dec")) {
            Collections.sort(dataVector,
                    new Comparator() {
                        public int compare(Object a, Object b) {
                            //todo this is so bad IntelliJ won't even analyze it
                            String aTokens[] = ((RowBean) a).getCol3().trim().split("-");
                            String bTokens[] = ((RowBean) b).getCol3().trim().split("-");

                            int noOfTokens = aTokens.length;

                            for (int i = 0; i < noOfTokens; i++) {

                                try {
                                    int aVal = Integer.parseInt(aTokens[i]);
                                    int bVal = Integer.parseInt(bTokens[i]);

                                    if (aVal > bVal) {
                                        return -1;
                                    }
                                    if (aVal < bVal) {
                                        return 1;
                                    }
                                }
                                catch (NumberFormatException e) {
                                    //**These are probably just Strings...
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) > 0) {
                                        return -1;
                                    }
                                    if (aTokens[i].compareToIgnoreCase(bTokens[i]) < 0) {
                                        return 1;
                                    }
                                }
                                catch (Exception e) {
                                    MCASLogUtil.logError(e.getMessage(), e);
                                }

                            }

                            return 0;
                        }
                    }

            );
        }

    }

    public static ExportBean getExportData() {
        //todo exporting static here
        return exportBean;
    }

}
