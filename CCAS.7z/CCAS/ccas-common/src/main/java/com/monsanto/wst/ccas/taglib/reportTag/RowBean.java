/**
 * Reporting Tool (RowBean) was created on Jun 6, 2005 using Monsanto resources and is the sole property of Monsanto.
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.wst.ccas.taglib.reportTag;

/**
 * RowBean: This is the class/object used to fill in the Data. The object of this class
 * has to be present in the HashMap taken by the report tag.
 *
 * @author Rasesh Desai
 */
public class RowBean {
    private final String[] cols = new String[100];


    String getCol(int n) {
        return cols[n];
    }

    public void setCol(Integer n, String colValue) {
        cols[n] = colValue;
    }

    public String getCol51() {
        return getCol(51);
    }

    public String getCol52() {
        return getCol(52);
    }

    public String getCol53() {
        return getCol(53);
    }

    public String getCol54() {
        return getCol(54);
    }

    public String getCol55() {
        return getCol(55);
    }

    public String getCol56() {
        return getCol(56);
    }

    public String getCol57() {
        return getCol(57);
    }

    public String getCol58() {
        return getCol(58);
    }

    public String getCol59() {
        return getCol(59);
    }

    public String getCol60() {
        return getCol(60);
    }

    public String getCol1() {
        return getCol(1);
    }

    public String getCol10() {
        return getCol(10);
    }

    public String getCol100() {
        return getCol(100);
    }

    public String getCol11() {
        return getCol(11);
    }

    public String getCol12() {
        return getCol(12);
    }

    public String getCol13() {
        return getCol(13);
    }

    public String getCol14() {
        return getCol(14);
    }

    public String getCol15() {
        return getCol(15);
    }

    public String getCol16() {
        return getCol(16);
    }

    public String getCol17() {
        return getCol(17);
    }

    public String getCol18() {
        return getCol(18);
    }

    public String getCol19() {
        return getCol(19);
    }

    public String getCol2() {
        return getCol(2);
    }

    public String getCol20() {
        return getCol(20);
    }

    public String getCol21() {
        return getCol(21);
    }

    public String getCol22() {
        return getCol(22);
    }

    public String getCol23() {
        return getCol(23);
    }

    public String getCol24() {
        return getCol(24);
    }

    public String getCol25() {
        return getCol(25);
    }

    public String getCol26() {
        return getCol(26);
    }

    public String getCol27() {
        return getCol(27);
    }

    public String getCol28() {
        return getCol(28);
    }

    public String getCol29() {
        return getCol(29);
    }

    public String getCol3() {
        return getCol(3);
    }

    public String getCol30() {
        return getCol(30);
    }

    public String getCol31() {
        return getCol(31);
    }

    public String getCol32() {
        return getCol(32);
    }

    public String getCol33() {
        return getCol(33);
    }

    public String getCol34() {
        return getCol(34);
    }

    public String getCol35() {
        return getCol(35);
    }

    public String getCol36() {
        return getCol(36);
    }

    public String getCol37() {
        return getCol(37);
    }

    public String getCol38() {
        return getCol(38);
    }

    public String getCol39() {
        return getCol(39);
    }

    public String getCol4() {
        return getCol(4);
    }

    public String getCol40() {
        return getCol(40);
    }

    public String getCol41() {
        return getCol(41);
    }

    public String getCol42() {
        return getCol(42);
    }

    public String getCol43() {
        return getCol(43);
    }

    public String getCol44() {
        return getCol(44);
    }

    public String getCol45() {
        return getCol(45);
    }

    public String getCol46() {
        return getCol(46);
    }

    public String getCol47() {
        return getCol(47);
    }

    public String getCol48() {
        return getCol(48);
    }

    public String getCol49() {
        return getCol(49);
    }

    public String getCol5() {
        return getCol(5);
    }

    public String getCol50() {
        return getCol(50);
    }

    public String getCol6() {
        return getCol(6);
    }

    public String getCol61() {
        return getCol(61);
    }

    public String getCol62() {
        return getCol(62);
    }

    public String getCol63() {
        return getCol(63);
    }

    public String getCol64() {
        return getCol(64);
    }

    public String getCol65() {
        return getCol(65);
    }

    public String getCol66() {
        return getCol(66);
    }

    public String getCol67() {
        return getCol(67);
    }

    public String getCol68() {
        return getCol(68);
    }

    public String getCol69() {
        return getCol(69);
    }

    public String getCol7() {
        return getCol(7);
    }

    public String getCol70() {
        return getCol(70);
    }

    public String getCol71() {
        return getCol(71);
    }

    public String getCol72() {
        return getCol(72);
    }

    public String getCol73() {
        return getCol(73);
    }

    public String getCol74() {
        return getCol(74);
    }

    public String getCol75() {
        return getCol(75);
    }

    public String getCol76() {
        return getCol(76);
    }

    public String getCol77() {
        return getCol(77);
    }

    public String getCol78() {
        return getCol(78);
    }

    public String getCol79() {
        return getCol(79);
    }

    public String getCol8() {
        return getCol(8);
    }

    public String getCol80() {
        return getCol(80);
    }

    public String getCol81() {
        return getCol(81);
    }

    public String getCol82() {
        return getCol(82);
    }

    public String getCol83() {
        return getCol(83);
    }

    public String getCol84() {
        return getCol(84);
    }

    public String getCol85() {
        return getCol(85);
    }

    public String getCol86() {
        return getCol(86);
    }

    public String getCol87() {
        return getCol(87);
    }

    public String getCol88() {
        return getCol(88);
    }

    public String getCol89() {
        return getCol(89);
    }

    public void setCol89(String col89) {
        setCol(89, col89);
    }

    public String getCol9() {
        return getCol(9);
    }

    public String getCol90() {
        return getCol(90);
    }

    public String getCol91() {
        return getCol(91);
    }

    public String getCol92() {
        return getCol(92);
    }

    public String getCol93() {
        return getCol(93);
    }

    public String getCol94() {
        return getCol(94);
    }

    public String getCol95() {
        return getCol(95);
    }

    public String getCol96() {
        return getCol(96);
    }

    public String getCol97() {
        return getCol(97);
    }

    public String getCol98() {
        return getCol(98);
    }

    public String getCol99() {
        return getCol(99);
    }
}
