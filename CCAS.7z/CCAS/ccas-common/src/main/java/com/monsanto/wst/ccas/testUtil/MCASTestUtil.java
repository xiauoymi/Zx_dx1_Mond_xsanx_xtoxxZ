package com.monsanto.wst.ccas.testUtil;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.controller.userAdmin.UserBusiness;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.model.UserDetails;
import com.monsanto.wst.ccas.model.VarietyBatch;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 6, 2006
 * Time: 3:43:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class MCASTestUtil {

    public static final String TEST_ROLE_1 = "SYSTEM_ADMIN";
    public static final String TEST_ROLE_2 = "USER";
    public static final String TEST_ROLE_3 = "REGIONAL_ADMIN";

    public static final String TEST_REGION_1 = "MEXICO";
    public static final String TEST_REGION_2 = "CANADA";
    public static final String TEST_REGION_3 = "UNITED STATES";

    public static final String TEST_VARIETY_BATCH_ID_1 = "1";
    public static final String TEST_VARIETY_BATCH_ID_2 = "2";
    public static final String TEST_VARIETY_BATCH_ID_3 = "3";
    private static final String TEST_VARIETY_BATCH_ID_4 = "4";

    private static final String TEST_VARIETY_1 = "A7545";
    public static final String TEST_VARIETY_2 = "B5645";
    public static final String TEST_VARIETY_3 = "A7545";
    private static final String TEST_VARIETY_4 = "C7866";

    private static final String TEST_BATCH_1 = "MTA-318";
    public static final String TEST_BATCH_2 = "MTA898";
    public static final String TEST_BATCH_3 = "MMP-7878";
    private static final String TEST_BATCH_4 = "MST899";

    public static Map<String, UserDetails> getTestUserMap() {
        Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
        UserDetails monUserDetails = new UserDetails("MONUSER", "Monsanto User", 3, "USER", new MockUserRegion("MONUSER", new String[]{"1", "2"}), "APAC", 1, 1);
        UserDetails aUserDetails = new UserDetails("AUser", "R-NAME", 3, "USER", new MockUserRegion("AUser", new String[]{"1", "2"}), "CANADA", 1, 1);
        UserDetails bUserDetails = new UserDetails("BUser", "R-NAME", 3, "USER", new MockUserRegion("BUser", new String[]{"1", "2"}), "CANADA", 1, 1);
        monUserDetails.setUserBusiness(new UserBusiness("MONUSER", new String[]{"1", "2"}));
        aUserDetails.setUserBusiness(new UserBusiness("AUser", new String[]{"1", "2"}));
        bUserDetails.setUserBusiness(new UserBusiness("BUser", new String[]{"1", "2"}));
        userMap.put("CUser", new UserDetails("CUser", "X-NAME", 1, 1, TEST_ROLE_1, TEST_REGION_1, 1,
                1));
        userMap.put("AUser", new UserDetails("AUser", "R-NAME", 2, 2, TEST_ROLE_2, TEST_REGION_2, 1,
                1));
        userMap.put("BUser", new UserDetails("BUser", "R-NAME", 3, 3, TEST_ROLE_3, TEST_REGION_3, 1,
                1));
        userMap.put("MONUSER", monUserDetails);
        userMap.put("AUser", aUserDetails);
        userMap.put("BUser", bUserDetails);
        return userMap;
    }

    public static Map<String, String> getTestRegionList() {
        Map<String, String> regionMap = new HashMap<String, String>();
        regionMap.put("1", TEST_REGION_1);
        regionMap.put("2", TEST_REGION_2);
        regionMap.put("3", TEST_REGION_3);
        return regionMap;
    }

    public static Map<String, String> getTestRoleList() {
        Map<String, String> roleList = new HashMap<String, String>();
        roleList.put("1", TEST_ROLE_1);
        roleList.put("2", TEST_ROLE_2);
        roleList.put("3", TEST_ROLE_3);
        return roleList;
    }

    public static User getTestLoginUser() {
        return new User("MONUSER", "Monsanto User", "testUser@testDomain.com", null, new HashMap<String, Boolean>());
    }

    public static UserDetails getTestUserDetailsForShowUser(String userId) {
        if (userId.equalsIgnoreCase("userPresentInDatabase")) {
            return new UserDetails("userPresentInDatabase", null, 2, 3, "testUserRole", "testUserRegion", 1,
                    1);
        }
        return new UserDetails("", null, 2, 3, "testUserRole", "testUserRegion", 1,
                1);
    }

    public static Map<String, UserDetails> getTestUserMap(String selectedRole, String[] selectedRegions) {
        if (!StringUtils.isNullOrEmpty(selectedRole) && selectedRole.equalsIgnoreCase("1")
                && selectedRegions != null && selectedRegions.length > 0) {
            Map<String, UserDetails> userMap = new LinkedHashMap<String, UserDetails>();
            userMap.put("user1", new UserDetails("user1", null, 1, 1, "role1", "region1", 1, 1));
            userMap.put("user2", new UserDetails("user1", null, 2, 2, "role2", "region2", 1, 1));
            userMap.put("user3", new UserDetails("user1", null, 3, 3, "role3", "region3", 1, 1));
            return userMap;
        }
        return null;
    }

    public static Map<String, LocationInfo> getTestLocationMap(String selectedRole) {
        if (selectedRole != null && selectedRole.equalsIgnoreCase("2")) {
            Map<String, LocationInfo> locationMap = new LinkedHashMap<String, LocationInfo>();
            locationMap.put("1002", new LocationInfo("1002", "Winnipeg Can", null, 1, "North America", true, "stlcc@monsanto.com", "user3@monsanto.com", true, true, true, true, true, true));
            locationMap.put("1001", new LocationInfo("1001", "Ashton, IL", null, 2, "Latin America - South", false, "la-s@monsanto.com", "user22@monsanto.com", true, true, true, true, true, true));
            locationMap.put("1000", new LocationInfo("1000", "St. Louis, CC", "St. Louis, Creve Coeur", 1, "North America", true, "stlcc@monsanto.com", "user1@monsanto.com", false, true, true, true, true, true));
            return locationMap;
        }
        return null;
    }

    public static Map<String, LocationInfo> getLocationMapForSortTest(String selectedRole) {
        if (selectedRole != null && selectedRole.equalsIgnoreCase("2")) {
            Map<String, LocationInfo> locationMap = new LinkedHashMap<String, LocationInfo>();
            locationMap.put("4", new LocationInfo("4", "Winnipeg Can", null, 1, "North America", true, "stlcc@monsanto.com", "user3@monsanto.com", true, true, true, true, true, true));
            locationMap.put("ASTN", new LocationInfo("ASTN", "Ashton, IL", null, 2, "Latin America - South", false, "la-s@monsanto.com", "user22@monsanto.com", true, true, true, true, true, true));
            locationMap.put("05", new LocationInfo("05", "St. Louis, CC", "St. Louis, Creve Coeur", 1, "North America", true, "stlcc@monsanto.com", "user1@monsanto.com", false, true, true, true, true, true));
            return locationMap;
        }
        return null;
    }

    public static Map<String, VarietyBatch> getVarietyBatchData(String varietyPattern, String batchPattern) {
        Map<String, VarietyBatch> varietyBatchMap = new LinkedHashMap<String, VarietyBatch>();
        if (StringUtils.isNullOrEmpty(varietyPattern) && StringUtils.isNullOrEmpty(batchPattern)) {
            varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, TEST_VARIETY_1, TEST_BATCH_1));
            varietyBatchMap.put(TEST_VARIETY_BATCH_ID_2, new VarietyBatch(2, TEST_VARIETY_2, TEST_BATCH_2));
            varietyBatchMap.put(TEST_VARIETY_BATCH_ID_3, new VarietyBatch(3, TEST_VARIETY_3, TEST_BATCH_3));
            varietyBatchMap.put(TEST_VARIETY_BATCH_ID_4, new VarietyBatch(4, TEST_VARIETY_4, TEST_BATCH_4));
        } else {
            if (!StringUtils.isNullOrEmpty(varietyPattern) && varietyPattern.equalsIgnoreCase("A75")) {
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, TEST_VARIETY_1, TEST_BATCH_1));
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_3, new VarietyBatch(2, TEST_VARIETY_3, TEST_BATCH_3));
            }
            if (!StringUtils.isNullOrEmpty(batchPattern) && batchPattern.equalsIgnoreCase("MTA")) {
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, TEST_VARIETY_1, TEST_BATCH_1));
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_2, new VarietyBatch(2, TEST_VARIETY_2, TEST_BATCH_2));
            }
            if (!StringUtils.isNullOrEmpty(varietyPattern) && !StringUtils.isNullOrEmpty(batchPattern)) {
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, varietyPattern, batchPattern));
            }
            if (StringUtils.isNullOrEmpty(varietyPattern) && !StringUtils.isNullOrEmpty(batchPattern)) {
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, "DK527", batchPattern));
            }
            if (!StringUtils.isNullOrEmpty(varietyPattern) && StringUtils.isNullOrEmpty(batchPattern)) {
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_1, new VarietyBatch(1, varietyPattern, batchPattern));
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_2, new VarietyBatch(2, varietyPattern, "0-50/463"));
                varietyBatchMap.put(TEST_VARIETY_BATCH_ID_3, new VarietyBatch(3, varietyPattern, "0-50/464"));
            }
        }
        return varietyBatchMap;
    }
}
