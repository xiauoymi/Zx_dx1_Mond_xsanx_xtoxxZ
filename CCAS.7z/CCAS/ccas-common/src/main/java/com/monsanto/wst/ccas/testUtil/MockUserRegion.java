package com.monsanto.wst.ccas.testUtil;

import com.monsanto.wst.ccas.controller.userAdmin.UserRegion;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 20, 2008
 * Time: 3:44:29 PM
 * To change this template use File | Settings | File Templates.
 */
class MockUserRegion extends UserRegion {
    public MockUserRegion(String s, String[] regionIds) {
        super(s, regionIds);
    }
}
