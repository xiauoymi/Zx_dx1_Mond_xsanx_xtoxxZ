/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.usernameupdateservice;

import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Filename:    $RCSfile: UserNameUpdateServiceDriver.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class UserNameUpdateServiceDriver {

    private static String databaseServerName = null;
    private static String portNumber = null;
    private static String sid = null;
    private static String userName = null;
    private static String password = null;

    public static void main(String[] args) {
        try {
            getUserInputForDBConnectionDetails();
            UserNameUpdateService userNameUpdateService = new UserNameUpdateService();
            userNameUpdateService.updateUsersWithUserName();
            System.out.println("\nUpdate User Name Successful!");
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            System.out.println("\nUpdate User Name Failed, Please see the error stack above.");
        }
    }

    private static void getUserInputForDBConnectionDetails() throws IOException {
        BufferedReader consoleReader = null;

        try {
            consoleReader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter Database Server Name (Eg: dev01.monsanto.com): ");
            databaseServerName = consoleReader.readLine();
            System.out.print("Enter Port Number (mostly 1521): ");
            portNumber = consoleReader.readLine();
            System.out.print("Enter Database Instance ID (or sid, Eg: comgend): ");
            sid = consoleReader.readLine();
            System.out.print("Enter User Name: ");
            userName = consoleReader.readLine();
            System.out.print("Enter Password: ");
            password = consoleReader.readLine();
            System.out.println("\nPlease wait while user names are being updated...\n");
        }
        finally {
            MCASResourceUtil.closeResource(consoleReader);
        }
    }
}