/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.usernameupdateservice.dao;

import com.monsanto.wst.ccas.model.User;

import java.util.List;

/**
 * Filename:    $RCSfile: UserAdministrationDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-03-23 19:08:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public interface UserAdministrationDAO {

    List<User> getUserIds() throws Exception;

    boolean updateUsersWithUserName(List<User> userList) throws Exception;


}