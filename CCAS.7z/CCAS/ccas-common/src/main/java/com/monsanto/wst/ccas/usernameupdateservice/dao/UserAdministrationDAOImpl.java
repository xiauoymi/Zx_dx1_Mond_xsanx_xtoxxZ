/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.usernameupdateservice.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASResourceUtil;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: UserAdministrationDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-03-25 15:33:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class UserAdministrationDAOImpl implements UserAdministrationDAO {

    private static final String ORACLE_DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
    private DataSource dataSource;
    private static final String GET_USER_IDS_SQL =
            "SELECT ua.user_id, ua.user_name \n" +
                    "  FROM user_administration ua";

    private static final String UPDATE_USERS_WITH_USER_NAME_SQL =
            "UPDATE user_administration ua \n" +
                    "   SET ua.user_name = ? \n" +
                    " WHERE upper(ua.user_id) = upper(?) ";

    private String GET_BUSINESS_RELATED_REGIONS = "SELECT R.REGION_ID,R.REGION_DESCRIPTION " +
            " FROM REGION_REF R,BUSINESS_REGION_REF BRR,BUSINESS B\n" +
            " WHERE " +
            " B.BUSINESS_ID = BRR.BUSINESS_ID " +
            " AND R.REGION_ID = BRR.REGION_ID ";

    public UserAdministrationDAOImpl(DataSource datasource) {
        this.dataSource = datasource;
    }

    public List<User> getUserIds() throws Exception {
        List<User> userList = new ArrayList<User>();
        Connection conn = dataSource.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;

        try {
            psmt = conn.prepareStatement(GET_USER_IDS_SQL);
            rs = psmt.executeQuery();
            while (rs.next()) {
                String userId = rs.getString("user_id");
                String userName = rs.getString("user_name");
                userList.add(new User(userId, userName, null, null, new HashMap<String, Boolean>()));
            }
            return userList;
        } catch (Exception e) {
            throw new Exception(e);
        }
        finally {
            MCASResourceUtil.closeDBResources(conn, psmt, rs);
        }
    }

    public boolean updateUsersWithUserName(List<User> userList) throws Exception {

        Connection conn = dataSource.getConnection();
        PreparedStatement psmt = null;

        try {
            psmt = conn.prepareStatement(UPDATE_USERS_WITH_USER_NAME_SQL);
            for (int i = 0; userList != null && i < userList.size(); i++) {
                User user = userList.get(i);
                psmt.setString(1, user.getFull_name());
                psmt.setString(2, user.getUser_id());
                psmt.addBatch();
            }
            psmt.executeBatch();
            conn.commit();
            return true;
        } catch (Exception e) {
            throw new Exception(e);
        }
        finally {
            MCASResourceUtil.closeDBResources(conn, psmt, null);
        }
    }

    /**
     * Bhargav 04/14/2008
     * <p/>
     * Method to fetch regions based on Business Selected
     *
     * @param businessIds
     * @return Map<Id,Description>
     * @throws Exception
     */
    public Map<String, String> getRegionListOnBusinessChange(String[] businessIds) throws Exception {
        Map<String, String> regionMap = new HashMap<String, String>();
        Connection conn = dataSource.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String businessIdInClause = prepareBusinessIdInClause(businessIds);
        String orderByClause = "ORDER BY REGION_DESCRIPTION ASC";
        try {
            GET_BUSINESS_RELATED_REGIONS = GET_BUSINESS_RELATED_REGIONS + businessIdInClause + orderByClause;
            ps = conn.prepareStatement(GET_BUSINESS_RELATED_REGIONS);
            rs = ps.executeQuery();
            if (rs != null) {
                int regionId;
                String description;
                while (rs.next()) {
                    regionId = rs.getInt("REGION_ID");
                    description = rs.getString("REGION_DESCRIPTION");
                    regionMap.put(Integer.toString(regionId), description);
                }
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            throw new Exception("Exception in " + getClass() + "getRegionListOnBusinessChange() method " + e.getMessage(), e);
        } finally {
            MCASResourceUtil.closeDBResources(conn, ps, rs);
        }
        return regionMap;
    }

    private String prepareBusinessIdInClause(String[] businessIds) {
        StringBuffer businessIdInClauseBuffer = new StringBuffer(" AND B.BUSINESS_ID IN ( ");
        if (isBusinessNull(businessIds)) {
            return "";
        }
        for (String businessId : businessIds) {
            if (StringUtils.isNumeric(businessId)) {
                businessIdInClauseBuffer.append(businessId);
                businessIdInClauseBuffer.append(",");
            }
        }
        businessIdInClauseBuffer.deleteCharAt(businessIdInClauseBuffer.lastIndexOf(","));
        businessIdInClauseBuffer.append(" )");

        return businessIdInClauseBuffer.toString();
    }

    private static boolean isBusinessNull(String[] businessIds) {
        return businessIds == null || (businessIds.length == 1 && businessIds[0].equalsIgnoreCase(""));
    }
}