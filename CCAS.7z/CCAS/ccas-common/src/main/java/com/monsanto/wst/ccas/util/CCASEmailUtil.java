package com.monsanto.wst.ccas.util;

import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 10, 2011
 * Time: 11:24:41 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CCASEmailUtil {
    String getEmailAddressForUser(String nameOrUserId) throws EmailAddressRetrievalException;

//    String getEmailAddressForNameOrUserId(String nameOrUserId) throws EmailAddressRetrievalException;
}
