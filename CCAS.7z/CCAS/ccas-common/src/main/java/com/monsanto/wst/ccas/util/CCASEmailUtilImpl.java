package com.monsanto.wst.ccas.util;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.EmailAddressRetrievalException;

import javax.print.attribute.standard.MultipleDocumentHandling;
import java.util.List;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

/**
 * Date: Oct 6, 2009 Time: 3:16:38 PM
 */
public class CCASEmailUtilImpl implements CCASEmailUtil {
    private final PeopleService peopleService;

    public CCASEmailUtilImpl(PeopleService peopleService) {
        this.peopleService = peopleService;
    }

    public String getEmailAddressForUser(String nameOrUserId) throws EmailAddressRetrievalException {

        String firstName = "", lastName = "", middleInitial = "", userId = "";
            String displayName="";
            boolean isId=false;
            isId=true;

            //If user id appended to name
            if (!StringUtils.isNullOrEmpty(nameOrUserId) && nameOrUserId.indexOf("/") != -1) {
                StringTokenizer st = new StringTokenizer(nameOrUserId, "/");
                displayName=st.nextToken();
                userId=st.nextToken();
            }

            else if (!StringUtils.isNullOrEmpty(nameOrUserId) && nameOrUserId.indexOf(",") != -1) {
                displayName=nameOrUserId;
                StringTokenizer st = new StringTokenizer(nameOrUserId, ",");
                if (st.hasMoreTokens()) {
                    lastName = st.nextToken().trim();
                    firstName = st.nextToken().trim();
                    middleInitial = "";
                    int firstNameIndex = firstName.indexOf(" ");
                    if (firstNameIndex != -1) {
                        middleInitial = firstName.substring(firstNameIndex).trim();
                        firstName = firstName.substring(0, firstNameIndex).trim();
                    }
                } else {
                    userId = nameOrUserId;
                }

            } else {
                userId = nameOrUserId;
            }
            try {
                StringBuffer b;
                String userIdentity;
                PersonInfo[] personInfos = peopleService.GetPeople(lastName, firstName, "", "", userId, "", "");

                String best = null;

                String adminEmailList="qm.team.sap@monsanto.com";

                if (personInfos != null) {

                    //If personinfos has more than one match search in user administration table
                    if(personInfos.length>1){
                        UserAdminDAO userAdminDAO = (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);

                        //Find a match in user_administration
                        List<String> listIds=userAdminDAO.getUserId(displayName);
                        //If multiple matchs or no match at all, return sapmq, user id should be appended to user name in the specific record
                        if(listIds.size()==0||listIds.size()>1){
                            return adminEmailList;
                            }
                        else{
                            userId=listIds.get(0);
                            personInfos = peopleService.GetPeople("", "", "", "", userId, "", "");
                            //If person is null user might no longer belong to monsanto, send email to sap qm
                            if(personInfos!=null){
                                //User Id return multiple
                                if(personInfos.length>1){
                                    for(PersonInfo pi:personInfos){
                                        if(pi.getUserId().equalsIgnoreCase(userId)){
                                            return pi.getEmail()+"@monsanto.com";
                                        }
                                    }
                                }
                                else{
                                    return personInfos[0].getEmail()+"@monsanto.com";
                                    }
                                }
                            else{
                                return adminEmailList;
                            }
                        }



                    }
                    else{
                    for (int i = 0; i < personInfos.length; i++) {

                        PersonInfo p = personInfos[i];
                        b = new StringBuffer();
                        b.append(" ").append(p.getFirstName()).append(" ").append(p.getMiddleName()).append(" ")
                                .append(p.getLastName()).append(" ").append(p.getUserId());
                        userIdentity = b.toString();
                        if (userIdentity.contains(userId.toUpperCase())
                                && userIdentity.contains(lastName.toUpperCase())
                                && userIdentity.contains(middleInitial.toUpperCase())
                                && userIdentity.contains(firstName.toUpperCase())) {

                            if (i < personInfos.length - 1 && !StringUtils.isNullOrEmpty(p.getMiddleName())) {
                                if (userIdentity.contains(p.getMiddleName())) {
                                    best = p.getEmail() + "@monsanto.com";
                                    continue;
                                }
                            }

                            return p.getEmail() + "@monsanto.com";
                        }
                    }
                }
                }

                if (best != null)
                    return best;

                throw new EmailAddressRetrievalException(
                        "Could not find Email Address from People Service for [last_name=" + lastName + "], [middile_name=" + middleInitial + "], [first_name=" + firstName + "], [user_id=" + userId + "]");
            } catch (Exception e) {
                throw new EmailAddressRetrievalException(
                        "Exception retrieving Email Address from People Service " + e.getMessage(), e);
            }

    }

    /**
     * This method returns the valid email of a single user.
     * @param userId
     * @return
     */
    public String returnValidEmailAddress(String userId) {
        return userId + "@monsanto.com";
    }

}
