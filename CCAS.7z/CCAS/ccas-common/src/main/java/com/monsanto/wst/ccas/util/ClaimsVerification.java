package com.monsanto.wst.ccas.util;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/2/14
 * Time: 9:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class ClaimsVerification {



    public static boolean isCropVarietyBatchConsult(String claimNumber, String region_id){
        if(isRegionNorthAmerica(region_id) && verifyClaimNumberExistence(claimNumber) && verifyClaimNumberPattern(claimNumber)){
              return true;
        }
        return false;
    }

    private static boolean isRegionNorthAmerica(String region_id){
        return region_id!=null&&region_id.equalsIgnoreCase("1") ? true :  false;
    }

    private static boolean verifyClaimNumberExistence(String claimNumber){
        return (claimNumber!=null&&!claimNumber.equalsIgnoreCase("")) ? true:false;
    }

    private static boolean verifyClaimNumberPattern(String claimNumber){
        try{
            Long l = Long.parseLong(claimNumber);
        }catch(NumberFormatException e){
            return false;
        }

        if(claimNumber.length()!=9) return false;

        return true;
    }
}
