package com.monsanto.wst.ccas.util;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.securityinterfaces.SystemSecurityProxy;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Mar 19, 2009
 * Time: 2:11:17 PM
 * To change this template use File | Settings | File Templates.
 */
class DocumentumXMLPOSConnection extends SecureXMLPOSConnection {
    private final UCCHelper helper;

    public DocumentumXMLPOSConnection(KerberosSPNEGOClient kerberosSPNEGOClient, SystemSecurityProxy systemSecurityProxy, UCCHelper helper) {
        super(kerberosSPNEGOClient, systemSecurityProxy);
        this.helper = helper;
    }

    protected String getURL(String posName) throws POSCommunicationException {
        String defaultURL = super.getURL(posName);
        String documentumServiceURL = checkForServiceRequests(helper, posName, defaultURL);
//        System.out.println("Doc Service URL******************* " + documentumServiceURL);
        return documentumServiceURL;
    }

    private String checkForServiceRequests(UCCHelper helper, String posName, String defaultURL) {
        String documentumServiceURL = "";
        if (isAttachmentRelatedRequest(posName)) {
            if (isAlternativeTestURL(helper)) { // Alternative URL for Test
                documentumServiceURL = "http://docservice-alt-t.monsanto.com" + defaultURL.substring(defaultURL.indexOf("/entdocumentservice"));
            } else if (isAlternativeITURL(helper)) {
                documentumServiceURL = "http://docservice-alt-t.monsanto.com" + defaultURL.substring(defaultURL.indexOf("/entdocumentservice"));
            } else if (isAlternativeProdURL(helper)) {
                documentumServiceURL = "http://docservice-alt-p.monsanto.com" + defaultURL.substring(defaultURL.indexOf("/entdocumentservice"));
            } else {
                documentumServiceURL = defaultURL;
            }
            return documentumServiceURL;

        }
        return defaultURL;
    }

    private boolean isAlternativeProdURL(UCCHelper helper) {
        return helper.requestedURL().contains("w3k.mcas.monsanto.com");
    }

    private boolean isAlternativeTestURL(UCCHelper helper) {
        return helper.requestedURL().contains("w3tk.mcas.monsanto.com");
    }

    private boolean isAlternativeITURL(UCCHelper helper) {
        return helper.requestedURL().contains("w3itk.mcas.monsanto.com");
    }

    private boolean isAttachmentRelatedRequest(String posName) {
        return "InsertDocumentService".equalsIgnoreCase(posName) ||
                "RetrieveDocumentService".equalsIgnoreCase(posName) ||
                "DeleteDocumentService".equalsIgnoreCase(posName);
    }


}
