package com.monsanto.wst.ccas.util;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/8/14
 * Time: 10:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocationMapResourceUtil {

    private static final String NOT_FOUND = null;

    /**
     * Location Map has the following structure
     *      KEY = LocationShortName-REGION_ID
     *      VALUE =  (Location ID)
     *
     * @param locationMap
     * @param locationShortName
     * @param regionId
     * @return  null when key is not found, a string value all other cases
     */
    public static String getLocationIdByLocationNameAndRegionId(Map<String, String> locationMap, String locationShortName, String regionId) {
        if (validateRegionIdIsNotNullOrEmpty(regionId) && validateLocationMapIsNotNullOrEmpty(locationMap)) {
            return retrieveLocationIdFromMap(locationMap, locationShortName, regionId);
        }
        return NOT_FOUND;
    }


    private static boolean validateLocationMapIsNotNullOrEmpty(Map<String, String> regionStateMap){
        if(regionStateMap==null || regionStateMap.isEmpty()){
            return false;
        }

        return true;
    }

    private static String retrieveLocationIdFromMap(Map<String, String> locationMap, String locationShortName, String regionId) {
        String key = locationShortName + "-" + regionId;
        String locationId = locationMap.get(key);
        if (locationId == NOT_FOUND) {
            MCASLogUtil.logMessage("The region"+regionId+" does not has a valid location short name ("+locationShortName+")");
        }
        return locationId;

    }

    private static boolean validateRegionIdIsNotNullOrEmpty(String regionId) {

        if (StringUtils.isNullOrEmpty(regionId)) {
            MCASLogUtil.logMessage("Region Id:"+regionId+" is invalid");
            return false;
        }
        return true;

    }


}
