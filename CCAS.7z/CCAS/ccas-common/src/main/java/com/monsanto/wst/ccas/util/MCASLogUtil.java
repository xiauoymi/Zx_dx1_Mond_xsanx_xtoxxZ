/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.util;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.ccas.actions.GlobalAbomination;

import javax.servlet.http.HttpSession;
import java.util.Calendar;

/**
 * Filename:    $RCSfile: MCASLogUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-03-10 16:14:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MCASLogUtil {

    public static void logError(String errorMessage, Exception exception) {
        if (errorMessage != null) {
            logMessage(errorMessage + " " + exception.getMessage());
        }
        if (exception != null) {
            logTrace(exception);
            GlobalAbomination.lastException = exception;
        }
    }

    public static void logMessage(String message) {
        Calendar cal = Calendar.getInstance();
        Logger.log(new LoggableError(cal.getTime() + " MCAS Exception..."));
        Logger.log(new LoggableError("Message: " + message));
    }

    private static void logTrace(Exception cause) {
        Calendar cal = Calendar.getInstance();
        Logger.log(new LoggableError(cal.getTime() + " MCAS Error Stack Trace:..."));
        Logger.log(new LoggableError(cause));

        GlobalAbomination.lastException = cause;
    }
}