package com.monsanto.wst.ccas.util;

import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.RegionServiceImpl;
import com.monsanto.wst.ccas.actions.ActionHelperConstants;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Sep 5, 2006
 * Time: 2:31:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class MCASLookupFilterUtil {

    /**
     * Compares user-regions (based on user-role) with entity-region (complaint, audit etc.)
     * Requirement:
     * If the entity-region is same as user-region -> display the list of all regions that belong to user (based on role) in the lookups (for edit screens).
     * If the entity-region is different compared to user-region -> display only that particular region  (for edit screens).
     *
     * @param entityRegionId
     * @param booleanVariableName
     * @param viewableRegionListName
     * @param user
     * @param request
     * @throws Exception
     */
    public void filterRegionLookup(String entityRegionId, String booleanVariableName,
                                   String viewableRegionListName, User user, HttpServletRequest request, String regionListName) throws Exception {
        boolean userInEntityRegion = isUserInEntityRegion(entityRegionId, user.getUser_id(), request);
        if (!userInEntityRegion) {
            request.getSession().setAttribute(booleanVariableName, "false");
            addViewableRegionAsList(entityRegionId, viewableRegionListName, request, regionListName);
        } else {
            request.getSession().setAttribute(booleanVariableName, "true");
        }
    }

    /**
     * Compares user-region with location-region (reporting, responsible, shipping etc.)
     * Requirement:
     * If the location-region is same as user-region -> display the list of all locations that belong to user-region in the lookups (for edit screens).
     * If the location-region is different compared to user-region -> display only that particular location  (for edit screens).
     *
     * @param entityLocationId
     * @param booleanVariableName
     * @param viewableLocationListName
     * @param user
     * @param request
     * @throws Exception
     */
    public void filterLocationLookup(String entityLocationId, String booleanVariableName,
                                     String viewableLocationListName, User user, HttpServletRequest request, int currentBusinessId, String regionLocationListName) throws Exception {
        boolean userInLocationRegion = isUserInLocationRegion(entityLocationId, user.getBusinessId(), user);
        if (!userInLocationRegion) {
            request.getSession().setAttribute(booleanVariableName, "false");
            addViewableLocationAsList(entityLocationId, viewableLocationListName, request, regionLocationListName);
        } else {
            addViewableLocationAsList(entityLocationId, viewableLocationListName, request, regionLocationListName);
            request.getSession().setAttribute(booleanVariableName, "true");
        }
    }

    private boolean isUserInEntityRegion(String entityRegionId, String userId, HttpServletRequest request) throws Exception {
        return getUserRegionList(request, userId).containsKey(entityRegionId);
    }

    private Map<String, String> getUserRegionList(HttpServletRequest request, String userId) {
        Map<String, String> userRegionList = (Map<String, String>) request.getSession().getAttribute(MCASConstants.HELPER_VAR_REGION_LIST);
        User user = (User) request.getSession().getAttribute(User.USER);
        //int businessId = ((User)request.getSession().getAttribute(ActionHelper.USER)).getBusinessId();
        if (userRegionList == null) {
            int businessId = -1;
            userRegionList = new RegionServiceImpl().getRegionList(userId, businessId, user.getLocale());
        }
        return userRegionList;
    }

    private void addViewableRegionAsList(String regionId, String viewableRegionListName, HttpServletRequest request, String regionListName) throws Exception {
        Map viewableRegionList;
        final User user = (User) request.getSession().getAttribute(User.USER);

        //this doesn't appear to be used.
//        Map alRegionSessionList = (Map) request.getSession().getAttribute(regionListName);
//        if (alRegionSessionList == null) {
//            int businessId = -1;
//            alRegionSessionList = new RegionServiceImpl().getRegionList(user.getUser_id(), businessId, user.getLocale());
//        }

        Map viewableSessionRegionList = (Map) request.getSession().getAttribute(viewableRegionListName);
        if (viewableSessionRegionList == null) {
            int businessId = -1;
            viewableRegionList = new RegionServiceImpl().getRegionList(user.getUser_id(), businessId, user.getLocale());
            request.getSession().setAttribute(viewableRegionListName, viewableRegionList);
        }
    }

    private boolean isUserInLocationRegion(String locationId, int businessId, User user) throws Exception {
        return user.isUserInLocationRegion(locationId, businessId);
    }

    private void addViewableLocationAsList(String locationId, String viewListName, HttpServletRequest request, String regionListName) {
        Map allLocationSessionList = (Map) request.getSession().getAttribute(regionListName);

        //fix for MCAS Vegetable not having responsible location list in session.  Investigate later
        if (allLocationSessionList == null)
            allLocationSessionList = (Map) request.getSession().getAttribute(ActionHelperConstants.REGION_SPECIFIC_LOCATION_LIST);

        if (allLocationSessionList != null && allLocationSessionList.size() > 0) {
            request.getSession().setAttribute("editLocationName", allLocationSessionList.get(locationId));
            request.getSession().setAttribute(viewListName, allLocationSessionList);
        }
    }
}
