/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.ccas.util;

import java.sql.*;
import java.io.Closeable;
import java.io.IOException;

public class MCASResourceUtil {

    public static void closeDBResources(Connection connection, Statement statement, ResultSet resultSet) {
        try {
            //I'm not sure why, but checking .isClosed() on some types of ResultSets
            //causes the isClosed() method to throw a NullPointerException
            if (resultSet != null) {// && !resultSet.isClosed()) {
                resultSet.close();
            }
        } catch (NullPointerException e) {
        } catch (Exception e) {
//            MCASLogUtil.logError(e.getMessage(), e);
        }
        try {
            //I'm not sure why, but checking .isClosed() on some types of Statements
            //causes the isClosed() method to throw a NullPointerException
            if (statement != null) {// && !statement.isClosed()) {
                connection.close();
            }
        } catch (NullPointerException e) {
        } catch (Exception e) {
//            MCASLogUtil.logError(e.getMessage(), e);
        }
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (NullPointerException e) {
        } catch (Exception e) {
//            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    public static void closeResource(Closeable res) {
        try {
            if (res != null) {
                res.close();
            }
        } catch (NullPointerException e) {
        } catch (IOException e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }
}