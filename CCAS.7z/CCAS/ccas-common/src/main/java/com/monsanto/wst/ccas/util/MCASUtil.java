package com.monsanto.wst.ccas.util;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.AuditConstants;
import com.monsanto.wst.ccas.model.User;
import com.monsanto.wst.ccas.service.ServiceException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 6, 2006
 * Time: 3:39:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class MCASUtil {
    private static Map<String, String> methodTypeMap;

    private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

    public static void displayErrorPage(UCCHelper helper) throws IOException {
        helper.forward(MCASConstants.FORWARD_ERROR_PAGE);
    }

    public static String getFileExtension(String localFilePath) {
        return localFilePath.substring(localFilePath.lastIndexOf(".") + 1);
    }

    /**
     * Method to Convert a String into viewable format
     *
     * @param locationString
     * @return
     */
    public static String getModifiedLocationNames(String locationString) {
        StringBuffer locBuf = new StringBuffer();
        try {
            locationString = locationString.toLowerCase();
            String firstCharInString = locationString.substring(0, 1);
            locBuf.append(firstCharInString.toUpperCase());
            String singleChar = "";
            int j;
            for (int i = 1; i < locationString.length(); i++) {
                j = i + 1;
                singleChar = locationString.substring(i, j);
                if (singleChar.equalsIgnoreCase(" ")) {
                    locBuf.append(" ");
                    if (j < locationString.length()) {
                        locBuf.append(locationString.substring(j, j + 1).toUpperCase());
                        i = j;
                    }
                } else {
                    locBuf.append(singleChar);
                }
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
        return locBuf.toString();
    }

    /**
     * Method to trim the input string to 40 chars.
     *
     * @param description
     * @return
     */
    public static String trimDescriptionText(String description) {
        String trimmedText = "";
        if (!StringUtils.isNullOrEmpty(description)) {
            trimmedText = description;
            if (trimmedText.length() > MCASConstants.DESCRIPTION_PREVIEW_LENGTH) {
                trimmedText = trimmedText.substring(0, MCASConstants.DESCRIPTION_PREVIEW_LENGTH);
            }
        }
        return trimmedText;
    }

    public static String escapeXML(String cstrStr) {

        StringBuffer strBuffer = new StringBuffer();
        if (!StringUtils.isNullOrEmpty(cstrStr)) {
            for (int i = 0; i < cstrStr.length(); i++) {

                char cChar = cstrStr.charAt(i);

                if (cChar == '\n') {

                    strBuffer.append("&#10;");

                } else if (cChar == '\r') {
                    strBuffer.append("&#13;");
                } else if (cChar == '<') {
                    strBuffer.append("&lt;");
                } else if (cChar == '>') {
                    strBuffer.append("&gt;");
                } else if (cChar == '\"') {
                    strBuffer.append("&quot;");
                } else if (cChar == '\'') {
                    strBuffer.append("&apos;");
                } else if (cChar == '\\') {
                    strBuffer.append("\\");
                } else if (cChar == ',') {
                    strBuffer.append(",");
                }
                if (!Character.isISOControl(cChar)) {
                    if (Character.getNumericValue(cChar) != -1) {
                        strBuffer.append(cChar);
                    } else if (Character.getNumericValue(cChar) == -1) {//If its a special character
                        if (Character.isWhitespace(cChar)) {//Include only if its a white space
                            strBuffer.append(cChar);
                        } else if (cChar == '.') {
                            strBuffer.append(cChar);
                        } else if (cChar == '-') {
                            strBuffer.append(cChar);
                        }
                    }
                }
            }

        }
        return strBuffer.toString();
    }

    public static boolean validateDate(StringTokenizer st, boolean dateErr) {
        for (int i = 0; i < 3; i++) {
            if (i == 0) {
                String month = st.nextToken().trim();
                if (month.length() != 2) {
                    dateErr = true;
                }
                try {
                    int x = Integer.parseInt(month);
                    if (x < 0 || x > 12) {
                        dateErr = true;
                    }
                }
                catch (Exception e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                    dateErr = true;
                }
            }
            if (i == 1) {
                String day = st.nextToken().trim();
                if (day.length() != 2) {
                    dateErr = true;
                }
                try {
                    int x = Integer.parseInt(day);
                    if (x < 0 || x > 31) {
                        dateErr = true;
                    }
                }
                catch (Exception e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                    dateErr = true;
                }
            }
            if (i == 2) {
                String year = st.nextToken().trim();
                if (year.length() != 4) {
                    dateErr = true;
                }
                try {
                    int x = Integer.parseInt(year);
                }
                catch (Exception e) {
                    MCASLogUtil.logError(e.getMessage(), e);
                    dateErr = true;
                }
            }
        }
        return dateErr;
    }

    public static boolean operationSupported(String methodType) {
        populateMethodTypeMap();
        return !StringUtils.isNullOrEmpty(methodTypeMap.get(methodType));
    }

    private static void populateMethodTypeMap() {
        if (methodTypeMap == null) {

            Map<String, String> temp = new HashMap<String, String>();
            temp.put("complaintNew", "true");
            temp.put("complaintSubmit", "true");
            temp.put("stopSaleDisplay", "true");
            temp.put("stopSaleSubmit", "true");
            temp.put("cparNew", "true");
            temp.put("cparSubmit", "true");
            temp.put(AuditConstants.AUDIT_NEW, "true");
            temp.put(AuditConstants.AUDIT_SAVE_OR_UPDATE, "true");
            temp.put(AuditConstants.AUDIT_FINDING_SAVE, "true");
            temp.put("attachFile", "true");
            temp.put(AuditConstants.AUDIT_FINDING_SAVE, "true");
            temp.put(AuditConstants.AUDIT_CREATE_CAR, "true");
            temp.put(AuditConstants.AUDIT_ADD_FINDING_CANCEL, "true");
            temp.put(AuditConstants.AUDIT_VIEW_EDIT, "true");

            methodTypeMap = temp;
        }
    }

    public static String buildInClause(List<Integer> idList) {
        StringBuffer idBuf = new StringBuffer(idList.size());
        for (Integer selectedId : idList) {
            if (selectedId > 0) {
                idBuf.append(selectedId.toString());
                idBuf.append(",");
            }
        }
        idBuf.deleteCharAt(idBuf.length() - 1);
        return idBuf.toString();
    }


    public String getRidOfTag(String tagName, boolean byId, String originalString, String labelIdArray[]) {
        for (String aDivIdArr : labelIdArray) {
            String divString = "<" + tagName + (byId ? " id='" : " name='") + aDivIdArr;
            int startIndexOfDiv = originalString.indexOf(divString);
            String endTag = "</" + tagName + ">";
            if (startIndexOfDiv > 0) {
                String divStringOne = originalString.substring(startIndexOfDiv, originalString.length() - 1);
                int endIndexOfDiv = divStringOne.indexOf(endTag);

                String firstPart = originalString.substring(0, startIndexOfDiv);
                String secondPart = originalString.substring(startIndexOfDiv + endIndexOfDiv + endTag.length(), originalString.length());
                originalString = firstPart + secondPart;
            }
        }
        return originalString;  //To change body of created methods use File | Settings | File Templates.
    }

    public String getRidOfTagClass(String tagName, String originalString, String labelIdArray[]) {
        for (String aDivIdArr : labelIdArray) {
            String divString = "<" + tagName + " class='" + aDivIdArr+"'>";
            int startIndexOfDiv = originalString.indexOf(divString);
            String endTag = "</" + tagName + ">";
            if (startIndexOfDiv > 0) {
                String divStringOne = originalString.substring(startIndexOfDiv, originalString.length() - 1);
                int endIndexOfDiv = divStringOne.indexOf(endTag);

                String firstPart = originalString.substring(0, startIndexOfDiv);
                String secondPart = originalString.substring(startIndexOfDiv + endIndexOfDiv + endTag.length(), originalString.length());
                originalString = firstPart + secondPart;
            }
        }
        return originalString;  //To change body of created methods use File | Settings | File Templates.
    }

    public String getTag(String tagName, boolean byId, String originalString, String labelIdArray[]) {
        String middlePart="";
        for (String aDivIdArr : labelIdArray) {
            String divString = "<" + tagName + (byId ? " id='" : " name='") + aDivIdArr;
            int startIndexOfDiv = originalString.indexOf(divString);
            String endTag = "</" + tagName + ">";
            if (startIndexOfDiv > 0) {
                String divStringOne = originalString.substring(startIndexOfDiv, originalString.length() - 1);
                int endIndexOfDiv = divStringOne.indexOf(endTag);

                middlePart = originalString.substring(startIndexOfDiv, startIndexOfDiv + endIndexOfDiv + endTag.length());


            }
        }
        return middlePart;
    }

    public String insertNew(String originalString,String value,String begining){
        int startIndexOfDiv = originalString.indexOf(begining);
        String divString = "<" + "div" + " id='" +begining;
         startIndexOfDiv = originalString.indexOf(divString);
        if (startIndexOfDiv > 0) {

             String divStringOne = originalString.substring(startIndexOfDiv, originalString.length() - 1);

                //<div id="gen_info"
                String firstPart = originalString.substring(0, startIndexOfDiv);
                String table="<div style=\"width:650;overflow: visible;\"><table style=\"font-family: Arial, Helvetica, sans-serif;  font-size: 20px;\"" +
                        "cellspacing=\"0\" cellpadding=\"0\" class=\"tbl_pad\" border=\"0\" width=\"650\"><tbody><tr>"+value+"</tr></tbody></table></div><br>";


                String secondPart = originalString.substring(startIndexOfDiv, originalString.length());
                originalString = firstPart +table+ secondPart;
            }
        return originalString;
    }



    public String getRidOfMCASAdminFieldsFromEmail(String originalString) {
        int startIndex = originalString.indexOf("<div id='comp_02'");
        int endIndex = originalString.indexOf("<div id='comp1_01'");    //comp2_04
        if (startIndex != -1 && endIndex != -1) {
            if (startIndex < endIndex) {
                originalString = originalString.substring(0, startIndex) + originalString.substring(endIndex);
            }
        }
        String str = getRidOfTag("p", false, originalString, new String[]{"c.complaintInvestigation.qualityScores", "c.complaintInvestigation.deliveryInfo"});
        str = getRidOfTag("select", false, str, new String[]{"c.lowCategoryId", "c.issueCategoryId", "c.complaintInvestigation.initiatorSample.id", "c.complaintInvestigation.siteSample.id",  "c.refugePlantedId", "c.traitCheckId", "c.rootInjuryId", "c.injuryRatingId"});
        str = getRidOfTag("select", true, str, new String[]{"responsible_plant_code"});
        str = getRidOfTag("h1", true, str, new String[]{"difficulty_header_1"});
        str = getRidOfTag("label", true, str, new String[]{"Investigator", "initiatorComments", "siteComments", "responsible_plant_code_txt"});
        return getRidOfTag("div", true, str, new String[]{"valid_quality_issue_value", "plantingAndOtherDiv", "comp2_02", "comp2_03"});
    }

    public String getRidOfMCASComplaintClosedFromEmail(String originalString,int varietyBatchSize) {
        int startIndex = originalString.indexOf("td id='headerId'");
        int endIndex = originalString.indexOf("<div id='findings'");
       /* if (startIndex != -1 && endIndex != -1) {
            if (startIndex < endIndex) {
                originalString = originalString.substring(0, startIndex) + originalString.substring(endIndex);
            }
        }*/
         String responsible=getTag("td", true, originalString, new String[]{"initiator_responseTd"});
        String responsible2=getTag("td", true, originalString, new String[]{"initiator_response_valueTd"});
        String str = getRidOfTag("td", true, originalString, new String[]{"claimCategoryIdTd","communicationDateIdTd","fieldCommunicatorTd","stateTd","initialAssesmentTd","complaintCategoryTd",
        "initialAssesment","complaintLitigationCategory","investigatorTd","cparIdTd","id_crop","highLevelTd","lowLevelTd",
        "siteSampleCommentTd","siteSampleTd","initiatorSampleCommentTd","initiatorSampleTd",
                "initiatorSampleCommentTd","siteSampleTd","siteSampleCommentTd","id_claim_statusTd","closedDateTd",
        "cropTd","qualityScoresTd","deliveryInfoTd","uomTd","seedSizeTd","ilTypeTd","cropYrTd","searchTd","deleteTd","findTd","initiator_responseTd","initiator_response_valueTd"
                ,"responsibleLocationId","locationIdSeedTd","id_settlementTd","id_settlement"});
        str = getRidOfTag("label", false, str, new String[]{"c.cpar_id",
        "c.customerLocationInfo","c.communication_date","c.field_communicator","c.responsibleLocationInfo",
        "c.claimStatusType","c.closingDate","c.feedbackCategoryInfo"});
        str = getRidOfTag("label", true, str, new String[]{"fieldCommunicator","feedbackCategoryInfo","customerLocationInfo",

        "communicationDate",
        "responsibleLocationInfo"});
        str = getRidOfTag("select", false, str, new String[]{"c.claimCategoryId","c.crop_id","c.complaintLitigationCategoryCode","c.initialAssesmentCode",
        "c.state_id"});
        str = getRidOfTag("select", true, str, new String[]{"state_id"});
        str = getRidOfTagClass("span", str, new String[]{"required_field_comment"});
        str = getRidOfTagClass("span", str, new String[]{"required_field_style"});
        str = getRidOfTagClass("span", str, new String[]{"requiredfieldcomment"});
        str=insertNew(str,responsible+responsible2,"gen_info");



        //str=getRidOfTag("p",false,str,new String[]{"c.initiator_response"});
        /*
        String str = getRidOfTag("td", true, originalString, new String[]{"entryDateTd", "createdByTd","id_region","id_regionTd","id_settlementTd",
                "id_settlement","claimCategoryIdTd","controlNumberTd","reportingLocationTd","locationIdTd","initiatedByTd","salsYearTd","id_control_number",
        "reportLocation","communicationDateIdTd","fieldCommunicatorTd","stateTd","reportLocation","id_sales_year","initialAssesmentTd","complaintCategoryTd",
        "initialAssesment","complaintLitigationCategory","investigatorTd","cparIdTd","id_crop","highLevelTd","lowLevelTd","responsibleLocationId","locationIdTd",
        "locationIdSeedTd","siteSampleCommentTd","siteSampleTd","initiatorSampleCommentTd","initiatorSampleTd",
                "initiatorSampleCommentTd","siteSampleTd","siteSampleCommentTd","id_claim_statusTd","closedDateTd","initiator_responseTd",
        "cropTd","qualityScoresTd","deliveryInfoTd","uomTd","seedSizeTd","ilTypeTd","cropYrTd","searchTd","findTd"});
        str = getRidOfTag("label", false, str, new String[]{"c.row_entry_date", "c.created_by", "c.settlement_value","c.cpar_id","c.reporting_location_code",
        "c.report_initiator","c.customerLocationInfo","c.communication_date","c.field_communicator","c.responsibleLocationInfo","c.complaint_id",
        "c.claimStatusType","c.closingDate","c.feedbackCategoryInfo","c.reporting_location_code"});
        str = getRidOfTag("label", true, str, new String[]{"reportInitiator","fieldCommunicator","reporting_location_code_txt","feedbackCategoryInfo","customerLocationInfo",

        "communicationDate",
        "responsibleLocationInfo"});
        str = getRidOfTag("select", false, str, new String[]{"c.claimCategoryId","c.crop_id","c.complaintLitigationCategoryCode","c.initialAssesmentCode",
        "c.sales_year_id","c.state_id","c.reporting_location_code","c.region_id"});
        str = getRidOfTag("select", true, str, new String[]{"state_id","region_id"});
        str=getRidOfTag("p",false,str,new String[]{"c.initiator_response"});
        */
        //select name='c.varietyBatchList[0].uomId'
        //<select name='c.varietyBatchList[0].seedSizeId
        //select name='c.varietyBatchList[0].ilType'
        //<select name='c.varietyBatchList[0].batchCropYrId'


        //initiator_responseTd

        for(int i=0;i<varietyBatchSize;i++){
           str = getRidOfTag("select", false, str, new String[]{"c.varietyBatchList["+i+"].uomId",
           "c.varietyBatchList["+i+"].seedSizeId",
           "c.varietyBatchList["+i+"].ilType",
           "c.varietyBatchList["+i+"].batchCropYrId"});
        }

        return getRidOfTag("div", true, str, new String[]{"valid_quality_issue_value", "plantingAndOtherDiv", "comp2_02", "comp2_03","comp1_01","comp1_02","comp1_03",
        "comp1_04","cpar_ci_01","cpar_ci_02","cpar_ci_03","valid_quality_issue_label","refugeTable","seed_info2"});
    }

    //this will fail for nested divs..
    public String getRidOfDiv(String originalString, String divIdArr[]) {
        for (String aDivIdArr : divIdArr) {
            String divString = "<div id='" + aDivIdArr;
            int startIndexOfDiv = originalString.indexOf(divString);
            if (startIndexOfDiv > 0) {
                String divStringOne = originalString.substring(startIndexOfDiv, originalString.length() - 1);
                int endIndexOfDiv = divStringOne.indexOf("</div>");

                String firstPart = originalString.substring(0, startIndexOfDiv);
                String secondPart = originalString.substring(startIndexOfDiv + endIndexOfDiv + 6, originalString.length());
                originalString = firstPart + secondPart;
            }
        }
        return originalString;  //To change body of created methods use File | Settings | File Templates.
    }

    public String getProcessedBody(String printPreviewSrc) {
        //'comp1_01',  'comp1_02' 'comp1_03'  , 'comp1_04' , 'comp2_04'
        //'c.refugePlantedId' , 'c.traitCheckId', 'c.rootInjuryId',  'c.injuryRatingId'
        String[] divArr = {"comp_02", "comp_03", "comp_04", "root_cause2", "root_cause3", "root_cause4", "root_cause5", "root_cause6", "root_cause7",
                "root_cause8", "root_cause9", "root_cause10", "root_cause11", "root_cause12", "root_cause13", "root_cause14", "root_cause15",
                "root_cause16", "root_cause17", "root_cause18", "comp2_01", "comp2_02", "comp2_03",
                "root_cause_info_human", "root_cause_info_equipment"
                , "attach_file_div", "comp1_01", "comp1_02", "comp1_03", "comp1_04", "valid_quality_issue_value",
                "valid_quality_issue_label", "sales_order_information", "to_delete"};
        String div = getRidOfDiv(printPreviewSrc, divArr);
        return div.replaceAll("Equipment Difficulty :", "");
    }

    public static int getUserBusiness(UCCHelper helper, BusinessService businessService) throws ServiceException {
        return businessService.getBusinessId((User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER));
    }

    public static String getAuthenticatedUserID(UCCHelper helper) {
        return ((User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER)).getUser_id().trim().toUpperCase();
    }
    /*
    public static String getUserLocale(UCCHelper helper) {
        return ((User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER)).getLocale().trim().toLowerCase();
    }*/

    public static String getUserLocale(UCCHelper helper) {
        String locale = ((User) helper.getSessionParameter(MCASConstants.SESSION_VAR_USER)).getLocale();
        if(locale == null)
           return null;
        else{
           locale = locale.trim().toLowerCase();
        }
        return locale;
    }
    


    /**
     * Sort a Map on the values
     *
     * @param map
     * @return
     */
    public static Map sortByValue(Map map) {
        List list = new LinkedList(map.entrySet());
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {

                //select text (with empty string as key) should be first in list.
                if (((Map.Entry) (o1)).getKey() == "")
                    return -1;

                return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
            }
        });                                         

        Map result = new LinkedHashMap();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /**
     * Format a date
     *
     * @param date
     * @return
     */
    public static String getDateFormat(java.util.Date date) {
        try {
            if (date == null) return "";
            return sdf.format(date);
        }
        catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
            return "";
        }
    }

    /**
     * Get a file name without the completed path
     *
     * @param localFilePath
     * @return
     */
    public static String getFileName(String localFilePath) {
        //return localFilePath.substring(localFilePath.lastIndexOf("\\") + 1);
        return localFilePath.substring(localFilePath.lastIndexOf("/") + 1);
    }

    public static String validateNoSpecialChars(String fileName) {
        //# % & * : < > ? / { | } "
        if (
                fileName.indexOf("#") != -1 ||
                        fileName.indexOf("%") != -1 ||
                        fileName.indexOf("&") != -1 ||
                        fileName.indexOf("*") != -1 ||
                        fileName.indexOf(":") != -1 ||
                        fileName.indexOf("<") != -1 ||
                        fileName.indexOf(">") != -1 ||
                        fileName.indexOf("?") != -1 ||
                        fileName.indexOf("/") != -1 ||
                        fileName.indexOf("{") != -1 ||
                        fileName.indexOf("|") != -1 ||
                        fileName.indexOf("}") != -1 ||
                        fileName.indexOf("'") != -1 ||
                        fileName.indexOf('"') != -1
                ) {
             return "f";
        }
        else{
            String regex = "^\\p{ASCII}*$" ;
            for(int i=0;i<fileName.length()-1;i++){
                String character=""+fileName.charAt(i);
                if(character.matches(regex)){
                    continue;
                }
                else{
                    return character+"";
                }
            }


        }
        return "";
    }

}