package com.monsanto.wst.ccas.util;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.wst.documentutil.constants.DocumentUtilConstants;
import com.monsanto.wst.documentutil.documentposutil.BaseSAXParser;
import com.monsanto.wst.documentutil.documentposutil.DocumentServiceClientUtil;
import com.monsanto.wst.documentutil.documentposutil.RetrieveAttachmentParser;
import com.monsanto.wst.documentutil.documentposutil.exception.DocumentClientServiceException;
import org.apache.xpath.XPathAPI;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Mar 18, 2009
 * Time: 3:58:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class McasDocumentServiceClientUtil extends DocumentServiceClientUtil {

    private String projectSpecificFolderMappingName;
    private UCCHelper helper;
    private SystemSecurityProxy systemSecurityProxy;

    public McasDocumentServiceClientUtil(UCCHelper helper, SystemSecurityProxy systemSecurityProxy, String projectSpecificFolderMappingName) throws DocumentClientServiceException {
        super(systemSecurityProxy, projectSpecificFolderMappingName);
            this.projectSpecificFolderMappingName = projectSpecificFolderMappingName;
            this.helper = helper;
            this.systemSecurityProxy = systemSecurityProxy;
    }

    public String insertDocument(String localFilePath, String mimeType, String documentName) throws DocumentClientServiceException, ParserException, IOException, SAXException, POSException, POSCommunicationException, GSSException, InvalidMimeTypeException, TransformerException {
        if (StringUtils.isNullOrEmpty(localFilePath)) {
            throw new DocumentClientServiceException("DocumentServiceClientUtil Exception: Local file path is null or empty");
        }
        Document insertResponse = insertIntoDocumentRepository(documentName, localFilePath, mimeType);
        return getObjectIdOfInsertedDocument(insertResponse);
    }

    private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
        String expression = DocumentUtilConstants.XPATH_STRING_GET_INSERTED_OBJECT_ID;
        Object objId = XPathAPI.eval(responseDoc, expression);
        return objId.toString();
    }

    /**
     * Method to Insert Document
     *
     * @param documentName
     * @param localFilePath
     * @param mimeType
     * @return
     * @throws ParserException
     * @throws IOException
     * @throws SAXException
     * @throws POSCommunicationException
     * @throws POSException
     * @throws InvalidMimeTypeException
     * @throws TransformerException
     */
    private Document insertIntoDocumentRepository(String documentName, String localFilePath, String mimeType) throws ParserException, IOException, SAXException, POSCommunicationException, POSException, InvalidMimeTypeException, TransformerException {
        Document insertRequest = transformRequestXML(DocumentUtilConstants.REQUEST_TEMPLATE_INSERT_SERVICE, documentName, DocumentUtilConstants.XPATH_STRING_INSERT_REQUEST, 0, projectSpecificFolderMappingName);
        DocumentumXMLPOSConnection posConn = new DocumentumXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), systemSecurityProxy, helper);
        addAttachmentToConnection(localFilePath, mimeType, posConn);
        DOMUtil.outputXML(insertRequest);
        POSResult result = posConn.callService(DocumentUtilConstants.POS_INSERT_SERVICE_NAME, insertRequest);
        return DOMUtil.newDocument(result.getInputStream());
    }

    private void addAttachmentToConnection(String localFilePath, String mimeType, DocumentumXMLPOSConnection posConn) throws InvalidMimeTypeException {
        MultiPartFormAttachment multipartFormAttachment = new MultiPartFormAttachment(localFilePath, mimeType);
        posConn.addAttachment(multipartFormAttachment);
    }

        /**
         * Method to Delete a document
         *
         * @param documentId
         * @return
         * @throws ParserException
         * @throws GSSException
         * @throws IOException
         * @throws TransformerException
         * @throws SAXException
         * @throws POSException
         * @throws POSCommunicationException
         * @throws DocumentClientServiceException
         */
        public boolean deleteDocument(String documentId) throws ParserException, GSSException, IOException, TransformerException, SAXException, POSException, POSCommunicationException, DocumentClientServiceException {
            if (StringUtils.isNullOrEmpty(documentId)) {
                throw new DocumentClientServiceException("DocumentServiceClientUtil Exception: DocumentId is null or empty");
            }
            return deleteAllVersionsOfInsertedDocument(documentId);
        }

    private boolean deleteAllVersionsOfInsertedDocument(String objectId) throws ParserException, POSCommunicationException, POSException, TransformerException, IOException, SAXException {
        Document deleteReq = transformRequestXML(DocumentUtilConstants.REQUEST_TEMPLATE_DELETE_SERVICE, objectId, DocumentUtilConstants.XPATH_STRING_DELETE_REQUEST, 0, projectSpecificFolderMappingName);
        DocumentumXMLPOSConnection posConn = new DocumentumXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), systemSecurityProxy, helper);
        posConn.callService(DocumentUtilConstants.POS_DELETE_SERVICE_NAME, deleteReq);
        return true;
    }

    public void retrieveDocument(String objectId, OutputStream outputStream) throws Exception {
        Document inputDocument = transformRequestXML(
                DocumentUtilConstants.REQUEST_TEMPLATE_RETRIEVE_SERVICE, objectId, DocumentUtilConstants.XPATH_STRING_RETRIEVE_REQUEST, 0, projectSpecificFolderMappingName);
        DocumentumXMLPOSConnection posConn = new DocumentumXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), systemSecurityProxy, helper);
        POSResult result = posConn.callService(DocumentUtilConstants.POS_RETRIEVE_SERVICE_NAME, inputDocument);
        RetrieveAttachmentParser parser = new BaseSAXParser();
        parser.parseContents(result.getInputStream(), outputStream);
    }
}
