package com.monsanto.wst.ccas.util;

import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSResult;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ajax.AJAXException;
import com.monsanto.ajax.AJAXPOSController;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;

import java.io.InputStream;
import java.io.OutputStream;
/*
 AJAXPOSController was created on May 22, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */
public class NonSecureAJAXPOSController extends AJAXPOSController {

    protected void runAJAXImplementation(UCCHelper helper, String posName, Document inputDocument) throws AJAXException {
        try {
            POSConnection pos = getPOSConnection(helper);
            POSResult posResult = pos.callService(posName, inputDocument);
            InputStream posStream = posResult.getInputStream();
            OutputStream output = helper.getBinaryStream();
            int data = posStream.read();
            while (data != -1) {
                output.write(data);
                data = posStream.read();
            }

            output.close();
            posStream.close();
        } catch (Exception e) {
            throw new AJAXException(e);
        }
    }

    protected POSConnection getPOSConnection(UCCHelper helper) throws GSSException {
        return new NonSecureXMLPOSConnection(helper);
    }
}