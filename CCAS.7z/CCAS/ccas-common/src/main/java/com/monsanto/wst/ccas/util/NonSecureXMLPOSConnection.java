package com.monsanto.wst.ccas.util;

import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import org.w3c.dom.Document;

import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Feb 23, 2009
 * Time: 10:08:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class NonSecureXMLPOSConnection extends XMLPOSConnection implements POSConnection {

    private UCCHelper helper = null;
    private static final int cacheDelaySeconds = 0;
    private final POSResultFactory posResultFactory;

    public NonSecureXMLPOSConnection(UCCHelper helper) {
        super();
        this.helper = helper;
        posResultFactory = new DefaultInputStreamPOSResultFactory();

    }

    public POSResult callService(String posName, Document document) throws POSException, POSCommunicationException {
        validatePOSRequestName(posName);
        validateDocumentNotNull(document);
        InputStream documentStream = getPOSEnvelopeStream(document, cacheDelaySeconds);
        String url = getURL(posName);
        InputStream inputStream = send(url, documentStream);
        return posResultFactory.createResult(inputStream);

    }

    public POSResult callService(String posName, Document document, String messageID) throws POSException, POSCommunicationException {
        return null;
    }

    protected String getURL(String posName) throws POSCommunicationException {
        String defaultURL = super.getURL(posName);
        String posAlias = defaultURL.substring(defaultURL.lastIndexOf("/"));
        return StringUtils.replace(helper.requestedURL(), "/ajaxController", posAlias);
    }

}
