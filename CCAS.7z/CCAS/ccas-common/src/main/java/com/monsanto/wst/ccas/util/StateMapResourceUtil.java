package com.monsanto.wst.ccas.util;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/8/14
 * Time: 10:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class StateMapResourceUtil {

    private static final String NOT_FOUND = null;

    /**
     * Region State Map has the following structure
     *      KEY = ABR-REGION_ID
     *      VALUE =  (State ID)
     *
     * @param regionStateMap
     * @param stateAbr
     * @param regionId
     * @return  null when key is not found, a string value all other cases
     */
    public static String getStateIdByStateNameAndRegionId(Map<String, String> regionStateMap, String stateAbr, String regionId) {
        if (validateRegionIdIsNotNullOrEmpty(regionId) && validateRegionStateMapIsNotNullOrEmpty(regionStateMap)) {
            return retrieveStateIdFromMap(regionStateMap, stateAbr, regionId);
        }
        return NOT_FOUND;
    }


    private static boolean validateRegionStateMapIsNotNullOrEmpty(Map<String, String> regionStateMap){
        if(regionStateMap==null || regionStateMap.isEmpty()){
            return false;
        }

        return true;
    }

    private static String retrieveStateIdFromMap(Map<String, String> stateMap, String stateAbr, String regionId) {
        String key = stateAbr + "-" + regionId;
        String stateId = stateMap.get(key);
        if (stateId == NOT_FOUND) {
            MCASLogUtil.logMessage("The region"+regionId+" does not has a valid state abbr ("+stateAbr+")");
        }
        return stateId;

    }

    private static boolean validateRegionIdIsNotNullOrEmpty(String regionId) {

        if (StringUtils.isNullOrEmpty(regionId)) {
            MCASLogUtil.logMessage("Region Id:"+regionId+" is invalid");
            return false;
        }
        return true;

    }


}
