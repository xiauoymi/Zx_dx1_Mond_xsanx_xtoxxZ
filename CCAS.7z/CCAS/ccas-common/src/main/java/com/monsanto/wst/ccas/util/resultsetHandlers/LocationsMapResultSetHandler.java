package com.monsanto.wst.ccas.util.resultsetHandlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/26/14
 * Time: 3:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationsMapResultSetHandler implements ResultMapHandler {

    public Map<String,String> getMap(ResultSet rs) throws SQLException {
        Map<String, String> locationMap = new HashMap<String, String>();

        if (rs != null) {
            while (rs.next()) {

                String locationId = rs.getString(1);
                String locationShortDescription = rs.getString(2);
                String regionId = rs.getString(3);
                String mapKey = locationShortDescription.trim()+"-"+regionId.trim();

                locationMap.put(mapKey, locationId.trim());
            }
        }


        return locationMap;
    }
}
