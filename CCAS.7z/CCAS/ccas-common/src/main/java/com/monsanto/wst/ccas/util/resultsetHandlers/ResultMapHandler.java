package com.monsanto.wst.ccas.util.resultsetHandlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/26/14
 * Time: 3:09 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ResultMapHandler {

    public Map<String,String> getMap(ResultSet rs) throws SQLException;
}
