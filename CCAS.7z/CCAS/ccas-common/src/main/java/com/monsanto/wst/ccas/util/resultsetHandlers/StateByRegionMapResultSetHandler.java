package com.monsanto.wst.ccas.util.resultsetHandlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: MANIET
 * Date: 5/26/14
 * Time: 3:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class StateByRegionMapResultSetHandler implements ResultMapHandler {

    public Map<String,String> getMap(ResultSet rs) throws SQLException {
        Map<String, String> statesMap = new HashMap<String, String>();

        if (rs != null) {
            while (rs.next()) {

                String stateAbbr = rs.getString(2);
                String regionId = rs.getString(3);
                String stateId = rs.getString(1);
                String key = stateAbbr.trim()+"-"+regionId.trim();
                statesMap.put(key,stateId.trim());

            }
        }


        return statesMap;
    }
}
