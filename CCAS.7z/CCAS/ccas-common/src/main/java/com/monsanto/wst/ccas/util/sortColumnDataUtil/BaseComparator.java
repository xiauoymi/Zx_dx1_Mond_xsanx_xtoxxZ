package com.monsanto.wst.ccas.util.sortColumnDataUtil;

import com.monsanto.Util.StringUtils;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 8:54:26 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class BaseComparator implements Comparator, Serializable {

    protected String sortOrder;
    private String aToken;
    private String bToken;

    protected void setaToken(String aToken) {
        this.aToken = aToken;
    }

    protected void setbToken(String bToken) {
        this.bToken = bToken;
    }

    protected int compareTokens() {
        if (sortOrder.equalsIgnoreCase("dec")) {
            if (aToken.compareToIgnoreCase(bToken) < 0) {
                return 1;
            }
            if (aToken.compareToIgnoreCase(bToken) > 0) {
                return -1;
            }
        } else {   //***Default: Ascending sort.
            if (aToken.compareToIgnoreCase(bToken) > 0) {
                return 1;
            }
            if (aToken.compareToIgnoreCase(bToken) < 0) {
                return -1;
            }
        }
        return 0;
    }

    protected int compareTokensIgnoringSpaces() {
        if (sortOrder.equalsIgnoreCase("dec")) {
            if (!StringUtils.isNullOrEmpty(bToken) && aToken.compareToIgnoreCase(bToken) < 0) {
                return 1;
            }
            if (!StringUtils.isNullOrEmpty(aToken) && aToken.compareToIgnoreCase(bToken) > 0) {
                return -1;
            }
        } else {   //***Default: Ascending sort.
            if (!StringUtils.isNullOrEmpty(bToken) && aToken.compareToIgnoreCase(bToken) > 0) {
                return 1;
            }
            if (!StringUtils.isNullOrEmpty(aToken) && aToken.compareToIgnoreCase(bToken) < 0) {
                return -1;
            }
        }
        return 0;
    }

    protected int compareAlphaNumericTokens() {
        try {
            return compareIntTokens(Integer.parseInt(aToken), Integer.parseInt(bToken));
        } catch (NumberFormatException e) {
            return compareTokens();
        }
    }

    private int compareIntTokens(int aTokenInt, int bTokenInt) {
        if (sortOrder.equalsIgnoreCase("dec")) {
            if (aTokenInt < bTokenInt) {
                return 1;
            }
            if (aTokenInt > bTokenInt) {
                return -1;
            }
        } else {
            if (aTokenInt > bTokenInt) {
                return 1;
            }
            if (aTokenInt < bTokenInt) {
                return -1;
            }
        }
        return 0;
    }

    abstract public int compare(Object o1, Object o2);

}
