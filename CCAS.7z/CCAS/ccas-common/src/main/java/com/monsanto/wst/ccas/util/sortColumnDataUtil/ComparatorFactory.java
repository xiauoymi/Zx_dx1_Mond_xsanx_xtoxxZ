package com.monsanto.wst.ccas.util.sortColumnDataUtil;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.controller.locationAdmin.comparators.LocationAdminPageLocationIdComparator;
import com.monsanto.wst.ccas.controller.locationAdmin.comparators.LocationAdminPageLocationNameComparator;
import com.monsanto.wst.ccas.controller.locationAdmin.comparators.LocationAdminPageLocationStatusComparator;
import com.monsanto.wst.ccas.controller.locationAdmin.comparators.LocationAdminPageRegionDescComparator;
import com.monsanto.wst.ccas.controller.userAdmin.comparators.UserAdminPageRegionDescComparator;
import com.monsanto.wst.ccas.controller.userAdmin.comparators.UserAdminPageRoleDescComparator;
import com.monsanto.wst.ccas.controller.userAdmin.comparators.UserAdminPageUserIdComparator;
import com.monsanto.wst.ccas.controller.userAdmin.comparators.UserAdminPageUserNameComparator;
import com.monsanto.wst.ccas.controller.varietyBatchController.comparator.VarietyBatchAdminPageBatchNumberComparator;
import com.monsanto.wst.ccas.controller.varietyBatchController.comparator.VarietyBatchAdminPageVarietyDescComparator;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.util.MCASLogUtil;

import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 8:54:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComparatorFactory {

    private static final Map<String, Class> compartorMap;

    static {
        compartorMap = new LinkedHashMap<String, Class>();
        compartorMap.put(MCASConstants.INDEX_USER_ADMIN_PG_USER_ID, UserAdminPageUserIdComparator.class);
        compartorMap.put(MCASConstants.INDEX_USER_ADMIN_PG_USER_NAME, UserAdminPageUserNameComparator.class);
        compartorMap.put(MCASConstants.INDEX_USER_ADMIN_PG_ROLE_DESC, UserAdminPageRoleDescComparator.class);
        compartorMap.put(MCASConstants.INDEX_USER_ADMIN_PG_REGION_DESC, UserAdminPageRegionDescComparator.class);
        compartorMap.put(MCASConstants.INDEX_LOCATION_ADMIN_PG_LOCATION_ID, LocationAdminPageLocationIdComparator.class);
        compartorMap.put(MCASConstants.INDEX_LOCATION_ADMIN_PG_LOCATION_NAME, LocationAdminPageLocationNameComparator.class);
        compartorMap.put(MCASConstants.INDEX_LOCATION_ADMIN_PG_REGION, LocationAdminPageRegionDescComparator.class);
        compartorMap.put(MCASConstants.INDEX_LOCATION_ADMIN_PG_STATUS, LocationAdminPageLocationStatusComparator.class);
        compartorMap.put(MCASConstants.INDEX_VARIETY_BATCH_ADMIN_PG_VARIETY_DESC, VarietyBatchAdminPageVarietyDescComparator.class);
        compartorMap.put(MCASConstants.INDEX_VARIETY_BATCH_ADMIN_PG_BATCH_NUMBER, VarietyBatchAdminPageBatchNumberComparator.class);
    }

    public static Object getComparator(String comparatorType, String sortOrder) throws MCASException {
        if (comparatorType == null) {
            throw new MCASException("Cannot retrieve Comparator implementation for null name.");
        }
        Object comparatorObj;
        Class comparatorClass = compartorMap.get(comparatorType);
        if (comparatorClass != null) {
            try {
                Class[] paramTypes = new Class[1];
                paramTypes[0] = String.class;
                Constructor constructorName = comparatorClass.getConstructor(paramTypes);
                String[] args = new String[1];
                args[0] = sortOrder;
                comparatorObj = constructorName.newInstance(args);
                Logger.log(new LoggableInfo("Found Comparator implementation '" + comparatorObj.getClass() + "' for class '" + comparatorType + "'"));
            } catch (Exception e) {
                MCASLogUtil.logError(e.getMessage(), e);
                throw new MCASException("Could not instantiate Comparator for name '" + comparatorType + "': ", e);
            }
        } else {
            throw new MCASException("Could not find implementation class for name '" + comparatorType + "', (not defined in ComparatorMap)");
        }
        return comparatorObj;
    }
}
