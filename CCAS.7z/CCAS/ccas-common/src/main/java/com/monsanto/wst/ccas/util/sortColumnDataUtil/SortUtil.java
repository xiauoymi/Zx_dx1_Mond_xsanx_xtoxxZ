package com.monsanto.wst.ccas.util.sortColumnDataUtil;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jul 12, 2006
 * Time: 10:04:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class SortUtil {

    public static String determineCurrentSortOrder(String index, String prevSortIndex, String prevSortOrder) {
        if (!StringUtils.isNullOrEmpty(index)) {
            if (!StringUtils.isNullOrEmpty(prevSortIndex) && !StringUtils.isNullOrEmpty(prevSortOrder)) {
                if (index.equalsIgnoreCase(prevSortIndex)) {
                    if (prevSortOrder.equalsIgnoreCase("asc")) {
                        return "dec";
                    } else {
                        return "asc";
                    }
                } else {
                    return "asc";
                }
            } else {
                return "asc";
            }
        }
        return "";
    }

    public static void populatePrevSortOrderAndIndex(UCCHelper helper, String index, String sortOrder) {
        helper.setSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_INDEX, index);
        helper.setSessionParameter(MCASConstants.HELPER_VAR_PREV_SORT_ORDER, sortOrder);
    }
}