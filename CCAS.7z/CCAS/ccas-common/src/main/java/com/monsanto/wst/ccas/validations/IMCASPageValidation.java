package com.monsanto.wst.ccas.validations;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 5, 2009
 * Time: 10:03:19 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IMCASPageValidation {
    List<String> validateAddAttachmentPage(UCCHelper helper) throws IOException;
}
