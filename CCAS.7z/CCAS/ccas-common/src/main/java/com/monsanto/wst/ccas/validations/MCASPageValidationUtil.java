package com.monsanto.wst.ccas.validations;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.LocationInfo;
import com.monsanto.wst.ccas.service.I18nServiceImpl;
import com.monsanto.wst.ccas.util.MCASUtil;
import com.monsanto.wst.documentutil.filetypeutil.AllowedAttachmentTypes;
import org.apache.log4j.Category;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jul 26, 2006 Time: 11:07:38 AM To change this template use File |
 * Settings | File Templates.
 */
public class MCASPageValidationUtil implements IMCASPageValidation {

   private static final Category logger = Category.getInstance(MCASPageValidationUtil.class.getName());
    public static final int MAX_FILE_SIZE = 55;


    public void validateHelperParam(String paramName, String paramValue) throws MCASException {
    if (StringUtils.isNullOrEmpty(paramValue)) {
      throw new MCASException(paramName + " is found null or empty");
    }
  }

  public List<String> validateUserDetailsForAdd(String userId, String roleId, String[] businessIds,
                                                String userBusinessPreference, String[] selectedRegions,
                                                String locale) {
    List<String> errorMessages = new ArrayList<String>();
    validateParam(userId, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectUser"));
    validateParam(roleId, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectRole"));
    validateMultipleSelections(businessIds, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectBusiness"));
    validateParam(userBusinessPreference, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectBusinessPreference"));
    //Validation to be done for Multiple Regions selected
    validateMultipleSelections(selectedRegions, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectRegion"));
    return errorMessages;
  }

  private void validateMultipleSelections(String[] values, List<String> errorMessages, String msg) {
    boolean hasError = false;
    if (values != null) {
      for (String param : values) {
        if (StringUtils.isNullOrEmpty(param)) {
          hasError = true;
          break;
        }
      }
    }

    if ((values == null || values.length == 0) || hasError) {
      errorMessages.add(msg);
    }
  }

  public List<String> validateUserDetailsForEdit(String roleId, String[] regionIds, String[] businessId,
                                                 String userBusinessPreference, String locale) {
    List<String> errorMessages = new ArrayList<String>();
    validateParam(roleId, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectRole"));
    validateMultipleSelections(businessId, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectBusiness"));
    validateParam(userBusinessPreference, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectBusinessPreference"));
    validateMultipleSelections(regionIds, errorMessages,
        I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectRegion"));
    return errorMessages;
  }

  public List<String> validateAddAttachmentPage(UCCHelper helper) throws IOException {

    String locale = MCASUtil.getUserLocale(helper);
    List<String> errorMessages = new ArrayList<String>();
    ArrayList clientFiles = helper.getClientFiles();
    String uploadedFilePath = null;
    if (clientFiles.size() > 0) {
      uploadedFilePath = (String) clientFiles.get(0);
    }
    if (StringUtils.isNullOrEmpty(uploadedFilePath)) {
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectAttachment"));
      return errorMessages;
    }

    File file = new File(uploadedFilePath);

    //if (!new File(uploadedFilePath).exists()) {
    if (!file.exists()) {
      logger.info("File Creating under absolute path: " + file.getAbsolutePath() + " name: " + file.getName() + " path: " + file.getPath());
      System.out.println("File Creating under absolute path: " + file.getAbsolutePath() + " name: " + file.getName() + " path: " + file.getPath());
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.attachmentNotFound"));
      return errorMessages;
    }
    String localFileExtension = MCASUtil.getFileExtension(uploadedFilePath);
    AllowedAttachmentTypes allowedAttachmentTypes = (AllowedAttachmentTypes) helper
        .getContextAttribute(MCASConstants.HELPER_VAR_ALLOWED_ATTACHMENT_TYPES);
    if (!allowedAttachmentTypes.isAllowedExtension(localFileExtension)) {
      errorMessages.add(" " + localFileExtension.toUpperCase() + " " +
          I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.invalidAttachmentType"));
      return errorMessages;
    }

    //We need to validate if the file cointains special characters.
    //String fileName = MCASUtil.getFileName(uploadedFilePath);
    String fileName = file.getName();
    logger.info("File Name after creation: " + fileName);
    System.out.println("File Name after creation.: " + fileName);
      String validResult=MCASUtil.validateNoSpecialChars(fileName);
      if(fileName.length()> MAX_FILE_SIZE){
          errorMessages.add("File name is longer than 55");
      }
      else if (validResult.equalsIgnoreCase("f")) {
        errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.attachmentNotValidFileName"));
      }
      else if(!validResult.equalsIgnoreCase("")){
         errorMessages.add("File name has special character <"+validResult+">");
      }
      return errorMessages;



  }

  private void validateParam(String param, List<String> errorMessages, String msg) {
    if (StringUtils.isNullOrEmpty(param)) {
      errorMessages.add(msg);
    }
  }

  public List<String> validateLocationInfo(LocationInfo locationInfo, String locale, String appName) {
    List<String> errorMessages = new ArrayList<String>();
    //Required fields
    if (locationInfo == null || locationInfo.getRegionId() == -1) {
        if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_BIOTECHFAS)){
           errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectfunctionalArea"));
        }
        else{
            errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectRegion"));
            }
    }
    if (locationInfo == null || StringUtils.isNullOrEmpty(locationInfo.getLocationId())) {
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectLocationCode"));
    }
    if (locationInfo == null || StringUtils.isNullOrEmpty(locationInfo.getLocationName())) {
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.selectLocationName"));
    }
    //Optional fields
    if (locationInfo != null && !validateEmailAsAnOptionalField(locationInfo.getLocationEmail())) {
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.enterEmail"));
    }
    if (locationInfo != null && !validateEmailAsAnOptionalField(locationInfo.getLocationOwnerEmail())) {
      errorMessages.add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.enterLocationEmail"));
    }
    if (locationInfo != null && StringUtils.isNullOrEmpty(locationInfo.getLocationOwnerEmail()) &&
        locationInfo.isOwnerEmailStatusActive()) {
      errorMessages
          .add(I18nServiceImpl.lookupProperty(locale, "com.monsanto.wst.ccas.error.activeLocationEmptyEmailY"));
    }
    return errorMessages;
  }

  private boolean validateEmailAsAnOptionalField(String emailAddr) {
    if (StringUtils.isNullOrEmpty(emailAddr)) {
      return true;
    }
    return isValidEmail(emailAddr);
  }

  /**
   * Simple email validation...please extend this as needed !!
   *
   * @param emailAddr
   *
   * @return boolean
   */
  public boolean isValidEmail(String emailAddr) {
    if (emailAddr.startsWith(".") || emailAddr.startsWith("@") || emailAddr.startsWith("www.")
        || emailAddr.endsWith(".") || emailAddr.endsWith("@")) {    //Cannot start/end with @ or . or www.
      return false;
    }
    if (emailAddr.split("@").length > 2) {
      return false;
    }
    return emailAddr.matches(MCASConstants.REGEX_SIMPLE_EMAIL_VALIDATION);
  }
}