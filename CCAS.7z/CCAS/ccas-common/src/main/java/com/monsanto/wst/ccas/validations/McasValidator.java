/*
 * Created on Apr 29, 2005
 *
 *
 */
package com.monsanto.wst.ccas.validations;

import com.ctc.wstx.util.StringUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.ccas.actionForms.ComplaintForm;
import com.monsanto.wst.ccas.actionForms.CparForm;
import com.monsanto.wst.ccas.actionForms.StopSaleForm;
import com.monsanto.wst.ccas.actionForms.UploadFileForm;
import com.monsanto.wst.ccas.actions.SessionHelper;
import com.monsanto.wst.ccas.audits.CheckboxGroup;
import com.monsanto.wst.ccas.audits.CheckboxItem;
import com.monsanto.wst.ccas.audits.CheckboxRow;
import com.monsanto.wst.ccas.complaints.BusinessService;
import com.monsanto.wst.ccas.complaints.BusinessServiceImpl;
import com.monsanto.wst.ccas.constants.MCASConstants;
import com.monsanto.wst.ccas.constants.ComplaintConstants;
import com.monsanto.wst.ccas.dao.DAOException;
import com.monsanto.wst.ccas.dao.DAOFactory;
import com.monsanto.wst.ccas.dao.UserAdminDAO;
import com.monsanto.wst.ccas.exception.MCASException;
import com.monsanto.wst.ccas.model.*;
import com.monsanto.wst.ccas.service.CheckboxItemServiceImpl;
import com.monsanto.wst.ccas.service.CparService;
import com.monsanto.wst.ccas.service.CparServiceImpl;
import com.monsanto.wst.ccas.util.MCASLogUtil;
import com.monsanto.wst.ccas.util.MCASUtil;
import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.Resources;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author rdesai2 <p/> <p/> Window - Preferences - Java - Code Style - Code Templates
 */

public class McasValidator {

    private static CparServiceImpl cparServiceImpl;

    public static boolean validateDate(Object bean,
                                       ValidatorAction action,
                                       Field field,
                                       ActionMessages errors,
                                       HttpServletRequest request) {
        //**Reqd...Step1...get the date-str
        String dateStr = ValidatorUtils.getValueAsString(bean, field.getProperty());

        //**We are not checking for required...
        if (dateStr == null || dateStr.length() == 0) {
            return true;
        }
        StringTokenizer st = new StringTokenizer(dateStr, "/");
        boolean dateErr = isInvalidDate(st);

        if (dateErr) {
            errors.add(field.getKey(), Resources.getActionError(request, action, field));
            return false;
        }
        return true;
    }

    public static boolean validateSelectOneRequired(Object bean,
                                                    ValidatorAction action,
                                                    Field field,
                                                    ActionMessages errors,
                                                    HttpServletRequest request) {
        String valueAsString = ValidatorUtils.getValueAsString(bean, field.getProperty());

        if (StringUtils.isNullOrEmpty(valueAsString) || "0".equalsIgnoreCase(valueAsString)) {
            errors.add(field.getKey(), Resources.getActionError(request, action, field));
            return false;
        } else {
            return true;
        }
    }

    /**
     * 04/29/2008 Method to obtain the Business Preference Id
     *
     * @param request
     * @return
     * @throws Exception
     */
    private int getUserBusiness(HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute(User.USER);
        BusinessService service = new BusinessServiceImpl();
        return service.getBusinessId(user);
    }

    /**
     * 04/25/2008 Method used to Validate  State Drop Down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateCrop(Object bean,
                             ValidatorAction action,
                             Field field,
                             ActionMessages errors,
                             HttpServletRequest request) {

        try {

            //Perform validation only if the business Preference = Vegetable
            int userBusinessId = getUserBusiness(request);

            //Ad-Hoc way of doing it.TODO use other strategy
            String paramName = "";
            if (bean instanceof ComplaintForm||bean instanceof UploadFileForm) {
                paramName = "c.crop_id";
            } else {
                paramName = "stopSale.cropID";
            }

            String appName = (String) request.getSession().getAttribute(MCASConstants.APPLICATION_NAME);
            if(appName.equalsIgnoreCase(MCASConstants.APPLICATION_NAME_MCAS)&&userBusinessId == MCASConstants.BUSINESS_ID_ROW_CROP){
                validateForMissingFields(bean, action, field, errors, request);
            }

            if (userBusinessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
                validateForMissingFields(bean, action, field, errors, request);
            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    public void validateCpar(Object bean,
                             ValidatorAction action,
                             Field field,
                             ActionMessages errors,
                             HttpServletRequest request) {

        try {
            int userBusinessId = getUserBusiness(request);

            if (bean instanceof ComplaintForm) {
                ComplaintForm complaintForm = (ComplaintForm) bean;
                if (!StringUtils.isNullOrEmpty(complaintForm.getC().getCpar_id())) {
                    CparService service = new CparServiceImpl();
                    Cpar c = service.getCparByControlNo(complaintForm.getC().getCpar_id(), userBusinessId);

                    if (c == null) {
                        errors.add("com.monsanto.wst.ccas.complaint.invalidCparId", new ActionMessage("com.monsanto.wst.ccas.complaint.invalidCparId"));
                    }
                }

            }

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }


    /**
     * 04/25/2008 Method used to Validate  State Drop Down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateState(Object bean,
                              ValidatorAction action,
                              Field field,
                              ActionMessages errors,
                              HttpServletRequest request) {

        try {

            //Perform validation only if the business Preference = Row Crop
            int userBusinessId = getUserBusiness(request);

            //Ad-Hoc way of doing it.TODO use other strategy
            String paramName = "";
            if (bean instanceof ComplaintForm) {
                paramName = ComplaintConstants.COMPLAINT_FORM_ENTRY_REGION;
            } else {
                paramName = "stopSale.region";
            }
            if (userBusinessId == MCASConstants.BUSINESS_ID_ROW_CROP) {
                validateForMissingFields(bean, action, field, errors, request);
            }
            HttpSession session = request.getSession();
            SessionHelper sessionHelper = new SessionHelper();
            //Obtain the Selected value of Region
            String regionSelected = request.getParameter(paramName);
            //If there are drop downs populated, clear them first.
            setRequestAttribute(regionSelected, request);
            clearSalesOfficeAndStateListDropDowns(session, sessionHelper);
            populateStateAndSalesOfficeDropdowns(request, sessionHelper, regionSelected);

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }


    private void populateSubFunctionAndLocations(HttpServletRequest request, SessionHelper sessionHelper,
                                                 String programSelected) {
        if (programSelected != null && !"".equals(programSelected)) {
            sessionHelper.setProgramRelatedSubFunctionsAndLocations(request.getSession(), programSelected);
        }
    }

    /**
     * 04/25/2008 Method used to Validate  Sales Office Drop Down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateSalesOffice(Object bean,
                                    ValidatorAction action,
                                    Field field,
                                    ActionMessages errors,
                                    HttpServletRequest request) {

        try {

            //Perform validation only if the business Preference = vegetable
            int userBusinessId = getUserBusiness(request);

            //Ad-Hoc way of doing it.TODO use other strategy
            String paramName = "";
            if (bean instanceof ComplaintForm) {
                paramName = ComplaintConstants.COMPLAINT_FORM_ENTRY_REGION;
            } else {
                paramName = "stopSale.region";
            }
            if (userBusinessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
                validateForMissingFields(bean, action, field, errors, request);
            }
            HttpSession session = request.getSession();
            SessionHelper sessionHelper = new SessionHelper();
            //Obtain the Selected value of Region
            String regionSelected = request.getParameter(paramName);
            setRequestAttribute(regionSelected, request);
            //If there are drop downs populated, clear them first.
            clearSalesOfficeAndStateListDropDowns(session, sessionHelper);
            populateStateAndSalesOfficeDropdowns(request, sessionHelper, regionSelected);
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    private void setRequestAttribute(String regionSelected, HttpServletRequest request) {
        if (!StringUtils.isNullOrEmpty(regionSelected)) {
            request.setAttribute("regionId", regionSelected);
        }
    }

    /**
     * 04/25/2008 Method used to validate  material Group Drop down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateMaterialGroup(Object bean,
                                      ValidatorAction action,
                                      Field field,
                                      ActionMessages errors,
                                      HttpServletRequest request) {

        try {
            int userBusinessId = getUserBusiness(request);

            //Ad-Hoc way of doing it.TODO use other strategy
            String paramName = "";
            if (bean instanceof ComplaintForm) {
                paramName = "c.crop_id";
            } else {
                paramName = "stopSale.cropID";
            }
            if (userBusinessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
                validateForMissingFields(bean, action, field, errors, request);
            }
            HttpSession session = request.getSession();
            SessionHelper sessionHelper = new SessionHelper();
            //Obtain the Selected value of Crop
            String cropSelected = request.getParameter(paramName);
            //If there are drop downs populated, clear them first.
            clearMaterialGroupDropDown(session, sessionHelper);
            populateMaterialGroupDorpDown(session, sessionHelper, cropSelected);

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    /**
     * 04/25/2008 Method used to Validate  material group pricing drop down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateMaterialGroupPricing(Object bean,
                                             ValidatorAction action,
                                             Field field,
                                             ActionMessages errors,
                                             HttpServletRequest request) {

        try {
            int userBusinessId = getUserBusiness(request);

            //Ad-Hoc way of doing it.TODO use other strategy
            String paramName = "";
            if (bean instanceof ComplaintForm) {
                paramName = "c.materialGroupCode";
            } else {
                paramName = "stopSale.materialGroupCode";
            }
            if (userBusinessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
                validateForMissingFields(bean, action, field, errors, request);
            }
            HttpSession session = request.getSession();
            SessionHelper sessionHelper = new SessionHelper();
            //Obtain the Selected value of Material Group
            String materialGroupSelected = request.getParameter(paramName);
            //If there are drop downs populated, clear them first.
            clearMaterialGroupPricingDropDown(session, sessionHelper);
            //Reload all the Drop downs
            populateMaterialGroupPricingDropDown(session, sessionHelper, materialGroupSelected);

        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }

    }

    /**
     * 096/10/2008 Method used to validate the Initial Assesment Drop down
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateInitialAssesment(Object bean,
                                         ValidatorAction action,
                                         Field field,
                                         ActionMessages errors,
                                         HttpServletRequest request) {

        try {
            int userBusinessId = getUserBusiness(request);
            if (userBusinessId == MCASConstants.BUSINESS_ID_VEGETABLE) {
                validateForMissingFields(bean, action, field, errors, request);
            }
        } catch (Exception e) {
            MCASLogUtil.logError(e.getMessage(), e);
        }
    }

    /**
     * Custom Method to validate the Settlement value<Must not be more than 9 digits without decimal point>
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     */
    public void validateSettlementValue(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        validateForSettlementValue(bean, action, field, errors, request);
    }

    private void validateForSettlementValue(Object bean, ValidatorAction action, Field field, ActionMessages errors,
                                            HttpServletRequest request) {
        String fieldName = field.getProperty();
        String fieldValue = ValidatorUtils.getValueAsString(bean, field.getProperty());
        if (!StringUtils.isNullOrEmpty(fieldValue)) {
            if (validateSettlementValueWithoutPeriod(fieldValue) || validateSettlementValueWithPeriod(fieldValue)) {
                errors.add(fieldName, Resources.getActionMessage(request, action, field));
            }
        }
    }

    private boolean validateSettlementValueWithPeriod(String fieldValue) {
        return fieldValue.indexOf(".") >= 9;
    }

    private boolean validateSettlementValueWithoutPeriod(String fieldValue) {
        return fieldValue.indexOf(".") == -1 && fieldValue.length() > 8;
    }

    /**
     * 04/25/2008 Method used to populate material group pricing drop down
     *
     * @param session
     * @param sessionHelper
     * @param materialGroupSelected
     * @throws Exception
     */
    private void populateMaterialGroupPricingDropDown(HttpSession session, SessionHelper sessionHelper,
                                                      String materialGroupSelected) throws Exception {
        if (materialGroupSelected != null && !"".equals(materialGroupSelected)) {
            sessionHelper.setMaterialGroupRelatedMaterialGroupPricing(session, Integer.parseInt(materialGroupSelected));
        }
    }

    /**
     * 04/25/2008 Method used to clear the material group pricing drop down
     *
     * @param session
     */
    private void clearMaterialGroupPricingDropDown(HttpSession session, SessionHelper helper) {
        helper.setDefaultMaterrialGroupPricings(session);
    }

    /**
     * 04/25/2008 Method used to populate material group  drop down
     *
     * @param session
     * @param sessionHelper
     * @param cropSelected
     * @throws Exception
     */
    private void populateMaterialGroupDorpDown(HttpSession session, SessionHelper sessionHelper,
                                               String cropSelected) throws Exception {
        if (cropSelected != null && !"".equals(cropSelected)) {
            sessionHelper.setCropRelatedMaterialGroup(session, cropSelected);
        }
    }

    /**
     * 04/25/2008 Method used to clear the material group drop down
     *
     * @param session
     */
    private void clearMaterialGroupDropDown(HttpSession session, SessionHelper helper) {
        helper.setDefaultMaterialGroups(session);
    }

    /**
     * 04/25/2008 Method used to populate state and sales office drop downs
     *
     * @param sessionHelper
     * @param regionSelected
     * @throws Exception
     */
    private void populateStateAndSalesOfficeDropdowns(HttpServletRequest request, SessionHelper sessionHelper,
                                                      String regionSelected) throws Exception {

        HttpSession session = request.getSession();
        String locale = ((User) session.getAttribute(User.USER)).getLocale();

//    if (regionSelected != null && !"".equals(regionSelected)) {
        sessionHelper.setRegionRelatedStates(request.getSession(), regionSelected);
        sessionHelper.setSalesOffice(request.getSession(), regionSelected, locale);
        sessionHelper.setAppSpecificReferenceData(request, false);
//    }
    }

    /**
     * 04/25/2008 Method used to clear sales office and states drop downs
     *
     * @param session
     */
    private void clearSalesOfficeAndStateListDropDowns(HttpSession session, SessionHelper helper) {
        helper.setDefaultStates(session);
        helper.setDefaultSalesOffices(session);
        helper.setDefaultLocations(session);
    }

    /**
     * 04/25/2008 Method for validating the sales office,material group and material group pricing
     *
     * @param field
     * @param error
     */
    private void validateForMissingFields(Object bean, ValidatorAction action, Field field, ActionMessages error,
                                          HttpServletRequest request) {
        String fieldName = field.getProperty();
        String fieldValue = ValidatorUtils.getValueAsString(bean, field.getProperty());
        if (fieldValue == null || fieldValue.equals("") || "0".equals(fieldValue)) {
            error.add(fieldName, Resources.getActionMessage(request, action, field));
        }
    }

    public void validateSubFunction(Object bean,
                                    ValidatorAction action,
                                    Field field,
                                    ActionMessages errors,
                                    HttpServletRequest request) {

        String paramName = field.getProperty();
        String programSelected = request.getParameter(paramName);

        if (programSelected == null) {
            errors.add(paramName, Resources.getActionMessage(request, action, field));
        }

//    try {
//
//      //Ad-Hoc way of doing it.TODO use other strategy
////      String paramName = "";
////      if (bean instanceof ComplaintForm) {
////        paramName = "c.subFunction_id";
////      } else {
////        paramName = "stopSale.subFunction_id";
////      }
////
////      HttpSession session = request.getSession();
////      SessionHelper sessionHelper = new SessionHelper();
////      //Obtain the Selected value of Region
////      String programSelected = request.getParameter(paramName);
////      //If there are drop downs populated, clear them first.
////      setRequestAttribute(programSelected,request);
////      populateSubFunctionAndLocationDropDowns(request, sessionHelper, programSelected);
////
////    } catch (Exception e) {
////      e.printStackTrace();
////    }

    }

    public void validateAudit(AuditObject auditObj, HttpServletRequest request, ActionMessages errors) {
        String appName = (String) request.getSession().getAttribute(MCASConstants.APPLICATION_NAME);
        if (StringUtils.isNullOrEmpty(auditObj.getLocationCode())) {
            errors.add("locationCodeEmpty", new ActionMessage("errors.mcas.audit.locationCode.empty"));
        }

        if (StringUtils.isNullOrEmpty(auditObj.getAuditDate())) {
            errors.add("auditDateEmpty", new ActionMessage("errors.mcas.audit.auditDate.empty"));
        } else {
            StringTokenizer st = new StringTokenizer(auditObj.getAuditDate(), "/");
            boolean dateErr = isInvalidDate(st);
            if (dateErr) {
                errors.add("auditDateFormat", new ActionMessage("errors.mcas.audit.auditDate.format"));
            }
        }
        if (StringUtils.isNullOrEmpty(auditObj.getRegion_id())) {
            errors.add("regionIDEmpty", new ActionMessage("errors.mcas.audit.regionID.empty"));
        }
        if (StringUtils.isNullOrEmpty(auditObj.getAuditor())) {
            errors.add("auditorEmpty", new ActionMessage("errors.mcas.audit.auditor.empty"));
        }
        if((auditObj.getBusinessId() == 2) && (appName.equalsIgnoreCase("sbfas"))){
            if (StringUtils.isNullOrEmpty(auditObj.getFunctionId())) {
                errors.add("functionIdEmpty", new ActionMessage("errors.mcas.audit.functionId.empty"));
            }
        }
//    if(auditObj.getAuditOverview() != null && auditObj.getAuditOverview().length() > 4000){
//      errors.add("auditOverviewTooLarge", new ActionMessage("errors.mcas.audit.auditOverview.tooLarge"));
//    }
        if (StringUtils.isNullOrEmpty(auditObj.getPreparedBy())) {
            errors.add("preparedByEmpty", new ActionMessage("errors.mcas.audit.preparedBy.empty"));
        }
        if (StringUtils.isNullOrEmpty(auditObj.getPreparedDate())) {
            errors.add("preparedDateEmpty", new ActionMessage("errors.mcas.audit.preparedDate.empty"));
        }
        if (StringUtils.isNullOrEmpty(auditObj.getAuditType())) {
            errors.add("auditTypeEmpty", new ActionMessage("errors.mcas.audit.auditType.empty"));
        } else {
            StringTokenizer st = new StringTokenizer(auditObj.getPreparedDate(), "/");
            boolean dateErr = isInvalidDate(st);
            if (dateErr) {
                errors.add("auditPreparedDateFormat", new ActionMessage("errors.mcas.audit.preparedDate.format"));
            }
        }
        boolean functionalAreaChecked=checkBoxGoupChecked(auditObj.getFunctionalAreaList());
        User user = (User) request.getSession().getAttribute(User.USER);
        
        if(!functionalAreaChecked&&user.getBusinessId()==MCASConstants.BUSINESS_ID_VEGETABLE&&appName.equalsIgnoreCase("mcas")){
            errors.add("functionalAreaList", new ActionMessage("errors.mcas.audit.departmentFunctional.required"));
        }

        if((user.getBusinessId()==MCASConstants.BUSINESS_ID_VEGETABLE)&&(request.getSession().getAttribute(MCASConstants.APPLICATION_NAME).toString().equalsIgnoreCase(MCASConstants.APPLICATION_NAME_MCAS))){
                validateUserISystem(auditObj.getAuditor(),auditObj.getAuditorId(),"auditorId","errors.mcas.audit.auditorId.UserNotValid",errors);
                validateUserISystem(auditObj.getSiteISOContact(),auditObj.getSiteISOContactId(),"siteISOContactId","errors.mcas.audit.auditorId.IsoContactNotValid",errors);
            validateUserISystem(auditObj.getPreparedBy(),auditObj.getPreparedById(),"preparedById","errors.mcas.audit.auditorId.PreparedByNotValid",errors);


        }

    }

    public static boolean validateUsersInSystem(Object bean,
                                                              ValidatorAction action,
                                                              Field field,
                                                              ActionMessages errors,
                                                              HttpServletRequest request){

        /* User user = (User) request.getSession().getAttribute(User.USER);

        if((user.getBusinessId()==MCASConstants.BUSINESS_ID_VEGETABLE)&&(request.getSession().getAttribute(MCASConstants.APPLICATION_NAME).toString().equalsIgnoreCase(MCASConstants.APPLICATION_NAME_MCAS))){
        if (bean instanceof StopSaleForm) {
            StopSaleObject stopObj=((StopSaleForm)bean).getStopSale();
               if(field.getKey().equalsIgnoreCase("stopSale.initiatedById")){
                   return validateUserISystem(stopObj.getInitiatedBy(),stopObj.getInitiatedById(),"initiatedById","com.monsanto.wst.ccas.complaint.initiatedByNotUser",errors);
               }
            if(field.getKey().equalsIgnoreCase("stopSale.fieldCommunicatorId")){
                   return validateUserISystem(stopObj.getFieldCommunicator(),stopObj.getFieldCommunicatorId(),"fieldCommunicatorId","com.monsanto.wst.ccas.complaint.fieldcomunicatorNotUser",errors);
               }
            if(field.getKey().equalsIgnoreCase("stopSale.investigatorId")){
                   return validateUserISystem(stopObj.getInvestigator(),stopObj.getInvestigatorId(),"investigatorId","com.monsanto.wst.ccas.complaint.investigatorNotUser",errors);
               }
            }
            else if(bean instanceof ComplaintForm){
                Complaint com=((ComplaintForm)bean).getC();
                if(field.getKey().equalsIgnoreCase("c.report_initiator_id")){
                   return validateUserISystem(com.getReport_initiator(),com.getReport_initiator_id(),"initiatedById","com.monsanto.wst.ccas.complaint.initiatedByNotUser",errors);
               }
                if(field.getKey().equalsIgnoreCase("c.field_communicator_id")){
                   return validateUserISystem(com.getField_communicator(),com.getField_communicator_id(),"fieldCommunicatorId","com.monsanto.wst.ccas.complaint.fieldcomunicatorNotUser",errors);
               }
                if(field.getKey().equalsIgnoreCase("c.person_investigating_id")){
                   return validateUserISystem(com.getPerson_investigating(),com.getPerson_investigating_id(),"investigatorId","com.monsanto.wst.ccas.complaint.investigatorNotUser",errors);
               }

        }
            else if(bean instanceof CparForm){
                Cpar cpar=((CparForm)bean).getCpar();
                if(field.getKey().equalsIgnoreCase("cpar.mgmt_approval_person_id")){
                    return validateUserISystem(cpar.getMgmt_approval_person(),cpar.getMgmt_approval_person_id(),"mgmt_approval_person_id","com.monsanto.wst.ccas.cpar.error.mgmt_approval_person_id",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.containment_actions_person_id")){
                    return validateUserISystem(cpar.getContainment_actions_person(),cpar.getContainment_actions_person_id(),"containment_actions_person_id","com.monsanto.wst.ccas.cpar.error.containment_actions_person_id",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.root_cause_person_id")){
                    return validateUserISystem(cpar.getRoot_cause_person(),cpar.getRoot_cause_person_id(),"root_cause_person_id","com.monsanto.wst.ccas.cpar.error.root_cause_person_id",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.long_term_corrective_action_person_id")){
                    return validateUserISystem(cpar.getLong_term_corrective_action_person(),cpar.getLong_term_corrective_action_person_id(),"long_term_corrective_action_person_id","com.monsanto.wst.ccas.cpar.error.long_term_corrective_action_person_id",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.evaluation_person_id")){
                    return validateUserISystem(cpar.getEvaluation_person(),cpar.getEvaluation_person_id(),"evaluation_person_id","com.monsanto.wst.ccas.cpar.error.evaluation_person_id",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.initiatedByUserId")){
                    return validateUserISystem(cpar.getInitiated_by(),cpar.getInitiatedByUserId(),"initiatedByUserId","com.monsanto.wst.ccas.cpar.error.initiatedByUserId",errors);
                    }
                if(field.getKey().equalsIgnoreCase("cpar.siteManagerUserId")){
                    return validateUserISystem(cpar.getSite_manager(),cpar.getSiteManagerUserMId(),"siteManagerUserId","com.monsanto.wst.ccas.cpar.error.siteManagerUserId",errors);
                    }
            if(field.getKey().equalsIgnoreCase("cpar.report_initiator_id")){
                    return validateUserISystem(cpar.getInitiated_by(),cpar.getReport_initiator_id(),"report_initiator_id","com.monsanto.wst.ccas.cpar.error.initiatedByUserId",errors);
                    }
        }
        }*/
        return true;

    }


    private static boolean validateUserISystem(String nameField,String userId,String field,String messageKey, ActionMessages errors){
        /*
        if(StringUtils.isNullOrEmpty(nameField)){
            return true;
        }
        try{
            UserAdminDAO userAdminDAO = (UserAdminDAO) DAOFactory.getDao(UserAdminDAO.class);
            if(!StringUtils.isNullOrEmpty(userId)){
                if(!userAdminDAO.validateUserPresentinSystem(userId)){
                      errors.add(field,new ActionMessage(messageKey));
                    return false;
                }
            }
            else{
                String []tokens=nameField.split(",");
                String first=tokens[1].split(" ")[0];
                if(StringUtils.isNullOrEmpty(first)){
                    first=tokens[1];
                }
                String last=tokens[0].split(" ")[0];
                //OROZCO, ALDO
                if(!userAdminDAO.validateUserPresentinSystemByName(last+","+first)){
                      errors.add(field,new ActionMessage(messageKey));
                    return false;
                }
            }
            } catch (DAOException e) {
                errors.add(field,new ActionMessage(messageKey));
            return false;

            } catch (MCASException e) {
                errors.add(field,new ActionMessage(messageKey));
            return false;
            }*/
        return true;

    }

    private static boolean isInvalidDate(StringTokenizer st) {
        boolean dateErr = false;
        if (st.countTokens() != 3) {
            dateErr = true;
        } else {
            dateErr = MCASUtil.validateDate(st, dateErr);
        }
        return dateErr;
    }


    /**
     * Only use this method in CPAR objects.
     *
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     * @return
     */
    public static boolean validateDateGreaterToday(Object bean,
                                                   ValidatorAction action,
                                                   Field field,
                                                   ActionMessages errors,
                                                   HttpServletRequest request) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");


        //**Reqd...Step1...get the date-str
        String dateStr = ValidatorUtils.getValueAsString(bean, field.getProperty());

        //**We are not checking for required...
        if (dateStr == null || dateStr.length() == 0) {
            return true;
        }
        StringTokenizer st = new StringTokenizer(dateStr, "/");
        boolean dateErr = isInvalidDate(st);

        if (dateErr) {
            errors.add(field.getKey(), Resources.getActionError(request, action, field));
            return false;
        }

        java.util.Date userDate = new java.util.Date(dateStr);
        java.util.Date entryDate;

        String fieldName = field.getProperty();

        if (bean != null) {
            CparForm cparForm = (CparForm) bean;
            Cpar cpar = cparForm.getCpar();
            String rowEntry = cpar.getRow_entry_date();

            boolean cparEdit = false;
            cparEdit = request.getSession().getAttribute("cparEdit").equals("true");


            if (cparEdit) {
                if (cparServiceImpl == null)
                    cparServiceImpl = new CparServiceImpl();

                Cpar cParDatabase = cparServiceImpl.getCpar(cpar.getCpar_id(), false);

                if (fieldName.equals("cpar.containment_actions_date") && !StringUtils.isNullOrEmpty(cpar.getContainment_actions_date()) && cParDatabase.getContainment_actions_date().equals(cpar.getContainment_actions_date()))
                    return true;
                if (fieldName.equals("cpar.root_cause_date") && !StringUtils.isNullOrEmpty(cpar.getRoot_cause_date()) && cParDatabase.getRoot_cause_date().equals(cpar.getRoot_cause_date()))
                    return true;
                if (fieldName.equals("cpar.long_term_corrective_action_date") && !StringUtils.isNullOrEmpty(cpar.getLong_term_corrective_action_date()) && cParDatabase.getLong_term_corrective_action_date().equals(cpar.getLong_term_corrective_action_date()))
                    return true;
                if (fieldName.equals("cpar.evaluation_date") && !StringUtils.isNullOrEmpty(cpar.getEvaluation_date()) && cParDatabase.getEvaluation_date().equals(cpar.getEvaluation_date()))
                    return true;
            }

            try {
                entryDate = sdf.parse(rowEntry);
            } catch (ParseException e) {
                errors.add(fieldName, Resources.getActionMessage(request, action, field));
                return false;
            }
        } else {
            errors.add(fieldName, Resources.getActionMessage(request, action, field));
            return false;
        }

        if (userDate.compareTo(entryDate) < 0) {
            errors.add(fieldName, Resources.getActionMessage(request, action, field));
            return false;
        }

        return true;
    }

    /**
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     * @return
     */
    public static boolean validateStatusClosedAndRootCauseEmpty(Object bean,
                                                                ValidatorAction action,
                                                                Field field,
                                                                ActionMessages errors,
                                                                HttpServletRequest request) {

        String MCAS_STATUS_CLOSED = "5";

        String fieldName = field.getProperty();
        CparForm cparForm = (CparForm) bean;
        Cpar cpar = cparForm.getCpar();

        if (cpar.getStatus_id() != null) {
            String id = cpar.getStatus_id();
            if (id.equals(MCAS_STATUS_CLOSED) && cpar.getRoot_cause() != null && cpar.getRoot_cause().isEmpty()) {
                errors.add(fieldName, Resources.getActionMessage(request, action, field));
                return false;
            }
        }

        return true;
    }


    /**
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     * @return
     */
    public static boolean validateISOElementHighLevelCategory(Object bean,
                                                              ValidatorAction action,
                                                              Field field,
                                                              ActionMessages errors,
                                                              HttpServletRequest request) {


        String fieldName = field.getProperty();
        CparForm cparForm = (CparForm) bean;
        Cpar cpar = cparForm.getCpar();
        User user = (User) request.getSession().getAttribute(User.USER);
        BusinessService service = new BusinessServiceImpl();
        int userBusiness = service.getBusinessId(user);
        String MCAS_STATUS_CLOSED = "5";
        String id = cpar.getStatus_id();

        if (StringUtils.isNullOrEmpty(cpar.getIso_standard()) && userBusiness == 2) {
            errors.add("isoElement", new ActionMessage("errors.mcas.cpar.isoElement"));
            return false;
        }

        //#132 Remove requirement that ISO element field be completed before closing a CAR
        if (StringUtils.isNullOrEmpty(cpar.getIssueCategoryId()) && userBusiness == 1 && id != MCAS_STATUS_CLOSED) {
            errors.add("highLevelCategory", new ActionMessage("errors.mcas.cpar.highLevelCategory"));
            return false;
        }


        return true;
    }

    /**
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     * @return
     */
    public static boolean validateFunctionalAreaTab(Object bean,
                                                              ValidatorAction action,
                                                              Field field,
                                                              ActionMessages errors,
                                                              HttpServletRequest request) {
        String fieldName = field.getProperty();
        CparForm cparForm = (CparForm) bean;
        Cpar cpar = cparForm.getCpar();
        User user = (User) request.getSession().getAttribute(User.USER);
        BusinessService service = new BusinessServiceImpl();
        if(service.getBusinessId(user)!=MCASConstants.BUSINESS_ID_VEGETABLE){

            return true;
        }
        boolean functionalAreaChecked=checkBoxGoupChecked(cpar.getFunctionalAreaList());
        if(!functionalAreaChecked){
         errors.add("fieldName", new ActionMessage("errors.mcas.audit.departmentFunctional.required"));
        }
        return functionalAreaChecked;
     }

    /**
     * @param bean
     * @param action
     * @param field
     * @param errors
     * @param request
     * @return
     */
    public static boolean validateNonConformanceTab(Object bean,
                                                              ValidatorAction action,
                                                              Field field,
                                                              ActionMessages errors,
                                                              HttpServletRequest request) {
        String fieldName = field.getProperty();
        CparForm cparForm = (CparForm) bean;
        Cpar cpar = cparForm.getCpar();
        User user = (User) request.getSession().getAttribute(User.USER);
        BusinessService service = new BusinessServiceImpl();


        if(service.getBusinessId(user)!=MCASConstants.BUSINESS_ID_VEGETABLE){
            return true;
        }

         //check all functional areas
        boolean functionalAreaChecked=checkBoxGoupChecked(cpar.getNonconformanceCategoryList());
        if(!functionalAreaChecked){
         errors.add("fieldName", new ActionMessage("errors.mcas.audit.nonConformance.required"));
        }
        return functionalAreaChecked;

     }

    private static boolean checkBoxGoupChecked( List<CheckboxGroup> listCheckBoxGroup){
          for(CheckboxGroup checkBoxGroup : listCheckBoxGroup)  {
             for(CheckboxRow row:checkBoxGroup.getCheckboxRowListAsList()){
                 for(CheckboxItem item : row.getCheckboxItemListAsList()){
                     if(!("").equalsIgnoreCase(item.getCheckboxItemDisplay())&&item.isCheckboxItemValue()){
                         return true;
                     }
                 }
             }
         }
        return false;

    }

    public static boolean validateWhenContainmentActions(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;



        Cpar cpar = cparForm.getCpar();
        String containmentText=cpar.getContainment_actions();
        String containmentPerson=cpar.getContainment_actions_person();
        int type=cpar.getType();
        if(type==MCASConstants.SBFAS_PAR_TYPE){
                  return true;
        }
        return validateResponsiblePersonWhenCarPar(containmentText,containmentPerson,errors,type,"com.monsanto.wst.ccas.cpar.containmentAction.person","com.monsanto.wst.ccas.cpar.projectTest.person", "com.monsanto.wst.ccas.cpar.containmentAction.person");
    }


     public static boolean validateWhenRootCause(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;
        Cpar cpar = cparForm.getCpar();
        String rootCauseText=cpar.getRoot_cause();
        String rootPerson=cpar.getRoot_cause_person();
        int type=cpar.getType();
        return validateResponsiblePersonWhenCarPar(rootCauseText,rootPerson,errors,type,"com.monsanto.wst.ccas.cpar.rootCause.person","com.monsanto.wst.ccas.cpar.projectResult.person", "com.monsanto.wst.ccas.cpar.rootCause.person");

    }

    public static boolean validateWhenClosedCpar(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request){

             CparForm cparForm = (CparForm) bean;
            Cpar cpar = cparForm.getCpar();
        if(cpar.getStatus_id().equalsIgnoreCase(MCASConstants.MCAS_STATUS_REF_TYPE_CLOSED)){
            CheckboxItemServiceImpl.getSelectedCheckboxItems(cpar, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");

          if(cpar.getSelectedRootCauseList().size()<2){
              errors.add("rootCauseListSelected",  new ActionMessage("com.monsanto.wst.ccas.cpar.rootCause.rootCause1WhenClosed"));
          }

          if(StringUtils.isNullOrEmpty(cpar.getLong_term_corrective_action())){
            errors.add("cpar.long_term_corrective_action",  new ActionMessage("com.monsanto.wst.ccas.cpar.longTermWhenClosed"));
          }



        }
        else{
            CheckboxItemServiceImpl.getSelectedCheckboxItems(cpar, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");
            if(cpar.getSelectedRootCauseList().size()==1){

                errors.add("rootCauseListSelected",  new ActionMessage("com.monsanto.wst.ccas.cpar.rootCause.rootCause1AndRootCause2"));
            }
        }

        return true;
    }

    public static boolean validateWhenClosedComplaint(Object bean,
                                                 ValidatorAction action,
                                                 Field field,
                                                 ActionMessages errors,
                                                 HttpServletRequest request){

        ComplaintForm complaintForm= (ComplaintForm) bean;
        Complaint complaint=complaintForm.getC();

     /*   if(complaint.getStatus_id().equalsIgnoreCase(MCASConstants.COMPLAINT_STATUS_CLOSED)){
            CheckboxItemServiceImpl.getSelectedCheckboxItems(complaint, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");

            if(complaint.getSelectedRootCauseList().size()<2){
                errors.add("rootCauseListSelected",  new ActionMessage("com.monsanto.wst.ccas.cpar.rootCause.rootCause1WhenClosed"));
            }


        }
        else{*/
            CheckboxItemServiceImpl.getSelectedCheckboxItems(complaint, (Map<String, String[]>) request.getParameterMap(), "rootCauseList");
            if(complaint.getSelectedRootCauseList().size()==1){
                errors.add("rootCauseListSelected",  new ActionMessage("com.monsanto.wst.ccas.cpar.rootCause.rootCause1AndRootCause2"));
            }
        //}

        return true;
    }

    public static boolean validateWhenLongTerm(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String longTermText=cpar.getLong_term_corrective_action();
        String longTermPerson=cpar.getLong_term_corrective_action_person();
        int type=cpar.getType();
        return validateResponsiblePersonWhenCarPar(longTermText,longTermPerson,errors,type,"com.monsanto.wst.ccas.cpar.correctiveAction.person","com.monsanto.wst.ccas.cpar.projectEvaluation.person", "com.monsanto.wst.ccas.par.correctiveAction.person");
    }

public static boolean validateWhenEvaluationComment(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String evaluationCommentText=cpar.getEvaluation_comments();
        String evaluationPerson=cpar.getEvaluation_person();
        int type=cpar.getType();
        if(cpar.isEvaluation_not_applicable()){
           return true;
        }
        else{
            return validateResponsiblePersonWhenCarPar(evaluationCommentText,evaluationPerson,errors,type,"com.monsanto.wst.ccas.cpar.evaluation.person","com.monsanto.wst.ccas.cpar.evaluation.person", "com.monsanto.wst.ccas.cpar.evaluation.person");
        }

    }


    public static boolean validateLenghtRootCause(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String rootCauseText=cpar.getRoot_cause();
        int type=cpar.getType();
        return validateLengthField( rootCauseText,MCASConstants.SBFAS_MIN_TEXT_AREA_LENGTH,MCASConstants.SBFAS_MAX_TEXT_AREA_LENGTH,type,errors,Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.car.rootCause"),Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.ci.projectResultComments"), Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.car.rootCause"), "cpar.root_cause");
    }


    public static boolean validateLenghContainmentActions(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String containmentActionsText=cpar.getContainment_actions();
        int type=cpar.getType();
        return validateLengthField( containmentActionsText,MCASConstants.SBFAS_DEFAULT_TEXT_AREA_LENGTH,MCASConstants.SBFAS_MAX_TEXT_AREA_LENGTH,type,errors,Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.car.containmentActionsComments"),Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.ci.containmentActionsComments"), Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.car.containmentActionsComments"), "cpar.containment_actions");
    }

    public static boolean validateLenghLongTerm(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String longTermText=cpar.getLong_term_corrective_action();
        int type=cpar.getType();
        return validateLengthField( longTermText,MCASConstants.SBFAS_MIN_TEXT_AREA_LENGTH,MCASConstants.SBFAS_MAX_TEXT_AREA_LENGTH,type,errors,Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.complaint.longTermCorrectiveAction"),Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.ci.projectEvaluationComments"), Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.complaint.longTermPreventiveAction"), "cpar.Long_term_corrective_action");
    }

    public static boolean validateLenghEvaluationComment(Object bean,
                                        ValidatorAction action,
                                        Field field,
                                        ActionMessages errors,
                                        HttpServletRequest request) {
        CparForm cparForm = (CparForm) bean;

        Cpar cpar = cparForm.getCpar();
        String evalComment=cpar.getEvaluation_comments();
        int type=cpar.getType();
        return validateLengthField( evalComment,MCASConstants.SBFAS_MIN_TEXT_AREA_LENGTH,MCASConstants.SBFAS_MAX_TEXT_AREA_LENGTH,type,errors,Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.par.evaluationCommentsDesc"),Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.cpar.evaluationCommentsDesc"), Resources.getMessageResources(request).getMessage("com.monsanto.wst.ccas.par.evaluationCommentsDesc"),"cpar.evaluation_comments");
    }


    private static boolean  validateLengthField(String text, int min, int max, int type, ActionMessages errors, String fieldNameCar, String fieldNameCi, String fieldNamePar, String field){


        if(text!=null&&!text.equalsIgnoreCase("")){
                        if(text.length()<min){
                            if(type==MCASConstants.SBFAS_CI_TYPE){
                               errors.add(field,  new ActionMessage("errors.minlength",new String[]{fieldNameCi,Integer.toString(min)}));
                            }
                            else if(type==MCASConstants.SBFAS_PAR_TYPE){
                               errors.add(field,  new ActionMessage("errors.minlength",new String[]{fieldNamePar,Integer.toString(min)}));

                            }
                            else{
                                errors.add(field,  new ActionMessage("errors.minlength",new String[]{fieldNameCar,Integer.toString(min)}));
                            }

                            return false;
                        }
                        else if(text.length()>max){
                            if(type==MCASConstants.SBFAS_CI_TYPE){
                                errors.add(field, new ActionMessage("errors.maxlength",new String[]{fieldNameCi,Integer.toString(max)}));
                            }
                            else if(type==MCASConstants.SBFAS_PAR_TYPE){
                               errors.add(field, new ActionMessage("errors.maxlength",new String[]{fieldNamePar,Integer.toString(max)}));

                            }
                            else{
                                errors.add(field, new ActionMessage("errors.maxlength",new String[]{fieldNameCar,Integer.toString(max)}));
                            }

                            return false;
                        }
                    }
        return true;
    }



    private static boolean validateResponsiblePersonWhenCarPar(String message, String responsiblePerson, ActionMessages errors, int type, String errorCar, String errorCI, String errorPar){



        if(message==null||message.equalsIgnoreCase("")){
                         return true;
        }

        else if(responsiblePerson==null||responsiblePerson.equalsIgnoreCase("")){
            if(type==MCASConstants.SBFAS_CI_TYPE){
                errors.add("fieldName", new ActionMessage(errorCI));
            }
            else if(type==MCASConstants.SBFAS_PAR_TYPE){
                errors.add("fieldName", new ActionMessage(errorPar));
            }
            else{
                errors.add("fieldName", new ActionMessage(errorCar));
            }
            return false;
        }
        else{
            return true;
        }

    }

}
