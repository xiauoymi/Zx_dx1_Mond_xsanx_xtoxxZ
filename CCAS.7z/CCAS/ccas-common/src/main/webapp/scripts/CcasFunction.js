var applicationName = null;
var forceReloadOfRegionsFlag;


function addOtherRegionLocationsToResponsibleLocation() {
    if (applicationName == "mcas") {
        var regionControl = document.getElementById("region");
        var responsibleLocOptionControl = document.getElementById("responsible_location");
        if (responsibleLocOptionControl == null || regionControl == null) return;
        for (var i = 0; i < regionControl.options.length; i++) {
            if (i == 0) continue;
            responsibleLocOptionControl.add(new Option("Location in : " + regionControl.options[i].text,
                    regionControl.options[i].value));
        }
    }
}


function setFunction(dropDown, appName) {
    try {
        var pos = new POSConnection("Mcas_FunctionPOS");
        //        pos.setControllerURL('http://w3devel.kerberos.monsanto.com/mcas/nsServlet/salesOfficePOS');
        pos.setControllerURL('/' + appName + '/nsServlet/functionPOS');
        if (dropDown != null || dropDown != undefined) {
            var dropDownValue = dropDown.options[dropDown.selectedIndex].value;
            if (dropDownValue != null) {
                var request = '<FunctionPOSRequest><functionId>' + dropDownValue + '</functionId></FunctionPOSRequest>';
                pos.send(request, populateFunctionDropDownList);
            }
        }
    } catch(ed) {
        alert(ed);
    }
}

function setIsoStandard(dropDown, appName) {
    try {
        var pos = new POSConnection("Mcas_IsoStandardPOS");
        pos.setControllerURL('/' + appName + '/nsServlet/isoStandardPOS');
        if (dropDown != null || dropDown != undefined) {
            var dropDownValue = dropDown.options[dropDown.selectedIndex].value;
            var request = '<IsoStandardPOSRequest><programId>' + dropDownValue + '</programId></IsoStandardPOSRequest>';
            pos.send(request, populateISOElementDropDownList);
        }
    } catch(ed) {
        alert(ed);
    }
}

function isErrors(xmlDoc) {
    try {
        var string = (new XMLSerializer()).serializeToString(xmlDoc);
        var error = xmlDoc.selectNodes("/ERROR/ERROR_MESSAGE");
        return error.length > 0;
    } catch(ex) {
        return false;
        //Ignore...Firefox throws exception
    }
}

function populateISOElementDropDownList(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {

        var functions = xmlDoc.getElementsByTagName('standard');
        if (document.getElementById('ccasisoelement') != null ||
                document.getElementById('ccasisoelement') != undefined) {
            var ccasselectnodelist = document.getElementById("ccasisoelement").childNodes;
            populateComplaintDropDowns(functions, ccasselectnodelist);
            //var string = (new XMLSerializer()).serializeToString(xmlDoc);
        }
    }
}

function populateFunctionDropDownList(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {

        var functions = xmlDoc.getElementsByTagName('function');
        if (document.getElementById('ccasfunction') != null || document.getElementById('ccasfunction') != undefined) {
            var ccasselectnodelist = document.getElementById("ccasfunction").childNodes;
            populateComplaintDropDowns(functions, ccasselectnodelist);
            //var string = (new XMLSerializer()).serializeToString(xmlDoc);
        }
    }
}

function removeAllOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}

function checkForEmptyDropDownCriteria(selectbox, defaulttext) {
    if (selectbox != null && selectbox.options.length <= 1) {
        removeAllOptions(selectbox);
        defaultid = '';
        var docoption = document.createElement("OPTION");
        if (defaulttext == '') {
            docoption.text = '------N/A-----';
        } else {
            docoption.text = defaulttext;
        }
        docoption.value = defaultid;
        selectbox.options.add(docoption);
        selectbox.selectedIndex = 0;
    }
}


//Method to Populate Material Group Pricing Drop down based on Material Group Selection
function getMaterialGroupPricing(materialGroupSelectBox, appName) {
    var materialGroupIdArray;
    var materialGroupId = '';
    try {
        var pos = new POSConnection("Mcas_MaterialGroupPricingPOS");
        //        pos.setControllerURL('/' + appName + '/nsServlet/ajaxController');
        pos.setControllerURL('/' + appName + '/nsServlet/materialGroupPricingPOS');
        if (materialGroupSelectBox != null) {
            materialGroupIdArray = new Array(materialGroupSelectBox.length);
            for (var i = 0; i < materialGroupSelectBox.length; i++) {
                if (materialGroupSelectBox.options[i].selected == true) {
                    materialGroupIdArray[i] = materialGroupSelectBox.options[i].value;
                } else {
                    materialGroupIdArray[i] = '';
                }
            }
            for (var j = 0; j < materialGroupIdArray.length; j++) {
                if (materialGroupIdArray[j] != '') {
                    materialGroupId = materialGroupId + materialGroupIdArray[j] + ':';
                }
            }
            var request = '<MaterialGroupPricingPOSRequest><MaterialGroupID>' + materialGroupId +
                    '</MaterialGroupID></MaterialGroupPricingPOSRequest>';
            pos.send(request, populateMaterialGroupPricing);
        }
    } catch(e) {
        alert('Error');
    }
}
//Method to Populate Material Group Pricing Drop down based on Material Group Selection
function setMaterialGroupPricing(materialGroupSelectValue, appName) {
    try {
        var pos = new POSConnection("Mcas_MaterialGroupPricingPOS");
        //        pos.setControllerURL('/' + appName + '/nsServlet/ajaxController');
        pos.setControllerURL('/' + appName + '/nsServlet/materialGroupPricingPOS');
        if (materialGroupSelectValue != null && materialGroupSelectValue != 0 && materialGroupSelectValue != '' &&
                materialGroupSelectValue != ' ') {
            var materialGroupId = materialGroupSelectValue;
            if (materialGroupId != null) {
                var request = '<MaterialGroupPricingPOSRequest><MaterialGroupID>' + materialGroupId +
                        '</MaterialGroupID></MaterialGroupPricingPOSRequest>';
                pos.send(request, populateMaterialGroupPricing);
            }
        }
    } catch(exception) {
        alert(exception);
    }

}

//Method to Populate Material Group Drop down based on Crop Selection
// : 04-09-08
function populateMaterialGroupPricing(xmlDoc) {

    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {

        var materialPricingGroups = xmlDoc.getElementsByTagName('MaterialPricingGroup');
        var materialPricingGroupNodeList = document.getElementById("materialGroupPricing").childNodes;
        populateComplaintDropDowns(materialPricingGroups, materialPricingGroupNodeList);
    }
}


//Method to Populate Material Group Drop down based on Crop Selection
function setMaterialGroup(cropSelectBox, appName) {
    try {
        var cropId = '';
        var cropArray;

        var pos = new POSConnection("Mcas_MaterialGroupPOS");
        //        pos.setControllerURL('/' + appName + '/nsServlet/ajaxController');
        pos.setControllerURL('/' + appName + '/nsServlet/materialGroupPOS');
        if (cropSelectBox != null) {
            cropArray = new Array(cropSelectBox.length);
            for (var i = 0; i < cropSelectBox.length; i++) {
                if (cropSelectBox.options[i].selected == true) {
                    cropArray[i] = cropSelectBox.options[i].value;
                } else {
                    cropArray[i] = '';
                }

            }
            for (var j = 0; j < cropArray.length; j++) {

                if (cropArray[j] != '') {
                    cropId = cropId + cropArray[j] + ':';
                }
            }
            var request = '<MaterialGroupPOSRequest><CropID>' + cropId + '</CropID></MaterialGroupPOSRequest>';
            pos.send(request, populateMaterialGroup);
        }
    } catch(exception) {
        alert(exception);
    }
}
//Method to Populate Material Group Drop down based on Crop Selection
// : 04-09-08
function populateMaterialGroup(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {
        var materialGroups = xmlDoc.getElementsByTagName('MaterialGroup');
        var materialGroupNodeList = document.getElementById("materialGroup").childNodes;
        var ccasselect = populateComplaintDropDowns(materialGroups, materialGroupNodeList);
        //populateMatGrpPricing(ccasselect);

    }
}


function retrieveAndLoadReportingLocationForRegion(regionId, appName, forceReloadOfRegions, callbackFunction) {
    try {
        forceReloadOfRegionsFlag = true;
        var pos = new POSConnection("Mcas_SalesOfficePOS");
        pos.setControllerURL('/' + appName + '/nsServlet/salesOfficePOS');
        if (regionId != null) {
            var request = '<SalesOfficePOSRequest><regionId>' + regionId + '</regionId></SalesOfficePOSRequest>';
            pos.send(request, callbackFunction == null ? populateResponsibleLocation : callbackFunction);
        }
    } catch(ed) {
        alert(ed);
    }
}

function populateMatGrpPricing(ccasselect) {
    for (var i = 0; i < ccasselect.length; i++) {
        document.forms[0].materialGroupCode.value = ccasselect.options[i].value;
        setMaterialGroupPricing(document.forms[0].materialGroupCode.value);
    }
}
function setSalesOffice(dropDown, appName) {
    var regionIdArray;
    var regionId = '';
    applicationName = appName;
    try {
        var pos = new POSConnection("Mcas_SalesOfficePOS");
        pos.setControllerURL('/' + appName + '/nsServlet/salesOfficePOS');
        if (dropDown != null) {
            regionIdArray = new Array(dropDown.length);
            for (var i = 0; i < dropDown.length; i++) {
                if (dropDown.options[i].selected == true) {
                    regionIdArray[i] = dropDown.options[i].value;
                } else {
                    regionIdArray[i] = '';
                }
            }
            for (var j = 0; j < regionIdArray.length; j++) {
                if (regionIdArray[j] != '') {
                    regionId = regionId + regionIdArray[j] + ':';
                }
            }
            var request = '<SalesOfficePOSRequest><regionId>' + regionId + '</regionId></SalesOfficePOSRequest>';
            pos.send(request, populateSalesOffice);
        }
        /*if(dropDown != null){
         var dropDownValue = dropDown.options[dropDown.selectedIndex].value;
         if(dropDownValue!=null){
         var request = '<SalesOfficePOSRequest><regionId>' + dropDownValue + '</regionId></SalesOfficePOSRequest>';
         pos.send(request,populateSalesOffice);
         }
         } */
    } catch(ed) {
        alert(ed.message);
    }
}

function setSalesOfficeCustom(dropDown, appName) {
    var regionIdArray;
    var regionId = '';
    applicationName = appName;
    try {
        var pos = new POSConnection("Mcas_SalesOfficePOS");
        pos.setControllerURL('/' + appName + '/nsServlet/salesOfficePOS');
        if (dropDown != null) {
            regionIdArray = new Array(dropDown.length);
            for (var i = 0; i < dropDown.length; i++) {
                if (dropDown.options[i].selected == true) {
                    regionIdArray[i] = dropDown.options[i].value;
                } else {
                    regionIdArray[i] = '';
                }
            }
            for (var j = 0; j < regionIdArray.length; j++) {
                if (regionIdArray[j] != '') {
                    regionId = regionId + regionIdArray[j] + ':';
                }
            }
            var request = '<SalesOfficePOSRequest><regionId>' + regionId + '</regionId></SalesOfficePOSRequest>';
            pos.send(request, populateSalesOfficeResponsibleLocation);
        }
        /*if(dropDown != null){
         var dropDownValue = dropDown.options[dropDown.selectedIndex].value;
         if(dropDownValue!=null){
         var request = '<SalesOfficePOSRequest><regionId>' + dropDownValue + '</regionId></SalesOfficePOSRequest>';
         pos.send(request,populateSalesOffice);
         }
         } */
    } catch(ed) {
        alert(ed.message);
    }
}

function populateResponsibleLocation(xmlDataOfLocations) {
    try {
        if (isErrors(xmlDataOfLocations)) {
            alert('Error');
        }
        else {
            var responsibleLocationMap = xmlDataOfLocations.getElementsByTagName('ResponsibleLocations')[0];
            var responsibleLocationList = responsibleLocationMap.getElementsByTagName('Location');
            if (document.getElementById("responsibleLocationtd") != null) {
                var responsibleLocationNode = document.getElementById("responsibleLocationtd").childNodes;
                populateComplaintDropDowns(responsibleLocationList, responsibleLocationNode);
            }

            var regionControl = document.getElementById("region");
            var responsibleLocOptionControl = document.getElementById("responsible_location");
            if (responsibleLocOptionControl == null || regionControl == null) {
                return;
            }
            for (var i = 0; i < regionControl.options.length; i++) {
                if (i == 0) continue;
                responsibleLocOptionControl.add(new Option("Location in : " + regionControl.options[i].text,
                        regionControl.options[i].value));
            }
        }
    }
    catch(e) {
        alert(e.message)
    }
}

function populateSalesOffice(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {
        var salesOfficeList = xmlDoc.getElementsByTagName('salesOffice');
        var stateList = xmlDoc.getElementsByTagName('state');

        var responsibleLocationMap = xmlDoc.getElementsByTagName('ResponsibleLocations')[0];
        var filingLocationMap = xmlDoc.getElementsByTagName('FilingLocations')[0];
        var reportingLocationMap = xmlDoc.getElementsByTagName('ReportingLocations')[0];
        var shippingLocationMap = xmlDoc.getElementsByTagName('ShippingLocations')[0];
        var customerLocationMap = xmlDoc.getElementsByTagName('CustomerLocations')[0];

        var responsibleLocationList = responsibleLocationMap.getElementsByTagName('Location');
        var filingLocationList = filingLocationMap.getElementsByTagName('Location');
        var reportingLocationList = reportingLocationMap.getElementsByTagName('Location');
        var shippingLocationList = shippingLocationMap.getElementsByTagName('Location');
        var customerLocationList = customerLocationMap.getElementsByTagName('Location');

        var locationNode;
        //First Check for the Sales Office
        if (salesOfficeList.length > 1) {
            if (document.getElementById("salesoffice") != null) {
                var ccasselectnodelist = document.getElementById("salesoffice").childNodes;
                populateComplaintDropDowns(salesOfficeList, ccasselectnodelist);
            }
        } else {//Populate the states
            var stateNode;
            if (document.getElementById("state") != null) {
                stateNode = document.getElementById("state").childNodes;
                populateComplaintDropDowns(stateList, stateNode);
            }
            if (document.getElementById("growerState") != null) {
                stateNode = document.getElementById("growerState").childNodes;
                populateComplaintDropDowns(stateList, stateNode);
            }
            if (document.getElementById("dealerState") != null) {
                stateNode = document.getElementById("dealerState").childNodes;
                populateComplaintDropDowns(stateList, stateNode);
            }
        }
        //Populate the Locations

        if (document.getElementById("responsibleLocationtd") != null) {
            var responsibleLocationNode = document.getElementById("responsibleLocationtd").childNodes;
            populateComplaintDropDowns(responsibleLocationList, responsibleLocationNode);
        }
        if (document.getElementById("filingLocationtd") != null) {
            var filingLocationNode = document.getElementById("filingLocationtd").childNodes;
            populateComplaintDropDowns(filingLocationList, filingLocationNode);
        }
        if (document.getElementById("reportLocation") != null) {
            var reportLocationNode = document.getElementById("reportLocation").childNodes;

            var application = document.forms[0].APP_NAME.value;

            if ((application == null) || (application != "SBFAS")) {

                populateComplaintDropDowns(reportingLocationList, reportLocationNode);
            }
            else {

                populateComplaintDropDowns(customerLocationList, reportLocationNode);
            }
        }
        if (document.getElementById("shippingLocation") != null) {
            var shippingLocationNode = document.getElementById("shippingLocation").childNodes;
            populateComplaintDropDowns(shippingLocationList, shippingLocationNode);
        }

       // addOtherRegionLocationsToResponsibleLocation()

    }
}

function populateSalesOfficeResponsibleLocation(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {
        var salesOfficeList = xmlDoc.getElementsByTagName('salesOffice');
        var stateList = xmlDoc.getElementsByTagName('state');

        var responsibleLocationMap = xmlDoc.getElementsByTagName('ResponsibleLocations')[0];


        var responsibleLocationList = responsibleLocationMap.getElementsByTagName('Location');


        var locationNode;

        //Populate the Locations

        if (document.getElementById("responsibleLocationtd") != null) {
            var responsibleLocationNode = document.getElementById("responsibleLocationtd").childNodes;
            populateComplaintDropDowns(responsibleLocationList, responsibleLocationNode);
        }


       // addOtherRegionLocationsToResponsibleLocation()

    }
}

/*
 *	Javascript function to populate drop downs on asynchronous calls<Refactored>
 */
function populateComplaintDropDowns(functions, ccasselectnodelist) {
    var ccasselect;
    for (var i = 0; i < ccasselectnodelist.length; i++) {
        var ccasnodetype = ccasselectnodelist[i].nodeType;
        if (ccasnodetype == 1) {
            ccasselect = ccasselectnodelist[i];
        }
    }

    removeAllOptions(ccasselect);

    for (var i = 0; i < functions.length; i++) {
        var functionId;
        if (functions[i].childNodes[0].firstChild == null) {
            functionId = '';
        } else {
            functionId = functions[i].childNodes[0].firstChild.nodeValue;
        }
        var functionDescription = functions[i].childNodes[1].firstChild.nodeValue;
        var docoption = document.createElement("OPTION");
        docoption.text = functionDescription;
        docoption.value = functionId;
        ccasselect.options.add(docoption);
    }
    checkForEmptyDropDownCriteria(ccasselect, '');
    return ccasselect;
}

function setTargetType(dropDown) {
    var selectedVar = dropDown.options[dropDown.selectedIndex].value;
    if (selectedVar == null || selectedVar == "") {
        return 'Please select a valid target type';
    } else {
        document.forms[0].cparTypeSelected.value = selectedVar;
    }
}

function changeType(cparId) {
    if (document.forms[0].cparTypeSelected != null) {
        if (document.forms[0].cparTypeSelected.value != "") {
            var targetType = document.forms[0].cparTypeSelected.value;
            document.forms[0].action = "cpar.do?method=cparEdit&cparId=" + cparId + "&changeTo=" + targetType;
            document.forms[0].submit();
            //alert(document.forms[0].action);
        } else {
            alert('Please select the target type');
            return;
        }
    }
}

function deleteCpar(cparId, sortValue, sortCriteria, carValue, selectedPage, type) {
    var cparType = "CAR";
    if (carValue == false) {
        if (type == 4){
        cparType = "CI";    
        }
        else {
        cparType = "PAR";
        }
    }
    if (cparId != null && cparId != '') {
        var isDeleteCar = confirm('You are about to Delete a  ' + cparType + ' ! Press OK to continue.');
        if (isDeleteCar) {
            var deleteForSure = confirm('Are you sure you want to delete the   ' + cparType + ' ?');
            if (deleteForSure) {
                document.forms[0].action = "cparList.do?method=cparDelete&cparIdToDelete=" + cparId +
                        "&isSorting=false&sortCriteria=" + sortCriteria + "&iscar=" + carValue +
                        "&reset=false&getMax=true&selectedPage=" + selectedPage + "&sortOrder=" +
                        sortValue;
                document.forms[0].submit();
            }
        } else {
            return;
        }
    }
}


function populateClaimInformation() {
    if (document.getElementById('id_claim_id') != null && document.getElementById('id_claim_id') != undefined) {
        if (document.getElementById("id_user_business") != null &&
                document.getElementById("id_user_business").value == "1"
                ) {
            //id_region
            var regionId = getTDChildElement("id_region");
            var selectedRegion = getSelectedOption(regionId);
            var contextPath = document.getElementById("contextPath").value;
            var claimId = getTDChildElement("id_claim").value;
            var control_number = getTDChildElement("id_control_number").value;
            if (claimId != '') {
                document.getElementById("id_claim_hidden").value = claimId;

                getDataByXML(contextPath + "/servlet/claimsController?CLAIM_ID=" + claimId + "&COMPLAINT_ID=" +
                        control_number + "&REGION_ID=" + selectedRegion, populateDetailClaimInformation);

            }
        }
    }
}

function populateSecondRootCauseByParentId(rootCauseCall){
  if(rootCauseCall==1){
      return;
  }

    var parentId=document.getElementById("rootCauseListSelected0").options[document.getElementById("rootCauseListSelected0").selectedIndex].value;

    var contextPath = document.getElementById("contextPath").value;
    getDataByXML(contextPath + "/servlet/rootCauseController?ROOT_CAUSE_ID=" +
        ''+(parseInt(parentId)), populateSecondRootCause);

}

function populateSecondRootCause(xmlDoc){

    var xmlDoc = xmlDoc.responseXML;
    var count = xmlDoc.getElementsByTagName('rootCause').length;
    var i = 0;

    if (count > 0) {
        var dropDown = document.getElementById('rootCauseListSelected1');

        if (dropDown === null || dropDown === undefined){

            return;
        }
        dropDown.options.length = 0;
          dropDown.options[0] = new Option('Select One', '', false, false);

        for (i = 0; i < count; i++) {
            var selected = false;
            var node = 'rootCause' + '/' + 'id';

            var node1Value = xmlDoc.getElementsByTagName(node)[i].text;

            node = 'rootCause' + '/' + 'description';

            var node2Value = xmlDoc.getElementsByTagName(node)[i].text;

            dropDown.options[i+1] = new Option(node2Value, node1Value, selected, selected);
        }
    }

}

function releaseClaimInformation() {
    if (document.getElementById('id_claim_id') != null && document.getElementById('id_claim_id') != undefined) {
        //       var claimId = document.getElementById("id_claim_id").value;
        var contextPath = document.getElementById("contextPath").value;
        var claimId = getTDChildElement("id_claim").value;
        if (claimId != '') {
            //           document.getElementById("id_claim_id").value=claimId;

            getDataByXML(contextPath + "/servlet/claimsController?method=release&CLAIM_ID=" +
                    claimId, releaseClaimInformationDisplayResult);
        }
    }
}

function populateDetailClaimInformation(xmlDoc) {
    var xmlDoc = xmlDoc.responseXML;
    //  var validateClaim = document.getElementById("validateClaim").value;
    //Begin claim related to single complaint
    if (xmlDoc.getElementsByTagName("ERROR")[0] != null && xmlDoc.getElementsByTagName("ERROR")[0].firstChild != null) {
        //        if(validateClaim==''){
        var invalidClaimComplaintRelation = xmlDoc.getElementsByTagName("ERROR")[0].firstChild.nodeValue;
        if (invalidClaimComplaintRelation != 'Not a CIS Claim') {
            alert(invalidClaimComplaintRelation);
            getTDChildElement("id_claim").value = "";
        }
        //        }
    } else {
        document.getElementById("id_get_claim_button").disabled = true;
        getTDChildElement("id_claim").disabled = true;
        var operation = document.getElementById("id_operation").value;
        if (operation != 'true') {
            populateSalesOffice(xmlDoc);
        }
        populateNamedTextBoxElement(xmlDoc, "TOT_SETTLEMENT_VALUE", "id_settlement");

        populateNamedTextBoxElement(xmlDoc, "GROWER_NAME", "id_grower_name");
        populateNamedTextBoxElement(xmlDoc, "GROWER_ADDRESS", "id_grower_address");
        populateNamedTextBoxElement(xmlDoc, "GROWER_CITY", "id_grower_city");
        populateNamedTextBoxElement(xmlDoc, "GROWER_ACCT_ID", "id_grower_ba_id");

        populateNamedTextBoxElement(xmlDoc, "RETAILER_DEALER_NAME", "id_dealer_name");
        populateNamedTextBoxElement(xmlDoc, "RETAILER_DEALER_ADDR", "id_dealer_address");
        populateNamedTextBoxElement(xmlDoc, "RETAILER_DEALER_CITY_NAME", "id_dealer_city");
        populateNamedTextBoxElement(xmlDoc, "RETAILER_DEALER_SAP_ID", "id_dealer_ba_id");

        populateNamedSelectElement(xmlDoc, "CROP_NAME", "id_crop");
        populateNamedSelectElement(xmlDoc, "RETAILER_DEALER_STATE", "dealerState");
        populateNamedSelectElement(xmlDoc, "RETAILER_DEALER_STATE", "state");
        populateNamedSelectElement(xmlDoc, "GROWER_STATE", "growerState");
        populateNamedSelectElement(xmlDoc, "CLAIM_YEAR", "id_sales_year");
        var arr=document.getElementsByName("c.problem_description");

        if (xmlDoc.getElementsByTagName("PROBLEM_DESCRIPTION")[0].firstChild != null) {
        var valueToBeSelected = xmlDoc.getElementsByTagName("PROBLEM_DESCRIPTION")[0].firstChild.nodeValue;
            arr[0].value=valueToBeSelected;
        }
       // populateNamedSelectElement(xmlDoc, "", "problem_description");

        disableReleaseClaimButton(xmlDoc);
        setRegion(xmlDoc);
        setReportingLocation(xmlDoc);
        var yearSelectDropDown = getTDChildElement("id_sales_year");
        var yearOption = getSelectedOption(yearSelectDropDown);
        var stateSelectDropDown = getTDChildElement("state");
        var stateOption = getSelectedOption(stateSelectDropDown);
        document.getElementById("id_hidden_sales_year").value = yearOption;
        document.getElementById("id_hidden_state").value = stateOption;
    }

}

function getSelectedOption(selectElementId) {
    //      var warehouseSelect = document.getElementById(selectElementId);
    var selectedOption = selectElementId.options[selectElementId.selectedIndex].value;
    return selectedOption;
}

function releaseClaimInformationDisplayResult(xmlDoc) {
    var xmlDoc = xmlDoc.responseXML;
    var result = xmlDoc.getElementsByTagName("RESULT")[0].firstChild.nodeValue;
    var status = xmlDoc.getElementsByTagName("status_id")[0].firstChild.nodeValue;
    var validQualityIssue = xmlDoc.getElementsByTagName("qualityIssueId")[0].firstChild.nodeValue;
    //    setStatus(status,"id_status");
    //    setValidQualityIssue(validQualityIssue,"valid_quality_issue_value");
    setDropDownValues(status, "id_status");
    setDropDownValues(validQualityIssue, "valid_quality_issue_value");
    alert(result);
}

function disableReleaseClaimButton(xmlDoc) {
    if (xmlDoc.getElementsByTagName("HOLD_REASON_STATUS")[0].firstChild != null) {
        var reasonStatus = xmlDoc.getElementsByTagName("HOLD_REASON_STATUS")[0].firstChild.nodeValue;
        if (reasonStatus == 'R') {
            if (document.getElementById("id_release_claim") != null) {
                document.getElementById("id_release_claim").disabled = true;
            }
        }
    }
}

//todo move this to a common area , rename elements.. eg pageElementId
function populateNamedTextBoxElement(xmlDoc, xmlElementName, pageElementId) {
    if (xmlDoc.getElementsByTagName(xmlElementName)[0].firstChild != null) {
        var elementValue = xmlDoc.getElementsByTagName(xmlElementName)[0].firstChild.nodeValue;
        var pageElement = getTDChildElement(pageElementId);
        pageElement.value = elementValue;
        pageElement.disabled = true;
    }
}

//todo move this to a common area , rename elements.. eg pageElementId
function populateNamedSelectElement(xmlDoc, xmlElementName, pageElementId) {
    var dropDownElement = getTDChildElement(pageElementId);
    if (xmlDoc.getElementsByTagName(xmlElementName)[0].firstChild != null) {
        var valueToBeSelected = xmlDoc.getElementsByTagName(xmlElementName)[0].firstChild.nodeValue;
        var options = dropDownElement.options;
        //dropDownElement.disabled = true;
        setSelectedTextTo(options, valueToBeSelected);
        var found=false;
        for (i = 0; i < options.length; i++) {
            if (strtrim(options[i].text).toUpperCase() != valueToBeSelected.toUpperCase()) {
            options[i].disabled=true;
        }
            else{
                found=true;
            }

    }
        if(!found){
               setSelectedTextTo(options, valueToBeSelected+"s");
         //alert(valueToBeSelected+"s");
         for (i = 0; i < options.length; i++) {
            if (strtrim(options[i].text).toUpperCase() == (valueToBeSelected+"s").toUpperCase()) {
            options[i].disabled=false;
                found=true;
        }
        }
            }
        if(!found){
            for(i = 0; i < options.length; i++){
               var optionDesc=strtrim(options[i].text).toUpperCase();
               var valueSelectedUpper=valueToBeSelected.toUpperCase();
                if(optionDesc.indexOf(valueSelectedUpper)!=-1){
                    options[i].disabled=false;
                    setSelectedTextTo(options, optionDesc);

                }
            }
        }
    }
}



function setRegion(xmlDoc) {
    var dropDownElement = getTDChildElement("id_region");
    var valueToBeSelected = "North America";
    var options = dropDownElement.options;
    setSelectedTextTo(options, valueToBeSelected);
}

function setDropDownValues(status, pageElementId) {
    var dropDownElement = getTDChildElement(pageElementId);
    //    var valueToBeSelected = status;
    var options = dropDownElement.options;
    setSelectedAcutalValueTo(options, strtrim(status));
}

function setReportingLocation(xmlDoc) {
    var dropDownElement = getTDChildElement("reportLocation");
    var valueToBeSelected = "St. Louis, CC";
    var options = dropDownElement.options;
    setSelectedTextTo(options, valueToBeSelected);
}


//todo move this to a common area
function getTDChildElement(tdNodeId) {
    var ccasselectnodelist = document.getElementById(tdNodeId).childNodes;
    var ccasselect;
    for (var i = 0; i < ccasselectnodelist.length; i++) {
        var ccasnodetype = ccasselectnodelist[i].nodeType;
        if (ccasnodetype == 1) {
            ccasselect = ccasselectnodelist[i];
        }
    }
    return ccasselect;
}

//todo move this to a common area.
function getDataByXML(url, callBackFunction) {
    try {
        var callBackAfterGettingResultsBack = {
            success: function(o) {
                this.cache = null;
                callBackFunction(o);
            },
            cache:false ,
            failure: function(o) {
                alert("Unable to connect URL." + url);
                return;
            },
            timeout: 600000 //20 seconds
        };
        this.getXML = YAHOO.util.Connect.asyncRequest("GET",
                url,
                callBackAfterGettingResultsBack);
    }
    catch(e) {
        alert(e.message);
    }
}

function setSelectedTextTo(dropDown, valueToBeSet) {
    for (i = 0; i < dropDown.length; i++) {
        if (strtrim(dropDown[i].text).toUpperCase() == valueToBeSet.toUpperCase()) {
            dropDown[i].selected = true;
        }
    }
}
function setSelectedAcutalValueTo(dropDown, valueToBeSet) {
    for (i = 0; i < dropDown.length; i++) {
        if (strtrim(dropDown[i].value) == valueToBeSet) {
            dropDown[i].selected = true;
        }
    }
}

function populateComplaintDropDowns_cleanup(functions, ccasselectnodelist) {
    var ccasselect;
    for (var i = 0; i < ccasselectnodelist.length; i++) {
        var ccasnodetype = ccasselectnodelist[i].nodeType;
        if (ccasnodetype == 1) {
            ccasselect = ccasselectnodelist[i];
        }
    }

    removeAllOptions(ccasselect);

    for (var i = 0; i < functions.length; i++) {
        var functionId;
        if (functions[i].childNodes[1].firstChild == null) {
            functionId = '';
        } else {
            functionId = functions[i].childNodes[1].firstChild.nodeValue;
        }
        var functionDescription = functions[i].childNodes[3].firstChild.nodeValue;
        var docoption = document.createElement("OPTION");
        docoption.text = functionDescription;
        docoption.value = functionId;
        ccasselect.options.add(docoption);
    }
    checkForEmptyDropDownCriteria(ccasselect, '');
    return ccasselect;
}

//This function is written to highlight the tab that is written using unordered lists.
function highlightActiveTab(element) {
    var contextPath = document.getElementById('contextPath').value;
    //    if (contextPath === '/biotechfas' || contextPath === '/sbfas') {
    var grandParent = element.parentElement.parentElement;
    var parent = element.parentElement;
    var numberOfChildren = grandParent.childNodes.length;
    for (i = 0; i < numberOfChildren; i++) {
        if (grandParent.childNodes[i] == parent) {
            grandParent.childNodes[i].className = 'menu_selected';
        } else {
            grandParent.childNodes[i].className = '';
        }
    }
    //    }
}

function autoPopulateFiscalYear(date) {
    if (document.getElementById('contextPath').value == '/biotechfas' ||
            document.getElementById('contextPath').value == '/mcas') {
        if (date == "" || date == undefined) {
            var newOrEditOperation = document.getElementById('id_operation').value;
            if (newOrEditOperation != 'true' || newOrEditOperation === '') {
                var url = document.getElementById("contextPath").value + "/servlet/yearData";
                getDataByXML(url, populateYearDropDown);
            }
        } else if (date != '' && document.getElementById('contextPath').value == '/biotechfas') {
            if (validateDate(date.value)) {
                var url = document.getElementById("contextPath").value + "/servlet/yearData";
                getDataByXML(url, populateYearDropDown);
            }
        }
    }
}

function validateDate(strValue) {
    var objRegExp = /^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$/;

    //check to see if in correct format
    if (!objRegExp.test(strValue)) {
        return false; //doesn't match pattern, bad date
    }
    return true; //any other values, bad date
}


function populateYearDropDown(o) {
    var xmlDoc = o.responseXML;
    var count = xmlDoc.getElementsByTagName('year').length;
    var i = 0;
    if (count > 0) {
        var dropDown = document.getElementById('sales_year_id');
        if (dropDown === null || dropDown === undefined) {
            var dropDown = document.getElementById('salesYear');
        }
        if (dropDown === null || dropDown === undefined) return;
        dropDown.options.length = 0;
        //  dropDown.options[i] = new Option('Select One', '', false, false);
        for (i = 0; i < count; i++) {
            var selected = false;
            var node = 'year' + '/' + 'id';
            var node1Value = xmlDoc.getElementsByTagName(node)[i].text;
            node = 'year' + '/' + 'description';
            var node2Value = xmlDoc.getElementsByTagName(node)[i].text;
            dropDown.options[i] = new Option(node2Value, node1Value, selected, selected);
        }
    }
}

function highlightParentTabOnHeader(anchorElement) {
    if (document.getElementById('cparType') != null || document.getElementById('cparType') != undefined) {
        var cparType = document.getElementById('cparType').value;
        if (cparType == 1) {
            anchorElement = 'carOption';
        } else if (cparType == 2) {
            anchorElement = 'parOption';
        } else if (cparType == 3) {
            anchorElement = 'ncrOption';
        } else if (cparType == 4) {
            anchorElement = 'ciOption';
        }
    }
    highlightActiveTab(parent.top.header.document.getElementById(anchorElement));
}

function showEmailMessage(personElement, personToBeNotified) {
    var contextPath = document.getElementById('contextPath').value;
    if (contextPath == '/biotechfas' && personElement.value != '') {
        var text = "";
        if (personToBeNotified == 'Team Lead') {
            text = " ";
            //            text = " for approval of this plan";
        }
        var confirmed = confirm("Would you like to send email notification to the " + personToBeNotified + text + "?");
        if (confirmed) {
            printFriendly('COMPLAINT', 'saveAndSubmit', '', '750', '400', 'yes', 'yes', 'default', contextPath);
            SendEmail();
        }
    }
}

function selectAllSubFunctions() {
    var subfunctionElement = document.getElementById('subFunction_id');
    var i = 0;
    for (i = 0; i < subfunctionElement.options.length; i++) {
        subfunctionElement.options[i].selected = true;
    }
}

