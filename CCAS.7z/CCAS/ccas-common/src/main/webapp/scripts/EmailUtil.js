/**
 * Redirect the user to a pop-up window to display email page.
 * @param businessId
 * @param previewID
 * @param path to pop up window.
 */
function SendEmail(to, subject, comments) {
    var path = document.getElementById('contextPath').value;
    var businessId = document.getElementById('BUSINESS_ID').value;
    var id_action = '';
    if (document.getElementById('id_action') != null) {
        var id_action = document.getElementById('id_action').value;
    }
    var previewID = 'printPreviewID';
    window.open(path + "/pages/email/SendEmail.jsp?BUSINESS_ID=" + businessId + "&previewId= " + previewID + "&id_action=" + id_action
             + "&to=" + to + "&subject=" + subject + "&comments=" + comments,
            "emailPage", "menubar=1,resizable=1,width=700,height=450,location=no,directories=no,status=no,menubar=no,toolbar=no,status=1");
}
