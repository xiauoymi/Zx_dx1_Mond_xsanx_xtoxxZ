POSConnection.CONTROLLER_URL = "ajaxController";

function POSConnection(posName) {
    this.url = POSConnection.CONTROLLER_URL;
    this.setPOSName(posName);
}

POSConnection.prototype.send = function (inputXML, callback) {
    var pars = "posName=" + this.posName +
               "&inputDocument=" + encodeURI(inputXML);
    if (callback) {
        this.callServiceAsynchronously(pars, callback);
        return;
    } else {
        return this.callServiceSynchronously(pars);
    }
};

POSConnection.prototype.callServiceSynchronously = function (pars, inputXML) {
    var response = new Ajax.Request(this.url, { method: 'get', asynchronous:false, parameters: pars});
    return response.transport.responseXML;
};

POSConnection.prototype.callServiceAsynchronously = function (pars, callback) {
    var request = new Ajax.Request(this.url, { method: 'get', parameters: pars,
        onComplete: this.processSuccessfulCall.bind(this, callback),
        onFailure: this.processFailureCall.bind(this, callback)});
    return;
};

POSConnection.prototype.processSuccessfulCall = function(callback, response) {
    callback(response.responseXML);
};

POSConnection.prototype.processFailureCall = function(callback, response) {
    var errorXML = "<ERROR><ERROR_CODE>"
            + response.status
            + "</ERROR_CODE><ERROR_MESSAGE>ajax asynchronous failure statusText:"
            + response.statusText + "</ERROR_MESSAGE><STACK_TRACE/></ERROR>";

    var xmlDoc = this.parseDocument(errorXML);
    callback(xmlDoc);
};

POSConnection.prototype.setControllerURL = function(controllerURL) {
    this.url = controllerURL;
};

POSConnection.prototype.setPOSName = function(posName) {
    this.posName = posName;
};

POSConnection.prototype.verifyPOSNameExists = function() {
    if (!this.posName) {
        alert("Missing Mandatory Argument, \"POSName\". Request haulted.");
        return false;
    }
    return true;
};

POSConnection.prototype.parseDocument = function(xmlStr) {
    if (!xmlStr)
        xmlStr = "";

    if (document.all) {
        var xmlDoc = new ActiveXObject("Microsoft.FreeThreadedXMLDOM");
        xmlDoc.async = false;
        xmlDoc.loadXML(xmlStr);
        return xmlDoc;
    }

    var parser = new DOMParser();
    return parser.parseFromString(xmlStr, "text/xml");
};