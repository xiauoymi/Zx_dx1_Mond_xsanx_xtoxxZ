function showRootCause(div_id) {
    // hide all the divs
    var isSelected = checkSelectedRootCauseTabForIndividualPerformance("divChange");
    //isSelected = "NONE";
    if (isSelected == "NONE") {
        document.getElementById('root_cause1').style.display = 'none';
        document.getElementById('root_cause2').style.display = 'none';
        document.getElementById('root_cause3').style.display = 'none';
        document.getElementById('root_cause4').style.display = 'none';
        // show the requested div
        document.getElementById(div_id).style.display = 'block';
    }
}

function checkSelectedRootCauseTabForIndividualPerformance(check) {
    var selectedTab = "NONE";
    if (check == "divChange") {
        if (document.getElementById('root_cause1').style.display == 'block') {
            var nodeList = document.getElementById('root_cause1ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause1");
        }
        if (document.getElementById('root_cause2').style.display == 'block') {
            var nodeList = document.getElementById('root_cause2ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause2");
        }
        if (document.getElementById('root_cause3').style.display == 'block') {
            var nodeList = document.getElementById('root_cause3ID').childNodes;
            ////selectedTab = restrictTabMovements(nodeList,"root_cause3");
        }

        if (document.getElementById('root_cause4').style.display == 'block') {
            var nodeList = document.getElementById('root_cause4ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause4");
        }
    }
    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        var nodeList;
        if (document.getElementById('root_cause1ID') != null) {
            nodeList = document.getElementById('root_cause1ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause1");
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause2ID') != null) {
                nodeList = document.getElementById('root_cause2ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause2");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause3ID') != null) {
                nodeList = document.getElementById('root_cause3ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause3");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause4ID') != null) {
                nodeList = document.getElementById('root_cause4ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause4");
            }
        }
    }
    return selectedTab;
}

/**
 * Bhargava 05/20/2008
 * Function to restrict the Tab Movements
 * @param nodeList
 */
function restrictTabMovements(nodeList, divId) {
    var trList = nodeList[0].childNodes;
    var actualList;
    var isChecked = false;
    for (var i = 0; i < trList.length; i++) {
        actualList = trList[i].childNodes;
        for (var j = 0; j < actualList.length; j++) {
            isChecked = actualList[j].childNodes[0].checked;
            if (isChecked == true) {
                return divId;
            } else {
                selectedTab = "NONE";
            }//End of Else
        }//End of Inner For
    }//End of Outer For
    return selectedTab;
}


function showRootCause1(div_id) {
    // hide all the divs
    var isSelected = checkSelectedRootCauseTabForteamPerformance("divChange");
    //isSelected = "NONE";
    if (isSelected == "NONE") {
        document.getElementById('root_cause5').style.display = 'none';
        document.getElementById('root_cause6').style.display = 'none';
        document.getElementById('root_cause7').style.display = 'none';
        // show the requested div
        document.getElementById(div_id).style.display = 'block';
    }
}


function checkSelectedRootCauseTabForteamPerformance(check) {
    var selectedTab = "NONE";
    if (check == "divChange") {


        if (document.getElementById('root_cause5').style.display == 'block') {
            var nodeList = document.getElementById('root_cause5ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause5");
        }
        if (document.getElementById('root_cause6').style.display == 'block') {
            var nodeList = document.getElementById('root_cause6ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause6");
        }
        if (document.getElementById('root_cause7').style.display == 'block') {
            var nodeList = document.getElementById('root_cause7ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause7");
        }

    }
    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        var nodeList;
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause5ID') != null) {
                nodeList = document.getElementById('root_cause5ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause5");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause6ID') != null) {
                nodeList = document.getElementById('root_cause6ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause6");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause7ID') != null) {
                nodeList = document.getElementById('root_cause7ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause7");
            }
        }

    }
    return selectedTab;
}

function showRootCause2(div_id) {
    // hide all the divs
    var isSelected = checkSelectedRootCauseTabManagement("divChange");
    //isSelected = "NONE";
    if (isSelected == "NONE") {
        document.getElementById('root_cause8').style.display = 'none';
        document.getElementById('root_cause9').style.display = 'none';
        document.getElementById('root_cause10').style.display = 'none';
        document.getElementById('root_cause11').style.display = 'none';
        // show the requested div
        document.getElementById(div_id).style.display = 'block';
    }
}


function checkSelectedRootCauseTabManagement(check) {
    var selectedTab = "NONE";
    if (check == "divChange") {

        if (document.getElementById('root_cause8').style.display == 'block') {
            var nodeList = document.getElementById('root_cause8ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause8");
        }
        if (document.getElementById('root_cause9').style.display == 'block') {
            var nodeList = document.getElementById('root_cause9ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause9");
        }
        if (document.getElementById('root_cause10').style.display == 'block') {
            var nodeList = document.getElementById('root_cause10ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause10");
        }
        if (document.getElementById('root_cause11').style.display == 'block') {
            var nodeList = document.getElementById('root_cause11ID').childNodes;
            //selectedTab = restrictTabMovements(nodeList,"root_cause11");
        }


    }
    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        var nodeList;

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause8ID') != null) {
                nodeList = document.getElementById('root_cause8ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause9ID') != null) {
                nodeList = document.getElementById('root_cause9ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause9");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause10ID') != null) {
                nodeList = document.getElementById('root_cause10ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause10");
            }
        }

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause11ID') != null) {
                nodeList = document.getElementById('root_cause11ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause11");
            }
        }

    }
    return selectedTab;
}

function showRootCause3(div_id) {
    // hide all the divs
    var isSelected = checkSelectedRootCauseTabManagement("divChange");
    if (isSelected == "NONE") {
        document.getElementById('root_cause12').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }

    if (isSelected == "NONE") {
        document.getElementById('root_cause13').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }

    if (isSelected == "NONE") {
        document.getElementById('root_cause14').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }
    if (isSelected == "NONE") {
        document.getElementById('root_cause15').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }
    if (isSelected == "NONE") {
        document.getElementById('root_cause16').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }
    if (isSelected == "NONE") {
        document.getElementById('root_cause17').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }

    if (isSelected == "NONE") {
        document.getElementById('root_cause18').style.display = 'none';
        document.getElementById(div_id).style.display = 'block';
    }
}


function checkSelectedRootCauseTolerableFailure(check) {
    var selectedTab = "NONE";
    if (check == "divChange") {
        if (document.getElementById('root_cause12').style.display == 'block') {
            var nodeList = document.getElementById('root_cause12ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause13').style.display == 'block') {
            var nodeList = document.getElementById('root_cause13ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause14').style.display == 'block') {
            var nodeList = document.getElementById('root_cause14ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause15').style.display == 'block') {
            var nodeList = document.getElementById('root_cause15ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause16').style.display == 'block') {
            var nodeList = document.getElementById('root_cause16ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause17').style.display == 'block') {
            var nodeList = document.getElementById('root_cause17ID').childNodes;

        }
    }
    if (check == "divChange") {
        if (document.getElementById('root_cause18').style.display == 'block') {
            var nodeList = document.getElementById('root_cause18ID').childNodes;

        }
    }
    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        var nodeList;

        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause12ID') != null) {
                nodeList = document.getElementById('root_cause12ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause13ID') != null) {
                nodeList = document.getElementById('root_cause13ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause14ID') != null) {
                nodeList = document.getElementById('root_cause14ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause15ID') != null) {
                nodeList = document.getElementById('root_cause15ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause16ID') != null) {
                nodeList = document.getElementById('root_cause16ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause17ID') != null) {
                nodeList = document.getElementById('root_cause17ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }
        if (selectedTab == "NONE") {
            if (document.getElementById('root_cause18ID') != null) {
                nodeList = document.getElementById('root_cause18ID').childNodes;
                //selectedTab = restrictTabMovements(nodeList,"root_cause8");
            }
        }

    }
    return selectedTab;
}
