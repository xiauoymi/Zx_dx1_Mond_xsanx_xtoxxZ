function show_div1(div_id) {
    // hide all the divs
    var isSelected = checkSelectedTab("divChange");
    var isFilter = document.getElementById('isFilter');

    //isSelected = "NONE";
    if (isSelected == "NONE" || isFilter != null) {

        for (var i = 1; i <= 8; i++) {
            if (document.getElementById('comp1_0' + i) != null) {
                document.getElementById('comp1_0' + i).style.display = 'none';
            }
        }

        // show the requested div
        document.getElementById(div_id).style.display = 'block';
    }
}

function checkSelectedTab(check) {
    var selectedTab = "NONE";
    if (check == "divChange") {
        if (document.getElementById('comp1_01').style.display == 'block') {
            var nodeList = document.getElementById('comp1_01ID').childNodes;
            selectedTab = restrictTabMovements(nodeList, "comp1_01");
            //Check for Delivery Info selected
            if (document.forms[0].delivery_info != null) {
                var deliveryInfoData = document.forms[0].delivery_info.value;
                if (deliveryInfoData != '' && deliveryInfoData != ' ') {
                    selectedTab = "comp1_01";
                }
            }
        }
        for (var i = 2; i <= 8; i++) {
            if (document.getElementById('comp1_0' + i) != null) {
                if (document.getElementById('comp1_0' + i).style.display == 'block') {
                    var nodeList = document.getElementById('comp1_0' + i + 'ID').childNodes;
                    selectedTab = restrictTabMovements(nodeList, "comp1_0" + i);
                }
            }
        }//End FOR
    }

    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        var nodeList;
        if (document.getElementById('comp1_01ID') != null) {
            nodeList = document.getElementById('comp1_01ID').childNodes;
            selectedTab = restrictTabMovements(nodeList, "comp1_01");
        }

        for (var i = 2; i <= 8; i++) {
            if (selectedTab == "NONE") {
                if (document.getElementById('comp1_0' + i + 'ID') != null) {
                    nodeList = document.getElementById('comp1_0' + i + 'ID').childNodes;
                    selectedTab = restrictTabMovements(nodeList, "comp1_0" + i);
                }
            }
        }
    }
    return selectedTab;
}

/**
 * Bhargava 05/20/2008
 * Function to restrict the Tab Movements
 * @param nodeList
 */
function restrictTabMovements(nodeList, divId) {
    var trList = nodeList[0].childNodes;
    var actualList;
    var isChecked = false;
    for (var i = 0; i < trList.length; i++) {
        actualList = trList[i].childNodes;
        for (var j = 0; j < actualList.length; j++) {
            isChecked = actualList[j].childNodes[0].checked;
            if (isChecked == true) {
                return divId;
            } else {
                selectedTab = "NONE";
            }//End of Else
        }//End of Inner For
    }//End of Outer For
    return selectedTab;
}

function selectNonconformanceCategories() {
    tab = checkSelectedTab("onLoad");
    if (tab != "NONE") {


        for (var i = 1; i <= 8; i++) {
            if (document.getElementById('comp1_0' + i) != null) {
                document.getElementById('comp1_0' + i).style.display = 'none';
            }
        }
        // show the requested div
        document.getElementById(tab).style.display = 'block';
    }
}