function sendEmailAndChangeStatus(actionItemsCompleteChkBox) {
    if (actionItemsCompleteChkBox.checked) {
        var longTermResponsiblePerson = document.getElementById("longTermResponsiblePerson").value;
        var long_term_corrective_action_due_date = document.getElementById("long_term_corrective_action_due_date").value;
        var longTermCorrectiveActionId = document.getElementById("longTermCorrectiveActionId").value;

        //name, date, comments under Long Term Corrective Action tab are required for the Actions Items Complete checkbox
        if (longTermResponsiblePerson.trim() == '' || long_term_corrective_action_due_date.trim() == '' ||
            longTermCorrectiveActionId.trim() == '') {
            actionItemsCompleteChkBox.checked = false;
            alert("Name, date and comments are required to complete actions.");
        } else {
            if (confirm("Please notify your coordinator and advance the status to Awaiting Evaluation.")) {
                var to = document.getElementById("investigationFindingsPersonEmail").value;
                var subject = document.getElementById("control_number").value;
                var comments = "Please review.";
                SendEmail(to, subject, comments);
            } else {
                actionItemsCompleteChkBox.checked = false;
            }
        }
    }
}

String.prototype.trim = function () {
    return this.replace(/^\s*/, "").replace(/\s*$/, "");
}
