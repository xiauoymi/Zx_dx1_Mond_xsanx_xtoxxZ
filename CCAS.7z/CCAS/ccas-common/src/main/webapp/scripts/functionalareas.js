function hideDeptProcess() {
    if (document.getElementById("deptProcess") != null) {
        document.getElementById('deptProcess').style.display = 'none';
    }
}
function showDeptProcess() {
    if (document.getElementById("deptProcess") != null) {
        document.getElementById('deptProcess').style.display = 'block';
    }
}
function selectFunctionalAreasTab() {
    tab = checkSelectedFunctionalAreaTab("onLoad");
    if (tab != "NONE") {
        for (var i = 1; i <= 11; i++) {
            if (document.getElementById('comp3_0' + i) != null) {
                document.getElementById('comp3_0' + i).style.display = 'none';
            }
        }
        // show the requested div
        document.getElementById(tab).style.display = 'block';
    }
}

function show_div3(div_id) {
    var isSelected = checkSelectedFunctionalAreaTab("divChange");

    if (isSelected == "NONE") {

        if (document.getElementById('comp3_01') != null) {
            document.getElementById('comp3_01').style.display = 'none';
        }


        if (document.getElementById('comp3_02') != null) {
            document.getElementById('comp3_02').style.display = 'none';
        }
        if (document.getElementById('comp3_03') != null) {
            document.getElementById('comp3_03').style.display = 'none';
        }
        if (document.getElementById('comp3_04') != null) {
            document.getElementById('comp3_04').style.display = 'none';
        }
        if (document.getElementById('comp3_05') != null) {
            document.getElementById('comp3_05').style.display = 'none';
        }
        if (document.getElementById('comp3_06') != null) {
            document.getElementById('comp3_06').style.display = 'none';
        }
        if (document.getElementById('comp3_07') != null) {
            document.getElementById('comp3_07').style.display = 'none';
        }
        if (document.getElementById('comp3_08') != null) {
            document.getElementById('comp3_08').style.display = 'none';
        }
        if (document.getElementById('comp3_09') != null) {
            document.getElementById('comp3_09').style.display = 'none';
        }
        if (document.getElementById('comp3_10') != null) {
            document.getElementById('comp3_10').style.display = 'none';
        }

        if (document.getElementById('comp3_11') != null) {
            document.getElementById('comp3_11').style.display = 'none';
        }

        // show the requested div
        document.getElementById(div_id).style.display = 'block';
    }
}

function checkSelectedFunctionalAreaTab(check) {
    var selectedTab = "NONE";

    //After Submitting the complaint, the selected category is displayed
    if (check == "onLoad") {
        for (var i = 1; i <= 11; i++) {
            if (selectedTab == "NONE") {
                if (document.getElementById('comp3_0' + i + 'ID') != null) {
                    nodeList = document.getElementById('comp3_0' + i + 'ID').childNodes;
                    selectedTab = restrictTabMovements(nodeList, "comp3_0" + i);
                    if (selectedTab != 'NONE') break;
                }
            }
        }
    }
    return selectedTab;
}

/**
 * Bhargava 05/20/2008
 * Function to restrict the Tab Movements
 * @param nodeList
 */
function restrictTabMovements(nodeList, divId) {
    var trList = nodeList[0].childNodes;
    var actualList;
    var isChecked = false;
    for (var i = 0; i < trList.length; i++) {
        actualList = trList[i].childNodes;
        for (var j = 0; j < actualList.length; j++) {
            isChecked = actualList[j].childNodes[0].checked;
            if (isChecked == true) {
                return divId;
            } else {
                selectedTab = "NONE";
            }//End of Else
        }//End of Inner For
    }//End of Outer For
    return selectedTab;
}

function selectFunctionalAreas() {
    tab = checkSelectedFunctionalAreaTab("onLoad");
    if (tab != "NONE") {
        for (var i = 1; i <= 11; i++) {
            if (document.getElementById('comp3_0' + i) != null) {
                document.getElementById('comp3_0' + i).style.display = 'none';
            }
        }
        // show the requested div
        document.getElementById(tab).style.display = 'block';
    }
}