// Common Javascript functions.
// --------------------------------------------------
// Each page need to have this method customized to get data from People Picker Utility.
// Do not change anything other than the html element ids.
//	arrPeopleData
//		index - 0 : party id
//		index - 1 : last name
//		index - 2 : first name
//		index - 3 : middle name
//		index - 4 : user id
//		index - 5 : phone id
//		index - 6 : email
//
// ---------------------------------------------------
var usernameConrolId = "";
var fullnameConrolId = "";
var emailConrolId = "";
function setValuesFromPeoplePicker(arrPeopleData)
{
    if (!usernameConrolId == "")
        document.getElementById(usernameConrolId).value = arrPeopleData[4];
    if (!fullnameConrolId == "")
        document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
    if (!emailConrolId == "")
        document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
    document.getElementById(fullnameConrolId).focus();
}

function setPeoplePickerControlIds(usrname, fullname, email) {
    usernameConrolId = usrname;
    fullnameConrolId = fullname;
    emailConrolId = email;
}

function strtrim(s) {
    //Match spaces at beginning and end of text and replace with null strings
    return s.replace(/^\s+/, '').replace(/\s+$/, '');
}

//Bhargava 04/14/2008
//Function to set the region drop down based on the business selected
function setRegionDropdown(businessSelectBox) {
    try {

        var pos = new POSConnection("Mcas_BusinessRegionPOS");

        //        pos.setControllerURL('/mcas/nsServlet/ajaxController');
        pos.setControllerURL('/mcas/nsServlet/businessRegionPOS');

        if (businessSelectBox != null) {
            var businessId = businessSelectBox.options[businessSelectBox.selectedIndex].value;

            if (businessId != null) {
                var request = '<Business><BusinessId>' + businessId + '</BusinessId></Business>';
                pos.send(request, populateRegionDropdown);
            }

        }
    } catch(exception) {
        alert(exception.description);
    }
}
//Method to Populate Material Group Drop down based on Crop Selection
//Bhargava : 04-14-08
function populateRegionDropdown(xmlDoc) {
    if (isErrors(xmlDoc)) {
        alert('Error');
    } else {

        var regions = xmlDoc.getElementsByTagName('Region');
        var regionSelect;
        var regionList = document.getElementById("regionId").childNodes;
        for (var i = 0; i < regionList.length; i++) {
            var regionNodeType = regionList[i].nodeType;
            if (regionNodeType == 1) {
                regionSelect = regionList[i];
            }
        }
        removeAllOptions(regionSelect);
        var regionId;
        for (var i = 0; i < regions.length; i++) {

            if (regions[i].childNodes[0].firstChild == null) {
                regionId = '';
            } else {
                regionId = regions[i].childNodes[0].firstChild.nodeValue;
            }
            var regionDescription = regions[i].childNodes[1].firstChild.nodeValue;
            var docOption = document.createElement("OPTION");
            docOption.text = regionDescription;
            docOption.value = regionId;
            regionSelect.options.add(docOption);
            document.forms[0].selectedRegion.value = docOption.value;
        }
    }
}

function isErrors(xmlDoc) {

    try {
        var string = (new XMLSerializer()).serializeToString(xmlDoc);
        alert(string);
        var error = xmlDoc.selectNodes("/ERROR/ERROR_MESSAGE");
        return error.length > 0;
    } catch(ex) {
        return false;
        //Ignore...Firefox throws exception
    }
}

function removeAllOptions(selectbox)
{
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}

function checkAndSetRegionDropDown() {
    var selectBox = document.forms[0].selectedBusiness;
    var regionId;
    if (selectBox != null) {
        setRegionDropdown(selectBox);
    }
}

function getRegionsForSelectedBusiness(selectedBusiness) {
    var businessIds = "";
    if (selectedBusiness != null) {
        for (var i = 0; i < selectedBusiness.options.length; i++) {
            if (selectedBusiness.options[i].selected && selectedBusiness.options[i].value > 0) {
                businessIds += selectedBusiness.options[i].value;
                businessIds += ":";
            }
        }
        if (businessIds == null || businessIds == "") {
            alert('Please select Business.');
            return;
        }
    }
    setRegionDropdownForSelectedBusiness(businessIds);
}

//Bhargava 04/14/2008
//Function to set the region drop down based on the business selected
function setRegionDropdownForSelectedBusiness(businessIds) {
    try {
        var pos = new POSConnection("Mcas_BusinessRegionPOS");
        //        pos.setControllerURL('/mcas/nsServlet/ajaxController');
        pos.setControllerURL('/mcas/nsServlet/businessRegionPOS');
        if (businessIds != null) {
            var request = '<Business><BusinessId>' + businessIds + '</BusinessId></Business>';
            pos.send(request, populateRegionDropdown);
        }
    } catch(exception) {
        alert(exception.description);
    }
}

function displaySelectedTabHidingTheRest(element, divId) {
    var i = 0;
    var divIds = new Array("root_cause12", "root_cause13", "root_cause14", "root_cause15", "root_cause16", "root_cause17", "root_cause18", "root_cause19");
    var parent = element.parentElement.parentElement;
    var numberOfChildren = parent.childNodes.length;
    for (i = 0; i < numberOfChildren; i++) {
        if (parent.childNodes[i] == element.parentElement) {
            //            parent.childNodes[i].id = 'tab_on';
            element.display = "block";
            document.getElementById(divId).style.display = 'block';
        } else {
            //            parent.childNodes[i].id = '';
        }
    }

    var display = "none";
    for (i = 0; i < divIds.length; i++) {
        if (divIds[i] === divId) {
            display = "block";
        } else {
            display = "none";
        }

        document.getElementById(divIds[i]).style.display = display;
    }
}

function getActiveTabAndRelatedChildren(element) {
    var tabName = element.innerText;
    var contextPath = document.getElementById("contextPath").value;
    getDataByXML(contextPath + "/servlet/tabInformation?tabName=" + tabName + "&type=1", populateTabField);
}

function populateTabField(o) {
    var xmlDoc = o.responseXML;
    var count = xmlDoc.getElementsByTagName('issueType').length;
    var table = document.getElementById("issueTypes");
    table.innerHTML = '';
    var trElement = document.createElement('tr');
    var i = 0;
    if (count > 0) {
        for (i = 0; i < count; i++) {
            var tdElement = document.createElement('td');
            var node = "issue/id";
            var id = xmlDoc.getElementsByTagName(node)[i].text;
            node = "issue/description";
            var description = xmlDoc.getElementsByTagName(node)[i].text;
            var checkbox = document.createElement('input');
            checkbox.setAttribute("type", "checkbox");
            checkbox.setAttribute("id", id);
            checkbox.setAttribute("name", description);
            tdElement.appendChild(checkbox);
            tdElement.appendChild(document.createTextNode(description));
        }
    }
    trElement.appendChild(tdElement);
}

function passedOverDueValidations(containtmentActionTextInternalized, longTermCorrectiveActionTextInternalized, rootCauseTextInternalized) {
    var containmentActionText = document.forms[0].containmentActionId.value;
    
    if (isDataEmpty(containmentActionText) == true) {
        alert(containtmentActionTextInternalized);
        return false;
    }
    if (isDataEmpty(longTermCorrectiveActionTextInternalized) == true) {
        alert(longTermCorrectiveActionTextInternalized);
        return false;
    }
    if (isDataEmpty(rootCauseTextInternalized) == true) {
        alert(rootCauseTextInternalized);
        return false;
    }
    return true;
}

function isDataEmpty(data) {
    if (data == null || data == '') {
        return true;
    }
    if (strtrim(data).length == 0) {
        return true;
    }
    return false;
}

function checkShortcut()
{
    if (event.keyCode == 8 || event.keyCode == 13)
    {
        var regExInput = /INPUT/;
        var regExTextarea = /TEXTAREA/;

        if (event.srcElement.readOnly) return false;

        return regExInput.test(event.srcElement.tagName) || regExTextarea.test(event.srcElement.tagName);
    }
}


function disableElements(e) {
    if (e != null) {
        for (var i = 0; i < e.length; i++) {
            if (!(e[i].tagName.toUpperCase() == "INPUT" || e[i].tagName.toUpperCase() == "TEXTAREA")
                    || e[i].type.toUpperCase() == 'BUTTON' || e[i].type.toUpperCase() == 'SUBMIT') {
                e[i].setAttribute('disabled', true);
            }
            else {
                e[i].setAttribute('readOnly', true);
            }
        }
    }
}

function disableLinks(e) {
    if (e != null) {
        for (var i = 0; i < e.length; i++) {
            e[i].setAttribute('onclick', 'return false;')
        }
    }
}

function enableElement(e) {
    if (e != null && e.tagName != null) {
        if (!(e.tagName.toUpperCase() == "INPUT" || e.tagName.toUpperCase() == "TEXTAREA")
                || e.type.toUpperCase() == 'BUTTON' || e.type.toUpperCase() == 'SUBMIT') {
            e.setAttribute('disabled', false);
        }
        else {
            e.setAttribute('readOnly', false);
        }
    }
}

function enableLink(e) {
    if (e != null) {
        e.setAttribute('onclick', 'return true;');
    }
}

function enableLinks(e) {
    if (e != null) {
        for (var i = 0; i < e.length; i++) {
            e[i].setAttribute('onclick', 'return true;');
        }
    }
}

function enableElements(e) {
    if (e != null) {
        for (var i = 0; i < e.length; i++) {
            if (!(e[i].tagName.toUpperCase() == "INPUT" || e[i].tagName.toUpperCase() == "TEXTAREA")
                    || e[i].type.toUpperCase() == 'BUTTON' || e[i].type.toUpperCase() == 'SUBMIT') {
                e[i].setAttribute('disabled', false);
            }
            else {
                e[i].setAttribute('readOnly', false);
            }
        }
    }
}
