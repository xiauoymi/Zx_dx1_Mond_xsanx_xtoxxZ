function loadPeoplePickerWindow(path, field) {
    document.getElementById("fieldToPopulate").value = field;
    document.getElementById("searchFields").style.visibility = "visible";
    document.getElementById("firstName").value = "";
    document.getElementById("lastName").value = "";
    document.getElementById("userId").value = "";
}

function moveContents(src, dest) {
    var i = 0;
    var srcSelection = document.getElementById(src);
    var length = srcSelection.options.length;
    if (length === 0) {
        alert("Please populate selection drop down before moving contents.");
        return;
    }

    var destSelection = document.getElementById(dest);
    var dstLength = 0;
    if (destSelection.options != null) {
        dstLength = destSelection.options.length;
    }
    var selectedItems = 0;
    for (i = 0; i < length; i++)
    {
        if (!srcSelection.options[i].selected) {
        } else {
            var value = srcSelection.options[i].value;
            var text = srcSelection.options[i].text;
            selectedItems++;
            destSelection.options[dstLength++] = new Option(text, value, false, false);
        }
    }

    if (selectedItems > 0 && selectedItems == srcSelection.options.length) {
        srcSelection.options.length = 0;
    } else {
        for (i = 0; i < srcSelection.options.length; i++) {
            if (srcSelection.options[i] != null && srcSelection.options[i].selected) {
                srcSelection.remove(i);
                i--;
            }
        }
    }
}

function populateEmailFieldsInParent(fieldToPopulate) {
    var toInput = document.getElementById(document.getElementById("fieldToPopulate").value);
    var emailField = document.getElementById("outputEmail");
    if (emailField.options.length == 0) {
        alert("Please select entries to populate in the email field\n");
        return;
    }
    var i = 0;
    var toString = toInput.value;
    for (i = 0; i < emailField.options.length; i++) {
        toString += emailField.options[i].text + "@monsanto.com;";
    }
    toInput.value = toString;
    activateDeactiveFormFields("hidden");
    document.getElementById("inputEmail").options.length = 0;
    document.getElementById("outputEmail").options.length = 0;
}

function activateDeactiveFormFields(hideOrShow) {
    document.getElementById("searchFields").style.visibility = hideOrShow;
    document.getElementById("displaySearchResults").style.visibility = hideOrShow;
    document.getElementById("inputEmail").style.visibility = hideOrShow;
    document.getElementById("outputEmail").style.visibility = hideOrShow;
    document.getElementById("moveRight").style.visibility = hideOrShow;
    document.getElementById("moveLeft").style.visibility = hideOrShow;
    document.getElementById("submitSelection").style.visibility = hideOrShow;
    document.getElementById("cancelSelection").style.visibility = hideOrShow;
}

function populateDropDownForInputSelect(inputSelect) {
    document.getElementById("noSearchResults").display == "none";
    activateDeactiveFormFields("visible");
    var url = "";
    var parameters = "";
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var userId = document.getElementById("userId").value;
    if (firstName === "" && lastName === "" && userId === "") {
        alert("Please enter a search criteria to find users");
        return;
    }
    parameters = "firstName=" + firstName;
    ;
    parameters += "&lastName=" + lastName;
    parameters += "&userId=" + userId;
    var contextPath = document.getElementById("urlContextPath").value;
    url += contextPath + "/servlet/searchUserEmail?" + parameters;

    var callBackAfterGettingResultsBack = {
        success: function(o) {
            this.cache = null;
            populateDataFromResponse(inputSelect, o);
        },
        failure: function(o) {
            alert("Unable to connect to People Picker Service.");
            return;
        },
        timeout: 20000,
         cache:false//20 seconds
    };
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            callBackAfterGettingResultsBack);
}

function populateDataFromResponse(inputSelect, output) {
    var xmlDoc = output.responseXML;
    var count = xmlDoc.getElementsByTagName('emailAddress').length;
    if (count > 0) {
        var inputSelectDropDown = document.getElementById(inputSelect);
        inputSelectDropDown.options.length = 0;
        var i = 0;
        for (i = 0; i < count; i++) {
            var emailAddress = xmlDoc.getElementsByTagName('emailAddress')[i].text;
            inputSelectDropDown.options[i] = new Option(emailAddress, emailAddress, false, false);
        }
        document.getElementById("selectPeople").style.visibility = "visible";
    } else {
        document.getElementById("noSearchResults").display == "";
        document.getElementById("noSearchResults").style.visibility = "visible";
        document.getElementById("displaySearchResults").style.visibility = "hidden";
        activateDeactiveFormFields("hidden");
        return;
    }
    document.getElementById("displaySearchResults").style.visibility = "visible";
}

function captureEnter(e) {
    var charCode = e.keyCode;
    var submitSelection = document.getElementById("submitSearch");

    if (charCode == 13) { //if generated character code is equal to ascii 13 (if enter key)
        submitSelection.click();
        return false;
    }
    else {
        return true;
    }
}


