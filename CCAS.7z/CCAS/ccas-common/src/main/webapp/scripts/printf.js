//|---------------------------------------------------------------------------
//| 1. THIS CODE REQUIRES:
//|    a. This to be added to head of web page
//|        <script Language="JavaScript" src="printf.js'"></script>
//|
//|    b. A <div id = 'start_prnt'> wrapped around the content to be printed but inside
//|       the body tag needs to be added
//|           ex:  <body><div id = 'start_prnt'>Content</div></body>
//|
//| 2. THIS CODE ASSUMES:
//|    a. "tab_on" is the id used to turn on a tab within each div   ex: <div id=""tab_on"></div>
//|
//| 3. LOOKS BETTER BUT NOT REQUIRED:
//|    a. For the sake of appearance it is helpful to use &nbsp; between <textarea> tags
//|       ex: <textarea name='' rows=' ' cols=''>&nbsp;<testarea>
//|
//| 4. STYLE SHEET:
//|    a. No changes to the style sheet are required, but the style sheet(s) must be
//|       hard coded into the javascript function printFriendly - the second document.write line
//|----------------------------------------------------------------------------

var win = null;

//can trim this down - offers several options to locate the new window
function doOpenWin(mypage, myname, w, h, resize, scroll, pos) {
    if (pos == "random") {
        LeftPosition = (screen.availWidth) ? Math.floor(Math.random() * (screen.availWidth - w)) : 50;
        TopPosition = (screen.availHeight) ? Math.floor(Math.random() * ((screen.availHeight - h) - 75)) : 50;
    }
    if (pos == "center") {
        LeftPosition = (screen.availWidth) ? (screen.availWidth - w) / 2 : 50;
        TopPosition = (screen.availHeight) ? (screen.availHeight - h) / 2 : 50;
    }
    if (pos == "default") {
        LeftPosition = 50;
        TopPosition = 50;
    }
    if (pos == "bottom") {
        LeftPosition = (screen.availWidth) ? ((screen.availWidth - w) - 25) : 50;
        TopPosition = (screen.availHeight) ? ((screen.availHeight - h) - 60) : 50;
    }
    else if ((pos != "center" && pos != "random" && pos != "default" && pos != "bottom") || pos == null) {
        LeftPosition = 0;
        TopPosition = 20;
    }
    settings = 'width=' + w + ',height=' + h + ',top=' + TopPosition + ',left=' + LeftPosition + ',scrollbars=' +
               scroll + ',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=' + resize;
    win = window.open(mypage, myname, settings);
    if (!win.focus) {
        win.focus();
    }
}
function printFriendly(mytitle, mypage, myname, w, h, resize, scroll, pos, appName) {
    if (appName == null || appName == undefined) {
        appName = document.getElementById('contextPath').value;
    }
    var jStart = document.getElementById("start_prnt");
    if (mypage == "saveAndSubmit") {
        var myjHtml = walkChildNodesForObjectMail(jStart);
        if (mytitle == "COMPLAINT" && appName == 'mcas') {
            //Variety Batch Section
            if (myjHtml != null && (myjHtml.indexOf("<>") != -1 || myjHtml.indexOf("< >") != -1)) {
                myjHtml = myjHtml.replace(/<>/g, "");
                myjHtml = myjHtml.replace(/< >/g, "");
            }
            var complaintBatchSubString = "";
            var complaintBatchStart = myjHtml.indexOf("complaint_batch");
            var complaintBatchEnd = myjHtml.indexOf("endComplaintBatchId");
            if (complaintBatchStart != -1 && complaintBatchEnd != -1) {
                complaintBatchSubString = "'" + myjHtml.substring(complaintBatchStart, complaintBatchEnd) +
                                          "endComplaintBatchId'/>";
            }

            //Initial Section
            var initialSection = myjHtml.substring(0, complaintBatchStart);
            //Problem Description Section
            var problemDescStart = myjHtml.indexOf("problemDescId");
            var problemDescEnd = myjHtml.indexOf("endProblemDescId");
            var problemDescriptionSubString = "";
            if (problemDescStart != -1 && problemDescEnd != -1) {
                problemDescriptionSubString = "<div id='" + myjHtml.substring(problemDescStart, problemDescEnd) +
                                              " endProblemDescId'/>";
            }
            //Complaint Issues and Audit Areas section
            var complaintAndAuditStart = myjHtml.indexOf("nonconformanceCategoriesAndAuditDiv");
            var nonconformanceCategoriesAndAuditSection = "<div id='" +
                                                          myjHtml.substring(complaintAndAuditStart, problemDescStart);
            var plantingInfoStart = myjHtml.indexOf("plantingAndOtherDiv");
            var plantingInfoEnd = myjHtml.indexOf("submitResetDiv");
            if (plantingInfoEnd == -1) plantingInfoEnd = myjHtml.indexOf("<div id='attach_file_div");
            var finalSection = myjHtml.substring(plantingInfoStart, plantingInfoEnd);

            myjHtml = initialSection + complaintBatchSubString + problemDescriptionSubString +
                      nonconformanceCategoriesAndAuditSection + finalSection;
        }
        document.forms[0].printPreviewSrc.value = "<html><head>" +
                                                  "\n<style type='text/css'>\n<!-- body \n {  " +
                                                  "margin: 5px;  font: 100% verdana, arial, sans-serif;} \n" +
                                                  "body#left_nav{  margin: 0px;  padding: 0px;  background-color: #CCCCCC;}\n" +
                                                  "body#complaint{  margin-top: 0px;  padding: 0px;  font: 100% verdana, arial, sans-serif; }\n" +
                                                  "body#admin{  margin-top: 0px;  padding: 0px;  font: 100% verdana, arial, sans-serif; }\n" +
                                                  "body#header{  margin: 0px;  padding: 0px;  background-color: #003366; }\n" +
                                                  "div#header_sub{  margin: 0px;  padding: 0px;  background-color: #CCCCCC;  width: 100%; }\n" +
                                                  "body#top_btn{  margin: 0px;  padding: 0px;  background-color: #FFFFFF; }\n" +
                                                  "body#ftr_bkgd{  margin: 0px;  padding: 0px;  background-color: #003366; }\n" +
                                                  "table{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                                                  "hr{  height: 1px;  color: #CCCCCC;  clear: both;}br{  line-height: 11px; }\n" +
                                                  "div{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                                                  ".pg_width{  width: 100%; }\n" +
                                                  "input{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                                                  "select{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                                                  "textarea{  font-family: Arial, Helvetica, sans-serif;  font-size: 11px; }\n" +
                                                  "a:link{  color: #000000;  text-decoration: underline; }\n" +
                                                  "a:visited{  color: #000000;  text-decoration: underline; }\n" +
                                                  "a:hover{  color: #000000;  text-decoration: none; }\n" +
                                                  "ul#tabnav {  font: 11px arial, sans-serif;  list-style-type: none;  padding-bottom: 19px;  border-bottom: 1px solid #999999;  margin: 0px; }\n" +
                                                  "ul#tabnav li {  float: left;  height: 16px;  background-color: #EAEAEA;  margin: 0px 2px 0px 2px;  border: 1px solid #999999; }\n" +
                                                  "div#audit_01 li#tab_on, div#audit_02 li#tab_on, div#audit_03 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#comp_01 li#tab_on, div#comp_02 li#tab_on, div#comp_03 li#tab_on, div#comp_04 li#tab_on, div#comp_05 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#cpar_ci_01 li#tab_on, div#cpar_ci_02 li#tab_on, div#cpar_ci_03 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#comp1_01 li#tab_on, div#comp1_02 li#tab_on, div#comp1_03 li#tab_on, div#comp1_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#cpar_01 li#tab_on, div#cpar_02 li#tab_on, div#cpar_03 li#tab_on, div#cpar_04 li#tab_on, div#cpar_05 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF;}div#comp2_01 li#tab_on, div#comp2_02 li#tab_on, div#comp2_03 li#tab_on, div#comp2_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#stop_01 li#tab_on, div#stop_02 li#tab_on, div#stop_03 li#tab_on, div#stop_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#stop1_01 li#tab_on, div#stop1_02 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#car_01 li#tab_on, div#car_02 li#tab_on, div#car_03 li#tab_on, div#car_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "div#par_01 li#tab_on, div#par_02 li#tab_on, div#par_03 li#tab_on, div#par_04 li#tab_on {  border-bottom: 1px solid #F2F8FF;  background-color: #F2F8FF; }\n" +
                                                  "#tabnav a, #tabnav2 a, #tabnav3 a {  float: left;  display: block;  color: #000000;  text-decoration: none;  padding: 2px 4px 2px 4px; }\n" +
                                                  "#tabnav a:hover, #tabnav2 a:hover, #tabnav3 a:hover {  background: #CCCCCC; }\n" +
                                                  ".report_table{  overflow: scroll }\n" +
                                                  ".comments_cell{  border-bottom: 1px solid #999999;  border-left: 1px solid #999999;  border-right: 1px solid #999999;  padding: 8px;  background-color: #F2F8FF; }\n" +
                                                  ".rgt_align{  text-align: right;  padding-left: 1px; }\n" +
                                                  ".form_head{  text-align: center;  font-weight: bold;  padding-bottom: 10px; }\n" +
                                                  ".form_align{  padding-left: 4px;  padding-right: 10px;  padding-top: 1px;  padding-bottom: 1px; }\n" +
                                                  "#seed_info{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 700px; }\n" +
                                                  "#error_info{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 700px; }\n" +
                                                  "#error_info_for_popup{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 350px; }\n" +
                                                  "#brand{  border: 1px solid #999999;  margin: 0px;  padding: 5px;  width: 205px;  float: left;  background-color: #F2F8FF;/*overflow: scroll;*/  height: 100px; }\n" +
                                                  "#batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 350px;  /*width: 555px;*/  float: left;  background-color: #F2F8FF;  overflow: scroll;  height: 100px; }\n" +
                                                  "#complaint_batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                                                  "#complaint_affina{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                                                  "#stopsale_batch{  border: 1px solid #999999;  margin-left: 5px;  padding: 5px;  width: 600px;  float: left;  background-color: #F2F8FF;  height: 100px; }\n" +
                                                  "#findings{  border: 1px solid #999999;  margin-left: 2px;  padding: 5px;  width: 650px;  float: left;  background-color: #FFFFFF;  overflow: scroll;  height: 100px; }\n" +
                                                  "#attach_file_div{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 700px;  background-color: #F2F8FF;  clear: both; }\n" +
                                                  "#button{  float: left;  padding-left: 5px; }\n" +
                                                  ".tbl_pad{  padding-left: 3px;  padding-right: 3px; }\n" +
                                                  ".div_pad{  width: 100%;  padding-left: 3px;  padding-right: 3px; }\n" +
                                                  "#gen_info{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 700px;  background-color: #FBE7BE;  clear: both; }\n" +
                                                  "#add_edit_user_div{  border: 1px solid #CCCCCC;  margin: 3px;  padding: 5px;  width: 300px;  background-color: #FBE7BE;  clear: both; }\n" +
                                                  "#add_attachment_div{  border: 1px solid #CCCCCC;  margin: 0px;  padding: 5px;  width: 350px;  background-color: #FBE7BE;  clear: both; }\n" +
                                                  "h1{  font-size: 14px;  margin: 0px;  color: #003366; }\n" +
                                                  "h2{  font-size: 10px;  margin: 0px;  color: #003366; }\n" +
                                                  ".hdr_rule{  background-color: #003366;  height: 1px; }\n" +
                                                  ".date{  text-align: right;  color: #003366; }\n" +
                                                  ".foot{  font-size: 9px;  text-align: center;  color: #FFFFFF; }\n" +
                                                  ".footer{  font-size: 11px;  vertical-align: middle;  color: #FFFFFF; }\n" +
                                                  "#list_hdr{  background-color: #597A9B;  padding: 2px;  padding-left: 4px;  color: #FFFFFF;  font-weight: bold; }\n" +
                                                  "#list_hdr a:link{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  "#list_hdr a:visited{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  "#list_hdr a:active{  color: #FFFFFF;  text-decoration: none; }\n" +
                                                  "#list_hdr a:hover{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  "#list_foot{  background-color: #597A9B;  padding: 2px;  padding-left: 4px;  color: #FFFFFF;  font-weight: bold;  text-align: center; }\n" +
                                                  "#list_foot a:link{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  "#list_foot a:visited{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  "#list_foot a:active{  color: #FFFFFF;  text-decoration: none; }\n" +
                                                  "#list_foot a:hover{  color: #FFFFFF;  text-decoration: underline; }\n" +
                                                  ".cn_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".date_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".name_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".status_col{  text-align: center;  vertical-align: middle;  padding: 1px; }\n" +
                                                  ".region_col{  text-align: center;  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".allLocation_col{  text-align: left;  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".allVarietyBatchAdmin_col{  text-align: left;  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".role_col{  text-align: center;  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".claim_col{  vertical-align: middle;  padding-left: 4px; }\n" +
                                                  ".edit_col{  text-align: center;  vertical-align: middle;  padding-top: 2px;  padding-bottom: 2px; }\n" +
                                                  ".delete_col{  text-align: center;  vertical-align: middle;  padding-top: 2px;  padding-bottom: 2px; }\n" +
                                                  "tr#b{  background-color: #EAEAEA; }\n" +
                                                  "tr#c{  background-color: #FBE7BE; }\n" +
                                                  ".comp_top_nav{  padding-bottom: 5px;  vertical-align: middle;  width: 700px; }\n" +
                                                  ".top_nav_return{  text-align: right;  width: 100%; }\n" +
                                                  ".tab_spacer{  width: 35px; }\n" +
                                                  ".filterLabel {  border:0;  background:#FBE7BE; }\n" +
                                                  ".userIdLabelForAddScreen {  background:#FBE7BE; }\n" +
                                                  ".locationIdLabel {  background:#FBE7BE; }\n" +
                                                  " -->\n</style>\n" +
                                                  "</head>\n<body width='680' margin='0' '>" + myjHtml + "\n</body>\n</html>";

    } else {
        //open window
        var jHtml = walkChildNodes(jStart);
        doOpenWin(mypage, myname, w, h, resize, scroll, pos);
        if (win != null) {
            win.document.open('text/html');
            win.document.write("<html><head><title>" + mytitle + "</title>");
            win.document.write("<link rel='stylesheet' type='text/css' href='css/site.css' >");
            win.document.write("</head><body width='680' margin='0' onload='window.print()'>");
            win.document.write(jHtml);
            win.document.write("</body></html>");
            win.document.close();
            win.focus();
        }
    }
    return;

}

function walkChildNodesForObjectMail(jObjRef) {
    var jObj;
    if (jObjRef) {
        if (typeof jObjRef == "string") {
            jObj = document.getElementById(jObjRef);
        }
        else {
            jObj = jObjRef;
        }
    }
    else {
        jObj = (document.body.parentElement) ? document.body.parentElement : document.body.parentNode;
    }
    var jEndtag = "";
    var jOutput = "";
    var i, jGroup, jTxt;
    jGroup = jObj.childNodes;
    for (i = 0; i < jGroup.length; i++) {
        jGetChild = true;
        jEndtag = "";

        switch (jGroup[i].nodeType) {
            case 1:
                var jThisStr = jGroup[i].tagName;
                jThisStr = jThisStr.toLowerCase();
                if (jGroup[i].type == "textarea") {
                    jThisStr = "p name='" + jGroup[i].name + "' style='padding: 5px 5px 5px 5px;border: 1px solid #003366;background-color: #FFF;'";
                }
                // remove javascript and images
                if (jThisStr == "script" || jThisStr == "img") {
                    break;
                }
                // remove all buttons and hidden input
                if (jThisStr == "input" &&
                    (jGroup[i].type == "button" || jGroup[i].type == "submit" || jGroup[i].type == "reset" ||
                     jGroup[i].type == "hidden")) {
                    break;
                }
                // code assumes that "tab_on" is the id used for tab divs
                if (jThisStr == "a" && jGroup[i].parentNode.tagName.toLowerCase() == "li" &&
                    jGroup[i].parentNode.id != "tab_on") {
                    jGetChild = false;
                    break;
                }
                if (jThisStr == "li" && jGroup[i].id != "tab_on") {
                    jGetChild = false;
                    break;
                }

                if (jThisStr == "input" && jGroup[i].type == "text") {
                    jOutput = "<label";
                } else {
                    jOutput += "<" + jThisStr;
                }
                if (jThisStr == "table") {
                    jOutput += " cellspacing=0 cellpadding=0 ";
                }
                if (jGroup[i].type != "textarea") {
                    jOutput += (jGroup[i].id) ? " id='" + jGroup[i].id + "'" : "";
                    jOutput += (jGroup[i].name) ? " name='" + jGroup[i].name + "'" : "";
                    jOutput += (jGroup[i].colSpan) ? " colspan=" + jGroup[i].colSpan : "";
                    jOutput += (jGroup[i].size) ? " size=" + jGroup[i].size : "";
                    jOutput += (jGroup[i].type) ? " type='" + jGroup[i].type + "'" : "";
                    jOutput += (jGroup[i].className) ? " class='" + jGroup[i].className + "'" : "";
                    jOutput += (jGroup[i].border) ? " border=" + jGroup[i].border : "";
                    //this trys to force the width of none div elements to 650px
                    if (jGroup[i].width > 650) {
                        jOutput += " width=650";
                    }
                    else {
                        jOutput += (jGroup[i].width) ? " width=" + jGroup[i].width : "";
                    }
                }
                //this trys to force the width of divs to 650px
                if (jThisStr == "div" && jGroup[i].id == "error_info") {
                    continue;
                }
                if (jGroup[i].id == "headerId") {
                    continue;
                }    //Skip the Maintenance part
                if (jThisStr == "div" && jGroup[i].clientWidth > 650) {
                    jOutput += " style='width:650;overflow: visible;'";
                }
                else if (jThisStr == "div") {
                    jOutput += " style='overflow: visible;' ";
                }
                if (jThisStr == "input" && jGroup[i].type == "checkbox" && jGroup[i].checked) {
                    jOutput += " checked ";
                }
                //if (jThisStr == "select" || (jThisStr == "input" && (jGroup[i].type == "checkbox" || jGroup[i].type == "text"))){jOutput +=" disabled ";}
                if (jThisStr == "input" && jGroup[i].type == "text") {
                    var outputVal = jGroup[i].value;
                    if (outputVal == '') {
                        jOutput += ">[    ]</label>";
                    } else {
                        jOutput += ">[" + outputVal + "]</label>";
                    }
                } else {
                    if (jThisStr == "select" || (jThisStr == "input" && jGroup[i].type == "text")) {
                        jOutput += " disabled ";
                    }
                    jOutput += ">";
                }

                if (jThisStr == "select") {
                    jGetChild = false;
                    var selectedText;
                    if (jGroup[i].selectedIndex < 0) {
                        selectedText = '';
                    } else {
                        selectedText = jGroup[i].options(jGroup[i].selectedIndex).text;
                    }
                    jOutput += "<option selected>" + selectedText + "</option>";
                }
                if (jThisStr != "input") {
                    if (jGroup[i].type == "textarea") {
                        jEndtag = "</p>";
                    } else {
                        jEndtag = "</" + jThisStr + ">";
                    }
                }
                break;
            case 3:
                var jTxtLen = jGroup[i].nodeValue.length;
                jTxt = jGroup[i].nodeValue.substr(0, jTxtLen);
                jOutput += jTxt.replace(/[\r\n]/g, "<cr>");
                break;
            case 8:
                break;

            default:
                //will leave a number on the page which is a nodeType
                jOutput += jGroup[i].nodeType;
        }
        if (jGetChild && jGroup[i].childNodes.length > 0) {
            jOutput += walkChildNodesForObjectMail(jGroup[i]);
        }
        jOutput += jEndtag;
    }
    return jOutput;
}

function walkChildNodes(jObjRef) {
    var jObj;
    if (jObjRef) {
        if (typeof jObjRef == "string") {
            jObj = document.getElementById(jObjRef);
        }
        else {
            jObj = jObjRef;
        }
    }
    else {
        jObj = (document.body.parentElement) ? document.body.parentElement : document.body.parentNode;
    }
    var jEndtag = "";
    var jOutput = "";
    var i, jGroup, jTxt;
    jGroup = jObj.childNodes;

    for (i = 0; i < jGroup.length; i++) {
       jGetChild = true;
        jEndtag = "";
        switch (jGroup[i].nodeType) {
            case 1:
                var jThisStr = jGroup[i].tagName;
                jThisStr = jThisStr.toLowerCase();
                if (jGroup[i].type == "textarea") {
                    jThisStr = "p style='padding: 5px 5px 5px 5px;border: 1px solid #003366;background-color: #FFF;'";
                }
                // remove javascript and images
                if (jThisStr == "script" || jThisStr == "img") {
                    break;
                }
                // remove all buttons and hidden input
                if (jThisStr == "input" &&
                    (jGroup[i].type == "button" || jGroup[i].type == "submit" || jGroup[i].type == "reset" ||
                     jGroup[i].type == "hidden")) {
                    break;
                }
                // code assumes that "tab_on" is the id used for tab divs
                if (jThisStr == "a" && jGroup[i].parentNode.tagName.toLowerCase() == "li" &&
                    jGroup[i].parentNode.id != "tab_on") {
                    jGetChild = false;
                    break;
                }
                if (jThisStr == "li" && jGroup[i].id != "tab_on") {
                    jGetChild = false;
                    break;
                }

               // if(jThisStr == "div"&&jGroup[i].id=="audit_01"){
                 //     jOutput += "<table><tr><td>";
                   //   jOutput += walkChildNodes(jGroup[i]);
                     // jOutput += "</td><td>";
                     // jOutput += walkChildNodes(jGroup[i+1]);
                     // jOutput += "</td><td>";
                     // jOutput += walkChildNodes(jGroup[i+2]);
                     //jOutput += "</td></tr></table>";

                     //jGetChild = false;
                    //break;
                   // }
                //if(jThisStr == "div"&&(jGroup[i].id=="audit_02"||jGroup[i].id=="audit_03")){
                //     jGetChild = false;
                //    break;
                //}


                jOutput += "<" + jThisStr;

                if (jThisStr == "table") {


                    jOutput += " cellspacing=0 cellpadding=0 ";
                }
                if (jGroup[i].type != "textarea") {
                    jOutput += (jGroup[i].colSpan) ? " colspan=" + jGroup[i].colSpan : "";
                    jOutput += (jGroup[i].size) ? " size=" + jGroup[i].size : "";
                    jOutput += (jGroup[i].type) ? " type='" + jGroup[i].type + "'" : "";
                    jOutput += (jGroup[i].name) ? " name='" + jGroup[i].name + "'" : "";
                    jOutput += (jGroup[i].id) ? " id='" + jGroup[i].id + "'" : "";
                    jOutput += (jGroup[i].className) ? " class='" + jGroup[i].className + "'" : "";
                    jOutput += (jGroup[i].border) ? " border=" + jGroup[i].border : "";
                    //this trys to force the width of none div elements to 650px
                    //if (jGroup[i].width > 650) {
                      //  jOutput += " width=650";
                    //}
                    //else {
                        jOutput += (jGroup[i].width) ? " width=" + jGroup[i].width : "";
                    //}
                }
                //this trys to force the width of divs to 650px
                if (jThisStr == "div" && jGroup[i].clientWidth > 650) {
                    //jOutput += " style='width:650;overflow: visible;'";
                    jOutput += " style='overflow: visible;' ";
                }
                else if (jThisStr == "div") {
                    jOutput += " style='overflow: visible;' ";
                }
                if (jThisStr == "input" && jGroup[i].type == "checkbox" && jGroup[i].checked) {
                    jOutput += " checked ";
                }
                //if (jThisStr == "select" || (jThisStr == "input" && (jGroup[i].type == "checkbox" || jGroup[i].type == "text"))){jOutput +=" disabled ";}
                if (jThisStr == "select" || (jThisStr == "input" && jGroup[i].type == "text")) {
                    jOutput += " disabled ";
                }
                if (jThisStr == "input" && jGroup[i].type == "text") {
                    jOutput += " value='" + jGroup[i].value + "'";
                }
                jOutput += ">";

                if (jThisStr == "select") {
                    jGetChild = false;
                    if (jGroup[i].selectedIndex > 0) {
                        jOutput += "<option selected>" + jGroup[i].options(jGroup[i].selectedIndex).text + "</option>";
                    }
                }
                if (jThisStr != "input") {
                    jEndtag = "</" + jThisStr + ">";
                }

                break;
            case 3:
                var jTxtLen = jGroup[i].nodeValue.length;
                jTxt = jGroup[i].nodeValue.substr(0, jTxtLen);
                jOutput += jTxt.replace(/[\r\n]/g, "<cr>");
                break;
            case 8:
                break;

            default:
                //will leave a number on the page which is a nodeType
                jOutput += jGroup[i].nodeType;
        }
        if (jGetChild && jGroup[i].childNodes.length > 0) {
            jOutput += walkChildNodes(jGroup[i]);
        }
        jOutput += jEndtag;
    }
    return jOutput;
}