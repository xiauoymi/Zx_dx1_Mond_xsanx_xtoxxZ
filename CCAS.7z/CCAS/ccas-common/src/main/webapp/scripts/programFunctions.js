function displayProgramRelatedEntities(inputSelect) {
    var contextPath = document.getElementById("contextPath").value;
    var programId = inputSelect.options[inputSelect.selectedIndex].value;
    var url = contextPath + "/servlet/programAndRelated?PROGRAM_ID=" + programId;
    var callBackAfterGettingResultsBack = {
        success: function(o) {
            this.cache = null;
            populateDataFromResponse(o);
        },
        failure: function(o) {
            alert("Unable to populate dropdown values.");
            return;
        },
        timeout: 20000, //20 seconds
        cache:false
    };
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            callBackAfterGettingResultsBack);
}

function displayProgramRelatedLocations(inputSelect) {
    var contextPath = document.getElementById("contextPath").value;
    var programId = inputSelect.options[inputSelect.selectedIndex].value;
    var url = contextPath + "/servlet/programAndRelated?method=getLocationsRelatedToPrograms&PROGRAM_ID=" + programId;
    var callBackAfterGettingResultsBack = {
        success: function(o) {
            this.cache = null;
            populateDropDown(o.responseXML, 'location', 'filing_location', 'id', 'description');
            populateDropDown(o.responseXML, 'location', 'filingLocation', 'id', 'description');
        },
        failure: function(o) {
            alert("Unable to populate dropdown values.");
            return;
        },
        timeout: 20000, //20 seconds
        cache:false
    };
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            callBackAfterGettingResultsBack);
}

function populateDataFromResponse(output) {
    var xmlDoc = output.responseXML;
    populateDropDown(xmlDoc, 'location', 'reporting_location_code', 'id', 'description');
    populateDropDown(xmlDoc, 'location', 'responsible_plant_code', 'id', 'description');
    //    populateDropDown(xmlDoc, 'location', 'filingLocation', 'id', 'description');
    populateDropDown(xmlDoc, 'location', 'reportingLocation', 'id', 'description');
    populateDropDown(xmlDoc, 'location', 'responsibleLocation', 'id', 'description');
    populateDropDown(xmlDoc, 'location', 'responsible_Location', 'id', 'description');
    populateDropDown(xmlDoc, 'location', 'locationCode', 'id', 'description');
    populateDropDown(xmlDoc, 'subFunction', 'subFunction_id', 'id', 'description');
    populateDropDown(xmlDoc, 'category', 'c.feedbackCategoryId', 'id', 'description');
    populateDropDown(xmlDoc, 'category', 'feedbackCategoryId', 'id', 'description');
    populateDropDown(xmlDoc, 'subFunction', 'subFunctionId', 'id', 'description');
    //    populateDropDown(xmlDoc, 'subFunction', 'subFunctionsSelected', 'id', 'description');
}

function populateDropDown(xmlDoc, roottag, element, node1, node2) {
    //    if(document.getElementById('element').tagName === 'TD')return;
    var count = xmlDoc.getElementsByTagName(roottag).length;
    var i = 0;
    if (count > 0) {
        var dropDown = document.getElementById(element);
        if (dropDown === null || dropDown === undefined || dropDown.options == undefined) return;
        dropDown.options.length = 0;
        var j = 1;
        if (element != 'subFunction_id' || element != 'responsibleLocation' || element != 'filingLocation') {
            dropDown.options[i] = new Option('Select One', '', false, false);
        } else {
            j = 0;
        }
        for (i = 0; i < count; i++) {
            var selected = false;
            var node = roottag + '/' + node1;
            var node1Value = xmlDoc.getElementsByTagName(node)[i].text;
            node = roottag + '/' + node2;
            var node2Value = xmlDoc.getElementsByTagName(node)[i].text;
            dropDown.options[j] = new Option(node2Value, node1Value, selected, selected);
            j = j + 1;
        }
    }
}