var timeOut;
var appTimeOut;
function displaySessionTimeout()
{
     alert("Your current Session is expired.");
}

function activateTimeout(sessionTimeout){
      timeOut = sessionTimeout * 1000; // convert to millisecond
      window.clearTimeout(appTimeOut);
      appTimeOut = window.setTimeout("displaySessionTimeout()", timeOut);
}

function refreshTimeout(){
    window.clearTimeout(appTimeOut);
    appTimeOut = window.setTimeout("displaySessionTimeout()", timeOut);
}