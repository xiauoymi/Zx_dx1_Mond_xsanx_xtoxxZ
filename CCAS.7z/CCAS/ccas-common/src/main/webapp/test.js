function populateMaterialBatchData() {
    var id_load_ticket = document.getElementById("id_load_ticket");
    var material = id_load_ticket.substr(3, 8);
    var batch = id_load_ticket.substr(4, id_load_ticket.length - 1);
    document.getElementById("id_material").setValue(material);
    document.getElementById("id_batch").setValue(batch);
}