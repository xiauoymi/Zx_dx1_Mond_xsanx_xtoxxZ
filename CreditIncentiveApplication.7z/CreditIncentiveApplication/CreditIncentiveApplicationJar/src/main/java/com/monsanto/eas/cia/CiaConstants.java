package com.monsanto.eas.cia;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:22:36 PM To change this template use File |
 * Settings | File Templates.
 */
public class CiaConstants {
    public static final String ERROR_VIEW = "error";
    public static final String HOME_VIEW = "home";
    public static final String SESSION_TIMEOUT_VIEW = "sessiontimeout";
    public static final String WAM_COOKIE = "AXMSESSION";
    public static final String WAM_CIA_USER = "WAM_CIA_USER";
    public static final String WAM_USER_ID = "WAM_USER_ID";
    public static final String LOCALE = "locale";
    public static final String NOT_AUTHORIZED_VIEW = "notauthorized";
    public static final String OUTPUT = "output";
    public static final String STATEMENT_TYPE = "statementType";
    public static final String ID = "id";
    public static final String FROM_MONTH = "fromMonth";
    public static final String YEAR = "year";
    public static final String CREDIT_NOTE_ID = "creditNoteId";
    public static final String DISTRIBUTOR_ID = "distributorId";
    public static final String CREDIT_NOTE_FIELD = "creditNoteData";
    public static final String DISTRIBUTORS_FIELD = "distributors";
    public static final String STATEMENT_TYPE_VALUE = "CREDIT_NOTE";
    public static final String HEADER_TERRITORY = "TERRITORY";
    public static final String HEADER_KEY_AGMT = "KEY AGREEMENT";
    public static final String HEADER_LOCAL_DEALER = "LOCAL DEALER";
    public static final String HEADER_COMPANY = "COMPANY";
    public static final String HEADER_MAX_TGT = "MAX. TARGET";
    public static final String HEADER_MIN_TGT = "MIN. TARGET";
    public static final String HEADER_PRODUCT = "PRODUCT";
    public static final String HEADER_PRESENTATION = "PRESENTATION";
    public static final String HEADER_LT_ENV = "LT./ENV";
    public static final String HEADER_TOTAL_VOL = "TOTAL VOLUME";
    public static final String HEADER_PERC_INCENTIVE = "% INCENTIVE";
    public static final String HEADER_INCENTIVE = "INCENTIVE";
    public static final String HEADER_CREDIT_APP_NOTE = "CREDIT APP NOTE";
    public static final String HEADER_CONCEPT = "CONCEPT";
    public static final String NOT_AVAILABLE_INFO = "N/A";
    public static final String FROM = "from";    
    public static final String TO = "to";
    public static final String SUBJECT = "subject";
    public static final String CC_LIST = "ccList";
    public static final String ATTACHED_FILE = "attachedFile";
    public static final String MAIL_BODY = "body";
    public static final String ATTACHED_FILENAME = "filename";
    public static final String DIST_MAIL_FROM_PROPERTY = "distributor.statement.mail.from";
    public static final String DIST_MAIL_FILENAME_PROPERTY = "distributor.statement.mail.filename";
    public static final String DIST_MAIL_SUBJECT_PROPERTY = "distributor.statement.mail.subject";
    public static final String DIST_MAIL_BODY_PROPERTY = "distributor.statement.mail.body";
    public static final String SAP_PROD_PRICE_NOT_FOUND = "sapProductPrice.productNotFound";
    public static final String SAP_PROD_PRICE_SAVE_INCOMPLETE_INF = "sapProductPrice.save.incompleteInformation";
    public static final String SAP_PROD_PRICE_UPDATE_NOT_FOUND = "sapProductPrice.update.NotFound";
    public static final String SAP_PROD_PRICE_INVALID_DATE_RANGE = "sapProductPrice.invalidDateRange";
}
