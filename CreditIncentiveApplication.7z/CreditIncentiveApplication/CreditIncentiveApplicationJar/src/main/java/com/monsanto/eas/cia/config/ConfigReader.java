/*
 Copyright:  Copyright  2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.config;

import com.monsanto.eas.cia.config.exception.ConfigurationException;
import com.monsanto.eas.cia.config.model.ConnectionParams;

/**
 * Filename:    $RCSfile: ConfigReader.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 22:03:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public interface ConfigReader {

  /**
   * Gets connection to desired resource
   * @param datasourceType - can be 1. LMMSConstants.DATASOURCE_TYPE_ORACLE or
   *                                2. LMMSConstants.DATASOURCE_TYPE_SQL_SERVER
   *                                3. LMMSConstants.DATASOURCE_TYPE_FTP_SERVER 
   * @param databaseNameOrRemoteSubDir - Can be 1. databaseName -> In case of oracle/sqlserver datasources
   *                                            2. remoteSubDir -> In case of FTP Server as datasource
   * @return - ConnectionParams
   * @throws ConfigurationException - For any error encountered.
   */
  ConnectionParams getConnectionParams(String datasourceType, String databaseNameOrRemoteSubDir) throws ConfigurationException;
}
