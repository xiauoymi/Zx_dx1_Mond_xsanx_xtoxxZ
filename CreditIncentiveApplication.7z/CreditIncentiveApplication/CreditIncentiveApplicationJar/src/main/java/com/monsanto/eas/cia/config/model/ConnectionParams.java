/*
 Copyright:  Copyright  2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.config.model;

/**
 * Filename:    $RCSfile: ConnectionParams.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 23:04:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class ConnectionParams {

  private String url;
  private String portNumber;
  private String serverName;
  private String userName;
  private String selectMethod;
  private String password;
  private String encryptedPasswordDir;
  private String urlBase;
  private String host;
  private String sid;

  public ConnectionParams(String url, String portNumber, String serverName, String userName, String selectMethod, String password, String encryptedPasswordDir, String urlBase) {
    this.url = url;
    this.portNumber = portNumber;
    this.serverName = serverName;
    this.userName = userName;
    this.selectMethod = selectMethod;
    this.password = password;
    this.encryptedPasswordDir = encryptedPasswordDir;
    this.urlBase = urlBase;
  }

  public ConnectionParams(String url, String portNumber, String serverName, String userName, String host, String sid, String selectMethod, String password, String encryptedPasswordDir, String urlBase) {
    this.url = url;
    this.portNumber = portNumber;
    this.serverName = serverName;
    this.userName = userName;
    this.selectMethod = selectMethod;
    this.password = password;
    this.encryptedPasswordDir = encryptedPasswordDir;
    this.urlBase = urlBase;
    this.host = host;
    this.sid = sid;
  }

  /**
   * (Just two setters...because the password and localDirectory will be set after the deserialized object is obtained from xstream parser)
   * @param password
   */
  public void setPassword(String password) {
    this.password = password;
  }

  public String getUrl() {
    return url;
  }

  public String getPortNumber() {
    return portNumber;
  }

  public String getServerName() {
    return serverName;
  }

  public String getUserName() {
    return userName;
  }

  public String getSelectMethod() {
    return selectMethod;
  }

  public String getPassword() {
    return password;
  }

  public String getEncryptedPasswordDir() {
    return encryptedPasswordDir;
  }

  public String getUrlBase() {
    return urlBase;
  }

  public String getHost() {
    return host;
  }

  public String getSid() {
    return sid;
  }
}
