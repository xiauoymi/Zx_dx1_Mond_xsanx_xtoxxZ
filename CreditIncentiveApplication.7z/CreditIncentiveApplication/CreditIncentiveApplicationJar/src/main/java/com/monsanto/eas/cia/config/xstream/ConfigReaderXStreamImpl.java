/*
 Copyright:  Copyright  2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.config.xstream;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.cia.config.ConfigReader;
import com.monsanto.eas.cia.config.exception.ConfigurationException;
import com.monsanto.eas.cia.config.model.ConnectionParams;
import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: ConfigReaderXStreamImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 23:04:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class ConfigReaderXStreamImpl implements ConfigReader {

  private String connectionConfigurationsFile;
  private XmlSerializer serializer;

  public ConfigReaderXStreamImpl(String configFilePath) {
    this.connectionConfigurationsFile = configFilePath;
    validateConstructorArgument(configFilePath);
    serializer = createSerializer();
  }

  public ConnectionParams getConnectionParams(String datasourceType, String databaseNameOrRemoteSubDir) throws ConfigurationException {
    validateMethodArguments(datasourceType);
    String environment = getSystemEnvironment();
    String xpath = buildXPathString(datasourceType, environment, databaseNameOrRemoteSubDir);
    Node configNode = getConfigNode(xpath);
    validateConfigNode(configNode, datasourceType, databaseNameOrRemoteSubDir, environment);
    ConnectionParams connectionParamsObject = getDeserializedConnectionParamsObject(configNode, datasourceType, databaseNameOrRemoteSubDir, environment);
    String encryptedPassword = getEncryptedPassword(connectionParamsObject.getEncryptedPasswordDir());
    connectionParamsObject.setPassword(encryptedPassword);
    return connectionParamsObject;
  }

  private String getEncryptedPassword(String encryptedPasswordDir) throws ConfigurationException {
    if(StringUtils.isNullOrEmpty(encryptedPasswordDir)) {
      throw new ConfigurationException("Encrypted password directory cannot be null or empty.");
    }
    try {
      return EncryptionUtils.GetDecryptedStringFromExternalStorage(CIAConstants.SYSTEM_PARAM_MONCRYPTJV, CIAConstants.APP_NAME + "/" + encryptedPasswordDir, "CipherValue.hex", "KeyValue.hex");
    } catch (EncryptorException e) {
      Logger.log(new LoggableError(e));
      throw new ConfigurationException("Exception occured while reading encrypted password.", e);
    }
  }

  private XmlSerializer createSerializer() {
    XmlSerializerBuilder builder = new XmlSerializerBuilder();
    builder.registerMapping("", CIAConstants.ALIAS_CONNECTION_PARAMS, ConnectionParams.class);
    return builder.createSerializer();
  }

  private ConnectionParams getDeserializedConnectionParamsObject(Node configNode, String datasourceType, String databaseName, String environment) throws ConfigurationException {
    try {
      return (ConnectionParams) serializer.fromXML(DOMUtil.getXMLString(configNode));
    } catch (DeserializationException e) {
      Logger.log(new LoggableError(e));
      throw new ConfigurationException("Deserialization Exception occured while getting config node with attributes, Datasource type = '"+ datasourceType +"' and Database name = '"+ databaseName +"' for Environment = '"+ environment +"'.");
    }
  }

  private void validateConfigNode(Node configNode, String datasourceType, String databaseName, String environment) throws ConfigurationException {
    if(configNode == null){
      throw new ConfigurationException("Configuration node with required attributes, Datasource type = '"+ datasourceType +"' and Database name = '"+ databaseName +"' for Environment = '"+ environment +"', not found.");
    }
  }

  private Node getConfigNode(String xpath) throws ConfigurationException {
    Document connectionConfigXML;
    try {
      connectionConfigXML = DOMUtil.newDocument(connectionConfigurationsFile);
    } catch (ParserException e) {
      Logger.log(new LoggableError(e));
      throw new ConfigurationException("Parser Exception while reading connection-config xml file: '" + connectionConfigurationsFile + "'", e);
    }
    Node configNode;
    try {
      configNode = XPathAPI.selectSingleNode(connectionConfigXML, xpath);
    } catch (TransformerException e) {
      Logger.log(new LoggableError(e));
      throw new ConfigurationException("Transformation Exception while getting required configuration Node: " + e.getMessage(), e);
    }
    return configNode;
  }

  private void validateMethodArguments(String datasourceType) {
    if(StringUtils.isNullOrEmpty(datasourceType) ){
      throw new IllegalArgumentException("Datasource type cannot be null or empty.");
    }
  }

  private void validateConstructorArgument(String confilFilePath) {
    if(StringUtils.isNullOrEmpty(confilFilePath)) {
      throw new IllegalArgumentException("Path to connection-configurations file cannot be null or empty.");
    }
  }

  private String getSystemEnvironment() throws ConfigurationException {
    String systemEnvironment = System.getProperty(CIAConstants.SYSTEM_PARAM_LSI_FUNCTION);
    validateSystemEnvironmentProperty(systemEnvironment);
    return systemEnvironment;
  }

  private void validateSystemEnvironmentProperty(String systemEnvironment) throws ConfigurationException {
    if(StringUtils.isNullOrEmpty(systemEnvironment)){
      throw new ConfigurationException("System parameter '-Dlsi.function' not set.");
    }
  }

  private String buildXPathString(String datasourceType, String environment, String databaseNameOrRemoteSubDir) {
    if (datasourceContainsDatabase(databaseNameOrRemoteSubDir)) {
      return new StringBuffer("/connection-config/connectionparams[@type='"+ datasourceType +"' and @environment='"+ environment +"' and @database='"+ databaseNameOrRemoteSubDir +"']").toString();
    }
    return new StringBuffer("/connection-config/connectionparams[@type='"+ datasourceType +"' and @environment='"+ environment +"']").toString();
  }

  private boolean datasourceContainsDatabase(String databaseName) {
    return !StringUtils.isNullOrEmpty(databaseName);
  }
}
