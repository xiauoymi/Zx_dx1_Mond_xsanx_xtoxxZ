/*
 Copyright:  Copyright  Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.constant;

import java.io.File;

public abstract class CIAConstants {

  public static final String APP_NAME = "cia";

  public static final String SYSTEM_SECURITY_PROXY = "SYSTEM_SECURITY_PROXY";

  public static final String EMPTY_STRING = "";

  //System/JVM Parameter names...
  public static final String SYSTEM_PARAM_LSI_FUNCTION = "lsi.function";
  public static final String SYSTEM_PARAM_CONFIG_DIR = "cia.config.dir";
  public static final String SYSTEM_PARAM_TEMP_DIR = "java.io.tmpdir";
  public static final String SYSTEM_PARAM_MONCRYPTJV = "MONCRYPTJV";

  public static final String LSI_FUNCTION_PROD = "prod";
  public static final String LSI_FUNCTION_TEST = "test";
  public static final String LSI_FUNCTION_DEV = "dev";
  public static final String LSI_FUNCTION_WIN = "win";

  //Files...
  public static final String FILE_2_BW_SALES = "1D_YSD_INC2.txt";
  public static final String FILE_8_CIA_LOCAL_DEALER = "ysd_oh_file8.txt";
  public static final String FILE_9_CIA_SALES = "ysd_oh_file9.txt";

  //XStream alias/mapping names...
  public static final String ALIAS_CONNECTION_PARAMS = "connectionparams";

  //Configuration
  public static final String XML_CONNECTION_EXTERNAL_CONFIG = System.getProperty("cia.config.dir")+ File.separator+
  "ConnectionConfigurations.xml";
  public static final String DATASOURCE_TYPE_FTP_SERVER = "ftpserver";

  //Local Directory
  public static final String SYSTEM_PARAM_LOCAL_DIR = "C:\\Test";

  //FTP Remote Sub Directories...
  public static final String FTP_REMOTE_SUB_DIR_INBOUND = "bw";
  public static final String FTP_REMOTE_SUB_DIR_OUTBOUND = "bw/Incentivos_Inventarios";

  public static final String NEW_LINE_CONSTANT = "\r\n";
  public static final String N_A_CONSTANT = "n/a";

  public static final String SPACE_CONSTANT = " ";

  public static final String PROPERTY_SKIP_FILE_FTP = "Skip File FTP";
  public static final String PROPERTY_REPOST_FOR_SPECIFIC_DATE = "Repost For Specific Date";
  public static final String PROPERTY_REPOST_DATE = "Repost Date";

}
