package com.monsanto.eas.cia.controller;

import com.monsanto.eas.cia.model.SapDistributor;
import com.monsanto.eas.cia.service.DistributorService;
import com.monsanto.eas.cia.service.FinderService;
import com.monsanto.eas.cia.service.SapDistributorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import com.monsanto.eas.cia.CiaConstants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Apr 5, 2011
 * Time: 10:06:58 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/creditNote")
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class CreditNote extends AbstractController {

    @Autowired
    CreditNotePdfViewImpl view;

    //@Autowired
    //DistributorService distributorService;
    @Autowired
    SapDistributorService distributorService;

    @Autowired
    FinderService finderService;

    Collection<SapDistributor> distributors;
    
    @RequestMapping(method = RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String output = ServletRequestUtils.getStringParameter(request, CiaConstants.OUTPUT);
        String statementType = ServletRequestUtils.getStringParameter(request, CiaConstants.STATEMENT_TYPE);
        String id = ServletRequestUtils.getStringParameter(request, CiaConstants.ID);
        String fromMonth = ServletRequestUtils.getStringParameter(request, CiaConstants.FROM_MONTH);
        String year = ServletRequestUtils.getStringParameter(request, CiaConstants.YEAR);
        String[] distributorIds = id.split(",");
        distributors = new HashSet<SapDistributor>();

        Map<String, Object> creditNoteData = new HashMap<String, Object>();
        creditNoteData.put(CiaConstants.CREDIT_NOTE_ID, id);
        creditNoteData.put(CiaConstants.FROM_MONTH, fromMonth);
        creditNoteData.put(CiaConstants.YEAR, year);
        creditNoteData.put(CiaConstants.STATEMENT_TYPE, statementType);
        if (distributorIds != null && distributorIds.length > 0) {         
            for (String distId : distributorIds) {
                SapDistributor distributor = distributorService.lookUpSapDistributorByCode(distId);
                //SapDistributor distributor = finderService.findSapDistributorFrom(distId);
                if(distributor!=null) {
                    distributors.add(distributor);
                }
            }
        }
        creditNoteData.put(CiaConstants.DISTRIBUTORS_FIELD, distributors);
        return new ModelAndView(view, CiaConstants.CREDIT_NOTE_FIELD, creditNoteData);

    }
}
