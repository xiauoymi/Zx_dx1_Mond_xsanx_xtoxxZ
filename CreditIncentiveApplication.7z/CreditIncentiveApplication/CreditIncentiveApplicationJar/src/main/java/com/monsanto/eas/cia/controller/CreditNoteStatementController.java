package com.monsanto.eas.cia.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Apr 5, 2011
 * Time: 10:06:58 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/creditNoteStatement")
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class CreditNoteStatementController extends AbstractController {

    public static final Logger LOGGER = Logger.getLogger(CreditNoteStatementController.class);

    @Autowired
    CreditNoteStatementPdfView view;

    @RequestMapping(method = RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Long distributorId = ServletRequestUtils.getLongParameter(request, "distributorId");
        Long programQuarterId = ServletRequestUtils.getLongParameter(request, "programQuarterId");
        Long creditNoteId = ServletRequestUtils.getLongParameter(request, "creditNoteId");
        Long taxReserveId = ServletRequestUtils.getLongParameter(request, "taxReserveId");
        LOGGER.debug(distributorId);
        LOGGER.debug(programQuarterId);
        LOGGER.debug(creditNoteId);
        LOGGER.debug(taxReserveId);
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("distributorId", distributorId);
        model.put("programQuarterId", programQuarterId);
        model.put("creditNoteId", creditNoteId);
        model.put("taxReserveId", taxReserveId);
        return new ModelAndView(view, model);
    }
}
