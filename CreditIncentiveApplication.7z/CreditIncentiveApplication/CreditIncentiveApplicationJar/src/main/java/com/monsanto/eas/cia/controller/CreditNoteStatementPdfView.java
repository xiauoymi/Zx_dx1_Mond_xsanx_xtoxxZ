package com.monsanto.eas.cia.controller;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.eas.cia.CiaConstants;
import com.monsanto.eas.cia.integration.util.CreditNoteGenerator;
import com.monsanto.eas.cia.integration.util.DistributorStatementGenerator;
import com.monsanto.eas.cia.model.SapDistributor;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Apr 5, 2011
 * Time: 10:13:16 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class CreditNoteStatementPdfView extends AbstractPdfView {
    @Autowired
    private CreditNoteGenerator creditNoteGenerator;
    @Autowired
    private DistributorStatementGenerator distributorStatementGenerator;

    @Override
    protected void buildPdfDocument(Map model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {

        Long distributorId = MapUtils.getLong(model,"distributorId");
        Long programQuarterId = MapUtils.getLong(model,"programQuarterId");
        Long creditNoteId = MapUtils.getLong(model,"creditNoteId");
        Long taxReserveId = MapUtils.getLong(model,"taxReserveId");
        creditNoteGenerator.generatePDF(document,distributorId,programQuarterId,creditNoteId,taxReserveId);

    }
}
