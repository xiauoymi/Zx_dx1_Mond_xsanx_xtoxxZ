package com.monsanto.eas.cia.controller;

import com.monsanto.eas.cia.dao.ProgramQuarterDao;
import com.monsanto.eas.cia.dao.SapDistributorDao;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.model.SapDistributor;
import com.monsanto.eas.cia.vo.DistributorStatementGoalsVO;
import com.monsanto.eas.cia.vo.DistributorStatementPerDealerAndProductVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.jasperreports.JasperReportsUtils;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 7/11/12
 * Time: 03:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/distributorStatementController")
public class DistributorStatementController {

    @Autowired
    private SapDistributorDao sapDistributorDao;

    @Autowired
    private ProgramQuarterDao programQuarterDao;

    @Autowired
    private DistributorStatementView view;

    @Autowired
    ServletContext context;

    private static final Logger LOG = Logger.getLogger(LocalDealerIncentiveReportController.class);

    @RequestMapping(method = {RequestMethod.POST, RequestMethod.GET})
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {

        int year = ServletRequestUtils.getIntParameter(request, "year");
        int quarter = ServletRequestUtils.getIntParameter(request, "quarter");
        long distributorId = ServletRequestUtils.getLongParameter(request, "distributorId");
        ProgramQuarter programQuarter = programQuarterDao.findByQuarterNumAndYear(quarter, year);
        long programQuarterId = programQuarter.getId();
        LOG.debug(programQuarterId);

        SimpleDateFormat formatter = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy", new Locale("es", "MX"));

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        Map<String, Object> model = new HashMap<String, Object>();
        Collection<DistributorStatementGoalsVO> distributorStatementGoals =
                sapDistributorDao.findDistributorStatementGoals(distributorId, year);
        Collection<DistributorStatementPerDealerAndProductVO> distributorStatementPerDealerAndProduct =
                sapDistributorDao.findDistributorStatementPerDealerAndProduct(distributorId, programQuarterId);

        BigDecimal totalVolumeDistributor = BigDecimal.ZERO;
        for (DistributorStatementGoalsVO vo : distributorStatementGoals) {
            switch (quarter) {
                case 1:
                    totalVolumeDistributor = totalVolumeDistributor.add(vo.getIncentiveVolumeFirstQuarter());
                    break;
                case 2:
                    totalVolumeDistributor = totalVolumeDistributor.add(vo.getIncentiveVolumeSecondQuarter());
                    break;
                case 3:
                    totalVolumeDistributor = totalVolumeDistributor.add(vo.getIncentiveVolumeThirdQuarter());
                    break;
                case 4:
                    totalVolumeDistributor = totalVolumeDistributor.add(vo.getIncentivePctFourthQuarter());
                    break;
            }
        }

        SapDistributor distributor = sapDistributorDao.findByPrimaryKey(SapDistributor.class, new Long(distributorId).intValue());

        model.put("year", year);
        model.put("startDate", formatter.format(programQuarter.getQuarterStart()));
        model.put("endDate", formatter.format(programQuarter.getQuarterEnd()));
        model.put("distributor", distributor.getDescription());
        model.put("quarter", quarter);
        model.put("totalVolumeDistributor", totalVolumeDistributor);
        model.put("jrDealerData", JasperReportsUtils.convertReportData(distributorStatementGoals));
        model.put("jrProductPriceVolIncentiveData", JasperReportsUtils.convertReportData(distributorStatementPerDealerAndProduct));

        return new ModelAndView(view, model);
    }

}
