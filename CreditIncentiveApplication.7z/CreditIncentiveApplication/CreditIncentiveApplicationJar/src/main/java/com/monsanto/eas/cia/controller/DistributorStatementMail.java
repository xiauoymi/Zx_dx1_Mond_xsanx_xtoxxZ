package com.monsanto.eas.cia.controller;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.eas.cia.CiaConstants;
import com.monsanto.eas.cia.integration.util.CreditNoteGenerator;
import com.monsanto.eas.cia.integration.util.DistributorStatementGenerator;
import com.monsanto.eas.cia.model.SapDistributor;
import com.monsanto.eas.cia.service.DistributorService;
import com.monsanto.eas.cia.service.MailSender;
import com.monsanto.eas.cia.service.SapDistributorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

/**
 * Controller for handling requests to send emails to distributors with the statement report.
 * User: JEESCO
 * Date: 22/07/2011
 * Time: 02:32:22 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/distributorStatementMail")
public class DistributorStatementMail extends AbstractController {
    @Autowired
    SapDistributorService distributorService;
    @Autowired
    CreditNotePdfViewImpl view;
    @Autowired
    DistributorStatementGenerator distributorStatementGenerator;
    @Autowired
    CreditNoteGenerator creditNoteGenerator;
    @Autowired
    MailSender mailSender;
    @Autowired
    MessageSource messageSource;
    /**
     * The attached report
     */
    OutputStream os;

    Collection<SapDistributor> distributors;

    @RequestMapping(method = RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String statementType = ServletRequestUtils.getStringParameter(request, CiaConstants.STATEMENT_TYPE);
        String id = ServletRequestUtils.getStringParameter(request, CiaConstants.ID);
        String fromMonth = ServletRequestUtils.getStringParameter(request, CiaConstants.FROM_MONTH);
        String year = ServletRequestUtils.getStringParameter(request, CiaConstants.YEAR);
        String[] distributorIds = id.split(",");
        distributors = new HashSet<SapDistributor>();

        Map<String, Object> creditNoteData = new HashMap<String, Object>();
        creditNoteData.put(CiaConstants.DISTRIBUTOR_ID, id);
        creditNoteData.put(CiaConstants.FROM_MONTH, fromMonth);
        creditNoteData.put(CiaConstants.YEAR, year);
        creditNoteData.put(CiaConstants.STATEMENT_TYPE, statementType);
        if (distributorIds != null && distributorIds.length > 0) {
            for (String distId : distributorIds) {
                SapDistributor distributor = distributorService.lookUpSapDistributorByCode(distId);
                if (distributor != null) {
                    distributors.add(distributor);
                }
            }
        }
        creditNoteData.put(CiaConstants.DISTRIBUTORS_FIELD, distributors);


        Iterator<SapDistributor> it = distributors.iterator();
        while (it.hasNext()) {
            SapDistributor tmpDistributor = it.next();
            Collection tmpDistributors = new ArrayList<SapDistributor>();
            tmpDistributors.add(tmpDistributor);
            Document document = new Document(PageSize.A4, 10, 10, 10, 10);

            if (statementType != null && statementType.equalsIgnoreCase(CiaConstants.STATEMENT_TYPE_VALUE)) {
                //To do send credit Note by email.
                //os = creditNoteGenerator.getGeneratedPDF(document, fromMonth, year, tmpDistributors);
            } else {
                os = distributorStatementGenerator.getGeneratedPdf(document, fromMonth, year, tmpDistributors);
            }

            Map<String, Object> mailData = new HashMap<String, Object>();
            Locale locale = Locale.getDefault();
            mailData.put(CiaConstants.ATTACHED_FILENAME, messageSource.getMessage(CiaConstants.DIST_MAIL_FILENAME_PROPERTY, null, locale));
            mailData.put(CiaConstants.FROM, messageSource.getMessage(CiaConstants.DIST_MAIL_FROM_PROPERTY, null, locale));
            mailData.put(CiaConstants.TO, tmpDistributor.getEmail());
            mailData.put(CiaConstants.ATTACHED_FILE, os);
            mailData.put(CiaConstants.SUBJECT, messageSource.getMessage(CiaConstants.DIST_MAIL_SUBJECT_PROPERTY, null, locale));
            mailData.put(CiaConstants.MAIL_BODY, messageSource.getMessage(CiaConstants.DIST_MAIL_BODY_PROPERTY, new String[]{tmpDistributor.getDescription()}, locale));
            mailSender.send(mailData);

            os = null;
        }


        return new ModelAndView(view, CiaConstants.CREDIT_NOTE_FIELD, creditNoteData);
    }
}
