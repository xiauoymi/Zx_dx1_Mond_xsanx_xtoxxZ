package com.monsanto.eas.cia.controller;

import com.lowagie.text.pdf.PdfWriter;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;
import net.sf.jasperreports.engine.util.JRLoader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.ui.jasperreports.JasperReportsUtils;
import org.springframework.web.context.support.ServletContextResource;
import org.springframework.web.servlet.view.AbstractView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Component
public class DistributorStatementView extends AbstractView {

    public static Logger LOGGER = Logger.getLogger(DistributorStatementView.class);

    @Autowired
    private ServletContext context;

    /**
     * This constructor sets the appropriate content type "application/pdf".
     * Note that IE won't take much notice of this, but there's not a lot we
     * can do about this. Generated documents should have a ".pdf" extension.
     */
    public DistributorStatementView() {
        setContentType("application/pdf");
    }


    protected boolean generatesDownloadContent() {
        return true;
    }

    private void setExporterParameters(ByteArrayOutputStream os, JasperPrint print) {
        JRPdfExporter exporter = new JRPdfExporter();
        final String author = "Monsanto";
        exporter.setParameters(new HashMap<String, Object>());
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, os);
        exporter.setParameter(JRPdfExporterParameter.IS_ENCRYPTED, Boolean.TRUE);
        exporter.setParameter(JRPdfExporterParameter.IS_128_BIT_KEY, Boolean.TRUE);
        exporter.setParameter(JRPdfExporterParameter.OWNER_PASSWORD, "iu2412_=12I12oj10_==");
        exporter.setParameter(JRPdfExporterParameter.PERMISSIONS, new Integer(PdfWriter.ALLOW_PRINTING));
        exporter.setParameter(JRPdfExporterParameter.METADATA_AUTHOR, author);
        exporter.setParameter(JRPdfExporterParameter.METADATA_TITLE, author);
        exporter.setParameter(JRPdfExporterParameter.METADATA_CREATOR, author);
        exporter.setParameter(JRPdfExporterParameter.METADATA_KEYWORDS, author);
        exporter.setParameter(JRPdfExporterParameter.METADATA_SUBJECT, author);
        try {
            exporter.exportReport();
        }
        catch (JRException e) {
            LOGGER.error(e);
            throw new RuntimeException(e);
        }
    }

    public void buildStatement(ByteArrayOutputStream os,
                               Map<String, Object> model) {

        Resource distStatementMainDesign = new ServletContextResource(context, "/WEB-INF/reports/DistributorStatement.jasper");
        Resource distStatementDealerInfoAndGoalsDesign = new ServletContextResource(context, "/WEB-INF/reports/DisStatementDealersInfoAndGoals_.jasper");
        Resource distStatementProductVolumeDesign = new ServletContextResource(context, "/WEB-INF/reports/DisStatementProductInfoVolume_.jasper");
        Resource distStatementProductIncentiveDesign = new ServletContextResource(context, "/WEB-INF/reports/DisStatementProductInfoIncentive_.jasper");
        //Resource distStatementCreditNotesByRegionDesign = new ServletContextResource(context, "/WEB-INF/reports/DisStatementCreditNotesByRegion_.jasper");
        Resource distStatementPricePerProductDesign = new ServletContextResource(context, "/WEB-INF/reports/DisStatementPricePerProduct_.jasper");

        try {
            JasperReport jrMain = (JasperReport) JRLoader.loadObject(distStatementMainDesign.getInputStream());
            JasperReport jrDealer = (JasperReport) JRLoader.loadObject(distStatementDealerInfoAndGoalsDesign.getInputStream());
            JasperReport jrProductVolume = (JasperReport) JRLoader.loadObject(distStatementProductVolumeDesign.getInputStream());
            JasperReport jrProductIncentive = (JasperReport) JRLoader.loadObject(distStatementProductIncentiveDesign.getInputStream());
            //JasperReport jrCreditNote = (JasperReport) JRLoader.loadObject(distStatementCreditNotesByRegionDesign.getInputStream());
            JasperReport jrProductPrice = (JasperReport) JRLoader.loadObject(distStatementPricePerProductDesign.getInputStream());


            //model.put("jrCreditNote", jrCreditNote);
            model.put("jrDealer", jrDealer);
            model.put("jrProductPrice", jrProductPrice);
            model.put("jrProductIncentive", jrProductIncentive);
            model.put("jrProductVolume", jrProductVolume);


            JasperPrint print = JasperFillManager.fillReport(jrMain,
                    model, JasperReportsUtils.convertReportData(Collections.<Object>emptyList()));

            setExporterParameters(os, print);

        }
        catch (JRException e) {
            LOGGER.error(e);
            throw new RuntimeException(e);
        }
        catch (IOException e) {
            LOGGER.error(e);
            throw new RuntimeException(e);
        }
    }


    protected final void renderMergedOutputModel(
            Map model, HttpServletRequest request, HttpServletResponse response) throws Exception {

        // IE workaround: write into byte array first.
        ByteArrayOutputStream os = createTemporaryOutputStream();

        buildStatement(os, model);

        // Flush to HTTP response.
        writeToResponse(response, os);
    }


}
