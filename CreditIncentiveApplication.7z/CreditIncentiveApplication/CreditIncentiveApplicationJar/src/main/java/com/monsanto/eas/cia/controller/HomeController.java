package com.monsanto.eas.cia.controller;

import com.monsanto.eas.cia.CiaConstants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:20:29 PM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/home")
public class HomeController extends AbstractController {

  @RequestMapping(method = RequestMethod.GET)
  public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
//    PogUser wamUser = (PogUser) request.getSession(true).getAttribute(CiaConstants.WAM_POG_USER);
//    if (wamUser == null) {
//      return new ModelAndView(CiaConstants.NOT_AUTHORIZED_VIEW);
//    }
    Map map = new HashMap();
//    map.put(CiaConstants.LOCALE, wamUser.getLocale().getLocale().toLowerCase());
    return new ModelAndView(CiaConstants.HOME_VIEW, map);
  }
}
