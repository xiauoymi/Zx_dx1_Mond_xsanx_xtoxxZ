package com.monsanto.eas.cia.controller;

import com.monsanto.eas.cia.dao.LocalDealerDao;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.vo.LdCreditNoteVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/11/12
 * Time: 01:56 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/localDealerIncentiveReport")
public class LocalDealerIncentiveReportController {

    @Autowired
    private LocalDealerDao localDealerDao;

    @Autowired
    ServletContext context;

    private static final Logger LOG = Logger.getLogger(LocalDealerIncentiveReportController.class);

    @RequestMapping(method = {RequestMethod.POST, RequestMethod.GET})
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {

        Integer id = ServletRequestUtils.getIntParameter(request, "id");
        Integer year = ServletRequestUtils.getIntParameter(request, "year");

        LocalDealer dealer = localDealerDao.lookUpLocalDealer(id);

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("name", dealer.getName());
        model.put("fiscalName", dealer.getFiscalName());
        model.put("agreementNumber", dealer.getAgreementNumber());

        District district = dealer.getDistrict();

        if (district != null) {
            if (district.getChildAreas().size() > 0) {
                model.put("district", district.getChildAreas().iterator().next().getDescription());
            }
        }

        model.put("dataSource", new ArrayList<Object>());
        model.put("LDRegisteredVolumeLitersSubReportData", localDealerDao.getLdRegisteredVolumeLitersVOCol(id, year));
        model.put("LDGoalToVolumeRecordSubReportData", localDealerDao.getLdGoalToVolumeRecordVOCol(id, year));

        Map<String, BigDecimal> totals = localDealerDao.getLdCreditNoteVODistTotals(id, year);
        Collection<LdCreditNoteVO> cnCol = localDealerDao.getLdCreditNoteVOCol(id, year);
        for (Iterator<LdCreditNoteVO> it = cnCol.iterator(); it.hasNext(); ) {
            if (!totals.containsKey(it.next().getDistributor())) {
                it.remove();
            }
        }
        model.put("LDCreditNoteTotalsMap", totals);
        model.put("LDCreditNoteSubReportData", cnCol);

        model.put("MonsantoImagineImg", context.getResourceAsStream("/images/MonsantoImagine.JPG"));
        model.put("MonsantoSocioImg", context.getResourceAsStream("/images/MonsantoSocio.JPG"));
        model.put("MonsantoTopImg", context.getResourceAsStream("/images/MonsantoTop.JPG"));
        model.put("MonsantoWMImg", context.getResourceAsStream("/images/MonsantoWM.JPG"));

        model.put("state", district != null ? district.getDescription() : null);
        model.put("subregion", dealer.getSubRegion() != null ? dealer.getSubRegion().getDescription() : null);
        model.put("START_DATE", String.format(" 1° de Enero de %d",year));
        model.put("END_DATE", String.format("31 de Diciembre de %d",year));
        model.put("YEAR", year);
        return new ModelAndView("localDealerStatement", model);
    }

}

