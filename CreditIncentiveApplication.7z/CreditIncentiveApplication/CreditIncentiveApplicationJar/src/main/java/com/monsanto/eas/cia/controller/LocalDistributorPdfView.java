package com.monsanto.eas.cia.controller;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 30/10/12
 * Time: 03:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocalDistributorPdfView extends AbstractPdfView {

    @Override
    protected void buildPdfDocument(Map map, Document document, PdfWriter pdfWriter, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {



    }
}
