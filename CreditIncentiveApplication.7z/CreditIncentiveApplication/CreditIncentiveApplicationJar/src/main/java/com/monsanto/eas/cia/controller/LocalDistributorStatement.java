package com.monsanto.eas.cia.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Apr 5, 2011
 * Time: 10:06:58 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/localDistributorStatement")
public class LocalDistributorStatement extends AbstractController{
  @Autowired
  PdfLocalDealerDistributorView view;

  private Logger logger = Logger.getLogger(getClass());

  @RequestMapping(method = RequestMethod.GET)
  protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String output =
			ServletRequestUtils.getStringParameter(request, "output");
		String id =
			ServletRequestUtils.getStringParameter(request, "id");
		String year =
			ServletRequestUtils.getStringParameter(request, "year");

		Map<String,String> localDealerStatementCriteria = new HashMap<String,String>();
		localDealerStatementCriteria.put("id", id);
		localDealerStatementCriteria.put("year", year);
      logger.debug("LocalDistributorStatementController...");
      logger.debug(id);
      logger.debug(year);
    return new ModelAndView(view,"localDealerStatementCriteria", localDealerStatementCriteria);
  }
}
