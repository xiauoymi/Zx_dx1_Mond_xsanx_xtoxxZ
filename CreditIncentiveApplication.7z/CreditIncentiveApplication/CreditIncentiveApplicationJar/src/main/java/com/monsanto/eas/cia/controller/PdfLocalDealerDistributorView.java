package com.monsanto.eas.cia.controller;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.eas.cia.integration.util.GenerateLocalDealerStatement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Apr 5, 2011
 * Time: 10:13:16 AM
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class PdfLocalDealerDistributorView extends AbstractPdfView{
    @Autowired
    GenerateLocalDealerStatement glds;

  @Override
  protected void buildPdfDocument(Map model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
    Map<String,String> criteria = (Map<String,String>) model.get("localDealerStatementCriteria");
    String year = criteria.get("year");
    String id = criteria.get("id");
    glds.generatePDF(document, year, id);
  }
}
