package com.monsanto.eas.cia.controller;

import com.monsanto.eas.cia.CiaConstants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:23:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/sessiontimeout")
public class SessionTimeoutController extends AbstractController {
  @RequestMapping(method = RequestMethod.GET)
  public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
    cleanUp(request, response);
    return new ModelAndView(CiaConstants.SESSION_TIMEOUT_VIEW);
  }

  public void cleanUp(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
    /** Invalidate Session **/
    if (httpServletRequest.getSession(false) != null) {
      httpServletRequest.getSession().removeAttribute(CiaConstants.WAM_CIA_USER);
      httpServletRequest.getSession().removeAttribute(CiaConstants.WAM_USER_ID);
      httpServletRequest.getSession().invalidate();
    }

    logger.debug("cleanUp() >> Session has been invalidated");
    Cookie[] cookies = httpServletRequest.getCookies();

    if (cookies != null & cookies.length > 0) {
      for (int i = 0; i < cookies.length; i++) {
        if (CiaConstants.WAM_COOKIE.equals(cookies[i].getName())) {
          /** Delete WAM Cookie **/
          Cookie wamCookie = new Cookie(CiaConstants.WAM_COOKIE, "");
          wamCookie.setMaxAge(0);
          httpServletResponse.addCookie(wamCookie);
          logger.debug("cleanUp() >> 'AXMSESSION' WAM Cookies has been deleted");
        }
      }
    }
  }

}
