package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.CnPerDistributorView;
import com.monsanto.eas.cia.model.DistributorCnView;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:38 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CnPerDistributorViewDao extends IGenericDao<CnPerDistributorView> {

    Collection<CnPerDistributorView> lookupCreditNotesByYearAndMonthAndDistributor(int year, Date date, Long distributorId);

    CnPerDistributorView findByDistributorProgramQuarterAndCreditNote(Long distributorId, Long programQuarterId, Long creditNoteId);

}
