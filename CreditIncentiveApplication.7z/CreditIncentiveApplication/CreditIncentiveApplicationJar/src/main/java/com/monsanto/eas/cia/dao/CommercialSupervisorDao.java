package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.CommercialSupervisor;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 3:06:56 PM To change this template use File |
 * Settings | File Templates.
 */
public interface CommercialSupervisorDao extends IGenericDao<CommercialSupervisor> {
    Collection<CommercialSupervisor> lookupAll();
    CommercialSupervisor lookupCommercialSupervisorByName(String param);
}
