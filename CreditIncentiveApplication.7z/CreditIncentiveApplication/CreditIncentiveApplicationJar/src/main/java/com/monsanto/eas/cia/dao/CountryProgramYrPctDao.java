package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.CountryProgramYrPct;
import com.monsanto.eas.cia.model.Year;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:14 PM To change this template use File |
 * Settings | File Templates.
 */
public interface CountryProgramYrPctDao extends IGenericDao<CountryProgramYrPct> {
  Collection<CountryProgramYrPct> lookupAllCountryProgramYrPcts();

  Collection<CountryProgramYrPct> lookupCountryProgramYrPctsByYear(Year year);

  CountryProgramYrPct lookupCountryProgramYrPctByCountryAndYear(Country country, Year year);

  Collection<CountryProgramYrPct> lookupActiveCountryProgramYrs();


}
