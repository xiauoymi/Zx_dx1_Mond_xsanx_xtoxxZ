package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.CreditNote;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 12:15:26 PM To change this template use File |
 * Settings | File Templates.
 */
public interface CreditNoteDao extends IGenericDao<CreditNote> {
    @SuppressWarnings("unchecked")
    CreditNote lookupAllDistributorsWithCreditNotesForYearMonth(String distributorId, String year, String month);

    @SuppressWarnings("unchecked")
    CreditNote lookupCreditNoteWithId(String creditNoteId);

    BigDecimal sumCreditNotesAmmount(Long distributorId, Date startingDate, Date endingDate);
}
