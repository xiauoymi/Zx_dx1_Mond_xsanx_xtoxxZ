package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.CriteriaCreator;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;

import java.io.Serializable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO  
 * Date: 01/02/2011
 * Time: 10:07:05 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CriteriaDao extends Serializable {

    public <T extends BaseEntity> T findByCode(Class<T> _class, String code);

    public <T extends BaseEntity> T findByDescription(Class<T> _class, String description);

    public <T extends BaseEntity> T findByProperty(Class<T> _class,String property, Object value);

    public <T extends BaseEntity> T findByCriteria(DefaultCriteriaCreator<T>criteriaCreator);
    public <T extends BaseEntity> List<T> findListByCriteria(DefaultCriteriaCreator<T>criteriaCreator);
    public <T> T findByCriteria(Class<T> _class,CriteriaCreator criteriaCreator);
    public <T> List<T> findListByCriteria(Class<T> _class,CriteriaCreator criteriaCreator);

    public <T extends BaseEntity> void persist(T entity);

    public ScrollableResults getScrollableResults(CriteriaCreator criteriaCreator, ScrollMode mode);    

    public void synchronize(long numRecord, int flushAtThisNumberOfRecords);
}
