package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.DistributorCnView;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 8/12/2010
 * Time: 10:55:39 AM
 * To change this template use File | Settings | File Templates.
 */
public interface DistributorCnDao extends IGenericDao<DistributorCnView>{

    Collection<DistributorCnView> lookupAll();

    Collection<DistributorCnView> lookupAllDistributorsWithNoCreditNotesForYearMonth(String s, String month);

  Collection<DistributorCnView> lookupAllDistributorsWithCreditNotes();

  Collection<DistributorCnView> lookupAllDistributorsSalesForYearMonth(String distId, Integer year, String month);

  Collection<DistributorCnView> lookupAllDistributorsWithCreditNotesForYearMonth(String year, String month);
}
