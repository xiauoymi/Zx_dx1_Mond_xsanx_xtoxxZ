package com.monsanto.eas.cia.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 25, 2010 Time: 12:28:21 PM To change this template use File |
 * Settings | File Templates.
 */
public interface IGenericDao<E> extends Serializable {

    /**
     * This method creates the entity on the database.
     * @param entity
     */
    void persist(E entity);

    /**
     * This method creates the entity on the database.
     *
     * @param entity the entity
     */
    public void save(E entity);

    /**
     * This method updates the database.
     *
     * @param entity the entity
     */
    public E merge(E entity);

    /**
     * This method deletes <code>E</code> from the database.
     *
     * @param entity the entity
     */
    public void delete(E entity);

    /**
     * Refresh.
     *
     * @param entity the entity
     */
    public void refresh(E entity);

    /**
     * This method checks if <code>E</code> exists in persistence context, if <code>E</code> this method returns true
     * otherwise false.<br>
     *
     * @param entity the entity
     * @return true, if successful
     */
    public boolean contains(E entity);

    /**
     * Find using a named query.
     *
     * @param queryName the name of the query
     * @param params    the query parameters
     * @return the list of entities
     */
    public Collection<E> findByQuery(final String queryName, Object... params);

    /**
     * Find by query name.
     *
     * @param queryName the query name
     * @param params    the params
     * @return the list< e>
     */
    public Collection<E> findByQueryName(final String queryName, Object... params);

    /**
     * Find by primary key
     *
     * @param clazz      - Class
     * @param primaryKey - primary key of table
     * @return the E
     */
    public E findByPrimaryKey(Class clazz, Integer primaryKey);

    public E findByPrimaryKey(Class clazz, Object primaryKey);

    public abstract E findByQueryName(String queryName, Map<String, Object> parameters);

    public abstract List<E> findListByQueryName(String queryName, Map<String, Object> parameters);
}
