package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdDist;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 8/12/2010
 * Time: 02:06:11 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LdDistDao extends IGenericDao <LdDist>{
    Collection<LdDist> lookupAll();
    Collection<LdDist> lookupByDistributorId(Integer distributorId);
}
