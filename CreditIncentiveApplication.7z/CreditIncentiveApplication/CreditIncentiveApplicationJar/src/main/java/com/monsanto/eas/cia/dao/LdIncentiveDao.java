package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdIncentive;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 30/11/2010
 * Time: 08:23:29 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LdIncentiveDao extends IGenericDao<LdIncentive>{
    Collection <LdIncentive>lookupAll();
    Collection <LdIncentive>lookupLdIncentiveByLocalDealerId(String param);
}
