package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdProgramYearStatus;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 11:56:02 AM To change this template use File |
 * Settings | File Templates.
 */
public interface LdProgramYearStatusDao extends IGenericDao<LdProgramYearStatus> {
  Collection<LdProgramYearStatus> lookupAll();
}
