package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.CreditNote;
import com.monsanto.eas.cia.model.DistributorCnView;
import com.monsanto.eas.cia.model.LdSalesCn;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 12:15:26 PM To change this template use File |
 * Settings | File Templates.
 */
public interface LdSalesCnDao extends IGenericDao<LdSalesCn> {
    Collection<LdSalesCn> lookupAllCreditNotesPerSale(String salesId);
}
