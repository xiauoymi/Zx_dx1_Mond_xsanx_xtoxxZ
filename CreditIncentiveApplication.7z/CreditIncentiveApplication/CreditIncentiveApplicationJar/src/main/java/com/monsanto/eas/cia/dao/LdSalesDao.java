package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdSales;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 30/11/2010
 * Time: 08:18:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LdSalesDao extends IGenericDao<LdSales> {
    Collection<LdSales> lookupAll();

    Collection<LdSales> lookupByIds(Collection<Integer> ids);

    Collection lookupBWDLSExport();

    Collection<LdSales> lookupBWTransactionExport();

    @SuppressWarnings("unchecked")
    LdSales lookupAllSalesWithId(Integer salesId);

    @SuppressWarnings("unchecked")
    Collection<LdSales> lookupSalesForDistributorYearMonth(String distributorId, String year, String month);

    void updateIncentiveAmount(Long distributorId, Long localDealerId, Date startingDate, Date endingDate, Double incentivePct);
}
