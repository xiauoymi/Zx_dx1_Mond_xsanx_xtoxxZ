package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.vo.LdCreditNoteVO;
import com.monsanto.eas.cia.vo.LdGoalToVolumeRecordVO;
import com.monsanto.eas.cia.vo.LdRegisteredVolumeLitersVO;
import com.monsanto.eas.cia.vo.LocalDealerStatementRecordVO;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:09:44 PM To change this template use File |
 * Settings | File Templates.
 */
public interface LocalDealerDao extends IGenericDao<LocalDealer> {
    Collection<LocalDealer> lookupAllLocalDealers();

    Collection<LocalDealer> lookupBWExport(String queryName, Object... params);

    LocalDealer lookupLocalDealerByRfc(String param);

    LocalDealer lookupLocalDealerByNameAndPosName(String param1, String param2);

    LocalDealer lookupLocalDealerByAgreementNumberAndRfc(String agreementNumber, String rfc);

    void setAgreementNumber(LocalDealer localDealer);

    Collection<LocalDealer> lookupAllUnsignedLocalDealers();

    LocalDealer lookUpLocalDealer(Integer localDealerId);

    Collection<LdGoalToVolumeRecordVO> getLdGoalToVolumeRecordVOCol(Integer id, Integer year);

    Collection<LdRegisteredVolumeLitersVO> getLdRegisteredVolumeLitersVOCol(Integer id, Integer year);

    Collection<LdCreditNoteVO> getLdCreditNoteVOCol(Integer id, Integer year);

    Map<String, BigDecimal> getLdCreditNoteVODistTotals(Integer id, Integer year);
}
