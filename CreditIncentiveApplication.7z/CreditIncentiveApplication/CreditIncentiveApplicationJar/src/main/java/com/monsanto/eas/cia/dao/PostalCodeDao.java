package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.State;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:14 PM To change this template use File |
 * Settings | File Templates.
 */
public interface PostalCodeDao extends IGenericDao<PostalCode> {
  Collection<PostalCode> lookupAllPostalCodes();

  Collection<PostalCode> lookupPostalCodesForDistrict(District district);
}
