package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.ProcessLog;

public interface ProcessLogDao extends IGenericDao<ProcessLog>{

}
