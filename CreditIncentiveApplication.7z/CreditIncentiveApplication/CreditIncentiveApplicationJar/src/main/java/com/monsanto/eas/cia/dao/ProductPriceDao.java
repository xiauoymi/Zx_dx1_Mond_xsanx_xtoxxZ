package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.ProductPrice;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 13/12/2010
 * Time: 12:24:26 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductPriceDao extends IGenericDao<ProductPrice>{
    Collection <ProductPrice> lookupAll();
    ProductPrice lookupProductPriceByProductId(String param);
}
