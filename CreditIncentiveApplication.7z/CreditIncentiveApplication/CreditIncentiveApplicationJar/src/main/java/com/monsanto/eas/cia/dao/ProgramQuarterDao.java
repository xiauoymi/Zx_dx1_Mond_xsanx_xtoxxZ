package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.ProgramQuarter;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:14 PM To change this template use File |
 * Settings | File Templates.
 */
public interface ProgramQuarterDao extends IGenericDao<ProgramQuarter> {
    //  Collection<QuarterType> lookupAllQuarters();
    ProgramQuarter lookupProgramQuarterByTransaction(String param);

    @SuppressWarnings("unchecked")
    ProgramQuarter lookupProgramQuarterByDate(Date date);

    ProgramQuarter lookupProgramQuarterByDate(Date date, Country country);

    ProgramQuarter findByQuarterNumAndYear(int quarterNum, int year);

    Collection<ProgramQuarter> lookupValidProgramQuarterBetweenDates(Date startingDate, Date endingDate, int year);

}
