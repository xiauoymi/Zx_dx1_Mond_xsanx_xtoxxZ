package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdSalesPerProduct;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: jbecerr
 * Date: 28/04/2011
 * Time: 09:47:52 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesPerProductDao extends IGenericDao<LdSalesPerProduct>{
    Collection<LdSalesPerProduct> lookupLdSalesPerProductByYearAndLeader(Integer localDealerId, Integer year);
    LdSalesPerProduct lookupLdSalesPerProductByYearAndLeaderAndProduct(Integer localDealerId, Integer year, Integer productLineId);
}
