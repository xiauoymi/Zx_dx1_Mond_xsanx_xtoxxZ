package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.LdSalesPerQuarter;

/**
 * Created by IntelliJ IDEA.
 * Date: 12/04/2011
 * Time: 05:25:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesPerQuarterDao  extends IGenericDao<LdSalesPerQuarter>{
     LdSalesPerQuarter lookupSalesByQuarterAndLeader(String quarterId, String leaderId);
}
