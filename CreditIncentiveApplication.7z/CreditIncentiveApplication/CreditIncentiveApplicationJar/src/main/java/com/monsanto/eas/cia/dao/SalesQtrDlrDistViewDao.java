package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.CnPerDistributorView;
import com.monsanto.eas.cia.model.SalesQtrDlrDistView;
import com.monsanto.eas.cia.model.SalesQtrProdDlrDistView;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:38 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesQtrDlrDistViewDao extends IGenericDao<SalesQtrDlrDistView> {

    BigDecimal[] findIncentiveDebtByDistQuarterYearGroupedByDist(Long distributorId, Long programQuarterId);

    Collection<SalesQtrDlrDistView> findByDistributorAndProgramQuarterId(Long distributorId, Long programQuarterId);

}
