package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.SalesQtrProdDlrDistView;
import com.monsanto.eas.cia.model.SalesView;

import java.math.BigDecimal;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:38 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SalesViewDao extends IGenericDao<SalesView> {

    Collection<SalesView> findByDistributorAndProgramQuarterAndCreditNoteNull(Long distributorId, Long programQuarterId);

}
