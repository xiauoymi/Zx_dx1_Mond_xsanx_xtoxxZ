package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.SapDistributor;
import com.monsanto.eas.cia.vo.DistributorStatementGoalsVO;
import com.monsanto.eas.cia.vo.DistributorStatementPerDealerAndProductVO;
import com.monsanto.eas.cia.vo.DistributorStatementPerSubRegionVO;

import java.util.Collection;

public interface SapDistributorDao extends IGenericDao<SapDistributor> {

    Collection<SapDistributor> lookupSapDistributorByCodeOrDescriptionOrEmail(String filter);

    Collection<SapDistributor> lookupAll();

    SapDistributor lookupSapDistributorById(String distId);

    SapDistributor lookupSapDistributorByCode(String distributorId);

    Collection<SapDistributor> saveAll(Collection<SapDistributor> sapDistributors);

    Collection<DistributorStatementPerDealerAndProductVO> findDistributorStatementPerDealerAndProduct(Long distributorId, Long programQuarterId);

    Collection<DistributorStatementPerSubRegionVO> findDistributorStatementPerSubRegion(Long distributorId, Long programQuarterId);

    Collection<DistributorStatementGoalsVO> findDistributorStatementGoals(Long distributorId, Integer year);

}
