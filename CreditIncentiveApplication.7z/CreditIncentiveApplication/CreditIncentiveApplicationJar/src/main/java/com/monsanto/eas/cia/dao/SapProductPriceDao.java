package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.SapProductPrice;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 8/02/13
 * Time: 09:55 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SapProductPriceDao extends IGenericDao<SapProductPrice> {

    /**
     * Get all SapProductPrice
     *
     * @return SapProductPrice collection
     */
    Collection<SapProductPrice> lookupAll();

    /**
     * Get SapProductPrice by Id
     *
     * @param id Id
     * @return SapProductPrice
     */
    SapProductPrice lookupProductPriceById(final Integer id);

    /**
     * Get SapProductPrice by transaction date
     *
     * @param productId       Product Id
     * @param transactionDate Transaction date
     * @return SapProductPrice
     */
    SapProductPrice lookupProductPriceByTransDate(final Integer productId, final Date transactionDate);

    /**
     * Check if the date range is valid to insert a product price
     * @param sapProductId
     * @param startDate
     * @param endDate
     * @return
     */
    public Boolean checkDateRangeToInsertUpdateSapProductPrice(final Integer sapProductId, final Date startDate, final Date endDate, final Integer idExclude);
}
