package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.State;
import com.monsanto.eas.cia.model.area.SubRegion;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:14 PM To change this template use File |
 * Settings | File Templates.
 */
public interface StateDao extends IGenericDao<State> {

    Collection<State> lookupAllStates();

    Collection<State> lookupStatesForSubRegion(SubRegion subRegion);

    State lookupStateForDistrict(District district);
}
