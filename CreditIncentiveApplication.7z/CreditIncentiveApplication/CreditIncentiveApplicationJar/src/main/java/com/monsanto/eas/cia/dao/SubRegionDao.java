package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.model.area.Region;
import com.monsanto.eas.cia.model.area.SubRegion;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:14 PM To change this template use File |
 * Settings | File Templates.
 */
public interface SubRegionDao extends IGenericDao<SubRegion> {
  Collection<SubRegion> lookupAllSubRegions();
//  Year lookupYearByYear(String param);

    Collection<SubRegion> lookupSubRegionsForRegion(Region region);

}
