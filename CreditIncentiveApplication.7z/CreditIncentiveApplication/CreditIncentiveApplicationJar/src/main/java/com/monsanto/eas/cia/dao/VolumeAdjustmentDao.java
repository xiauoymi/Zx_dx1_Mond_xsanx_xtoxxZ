package com.monsanto.eas.cia.dao;

import com.monsanto.eas.cia.vo.ParamLookupSalesVO;
import com.monsanto.eas.cia.vo.VolumeAdjustmentSearchResultVO;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 22/12/2011
 * Time: 01:50:05 PM
 */
public interface VolumeAdjustmentDao extends Serializable {
    Collection<VolumeAdjustmentSearchResultVO> lookupSalesByParams(final ParamLookupSalesVO paramLookupSalesVO);
}
