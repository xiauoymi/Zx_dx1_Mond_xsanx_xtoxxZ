package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.CnPerDistributorViewDao;
import com.monsanto.eas.cia.model.CnPerDistributorView;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;


import javax.persistence.Query;
import java.util.Collection;
import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:37 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaCnPerDistributorViewDaoImpl
        extends JpaGenericDaoImpl<CnPerDistributorView> implements CnPerDistributorViewDao {

    public static final Logger LOGGER = Logger.getLogger(JpaCnPerDistributorViewDaoImpl.class);

    public Collection<CnPerDistributorView> lookupCreditNotesByYearAndMonthAndDistributor(int year, Date date, Long distributorId) {

        LOGGER.debug(year);
        LOGGER.debug(date);
        LOGGER.debug(distributorId);
        Query query = entityManager.createNamedQuery("CnPerDistributorView.findByCreditNotesByYearAndMonth");
        query.setParameter("programYear", year);
        query.setParameter("date", date);
        query.setParameter("distributorId", distributorId != null ? distributorId : 0);
        query.setParameter("filterFlag", distributorId != null ? 0 : 1);
        return query.getResultList();
    }

    public CnPerDistributorView findByDistributorProgramQuarterAndCreditNote(Long distributorId, Long programQuarterId, Long creditNoteId) {
        Query query = entityManager.createNamedQuery("CnPerDistributorView.findByDistributorProgramQuarterAndCreditNote");
        query.setParameter("distributorId", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        query.setParameter("creditNoteId", creditNoteId != null ? creditNoteId : 0);
        query.setParameter("filterFlag", creditNoteId != null ? 0 : 1);
        return (CnPerDistributorView)query.getSingleResult();
    }
}
