package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.CommercialSupervisorDao;
import com.monsanto.eas.cia.model.CommercialSupervisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 3:08:42 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaCommercialSupervisorDaoImpl extends JpaGenericDaoImpl<CommercialSupervisor> implements
    CommercialSupervisorDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

    public Collection<CommercialSupervisor> lookupAll() {
        return super.findByQueryName("CommercialSupervisor.lookupAll");
    }

    public CommercialSupervisor lookupCommercialSupervisorByName(String param) {
       return (CommercialSupervisor) entityManager
               .createNamedQuery("CommercialSupervisor.lookupCommercialSupervisorByName")
               .setParameter("name", param)
               .getSingleResult();
    }
}
