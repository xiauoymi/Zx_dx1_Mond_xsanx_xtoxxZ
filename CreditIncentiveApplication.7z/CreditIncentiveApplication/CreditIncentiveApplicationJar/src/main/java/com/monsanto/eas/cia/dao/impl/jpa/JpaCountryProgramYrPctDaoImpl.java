package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.CountryProgramYrPctDao;
import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.CountryProgramYrPct;
import com.monsanto.eas.cia.model.Year;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaCountryProgramYrPctDaoImpl extends JpaGenericDaoImpl<CountryProgramYrPct>
    implements CountryProgramYrPctDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;


  @SuppressWarnings("unchecked")  
  public Collection<CountryProgramYrPct> lookupAllCountryProgramYrPcts() {
    return super.findByQueryName("CountryProgramYrPct.lookupAllCountryProgramYrPct");
  }

  @SuppressWarnings("unchecked")
  public Collection<CountryProgramYrPct> lookupCountryProgramYrPctsByYear(Year year) {
    Collection<CountryProgramYrPct> pctCollection = super.findByQueryName("CountryProgramYrPct.lookupCountryProgramYrPctByYear", year.getId());
    return pctCollection;
  }

  @SuppressWarnings("unchecked")
  public CountryProgramYrPct lookupCountryProgramYrPctByCountryAndYear(Country country, Year year) {
    Collection<CountryProgramYrPct> pctCollection = super
        .findByQueryName("CountryProgramYrPct.lookupCountryProgramYrPctByCountryAndYear", country.getId(), year.getId());
    return pctCollection.isEmpty() ? null : pctCollection.iterator().next();
  }

  public Collection<CountryProgramYrPct> lookupActiveCountryProgramYrs() {
    return super.findByQueryName("CountryProgramYrPct.lookupOpenCountryProgramYears");  //To change body of implemented methods use File | Settings | File Templates.
  }
}
