package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.CreditNoteDao;
import com.monsanto.eas.cia.dao.TaxReserveDao;
import com.monsanto.eas.cia.model.CreditNote;
import com.monsanto.eas.cia.model.DistributorCnView;
import com.monsanto.eas.cia.model.TaxReserve;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 12:15:54 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaCreditNoteDaoImpl extends JpaGenericDaoImpl<CreditNote> implements CreditNoteDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public CreditNote lookupAllDistributorsWithCreditNotesForYearMonth(String distributorId, String year, String month) {
        CreditNote creditNote = (CreditNote) entityManager.createNamedQuery("lookupCreditNoteForDistributorYearMonth").setParameter("id", 4757).setParameter("monthyear", month + "/" + year).getSingleResult();
        return creditNote;
    }

    @SuppressWarnings("unchecked")
    public CreditNote lookupCreditNoteWithId(String creditNoteId) {
        CreditNote creditNote = (CreditNote) entityManager.createNamedQuery("lookupCreditNoteWithId").setParameter("id", Integer.valueOf(creditNoteId)).getSingleResult();
        return creditNote;
    }

    public BigDecimal sumCreditNotesAmmount(Long distributorId, Date startingDate, Date endingDate) {

        return (BigDecimal)entityManager.createNamedQuery("CreditNote.sumCreditNotesAmmount")
                .setParameter("distributorId", distributorId)
                .setParameter("startingDate", startingDate)
                .setParameter("endingDate", endingDate).getSingleResult();
    }

}
