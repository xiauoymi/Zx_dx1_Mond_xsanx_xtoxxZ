package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.CriteriaCreator;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.hibernate.Criteria;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.criterion.Property;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 19/11/2010
 * Time: 10:24:26 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaCriteriaDaoImpl implements CriteriaDao {
    @PersistenceContext (unitName="CreditIncentivesApplication")
    protected EntityManager entityManager;

    protected String modUser="BW";

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public <T extends BaseEntity> T findByCode(Class<T> _class, String code) {
        return findByProperty(_class,"code",code);        
    }

    public <T extends BaseEntity> T findByDescription(Class<T> _class, String description) {
        return findByProperty(_class,"description",description);
    }

    public <T extends BaseEntity> T findByProperty(Class<T> _class, String property, Object value) {
        if(property==null)
            throw new IllegalArgumentException("Not a property");
        if(value==null)return null;        
        Session     session =   getHibernateSession();
        Criteria criteria=session.createCriteria(_class);
        criteria.add(Property.forName(property).eq(value));
        return (T) criteria.uniqueResult();        
    }

    public <T> T findByCriteria(Class<T> _class,CriteriaCreator criteriaCreator){
        if(criteriaCreator==null)
            throw new IllegalArgumentException("No criteria creator provided");
        Session     session =   getHibernateSession();
        Criteria    criteria=   criteriaCreator.createCriteria(session);
        return (T) criteria.uniqueResult();
    }
    
    public <T extends BaseEntity> T findByCriteria(DefaultCriteriaCreator<T> criteriaCreator){
        return (T)findByCriteria(getGenericType(criteriaCreator),criteriaCreator);
    }

    public <T> List<T> findListByCriteria(Class<T> _class, CriteriaCreator criteriaCreator) {
        if(criteriaCreator==null)
            throw new IllegalArgumentException("No criteria creator provided");
        Session     session =   getHibernateSession();
        Criteria    criteria=   criteriaCreator.createCriteria(session);
        return (List<T>) criteria.list();
    }

    public <T extends BaseEntity> List<T> findListByCriteria(DefaultCriteriaCreator<T> criteriaCreator) {
        return (List<T>)findListByCriteria(getGenericType(criteriaCreator),criteriaCreator);
    }

    public Class<?> getGenericType(CriteriaCreator criteriaCreator){
        if(criteriaCreator==null) throw new IllegalArgumentException();
        Class<?> genericType=ObjectUtils.getGenericType(criteriaCreator.getClass(),BaseEntity.class);
        if(genericType==null)throw new IllegalArgumentException();
        return genericType;
    }
    
    public <T extends BaseEntity> void persist(T entity) {
        entityManager.persist(entity);            
        entityManager.flush();
    }

    public ScrollableResults getScrollableResults(CriteriaCreator criteriaCreator, ScrollMode mode) {
        if(criteriaCreator  ==  null)
            throw new IllegalArgumentException("Illegal criteria creator");
        if(mode             ==  null)
            throw new IllegalArgumentException("Illegal scroll mode");
        Session session     =   getHibernateSession();
        Criteria criteria   =   criteriaCreator.createCriteria(session);
        if(criteria         ==  null)
            return null;
        
        return criteria.scroll(mode);
    }

    public void synchronize(long numRecords, int flushAtThisNumberOfRecords) {
        Session     session     =   getHibernateSession();
        numRecords                  =   Math.abs(numRecords);
        flushAtThisNumberOfRecords  =   Math.abs(flushAtThisNumberOfRecords);
        flushAtThisNumberOfRecords  =   flushAtThisNumberOfRecords==0?1:flushAtThisNumberOfRecords;   
        if(numRecords!=0&&numRecords%flushAtThisNumberOfRecords==0){                       
            session.flush();
            session.clear();
        }
    }

    public Session getHibernateSession(){
        return (Session)entityManager.getDelegate();
    }
}
