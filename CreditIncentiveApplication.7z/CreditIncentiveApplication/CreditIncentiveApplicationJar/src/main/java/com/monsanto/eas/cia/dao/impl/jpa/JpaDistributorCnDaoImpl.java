package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.DistributorCnDao;
import com.monsanto.eas.cia.model.DistributorCnView;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 8/12/2010
 * Time: 10:58:16 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaDistributorCnDaoImpl extends JpaGenericDaoImpl<DistributorCnView> implements DistributorCnDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext (unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection<DistributorCnView> lookupAll() {
      List<DistributorCnView> distributorCnList = entityManager.createNamedQuery("distributorCreditView").getResultList();
        return distributorCnList;
    }

    @SuppressWarnings("unchecked")
    public Collection<DistributorCnView> lookupAllDistributorsWithCreditNotesForYearMonth(String year, String month) {
      List monthComList = new ArrayList();
      monthComList.add(month.toUpperCase());
      List<DistributorCnView> distributorCnList = entityManager.createNamedQuery("distributorCreditViewForYearMonth").setParameter(1, monthComList).setParameter("yr",year).getResultList();
        return distributorCnList;
    }

    @SuppressWarnings("unchecked")
    public Collection<DistributorCnView> lookupAllDistributorsWithNoCreditNotesForYearMonth(String year, String month) {
      List monthComList = new ArrayList();
      monthComList.add(month.toUpperCase());
      List<DistributorCnView> distributorCnList = entityManager.createNamedQuery("distinctDistributorsWithNoCreditNotes").setParameter(1, monthComList).setParameter("yr",year).getResultList();
        return distributorCnList;
    }

    @SuppressWarnings("unchecked")
    public Collection<DistributorCnView> lookupAllDistributorsWithCreditNotes() {
      List<DistributorCnView> distributorCnList = entityManager.createNamedQuery("distinctDistributorsWithCreditNotes").getResultList();
        return distributorCnList;
    }  

    @SuppressWarnings("unchecked")
    public Collection<DistributorCnView> lookupAllDistributorsSalesForYearMonth(String distId, Integer year, String month) {
      List monthComList = new ArrayList();
      monthComList.add(month.toUpperCase());
      List<DistributorCnView> distributorCnList = entityManager.createNamedQuery("distributorSalesForYearMonth").setParameter("id",Integer.parseInt(distId)).setParameter(1, monthComList).setParameter("yr",year).getResultList();
        return distributorCnList;
    }
}
