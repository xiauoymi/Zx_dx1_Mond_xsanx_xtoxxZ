package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.DistrictDao;
import com.monsanto.eas.cia.dao.StateDao;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.State;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaDistrictDaoImpl extends JpaGenericDaoImpl<District> implements DistrictDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext (unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<District> lookupAllDistricts() {
    return super.findByQueryName("District.lookupAll");
  }

  public Collection<District> lookupDistrictsForState(State state) {
    return super.findByQueryName("District.lookupByState", state.getId());
  }

}
