package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.IGenericDao;
import com.monsanto.eas.cia.util.MapBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 25, 2010 Time: 12:29:26 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaGenericDaoImpl<E> implements IGenericDao<E> {

    protected EntityManager entityManager;

    private final static String DAO_ADD_ENTITY_CANNOT_NULL = "[Assertion failed] : Entity can't be null. Please make sure the entity you want to persist is not null.";

    private final static String DAO_UPDATE_ENTITY_CANNOT_NULL = "[Assertion failed] : Entity can't be null. Please make sure the entity you want to update is not null.";

    private final static String DAO_SQL_QUERY_CANNOT_NULL = "[Assertion failed] : Query can't be empty or null. Please make sure the query you want to execute is excecutable.";

    private final static String DAO_PRIMARY_KEY_CANNOT_NULL = "[Assertion failed] : Entity can't be empty or null. Please make sure the entity you want to find by primary key is not null.";

    @Transactional
    public void delete(E entity) {
        Assert.notNull(entity, DAO_ADD_ENTITY_CANNOT_NULL);

        this.entityManager.remove(entity);
        this.entityManager.flush();
    }

    @Transactional
    public boolean contains(E entity) {
        Assert.notNull(entity, DAO_ADD_ENTITY_CANNOT_NULL);

        return this.entityManager.contains(entity);
    }

    @Transactional
    public void persist(E entity) {
        Assert.notNull(entity, DAO_ADD_ENTITY_CANNOT_NULL);
        this.entityManager.persist(entity);
    }

    @Transactional
    public void save(E entity) {
        Assert.notNull(entity, DAO_ADD_ENTITY_CANNOT_NULL);
        this.entityManager.persist(entity);
        this.entityManager.flush();
        this.entityManager.clear();
    }

    @Transactional
    public E merge(E entity) {
        Assert.notNull(entity, DAO_UPDATE_ENTITY_CANNOT_NULL);

        E value = this.entityManager.merge(entity);
        this.entityManager.flush();
        return value;
    }

    @SuppressWarnings("unchecked")
    @Transactional
    public E findByPrimaryKey(Class clazz, Object primaryKey) {
        Assert.notNull(primaryKey, DAO_PRIMARY_KEY_CANNOT_NULL);
        return (E) this.entityManager.find(clazz, primaryKey);
    }

    @SuppressWarnings("unchecked")
    @Transactional
    public E findByPrimaryKey(Class clazz, Integer primaryKey) {
        Assert.notNull(primaryKey, DAO_PRIMARY_KEY_CANNOT_NULL);

        return (E) this.entityManager.find(clazz, primaryKey);
    }

    @SuppressWarnings("unchecked")
    @Transactional
    public Collection<E> findByQuery(String queryName, Object... params) {
        Assert.notNull(queryName, DAO_SQL_QUERY_CANNOT_NULL);

        Query query = this.entityManager.createQuery(queryName);

        if (params != null && params.length > 0) {
            for (int i = 0; i < params.length; i++) {
                query.setParameter(i + 1, params[i]);
            }
        }

        return (List<E>) query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional
    public Collection<E> findByQueryName(String queryName, Object... params) {
        Assert.notNull(queryName, DAO_SQL_QUERY_CANNOT_NULL);

        Query query = this.entityManager.createNamedQuery(queryName);

        if (params != null && params.length > 0) {
            for (int i = 0; i < params.length; i++) {
                query.setParameter(i + 1, params[i]);
            }
        }

        return (List<E>) query.getResultList();
    }

    @Transactional
    @SuppressWarnings("unchecked")
    public List<E> findListByQueryName(String queryName, Map<String, Object> parameters) {
        Query query = entityManager.createNamedQuery(queryName);
        if (parameters != null) {
            for (String parameterName : parameters.keySet()) {
                if (parameterName == null) continue;
                query.setParameter(parameterName, parameters.get(parameterName));
            }
        }
        return query.getResultList();
    }


    @Transactional
    public E findByQueryName(String queryName, Map<String, Object> parameters) {
        List<E> result = findListByQueryName(queryName, parameters);
        if (result.isEmpty()) return null;
        return result.get(0);
    }

    @Transactional
    public void refresh(E entity) {
        Assert.notNull(entity, DAO_ADD_ENTITY_CANNOT_NULL);

        this.entityManager.refresh(entity);
    }

    public MapBuilder<String, Object> parameters() {
        return new MapBuilder<String, Object>();
    }

    public Map<String, Object> parameters(String parameterName, Object value) {
        return parameters().put(parameterName, value).map();
    }

    @PersistenceContext(unitName = "CreditIncentivesApplication")
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
}
