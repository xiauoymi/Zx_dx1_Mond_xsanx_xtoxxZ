package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdDistDao;
import com.monsanto.eas.cia.model.LdDist;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 8/12/2010
 * Time: 02:10:08 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository

public class JpaLdDistDaoImpl extends JpaGenericDaoImpl<LdDist> implements LdDistDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection lookupAll() {
        return super.findByQueryName("LdDist.lookupAll");
    }

    @SuppressWarnings("unchecked")    
    public Collection<LdDist> lookupByDistributorId(Integer distributorId) {
        return entityManager.createNamedQuery("LdDist.lookupByDistributorId")
                .setParameter("distributorId", distributorId)
                .getResultList();        
    }
}
