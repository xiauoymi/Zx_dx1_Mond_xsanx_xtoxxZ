package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdIncentiveDao;
import com.monsanto.eas.cia.model.LdIncentive;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 30/11/2010
 * Time: 08:25:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaLdIncentiveDaoImpl extends JpaGenericDaoImpl<LdIncentive> implements LdIncentiveDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")    
    public Collection lookupAll() {
        return super.findByQueryName("LdIncentive.lookupAll");  //To change body of implemented methods use File | Settings | File Templates.
    }

    @SuppressWarnings("unchecked")    
    public Collection<LdIncentive>lookupLdIncentiveByLocalDealerId(String param){
        return entityManager
                .createNamedQuery("LdIncentive.lookupLdIncentiveByLocalDealerId")
                .setParameter("rfc", param)
                .getResultList();
    }
}
