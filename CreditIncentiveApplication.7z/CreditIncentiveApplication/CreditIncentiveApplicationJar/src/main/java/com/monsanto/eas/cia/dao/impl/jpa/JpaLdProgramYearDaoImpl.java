package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdProgramYearDao;
import com.monsanto.eas.cia.model.LdProgramYear;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 9/12/2010
 * Time: 08:58:37 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository

public class JpaLdProgramYearDaoImpl extends JpaGenericDaoImpl<LdProgramYear> implements LdProgramYearDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */

    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection<LdProgramYear> lookupAll() {
        return super.findByQueryName("LdProgramYear.lookupAll");  //To change body of implemented methods use File | Settings | File Templates.
    }

    @SuppressWarnings("unchecked")    
    public Collection<LdProgramYear> lookupLdProgramYearByYearId(String param) {
        return entityManager
                .createNamedQuery("LdProgramYear.lookupLdProgramYearByYearId")
                .setParameter("idYear", param)
                .getResultList();  //To change body of implemented methods use File | Settings | File Templates.
    }
}
