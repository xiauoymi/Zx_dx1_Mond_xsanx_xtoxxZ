package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdSalesCnDao;
import com.monsanto.eas.cia.dao.TaxReserveDao;
import com.monsanto.eas.cia.model.DistributorCnView;
import com.monsanto.eas.cia.model.LdSalesCn;
import com.monsanto.eas.cia.model.TaxReserve;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 12:15:54 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaLdSalesCnDaoImpl extends JpaGenericDaoImpl<LdSalesCn> implements LdSalesCnDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;
  @SuppressWarnings("unchecked")
  public Collection<LdSalesCn> lookupAllCreditNotesPerSale(String salesId) {
    List<LdSalesCn> distributorCnList = entityManager.createNamedQuery("creditNotesPerSale").setParameter("id",Integer.parseInt(salesId)).getResultList();
    return distributorCnList;
  }

}
