package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdSalesDao;
import com.monsanto.eas.cia.model.LdSales;
import java.util.Collections;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import java.util.Collection;
import java.util.Date;


/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 30/11/2010
 * Time: 08:25:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaLdSalesDaoImpl extends JpaGenericDaoImpl<LdSales> implements LdSalesDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")    
    public Collection<LdSales> lookupAll() {
        return super.findByQueryName("LdSales.lookupAll");
    }

    public Collection<LdSales> lookupByIds(Collection<Integer> ids) {
        if(ids==null||ids.isEmpty()) {
            return Collections.emptyList();
        }
        Query query = this.entityManager.createNamedQuery("LdSales.findSalesByIds").setParameter("idList", ids);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    public LdSales lookupAllSalesWithId(Integer salesId) {
        return (LdSales)this.entityManager.createNamedQuery("LdSales.lookupSalesWithId").setParameter("id",salesId).getSingleResult();
    }

    @SuppressWarnings("unchecked")
    public Collection lookupBWDLSExport() {
        Query query = this.entityManager.createNativeQuery("SELECT DISTINCT f.YEAR,g.NAME,h.DESCRIPTION,i.NAME,b.POS_NAME,b.RFC,b.ADDRESS_1,b.POSTAL_CODE,b.PHONE,b.FAX,b.EMAIL,b.BIRTHDAY,b.BUSINESS_ANIVERSARY,b.AGREEMENT_NUMBER,c.NAME as DISTRIBUTOR_NAME,(SELECT SUM(j.MIN_INCENTIVE) FROM LD_INCENTIVE j, LOCAL_DEALER k, LD_PROGRAM_YEAR l, YEAR m WHERE j.LOCAL_DEALER_ID = k.ID AND l.LD_ID = j.LOCAL_DEALER_ID AND m.ID = l.YEAR_ID) as MIN_TARGET,(SELECT SUM(j.MAX_INCENTIVE) FROM LD_INCENTIVE j, LOCAL_DEALER k, LD_PROGRAM_YEAR l, YEAR m WHERE j.LOCAL_DEALER_ID = k.ID AND l.LD_ID = j.LOCAL_DEALER_ID AND m.ID = l.YEAR_ID) as MAX_TARGET FROM LD_DIST a,LOCAL_DEALER b,DISTRIBUTOR c,LD_INCENTIVE d, LD_SALES e, YEAR f, COMMERCIAL_SUPERVISOR g, TERRITORY h, ATC i WHERE a.LD_ID = b.ID AND a.DISTRIBUTOR_ID = c.ID AND d.LOCAL_DEALER_ID = b.ID AND e.LD_DIST_ID = a.ID AND b.TERRITORY_ID = h.ID AND b.ID = d.LOCAL_DEALER_ID AND d.PROGRAM_QUARTER_ID IN (1,4) ORDER BY f.YEAR");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")    
    public Collection<LdSales> lookupBWTransactionExport() {
        Query query = this.entityManager.createNativeQuery("SELECT DISTINCT a.SALES_DATE,a.TRANSACTION_NUMBER,b.DESCRIPTION as TRANSACTION_DESC,c.DESCRIPTION as TERRITORY_DESC,d.AGREEMENT_NUMBER,e.ID,d.NAME,d.POS_NAME,h.CODE,h.LINE,a.SALES_VOLUME,d.AGREEMENT_NUMBER || ' ' || d.POS_NAME,a.VOLUME_ASSIGNED,a.MODIFIED_SALES_VOLUME,a.VALID_FOR_INCENTIVE_PLANNING FROM LD_SALES a, TRANSACTION_TYPE b, TERRITORY c, LOCAL_DEALER d, DISTRIBUTOR e, LD_DIST f, PRODUCT_PRICE g, PRODUCT h WHERE a.DOCUMENT_TYPE_ID = b.ID AND a.LD_DIST_ID = f.ID AND f.DISTRIBUTOR_ID = e.ID AND d.id = f.LD_ID ORDER BY a.SALES_DATE");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    public Collection<LdSales> lookupSalesForDistributorYearMonth(String distributorId, String year, String month) {      
      return this.entityManager.createNamedQuery("LdSales.lookupSalesForYearMonthDistributor").setParameter("distId",distributorId).setParameter("monthyear",month.toUpperCase()+"/"+year).getResultList();
    }

    public void updateIncentiveAmount(Long distributorId, Long localDealerId, Date startingDate, Date endingDate, Double incentivePct){
        Query query = this.entityManager.createNamedQuery("LdSalesIncentiveAmountBatchUpdate");
        query.setParameter("distributorId",distributorId);
        query.setParameter("localDealerId",localDealerId);
        query.setParameter("startingDate",startingDate);
        query.setParameter("endingDate",endingDate);
        query.setParameter("incentivePct",incentivePct);
        query.executeUpdate();
    }
}
