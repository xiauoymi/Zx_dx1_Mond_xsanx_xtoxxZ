/*
 Copyright:  Copyright  2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LdSalesPerQuarterDao;
import com.monsanto.eas.cia.model.LdSalesPerQuarter;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Repository
public class JpaLdSalesPerQuarterDaoImpl extends JpaGenericDaoImpl<LdSalesPerQuarter> implements LdSalesPerQuarterDao {
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<LdSalesPerQuarter> lookupLdSalesPerQuarterByYear(Integer year) {
    return entityManager
        .createNamedQuery("LdSalesPerQuarter.lookupLdSalesPerQuarterByYear")
        .setParameter("year", year)
        .getResultList();
  }

  @SuppressWarnings("unchecked")
  public LdSalesPerQuarter lookupLdSalesPerQuarterByLocalDealer(String localDealerId, String programQuarterId) {
    return (LdSalesPerQuarter) entityManager
        .createNamedQuery("LdSalesPerQuarter.lookupSalesByQuarterAndLeader")
        .setParameter("ldId", localDealerId)
        .setParameter("programQuarterId", programQuarterId)
        .getSingleResult();
  }
}