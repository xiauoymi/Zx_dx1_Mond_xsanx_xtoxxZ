package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.LocalDealerDao;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.vo.LdCreditNoteVO;
import com.monsanto.eas.cia.vo.LdGoalToVolumeRecordVO;
import com.monsanto.eas.cia.vo.LdRegisteredVolumeLitersVO;
import com.monsanto.eas.cia.vo.LocalDealerStatementRecordVO;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:09:52 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaLocalDealerDaoImpl extends JpaGenericDaoImpl<LocalDealer> implements LocalDealerDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection<LocalDealer> lookupAllLocalDealers() {
        return super.findByQueryName("LocalDealer.lookupAll");
    }

    @SuppressWarnings("unchecked")
    public Collection<LocalDealer> lookupAllUnsignedLocalDealers() {
        return super.findByQueryName("LocalDealer.lookupAllUnSignedLocalDealers");
    }

    public LocalDealer lookUpLocalDealer(Integer localDealerId) {
        return (LocalDealer) entityManager
                .createNamedQuery("LocalDealer.lookupLocalDealerById")
                .setParameter("id", localDealerId)
                .getSingleResult();
    }

    @SuppressWarnings("unchecked")
    public Collection<LocalDealer> lookupBWExport(String queryName, Object... params) {
        //return super.findByQueryName("LocalDealer.bwExport");
        System.out.println(" -- lookupBWExport -- ");
        Query query = this.entityManager.createNativeQuery(queryName);
        List lstRes = query.getResultList();
        System.out.println(" -- lstRes -- " + lstRes);
        return lstRes;//(List) query.getResultList();

    }

    @SuppressWarnings("unchecked")
    public LocalDealer lookupLocalDealerByRfc(String param) {
        return (LocalDealer) entityManager
                .createNamedQuery("LocalDealer.lookupLocalDealerByRfc")
                .setParameter("rfc", param)
                .getSingleResult();
    }

    @SuppressWarnings("unchecked")
    public LocalDealer lookupLocalDealerByNameAndPosName(String param1, String param2) {
        return (LocalDealer) entityManager
                .createNamedQuery("LocalDealer.lookupLocalDealerByNameAndPosName")
                .setParameter("name", param1)
                .setParameter("posName", param2)
                .getSingleResult();
    }

    @SuppressWarnings("unchecked")
    public LocalDealer lookupLocalDealerByAgreementNumberAndRfc(String agreementNumber, String rfc) {
        return (LocalDealer) entityManager
                .createNamedQuery("LocalDealer.lookupLocalDealerByAgreementNumberAndRfc")
                .setParameter("agreementNumber", agreementNumber)
                .setParameter("rfc", rfc)
                .getSingleResult();
    }

    public void setAgreementNumber(LocalDealer localDealer) {
        StringBuffer aggrementNumber = new StringBuffer();
        String suffix;
        Session session = (Session) entityManager.getDelegate();
        localDealer.setAgreementNumber(UUID.randomUUID().toString());
        session.save(localDealer);
        session.lock(localDealer, LockMode.UPGRADE_NOWAIT);
        Criteria criteria = session.createCriteria(LocalDealer.class);
        criteria.add(Restrictions.eq("subRegion.id", localDealer.getSubRegion().getId()));
        List list = criteria.list();
        int suffixNumber = list.size() + 1;
        suffix = Integer.toString(suffixNumber);
        aggrementNumber.append(localDealer.getSubRegion().getShortcut());
        aggrementNumber.append(StringUtils.leftPad(suffix, 5, "0").toString());
        localDealer.setAgreementNumber(aggrementNumber.toString());
        session.save(localDealer);
        session.flush();
    }

    private void setProgramQuarterLabels(Query query, Integer year) {

        Collection<ProgramQuarter> programQuarters = entityManager.createNamedQuery("ProgramQuarter.lookupByYear")
                .setParameter("year", year).getResultList();

        SimpleDateFormat monthSdf = new SimpleDateFormat("MMM", new Locale("es", "MX"));
        String quarterLabel;
        for (ProgramQuarter programQuarter : programQuarters) {
            switch (programQuarter.getQuarterType().getQuarterNum()) {
                case 1:
                    /*quarterLabel = String.format("1er periodo (%s-%s)",
                            monthSdf.format(programQuarter.getQuarterStart()),
                            monthSdf.format(programQuarter.getQuarterEnd()));*/
                    query.setParameter("firstQuarterLabel", "1er periodo");
                    break;
                case 2:
                    query.setParameter("secondQuarterLabel", "2° periodo");
                    break;
                case 3:
                    query.setParameter("thirdQuarterLabel", "3er periodo");
                    break;
                case 4:
                    query.setParameter("fourthQuarterLabel", "4° periodo");
                    break;
            }
        }
    }

    public Collection<LdGoalToVolumeRecordVO> getLdGoalToVolumeRecordVOCol(Integer id, Integer year) {

        Query query = entityManager.createNamedQuery("LDGoalToVolumeRecordSubReportData");
        query.setParameter("id", id);
        query.setParameter("year", year);

        setProgramQuarterLabels(query, year);
        List<Object[]> resultList = query.getResultList();
        List<LdGoalToVolumeRecordVO> result = new ArrayList<LdGoalToVolumeRecordVO>(resultList.size());
        for (Object[] obj : resultList) {
            LdGoalToVolumeRecordVO vo = new LdGoalToVolumeRecordVO();
            vo.setQuarterLabel((String) obj[0]);
            vo.setMaxIncentive((BigDecimal) obj[1]);
            vo.setMinIncentive((BigDecimal) obj[2]);
            vo.setVolumePerQuarter((BigDecimal) obj[3]);
            vo.setIncentivePercentage((BigDecimal) obj[4]);
            vo.setTotalToIncentive((BigDecimal) obj[5]);
            result.add(vo);
        }
        return result;
    }

    public Collection<LdRegisteredVolumeLitersVO> getLdRegisteredVolumeLitersVOCol(Integer id, Integer year) {

        Query query = entityManager.createNamedQuery("LDRegisteredVolumeLitersSubReportData");
        query.setParameter("id", id);
        query.setParameter("year", year);
        List<Object[]> resultList = query.getResultList();
        List<LdRegisteredVolumeLitersVO> result = new ArrayList<LdRegisteredVolumeLitersVO>(resultList.size());
        for (Object[] obj : resultList) {
            LdRegisteredVolumeLitersVO vo = new LdRegisteredVolumeLitersVO();
            vo.setVolume((BigDecimal) obj[0]);
            vo.setDistributor((String) obj[1]);
            vo.setProduct((String) obj[2]);
            result.add(vo);
        }
        return result;
    }

    public Collection<LdCreditNoteVO> getLdCreditNoteVOCol(Integer id, Integer year) {

        Query query = entityManager.createNamedQuery("LDCreditNoteSubReportData");
        query.setParameter("id", id);
        query.setParameter("year", year);
        setProgramQuarterLabels(query, year);
        List<Object[]> resultList = query.getResultList();
        List<LdCreditNoteVO> result = new ArrayList<LdCreditNoteVO>(resultList.size());
        for (Object[] obj : resultList) {
            LdCreditNoteVO vo = new LdCreditNoteVO();
            vo.setQuarterLabel((String) obj[0]);
            vo.setDistributor((String) obj[2]);
            vo.setTotalIncentives((BigDecimal) obj[5]);
            result.add(vo);
        }
        return result;
    }

    public Map<String, BigDecimal> getLdCreditNoteVODistTotals(Integer id, Integer year) {

        Query query = entityManager.createNamedQuery("LdCreditNoteVODistTotal");
        query.setParameter("id", id);
        query.setParameter("year", year);
        List<Object[]> resultList = query.getResultList();
        Map<String, BigDecimal> result = new HashMap<String, BigDecimal>();
        for (Object[] obj : resultList) {
            result.put((String) obj[0], (BigDecimal) obj[1]);
        }
        return result;

    }
}
