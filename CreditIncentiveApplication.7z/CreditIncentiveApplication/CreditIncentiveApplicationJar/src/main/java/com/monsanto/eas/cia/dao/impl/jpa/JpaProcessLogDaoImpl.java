package com.monsanto.eas.cia.dao.impl.jpa;

import org.springframework.stereotype.Repository;

import com.monsanto.eas.cia.dao.ProcessLogDao;
import com.monsanto.eas.cia.model.ProcessLog;

@Repository
public class JpaProcessLogDaoImpl  extends JpaGenericDaoImpl<ProcessLog> implements ProcessLogDao {
	
}
