package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.ProductLineDao;
import com.monsanto.eas.cia.model.ProductLine;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 11:56:12 AM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaProductLineDaoImpl extends JpaGenericDaoImpl<ProductLine> implements ProductLineDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<ProductLine> lookupAll(Integer id) {
    return entityManager.createNamedQuery("ProductLine.lookUpAllProductLines").getResultList();
  }
}
