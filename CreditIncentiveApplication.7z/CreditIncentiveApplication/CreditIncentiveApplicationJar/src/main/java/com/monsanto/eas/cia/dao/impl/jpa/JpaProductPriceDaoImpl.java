package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.ProductPriceDao;
import com.monsanto.eas.cia.model.ProductPrice;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 13/12/2010
 * Time: 12:25:59 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaProductPriceDaoImpl extends JpaGenericDaoImpl<ProductPrice> implements ProductPriceDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")    
    public Collection<ProductPrice> lookupAll() {
        return super.findByQueryName("ProductPrice.lookupAll");  //To change body of implemented methods use File | Settings | File Templates.
    }

    @SuppressWarnings("unchecked")    
    public ProductPrice lookupProductPriceByProductId(String param) {
        return (ProductPrice)entityManager
                .createNamedQuery("ProductPrice.lookupProductPriceByProductId")
                .setParameter("idProduct", param)
                .getSingleResult();  //To change body of implemented methods use File | Settings | File Templates.
    }
}
