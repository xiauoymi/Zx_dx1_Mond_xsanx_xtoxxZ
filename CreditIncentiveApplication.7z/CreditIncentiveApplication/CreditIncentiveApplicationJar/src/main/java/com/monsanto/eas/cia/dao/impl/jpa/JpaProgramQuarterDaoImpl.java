package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.ProgramQuarterDao;
import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.ProgramQuarter;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaProgramQuarterDaoImpl extends JpaGenericDaoImpl<ProgramQuarter> implements ProgramQuarterDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public ProgramQuarter lookupProgramQuarterByTransaction(String param) {
//    return (ProgramQuarter) entityManager
//            .createNamedQuery("ProgramQuarter.lookupProgramQuarterByTransaction")
//            .setParameter("transactionNumber", param)
//            .getSingleResult();

        ProgramQuarter quarter = null;

        String querySt = "SELECT ld.id AS ld_id, progquater.id AS prog_quarter_id, countryprogyear.max_pct AS max_pct, countryprogyear.min_pct AS min_pct, SUM(sl.vol_to_incentive) AS volume_per_quarter FROM cia. local_dealer ld, cia. ld_sales sl, cia. ld_program_year ldprogyear, cia. ld_dist lddist, cia. program_quarter progquater,  cia. country_program_yr_pct countryprogyear  WHERE countryprogyear.country_id = ld.country_id AND countryprogyear.year_id = ldprogyear.year_id AND ldprogyear.ld_id = ld.id AND countryprogyear.id = progquater.country_program_id AND sl.sales_date BETWEEN progquater.quarter_start AND progquater.quarter_end AND sl.ld_dist_id = lddist.id  AND lddist.ld_id = ld.id AND lddist.LD_PROGRAM_YEAR_ID = ldprogyear.id and sl.transaction_number = :tn GROUP BY ld.id, progquater.id, countryprogyear.max_pct, countryprogyear.min_pct";

        Query query = this.entityManager.createNativeQuery(querySt);
        query.setParameter("tn", param);
        Object[] result = (Object[]) query.getSingleResult();

        if (result != null) {
            if (result.length == 5) {
                quarter = new ProgramQuarter();
                quarter.setId(((BigDecimal) result[1]).intValue());
            }
        }
        return quarter;
    }

    @SuppressWarnings("unchecked")
    public ProgramQuarter lookupProgramQuarterByDate(Date date) {
        return (ProgramQuarter) entityManager
                .createNamedQuery("ProgramQuarter.lookupProgramQuarterWithDates")
                .setParameter("quarterDate", date).getSingleResult();
    }

    public ProgramQuarter lookupProgramQuarterByDate(Date date, Country country) {
        return (ProgramQuarter) entityManager
                .createNamedQuery("ProgramQuarter.lookupProgramQuarterWithDateAndCountry")
                .setParameter("quarterDate", date)
                .setParameter("countryId", country.getId()).getSingleResult();
    }

    public Collection<ProgramQuarter> lookupValidProgramQuarterBetweenDates(Date startingDate, Date endingDate, int year) {

        return entityManager
                .createNamedQuery("ProgramQuarter.lookupValidProgramQuarterBetweenDates")
                .setParameter("startingDate", startingDate)
                .setParameter("endingDate", endingDate)
                .setParameter("year", year).getResultList();

    }

    public ProgramQuarter findByQuarterNumAndYear(int quarterNum, int year) {
        return (ProgramQuarter) entityManager
                .createNamedQuery("ProgramQuarter.findByQuarterNumAndYear")
                .setParameter("quarterNum", quarterNum)
                .setParameter("year", year).getSingleResult();
    }

    //  @SuppressWarnings("unchecked")
//  @Override
//  public Collection<QuarterType> lookupAllQuarters() {
//    return super.findByQueryName("Year.lookupAllQuarters");
//  }
}
