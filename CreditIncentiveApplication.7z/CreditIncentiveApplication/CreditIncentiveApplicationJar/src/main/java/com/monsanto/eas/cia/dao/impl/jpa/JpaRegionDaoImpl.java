package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.AreaDao;
import com.monsanto.eas.cia.dao.RegionDao;
import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.area.Region;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.apache.poi.ss.util.RegionUtil;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaRegionDaoImpl extends JpaGenericDaoImpl<Region> implements RegionDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<Region> lookupAllRegions() {
    return super.findByQueryName("Region.lookupAll");
  }

    public Region lookupRegionForSubRegion(SubRegion subRegion){
        Collection<Region> regionList = super.findByQueryName("Region.lookupRegionForSubRegion", subRegion.getId());
        if (null != regionList && !regionList.isEmpty()){
            return regionList.iterator().next();
        }
        return null;
    }

}
