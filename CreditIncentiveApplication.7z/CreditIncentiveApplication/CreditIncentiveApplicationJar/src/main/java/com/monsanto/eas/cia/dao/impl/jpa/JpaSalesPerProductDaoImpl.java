package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SalesPerProductDao;
import com.monsanto.eas.cia.dao.impl.jpa.JpaGenericDaoImpl;
import com.monsanto.eas.cia.model.LdSalesPerProduct;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jbecerr
 * Date: 28/04/2011
 * Time: 09:51:53 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaSalesPerProductDaoImpl extends JpaGenericDaoImpl<LdSalesPerProduct> implements SalesPerProductDao{
    private static final long serialVersionUID = 13L;

    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection<LdSalesPerProduct> lookupLdSalesPerProductByYearAndLeader(Integer localDealerId, Integer year) {
        Query query = entityManager.createNamedQuery("LdSalesPerProduct.lookupLdSalesPerProductByYearAndLeader");
        query.setParameter("ldId",localDealerId);
        query.setParameter("year",year);
        List<LdSalesPerProduct> ldSalesPerProductList = query.getResultList();

        return ldSalesPerProductList;
    }

    @SuppressWarnings("unchecked")
    public LdSalesPerProduct lookupLdSalesPerProductByYearAndLeaderAndProduct(Integer localDealerId, Integer year, Integer productLineId) {
        Query query = entityManager.createNamedQuery("LdSalesPerProduct.lookupLdSalesPerProductByYearAndLeaderAndProduct");
        query.setParameter("ldId",localDealerId);
        query.setParameter("year",year);
        query.setParameter("productLineId", productLineId);
        LdSalesPerProduct ldSalesPerProductList = (LdSalesPerProduct) query.getSingleResult();

        return ldSalesPerProductList;
    }
}
