package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SalesPerQuarterDao;
import com.monsanto.eas.cia.model.LdSalesPerQuarter;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Created by IntelliJ IDEA.
 * Date: 13/04/2011
 * Time: 09:54:47 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaSalesPerQuarterDaoImpl extends JpaGenericDaoImpl<LdSalesPerQuarter> implements SalesPerQuarterDao{

    private static final long serialVersionUID = 12L;

    @PersistenceContext (unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public LdSalesPerQuarter lookupSalesByQuarterAndLeader(String quarterId, String leaderId) {

        Query query = entityManager.createNamedQuery("LdSalesPerQuarter.lookupSalesByQuarterAndLeader");
        query.setParameter("ldId",leaderId);
        query.setParameter("programQuarterId",quarterId);

        return (LdSalesPerQuarter) query.getSingleResult();
    }
}
