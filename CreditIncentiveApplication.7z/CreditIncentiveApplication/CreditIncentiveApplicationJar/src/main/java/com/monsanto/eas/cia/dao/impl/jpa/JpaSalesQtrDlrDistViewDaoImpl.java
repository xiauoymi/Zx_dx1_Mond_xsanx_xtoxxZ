package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SalesQtrDlrDistViewDao;
import com.monsanto.eas.cia.model.SalesQtrDlrDistView;
import com.monsanto.eas.cia.model.SalesQtrProdDlrDistView;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:37 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaSalesQtrDlrDistViewDaoImpl
        extends JpaGenericDaoImpl<SalesQtrDlrDistView> implements SalesQtrDlrDistViewDao {

    public static final Logger LOGGER = Logger.getLogger(JpaSalesQtrDlrDistViewDaoImpl.class);

    public BigDecimal[] findIncentiveDebtByDistQuarterYearGroupedByDist(Long distributorId, Long programQuarterId) {
        LOGGER.debug(distributorId);
        LOGGER.debug(programQuarterId);
        Query query = entityManager.createNamedQuery("SalesQtrDlrDistView.findIncentiveDebtByDistQuarterYearGroupedByDist");
        query.setParameter("distributorId", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        Object[] result = (Object[])query.getSingleResult();
        return new BigDecimal[]{(BigDecimal)result[0], (BigDecimal) result[1], (BigDecimal) result[2]};
    }

    public Collection<SalesQtrDlrDistView> findByDistributorAndProgramQuarterId(Long distributorId, Long programQuarterId) {
        LOGGER.debug(distributorId);
        LOGGER.debug(programQuarterId);
        Query query = entityManager.createNamedQuery("SalesQtrDlrDistView.findByDistributorAndProgramQuarterId");
        query.setParameter("distributorId", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        return query.getResultList();
    }


}
