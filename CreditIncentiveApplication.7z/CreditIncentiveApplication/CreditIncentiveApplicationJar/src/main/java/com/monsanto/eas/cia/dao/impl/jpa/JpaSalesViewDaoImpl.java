package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SalesViewDao;
import com.monsanto.eas.cia.model.SalesView;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:37 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaSalesViewDaoImpl
        extends JpaGenericDaoImpl<SalesView> implements SalesViewDao {

    public static final Logger LOGGER = Logger.getLogger(JpaSalesViewDaoImpl.class);

    public Collection<SalesView> findByDistributorAndProgramQuarterAndCreditNoteNull(Long distributorId, Long programQuarterId){
        LOGGER.debug(distributorId);
        LOGGER.debug(programQuarterId);
        Query query = entityManager.createNamedQuery("SalesView.findByDistributorAndProgramQuarterAndCreditNoteNull");
        query.setParameter("distributorId", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        return query.getResultList();
    }
}
