package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SapDistributorDao;
import com.monsanto.eas.cia.model.SapDistributor;
import com.monsanto.eas.cia.vo.DistributorStatementGoalsVO;
import com.monsanto.eas.cia.vo.DistributorStatementPerDealerAndProductVO;
import com.monsanto.eas.cia.vo.DistributorStatementPerSubRegionVO;
import com.monsanto.eas.cia.vo.LdRegisteredVolumeLitersVO;
import org.springframework.stereotype.Repository;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Repository
public class JpaSapDistributorDaoImpl extends JpaGenericDaoImpl<SapDistributor> implements SapDistributorDao {

    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    public Collection<SapDistributor> lookupSapDistributorByCodeOrDescriptionOrEmail(String filter) {
        Query query = entityManager.createNamedQuery("SapDistributor.lookupSapDistributorByCodeOrDescriptionOrEmail");
        query.setParameter("filter", "%" + filter + "%");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    public Collection<SapDistributor> lookupAll() {
        return super.findByQueryName("SapDistributor.lookupAll");
    }

    public SapDistributor lookupSapDistributorById(String distId) {
        return (SapDistributor) entityManager
                .createNamedQuery("SapDistributor.lookupSapDistributorById")
                .setParameter("id", Integer.valueOf(distId))
                .getSingleResult();
    }

    public SapDistributor lookupSapDistributorByCode(String code) {
        return (SapDistributor) entityManager
                .createNamedQuery("SapDistributor.lookupDistributorByCode")
                .setParameter("code", code)
                .getSingleResult();
    }

    public Collection<SapDistributor> saveAll(Collection<SapDistributor> sapDistributors) {
        Collection<SapDistributor> result = new ArrayList<SapDistributor>(sapDistributors.size());
        for (SapDistributor distributor : sapDistributors) {
            SapDistributor pd = findByPrimaryKey(SapDistributor.class, distributor.getId());
            pd.setEmail(distributor.getEmail());
            pd.setDescription(distributor.getDescription());
            pd.setCode(distributor.getCode());
            result.add(merge(pd));
        }
        return result;
    }

    public Collection<DistributorStatementPerDealerAndProductVO> findDistributorStatementPerDealerAndProduct(Long distributorId, Long programQuarterId) {
        Query query = entityManager.createNamedQuery("SalesQtrProdDlrDistView.findDistributorStatementPerDealerAndProduct");
        query.setParameter("id", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        return query.getResultList();
    }

    public Collection<DistributorStatementPerSubRegionVO> findDistributorStatementPerSubRegion(Long distributorId, Long programQuarterId) {
        Query query = entityManager.createNamedQuery("SalesView.findDistributorStatementPerSubRegion");
        query.setParameter("distributorId", distributorId);
        query.setParameter("programQuarterId", programQuarterId);
        return query.getResultList();
    }

    public Collection<DistributorStatementGoalsVO> findDistributorStatementGoals(Long distributorId, Integer year) {
        Query query = entityManager.createNamedQuery("DistributorStatementGoals");
        query.setParameter("id", distributorId);
        query.setParameter("year", year);
        List<Object[]> resultList = query.getResultList();
        List<DistributorStatementGoalsVO> result = new ArrayList<DistributorStatementGoalsVO>(resultList.size());
        for (Object[] obj : resultList) {
            DistributorStatementGoalsVO vo = new DistributorStatementGoalsVO();
            int i = 0;
            vo.setSubRegion((String)obj[i++]);
            vo.setAgreementNumber((String)obj[i++]);
            vo.setName((String)obj[i++]);
            vo.setFiscalName((String)obj[i++]);
            vo.setRfc((String)obj[i++]);
            vo.setMunicipality((String)obj[i++]);
            vo.setState((String)obj[i++]);
            vo.setIncentivePctFirstQuarter((BigDecimal)obj[i++]);
            vo.setIncentivePctSecondQuarter((BigDecimal)obj[i++]);
            vo.setIncentivePctThirdQuarter((BigDecimal)obj[i++]);
            vo.setIncentivePctFourthQuarter((BigDecimal)obj[i++]);
            vo.setIncentiveVolumeFirstQuarter((BigDecimal)obj[i++]);
            vo.setIncentiveVolumeSecondQuarter((BigDecimal)obj[i++]);
            vo.setIncentiveVolumeThirdQuarter((BigDecimal)obj[i++]);
            vo.setIncentiveVolumeFourthQuarter((BigDecimal)obj[i++]);
            vo.setPctAnnualGoal((BigDecimal)obj[i++]);
            vo.setPctFirstQuarterGoal((BigDecimal)obj[i++]);
            vo.setPctSecondQuarterGoal((BigDecimal)obj[i++]);
            vo.setPctThirdQuarterGoal((BigDecimal)obj[i++]);
            vo.setPctFourthQuarterGoal((BigDecimal)obj[i++]);
            result.add(vo);
        }
        return result;

    }
}
