package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.SapProductPriceDao;
import com.monsanto.eas.cia.model.SapProductPrice;
import com.monsanto.eas.cia.util.DateUtil;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 8/02/13
 * Time: 10:11 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaSapProductPriceDaoImpl extends JpaGenericDaoImpl<SapProductPrice> implements SapProductPriceDao {

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    /**
     * @see SapProductPriceDao#lookupAll()
     */
    public Collection<SapProductPrice> lookupAll() {
        return super.findByQueryName("SapProductPrice.lookupAll");
    }

    /**
     * @see SapProductPriceDao#lookupProductPriceById(Integer)
     */
    public SapProductPrice lookupProductPriceById(final Integer id) {
        SapProductPrice sapProductPrice = null;
        final List<SapProductPrice> sapProductPrices = this.entityManager.createNamedQuery("SapProductPrice.lookupProductPriceById").setParameter("id", id).getResultList();
        if (!sapProductPrices.isEmpty()) {
            sapProductPrice = sapProductPrices.get(0);
        }
        return sapProductPrice;
    }

    /**
     * @see SapProductPriceDao#lookupProductPriceByTransDate(Integer, Date)
     */
    public SapProductPrice lookupProductPriceByTransDate(final Integer productId, final Date transactionDate) {
        SapProductPrice sapProductPrice = null;
        final List<SapProductPrice> sapProductPrices = this.entityManager.createNamedQuery("SapProductPrice.lookupProductPriceByTransDate").setParameter("productId", productId).setParameter("transactionDate", transactionDate).getResultList();
        if (!sapProductPrices.isEmpty()) {
            sapProductPrice = sapProductPrices.get(0);
        }
        return sapProductPrice;
    }

    public Boolean checkDateRangeToInsertUpdateSapProductPrice(final Integer sapProductId, final Date startDate, final Date endDate, final Integer idExcluded) {

        Boolean isValid = true;

        String nativeQuery ="SELECT COUNT (*) FROM CIA.SAP_PRODUCT_PRICE " +
                            " WHERE id IN (" +
                            "   (SELECT id FROM CIA.SAP_PRODUCT_PRICE WHERE sap_product_id = :sapProductId AND :startDate BETWEEN start_date AND end_date) UNION " +
                            "   (SELECT id FROM CIA.SAP_PRODUCT_PRICE WHERE sap_product_id = :sapProductId AND :endDate BETWEEN start_date AND end_date) UNION " +
                            "   (SELECT id FROM CIA.SAP_PRODUCT_PRICE WHERE sap_product_id = :sapProductId AND start_date BETWEEN :startDate AND :endDate) UNION" +
                            "   (SELECT id FROM CIA.SAP_PRODUCT_PRICE WHERE sap_product_id = :sapProductId AND end_date BETWEEN :startDate AND :endDate)" +
                            ")";

        nativeQuery+= idExcluded!=null ? " AND id NOT IN (:idExcluded) ":"";

        Query query = entityManager.createNativeQuery(nativeQuery)
                .setParameter("sapProductId",sapProductId)
                .setParameter("startDate", startDate)
                .setParameter("endDate", endDate);

        if(idExcluded!=null) {
            query.setParameter("idExcluded",idExcluded);
        }

        BigDecimal total = (BigDecimal)query.getSingleResult();

        if(total!=null && total.intValue()>0) {
            isValid = false;
        }

        return isValid;
    }
}
