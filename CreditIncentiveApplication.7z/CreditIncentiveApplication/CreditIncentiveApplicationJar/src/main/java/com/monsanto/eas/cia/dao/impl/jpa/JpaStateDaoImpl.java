package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.StateDao;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.State;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaStateDaoImpl extends JpaGenericDaoImpl<State> implements StateDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext(unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<State> lookupAllStates() {
    return super.findByQueryName("State.lookupAll");
  }

    public Collection<State> lookupStatesForSubRegion(SubRegion subRegion) {
        return super.findByQueryName("State.lookupBySubRegion", subRegion.getId());
    }

    public State lookupStateForDistrict(District district){
        Collection<State> stateList = super.findByQueryName("State.lookupStateForDistrict", district.getId());
        if (null != stateList && !stateList.isEmpty()){
            return stateList.iterator().next();
        }
        return null;
    }

}
