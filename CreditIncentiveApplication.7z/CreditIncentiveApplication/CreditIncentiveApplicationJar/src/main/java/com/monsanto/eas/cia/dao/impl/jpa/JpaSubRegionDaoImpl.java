package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.RegionDao;
import com.monsanto.eas.cia.dao.SubRegionDao;
import com.monsanto.eas.cia.model.area.Region;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:16:33 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class JpaSubRegionDaoImpl extends JpaGenericDaoImpl<SubRegion> implements SubRegionDao {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The entity manager.
   */
  @PersistenceContext (unitName="CreditIncentivesApplication")
  private EntityManager entityManager;

  @SuppressWarnings("unchecked")
  public Collection<SubRegion> lookupAllSubRegions() {
    return super.findByQueryName("SubRegion.lookupAll");
  }

//  public Year lookupYearByYear(String param){
//      return (Year)entityManager
//              .createNamedQuery("Year.lookupYearByYear")
//              .setParameter("year", param)
//              .getSingleResult();
//  }


    public Collection<SubRegion> lookupSubRegionsForRegion(Region region) {
        return super.findByQueryName("SubRegion.lookupByRegion",region.getId());
    }

}
