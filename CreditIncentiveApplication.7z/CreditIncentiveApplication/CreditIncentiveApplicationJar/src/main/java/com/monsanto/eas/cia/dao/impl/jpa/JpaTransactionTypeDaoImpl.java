package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.TransactionTypeDao;
import com.monsanto.eas.cia.model.TransactionType;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JSANDO1
 * Date: 7/12/2010
 * Time: 11:20:38 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class JpaTransactionTypeDaoImpl extends JpaGenericDaoImpl<TransactionType> implements TransactionTypeDao {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The entity manager.
     */
    @PersistenceContext(unitName="CreditIncentivesApplication")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public Collection<TransactionType> lookupAll() {
        //return null;  //To change body of implemented methods use File | Settings | File Templates.
        return super.findByQueryName("TransactionType.lookupAll");
    }

    @SuppressWarnings("unchecked")
    public void importBWTransaction(TransactionType transactionType) {
        //To change body of implemented methods use File | Settings | File Templates.
        super.save(transactionType);
    }
}
