package com.monsanto.eas.cia.dao.impl.jpa;

import com.monsanto.eas.cia.dao.VolumeAdjustmentDao;
import com.monsanto.eas.cia.model.LdSales;
import com.monsanto.eas.cia.vo.ParamLookupSalesVO;
import com.monsanto.eas.cia.vo.VolumeAdjustmentSearchResultVO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 22/12/2011
 * Time: 01:57:25 PM
 */
@Repository
public class JpaVolumeAdjustmentDaoImpl implements VolumeAdjustmentDao {
    @PersistenceContext(unitName = "CreditIncentivesApplication")
    private EntityManager entityManager;

    public Collection<VolumeAdjustmentSearchResultVO> lookupSalesByParams(final ParamLookupSalesVO paramLookupSalesVO) {
        final StringBuffer strQuery = new StringBuffer(16);
        strQuery.append("select new ")
                .append(VolumeAdjustmentSearchResultVO.class.getName())
                .append("(lds.id, lds.salesDate, lds.transactionNumber, lds.ldDist.localDealer.agreementNumber, ")
                .append("lds.ldDist.localDealer.name, lds.ldDist.localDealer.posName, lds.productLine.sapProduct.code, ")
                .append("lds.productLine.sapProduct.description, lds.transactionType.description, lds.salesVolume, ")
                .append("lds.volumeAssigned, lds.volumeToIncentive, lds.validForIncentivePlanning, lds.ldDist.localDealer.rfc, ")
                .append("lds.ldDist.distributor.code, lds.ldDist.distributor.description, lds.price)")
                .append(" from ")
                .append(LdSales.class.getName())
                .append(" lds ")
                .append(addConditions(paramLookupSalesVO));

        final Query query = this.entityManager.createQuery(strQuery.toString());

        return query.getResultList();
    }

    private StringBuffer addConditions(final ParamLookupSalesVO paramLookupSalesVO) {
        boolean boWhere = Boolean.FALSE;
        final StringBuffer conditions = new StringBuffer("");

        if (null != paramLookupSalesVO.getDate() && !paramLookupSalesVO.getDate().isEmpty()) {
            boWhere = addCondition(boWhere, conditions);
            conditions.append("to_char(lds.salesDate, 'MM/yyyy') = '")
                    .append(paramLookupSalesVO.getDate())
                    .append("' ");
        }

        if (null != paramLookupSalesVO.getSubRegionId()) {
            boWhere = addCondition(boWhere, conditions);
            conditions.append("lds.ldDist.localDealer.subRegion.id = ")
                    .append(paramLookupSalesVO.getSubRegionId().intValue())
                    .append(' ');
        }

        if (null != paramLookupSalesVO.getDistributorId()) {
            boWhere = addCondition(boWhere, conditions);
            conditions.append("lds.ldDist.distributor.id = ")
                    .append(paramLookupSalesVO.getDistributorId().intValue())
                    .append(' ');
        }

        if (null != paramLookupSalesVO.getDealerId()) {
            boWhere = addCondition(boWhere, conditions);
            conditions.append("lds.ldDist.localDealer.id = ")
                    .append(paramLookupSalesVO.getDealerId().intValue())
                    .append(' ');
        }

        return conditions;
    }

    private boolean addCondition(boolean boWhere, final StringBuffer conditions) {
        if (boWhere) {
            conditions.append("and ");
        } else {
            conditions.append("where ");
        }
        return Boolean.TRUE;
    }
}
