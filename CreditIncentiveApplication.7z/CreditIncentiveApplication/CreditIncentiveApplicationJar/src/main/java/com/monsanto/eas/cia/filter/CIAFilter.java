package com.monsanto.eas.cia.filter;

import com.monsanto.eas.cia.CiaConstants;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import weblogic.security.Security;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.Principal;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 11, 2010 Time: 10:28:47 AM To change this template use File |
 * Settings | File Templates.
 */

@Component
public class CIAFilter implements Filter {
  private FilterConfig config;

  //  @Autowired
//  private PogUserDao pogUserDao;
  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (CIAFilter.class.getName());

  public void destroy() {
  }

  public CIAFilter() {
  }

//  public CIAFilter(PogUserDao pogUserDao) {
//    this.pogUserDao = pogUserDao;
//  }

  public void doFilter(ServletRequest req, ServletResponse resp,
                       FilterChain chain) throws ServletException, IOException {
    HttpServletRequest httpServletRequest = (HttpServletRequest) req;
    HttpServletResponse httpServletResponse = (HttpServletResponse) resp;
    String environment = System.getProperty("lsi.function");
    String userId = null;
    System.out.println("environment: " + environment);
    if ("win".equalsIgnoreCase(environment)) {
      userId = "SSPATI1";
    } else {
      Set<Principal> principals = Security.getCurrentSubject().getPrincipals();
      if (!principals.isEmpty()) {
        userId = principals.iterator().next().getName();
        if (userId.indexOf("_monsanto") > 0) {
          //RRMALL_monsantoT
          userId = userId.substring(0, userId.indexOf("_"));
        }
      }
    }
    System.out.println("WAM USER ID is: " + userId);
    if (userId != null) {
//      try {
//        PogUser pogUser = pogUserDao.findByUserId(userId);
        httpServletRequest.getSession(true).setAttribute(CiaConstants.WAM_USER_ID, userId);
//        Locale locale = new Locale(pogUser.getLocale().getLocale());
//        httpServletRequest.getSession(true).setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, locale);

//      } catch (UserNotFoundException e) {
//        e.printStackTrace();
//      }
    }
//    httpServletRequest.getSession(true).setAttribute(PogConstants.WAM_USER_ID, userId);
//    handleAutoLogoutDetect(httpServletRequest, httpServletResponse, 0);
    chain.doFilter(req, resp);
  }

  protected void handleAutoLogoutDetect(HttpServletRequest request, HttpServletResponse response, int sessionTimeout) {
    if (sessionTimeout == 0) {
      sessionTimeout = request.getSession(false).getMaxInactiveInterval();
    }

    logger.info("Handle Auto Logout Detect : Refreshing in seconds ==> [" + sessionTimeout + "]");
    response.setHeader("Refresh",
        String.valueOf(sessionTimeout) + "; URL=" + request.getContextPath() + "/servlet/sessiontimeout");
  }

  public void init(FilterConfig config) throws ServletException {
    this.config = config;
    ServletContext servletContext = config.getServletContext();
    WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
    if (webApplicationContext != null) {
      AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext.getAutowireCapableBeanFactory();
      autowireCapableBeanFactory.autowireBean(this);
    }

  }

  //RRMALL logged in
  // Result -> null//RRMALL_monsantoT//Users//WAM-0000-POG_USER-TEST_DMZ-U//WAM-0000-POG_ADMIN-TEST_DMZ-U//Domain Users

  public FilterConfig getConfig() {
    return config;
  }
}