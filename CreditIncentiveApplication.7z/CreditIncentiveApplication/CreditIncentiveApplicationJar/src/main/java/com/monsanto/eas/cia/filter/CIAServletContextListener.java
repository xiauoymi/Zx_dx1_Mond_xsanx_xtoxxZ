package com.monsanto.eas.cia.filter;

import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:10:11 PM To change this template use File |
 * Settings | File Templates.
 */
@Component
public class CIAServletContextListener extends ContextLoaderListener {
//  @Autowired
//  private ProductService productService;

  public CIAServletContextListener() {
  }

//  public CIAServletContextListener(ProductService productService) {
//    this.productService = productService;
//  }

  @Override
  public void contextInitialized(ServletContextEvent servletContextEvent) {
    ServletContext context = initializeContext(servletContextEvent);
//    productService.setProductMapInServletContext(context);
  }

  //protected only for testing
  protected ServletContext initializeContext(ServletContextEvent servletContextEvent) {
    super.contextInitialized(servletContextEvent);
    ServletContext context = servletContextEvent.getServletContext();
    WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(context);
    if (webApplicationContext != null) {
      AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext.getAutowireCapableBeanFactory();
      autowireCapableBeanFactory.autowireBean(this);
    }
    return context;
  }

  public void contextDestroyed(ServletContextEvent servletContextEvent) {
  }
}
