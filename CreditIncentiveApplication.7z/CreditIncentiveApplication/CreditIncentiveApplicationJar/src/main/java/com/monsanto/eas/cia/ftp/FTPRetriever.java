/*
 FTPRetriever was created on May 30, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.cia.ftp;

import com.monsanto.eas.cia.ftp.exception.FTPException;
import com.monsanto.eas.cia.ftp.service.FTPService;

public class FTPRetriever {

  private FTPService ftpService;

  public FTPRetriever(FTPService ftpService) {
    this.ftpService = ftpService;
  }

  private void retrieveFileFromSAP() {
    try {
        ftpService.download(com.monsanto.eas.cia.constant.CIAConstants.FILE_2_BW_SALES, null, com.monsanto.eas.cia.constant.CIAConstants.FTP_REMOTE_SUB_DIR_INBOUND);
    } catch (FTPException e) {
        e.printStackTrace();
    }
  }

}
