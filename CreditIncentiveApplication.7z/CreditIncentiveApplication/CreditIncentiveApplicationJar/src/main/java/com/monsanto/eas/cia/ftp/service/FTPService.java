/*
 Copyright:  Copyright  2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.ftp.service;

import com.monsanto.eas.cia.ftp.exception.FTPException;

/**
 * This is an FTPService which provides the two functionalities: upload and download.
 *
 * Filename:    $RCSfile: FTPService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-04-25 18:58:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public interface FTPService {

  /**
   * Uploads the local file to a remote system in the current remote dir
   * @param absolutePathToLocalFile (fully-qualified/absolute path on local system including the file name with extension)
   * @param remoteSubDir - Remote Sub Directory from where one needs to upload. (Sub Directory within the default "/" dir)
   *                       Eg: inbound, inbound/newdir, outbound etc...
   *                       If Null: File will be uploaded to default dir "/" will be returned.
   * @return boolean - true if operation executes sucessfuly
   *                 - false otherwise
   * @throws FTPException - For any exceptions
   */
  boolean upload(String absolutePathToLocalFile, String remoteSubDir) throws FTPException;

  /**
   * Downloads the file from a remote system
   * @param remoteFileName - name of the file on the remote system in the current remote dir
   * @param absolutePathToDownloadLocation - download to local system as this file name (fully-qualified/absolute path on local system including the file name with extension)
   * @param remoteSubDir- Remote Sub Directory from where one needs to download. (Sub Directory within the default "/" dir)
   *                      Eg: inbound, inbound/newdir, outbound etc...
   *                      If Null: File will be downloaded to default dir "/" will be returned.
   * @return boolean - true: If the file is downloaded successfully
   *                 - false: otherwise
   * @throws FTPException - For any exceptions
   */
  boolean download(String remoteFileName, String absolutePathToDownloadLocation, String remoteSubDir) throws FTPException;
}
