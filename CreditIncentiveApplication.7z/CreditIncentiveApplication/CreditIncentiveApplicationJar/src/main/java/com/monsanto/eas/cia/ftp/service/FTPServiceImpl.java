/*
 Copyright:  Copyright  2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.ftp.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.FTPConnection;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.eas.cia.ftp.exception.FTPException;
import com.monsanto.eas.cia.resource.ResourceConnectionException;
import com.monsanto.eas.cia.resource.ResourceConnectionManager;
import com.monsanto.eas.cia.resource.ResourceManagerFactory;
import com.monsanto.eas.cia.util.DocumentUtil;
//import com.monsanto.eas.cia.util.DocumentUtil;

import java.io.*;

/**
 * Filename:    $RCSfile: FTPServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 22:03:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.12 $
 */
public class FTPServiceImpl implements FTPService {

  //As per RFC 959 (http://www.ietf.org/rfc/rfc0959.txt)
  private static final String FTP_COMMAND_STORE = "STOR ";
  private static final String FTP_COMMAND_RETRIEVE = "RETR ";

  private ResourceConnectionManager connectionManager;

  public FTPServiceImpl(ResourceManagerFactory managerFactory) {
    connectionManager = managerFactory.getConnectionManager(CIAConstants.DATASOURCE_TYPE_FTP_SERVER);
  }

  public boolean upload(String absolutePathToLocalFile, String remoteSubDir) throws FTPException {
    validateLocalFileName(absolutePathToLocalFile);
    FTPConnection connection = getConnection(remoteSubDir);
    boolean uploadResult = false;
    if(upload(connection, absolutePathToLocalFile)) {
      uploadResult = true;
    }
    disconnect(connection);
    return uploadResult;
  }

  public boolean download(String remoteFileName, String absolutePathToDownloadLocation, String remoteSubDir)  throws FTPException {
    validateRemoteFileName(remoteFileName);
    validateDownloadLocation(absolutePathToDownloadLocation, remoteFileName);
    FTPConnection connection = getConnection(remoteSubDir);
    boolean downloadResult = false;
    FileOutputStream downloadLocation = getOutputStreamForDownloadLocation(absolutePathToDownloadLocation);
    if(download(connection, remoteFileName, downloadLocation)) {
      downloadResult = true;
    }
    disconnect(connection);
    return downloadResult;
  }

  private void validateDownloadLocation(String absolutePathToDownloadLocation, String remoteFileName) {
    if(StringUtils.isNullOrEmpty(absolutePathToDownloadLocation)) {
      throw new IllegalArgumentException("Invalid download file location specified for downloading: '" + remoteFileName + "'.");
    }
  }

  private void validateRemoteFileName(String remoteFileName) {
    if(StringUtils.isNullOrEmpty(remoteFileName)) {
      throw new IllegalArgumentException("Invalid remote file name specified for downloading: '" + remoteFileName + "'.");
    }
  }

  private FileOutputStream getOutputStreamForDownloadLocation(String absolutePathToDownloadLocation) throws FTPException {
    FileOutputStream downloadLocation;
    try {
      downloadLocation = new FileOutputStream(absolutePathToDownloadLocation);
    } catch (FileNotFoundException e) {
      Logger.log(new LoggableError(e));
      throw new FTPException("Error creating an output stream from the specified absolutePathToDownloadLocation: '" + absolutePathToDownloadLocation + "'", e);
    }
    return downloadLocation;
  }

  private FTPConnection getConnection(String remoteSubDir) throws FTPException {
    FTPConnection connection;
    try {
      connection = (FTPConnection) connectionManager.getConnection(remoteSubDir);
    } catch (ResourceConnectionException e) {
      Logger.log(new LoggableError(e));
      throw new FTPException("Exception while getting connection to FTP server.", e);
    }
    return connection;
  }

  private boolean upload(FTPConnection connection, String absolutePathToLocalFile) throws FTPException {
    try {
      InputStream fileContents = new FileInputStream(absolutePathToLocalFile);
      return connection.executeDataCommand(FTP_COMMAND_STORE + DocumentUtil.extractNameFromFilePath(absolutePathToLocalFile), fileContents);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new FTPException("FTP exception while uploading file: '" + absolutePathToLocalFile + "'.", e);
    }
  }

  private void validateLocalFileName(String absolutePathToLocalFile) {
    if(StringUtils.isNullOrEmpty(absolutePathToLocalFile)) {
      throw new IllegalArgumentException("Invalid file name specified for uploading: '" + absolutePathToLocalFile + "'.");
    }
  }

  private boolean download(FTPConnection connection, String remoteFileName, OutputStream downloadLocation) throws FTPException {
    try {
      return connection.executeDataCommand(FTP_COMMAND_RETRIEVE + remoteFileName, downloadLocation);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new FTPException("FTP exception while downloading file: '" + remoteFileName + "'.", e);
    }
  }

  private void disconnect(FTPConnection connection) {
    connection.disconnect();
  }
}
