package com.monsanto.eas.cia.integration.contract;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 20/01/2011
 * Time: 10:15:46 AM
 * Marker interface 
 */
public interface Layout extends Cloneable{
    public Layout clone();
}
