package com.monsanto.eas.cia.integration.exception;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 4/02/2011
 * Time: 02:16:13 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLayoutException extends RuntimeException{
    protected Object    layout;
    protected long      recordNumber;


    protected AbstractLayoutException(){} 

    protected AbstractLayoutException(String message) {
        super(message);
    }

    protected AbstractLayoutException(String message, Throwable cause) {
        super(message, cause);
    }

    public void setLayout(Object layout) {
        this.layout = layout;
    }

    public Object getLayout() {
        return layout;
    }

    public long getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(long recordNumber) {
        this.recordNumber = recordNumber;
    }

    public String getStackTraceValue(){
        StringWriter buffer=new StringWriter();
        PrintWriter printWriter=new PrintWriter(buffer,true);
        this.printStackTrace(printWriter);
        printWriter.flush();
        printWriter.close();
        return buffer.toString();
    }

    public abstract String explain(ResourceBundle bundle);

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
