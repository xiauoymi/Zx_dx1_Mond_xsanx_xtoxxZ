package com.monsanto.eas.cia.integration.format;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 05:00:46 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FieldAnnotationProcessor<S> {
    S process(S value);
}
