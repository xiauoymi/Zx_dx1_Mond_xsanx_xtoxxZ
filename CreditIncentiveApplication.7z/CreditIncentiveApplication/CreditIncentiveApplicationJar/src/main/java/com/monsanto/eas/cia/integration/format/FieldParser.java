package com.monsanto.eas.cia.integration.format;

import java.text.ParseException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 11:44:40 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FieldParser<T,S> {
    public T parse(S source) throws ParseException;
}
