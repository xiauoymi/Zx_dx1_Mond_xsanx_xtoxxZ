package com.monsanto.eas.cia.integration.format;

import com.monsanto.eas.cia.integration.format.exception.ParseRecordException;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.apache.commons.lang.ClassUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 11:52:04 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class Record<S> {
    protected long recordNumber;
    protected Map<Class<?>, FieldParser<?,S>> fieldParsers=new HashMap<Class<?>, FieldParser<?,S>>();
    protected Map<Class<?>,FieldAnnotationProcessor<S>> fieldAnnotationProcessors=new HashMap<Class<?>,FieldAnnotationProcessor<S>>();
    protected int currentFieldPosition;

    protected Record(long recordNumber,Map<Class<?>, FieldParser<?, S>> fieldParsers, Map<Class<?>,FieldAnnotationProcessor<S>> fieldAnnotationProcessors) {
        setFieldAnnotationProcessors(fieldAnnotationProcessors);
        setRecordNumber(recordNumber);        
        setFieldParsers(fieldParsers);       
    }

    public long getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(long recordNumber) {
        this.recordNumber = Math.abs(recordNumber);
    }

    public Map<Class<?>, FieldParser<?, S>> getFieldParsers() {
        return fieldParsers;
    }

    public Map<Class<?>, FieldAnnotationProcessor<S>> getFieldAnnotationProcessors() {
        return fieldAnnotationProcessors;
    }

    public void setFieldAnnotationProcessors(Map<Class<?>, FieldAnnotationProcessor<S>> fieldAnnotationProcessors) {
        if(fieldAnnotationProcessors==null)throw new IllegalArgumentException();
        this.fieldAnnotationProcessors = fieldAnnotationProcessors;
    }

    public void setFieldParsers(Map<Class<?>, FieldParser<?, S>> fieldParsers) {
        if(fieldParsers==null)throw new IllegalArgumentException();
        this.fieldParsers = fieldParsers;
    }

    public int getCurrentFieldPosition() {
        return currentFieldPosition;
    }

    public void setCurrentFieldPosition(int currentFieldPosition) {
        this.currentFieldPosition = currentFieldPosition;
    }
        
    public void resetCurrentFieldPosition(){
        setCurrentFieldPosition(0);
    }

    /**
     * @param _class The class of this field
     * @param <T> The type of this parsed field     
     * @return The parsed value
     */
    public <T> T toType(Class<T> _class){
       return this.toType(currentFieldPosition++,_class);
    }

    public <T> T toType(int fieldPosition, Class<T> _class){
        return toType(fieldPosition,_class,null);
    }

    public <T> T toType(int fieldPosition, Class<T> _class,Object instance){
        return toType(fieldPosition,null,_class,instance);
    }

    /**
     * @param fieldPosition The field position
     * @param annotations The annotations that have to be considered for this field 
     * @param _class The class of this field
     * @param <T> The type of this parsed field
     * @return The parsed value
     */
    public <T> T toType(int fieldPosition, Annotation[] annotations, Class<T> _class, Object instance){
        S fieldValue   =   null;
        fieldPosition       =   Math.abs(fieldPosition);
        try{
            fieldValue= processAnnotations(annotations,this.getFieldValue(fieldPosition));
            FieldParser<?,S> converter= fieldParsers.get(_class);
            if(converter==null)
                throw new IllegalArgumentException("The converter for "+_class+" doesn't exist");
            return (T)converter.parse(fieldValue);
        }
        catch(Exception e){
            throw createConversionException(e,fieldPosition,_class,instance,fieldValue);
        }                
    }

    protected S processAnnotations(Annotation[]annotations, S fieldValue){
        if(annotations!=null&&fieldAnnotationProcessors!=null){
            FieldAnnotationProcessor<S>fieldAnnotationProcessor=null;
            Class<?> _annotationType;
            for(Annotation annotation:annotations){
                if(annotation==null)continue;
                _annotationType=annotation.annotationType();
                fieldAnnotationProcessor=fieldAnnotationProcessors.get(_annotationType);
                if(fieldAnnotationProcessor==null)continue;
                fieldValue=fieldAnnotationProcessor.process(fieldValue);
            }            
        }
        return fieldValue;
    }

    /**
     * @param _class the class we are trying to convert
     * @param <T> The generic type of the entity
     * @return A new instance of the given class
     */
    public <T> T toLayout(Class<T> _class){
        Integer             position            =   null;
        Object              value               =   null;
        T                   newInstance         =   null;
        try {
            newInstance         =   _class.newInstance();
            Field[] fields      =   _class.getDeclaredFields();
            for(Field field:fields){
                value                            =   null;
                position= LayoutUtils.getFieldPosition(field);
                if(position!=null){                    
                    value= toType(position, field.getAnnotations(), field.getType(),newInstance);
                }
                else if(LayoutUtils.isLayout(field.getDeclaringClass())){
                    value= toLayout(field.getClass());
                }
                field.setAccessible(true);
                field.set(newInstance,value);
            }
            return newInstance;
        }
        catch(RuntimeException e){
            Class<?> runtimeExceptionClass=ObjectUtils.getGenericType(this.getClass(),RuntimeException.class);
            if(ClassUtils.isAssignable(e.getClass(),runtimeExceptionClass))
                throw e;
            throw createConversionException(e,-1,_class,newInstance,null);
        }
        catch (Exception e) {
            throw createConversionException(e,-1,_class,newInstance,null); 
        }
    }

    public abstract S getFieldValue(int position);

    public ParseRecordException createConversionException(Throwable e,int fieldPosition,Class<?> _class,Object object, S fieldValue){
        ParseRecordException csvReaderException= new ParseRecordException(_class.getName(),e, recordNumber, fieldPosition, _class);
        csvReaderException.setLayout(object);
        return csvReaderException;
    }
}
