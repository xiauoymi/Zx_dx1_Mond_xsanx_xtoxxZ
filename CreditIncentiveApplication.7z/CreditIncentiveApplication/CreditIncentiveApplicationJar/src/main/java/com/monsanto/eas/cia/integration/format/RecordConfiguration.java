package com.monsanto.eas.cia.integration.format;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 19/02/2011
 * Time: 12:49:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class RecordConfiguration {
    /**
     * The value to use in csv files instead of null
     */
    protected           String              emptyFieldValue     =   "";
    /**
     * The date format to use in csv files
     * */
    protected String dateFormatString                 =   "yyyy/MM/dd";
    /**
     * The decimal format to use in csv files
     * */
    protected String decimalFormatString              =   "0.000";

    public String getDateFormatString() {
        return dateFormatString;
    }

    public void setDateFormatString(String dateFormatString) {
        this.dateFormatString = dateFormatString;
    }

    public String getDecimalFormatString() {
        return decimalFormatString;
    }

    public void setDecimalFormatString(String decimalFormatString) {
        this.decimalFormatString = decimalFormatString;
    }

    public String getEmptyFieldValue() {
        return emptyFieldValue;
    }

    public void setEmptyFieldValue(String emptyFieldValue) {
        this.emptyFieldValue = emptyFieldValue;
    }
}
