package com.monsanto.eas.cia.integration.format;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 10:59:04 AM
 * To change this template use File | Settings | File Templates.
 */
public interface RecordIterator extends Iterator<Record> {
    public RecordIterator start();
}
