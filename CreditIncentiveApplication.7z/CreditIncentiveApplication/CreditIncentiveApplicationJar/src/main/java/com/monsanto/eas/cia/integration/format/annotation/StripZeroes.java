package com.monsanto.eas.cia.integration.format.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 05:10:18 PM
 * To change this template use File | Settings | File Templates.
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface StripZeroes {
    
}
