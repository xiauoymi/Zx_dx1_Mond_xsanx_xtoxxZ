package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.format.RecordConfiguration;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/01/2011
 * Time: 05:06:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvConfiguration extends RecordConfiguration {
    /**
     * The character to separate out the records in the file
     */
    protected           Character           fieldSeparator      =   '|';
    /**
     * The quote character
     */
    protected           Character           quoteCharacter      =   CsvWriter.NO_QUOTE_CHARACTER;
    /**
     * The escape character
     */
    protected           Character           escapeCharacter     =   '\\';
    /**
     * The line end
     */
    protected           String              lineEnd             =   CsvWriter.DEFAULT_LINE_END;

    public CsvConfiguration() {
        setDateFormatString("yyyyMMdd");
    }

    public Character getFieldSeparator() {
        return fieldSeparator;
    }

    public void setFieldSeparator(Character fieldSeparator) {
        this.fieldSeparator = fieldSeparator;
    }

    public SimpleDateFormat getDateFormat() {
        return new SimpleDateFormat(dateFormatString);
    }

    public DecimalFormat getDecimalFormat() {
        return new DecimalFormat(decimalFormatString);
    }

    /**
     * Quoting character
     * */
    public Character getQuoteCharacter() {
        return quoteCharacter;
    }

    public void setQuoteCharacter(Character quoteCharacter) {
        this.quoteCharacter = quoteCharacter;
    }

    /**
     * Escape character
     */
    public Character getEscapeCharacter() {
        return escapeCharacter;
    }

    public void setEscapeCharacter(Character escapeCharacter) {
        this.escapeCharacter = escapeCharacter;
    }

    /**
     * Default line end
     */
    public String getLineEnd() {
        return lineEnd;
    }

    public void setLineEnd(String lineEnd) {
        this.lineEnd = lineEnd;
    }
}
