package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.format.FieldAnnotationProcessor;
import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/01/2011
 * Time: 10:32:50 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class CsvReaderConfiguration extends CsvConfiguration {

    /**
     * Data parser delegates
     */
    protected Map<Class<?>, FieldParser<?,String>> fieldParserAdapters;

    /**
     * fieldAnnotationProcessors
     */
    protected Map<Class<?>, FieldAnnotationProcessor<String>> fieldAnnotationProcessors;

    /**
     * Default constructor
     */
    public CsvReaderConfiguration() {
        initFieldParserAdapters();
        initFieldAnnotationProcessors();
    }



    /**     
     * @param reader The native source of data
     * @return A CSVReader object
     * @throws java.io.IOException Any file system exception
     */
    public CsvReader createCsvReader(Reader reader) throws IOException {
        CsvReader csvReader=new CsvReader(
            reader,
            super.getFieldSeparator(),
            super.getQuoteCharacter(),
            super.getEscapeCharacter()
        );
        return csvReader;
    }

    /**
     * Initialize parserDelegates map
     */
    protected void initFieldParserAdapters(){
        fieldParserAdapters =new HashMap<Class<?>, FieldParser<?,String>>();
        fieldParserAdapters.put(String.class,new StringCsvFieldParserAdapter());
        fieldParserAdapters.put(Integer.class,new IntegerCsvFieldParserAdapter());
        fieldParserAdapters.put(Double.class,new DoubleCsvFieldParserAdapter());
        fieldParserAdapters.put(Date.class,new DateCsvFieldParserAdapter());
        fieldParserAdapters.put(Boolean.class,new BooleanCsvFieldParserAdapter());
    }

    /**
     * Initialize field annotation processors
     */
    protected void initFieldAnnotationProcessors() {
        fieldAnnotationProcessors=new HashMap<Class<?>,FieldAnnotationProcessor<String>>();
        fieldAnnotationProcessors.put(StripZeroes.class,new StripZeroesFieldAnnotationProcessor());
    }

    /**
     * @return Field parser adapters
     */
    public Map<Class<?>, FieldParser<?,String>> getFieldParserAdapters() {
        return fieldParserAdapters;
    }

    /**
     * @param recordPosition The position of the record
     * @param record The string array that holds csv values
     * @return A new CSV Record
     */
    public CsvRecord createCsvRecord(long recordPosition, String[]record){
        return new CsvRecord(record,recordPosition,fieldParserAdapters,fieldAnnotationProcessors);
    }

    public class StripZeroesFieldAnnotationProcessor implements FieldAnnotationProcessor<String> {
        public String process(String value) {
            if(value!=null){
                value= StringUtils.stripStart(value.trim(),"0");
            }
            return value;
        }
    }

    public class TrimFieldAnnotationProcessor implements FieldAnnotationProcessor<String>{
        public String process(String value) {            
            return value!=null?value.trim():value;
        }
    }

    /**
     * Parse strings
     */
    public class StringCsvFieldParserAdapter implements FieldParser<String,String> {
        public String parse(String field) {
            return CsvReaderConfiguration.this.parseString(field);
        }
    }

    /**
     * Parse integers
     */
    public class IntegerCsvFieldParserAdapter implements FieldParser<Integer,String> {
        public Integer parse(String field)  throws ParseException{
            return CsvReaderConfiguration.this.parseInteger(field);

        }
    }

    /**
     * Parse double values
     */
    public class DoubleCsvFieldParserAdapter implements FieldParser<Double,String> {
        public Double parse(String field)  throws ParseException{
            Number number = CsvReaderConfiguration.this.parseDouble(field);
            return number==null?null:number.doubleValue();
        }
    }

    /**
     * Parse date values     
     */
    public class DateCsvFieldParserAdapter implements FieldParser<Date,String> {
        public Date parse(String field) throws ParseException {
            return CsvReaderConfiguration.this.parseDate(field);
        }
    }

    /**
     * Parse boolean values
     */
    public class BooleanCsvFieldParserAdapter implements FieldParser<Boolean,String> {
        public Boolean parse(String field) throws ParseException {
            return CsvReaderConfiguration.this.parseBoolean(field);
        }
    }

    /**     
     * @param field The field we are verifying not to be null
     * @return Whether this input field was null
     */
    public boolean isInputNull(String field){
        if(field==null) {
            return true;
        }
        if(field.trim().equalsIgnoreCase(super.getEmptyFieldValue())) {
            return true;
        }
        return false;
    }

    /**
     * @param field The string representation of a date
     * @return A date object or null
     * @throws ParseException Upon conversion failure
     */
    public Date parseDate(String field) throws ParseException {
        if(isInputNull(field)){
            return null;        
        }
        return super.getDateFormat().parse(field);
    }

    /**
     * @param field The string representation of a floating point number
     * @return A Number for this object  or null
     * @throws ParseException Upon conversion failure
     */
    public Number parseDouble(String field) throws ParseException {
        if(isInputNull(field)) {
            return null;
        }
        return super.getDecimalFormat().parse(field);
    }

    /**
     * @param field The string representation of an integer
     * @return An integer for this object  or null
     * @throws ParseException Upon conversion failure
     */
    public Integer parseInteger(String field) throws ParseException{
        if(isInputNull(field))return null;        
        try{
            return new Integer(field);
        }
        catch(NumberFormatException nfe){
            throw new ParseException("Number format exception: "+field,0);
        }
    }

    /**
     * This method is meant to adapt strings from the input file into strings required by the object data model
     * @param field A string or null
     * @return The same input string
     */
    public String parseString(String field){
        if(isInputNull(field)){
            return null;
        }
        return field;
    }

    /**
     * @param field The string representation of an boolean
     * @return An boolean for this object  or null
     */
    public Boolean parseBoolean(String field){
        if(isInputNull(field)){
            return Boolean.FALSE;
        }
        if("1".equals(field)){
            return Boolean.TRUE;
        }
        return Boolean.FALSE;                
    }
}
