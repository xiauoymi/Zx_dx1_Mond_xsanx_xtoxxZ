package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.format.FieldAnnotationProcessor;
import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.Record;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 19/01/2011
 * Time: 09:43:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvRecord extends Record<String> {
    /**
     * The csv record
     */
    protected String[] fields;

    /**
     * @param recordNumber The position of the record from 1
     * @param fields The csv record
     */
    public CsvRecord(String[] fields,long recordNumber,Map<Class<?>, FieldParser<?,String>> fieldParsers, Map<Class<?>,FieldAnnotationProcessor<String>> fieldAnnotationProcessors){
        super(recordNumber,fieldParsers,fieldAnnotationProcessors);
        this.setFields(fields);
    }

    public String[] getFields() {
        return fields;        
    }

    public void setFields(String[] fields) {
        if(fields ==null)throw new IllegalArgumentException();
        this.fields = fields;
    }

    public  String getFieldValue(int position){
        String field = fields[position];
        return field!=null?field.trim():field;
    }
}
