package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.RecordIterator;

import java.io.Reader;
/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 4/02/2011
 * Time: 11:18:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvRecordIterator implements RecordIterator {
    protected CsvReaderConfiguration csvReaderConfiguration;
    protected Reader        reader;
    protected CsvReader     csvReader;
    protected long          position        =   -1;
    protected String[]      fields          =   null;
    protected boolean       started         =   false;


    public CsvRecordIterator(CsvReaderConfiguration csvReaderConfiguration,Reader reader){
        this.csvReaderConfiguration         =   csvReaderConfiguration;
        this.reader                         =   reader;
    }

    public void throwCsvRecordIteratorException(Throwable t){
        throw new CsvRecordIteratorException(
            t,
            getPosition(),
            getFields()
        );
    }

    public CsvRecordIterator start() {
        if(started)     throwCsvRecordIteratorException(new IllegalStateException());
        try{
            csvReader   =   csvReaderConfiguration.createCsvReader(reader);
        }
        catch(Exception e){
            throwCsvRecordIteratorException(e);
        }
        started         =   true;
        fields =   null;
        return this;
    }

    public boolean hasNext() {
        if(fields ==null){
            readNext();
        }
        return fields !=null;
    }

    public Record next() {
        checkRuntimeState();
        if(fields ==null){
            readNext();
            if(fields ==null){
                throwCsvRecordIteratorException(new IndexOutOfBoundsException());
            }
        }
        CsvRecord csvRecord = csvReaderConfiguration.createCsvRecord(position, fields);
        fields =null;
        return csvRecord;
    }

    public long getPosition() {
        return position;
    }

    public boolean isStarted() {
        return started;
    }

    public String[] getFields() {
        return fields;
    }

    protected void readNext(){
        checkRuntimeState();
        try {
            fields =   csvReader.readNext();
        } catch (Exception e) {
            throwCsvRecordIteratorException(e);
        }
        if(fields !=null)
            position++;
        else{
            try{
                csvReader.close();
            }
            catch(Exception e){}
        }
    }

    protected void checkRuntimeState(){
        if(!started)    throwCsvRecordIteratorException(new IllegalStateException("Start first"));        
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
