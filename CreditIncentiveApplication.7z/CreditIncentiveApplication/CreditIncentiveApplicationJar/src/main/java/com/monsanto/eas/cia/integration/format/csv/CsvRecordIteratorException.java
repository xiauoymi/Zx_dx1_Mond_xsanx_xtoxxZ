package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.format.exception.RecordIteratorException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 4/02/2011
 * Time: 03:12:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvRecordIteratorException extends RecordIteratorException {

    protected String[]      fields      =   null;

    public CsvRecordIteratorException(Throwable t,long position, String[] fields) {
        super(t,position);
        setFields(fields);
    }

    public long getPosition() {
        return position;
    }

    public void setPosition(long position) {
        this.position = position;
    }

    @Override
    public Object getFieldValue(int position) {
        return fields[position];
    }

    public String[] getFields() {
        return fields;
    }

    public void setFields(String[] fields) {
        this.fields = fields;
    }

}
