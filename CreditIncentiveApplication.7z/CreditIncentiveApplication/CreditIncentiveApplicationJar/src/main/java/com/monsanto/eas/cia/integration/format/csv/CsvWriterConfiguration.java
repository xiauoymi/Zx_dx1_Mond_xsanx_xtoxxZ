package com.monsanto.eas.cia.integration.format.csv;

import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.TreeMap;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/01/2011
 * Time: 04:11:03 PM
 */
@Component
public class CsvWriterConfiguration extends CsvConfiguration {

    /**
     * Default constructor
     */
    public CsvWriterConfiguration(){}

    /**
     * This method creates the CURRENT csv writer. This must be invoked before the other csv writer related methods
     * @throws java.io.IOException File system exceptions
     * @throws java.lang.IllegalArgumentException If writer parameter is null
     */
    public CsvWriter createCsvWriter(Writer writer) throws IOException {
        if(writer==null)throw new IllegalArgumentException();
        return new CsvWriter(
            writer,
            getFieldSeparator(),
            getQuoteCharacter(),
            getEscapeCharacter(),
            getLineEnd()
        );        
    }



    /**
     * @param value An array containing two items representing a range
     * @return The lower bound in the range represented by the parameter
     */
    public String minValue(Object[] value){
        if(value==null||value.length<1)return emptyFieldValue;
        return value(value[0]);
    }

    /**
     * @param value An array containing two items representing a range
     * @return The upper bound in the range represented by the parameter
     */
    public String maxValue(Object[] value){
        if(value==null||value.length<2)return emptyFieldValue;
        return value(value[1]);
    }

    /**
     * Formats the value according to the configured data format in this instance
     * @param value The value to format
     * @return The string representation of the date or 'emptyFieldValue' if the parameter was null
     */
    public String value(Date value){
        return value!=null? getDateFormat().format(value):emptyFieldValue;
    }

    /**
     * Formats the value according to the configured decimal format in this instance
     * @param value The value to format
     * @return The string representation of the date or 'emptyFieldValue' if the parameter was null
     */
    public String value(Double value){
        return value!=null?getDecimalFormat().format(value):emptyFieldValue;
    }

    public String value(Boolean value){
        if(value!=null&&value){
            return "1";
        }
        return "0";
    }

    /**
     * @param data The values whose string representations we'll return
     * @return The string representation of the value or 'emptyFieldValue' if the parameter was null
     */
    public String value(Object ... data){
        if(data==null)return emptyFieldValue;
        StringBuilder builder=new StringBuilder();
        boolean writtenValue=false;
        for(Object item:data){
            if(item!=null){
                if(item instanceof Object[])
                    builder.append(value((Object[])item));
                else if(item instanceof Date)
                    builder.append(value((Date)item));
                else if(item instanceof Double)
                    builder.append(value((Double)item));
                else if(item instanceof Boolean){
                    builder.append(value((Boolean)item));
                }
                else
                    builder.append(item.toString());
                writtenValue=true;
            }
        }
        if(writtenValue){
            return builder.toString();
        }
        return emptyFieldValue;
    }

    /**
     * @param layout The dto to convert to a string array
     * @return The string array
     */
    public String[] fromLayout(Object layout){
        if(!LayoutUtils.isLayout(layout)){
            throw new IllegalArgumentException("Object: "+ layout +" is not annotated with CsvDTO annotation");
        }
        String[]            fieldArray      =   null;
        TreeMap<Integer,String> map         =   getValueMap(layout);
        if(map.isEmpty()){
            fieldArray                      =   new String[]{this.getEmptyFieldValue()};
        }
        else{
            fieldArray                      =   new String[map.lastKey()+1];
            for(int i=0;i<fieldArray.length;i++){
                fieldArray[i]=this.getEmptyFieldValue();
            }
            for(Integer position:map.keySet()){
                fieldArray[position]        =   map.get(position);
            }
        }
        return fieldArray;
    }

    public String formatLayout(Object layout){
        return formatFields(fromLayout(layout));
    }

    /**
     * @param fields The fields to write
     * @return A formatted string
     */
    public String formatFields(String[] fields) {
        StringWriter writer=new StringWriter();
        try {
            CsvWriter csvWriter=createCsvWriter(writer);
            csvWriter.writeNext(fields);
            csvWriter.flush();
            csvWriter.close();
        } catch (IOException e) {

        }
        return writer.toString();
    }

    /**      
     * @param dto The dto to convert to a list of strings
     * @return A list of strings
     */
    public TreeMap<Integer,String> getValueMap(Object dto){
        TreeMap<Integer,String> values          =   new TreeMap<Integer,String>();        
        try{            
            Integer     position    =   null;
            Field[]     fields      =   dto.getClass().getDeclaredFields();
            for(Field field: fields){
                field.setAccessible(true);
                position            =   LayoutUtils.getFieldPosition(field);
                if(position!=null){
                    values.put(position,value(field.get(dto)));
                }
                else if(LayoutUtils.isLayout(field.getType())){
                    values.putAll(getValueMap(field.get(dto)));
                }
            }
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
        return values;
    }
}
