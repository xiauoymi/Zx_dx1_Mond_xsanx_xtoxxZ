package com.monsanto.eas.cia.integration.format.excel;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 04:47:30 PM
 * To change this template use File | Settings | File Templates.
 */
public enum CellType {
    HEADER(){
        public Class<CellType> getType() {
            return CellType.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
            cellStyle.setBorderBottom(CellStyle.BORDER_THICK);
            cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            cellStyle.setBorderTop(CellStyle.BORDER_THICK);
            cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
            Font font= excelDocumentBuilder.getFont(this.name());
            font.setColor(IndexedColors.BLACK.getIndex());
            font.setBoldweight(Font.BOLDWEIGHT_BOLD);            
            cellStyle.setFont(font);
        }
        public Cell buildCell(int position, Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            String value=(String)content;
            Cell cell= getCell(position, excelDocumentBuilder);
            if(value!=null){
                cell.setCellValue(
                    excelDocumentBuilder.getCreationHelper().createRichTextString(value)
                );
            }
            return cell;
        }},
    STRING(){
        public Class<String> getType(){
            return String.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_JUSTIFY);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        }
        public Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            String value=(String)content;
            Cell cell= getCell(position, excelDocumentBuilder);
            if(value!=null){
                cell.setCellValue(
                    excelDocumentBuilder.getCreationHelper().createRichTextString(value)
                );
            }
            return cell;
        }
    },
    INTEGER(){
        public Class<Integer> getType(){
            return Integer.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
            cellStyle.setDataFormat(getDataFormat(excelDocumentBuilder).getFormat(configuration.getIntegerDataFormat()));
        }
        public Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            Integer value=(Integer)content;
            Cell cell=getCell(position, excelDocumentBuilder);
            if(value!=null)
                cell.setCellValue(value);
            return cell;
        }},
    DOUBLE(){
        public Class<Double> getType(){
            return Double.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
            cellStyle.setDataFormat(getDataFormat(excelDocumentBuilder).getFormat(configuration.getDecimalFormatString()));
        }
        public Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            Double value=(Double)content;
            Cell cell=getCell(position, excelDocumentBuilder);
            if(value!=null)
                cell.setCellValue(value);
            return cell;
        }},
    BOOLEAN(){
        public Class<Boolean> getType(){
            return Boolean.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_JUSTIFY);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        }public Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            Boolean value=(Boolean)content;
            Cell cell=getCell(position, excelDocumentBuilder);
            cell.setCellValue(value!=null?value:false);
            return cell;
        }},
    DATE(){
        public Class<Date> getType(){
            return Date.class;
        }
        public void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder) {
            CellStyle cellStyle=getCellStyle(excelDocumentBuilder);
            cellStyle.setAlignment(XSSFCellStyle.ALIGN_JUSTIFY);
            cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
            cellStyle.setDataFormat(getDataFormat(excelDocumentBuilder).getFormat(configuration.getDateFormatString()));
        }public Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder) {
            Date value=(Date)content;
            Cell cell=getCell(position, excelDocumentBuilder);
            if(value!=null)
                cell.setCellValue(value);
            return cell;
        }}
    ;
    public abstract void declareCellStyle(ExcelWriterConfiguration configuration, ExcelDocumentBuilder excelDocumentBuilder);
    public abstract Cell buildCell(int position,Object content, ExcelDocumentBuilder excelDocumentBuilder);
    public abstract Class<?> getType();

    protected CellStyle getCellStyle(ExcelDocumentBuilder excelDocumentBuilder){
        return excelDocumentBuilder.getCellStyle(this.name());
    }

    protected Cell getCell(int position, ExcelDocumentBuilder excelDocumentBuilder){
        return excelDocumentBuilder.createCell(position,this.name());
    }

    protected DataFormat getDataFormat(ExcelDocumentBuilder cellBuilder){
        return cellBuilder.getAnonymousDataFormat();
    }

    public static Map<Class<?>, CellType> getCellTypes(boolean includeSpecialStyles){
        Map<Class<?>, CellType> map=new HashMap<Class<?>, CellType>();
        for(CellType cellType: CellType.values()){
            if(!includeSpecialStyles&&cellType.getType()==CellType.class)continue;
            map.put(cellType.getType(),cellType);
        }
        return map;
    }
}
