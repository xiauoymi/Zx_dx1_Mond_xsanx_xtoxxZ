package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.format.RecordConfiguration;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 12:57:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelConfiguration extends RecordConfiguration {
    protected int       sheetNumber =   0;    
    protected int       headerRows  =   1;
    protected String    integerDataFormat="0";

    public ExcelConfiguration() {
        setDateFormatString("dd/MM/yyyy");
    }

    public int getHeaderRows() {
        return headerRows;
    }

    public void setHeaderRows(int headerRows) {
        this.headerRows = headerRows;
    }

    public int getSheetNumber() {
        return sheetNumber;
    }

    public void setSheetNumber(int sheetNumber) {
        this.sheetNumber = sheetNumber;
    }

    public String getIntegerDataFormat() {
        return integerDataFormat;
    }

    public void setIntegerDataFormat(String integerDataFormat) {
        this.integerDataFormat = integerDataFormat;
    }
}
