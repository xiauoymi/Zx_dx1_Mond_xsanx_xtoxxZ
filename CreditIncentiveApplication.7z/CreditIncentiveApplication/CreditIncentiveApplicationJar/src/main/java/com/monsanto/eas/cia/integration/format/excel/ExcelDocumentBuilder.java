package com.monsanto.eas.cia.integration.format.excel;


import org.apache.poi.ss.usermodel.*;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 02:07:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelDocumentBuilder {
    protected Sheet                 sheet;
    protected Map<String,CellStyle> cellStyles=new HashMap<String,CellStyle>();
    protected Map<String,DataFormat> dataFormats=new HashMap<String,DataFormat>();
    protected Map<String,Font>      fonts=new HashMap<String,Font>();
    protected CreationHelper        creationHelper;
    protected Row                   row;
    protected Cell                  cell;
    protected int                   recordNumber;
    protected int                   cellNumber;

    public ExcelDocumentBuilder(Sheet sheet) {
        this(sheet,0);
    }

    public ExcelDocumentBuilder(Sheet sheet, int recordNumber) {
        this.sheet          =   sheet;
        this.creationHelper =   this.sheet.getWorkbook().getCreationHelper();
        this.recordNumber   =   Math.abs(recordNumber);
        this.cellStyles     =   new HashMap<String,CellStyle>();
    }

    public void saveDocument(OutputStream output) throws IOException {
        Workbook workbook=getWorkbook();
        workbook.write(output);
        output.close();
    }

    public Workbook getWorkbook(){
        return this.sheet.getWorkbook();
    }

    public ExcelDocumentBuilder autoSizeColumns(){
        this.sheet.autoSizeColumn((short)2);
        return this;
    }

    public CreationHelper getCreationHelper() {
        return creationHelper;
    }

    public ExcelDocumentBuilder createRow(){
        cell=null;
        cellNumber=0;
        row=sheet.createRow(recordNumber++);
        return this;
    }

    public Row getCurrentRow(){
        return row;
    }

    public Cell getCurrentCell(){
        return cell;
    }

    public Cell createCell(){
        return createCell(cellNumber++);
    }

    public Cell createCell(String name){
        return createCell(cellNumber++,name);
    }
        
    public Cell createCell(int position){
        if(row==null)throw new IllegalStateException();
        return cell=row.createCell(Math.abs(position));        
    }

    public Cell createCell(int position,String name){
        Cell cell= createCell(position);
        if(name!=null){
            CellStyle cellStyle=getCellStyle(name);
            if(cellStyle!=null)
                cell.setCellStyle(cellStyle);
        }        
        return cell;
    }

    public Font getFont(String fontName){
        Font font=null;
        if(fonts.containsKey(fontName)){
            font=fonts.get(fontName);
        }
        else{
            fonts.put(fontName,font=getAnonymousFont());
        }
        return font;
    }

    public Font getAnonymousFont(){
        return sheet.getWorkbook().createFont();
    }

    public CellStyle getCellStyle(String cellStyleName){
        CellStyle cellStyle=null;
        if(cellStyles.containsKey(cellStyleName)){
            cellStyle=cellStyles.get(cellStyleName);
        }
        else{
            cellStyles.put(cellStyleName,cellStyle=getAnonymousCellStyle());
        }                
        return cellStyle;
    }    

    public CellStyle getAnonymousCellStyle(){
        return sheet.getWorkbook().createCellStyle();
    }

    public DataFormat getDataFormat(String dataFormatName){
        DataFormat dataFormat=null;
        if(dataFormats.containsKey(dataFormatName)){
            dataFormat=dataFormats.get(dataFormatName);
        }
        else{
            dataFormats.put(dataFormatName,dataFormat=getAnonymousDataFormat());
        }
        return dataFormat;
    }

    public DataFormat getAnonymousDataFormat(){
        return sheet.getWorkbook().createDataFormat();
    }


    public int getRecordNumber() {
        return recordNumber;
    }

    public Sheet getSheet() {
        return sheet;
    }
}
