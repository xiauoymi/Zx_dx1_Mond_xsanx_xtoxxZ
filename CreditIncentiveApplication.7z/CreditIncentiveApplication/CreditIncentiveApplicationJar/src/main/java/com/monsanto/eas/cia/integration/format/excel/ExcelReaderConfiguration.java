package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.format.FieldAnnotationProcessor;
import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 12:57:42 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ExcelReaderConfiguration extends ExcelConfiguration {

    /**
     * Data parser delegates
     */
    protected Map<Class<?>, FieldParser<?,Cell>> fieldConverterAdapters;

    /**
     * fieldAnnotationProcessors
     */
    protected Map<Class<?>, FieldAnnotationProcessor<Cell>> fieldAnnotationProcessors;

    public ExcelReaderConfiguration() {
        initFieldConverterAdapters();
        initFieldAnnotationProcessors();
    }

    public Workbook getWorkbook(InputStream inputStream) throws IOException, InvalidFormatException {
        return WorkbookFactory.create(inputStream);        
    }

    public Sheet getSheet(InputStream inputStream)throws IOException, InvalidFormatException {
        Workbook    workbook= getWorkbook(inputStream);
        Sheet       sheet   =workbook.getSheetAt(getSheetNumber());
        return sheet;
    }

    public Iterator<Row> getIterator(InputStream inputStream)throws IOException, InvalidFormatException{
        Sheet   sheet=getSheet(inputStream);
        return sheet.iterator();
    }

    public Iterator<Row> getIteratorAndSkipHeaderRows(InputStream inputStream)throws IOException, InvalidFormatException{
        Iterator<Row> iterator= getIterator(inputStream);
        for(int i=getHeaderRows();i>0&&iterator.hasNext();i--){
            iterator.next();
        }
        return iterator;
    }

    /**
     * Initialize parserDelegates map
     */
    protected void initFieldConverterAdapters(){
        fieldConverterAdapters =new HashMap<Class<?>, FieldParser<?,Cell>>();
        fieldConverterAdapters.put(String.class,new StringCellParserAdapter());
        fieldConverterAdapters.put(Integer.class,new IntegerCellParserAdapter());
        fieldConverterAdapters.put(Double.class,new DoubleCellParserAdapter());
        fieldConverterAdapters.put(Date.class,new DateCellParserAdapter());
        fieldConverterAdapters.put(Boolean.class,new BooleanCellParserAdapter());
    }

    protected void initFieldAnnotationProcessors(){
        fieldAnnotationProcessors=new HashMap<Class<?>,FieldAnnotationProcessor<Cell>>();
        fieldAnnotationProcessors.put(StripZeroes.class,new StripZeroesFieldAnnotationProcessor());
    }

    public ExcelRecord createExcelRecord(Row row){
        return new ExcelRecord(row, fieldConverterAdapters,fieldAnnotationProcessors);
    }

    public class StripZeroesFieldAnnotationProcessor implements FieldAnnotationProcessor<Cell> {
        public Cell process(Cell cell) {
            if(cell!=null){
                String value=cell.getRichStringCellValue().toString();
                if(value!=null){
                    value= StringUtils.stripStart(value.trim(),"0");
                }
                cell.setCellValue(value);
            }
            return cell;
        }
    }

    public class StringCellParserAdapter implements FieldParser<String,Cell> {
        public String parse(Cell source) throws ParseException {
            return parseString(source);
        }
    }

    public class DoubleCellParserAdapter implements FieldParser<Double,Cell> {
        public Double parse(Cell source) throws ParseException {
            return parseDouble(source);
        }
    }

    public class IntegerCellParserAdapter implements FieldParser<Integer,Cell> {
        public Integer parse(Cell source) throws ParseException {
            return parseInteger(source);
        }
    }

    public class BooleanCellParserAdapter implements FieldParser<Boolean,Cell> {
        public Boolean parse(Cell source) throws ParseException {
            return parseBoolean(source);
        }
    }

    public class DateCellParserAdapter implements FieldParser<Date,Cell> {
        public Date parse(Cell source) throws ParseException {
            return parseDate(source);
        }
    }

    public String parseString(Cell cell){
        if(isCellValueNull(cell))return null;
        if(isNumericCellValue(cell))return String.valueOf(cell.getNumericCellValue());
        return cell.getRichStringCellValue().toString();
    }

    public Double parseDouble(Cell cell){
        if(isNumericCellValueNull(cell))return null;
        return cell.getNumericCellValue();
    }

    public Integer parseInteger(Cell cell){
        if(isNumericCellValueNull(cell))return null;
        return (int)cell.getNumericCellValue();
    }

    public Boolean parseBoolean(Cell cell){
        if(isCellValueNull(cell))return Boolean.FALSE;        
        return cell.getBooleanCellValue();
    }

    public Date parseDate(Cell cell){
        if(isCellValueNull(cell))return null;
        return cell.getDateCellValue();
    }

    /**     
     * @param cell The cell we are verifying not to be null
     * @return Whether this input field was null
     */
    public boolean isCellValueNull(Cell cell){
        if(cell==null||(cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue()==null))return true;
        boolean test = false;
        try {
            test = cell.getStringCellValue().trim().equalsIgnoreCase(getEmptyFieldValue());
        } catch (Exception e) {
            test = false;
        }
        return test;
    }

    public boolean isNumericCellValueNull(Cell cell){
        if(cell==null){
          return true;
        } return false;
    }

    public boolean isNumericCellValue(Cell cell){
        try {
            cell.getNumericCellValue();
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
