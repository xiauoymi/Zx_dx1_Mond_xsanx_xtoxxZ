package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.format.FieldAnnotationProcessor;
import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.Record;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 01:23:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelRecord extends Record<Cell> {
    protected Row row;

    protected ExcelRecord(Row row, Map<Class<?>, FieldParser<?, Cell>> fieldParsers,Map<Class<?>, FieldAnnotationProcessor<Cell>> fieldAnnotationProcessors) {
        super(row.getRowNum(), fieldParsers,fieldAnnotationProcessors);
        setRow(row);
    }

    @Override
    public Cell getFieldValue(int position) {        
        return row.getCell(position,Row.RETURN_BLANK_AS_NULL);
    }

    public void setRow(Row row) {
        this.row = row;
    }
}
