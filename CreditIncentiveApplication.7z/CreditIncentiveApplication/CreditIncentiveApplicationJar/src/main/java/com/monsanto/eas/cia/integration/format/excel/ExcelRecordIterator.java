package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.RecordIterator;
import org.apache.poi.ss.usermodel.Row;

import java.io.InputStream;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 10:49:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelRecordIterator implements RecordIterator {

    protected ExcelReaderConfiguration  excelReaderConfiguration;
    protected InputStream               inputStream;
    protected Iterator<Row>             iterator;

    public ExcelRecordIterator(ExcelReaderConfiguration excelReaderConfiguration, InputStream inputStream) {
        this.excelReaderConfiguration = excelReaderConfiguration;
        this.inputStream = inputStream;
    }

    public RecordIterator start() {
        try {
            iterator=excelReaderConfiguration.getIteratorAndSkipHeaderRows(inputStream);
        } catch (Exception e) {
            throw new ExcelRecordIteratorException(e,null);
        }        
        return this;
    }

    public boolean hasNext() {
        return iterator.hasNext();
    }

    public Record next() {
        Row row=null;
        try{
           row=iterator.next();
            return excelReaderConfiguration.createExcelRecord(row);
        }
        catch(Exception e){
            throw new ExcelRecordIteratorException(e,row);
        }
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
