package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.format.exception.RecordIteratorException;
import org.apache.poi.ss.usermodel.Row;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 11:54:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelRecordIteratorException extends RecordIteratorException {
    protected Row row;

    public ExcelRecordIteratorException(Throwable t, Row row) {
        super(t, row!=null?row.getRowNum():-1);
        setRow(row);
    }

    public Row getRow() {
        return row;
    }

    public void setRow(Row row) {
        this.row = row;
    }

    @Override
    public Object getFieldValue(int position) {
        return row.getCell(position);
    }
}
