package com.monsanto.eas.cia.integration.format.excel;

import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 11:59:44 AM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ExcelWriterConfiguration extends ExcelConfiguration{

    protected String defaultSheetName="info"; 

    public ExcelWriterConfiguration() {
        super.setDateFormatString("dd/mm/yyyy");
        super.setIntegerDataFormat("#'###,##0");
        super.setDecimalFormatString("#'###,##0.000");
    }

    public Workbook createEmptyWorkbook(){
        return new XSSFWorkbook();
    }

    public Sheet createEmptySheet(String sheetName){        
        return createEmptyWorkbook().createSheet(sheetName);
    }

    public ExcelDocumentBuilder createExcelDocumentBuilder(String sheetName){
        return new ExcelDocumentBuilder(createEmptySheet(sheetName));
    }

    public void addHeaders(Class<?> _class, ExcelDocumentBuilder excelDocumentBuilder, ResourceBundle bundle) throws Exception{
        Integer     position    =   null;
        Field[]     fields      =   _class.getDeclaredFields();
        for(Field field: fields){
            field.setAccessible(true);
            position            =   LayoutUtils.getFieldPosition(field);
            Class<?> type       =   field.getType();
            if(position!=null){
                String fieldName    =_class.getName()+"."+field.getName();                                
                String headerName   =bundle!=null&&bundle.containsKey(fieldName)?bundle.getString(fieldName):field.getName();
                CellType.HEADER.buildCell(position,headerName,excelDocumentBuilder);                
            }
            else if(LayoutUtils.isLayout(type)){
                addHeaders(type,excelDocumentBuilder,bundle);
            }
        }
    }

    public void addLayout(Object layout, ExcelDocumentBuilder cellBuilder) throws Exception{
        Integer     position    =   null;
        Field[]     fields      =   layout.getClass().getDeclaredFields();
        Map<Class<?>, CellType> cellTypes= CellType.getCellTypes(false);
        for(Field field: fields){
            field.setAccessible(true);
            position            =   LayoutUtils.getFieldPosition(field);
            Class<?> type       =   field.getType();
            Object   value      =   field.get(layout);
            if(position!=null){
                CellType cellType=cellTypes.get(type);
                if(cellType!=null){
                    cellType.buildCell(position,value,cellBuilder);
                }
                else
                	throw new RuntimeException("Missing cell type");
            }
            else if(LayoutUtils.isLayout(type)){
                addLayout(value,cellBuilder);
            }
        }
    }

    public String getDefaultSheetName() {
        return defaultSheetName;
    }

    public void setDefaultSheetName(String defaultSheetName) {
        this.defaultSheetName = defaultSheetName;
    }
}
