package com.monsanto.eas.cia.integration.format.exception;

import com.monsanto.eas.cia.integration.exception.AbstractLayoutException;

import java.util.Formatter;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 18/01/2011
 * Time: 04:17:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class ParseRecordException extends AbstractLayoutException {
    private Class<?> conversionType;
    private int fieldPosition;

    public ParseRecordException(long recordNumber, int fieldPosition,Class<?> conversionType) {
        setFullPosition(recordNumber, fieldPosition);
        setConversionType(conversionType);
    }

    public ParseRecordException(String message,long recordNumber, int fieldPosition, Class<?> conversionType) {
        super(message);
        setFullPosition(recordNumber, fieldPosition);
        setConversionType(conversionType);
    }

    public ParseRecordException(String message, Throwable cause, long recordNumber, int fieldPosition,Class<?> conversionType) {
        super(message, cause);
        setFullPosition(recordNumber, fieldPosition);
        setConversionType(conversionType);
    }    

    public void setFullPosition(long recordNumber, int fieldNumber){
        setRecordNumber(recordNumber);
        setFieldPosition(fieldNumber);
    }

    public int getFieldPosition() {
        return fieldPosition;
    }

    public void setFieldPosition(int fieldPosition) {
        this.fieldPosition = fieldPosition;
    }

    public Class<?> getConversionType() {
        return conversionType;
    }

    public void setConversionType(Class<?> conversionType) {
        this.conversionType = conversionType;
    }

    @Override
    public String explain(ResourceBundle bundle) {
        Formatter formatter=new Formatter(new StringBuilder());
        formatter.format("%s[%d,%d]:= %s.%n %s",bundle.getString("field.label"),getRecordNumber(),getFieldPosition(),getMessage(),getStackTraceValue());
        return formatter.toString();
    }
}
