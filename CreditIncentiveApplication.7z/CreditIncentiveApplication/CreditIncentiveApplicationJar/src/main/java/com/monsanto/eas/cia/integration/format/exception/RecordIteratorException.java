package com.monsanto.eas.cia.integration.format.exception;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 11:50:35 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class RecordIteratorException extends RuntimeException{
    protected long          position    =   -1;
    
    public RecordIteratorException(Throwable t,long position) {
        super(t);
        setPosition(position);
    }

    public long getPosition() {
        return position;
    }

    public void setPosition(long position) {
        this.position = position;
    }

    public boolean isStarted() {
        return position>-1;
    }

    public abstract Object getFieldValue(int position);
    
}
