package com.monsanto.eas.cia.integration.layout.aspect;

import com.monsanto.eas.cia.model.listener.BatchLoadEntityListener;
import com.monsanto.eas.cia.model.listener.ExecutionContextEntityListener;
import com.monsanto.eas.cia.util.ExecutionContext;
import com.monsanto.eas.cia.util.MapBuilder;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.Ordered;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 04:14:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Aspect
public class BatchLoadEntityListenerAspect implements Ordered {
    protected int order;

    protected String batchLoadUser ="bw";

    @Pointcut("execution (* com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService+.importLayout(..))")
    public void importLayoutService(){}

    @Around("importLayoutService()")
    public Object enableBatchLoadEntitiesCallback(ProceedingJoinPoint joinpoint) throws Throwable{
        ExecutionContextEntityListener.enableCallback(
            BatchLoadEntityListener.EXECUTION_KEY,
            new MapBuilder<String,Object>().
                put(BatchLoadEntityListener.BATCH_LOAD_USER_KEY,getBatchLoadUser()).
                    map()
        );        
        try{
            return joinpoint.proceed();
        }
        catch(Throwable t){
            throw t;
        }
        finally{
            ExecutionContextEntityListener.disableCallback(BatchLoadEntityListener.EXECUTION_KEY);
        }
    }


    public String getBatchLoadUser() {
        return ExecutionContext.
            getCurrentExecutionContext().
            getVariable(
                    BatchLoadEntityListener.BATCH_LOAD_USER_KEY,
                    batchLoadUser
            );
    }

    public void setBatchLoadUser(String layoutServiceExecutionUser) {
        this.batchLoadUser = layoutServiceExecutionUser;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
}
