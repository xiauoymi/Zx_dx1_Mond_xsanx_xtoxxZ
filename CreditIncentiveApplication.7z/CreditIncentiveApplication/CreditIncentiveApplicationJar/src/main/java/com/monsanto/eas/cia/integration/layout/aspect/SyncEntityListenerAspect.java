package com.monsanto.eas.cia.integration.layout.aspect;

import com.monsanto.eas.cia.model.listener.ExecutionContextEntityListener;
import com.monsanto.eas.cia.model.listener.SyncEntityListener;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.Ordered;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/03/2011
 * Time: 01:18:11 PM
 * To change this template use File | Settings | File Templates.
 */
@Aspect
public class SyncEntityListenerAspect implements Ordered{

    protected int order=-1;

    @Pointcut("execution (@com.monsanto.eas.cia.integration.layout.annotation.SyncEntities * com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService+.importLayout(..))")
    public void importLayoutService(){}

    @Around("importLayoutService()")
    public Object enableSyncEntitiesCallback(ProceedingJoinPoint joinpoint) throws Throwable{
        ExecutionContextEntityListener.enableCallback(SyncEntityListener.EXECUTION_KEY);
        try{
            return joinpoint.proceed();
        }
        catch(Throwable t){
            throw t;
        }
        finally{
            ExecutionContextEntityListener.disableCallback(SyncEntityListener.EXECUTION_KEY);
        }
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getOrder() {
        return order;
    }
}
