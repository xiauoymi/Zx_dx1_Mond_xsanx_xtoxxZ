package com.monsanto.eas.cia.integration.layout.contract;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.service.FinderService;
import com.monsanto.eas.cia.util.ExecutionContext;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 2/02/2011
 * Time: 10:34:16 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLayoutService implements BeanNameAware{
    @Autowired
    protected CriteriaDao dao;

    @Autowired
    protected FinderService finderService;

	private String defaultCountryCode="MX";	   
    
    public void setDao(CriteriaDao dao) {
        this.dao = dao;
    }

    public void setFinderService(FinderService finderService) {
        this.finderService = finderService;
    }

    public FinderService getFinderService() {
        return finderService;
    }

    public CriteriaDao getDao() {
        return dao;
    }

	public void setDefaultCountryCode(String defaultCountryCode) {
		this.defaultCountryCode = defaultCountryCode;
	}
	
	public String getDefaultCountryCode(){
		return ExecutionContext.getCurrentExecutionContext().getVariable("countryCode",this.defaultCountryCode);		
	}
        
    public void setBeanName(String name) {
        Class<? extends AbstractLayoutService> thisClass=this.getClass();
        Class<? extends Layout> layoutClass= (Class<? extends Layout>) ObjectUtils.getGenericType(thisClass, Layout.class);
        LAYOUT_SERVICE_STRUCTURES.put(name,layoutClass);
        LAYOUT_SERVICE_CLASS.put(name,thisClass);
    }

    public static final Map<String,Class<?>> LAYOUT_SERVICE_CLASS=new HashMap<String,Class<?>>();
    public static final Map<String,Class<?>> LAYOUT_SERVICE_STRUCTURES=new HashMap<String,Class<?>>();

}
