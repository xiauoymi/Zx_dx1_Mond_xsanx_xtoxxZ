package com.monsanto.eas.cia.integration.layout.contract;

import com.monsanto.eas.cia.integration.contract.Layout;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 2/02/2011
 * Time: 10:34:59 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ImportLayoutService<T extends Layout> {
    public void importLayout(T layout);
}
