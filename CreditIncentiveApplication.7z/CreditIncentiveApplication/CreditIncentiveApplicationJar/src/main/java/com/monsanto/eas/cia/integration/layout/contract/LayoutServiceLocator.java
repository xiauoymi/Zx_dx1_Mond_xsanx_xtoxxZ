package com.monsanto.eas.cia.integration.layout.contract;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 5/02/2011
 * Time: 09:17:32 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LayoutServiceLocator {
    public ExportLayoutService lookupExportLayoutService(String serviceId);
    public ImportLayoutService lookupImportLayoutService(String serviceId);

}
