package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.contract.Layout;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 5/02/2011
 * Time: 08:13:04 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLayout implements Layout {

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    public abstract AbstractLayout clone();
}
