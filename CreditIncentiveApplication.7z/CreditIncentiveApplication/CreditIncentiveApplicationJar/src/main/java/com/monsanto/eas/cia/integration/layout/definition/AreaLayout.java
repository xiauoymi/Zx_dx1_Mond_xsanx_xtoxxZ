package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 03:44:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class AreaLayout extends AbstractLayout{

    /**
     * Code
     */
    @NotNull
    @FieldPosition(0) protected String code;
    /**
     * Description
     */
    @NotNull
    @FieldPosition(1) protected String description;    
    @FieldPosition(2) protected String parentCode;
    @FieldPosition(3) protected String discriminator;
    @FieldPosition(4) protected String shortcut;
    
	public AreaLayout() {
    }

    public AreaLayout(AreaLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }    
    
	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDiscriminator() {
        return discriminator;
    }

    public void setDiscriminator(String discriminator) {
        this.discriminator = discriminator;
    }
    
    public String getShortcut() {
		return shortcut;
	}

	public void setShortcut(String shortcut) {
		this.shortcut = shortcut;
	}

	@Override
    public AreaLayout clone() {
        return new AreaLayout(this);
    }
}
