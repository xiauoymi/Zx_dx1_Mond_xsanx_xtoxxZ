package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 06:16:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class CodeDescriptionLayout  extends AbstractLayout{

    /**
     * Code
     */
    @NotNull
    @StripZeroes
    @FieldPosition(0) protected String code;
    /**
     * Description
     */
    @NotNull
    @FieldPosition(1) protected String description;

    public CodeDescriptionLayout() {
    }
    
    public CodeDescriptionLayout(CodeDescriptionLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public CodeDescriptionLayout clone(){
        return new CodeDescriptionLayout(this);
    }
}
