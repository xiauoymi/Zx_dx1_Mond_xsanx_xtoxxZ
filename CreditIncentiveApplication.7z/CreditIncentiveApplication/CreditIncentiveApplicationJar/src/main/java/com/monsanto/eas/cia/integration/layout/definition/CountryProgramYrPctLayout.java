package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/02/2011
 * Time: 12:20:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class CountryProgramYrPctLayout extends AbstractLayout{

    @NotNull
    @FieldPosition(0)   protected Integer   year;
    @NotNull
    @FieldPosition(1)   protected Boolean   open;
    @NotNull
    @FieldPosition(2)   protected String    countryCode;
    @NotNull
    @FieldPosition(3)   protected String    countryName;
    @FieldPosition(4)   protected Date      quarter1Start;
    @FieldPosition(5)   protected Date      quarter1End;
    @FieldPosition(6)   protected Date      quarter2Start;
    @FieldPosition(7)   protected Date      quarter2End;
    @FieldPosition(8)   protected Date      quarter3Start;
    @FieldPosition(9)   protected Date      quarter3End;
    @FieldPosition(10)  protected Date      quarter4Start;
    @FieldPosition(11)  protected Date      quarter4End;
    @FieldPosition(12)  protected Double minPct;
    @FieldPosition(13)  protected Double maxPct;
    @FieldPosition(14)  protected Double minYrPct;
    @FieldPosition(15)  protected Double maxYrPct;    

    public CountryProgramYrPctLayout() {
    }

    public CountryProgramYrPctLayout(CountryProgramYrPctLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public Double getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(Double maxPct) {
        this.maxPct = maxPct;
    }

    public Double getMaxYrPct() {
        return maxYrPct;
    }

    public void setMaxYrPct(Double maxYrPct) {
        this.maxYrPct = maxYrPct;
    }

    public Double getMinPct() {
        return minPct;
    }

    public void setMinPct(Double minPct) {
        this.minPct = minPct;
    }

    public Double getMinYrPct() {
        return minYrPct;
    }

    public void setMinYrPct(Double minYrPct) {
        this.minYrPct = minYrPct;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public Date getQuarter1End() {
        return quarter1End;
    }

    public void setQuarter1End(Date quarter1End) {
        this.quarter1End = quarter1End;
    }

    public Date getQuarter1Start() {
        return quarter1Start;
    }

    public void setQuarter1Start(Date quarter1Start) {
        this.quarter1Start = quarter1Start;
    }

    public Date getQuarter2End() {
        return quarter2End;
    }

    public void setQuarter2End(Date quarter2End) {
        this.quarter2End = quarter2End;
    }

    public Date getQuarter2Start() {
        return quarter2Start;
    }

    public void setQuarter2Start(Date quarter2Start) {
        this.quarter2Start = quarter2Start;
    }

    public Date getQuarter3End() {
        return quarter3End;
    }

    public void setQuarter3End(Date quarter3End) {
        this.quarter3End = quarter3End;
    }

    public Date getQuarter3Start() {
        return quarter3Start;
    }

    public void setQuarter3Start(Date quarter3Start) {
        this.quarter3Start = quarter3Start;
    }

    public Date getQuarter4End() {
        return quarter4End;
    }

    public void setQuarter4End(Date quarter4End) {
        this.quarter4End = quarter4End;
    }

    public Date getQuarter4Start() {
        return quarter4Start;
    }

    public void setQuarter4Start(Date quarter4Start) {
        this.quarter4Start = quarter4Start;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public CountryProgramYrPctLayout clone() {
        return new CountryProgramYrPctLayout(this);        
    }
}
