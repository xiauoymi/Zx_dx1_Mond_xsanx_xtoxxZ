package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 04:45:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class DescriptionLayout extends AbstractLayout{

    @NotNull
    @FieldPosition(0) protected String description;

    public DescriptionLayout() {
    }

    public DescriptionLayout(DescriptionLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public DescriptionLayout clone() {
        return new DescriptionLayout(this);
    }
}
