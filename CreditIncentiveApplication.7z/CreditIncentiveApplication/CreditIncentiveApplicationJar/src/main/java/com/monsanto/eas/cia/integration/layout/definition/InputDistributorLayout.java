package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 06:09:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputDistributorLayout extends AbstractLayout {

    /**
     * Distributor.code
     */
    @StripZeroes
    @FieldPosition(0)
    protected String sapId;
    /**
     * Distributor.division.code
     */
    @FieldPosition(1)
    protected String division;
    /**
     * Distributor.distributionChannel.code
     */
    @FieldPosition(2)
    protected String distributionChannel;
    /**
     * Distributor.salesOrganization.code
     */
    @FieldPosition(3)
    protected String salesOrganization;
    /**
     * Distributor.description
     */
    @FieldPosition(4)
    protected String description;

    public InputDistributorLayout() {
    }

    public InputDistributorLayout(InputDistributorLayout other) {
        ObjectUtils.copySourceInto(other, this);
    }

    public String getSapId() {
        return sapId;
    }

    public void setSapId(String sapId) {
        this.sapId = sapId;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getDistributionChannel() {
        return distributionChannel;
    }

    public void setDistributionChannel(String distributionChannel) {
        this.distributionChannel = distributionChannel;
    }

    public String getSalesOrganization() {
        return salesOrganization;
    }

    public void setSalesOrganization(String salesOrganization) {
        this.salesOrganization = salesOrganization;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public InputDistributorLayout clone() {
        return new InputDistributorLayout(this);
    }
}
