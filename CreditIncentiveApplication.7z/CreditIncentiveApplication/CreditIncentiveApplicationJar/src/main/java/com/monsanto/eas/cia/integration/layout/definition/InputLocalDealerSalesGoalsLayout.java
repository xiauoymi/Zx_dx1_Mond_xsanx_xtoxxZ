package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 08:37:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputLocalDealerSalesGoalsLayout extends AbstractLayout {
    @FieldPosition(0)
    protected Integer year;

    /**
     * LocalDealer.agreementNumber
     */
    @FieldPosition(1)
    protected String agreementNumber;

    /**
     * LocalDealer.incentives[0].maxIncentive
     */
    @FieldPosition(2)
    protected Double maxQ1;

    /**
     * LocalDealer.incentives[1].maxIncentive
     */
    @FieldPosition(3)
    protected Double maxQ2;

    /**
     * LocalDealer.incentives[2].maxIncentive
     */
    @FieldPosition(4)
    protected Double maxQ3;

    /**
     * LocalDealer.incentives[3].maxIncentive
     */
    @FieldPosition(5)
    protected Double maxQ4;

    /**
     * LocalDealer.incentives[0].minIncentive
     */
    @FieldPosition(6)
    protected Double minQ1;

    /**
     * LocalDealer.incentives[1].minIncentive
     */
    @FieldPosition(7)
    protected Double minQ2;

    /**
     * LocalDealer.incentives[2].minIncentive
     */
    @FieldPosition(8)
    protected Double minQ3;

    /**
     * LocalDealer.incentives[3].minIncentive
     */
    @FieldPosition(9)
    protected Double minQ4;

    /**
     * LocalDealer.programYears[1..*].maxTarget
     */
    @FieldPosition(10)
    protected Double maxTarget;

    /**
     * LocalDealer.programYears[1..*].minTarget
     */
    @FieldPosition(11)
    protected Double minTarget;


    @FieldPosition(12)
    private Double minPctQ1;

    @FieldPosition(13)
    private Double maxPctQ1;


    @FieldPosition(14)
    private Double minPctQ2;

    @FieldPosition(15)
    private Double maxPctQ2;


    @FieldPosition(16)
    private Double minPctQ3;

    @FieldPosition(17)
    private Double maxPctQ3;


    @FieldPosition(18)
    private Double minPctQ4;

    @FieldPosition(19)
    private Double maxPctQ4;


    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(20)
    protected Integer distId1;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(21)
    protected Integer distId2;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(22)
    protected Integer distId3;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(23)
    protected Integer distId4;

    @FieldPosition(24)
    protected String address1;

    @FieldPosition(25)
    protected String address2;

    @FieldPosition(26)
    protected String birthday;

    @FieldPosition(27)
    protected String businessAnniversary;

    @FieldPosition(28)
    protected String email;

    @FieldPosition(29)
    protected String fax;

    @FieldPosition(30)
    protected String fiscalName;

    @FieldPosition(31)
    protected String name;

    @FieldPosition(32)
    protected String phone;

    @FieldPosition(33)
    protected String posName;

    @FieldPosition(34)
    protected String rfc;

    @FieldPosition(35)
    protected String commercialManager;

    @FieldPosition(36)
    protected String commercialSupervisor;

    @FieldPosition(37)
    protected String subRegion;

    @FieldPosition(38)
    protected String postalCode;

    public InputLocalDealerSalesGoalsLayout() {
    }

    public InputLocalDealerSalesGoalsLayout(InputLocalDealerSalesGoalsLayout other) {
        ObjectUtils.copySourceInto(other, this);
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Double getMaxPctQ1() {
        return maxPctQ1;
    }

    public void setMaxPctQ1(Double maxPctQ1) {
        this.maxPctQ1 = maxPctQ1;
    }

    public Double getMinPctQ1() {
        return minPctQ1;
    }

    public void setMinPctQ1(Double minPctQ1) {
        this.minPctQ1 = minPctQ1;
    }

    public Double getMaxPctQ2() {
        return maxPctQ2;
    }

    public void setMaxPctQ2(Double maxPctQ2) {
        this.maxPctQ2 = maxPctQ2;
    }

    public Double getMinPctQ2() {
        return minPctQ2;
    }

    public void setMinPctQ2(Double minPctQ2) {
        this.minPctQ2 = minPctQ2;
    }

    public Double getMaxPctQ3() {
        return maxPctQ3;
    }

    public void setMaxPctQ3(Double maxPctQ3) {
        this.maxPctQ3 = maxPctQ3;
    }

    public Double getMinPctQ3() {
        return minPctQ3;
    }

    public void setMinPctQ3(Double minPctQ3) {
        this.minPctQ3 = minPctQ3;
    }

    public Double getMaxPctQ4() {
        return maxPctQ4;
    }

    public void setMaxPctQ4(Double maxPctQ4) {
        this.maxPctQ4 = maxPctQ4;
    }

    public Double getMinPctQ4() {
        return minPctQ4;
    }

    public void setMinPctQ4(Double minPctQ4) {
        this.minPctQ4 = minPctQ4;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public Integer getDistId1() {
        return distId1;
    }

    public void setDistId1(Integer distId1) {
        this.distId1 = distId1;
    }

    public Integer getDistId2() {
        return distId2;
    }

    public void setDistId2(Integer distId2) {
        this.distId2 = distId2;
    }

    public Integer getDistId3() {
        return distId3;
    }

    public void setDistId3(Integer distId3) {
        this.distId3 = distId3;
    }

    public Integer getDistId4() {
        return distId4;
    }

    public void setDistId4(Integer distId4) {
        this.distId4 = distId4;
    }

    public Double getMaxQ1() {
        return maxQ1;
    }

    public void setMaxQ1(Double maxQ1) {
        this.maxQ1 = maxQ1;
    }

    public Double getMaxQ2() {
        return maxQ2;
    }

    public void setMaxQ2(Double maxQ2) {
        this.maxQ2 = maxQ2;
    }

    public Double getMaxQ3() {
        return maxQ3;
    }

    public void setMaxQ3(Double maxQ3) {
        this.maxQ3 = maxQ3;
    }

    public Double getMaxQ4() {
        return maxQ4;
    }

    public void setMaxQ4(Double maxQ4) {
        this.maxQ4 = maxQ4;
    }

    public Double getMaxTarget() {
        return maxTarget;
    }

    public void setMaxTarget(Double maxTarget) {
        this.maxTarget = maxTarget;
    }

    public Double getMinQ1() {
        return minQ1;
    }

    public void setMinQ1(Double minQ1) {
        this.minQ1 = minQ1;
    }

    public Double getMinQ2() {
        return minQ2;
    }

    public void setMinQ2(Double minQ2) {
        this.minQ2 = minQ2;
    }

    public Double getMinQ3() {
        return minQ3;
    }

    public void setMinQ3(Double minQ3) {
        this.minQ3 = minQ3;
    }

    public Double getMinQ4() {
        return minQ4;
    }

    public void setMinQ4(Double minQ4) {
        this.minQ4 = minQ4;
    }

    public Double getMinTarget() {
        return minTarget;
    }

    public void setMinTarget(Double minTarget) {
        this.minTarget = minTarget;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getBusinessAnniversary() {
        return businessAnniversary;
    }

    public void setBusinessAnniversary(String businessAnniversary) {
        this.businessAnniversary = businessAnniversary;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFiscalName() {
        return fiscalName;
    }

    public void setFiscalName(String fiscalName) {
        this.fiscalName = fiscalName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getCommercialManager() {
        return commercialManager;
    }

    public void setCommercialManager(String commercialManager) {
        this.commercialManager = commercialManager;
    }

    public String getCommercialSupervisor() {
        return commercialSupervisor;
    }

    public void setCommercialSupervisor(String commercialSupervisor) {
        this.commercialSupervisor = commercialSupervisor;
    }


    public String getSubRegion() {
        return subRegion;
    }

    public void setSubRegion(String subRegion) {
        this.subRegion = subRegion;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @Override
    public InputLocalDealerSalesGoalsLayout clone() {
        return new InputLocalDealerSalesGoalsLayout(this);
    }
}
