package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 06:13:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputProductLayout extends AbstractLayout {
    /**
     * Product.code
     */
    @StripZeroes
    @FieldPosition(0)
    protected String sapId;
    /**
     * Product.description
     */
    @FieldPosition(1)
    protected String description;
    /**
     * Product.division.code
     */
    @FieldPosition(2)
    protected String division;
    /**
     * Product.group.code
     */
    @FieldPosition(3)
    protected String group;

    public InputProductLayout() {
    }

    public InputProductLayout(InputProductLayout other) {
        ObjectUtils.copySourceInto(other, this);
    }

    public String getSapId() {
        return sapId;
    }

    public void setSapId(String sapId) {
        this.sapId = sapId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    @Override
    public InputProductLayout clone() {
        return new InputProductLayout(this);
    }
}
