package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.format.annotation.StripZeroes;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 06:19:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputSalesLayout  extends AbstractLayout{
    /**
     *  LdSales.salesDate
     */
    @NotNull
    @FieldPosition(0)  protected Date    date                ;
    /**
     * LdSales.transactionType.description
     */
    @StripZeroes
    @NotNull
    @FieldPosition(1)  protected String  transactionType     ;
    /**
     * LdSales.transactionNumber
     */
    @StripZeroes
    @NotNull
    @FieldPosition(2)  protected String  transactionNumber   ;

    @StripZeroes
    @FieldPosition(3)  protected String subRegionCode;

    @FieldPosition(4)  protected Integer programYear;
    /**
     * LdSales.ldDist.localDealer.agreementNumber
     */
    @NotNull
    @FieldPosition(5)  protected String  agreement           ;
    /**
     * LdSales.productCode.code
     */
    @NotNull
    @FieldPosition(6)  protected String  productCode         ;
    /**
     * LdSales.ldDist.localDealer.agreementNumber
     */
    @FieldPosition(7)  protected String  assignedFrom        ;

    /**
     * LdSales.validForIncentivePlanning
     */
    @NotNull
    @FieldPosition(8)  protected Boolean validForIncentivePlanning;

    /**
     * LdSales.creditNote.code
     */
    @FieldPosition(9)  protected String  creditNoteCode      ;
    /**
     * LdSales.creditNote!=null
     */
    @FieldPosition(10) protected Boolean sent2Sap            ;
    /**
     * LdSales.creditNote.to
     */
    @FieldPosition(11) protected Date    creditNoteDate      ;
    /**
     * LdSales.creditNote.taxReserve.code
     */
    @FieldPosition(12) protected String  taxReserveNumber   ;

    @FieldPosition(13)  protected String  creditNoteCode2      ;
    @FieldPosition(14) protected Boolean sent2Sap2            ;

    @FieldPosition(15) protected String  taxReserveNumber3    ;


    @FieldPosition(16)  protected String  creditNoteCode4      ;
    @FieldPosition(17) protected Boolean sent2Sap4            ;
    @FieldPosition(18) protected Date    creditNoteDate4      ;
    @FieldPosition(19) protected String  taxReserveNumber4    ;

    @FieldPosition(20)  protected String  creditNoteCode5      ;
    @FieldPosition(21) protected Boolean sent2Sap5            ;
    @FieldPosition(22) protected Date    creditNoteDate5      ;
    @FieldPosition(23) protected String  taxReserveNumber5    ;

    /**
     * LdSales.ldDist.distributor.sapId
     */
    @StripZeroes
    @NotNull
    @FieldPosition(24) protected String magneticStripe;

    @FieldPosition(25) protected Date    creditNoteDate2      ;
    @FieldPosition(26) protected String  taxReserveNumber2    ;
    @FieldPosition(27)  protected String  creditNoteCode3      ;
    @FieldPosition(28) protected Boolean sent2Sap3            ;
    @FieldPosition(29) protected Date    creditNoteDate3      ;

    /**
     * LdSales.salesVolume
     * Units
     */
    @FieldPosition(30) protected Double  salesVolume         ;

    /**
     * LdSales.volumeAssigned
     */
    @FieldPosition(31) protected Double  volumeAssigned      ;
    /**
     * LdSales.volumeToIncentive
     */
    @FieldPosition(32) protected Double  volumeToIncentive   ;
    /**
     * LdSales.price
     */
    @FieldPosition(33) protected Double  price               ;
    /**
     * LdSales.incentiveAmount
     */
    @FieldPosition(34) protected Double  incentiveAmount     ;

    public InputSalesLayout() {
    }

    public InputSalesLayout(InputSalesLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public String getCreditNoteCode2() {
        return creditNoteCode2;
    }

    public void setCreditNoteCode2(String creditNoteCode2) {
        this.creditNoteCode2 = creditNoteCode2;
    }

    public Boolean getSent2Sap2() {
        return sent2Sap2;
    }

    public void setSent2Sap2(Boolean sent2Sap2) {
        this.sent2Sap2 = sent2Sap2;
    }

    public Date getCreditNoteDate2() {
        return creditNoteDate2;
    }

    public void setCreditNoteDate2(Date creditNoteDate2) {
        this.creditNoteDate2 = creditNoteDate2;
    }

    public String getTaxReserveNumber2() {
        return taxReserveNumber2;
    }

    public void setTaxReserveNumber2(String taxReserveNumber2) {
        this.taxReserveNumber2 = taxReserveNumber2;
    }

    public String getCreditNoteCode3() {
        return creditNoteCode3;
    }

    public void setCreditNoteCode3(String creditNoteCode3) {
        this.creditNoteCode3 = creditNoteCode3;
    }

    public Boolean getSent2Sap3() {
        return sent2Sap3;
    }

    public void setSent2Sap3(Boolean sent2Sap3) {
        this.sent2Sap3 = sent2Sap3;
    }

    public Date getCreditNoteDate3() {
        return creditNoteDate3;
    }

    public void setCreditNoteDate3(Date creditNoteDate3) {
        this.creditNoteDate3 = creditNoteDate3;
    }

    public String getTaxReserveNumber3() {
        return taxReserveNumber3;
    }

    public void setTaxReserveNumber3(String taxReserveNumber3) {
        this.taxReserveNumber3 = taxReserveNumber3;
    }

    public String getCreditNoteCode4() {
        return creditNoteCode4;
    }

    public void setCreditNoteCode4(String creditNoteCode4) {
        this.creditNoteCode4 = creditNoteCode4;
    }

    public Boolean getSent2Sap4() {
        return sent2Sap4;
    }

    public void setSent2Sap4(Boolean sent2Sap4) {
        this.sent2Sap4 = sent2Sap4;
    }

    public Date getCreditNoteDate4() {
        return creditNoteDate4;
    }

    public void setCreditNoteDate4(Date creditNoteDate4) {
        this.creditNoteDate4 = creditNoteDate4;
    }

    public String getTaxReserveNumber4() {
        return taxReserveNumber4;
    }

    public void setTaxReserveNumber4(String taxReserveNumber4) {
        this.taxReserveNumber4 = taxReserveNumber4;
    }

    public String getCreditNoteCode5() {
        return creditNoteCode5;
    }

    public void setCreditNoteCode5(String creditNoteCode5) {
        this.creditNoteCode5 = creditNoteCode5;
    }

    public Boolean getSent2Sap5() {
        return sent2Sap5;
    }

    public void setSent2Sap5(Boolean sent2Sap5) {
        this.sent2Sap5 = sent2Sap5;
    }

    public Date getCreditNoteDate5() {
        return creditNoteDate5;
    }

    public void setCreditNoteDate5(Date creditNoteDate5) {
        this.creditNoteDate5 = creditNoteDate5;
    }

    public String getTaxReserveNumber5() {
        return taxReserveNumber5;
    }

    public void setTaxReserveNumber5(String taxReserveNumber5) {
        this.taxReserveNumber5 = taxReserveNumber5;
    }

    public Integer getProgramYear() {
        return programYear;
    }

    public void setProgramYear(Integer programYear) {
        this.programYear = programYear;
    }

    public String getSubRegionCode() {
        return subRegionCode;
    }

    public void setSubRegionCode(String subRegionCode) {
        this.subRegionCode = subRegionCode;
    }

    public String getMagneticStripe() {
        return magneticStripe;
    }

    public void setMagneticStripe(String magneticStripe) {
        this.magneticStripe = magneticStripe;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public String getAgreement() {
        return agreement;
    }

    public void setAgreement(String agreement) {
        this.agreement = agreement;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Double getSalesVolume() {
        return salesVolume;
    }

    public void setSalesVolume(Double salesVolume) {
        this.salesVolume = salesVolume;
    }

    public String getAssignedFrom() {
        return assignedFrom;
    }

    public void setAssignedFrom(String assignedFrom) {
        this.assignedFrom = assignedFrom;
    }

    public Double getVolumeAssigned() {
        return volumeAssigned;
    }

    public void setVolumeAssigned(Double volumeAssigned) {
        this.volumeAssigned = volumeAssigned;
    }

    public Double getVolumeToIncentive() {
        return volumeToIncentive;
    }

    public void setVolumeToIncentive(Double volumeToIncentive) {
        this.volumeToIncentive = volumeToIncentive;
    }

    public Boolean getValidForIncentivePlanning() {
        return validForIncentivePlanning;
    }

    public void setValidForIncentivePlanning(Boolean validForIncentivePlanning) {
        this.validForIncentivePlanning = validForIncentivePlanning;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getIncentiveAmount() {
        return incentiveAmount;
    }

    public void setIncentiveAmount(Double incentiveAmount) {
        this.incentiveAmount = incentiveAmount;
    }

    public String getCreditNoteCode() {
        return creditNoteCode;
    }

    public void setCreditNoteCode(String creditNoteCode) {
        this.creditNoteCode = creditNoteCode;
    }

    public Boolean getSent2Sap() {
        return sent2Sap!=null&&sent2Sap;
    }

    public void setSent2Sap(Boolean sent2Sap) {
        this.sent2Sap = sent2Sap;
    }

    public Date getCreditNoteDate() {
        return creditNoteDate;
    }

    public void setCreditNoteDate(Date creditNoteDate) {
        this.creditNoteDate = creditNoteDate;
    }

    public String getTaxReserveNumber() {
        return taxReserveNumber;
    }

    public void setTaxReserveNumber(String taxReserveNumber) {
        this.taxReserveNumber = taxReserveNumber;
    }

    @Override
    public InputSalesLayout clone(){
        return new InputSalesLayout(this);
    }
}
