package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: JNOLA1
 * Date: 24/01/2013
 * Time: 13:33:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputSalesUploadLayout extends AbstractLayout{

    @NotNull
    @FieldPosition(0)
    protected String  transactionNumber;

    @NotNull
    @FieldPosition(1)
    protected Integer  barCode;

    @NotNull
    @FieldPosition(2)
    protected Integer  transactionType;

    @NotNull
    @FieldPosition(3)
    protected String transactionDate;

    @NotNull
    @FieldPosition(4)
    protected String salesRep;

    @NotNull
    @FieldPosition(5)
    protected Double  volumeAssigned;

    @FieldPosition(6)
    protected String idDevReason;

    @NotNull
    @FieldPosition(7)
    protected Double factorLts;

    @NotNull
    @FieldPosition(8)
    protected Double factorReg;

    @NotNull
    @FieldPosition(9)
    protected Integer sapCode;

    @NotNull
    @FieldPosition(10)
    protected String  agreement;

    public InputSalesUploadLayout() {
    }

    public InputSalesUploadLayout(InputSalesUploadLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    @Override
    public InputSalesUploadLayout clone(){
        return new InputSalesUploadLayout(this);
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public Integer getBarCode() {
        return barCode;
    }

    public void setBarCode(Integer barCode) {
        this.barCode = barCode;
    }

    public Integer getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(Integer transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(String salesRep) {
        this.salesRep = salesRep;
    }

    public Double getVolumeAssigned() {
        return volumeAssigned;
    }

    public void setVolumeAssigned(Double volumeAssigned) {
        this.volumeAssigned = volumeAssigned;
    }

    public String getIdDevReason() {
        return idDevReason;
    }

    public void setIdDevReason(String idDevReason) {
        this.idDevReason = idDevReason;
    }

    public Double getFactorLts() {
        return factorLts;
    }

    public void setFactorLts(Double factorLts) {
        this.factorLts = factorLts;
    }

    public Double getFactorReg() {
        return factorReg;
    }

    public void setFactorReg(Double factorReg) {
        this.factorReg = factorReg;
    }

    public Integer getSapCode() {
        return sapCode;
    }

    public void setSapCode(Integer sapCode) {
        this.sapCode = sapCode;
    }

    public String getAgreement() {
        return agreement;
    }

    public void setAgreement(String agreement) {
        this.agreement = agreement;
    }
}