package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 08:28:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class OutputLocalDealerSalesGoalsLayout extends AbstractLayout {
    /**
     * LocalDealer.programYears[1..*].year.year
     */
    @FieldPosition(0)  protected Integer     year                ;

    /**
     * LocalDealer.commercialSupervisor.description
     */
    @FieldPosition(1)  protected String      salesRepresent;

    /**
     * LocalDealer.subRegion.code
     */
    @FieldPosition(2)  protected String      subRegion           ;

    /**
     * LocalDealer.commercialSupervisor.description
     */
    @FieldPosition(3)  protected String      commercialSupervisor;

     /**
     * LocalDealer.name
     */
    @FieldPosition(4)  protected String      contactName         ;

    /**
     * LocalDealer.posName
     */
    @FieldPosition(5)  protected String      company             ;

    /**
     * LocalDealer.rfc
     */
    @FieldPosition(6)  protected String      taxId               ;

    /**
     * LocalDealer.district.parentArea.code
     */
    @FieldPosition(7)  protected String      state               ;

     /**
     * LocalDealer.district.code
     */
    @FieldPosition(8)  protected String      district            ;

    /**
     * LocalDealer.country.description
     */
    @FieldPosition(9) protected String country;
    
    /**
     * LocalDealer.address1+" "+LocalDealer.address2
     */
    @FieldPosition(10) protected String      address             ;

    /**
     * LocalDealer.postalCodeArea.code
     */
    @FieldPosition(11) protected String      zipCode             ;
    
    /**
     * LocalDealer.phone
     */
    @FieldPosition(12) protected String      phone               ;

    /**
     * LocalDealer.fax
     */
    @FieldPosition(13) protected String      fax                 ;

    /**
     * LocalDealer.email
     */
    @FieldPosition(14) protected String      email               ;

    /**
     * LocalDealer.birthday
     */
    @FieldPosition(15) protected Date        birthday            ;

    /**
     * LocalDealer.businessAnniversary
     */
    @FieldPosition(16) protected Date      anniversary         ;

    /**
     * LocalDealer.agreementNumber
     */
    @FieldPosition(17) protected String      agreementNumber      ;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(18) protected String      distId1             ;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(19) protected String      distId2             ;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(20) protected String      distId3             ;

    /**
     * LocalDealer.ldDist.distributor.sapId
     */
    @FieldPosition(21) protected String      distId4             ;

    /**
     * LocalDealer.incentives[0].minIncentive
     */
    @FieldPosition(22) protected Double      minQ1               ;

    /**
     * LocalDealer.incentives[0].maxIncentive
     */
    @FieldPosition(23) protected Double      maxQ1               ;

    /**
     * LocalDealer.incentives[1].minIncentive
     */
    @FieldPosition(24) protected Double      minQ2               ;

    /**
     * LocalDealer.incentives[1].maxIncentive
     */
    @FieldPosition(25) protected Double      maxQ2               ;

    /**
     * LocalDealer.incentives[2].minIncentive
     */
    @FieldPosition(26) protected Double      minQ3               ;

    /**
     * LocalDealer.incentives[2].maxIncentive
     */
    @FieldPosition(27) protected Double      maxQ3               ;

    /**
     * LocalDealer.incentives[3].minIncentive
     */
    @FieldPosition(28) protected Double      minQ4               ;

    /**
     * LocalDealer.incentives[3].maxIncentive
     */
    @FieldPosition(29) protected Double      maxQ4               ;

    /**
     * LocalDealer.programYears[1..*].maxTarget
     */
    @FieldPosition(30) protected Double      maxTarget           ;
    
    /**
     * LocalDealer.programYears[1..*].minTarget
     */
    @FieldPosition(31) protected Double      minTarget           ;

    @FieldPosition(32) protected String signed;

    @FieldPosition(33) protected Date validFromDate;

    @FieldPosition(34) protected Date validToDate;

    public OutputLocalDealerSalesGoalsLayout() {
    }

    public OutputLocalDealerSalesGoalsLayout(OutputLocalDealerSalesGoalsLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getSalesRepresent() {
        return salesRepresent;
    }

    public void setSalesRepresent(String salesRepresent) {
        this.salesRepresent = salesRepresent;
    }

    public String getSubRegion() {
        return subRegion;
    }

    public void setSubRegion(String subRegion) {
        this.subRegion = subRegion.toUpperCase();
    }

    public String getCommercialSupervisor() {
        return commercialSupervisor;
    }

    public void setCommercialSupervisor(String commercialSupervisor) {
        this.commercialSupervisor = commercialSupervisor;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName.toUpperCase();
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company.toUpperCase();
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country.toUpperCase();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Date getAnniversary() {
        return anniversary;
    }

    public void setAnniversary(Date anniversary) {
        this.anniversary = anniversary;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getSigned() {
        return signed;
    }

    public void setSigned(String signed) {
        this.signed = signed;
    }

    public Double getMinTarget() {
        return minTarget;
    }

    public void setMinTarget(Double minTarget) {
        this.minTarget = minTarget;
    }

    public Double getMaxTarget() {
        return maxTarget;
    }

    public void setMaxTarget(Double maxTarget) {
        this.maxTarget = maxTarget;
    }

    public Double getMaxQ4() {
        return maxQ4;
    }

    public void setMaxQ4(Double maxQ4) {
        this.maxQ4 = maxQ4;
    }

    public Double getMinQ4() {
        return minQ4;
    }

    public void setMinQ4(Double minQ4) {
        this.minQ4 = minQ4;
    }

    public Double getMaxQ3() {
        return maxQ3;
    }

    public void setMaxQ3(Double maxQ3) {
        this.maxQ3 = maxQ3;
    }

    public Double getMinQ3() {
        return minQ3;
    }

    public void setMinQ3(Double minQ3) {
        this.minQ3 = minQ3;
    }

    public Double getMaxQ2() {
        return maxQ2;
    }

    public void setMaxQ2(Double maxQ2) {
        this.maxQ2 = maxQ2;
    }

    public Double getMinQ2() {
        return minQ2;
    }

    public void setMinQ2(Double minQ2) {
        this.minQ2 = minQ2;
    }

    public Double getMinQ1() {
        return minQ1;
    }

    public void setMinQ1(Double minQ1) {
        this.minQ1 = minQ1;
    }

    public Double getMaxQ1() {
        return maxQ1;
    }

    public void setMaxQ1(Double maxQ1) {
        this.maxQ1 = maxQ1;
    }

    public String getDistId4() {
        return distId4;
    }

    public void setDistId4(String distId4) {
        this.distId4 = distId4;
    }

    public String getDistId3() {
        return distId3;
    }

    public void setDistId3(String distId3) {
        this.distId3 = distId3;
    }

    public String getDistId2() {
        return distId2;
    }

    public void setDistId2(String distId2) {
        this.distId2 = distId2;
    }

    public String getDistId1() {
        return distId1;
    }

    public void setDistId1(String distId1) {
        this.distId1 = distId1;
    }

    public Date getValidFromDate() {
        return validFromDate;
    }

    public void setValidFromDate(Date validFromDate) {
        this.validFromDate = validFromDate;
    }

    public Date getValidToDate() {
        return validToDate;
    }

    public void setValidToDate(Date validToDate) {
        this.validToDate = validToDate;
    }

    @Override
    public OutputLocalDealerSalesGoalsLayout clone() {
        return new OutputLocalDealerSalesGoalsLayout(this);  //To change body of implemented methods use File | Settings | File Templates.
    }
}
