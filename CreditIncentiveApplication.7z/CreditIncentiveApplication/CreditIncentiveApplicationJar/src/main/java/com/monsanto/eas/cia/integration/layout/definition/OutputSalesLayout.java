package com.monsanto.eas.cia.integration.layout.definition;

import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.integration.util.FieldPosition;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 06:23:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class OutputSalesLayout extends AbstractLayout {

    /**
     * LdSales.transactionNumber
     */
    @FieldPosition(0) protected String  transactionNumber        ;
    /**
     * LdSales.volumeAssigned
     */
    @FieldPosition(1) protected Double  volumeAssigned           ;
    /**
     * LdSales.volumeToIncentive
     */
    @FieldPosition(2) protected Double  volumeToIncentive        ;
    /**
     * LdSales.validForIncentivePlanning
     */
    @FieldPosition(3) protected Boolean validForIncentivePlanning;
    /**
     * LdSales.incentiveAmount
     */
    @FieldPosition(4) protected Double  incentiveAmount          ;
    /**
     * LdSales.creditNote.code
     */
    @FieldPosition(5) protected String  creditNoteCode           ;
    /**
     * LdSales.creditNote!=null
     */
    @FieldPosition(6) protected Boolean sent2Sap                 ;
    /**
     * LdSales.creditNote.to
     */
    @FieldPosition(7) protected Date    creditNoteDate           ;

    /**
     * LdSales.creditNote.taxReserve.code
     */
    @FieldPosition(8) protected String taxReserveCode           ;

    @FieldPosition(9) protected String  creditNote2              ;
    @FieldPosition(10) protected Boolean sent2Sap2               ;
    @FieldPosition(11) protected Date    creditNoteDate2         ;
    @FieldPosition(12) protected String taxReserveCode2         ;

    @FieldPosition(13) protected String  creditNote3             ;
    @FieldPosition(14) protected Boolean sent2Sap3               ;
    @FieldPosition(15) protected Date    creditNoteDate3         ;
    @FieldPosition(16) protected String taxReserveCode3         ;

    @FieldPosition(17) protected String  creditNote4             ;
    @FieldPosition(18) protected Boolean sent2Sap4               ;
    @FieldPosition(19) protected Date    creditNoteDate4         ;
    @FieldPosition(20) protected String taxReserveCode4         ;

    @FieldPosition(21) protected String  creditNote5             ;
    @FieldPosition(22) protected Boolean sent2Sap5               ;
    @FieldPosition(23) protected Date    creditNoteDate5         ;
    @FieldPosition(24) protected String taxReserveCode5         ;

    /**
     * LdSales.assignedFrom.agreementNumber
     */
    @FieldPosition(25) protected String  assignedFrom             ;

    public String getTaxReserveCode2() {
        return taxReserveCode2;
    }

    public void setTaxReserveCode2(String taxReserveCode2) {
        this.taxReserveCode2 = taxReserveCode2;
    }

    public String getTaxReserveCode3() {
        return taxReserveCode3;
    }

    public void setTaxReserveCode3(String taxReserveCode3) {
        this.taxReserveCode3 = taxReserveCode3;
    }

    public String getTaxReserveCode4() {
        return taxReserveCode4;
    }

    public void setTaxReserveCode4(String taxReserveCode4) {
        this.taxReserveCode4 = taxReserveCode4;
    }

    public String getTaxReserveCode5() {
        return taxReserveCode5;
    }

    public void setTaxReserveCode5(String taxReserveCode5) {
        this.taxReserveCode5 = taxReserveCode5;
    }

    public Boolean getSent2Sap2() {
        return sent2Sap2;
    }

    public void setSent2Sap2(Boolean sent2Sap2) {
        this.sent2Sap2 = sent2Sap2;
    }

    public Date getCreditNoteDate2() {
        return creditNoteDate2;
    }

    public void setCreditNoteDate2(Date creditNoteDate2) {
        this.creditNoteDate2 = creditNoteDate2;
    }

    public Boolean getSent2Sap3() {
        return sent2Sap3;
    }

    public void setSent2Sap3(Boolean sent2Sap3) {
        this.sent2Sap3 = sent2Sap3;
    }

    public Date getCreditNoteDate3() {
        return creditNoteDate3;
    }

    public void setCreditNoteDate3(Date creditNoteDate3) {
        this.creditNoteDate3 = creditNoteDate3;
    }

    public Boolean getSent2Sap4() {
        return sent2Sap4;
    }

    public void setSent2Sap4(Boolean sent2Sap4) {
        this.sent2Sap4 = sent2Sap4;
    }

    public Date getCreditNoteDate4() {
        return creditNoteDate4;
    }

    public void setCreditNoteDate4(Date creditNoteDate4) {
        this.creditNoteDate4 = creditNoteDate4;
    }

    public Boolean getSent2Sap5() {
        return sent2Sap5;
    }

    public void setSent2Sap5(Boolean sent2Sap5) {
        this.sent2Sap5 = sent2Sap5;
    }

    public Date getCreditNoteDate5() {
        return creditNoteDate5;
    }

    public void setCreditNoteDate5(Date creditNoteDate5) {
        this.creditNoteDate5 = creditNoteDate5;
    }

    public String getCreditNote2() {
        return creditNote2;
    }

    public void setCreditNote2(String creditNote2) {
        this.creditNote2 = creditNote2;
    }

    public String getCreditNote3() {
        return creditNote3;
    }

    public void setCreditNote3(String creditNote3) {
        this.creditNote3 = creditNote3;
    }

    public String getCreditNote4() {
        return creditNote4;
    }

    public void setCreditNote4(String creditNote4) {
        this.creditNote4 = creditNote4;
    }

    public String getCreditNote5() {
        return creditNote5;
    }

    public void setCreditNote5(String creditNote5) {
        this.creditNote5 = creditNote5;
    }

    public OutputSalesLayout() {
    }

    public OutputSalesLayout(OutputSalesLayout other) {
        ObjectUtils.copySourceInto(other,this);
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public Double getVolumeAssigned() {
        return volumeAssigned;
    }

    public void setVolumeAssigned(Double volumeAssigned) {
        this.volumeAssigned = volumeAssigned;
    }

    public Double getVolumeToIncentive() {
        return volumeToIncentive;
    }

    public void setVolumeToIncentive(Double volumeToIncentive) {
        this.volumeToIncentive = volumeToIncentive;
    }

    public Boolean getValidForIncentivePlanning() {
        return validForIncentivePlanning;
    }

    public void setValidForIncentivePlanning(Boolean validForIncentivePlanning) {
        this.validForIncentivePlanning = validForIncentivePlanning;
    }

    public Double getIncentiveAmount() {
        return incentiveAmount;
    }

    public void setIncentiveAmount(Double incentiveAmount) {
        this.incentiveAmount = incentiveAmount;
    }

    public String getCreditNoteCode() {
        return creditNoteCode;
    }

    public void setCreditNoteCode(String creditNoteCode) {
        this.creditNoteCode = creditNoteCode;
    }

    public Boolean getSent2Sap() {
        return sent2Sap;
    }

    public void setSent2Sap(Boolean sent2Sap) {
        this.sent2Sap = sent2Sap;
    }

    public Date getCreditNoteDate() {
        return creditNoteDate;
    }

    public void setCreditNoteDate(Date creditNoteDate) {
        this.creditNoteDate = creditNoteDate;
    }

    public String getTaxReserveCode() {
        return taxReserveCode;
    }

    public void setTaxReserveCode(String taxReserveCode) {
        this.taxReserveCode = taxReserveCode;
    }

    public String getAssignedFrom() {
        return assignedFrom;
    }

    public void setAssignedFrom(String assignedFrom) {
        this.assignedFrom = assignedFrom;
    }

    @Override
    public OutputSalesLayout clone(){
        return new OutputSalesLayout(this);
    }
}
