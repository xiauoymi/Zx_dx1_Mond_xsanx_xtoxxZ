package com.monsanto.eas.cia.integration.layout.exception;

import com.monsanto.eas.cia.integration.contract.Layout;
import org.hibernate.validator.InvalidValue;

public class EmptyLineException extends Throwable {
    public EmptyLineException(Layout layout, long recordNumber, InvalidValue[] invalidValues) {
    }
}
