package com.monsanto.eas.cia.integration.layout.exception;

import com.monsanto.eas.cia.integration.exception.AbstractLayoutException;

import java.text.MessageFormat;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 3/02/2011
 * Time: 07:19:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceException extends AbstractLayoutException {

    protected Object[] parameters;

    public LayoutServiceException(String messageKey, Object ... parameters) {
        super(messageKey);
        setParameters(parameters);
    }

    public LayoutServiceException(String messageKey, Throwable cause, Object ... parameters) {
        super(messageKey, cause);
        setParameters(parameters);
    }

    public Object[] getParameters() {
        return parameters;
    }

    public void setParameters(Object[] parameters) {
        this.parameters = parameters;
    }

    @Override
    public String explain(ResourceBundle bundle) {
        return MessageFormat.format(bundle.getString(getMessage()),parameters)+"\n"+
               MessageFormat.format(bundle.getString("stacktrace"),getStackTraceValue());
    }
}
