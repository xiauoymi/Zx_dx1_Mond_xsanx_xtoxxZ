package com.monsanto.eas.cia.integration.layout.exception;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 3/02/2011
 * Time: 07:31:11 PM
 * To change this template use File | Settings | File Templates.
 */
public enum LayoutServiceExceptionCode {
    UNKNOWN_AREA_DISCRIMINATOR("unknown.area.discriminator"),
    MISSING_LOCAL_DEALER_SIGNATURE_FOR_YEAR("missing.local.dealer.signature.year"),
    MISSING_COUNTRY_PROGRAM_YEAR("missing.country.program.year"),
    SAP_DISTRIBUTOR_NOT_FOUND("sap.distributor.not.found"),
    PRODUCT_LINE_NOT_FOUND("product.line.not.found"),
    DISTRIBUTOR_WITH_SYM_ID_NOT_FOUND("distributor.with.sym.id.not.found"),
    DISTRIBUTOR_WITH_CARD_NOT_FOUND("distributor.with.card.not.found"),
    LOCAL_DEALER_WITH_AGREEMENT_NUMBER_NOT_FOUND("local.dealer.with.agreement.number.not.found"),
    LOCAL_DEALER_LENDING_SALES_VOLUME_NOT_FOUND("local.dealer.lending.sales.volume.not.found"),        
    SAP_PRODUCT_NOT_FOUND("sap.product.not.found"),
    TAX_RESERVE_NOT_FOUND("tax.reserve.not.found"),
    CONFLICTING_SAP_DISTRIBUTOR_CODE("conflicting.sap.distributor.code"),
    EXCEPTION("exception"),
    DISTRIBUTOR_NOT_FOUND_FOR_LOCAL_DEALER("distributor.not.found.for.local.dealer"),
    DATE_SALES_UPLOAD_NOT_FOUND("date.sales.upload.not.found"),
    SAP_PRODUCT_PRICE_NOT_FOUND("sap.product.price.not.found"),
    TRANSACTION_TYPE_NOT_FOUND("transaction.type.not.found")
    ;
    LayoutServiceExceptionCode(String key){
        this.key=key;
    }

    public LayoutServiceException get(Object ... parameters){
        return get((Throwable)null,parameters);
    }

    public LayoutServiceException get(Throwable cause, Object ... parameters){
        return new LayoutServiceException(key,cause, parameters);
    }

    public void fail(){
        throw get();
    }

    public void fail(Object ... parameters){
        throw get((Throwable)null,parameters);
    }

    public void fail(Throwable cause, Object... parameters){
        throw get(cause,parameters);
    }

    public String getKey(){
        return key;
    }

    protected String key;    
}
