package com.monsanto.eas.cia.integration.layout.exception;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 7/02/2011
 * Time: 12:16:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceLocatorException extends RuntimeException{
    protected String    serviceId;
    protected Class<?>  serviceClass;

    public LayoutServiceLocatorException(Throwable e,String serviceId, Class<?> serviceClass) {
        super(e);
        setServiceId(serviceId);
        setServiceClass(serviceClass);
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public Class<?> getServiceClass() {
        return serviceClass;
    }

    public void setServiceClass(Class<?> serviceClass) {
        this.serviceClass = serviceClass;
    }
}
