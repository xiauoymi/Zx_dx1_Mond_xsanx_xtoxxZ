package com.monsanto.eas.cia.integration.layout.exception;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.exception.AbstractLayoutException;
import org.hibernate.validator.InvalidValue;

import java.util.Formatter;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 4/02/2011
 * Time: 02:05:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutValidatorException extends AbstractLayoutException {
    protected InvalidValue[] invalidValues;

    public LayoutValidatorException(Layout layout, long recordNumber, InvalidValue[] invalidValues) {
        setLayout(layout);
        setRecordNumber(recordNumber);
        setInvalidValues(invalidValues);
    }

    public InvalidValue[] getInvalidValues() {
        return invalidValues;
    }

    public void setInvalidValues(InvalidValue[] invalidValues) {
        this.invalidValues = invalidValues;
    }

    public String explain(ResourceBundle bundle) {
        Formatter formatter=new Formatter(new StringBuilder());
        int position=1;
        formatter.format("%n");
        for(InvalidValue invalidValue:invalidValues){            
            formatter.format("%-15s: %d/%d %n",bundle.getString("invalid.value"),position++,invalidValues.length);
            formatter.format("%-15s: %s %n",bundle.getString("invalid.value.class"),invalidValue.getBeanClass().getName());
            formatter.format("%-15s: %s %n",bundle.getString("invalid.value.path"),invalidValue.getPropertyPath());
            formatter.format("%-15s: %s %n",bundle.getString("invalid.value.label"),invalidValue.getValue());
            formatter.format("%-15s: %s %n",bundle.getString("invalid.value.reason"),invalidValue.getMessage());
            formatter.format("%n");
        }
        return formatter.toString();
    }
}
