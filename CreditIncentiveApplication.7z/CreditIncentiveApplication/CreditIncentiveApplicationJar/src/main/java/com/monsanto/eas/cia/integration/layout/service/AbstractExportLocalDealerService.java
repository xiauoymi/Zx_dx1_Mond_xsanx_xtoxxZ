package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.model.LdIncentive;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.model.Year;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 21/02/2011
 * Time: 05:51:06 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractExportLocalDealerService extends AbstractLayoutService {
           
    public Map<Integer,Double[]> getLocalDealerIncentives(Year year,LocalDealer localDealer){
        return getLocalDealerIncentives(year,localDealer,false);
    }

    /**
     * Gets the min and max target value of an incentive for a given local dealer
     * @param localDealer The dealer we are currently processing
     * @return A map associating the quarter number (1..4) to the min and max incentive target value
     */
    public Map<Integer,Double[]> getLocalDealerIncentives(Year year,LocalDealer localDealer, boolean syncVersions){
        Map<Integer,Double[]> incentives=new HashMap<Integer,Double[]>();
        for(int i=0;i<4; i++){
            incentives.put(i,new Double[]{null,null});
        }

        ProgramQuarter programQuarter=null;
        LdIncentive incentive=null;

        for(int i=0;i<4;i++){
            programQuarter=finderService.findProgramQuarterFrom(localDealer,year.getYear(),i+1);
            if(programQuarter==null){                
                continue;
            }
            incentive=finderService.findLdIncentiveFrom(localDealer, year.getYear(),i+1);
            if(incentive != null) {
                incentives.put(
                    incentive.getProgramQuarter().getQuarterType().getQuarterNum()-1,
                    new Double[]{
                        incentive.getMinIncentive(),
                        incentive.getMaxIncentive()
                    }
                );
                if(syncVersions){
                    incentive.syncVersion();
                }                
            }
        }
        return incentives;
    }
}
