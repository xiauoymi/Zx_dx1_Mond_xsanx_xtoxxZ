package com.monsanto.eas.cia.integration.layout.service;

import org.springframework.transaction.annotation.Transactional;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.CodeDescriptionLayout;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 04:30:49 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractImportCodeCatalogEntityService extends AbstractLayoutService implements ImportLayoutService<CodeDescriptionLayout> {
	@Transactional
	public void importLayout(CodeDescriptionLayout layout) {
        String code=layout.getCode();
        CodeCatalogEntity entity= dao.findByCode(getCodeCatalogEntityClass(),code);
        if(entity   ==  null){
            entity          =   getNewCodeCatalogEntity();
            entity.setCode(code);
        }
        entity.setDescription   (layout.getDescription());
        dao.persist(entity);
    }

    public CodeCatalogEntity getNewCodeCatalogEntity(){
        return ObjectUtils.newInstance(getCodeCatalogEntityClass());
    }

    public abstract Class<? extends CodeCatalogEntity> getCodeCatalogEntityClass();
    
}
