package com.monsanto.eas.cia.integration.layout.service;

import org.springframework.transaction.annotation.Transactional;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.DescriptionLayout;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 04:45:08 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractImportDescriptionCatalogEntityService extends AbstractLayoutService implements ImportLayoutService<DescriptionLayout> {
	@Transactional
	public void importLayout(DescriptionLayout layout) {
        String description=layout.getDescription();
        DescriptionCatalogEntity entity= dao.findByDescription(getDescriptionCatalogEntityClass(),description);
        if(entity   ==  null){
            entity          =   getNewDescriptionCatalogEntity();
            entity.setDescription   (description);
            dao.persist(entity);
        }
    }

    public DescriptionCatalogEntity getNewDescriptionCatalogEntity(){
        return ObjectUtils.newInstance(getDescriptionCatalogEntityClass());
    }

    public abstract Class<? extends DescriptionCatalogEntity> getDescriptionCatalogEntityClass();
}
