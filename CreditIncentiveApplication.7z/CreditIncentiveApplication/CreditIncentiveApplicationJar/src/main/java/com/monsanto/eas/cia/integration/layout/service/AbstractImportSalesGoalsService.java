package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.model.LdIncentive;
import com.monsanto.eas.cia.model.LocalDealer;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 12:19:48 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractImportSalesGoalsService extends AbstractLayoutService {

    protected int firstQuarterNumber = 1;

    public void importQuarterSalesGoals(Double[][] incentives, LocalDealer localDealer, final int year) {
        for (int i = 0, quarterNumber = firstQuarterNumber; i < 4; i++, quarterNumber++) {
            Double[] quarterlyIncentive = incentives[i];
            Double minIncentive = quarterlyIncentive[0];
            Double maxIncentive = quarterlyIncentive[1];
            Double minPct = quarterlyIncentive.length > 2 ? quarterlyIncentive[2] : null;
            Double maxPct = quarterlyIncentive.length > 3 ? quarterlyIncentive[3] : null;

            if (minIncentive != null || maxIncentive != null) {
                LdIncentive ldIncentive = finderService.findOrCreateLdIncentive(localDealer, year, quarterNumber);
                ldIncentive.setMinIncentive(minIncentive.doubleValue());
                ldIncentive.setMaxIncentive(maxIncentive.doubleValue());
                if (minPct != null) {
                    ldIncentive.setMinPct(new BigDecimal(minPct));
                }
                if (maxPct != null) {
                    ldIncentive.setMaxPct(new BigDecimal(maxPct));
                }
                dao.persist(ldIncentive);
            }
        }
    }


    public void setFirstQuarterNumber(int firstQuarterNumber) {
        this.firstQuarterNumber = firstQuarterNumber;
    }
}
