package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.OutputLocalDealerSalesGoalsLayout;
import com.monsanto.eas.cia.integration.layout.util.ServiceLayoutUtils;
import com.monsanto.eas.cia.model.CountryProgramYrPct;
import com.monsanto.eas.cia.model.LdProgramYear;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.Year;
import com.monsanto.eas.cia.util.ExecutionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.monsanto.eas.cia.integration.util.LayoutUtils.value;
import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.eqProperty;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 08:40:44 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("export-local-dealer-sales-goals-service")
public class ExportLocalDealerSalesGoalsServiceImpl extends AbstractExportLocalDealerService implements ExportLayoutService<OutputLocalDealerSalesGoalsLayout> {

    protected Integer considerPreviousNumberOfYears = 3;


    public Criteria createCriteria(Session session) {
        CountryProgramYrPct lastCountryProgramYear = getLastCountryProgramYear();
        List<CountryProgramYrPct> previousCountryProgramYears = getPreviousCountryProgramYears(lastCountryProgramYear);
        storePreviousCountryProgramYears(previousCountryProgramYears);
        if (lastCountryProgramYear != null) {
            Year lastYear = lastCountryProgramYear.getYear();

            DetachedCriteria lastYearProgramSignatureCriteria = DetachedCriteria.forClass(LdProgramYear.class, "py");
            lastYearProgramSignatureCriteria.setProjection(Property.forName("py.id"));
            lastYearProgramSignatureCriteria.add(eqProperty("py.localDealer.id", "ld.id"));
            lastYearProgramSignatureCriteria.add(eq("py.year", lastYear));

            Criteria localDealerCriteria = session.createCriteria(LocalDealer.class, "ld");
            localDealerCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
            localDealerCriteria.add(Subqueries.exists(lastYearProgramSignatureCriteria));
            Criteria countryCriteria = localDealerCriteria.createCriteria("ld.country");
            countryCriteria.add(eq("code", getDefaultCountryCode()));
            return localDealerCriteria;
        } else {
            throw new RuntimeException("Found no years in the database");
        }
    }

    public Collection<OutputLocalDealerSalesGoalsLayout> exportLayouts(Object... objects) {
        Year year;
        LdProgramYear ldProgramYear;
        Map<Integer, Double[]> incentives;
        OutputLocalDealerSalesGoalsLayout salesGoals;
        LocalDealer localDealer = (LocalDealer) objects[0];
        List<CountryProgramYrPct> previousCountryProgramYears = retrievePreviousCountryProgramYears();
        List<OutputLocalDealerSalesGoalsLayout> salesGoalsLayouts = new ArrayList<OutputLocalDealerSalesGoalsLayout>();
        String[] distributorSapIds = null;

        for (CountryProgramYrPct countryProgramYear : previousCountryProgramYears) {
            year = countryProgramYear.getYear();
            ldProgramYear = finderService.findLdProgramYearFrom(countryProgramYear, localDealer);
            if (ldProgramYear == null) continue;

            salesGoals = new OutputLocalDealerSalesGoalsLayout();
            salesGoals.setAddress(value(localDealer.getAddress1(), " ", localDealer.getAddress2()));
            salesGoals.setAgreementNumber(localDealer.getAgreementNumber() != null ? localDealer.getAgreementNumber() : "");
            salesGoals.setAnniversary(localDealer.getBusinessAnniversary());
            salesGoals.setBirthday(localDealer.getBirthday());
            salesGoals.setCommercialSupervisor(localDealer.getCommercialSupervisor() != null ? replaceSpecialChars(localDealer.getCommercialSupervisor().getDescription()) : null);
            salesGoals.setCompany(localDealer.getPosName() != null ? localDealer.getPosName() : "");
            salesGoals.setContactName(localDealer.getName() != null ? replaceSpecialChars(localDealer.getName()) : "");
            salesGoals.setCountry((localDealer.getCountry() != null && localDealer.getCountry().getDescription() != null) ? localDealer.getCountry().getDescription() : "");
            distributorSapIds = ServiceLayoutUtils.getLocalDealerDistIds(localDealer, ldProgramYear);
            salesGoals.setDistId1(distributorSapIds[0]);
            salesGoals.setDistId2(distributorSapIds[1]);
            salesGoals.setDistId3(distributorSapIds[2]);
            salesGoals.setDistId4(distributorSapIds[3]);
            salesGoals.setDistrict(localDealer.getDistrict() != null ? localDealer.getDistrict().getDescription() : null);
            salesGoals.setEmail(localDealer.getEmail());
            salesGoals.setFax(localDealer.getFax());
            incentives = getLocalDealerIncentives(year, localDealer);
            salesGoals.setMinQ1(incentives.get(0)[0]);
            salesGoals.setMaxQ1(incentives.get(0)[1]);
            salesGoals.setMinQ2(incentives.get(1)[0]);
            salesGoals.setMaxQ2(incentives.get(1)[1]);
            salesGoals.setMinQ3(incentives.get(2)[0]);
            salesGoals.setMaxQ3(incentives.get(2)[1]);
            salesGoals.setMinQ4(incentives.get(3)[0]);
            salesGoals.setMaxQ4(incentives.get(3)[1]);

            salesGoals.setMaxTarget(ldProgramYear.getMaxTarget());
            salesGoals.setMinTarget(ldProgramYear.getMinTarget());

            salesGoals.setPhone(localDealer.getPhone() != null ? localDealer.getPhone() : "");
            salesGoals.setSalesRepresent(localDealer.getCommercialSupervisor() != null ? replaceSpecialChars(localDealer.getCommercialSupervisor().getDescription()) : "");
            salesGoals.setSigned(ldProgramYear.getLdProgramYearStatus() != null ? ldProgramYear.getLdProgramYearStatus().getDescription() : "");
            salesGoals.setState(replaceSpecialChars(ServiceLayoutUtils.getStateDescription(localDealer)));
            salesGoals.setSubRegion(localDealer.getSubRegion() != null ? localDealer.getSubRegion().getDescription() : "");
            salesGoals.setTaxId(localDealer.getRfc() != null ? localDealer.getRfc() : "");
            salesGoals.setYear(countryProgramYear.getYear().getYear());
            salesGoals.setZipCode(localDealer.getPostalCodeArea() != null ? localDealer.getPostalCodeArea().getDescription() : "");
            salesGoals.setValidFromDate(getFirstDateInYear(year.getYear()));
            salesGoals.setValidToDate(getLastDateInYear(year.getYear()));
            salesGoalsLayouts.add(salesGoals);
        }

        return salesGoalsLayouts;
    }

    private String replaceSpecialChars(String stringToValidate) {
        final String regExp = "[\u00f1\u00d1]*";
        StringBuffer sb = new StringBuffer();

        if(stringToValidate!=null) {        
            Pattern p = Pattern.compile(regExp);
            Matcher m = p.matcher(stringToValidate);
            while (m.find()) {
                int start = m.start();
                int end = m.end();
                int position = 0;

                if (start != end) {
                    position = start;
                    m.appendReplacement(sb, computeReplacementString(stringToValidate.charAt(position)));
                }
            }
            m.appendTail(sb);
        }
        return sb.toString();
    }

    private static String computeReplacementString(char c) {
        String replacement = "";
        String[] optionsForReplacement = {"n", "N"};
        if(Character.isUpperCase(c)) {
            replacement = optionsForReplacement[1];
        } else {
            replacement = optionsForReplacement[0];
        }
        return replacement;
    }

    public CountryProgramYrPct getLastCountryProgramYear() {
        return finderService.findPreviousCountryProgramYearFrom(getDefaultCountryCode());
    }

    public List<CountryProgramYrPct> getPreviousCountryProgramYears(CountryProgramYrPct lastCountryProgramYear) {
        return finderService.findPreviousCountryProgramYearsFrom(lastCountryProgramYear, getContextualPreviousNumberOfYears(), getDefaultCountryCode());
    }

    public void storePreviousCountryProgramYears(List<CountryProgramYrPct> previousCountryProgramYears) {
        ExecutionContext executionContext = ExecutionContext.getCurrentExecutionContext();
        executionContext.setVariable("previousCountryProgramYears", previousCountryProgramYears);
    }

    public List<CountryProgramYrPct> retrievePreviousCountryProgramYears() {
        ExecutionContext executionContext = ExecutionContext.getCurrentExecutionContext();
        return executionContext.getVariable("previousCountryProgramYears", new ArrayList<CountryProgramYrPct>());
    }

    public Integer getContextualPreviousNumberOfYears() {
        ExecutionContext executionContext = ExecutionContext.getCurrentExecutionContext();
        return executionContext.getVariable("previousNumberOfYears", considerPreviousNumberOfYears);
    }

    public void setConsiderPreviousNumberOfYears(Integer considerPreviousNumberOfYears) {
        this.considerPreviousNumberOfYears = considerPreviousNumberOfYears;
    }

    private Date getFirstDateInYear(int year) {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.WEEK_OF_YEAR, 1);
        calendar.set(Calendar.DAY_OF_WEEK, 1);
        return calendar.getTime();
    }

    private Date getLastDateInYear(int year) {
        Calendar calendar = new GregorianCalendar();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH, 11);
        calendar.set(Calendar.DAY_OF_MONTH, 31);
        return calendar.getTime();
    }

}
