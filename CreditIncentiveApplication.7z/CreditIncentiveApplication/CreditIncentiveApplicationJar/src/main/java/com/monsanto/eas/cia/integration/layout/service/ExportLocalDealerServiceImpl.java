package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.LocalDealerLayout;
import com.monsanto.eas.cia.integration.layout.util.ServiceLayoutUtils;
import com.monsanto.eas.cia.model.LdDist;
import com.monsanto.eas.cia.model.LdIncentive;
import com.monsanto.eas.cia.model.LdProgramYear;
import com.monsanto.eas.cia.model.LocalDealer;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import static com.monsanto.eas.cia.integration.util.LayoutUtils.value;
import static com.monsanto.eas.cia.util.CriteriaUtils.addSyncVersionRestriction;
import static org.hibernate.criterion.Restrictions.eq;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/01/2011
 * Time: 12:06:17 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("export-local-dealer-service")
public class ExportLocalDealerServiceImpl extends AbstractExportLocalDealerService implements ExportLayoutService<LocalDealerLayout> {
        
    public Criteria createCriteria(Session session){
        
    	DetachedCriteria programYearsCriteria=DetachedCriteria.forClass(LdProgramYear.class,"programYear");
    	programYearsCriteria.setProjection(Property.forName("programYear.id"));
        programYearsCriteria.add(Restrictions.eqProperty("programYear.localDealer.id","mainLocalDealer.id"));
    	addSyncVersionRestriction(programYearsCriteria,"programYear");
    	
    	DetachedCriteria incentivesCriteria=DetachedCriteria.forClass(LdIncentive.class,"incentive");
    	incentivesCriteria.setProjection(Property.forName("incentive.id"));
        incentivesCriteria.add(Restrictions.eqProperty("incentive.localDealer.id","mainLocalDealer.id"));
    	addSyncVersionRestriction(incentivesCriteria, "incentive");

    	DetachedCriteria ldDistCriteria=DetachedCriteria.forClass(LdDist.class,"ldDist");
    	ldDistCriteria.setProjection(Property.forName("ldDist.id"));
        ldDistCriteria.add(Restrictions.eqProperty("ldDist.localDealer.id","mainLocalDealer.id"));        
    	addSyncVersionRestriction(ldDistCriteria, "ldDist");
    	    	    	    	
    	Criteria localDealerCriteria=session.createCriteria(LocalDealer.class,"mainLocalDealer");
        localDealerCriteria.add(
        	Restrictions.disjunction().
        		add(Restrictions.neProperty("mainLocalDealer.currentVersion","mainLocalDealer.syncVersion")).
        		add(Subqueries.exists(programYearsCriteria)).
        		add(Subqueries.exists(incentivesCriteria)).
        		add(Subqueries.exists(ldDistCriteria))
        );    	    	    
        Criteria countryCriteria=localDealerCriteria.createCriteria("mainLocalDealer.country","country");
        countryCriteria.add(eq("country.code",getDefaultCountryCode()));        
        return localDealerCriteria;
    }
    
    public Collection<LocalDealerLayout> exportLayouts(Object ... objects){
        LocalDealerLayout       localDealerLayout   =   null;
        List<LocalDealerLayout> localDealerLayouts  =   new ArrayList<LocalDealerLayout>();

        LocalDealer             localDealer         =   (LocalDealer)objects[0];

        LocalDealerLayout       prototypeLayout     =   getLayoutFrom(localDealer);
        List<String>            distIds             =   null;
        for(LdProgramYear programYear:localDealer.getProgramYears()){            
            localDealerLayout                       =   prototypeLayout.clone();
            localDealerLayout.setSigned                 (true);
            Map<Integer,Double[]> incentives          =   getLocalDealerIncentives(programYear.getYear(),localDealer,true);

            localDealerLayout.setMinQ1(incentives.get(0)[0]);
            localDealerLayout.setMaxQ1(incentives.get(0)[1]);
            localDealerLayout.setMinQ2(incentives.get(1)[0]);
            localDealerLayout.setMaxQ2(incentives.get(1)[1]);
            localDealerLayout.setMinQ3(incentives.get(2)[0]);
            localDealerLayout.setMaxQ3(incentives.get(2)[1]);
            localDealerLayout.setMinQ4(incentives.get(3)[0]);
            localDealerLayout.setMaxQ4(incentives.get(3)[1]);

            localDealerLayout.setMinTarget              (programYear.getMinTarget());
            localDealerLayout.setMaxTarget              (programYear.getMaxTarget());
            localDealerLayout.setYear                   (programYear.getYear().getYear());
            distIds= ServiceLayoutUtils.getLocalDealerDynamicDistIds(localDealer,programYear,true);
            if(distIds!=null&&distIds.size()>0){
                for(String distId:distIds){
                    localDealerLayout                   =   localDealerLayout.clone();
                    localDealerLayout.setDistId             (distId);
                    localDealerLayouts.add                  (localDealerLayout);
                }
            }
            else if(localDealer.needsSynchronization()){
                localDealerLayouts.add                  (localDealerLayout);
            }
            programYear.syncVersion();
        }
        localDealer.syncVersion();
        return localDealerLayouts;
    }

    /**
     *
     * @param dealer The current local dealer
     * @return A partially filled local dealer layout
     */
    public LocalDealerLayout getLayoutFrom(LocalDealer dealer){
        LocalDealerLayout       localDealerLayout   =   new LocalDealerLayout();
        
        localDealerLayout.setCommercialManager      (dealer.getCommercialManager()!=null?dealer.getCommercialManager().getDescription():null);
        localDealerLayout.setCommercialSupervisor   (dealer.getCommercialSupervisor()!=null?dealer.getCommercialSupervisor().getDescription():null);
        localDealerLayout.setSubRegion              (dealer.getSubRegion()!=null?dealer.getSubRegion().getCode():null);        
        localDealerLayout.setContactName            (dealer.getName());
        localDealerLayout.setCompany                (dealer.getPosName());
        localDealerLayout.setTaxId                  (dealer.getRfc());
        localDealerLayout.setState                  (ServiceLayoutUtils.getStateCode(dealer));
        localDealerLayout.setDistrict               (ServiceLayoutUtils.getDistrictCode(dealer));
        localDealerLayout.setCountry                (dealer.getCountry()!=null?dealer.getCountry().getCode():null);
        localDealerLayout.setAddress                (value(dealer.getAddress1(), " ",dealer.getAddress2()));
        localDealerLayout.setZipCode                (dealer.getPostalCodeArea()!=null?dealer.getPostalCodeArea().getCode():null);
        localDealerLayout.setPhone                  (dealer.getPhone());
        localDealerLayout.setFax                    (dealer.getFax());
        localDealerLayout.setEmail                  (dealer.getEmail());
        localDealerLayout.setBirthday               (dealer.getBirthday());
        localDealerLayout.setAnniversary            (dealer.getBusinessAnniversary());
        localDealerLayout.setAgreementNumber        (dealer.getAgreementNumber());
        return localDealerLayout;
    }
}
