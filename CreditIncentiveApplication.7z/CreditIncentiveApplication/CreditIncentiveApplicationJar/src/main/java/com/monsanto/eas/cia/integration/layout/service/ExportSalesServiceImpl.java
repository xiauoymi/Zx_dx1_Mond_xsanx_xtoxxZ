package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.dao.SalesPerQuarterDao;
import com.monsanto.eas.cia.dao.ProgramQuarterDao;
import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.OutputSalesLayout;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.*;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.System;
import java.util.Collection;
import java.util.Iterator;

import static com.monsanto.eas.cia.util.CriteriaUtils.addSyncVersionRestriction;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/01/2011
 * Time: 06:05:34 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("export-sales-service")
public class ExportSalesServiceImpl extends AbstractLayoutService implements ExportLayoutService<OutputSalesLayout> {
    @Autowired
    ProgramQuarterDao pqdao;

    @Autowired
    SalesPerQuarterDao sqdao;

    public Criteria createCriteria(Session session) {

        DetachedCriteria creditNote =DetachedCriteria.forClass(CreditNote.class,"creditNote");
        creditNote.setProjection(Property.forName("creditNote.id"));
        creditNote.add(Restrictions.neProperty("creditNote.currentVersion","creditNote.syncVersion"));

        DetachedCriteria creditNoteCriteria=DetachedCriteria.forClass(LdSalesCn.class,"ldSalesCn");
        creditNoteCriteria.setProjection(Property.forName("ldSalesCn.id"));
        creditNoteCriteria.add(Restrictions.eqProperty("ldSalesCn.creditNote.id","creditNote.id"));
        creditNoteCriteria.add(Restrictions.neProperty("ldSalesCn.currentVersion","ldSalesCn.syncVersion"));
        creditNoteCriteria.add(Subqueries.exists(creditNote));

//        DetachedCriteria creditNoteCriteria=DetachedCriteria.forClass(CreditNote.class,"creditNote");
//        creditNoteCriteria.setProjection(Property.forName("creditNote.id"));
//        creditNoteCriteria.add(Restrictions.eqProperty("creditNote.id","ldSales.creditNote.id"));
//        addSyncVersionRestriction(creditNoteCriteria, "creditNote");

    	Criteria ldSalesCriteria=session.createCriteria(LdSales.class,"ldSales");
    	ldSalesCriteria.add(
    		Restrictions.disjunction().
    			add(Restrictions.neProperty("ldSales.currentVersion","ldSales.syncVersion")).
    			add(Subqueries.exists(creditNoteCriteria))
    	);
                                
        return ldSalesCriteria;
    }
    
    public Collection<OutputSalesLayout> exportLayouts(Object... objects) {

        LdSales             ldSales             =   (LdSales)objects[0];

        ProgramQuarter program = pqdao.lookupProgramQuarterByTransaction(ldSales.getTransactionNumber());
        LdSalesPerQuarter sales = sqdao.lookupSalesByQuarterAndLeader(String.valueOf(program.getId()),String.valueOf(ldSales.getLdDist().getLocalDealer().getId()));

        OutputSalesLayout   salesLayout         =   new OutputSalesLayout();
        salesLayout.setTransactionNumber        (ldSales.getTransactionNumber());
        salesLayout.setVolumeToIncentive        (ldSales.getVolumeToIncentive());
        salesLayout.setVolumeAssigned           (ldSales.getVolumeAssigned());
        salesLayout.setValidForIncentivePlanning(ldSales.isValidForIncentivePlanning());
        //salesLayout.setIncentiveAmount          (ldSales.getIncentiveAmount());

        //double incentiveAmount =   ldSales.getPrice() * ldSales.getVolumeToIncentive() * sales.getIncentivePct();
        double incentiveAmount =   ldSales.getPrice() * ldSales.getVolumeToIncentive() * sales.getInventivePct();
        salesLayout.setIncentiveAmount(incentiveAmount);

//        CreditNote          creditNote          =   ldSales.getCreditNote();
//        if(creditNote!=null){
//            salesLayout.setCreditNoteCode       (creditNote.getCode());
//            salesLayout.setCreditNoteDate       (creditNote.getDate());
//            TaxReserve taxReserve               =   creditNote.getTaxReserve();
//            if(taxReserve!=null){
//                salesLayout.setTaxReserveCode   (taxReserve.getCode());
//            }
//            creditNote.syncVersion();
//        }
//        salesLayout.setSent2Sap                 (creditNote!=null);
                
        LocalDealer localDealer                 =  ldSales.getAssignedFrom();
        if(localDealer!=null){
            salesLayout.setAssignedFrom         (localDealer.getAgreementNumber());    
        }

        LdSalesCn ldSalesCnList[] = new LdSalesCn[5];
        ldSales.getSalesCns().toArray(ldSalesCnList);

        if(ldSalesCnList[0] != null) {
            salesLayout.setCreditNoteCode(ldSalesCnList[0].getCreditNote().getCode());
            salesLayout.setIncentiveAmount(ldSalesCnList[0].getIncentiveAmount());
            salesLayout.setCreditNoteDate(ldSalesCnList[0].getCreditNote().getDate());
            salesLayout.setSent2Sap(true);
            TaxReserve taxReserve =   ldSalesCnList[0].getCreditNote().getTaxReserve();
            if(taxReserve!=null){
                salesLayout.setTaxReserveCode(taxReserve.getCode());
            }
            ldSalesCnList[0].getCreditNote().syncVersion();
        }
        if(ldSalesCnList[1] != null) {
            salesLayout.setCreditNote2(ldSalesCnList[1].getCreditNote().getCode());
            salesLayout.setCreditNoteDate2(ldSalesCnList[1].getCreditNote().getDate());
            salesLayout.setSent2Sap2(true);
            TaxReserve taxReserve =   ldSalesCnList[1].getCreditNote().getTaxReserve();
            if(taxReserve!=null){
                salesLayout.setTaxReserveCode2(taxReserve.getCode());
            }
            ldSalesCnList[1].getCreditNote().syncVersion();
        }
        if(ldSalesCnList[2] != null) {
            salesLayout.setCreditNote3(ldSalesCnList[2].getCreditNote().getCode());
            salesLayout.setCreditNoteDate3(ldSalesCnList[2].getCreditNote().getDate());
            salesLayout.setSent2Sap3(true);
            TaxReserve taxReserve =   ldSalesCnList[2].getCreditNote().getTaxReserve();
            if(taxReserve!=null){
                salesLayout.setTaxReserveCode3(taxReserve.getCode());
            }
            ldSalesCnList[2].getCreditNote().syncVersion();
        }
        if(ldSalesCnList[3] != null) {
            salesLayout.setCreditNote4(ldSalesCnList[3].getCreditNote().getCode());
            salesLayout.setCreditNoteDate4(ldSalesCnList[3].getCreditNote().getDate());
            salesLayout.setSent2Sap4(true);
            TaxReserve taxReserve =   ldSalesCnList[3].getCreditNote().getTaxReserve();
            if(taxReserve!=null){
                salesLayout.setTaxReserveCode4(taxReserve.getCode());
            }
            ldSalesCnList[3].getCreditNote().syncVersion();
        }
        if(ldSalesCnList[4] != null) {
            salesLayout.setCreditNote5(ldSalesCnList[4].getCreditNote().getCode());
            salesLayout.setCreditNoteDate5(ldSalesCnList[4].getCreditNote().getDate());
            salesLayout.setSent2Sap5(true);
            TaxReserve taxReserve =   ldSalesCnList[4].getCreditNote().getTaxReserve();
            if(taxReserve!=null){
                salesLayout.setTaxReserveCode5(taxReserve.getCode());
            }
            ldSalesCnList[4].getCreditNote().syncVersion();
        }

        ldSales.syncVersion();
        return ObjectUtils.asCollection(salesLayout);
    }
}
