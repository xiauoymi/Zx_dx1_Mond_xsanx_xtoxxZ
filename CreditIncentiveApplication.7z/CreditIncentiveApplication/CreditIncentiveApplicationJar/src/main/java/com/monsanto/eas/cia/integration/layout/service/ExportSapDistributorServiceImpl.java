package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.CodeDescriptionLayout;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.SapDistributor;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("export-sap-distributors-service")
public class ExportSapDistributorServiceImpl extends AbstractLayoutService
		implements ExportLayoutService<CodeDescriptionLayout> {

	public Criteria createCriteria(Session session) {		
		return session.createCriteria(SapDistributor.class).addOrder(Order.desc("description"));
	}

	public Collection<CodeDescriptionLayout> exportLayouts(Object... objects) {
		SapDistributor sapDistributor=(SapDistributor)objects[0];
		CodeDescriptionLayout layout=new CodeDescriptionLayout();
		layout.setCode(sapDistributor.getCode());
		layout.setDescription(sapDistributor.getDescription());
		return ObjectUtils.asCollection(layout);
	}
}
