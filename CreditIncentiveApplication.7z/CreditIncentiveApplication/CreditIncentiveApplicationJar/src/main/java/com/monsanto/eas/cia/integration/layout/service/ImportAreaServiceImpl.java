package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.AreaLayout;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.area.*;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.apache.commons.lang.ClassUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 03:18:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-area-service")
public class ImportAreaServiceImpl extends AbstractLayoutService implements ImportLayoutService<AreaLayout> {

    protected Map<String,Class<? extends Area>> areaClasses;

    public ImportAreaServiceImpl() {
        areaClasses=new HashMap<String,Class<? extends Area>>();
        areaClasses.put("world",        WorldArea.class);
        areaClasses.put("country",      CountryArea.class);
        areaClasses.put("region",       Region.class);
        areaClasses.put("subregion",    SubRegion.class);
        areaClasses.put("state",        State.class);
        areaClasses.put("district",     District.class);
        areaClasses.put("postal_code",  PostalCode.class);
    }

	@Transactional
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void importLayout(AreaLayout layout) {
        String discriminator=layout.getDiscriminator();
        if(discriminator==null)
        	LayoutServiceExceptionCode.UNKNOWN_AREA_DISCRIMINATOR.fail(discriminator);
        Class<? extends Area> _areaClass=getAreaClass(discriminator);
        if(_areaClass==null)
        	LayoutServiceExceptionCode.UNKNOWN_AREA_DISCRIMINATOR.fail(discriminator);

        String areaCode=layout.getCode();        
        Area area=finderService.findAreaFrom(_areaClass, areaCode);

        Class<? extends Area> _parentAreaClass=null;
        if(ClassUtils.isAssignable(_areaClass,TerritoryArea.class))
            _parentAreaClass = CountryArea.class;                    
        else
            _parentAreaClass=(Class<? extends Area>)ObjectUtils.getGenericType(_areaClass, Area.class);

        Area parentArea=finderService.findAreaFrom(_parentAreaClass,layout.getParentCode());
                
        if(area==null){            
            area=newAreaInstance(discriminator);
            area.setCode(areaCode);                        
        }
        
        String description=layout.getDescription();
        
        if(!("postal_code".equals(discriminator))){
        	area.setDescription(description);
        }
        
        String shortcut=layout.getShortcut();
        area.setShortcut(shortcut!=null?shortcut:areaCode);
        area.setActive(true);                  
        
        if(parentArea!=null){
        	parentArea.addChildArea(area);
        }
        dao.persist(area);        
    }

    public Area newAreaInstance(String discriminator){
        Class<? extends Area> areaClass=areaClasses.get(discriminator.toLowerCase());
        if(areaClass==null)return null;
        return ObjectUtils.newInstance(areaClass);
    }

    public Class<? extends Area> getAreaClass(String discriminator){
    	return areaClasses.get(discriminator);
    }
    
    public void setAreaClasses(Map<String, Class<? extends Area>> areaClasses) {
        this.areaClasses = areaClasses;
    }
}
