package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.model.CommercialSupervisor;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 05:17:10 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-commercial-supervisor-service")
public class ImportCommercialSupervisorServiceImpl extends AbstractImportDescriptionCatalogEntityService{
    @Override
    public Class<CommercialSupervisor> getDescriptionCatalogEntityClass() {
        return CommercialSupervisor.class;
    }
}
