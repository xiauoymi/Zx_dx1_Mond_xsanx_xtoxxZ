package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.CountryProgramYrPctLayout;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.hibernate.Criteria;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.TreeMap;

import static org.hibernate.criterion.Restrictions.eq;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/02/2011
 * Time: 12:17:48 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-country-program-yr-pct-service")
public class ImportCountryProgramYrPctServiceImpl extends AbstractLayoutService  implements ImportLayoutService<CountryProgramYrPctLayout> {
	@Transactional
	public void importLayout(final CountryProgramYrPctLayout layout) {
        Year year=dao.findByCriteria(new DefaultCriteriaCreator<Year>(){
            public void modifyCriteria(Criteria criteria) {
                criteria.add(eq("year",layout.getYear()));
            }
        });
        if(year==null){
            year=new Year();
            year.setYear(layout.getYear());
            dao.persist(year);
        }

        Country country=dao.findByCode(Country.class,layout.getCountryCode());
        if(country==null){
            country=new Country();
            country.setCode(layout.getCountryCode());            
        }
        country.setDescription(layout.getCountryName());
        dao.persist(country);
        final String countryCode=country.getCode();
        final Integer yearValue=year.getYear();
        CountryProgramYrPct countryProgramYear= dao.findByCriteria(new DefaultCriteriaCreator<CountryProgramYrPct>(){
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("country").add(eq("code",countryCode));
                criteria.createCriteria("year").add(eq("year",yearValue));
            }
        });
        boolean newCountryProgramYear=false;

        if(countryProgramYear==null){
            countryProgramYear=new CountryProgramYrPct();
            countryProgramYear.setCountry(country);
            countryProgramYear.setYear(year);            
            newCountryProgramYear=true;
        }
        
        countryProgramYear.setMaxPct(layout.getMaxPct());
        countryProgramYear.setMaxYrPct(layout.getMaxYrPct());
        countryProgramYear.setMinPct(layout.getMinPct());
        countryProgramYear.setMinYrPct(layout.getMinYrPct());
        countryProgramYear.setOpen(layout.getOpen());
        dao.persist(countryProgramYear);

        TreeMap<Integer, Date[]> programQuarters=getProgramQuarterDates(layout);
        for(final Integer quarterNum:programQuarters.keySet()){
            boolean newQuarterType=false;
            QuarterType quarterType=dao.findByCriteria(new DefaultCriteriaCreator<QuarterType>(){
                public void modifyCriteria(Criteria criteria) {
                    criteria.add(eq("quarterNum",quarterNum));
                }
            });
            if(quarterType==null){
                quarterType=new QuarterType();
                quarterType.setQuarterNum(quarterNum);
                quarterType.setDescription(quarterNum.toString());
                dao.persist(quarterType);
                newQuarterType=true;
            }

            ProgramQuarter programQuarter = null;
            if(newCountryProgramYear||newQuarterType){
                programQuarter=new ProgramQuarter();
                programQuarter.setQuarterType(quarterType);
                programQuarter.setCountryProgram(countryProgramYear);
            }
            else{
                programQuarter = dao.findByCriteria(new DefaultCriteriaCreator<ProgramQuarter>(){
                    public void modifyCriteria(Criteria criteria) {
                        criteria.createCriteria("quarterType").add(eq("quarterNum",quarterNum));
                        Criteria countryProgramYrPctCriteria    =criteria.createCriteria("countryProgram");
                        countryProgramYrPctCriteria.createCriteria("country").add(eq("code",countryCode));
                        countryProgramYrPctCriteria.createCriteria("year").add(eq("year",yearValue));
                    }
                });
            }
            Date[] dates=programQuarters.get(quarterNum);
            programQuarter.setQuarterStart  (dates[0]);
            programQuarter.setQuarterEnd    (dates[1]);            
            countryProgramYear.addProgramQuarter(programQuarter);
            dao.persist(programQuarter);
        }
        
    }

    public TreeMap<Integer, Date[]> getProgramQuarterDates(CountryProgramYrPctLayout layout){
        TreeMap<Integer, Date[]> programQuarterDates=new TreeMap<Integer,Date[]>();

        if(layout.getQuarter1Start()!=null&&layout.getQuarter1End()!=null){
            programQuarterDates.put(1,new Date[]{layout.getQuarter1Start(),layout.getQuarter1End()});    
        }
        if(layout.getQuarter2Start()!=null&&layout.getQuarter2End()!=null){
            programQuarterDates.put(2,new Date[]{layout.getQuarter2Start(),layout.getQuarter2End()});
        }
        if(layout.getQuarter3Start()!=null&&layout.getQuarter3End()!=null){
            programQuarterDates.put(3,new Date[]{layout.getQuarter3Start(),layout.getQuarter3End()});
        }
        if(layout.getQuarter4Start()!=null&&layout.getQuarter4End()!=null){
            programQuarterDates.put(4,new Date[]{layout.getQuarter4Start(),layout.getQuarter3End()});    
        }
        return programQuarterDates;
    }
}
