package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.InputDistributorLayout;
import com.monsanto.eas.cia.model.SapDistributor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 18/01/2011
 * Time: 04:03:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("import-distributor-service")
public class ImportDistributorServiceImpl extends AbstractLayoutService implements ImportLayoutService<InputDistributorLayout> {

	@Transactional
    public void importLayout(InputDistributorLayout layout) {
        SapDistributor sapDistributor = finderService.findSapDistributorFrom(layout.getSapId());
        if (null == sapDistributor) {
            sapDistributor = new SapDistributor();
            sapDistributor.setCode(layout.getSapId());
        }
        sapDistributor.setDescription(layout.getDescription());
        sapDistributor.setDivision(layout.getDivision());
        sapDistributor.setDistributionChannel(layout.getDistributionChannel());
        sapDistributor.setSalesOrganization(layout.getSalesOrganization());
        dao.persist(sapDistributor);
    }
}
