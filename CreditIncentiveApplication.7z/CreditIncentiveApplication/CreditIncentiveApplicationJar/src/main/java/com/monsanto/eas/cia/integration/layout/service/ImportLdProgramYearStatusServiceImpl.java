package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.model.LdProgramYearStatus;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 05:18:45 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-ld-program-year-status-service")
public class ImportLdProgramYearStatusServiceImpl extends AbstractImportCodeCatalogEntityService{
    @Override
    public Class<LdProgramYearStatus> getCodeCatalogEntityClass() {
        return LdProgramYearStatus.class;
    }
}
