package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.InputLocalDealerSalesGoalsLayout;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.*;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.hibernate.Criteria;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.lang.System;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.hibernate.criterion.Restrictions.eq;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 08:42:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-local-dealer-sales-goals-service")
public class ImportLocalDealerSalesGoalsServiceImpl extends AbstractImportSalesGoalsService implements ImportLayoutService<InputLocalDealerSalesGoalsLayout> {

    private void updateLocalDealer(InputLocalDealerSalesGoalsLayout layout, LocalDealer localDealer) {
        localDealer.setAddress1(layout.getAddress1());
        localDealer.setAddress2(layout.getAddress2());
        if (StringUtils.hasText(layout.getAgreementNumber())) {
            localDealer.setAgreementNumber(layout.getAgreementNumber());
        }

        if (null != layout.getBirthday()) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            try {
                localDealer.setBirthday(sdf.parse(layout.getBirthday()));
            } catch (ParseException e) {}
        }

        if (null != layout.getBusinessAnniversary()) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            try {
                localDealer.setBusinessAnniversary(sdf.parse(layout.getBusinessAnniversary()));
            } catch (ParseException e) {}
        }

        CommercialSupervisor supervisor = dao.findByDescription(CommercialSupervisor.class, layout.getCommercialSupervisor());
        CommercialSupervisor manager = dao.findByDescription(CommercialSupervisor.class, layout.getCommercialManager());
        localDealer.setCommercialManager(manager);
        localDealer.setCommercialSupervisor(supervisor);
        Country country = dao.findByCode(Country.class, "MX");
        localDealer.setCountry(country);
        if (StringUtils.hasText(layout.getSubRegion())) {
            SubRegion subRegion = dao.findByDescription(SubRegion.class, layout.getSubRegion());
            localDealer.setSubRegion(subRegion);
        }
        localDealer.setEmail(layout.getEmail());
        localDealer.setFax(layout.getFax());
        if (StringUtils.hasText(layout.getFiscalName())) {
            localDealer.setFiscalName(layout.getFiscalName());
        }
        localDealer.setName(layout.getName());
        localDealer.setPhone(layout.getPhone());

        if (StringUtils.hasText(layout.getPosName())) {
            localDealer.setPosName(layout.getPosName());
        }

        if (StringUtils.hasText(layout.getPostalCode())) {
            PostalCode postalCode = dao.findByCode(PostalCode.class, layout.getPostalCode());
            if (postalCode != null) {
                localDealer.setPostalCodeArea(postalCode);
                Integer idDistrict = ((Area)postalCode.getParentArea()).getId();
                District district = new District();
                district.setId(idDistrict);
                localDealer.setDistrict(district);
            }
        }
        localDealer.setRfc(layout.getRfc());
        dao.persist(localDealer);
    }

    @Transactional(timeout = 600)
    public void importLayout(final InputLocalDealerSalesGoalsLayout layout) {
        if (layout != null && (layout.getAgreementNumber() != null && layout.getAgreementNumber().trim().length() > 0)) {
            LocalDealer localDealer = finderService.findLocalDealerFrom(layout.getAgreementNumber());
            if (localDealer == null) {
                //LayoutServiceExceptionCode.LOCAL_DEALER_WITH_AGREEMENT_NUMBER_NOT_FOUND.fail(layout.getAgreementNumber());
                localDealer = new LocalDealer();
                updateLocalDealer(layout, localDealer);
            } else {

                if (
                        StringUtils.hasText(layout.getAddress1()) ||
                                StringUtils.hasText(layout.getAddress2()) ||
                                StringUtils.hasText(layout.getBirthday()) ||
                                StringUtils.hasText(layout.getBusinessAnniversary()) ||
                                StringUtils.hasText(layout.getCommercialSupervisor()) ||
                                StringUtils.hasText(layout.getCommercialManager()) ||
                                StringUtils.hasText(layout.getSubRegion()) ||
                                StringUtils.hasText(layout.getPostalCode()) ||
                                StringUtils.hasText(layout.getEmail()) ||
                                StringUtils.hasText(layout.getFax()) ||
                                StringUtils.hasText(layout.getFiscalName()) ||
                                StringUtils.hasText(layout.getName()) ||
                                StringUtils.hasText(layout.getPhone()) ||
                                StringUtils.hasText(layout.getRfc())
                        ) {
                    updateLocalDealer(layout, localDealer);
                }

            }

            String countryCode = localDealer.getCountry().getCode();
            CountryProgramYrPct countryProgramYear = finderService.findCurrentCountryProgramYearFrom(countryCode, layout.getYear());
            if (countryProgramYear == null) {
                LayoutServiceExceptionCode.MISSING_COUNTRY_PROGRAM_YEAR.fail(countryCode, new Date());
            }
            LdProgramYear ldProgramYear = finderService.findLdProgramYearFrom(countryProgramYear, localDealer);
            if (ldProgramYear == null) {
                //LayoutServiceExceptionCode.MISSING_LOCAL_DEALER_SIGNATURE_FOR_YEAR.fail(localDealer.getAgreementNumber(), countryProgramYear.getYear().getYear());
                ldProgramYear = new LdProgramYear();
                ldProgramYear.setYear(
                        dao.findByCriteria(new DefaultCriteriaCreator<Year>() {
                            public void modifyCriteria(Criteria criteria) {
                                criteria.add(eq("year", layout.getYear()));
                            }
                        })
                );
                localDealer.addProgramYear(ldProgramYear);
            }

            ldProgramYear.setLdProgramYearStatus(dao.findByCode(LdProgramYearStatus.class, "active"));
            ldProgramYear.setMinTarget(layout.getMinTarget());
            ldProgramYear.setMaxTarget(layout.getMaxTarget());

            Double[][] incentives = new Double[][]{
                    {layout.getMinQ1(), layout.getMaxQ1(), layout.getMinPctQ1().doubleValue(), layout.getMaxPctQ1()},
                    {layout.getMinQ2(), layout.getMaxQ2(), layout.getMinPctQ2().doubleValue(), layout.getMaxPctQ2()},
                    {layout.getMinQ3(), layout.getMaxQ3(), layout.getMinPctQ3().doubleValue(), layout.getMaxPctQ3()},
                    {layout.getMinQ4(), layout.getMaxQ4(), layout.getMinPctQ4().doubleValue(), layout.getMaxPctQ4()}
            };

            importQuarterSalesGoals(incentives, localDealer, layout.getYear());

            Set<Integer> sapDistributorIds = new HashSet<Integer>();
            sapDistributorIds.add(layout.getDistId1());
            sapDistributorIds.add(layout.getDistId2());
            sapDistributorIds.add(layout.getDistId3());
            sapDistributorIds.add(layout.getDistId4());

            for (Integer sapDistributorId : sapDistributorIds) {
                if (sapDistributorId != null && sapDistributorId > 0) {
                    SapDistributor distributor = finderService.findSapDistributorFrom(sapDistributorId.toString());
                    if (distributor == null)
                        LayoutServiceExceptionCode.SAP_DISTRIBUTOR_NOT_FOUND.fail(sapDistributorId);
                    LdDist ldDist = finderService.findOrCreateLdDistFrom(localDealer, distributor, ldProgramYear);
                    dao.persist(ldDist);
                }
            }
        }
    }
}
