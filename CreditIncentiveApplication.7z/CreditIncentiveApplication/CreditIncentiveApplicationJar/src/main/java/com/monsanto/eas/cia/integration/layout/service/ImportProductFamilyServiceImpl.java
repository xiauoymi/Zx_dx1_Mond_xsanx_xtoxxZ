package com.monsanto.eas.cia.integration.layout.service;

import org.springframework.stereotype.Component;

import com.monsanto.eas.cia.model.ProductFamily;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 04:38:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-product-family-service")
public class ImportProductFamilyServiceImpl extends AbstractImportDescriptionCatalogEntityService{
    @Override
    public Class<ProductFamily> getDescriptionCatalogEntityClass() {
        return ProductFamily.class;
    }
}
