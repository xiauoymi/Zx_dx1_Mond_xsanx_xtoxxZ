package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.dao.SapDistributorDao;
import com.monsanto.eas.cia.dao.SapProductPriceDao;
import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.InputSalesUploadLayout;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

import static com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode.*;

/**
 * Created by IntelliJ IDEA.
 * User: JNOLA1
 * Date: 25/01/2013
 * Time: 04:47:29 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("import-sales-upload-service")
public class ImportSalesUploadServiceImpl extends AbstractLayoutService implements ImportLayoutService<InputSalesUploadLayout> {

    @Autowired
    private SapDistributorDao sapDistributorDao;

    @Autowired
    private SapProductPriceDao sapProductPriceDao;

    @Transactional(timeout = 600)
    public void importLayout(InputSalesUploadLayout layout) {

        String sapCode = layout.getSapCode().toString();

        SapDistributor distributor = sapDistributorDao.lookupSapDistributorByCode(sapCode);

        if (distributor == null) {
            DISTRIBUTOR_WITH_CARD_NOT_FOUND.fail(sapCode);
        }

        String sapId = layout.getBarCode().toString();
        SapProduct sapProduct = finderService.findSapProductFrom(sapId);

        if (sapProduct == null) {
            SAP_PRODUCT_NOT_FOUND.fail(sapId);
        }


        String agreement = layout.getAgreement();
        LocalDealer localDealer = finderService.findLocalDealerFrom(agreement);

        if (localDealer == null) {
            LOCAL_DEALER_WITH_AGREEMENT_NUMBER_NOT_FOUND.fail(agreement);
        }

        final TransactionType transactionType = finderService.findTransactionTypeFrom(layout.getTransactionType().toString());

        if (transactionType == null) {
            TRANSACTION_TYPE_NOT_FOUND.fail(layout.getTransactionType());
        }

        Double volumeAssigned = layout.getVolumeAssigned();

        if (volumeAssigned == null) {
            LOCAL_DEALER_LENDING_SALES_VOLUME_NOT_FOUND.fail();
        }
        volumeAssigned = Math.abs(volumeAssigned) * transactionType.getSign().intValue();

        String transactionNumber = layout.getTransactionNumber();

        final Date transactionDate = DateUtil.getDate(layout.getTransactionDate(), DateUtil.PATTERN_dd_MM_yyyy_DOT_SEPARATOR);

        if (transactionDate == null) {
            LayoutServiceExceptionCode.DATE_SALES_UPLOAD_NOT_FOUND.fail(transactionNumber, sapId, agreement);
        }

        LdSales ldSales = finderService.findLdSalesFrom(transactionNumber);

        if (ldSales == null) {
            ldSales = new LdSales();
            ldSales.setTransactionNumber(transactionNumber);
        }

        ProductLine productLine = dao.findByProperty(ProductLine.class, "sapProduct", sapProduct);
        if (null == productLine) {
            productLine = new ProductLine();
            productLine.setSapProduct(sapProduct);
            //productLine.setLtConversionFactor(layout.getFactorLts());
            //productLine.setRegsConversionFactor(layout.getFactorReg());
            productLine.setProductFamily(null);
            productLine.setUom(null);
            dao.persist(productLine);
        }

        ldSales.setTransactionType(transactionType);
        ldSales.setProductLine(productLine);
        ldSales.setAssignedFrom(localDealer);
        ldSales.setSalesVolume(volumeAssigned);
        ldSales.setVolumeToIncentive(volumeAssigned); //initially, volume to incentive and sales volume will have the same value.
        ldSales.setValidForIncentivePlanning(Boolean.TRUE);    //all transactions will be marked as valid for incentive planning by default.
        ldSales.setPrice(getPrice(sapProduct, transactionDate));

        String countryCode = localDealer.getCountry().getCode();

        CountryProgramYrPct countryProgramYear = finderService.findCountryProgramYearContainingDate(countryCode, transactionDate);
        if (countryProgramYear == null) {
            LayoutServiceExceptionCode.MISSING_COUNTRY_PROGRAM_YEAR.fail(countryCode, transactionDate);
        }

        LdProgramYear ldProgramYear = finderService.findLdProgramYearFrom(countryProgramYear, localDealer);
        if (ldProgramYear == null) {
            LayoutServiceExceptionCode.MISSING_LOCAL_DEALER_SIGNATURE_FOR_YEAR.fail(agreement, countryProgramYear.getYear().getYear());
        }

        // validate if the local dealer - distributor relation already exist
        LdDist ldDist = finderService.findLdDistFrom(localDealer, distributor, ldProgramYear);
        if (ldDist == null) {
            LayoutServiceExceptionCode.DISTRIBUTOR_NOT_FOUND_FOR_LOCAL_DEALER.fail(agreement);
        }

        ldSales.setSalesDate(transactionDate);
        ldDist.addLdSales(ldSales);
        dao.persist(ldDist);
    }

    /**
     * Gets the price of a product based on the transaction date
     *
     * @param sapProduct      Product
     * @param transactionDate Transaction date
     * @return price
     */
    private Double getPrice(final SapProduct sapProduct, final Date transactionDate) {
        final SapProductPrice sapProductPrice = sapProductPriceDao.lookupProductPriceByTransDate(sapProduct.getId(), transactionDate);
        if (null == sapProductPrice || null == sapProductPrice.getPrice()) {
            LayoutServiceExceptionCode.SAP_PRODUCT_PRICE_NOT_FOUND.fail(sapProduct.getCode(), transactionDate);
        }
        return Math.abs(sapProductPrice.getPrice());
    }
}