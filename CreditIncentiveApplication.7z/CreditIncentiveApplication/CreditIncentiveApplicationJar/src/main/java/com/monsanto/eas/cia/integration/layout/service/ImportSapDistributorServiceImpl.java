package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.model.SapDistributor;
import org.springframework.stereotype.Service;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 18/01/2011
 * Time: 04:07:00 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("import-sap-distributor-service")
public class ImportSapDistributorServiceImpl extends AbstractImportCodeCatalogEntityService{
    @Override
    public Class<SapDistributor> getCodeCatalogEntityClass() {
        return SapDistributor.class;
    }
}
