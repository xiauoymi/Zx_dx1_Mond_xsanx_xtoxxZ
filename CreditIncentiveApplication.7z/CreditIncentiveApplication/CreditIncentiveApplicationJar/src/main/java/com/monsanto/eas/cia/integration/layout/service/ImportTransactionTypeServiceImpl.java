package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.model.TransactionType;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 05:23:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-transaction-type-service")
public class ImportTransactionTypeServiceImpl extends AbstractImportDescriptionCatalogEntityService{
    @Override
    public Class<TransactionType> getDescriptionCatalogEntityClass() {
        return TransactionType.class;
    }
}
