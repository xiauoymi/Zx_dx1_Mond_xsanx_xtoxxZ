package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.model.Uom;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/02/2011
 * Time: 04:43:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-uom-service")
public class ImportUomServiceImpl extends AbstractImportCodeCatalogEntityService{
    @Override
    public Class<Uom> getCodeCatalogEntityClass() {
        return Uom.class;
    }
}
