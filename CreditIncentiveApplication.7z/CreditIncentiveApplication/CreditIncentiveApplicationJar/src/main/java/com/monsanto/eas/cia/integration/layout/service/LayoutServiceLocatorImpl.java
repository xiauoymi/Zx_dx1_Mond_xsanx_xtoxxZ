package com.monsanto.eas.cia.integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 5/02/2011
 * Time: 09:19:24 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class LayoutServiceLocatorImpl implements LayoutServiceLocator,ApplicationContextAware {

    protected ApplicationContext applicationContext;

    public void setApplicationContext(ApplicationContext applicationContext){
        this.applicationContext=applicationContext;
    }

    public <T> T lookup(String serviceId,Class<T> _class){
        try{
            T service=(T)applicationContext.getBean(serviceId,_class);
            if(service==null)
                throw new NullPointerException();
            return service;
        }
        catch(Exception e){
            throw new LayoutServiceLocatorException(e,serviceId,_class);
        }
    }

    public ExportLayoutService lookupExportLayoutService(String serviceId) {
        return lookup(serviceId,ExportLayoutService.class);
    }

    public ImportLayoutService lookupImportLayoutService(String serviceId) {
        return lookup(serviceId,ImportLayoutService.class);
    }
}
