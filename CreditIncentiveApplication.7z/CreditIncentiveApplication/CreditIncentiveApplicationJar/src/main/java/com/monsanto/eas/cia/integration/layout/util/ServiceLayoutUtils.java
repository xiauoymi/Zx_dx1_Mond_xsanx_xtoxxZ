package com.monsanto.eas.cia.integration.layout.util;

import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.State;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 06:17:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServiceLayoutUtils {

    public static String getStateDescription(LocalDealer dealer){
        District district    =   dealer.getDistrict();
        if(district!=null){
            if (district.getParentArea() != null) {
                if(district.getParentArea() instanceof State){
                    State state       =   district.getParentArea();
                    if(state!=null)
                        return state.getDescription();
                }
            }
        }
        return null;
    }

    /**
     * @param dealer The dealer we are currently processing
     * @return The bw id of the dealer's state
     */
    public static String getStateCode(LocalDealer dealer){
        District district    =   dealer.getDistrict();
        if(district!=null){
            if(district.getParentArea() != null) {
               if(district.getParentArea() instanceof State) {
                   State state       =   district.getParentArea();
                    if(state!=null)
                        return state.getCode();
               }
            }

        }
        return null;
    }

    /**
     * @param dealer The dealer we are currently processing
     * @return The bw id of the dealer's district
     */
    public static String getDistrictCode(LocalDealer dealer){
        PostalCode postalCode  =   dealer.getPostalCodeArea();
        if(postalCode!=null){
            if(postalCode.getParentArea() != null) {
                if(postalCode.getParentArea() instanceof District) {
                    District            district    =   postalCode.getParentArea();
                    if(district != null)
                        return district.getCode();
                }
            }            
        }
        return null;
    }

    public static String[] getLocalDealerDistIds(LocalDealer localDealer, LdProgramYear forThisProgramYear){
        return getLocalDealerDistIds(localDealer,forThisProgramYear,false);
    }



    public static String[] getLocalDealerDistIds(LocalDealer localDealer, LdProgramYear forThisProgramYear,boolean syncVersions){
        List<String> result=getLocalDealerDynamicDistIds(localDealer,forThisProgramYear,syncVersions);
        String[] tmpArray=Arrays.copyOf(result.toArray(),4,String[].class);
        return tmpArray;
    }

    /**
     * Gets the distributors associated with local dealer.
     * @param localDealer The dealer we are currently processing
     * @return An array of 4 elements containing the local dealers id's
     */
    public static List<String> getLocalDealerDynamicDistIds(LocalDealer localDealer, LdProgramYear forThisProgramYear,boolean syncVersions){
        SapDistributor distributor         =   null;
//        SapDistributor sapDistributor   =   null;
        List<String> result=new ArrayList<String>();

        for(LdDist ldDist:localDealer.getLdDist()) {
            if(ldDist.isActive()){
                distributor             =   ldDist.getDistributor();
//                if(distributor          !=  null){
//                    sapDistributor      =   distributor.getSapDistributor();
//                    if(sapDistributor   !=  null){
                    if(distributor   !=  null){
                        LdProgramYear ldProgramYear=ldDist.getLdProgramYear();
                        if(ldProgramYear!=null&&ldProgramYear.equals(forThisProgramYear)){
                            if(syncVersions){
                                if(ldProgramYear.needsSynchronization()||ldDist.needsSynchronization()){
//                                    result.add(sapDistributor.getCode());
                                    result.add(distributor.getCode());
                                    ldDist.syncVersion();
                                }
                            }
                            else{
//                                result.add(sapDistributor.getCode());
                                result.add(distributor.getCode());
                            }
                        }
                    }
//                }
            }
        }
        return result;
    }
}
