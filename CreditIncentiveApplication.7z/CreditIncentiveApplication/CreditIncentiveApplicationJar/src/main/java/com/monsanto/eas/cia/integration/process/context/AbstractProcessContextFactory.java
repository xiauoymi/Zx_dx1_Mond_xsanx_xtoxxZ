package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.process.contract.EventQueueFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:05:03 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractProcessContextFactory {
    @Autowired
    protected EventQueueFactory eventQueueFactory;

    public EventQueueFactory getEventQueueFactory() {
        return eventQueueFactory;
    }

    public void setEventQueueFactory(EventQueueFactory eventQueueFactory) {
        this.eventQueueFactory = eventQueueFactory;
    }

    public Object[] remaining(int from,Object ... parameters){
        return Arrays.copyOfRange(parameters,from,parameters.length);
    }
}
