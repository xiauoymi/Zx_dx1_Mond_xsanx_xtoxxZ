package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.io.Writer;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 01:02:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvExportProcessContext extends ExportProcessContext {
    protected Writer                writer              =   null;
    protected CsvWriter             csvWriter           =   null;

    public CsvExportProcessContext() {
        setRecordNumber(-1);
    }

    public CsvExportProcessContext(ProcessQueue eventQueue) {
        super(eventQueue);
    }

    public CsvExportProcessContext(String serviceId, ProcessQueue eventQueue) {
        super(serviceId, eventQueue);
    }

    public synchronized Writer getWriter() {
        return writer;
    }

    public synchronized void setWriter(Writer writer) {
        this.writer = writer;
    }

    public synchronized CsvWriter getCsvWriter() {
        return csvWriter;
    }

    public synchronized void setCsvWriter(CsvWriter csvWriter) {
        this.csvWriter = csvWriter;
    }

    @Override
    public synchronized CsvExportProcessContext clone() {
        CsvExportProcessContext newContext=new CsvExportProcessContext();
        ObjectUtils.copySourceInto(this,newContext);
        return newContext;
    }
}
