package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.process.contract.ProcessContextFactory;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 11:32:08 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("csv-export-process-context-factory")
public class CsvExportProcessContextFactoryImpl extends AbstractProcessContextFactory implements ProcessContextFactory<CsvExportProcessContext> {
    public CsvExportProcessContext createProcessContext(Object ... parameters)  throws IOException {
        Writer writer=(Writer)parameters[0];
        String serviceId=(String)parameters[1];
        ProcessQueue eventQueue= eventQueueFactory.createEventQueue(remaining(2,parameters));
        CsvExportProcessContext defaultCsvExportProcessContext=new CsvExportProcessContext(serviceId,eventQueue);
        defaultCsvExportProcessContext.setWriter(writer);
        return defaultCsvExportProcessContext;
    }
}
