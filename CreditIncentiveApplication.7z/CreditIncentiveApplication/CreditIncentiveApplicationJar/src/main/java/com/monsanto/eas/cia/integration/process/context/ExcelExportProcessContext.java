package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.format.excel.ExcelDocumentBuilder;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 08:02:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelExportProcessContext extends ExportProcessContext{

    protected OutputStream          outputStream;
    protected ExcelDocumentBuilder  excelDocumentBuilder;

    public ExcelExportProcessContext() {
    }

    public ExcelExportProcessContext(ProcessQueue eventQueue) {
        super(eventQueue);
    }

    public ExcelExportProcessContext(String serviceId, ProcessQueue eventQueue) {
        super(serviceId, eventQueue);
    }

    public ExcelDocumentBuilder getExcelDocumentBuilder() {
        return excelDocumentBuilder;
    }

    public void setExcelDocumentBuilder(ExcelDocumentBuilder excelDocumentBuilder) {
        this.excelDocumentBuilder = excelDocumentBuilder;
    }

    public OutputStream getOutputStream() {
        return outputStream;
    }

    public void setOutputStream(OutputStream outputStream) {
        this.outputStream = outputStream;
    }

    @Override
    public ExcelExportProcessContext clone() {
        ExcelExportProcessContext context=new ExcelExportProcessContext();
        ObjectUtils.copySourceInto(this,context);
        return context;
    }
}
