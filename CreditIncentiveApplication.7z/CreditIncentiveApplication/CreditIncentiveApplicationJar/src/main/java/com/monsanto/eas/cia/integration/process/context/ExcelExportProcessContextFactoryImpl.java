package com.monsanto.eas.cia.integration.process.context;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

import org.springframework.stereotype.Component;

import com.monsanto.eas.cia.integration.process.contract.ProcessContextFactory;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;

@Component("excel-export-process-context-factory")
public class ExcelExportProcessContextFactoryImpl extends
		AbstractProcessContextFactory implements
		ProcessContextFactory<ExcelExportProcessContext> {

	public ExcelExportProcessContext createProcessContext(Object... parameters)
			throws IOException {
        OutputStream outputStream=(OutputStream)parameters[0];
        String serviceId=(String)parameters[1];
        ProcessQueue eventQueue= eventQueueFactory.createEventQueue(remaining(2,parameters));
        ExcelExportProcessContext defaultExcelExportProcessContext=new ExcelExportProcessContext(serviceId,eventQueue);
        defaultExcelExportProcessContext.setOutputStream(outputStream);        
        return defaultExcelExportProcessContext;
	}

}
