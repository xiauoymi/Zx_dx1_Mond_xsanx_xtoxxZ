package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.ScrollableResults;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 19/02/2011
 * Time: 01:54:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportProcessContext extends ProcessContext {
    protected Collection<Layout>    layouts             =   null;
    protected Class<?>              layoutType          =   null;
    protected ScrollableResults     scrollableResults   =   null;
    protected ExportLayoutService   exportLayoutService =   null;
    protected Object[]              entities            =   null;

    public ExportProcessContext() {
    }

    public ExportProcessContext(ProcessQueue eventQueue) {
        super(eventQueue);
    }

    public ExportProcessContext(String serviceId, ProcessQueue eventQueue) {
        super(serviceId, eventQueue);
    }

    public Object[] getEntities() {
        return entities;
    }

    public void setEntities(Object[] entities) {
        this.entities = entities;
    }

    public ExportLayoutService getExportLayoutService() {
        return exportLayoutService;
    }

    public void setExportLayoutService(ExportLayoutService exportLayoutService) {
        this.exportLayoutService = exportLayoutService;
    }

    public Collection<Layout> getLayouts() {
        return layouts;
    }

    public void setLayouts(Collection<Layout> layouts) {
        this.layouts = layouts;
    }

    public ScrollableResults getScrollableResults() {
        return scrollableResults;
    }

    public void setScrollableResults(ScrollableResults scrollableResults) {
        this.scrollableResults = scrollableResults;
    }

    public Class<?> getLayoutType() {
        return layoutType;
    }

    public void setLayoutType(Class<?> layoutType) {
        this.layoutType = layoutType;
    }

    @Override
    public ExportProcessContext clone() {
        ExportProcessContext context=new ExportProcessContext();
        ObjectUtils.copySourceInto(this,context);
        return context;
    }
}

