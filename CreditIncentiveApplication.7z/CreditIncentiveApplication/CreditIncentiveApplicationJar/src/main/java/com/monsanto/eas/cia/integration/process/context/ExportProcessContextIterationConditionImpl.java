package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.util.Condition;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 12:30:47 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("export-process-iteration-condition")
public class ExportProcessContextIterationConditionImpl implements Condition<ExportProcessContext> {
    public boolean evaluate(ExportProcessContext context) {                
        return context.getEntities()!=null;
    }
}
