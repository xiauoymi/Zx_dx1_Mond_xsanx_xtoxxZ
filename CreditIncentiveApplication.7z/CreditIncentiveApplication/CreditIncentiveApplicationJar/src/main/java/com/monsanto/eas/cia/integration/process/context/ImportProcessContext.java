package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.RecordIterator;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.hibernate.validator.ClassValidator;

import java.io.InputStream;
import java.io.Reader;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 12:32:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessContext extends ProcessContext {
    protected InputStream               inputStream;
    protected Reader                    reader;
    protected Record abstractRecord;
    protected Layout                    layout;
    protected ImportLayoutService       importLayoutService;
    protected Class<?>                  importLayoutType;
    protected ClassValidator            validator;
    protected RecordIterator            iterator;

    public ImportProcessContext(){

    }

    public ImportProcessContext(ProcessQueue eventQueue) {
        super(eventQueue);
    }

    public ImportProcessContext(String serviceId, ProcessQueue eventQueue) {
        super(serviceId, eventQueue);
    }

    public synchronized InputStream getInputStream() {
        return inputStream;
    }

    public synchronized void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public synchronized Reader getReader() {
        return reader;
    }

    public synchronized void setReader(Reader reader) {
        this.reader = reader;
    }

    public synchronized Record getAbstractRecord() {
        return abstractRecord;
    }

    public synchronized void setAbstractRecord(Record abstractRecord) {
        this.abstractRecord = abstractRecord;
    }

    public synchronized Layout getLayout() {
        return layout;
    }

    public synchronized void setLayout(Layout layout) {
        this.layout = layout;
    }

    public synchronized ImportLayoutService getImportLayoutService() {
        return importLayoutService;
    }

    public synchronized void setImportLayoutService(ImportLayoutService importLayoutService) {
        this.importLayoutService = importLayoutService;
    }

    public synchronized Class<?> getImportLayoutType() {
        return importLayoutType;
    }

    public synchronized void setImportLayoutType(Class<?> importLayoutType) {
        this.importLayoutType = importLayoutType;
    }

    public synchronized ClassValidator getValidator() {
        return validator;
    }

    public synchronized void setValidator(ClassValidator validator) {
        this.validator = validator;
    }

    public synchronized RecordIterator getIterator() {
        return iterator;
    }

    public synchronized void setIterator(RecordIterator iterator) {
        this.iterator = iterator;
    }

    @Override
    public synchronized ImportProcessContext clone() {
        ImportProcessContext context= new ImportProcessContext();
        ObjectUtils.copySourceInto(this,context);
        return context;
    }
}
