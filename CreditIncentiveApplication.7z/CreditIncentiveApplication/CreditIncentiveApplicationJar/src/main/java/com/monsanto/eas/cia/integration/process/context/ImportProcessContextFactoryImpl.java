package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.process.contract.ProcessContextFactory;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 11:25:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-process-context-factory")
public class ImportProcessContextFactoryImpl extends AbstractProcessContextFactory implements ProcessContextFactory<ImportProcessContext> {
    public ImportProcessContext createProcessContext(Object ... parameters)  throws IOException {
        Reader reader=null;
        if(parameters[0] instanceof Reader){
            reader=(Reader)parameters[0];
        }
        InputStream stream=null;
        if(parameters[0] instanceof InputStream){
            stream=(InputStream)parameters[0];
        }

        String serviceId=(String)parameters[1];        
        ProcessQueue eventQueue= eventQueueFactory.createEventQueue(remaining(2,parameters));
        ImportProcessContext context=new ImportProcessContext(serviceId,eventQueue);
        context.setInputStream(stream);
        context.setReader(reader);
        return context;
    }
}
