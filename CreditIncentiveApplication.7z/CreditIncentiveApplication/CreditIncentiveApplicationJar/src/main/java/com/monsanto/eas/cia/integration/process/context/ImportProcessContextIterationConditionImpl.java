package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.util.Condition;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 11:42:04 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-process-iteration-condition")
public class ImportProcessContextIterationConditionImpl implements Condition<ImportProcessContext>{
    public boolean evaluate(ImportProcessContext context) {
        return context.getAbstractRecord()!=null;
    }
}