package com.monsanto.eas.cia.integration.process.context;

import com.monsanto.eas.cia.integration.process.contract.EventQueueFactory;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.eip.SedaProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistryImpl;
import com.monsanto.eas.cia.integration.process.event.ThrowableEventHandlerImpl;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 11:28:40 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ThrowableEventQueueFactoryImpl implements EventQueueFactory {

    protected int queueSize =300;
    protected int numberOfConsumers=1;
    
    public ProcessQueue createEventQueue(Object ... parameters) throws IOException {
        Writer log=(Writer)parameters[0];
        ProcessEventHandlerRegistry processEventHandlerRegistry=new ProcessEventHandlerRegistryImpl();
        SedaProcessQueue eventQueue=new SedaProcessQueue(numberOfConsumers, queueSize, processEventHandlerRegistry);
        processEventHandlerRegistry.addProcessEventHandler(
            new ThrowableEventHandlerImpl(
                log,
                LayoutUtils.RESOURCE_BUNDLE
            )
        );
        return eventQueue;
    }

    public void setNumberOfConsumers(int numberOfConsumers) {
        this.numberOfConsumers = Math.abs(numberOfConsumers);
    }

    public void setQueueSize(int queueSize) {
        this.queueSize = queueSize;
    }
}
