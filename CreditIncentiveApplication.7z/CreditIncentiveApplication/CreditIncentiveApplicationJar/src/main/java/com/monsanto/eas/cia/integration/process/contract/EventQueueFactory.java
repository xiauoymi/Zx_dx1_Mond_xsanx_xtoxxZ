package com.monsanto.eas.cia.integration.process.contract;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:10:59 AM
 * To change this template use File | Settings | File Templates.
 */
public interface EventQueueFactory {
    public ProcessQueue createEventQueue(Object ... parameters) throws IOException;
}
