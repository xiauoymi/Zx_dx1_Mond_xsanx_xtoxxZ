package com.monsanto.eas.cia.integration.process.contract;

import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 12:58:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessContext{
    protected String          serviceId;
    protected ProcessQueue    eventQueue;
    protected ProcessOutcome  processOutcome;
    protected boolean         exceptionFired;
    protected boolean         interrupted;
    protected boolean         halted;
    protected long            recordNumber;

    public ProcessContext(){

    }

    public ProcessContext(ProcessQueue eventQueue){
        setEventQueue(eventQueue);
    }

    public ProcessContext(String serviceId,ProcessQueue eventQueue){
        setServiceId(serviceId);
        setEventQueue(eventQueue);
    }

    public synchronized String getServiceId() {
        return serviceId;
    }

    public synchronized void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }    

    public synchronized ProcessQueue getEventQueue() {
        return eventQueue;
    }

    public synchronized void setEventQueue(ProcessQueue eventQueue) {
        this.eventQueue = eventQueue;
    }

    public synchronized ProcessOutcome getProcessOutcome() {
        return processOutcome;
    }

    public synchronized void setProcessOutcome(ProcessOutcome processOutcome) {
        this.processOutcome = processOutcome;
    }

    public synchronized boolean isExceptionFired() {
        return exceptionFired;
    }

    public synchronized void setExceptionFired(boolean exceptionFired) {
        this.exceptionFired = exceptionFired;
    }

    public synchronized boolean isInterrupted() {
        return interrupted||halted;
    }

    public synchronized void setInterrupted(boolean interrupted) {
        this.interrupted = interrupted;
    }

    public synchronized boolean isHalted() {
        return halted;
    }

    public synchronized void halt() {
        this.halted = true;
    }

    public synchronized void fireFatalException(Object payload){
        halt();
        fireEvent(payload,true,true,ProcessEvent.URGENT_PRIORITY);
    }

    public synchronized void fireException(Object payload){
        fireException(payload,true);
    }

    public synchronized void fireException(Object payload, boolean interrupted){
        fireEvent(payload,true,interrupted);
    }

    public synchronized void fireEvent(Object payload){
        fireEvent(payload,false);
    }

    public synchronized void fireEvent(Object payload, boolean interrupted){
        fireEvent(payload,false,interrupted);
    }

    public synchronized void fireEvent(Object payload,boolean exceptionFired, boolean interrupted){
        fireEvent(payload,exceptionFired,interrupted, ProcessEvent.NORMAL_PRIORITY);
    }

    public synchronized void fireEvent(Object payload,boolean exceptionFired, boolean interrupted, int priority){
        if(payload==null)return;
        setInterrupted(interrupted);
        setExceptionFired(exceptionFired);
        if(eventQueue!=null){
            eventQueue.send(payload,this,priority);
        }
    }

    public synchronized void setHalted(boolean halted) {
        this.halted = halted;
    }

    public synchronized long getRecordNumber() {
        return recordNumber;
    }

    public synchronized void setRecordNumber(long recordNumber) {
        this.recordNumber = recordNumber;
    }

    @Override
    public synchronized ProcessContext clone(){
        ProcessContext processContext=new ProcessContext();
        ObjectUtils.copySourceInto(this,processContext);
        return processContext;
    }
}
