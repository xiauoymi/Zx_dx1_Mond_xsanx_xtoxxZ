package com.monsanto.eas.cia.integration.process.contract;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 04:16:58 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessContextFactory <T extends ProcessContext>{
    public T createProcessContext(Object ... parameters) throws IOException; 
}
