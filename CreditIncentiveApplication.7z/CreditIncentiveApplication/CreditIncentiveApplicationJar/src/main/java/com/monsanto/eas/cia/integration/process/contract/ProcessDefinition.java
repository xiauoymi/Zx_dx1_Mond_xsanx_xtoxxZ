package com.monsanto.eas.cia.integration.process.contract;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 04:29:02 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessDefinition<T extends ProcessContext>{
    public T execute(Object ... parameters) throws Exception;
}
