package com.monsanto.eas.cia.integration.process.contract;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 08:23:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessOutcome {
    protected long interrupted      =   0;
    protected long successful       =   0;
    protected long failures         =   0;
    protected long exceptionsFired  =   0;

    public long getProcessed(){
        return getInterrupted()+getSuccessful()+ getFailures()+ getExceptionsFired();
    }

    public long getInterrupted() {
        return interrupted;
    }

    public void addInterrupted(){
        interrupted++;
    }

    public long getSuccessful() {
        return successful;
    }

    public void addSuccessful(){
        successful++;
    }

    public long getFailures() {
        return failures;
    }

    public void addFailure(){
        failures++;
    }

    public long getExceptionsFired() {
        return exceptionsFired;
    }

    public void addExceptionFired(){
        exceptionsFired++;
    }
}
