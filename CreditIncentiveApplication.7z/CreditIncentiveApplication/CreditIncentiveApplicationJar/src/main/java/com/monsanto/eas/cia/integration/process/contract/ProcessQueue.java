package com.monsanto.eas.cia.integration.process.contract;

import com.monsanto.eas.cia.integration.process.event.ProcessEvent;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 04:44:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessQueue {
    public void send(ProcessEvent event);
    public <P,C extends ProcessContext> void send(P payload, C context);
    public <P,C extends ProcessContext> void send(P payload, C context, int priority);
    public void shutdown();

    boolean isShutdown();
}
