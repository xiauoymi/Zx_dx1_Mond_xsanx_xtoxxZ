package com.monsanto.eas.cia.integration.process.contract;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 12:42:46 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessStage<T extends ProcessContext> {
    public void process(T context);
}
