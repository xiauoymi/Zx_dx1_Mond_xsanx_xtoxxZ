package com.monsanto.eas.cia.integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContextFactory;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 12:10:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultProcessDefinition<T extends ProcessContext> implements ProcessDefinition<T>, ProcessStage<T> {
    protected ProcessBuilderFactory<? extends T>          processBuilderFactory;
    protected ProcessContextFactory<? extends T>          processContextFactory;

    public void setProcessBuilderFactory(ProcessBuilderFactory<? extends T> processBuilderFactory) {
        this.processBuilderFactory = processBuilderFactory;
    }

    public void setProcessContextFactory(ProcessContextFactory<? extends T> processContextFactory) {
        this.processContextFactory = processContextFactory;
    }

    public void process(T context) {
        ProcessStage<T> processStage= (ProcessStage<T>) processBuilderFactory.getRootStage();
        processStage.process(context);
        if(context!=null){
            ProcessQueue processQueue=context.getEventQueue();
            if(processQueue!=null){
                processQueue.shutdown();
            }
        }                
    }

    public T execute(Object... parameters) throws Exception{
        T context=(T)processContextFactory.createProcessContext(parameters);
        process(context);
        return context;
    }
}
