package com.monsanto.eas.cia.integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import com.monsanto.eas.cia.integration.util.Condition;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 12:02:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportProcessBuilderFactoryImpl<T extends ProcessContext> extends ProcessBuilderFactory<T>{

    protected Condition<T>                      iterationCondition;
    protected ProcessStage<T>                   lookupExportLayoutServiceStage;
    protected ProcessStage<T>                   iterateRecordsStage;
    protected ProcessStage<T>                   exportLayoutExecutionStage;
    protected ProcessStage<T>                   writeRecordsStage;
    protected Aggregator                        aggregator;

    @Override
    public void configure() {
        add(lookupExportLayoutServiceStage);        
        add(splitter()).
            iterationCondition(iterationCondition).
            iteratorStage(iterateRecordsStage).
            serialProcessing().
            pipeline(
                pipeline(
                    exportLayoutExecutionStage,
                    writeRecordsStage
                )
            ).
            aggregator(aggregator);
        add(writeRecordsStage);
    }

    public void setAggregator(Aggregator aggregator) {
        this.aggregator = aggregator;
    }

    public void setExportLayoutExecutionStage(ProcessStage<T> exportLayoutExecutionStage) {
        this.exportLayoutExecutionStage = exportLayoutExecutionStage;
    }

    public void setIterateRecordsStage(ProcessStage<T> iterateRecordsStage) {
        this.iterateRecordsStage = iterateRecordsStage;
    }

    public void setIterationCondition(Condition<T> iterationCondition) {
        this.iterationCondition = iterationCondition;
    }

    public void setLookupExportLayoutServiceStage(ProcessStage<T> lookupExportLayoutServiceStage) {
        this.lookupExportLayoutServiceStage = lookupExportLayoutServiceStage;
    }

    public void setWriteRecordsStage(ProcessStage<T> writeRecordsStage) {
        this.writeRecordsStage = writeRecordsStage;
    }
}
