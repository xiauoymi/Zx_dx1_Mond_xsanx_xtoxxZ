package com.monsanto.eas.cia.integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import com.monsanto.eas.cia.integration.util.Condition;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 11:56:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessBuilderFactoryImpl<T extends ProcessContext> extends ProcessBuilderFactory<T> {

    protected int                               numberOfWorkers;
    protected Condition<T>                      iterationCondition;
    protected ProcessStage<T>                   initializeProcessStage;
    protected ProcessStage<T>                   createRecordsIteratorStage;
    protected ProcessStage<T>                   iterateRecordsStage;
    protected ProcessStage<T>                   convertRecordsStage;
    protected ProcessStage<T>                   validateRecordsStage;
    protected ProcessStage<T>                   importRecordsStage;
    protected Aggregator                        aggregator;

    @Override
    public void configure() {
        add(initializeProcessStage);
        add(createRecordsIteratorStage);
        add(splitter()).
            iterationCondition(iterationCondition).
            iteratorStage(iterateRecordsStage).
            parallelProcessing(numberOfWorkers).
            pipeline(
                pipeline(convertRecordsStage,validateRecordsStage,importRecordsStage)
            ).
            aggregator(aggregator);
    }

    public void setAggregator(Aggregator aggregator) {
        this.aggregator = aggregator;
    }

    public void setConvertRecordsStage(ProcessStage<T> convertRecordsStage) {
        this.convertRecordsStage = convertRecordsStage;
    }

    public void setImportRecordsStage(ProcessStage<T> importRecordsStage) {
        this.importRecordsStage = importRecordsStage;
    }

    public void setInitializeProcessStage(ProcessStage<T> initializeProcessStage) {
        this.initializeProcessStage = initializeProcessStage;
    }

    public void setCreateRecordsIteratorStage(ProcessStage<T> createRecordsIteratorStage) {
        this.createRecordsIteratorStage = createRecordsIteratorStage;
    }

    public void setIterateRecordsStage(ProcessStage<T> iterateRecordsStage) {
        this.iterateRecordsStage = iterateRecordsStage;
    }

    public void setIterationCondition(Condition<T> iterationCondition) {
        this.iterationCondition = iterationCondition;
    }

    public void setNumberOfWorkers(int numberOfWorkers) {
        this.numberOfWorkers = numberOfWorkers;
    }

    public void setValidateRecordsStage(ProcessStage<T> validateRecordsStage) {
        this.validateRecordsStage = validateRecordsStage;
    }
}
