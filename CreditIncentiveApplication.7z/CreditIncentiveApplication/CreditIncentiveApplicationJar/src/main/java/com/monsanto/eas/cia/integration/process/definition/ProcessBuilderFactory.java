package com.monsanto.eas.cia.integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.eip.Pipeline;
import com.monsanto.eas.cia.integration.process.eip.Splitter;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/02/2011
 * Time: 11:28:03 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ProcessBuilderFactory<C extends ProcessContext>{
    public static final ThreadLocal<Pipeline> mainPipelineVariable =new ThreadLocal<Pipeline>();

    public ProcessStage<C> getRootStage(){
        configure();
        Pipeline<C> mainPipeline= getMainPipeline();
        mainPipelineVariable.remove();
        return mainPipeline;
    }

    public abstract void configure();

    public <T extends ProcessStage<C>> T add(T stage){
        Pipeline<C> pipeline= getMainPipeline();
        pipeline.add(stage);
        return stage;
    }

    public <T extends ProcessStage<C>> T add(ProcessBuilderFactory<C> processBuilder){
        T stage=(T)processBuilder.getRootStage();
        return add(stage);
    }

    public Splitter<C> splitter(){
        Splitter<C> splitter=new Splitter<C>();        
        return splitter;
    }

    public Pipeline<C> pipeline(ProcessStage<C>... stages){
        Pipeline<C> pipeline=new Pipeline<C>(stages);
        return pipeline;
    }

    public Pipeline<C> getMainPipeline(){
        Pipeline<C> mainPipeline= mainPipelineVariable.get();
        if(mainPipeline==null)
            mainPipelineVariable.set(mainPipeline=new Pipeline<C>());
        return mainPipeline;
    }
}
