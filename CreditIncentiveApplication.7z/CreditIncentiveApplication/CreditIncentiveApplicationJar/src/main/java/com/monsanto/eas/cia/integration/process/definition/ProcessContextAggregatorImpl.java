package com.monsanto.eas.cia.integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 08:03:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("process-context-aggregator")
public class ProcessContextAggregatorImpl implements Aggregator<ProcessContext> {

    public void aggregateContexts(ProcessContext originalContext, ProcessContext ... newContexts) {
        ProcessOutcome processOutcome=null;
        if((processOutcome=originalContext.getProcessOutcome())==null){
            originalContext.setProcessOutcome(processOutcome=new ProcessOutcome());
        }
        if(newContexts==null)return;
        for(ProcessContext context:newContexts){
            if(context.isExceptionFired()&&context.isInterrupted()){
                processOutcome.addFailure();
            }
            else if(context.isExceptionFired()){
                processOutcome.addExceptionFired();
            }
            else if(context.isInterrupted()){
                processOutcome.addInterrupted();
            }
            else{
                processOutcome.addSuccessful();
            }
            if(context.isHalted()){
                originalContext.halt();
            }
        }
    }
}
