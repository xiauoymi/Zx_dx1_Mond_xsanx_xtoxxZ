package com.monsanto.eas.cia.integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 04:13:00 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Aggregator <T extends ProcessContext>{
    public void aggregateContexts(T context,T ... contexts);
}
