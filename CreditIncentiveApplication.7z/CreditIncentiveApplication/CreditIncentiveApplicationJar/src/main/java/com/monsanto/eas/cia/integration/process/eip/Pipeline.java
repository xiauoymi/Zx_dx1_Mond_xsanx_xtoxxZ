package com.monsanto.eas.cia.integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.stage.ReliableProcessStage;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:30:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class Pipeline<T extends ProcessContext> implements ProcessStage<T> {
    protected ProcessStage<T>[] processStages=null;

    public Pipeline(){
        
    }

    public Pipeline(ProcessStage<T> ... stages){
        addAll(stages);
    }

    public void process(T context) {          
        for(ProcessStage<T> stage:processStages){
            stage.process(context);
            if(context.isInterrupted()){
                context.setInterrupted(false);
                break;
            }
        }
    }    

    public synchronized Pipeline<T> addAll(ProcessStage<T> ... stages){
        for(ProcessStage<T> stage:stages){
            add(stage);
        }
        return this;
    }

    public synchronized Pipeline<T> add(ProcessStage<T> processStage){
        if(processStage!=null){
            int index=0;
            if(processStages==null){
                processStages=new ProcessStage[1];
            }
            else{
                index=processStages.length;
                processStages= Arrays.copyOf(processStages,index+1);
            }
            processStages[index]=new ReliableProcessStage<T>(processStage);                
        }
        return this;
    }
}
