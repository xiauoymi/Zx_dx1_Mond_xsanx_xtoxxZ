package com.monsanto.eas.cia.integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import com.monsanto.eas.cia.integration.process.event.ProcessEventWorker;

import java.util.concurrent.*;

import static com.monsanto.eas.cia.integration.util.ObjectUtils.absOrValue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 04:42:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class SedaProcessQueue implements ProcessQueue{
    protected int                           consumers;
    protected Semaphore                     semaphore;
    protected int                           capacity;
    protected ExecutorService               executorService;
    protected ProcessEventHandlerRegistry   processEventHandlerRegistry;
    protected boolean                       shutdown;

    public SedaProcessQueue(int _consumers, int _capacity, ProcessEventHandlerRegistry _registry){
        setConsumers(_consumers);
        setCapacity(_capacity);
        setProcessEventHandlerRegistry(_registry);
        createExecutorService();
    }

    protected void setConsumers(int consumers){
        this.consumers  =   absOrValue(consumers,0);
    }

    protected void setCapacity(int _capacity){        
        this.capacity   =   absOrValue(_capacity,1);
    }

    protected void setProcessEventHandlerRegistry(ProcessEventHandlerRegistry processEventHandlerRegistry){
        this.processEventHandlerRegistry = processEventHandlerRegistry;
    }

    protected void createExecutorService(){
        if(getConsumers()>0){
            semaphore=new Semaphore(getCapacity(),true);
            executorService=new ThreadPoolExecutor(
                getConsumers(),getConsumers(),2,TimeUnit.SECONDS,
                new PriorityBlockingQueue<Runnable>(getCapacity()),
                new ThreadPoolExecutor.DiscardPolicy()
            ){
                protected void afterExecute(Runnable runnable, Throwable t) {
                    semaphore.release();
                }
            };
        }
    }

    public <P,C extends ProcessContext> void send(P payload, C context){
        send(payload,context,ProcessEvent.NORMAL_PRIORITY);
    }

    public <P,C extends ProcessContext> void send(P payload, C context,int priority){
        send(new ProcessEvent(payload,context).setPriority(priority));
    }

    protected boolean semaphoreAcquired(){
        if(semaphore==null)return false;
        boolean semaphoreAcquired=false;        
        try {
            semaphoreAcquired=semaphore.tryAcquire(1,TimeUnit.SECONDS);
        } catch (InterruptedException e) {}
        return semaphoreAcquired;
    }

    public synchronized void send(ProcessEvent processEvent){
        if(processEvent==null||processEvent.getPayload()==null||shutdown)return;
        ProcessEventWorker processEventWorker=new ProcessEventWorker(processEvent, processEventHandlerRegistry);
        if(executorService!=null&&semaphoreAcquired()){
            executorService.execute(processEventWorker);            
        }
        else{
            processEventWorker.run();
        }
    }

    public synchronized void shutdown() {
        if(shutdown)return;
        shutdown=true;
        if(executorService!=null){
            executorService.shutdown();
            try{
                while(!executorService.awaitTermination(10,TimeUnit.SECONDS));
            } catch (InterruptedException e) {}            
        }
        if(processEventHandlerRegistry !=null){
            processEventHandlerRegistry.removeAllProcessEventHandlers();
        }
    }

    public ProcessEventHandlerRegistry getProcessEventHandlerRegistry() {
        return processEventHandlerRegistry;
    }

    public int getConsumers() {
        return consumers;
    }

    public int getCapacity() {
        return capacity;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }

    public synchronized boolean isShutdown() {
        return shutdown;
    }
}
