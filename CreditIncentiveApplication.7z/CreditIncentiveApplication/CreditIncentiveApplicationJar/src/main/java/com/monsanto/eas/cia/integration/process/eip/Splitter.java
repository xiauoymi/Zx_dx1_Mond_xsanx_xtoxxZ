package com.monsanto.eas.cia.integration.process.eip;

import static com.monsanto.eas.cia.integration.util.ObjectUtils.absOrValue;

import java.io.IOException;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.event.PipelineProcessEventHandler;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistryImpl;
import com.monsanto.eas.cia.integration.process.stage.ReliableProcessStage;
import com.monsanto.eas.cia.integration.util.Condition;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 10:40:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class Splitter<T extends ProcessContext> implements ProcessStage<T>{

    protected ProcessStage<T>           iteratorStage           ;
    protected Condition<T>              iterationCondition      ;
    protected Pipeline<T>               pipelineStage           ;
    protected int                       concurrentWorkers   =   0;
    protected int                       bufferSizeFactor    =   10;
    protected Aggregator<T>             aggregator              ;    

    public Splitter() {

    }

    public Splitter(ProcessStage<T> iteratorStage) {
        iteratorStage(iteratorStage);
    }

    public Splitter<T> serialProcessing(){
        return parallelProcessing(0);
    }

    public Splitter<T> setBufferSizeFactor(int bufferSizeFactor){
        this.bufferSizeFactor=absOrValue(bufferSizeFactor,1);
        return this;
    }

    public Splitter<T> parallelProcessing(int concurrentWorkers) {                
        this.concurrentWorkers = absOrValue(concurrentWorkers,1,2);
        return this;
    }

    public Splitter<T> iteratorStage(ProcessStage<T> iteratorStage){
        this.iteratorStage =new ReliableProcessStage<T>(iteratorStage);
        return this;
    }

    public Splitter<T> iterationCondition(final Condition<T> condition){
        if(condition==null)throw new IllegalArgumentException();
        this.iterationCondition = condition;
        return this;
    }

    public Splitter<T> aggregator(Aggregator<T> aggregator){
        this.aggregator=aggregator;
        return this;
    }

    public Splitter<T> pipeline(Pipeline<T> pipelineStage){
        this.pipelineStage=pipelineStage;
        return this;
    }

    public SedaProcessQueue createPipelineProcessQueue(){
        ProcessEventHandlerRegistry processEventHandlerRegistry=new ProcessEventHandlerRegistryImpl();
        PipelineProcessEventHandler<T> pipelineProcessEventHandler = new PipelineProcessEventHandler<T>(pipelineStage,aggregator);
        try{
            processEventHandlerRegistry.addProcessEventHandler(ProcessContext.class,pipelineProcessEventHandler);
        }
        catch(IOException ioe){
            throw new RuntimeException(ioe);
        }
        return new SedaProcessQueue(concurrentWorkers,bufferSizeFactor*concurrentWorkers,processEventHandlerRegistry);
    }

    public synchronized void process(T context) {
        if(context==null||context.isInterrupted())return;
        SedaProcessQueue pipelineProcessQueue= createPipelineProcessQueue();
        iteratorStage.process(context);
        ProcessContext pipelineProcessContext;
        while(!context.isInterrupted()&&iterationCondition.evaluate(context)){
        	pipelineProcessContext=this.concurrentWorkers==0?context:context.clone();
            pipelineProcessQueue.send(pipelineProcessContext,context);
            iteratorStage.process(context);
        }
        pipelineProcessQueue.shutdown();
    }

    public ProcessStage<T> getIteratorStage() {
        return iteratorStage;
    }

    public Condition<T> getIterationCondition() {
        return iterationCondition;
    }

    public Pipeline<T> getPipelineStage() {
        return pipelineStage;
    }

    public int getConcurrentWorkers() {
        return concurrentWorkers;
    }

    public Aggregator<T> getAggregator() {
        return aggregator;
    }
}
