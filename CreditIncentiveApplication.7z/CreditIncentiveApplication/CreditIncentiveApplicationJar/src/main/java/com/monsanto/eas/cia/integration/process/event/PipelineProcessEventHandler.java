package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import com.monsanto.eas.cia.integration.process.eip.Pipeline;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 02:35:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class PipelineProcessEventHandler<T extends ProcessContext> implements ProcessEventHandler<T>{
    protected Pipeline      pipelineStage;
    protected Aggregator    aggregator;

    public PipelineProcessEventHandler(Pipeline pipelineStage,Aggregator aggregator) {
        this.pipelineStage  =   pipelineStage;
        this.aggregator     =   aggregator;
    }

    public void handleEvent(T newContext, ProcessContext originalContext) {        
        if(pipelineStage!=null){
            pipelineStage.process(newContext);
            if(aggregator!=null){
                synchronized(aggregator){
                    aggregator.aggregateContexts((T)originalContext,newContext);
                }
            }
        }
    }
    
    public void start() {}
    public void close() {}

    public Pipeline getPipelineStage() {
        return pipelineStage;
    }

    public Aggregator getAggregator() {
        return aggregator;
    }
}
