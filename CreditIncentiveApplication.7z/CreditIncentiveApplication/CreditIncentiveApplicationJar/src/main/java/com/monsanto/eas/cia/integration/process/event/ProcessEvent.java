package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import org.apache.commons.lang.ClassUtils;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 02:14:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEvent implements Comparable {
    public static final int URGENT_PRIORITY =   10;
    public static final int HIGH_PRIORITY   =   5;
    public static final int NORMAL_PRIORITY =   0;
    public static final int LOW_PRIORITY    =   -5;

    protected Object payload;
    protected ProcessContext processContext;
    protected int priority=NORMAL_PRIORITY;


    public ProcessEvent(Object payload,ProcessContext processContext) {
        if(payload==null)throw new IllegalArgumentException();
        this.payload = payload;
        this.processContext=processContext;
    }

    public ProcessEvent setPriority(int priority){
        this.priority=priority;
        return this;
    }

    public ProcessContext getProcessContext() {
        return processContext;
    }

    public Object getPayload() {
        return payload;
    }

    public boolean isPayloadAssignableTo(Class _class){
        return ClassUtils.isAssignable(payload.getClass(),_class);
    }

    public int compareTo(Object o) {
        ProcessEvent other=(ProcessEvent)o;        
        return this.getPriority()-other.getPriority();
    }

    public int getPriority() {
        return priority;
    }
}
