package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 04:53:31 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessEventHandler<T>{
    public void start() throws IOException;
    public void handleEvent(T payload, ProcessContext context);
    public void close() throws IOException;
}
