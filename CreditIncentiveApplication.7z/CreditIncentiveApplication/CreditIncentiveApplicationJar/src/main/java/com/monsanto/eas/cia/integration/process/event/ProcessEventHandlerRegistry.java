package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.util.ClassHierarchyType;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 12:11:54 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProcessEventHandlerRegistry {
    void removeProcessEventHandler(ProcessEventHandler<?> handler);

    void removeProcessEventHandler(Class<?> _class);

    void removeProcessEventHandler(ClassHierarchyType type);

    void addProcessEventHandler(ProcessEventHandler<?> handler) throws IOException;

    void addProcessEventHandler(Class<?> _class,ProcessEventHandler<?> handler) throws IOException;

    void addProcessEventHandler(ClassHierarchyType type,ProcessEventHandler<?> handler) throws IOException;

    ProcessEventHandler<?> getProcessEventHandler(Class<?> _class);

    ProcessEventHandler<?> getProcessEventHandler(ClassHierarchyType type);

    void removeAllProcessEventHandlers();
}
