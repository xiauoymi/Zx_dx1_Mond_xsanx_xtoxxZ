package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.util.ClassHierarchyType;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 12:05:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEventHandlerRegistryImpl implements ProcessEventHandlerRegistry{
    protected Map<ClassHierarchyType, ProcessEventHandler>  handlerMap;
    protected PriorityQueue<ClassHierarchyType>             typeIndex;

    public ProcessEventHandlerRegistryImpl(){
        typeIndex =new PriorityQueue<ClassHierarchyType>();
        handlerMap = Collections.synchronizedMap(new HashMap<ClassHierarchyType,ProcessEventHandler>());
    }

    public synchronized int size(){
        return typeIndex.size();
    }

    public synchronized void removeProcessEventHandler(ProcessEventHandler<?> handler){
        if(handler==null)return;
        removeProcessEventHandler(ObjectUtils.getGenericType(handler.getClass(),Object.class));
    }

    public synchronized void removeProcessEventHandler(Class<?> _class){
        if(_class==null)return;
        removeProcessEventHandler(new ClassHierarchyType(_class));
    }

    public synchronized void removeProcessEventHandler(ClassHierarchyType type){
        if(type==null)return;
        ProcessEventHandler<?> handler= getProcessEventHandler(type);
        handlerMap.remove(type);
        typeIndex.remove(type);
        if(handler!=null){
            try{
                handler.close();
            }
            catch(Exception e){}
        }
    }

    public synchronized void addProcessEventHandler(ProcessEventHandler<?> handler) throws IOException {
        if(handler==null)return;
        addProcessEventHandler(ObjectUtils.getGenericType(handler.getClass(),Object.class),handler);
    }

    public synchronized void addProcessEventHandler(Class<?> _class,ProcessEventHandler<?> handler) throws IOException{
        if(handler==null||_class==null)return;
        addProcessEventHandler(new ClassHierarchyType(_class),handler);
    }

    public synchronized void addProcessEventHandler(ClassHierarchyType type,ProcessEventHandler<?> handler) throws IOException{
        if(handler==null||type==null)return;
        ProcessEventHandler<?> lastHandler= handlerMap.put(type,handler);
        typeIndex.offer(type);
        if(lastHandler==null||handler!=lastHandler){
            handler.start();
        }
    }

    public synchronized ProcessEventHandler<?> getProcessEventHandler(Class<?> _class){
        if(_class==null)return null;
        return getProcessEventHandler(new ClassHierarchyType(_class));
    }

    public synchronized ProcessEventHandler<?> getProcessEventHandler(ClassHierarchyType type){
        if(type==null)return null;
        ProcessEventHandler handler= handlerMap.get(type);
        if(handler==null){
            for(ClassHierarchyType key: typeIndex){
                if(key.canBeAssigned(type)){
                    handler= handlerMap.get(key);
                    break;
                }
            }
        }
        return handler;
    }

    public synchronized void removeAllProcessEventHandlers(){
        ClassHierarchyType[] temporal= typeIndex.toArray(new ClassHierarchyType[typeIndex.size()]);                
        for(ClassHierarchyType type: temporal){
            this.removeProcessEventHandler(type);
        }
    }
}
