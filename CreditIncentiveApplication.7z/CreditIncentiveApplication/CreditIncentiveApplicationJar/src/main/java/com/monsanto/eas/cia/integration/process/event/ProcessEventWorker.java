package com.monsanto.eas.cia.integration.process.event;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 12:17:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEventWorker implements Runnable,Comparable{
    protected ProcessEvent                  processEvent;
    protected ProcessEventHandlerRegistry   processEventHandlerRegistry;

    public ProcessEventWorker(ProcessEvent processEvent,ProcessEventHandlerRegistry processEventHandlerRegistry) {
        this.processEvent                   = processEvent;
        this.processEventHandlerRegistry    = processEventHandlerRegistry;
    }

    public void run(){
        if(processEvent==null|| processEventHandlerRegistry ==null)return;
        Object payload=processEvent.getPayload();
        if(payload==null)return;
        ProcessEventHandler handler= processEventHandlerRegistry.getProcessEventHandler(payload.getClass());
        if(handler==null)return;
        try{
            handler.handleEvent(payload,processEvent.getProcessContext());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public ProcessEvent getProcessEvent() {
        return processEvent;
    }

    public ProcessEventHandlerRegistry getProcessEventHandlerRegistry() {
        return processEventHandlerRegistry;
    }

    public int compareTo(Object o) {
        if(processEvent==null)return 0;
        ProcessEventWorker other=(ProcessEventWorker)o;
        ProcessEvent otherProcessEvent  =other.getProcessEvent();
        ProcessEvent thisProcessEvent   =this.getProcessEvent();
        if(otherProcessEvent==null||thisProcessEvent==null)return 0;
        return thisProcessEvent.compareTo(otherProcessEvent);
    }
}
