package com.monsanto.eas.cia.integration.process.event;

import com.monsanto.eas.cia.integration.exception.AbstractLayoutException;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIteratorException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.exception.GenericTypeException;
import com.monsanto.eas.cia.integration.process.exception.ProcessStageException;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 7/02/2011
 * Time: 01:14:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class ThrowableEventHandlerImpl extends WriterProcessEventHandlerImpl<Throwable> {

    public ThrowableEventHandlerImpl() {
    }

    public ThrowableEventHandlerImpl(Writer writer, ResourceBundle bundle) throws IOException {
        super(writer, bundle);
    }

    public void handleEvent(Throwable throwable, ProcessContext context) {        
        bundleln(false,"record.failure",context.getRecordNumber());
        if(throwable instanceof AbstractLayoutException){
            AbstractLayoutException exception=(AbstractLayoutException)throwable;            
            println(exception.explain(bundle));
        }
        else if(throwable instanceof CsvRecordIteratorException){
            CsvRecordIteratorException exception=(CsvRecordIteratorException)throwable;
            bundleln("csv.record.iterator.exception",exception.getPosition(),exception.getMessage(),exception.getCause());
        }
        else if(throwable instanceof GenericTypeException){
            GenericTypeException exception =(GenericTypeException)throwable;
            Class<?> genericType=exception.getGenericType();
            bundleln("generic.type.exception",genericType!=null?genericType.getName():genericType);
        }
        else if(throwable instanceof LayoutServiceLocatorException){
            LayoutServiceLocatorException exception=(LayoutServiceLocatorException)throwable;
            Class<?> serviceClass=exception.getServiceClass();
            bundleln("service.locator.exception",exception.getServiceId(),serviceClass!=null?serviceClass.getName():serviceClass);
        }
        else if(throwable instanceof ProcessStageException){
            bundleln("configuration.exception");
        }
        else{
            StringWriter buffer;
            throwable.printStackTrace(new PrintWriter(buffer=new StringWriter(),true));            
            bundleln("unknown.exception", throwable.getMessage(), buffer.toString());
        }        
    }
}
