package com.monsanto.eas.cia.integration.process.event;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.MessageFormat;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 7/02/2011
 * Time: 01:37:07 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class WriterProcessEventHandlerImpl<T> implements ProcessEventHandler<T> {

    protected PrintWriter printer=null;
    protected ResourceBundle bundle=null;
    protected Writer writer=null;

    protected WriterProcessEventHandlerImpl() {
    }

    protected WriterProcessEventHandlerImpl(Writer writer, ResourceBundle bundle) throws IOException {
        setWriter(writer);        
        setBundle(bundle);
    }

    public void start() throws IOException{
        this.printer = new PrintWriter(writer,true);
    }

    public void bundleln(String key, Object ... args){
        bundleln(true,key,args);
    }

    public void bundleln(boolean nl,String key, Object ... args){
        if(key==null||key.trim().length()==0){
            println(null);
        }
        else{
            String message=null;
            if(bundle.containsKey(key))
                message=bundle.getString(key);
            if(message==null){
                 printer.print("");
            }
            else{
                printer.print(MessageFormat.format(message,args));
            }
            if(nl)printer.println();
        }
    }

    public void println(String string){
        if(string==null)string="";
        printer.println(string);
    }

    public void formatln(String string, Object ... args){
        if(string==null)string="";
        printer.format(string+"%n",args);        
    }

    public void setBundle(ResourceBundle bundle) {
        this.bundle = bundle;
    }

    public void setWriter(Writer writer) {
        this.writer = writer;
    }

    public void close() {
        printer.flush();
        printer.close();
    }
}
