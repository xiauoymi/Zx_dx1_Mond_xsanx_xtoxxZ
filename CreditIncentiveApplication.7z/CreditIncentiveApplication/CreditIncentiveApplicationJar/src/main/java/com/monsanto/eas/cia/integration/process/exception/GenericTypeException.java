package com.monsanto.eas.cia.integration.process.exception;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 7/02/2011
 * Time: 12:25:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenericTypeException extends RuntimeException{
    protected Class<?>  genericType;

    public GenericTypeException(Class<?> genericType) {
        setGenericType(genericType);
    }

    public Class<?> getGenericType() {
        return genericType;
    }

    public void setGenericType(Class<?> genericType) {
        this.genericType = genericType;
    }    
}
