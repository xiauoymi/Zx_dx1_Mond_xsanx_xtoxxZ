package com.monsanto.eas.cia.integration.process.exception;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 02:35:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessStageException extends RuntimeException{

    public ProcessStageException() {
    }

    public ProcessStageException(String message) {
        super(message);
    }
}
