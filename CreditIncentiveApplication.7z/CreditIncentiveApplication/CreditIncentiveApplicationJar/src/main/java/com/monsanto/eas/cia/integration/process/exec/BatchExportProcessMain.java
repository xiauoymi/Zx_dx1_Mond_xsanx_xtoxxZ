package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import com.monsanto.eas.cia.integration.process.exec.vo.BatchInteraction;
import com.monsanto.eas.cia.integration.process.exec.vo.FileInteraction;
import com.monsanto.eas.cia.integration.process.exec.vo.FileInteractionHelper;

import java.io.*;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 07:40:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchExportProcessMain extends BatchProcessMain{
    public BatchExportProcessMain(String contextId) {
        super(contextId);
    }

    public Writer getOutputWriter(int position, String file) throws IOException{
        try{
            return new FileWriter(new File(file));
        }
        catch(Exception e){
            throw new RuntimeException("Cannot access output file at: "+position,e);
        }
    }

    public static void main(String ... arguments) throws Exception{
        BatchExportProcessMain batchExportProcessMain=new BatchExportProcessMain("batch-export-process");
        if(batchExportProcessMain.commandLineInput(arguments)){
            BatchInteraction batchInteraction=batchExportProcessMain.getBatchInteraction();
            FileInteractionHelper helper =null;
            ProcessDefinition processDefinition=null;
            String processId=null,serviceId=null,fileName=null,errorLog=null;
            List<FileInteraction> fileInteractions=batchInteraction.getFileInteractions();
            if(fileInteractions==null)
                throw new RuntimeException("No file interactions");
            int position=0;
            for(FileInteraction fileInteraction:batchInteraction.getFileInteractions()){
                helper =new FileInteractionHelper(batchInteraction,fileInteraction);
                processId= helper.getProcessId();
                processDefinition=batchExportProcessMain.getProcessDefinition(processId);
                if(processDefinition==null){
                    throw new RuntimeException("No process definition with id: "+processId+". At position: "+position);
                }
                serviceId= helper.getServiceId();
                if(serviceId==null){
                    throw new RuntimeException("No service id at: "+position);
                }
                fileName= helper.getFileName();
                errorLog= helper.getErrorLog();
                processDefinition.execute(
                    batchExportProcessMain.getOutputWriter(position,fileName),
                    serviceId,
                    batchExportProcessMain.getErrorLog(position,errorLog)
                );
                position++;
            }
        }
    }


}
