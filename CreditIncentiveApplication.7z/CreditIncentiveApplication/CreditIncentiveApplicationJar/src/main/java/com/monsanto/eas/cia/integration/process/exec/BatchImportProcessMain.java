package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import com.monsanto.eas.cia.integration.process.exec.vo.BatchInteraction;
import com.monsanto.eas.cia.integration.process.exec.vo.FileInteraction;
import com.monsanto.eas.cia.integration.process.exec.vo.FileInteractionHelper;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 06:41:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchImportProcessMain extends BatchProcessMain{

    protected BatchImportProcessMain(String contextId) {
        super(contextId);
    }

    public Reader getInputReader(int position, String file) throws IOException {
        try{
            return new FileReader(new File(file));
        }
        catch(Exception e){
            throw new RuntimeException("Cannot access input file at: "+position,e);
        }
    }

    public static void main(String ... arguments) throws Exception{
        BatchImportProcessMain batchImportProcessMain=new BatchImportProcessMain("batch-import-process");
        if(batchImportProcessMain.commandLineInput(arguments)){

            BatchInteraction batchInteraction=batchImportProcessMain.getBatchInteraction();
            FileInteractionHelper helper =null;
            ProcessDefinition processDefinition=null;
            String processId=null,serviceId=null,fileName=null,errorLog=null;
            List<FileInteraction> fileInteractions=batchInteraction.getFileInteractions();
            if(fileInteractions==null)
                throw new RuntimeException("No file interactions");
            int position=0;
            for(FileInteraction fileInteraction:batchInteraction.getFileInteractions()){
                helper =new FileInteractionHelper(batchInteraction,fileInteraction);
                processId= helper.getProcessId();
                processDefinition=batchImportProcessMain.getProcessDefinition(processId);
                if(processDefinition==null){
                    throw new RuntimeException("No process definition with id: "+processId+". At position: "+position);                    
                }
                serviceId= helper.getServiceId();
                if(serviceId==null){
                    throw new RuntimeException("No service id at: "+position);                    
                }
                fileName= helper.getFileName();
                errorLog= helper.getErrorLog();
                processDefinition.execute(
                    batchImportProcessMain.getInputReader(position,fileName),
                    serviceId,
                    batchImportProcessMain.getErrorLog(position,errorLog)
                );
                position++;
            }            
        }
    }
}
