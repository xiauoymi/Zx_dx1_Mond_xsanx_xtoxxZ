package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import com.monsanto.eas.cia.integration.process.exec.vo.BatchInteraction;
import com.monsanto.eas.cia.integration.process.exec.vo.FileInteraction;
import com.thoughtworks.xstream.XStream;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 07:36:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchProcessMain extends ProcessMain{

    protected XStream xstream;

    public BatchProcessMain(String contextId) {
        super(contextId);
        xstream=createXStream();
    }

    protected XStream createXStream(){
        XStream xstream = new XStream();
        xstream.alias("batch", BatchInteraction.class);
        xstream.alias("item", FileInteraction.class);

        xstream.useAttributeFor(FileInteraction.class,"processId");
        xstream.useAttributeFor(FileInteraction.class,"serviceId");
        xstream.useAttributeFor(FileInteraction.class,"fileDirectory");
        xstream.useAttributeFor(FileInteraction.class,"errorLogDirectory");
        xstream.useAttributeFor(FileInteraction.class, "fileName");
        xstream.useAttributeFor(FileInteraction.class, "errorLog");

        xstream.useAttributeFor(BatchInteraction.class, "fileSuffix");
        xstream.useAttributeFor(BatchInteraction.class, "errorLogSuffix");

        xstream.addImplicitCollection(BatchInteraction.class,"fileInteractions", FileInteraction.class);
        return xstream;
    }

    public BatchInteraction getBatchInteraction(){
        try{
            return (BatchInteraction)xstream.fromXML(new FileReader(new File(context.getOptionValue("configuration"))));
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    public ProcessDefinition getProcessDefinition(String processId){
        return context.getService(processId,ProcessDefinition.class);
    }

    public Writer getErrorLog(int position, String file) throws IOException {
        try{
            return new FileWriter(new File(file));
        }
        catch(Exception e){
            throw new RuntimeException("Cannot obtain error log at: "+position);
        }
    }


    @Override
    public void addCommandLineOptions(ProcessMainContext context){
        Option processId    = OptionBuilder.withArgName( "file" )
                                .isRequired()
                                .hasArg()
                                .withDescription("Xml configuration with values to import")
                                .create("configuration");
        context.addOption(processId);
        addExtendedCommandLineOptions(context);
    }
}
