package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.eas.cia.ftp.service.FTPService;
import com.monsanto.eas.cia.ftp.service.FTPServiceImpl;
import com.monsanto.eas.cia.resource.ResourceManagerFactoryImpl;

public class BatchTransferProcessMain{

    public static final String PUT_COMMAND = "PUT";
    public static final String GET_COMMAND = "GET";

    public static void main(String ... arguments) throws Exception{
        FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
        String ftpLocationOnServer = arguments[0];
        String fileName = arguments[1];
        String absolutePathToLocalFile = ftpLocationOnServer + fileName;
        String ftpCommand = arguments[2];
        if (ftpCommand.equals(PUT_COMMAND)) {
            handleUpload(ftpService, absolutePathToLocalFile);
        } else if (ftpCommand.equals(GET_COMMAND)) {
            handleDownload(ftpService, fileName, absolutePathToLocalFile);
        }
    }

    private static void handleDownload(FTPService ftpService, String fileName, String absolutePathToLocalFile) throws Exception {
        ftpService.download(fileName, absolutePathToLocalFile, CIAConstants.FTP_REMOTE_SUB_DIR_INBOUND);
    }

    private static void handleUpload(FTPService ftpService, String absolutePathToLocalFile) throws Exception {
        ftpService.upload(absolutePathToLocalFile, CIAConstants.FTP_REMOTE_SUB_DIR_OUTBOUND);
    }

}
