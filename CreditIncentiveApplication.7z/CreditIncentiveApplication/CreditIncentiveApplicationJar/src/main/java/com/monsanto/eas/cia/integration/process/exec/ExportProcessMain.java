package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/01/2011
 * Time: 07:25:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportProcessMain extends ProcessMain{
    public ExportProcessMain(String contextId) {
        super(contextId);
    }

    public ExportProcessMain(String contextId, String applicationContextId) {
        super(contextId, applicationContextId);
    }

    public static void main(String ... arguments) throws Exception{
        ExportProcessMain exportProcessMain=new ExportProcessMain("export-process");
        if(exportProcessMain.commandLineInput(arguments)){            
            ProcessDefinition processDefinition = exportProcessMain.getProcessDefinition();
            processDefinition.execute(
                exportProcessMain.getOutputWriter(),
                exportProcessMain.getExportLayoutServiceId(),
                exportProcessMain.getErrorLog()
            );
        }                
    }

    public String getExportLayoutServiceId(){
        return context.getOptionValue("serviceId");
    }

    public Writer getOutputWriter() throws IOException {
        return new FileWriter(new File(context.getOptionValue("outputFile","output.dat")));
    }

    public Writer getErrorLog() throws IOException{
        return new FileWriter(new File(context.getOptionValue("errorLog","error.log")));
    }

    @Override
    public void addExtendedCommandLineOptions(ProcessMainContext context) {        
        Option serviceId    = OptionBuilder.withArgName( "beanId" )
                                .isRequired()
                                .hasArg()
                                .withDescription("The id of a bean implementing the interface ExportLayoutService")
                                .create("serviceId");
        context.addOption(serviceId);

        Option outputFile   = OptionBuilder.withArgName("file")
                                .hasArg()
                                .withDescription("Output of this process execution")
                                .create( "outputFile" );
        context.addOption(outputFile);

        Option errorLog      = OptionBuilder.withArgName("logFile")
                                .hasArg()
                                .withDescription("The error log")
                                .create( "errorLog" );
        context.addOption(errorLog);
    }
}
