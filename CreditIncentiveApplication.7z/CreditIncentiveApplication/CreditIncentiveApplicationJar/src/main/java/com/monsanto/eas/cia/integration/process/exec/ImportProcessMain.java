package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/01/2011
 * Time: 12:37:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessMain extends ProcessMain{
    public ImportProcessMain(String contextId) {
        super(contextId);
    }

    public ImportProcessMain(String contextId, String applicationContextId) {
        super(contextId, applicationContextId);
    }

    public static void main(String ... arguments) throws Exception{
        ImportProcessMain importProcessMain=new ImportProcessMain("import-process");
        if(importProcessMain.commandLineInput(arguments)){
            ProcessDefinition processDefinition=importProcessMain.getProcessDefinition();
            processDefinition.execute(
                importProcessMain.getInputReader(),
                importProcessMain.getImportLayoutServiceId(),
                importProcessMain.getErrorLog()
            );
        }
    }

    public String getImportLayoutServiceId(){
        return context.getOptionValue("serviceId");
    }

    public Reader getInputReader() throws IOException {
        return new FileReader(new File(context.getOptionValue("inputFile")));
    }

    public Writer getErrorLog() throws IOException{
        return new FileWriter(new File(context.getOptionValue("errorLog","error.log")));
    }

    @Override
    public void addExtendedCommandLineOptions(ProcessMainContext context) {

        Option serviceId    = OptionBuilder.withArgName( "beanId" )
                                .isRequired()
                                .hasArg()
                                .withDescription("The id of a bean implementing the interface ImportLayoutService")
                                .create("serviceId");
        context.addOption(serviceId);

        Option inputFile   = OptionBuilder.withArgName("file")
                                .isRequired()
                                .hasArg()
                                .withDescription("Input of this process execution")
                                .create( "inputFile" );
        context.addOption(inputFile);

        Option errorLog      = OptionBuilder.withArgName("logFile")
                                .hasArg()
                                .withDescription("The error log")
                                .create( "errorLog" );
        context.addOption(errorLog);
    }
}
