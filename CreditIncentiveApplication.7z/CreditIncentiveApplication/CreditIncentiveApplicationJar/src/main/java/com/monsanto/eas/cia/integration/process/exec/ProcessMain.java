package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.dbcp.BasicDataSource;

import java.util.ResourceBundle;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 04:02:16 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ProcessMain {

    public static final String DEFAULT_APPLICATION_CONTEXT="applicationContext-standalone.xml";
    private static final String BATCH_JOB_PROPERTIES = "standalone";
    private static final String ENV_D_PARAM = "env";
    private static final String LSI_FUNCTION = "lsi.function";

    protected ProcessMainContext context;

    public ProcessMain(String contextId) {
        this(contextId,DEFAULT_APPLICATION_CONTEXT);
    }

    private static String getDatabaseUrl() throws Exception {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".connection.url");
    }

    private static String getDatabaseUsername() throws Exception {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".username");
    }

    private static String getEnvironment() {
        String env = System.getProperty(ENV_D_PARAM);
        if (env == null) {
            env = System.getProperty(LSI_FUNCTION);
        }
        return env;
    }

    public ProcessMain(String contextId,String applicationContextId){
        this.context = new ProcessMainContext(contextId,applicationContextId);
        addCommandLineOptions(this.context);
        initializeDataSource(this.context);
    }

    private void initializeDataSource(ProcessMainContext context){
        // initialize datasource
        String databaseUrl = null;
        String userName = null;
        String encryptedPwd = null;
        try {
            databaseUrl = getDatabaseUrl();
            userName = getDatabaseUsername();
            encryptedPwd = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "cia", "CipherValue.hex", "KeyValue.hex");
        } catch (Exception e) {
            System.err.println("No database URL/username/pwd found. Please pass a -Denv param with value dev,test or prod. ");
            return;
        }

        BasicDataSource dataSource = context.getService("dataSource", BasicDataSource.class);
        System.out.println("url = " + databaseUrl);
        System.out.println("username = " + userName);
        dataSource.setUrl(databaseUrl);
        dataSource.setUsername(userName);
        dataSource.setPassword(encryptedPwd);
    }

    public ProcessMainContext getContext() {
        return context;
    }

    public ProcessDefinition getProcessDefinition(){
        return context.getServiceFromOptionName("processId",ProcessDefinition.class);
    }

    public boolean commandLineInput(String ... arguments){
        return context.commandLineInput(arguments);
    }

    public void addCommandLineOptions(ProcessMainContext context){
        Option processId    = OptionBuilder.withArgName( "beanId" )
                                .isRequired()
                                .hasArg()
                                .withDescription("The id of a bean implementing the interface ProcessDefinition")
                                .create("processId");
        context.addOption(processId);
        addExtendedCommandLineOptions(context);
    }

    public  void addExtendedCommandLineOptions(ProcessMainContext context){

    }
}
