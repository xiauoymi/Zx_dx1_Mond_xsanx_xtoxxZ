package com.monsanto.eas.cia.integration.process.exec;

import com.monsanto.eas.cia.util.CommandLineInput;
import org.apache.commons.cli.Option;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 03:38:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessMainContext {
    protected ApplicationContext    applicationContext;
    protected CommandLineInput      commandLineInput;

    public ProcessMainContext(String processMainName, String applicationContextId) {
        commandLineInput=new CommandLineInput(processMainName);
        applicationContext=createApplicationContext(applicationContextId);
    }

    protected ApplicationContext createApplicationContext(String applicationContextId){
        return new ClassPathXmlApplicationContext(applicationContextId);
    }

    public void addOption(Option option){
        commandLineInput.addOption(option);
    }

    public void clearOptions(){
        commandLineInput.clearOptions();
    }

    public boolean commandLineInput(String ... arguments){
        return commandLineInput.parseInput(arguments);
    }

    public String getOptionValue(String optionName){
        return getOptionValue(optionName,null);
    }

    public String getOptionValue(String optionName,String defaultValue){
        return commandLineInput.getOptionValue(optionName,defaultValue);
    }

    public <T> T getServiceFromOptionName(String optionName,Class<T> _class){
        return getService(getOptionValue(optionName),_class);
    }

    public <T> T getService(String serviceId, Class<T> _class){
        return (T)applicationContext.getBean(serviceId,_class);    
    }
}
