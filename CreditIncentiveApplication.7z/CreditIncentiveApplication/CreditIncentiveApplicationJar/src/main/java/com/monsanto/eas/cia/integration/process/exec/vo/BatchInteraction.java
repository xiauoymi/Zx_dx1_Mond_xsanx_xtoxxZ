package com.monsanto.eas.cia.integration.process.exec.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 06:54:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchInteraction extends FileInteraction {

    protected String fileSuffix;
    protected String errorLogSuffix;

    protected List<FileInteraction> fileInteractions =new ArrayList<FileInteraction>();

    public BatchInteraction() {
    }

    public List<FileInteraction> getFileInteractions() {
        return fileInteractions;
    }

    public String getErrorLogSuffix() {
        return errorLogSuffix;
    }

    public void setErrorLogSuffix(String errorLogSuffix) {
        this.errorLogSuffix = errorLogSuffix;
    }

    public String getFileSuffix() {
        return fileSuffix;
    }

    public void setFileSuffix(String fileSuffix) {
        this.fileSuffix = fileSuffix;
    }

    public void setFileInteractions(List<FileInteraction> fileInteractions) {
        this.fileInteractions = fileInteractions;
    }

    public void addFileInteraction(FileInteraction fileInteraction){
        if(fileInteraction!=null){
            fileInteractions.add(fileInteraction);
        }
    }
}
