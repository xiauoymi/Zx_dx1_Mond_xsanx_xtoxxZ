package com.monsanto.eas.cia.integration.process.exec.vo;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 07:24:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileInteraction {
    protected String processId;
    protected String serviceId;
    protected String fileDirectory;
    protected String errorLogDirectory;
    protected String fileName;
    protected String errorLog;


    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getErrorLogDirectory() {
        return errorLogDirectory;
    }

    public void setErrorLogDirectory(String errorLogDirectory) {
        this.errorLogDirectory = errorLogDirectory;
    }

    public String getFileDirectory() {
        return fileDirectory;
    }

    public void setFileDirectory(String fileDirectory) {
        this.fileDirectory = fileDirectory;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }
    
    public String getErrorLog() {
        return errorLog;
    }

    public void setErrorLog(String errorLog) {
        this.errorLog = errorLog;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
