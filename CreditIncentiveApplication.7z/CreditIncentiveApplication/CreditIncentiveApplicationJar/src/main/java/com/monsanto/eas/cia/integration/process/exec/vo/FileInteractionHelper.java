package com.monsanto.eas.cia.integration.process.exec.vo;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 07:45:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileInteractionHelper extends FileInteraction{
    protected BatchInteraction batchInteraction;
    protected FileInteraction fileInteraction;

    public FileInteractionHelper(BatchInteraction batchInteraction, FileInteraction fileInteraction) {
        this.batchInteraction = batchInteraction;
        this.fileInteraction = fileInteraction;
    }

    protected String getSuffixedName(String value,String suffix){
        if(suffix==null||suffix.trim().length()==0){
            return value;
        }
        suffix=suffix.trim();
        if(suffix.startsWith(".")){
            return value+suffix;
        }
        return value+"."+suffix;
    }

    @Override
    public String getErrorLog() {
        String errorLog= fileInteraction.getErrorLog();
        if(errorLog==null){
        	errorLog= fileInteraction.getFileName();
        }
        if(errorLog==null){
            errorLog=getServiceId();
        }
        if(errorLog==null){
        	return null;
        }
        File file=new File(getErrorLogDirectory(),getSuffixedName(errorLog,batchInteraction.getErrorLogSuffix()));
        return file.getAbsolutePath();
    }

    @Override
    public String getFileName() {
        String fileName= fileInteraction.getFileName();
        if(fileName==null){
            fileName=getServiceId();
        }
        if(fileName==null){
        	return null;
        }
        File file=new File(getFileDirectory(),getSuffixedName(fileName,batchInteraction.getFileSuffix()));
        return file.getAbsolutePath();
    }

    @Override
    public String getErrorLogDirectory() {
        String errorLogDirectory= fileInteraction.getErrorLogDirectory();
        if(errorLogDirectory==null){
            errorLogDirectory=batchInteraction.getErrorLogDirectory();
        }
        return errorLogDirectory;
    }

    @Override
    public String getFileDirectory() {
        String inputDirectory= fileInteraction.getFileDirectory();
        if(inputDirectory==null){
            inputDirectory=batchInteraction.getFileDirectory();
        }
        return inputDirectory;
    }

    @Override
    public String getProcessId() {
        String processId= fileInteraction.getProcessId();
        if(processId==null) {
            processId=batchInteraction.getProcessId();
        }
        return processId;        
    }

    @Override
    public String getServiceId() {
        String serviceId= fileInteraction.getServiceId();
        if(serviceId==null) {
            serviceId=batchInteraction.getServiceId();
        }
        return serviceId;
    }    

    @Override
    public void setErrorLog(String errorLog) {
        fileInteraction.setErrorLog(errorLog);
    }

    @Override
    public void setFileName(String fileName) {
        fileInteraction.setFileName(fileName);
    }

    @Override
    public void setErrorLogDirectory(String errorLogDirectory) {
        fileInteraction.setErrorLogDirectory(errorLogDirectory);
    }

    @Override
    public void setFileDirectory(String inputDirectory) {
        fileInteraction.setFileDirectory(inputDirectory);
    }

    @Override
    public void setProcessId(String processId) {
        fileInteraction.setProcessId(processId);
    }

    @Override
    public void setServiceId(String serviceId) {
        fileInteraction.setServiceId(serviceId);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
