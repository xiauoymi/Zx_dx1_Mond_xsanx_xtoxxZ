package com.monsanto.eas.cia.integration.process.stage;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;

import java.util.concurrent.CountDownLatch;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 09:09:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessStageWorker<T extends ProcessContext> implements Runnable{
    protected ProcessStage<T> processStage;
    protected T                 context;
    protected CountDownLatch doneSignal;
    public ProcessStageWorker(ProcessStage<T> processStage,T context, CountDownLatch doneSignal) {
        setProcessStage(processStage);
        setContext(context);
        setDoneSignal(doneSignal);
    }

    public void run(){
        getProcessStage().process(context);        
        if(getDoneSignal()!=null)
            getDoneSignal().countDown();
    }

    public ProcessStage<T> getProcessStage() {
        return processStage;
    }

    public void setProcessStage(ProcessStage<T> processStage) {
        this.processStage = new ReliableProcessStage<T>(processStage);
    }

    public T getContext() {
        return context;
    }

    public void setContext(T context) {
        this.context = context;
    }

    public CountDownLatch getDoneSignal() {
        return doneSignal;
    }

    public void setDoneSignal(CountDownLatch doneSignal) {
        this.doneSignal = doneSignal;
    }
}

