package com.monsanto.eas.cia.integration.process.stage;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.exception.ProcessStageException;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:54:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReliableProcessStage<T extends ProcessContext> implements ProcessStage<T> {

    protected ProcessStage<T> processStage;

    public ReliableProcessStage(ProcessStage<T> processStage) {
        setProcessStage(processStage);
    }

    public void process(T context) {        
        if(context==null||context.isInterrupted())return;
        if(processStage==null){
            try{
                throw new ProcessStageException();
            }
            catch(ProcessStageException pse){
                context.fireFatalException(pse);
                return;
            }
        }
        try{
            processStage.process(context);
        }
        catch(Exception e){
            context.fireException(e);
        }
    }

    public void setProcessStage(ProcessStage<T> processStage) {
        this.processStage = processStage;
    }

    public ProcessStage<T> getProcessStage() {
        return processStage;
    }
}
