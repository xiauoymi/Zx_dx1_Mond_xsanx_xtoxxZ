package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.format.RecordIterator;
import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIterator;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 19/02/2011
 * Time: 01:42:31 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("create-csv-record-iterator-stage")
public class CreateCsvRecordIteratorStage implements ProcessStage<ImportProcessContext> {
    @Autowired
    protected CsvReaderConfiguration csvReaderConfiguration;

    public void process(ImportProcessContext context) {
        RecordIterator iterator=null;
        if((iterator=context.getIterator())==null){
            iterator=new CsvRecordIterator(csvReaderConfiguration,context.getReader()).start();
            context.setIterator(iterator);
        }
    }

    public void setCsvReaderConfiguration(CsvReaderConfiguration csvReaderConfiguration) {
        this.csvReaderConfiguration = csvReaderConfiguration;
    }
}
