package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.format.RecordIterator;
import com.monsanto.eas.cia.integration.format.excel.ExcelReaderConfiguration;
import com.monsanto.eas.cia.integration.format.excel.ExcelRecordIterator;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 07:01:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("create-excel-record-iterator-stage")
public class CreateExcelRecordIteratorStage  implements ProcessStage<ImportProcessContext> {

    @Autowired
    protected ExcelReaderConfiguration excelReaderConfiguration;

    public void process(ImportProcessContext context) {
        InputStream inputStream=context.getInputStream();
        RecordIterator iterator=null;
        if((iterator=context.getIterator())==null){
            iterator=new ExcelRecordIterator(excelReaderConfiguration,inputStream).start();
            context.setIterator(iterator);
        }                                                          
    }

    public void setExcelReaderConfiguration(ExcelReaderConfiguration excelReaderConfiguration) {
        this.excelReaderConfiguration = excelReaderConfiguration;
    }
}
