package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.context.ExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 11:24:27 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("export-layout-execution-stage")
public class ExportLayoutServiceExecutionStage implements ProcessStage<ExportProcessContext> {
            
    public void process(ExportProcessContext context) {
        ExportLayoutService exportLayoutService =   context.getExportLayoutService();
        Object[]            entities            =   context.getEntities();
        Collection<Layout>  layouts             =   exportLayoutService.exportLayouts(entities);
        context.setLayoutType(ObjectUtils.getGenericType(exportLayoutService.getClass(),Layout.class));
        context.setLayouts(layouts);
    }
}
