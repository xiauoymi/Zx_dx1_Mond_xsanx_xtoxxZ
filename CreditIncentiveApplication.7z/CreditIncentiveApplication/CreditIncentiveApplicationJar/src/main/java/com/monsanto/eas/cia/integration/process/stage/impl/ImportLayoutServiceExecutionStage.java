package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:45:37 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("import-layout-service-execution")
public class ImportLayoutServiceExecutionStage implements ProcessStage<ImportProcessContext> {

    public void process(ImportProcessContext context) {
        ImportLayoutService importLayoutService =   context.getImportLayoutService();
        Layout              layout              =   context.getLayout();

        boolean emptyLine = false;
        Record abstractRecord = context.getAbstractRecord();
        if (abstractRecord.getClass() == CsvRecord.class) {
            CsvRecord tempCsvRecord = (CsvRecord) abstractRecord;
            emptyLine = isEmptyLine(tempCsvRecord.getFields());
        }
        if (!emptyLine) {
            try{
                importLayoutService.importLayout(layout);
                context.setExceptionFired(false);
            }
            catch(LayoutServiceException layoutServiceException){
                handleLayoutServiceException(context,layoutServiceException);
            }
            catch(Exception e){
                handleLayoutServiceException(context,LayoutServiceExceptionCode.EXCEPTION.get(e));
            }
        }
    }

    public void handleLayoutServiceException(ImportProcessContext context, LayoutServiceException layoutServiceException){
        layoutServiceException.setLayout(context.getLayout());
        layoutServiceException.setRecordNumber(context.getRecordNumber());
        context.fireException(layoutServiceException);
    }

    private boolean isEmptyLine(String[] tempFields) {
        boolean test = false;
        if (tempFields[0].equals("") && tempFields[1].equals("")) {
            test = true;
        }
        return test;
    }

}
