package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.exception.GenericTypeException;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.hibernate.validator.ClassValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 12:49:01 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("init-import-process")
public class InitImportProcessStage implements ProcessStage<ImportProcessContext> {

    @Autowired
    protected LayoutServiceLocator serviceLocator;
    
    public void process(ImportProcessContext context) {
        ImportLayoutService importLayoutService =   serviceLocator.lookupImportLayoutService(context.getServiceId());
        if(importLayoutService==null)
            throw new LayoutServiceLocatorException(null,context.getServiceId(),ImportLayoutService.class);

        Class<?>    importLayoutType            =   LayoutUtils.getLayoutGenericType(importLayoutService);
        if(importLayoutType==null){
            throw new GenericTypeException(importLayoutService.getClass());    
        }

        ClassValidator validator                =   new ClassValidator(importLayoutType, LayoutUtils.RESOURCE_BUNDLE);
        context.setImportLayoutService          (importLayoutService);
        context.setImportLayoutType             (importLayoutType);
        context.setValidator                    (validator);
    }

    public void setServiceLocator(LayoutServiceLocator serviceLocator) {
        this.serviceLocator = serviceLocator;
    }
}
