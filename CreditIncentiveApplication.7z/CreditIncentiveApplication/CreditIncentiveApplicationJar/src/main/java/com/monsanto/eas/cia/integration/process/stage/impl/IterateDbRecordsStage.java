package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.context.ExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 01:35:34 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("iterate-db-records-stage")
public class IterateDbRecordsStage implements ProcessStage<ExportProcessContext> {

    @Autowired
    protected CriteriaDao dao;

    protected int synchronizeOnNumberOfRecords =   20;

    public void process(ExportProcessContext context) {
        long recordNumber=context.getRecordNumber();
        ExportLayoutService exportLayoutService =   context.getExportLayoutService();
        ScrollableResults   scrollableResults   =   context.getScrollableResults();
        Object[] entities=null;
        try{

            if(scrollableResults==null){
                scrollableResults   =   dao.getScrollableResults(exportLayoutService, ScrollMode.FORWARD_ONLY);
                recordNumber        =   -1;
            }

            if(scrollableResults!=null){                
                synchronize(++recordNumber);
                if(scrollableResults.next()){
                    entities=scrollableResults.get();
                }
                else{                    
                    closeScrollableResults(scrollableResults);
                }
            }
        }
        catch(Exception e){
            context.fireFatalException(e);
        }
        
        context.setEntities(entities);
        context.setRecordNumber(recordNumber);
        context.setScrollableResults(scrollableResults);
    }

    public void synchronize(long numRecords){
        dao.synchronize(numRecords,synchronizeOnNumberOfRecords);
    }

    public void closeScrollableResults(ScrollableResults scrollableResults){
        try{
            scrollableResults.close();
        }catch(Exception e){}
    }

    public void setSynchronizeOnNumberOfRecords(int synchronizeOnNumberOfRecords) {
        synchronizeOnNumberOfRecords=Math.abs(synchronizeOnNumberOfRecords);
        synchronizeOnNumberOfRecords=synchronizeOnNumberOfRecords!=0?synchronizeOnNumberOfRecords:100;
        this.synchronizeOnNumberOfRecords = synchronizeOnNumberOfRecords;
    }

    public int getSynchronizeOnNumberOfRecords() {
        return synchronizeOnNumberOfRecords;
    }

    public void setDao(CriteriaDao dao) {
        this.dao = dao;
    }

    public CriteriaDao getDao() {
        return dao;
    }
}
