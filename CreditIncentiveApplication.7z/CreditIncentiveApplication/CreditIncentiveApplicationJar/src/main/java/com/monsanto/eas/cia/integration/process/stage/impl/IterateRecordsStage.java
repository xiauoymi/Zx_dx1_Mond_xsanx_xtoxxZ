package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.stereotype.Component;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:02:38 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("iterate-records")
public class IterateRecordsStage implements ProcessStage<ImportProcessContext> {
    public void process(ImportProcessContext context) {
        Iterator<Record> iterator=null;
        try{
            iterator=context.getIterator();
            Record abstractRecord=null;
            if(iterator.hasNext()) {
                abstractRecord  = iterator.next();
            }
            context.setAbstractRecord(abstractRecord);
        }
        catch(RuntimeException exception){            
            context.fireFatalException(exception);
        }
    }
}
