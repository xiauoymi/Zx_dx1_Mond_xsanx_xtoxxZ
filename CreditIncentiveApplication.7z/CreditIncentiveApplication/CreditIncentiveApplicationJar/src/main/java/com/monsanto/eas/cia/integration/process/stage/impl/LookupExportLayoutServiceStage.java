package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.context.ExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 01:17:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("lookup-export-layout-service-stage")
public class LookupExportLayoutServiceStage implements ProcessStage<ExportProcessContext> {
    @Autowired
    protected LayoutServiceLocator serviceLocator;

    public void process(ExportProcessContext context) {
        try{
            ExportLayoutService exportLayoutService =   serviceLocator.lookupExportLayoutService(context.getServiceId());
            context.setExportLayoutService(exportLayoutService);
        }
        catch(LayoutServiceLocatorException layoutServiceLocatorException){
            context.fireFatalException(layoutServiceLocatorException);
        }        
    }

    public void setServiceLocator(LayoutServiceLocator serviceLocator) {
        this.serviceLocator = serviceLocator;
    }
}
