package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:20:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("read-layout-from-abstract-record")
public class ReadLayoutFromAbstractRecordStage implements ProcessStage<ImportProcessContext> {
    public void process(ImportProcessContext context) {
        Record abstractRecord   =   context.getAbstractRecord();
        long   recordNumber             =   abstractRecord.getRecordNumber();
        context.setRecordNumber         (recordNumber);
        Class<?>    importLayoutType    =   context.getImportLayoutType();
        Layout      layout              =   (Layout)abstractRecord.toLayout(importLayoutType);
        context.setLayout(layout);                
    }
}
