package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.layout.exception.LayoutValidatorException;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.hibernate.validator.ClassValidator;
import org.hibernate.validator.InvalidValue;
import org.springframework.stereotype.Component;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 01:39:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Component("validate-layout")
public class ValidateLayoutStage implements ProcessStage<ImportProcessContext> {
    public void process(ImportProcessContext context) {
        Layout          layout          =   context.getLayout();
        ClassValidator  validator       =   context.getValidator();
        InvalidValue[]  invalidValues   =   validator.getInvalidValues(context.getLayout());

        boolean emptyLine = false;
        Record abstractRecord = context.getAbstractRecord();
        if (abstractRecord.getClass() == CsvRecord.class) {
            CsvRecord tempCsvRecord = (CsvRecord) abstractRecord;
            emptyLine = isEmptyLine(tempCsvRecord.getFields());
        }
        if (!emptyLine) {
            if(invalidValues!=null&&invalidValues.length>0){
                throw new LayoutValidatorException(layout,context.getRecordNumber(),invalidValues);
            }
        }
    }

    private boolean isEmptyLine(String[] tempFields) {
        boolean test = false;
        if (tempFields[0].equals("") && tempFields[1].equals("")) {
            test = true;
        }
        return test;
    }


}
