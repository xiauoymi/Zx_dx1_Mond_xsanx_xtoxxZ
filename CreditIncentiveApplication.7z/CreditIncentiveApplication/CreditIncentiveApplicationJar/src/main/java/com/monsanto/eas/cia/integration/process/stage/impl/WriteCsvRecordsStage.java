package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Writer;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/02/2011
 * Time: 12:01:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("write-csv-records-stage")
public class WriteCsvRecordsStage implements ProcessStage<CsvExportProcessContext> {
    @Autowired
    protected CsvWriterConfiguration csvWriterConfiguration;

    public void process(CsvExportProcessContext context) {
        CsvWriter csvWriter             =   context.getCsvWriter();
        Collection<Layout>  layouts     =   context.getLayouts();
        Object[]            entities    =   context.getEntities();

        try{
            if(csvWriter==null){
                Writer writer  =   context.getWriter();
                csvWriter       =   csvWriterConfiguration.createCsvWriter(writer);
                csvWriter.flush();
            }

            if(layouts!=null){
                for(Layout layout:layouts){
                    if(layout==null)continue;
                    String[] fields  =   csvWriterConfiguration.fromLayout(layout);
                    csvWriter.writeNext(fields);
                }
                layouts=null;
            }
            else if(entities==null){
                csvWriter.flush();
                csvWriter.close();
            }
        }
        catch(Exception e){
            context.fireFatalException(e);
        }
        context.setLayouts  (layouts);
        context.setCsvWriter(csvWriter);
    }

    public void setCsvWriterConfiguration(CsvWriterConfiguration csvWriterConfiguration) {
        this.csvWriterConfiguration = csvWriterConfiguration;
    }
}
