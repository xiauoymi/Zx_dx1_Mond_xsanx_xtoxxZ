package com.monsanto.eas.cia.integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.excel.CellType;
import com.monsanto.eas.cia.integration.format.excel.ExcelDocumentBuilder;
import com.monsanto.eas.cia.integration.format.excel.ExcelWriterConfiguration;
import com.monsanto.eas.cia.integration.process.context.ExcelExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 20/02/2011
 * Time: 07:09:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Component("write-excel-records-stage")
public class WriteExcelRecordsStage implements ProcessStage<ExcelExportProcessContext> {

    @Autowired
    protected ExcelWriterConfiguration excelWriteConfiguration;
    
    public void process(ExcelExportProcessContext context) {
        ExcelDocumentBuilder excelDocumentBuilder=context.getExcelDocumentBuilder();
        Collection<Layout> layouts     =   context.getLayouts();
        Object[]           entities    =   context.getEntities();
        try{
            if(excelDocumentBuilder==null){
                excelDocumentBuilder=excelWriteConfiguration.createExcelDocumentBuilder(excelWriteConfiguration.getDefaultSheetName());
                for(CellType cellType:CellType.values()){
                    cellType.declareCellStyle(excelWriteConfiguration,excelDocumentBuilder);                    
                }
                excelDocumentBuilder.createRow();
                excelWriteConfiguration.addHeaders(context.getLayoutType(),excelDocumentBuilder, LayoutUtils.RESOURCE_BUNDLE);
            }

            if(layouts!=null){
                for(Layout layout:layouts){
                    excelDocumentBuilder.createRow();
                    excelWriteConfiguration.addLayout(layout,excelDocumentBuilder);
                }
                layouts=null;
            }
            else if(entities==null){
                excelDocumentBuilder.saveDocument(context.getOutputStream());
            }
        }
        catch(Exception e){
            context.fireFatalException(e);
        }
        
        context.setExcelDocumentBuilder(excelDocumentBuilder);
        context.setLayouts  (layouts);
    }

    public void setExcelWriteConfiguration(ExcelWriterConfiguration excelWriteConfiguration) {
        this.excelWriteConfiguration = excelWriteConfiguration;
    }
}
