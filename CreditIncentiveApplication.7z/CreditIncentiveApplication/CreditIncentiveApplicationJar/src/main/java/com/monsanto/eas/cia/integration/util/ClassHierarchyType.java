package com.monsanto.eas.cia.integration.util;

import org.apache.commons.lang.ClassUtils;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 06:12:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class ClassHierarchyType implements Comparable<ClassHierarchyType>{
    public Class<?> type;
    public int priority;

    public ClassHierarchyType(Class<?> type) {
        if(type==null)
            throw new IllegalArgumentException();
        this.type = type;
        if(type==Object.class)
            priority=0;
        else{
            List<Class> interfaces= ClassUtils.getAllInterfaces(type);
            List<Class> classes=ClassUtils.getAllSuperclasses(type);
            priority=interfaces.size()>classes.size()?interfaces.size():classes.size();
        }
    }

    public Class<?> getType() {
        return type;
    }

    public int getPriority() {
        return priority;
    }

    public boolean canBeAssigned(ClassHierarchyType other){
        if(type==null)return false;
        return ClassUtils.isAssignable(other.type,this.type);
    }

    public boolean classCanBeAssigned(Class<?> _class){
        if(_class==null)return false;        
        return canBeAssigned(new ClassHierarchyType(_class));
    }

    public boolean equals(Object o){
        if(o instanceof ClassHierarchyType){
            return this.type==((ClassHierarchyType)o).type;
        }
        return false;
    }

    public int hashCode(){
        return this.type.hashCode();
    }

    public int compareTo(ClassHierarchyType other) {
        return other.priority-this.priority;
    }
}
