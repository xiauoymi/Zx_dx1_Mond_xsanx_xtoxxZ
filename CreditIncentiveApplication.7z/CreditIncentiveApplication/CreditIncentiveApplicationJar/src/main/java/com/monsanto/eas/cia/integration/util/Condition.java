package com.monsanto.eas.cia.integration.util;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 6/02/2011
 * Time: 10:41:00 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Condition<T> {
    public boolean evaluate(T argument);
}
