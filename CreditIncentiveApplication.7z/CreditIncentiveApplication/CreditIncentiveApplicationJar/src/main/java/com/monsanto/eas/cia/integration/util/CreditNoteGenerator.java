package com.monsanto.eas.cia.integration.util;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.monsanto.eas.cia.model.SapDistributor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: May 2, 2011
 * Time: 9:48:22 AM
 * To change this template use File | Settings | File Templates.
 */
@Service
public interface CreditNoteGenerator {
    void generatePDF(Document document,Long distributorId, Long programQuarterId, Long creditNoteId, Long taxReserveId) throws DocumentException, IOException;
}