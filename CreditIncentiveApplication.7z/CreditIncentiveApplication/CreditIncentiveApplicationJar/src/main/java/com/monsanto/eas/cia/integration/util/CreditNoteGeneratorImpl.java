package com.monsanto.eas.cia.integration.util;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.monsanto.eas.cia.dao.*;
import com.monsanto.eas.cia.model.CnPerDistributorView;
import com.monsanto.eas.cia.model.CreditNote;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.model.TaxReserve;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
@Transactional(readOnly = true, timeout = 600)
public class CreditNoteGeneratorImpl implements CreditNoteGenerator {

    public static final Logger LOGGER = Logger.getLogger(CreditNoteGeneratorImpl.class);

    @Autowired
    private CreditNoteDao creditNoteDao;

    @Autowired
    private TaxReserveDao taxReserveDao;

    @Autowired
    private SalesQtrDlrDistViewDao salesQtrDlrDistViewDao;

    @Autowired
    private CnPerDistributorViewDao cnPerDistributorViewDao;

    @Autowired
    private ProgramQuarterDao programQuarterDao;

    //private Collection<SapDistributor> distributors;

    public void generatePDF(Document document, Long distributorId, Long programQuarterId, Long creditNoteId, Long taxReserveId) throws DocumentException, IOException {

        OutputStream generatedFile = new ByteArrayOutputStream();

        CnPerDistributorView creditNoteView = cnPerDistributorViewDao.findByDistributorProgramQuarterAndCreditNote(
                distributorId, programQuarterId, creditNoteId);

        CreditNote creditNote = null;
        if (creditNoteId != null) {
            creditNote = creditNoteDao.findByPrimaryKey(CreditNote.class, creditNoteId.intValue());
        }
        if (creditNote == null) {
            BigDecimal[] incentiveCalculations = salesQtrDlrDistViewDao.
                    findIncentiveDebtByDistQuarterYearGroupedByDist(
                            distributorId, programQuarterId);
            BigDecimal accumulatedIncentive = incentiveCalculations[0];
            BigDecimal closingIncentive = incentiveCalculations[1];
            BigDecimal fixedIncentive = incentiveCalculations[2];
            BigDecimal creditNoteAmount = accumulatedIncentive.subtract(fixedIncentive);
            LOGGER.debug("accumulatedIncentive "+accumulatedIncentive);
            LOGGER.debug("closingIncentive "+closingIncentive);
            LOGGER.debug("fixedIncentive "+fixedIncentive);
            LOGGER.debug("creditNoteAmount "+creditNoteAmount);
            creditNote = new CreditNote();
            creditNote.setAmount(creditNoteAmount);
            if (taxReserveId != null) {
                TaxReserve taxReserve = taxReserveDao.findByPrimaryKey(TaxReserve.class, taxReserveId.intValue());
                creditNote.setTaxReserve(taxReserve);
            }
        }
        document.setPageSize(PageSize.A4.rotate());
        document.setMargins(10, 10, 10, 10);
        document.open();

        Font font = new Font(Font.HELVETICA, 8);
        Font boldFont = new Font(Font.HELVETICA, 8, Font.BOLD);

        PdfPTable headerTable = new PdfPTable(1);

        headerTable.setTotalWidth(800);
        headerTable.setLockedWidth(true);

        PdfPCell headerFirstLineCell = new PdfPCell(new Paragraph("MONSANTO COMMERCIAL, S.A. DE C.V.", boldFont));
        headerFirstLineCell.setBorder(PdfPCell.NO_BORDER);
        headerFirstLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerTable.addCell(headerFirstLineCell);

        PdfPCell headerSecondLineCell = new PdfPCell(new Paragraph("DOCUMENT REQUEST", boldFont));
        headerSecondLineCell.setBorder(PdfPCell.NO_BORDER);
        headerSecondLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerTable.addCell(headerSecondLineCell);
        headerTable.setSpacingAfter(10f);
        headerTable.setSpacingBefore(10f);
        document.add(headerTable);

        PdfPTable summaryTable = getSummaryTable(creditNoteView);
        summaryTable.setSpacingAfter(10f);
        summaryTable.setSpacingBefore(10f);
        document.add(summaryTable);
        PdfPTable conceptTable = getConceptTable();
        conceptTable.setSpacingAfter(10f);
        conceptTable.setSpacingBefore(10f);
        document.add(conceptTable);

        PdfPTable detailsTable = getDetailsTable(creditNoteView, creditNote);
        detailsTable.setSpacingAfter(10f);
        detailsTable.setSpacingBefore(10f);
        document.add(detailsTable);

        PdfPTable creditNotesDetails = getCreditNotesTable(creditNote);
        creditNotesDetails.setSpacingAfter(10f);
        creditNotesDetails.setSpacingBefore(10f);
        document.add(creditNotesDetails);

        PdfPTable reserveTable = getReserveTable(creditNote);
        reserveTable.setSpacingAfter(10f);
        reserveTable.setSpacingBefore(10f);
        document.add(reserveTable);

        PdfPTable requestedTable = getRequestedTable();
        requestedTable.setSpacingAfter(10f);
        requestedTable.setSpacingBefore(10f);
        document.add(requestedTable);
        //}
        document.close();
    }


    public PdfPTable getSummaryTable(CnPerDistributorView cnPerDistributorView) {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable summaryTable = new PdfPTable(11);

        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setFixedHeight(5);

        PdfPCell blankRowCell = new PdfPCell();
        blankRowCell.setBorder(PdfPCell.NO_BORDER);
        blankRowCell.setFixedHeight(5);
        blankRowCell.setColspan(11);

        summaryTable.addCell(blankCell);

        addNameValuePair(summaryTable, "DEBIT MEMO", "", font);
        addNameValuePair(summaryTable, "CREDIT NOTE", "x", font);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);
        addNameValuePair(summaryTable, "FOLIO",
                cnPerDistributorView.getCreditNoteId() != null ?
                        cnPerDistributorView.getCreditNoteId().toString() : "", font);

        summaryTable.addCell(blankRowCell);

        summaryTable.addCell(blankCell);
        addNameValuePair(summaryTable, "PESOS", "X", font);
        addNameValuePair(summaryTable, "USD", "", font);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);
        Calendar instance = Calendar.getInstance();
        Date date = instance.getTime();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String s = simpleDateFormat.format(date);
        addNameValuePair(summaryTable, "DATE", s, font);

        summaryTable.addCell(blankRowCell);

        //addNameValuePair(summaryTable, "Client No.", distributor.getSapDistributor().getCode(), font);
        addNameValuePair(summaryTable, "Client No.", cnPerDistributorView.getCode(), font);
        summaryTable.addCell(blankCell);

        PdfPCell debitMemoLabel = new PdfPCell(new Paragraph("DISTRIBUTOR", font));
        debitMemoLabel.setBorder(PdfPCell.NO_BORDER);
        debitMemoLabel.setHorizontalAlignment(Element.ALIGN_CENTER);
        summaryTable.addCell(debitMemoLabel);

        PdfPCell debitMemoValue = new PdfPCell(
                new Paragraph(cnPerDistributorView.getDistributorName(), font));
        debitMemoValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        debitMemoValue.setColspan(7);
        summaryTable.addCell(debitMemoValue);

        summaryTable.addCell(blankRowCell);


        //TODO JAJU provide Region
        //addNameValuePair(summaryTable, "Area", distributor.getRegion().getDescription(), font);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);

        addNameValuePair(summaryTable, "Program Year", "FY"
                + String.valueOf(cnPerDistributorView.getProgramYear()).substring(0, 2), font);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);
        summaryTable.addCell(blankCell);

        return summaryTable;
    }

    private void addNameValuePair(PdfPTable summaryTable, String name, String value, Font font) {
        PdfPCell debitMemoLabel = new PdfPCell(new Paragraph(name, font));
        debitMemoLabel.setBorder(PdfPCell.NO_BORDER);
        debitMemoLabel.setHorizontalAlignment(Element.ALIGN_CENTER);
        if (name != null && (name.equalsIgnoreCase("FOLIO") || name.equalsIgnoreCase("DATE"))) {
            debitMemoLabel.setColspan(3);
        }
        summaryTable.addCell(debitMemoLabel);

        PdfPCell debitMemoValue = new PdfPCell(new Paragraph(value, font));
        debitMemoValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        summaryTable.addCell(debitMemoValue);
    }

    public PdfPTable getConceptTable() {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable conceptTable = new PdfPTable(11);

        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setFixedHeight(5);

        PdfPCell blankRowCell = new PdfPCell();
        blankRowCell.setBorder(PdfPCell.NO_BORDER);
        blankRowCell.setFixedHeight(5);
        blankRowCell.setColspan(11);

        PdfPCell conceptCell = new PdfPCell(new Paragraph("CONCEPT", font));    //TODO INCLUIR TITULO DE LA RESEVRA
        conceptCell.setFixedHeight(10);
        conceptCell.setColspan(9);
        conceptCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        conceptTable.addCell(conceptCell);

        PdfPCell importCell = new PdfPCell(new Paragraph("IMPORT", font));
        importCell.setFixedHeight(10);
        importCell.setColspan(2);
        importCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        conceptTable.addCell(importCell);

        conceptTable.addCell(blankCell);


        return conceptTable;
    }

    public PdfPTable getDetailsTable(CnPerDistributorView cnPerDistributorView, CreditNote creditNote) {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable detailsTable = new PdfPTable(11);

        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setFixedHeight(5);

        addBlankCellsToDetail(detailsTable);

        addIncentiveDetails(font, detailsTable, "DISTRIBUTORS LOCALES - INCENTIVO BONO NUEVAS METAS", "");
        NumberFormat nf = new DecimalFormat("$ #,##0.00");
        ProgramQuarter programQuarter = programQuarterDao.findByPrimaryKey(
                ProgramQuarter.class, cnPerDistributorView.getProgramQuarterId().intValue());
        SimpleDateFormat sdf = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy ", new Locale("es", "MX"));
        LOGGER.debug(creditNote.getAmount());
        addIncentiveDetails(font, detailsTable, "PERIOD: From " +
                sdf.format(programQuarter.getQuarterStart()) + " To " +
                sdf.format(programQuarter.getQuarterEnd()), nf.format(creditNote.getAmount()));
        //TODO JAJU provide Region
        //addIncentiveDetails(font, detailsTable, distributor.getRegion().getDescription(), "");
        addBlankCellsToDetail(detailsTable);
        addBlankCellsToDetail(detailsTable);
        addBlankCellsToDetail(detailsTable);
        addBlankCellsToDetail(detailsTable);

        PdfPCell tocalCell = new PdfPCell(new Paragraph("TOTAL", font));
        tocalCell.setFixedHeight(10);
        tocalCell.setColspan(9);
        tocalCell.setBorder(PdfPCell.NO_BORDER);
        tocalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        detailsTable.addCell(tocalCell);

        PdfPCell totalValueCell = new PdfPCell(new Paragraph(nf.format(creditNote.getAmount()), font));
        totalValueCell.setFixedHeight(10);
        totalValueCell.setColspan(2);
        totalValueCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        detailsTable.addCell(totalValueCell);
        return detailsTable;
    }

    public PdfPTable getCreditNotesTable(CreditNote creditNote) {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable creditNotesDetailsTable = new PdfPTable(11);

        PdfPCell materialCell = new PdfPCell(new Paragraph("MATERIAL:", font));
        materialCell.setFixedHeight(10);
        materialCell.setColspan(2);
        materialCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        creditNotesDetailsTable.addCell(materialCell);

        PdfPCell materialNumber = new PdfPCell(
                new Paragraph(creditNote.getTaxReserve() != null ?
                        creditNote.getTaxReserve().getMaterial() : "", font));
        materialNumber.setFixedHeight(10);
        materialNumber.setColspan(7);
        materialNumber.setHorizontalAlignment(Element.ALIGN_CENTER);
        creditNotesDetailsTable.addCell(materialNumber);

        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setColspan(2);
        blankCell.setFixedHeight(5);
        creditNotesDetailsTable.addCell(blankCell);

        PdfPCell reasonForRequest = new PdfPCell(new Paragraph("REASON FOR REQUEST:", font));
        reasonForRequest.setFixedHeight(10);
        reasonForRequest.setColspan(2);
        reasonForRequest.setHorizontalAlignment(Element.ALIGN_LEFT);
        creditNotesDetailsTable.addCell(reasonForRequest);

        PdfPCell reasonForRequestValue = new PdfPCell(
                new Paragraph(creditNote.getTaxReserve() != null ?
                        creditNote.getTaxReserve().getPurpose() : "", font));
        reasonForRequestValue.setFixedHeight(10);
        reasonForRequestValue.setColspan(2);
        reasonForRequestValue.setHorizontalAlignment(Element.ALIGN_LEFT);
        creditNotesDetailsTable.addCell(reasonForRequestValue);


        PdfPCell position = new PdfPCell(new Paragraph("Posicion:", font));
        position.setFixedHeight(10);
        position.setColspan(2);
        position.setHorizontalAlignment(Element.ALIGN_LEFT);
        creditNotesDetailsTable.addCell(position);


        PdfPCell positionValue = new PdfPCell(
                new Paragraph(creditNote.getTaxReserve() != null ?
                        creditNote.getTaxReserve().getPosition() : "", font));
        positionValue.setFixedHeight(10);
        positionValue.setColspan(3);
        positionValue.setHorizontalAlignment(Element.ALIGN_LEFT);
        creditNotesDetailsTable.addCell(positionValue);

        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setColspan(2);
        blankCell.setFixedHeight(5);
        creditNotesDetailsTable.addCell(blankCell);


        return creditNotesDetailsTable;
    }

    public PdfPTable getReserveTable(CreditNote creditNote) {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable reserveTable = new PdfPTable(11);

        PdfPCell materialCell = new PdfPCell(new Paragraph("RESERVE AFFECTED:", font));
        materialCell.setFixedHeight(10);
        materialCell.setColspan(2);
        materialCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        reserveTable.addCell(materialCell);

        PdfPCell materialNumber = new PdfPCell(
                new Paragraph(creditNote.getTaxReserve() != null ?
                        creditNote.getTaxReserve().getProgramName() : "", new Font(Font.HELVETICA, 7)));
        materialNumber.setFixedHeight(10);
        materialNumber.setColspan(2);
        materialNumber.setHorizontalAlignment(Element.ALIGN_LEFT);
        reserveTable.addCell(materialNumber);

        PdfPCell materialNumberValue = new PdfPCell(
                new Paragraph(creditNote.getTaxReserve() != null ?
                        creditNote.getTaxReserve().getAccountNumber() : "", font));
        materialNumberValue.setFixedHeight(10);
        materialNumberValue.setColspan(2);
        materialNumberValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        reserveTable.addCell(materialNumberValue);

        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setColspan(5);
        blankCell.setFixedHeight(5);
        reserveTable.addCell(blankCell);

        return reserveTable;
    }

    public PdfPTable getRequestedTable() {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable requestedTable = new PdfPTable(6);

        PdfPCell requestedTo = new PdfPCell(new Paragraph("Requested TO", font));
        requestedTo.setFixedHeight(10);
        requestedTo.setColspan(2);
        requestedTo.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(requestedTo);

        PdfPCell requestedBy = new PdfPCell(new Paragraph("Requested By", font));
        requestedBy.setFixedHeight(10);
        requestedBy.setColspan(2);
        requestedBy.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(requestedBy);

        PdfPCell authorize = new PdfPCell(new Paragraph("AUTHORIZE", font));
        authorize.setFixedHeight(10);
        authorize.setColspan(2);
        authorize.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(authorize);

        PdfPCell requestedToValue = new PdfPCell(new Paragraph("*********", font));
        requestedToValue.setFixedHeight(10);
        requestedToValue.setColspan(2);
        requestedToValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(requestedToValue);

        PdfPCell requestedByValue = new PdfPCell(new Paragraph("*********", font));
        requestedByValue.setFixedHeight(10);
        requestedByValue.setColspan(2);
        requestedByValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(requestedByValue);

        PdfPCell authorizeValue = new PdfPCell(new Paragraph("*****", font));
        authorizeValue.setFixedHeight(10);
        authorizeValue.setColspan(2);
        authorizeValue.setHorizontalAlignment(Element.ALIGN_CENTER);
        requestedTable.addCell(authorizeValue);
        return requestedTable;
    }

    private void addIncentiveDetails(Font font, PdfPTable detailsTable, String programName, String value) {
        PdfPCell conceptCell = new PdfPCell(new Paragraph(programName, font));
        conceptCell.setFixedHeight(10);
        conceptCell.setColspan(9);
        conceptCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        detailsTable.addCell(conceptCell);

        PdfPCell importCell = new PdfPCell(new Paragraph(value, font));
        importCell.setFixedHeight(10);
        importCell.setColspan(2);
        importCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        detailsTable.addCell(importCell);
    }

    private void addBlankCellsToDetail(PdfPTable detailsTable) {
        PdfPCell blankRowCellOne = new PdfPCell();
        blankRowCellOne.setFixedHeight(10);
        blankRowCellOne.setColspan(9);
        detailsTable.addCell(blankRowCellOne);

        PdfPCell blankRowCellTwo = new PdfPCell();
        blankRowCellTwo.setFixedHeight(10);
        blankRowCellTwo.setColspan(2);
        detailsTable.addCell(blankRowCellTwo);
    }

    private java.util.List getMonthList(String startMonth, String endMonth) {
        boolean addcumonth = false;
        java.util.List<String> monthComList = new ArrayList<String>();
        monthComList.add("Jan");
        monthComList.add("Feb");
        monthComList.add("Mar");
        monthComList.add("Apr");
        monthComList.add("Jun");
        monthComList.add("Jul");
        monthComList.add("Aug");
        monthComList.add("Sep");
        monthComList.add("Oct");
        monthComList.add("Nov");
        monthComList.add("Dec");

        java.util.List monthList = new ArrayList();
        if (startMonth.equalsIgnoreCase(endMonth)) {
            monthList.add(startMonth.toUpperCase());
            return monthList;
        }
        else {
            Iterator monthIterator = monthComList.iterator();
            while (monthIterator.hasNext()) {
                String cumonth = (String) monthIterator.next();
                if (startMonth.equalsIgnoreCase(cumonth) || addcumonth) {
                    addcumonth = true;
                    monthList.add(cumonth.toUpperCase());
                    if (endMonth.equalsIgnoreCase(cumonth)) {
                        addcumonth = false;
                    }
                }

            }
        }
        return monthList;
    }
}
