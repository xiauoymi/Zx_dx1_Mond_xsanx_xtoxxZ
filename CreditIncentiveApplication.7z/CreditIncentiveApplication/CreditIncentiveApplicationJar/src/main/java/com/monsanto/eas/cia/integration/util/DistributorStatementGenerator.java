package com.monsanto.eas.cia.integration.util;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.monsanto.eas.cia.model.SapDistributor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: May 9, 2011
 * Time: 4:50:12 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public interface DistributorStatementGenerator {
    void generatePDF(Document document, String fromMonth, String year, Collection<SapDistributor> distributors) throws DocumentException, IOException;
    OutputStream getGeneratedPdf(Document document, String fromMonth, String year, Collection<SapDistributor> distributors) throws DocumentException, IOException;
}