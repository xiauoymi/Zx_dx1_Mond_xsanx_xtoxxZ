package com.monsanto.eas.cia.integration.util;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.eas.cia.dao.CreditNoteDao;
import com.monsanto.eas.cia.dao.DistributorCnDao;
import com.monsanto.eas.cia.dao.LdSalesDao;
import com.monsanto.eas.cia.dao.LdSalesPerQuarterDao;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.service.DistributorService;
import com.monsanto.eas.cia.CiaConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.lang.System;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

@Service
@Transactional(readOnly = true, timeout = 600)
public class DistributorStatementGeneratorImpl implements DistributorStatementGenerator {

    //@Autowired
    //private DistributorService distributorService;

    @Autowired
    private DistributorCnDao distributorCnDao;

    //@Autowired
    //private CreditNoteDao creditNoteDao;

    @Autowired
    private LdSalesDao ldSalesDao;

    @Autowired
    private LdSalesPerQuarterDao ldSalesPerQuarterDao;

    private OutputStream generatedFile;



    private String fromMonth;
    private String year;
    private SapDistributor distributor;
    private Collection<SapDistributor> distributors;
    private CreditNote creditNote;
    private Double totalIncentive = 0.0;
    private Collection<LdSales> ldSalesCollection;
    private PdfPTable localDealerSales;

    public void generatePDF(Document document, String fromMonth, String year, Collection<SapDistributor> distributors) throws DocumentException, IOException {
        this.fromMonth = fromMonth;
        this.year = year;        
        this.distributors = distributors;
        Iterator<SapDistributor> distributorIterator = distributors.iterator();
        generatedFile = new ByteArrayOutputStream();

        PdfWriter wr = PdfWriter.getInstance(document, generatedFile);
        document.setPageSize(PageSize.A4.rotate());
        document.setMargins(10, 10, 10, 10);
        document.open();
        
        while (distributorIterator.hasNext()) {
            distributor = distributorIterator.next();
            Collection<DistributorCnView> distributorCnViewCollection = distributorCnDao.lookupAllDistributorsSalesForYearMonth(Integer.toString(distributor.getId()), Integer.parseInt(year), fromMonth);
            DistributorCnView distributorCnView = null;
            Iterator<DistributorCnView> iterator = distributorCnViewCollection.iterator();
            if (iterator.hasNext()) {
                distributorCnView = iterator.next();
            }
            //creditNote = creditNoteDao.lookupCreditNoteWithId(distributorCnView.getCreditNoteId());

            ldSalesCollection = ldSalesDao.lookupSalesForDistributorYearMonth(distributor.getId().toString(), year, fromMonth);


            Font font = new Font(Font.HELVETICA, 8);
            Font boldFont = new Font(Font.HELVETICA, 8, Font.BOLD);

            PdfPTable headerTable = new PdfPTable(1);

            headerTable.setTotalWidth(800);
            headerTable.setLockedWidth(true);
            //TODO AGREGAR AL TITULO PROGRAMA EN CURSO.
            PdfPCell headerFirstLineCell = new PdfPCell(new Paragraph("STATEMENT DISTRIBUTOR PROGRAM ", boldFont));
            headerFirstLineCell.setBorder(PdfPCell.NO_BORDER);
            headerFirstLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headerTable.addCell(headerFirstLineCell);

            PdfPCell headerSecondLineCell = new PdfPCell(new Paragraph("PERIOD", boldFont));
            headerSecondLineCell.setBorder(PdfPCell.NO_BORDER);
            headerSecondLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headerTable.addCell(headerSecondLineCell);
            headerTable.setSpacingAfter(10f);
            headerTable.setSpacingBefore(10f);

            PdfPCell headerDistributorNameCell = new PdfPCell(new Paragraph(distributor.getDescription(), boldFont));
            headerDistributorNameCell.setBorder(PdfPCell.NO_BORDER);
            headerDistributorNameCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headerTable.addCell(headerDistributorNameCell);
            headerTable.setSpacingAfter(10f);
            headerTable.setSpacingBefore(10f);
            document.add(headerTable);
                        
            PdfPTable summaryTable = getLDDetailsTable();
            summaryTable.setSpacingAfter(10f);
            summaryTable.setSpacingBefore(10f);
            document.add(summaryTable);
            PdfPTable pdfPTable = getLocalDealerSales();
            document.add(pdfPTable);
        }
        document.close();
    }

    public OutputStream getGeneratedPdf(Document document, String fromMonth, String year, Collection<SapDistributor> distributors) throws DocumentException, IOException {
        generatePDF(document, fromMonth, year, distributors);
        return generatedFile;
    }

    public PdfPTable getLDDetailsTable() {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable summaryTable = new PdfPTable(14);

        addCell(font, summaryTable, CiaConstants.HEADER_TERRITORY);
        addCell(font, summaryTable, CiaConstants.HEADER_KEY_AGMT);
        addCell(font, summaryTable, CiaConstants.HEADER_LOCAL_DEALER);
        addCell(font, summaryTable, CiaConstants.HEADER_COMPANY);
        addCell(font, summaryTable, CiaConstants.HEADER_MAX_TGT);
        addCell(font, summaryTable, CiaConstants.HEADER_MIN_TGT);
        addCell(font, summaryTable, CiaConstants.HEADER_PRODUCT);
        addCell(font, summaryTable, CiaConstants.HEADER_PRESENTATION);
        addCell(font, summaryTable, CiaConstants.HEADER_LT_ENV);
        addCell(font, summaryTable, CiaConstants.HEADER_TOTAL_VOL);
        addCell(font, summaryTable, CiaConstants.HEADER_PERC_INCENTIVE);
        addCell(font, summaryTable, CiaConstants.HEADER_INCENTIVE);
        addCell(font, summaryTable, CiaConstants.HEADER_CREDIT_APP_NOTE);
        addCell(font, summaryTable, CiaConstants.HEADER_CONCEPT);

        return summaryTable;
    }

    private void addCell(Font font, PdfPTable summaryTable, String s) {
        PdfPCell debitMemoLabel = new PdfPCell(new Paragraph(s, font));
        debitMemoLabel.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.LEFT|Rectangle.RIGHT);
        debitMemoLabel.setHorizontalAlignment(Element.ALIGN_CENTER);
        summaryTable.addCell(debitMemoLabel);
    }


    public PdfPTable getLocalDealerSales() {
        Font font = new Font(Font.HELVETICA, 8);
        PdfPTable summaryTable = new PdfPTable(14);
        Iterator<LdSales> salesIterator = ldSalesCollection.iterator();
        boolean isLdDistributorFound = Boolean.TRUE;
        boolean isLocalDealerFound = Boolean.TRUE;
        boolean isSubregionFound = Boolean.TRUE;
        boolean isProgramYearFound = Boolean.TRUE;
        boolean isLdIncentiveFound = Boolean.TRUE;
        boolean isProductLineFound = Boolean.TRUE;
        boolean isSapProductFound = Boolean.TRUE;
        boolean isLtConversionFactorFound = Boolean.TRUE;
        boolean isSalesPerQuarterFound = Boolean.TRUE;

        while (salesIterator.hasNext()) {
            LdSales ldSales = salesIterator.next();
            LocalDealer dealer = ldSales.getLdDist().getLocalDealer();
            LdProgramYear programYear = getProgramYear(dealer);
            LdIncentive ldIncentive = getIncentive(dealer, ldSales.getSalesDate());
            ProductLine productLine = ldSales.getProductLine();

            isLocalDealerFound = (isLocalDealerFound && dealer != null);
            isProgramYearFound = (isProgramYearFound && programYear != null);
            isLdIncentiveFound = (isLdIncentiveFound && ldIncentive != null);
            isLdDistributorFound = (isLdDistributorFound && ldSales.getLdDist() != null);
            isSubregionFound = (isSubregionFound && isLdDistributorFound && dealer.getSubRegion() != null);
            isProductLineFound = (isProductLineFound && productLine != null);

            if (isLdDistributorFound) {
                if (isLocalDealerFound) {
                    if (isSubregionFound) {
                        addCell(font, summaryTable, dealer.getSubRegion().getDescription());
                    } else {
                        addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                    }
                    addCell(font, summaryTable, dealer.getAgreementNumber() != null ? dealer.getAgreementNumber() : CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, dealer.getName() != null ? dealer.getName() : CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, dealer.getRfc() != null ? dealer.getRfc() : CiaConstants.NOT_AVAILABLE_INFO);
                }
                if (isProgramYearFound) {
                    addCell(font, summaryTable, programYear.getMaxTarget().toString() != null ? programYear.getMaxTarget().toString() : CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, programYear.getMinTarget().toString() != null ? programYear.getMinTarget().toString() : CiaConstants.NOT_AVAILABLE_INFO);
                } else {
                    addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                }
            }

            if (isProductLineFound) {
                SapProduct sapProduct = productLine.getSapProduct();
                isSapProductFound = (isSapProductFound && sapProduct != null);
                if (isSapProductFound) {
                    addCell(font, summaryTable, sapProduct.getDescription() != null ? sapProduct.getDescription() : CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, sapProduct.getDescription() != null ? sapProduct.getDescription() : CiaConstants.NOT_AVAILABLE_INFO);
                } else {
                    addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                    addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                }
                //addCell(font, summaryTable, productLine.getLtConversionFactor().toString() != null ? productLine.getLtConversionFactor().toString() : CiaConstants.NOT_AVAILABLE_INFO);
                addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
            }

            addCell(font, summaryTable, ldSales.getVolumeToIncentive().toString());

            if (isLocalDealerFound && isLdIncentiveFound) {
                ProgramQuarter programQuarter = ldIncentive.getProgramQuarter();
                if (programQuarter != null) {
                    LdSalesPerQuarter ldSalesPerQuarter = ldSalesPerQuarterDao.lookupLdSalesPerQuarterByLocalDealer(dealer.getId().toString(), ldIncentive.getProgramQuarter().getId().toString());
                    isSalesPerQuarterFound = (isSalesPerQuarterFound && ldSalesPerQuarter != null);

                    if (isSalesPerQuarterFound) {
                        if (ldSalesPerQuarter.getInventivePct() != null) {
                            addCell(font, summaryTable, ldSalesPerQuarter.getInventivePct().toString());
                            addCell(font, summaryTable, String.valueOf(ldSalesPerQuarter.getInventivePct() * ldSales.getVolumeToIncentive() * ldSales.getPrice()));
                        } else {
                            addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                            addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                        }
                    }
                }
            } else {
                addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
                addCell(font, summaryTable, CiaConstants.NOT_AVAILABLE_INFO);
            }


            addCell(font, summaryTable, "credit application note");
            addCell(font, summaryTable, "concept");
        }
        return summaryTable;
    }

    private LdIncentive getIncentive(LocalDealer dealer, Date salesDate) {
        LdIncentive ldIncentiveResult = null;
        if (dealer != null) {
            Collection<LdIncentive> incentiveCollection = dealer.getIncentives();
            if (incentiveCollection != null) {
                Iterator<LdIncentive> incentiveIterator = incentiveCollection.iterator();
                while (incentiveIterator.hasNext()) {
                    LdIncentive ldIncentive = incentiveIterator.next();
                    if (ldIncentive != null) {
                        Date quarterEnd = ldIncentive.getProgramQuarter().getQuarterEnd();
                        Date quarterStart = ldIncentive.getProgramQuarter().getQuarterStart();
                        if (salesDate.after(quarterStart) && salesDate.before(quarterEnd)) {
                            ldIncentiveResult = ldIncentive;
                        }
                    }
                }
            }
        }
        return ldIncentiveResult;
    }


    public LdProgramYear getProgramYear(LocalDealer localDealer) {
        LdProgramYear ldProgramYr = null;

        if (localDealer != null) {
            if (localDealer.getProgramYears() != null) {
                Iterator<LdProgramYear> ldProgramYearIterator = localDealer.getProgramYears().iterator();
                while (ldProgramYearIterator.hasNext()) {
                    LdProgramYear programYear = ldProgramYearIterator.next();
                    if (programYear != null && programYear.getYear().getYear() == Integer.parseInt(year)) {
                        ldProgramYr = programYear;
                    }
                }
            }
        }
        return ldProgramYr;
    }
}
