package com.monsanto.eas.cia.integration.util;


import com.monsanto.eas.cia.vo.LocalDealerStatementRecordVO;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 25/10/12
 * Time: 07:39 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ExcelGenerator {
    private static final String MAP_KEY_NAME = "DEALER_INFO";
    private static final String TITLE_KEY = "TITLE";
    private static final String VOLUME_INFO_KEY = "VOLUME_RECORD_INFO";
    private static final String VOLUME_INC_KEY ="INCENTIVE_INFO";
	private static final String NOT_AVAILABLE_INFO = "N/A";
	private static final String ACTIVE_SHEET_NAME = "resumen";
    private static final String VOLUME_INFO_TITLE = "VOLUME RECORD";
    private static final String INCENTIVE_TITLE = "GENERATED INCENTIVE";
    private static final int TITLE_ROW_INDEX = 1;
    private static final int TOP_LEVEL_ROW_INDEX = 2;
    private static final int FIRST_DATA_ROW = 4;
    private static final int EXP_GOAL_MERGED_START_COL = 4;
    private static final int EXP_GOAL_MERGED_END_COL = 8;
    private static final int MIN_GOAL_MERGED_START_COL = 9;
    private static final int MIN_GOAL_MERGED_END_COL = 13;
    private static final int TERRITORY_COL_INDEX = 0;
    private static final int AGREEMENT_COL_INDEX = 1;
    private static final int DEALER_NAME_COL_INDEX = 2;
    private static final int COMPANY_NAME_COL_INDEX = 3;
    private static final int EXP1_COL_INDEX = 4;
    private static final int EXP2_COL_INDEX = 5;
    private static final int EXP3_COL_INDEX = 6;
    private static final int EXP4_COL_INDEX = 7;
    private static final int EXP_TOTAL_COL_INDEX = 8;
    private static final int MIN1_COL_INDEX = 9;
    private static final int MIN2_COL_INDEX = 10;
    private static final int MIN3_COL_INDEX = 11;
    private static final int MIN4_COL_INDEX = 12;
    private static final int MIN_TOTAL_COL_INDEX = 13;

    private static final Collection<String> HEADER_NAMES = Collections.unmodifiableCollection(Arrays.asList("Territorio", "Convenio", "Nombre", "Razon Social",
            "1er periodo", "2do periodo", "3er periodo", "4to periodo", "Meta Total",
            "1er periodo", "2do periodo", "3er periodo", "4to periodo", "Total Meta minima"));

    private static final Collection<String> TOP_LEVEL_HEADER_NAMES = Collections.unmodifiableCollection(Arrays.asList("META ESPERADA", "META MINIMA"));

    public void generateExcelTemplate(Map model, HSSFWorkbook book) {
        int currentRow = 0;
        HSSFSheet workSheet = book.createSheet(ACTIVE_SHEET_NAME);
        List<HSSFCellStyle> stylesForHeaders = Arrays.asList(createStyleForTopLevelHeader(book, IndexedColors.ORANGE.getIndex()), createStyleForTopLevelHeader(book, IndexedColors.GREEN.getIndex()), createStyleForHeader(book));
        addMergedRegionsToSheet(workSheet);
        addTitleToSheet(model, workSheet, stylesForHeaders.get(2));
        addHeadersToSheet(workSheet, stylesForHeaders);
        currentRow = createContent(model, workSheet);
        currentRow = addVolumeRecordInformation(model, workSheet, stylesForHeaders.get(2), (1 + currentRow));
        addIncentiveRecordInformation(model, workSheet, stylesForHeaders.get(2), (1+currentRow));
        adjustColumnWidthToContent(workSheet);
    }

    private int addVolumeRecordInformation(Map model, HSSFSheet workSheet, CellStyle styleForVolumeLegend, int currentRow) {
        int headerForVolumeRow = currentRow;
        int startRow = (1+currentRow);
        int startCol = 0;
        String[][] volumeRecordInfo = (String[][]) model.get(VOLUME_INFO_KEY);

        HSSFRow headerRow = workSheet.createRow(headerForVolumeRow);
        workSheet.addMergedRegion(new CellRangeAddress(headerForVolumeRow, headerForVolumeRow, 0, volumeRecordInfo[0].length));
        HSSFCell legendForVol = headerRow.createCell(startCol);
        legendForVol.setCellValue(VOLUME_INFO_TITLE);
        legendForVol.setCellStyle(styleForVolumeLegend);

        for(int j=0;j<volumeRecordInfo.length;j++) {
            startCol = 0;
            HSSFRow volumeRow = workSheet.createRow(startRow);
            for(int k=0;k<volumeRecordInfo[0].length;k++) {
                HSSFCell volumeCell = volumeRow.createCell(startCol);
                volumeCell.setCellValue(volumeRecordInfo[j][k]);
                startCol++;
            }
            startRow++;
        }
        return startRow;
    }

    private int addIncentiveRecordInformation(Map model, HSSFSheet workSheet, CellStyle styleForVolumeLegend, int currentRow) {
        int headerForIncentiveRow = currentRow;
        int startRow = (1 + currentRow);
        int startCol = 0;
        String[][] incentiveRecordInfo = (String[][]) model.get(VOLUME_INC_KEY);

        HSSFRow headerRow = workSheet.createRow(headerForIncentiveRow);
        workSheet.addMergedRegion(new CellRangeAddress(headerForIncentiveRow, headerForIncentiveRow, 0, incentiveRecordInfo[0].length));
        HSSFCell legendForVol = headerRow.createCell(startCol);
        legendForVol.setCellValue(INCENTIVE_TITLE);
        legendForVol.setCellStyle(styleForVolumeLegend);

        for(int j=0;j<incentiveRecordInfo.length;j++) {
            startCol = 0;
            HSSFRow volumeRow = workSheet.createRow(startRow);
            for(int k=0;k<incentiveRecordInfo[0].length;k++) {
                HSSFCell volumeCell = volumeRow.createCell(startCol);
                volumeCell.setCellValue(incentiveRecordInfo[j][k]);
                startCol++;
            }
            startRow++;
        }
        return startRow;
    }

    private void addTitleToSheet(Map model, HSSFSheet workSheet, CellStyle style) {
        HSSFRow titleRow = workSheet.createRow(TITLE_ROW_INDEX);
        HSSFCell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(model.get(TITLE_KEY).toString());
        titleCell.setCellStyle(style);
    }

    private void adjustColumnWidthToContent(HSSFSheet workSheet) {
        int numberOfCols = workSheet.getRow(TOP_LEVEL_ROW_INDEX + 1).getPhysicalNumberOfCells();
        for(int j=0;j<numberOfCols;j++) {
            workSheet.autoSizeColumn(j);
        }
    }

    private HSSFCellStyle createStyleForTopLevelHeader(HSSFWorkbook book, short color) {
        HSSFCellStyle style = book.createCellStyle();
        style.setFillForegroundColor(color);
        style.setFillBackgroundColor(color);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        return style;
    }

    private void addMergedRegionsToSheet(HSSFSheet sheet) {
        sheet.addMergedRegion(new CellRangeAddress(TITLE_ROW_INDEX, TITLE_ROW_INDEX, TERRITORY_COL_INDEX, MIN_TOTAL_COL_INDEX ));
        sheet.addMergedRegion(new CellRangeAddress(TOP_LEVEL_ROW_INDEX, TOP_LEVEL_ROW_INDEX, EXP_GOAL_MERGED_START_COL, EXP_GOAL_MERGED_END_COL));
        sheet.addMergedRegion(new CellRangeAddress(TOP_LEVEL_ROW_INDEX, TOP_LEVEL_ROW_INDEX, MIN_GOAL_MERGED_START_COL, MIN_GOAL_MERGED_END_COL));
    }

    private void addHeadersToSheet(HSSFSheet sheet, List<HSSFCellStyle> styles) {
        HSSFRow topLevelHeadersRow = sheet.createRow(TOP_LEVEL_ROW_INDEX);
        addCellsToTopLevelHeaderRow(topLevelHeadersRow, styles);

        HSSFRow headersRow = sheet.createRow(TOP_LEVEL_ROW_INDEX + 1);
        addCellsToHeaderRow(headersRow, styles);
    }

    private void addCellsToTopLevelHeaderRow(HSSFRow topLevelHeadersRow, List<HSSFCellStyle> styles) {
        int indexInColumnsCollection = 0;
        int columns[] = {EXP_GOAL_MERGED_START_COL, MIN_GOAL_MERGED_START_COL};
        int indexForStylesCollection = 0;
        for(String topLevelHeader:TOP_LEVEL_HEADER_NAMES) {
            HSSFCell cell = topLevelHeadersRow.createCell(columns[indexInColumnsCollection]);
            cell.setCellValue(topLevelHeader);
            cell.setCellStyle(styles.get(indexForStylesCollection));
            indexInColumnsCollection++;
            indexForStylesCollection++;
        }
    }

    private void addCellsToHeaderRow(HSSFRow row, List<HSSFCellStyle> stylesForHeader) {
        int startCol = 0;
        for (String header : HEADER_NAMES) {
            HSSFCell cell = row.createCell(startCol);
            cell.setCellValue(header);
            cell.setCellStyle(stylesForHeader.get(2));
            startCol++;
        }
    }

    private HSSFCellStyle createStyleForHeader(HSSFWorkbook book) {
        HSSFCellStyle style = book.createCellStyle();

        style.setFillForegroundColor(IndexedColors.BROWN.getIndex());
        style.setFillBackgroundColor(IndexedColors.BROWN.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFont(createFontForHeader(book));

        return style;
    }

    private HSSFFont createFontForHeader(HSSFWorkbook book) {
        HSSFFont font = book.createFont();
        font.setColor(HSSFColor.WHITE.index);
        return font;
    }

    private int createContent(Map model, HSSFSheet dataSheet) {
    	int startRow = FIRST_DATA_ROW;
    	List<LocalDealerStatementRecordVO> statement = (List<LocalDealerStatementRecordVO>) model.get(MAP_KEY_NAME);
    	Iterator<LocalDealerStatementRecordVO> iterator = statement.iterator();
    	while(iterator.hasNext()) {
    		HSSFRow row = dataSheet.createRow(startRow);
    		writeContentToDataCell(row, iterator.next());
    		startRow++;
    	}
        return startRow;
    }

    private void writeContentToDataCell(HSSFRow row, LocalDealerStatementRecordVO source) {
    	row.createCell(TERRITORY_COL_INDEX).setCellValue(source.getTerritory()!=null?source.getTerritory():NOT_AVAILABLE_INFO);
    	row.createCell(AGREEMENT_COL_INDEX).setCellValue(source.getAgreement()!=null?source.getAgreement():NOT_AVAILABLE_INFO);
    	row.createCell(DEALER_NAME_COL_INDEX).setCellValue(source.getDealerName()!=null?source.getDealerName():NOT_AVAILABLE_INFO);
    	row.createCell(COMPANY_NAME_COL_INDEX).setCellValue(source.getCompanyName()!=null?source.getCompanyName():NOT_AVAILABLE_INFO);
    	row.createCell(EXP1_COL_INDEX).setCellValue(source.getIncentives().get(0).getMaxGoal().doubleValue());
    	row.createCell(EXP2_COL_INDEX).setCellValue(source.getIncentives().get(1).getMaxGoal().doubleValue());
    	row.createCell(EXP3_COL_INDEX).setCellValue(source.getIncentives().get(2).getMaxGoal().doubleValue());
    	row.createCell(EXP4_COL_INDEX).setCellValue(source.getIncentives().get(3).getMaxGoal().doubleValue());
    	row.createCell(EXP_TOTAL_COL_INDEX).setCellValue(source.getTotal(true).doubleValue());
    	row.createCell(MIN1_COL_INDEX).setCellValue(source.getIncentives().get(0).getMinGoal().doubleValue());
    	row.createCell(MIN2_COL_INDEX).setCellValue(source.getIncentives().get(1).getMinGoal().doubleValue());
    	row.createCell(MIN3_COL_INDEX).setCellValue(source.getIncentives().get(2).getMinGoal().doubleValue());
    	row.createCell(MIN4_COL_INDEX).setCellValue(source.getIncentives().get(3).getMinGoal().doubleValue());
    	row.createCell(MIN_TOTAL_COL_INDEX).setCellValue(source.getTotal(false).doubleValue());
    }
}