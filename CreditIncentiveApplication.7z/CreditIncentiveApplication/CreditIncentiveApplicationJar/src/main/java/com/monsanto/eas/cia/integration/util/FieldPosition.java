package com.monsanto.eas.cia.integration.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 20/01/2011
 * Time: 09:55:01 AM
 * This interface is used to set/get csv fields
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface FieldPosition {
    int value() default 0;
}
