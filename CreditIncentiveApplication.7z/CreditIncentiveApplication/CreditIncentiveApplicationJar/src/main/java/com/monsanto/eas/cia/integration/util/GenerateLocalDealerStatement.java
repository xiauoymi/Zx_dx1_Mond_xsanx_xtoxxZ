package com.monsanto.eas.cia.integration.util;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.service.LdSalesService;
import com.monsanto.eas.cia.service.LocalDealerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.lang.System;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

@Service
public class GenerateLocalDealerStatement {
  public static final String RESULT
      = "c:\\pdf\\working_table.pdf";
  @Autowired
  private LocalDealerService ldServ;

  @Autowired
  private LdSalesService salesServ;

  @Transactional
  public void generatePDF(Document document, String yearin, String id) throws DocumentException, IOException {
//    PdfWriter wr = PdfWriter.getInstance(document, new FileOutputStream(RESULT));
    document.setPageSize(PageSize.A4.rotate());
    document.setMargins(10, 10, 10, 10);
    document.open();
//    Image image = Image.getInstance("C:\\projects\\CreditIncentiveApplication\\CreditIncentiveApplicationWeb\\src\\main\\webapp\\images\\bkg-logo.gif");
//    image.setAlignment(Image.ALIGN_MIDDLE);
//    image.setBorder(Image.BOX);
//    image.setBorderWidth(10f);
//    image.setBorderColor(Color.WHITE);
//    image.scaleToFit(100,70);
//    document.add(image);

     Integer localDealerId = new Integer(id);
     Integer year = new Integer(yearin); 

     LocalDealer localDealer = //ldServ.lookUpLocalDealer(localDealerId);
       ldServ.lookupLocalDealerById(localDealerId);

    //localDealerDao.look
    Font font = new Font(Font.HELVETICA,8);
    Font boldFont = new Font(Font.HELVETICA,8, Font.BOLD);

    PdfPTable headerTable = new PdfPTable(1);

    headerTable.setTotalWidth(800);
    headerTable.setLockedWidth(true);

    PdfPCell headerFirstLineCell = new PdfPCell(new Paragraph("MONSANTO OFFICIAL PROGRAM - INCENTIVE TO LOCAL DEALERS "+year+"-STATEMENT", boldFont));
    headerFirstLineCell.setBorder(PdfPCell.NO_BORDER);
    headerFirstLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
    headerTable.addCell(headerFirstLineCell);

//    PdfPCell headerSecondLineCell = new PdfPCell(new Paragraph("PERIOD:", boldFont));
//    headerSecondLineCell.setBorder(PdfPCell.NO_BORDER);
//    headerSecondLineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
//    headerTable.addCell(headerSecondLineCell);
//    headerTable.setSpacingAfter(10f);
//    headerTable.setSpacingBefore(10f);
//    document.add(headerTable);


    PdfPTable table = new PdfPTable(4);

    PdfPCell cell = new PdfPCell(new Paragraph("GENERAL INFORMATION",boldFont));
    cell.setColspan(4);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
//    cell.setBackgroundColor(BaseColor.BLUE);
    table.addCell(cell);
    table.addCell(new Phrase("Local Dealer", font));
    //table.addCell(getCell("Ram bethina", 4, font));
    table.addCell(getCell(localDealer.getName(), 4, font));

    table.addCell(new Phrase("Company", font));
    //table.addCell(getCell("Monsanto", 4, font));
    table.addCell(getCell(localDealer.getPosName(), 4, font));
    
    table.addCell(new Phrase("Address", font));
    //table.addCell(getCell("123 ABC Street", 4, font));
    table.addCell(getCell(localDealer.getAddress1() + (localDealer.getAddress2() != null ? localDealer.getAddress2() : ""), 4, font));

    table.addCell(new Phrase("State", font));
    //table.addCell(getCell("IL", 4, font));
    String state = null;
    if(localDealer.getDistrict()!=null && localDealer.getDistrict().getParentArea() != null) {
        Area a = localDealer.getDistrict().getParentArea();
        state = a.getDescription();
    }
    table.addCell(getCell(state != null ? state : "" , 4, font));   

    PdfPTable table1 = new PdfPTable(2);
    table1.addCell(new Phrase("Agreement", boldFont));
    //table1.addCell(new Phrase("123", font));
    table1.addCell(new Phrase(localDealer.getAgreementNumber(), font));

    table1.addCell(new Phrase("Territory", boldFont));
    //table1.addCell(new Phrase("North America", font));
    table1.addCell(new Phrase(localDealer.getSubRegion() != null ? localDealer.getSubRegion().getDescription() : "", font));

    PdfPCell emptyCell = new PdfPCell();
    emptyCell.setBorder(PdfPCell.NO_BORDER);

    table1.addCell(emptyCell);
    table1.addCell(emptyCell);
    table1.addCell(emptyCell);
    table1.addCell(emptyCell);

    PdfPTable table2 = new PdfPTable(4);
    table2.setTotalWidth(800);
    table2.setLockedWidth(true);

    PdfPCell cell2 = new PdfPCell(table);
    cell2.setColspan(3);
    cell2.setPaddingRight(100);
    cell2.setBorder(PdfPCell.NO_BORDER);
    table2.addCell(cell2);

    PdfPCell cell3 = new PdfPCell(table1);
    cell3.setBorder(PdfPCell.NO_BORDER);
    cell3.setPaddingLeft(2);
    table2.addCell(cell3);
    table2.setHorizontalAlignment(Element.ALIGN_LEFT);

    document.add(table2);

    PdfPTable goalsTable = getGoalsTable(localDealer, year);
    PdfPTable volumeRecord = getVolumeRecord(localDealer, year);
    PdfPTable record = getIncentiveRecord(localDealer, year);
    document.add(goalsTable);
    document.add(volumeRecord);
    document.add(record);
    document.add(getTarget("TARGET", localDealer, year));
    document.add(getTargetPct("TARGET %", localDealer, year));
    //document.add(getPriceListToIncentives());
    document.close();
  }

  private PdfPCell getCell(String value, int colSpan, Font font) {
    PdfPCell cell1 = new PdfPCell(new Paragraph(value,font));
    cell1.setColspan(colSpan);
    return cell1;
  }

  public PdfPTable getGoalsTable(LocalDealer localDealer, Integer year) {
    Font font = new Font(Font.HELVETICA,8);
    PdfPTable table = new PdfPTable(8);
    table.setTotalWidth(600);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);
    PdfPCell cell=new PdfPCell();
    cell.setRowspan(2);
    table.addCell(cell);
    table.addCell(new Phrase("1st Period", font));
    table.addCell(new Phrase("2nd Period", font));
    table.addCell(new Phrase("3rd Period", font));
    table.addCell(new Phrase("4th Period", font));

    PdfPCell wholeEmptyColumn=new PdfPCell();
    wholeEmptyColumn.setRowspan(7);
    table.addCell(wholeEmptyColumn);

    PdfPCell annualTarget=new PdfPCell(new Phrase("Annual Target", font));
    annualTarget.setRowspan(2);
    table.addCell(annualTarget);

    PdfPCell maxTarget=new PdfPCell(new Phrase("Max Opportunity", font));
    maxTarget.setRowspan(2);
    table.addCell(maxTarget);
  
    HashMap<Integer, LdIncentive> incentives = new HashMap();
    for(LdIncentive inc : localDealer.getIncentives()) {
        LdIncentive tmp = inc;
        if(year.intValue() == tmp.getProgramQuarter().getCountryProgram().getYear().getYear().intValue()){
            incentives.put(tmp.getProgramQuarter().getQuarterType().getQuarterNum(), tmp);
        }
    }

    LdProgramYear program = null;
    LdProgramYear tmp = null;
    for(LdProgramYear prog : localDealer.getProgramYears()){
        tmp = prog;
        if(tmp.getYear().getYear().intValue() == year) {
            program = tmp;
        }
    }
      
//    table.addCell(new Phrase("1 Jan- 31 Mar", font));
//    table.addCell(new Phrase("1 Apr- 31 May", font));
//    table.addCell(new Phrase("1 Jun- 31 Aug", font));
//    table.addCell(new Phrase("1 Sep- 31 Dec", font));

      table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getQuarterStartString("d MMM, yyyy") + " - " +incentives.get(1).getProgramQuarter().getQuarterEndString("d MMM, yyyy") : "", font));
      table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(2).getProgramQuarter().getQuarterStartString("d MMM, yyyy") + " - " +incentives.get(2).getProgramQuarter().getQuarterEndString("d MMM, yyyy") : "", font));
      table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(3).getProgramQuarter().getQuarterStartString("d MMM, yyyy") + " - " +incentives.get(3).getProgramQuarter().getQuarterEndString("d MMM, yyyy") : "", font));
      table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(4).getProgramQuarter().getQuarterStartString("d MMM, yyyy") + " - " +incentives.get(4).getProgramQuarter().getQuarterEndString("d MMM, yyyy") : "", font));
      
    table.addCell(new Phrase("Expected Goal", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(1).getMaxIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(2).getMaxIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(3).getMaxIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(4).getMaxIncentive().toString() : "", font));
    table.addCell(new Phrase(program != null ? program.getMaxTarget().toString() : "", font));
//    table.addCell(new Phrase("x", font));

//    PdfPCell maxTargetPct=new PdfPCell(new Phrase("8%", font));
    PdfPCell maxTargetPct=new PdfPCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMaxYrPct() * 2 : 0d), font));
    maxTargetPct.setRowspan(2);
    table.addCell(maxTargetPct);

    table.addCell(new Phrase("Incentive By Period", font));
//    table.addCell(new Phrase("4%", font));
//    table.addCell(new Phrase("4%", font));
//    table.addCell(new Phrase("4%", font));
//    table.addCell(new Phrase("4%", font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMaxPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(2).getProgramQuarter().getCountryProgram().getMaxPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(3).getProgramQuarter().getCountryProgram().getMaxPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(4).getProgramQuarter().getCountryProgram().getMaxPct() : 0d), font));
//    table.addCell(new Phrase("4% Additional", font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMaxYrPct()  : 0d), font));

    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");


    table.addCell(new Phrase("Min. Target", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
//    table.addCell(new Phrase("x", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(1).getMinIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(2).getMinIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(3).getMinIncentive().toString() : "", font));
    table.addCell(new Phrase(incentives.size() == 4 ? incentives.get(4).getMinIncentive().toString() : "", font));
//  table.addCell(new Phrase("x", font));
    table.addCell(new Phrase(program != null ? program.getMinTarget().toString() : "", font));


//    PdfPCell minTargetPct=new PdfPCell(new Phrase("4%", font));
    PdfPCell minTargetPct=new PdfPCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMinYrPct() * 2 : 0d), font));
    minTargetPct.setRowspan(2);
    table.addCell(minTargetPct);

    table.addCell(new Phrase("Incentive By Period", font));
//    table.addCell(new Phrase("2%", font));
//    table.addCell(new Phrase("2%", font));
//    table.addCell(new Phrase("2%", font));
//    table.addCell(new Phrase("2%", font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMinPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(2).getProgramQuarter().getCountryProgram().getMinPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(3).getProgramQuarter().getCountryProgram().getMinPct() : 0d), font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(4).getProgramQuarter().getCountryProgram().getMinPct() : 0d), font));
//    table.addCell(new Phrase("4% Additional", font));
    table.addCell(new Phrase(toPctFormat(incentives.size() == 4 ? incentives.get(1).getProgramQuarter().getCountryProgram().getMinYrPct() : 0d), font));

    System.out.println("A:" +incentives.get(1).getProgramQuarter().getCountryProgram().getMinPct());
    System.out.println("B:" +incentives.get(2).getProgramQuarter().getCountryProgram().getMinPct());
    System.out.println("C:" +incentives.get(3).getProgramQuarter().getCountryProgram().getMinPct());
    System.out.println("D:" +incentives.get(4).getProgramQuarter().getCountryProgram().getMinPct());

    return table;
  }

  public PdfPTable getVolumeRecord(LocalDealer localDealer, Integer year) {

    // get the sales
    Collection<LdSales> sales = salesServ.findByYearAndLocalDealer( year, localDealer);

    Iterator<LdSales> itSales = sales.iterator();
    Iterator<ProductLine> itProduct = null;
    Iterator<SapDistributor> itDistributor = null;
    LdSales tmpSales = null;
    HashMap<Integer, ProductLine> productsHash = new HashMap();
    HashMap<Integer, SapDistributor> distributorsHash = new HashMap();
    int tableWidth;
    int tableHeight;

    while(itSales.hasNext()) {
        tmpSales = itSales.next();
        // to avoid duplicates
        distributorsHash.put(tmpSales.getLdDist().getDistributor().getId(), tmpSales.getLdDist().getDistributor());
        productsHash.put(tmpSales.getProductLine().getId(), tmpSales.getProductLine());
    }

    tableWidth = productsHash.size() + 2;
    tableHeight  = distributorsHash.size() + 1;      

    Font font = new Font(Font.HELVETICA,8);
    PdfPTable table = new PdfPTable(tableWidth);
    table.setTotalWidth(700);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);

    PdfPCell cell=new PdfPCell(new Phrase("VOLUME RECORD",font));
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(tableWidth); //-->Value to be calculated
    table.addCell(cell);

    // initialize the headers
    String data[][] = new String[tableHeight][tableWidth];
    itDistributor = distributorsHash.values().iterator();
    int counter = 1;
    data[0][0] = "DISTRIBUTORS";
    data[0][tableWidth - 1] = "TOTAL";
    while(itDistributor.hasNext()) {
      data[counter][0] = itDistributor.next().getDescription();
      counter++;
    }
    itProduct = productsHash.values().iterator();
    counter = 1;
    while(itProduct.hasNext()){
      data[0][counter] = itProduct.next().getSapProduct().getDescription();
      counter++;
    }

    itSales = sales.iterator();
    while(itSales.hasNext()) {
        tmpSales = itSales.next();
        for(int i=0; i < tableHeight; i++) {
            if(tmpSales.getLdDist().getDistributor().getDescription().equalsIgnoreCase(data[i][0])) {
                for(int j = 0; j < tableWidth; j++) {
                    if(tmpSales.getProductLine().getSapProduct().getDescription().equalsIgnoreCase(data[0][j])) {
                        LdSalesPerProduct salesPerProduct = ldServ.lookupLdSalesPerProductByYearAndLeaderAndProduct(localDealer.getId(), year, tmpSales.getProductLine().getId());
                        Double generatedIncentive = salesPerProduct.getVolumePerProductLine();
                        data[i][j] = generatedIncentive.toString();
                    }
                }
            }
        }
    }

    // Calculate totals
    Double rowTotal = 0d;
    for(int i=1; i <= distributorsHash.size(); i++) {
      for(int j = 1; j <= productsHash.size(); j++) {
          if(data[i][j] != null) {
              rowTotal += Double.parseDouble(data[i][j]);
          }
      }
      data[i][tableWidth - 1] = rowTotal.toString();
      rowTotal = 0d;

    }

    // populate the table
    // print the table in the report
    for(int i=0; i < tableHeight; i++) {
      for(int j = 0; j < tableWidth; j++) {
          if(data[i][j] != null) {
              table.addCell(new PdfPCell(new Phrase(data[i][j],font)));
          } else {
              table.addCell(new PdfPCell(new Phrase("0.0",font)));
          }
      }
    }


//    PdfPCell distributorHeader=new PdfPCell(new Phrase("DISTRIBUTOR",font));
//    distributorHeader.setRowspan(2); //-->Value to be calculated
//    table.addCell(distributorHeader);
//
//    PdfPCell productOneCell = new PdfPCell(new Phrase("FAENA FUERTE 360",font));
//    productOneCell.setHorizontalAlignment(Element.ALIGN_CENTER);
//    productOneCell.setColspan(3);
//    table.addCell(productOneCell);
//    table.addCell(productOneCell);
//    table.addCell(productOneCell);
//    PdfPCell producttemp = new PdfPCell(new Phrase("FAENA one FUERTE 360",font));
//    producttemp.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(producttemp);
//
//    PdfPCell totalGral=new PdfPCell(new Phrase("TOTAL GRAL",font));
//    totalGral.setRowspan(2); //-->Value to be calculated
//    table.addCell(totalGral);
//
//    PdfPCell productOne1 = new PdfPCell(new Phrase("1LT", font));
//    productOne1.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne1);
//
//    PdfPCell productOne2 = new PdfPCell(new Phrase("4LTS", font));
//    productOne2.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne2);
//
//    PdfPCell productOne3 = new PdfPCell(new Phrase("10LTS", font));
//    productOne3.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne3);
//
//    PdfPCell productTwo1 = new PdfPCell(new Phrase("1LT", font));
//    productTwo1.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productTwo1);
//
//    PdfPCell productTwo2 = new PdfPCell(new Phrase("4LTS", font));
//    table.addCell(productTwo2);
//
//    PdfPCell productTwo3 = new PdfPCell(new Phrase("10LTS", font));
//    table.addCell(productTwo3);
//
//    PdfPCell productThree1 = new PdfPCell(new Phrase("1LT", font));
//    table.addCell(productThree1);
//
//    PdfPCell productThree2 = new PdfPCell(new Phrase("4LTS", font));
//    table.addCell(productThree2);
//
//    PdfPCell productThree3 = new PdfPCell(new Phrase("10LTS", font));
//    table.addCell(productThree3);
//
//    PdfPCell productFour1 = new PdfPCell(new Phrase("1LT", font));
//    table.addCell(productFour1);
//
//    PdfPCell distributorCell = new PdfPCell(new Phrase("DISTRIBUTOR1", font));
//    table.addCell(distributorCell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//
//    PdfPCell distributor1Cell = new PdfPCell(new Phrase("DISTRIBUTOR2", font));
//    table.addCell(distributor1Cell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//
//    PdfPCell distributor2Cell = new PdfPCell(new Phrase("DISTRIBUTOR3", font));
//    table.addCell(distributor2Cell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
    return table;
  }

  public PdfPTable getPriceListToIncentives() {
    Font font = new Font(Font.HELVETICA,8);
    PdfPTable table = new PdfPTable(12);
    table.setTotalWidth(700);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);

    PdfPCell cell=new PdfPCell(new Phrase("PRICE LIST TO INCENTIVES",font));
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(12); //-->Value to be calculated
    table.addCell(cell);

    PdfPCell distributorHeader=new PdfPCell(new Phrase("DISTRIBUTOR",font));
    distributorHeader.setRowspan(2); //-->Value to be calculated
    table.addCell(distributorHeader);

    PdfPCell productOneCell = new PdfPCell(new Phrase("FAENA FUERTE 360",font));
    productOneCell.setColspan(3);
    productOneCell.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(productOneCell);
    table.addCell(productOneCell);
    table.addCell(productOneCell);
    PdfPCell producttemp = new PdfPCell(new Phrase("FAENA one FUERTE 360",font));
    producttemp.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(producttemp);

    PdfPCell totalGral=new PdfPCell(new Phrase("TOTAL ",font));
    totalGral.setRowspan(2); //-->Value to be calculated
    table.addCell(totalGral);

    PdfPCell productOne1 = new PdfPCell(new Phrase("1LT", font));
    productOne1.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(productOne1);

    PdfPCell productOne2 = new PdfPCell(new Phrase("4LTS", font));
    productOne2.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(productOne2);

    PdfPCell productOne3 = new PdfPCell(new Phrase("10LTS", font));
    productOne3.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(productOne3);

    PdfPCell productTwo1 = new PdfPCell(new Phrase("1LT", font));
    productTwo1.setHorizontalAlignment(Element.ALIGN_CENTER);
    table.addCell(productTwo1);

    PdfPCell productTwo2 = new PdfPCell(new Phrase("4LTS", font));
    table.addCell(productTwo2);

    PdfPCell productTwo3 = new PdfPCell(new Phrase("10LTS", font));
    table.addCell(productTwo3);

    PdfPCell productThree1 = new PdfPCell(new Phrase("1LT", font));
    table.addCell(productThree1);

    PdfPCell productThree2 = new PdfPCell(new Phrase("4LTS", font));
    table.addCell(productThree2);

    PdfPCell productThree3 = new PdfPCell(new Phrase("10LTS", font));
    table.addCell(productThree3);

    PdfPCell productFour1 = new PdfPCell(new Phrase("1LT", font));
    table.addCell(productFour1);

    PdfPCell distributorCell = new PdfPCell(new Phrase("PRICE", font));
    table.addCell(distributorCell);
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");
    table.addCell("");

    return table;
  }

  public PdfPTable getIncentiveRecord(LocalDealer localDealer, Integer year) {

    Collection<LdSales> sales = salesServ.findByYearAndLocalDealer( year, localDealer);

    Iterator<LdSales> itSales = sales.iterator();
    Iterator<ProductLine> itProduct = null;
    Iterator<SapDistributor> itDistributor = null;
    LdSales tmpSales = null;
    HashMap<Integer, ProductLine> productsHash = new HashMap();
    HashMap<Integer, SapDistributor> distributorsHash = new HashMap();
    int tableWidth;
    int tableHeight;

    while(itSales.hasNext()) {
        tmpSales = itSales.next();
        // to avoid duplicates
        distributorsHash.put(tmpSales.getLdDist().getDistributor().getId(), tmpSales.getLdDist().getDistributor());
        productsHash.put(tmpSales.getProductLine().getId(), tmpSales.getProductLine());
    }

    tableWidth = productsHash.size() + 2;
    tableHeight  = distributorsHash.size() + 1;

    // initialize the headers
    String data[][] = new String[tableHeight][tableWidth];
    itDistributor = distributorsHash.values().iterator();
    int counter = 1;
    data[0][0] = "DISTRIBUTORS";
    data[0][tableWidth - 1] = "TOTAL";
    while(itDistributor.hasNext()) {
        data[counter][0] = itDistributor.next().getDescription();
        counter++;
    }
    itProduct = productsHash.values().iterator();
    counter = 1;
    while(itProduct.hasNext()){
        data[0][counter] = itProduct.next().getSapProduct().getDescription();
        counter++;
    }

    itSales = sales.iterator();
    while(itSales.hasNext()) {
        tmpSales = itSales.next();
        for(int i=0; i < tableHeight; i++) {
            if(tmpSales.getLdDist().getDistributor().getDescription().equalsIgnoreCase(data[i][0])) {
                for(int j = 0; j < tableWidth; j++) {
                    if(tmpSales.getProductLine().getSapProduct().getDescription().equalsIgnoreCase(data[0][j])) {
                        LdSalesPerProduct salesPerProduct = ldServ.lookupLdSalesPerProductByYearAndLeaderAndProduct(localDealer.getId(), year, tmpSales.getProductLine().getId());
                        Double generatedIncentive = tmpSales.getVolumeToIncentive() * tmpSales.getPrice() * salesPerProduct.getInventivePct();
                        data[i][j] = generatedIncentive.toString();                       
                    }
                }
            }
        }
    }

    // Calculate totals
    Double rowTotal = 0d;
    for(int i=1; i <= distributorsHash.size(); i++) {
        for(int j = 1; j <= productsHash.size(); j++) {
            if(data[i][j] != null) {
                rowTotal += Double.parseDouble(data[i][j]);                
            }  
        }
        data[i][tableWidth - 1] = rowTotal.toString();
        rowTotal = 0d;

    }

    // populate the table
    Font font = new Font(Font.HELVETICA,8);
    PdfPTable table = new PdfPTable(tableWidth);
    table.setTotalWidth(700);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);

    PdfPCell cell=new PdfPCell(new Phrase("GENERATED INCENTIVE",font));
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(tableWidth); //-->Value to be calculated
    table.addCell(cell);

    // print the table in the report
    for(int i=0; i < tableHeight; i++) {
        for(int j = 0; j < tableWidth; j++) {
            if(data[i][j] != null) {
                table.addCell(new PdfPCell(new Phrase(data[i][j],font)));
            } else {
                table.addCell(new PdfPCell(new Phrase("0.0",font)));                
            }
        }
    }


//    Font font = new Font(Font.HELVETICA,8);
//    PdfPTable table = new PdfPTable(12);
//    table.setTotalWidth(700);
//    table.setHorizontalAlignment(Element.ALIGN_LEFT);
//    table.setLockedWidth(true);
//    table.setSpacingBefore(10f);
//    table.setSpacingAfter(10f);
//
//    PdfPCell cell=new PdfPCell(new Phrase("GENERATED INCENTIVE",font));
//    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
//    cell.setColspan(12); //-->Value to be calculated
//    table.addCell(cell);
//
//    PdfPCell distributorHeader=new PdfPCell(new Phrase("DISTRIBUTOR",font));
//    distributorHeader.setRowspan(2); //-->Value to be calculated
//    table.addCell(distributorHeader);
//
//    PdfPCell productOneCell = new PdfPCell(new Phrase("FAENA FUERTE 360",font));
//    productOneCell.setColspan(3);
//    productOneCell.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOneCell);
//    table.addCell(productOneCell);
//    table.addCell(productOneCell);
//    PdfPCell producttemp = new PdfPCell(new Phrase("FAENA one FUERTE 360",font));
//    producttemp.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(producttemp);
//
//    PdfPCell totalGral=new PdfPCell(new Phrase("TOTAL INCENTIVE",font));
//    totalGral.setRowspan(2); //-->Value to be calculated
//    table.addCell(totalGral);
//
//    PdfPCell productOne1 = new PdfPCell(new Phrase("1LT", font));
//    productOne1.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne1);
//
//    PdfPCell productOne2 = new PdfPCell(new Phrase("4LTS", font));
//    productOne2.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne2);
//
//    PdfPCell productOne3 = new PdfPCell(new Phrase("10LTS", font));
//    productOne3.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productOne3);
//
//    PdfPCell productTwo1 = new PdfPCell(new Phrase("1LT", font));
//    productTwo1.setHorizontalAlignment(Element.ALIGN_CENTER);
//    table.addCell(productTwo1);
//
//    PdfPCell productTwo2 = new PdfPCell(new Phrase("4LTS", font));
//    table.addCell(productTwo2);
//
//    PdfPCell productTwo3 = new PdfPCell(new Phrase("10LTS", font));
//    table.addCell(productTwo3);
//
//    PdfPCell productThree1 = new PdfPCell(new Phrase("1LT", font));
//    table.addCell(productThree1);
//
//    PdfPCell productThree2 = new PdfPCell(new Phrase("4LTS", font));
//    table.addCell(productThree2);
//
//    PdfPCell productThree3 = new PdfPCell(new Phrase("10LTS", font));
//    table.addCell(productThree3);
//
//    PdfPCell productFour1 = new PdfPCell(new Phrase("1LT", font));
//    table.addCell(productFour1);
//
//    PdfPCell distributorCell = new PdfPCell(new Phrase("DISTRIBUTOR1", font));
//    table.addCell(distributorCell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//
//    PdfPCell distributor1Cell = new PdfPCell(new Phrase("DISTRIBUTOR2", font));
//    table.addCell(distributor1Cell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//
//    PdfPCell distributor2Cell = new PdfPCell(new Phrase("DISTRIBUTOR3", font));
//    table.addCell(distributor2Cell);
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");
//    table.addCell("");

    return table;
  }
  public PdfPTable getTarget(String tagetStr, LocalDealer localDealer, Integer year) {

    Collection programYears = localDealer.getProgramYears();
    LdProgramYear programYear = null, tmp = null;
    Iterator<LdProgramYear> it = programYears.iterator();
    while(it.hasNext()) {
         tmp = it.next();
         if(tmp.getYear().getYear().intValue() == year.intValue()) {
               programYear = tmp;
         }
    }


    Font font = new Font(Font.HELVETICA, 8);
    PdfPTable table = new PdfPTable(4);
    table.setTotalWidth(300);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);

    PdfPCell cell = new PdfPCell(new Phrase(tagetStr, font));
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(4); //-->Value to be calculated
    table.addCell(cell);

    PdfPCell maxTargetLabel = new PdfPCell(new Phrase("MAX. TARGET", font));
    table.addCell(maxTargetLabel);

    PdfPCell maxTargetValue = new PdfPCell(new Phrase(programYear != null ? programYear.getMaxTarget().toString() : "", font));
    maxTargetValue.setColspan(3);
    table.addCell(maxTargetValue);

    PdfPCell minTargetLabel = new PdfPCell(new Phrase("MIN. TARGET", font));
    table.addCell(minTargetLabel);

    PdfPCell minTargetValue = new PdfPCell(new Phrase(programYear != null ? programYear.getMinTarget().toString() : "", font));
    minTargetValue.setColspan(3);
    table.addCell(minTargetValue);


    return table;
  }

  public PdfPTable getTargetPct(String tagetStr, LocalDealer localDealer, Integer year) {

    HashMap<Integer, CountryProgramYrPct> countryPrograms = new HashMap();
    for(LdIncentive inc : localDealer.getIncentives()) {
        LdIncentive tmp = inc;
        if(year.intValue() == tmp.getProgramQuarter().getCountryProgram().getYear().getYear().intValue()){
            countryPrograms.put(tmp.getProgramQuarter().getCountryProgram().getYear().getYear(), tmp.getProgramQuarter().getCountryProgram());
        }
    }


    Font font = new Font(Font.HELVETICA, 8);
    PdfPTable table = new PdfPTable(4);
    table.setTotalWidth(300);
    table.setHorizontalAlignment(Element.ALIGN_LEFT);
    table.setLockedWidth(true);
    table.setSpacingBefore(10f);
    table.setSpacingAfter(10f);

    PdfPCell cell = new PdfPCell(new Phrase(tagetStr, font));
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(4); //-->Value to be calculated
    table.addCell(cell);

    PdfPCell maxTargetLabel = new PdfPCell(new Phrase("MAX. TARGET", font));
    table.addCell(maxTargetLabel);

    PdfPCell maxTargetValue = new PdfPCell(new Phrase(toPctFormat(countryPrograms.get(year) != null ? countryPrograms.get(year).getMaxYrPct() : 0d), font));
    maxTargetValue.setColspan(3);
    table.addCell(maxTargetValue);

    PdfPCell minTargetLabel = new PdfPCell(new Phrase("MIN. TARGET", font));
    table.addCell(minTargetLabel);

    PdfPCell minTargetValue = new PdfPCell(new Phrase(toPctFormat(countryPrograms.get(year) != null ? countryPrograms.get(year).getMinYrPct() : 0d), font));
    minTargetValue.setColspan(3);
    table.addCell(minTargetValue);

    return table;
  }

  private String toPctFormat(Double number) {
      String result = "";
      if(number != null) {
        result = (number * 100) + "%";
      }
      return result;
  }
}
