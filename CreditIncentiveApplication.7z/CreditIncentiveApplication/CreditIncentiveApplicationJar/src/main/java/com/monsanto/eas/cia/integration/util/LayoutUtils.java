package com.monsanto.eas.cia.integration.util;

import com.monsanto.eas.cia.integration.contract.Layout;
import org.apache.commons.lang.ClassUtils;

import java.lang.reflect.Field;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 25/01/2011
 * Time: 07:32:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutUtils {
    /**
     * @param object Determine if this object is csv layout
     * @return boolean 
     */
    public static boolean isLayout(Object object){
        return object instanceof Layout;
    }

    /**
     * @param _class Any class
     * @return Whether the input is annotated with CsvLayout.class
     */
    public static boolean isLayout(Class _class){
        if(_class==null)return false;
        return ClassUtils.isAssignable(_class,Layout.class);        
    }

    /**     
     * @param object An object instantiating a generic class with at least one generic type
     * @return Whether the first generic type of the object is annotated with CsvLayout.class
     */
    public static boolean isGenericTypeLayout(Object object){        
        return  getLayoutGenericType(object)!=null;
    }

    /**
     * @param values
     * @return The concatenated string from all parameter values. This string is trimmed.
     */
    public static String value(Object ... values){
        StringBuilder builder=new StringBuilder();
        for(Object value:values){
            if(value!=null)
                builder.append(value);
        }
        return builder.toString().trim();
    }

    /**     
     * @param object An object instantiating a generic class with at least one generic type
     * @return The first generic type annotated with CsvLayout.class or null if none is found 
     */
    public static Class getLayoutGenericType(Object object){
        if(object==null)return null;
        Class   type    =   ObjectUtils.getGenericType(object.getClass(),Layout.class);        
        if(isLayout(type)){
            return type;
        }
        return null;
    }

    /**     
     * @param field A field obtained through reflection
     * @return The position of this field in the layout
     */
    public static Integer getFieldPosition(Field field){
        FieldPosition fieldPosition=field.getAnnotation(FieldPosition.class);
        if(fieldPosition==null)
            return null;
        return fieldPosition.value();
    }

    public static final String getBundleValue(String key){
        return RESOURCE_BUNDLE.getString(key);
    }

    public static final ResourceBundle RESOURCE_BUNDLE =ResourceBundle.getBundle("layout");
}
