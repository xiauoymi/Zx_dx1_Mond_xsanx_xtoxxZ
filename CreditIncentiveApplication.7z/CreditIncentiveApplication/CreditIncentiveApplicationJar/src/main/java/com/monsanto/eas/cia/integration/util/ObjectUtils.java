package com.monsanto.eas.cia.integration.util;

import org.apache.commons.lang.ClassUtils;
import org.springframework.beans.BeanUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 1/02/2011
 * Time: 08:06:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ObjectUtils {

    public static <T> Collection<T> asCollection(T ... objects){
        return Arrays.asList(objects);
    }
    
    /**
     * @param _class The class that might implement/extend a parametrized type
     * @param complyWith The genericType we are looking
     * @return
     */
    public static Class<?> getGenericType(Class<?> _class, Class<?> complyWith){
        if(_class==null||_class==Object.class)return null;
        if(complyWith==null)complyWith=Object.class;

        List<Type> _classTypes=new ArrayList<Type>();

        if(_class.isInterface()){
            _classTypes.addAll(Arrays.asList(_class.getGenericInterfaces()));
        }
        else{
            _classTypes.addAll(Arrays.asList(_class.getGenericSuperclass()));
            _classTypes.addAll(Arrays.asList(_class.getGenericInterfaces()));                        
        }

        for(Type _classType:_classTypes){
            if(_classType==null) {
                continue;
            }
            if(_classType instanceof ParameterizedType){
                Type[]_types=((ParameterizedType) _classType).getActualTypeArguments();
                for(Type _type:_types){
                    if(_type instanceof Class){
                    Class<?> genericType= (Class)_type;
                    if(ClassUtils.isAssignable(genericType,complyWith))
                        return genericType;
                    }
                }                
            }
            else{
                Class<?> genericType=null;
                Class<?>[]_interfaces=_class.getInterfaces();
                if(_interfaces!=null){
                    for(Class<?> _interface:_interfaces){
                        genericType=getGenericType(_interface,complyWith);
                        if(genericType!=null)break;
                    }
                }
                if(genericType==null){
                    genericType=getGenericType(_class.getSuperclass(),complyWith);
                }                
                if(genericType!=null){
                    return genericType;
                }
            }
        }
        return getGenericType(_class.getSuperclass(),complyWith);
    }


    /**
     * Copy properties from source to target
     * @param source Source object
     * @param target Target object
     */
    public static void copySourceInto(Object source, Object target){
        if(source==null) {
            throw new IllegalArgumentException("Source is null");
        }
        if(target==null) {
            throw new IllegalArgumentException("Target is null");
        }
        BeanUtils.copyProperties(source,target);
    }

    public static int absOrValue(int value, int conditionValue){
        return absOrValue(value,0,conditionValue);
    }

    public static int absOrValue(int value, int condition, int conditionValue){
        value           =   Math.abs(value);
        condition       =   Math.abs(condition);
        conditionValue  =   Math.abs(conditionValue);
        if(value==condition){
            value=conditionValue;
        }
        return value;
    }

    public static <T> T newInstance(Class<T> _class){
        try{
            return _class.newInstance();
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }
}
