package com.monsanto.eas.cia.integration.util;


//import com.itextpdf.text.*;
//import com.itextpdf.text.pdf.PdfPCell;
//import com.itextpdf.text.pdf.PdfPTable;
//import com.itextpdf.text.pdf.PdfWriter;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.monsanto.eas.cia.controller.LocalDistributorStatement;

import java.awt.*;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Mar 27, 2011
 * Time: 10:20:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class WorkingExample {

  /** The resulting PDF file. */
  public static final String RESULT
      = "c:\\pdf\\working_table.pdf";
  private static PdfPTable goalsTable;

  /**
   * Main method.
   * @param    args    no arguments needed
   * @throws java.io.IOException
   */
  public static void main(String[] args)
      throws IOException, DocumentException {
//    Rectangle rectangle = new Rectangle(14400, 14400);
//    rectangle.rotate();
    GenerateLocalDealerStatement generateLocalDealerStatement = new GenerateLocalDealerStatement();
    Document document = new Document();
//    generateLocalDealerStatement.generatePDF(document);
    document.close();

  }

}
