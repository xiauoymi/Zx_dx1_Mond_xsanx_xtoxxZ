package com.monsanto.eas.cia.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.flex.core.io.AmfIgnore;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Dec 1, 2010 Time: 12:49:53 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(
	schema ="CIA", name = "AREA",
	uniqueConstraints=@UniqueConstraint(columnNames={"CODE", "DTYPE"})
)
@NamedQueries({
        @NamedQuery(name = "Area.lookupAllAreas", query = "FROM Area area ORDER BY area.description")
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DTYPE", length = 15, discriminatorType = DiscriminatorType.STRING)
@AttributeOverrides({	
	@AttributeOverride(name="code", column=@Column(name = "CODE", length=63, nullable = false)),
    @AttributeOverride(name="description", column=@Column(name="DESCRIPTION", length=96, nullable=true))        
})
public class Area<P extends Area, C extends Area> extends CodeCatalogEntity implements Serializable {
    /**                                                                                              
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;


    @ManyToOne(cascade = CascadeType.ALL, targetEntity = Area.class,fetch=FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID", nullable = true)
    private P parentArea;

//    @OneToMany(mappedBy = "parentArea", targetEntity = Area.class, fetch=FetchType.LAZY, cascade = CascadeType.ALL)
//    @OrderBy("code")
    @Transient
    private Set<C> childAreas = new HashSet<C>();

    @Basic(optional=true)
    @Column(name="SHORTCUT",length=63,nullable=true)
    private String shortcut;

    //@AmfIgnore
    public P getParentArea() {
        return parentArea;
    }

    public void setParentArea(P parentArea) {
        this.parentArea = parentArea;
    }

    @AmfIgnore
    public Set<C> getChildAreas() {
        return childAreas;
    }

    public void setChildAreas(Set<C> childAreas) {
        this.childAreas = childAreas;
    }

    public void addChildArea(C child){
        if(child!=null){
            childAreas.add(child);
            child.setParentArea(this);
        }
    }
            
    public String getShortcut() {
		return shortcut;
	}

	public void setShortcut(String shortcut) {
		this.shortcut = shortcut;
	}

	@Override
    public boolean equals(Object o) {
        return o instanceof Area && super.equals(o);
    }

}
