package com.monsanto.eas.cia.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 22/11/12
 * Time: 01:19 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "CN_PER_DISTRIBUTOR_VIEW")
@NamedQueries(value = {
        @NamedQuery(name = "CnPerDistributorView.findByCreditNotesByYearAndMonth",
                query = "select cn from CnPerDistributorView cn where cn.programYear=:programYear and :date between cn.quarterStart and cn.quarterEnd and (cn.distributorId = :distributorId or 1 = :filterFlag)"),
        @NamedQuery(name = "CnPerDistributorView.findByDistributorProgramQuarterAndCreditNote",
                query = "select cn from CnPerDistributorView cn where cn.programQuarterId =:programQuarterId and cn.distributorId = :distributorId and ((cn.creditNoteId = :creditNoteId) or (:filterFlag = 1 and cn.creditNoteId is null))")
})
public class CnPerDistributorView {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "QUARTER_ID", insertable = false, updatable = false)
    private Long programQuarterId;

    @Column(name = "PROGRAM_YEAR", insertable = false, updatable = false)
    private int programYear;

    @Column(name = "QUARTER", insertable = false, updatable = false)
    private int quarter;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "QUARTER_START", insertable = false, updatable = false)
    private Date quarterStart;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "QUARTER_END", insertable = false, updatable = false)
    private Date quarterEnd;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MOD_DATE", insertable = false, updatable = false)
    private Date modDate;

    @Column(name = "DISTRIBUTOR_ID", insertable = false, updatable = false)
    private Long distributorId;

    @Column(name = "CODE", insertable = false, updatable = false)
    private String code;

    @Column(name = "DISTRIBUTOR_NAME", insertable = false, updatable = false)
    private String distributorName;

    @Column(name = "CREDIT_NOTE_ID", insertable = false, updatable = false)
    private Long creditNoteId;

    @Column(name = "TAX_RESERVE_ID", insertable = false, updatable = false)
    private Long taxReserveId;

    @Transient
    private Boolean creditNoteSent;

    public Date getQuarterStart() {
        return quarterStart;
    }

    public void setQuarterStart(Date quarterStart) {
        this.quarterStart = quarterStart;
    }

    public Date getQuarterEnd() {
        return quarterEnd;
    }

    public void setQuarterEnd(Date quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public Boolean getCreditNoteSent() {
        return creditNoteId != null;
    }

    public Long getProgramQuarterId() {
        return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
        this.programQuarterId = programQuarterId;
    }

    public void setCreditNoteSent(Boolean creditNoteSent) {
        this.creditNoteSent = creditNoteSent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getProgramYear() {
        return programYear;
    }

    public void setProgramYear(int programYear) {
        this.programYear = programYear;
    }

    public int getQuarter() {
        return quarter;
    }

    public void setQuarter(int quarter) {
        this.quarter = quarter;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public Long getCreditNoteId() {
        return creditNoteId;
    }

    public void setCreditNoteId(Long creditNoteId) {
        this.creditNoteId = creditNoteId;
    }

    public Long getTaxReserveId() {
        return taxReserveId;
    }

    public void setTaxReserveId(Long taxReserveId) {
        this.taxReserveId = taxReserveId;
    }

}
