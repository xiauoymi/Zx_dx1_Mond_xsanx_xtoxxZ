package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:41 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "COMMERCIAL_SUPERVISOR")
@Entity
@NamedQueries({
        @NamedQuery(name = "CommercialSupervisor.lookupAll", query = "FROM CommercialSupervisor"),
        @NamedQuery(name = "CommercialSupervisor.lookupCommercialSupervisorByName", query = "FROM CommercialSupervisor cs WHERE cs.description=:name")
})
@AttributeOverrides({
    @AttributeOverride(name="description", column=@Column(name = "NAME", nullable = false))        
})
public class CommercialSupervisor extends DescriptionCatalogEntity {

    @Override
    public boolean equals(Object o) {
        return o instanceof CommercialSupervisor && super.equals(o);
    }
}
