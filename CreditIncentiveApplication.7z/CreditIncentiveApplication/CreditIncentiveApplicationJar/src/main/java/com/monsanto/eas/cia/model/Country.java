package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.SimpleCodeCatalogEntity;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Dec 1, 2010 Time: 9:44:12 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "COUNTRY")
@NamedQueries({
        @NamedQuery(name = "Country.lookupAll", query = "FROM Country c ORDER BY c.description asc")})
@AttributeOverrides({
    @AttributeOverride(name="code",column=@Column(name="CODE", length=3, nullable=false))        
})
public class Country extends SimpleCodeCatalogEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object o) {
        return o instanceof Country && super.equals(o);
    }
}
