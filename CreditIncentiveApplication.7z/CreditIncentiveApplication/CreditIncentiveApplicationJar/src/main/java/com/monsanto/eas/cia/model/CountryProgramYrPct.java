package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:41 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "COUNTRY_PROGRAM_YR_PCT")
@Entity
@NamedQueries({
        @NamedQuery(name = "CountryProgramYrPct.lookupAllCountryProgramYrPct", query = "FROM CountryProgramYrPct cpyp"),
        @NamedQuery(name = "CountryProgramYrPct.lookupCountryProgramYrPctByYear", query = "SELECT cpyp FROM CountryProgramYrPct cpyp JOIN cpyp.year where cpyp.year.id = :1"),
        @NamedQuery(name = "CountryProgramYrPct.lookupCountryProgramYrPctByCountryAndYear", query = "SELECT cpyp FROM CountryProgramYrPct cpyp JOIN cpyp.year JOIN cpyp.country where cpyp.country.id = :1 and cpyp.year.id = :2"),
        @NamedQuery(name = "CountryProgramYrPct.lookupOpenCountryProgramYears", query = "SELECT cpyp FROM CountryProgramYrPct cpyp where cpyp.open='Y'")
})
public class CountryProgramYrPct extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(name = "MIN_PCT", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double minPct;

    @javax.persistence.Column(name = "MAX_PCT", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double maxPct;

    @javax.persistence.Column(name = "MIN_YR_PCT", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double minYrPct;

    @javax.persistence.Column(name = "MAX_YR_PCT", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double maxYrPct;

    @javax.persistence.Column(name = "IS_OPEN", insertable = true, updatable = true)
    @Basic
    @Type(type = "yes_no")
    private boolean open;

    //@ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    @ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
    @javax.persistence.JoinColumn(name = "COUNTRY_ID", referencedColumnName = "ID")
    private Country country;

    //@ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    @ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
    @javax.persistence.JoinColumn(name = "YEAR_ID", referencedColumnName = "ID")
    private Year year;

    @OneToMany(mappedBy = "countryProgram", cascade = CascadeType.ALL) //************************no fetch
    private Collection<ProgramQuarter> programQuarters=new HashSet<ProgramQuarter>();

    public Double getMinPct() {
        return minPct;
    }

    public void setMinPct(Double minPct) {
        this.minPct = minPct;
    }

    public Double getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(Double maxPct) {
        this.maxPct = maxPct;
    }

    public Double getMinYrPct() {
        return minYrPct;
    }

    public void setMinYrPct(Double minYrPct) {
        this.minYrPct = minYrPct;
    }


    public Double getMaxYrPct() {
        return maxYrPct;
    }

    public void setMaxYrPct(Double maxYrPct) {
        this.maxYrPct = maxYrPct;
    }

    public Year getYear() {
        return year;
    }

    public void setYear(Year year) {
        this.year = year;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public Collection<ProgramQuarter> getProgramQuarters() {
        return programQuarters;
    }

    public void setProgramQuarters(Collection<ProgramQuarter> programQuarters) {
        this.programQuarters = programQuarters;
    }

    public void addProgramQuarter(ProgramQuarter programQuarter){
        if(programQuarter!=null){
            programQuarters.add(programQuarter);
            programQuarter.setCountryProgram(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
