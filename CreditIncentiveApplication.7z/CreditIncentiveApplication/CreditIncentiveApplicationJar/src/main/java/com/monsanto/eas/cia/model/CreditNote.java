package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 11:39:32 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "CREDIT_NOTE")
@NamedQueries({
        @NamedQuery(name = "CreditNote.sumCreditNotesAmount", query = "select sum(cn.amount) from LdSalesCn scn inner join scn.ldSales sales inner join scn.creditNote cn  where cn.distributor.id = :distributorId and sales.salesDate between :startingDate and :endingDate"),
        @NamedQuery(name = "lookupCreditNoteForDistributorYearMonth", query = "From CreditNote creditNote where creditNote.distributor.id=:id and to_char(creditNote.date,'mm/yyyy')=:monthyear"),
        @NamedQuery(name = "lookupCreditNoteWithId", query = "From CreditNote creditNote where creditNote.id=:id")
}
)
public class CreditNote extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @Basic(optional = true)
    @Column(name = "CN_SEQUENCE", nullable = true, length = 20)
    private String code;

    @Basic(optional = false)
    @Temporal(TemporalType.DATE)
    @Column(name = "CN_DATE", nullable = false)
    private Date date = new Date();

    @ManyToOne(optional = false)
    @JoinColumn(name = "DISTRIBUTOR_ID", nullable = false)
    private SapDistributor distributor;

    @ManyToOne(optional = false)
    @JoinColumn(name = "TAX_RESERVE_ID", nullable = false)
    private TaxReserve taxReserve;

    @Column(name = "AMOUNT", nullable = false)
    private BigDecimal amount;

    @OneToMany(mappedBy = "creditNote", fetch = FetchType.LAZY)
    private Collection<LdSalesCn> salesCns = new ArrayList<LdSalesCn>();


    public Collection<LdSalesCn> getSalesCns() {
        return salesCns;
    }

    public void setSalesCns(Collection<LdSalesCn> salesCns) {
        this.salesCns = salesCns;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public TaxReserve getTaxReserve() {
        return taxReserve;
    }

    public void setTaxReserve(TaxReserve taxReserve) {
        this.taxReserve = taxReserve;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public SapDistributor getDistributor() {
        return distributor;
    }

    public void setDistributor(SapDistributor distributor) {
        this.distributor = distributor;
    }


    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof CreditNote) {
            return new EqualsBuilder().append(this.getCode(), ((CreditNote) o).getCode()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7, 7).append(this.getCode()).toHashCode();
    }
}
