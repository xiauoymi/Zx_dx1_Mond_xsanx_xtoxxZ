package com.monsanto.eas.cia.model;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:56 PM To change this template use File |
 * Settings | File Templates.
 */

@Entity
@NamedNativeQueries(
    {
        @NamedNativeQuery(name = "distributorCreditView", query = "select * from cia. DISTRIBUTOR_CN_VIEW", resultClass = DistributorCnView.class),
        @NamedNativeQuery(name = "distributorCreditViewForYearMonth", query = "select * from cia. DISTRIBUTOR_CN_VIEW where cn_id is not null and PRG_MONTH in (?1)  and PRG_YEAR=:yr", resultClass = DistributorCnView.class),
        @NamedNativeQuery(name = "distinctDistributorsWithCreditNotes", query = "select * from cia. DISTRIBUTOR_CN_VIEW where cn_id is not null", resultClass = DistributorCnView.class),
        @NamedNativeQuery(name = "distinctDistributorsWithNoCreditNotes", query = "select * from cia. DISTRIBUTOR_CN_VIEW where cn_id is null and PRG_MONTH in (?1) and PRG_YEAR=:yr", resultClass = DistributorCnView.class),
        @NamedNativeQuery(name = "distributorSalesForYearMonth", query = "select * from cia. DISTRIBUTOR_CN_VIEW where dist_id=:id and PRG_MONTH in (?1) and PRG_YEAR=:yr", resultClass = DistributorCnView.class)
})
public class DistributorCnView implements Serializable {

  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;


  private String salesId;

  private String distId;

  private String distName;

  private String symId;

  private boolean creditNoteSent;

  private String taxReserveId;

  private String programYear;

  private String programMonth;

  private String creditNoteId;

  @Id
  @Column(name = "SALES_ID", nullable = false, length = 50)
  public String getSalesId() {
    return salesId;
  }

  public void setSalesId(final String salesId) {
    this.salesId = salesId;
  }

  @Column(name = "DIST_NAME")
  public String getDistName() {
    return distName;
  }

  public void setDistName(String distName) {
    this.distName = distName;
  }

  @Column(name ="SYM_ID")
  public String getSymId() {
    return symId;
  }

  public void setSymId(String symId) {
    this.symId = symId;
  }
  
  @Transient
  public boolean isCreditNoteSent() {
    return creditNoteSent;
  }

  public void setCreditNoteSent(boolean creditNoteSent) {
    this.creditNoteSent = creditNoteSent;
  }

  @Column(name ="DIST_ID") 
  public String getDistId() {
    return distId;
  }

  public void setDistId(String distId) {
    this.distId = distId;
  }

  @Column(name="TAX_RESERVE_ID")
  public String getTaxReserveId() {
    return taxReserveId;
  }

  public void setTaxReserveId(String taxReserveId) {
    this.taxReserveId = taxReserveId;
  }

  @Column(name="PRG_YEAR")
  public String getProgramYear() {
    return programYear;
  }

  public void setProgramYear(String programYear) {
    this.programYear = programYear;
  }

  @Column(name="PRG_MONTH")
  public String getProgramMonth() {
    return programMonth;
  }

  public void setProgramMonth(String programMonth) {
    this.programMonth = programMonth;
  }

  @Column(name="CN_ID")
  public String getCreditNoteId() {
    return creditNoteId;
  }

  public void setCreditNoteId(String creditNoteId) {
    this.creditNoteId = creditNoteId;
  }
}
