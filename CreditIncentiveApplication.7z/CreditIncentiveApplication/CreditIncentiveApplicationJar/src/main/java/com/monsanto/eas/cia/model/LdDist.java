package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:44 PM To change this template use File |
 * Settings | File Templates.
 */
@Table(schema = "CIA", name = "LD_DIST")
@Entity
@NamedQueries({
        @NamedQuery(name = "LdDist.lookupAll", query = "FROM LdDist"),
        @NamedQuery(name = "LdDist.lookupByDistributorId", query = "SELECT a.localDealer.id FROM LdDist a WHERE a.distributor.code =:distributorId")
})
public class LdDist extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "LD_ID")
    private LocalDealer localDealer;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "DISTRIBUTOR_ID")
    private SapDistributor distributor;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="LD_PROGRAM_YEAR_ID") //@JoinColumn(name="LD_PROGRAM_YEAR_ID", nullable=false)
    private LdProgramYear ldProgramYear;

    @OneToMany(mappedBy = "ldDist", fetch=FetchType.LAZY)
    @Cascade({org.hibernate.annotations.CascadeType.ALL})
    private Set<LdSales> ldSales=new HashSet<LdSales>();

    @Basic(optional=false)
    @Type(type = "yes_no")
    @Column(name = "ACTIVE", nullable = false)
    protected boolean active=true;

    public LocalDealer getLocalDealer() {
        return localDealer;
    }

    public void setLocalDealer(LocalDealer localDealer) {
        this.localDealer = localDealer;
    }

    public SapDistributor getDistributor() {
        return distributor;
    }

    public void setDistributor(SapDistributor distributor) {
        this.distributor = distributor;
    }

    public Set<LdSales> getLdSales() {
        return ldSales;
    }

    public void setLdSales(Set<LdSales> ldSales) {
        this.ldSales = ldSales;
    }

    public void addLdSales(LdSales _ldSales){
        if(_ldSales!=null){
            _ldSales.setLdDist(this);
            ldSales.add(_ldSales);
        }
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public LdProgramYear getLdProgramYear() {
        return ldProgramYear;
    }

    public void setLdProgramYear(LdProgramYear ldProgramYear) {
        this.ldProgramYear = ldProgramYear;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof LdDist){
            LdDist other=(LdDist)o;
            return new EqualsBuilder().
                    append(this.getLocalDealer(),other.getLocalDealer()).
                    append(this.getDistributor(),other.getDistributor()).
                    append(this.getLdProgramYear(),other.getLdProgramYear()).
                    isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).
                append(this.getLocalDealer()).
                append(this.getDistributor()).
                append(this.getLdProgramYear()).
                toHashCode();
    }
}
