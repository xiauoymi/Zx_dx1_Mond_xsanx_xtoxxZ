package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:44 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "LD_INCENTIVE")
@Entity
@NamedQueries({
        @NamedQuery(name = "LdIncentive.lookupAll", query = "FROM LdIncentive"),
        @NamedQuery(name = "LdIncentive.lookupLdIncentiveByLocalDealerId", query = "FROM LdIncentive inc WHERE inc.localDealer.rfc=:rfc")
})
public class LdIncentive extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(name = "MIN_INCENTIVE", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double minIncentive;

    @javax.persistence.Column(name = "MAX_INCENTIVE", nullable = true, insertable = true, updatable = true)
    @Basic
    private Double maxIncentive;

    @Column(name = "MAX_PCT")
    private BigDecimal maxPct;

    @Column(name = "MIN_PCT")
    private BigDecimal minPct;

    @ManyToOne(cascade = CascadeType.ALL)
    @javax.persistence.JoinColumn(name = "PROGRAM_QUARTER_ID", referencedColumnName = "ID")
    private ProgramQuarter programQuarter;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "LOCAL_DEALER_ID", referencedColumnName = "ID")
    private LocalDealer localDealer;

    public Double getMinIncentive() {
        return minIncentive;
    }

    public void setMinIncentive(Double minIncentive) {
        this.minIncentive = minIncentive;
    }

    public Double getMaxIncentive() {
        return maxIncentive;
    }

    public void setMaxIncentive(Double maxIncentive) {
        this.maxIncentive = maxIncentive;
    }

    public ProgramQuarter getProgramQuarter() {
        return programQuarter;
    }

    public void setProgramQuarter(ProgramQuarter programQuarter) {
        this.programQuarter = programQuarter;
    }

    public LocalDealer getLocalDealer() {
        return localDealer;
    }

    public void setLocalDealer(LocalDealer localDealer) {
        this.localDealer = localDealer;
    }


    public BigDecimal getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(BigDecimal maxPct) {
        this.maxPct = maxPct;
    }

    public BigDecimal getMinPct() {
        return minPct;
    }

    public void setMinPct(BigDecimal minPct) {
        this.minPct = minPct;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof LdIncentive) {
            LdIncentive other = (LdIncentive) o;
            return new EqualsBuilder().
                    append(this.getLocalDealer(), other.getLocalDealer()).
                    append(this.getProgramQuarter(), other.getProgramQuarter()).
                    isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7, 7).
                append(this.getLocalDealer()).
                append(this.getProgramQuarter()).
                toHashCode();
    }
}
