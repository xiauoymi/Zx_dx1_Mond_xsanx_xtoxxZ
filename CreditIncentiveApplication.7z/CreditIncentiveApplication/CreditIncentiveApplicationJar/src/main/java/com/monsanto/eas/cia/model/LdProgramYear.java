package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:45 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "LD_PROGRAM_YEAR")
@Entity
@NamedQueries({
        @NamedQuery(name = "LdProgramYear.lookupAll", query = "FROM LdProgramYear"),
        @NamedQuery(name = "LdProgramYear.lookupLdProgramYearByYearId", query = "FROM LdProgramYear py WHERE py.year.id=:idYear")
})
public class LdProgramYear extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @Basic(optional = true)
    @Column(name = "MAX_TARGET", nullable = true, precision = 8, scale = 2)
    private Double maxTarget;

    @Basic(optional = true)
    @Column(name = "MIN_TARGET", nullable = true, precision = 8, scale = 2)
    private Double minTarget;

    @javax.persistence.Column(name = "CREDIT_NOTES_SENT", insertable = true, updatable = true)
    @Basic
    @Type(type = "yes_no")
    private boolean creditNotesSent;

    @ManyToOne(fetch = FetchType.EAGER)
    @javax.persistence.JoinColumn(name = "YEAR_ID")
    private Year year;

    @ManyToOne(fetch = FetchType.LAZY)
    @javax.persistence.JoinColumn(name = "LD_ID")
    private LocalDealer localDealer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LD_PROGRAM_YEAR_STATUS_ID")
    protected LdProgramYearStatus ldProgramYearStatus;

    public Double getMaxTarget() {
        return maxTarget;
    }

    public void setMaxTarget(Double maxTarget) {
        this.maxTarget = maxTarget;
    }

    public Double getMinTarget() {
        return minTarget;
    }

    public void setMinTarget(Double minTarget) {
        this.minTarget = minTarget;
    }

    public boolean isCreditNotesSent() {
        return creditNotesSent;
    }

    public void setCreditNotesSent(boolean creditNotesSent) {
        this.creditNotesSent = creditNotesSent;
    }

    public Year getYear() {
        return year;
    }

    public void setYear(Year year) {
        this.year = year;
    }

    public LocalDealer getLocalDealer() {
        return localDealer;
    }

    public void setLocalDealer(LocalDealer localDealer) {
        this.localDealer = localDealer;
    }

    public LdProgramYearStatus getLdProgramYearStatus() {
        return ldProgramYearStatus;
    }

    public void setLdProgramYearStatus(LdProgramYearStatus ldProgramYearStatus) {
        this.ldProgramYearStatus = ldProgramYearStatus;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof LdProgramYear){
            LdProgramYear other=(LdProgramYear)o;
            return new EqualsBuilder().
                append(this.getYear(),other.getYear()).
                append(this.getLocalDealer(),other.getLocalDealer()).
                isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).
                append(this.getYear()).
                append(this.getLocalDealer()).
                toHashCode();
    }
}
