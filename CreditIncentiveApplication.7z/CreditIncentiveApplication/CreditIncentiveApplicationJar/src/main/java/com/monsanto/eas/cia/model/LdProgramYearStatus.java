package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;
import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/02/2011
 * Time: 12:08:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="LD_PROGRAM_YEAR_STATUS")
@NamedQueries({
        @NamedQuery(name = "LdProgramYearStatus.lookupAll", query = "FROM LdProgramYearStatus")
})
public class LdProgramYearStatus extends CodeCatalogEntity {
    @Override
    public boolean equals(Object o) {
        return o instanceof DescriptionCatalogEntity && super.equals(o); 
    }
}
