package com.monsanto.eas.cia.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.*;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import com.monsanto.eas.cia.model.entity.ActiveEntity;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:45 PM To change this template use File |
 * Settings | File Templates.
 */
@Table(schema = "CIA", name = "LD_SALES")
@Entity
@NamedQueries({
    @NamedQuery(name = "LdSales.lookupAll", query = "FROM LdSales"),
    @NamedQuery(name = "LdSales.lookupBWDLSExport",
        query = "FROM LdSales a JOIN a.ldDist JOIN a.ldDist.localDealer where a.ldDist.localDealer.id = (SELECT inc.id FROM a.ldDist.localDealer.incentives inc WHERE inc.id IN (a.ldDist.localDealer.id))"),
    @NamedQuery(name="LdSales.lookupSalesWithId", query="FROM LdSales WHERE id=:id"),
    @NamedQuery(name="LdSales.lookupSalesForYearMonthDistributor", query="FROM LdSales ldSales WHERE to_char(ldSales.salesDate,'MON/yyyy')=:monthyear and ldSales.ldDist.distributor.id=:distId"),
    @NamedQuery(name = "LdSales.findSalesByIds", query="from LdSales lds where lds.id in(:idList)")
})
public class LdSales extends ActiveEntity {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  @Column(name = "SALES_DATE", nullable = true, insertable = true, updatable = true)
  @Basic
  private Date salesDate;

  @Column(name = "TRANSACTION_NUMBER", nullable = true, insertable = true, updatable = true)
  @Basic
  private String transactionNumber;

  @Basic(optional = true)
  @Column(name = "PRICE", precision = 9, scale = 2, nullable = true)
  private Double price;

  @Column(name = "SALES_VOLUME", nullable = true, insertable = true, updatable = true)
  @Basic
  private Double salesVolume;

  @Column(name = "VOLUME_ASSIGNED", nullable = true, insertable = true)
  @Basic
  private Double volumeAssigned;

  @Basic(optional = true)
  @Column(name = "VOL_TO_INCENTIVE", nullable = true, precision = 8, scale = 2)
  private Double volumeToIncentive;

  @Column(name = "INCENTIVE_AMOUNT", nullable = true, insertable = true)
  @Basic
  private Double incentiveAmount;

  @Column(name = "VALID_FOR_INCENTIVE_PLANNING", nullable = true, insertable = true, updatable = true)
  @Type(type = "yes_no")
  private boolean validForIncentivePlanning;

  @Column(name = "VALID_FOR_INCENTIVE_CALC", nullable = true, insertable = true, updatable = true)
  @Type(type = "yes_no")
  private boolean validForIncentiveCalculation;

  @ManyToOne(optional = true, fetch=FetchType.LAZY)
  @JoinColumn(name = "LD_ID_FOR_VOL_ASS_FROM", nullable = true)
  private LocalDealer assignedFrom;

  @ManyToOne(optional = false, fetch=FetchType.LAZY)
  @JoinColumn(name = "LD_DIST_ID", nullable = false)
  private LdDist ldDist;

  @ManyToOne(optional = true, fetch=FetchType.LAZY)
  @JoinColumn(name = "PRODUCT_LINE_ID", nullable = true)
  private ProductLine productLine;

  @OneToMany(mappedBy = "ldSales", fetch = FetchType.LAZY)
  private Collection<LdSalesCn> salesCns = new ArrayList<LdSalesCn>();

  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name = "DOCUMENT_TYPE_ID", referencedColumnName = "ID")
  private TransactionType transactionType;

    public Collection<LdSalesCn> getSalesCns() {
        return salesCns;
    }

    public void setSalesCns(Collection<LdSalesCn> salesCns) {
        this.salesCns = salesCns;
    }

  public void addSalesCn(LdSalesCn ldSalesCn) {
    if (ldSalesCn != null) {
      ldSalesCn.setLdSales(this);
      salesCns.add(ldSalesCn);
    }
  }

    public Date getSalesDate() {
    return salesDate;
  }

  public void setSalesDate(Date salesDate) {
    this.salesDate = salesDate;
  }

  public Double getPrice() {
    return price;
  }

  public void setPrice(Double price) {
    this.price = price;
  }

  public String getTransactionNumber() {
    return transactionNumber;
  }

  public void setTransactionNumber(String transactionNumber) {
    this.transactionNumber = transactionNumber;
  }

  public Double getSalesVolume() {
    return salesVolume;
  }

  public void setSalesVolume(Double salesVolume) {
    this.salesVolume = salesVolume;
  }

  public Double getVolumeAssigned() {
    return volumeAssigned;
  }

  public void setVolumeAssigned(Double volumeAssigned) {
    this.volumeAssigned = volumeAssigned;
  }

  public Double getVolumeToIncentive() {
    return volumeToIncentive;
  }

  public void setVolumeToIncentive(Double volumeToIncentive) {
    this.volumeToIncentive = volumeToIncentive;
  }

  public Double getIncentiveAmount() {
    return incentiveAmount;
  }

  public void setIncentiveAmount(Double incentiveAmount) {
    this.incentiveAmount = incentiveAmount;
  }

  public boolean isValidForIncentivePlanning() {
    return validForIncentivePlanning;
  }

  public void setValidForIncentivePlanning(boolean validForIncentivePlanning) {
    this.validForIncentivePlanning = validForIncentivePlanning;
  }

  public boolean isValidForIncentiveCalculation() {
    return validForIncentiveCalculation;
  }

  public void setValidForIncentiveCalculation(boolean validForIncentiveCalculation) {
    this.validForIncentiveCalculation = validForIncentiveCalculation;
  }

  public LocalDealer getAssignedFrom() {
    return assignedFrom;
  }

  public void setAssignedFrom(LocalDealer assignedFrom) {
    this.assignedFrom = assignedFrom;
  }

  public LdDist getLdDist() {
    return ldDist;
  }

  public void setLdDist(LdDist ldDist) {
    this.ldDist = ldDist;
  }

  public TransactionType getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(TransactionType transactionType) {
    this.transactionType = transactionType;
  }

  public ProductLine getProductLine() {
    return productLine;
  }

  public void setProductLine(ProductLine productLine) {
    this.productLine = productLine;
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof LdSales) {
      LdSales other = (LdSales) o;
      return new EqualsBuilder().
          append(this.getTransactionNumber(), other.getTransactionNumber()).
          isEquals();
    }
    return false;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(7, 7).append(this.getTransactionNumber()).toHashCode();
  }
}
