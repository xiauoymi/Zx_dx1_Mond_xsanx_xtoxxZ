package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 11:39:32 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "LD_SALES_CN")
@NamedQueries({
  @NamedQuery(name = "creditNotesPerSale", query = "from LdSalesCn ldSalesCn where ldSalesCn.ldSales.id=:id")
})

public class LdSalesCn extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LD_SALES_ID")
    private LdSales ldSales;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREDIT_NOTE_ID")
    private CreditNote creditNote;     

    @Column(name = "INCENTIVE_AMT", length = 10)
    private Double incentiveAmount;

    @Override
    public boolean equals(Object o) {
        if (o instanceof LdSalesCn) {
            return new EqualsBuilder().append(this.getId(), ((LdSalesCn) o).getId()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7, 7).append(this.getId()).toHashCode();
    }

    public LdSales getLdSales() {
        return ldSales;
    }

    public void setLdSales(LdSales ldSales) {
        this.ldSales = ldSales;
    }

    public CreditNote getCreditNote() {
        return creditNote;
    }

    public void setCreditNote(CreditNote creditNote) {
        this.creditNote = creditNote;
    }

  public Double getIncentiveAmount() {
    return incentiveAmount;
  }

  public void setIncentiveAmount(Double incentiveAmount) {
    this.incentiveAmount = incentiveAmount;
  }
}
