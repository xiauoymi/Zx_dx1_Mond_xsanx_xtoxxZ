/*
 Copyright:  Copyright  2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.model;

import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "CIA", name = "LD_SALES_PER_PRODUCT")
@NamedQueries({
    @NamedQuery(name = "LdSalesPerProduct.lookupLdSalesPerProductByYearAndLeader",
        query = "FROM LdSalesPerProduct lds WHERE lds.localDealerId=:ldId and lds.programQuarter.countryProgram.year.year=:year"),
    @NamedQuery(name = "LdSalesPerProduct.lookupLdSalesPerProductByYearAndLeaderAndProduct",
        query = "FROM LdSalesPerProduct lds WHERE lds.localDealerId=:ldId and lds.programQuarter.countryProgram.year.year=:year" +
                " and lds.productLine.id=:productLineId")
})
@IdClass(LdSalesPerProduct.LdSalesPerProductId.class)
public class LdSalesPerProduct implements Serializable {
    private static final long serialVersionUID = 2L;

  @Id
  private Long localDealerId;

  @Id
  private Long programQuarterId;

    @Id
    private Long productLineId;

  @ManyToOne
  @JoinColumn(name = "LD_ID", referencedColumnName = "ID", nullable = false, updatable = false, insertable = false)
  private LocalDealer localDealer;

  @ManyToOne
  @JoinColumn(name = "PROGRAM_QUARTER_ID", referencedColumnName = "ID", nullable = false, updatable = false,
      insertable = false)
  private ProgramQuarter programQuarter;

  @ManyToOne
  @JoinColumn(name = "PRODUCT_LINE_ID", referencedColumnName = "ID", nullable = false, updatable = false, insertable = false)
  private ProductLine productLine;

  @Basic
  @Column(name = "VOLUME_PER_PRODUCT_LINE", nullable = false, updatable = false, insertable = false)
  private Double volumePerProductLine;

  @Basic
  @Column(name = "INCENTIVE_PCT", nullable = false, insertable = false, updatable = false)
  private Double inventivePct;

  public Long getLocalDealerId() {
    return localDealerId;
  }

  public void setLocalDealerId(Long localDealerId) {
    this.localDealerId = localDealerId;
  }

  public Long getProgramQuarterId() {
    return programQuarterId;
  }

  public void setProgramQuarterId(Long programQuarterId) {
    this.programQuarterId = programQuarterId;
  }

  public Long getProductLineId() {
    return productLineId;
  }

  public void setProductLineId(Long productLineId) {
    this.productLineId = productLineId;
  }

  public LocalDealer getLocalDealer() {
    return localDealer;
  }

  public void setLocalDealer(LocalDealer localDealer) {
    this.localDealer = localDealer;
  }

  public ProgramQuarter getProgramQuarter() {
    return programQuarter;
  }

  public void setProgramQuarter(ProgramQuarter programQuarter) {
    this.programQuarter = programQuarter;
  }

  public ProductLine getProductLine() {
    return productLine;
  }

  public void setProductLine(ProductLine productLine) {
    this.productLine = productLine;
  }

  public Double getVolumePerProductLine() {
    return volumePerProductLine;
  }

  public void setVolumePerProductLine(Double volumePerProductLine) {
    this.volumePerProductLine = volumePerProductLine;
  }

  public Double getInventivePct() {
    return inventivePct;
  }

  public void setInventivePct(Double inventivePct) {
    this.inventivePct = inventivePct;
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof LdSalesPerQuarter) {
      LdSalesPerQuarter other = (LdSalesPerQuarter) o;
      return ((other instanceof LdSalesPerQuarter) &&
          getLocalDealer().equals(other.getLocalDealer()) &&
          getProgramQuarter().equals(other.getProgramQuarter()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(7, 7).append(this.getLocalDealer().hashCode())
        .append(this.getProgramQuarter().hashCode())
        .toHashCode();
  }

  public static class LdSalesPerProductId implements Serializable{
    @Column(name = "LD_ID", nullable = false, insertable = false, updatable = false)
    private Long localDealerId;
    @Column(name = "PROGRAM_QUARTER_ID", nullable = false, insertable = false, updatable = false)
    private Long programQuarterId;

        @Column(name = "PRODUCT_LINE_ID", nullable = false, insertable = false, updatable = false)
        private Long productLineId;

    public Long getLocalDealerId() {
      return localDealerId;
    }

    public void setLocalDealerId(Long localDealerId) {
      this.localDealerId = localDealerId;
    }

    public Long getProgramQuarterId() {
      return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
      this.programQuarterId = programQuarterId;
    }

    public Long getProductLineId() {
      return productLineId;
    }

    public void setProductLineId(Long productLineId) {
      this.productLineId = productLineId;
    }

    @Override
        public int hashCode(){
            return new HashCodeBuilder(7, 7).append(this.getLocalDealerId().hashCode())
            .append(this.getProgramQuarterId().hashCode())
            .append(this.getProductLineId())
            .toHashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if(obj instanceof LdSalesPerProductId) {
              LdSalesPerProductId other = (LdSalesPerProductId) obj;
              return ((obj instanceof LdSalesPerProductId) &&
                localDealerId.equals(other.getLocalDealerId()) &&
                programQuarterId.equals(other.getProgramQuarterId()) &&
                productLineId.equals(other.getProductLineId())
              );
            }
            return false;
        }
  }
}