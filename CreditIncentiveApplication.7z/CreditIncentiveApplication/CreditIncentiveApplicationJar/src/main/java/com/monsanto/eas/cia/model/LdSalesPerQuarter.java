/*
 Copyright:  Copyright  2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.model;

import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "CIA", name = "LD_SALES_PER_QUARTER")
@NamedQueries({
    @NamedQuery(name = "LdSalesPerQuarter.lookupLdSalesPerQuarterByYear",
        query = "FROM LdSalesPerQuarter lds WHERE lds.programQuarter.countryProgram.year.year=:year"),
    @NamedQuery(name = "LdSalesPerQuarter.lookupSalesByQuarterAndLeader",
        query = "FROM LdSalesPerQuarter lds WHERE lds.localDealerId=:ldId and lds.programQuarterId=:programQuarterId")

})
@IdClass(LdSalesPerQuarter.LdSalesPerQuarterId.class)
public class LdSalesPerQuarter implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  private Long localDealerId;

  @Id
  private Long programQuarterId;

  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name = "LD_ID", referencedColumnName = "ID", nullable = false, updatable = false, insertable = false)
  private LocalDealer localDealer;

  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name = "PROGRAM_QUARTER_ID", referencedColumnName = "ID", nullable = false, updatable = false,
      insertable = false)
  private ProgramQuarter programQuarter;

  @Basic
  @Column(name = "VOLUME_PER_QUARTER", nullable = false, updatable = false, insertable = false)
  private Double volumePerQuarter;

  @Basic
  @Column(name = "INCENTIVE_PCT", nullable = false, insertable = true, updatable = true)
  private Double inventivePct;

  public Long getLocalDealerId() {
    return localDealerId;
  }

  public void setLocalDealerId(Long localDealerId) {
    this.localDealerId = localDealerId;
  }

  public Long getProgramQuarterId() {
    return programQuarterId;
  }

  public void setProgramQuarterId(Long programQuarterId) {
    this.programQuarterId = programQuarterId;
  }

  public LocalDealer getLocalDealer() {
    return localDealer;
  }

  public void setLocalDealer(LocalDealer localDealer) {
    this.localDealer = localDealer;
  }

  public ProgramQuarter getProgramQuarter() {
    return programQuarter;
  }

  public void setProgramQuarter(ProgramQuarter programQuarter) {
    this.programQuarter = programQuarter;
  }

  public Double getVolumePerQuarter() {
    return volumePerQuarter;
  }

  public void setVolumePerQuarter(Double volumePerQuarter) {
    this.volumePerQuarter = volumePerQuarter;
  }

  public Double getInventivePct() {
    return inventivePct;
  }

  public void setInventivePct(Double inventivePct) {
    this.inventivePct = inventivePct;
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof LdSalesPerQuarter) {
      LdSalesPerQuarter other = (LdSalesPerQuarter) o;
      return ((other instanceof LdSalesPerQuarter) &&
          getLocalDealer().equals(other.getLocalDealer()) &&
          getProgramQuarter().equals(other.getProgramQuarter()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(7, 7).append(this.getLocalDealer().hashCode())
        .append(this.getProgramQuarter().hashCode())
        .toHashCode();
  }

  public static class LdSalesPerQuarterId implements Serializable {
    @Column(name = "LD_ID", nullable = false, insertable = false, updatable = false)
    private Long localDealerId;
    @Column(name = "PROGRAM_QUARTER_ID", nullable = false, insertable = false, updatable = false)
    private Long programQuarterId;

    public Long getLocalDealerId() {
      return localDealerId;
    }

    public void setLocalDealerId(Long localDealerId) {
      this.localDealerId = localDealerId;
    }

    public Long getProgramQuarterId() {
      return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
      this.programQuarterId = programQuarterId;
    }

    @Override
    public int hashCode() {
      return new HashCodeBuilder(7, 7).append(this.getLocalDealerId().hashCode())
          .append(this.getProgramQuarterId().hashCode())
          .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj instanceof LdSalesPerQuarterId) {
        LdSalesPerQuarterId other = (LdSalesPerQuarterId) obj;
        return ((obj instanceof LdSalesPerQuarterId) &&
            localDealerId.equals(other.getLocalDealerId()) &&
            programQuarterId.equals(other.getProgramQuarterId()));
      }
      return false;
    }
  }
}