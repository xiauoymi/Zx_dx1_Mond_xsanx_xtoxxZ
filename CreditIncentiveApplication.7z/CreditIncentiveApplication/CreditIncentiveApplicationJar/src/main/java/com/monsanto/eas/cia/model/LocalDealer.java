    package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.SubRegion;
import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Cascade;
import org.springframework.flex.core.io.AmfIgnore;

import javax.persistence.*;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:48 PM To change this template use File |
 * Settings | File Templates.
 */
@Table(schema = "CIA", name = "LOCAL_DEALER")
@Entity
@NamedQueries({
    @NamedQuery(name = "LocalDealer.lookupAll", query = "from LocalDealer ld left join fetch ld.district dis left join fetch ld.postalCodeArea pos left join fetch ld.subRegion reg left join fetch ld.commercialSupervisor supervisor left join fetch ld.commercialManager manager left join fetch ld.country country order by ld.posName asc"),
    @NamedQuery(name = "LocalDealer.lookupLocalDealerByRfc", query = "FROM LocalDealer ld WHERE ld.rfc=:rfc"),
    @NamedQuery(name = "LocalDealer.lookupLocalDealerByNameAndPosName",
        query = "FROM LocalDealer ld WHERE ld.name=:name and ld.posName=:posName"),
    @NamedQuery(name = "LocalDealer.lookupLocalDealerByAgreementNumberAndRfc",
        query = "FROM LocalDealer ld WHERE ld.agreementNumber=:agreementNumber and ld.rfc=:rfc"),
    @NamedQuery(name = "LocalDealer.lookupAllLocalDealerInASubRegion",
        query = "FROM LocalDealer ld where ld.subRegion.id=:id"),
    @NamedQuery(name = "LocalDealer.lookupLocalDealerById",
        query = "FROM LocalDealer ld where ld.id=:id"),
    @NamedQuery(name = "LocalDealer.lookupAllUnSignedLocalDealers", query = "from LocalDealer ld left join fetch ld.district dis left join fetch ld.postalCodeArea pos left join fetch ld.subRegion reg left join fetch ld.commercialSupervisor supervisor left join fetch ld.commercialManager manager left join fetch ld.country country order by ld.name asc")
})
public class LocalDealer extends BaseEntity {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  @Column(name = "FISCAL_NAME", nullable = true)
  private String fiscalName;

  @Basic(optional = false)
  @Column(name = "AGREEMENT_NUMBER", nullable = false, unique = true)
  private String agreementNumber;

  @Column(name = "NAME", nullable = true)
  private String name;

  @Column(name = "POS_NAME", nullable = true)
  private String posName;

  @Column(name = "ADDRESS_1", nullable = true)
  private String address1;

  @Column(name = "ADDRESS_2", nullable = true)
  private String address2;

  @Column(name = "PHONE", nullable = true)
  private String phone;

  @Column(name = "FAX", nullable = true)
  private String fax;

  @Column(name = "EMAIL", nullable = true)
  private String email;

  @Column(name = "BIRTHDAY", nullable = true)
  private Date birthday;

  @Column(name = "BUSINESS_ANIVERSARY", nullable = true)
  private Date businessAnniversary;

  @Column(name = "RFC", nullable = true)
  private String rfc;

  @OneToMany(mappedBy = "localDealer", fetch = FetchType.LAZY)
  @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.MERGE})
  private Collection<LdDist> ldDist = new ArrayList<LdDist>();

  @OneToMany(mappedBy = "localDealer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private Collection<LdIncentive> incentives = new ArrayList<LdIncentive>();

  @OneToMany(mappedBy = "localDealer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private Collection<LdProgramYear> programYears = new ArrayList<LdProgramYear>();

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "DISTRICT_ID", nullable = true)
  private District district;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "POSTAL_CODE_ID", nullable = true)
  private PostalCode postalCodeArea;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "SUB_REGION_ID", nullable = true)
  private SubRegion subRegion;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "COMMERCIAL_SUPERVISOR_ID", nullable = true)
  private CommercialSupervisor commercialSupervisor;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "COMMERCIAL_MANAGER_ID", nullable = true)
  private CommercialSupervisor commercialManager;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "COUNTRY_ID", nullable = true)
  private Country country;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getRfc() {
    return rfc;
  }

  public void setRfc(String rfc) {
    this.rfc = rfc;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPosName() {
    return posName;
  }

  public void setPosName(String posName) {
    this.posName = posName;
  }

  public String getAddress1() {
    return address1;
  }

  public void setAddress1(String address1) {
    this.address1 = address1;
  }

  public String getAddress2() {
    return address2;
  }

  public void setAddress2(String address2) {
    this.address2 = address2;
  }

  public CommercialSupervisor getCommercialManager() {
    return commercialManager;
  }

  public void setCommercialManager(CommercialSupervisor commercialManager) {
    this.commercialManager = commercialManager;
  }

  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Date getBirthday() {
    return birthday;
  }

  public void setBirthday(Date birthday) {
    this.birthday = birthday;
  }

    public Date getBusinessAnniversary() {
        return businessAnniversary;
    }

    public void setBusinessAnniversary(Date businessAnniversary) {
        this.businessAnniversary = businessAnniversary;
    }

    public String getFiscalName() {
    return fiscalName;
  }

  public void setFiscalName(String fiscalName) {
    this.fiscalName = fiscalName;
  }

  public String getAgreementNumber() {
    return agreementNumber;
  }

  public void setAgreementNumber(String agreementNumber) {
    this.agreementNumber = agreementNumber;
  }

  @AmfIgnore
  public Collection<LdIncentive> getIncentives() {
    return incentives;
  }

  public void setIncentives(Collection<LdIncentive> incentives) {
    this.incentives = incentives;
  }

  public void addIncentive(LdIncentive ldIncentive) {
    if (ldIncentive != null) {
      ldIncentive.setLocalDealer(this);
      incentives.add(ldIncentive);
    }
  }

  public CommercialSupervisor getCommercialSupervisor() {
    return commercialSupervisor;
  }

  public void setCommercialSupervisor(
      CommercialSupervisor commercialSupervisor) {
    this.commercialSupervisor = commercialSupervisor;
  }

  @AmfIgnore
  public Collection<LdDist> getLdDist() {
    return ldDist;
  }

  public void setLdDist(Collection<LdDist> ldDist) {
    this.ldDist = ldDist;
  }

  public void addLdDist(LdDist _ldDist) {
    if (_ldDist != null) {
      _ldDist.setLocalDealer(this);
      ldDist.add(_ldDist);
    }
  }

  public Collection<LdProgramYear> getProgramYears() {
    return programYears;
  }

  public void setProgramYears(Collection<LdProgramYear> programYears) {
    this.programYears = programYears;
  }

  public void addProgramYear(LdProgramYear ldProgramYear) {
    if (ldProgramYear != null) {
      ldProgramYear.setLocalDealer(this);
      programYears.add(ldProgramYear);
    }
  }    
	
	public PostalCode getPostalCodeArea() {
    return postalCodeArea;
  }

  public void setPostalCodeArea(PostalCode postalCodeArea) {
    this.postalCodeArea = postalCodeArea;
  }

  public District getDistrict() {
    return district;
  }

  public void setDistrict(District district) {
    this.district = district;
  }

  public SubRegion getSubRegion() {
    return subRegion;
  }

  public void setSubRegion(SubRegion subRegion) {
    this.subRegion = subRegion;
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof LocalDealer) {
      LocalDealer other = (LocalDealer) o;
      return new EqualsBuilder().
          append(this.getAgreementNumber(), other.getAgreementNumber()).
          isEquals();
    }
    return false;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(7, 7).append(this.getAgreementNumber()).toHashCode();
  }
}
