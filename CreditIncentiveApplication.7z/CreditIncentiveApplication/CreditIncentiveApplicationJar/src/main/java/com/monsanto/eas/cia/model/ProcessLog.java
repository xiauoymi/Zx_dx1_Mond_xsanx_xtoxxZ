package com.monsanto.eas.cia.model;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.Hibernate;
import org.hibernate.annotations.Type;

import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.model.entity.BaseEntity;

@Entity
@Table(schema = "CIA", name="PROCESS_LOG")
public class ProcessLog extends BaseEntity{			
    
	@Column(name="INTERRUPTED_MSGS", nullable=false)
	protected long interrupted      =   0;	
	
	@Column(name="SUCCESSFUL_MSGS", nullable=false)
	protected long successful       =   0;
    
	@Column(name="FAILURE_MSGS", nullable=false)
	protected long failures         =   0;
	
	@Column(name="EXCEPTION_FIRED_MSGS", nullable=false)
	protected long exceptionsFired  =   0;
	
	@Column(name="PROCESSED_MSGS", nullable=false)
	protected long processed		=	0;	
	
	@Lob
	@Column(name="DETAIL", nullable=false)
	protected Clob    detail=Hibernate.createClob("EMPTY");
	
	@Basic(optional=false)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LOG_DATE", nullable=false)
	protected Date 		date=new Date();
	
	@Type(type="yes_no")
	@Column(name="DELETE_AFTER_NEXT_READ",nullable=false)
	protected boolean deleteAfterNextRead;

	public void setProcessOutcome(ProcessOutcome outcome){
		setInterrupted(outcome.getInterrupted());
		setSuccessful(outcome.getSuccessful());
		setFailures(outcome.getFailures());
		setExceptionsFired(outcome.getExceptionsFired());
		setProcessed(outcome.getProcessed());
	}	
	
	public String getDetail() {
		try {
			Reader reader=detail.getCharacterStream();
			StringWriter writer=new StringWriter();
			char[]buffer=new char[512];
			int charsRead;
			while((charsRead=reader.read(buffer))!=-1){
				writer.write(buffer,0,charsRead);				
			}
			return writer.toString();		
		} catch (Exception e) {

		}		
		return "";
	}
	
	public void setDetail(String detail) {
		detail=detail!=null?detail.trim():"";
		if(detail.length()==0)
			detail="EMPTY";
		this.detail=Hibernate.createClob(detail);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public boolean isDeleteAfterNextRead() {
		return deleteAfterNextRead;
	}

	public void setDeleteAfterNextRead(boolean deleteAfterNextRead) {
		this.deleteAfterNextRead = deleteAfterNextRead;
	}	
	
	public long getProcessed() {
		return processed;
	}

	public void setProcessed(long processed) {
		this.processed = processed;
	}

	public long getInterrupted() {
		return interrupted;
	}

	public void setInterrupted(long interrupted) {
		this.interrupted = interrupted;
	}

	public long getSuccessful() {
		return successful;
	}

	public void setSuccessful(long successful) {
		this.successful = successful;
	}

	public long getFailures() {
		return failures;
	}

	public void setFailures(long failures) {
		this.failures = failures;
	}

	public long getExceptionsFired() {
		return exceptionsFired;
	}

	public void setExceptionsFired(long exceptionsFired) {
		this.exceptionsFired = exceptionsFired;
	}
}
