package com.monsanto.eas.cia.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 31/01/2011
 * Time: 07:54:17 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name="PRODUCT_FAMILY")
public class ProductFamily extends DescriptionCatalogEntity{
    @Override
    public boolean equals(Object o) {
        return o instanceof ProductFamily && super.equals(o);
    }
}
