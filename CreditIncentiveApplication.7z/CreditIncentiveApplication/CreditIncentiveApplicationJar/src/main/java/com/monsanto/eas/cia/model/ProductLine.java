package com.monsanto.eas.cia.model;

import javax.persistence.*;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.monsanto.eas.cia.model.entity.BaseEntity;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 12:16:36 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "PRODUCT_LINE")
@NamedQueries({
    @NamedQuery(name="ProductLine.lookUpAllProductLines", query = "From ProductLine productLine")
})
public class ProductLine extends BaseEntity {

	private static final long serialVersionUID = 8464844582412114689L;

	@ManyToOne(optional = false)
    @JoinColumn(name="SAP_PRODUCT_ID", nullable=false, unique=true)
    private SapProduct sapProduct;//This is the new product presentation

    @ManyToOne(optional=true)
    @JoinColumn(name="PRODUCT_FAMILY_ID", nullable=true)
    private ProductFamily productFamily;

    @ManyToOne(optional=true)
    @JoinColumn(name="UOM_ID", nullable=true)
    private Uom uom;
      /*
    @Basic(optional = true)
    @Column(name = "LT_CONVERSION_FACTOR", precision = 3, scale = 1, nullable = true)
    private Double ltConversionFactor;

    @Basic(optional = true)
    @Column(name = "REGS_CONVERSION_FACTOR", precision = 6, scale = 4, nullable = true)
    private Double regsConversionFactor;
    */

    public SapProduct getSapProduct() {
        return sapProduct;
    }

    public void setSapProduct(SapProduct sapProduct) {
        this.sapProduct = sapProduct;
    }

    public ProductFamily getProductFamily() {
        return productFamily;
    }

    public void setProductFamily(ProductFamily productFamily) {
        this.productFamily = productFamily;
    }

    public Uom getUom() {
        return uom;
    }

    public void setUom(Uom uom) {
        this.uom = uom;
    }
          /*
    public Double getLtConversionFactor() {
        return ltConversionFactor;
    }

    public void setLtConversionFactor(Double ltConversionFactor) {
        this.ltConversionFactor = ltConversionFactor;
    }

    public Double getRegsConversionFactor() {
        return regsConversionFactor;
    }

    public void setRegsConversionFactor(Double regsConversionFactor) {
        this.regsConversionFactor = regsConversionFactor;
    }
    */

    @Override
    public boolean equals(Object o) {
        if (o instanceof ProductLine) {
            return new EqualsBuilder().append(this.getSapProduct(), ((ProductLine) o).getSapProduct()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7, 7).append(this.getSapProduct()).toHashCode();
    }
}
