package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:51 PM To change this template use File |
 * Settings | File Templates.
 */
@Deprecated
@javax.persistence.Table(schema = "CIA", name = "PRODUCT_PRICE")
@NamedQueries({
        @NamedQuery(name = "ProductPrice.lookupAll", query = "FROM ProductPrice"),
        @NamedQuery(name = "ProductPrice.lookupProductPriceByProductId", query = "FROM ProductPrice pp WHERE pp.product.id=:idProduct")
})
public class ProductPrice extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(name = "PRICE", nullable = false, insertable = true, updatable = true)
    @Basic
    private Double price;

    @javax.persistence.Column(name = "ACTIVE", nullable = false, insertable = true, updatable = true)
    @Basic
    @Type(type = "yes_no")
    private boolean active;

    @javax.persistence.Column(name = "MOD_USER", nullable = true, insertable = true, updatable = true)
    @Basic
    private String modUser;

    @javax.persistence.Column(name = "MOD_DATE", nullable = true, insertable = true, updatable = true)
    @Basic
    private Date modDate;

    /*@ManyToOne
    @JoinColumn(name = "UOM_ID", referencedColumnName = "ID", nullable = false)*/
    @Deprecated
    private Uom uom;

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    @Deprecated
    public Uom getUom() {
        return uom;
    }

    @Deprecated
    public void setUom(Uom uom) {
        this.uom = uom;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
