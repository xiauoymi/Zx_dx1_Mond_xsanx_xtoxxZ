package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.ActiveEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.time.DateFormatUtils;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:52 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "PROGRAM_QUARTER")
@NamedQueries({
    @NamedQuery(name="ProgramQuarter.lookupValidProgramQuarterBetweenDates", query="select pq from ProgramQuarter pq inner join pq.countryProgram cp inner join cp.year y where pq.quarterStart <= :endingDate and pq.quarterEnd >= :startingDate and y.year=:year "),
    @NamedQuery(name = "ProgramQuarter.lookupProgramQuarterWithDates", query = "select pq from ProgramQuarter pq where :quarterDate between pq.quarterStart and pq.quarterEnd"),
    @NamedQuery(name = "ProgramQuarter.findByQuarterNumAndYear", query = "select pq from ProgramQuarter pq inner join pq.quarterType type inner join pq.countryProgram cp inner join cp.year y where y.year = :year and type.quarterNum = :quarterNum"),
    @NamedQuery(name = "ProgramQuarter.lookupByYear", query = "select pq from ProgramQuarter pq inner join fetch pq.quarterType inner join pq.countryProgram cp inner join cp.year y where y.year = :year order by pq.quarterType.quarterNum"),
    @NamedQuery(name = "ProgramQuarter.lookupProgramQuarterWithDateAndCountry", query = "select pq from ProgramQuarter pq where :quarterDate between pq.quarterStart and pq.quarterEnd and pq.countryProgram.country.id=:countryId")
})
public class ProgramQuarter extends ActiveEntity {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  @Basic(optional = false)
  @Column(name = "QUARTER_START", nullable = false)
  private Date quarterStart = null;

  @Basic(optional = false)
  @Column(name = "QUARTER_END", nullable = false)
  private Date quarterEnd = null;

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "QUARTER_TYPE_ID", nullable = false)
  private QuarterType quarterType;

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "COUNTRY_PROGRAM_ID", nullable = false)
  private CountryProgramYrPct countryProgram;

  public Date getQuarterStart() {
    return quarterStart;
  }

  public String getQuarterStartString() {
    if (this.quarterStart != null)
      return DateFormatUtils.format(this.quarterStart, "yyyy-MM-dd");
    return null;
  }

  public String getQuarterStartString(String pattern) {
    if (this.quarterStart != null)
      return DateFormatUtils.format(this.quarterStart, pattern);
    return null;
  }

  public void setQuarterStart(Date quarterStart) {
    this.quarterStart = quarterStart;
  }

  public Date getQuarterEnd() {
    return quarterEnd;
  }

  public String getQuarterEndString(String pattern) {
    if (this.quarterEnd != null)
      return DateFormatUtils.format(this.quarterEnd, pattern);
    return null;
  }

  public String getQuarterEndString() {
    if (this.quarterEnd != null)
      return DateFormatUtils.format(this.quarterEnd, "yyyy-MM-dd");
    return null;
  }

  public void setQuarterEnd(Date quarterEnd) {
    this.quarterEnd = quarterEnd;
  }

  public QuarterType getQuarterType() {
    return quarterType;
  }

  public void setQuarterType(QuarterType quarterType) {
    this.quarterType = quarterType;
  }

  public CountryProgramYrPct getCountryProgram() {
    return countryProgram;
  }

  public void setCountryProgram(
      CountryProgramYrPct countryProgram) {
    this.countryProgram = countryProgram;
  }

    @Override
  public boolean equals(Object o) {
    if (o instanceof ProgramQuarter) {
      ProgramQuarter other = (ProgramQuarter) o;
      return new EqualsBuilder().append(
          this.getQuarterStartString(),
          other.getQuarterStartString()
      ).append(
          this.getQuarterEndString(),
          other.getQuarterEndString()
      )
          .isEquals();
    }
    return false;
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder().
        append(this.getQuarterStartString()).
        append(this.getQuarterEndString()).
        toHashCode();
  }
}
