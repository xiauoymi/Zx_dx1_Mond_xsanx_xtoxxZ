package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:53 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@javax.persistence.Table(schema = "CIA", name = "QUARTER_TYPE")
@NamedQueries({
        @NamedQuery(name = "QuarterType.lookupAllQuarters", query = "FROM QuarterType qt ")
})
public class QuarterType extends DescriptionCatalogEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;
    
    @Basic
    @javax.persistence.Column(name = "QUARTER_NUM", nullable = false, unique=true)
    private Integer quarterNum;


    public Integer getQuarterNum() {
        return quarterNum;
    }

    public void setQuarterNum(Integer quarterNum) {
        this.quarterNum = quarterNum;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof QuarterType){
            QuarterType other=(QuarterType)o;            
            return new EqualsBuilder().
                append(this.getQuarterNum(),other.getQuarterNum()).
                isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).append(this.getQuarterNum()).toHashCode();
    }
}
