package com.monsanto.eas.cia.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 27/11/12
 * Time: 11:48 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SALES_QTR_DLR_DIST_VIEW")
@NamedQueries(value = {
        @NamedQuery(name = "SalesQtrDlrDistView.findByDistributorAndProgramQuarterId",
                query = "select v from SalesQtrDlrDistView v where v.distributorId = :distributorId and v.id.programQuarterId = :programQuarterId"),
        @NamedQuery(name = "SalesQtrDlrDistView.findIncentiveDebtByDistQuarterYearGroupedByDist",
                query = "select sum(v.totalToIncentive), sum(v.cnIncentiveAmt), sum(v.incentiveAmount) from SalesQtrDlrDistView v where v.distributorId = :distributorId and v.id.programQuarterId = :programQuarterId"),
        @NamedQuery(name = "SalesQtrDlrDistView.findCreditNoteAdjustmentsByDistQuarterYearGroupedByDist",
                query = "select sum(v.incentiveAmount), sum(v.cnIncentiveAmt) from SalesQtrDlrDistView v where v.distributorId = :distributorId and v.id.programQuarterId = :programQuarterId")
})
public class SalesQtrDlrDistView {

    @EmbeddedId
    private SalesQtrDlrDistViewId id;

    @Column(name = "DISTRIBUTOR", insertable = false, updatable = false)
    private String distributor;

    @Column(name = "DISTRIBUTOR_ID", insertable = false, updatable = false)
    private Long distributorId;

    @Column(name = "DEALER_ID", insertable = false, updatable = false)
    private Long dealerId;

    @Column(name = "DEALER", insertable = false, updatable = false)
    private String dealer;

    @Column(name = "QUARTER_START", insertable = false, updatable = false)
    private Date quarterStart;

    @Column(name = "QUARTER_END", insertable = false, updatable = false)
    private Date quarterEnd;

    @Column(name = "QUARTER_NUM", insertable = false, updatable = false)
    private Integer quarterNum;

    @Column(name = "YEAR", insertable = false, updatable = false)
    private Integer year;

    @Column(name = "MIN_PCT", insertable = false, updatable = false)
    private BigDecimal minPct;

    @Column(name = "MAX_PCT", insertable = false, updatable = false)
    private BigDecimal maxPct;

    @Column(name = "MIN_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal minIncentive;

    @Column(name = "MAX_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal maxIncentive;

    @Column(name = "VOLUME", insertable = false, updatable = false)
    private BigDecimal volume;

    @Column(name = "COST", insertable = false, updatable = false)
    private BigDecimal cost;

    @Column(name = "INCENTIVE_PCT", insertable = false, updatable = false)
    private BigDecimal incentivePct;

    /**
     * Total incentive calculation based on results.
     */
    @Column(name = "TOTAL_TO_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal totalToIncentive;

    /**
     * Total incentive already payed with recalculations
     */
    @Column(name = "INCENTIVE_AMOUNT", insertable = false, updatable = false)
    private BigDecimal incentiveAmount;

    /**
     * Total incentive amount without recalculation fixes, this field is useless.
     */
    @Column(name = "CN_INCENTIVE_AMT", insertable = false, updatable = false)
    private BigDecimal cnIncentiveAmt;

    public SalesQtrDlrDistViewId getId() {
        return id;
    }

    public void setId(SalesQtrDlrDistViewId id) {
        this.id = id;
    }

    public BigDecimal getIncentiveAmount() {
        return incentiveAmount;
    }

    public void setIncentiveAmount(BigDecimal incentiveAmount) {
        this.incentiveAmount = incentiveAmount;
    }

    public Long getDealerId() {
        return dealerId;
    }

    public void setDealerId(Long dealerId) {
        this.dealerId = dealerId;
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }

    public String getDealer() {
        return dealer;
    }

    public void setDealer(String dealer) {
        this.dealer = dealer;
    }

    public Date getQuarterStart() {
        return quarterStart;
    }

    public void setQuarterStart(Date quarterStart) {
        this.quarterStart = quarterStart;
    }

    public Date getQuarterEnd() {
        return quarterEnd;
    }

    public void setQuarterEnd(Date quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public Integer getQuarterNum() {
        return quarterNum;
    }

    public void setQuarterNum(Integer quarterNum) {
        this.quarterNum = quarterNum;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public BigDecimal getMinPct() {
        return minPct;
    }

    public void setMinPct(BigDecimal minPct) {
        this.minPct = minPct;
    }

    public BigDecimal getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(BigDecimal maxPct) {
        this.maxPct = maxPct;
    }

    public BigDecimal getMinIncentive() {
        return minIncentive;
    }

    public void setMinIncentive(BigDecimal minIncentive) {
        this.minIncentive = minIncentive;
    }

    public BigDecimal getMaxIncentive() {
        return maxIncentive;
    }

    public void setMaxIncentive(BigDecimal maxIncentive) {
        this.maxIncentive = maxIncentive;
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public void setVolume(BigDecimal volume) {
        this.volume = volume;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public BigDecimal getIncentivePct() {
        return incentivePct;
    }

    public void setIncentivePct(BigDecimal incentivePct) {
        this.incentivePct = incentivePct;
    }

    public BigDecimal getTotalToIncentive() {
        return totalToIncentive;
    }

    public void setTotalToIncentive(BigDecimal totalToIncentive) {
        this.totalToIncentive = totalToIncentive;
    }

    public BigDecimal getCnIncentiveAmt() {
        return cnIncentiveAmt;
    }

    public void setCnIncentiveAmt(BigDecimal cnIncentiveAmt) {
        this.cnIncentiveAmt = cnIncentiveAmt;
    }
}
