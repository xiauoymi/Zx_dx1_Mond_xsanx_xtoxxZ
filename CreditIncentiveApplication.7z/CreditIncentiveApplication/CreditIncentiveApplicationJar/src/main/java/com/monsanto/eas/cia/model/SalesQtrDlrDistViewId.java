package com.monsanto.eas.cia.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 27/11/12
 * Time: 05:45 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class SalesQtrDlrDistViewId implements Serializable {


    @Column(name = "PROGRAM_QUARTER_ID", insertable = false, updatable = false)
    private Long programQuarterId;

    @Column(name = "LD_DIST_ID", insertable = false, updatable = false)
    private Long ldDistId;


    public Long getLdDistId() {
        return ldDistId;
    }

    public void setLdDistId(Long ldDistId) {
        this.ldDistId = ldDistId;
    }

    public Long getProgramQuarterId() {
        return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
        this.programQuarterId = programQuarterId;
    }

}
