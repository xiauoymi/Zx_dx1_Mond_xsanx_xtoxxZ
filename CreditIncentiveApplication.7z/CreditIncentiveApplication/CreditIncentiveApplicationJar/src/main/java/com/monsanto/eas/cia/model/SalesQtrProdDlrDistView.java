package com.monsanto.eas.cia.model;

import org.omg.CORBA.PRIVATE_MEMBER;

import javax.persistence.*;
import java.math.BigDecimal;
import java.security.PrivateKey;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 27/11/12
 * Time: 11:48 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SALES_QTR_PROD_DLR_DIST_VIEW")
@NamedQueries(value = {
        @NamedQuery(name = "SalesQtrProdDlrDistView.findDistributorStatementPerDealerAndProduct",
                query = "select new com.monsanto.eas.cia.vo.DistributorStatementPerDealerAndProductVO(" +
                        "     pv.distributorId" +
                        "    ,pv.agreementNumber" +
                        "    ,pv.dealer" +
                        "    ,pv.family" +
                        "    ,pv.presentation" +
                        "    ,pv.volume" +
                        "    ,pv.totalToIncentive" +
                        "    ,pv.price)" +
                        "from SalesQtrProdDlrDistView pv\n" +
                        "where pv.programQuarterId = :programQuarterId\n" +
                        "and pv.distributorId = :id\n" +
                        "order by pv.agreementNumber, pv.family, pv.presentation"
        )
})
public class SalesQtrProdDlrDistView {

    @Id
    @Column(name = "ID", insertable = false, updatable = false)
    private Long id;

    @Column(name = "DISTRIBUTOR_ID", insertable = false, updatable = false)
    private Long distributorId;

    @Column(name = "DISTRIBUTOR", insertable = false, updatable = false)
    private String distributor;

    @Column(name = "DEALER_ID", insertable = false, updatable = false)
    private Long dealerId;

    @Column(name = "DEALER", insertable = false, updatable = false)
    private String dealer;

    @Column(name = "AGREEMENT_NUMBER", insertable = false, updatable = false)
    private String agreementNumber;

    @Column(name = "PRODUCT_ID", insertable = false, updatable = false)
    private Long productId;

    @Column(name = "PRODUCT", insertable = false, updatable = false)
    private String product;

    @Column(name = "FAMILY", insertable = false, updatable = false)
    private String family;

    @Column(name = "PRESENTATION", insertable = false, updatable = false)
    private String presentation;

    @Column(name = "SYM_ID", insertable = false, updatable = false)
    private String symId;

    @Column(name = "PROGRAM_QUARTER_ID", insertable = false, updatable = false)
    private Long programQuarterId;

    @Column(name = "QUARTER_START", insertable = false, updatable = false)
    private Date quarterStart;

    @Column(name = "QUARTER_END", insertable = false, updatable = false)
    private Date quarterEnd;

    @Column(name = "QUARTER_NUM", insertable = false, updatable = false)
    private Integer quarterNum;

    @Column(name = "YEAR", insertable = false, updatable = false)
    private Integer year;

    @Column(name = "MIN_PCT", insertable = false, updatable = false)
    private BigDecimal minPct;

    @Column(name = "MAX_PCT", insertable = false, updatable = false)
    private BigDecimal maxPct;

    @Column(name = "MIN_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal minIncentive;

    @Column(name = "MAX_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal maxIncentive;

    @Column(name = "VOLUME", insertable = false, updatable = false)
    private BigDecimal volume;

    @Column(name = "COST", insertable = false, updatable = false)
    private BigDecimal cost;

    @Column(name = "PRICE", insertable = false, updatable = false)
    private BigDecimal price;

    @Column(name = "INCENTIVE_PCT", insertable = false, updatable = false)
    private BigDecimal incentivePct;

    @Column(name = "TOTAL_TO_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal totalToIncentive;

    @Column(name = "CN_INCENTIVE_AMT", insertable = false, updatable = false)
    private BigDecimal cnIncentiveAmt;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public Long getDealerId() {
        return dealerId;
    }

    public void setDealerId(Long dealerId) {
        this.dealerId = dealerId;
    }

    public String getDealer() {
        return dealer;
    }

    public void setDealer(String dealer) {
        this.dealer = dealer;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public String getSymId() {
        return symId;
    }

    public void setSymId(String symId) {
        this.symId = symId;
    }

    public Long getProgramQuarterId() {
        return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
        this.programQuarterId = programQuarterId;
    }

    public Date getQuarterStart() {
        return quarterStart;
    }

    public void setQuarterStart(Date quarterStart) {
        this.quarterStart = quarterStart;
    }

    public Date getQuarterEnd() {
        return quarterEnd;
    }

    public void setQuarterEnd(Date quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public Integer getQuarterNum() {
        return quarterNum;
    }

    public void setQuarterNum(Integer quarterNum) {
        this.quarterNum = quarterNum;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public BigDecimal getMinPct() {
        return minPct;
    }

    public void setMinPct(BigDecimal minPct) {
        this.minPct = minPct;
    }

    public BigDecimal getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(BigDecimal maxPct) {
        this.maxPct = maxPct;
    }

    public BigDecimal getMinIncentive() {
        return minIncentive;
    }

    public void setMinIncentive(BigDecimal minIncentive) {
        this.minIncentive = minIncentive;
    }

    public BigDecimal getMaxIncentive() {
        return maxIncentive;
    }

    public void setMaxIncentive(BigDecimal maxIncentive) {
        this.maxIncentive = maxIncentive;
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public void setVolume(BigDecimal volume) {
        this.volume = volume;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getIncentivePct() {
        return incentivePct;
    }

    public void setIncentivePct(BigDecimal incentivePct) {
        this.incentivePct = incentivePct;
    }

    public BigDecimal getTotalToIncentive() {
        return totalToIncentive;
    }

    public void setTotalToIncentive(BigDecimal totalToIncentive) {
        this.totalToIncentive = totalToIncentive;
    }

    public BigDecimal getCnIncentiveAmt() {
        return cnIncentiveAmt;
    }

    public void setCnIncentiveAmt(BigDecimal cnIncentiveAmt) {
        this.cnIncentiveAmt = cnIncentiveAmt;
    }
}
