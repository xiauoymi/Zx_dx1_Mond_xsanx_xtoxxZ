package com.monsanto.eas.cia.model;

import org.omg.CORBA.PRIVATE_MEMBER;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 27/11/12
 * Time: 11:48 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SALES_VIEW")
@NamedQueries(value = {
        @NamedQuery(name = "SalesView.findByDistributorAndProgramQuarterAndCreditNoteNull",
                query = "select sv from SalesView sv where sv.distributorId = :distributorId and sv.programQuarterId = :programQuarterId and sv.creditNoteId is null"
        ),
        @NamedQuery(name = "SalesView.findDistributorStatementPerSubRegion",
                query = "select new com.monsanto.eas.cia.vo.DistributorStatementPerSubRegionVO(sv.subRegion, sum(sv.salesIncentiveAmount)) from SalesView sv where sv.programQuarterId = :programQuarterId and sv.distributorId = :distributorId group by sv.subRegionId, sv.subRegion")
})
public class SalesView {

    @Id
    @Column(name = "ID", insertable = false, updatable = false)
    private Long id;

    @Column(name = "DISTRIBUTOR_ID", insertable = false, updatable = false)
    private Long distributorId;

    @Column(name = "DISTRIBUTOR", insertable = false, updatable = false)
    private String distributor;

    @Column(name = "DEALER_ID", insertable = false, updatable = false)
    private Long dealerId;

    @Column(name = "DEALER", insertable = false, updatable = false)
    private String dealer;

    @Column(name = "FISCAL_NAME", insertable = false, updatable = false)
    private String fiscalName;

    @Column(name = "RFC", insertable = false, updatable = false)
    private String rfc;

    @Column(name = "AGREEMENT_NUMBER", insertable = false, updatable = false)
    private String agreementNumber;

    @Column(name = "SUB_REGION", insertable = false, updatable = false)
    private String subRegion;

    @Column(name = "SUB_REGION_ID", insertable = false, updatable = false)
    private Long subRegionId;

    @Column(name = "PRODUCT_ID", insertable = false, updatable = false)
    private Long productId;

    @Column(name = "PRODUCT", insertable = false, updatable = false)
    private String product;

    @Column(name = "FAMILY", insertable = false, updatable = false)
    private String family;

    @Column(name = "PRESENTATION", insertable = false, updatable = false)
    private String presentation;

    @Column(name = "SYM_ID", insertable = false, updatable = false)
    private String symId;

    /*
    @Column(name = "LT_CONVERSION_FACTOR", insertable = false, updatable = false)
    private BigDecimal ltConversionFactor;
    */

    @Column(name = "PROGRAM_QUARTER_ID", insertable = false, updatable = false)
    private Long programQuarterId;

    @Column(name = "QUARTER_START", insertable = false, updatable = false)
    private Date quarterStart;

    @Column(name = "QUARTER_END", insertable = false, updatable = false)
    private Date quarterEnd;

    @Column(name = "QUARTER_NUM", insertable = false, updatable = false)
    private Integer quarterNum;

    @Column(name = "YEAR", insertable = false, updatable = false)
    private Integer year;

    @Column(name = "MIN_PCT", insertable = false, updatable = false)
    private BigDecimal minPct;

    @Column(name = "MAX_PCT", insertable = false, updatable = false)
    private BigDecimal maxPct;

    @Column(name = "MIN_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal minIncentive;

    @Column(name = "MAX_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal maxIncentive;

    @Column(name = "SALES_ID", insertable = false, updatable = false)
    private Long salesId;

    @Column(name = "SALES_CN_ID", insertable = false, updatable = false)
    private Long salesCnId;

    @Column(name = "CREDIT_NOTE_ID", insertable = false, updatable = false)
    private Long creditNoteId;

    @Column(name = "SALES_STATUS", insertable = false, updatable = false)
    private char salesStatus;

    @Column(name = "SALES_DATE", insertable = false, updatable = false)
    private Date salesDate;

    @Column(name = "SALES_VOLUME", insertable = false, updatable = false)
    private BigDecimal salesVolume;

    @Column(name = "VOLUME_TO_INCENTIVE", insertable = false, updatable = false)
    private BigDecimal volumeToIncentive;

    @Column(name = "PRICE", insertable = false, updatable = false)
    private BigDecimal price;

    @Column(name = "SALES_INCENTIVE_AMOUNT", insertable = false, updatable = false)
    private BigDecimal salesIncentiveAmount;

    @Column(name = "SALES_CN_INCENTIVE_AMT", insertable = false, updatable = false)
    private BigDecimal salesCnIncentiveAmt;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public Long getDealerId() {
        return dealerId;
    }

    public void setDealerId(Long dealerId) {
        this.dealerId = dealerId;
    }

    public String getDealer() {
        return dealer;
    }

    public void setDealer(String dealer) {
        this.dealer = dealer;
    }

    public String getFiscalName() {
        return fiscalName;
    }

    public void setFiscalName(String fiscalName) {
        this.fiscalName = fiscalName;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getSubRegion() {
        return subRegion;
    }

    public void setSubRegion(String subRegion) {
        this.subRegion = subRegion;
    }

    public Long getSubRegionId() {
        return subRegionId;
    }

    public void setSubRegionId(Long subRegionId) {
        this.subRegionId = subRegionId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public String getSymId() {
        return symId;
    }

    public void setSymId(String symId) {
        this.symId = symId;
    }

    public Long getProgramQuarterId() {
        return programQuarterId;
    }

    public void setProgramQuarterId(Long programQuarterId) {
        this.programQuarterId = programQuarterId;
    }

    public Date getQuarterStart() {
        return quarterStart;
    }

    public void setQuarterStart(Date quarterStart) {
        this.quarterStart = quarterStart;
    }

    public Date getQuarterEnd() {
        return quarterEnd;
    }

    public void setQuarterEnd(Date quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public Integer getQuarterNum() {
        return quarterNum;
    }

    public void setQuarterNum(Integer quarterNum) {
        this.quarterNum = quarterNum;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public BigDecimal getMinPct() {
        return minPct;
    }

    public void setMinPct(BigDecimal minPct) {
        this.minPct = minPct;
    }

    public BigDecimal getMaxPct() {
        return maxPct;
    }

    public void setMaxPct(BigDecimal maxPct) {
        this.maxPct = maxPct;
    }

    public BigDecimal getMinIncentive() {
        return minIncentive;
    }

    public void setMinIncentive(BigDecimal minIncentive) {
        this.minIncentive = minIncentive;
    }

    public BigDecimal getMaxIncentive() {
        return maxIncentive;
    }

    public void setMaxIncentive(BigDecimal maxIncentive) {
        this.maxIncentive = maxIncentive;
    }

    public Long getSalesId() {
        return salesId;
    }

    public void setSalesId(Long salesId) {
        this.salesId = salesId;
    }

    public Long getSalesCnId() {
        return salesCnId;
    }

    public void setSalesCnId(Long salesCnId) {
        this.salesCnId = salesCnId;
    }

    public Long getCreditNoteId() {
        return creditNoteId;
    }

    public void setCreditNoteId(Long creditNoteId) {
        this.creditNoteId = creditNoteId;
    }

    public char getSalesStatus() {
        return salesStatus;
    }

    public void setSalesStatus(char salesStatus) {
        this.salesStatus = salesStatus;
    }

    public Date getSalesDate() {
        return salesDate;
    }

    public void setSalesDate(Date salesDate) {
        this.salesDate = salesDate;
    }

    public BigDecimal getSalesVolume() {
        return salesVolume;
    }

    public void setSalesVolume(BigDecimal salesVolume) {
        this.salesVolume = salesVolume;
    }

    public BigDecimal getVolumeToIncentive() {
        return volumeToIncentive;
    }

    public void setVolumeToIncentive(BigDecimal volumeToIncentive) {
        this.volumeToIncentive = volumeToIncentive;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getSalesIncentiveAmount() {
        return salesIncentiveAmount;
    }

    public void setSalesIncentiveAmount(BigDecimal salesIncentiveAmount) {
        this.salesIncentiveAmount = salesIncentiveAmount;
    }

    public BigDecimal getSalesCnIncentiveAmt() {
        return salesCnIncentiveAmt;
    }

    public void setSalesCnIncentiveAmt(BigDecimal salesCnIncentiveAmt) {
        this.salesCnIncentiveAmt = salesCnIncentiveAmt;
    }

    /*
    public BigDecimal getLtConversionFactor() {
        return ltConversionFactor;
    }

    public void setLtConversionFactor(BigDecimal ltConversionFactor) {
        this.ltConversionFactor = ltConversionFactor;
    }
    */
}
