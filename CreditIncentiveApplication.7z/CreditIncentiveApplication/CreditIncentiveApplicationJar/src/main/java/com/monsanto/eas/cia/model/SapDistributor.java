package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;

import javax.persistence.*;


/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 1/02/2011
 * Time: 04:42:39 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "SAP_DISTRIBUTOR")
@NamedQueries({
        @NamedQuery(name = "SapDistributor.lookupAll", query = "FROM SapDistributor sd ORDER BY sd.description asc", hints = {@QueryHint(name = "org.hibernate.cacheable", value = "true")}),
        @NamedQuery(name = "SapDistributor.lookupSapDistributorById", query = "FROM SapDistributor d WHERE d.id=:id"),
        @NamedQuery(name = "SapDistributor.lookupDistributorByCode", query = "FROM SapDistributor d WHERE d.code=:code"),
        @NamedQuery(name = "SapDistributor.lookupSapDistributorByCodeOrDescriptionOrEmail", query = "from SapDistributor dis where dis.description like :filter or dis.code like :filter or dis.email like :filter")
})
public class SapDistributor extends CodeCatalogEntity {

    @Column(name = "EMAIL", length = 100)
    private String email;

    @Column(name = "DIVISION", length = 150)
    private String division;

    @Column(name = "DISTRIBUTION_CHANNEL", length = 150)
    private String distributionChannel;

    @Column(name = "SALES_ORGANIZATION", length = 150)
    private String salesOrganization;

    @Transient
    private boolean sendEmail;

    public boolean isSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(boolean sendEmail) {
        this.sendEmail = sendEmail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getDistributionChannel() {
        return distributionChannel;
    }

    public void setDistributionChannel(String distributionChannel) {
        this.distributionChannel = distributionChannel;
    }

    public String getSalesOrganization() {
        return salesOrganization;
    }

    public void setSalesOrganization(String salesOrganization) {
        this.salesOrganization = salesOrganization;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof SapDistributor && super.equals(o);
    }

}
