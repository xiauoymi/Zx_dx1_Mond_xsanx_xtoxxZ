package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 31/01/2011
 * Time: 07:58:55 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "SAP_PRODUCT")
@NamedQueries({
        @NamedQuery(name = "SapProduct.lookupAll", query = "FROM SapProduct"),
        @NamedQuery(name = "SapProduct.lookupProductByCode", query = "FROM SapProduct p WHERE p.code=:code")
})
public class SapProduct extends CodeCatalogEntity {

    @Override
    public boolean equals(Object o) {
        return o instanceof SapProduct && super.equals(o);
    }
}
