package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.ActiveEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 7/02/13
 * Time: 05:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Table(schema = "CIA", name = "SAP_PRODUCT_PRICE")
@Entity
@NamedQueries({
        @NamedQuery(name = "SapProductPrice.lookupAll", query = "FROM SapProductPrice pp order by pp.sapProduct.code asc, pp.startDate desc "),
        @NamedQuery(name = "SapProductPrice.lookupProductPriceById", query = "FROM SapProductPrice pp WHERE pp.id=:id"),
        @NamedQuery(name = "SapProductPrice.lookupProductPriceByTransDate", query = "FROM SapProductPrice pp WHERE pp.sapProduct.id = :productId AND (:transactionDate BETWEEN pp.startDate AND pp.endDate)")
})
public class SapProductPrice extends ActiveEntity {

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "SAP_PRODUCT_ID", nullable = false)
    private SapProduct sapProduct;

    @Column(name = "START_DATE", nullable = false)
    private Date startDate;

    @Column(name = "END_DATE", nullable = false)
    private Date endDate;

    @Column(name = "PRICE", precision = 12, scale = 4, nullable = true)
    private Double price;

    public SapProduct getSapProduct() {
        return sapProduct;
    }

    public void setSapProduct(SapProduct sapProduct) {
        this.sapProduct = sapProduct;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
