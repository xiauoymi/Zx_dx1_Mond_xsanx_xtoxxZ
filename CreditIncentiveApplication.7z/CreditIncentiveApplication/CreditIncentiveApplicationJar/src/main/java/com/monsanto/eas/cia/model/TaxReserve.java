package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 28/01/2011
 * Time: 09:56:50 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "CIA", name = "TAX_RESERVE")
@NamedQueries({
        @NamedQuery(name = "TaxReserve.lookupTaxReserveById", query = "FROM TaxReserve a WHERE a.id=:id"),
        @NamedQuery(name = "TaxReserve.lookupAll", query = "FROM TaxReserve")
})
public class TaxReserve extends BaseEntity {

    @Basic(optional = false)
    @Column(name = "CODE", precision = 2, nullable = false)
    private String code;

    @Basic(optional = false)
    @Column(name = "ACCOUNT_NUMBER", length = 10, nullable = false)
    private String accountNumber;

    @Basic(optional = true)
    @Column(name = "PROGRAM_NAME", length = 30, nullable = true)
    private String programName;

    @Basic(optional = true)
    @Column(name = "MATERIAL", length = 15, nullable = true)
    private String material;

    @Basic(optional = true)
    @Column(name = "PURPOSE", length = 15, nullable = true)
    private String purpose;

    @Basic(optional = true)
    @Column(name = "POSITION", length = 4, nullable = true)
    private String position;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
//    public Integer getCode() {
//        return code;
//    }
//
//    public void setCode(Integer code) {
//        this.code = code;
//    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof TaxReserve) {
            return new EqualsBuilder().append(this.getCode(), ((TaxReserve) o).getCode()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7, 7).append(this.getCode()).toHashCode();
    }
}
