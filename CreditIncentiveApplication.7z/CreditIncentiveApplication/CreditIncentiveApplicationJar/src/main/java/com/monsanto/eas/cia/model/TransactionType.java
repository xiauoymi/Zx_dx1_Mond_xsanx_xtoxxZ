package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.DescriptionCatalogEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:43 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "TRANSACTION_TYPE")
@Entity
@NamedQueries({
        @NamedQuery(name = "TransactionType.lookupAll", query = "FROM TransactionType")
})
public class TransactionType extends DescriptionCatalogEntity {

    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @Column(name = "CODE", nullable = false)
    private String code;

    @Column(name = "SIGN", nullable = false)
    private Integer sign;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getSign() {
        return sign;
    }

    public void setSign(Integer sign) {
        this.sign = sign;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof TransactionType && super.equals(o);
    }
}
