package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.CodeCatalogEntity;

import javax.persistence.Entity;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:55 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@javax.persistence.Table(schema = "CIA", name = "UOM")
public class Uom extends CodeCatalogEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object o) {
        return o instanceof Uom && super.equals(o);
    }    
}
