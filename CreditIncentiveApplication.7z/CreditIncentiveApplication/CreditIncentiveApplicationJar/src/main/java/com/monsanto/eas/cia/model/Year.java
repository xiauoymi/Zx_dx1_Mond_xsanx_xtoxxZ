package com.monsanto.eas.cia.model;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 12, 2010 Time: 1:30:56 PM To change this template use File |
 * Settings | File Templates.
 */
@javax.persistence.Table(schema = "CIA", name = "YEAR")
@Entity
@NamedQueries({
        @NamedQuery(name = "Year.lookupAllYears", query = "FROM Year y ORDER BY y.year DESC"),
        @NamedQuery(name = "Year.lookupYearByYear", query = "FROM Year y WHERE y.year=:year")
})
public class Year extends BaseEntity {
    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(name = "YEAR", nullable = false, insertable = true, updatable = true)
    @Basic
    private Integer year;

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof Year){
            return new EqualsBuilder().append(this.getYear(),((Year)o).getYear()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).append(this.getYear()).toHashCode();
    }
}
