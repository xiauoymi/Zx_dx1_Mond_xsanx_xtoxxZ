package com.monsanto.eas.cia.model.area;

import com.monsanto.eas.cia.model.Area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/01/2011
 * Time: 12:31:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("DISTRICT")
@NamedQueries({
   @NamedQuery(name = "District.lookupAll",query = "FROM District district ORDER BY district.description"),
   @NamedQuery(name = "District.lookupByState",query = "FROM District district where district.parentArea.id = :1 ORDER BY district.description")
}
)
public class District extends Area<State, PostalCode> {
    @Override
    public boolean equals(Object o) {
        return o instanceof District && super.equals(o);
    }
}
