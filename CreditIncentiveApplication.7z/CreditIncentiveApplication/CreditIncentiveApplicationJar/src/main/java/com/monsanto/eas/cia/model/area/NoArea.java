package com.monsanto.eas.cia.model.area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.monsanto.eas.cia.model.Area;

@Entity
@DiscriminatorValue("NO_AREA")
public abstract class NoArea extends Area<NoArea, NoArea> {
    @Override
    public boolean equals(Object o) {
        return false;
    }
}
    