package com.monsanto.eas.cia.model.area;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.monsanto.eas.cia.model.Area;
import org.springframework.flex.core.io.AmfIgnore;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/01/2011
 * Time: 12:31:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("POSTAL_CODE")
@NamedQueries(
    {
        @NamedQuery(name="PostalCode.lookupAll" , query="from PostalCode postalCode ORDER BY postalCode.code"),
        @NamedQuery(name="PostalCode.lookupByDistrictId", query="from PostalCode postalCode where postalCode.parentArea.id=:1")
    }
)
public class PostalCode extends Area<District, NoArea> {

	@Override
    public boolean equals(Object o) {
        return o instanceof PostalCode && super.equals(o);
    }
}
