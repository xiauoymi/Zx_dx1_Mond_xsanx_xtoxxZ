package com.monsanto.eas.cia.model.area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 10:28:25 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("REGION")
@NamedQueries({
    @NamedQuery(name = "Region.lookupAll",query = "FROM Region r ORDER BY r.description"),
    @NamedQuery(name = "Region.lookupRegionForSubRegion",query = "SELECT r FROM SubRegion sr JOIN sr.parentArea r where sr.id = :1 ")

        //SELECT cpyp FROM CountryProgramYrPct cpyp JOIN cpyp.year where cpyp.year.id = :1")
})
public class Region extends TerritoryArea<SubRegion> {
    @Override
    public boolean equals(Object o) {
        return o instanceof Region && super.equals(o);    
    }
}
