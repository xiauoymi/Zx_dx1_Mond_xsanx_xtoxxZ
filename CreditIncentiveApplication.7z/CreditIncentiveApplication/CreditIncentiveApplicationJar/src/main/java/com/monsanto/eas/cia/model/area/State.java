package com.monsanto.eas.cia.model.area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/01/2011
 * Time: 12:30:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("STATE")
@NamedQueries({
   @NamedQuery(name = "State.lookupAll",query = "FROM State s ORDER BY s.description"),
   @NamedQuery(name = "State.lookupBySubRegion",query = "FROM  State s  where s.parentArea.id = :1 ORDER BY s.description"),
   @NamedQuery(name = "State.lookupStateForDistrict",query = "SELECT s FROM District d JOIN d.parentArea s where d.id = :1 ORDER BY s.description")
}
)
public class State extends TerritoryArea<District> {
    @Override
    public boolean equals(Object o) {
        return o instanceof State && super.equals(o);    
    }
}
