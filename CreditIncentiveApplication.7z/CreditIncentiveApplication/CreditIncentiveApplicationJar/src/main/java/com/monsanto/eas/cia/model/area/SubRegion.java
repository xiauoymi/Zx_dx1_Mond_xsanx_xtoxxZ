package com.monsanto.eas.cia.model.area;

import com.monsanto.eas.cia.model.Area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 10:29:13 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("SUBREGION")
@NamedQueries({
    @NamedQuery(name = "SubRegion.lookupAll",query = "FROM   SubRegion sr ORDER BY sr.description"),
    @NamedQuery(name = "SubRegion.lookupByRegion",query = "FROM  SubRegion sr  where sr.parentArea.id = :1 ORDER BY sr.description")
})
public class SubRegion extends Area<Region, NoArea> {
    @Override
    public boolean equals(Object o) {
        return o instanceof SubRegion && super.equals(o);    
    }
}
