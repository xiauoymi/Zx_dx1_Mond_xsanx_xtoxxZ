package com.monsanto.eas.cia.model.area;

import com.monsanto.eas.cia.model.Area;

import javax.persistence.MappedSuperclass;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 08:20:54 PM
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public abstract class TerritoryArea<C extends Area> extends Area<CountryArea, C> {
    
}
