package com.monsanto.eas.cia.model.area;

import com.monsanto.eas.cia.model.Area;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Created by IntelliJ IDEA.
 * User: ovegago
 * Date: 24/01/2011
 * Time: 08:09:29 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@DiscriminatorValue("WORLD")
public class WorldArea extends Area<NoArea, CountryArea> {
    @Override
    public boolean equals(Object o) {
        return o instanceof WorldArea && super.equals(o);
    }
}
