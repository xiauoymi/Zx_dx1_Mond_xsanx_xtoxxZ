package com.monsanto.eas.cia.model.entity;

import org.hibernate.annotations.Type;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 28/01/2011
 * Time: 02:17:03 PM
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public abstract class ActiveEntity extends BaseEntity{

    @Basic(optional=false)
    @Type(type = "yes_no")
    @Column(name = "ACTIVE", nullable = false)
    protected boolean active=true;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
