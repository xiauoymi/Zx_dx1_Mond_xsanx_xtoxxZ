package com.monsanto.eas.cia.model.entity;

import org.apache.commons.lang.builder.EqualsBuilder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 25, 2010 Time: 12:28:30 PM To change this template use File |
 * Settings | File Templates.
 */
@MappedSuperclass
public abstract class BaseEntity implements Serializable {
  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "ciaSeq", sequenceName = "cia.CIA_SEQ")
  @GeneratedValue(generator = "ciaSeq", strategy = GenerationType.SEQUENCE)
  @Column(name = "ID")
  protected Integer id;

  @Version
  @Column(name = "CURRENT_VERSION")
  protected Integer currentVersion=0;

  @Column(name = "SYNC_VERSION", nullable = false)
  protected Integer syncVersion=-1;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "MOD_DATE", nullable = true)
  protected Date modDate = new Date();

  @Basic(optional = true)
  @Column(name = "MOD_USER", length = 255, nullable = true)
  protected String modUser;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Integer getCurrentVersion() {
    return currentVersion;
  }

  public void setCurrentVersion(Integer currentVersion){
    this.currentVersion = currentVersion;
  }

  public Integer getSyncVersion() {
    return syncVersion;
  }

  public void setSyncVersion(Integer syncVersion){
    this.syncVersion = syncVersion;
  }


  public boolean needsSynchronization(){
    return ! new EqualsBuilder().append(this.currentVersion,this.syncVersion).isEquals();
  }

  public void syncVersion(){
    if(needsSynchronization())this.syncVersion=this.currentVersion+1;
  }

}
