package com.monsanto.eas.cia.model.entity;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 28/01/2011
 * Time: 12:05:21 PM
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public abstract class CodeCatalogEntity extends ActiveEntity {

    @Basic(optional=false)
    @Column(name = "CODE", length=63, nullable = false, unique=true)
    protected String code;

    @Basic(optional=true)
    @Column(name = "DESCRIPTION", length=255, nullable = false)
    protected String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof CodeCatalogEntity){
            return new EqualsBuilder().append(this.getCode(),((CodeCatalogEntity)o).getCode()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).append(this.getCode()).toHashCode();
    }
}
