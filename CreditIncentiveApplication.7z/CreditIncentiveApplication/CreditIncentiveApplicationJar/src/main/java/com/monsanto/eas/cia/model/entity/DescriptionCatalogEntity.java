package com.monsanto.eas.cia.model.entity;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 28/01/2011
 * Time: 01:31:01 PM
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public abstract class DescriptionCatalogEntity extends ActiveEntity {

    @Basic(optional=true)
    @Column(name = "DESCRIPTION", length=255, nullable = false, unique=true)
    protected String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof DescriptionCatalogEntity){
            return new EqualsBuilder().append(this.getDescription(),((DescriptionCatalogEntity)o).getDescription()).isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(7,7).append(this.getDescription()).toHashCode();
    }
}
