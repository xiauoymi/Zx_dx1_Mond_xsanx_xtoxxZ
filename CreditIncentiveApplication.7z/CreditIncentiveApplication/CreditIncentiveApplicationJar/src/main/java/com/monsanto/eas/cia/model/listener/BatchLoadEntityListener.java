package com.monsanto.eas.cia.model.listener;

import com.monsanto.eas.cia.model.entity.BaseEntity;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 03:45:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchLoadEntityListener extends ExecutionContextEntityListener {

    public static final String EXECUTION_KEY="batch-load-entities";
    public static final String BATCH_LOAD_USER_KEY="batch-load-user";


    @PrePersist
    @PreUpdate
    public void modifyEntity(Object entity){
        if(isCallbackEnabled(EXECUTION_KEY)){
            if(entity instanceof BaseEntity){
                BaseEntity baseEntity=(BaseEntity)entity;
                baseEntity.setModDate(new Date());
                baseEntity.setModUser(
                    getVariable(EXECUTION_KEY,BATCH_LOAD_USER_KEY,"BW")
                );
            }
        }
    }
}
