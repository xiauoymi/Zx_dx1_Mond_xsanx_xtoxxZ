package com.monsanto.eas.cia.model.listener;

import com.monsanto.eas.cia.util.ExecutionContext;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 03:46:44 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ExecutionContextEntityListener {


    public static String getExecutionContextKey(String executionKey){
        return executionKey+".context";
    }

    public static void enableCallback(String executionKey){
        enableCallback(executionKey,null);
    }

    public static void enableCallback(String executionKey,Map<String,Object> context){
        ExecutionContext executionContext=ExecutionContext.getCurrentExecutionContext();
        executionContext.setVariable(executionKey,Boolean.TRUE);
        executionContext.setVariable(getExecutionContextKey(executionKey),context);
    }

    public static void disableCallback(String executionKey){
        ExecutionContext executionContext=ExecutionContext.getCurrentExecutionContext();
        executionContext.setVariable(executionKey,Boolean.FALSE);
        executionContext.setVariable(getExecutionContextKey(executionKey),null);
    }

    public static boolean isCallbackEnabled(String executionKey){
        ExecutionContext executionContext=ExecutionContext.getCurrentExecutionContext();
        return executionContext.getVariable(executionKey,Boolean.FALSE);
    }

    public static Map<String,Object> getExecutionContext(String executionKey){
        ExecutionContext executionContext=ExecutionContext.getCurrentExecutionContext();
        return executionContext.getVariable(getExecutionContextKey(executionKey),new HashMap<String,Object>());
    }

    public static <T> T getVariable(String key, T defaultValue){
        return getVariable(null,key,defaultValue);
    }

    public static <T> T getVariable(String executionKey,String key, T defaultValue){
        if(executionKey==null){
            ExecutionContext executionContext=ExecutionContext.getCurrentExecutionContext();
            return executionContext.getVariable(key,defaultValue);
        }
        else{
            Map<String,Object> executionContext=getExecutionContext(executionKey);
            if(executionContext!=null&&executionContext.containsKey(key)){
                return (T)executionContext.get(key);
            }
            return defaultValue;
        }
    }
}
