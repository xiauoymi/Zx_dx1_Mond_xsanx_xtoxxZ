package com.monsanto.eas.cia.model.listener;

import com.monsanto.eas.cia.model.entity.BaseEntity;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/03/2011
 * Time: 01:01:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class SyncEntityListener extends ExecutionContextEntityListener {

    public static final String EXECUTION_KEY="sync-entities";

    @PrePersist
    @PreUpdate
    public void modifyEntity(Object entity){
        if(isCallbackEnabled(EXECUTION_KEY)){
            if(entity instanceof BaseEntity){
                BaseEntity baseEntity=(BaseEntity)entity;
                baseEntity.syncVersion();
            }                
        }
    }

}
