package com.monsanto.eas.cia.model.vo;

import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 9/11/12
 * Time: 11:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocalDealerVO {

    private Integer id;

    private String fiscalName;

    private String agreementNumber;

    private String name;

    private String posName;

    private String address1;

    private String address2;

    private String phone;

    private String fax;

    private String email;

    private Date birthday;

    private Date businessAnniversary;

    private String rfc;


    //private District district;


    //private PostalCode postalCodeArea;


    //private SubRegion subRegion;


    //private CommercialSupervisor commercialSupervisor;


    //private CommercialSupervisor commercialManager;


    //private Country country;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFiscalName() {
        return fiscalName;
    }

    public void setFiscalName(String fiscalName) {
        this.fiscalName = fiscalName;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Date getBusinessAnniversary() {
        return businessAnniversary;
    }

    public void setBusinessAnniversary(Date businessAnniversary) {
        this.businessAnniversary = businessAnniversary;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }
}
