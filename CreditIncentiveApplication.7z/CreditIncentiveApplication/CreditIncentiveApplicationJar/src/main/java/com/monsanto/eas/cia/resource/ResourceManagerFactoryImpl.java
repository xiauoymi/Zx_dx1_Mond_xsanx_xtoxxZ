/*
Copyright:  Copyright  2006 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.resource;

import com.monsanto.eas.cia.config.xstream.ConfigReaderXStreamImpl;
import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.eas.cia.resource.ftpserver.FTPServerConnectionManager;

/**
* Filename:    $RCSfile: ResourceManagerFactoryImpl.java,v $
* Label:       $Name: not supported by cvs2svn $
* Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-08 20:14:20 $
*
* @author rdesai2
* @version $Revision: 1.4 $
*/
public class ResourceManagerFactoryImpl implements ResourceManagerFactory {

  public ResourceConnectionManager getConnectionManager(String type) {
    if (CIAConstants.DATASOURCE_TYPE_FTP_SERVER.equalsIgnoreCase(type)) {
      return new FTPServerConnectionManager(new ConfigReaderXStreamImpl(CIAConstants.XML_CONNECTION_EXTERNAL_CONFIG));
    }
    throw new IllegalArgumentException("Invalid connection-manager type requested: '" + type + "'");
  }

}
