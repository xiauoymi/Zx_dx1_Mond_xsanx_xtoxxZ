/*
Copyright:  Copyright  2006 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.resource.ftpserver;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.FTPConnection;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.cia.config.ConfigReader;
import com.monsanto.eas.cia.config.exception.ConfigurationException;
import com.monsanto.eas.cia.config.model.ConnectionParams;
import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.eas.cia.resource.ResourceConnectionException;
import com.monsanto.eas.cia.resource.ResourceConnectionManager;


import java.io.IOException;

/**
* Filename:    $RCSfile: FTPServerConnectionManager.java,v $
* Label:       $Name: not supported by cvs2svn $
* Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 22:03:37 $
*
* @author rdesai2
* @version $Revision: 1.9 $
*/
public class FTPServerConnectionManager implements ResourceConnectionManager {

  private ConfigReader configReader;
  private ConnectionParams connectionParams;

  public FTPServerConnectionManager(ConfigReader configReader) {
    this.configReader = configReader;
  }

  /**
   * Gets connection to FTPServer for the current environment
   * @param remoteSubDir - Sub Directory within the default "/" dir. Eg: inbound, inbound/newdir, outbound etc...
   *                       If Null: Connection to default dir "/" will be returned.
   * @return Object - FTPConnection
   */
  public Object getConnection(String remoteSubDir)  throws ResourceConnectionException {
    FTPConnection connection = new FTPConnection();
    getConnectionParams();
    connect(connection, Integer.parseInt(connectionParams.getPortNumber()));
    login(connection);
    if (!StringUtils.isNullOrEmpty(remoteSubDir)) {
      changeRemoteDir(connection, remoteSubDir);
    }
    return connection;
  }

  private void connect(FTPConnection connection, int portNumber) throws ResourceConnectionException {
    String host = connectionParams.getServerName();
    boolean connected;
    try {
      connected = connection.connect(host, portNumber);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ResourceConnectionException("FTP Connection exception while connecting to host: '" + host + "'.", e);
    }
    if(!connected){
      throw new ResourceConnectionException("FTP Connection failed while connecting to host: '" + host + "'.");
    }
  }

  private void login(FTPConnection connection) throws ResourceConnectionException {
    String host = connectionParams.getServerName();
    String username = connectionParams.getUserName();
    String password = connectionParams.getPassword();
    boolean logged;
    try {
      logged = connection.login(username, password);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ResourceConnectionException("FTP exception while logging to host: '" + host + "', using username = '" + username + "'.", e);
    }
    if(!logged){
      throw new ResourceConnectionException("FTP loggin failed to host: '" + host + "', using username = '" + username + "'.");
    }
  }

  private void changeRemoteDir(FTPConnection connection, String remoteSubDir) throws ResourceConnectionException {
    boolean changeDirSuccessful;
    try {
      changeDirSuccessful = connection.changeDirectory(remoteSubDir);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ResourceConnectionException("FTP exception while changing remote directory to: '" + remoteSubDir + "'.", e);
    }
    if(!changeDirSuccessful){
      throw new ResourceConnectionException("FTP cd (change remote directory) command to: '" + remoteSubDir + "' failed.");
    }
  }

  private void getConnectionParams() throws ResourceConnectionException {
    try {
      connectionParams = configReader.getConnectionParams(CIAConstants.DATASOURCE_TYPE_FTP_SERVER, null);
    } catch (ConfigurationException e) {
      Logger.log(new LoggableError(e));
      throw new ResourceConnectionException("Unable to get configuation parameters for FTP Server.", e);
    }
  }
}
