package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.area.*;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 10:45:50 AM To change this template use File |
 * Settings | File Templates.
 */
public interface AreaService {
  Collection<Area> lookupAllAreas();

  Collection<Region> lookupAllRegion();

  Collection<SubRegion> lookupAllSubRegions();

  Collection<SubRegion> lookupSubRegionsForRegion(Region region);

  Collection<State> lookupAllStates();

  Collection<State> lookupStatesForSubRegion(SubRegion subRegion);

  Collection<District> lookupAllDistricts();

  Collection<District> lookupDistrictsForState(State state);

  Collection<PostalCode> lookupAllPostalCodes();

  Collection<PostalCode> lookupPostalCodesForDistrict(District district);

}
