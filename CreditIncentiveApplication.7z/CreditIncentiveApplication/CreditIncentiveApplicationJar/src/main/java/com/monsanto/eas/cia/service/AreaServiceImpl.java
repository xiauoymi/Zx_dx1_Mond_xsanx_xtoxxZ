package com.monsanto.eas.cia.service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.monsanto.eas.cia.dao.*;
import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.area.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 10:46:35 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "areaService")
public class AreaServiceImpl implements AreaService {
    @Autowired
    private AreaDao areaDao;

    @Autowired
    private RegionDao regionDao;

    @Autowired
    private SubRegionDao subRegionDao;

    @Autowired
    private StateDao stateDao;

    @Autowired
    private DistrictDao districtDao;

    @Autowired
    private PostalCodeDao postalCodeDao;

    @RemotingInclude
    @Cacheable(cacheName = "allAreasCache")
    public Collection<Area> lookupAllAreas() {
        Collection<Area> areas = areaDao.lookupAllAreas();
        Iterator<Area> iterator = areas.iterator();
        while(iterator.hasNext()) {
            Area area = iterator.next();
            area.setChildAreas(null);
        }
        return areas;        
    }

    @RemotingInclude
    @Cacheable(cacheName = "allRegionsCache")
    public Collection<Region> lookupAllRegion() {
        Collection<Region> regions = regionDao.lookupAllRegions();
        Iterator<Region> iterator = regions.iterator();
        while (iterator.hasNext()) {
            Region region = iterator.next();
            region.setChildAreas(null);
        }
        return regions;
    }

    @RemotingInclude
    @Cacheable(cacheName = "allSubRegionsCache")
    public Collection<SubRegion> lookupAllSubRegions() {
        Collection<SubRegion> subregions = subRegionDao.lookupAllSubRegions();
        Iterator<SubRegion> iterator = subregions.iterator();
        while (iterator.hasNext()) {
            SubRegion subregion = iterator.next();
            subregion.setChildAreas(null);
        }
        return subregions;
    }

    @RemotingInclude
    @Cacheable(cacheName = "SubRegionsForRegionCache")
    public Collection<SubRegion> lookupSubRegionsForRegion(Region region) {
        Collection<SubRegion> subregions = subRegionDao.lookupSubRegionsForRegion(region);
        Iterator<SubRegion> iterator = subregions.iterator();
        while (iterator.hasNext()) {
            SubRegion subregion = iterator.next();
            subregion.setChildAreas(null);
        }
        return subregions;
    }

    @RemotingInclude
    @Cacheable(cacheName = "allStatesCache")
    public Collection<State> lookupAllStates() {
        Collection<State> states = stateDao.lookupAllStates();
        Iterator<State> iterator = states.iterator();
        while(iterator.hasNext()) {
            State state = iterator.next();
            state.setChildAreas(null);
        }
        return states;
    }

    @RemotingInclude
    @Cacheable(cacheName = "StatesForSubRegionCache")
    public Collection<State> lookupStatesForSubRegion(SubRegion subRegion) {
        Collection<State> states = stateDao.lookupStatesForSubRegion(subRegion);
        Iterator<State> iterator = states.iterator();
        while (iterator.hasNext()) {
            State state = iterator.next();
            state.setChildAreas(null);
        }
        return states;
    }

    @RemotingInclude
    @Cacheable(cacheName = "allDistrictsCache")
    public Collection<District> lookupAllDistricts() {
        Collection<District> districts = districtDao.lookupAllDistricts();
        Iterator<District> iterator = districts.iterator();
        while(iterator.hasNext()) {
            District district = iterator.next();
            district.setChildAreas(null);
        }
        return districts;
    }

    @RemotingInclude
    @Cacheable(cacheName = "StatesForSubRegionCache")
    public Collection<District> lookupDistrictsForState(State state) {
        Collection<District> districts = districtDao.lookupDistrictsForState(state);
        Iterator<District> iterator = districts.iterator();
        while (iterator.hasNext()) {
            District district = iterator.next();
            district.setChildAreas(null);
        }
        return districts;
    }

    @RemotingInclude
    @Cacheable(cacheName = "allPostalCodesCache")
    public Collection<PostalCode> lookupAllPostalCodes() {
        Collection<PostalCode> postalCodes = postalCodeDao.lookupAllPostalCodes();
        Iterator<PostalCode> iterator = postalCodes.iterator();
        while(iterator.hasNext()) {
            PostalCode postalCode = iterator.next();
            postalCode.setChildAreas(null);
        }
        return postalCodes;
    }

    @RemotingInclude
    @Cacheable(cacheName = "PostalCodesForDistrictCache")
    public Collection<PostalCode> lookupPostalCodesForDistrict(District district) {
        Collection<PostalCode> postalCodes = postalCodeDao.lookupPostalCodesForDistrict(district);
        Iterator<PostalCode> iterator = postalCodes.iterator();
        while(iterator.hasNext()) {
            PostalCode postalCode = iterator.next();
            postalCode.setChildAreas(null);
        }
        return postalCodes;
    }

    @RemotingInclude
    //@Cacheable(cacheName = "SubRegionsForRegionCache")
    public Region lookupRegionForSubRegion(SubRegion subRegion) {
        Region region = regionDao.lookupRegionForSubRegion(subRegion);
        region.setChildAreas(null);
        return region;
    }

    @RemotingInclude
    //@Cacheable(cacheName = "SubRegionsForRegionCache")
    public State lookupStateForDistrict(District district) {
        State state = stateDao.lookupStateForDistrict(district);
        state.setChildAreas(null);
        return state;
    }

}
