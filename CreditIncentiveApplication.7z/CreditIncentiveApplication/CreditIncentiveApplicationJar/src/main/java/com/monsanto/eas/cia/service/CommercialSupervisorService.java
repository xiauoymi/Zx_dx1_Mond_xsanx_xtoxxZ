package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.CommercialSupervisor;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 4:49:07 PM To change this template use File |
 * Settings | File Templates.
 */
public interface CommercialSupervisorService {
  Collection<CommercialSupervisor> lookupAll();
}
