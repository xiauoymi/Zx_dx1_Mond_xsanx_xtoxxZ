package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.CommercialSupervisorDao;
import com.monsanto.eas.cia.model.CommercialSupervisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 4:47:46 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "commercialSupervisorService")
public class CommercialSupervisorServiceImpl implements CommercialSupervisorService {
  @Autowired
  private CommercialSupervisorDao commercialSupervisorDao;

  @RemotingInclude
  public Collection<CommercialSupervisor> lookupAll() {
    return commercialSupervisorDao.lookupAll();
  }
}
