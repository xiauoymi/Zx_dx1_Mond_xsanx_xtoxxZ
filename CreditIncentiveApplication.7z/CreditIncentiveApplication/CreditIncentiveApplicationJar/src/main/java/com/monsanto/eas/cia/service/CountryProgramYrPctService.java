package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.CountryProgramYrPct;
import com.monsanto.eas.cia.model.Year;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Nov 29, 2010
 * Time: 2:23:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CountryProgramYrPctService {
  Collection<CountryProgramYrPct> lookupAllProgramYrPcts(Year year);

  @RemotingInclude
  void saveOrUpdate(CountryProgramYrPct countryProgramYrPct);

  CountryProgramYrPct lookupCountryProgramYrPctByCountryAndYear(Country country, Year year);

  void closeProgramYear();
}
