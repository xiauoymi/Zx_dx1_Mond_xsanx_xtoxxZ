package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.CountryProgramYrPctDao;
import com.monsanto.eas.cia.dao.ProgramQuarterDao;
import com.monsanto.eas.cia.model.Country;
import com.monsanto.eas.cia.model.CountryProgramYrPct;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.model.Year;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA. User: vrbethi Date: Nov 29, 2010 Time: 2:24:24 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "countryProgramYrPctService")
public class CountryProgramYrPctServiceImpl implements CountryProgramYrPctService {
  @Autowired
  CountryProgramYrPctDao countryProgramYrPctDao;

  @Autowired
  ProgramQuarterDao programQuarterDao;

  @Autowired
  FinderService finderService;

  @RemotingInclude  
  public Collection<CountryProgramYrPct> lookupAllProgramYrPcts(Year year) {
//    CountryProgramYrPct countryProgramYrPct=null;
//    Collection<CountryProgramYrPct> pctCollection = countryProgramYrPctDao.lookupAllCountryProgramYrPcts();
//    Iterator<CountryProgramYrPct> iterator = pctCollection.iterator();
//    while(iterator.hasNext()){
//      CountryProgramYrPct countryProgramYrPct1 = iterator.next();
//      if(countryProgramYrPct1.getYear()!=null && countryProgramYrPct1.getYear().getId().equals(year.getId())){
//         countryProgramYrPct = countryProgramYrPct1;
//      }
//    }
//    pctCollection.clear();
//    pctCollection.add(countryProgramYrPct);
//    System.out.println("pctCollection.size() = " + pctCollection.size());
//    return pctCollection;
    return countryProgramYrPctDao.lookupCountryProgramYrPctsByYear(year);
  }

  @RemotingInclude
  public void saveOrUpdate(CountryProgramYrPct countryProgramYrPct) {
//    if (countryProgramYrPct.getId() == null) {
//      countryProgramYrPctDao.save(countryProgramYrPct);
//    } else {
//    Collection<ProgramQuarter> programQuarters = countryProgramYrPct.getProgramQuarters();
//    Iterator<ProgramQuarter> quarterIterator = programQuarters.iterator();
//    while(quarterIterator.hasNext()){
//      ProgramQuarter programQuarter = quarterIterator.next();
//      programQuarterDao.save(programQuarter);
//    }
        countryProgramYrPct.setOpen(true);
        countryProgramYrPct.setCountry(finderService.findCountryFrom("MX"));
        countryProgramYrPctDao.merge(countryProgramYrPct);
//    }
  }

  @RemotingInclude
  public CountryProgramYrPct lookupCountryProgramYrPctByCountryAndYear(Country country, Year year) {
    return countryProgramYrPctDao.lookupCountryProgramYrPctByCountryAndYear(finderService.findCountryFrom(country.getCode()), year);
  }

  @RemotingInclude
  public void closeProgramYear(){
    Collection<CountryProgramYrPct> pctCollection = countryProgramYrPctDao.lookupActiveCountryProgramYrs();
    Iterator<CountryProgramYrPct> countryProgramYrPctIterator = pctCollection.iterator();
    while (countryProgramYrPctIterator.hasNext()){
      CountryProgramYrPct countryProgramYrPct = countryProgramYrPctIterator.next();
      countryProgramYrPct.setOpen(false);
      countryProgramYrPctDao.save(countryProgramYrPct);
    }
  }
}
