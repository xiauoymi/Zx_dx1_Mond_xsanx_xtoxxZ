package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.*;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:49 PM To change this template use File |
 * Settings | File Templates.
 */
public interface DistributorService {
  Collection<DistributorCnView> saveCreditNotes(Collection<DistributorCnView> creditNotesList, Year year, String startMonth);
}
