package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.*;
import com.monsanto.eas.cia.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:57 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "distributorService")
public class DistributorServiceImpl implements DistributorService {

    @Autowired
    private DistributorCnDao distributorCnDao;

    @Autowired
    private TaxReserveDao taxReserveDao;

    @Autowired
    private CreditNoteDao creditNoteDao;

    @Autowired
    private LdSalesCnDao ldSalesCnDao;

    @Autowired
    private SalesPerQuarterDao salesPerQuarterDao;

    @Autowired
    private LdSalesDao ldSalesDao;

    @Autowired
    private ProgramQuarterDao programQuarterDao;

    @RemotingInclude
    @Transactional(timeout = 600)
    public Collection<DistributorCnView> saveCreditNotes(Collection<DistributorCnView> creditNotesList, Year yearIn, String startMonth) {

        Iterator<DistributorCnView> iterator = creditNotesList.iterator();

        return null;
    }

    private Double getAmountPaidSoFar(String salesId) {
        Double cumulativeAmt = 0.0;
        Collection<LdSalesCn> salesCns = ldSalesCnDao.lookupAllCreditNotesPerSale(salesId);
        Iterator<LdSalesCn> salesCnIterator = salesCns.iterator();
        while (salesCnIterator.hasNext()) {
            LdSalesCn cn = salesCnIterator.next();
            Double amount = cn.getIncentiveAmount();
            cumulativeAmt += amount;
        }
        return cumulativeAmt;  //To change body of created methods use File | Settings | File Templates.
    }

}
