package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.Region;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: OVEGAGO Date: 3/02/2011 Time: 03:47:47 PM To change this template use File | Settings
 * | File Templates.
 */
@Transactional(readOnly = true, timeout = 300)
public interface FinderService {

  @Transactional(readOnly = false)
  LdDist findOrCreateLdDistFrom(LocalDealer localDealer, SapDistributor distributor, LdProgramYear programYear);

  @Transactional(readOnly = false)
  LdIncentive findOrCreateLdIncentive(LocalDealer localDealer, int year, int quarterNumber);

  @Transactional(readOnly = false)
  LdProgramYear findOrCreateLdProgramYear(LocalDealer localDealer, int year);

  SapProduct findSapProductFrom(String code);

  SapDistributor findSapDistributorFrom(String code);

  CommercialSupervisor findCommercialSupervisorFrom(String description);

  ProductFamily findProductFamilyFrom(String code);

  Uom findUomFrom(String code);

  ProductLine findProductLineFrom(SapProduct sapProduct);

  LdSales findLdSalesFrom(String transactionNumber);

  CreditNote findCreditNoteFrom(String code);

  LocalDealer findLocalDealerFrom(String agreementNumber);

  TransactionType findTransactionTypeFrom(String description);

  Year findYearFrom(Integer year);

  TaxReserve findTaxReserveFrom(String code);

  Area findAreaFrom(Class<? extends Area> _class,String code);
  
  Country findCountryFrom(String code);

  Region findRegionFrom(String code);
  
  SubRegion findSubRegionFrom(String code);  
  
  District findDistrictFrom(String code);

  PostalCode findPostalCodeFrom(String code);

  CountryProgramYrPct findPreviousCountryProgramYearFrom(String countryCode);

  List<CountryProgramYrPct> findCountryProgramYearsFrom(String countryCode);

  List<CountryProgramYrPct> findPreviousCountryProgramYearsFrom(CountryProgramYrPct lastCountryProgramYear,
                                                                int programYears, String countryCode);

  LdProgramYear findLdProgramYearFrom(CountryProgramYrPct countryProgramYear, LocalDealer localDealer);

  ProgramQuarter findProgramQuarterFrom(LocalDealer localDealer, int year, int quarterNumber);

  LdIncentive findLdIncentiveFrom(LocalDealer localDealer, int year, int quarterNumber);

  List<LdDist> findLdDistFrom(LocalDealer localDealer, LdProgramYear ldProgramYear);

  LdDist findLdDistFrom(LocalDealer localDealer, SapDistributor distributor ,LdProgramYear ldProgramYear);

  CountryProgramYrPct findCurrentCountryProgramYearFrom(String countryCode, int year);

  CountryProgramYrPct findCountryProgramYearContainingDate(String countryCode, Date date);

  List<LdSales> findLdSalesByYearAndLocalDealer(int year,LocalDealer localDealer);

    LdProgramYearStatus findLdProgramYearStatusFrom(String code);

  LdSalesCn findLdSalesCn(int ldSalesId, int creditNoteId);
}
