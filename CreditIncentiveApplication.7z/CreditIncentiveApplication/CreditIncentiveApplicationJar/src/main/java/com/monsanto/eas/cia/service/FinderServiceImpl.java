package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.Region;
import com.monsanto.eas.cia.model.area.SubRegion;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.eclipse.jdt.internal.compiler.flow.FinallyFlowContext;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.monsanto.eas.cia.integration.util.ObjectUtils.absOrValue;
import static org.hibernate.criterion.Restrictions.*;

/**
 * Created by IntelliJ IDEA. User: OVEGAGO Date: 3/02/2011 Time: 03:39:39 PM To change this template use File | Settings
 * | File Templates.
 */
//TODO Ask ram about disabled catalogs    
@Service
public class FinderServiceImpl implements FinderService {

    @Autowired
    protected CriteriaDao dao;

    protected int maxNumberOfDistributorsInProgram = 4;

    public CriteriaDao getDao() {
        return dao;
    }

    public void setDao(CriteriaDao dao) {
        this.dao = dao;
    }

    public void setMaxNumberOfDistributorsInProgram(int maxNumberOfDistributorsInProgram) {
        maxNumberOfDistributorsInProgram = Math.abs(maxNumberOfDistributorsInProgram);
        if (maxNumberOfDistributorsInProgram == 0) maxNumberOfDistributorsInProgram = 1;
        this.maxNumberOfDistributorsInProgram = maxNumberOfDistributorsInProgram;
    }

    public int getMaxNumberOfDistributorsInProgram() {
        return maxNumberOfDistributorsInProgram;
    }

    public LdProgramYear findOrCreateLdProgramYear(final LocalDealer localDealer, final int year) {
        LdProgramYear ldProgramYear = dao.findByCriteria(new DefaultCriteriaCreator<LdProgramYear>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("year").add(eq("year", year));
                criteria.createCriteria("localDealer").add(eq("agreementNumber", localDealer.getAgreementNumber()));
            }
        });
        if (ldProgramYear == null) {
            ldProgramYear = new LdProgramYear();
            ldProgramYear.setYear(
                    dao.findByCriteria(new DefaultCriteriaCreator<Year>() {
                        public void modifyCriteria(Criteria criteria) {
                            criteria.add(eq("year", year));
                        }
                    })
            );
            localDealer.addProgramYear(ldProgramYear);
        }
        return ldProgramYear;
    }

    public ProgramQuarter findProgramQuarterFrom(final LocalDealer localDealer, final int year, final int quarterNumber) {
        if (localDealer.getCountry() == null)
            throw new IllegalArgumentException("Missing country from local dealer");

        ProgramQuarter programQuarter = dao.findByCriteria(new DefaultCriteriaCreator<ProgramQuarter>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("quarterType").add(eq("quarterNum", quarterNumber));
                Criteria countryProgramYrPctCriteria = criteria.createCriteria("countryProgram");
                countryProgramYrPctCriteria.createCriteria("country").add(eq("code", localDealer.getCountry().getCode()));
                countryProgramYrPctCriteria.createCriteria("year").add(eq("year", year));
            }
        });
        return programQuarter;
    }

    public LdIncentive findLdIncentiveFrom(final LocalDealer localDealer, final int year, final int quarterNumber) {
        final ProgramQuarter programQuarter = findProgramQuarterFrom(localDealer, year, quarterNumber);

        if (programQuarter == null)
            throw new IllegalArgumentException("Missing program quarter num " + quarterNumber);

        LdIncentive incentive = dao.findByCriteria(new DefaultCriteriaCreator<LdIncentive>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("localDealer").add(eq("agreementNumber", localDealer.getAgreementNumber()));
                criteria.createCriteria("programQuarter").add(idEq(programQuarter.getId()));
            }
        });
        return incentive;
    }

    public LdIncentive findOrCreateLdIncentive(final LocalDealer localDealer, final int year, final int quarterNumber) {
        LdIncentive incentive = findLdIncentiveFrom(localDealer, year, quarterNumber);
        ProgramQuarter programQuarter = findProgramQuarterFrom(localDealer, year, quarterNumber);
        if (incentive == null) {
            incentive = new LdIncentive();
            incentive.setCurrentVersion(0);
            localDealer.addIncentive(incentive);
        }
        incentive.setProgramQuarter(programQuarter);
        return incentive;
    }

    public List<LdDist> findLdDistFrom(final LocalDealer localDealer, final LdProgramYear ldProgramYear) {
        return dao.findListByCriteria(new DefaultCriteriaCreator<LdDist>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.add(eq("localDealer", localDealer));
                criteria.add(eq("ldProgramYear", ldProgramYear));
            }
        });
    }

    public LdDist findLdDistFrom(final LocalDealer localDealer, final SapDistributor distributor, final LdProgramYear ldProgramYear) {
        return dao.findByCriteria(new DefaultCriteriaCreator<LdDist>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.add(eq("localDealer", localDealer));
                criteria.add(eq("distributor", distributor));
                criteria.add(eq("ldProgramYear", ldProgramYear));
            }
        });
    }

    public LdDist findOrCreateLdDistFrom(final LocalDealer localDealer, final SapDistributor distributor,
                                         final LdProgramYear programYear) {
        LdDist ldDist = dao.findByCriteria(new DefaultCriteriaCreator<LdDist>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("localDealer").add(eq("agreementNumber", localDealer.getAgreementNumber()));
                criteria.add(eq("ldProgramYear", programYear));
                criteria.createCriteria("distributor")
                        .add(eq("code", distributor.getCode()));
            }
        });

        if (ldDist == null) {
            ldDist = new LdDist();
            localDealer.addLdDist(ldDist);
            ldDist.setLdProgramYear(programYear);
            List<LdDist> listOfLdDist = dao.findListByCriteria(
                    new DefaultCriteriaCreator<LdDist>() {
                        public void modifyCriteria(Criteria criteria) {
                            criteria.createCriteria("localDealer").add(eq("agreementNumber", localDealer.getAgreementNumber()));
                            criteria.add(eq("ldProgramYear", programYear));
                        }
                    }
            );
            ldDist.setDistributor(distributor);
            ldDist.setActive(listOfLdDist.size() <= maxNumberOfDistributorsInProgram);
        }
        return ldDist;
    }

    public ProductLine findProductLineFrom(final SapProduct sapProduct) {
        return dao.findByCriteria(new DefaultCriteriaCreator<ProductLine>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.add(eq("sapProduct", sapProduct));
            }
        });
    }

    public LdProgramYearStatus findLdProgramYearStatusFrom(String code) {
        return dao.findByCode(LdProgramYearStatus.class, code);
    }

    public LdProgramYear findLdProgramYearFrom(final CountryProgramYrPct countryProgramYear,
                                               final LocalDealer localDealer) {
        if (!localDealer.getCountry().equals(countryProgramYear.getCountry())) {
            return null;
        }
        return dao.findByCriteria(new DefaultCriteriaCreator<LdProgramYear>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.add(eq("localDealer", localDealer));
                criteria.add(eq("year", countryProgramYear.getYear()));
            }
        });
    }

    public CountryProgramYrPct findCurrentCountryProgramYearFrom(final String countryCode, final int year) {
        return dao.findByCriteria(new DefaultCriteriaCreator<CountryProgramYrPct>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createAlias("year", "currentYear");
                criteria.addOrder(Order.desc("currentYear.year"));
                criteria.add(eq("open", true));
                criteria.add(eq("currentYear.year", year));
                Criteria countryCriteria = criteria.createCriteria("country");
                countryCriteria.add(eq("code", countryCode));
                criteria.setMaxResults(1);
            }
        });
    }

    public CountryProgramYrPct findPreviousCountryProgramYearFrom(final String countryCode) {
        List<CountryProgramYrPct> countryProgramYears = findCountryProgramYearsFrom(countryCode);
        CountryProgramYrPct lastOpenCountryProgramYear = null;
        for (CountryProgramYrPct programYear : countryProgramYears) {
            if (programYear.isOpen()) {
                lastOpenCountryProgramYear = programYear;
            }
            else {
                return programYear;
            }
        }
        return lastOpenCountryProgramYear;
    }

    public List<CountryProgramYrPct> findPreviousCountryProgramYearsFrom(final CountryProgramYrPct lastCountryProgramYear,
                                                                         int programYears, final String countryCode) {
        List<CountryProgramYrPct> countryProgramYears = dao
                .findListByCriteria(new DefaultCriteriaCreator<CountryProgramYrPct>() {
                    public void modifyCriteria(Criteria criteria) {
                        criteria.createAlias("year", "currentYear");
                        criteria.add(Restrictions.le("currentYear.year", lastCountryProgramYear.getYear().getYear()));
                        criteria.addOrder(Order.desc("currentYear.year"));
                        Criteria countryCriteria = criteria.createCriteria("country");
                        countryCriteria.add(eq("code", countryCode));
                    }
                });

        programYears = absOrValue(programYears, 1);
        List<CountryProgramYrPct> selectedProgramYears = new ArrayList<CountryProgramYrPct>();

        int i = 0;
        for (CountryProgramYrPct programYear : countryProgramYears) {
            if (i++ < programYears) {
                selectedProgramYears.add(programYear);
            }
            else
                break;
        }
        return selectedProgramYears;
    }

    public List<CountryProgramYrPct> findCountryProgramYearsFrom(final String countryCode) {
        return dao.findListByCriteria(new DefaultCriteriaCreator<CountryProgramYrPct>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createAlias("year", "currentYear");
                criteria.addOrder(Order.desc("currentYear.year"));
                Criteria countryCriteria = criteria.createCriteria("country");
                countryCriteria.add(eq("code", countryCode));
            }
        });
    }

    public CountryProgramYrPct findCountryProgramYearContainingDate(final String countryCode, final Date date) {
        return dao.findByCriteria(new DefaultCriteriaCreator<CountryProgramYrPct>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("country").add(eq("code", countryCode));
                criteria.createCriteria("programQuarters").add(
                        disjunction().add(
                                conjunction().
                                        add(le("quarterStart", date)).
                                        add(ge("quarterEnd", date))
                        ).add(
                                conjunction().
                                        add(le("quarterStart", date)).
                                        add(isNull("quarterEnd"))
                        )
                );
            }
        });
    }

    public LocalDealer findLocalDealerFrom(String agreementNumber) {
        return dao.findByProperty(LocalDealer.class, "agreementNumber", agreementNumber);
    }

    public CreditNote findCreditNoteFrom(String code) {
        return dao.findByCode(CreditNote.class, code);
    }

    public LdSales findLdSalesFrom(String transactionNumber) {
        return dao.findByProperty(LdSales.class, "transactionNumber", transactionNumber);
    }

    public TransactionType findTransactionTypeFrom(String description) {
        return dao.findByCode(TransactionType.class, description);
    }

    public Year findYearFrom(Integer year) {
        return dao.findByProperty(Year.class, "year", year);
    }

    public TaxReserve findTaxReserveFrom(String code) {
        return dao.findByCode(TaxReserve.class, code);
    }

    public Area findAreaFrom(Class<? extends Area> _class, String code) {
        return dao.findByCode(_class, code);
    }

    public Region findRegionFrom(String code) {
        return dao.findByCode(Region.class, code);
    }

    public SubRegion findSubRegionFrom(String code) {
        return dao.findByCode(SubRegion.class, code);
    }

    public District findDistrictFrom(String code) {
        return dao.findByCode(District.class, code);
    }

    public PostalCode findPostalCodeFrom(String code) {
        return dao.findByCode(PostalCode.class, code);
    }


    public SapProduct findSapProductFrom(String code) {
        return dao.findByCode(SapProduct.class, code);
    }

    public SapDistributor findSapDistributorFrom(String code) {
        return dao.findByCode(SapDistributor.class, code);
    }

    public CommercialSupervisor findCommercialSupervisorFrom(String description) {
        return dao.findByDescription(CommercialSupervisor.class, description);
    }

    public ProductFamily findProductFamilyFrom(String code) {
        return dao.findByDescription(ProductFamily.class, code);
    }

    public Uom findUomFrom(String code) {
        return dao.findByCode(Uom.class, code);
    }

    public Country findCountryFrom(String code) {
        return dao.findByCode(Country.class, code);
    }

    public List<LdSales> findLdSalesByYearAndLocalDealer(final int year, final LocalDealer localDealer) {
        return dao.findListByCriteria(new DefaultCriteriaCreator<LdSales>() {
            public void modifyCriteria(Criteria criteria) {
                Criteria ldDistCriteria = criteria.createCriteria("ldDist");
                ldDistCriteria.add(eq("localDealer", localDealer));
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.DATE, 1);
                calendar.set(Calendar.MONTH, Calendar.JANUARY);
                calendar.set(Calendar.YEAR, year);
                Date fromDate = calendar.getTime();

                calendar.set(Calendar.DATE, 31);
                calendar.set(Calendar.MONTH, Calendar.DECEMBER);
                calendar.set(Calendar.YEAR, year);
                Date toDate = calendar.getTime();
                criteria.add(between("salesDate", fromDate, toDate));
                criteria.add(eq("active", true));

                criteria.add(eq("validForIncentivePlanning", true));

                criteria.addOrder(Order.asc("ldDist.id"));
            }
        });

    }

    public LdSalesCn findLdSalesCn(final int ldSalesId, final int creditNoteId) {

        LdSalesCn ldSalesCn = dao.findByCriteria(new DefaultCriteriaCreator<LdSalesCn>() {
            public void modifyCriteria(Criteria criteria) {
                criteria.createCriteria("ldSales").add(eq("id", ldSalesId));
                criteria.createCriteria("creditNote").add(eq("id", creditNoteId));
            }
        });
        return ldSalesCn;
    }

}
