package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.LdDist;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 7/12/2011
 * Time: 03:13:06 PM
 */
public interface LdDistService {
    Collection<LdDist> lookupLdDistByDistributor(Integer distributorId);
}
