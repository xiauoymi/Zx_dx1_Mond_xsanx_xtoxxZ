package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdDistDao;
import com.monsanto.eas.cia.model.LdDist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 7/12/2011
 * Time: 03:15:05 PM
 */
@Service
@RemotingDestination(value = "ldDistService")
public class LdDistServiceImpl implements LdDistService {
    @Autowired
    private LdDistDao ldDistDao;

    @RemotingInclude
    public Collection<LdDist> lookupLdDistByDistributor(Integer distributorId) {
        return ldDistDao.lookupByDistributorId(distributorId);  
    }
}
