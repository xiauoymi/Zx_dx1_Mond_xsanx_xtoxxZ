package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdProgramYearStatusDao;
import com.monsanto.eas.cia.model.LdProgramYearStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 4:50:36 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "ldProgramStatusService")
public class LdProgramYearServiceImpl implements LdProgramStatusService {
  @Autowired
  private LdProgramYearStatusDao ldProgramYearStatusDao;

  @RemotingInclude
  public Collection<LdProgramYearStatus> lookupAll() {
    return ldProgramYearStatusDao.lookupAll();
  }

}
