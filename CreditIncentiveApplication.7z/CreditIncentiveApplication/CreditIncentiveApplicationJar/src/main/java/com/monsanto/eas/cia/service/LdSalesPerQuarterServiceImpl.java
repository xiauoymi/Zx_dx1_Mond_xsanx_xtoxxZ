/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdSalesPerQuarterDao;
import com.monsanto.eas.cia.model.Area;
import com.monsanto.eas.cia.model.LdSalesPerQuarter;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.ProgramQuarter;
import com.monsanto.eas.cia.model.area.SubRegion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Iterator;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "ldSalesPerQuarterService")
public class LdSalesPerQuarterServiceImpl implements LdSalesPerQuarterService{

  @Autowired
  private LdSalesPerQuarterDao ldSalesPerQuarterDao;

  @Transactional
  @RemotingInclude
  public Collection<LdSalesPerQuarter> lookupLdSalesPerQuarterByYear(Integer year) {
    Collection<LdSalesPerQuarter> ldSalesPerQuarter = ldSalesPerQuarterDao.lookupLdSalesPerQuarterByYear(year);
    Iterator<LdSalesPerQuarter> iterator = ldSalesPerQuarter.iterator();
    while(iterator.hasNext()) {
        LdSalesPerQuarter salesPerQuarter = iterator.next();
        LocalDealer dealer = salesPerQuarter.getLocalDealer();
        if(dealer!=null) {
            setAreaFieldsToNull(dealer);
            dealer.setLdDist(null);            
        }        
    }    
    return ldSalesPerQuarter;
  }

  private void setAreaFieldsToNull(LocalDealer dealer) {
      setAreaValuesToNull(dealer.getSubRegion());
      setAreaValuesToNull(dealer.getPostalCodeArea());
      setAreaValuesToNull(dealer.getDistrict());
  }

  private void setAreaValuesToNull(Area area) {
      if(area!=null) {
        Area parentArea = area.getParentArea();
        do {
            parentArea.setChildAreas(null);
            area.setChildAreas(null);
            parentArea = parentArea.getParentArea();
        } while (parentArea!=null);
      }
  }

}