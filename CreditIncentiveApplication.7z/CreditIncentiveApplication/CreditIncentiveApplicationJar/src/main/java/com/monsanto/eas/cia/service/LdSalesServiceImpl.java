/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdSalesDao;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.service.FinderService;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.System;
import java.util.Collection;
import java.util.Iterator;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "ldSalesService")
public class LdSalesServiceImpl implements LdSalesService {

    @Autowired
    private LdSalesDao ldSalesDao;

    @Autowired
    private FinderService finderService;

    @RemotingInclude
    public LdSales findById(Integer id) {
        LdSales ldSales = ldSalesDao.findByPrimaryKey(LdSales.class, id);
        ldSales.setAssignedFrom(null);
        return ldSales;
    }


    @RemotingInclude
    public void update(Collection<LdSales> ldSales) {
        for (LdSales sale : ldSales) {
            ldSalesDao.merge(sale);
        }
    }

    @RemotingInclude
    public void updateSingleSale(LdSales sale) {
        ldSalesDao.merge(sale);
    }

    @RemotingInclude
    public Collection<LdSales> findSalesByIds(Collection<Integer> ids) {
        Collection<LdSales> result = ldSalesDao.lookupByIds(ids);
        Iterator<LdSales> iterator = result.iterator();
        while(iterator.hasNext()) {
            LdSales tmpSale = iterator.next();
            tmpSale.setAssignedFrom(null);
        }
        return result;
    }

    private void resetLdProgramYears(LocalDealer localDealer) {
        if (localDealer != null) {
            Collection<LdProgramYear> programYears = localDealer.getProgramYears();
            Iterator<LdProgramYear> iterator = programYears.iterator();
            while (iterator.hasNext()) {
                LdProgramYear tmpProgYear = iterator.next();
                setAreaFieldsToNull(tmpProgYear.getLocalDealer());
                tmpProgYear.setLdProgramYearStatus(null);
            }
        }
    }

    private void resetLdIncentives(LocalDealer localDealer) {
        if (localDealer != null) {
            Collection<LdIncentive> incentives = localDealer.getIncentives();
            Iterator<LdIncentive> iterator = incentives.iterator();
            while (iterator.hasNext()) {
                LdIncentive tmpIncentive = iterator.next();
                setAreaFieldsToNull(tmpIncentive.getLocalDealer());
            }
        }
    }

    private void resetLdSalesCnCollection(Collection<LdSalesCn> ldSalesCnCollection) {
        if (ldSalesCnCollection != null) {
            Iterator<LdSalesCn> iterator = ldSalesCnCollection.iterator();
            while (iterator.hasNext()) {
                LdSalesCn tmpLdSalesCn = iterator.next();
                if (tmpLdSalesCn.getLdSales() != null) {
                    resetLdIncentives(tmpLdSalesCn.getLdSales().getAssignedFrom());
                    resetLdProgramYears(tmpLdSalesCn.getLdSales().getAssignedFrom());
                    resetLdDist(tmpLdSalesCn.getLdSales().getLdDist());
                    setAreaFieldsToNull(tmpLdSalesCn.getLdSales().getAssignedFrom());
                }
            }
        }
    }

    private void resetLdDist(LdDist ldDist) {
        if (ldDist != null) {
            setAreaFieldsToNull(ldDist.getLocalDealer());
            setAreaFieldsToNull(ldDist.getDistributor());
        }
        ldDist.setLdSales(null);
        ldDist.setLdProgramYear(null);
    }

    private void setAreaFieldsToNull(Object dealerDist) {
        LocalDealer dealer = null;
        if (dealerDist instanceof LocalDealer) {
            dealer = (LocalDealer) dealerDist;
        }
        if (dealer != null) {
            setAreaValuesToNull(dealer.getSubRegion());
            setAreaValuesToNull(dealer.getPostalCodeArea());
            setAreaValuesToNull(dealer.getDistrict());
        }
    }

    private void setAreaValuesToNull(Area area) {
        if (area != null) {
            area.setChildAreas(null);
        }
    }

    public Collection<LdSales> findByYearAndLocalDealer(int year, LocalDealer localDealer) {
        return finderService.findLdSalesByYearAndLocalDealer(year, localDealer);
    }
}
