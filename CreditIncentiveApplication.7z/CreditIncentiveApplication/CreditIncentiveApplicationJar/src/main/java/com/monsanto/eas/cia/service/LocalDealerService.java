package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.LdSales;
import com.monsanto.eas.cia.model.LdSalesPerProduct;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.vo.LocalDealerVO;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:49 PM To change this template use File |
 * Settings | File Templates.
 */
public interface LocalDealerService {

  Collection<LocalDealerVO> lookupAllLocalDealersVO();

  Collection<LocalDealer> lookupAllLocalDealers();

  LocalDealer lookUpLocalDealer(Integer localDealerId);

  LocalDealer saveOrUpdate(LocalDealer localDealer);

  LocalDealer lookupLocalDealerById(Integer localDealerId);

  @RemotingInclude
  Collection<LdSales> lookUpAllSalesTransactions();

  Collection<LocalDealer> lookupAllUnSignedLocalDealers();

  Collection<LdSalesPerProduct> lookupLdSalesPerProductByYearAndLeader(Integer localDeaderId, Integer year);

  LdSalesPerProduct lookupLdSalesPerProductByYearAndLeaderAndProduct(Integer localDeaderId, Integer year, Integer productLineId);

}
