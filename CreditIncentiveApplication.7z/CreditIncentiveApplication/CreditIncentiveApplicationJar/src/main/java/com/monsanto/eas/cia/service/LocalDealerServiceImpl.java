package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdIncentiveDao;
import com.monsanto.eas.cia.dao.LdSalesDao;
import com.monsanto.eas.cia.dao.LocalDealerDao;
import com.monsanto.eas.cia.dao.SalesPerProductDao;
import com.monsanto.eas.cia.model.*;
import com.monsanto.eas.cia.model.area.District;
import com.monsanto.eas.cia.model.area.PostalCode;
import com.monsanto.eas.cia.model.area.SubRegion;
import com.monsanto.eas.cia.model.vo.LocalDealerVO;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:57 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "localDealerService")
public class LocalDealerServiceImpl implements LocalDealerService {
    @Autowired
    private LocalDealerDao localDealerDao;

    @Autowired
    private LdSalesDao ldSalesDao;

    @Autowired
    private SalesPerProductDao ldSalesPerProductDao;

    private Collection<LocalDealerVO> getLocalDealerVO(Collection<LocalDealer> dealers){
          Collection<LocalDealerVO> dealersList = new ArrayList<LocalDealerVO>(dealers.size());
        for (LocalDealer dealer : dealers) {
            LocalDealerVO vo = new LocalDealerVO();
            vo.setId(dealer.getId());
            vo.setName(dealer.getName());
            vo.setAddress1(dealer.getAddress1());
            vo.setAddress2(dealer.getAddress2());
            vo.setAgreementNumber(dealer.getAgreementNumber());
            vo.setBirthday(dealer.getBirthday());
            vo.setBusinessAnniversary(dealer.getBusinessAnniversary());
            vo.setEmail(dealer.getEmail());
            vo.setFax(dealer.getFax());
            vo.setFiscalName(dealer.getFiscalName());
            vo.setPhone(dealer.getPhone());
            vo.setPosName(dealer.getPosName());
            vo.setRfc(dealer.getRfc());
            dealersList.add(vo);
        }
        return dealersList;
    }

    @RemotingInclude
    public Collection<LocalDealerVO> lookupAllLocalDealersVO() {
        Collection<LocalDealer> dealers = localDealerDao.lookupAllLocalDealers();
        return getLocalDealerVO(dealers);
    }

    @RemotingInclude
    public Collection<LocalDealer> lookupAllLocalDealers() {
        Collection<LocalDealer> dealers = localDealerDao.lookupAllLocalDealers();
        Iterator<LocalDealer> iterator = dealers.iterator();
        while (iterator.hasNext()) {
            LocalDealer localDealer = iterator.next();
            setAreaFieldsToNull(localDealer);
            localDealer.setIncentives(null);
            localDealer.setLdDist(null);
            localDealer.setProgramYears(null);
        }
        return dealers;
    }

    @RemotingInclude
    public LocalDealer lookUpLocalDealer(Integer localDealerId) {
        LocalDealer localDealer = localDealerDao.lookUpLocalDealer(localDealerId);
        setAreaFieldsToNull(localDealer);
        Collection<LdDist> distCollection = localDealer.getLdDist();
        Iterator<LdDist> ldDistIterator = distCollection.iterator();
        while (ldDistIterator.hasNext()) {
            LdDist ldDist = ldDistIterator.next();
            ldDist.setLocalDealer(null);
            ldDist.setLdSales(null);
            ldDist.setLdProgramYear(null);

            SapDistributor distributor = ldDist.getDistributor();
            if (null != distributor) {
                distributor.setCurrentVersion(null);
                distributor.setDescription(null);
                distributor.setModDate(null);
                distributor.setModUser(null);
                distributor.setSyncVersion(null);
            }
        }
        return localDealer;
    }

    private void setAreaFieldsToNull(LocalDealer localDealer) {
        SubRegion subRegion = localDealer.getSubRegion();
        if (subRegion != null) {
            subRegion.setChildAreas(null);
            subRegion.setParentArea(null);
        }
        District district = localDealer.getDistrict();
        if (district != null) {
            district.setChildAreas(null);
            district.setParentArea(null);
        }
        PostalCode postalCodeArea = localDealer.getPostalCodeArea();
        if (postalCodeArea != null) {
            postalCodeArea.setChildAreas(null);
            postalCodeArea.setParentArea(null);
        }
    }

    @RemotingInclude
    @Transactional(timeout = 600)
    public LocalDealer saveOrUpdate(LocalDealer localDealer) {

        if(localDealer.getLdDist()!=null && !localDealer.getLdDist().isEmpty()) {
            for(LdDist d : localDealer.getLdDist()) {
                d.setLdProgramYear(localDealer.getProgramYears().iterator().next());
            }
        }

        String agreementNumber = localDealer.getAgreementNumber();
        if (StringUtils.isEmpty(agreementNumber)) {
            localDealerDao.setAgreementNumber(localDealer);
        }
        else {
            localDealerDao.merge(localDealer);
        }
        return localDealer;
    }

    public LocalDealer lookupLocalDealerById(Integer localDealerId) {
        return localDealerDao.findByPrimaryKey(LocalDealer.class, localDealerId);
    }

    @RemotingInclude
    public Collection<LdSales> lookUpAllSalesTransactions() {
        Collection<LdSales> salesCollection = ldSalesDao.lookupAll();
        Iterator<LdSales> iterator = salesCollection.iterator();
        while (iterator.hasNext()) {
            LdSales sale = iterator.next();
            sale.setLdDist(null);
            LocalDealer dealer = sale.getAssignedFrom();
            if (dealer != null) {
                setAreaFieldsToNull(dealer);
            }
        }
        return salesCollection;
    }

    @RemotingInclude
    public Collection<LocalDealer> lookupAllUnSignedLocalDealers() {
        Collection<LocalDealer> unsignedDealers = localDealerDao.lookupAllUnsignedLocalDealers();
        Iterator<LocalDealer> iterator = unsignedDealers.iterator();
        while (iterator.hasNext()) {
            LocalDealer unsignedDealer = iterator.next();
            unsignedDealer.setLdDist(null);
            unsignedDealer.setIncentives(null);
            unsignedDealer.setProgramYears(null);
            setAreaFieldsToNull(unsignedDealer);
        }
        return unsignedDealers;
    }

    public Collection<LdSalesPerProduct> lookupLdSalesPerProductByYearAndLeader(Integer localDealerId, Integer year) {
        return ldSalesPerProductDao.lookupLdSalesPerProductByYearAndLeader(localDealerId, year);
    }

    public LdSalesPerProduct lookupLdSalesPerProductByYearAndLeaderAndProduct(Integer localDeaderId, Integer year, Integer productLineId) {
        return ldSalesPerProductDao.lookupLdSalesPerProductByYearAndLeaderAndProduct(localDeaderId, year, productLineId);
    }


}
