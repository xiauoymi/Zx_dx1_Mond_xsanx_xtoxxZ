package com.monsanto.eas.cia.service;

import org.springframework.transaction.annotation.Transactional;

import javax.mail.MessagingException;
import java.util.Map;

/**
 * Utility for sending emails.
 *
 * User: JEESCO
 * Date: 21/07/2011
 * Time: 04:32:36 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface MailSender {
    public void send(final Map<String, Object> mailData) throws MessagingException;
}
