package com.monsanto.eas.cia.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.ByteArrayOutputStream;

import java.io.OutputStream;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import com.monsanto.eas.cia.CiaConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

/**
 * Implementation of the <code>MailSender</code> interface.
 * User: JEESCO
 * Date: 21/07/2011
 * Time: 04:56:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
public class MailSenderImpl implements MailSender {
    @Autowired
    private JavaMailSender mailSender;
    /**
     * Sends an email with the information specified in the mailData.
     * @param mailData Map what contains the information that is required for sending an email.
     * @throws MessagingException In case an error occurs.
     */
    @RemotingInclude
    public void send(final Map<String, Object> mailData) throws MessagingException {        
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            @SuppressWarnings("unchecked")
            public void prepare(MimeMessage mimeMessage) throws Exception {
                String from = (String) mailData.get(CiaConstants.FROM);
                String to = (String) mailData.get(CiaConstants.TO);
                String subject = (String) mailData.get(CiaConstants.SUBJECT);
                String text = (String) mailData.get(CiaConstants.MAIL_BODY);
                Collection<String> ccList = (List<String>) mailData.get(CiaConstants.CC_LIST);
                MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, Boolean.TRUE);
                messageHelper.setFrom(from);
                messageHelper.setTo(to);
                messageHelper.setSubject(subject);
                OutputStream file = (OutputStream) mailData.get(CiaConstants.ATTACHED_FILE);
                if(file instanceof ByteArrayOutputStream) {
                    messageHelper.addAttachment((String)mailData.get(CiaConstants.ATTACHED_FILENAME), new ByteArrayResource(((ByteArrayOutputStream) file).toByteArray()));
                }
                if(ccList!=null && ccList.size()>0) {
                    for(String cc:ccList) {
                        messageHelper.addCc(cc);
                    }
                }
                messageHelper.setText((text!=null && text.trim().length()>0) ? text : "N/A");
            }
        };         
        mailSender.send(preparator);
    }    
}
