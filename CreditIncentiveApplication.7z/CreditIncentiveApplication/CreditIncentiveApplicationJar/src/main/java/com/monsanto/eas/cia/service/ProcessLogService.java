package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.ProcessLog;

public interface ProcessLogService {

	public abstract void mergeProcessLog(ProcessLog processLog);

	public abstract void saveProcessLog(ProcessLog processLog);

	public abstract ProcessLog findProcessLog(Integer id);

	public abstract Integer createNewProcessLog();

}
