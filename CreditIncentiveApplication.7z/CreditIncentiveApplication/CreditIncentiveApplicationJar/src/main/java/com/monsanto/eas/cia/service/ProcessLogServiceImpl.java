package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.ProcessLogDao;
import com.monsanto.eas.cia.model.ProcessLog;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@RemotingDestination(value = "processLogService")
public class ProcessLogServiceImpl implements ProcessLogService{
	
	@Autowired
	protected ProcessLogDao processLogDao;

    protected int trimDetailLength=2048;

	@Transactional
	@RemotingInclude
	public ProcessLog findProcessLog(Integer id){				
		ProcessLog processLog=processLogDao.findByPrimaryKey(ProcessLog.class, id);
		if(processLog==null)return null;
		
		if(processLog.isDeleteAfterNextRead()){
			processLogDao.delete(processLog);
		}

		return processLog;
	}

    protected String trimDetail(String detail){
        if(detail==null)return "";
        return StringUtils.abbreviate(detail,trimDetailLength);
    }

	@Transactional	
	public Integer createNewProcessLog(){
		ProcessLog processLog=new ProcessLog();
		processLog.setDate(new Date());
		processLog.setDeleteAfterNextRead(false);
		processLog.setDetail("");
		saveProcessLog(processLog);
		return processLog.getId();		
	}
	
	@Transactional
	@RemotingInclude
	public void saveProcessLog(ProcessLog processLog){
        if(processLog!=null){
            processLog.setDetail(trimDetail(processLog.getDetail()));
		    processLogDao.save(processLog);
        }
	}

	@Transactional	
	public void mergeProcessLog(ProcessLog processLog){
		processLogDao.merge(processLog);
	}
	
	public void setProcessLogDao(ProcessLogDao processLogDao) {
		this.processLogDao = processLogDao;
	}

    public void setTrimDetailLength(int trimDetailLength) {
        this.trimDetailLength = trimDetailLength;
    }
}
