package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.ProductLine;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 23, 2010 Time: 4:51:52 PM To change this template use File |
 * Settings | File Templates.
 */
public interface ProductLineService {
  Collection<ProductLine> lookupAllProductLinesNotAssignedToDist(Integer id);
}
