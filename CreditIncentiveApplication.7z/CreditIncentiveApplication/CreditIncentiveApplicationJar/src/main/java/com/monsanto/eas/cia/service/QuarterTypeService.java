package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.QuarterType;
import com.monsanto.eas.cia.model.Year;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 10:45:50 AM To change this template use File |
 * Settings | File Templates.
 */
public interface QuarterTypeService {
  Collection<QuarterType> lookupAllQuarterTypes();
}
