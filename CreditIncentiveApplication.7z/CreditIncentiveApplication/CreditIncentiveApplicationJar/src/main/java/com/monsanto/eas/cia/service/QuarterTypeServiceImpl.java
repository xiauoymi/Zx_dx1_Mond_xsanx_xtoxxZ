package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.QuarterTypeDao;
import com.monsanto.eas.cia.dao.YearDao;
import com.monsanto.eas.cia.model.QuarterType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 10:46:35 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout=600)
@RemotingDestination(value = "quarterTypeService")
public class QuarterTypeServiceImpl implements QuarterTypeService {
  @Autowired
  private QuarterTypeDao quarterTypeDao;

  @RemotingInclude
  public Collection<QuarterType> lookupAllQuarterTypes() {
    return quarterTypeDao.lookupAllQuarters();
  }

}
