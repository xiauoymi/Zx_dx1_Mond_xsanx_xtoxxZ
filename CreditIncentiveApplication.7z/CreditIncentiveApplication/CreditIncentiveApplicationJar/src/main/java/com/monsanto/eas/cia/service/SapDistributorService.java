package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.*;

import java.util.Collection;

public interface SapDistributorService {

    Collection<CnPerDistributorView> lookupCreditNotesByYearAndMonthAndDistributor(int year, String toMonth, Long distributorId );

    Collection<SapDistributor> lookupSapDistributorByCodeOrDescriptionOrEmail(String filter);

    Collection<SapDistributor> lookupAllSapDistributors();

    void saveCreditNotes(Collection<CnPerDistributorView> pendingCreditNotes, int year, String toMonth);

    SapDistributor lookUpSapDistributorByCode(String distId);

    Collection<SapDistributor> saveAll(Collection<SapDistributor> sapDistributors);
}
