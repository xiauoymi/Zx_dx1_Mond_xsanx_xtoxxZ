package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.*;
import com.monsanto.eas.cia.model.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
@RemotingDestination(value = "sapDistributorService")
public class SapDistributorServiceImpl implements SapDistributorService {

    private enum months {jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec}


    @Autowired
    private SapDistributorDao sapDistributorDao;

    @Autowired
    private DistributorCnDao distributorCnDao;

    @Autowired
    private TaxReserveDao taxReserveDao;

    @Autowired
    private CreditNoteDao creditNoteDao;

    @Autowired
    private LdSalesCnDao ldSalesCnDao;

    @Autowired
    private SalesPerQuarterDao salesPerQuarterDao;

    @Autowired
    private LdSalesDao ldSalesDao;

    @Autowired
    private ProgramQuarterDao programQuarterDao;

    @Autowired
    private CnPerDistributorViewDao cnPerDistributorViewDao;

    @Autowired
    private SalesQtrDlrDistViewDao salesQtrDlrDistViewDao;

    @Autowired
    private SalesViewDao salesViewDao;


    public static final Logger LOGGER = Logger.getLogger(SapDistributorServiceImpl.class);


    @RemotingInclude
    @Transactional
    public Collection<SapDistributor> saveAll(Collection<SapDistributor> sapDistributors) {
        return sapDistributorDao.saveAll(sapDistributors);
    }

    @RemotingInclude
    public Collection<SapDistributor> lookupSapDistributorByCodeOrDescriptionOrEmail(String filter) {
        Collection<SapDistributor> col = sapDistributorDao.lookupSapDistributorByCodeOrDescriptionOrEmail(filter);
        return col;
    }

    @RemotingInclude
    public Collection<SapDistributor> lookupAllSapDistributors() {
        return sapDistributorDao.lookupAll();
    }

    public SapDistributor lookUpSapDistributorByCode(String distributorId) {
        return sapDistributorDao.lookupSapDistributorByCode(distributorId);
    }

    @RemotingInclude
    public Collection<CnPerDistributorView> lookupCreditNotesByYearAndMonthAndDistributor(int year, String toMonth, Long distributorId) {

        Integer month = months.valueOf(toMonth.toLowerCase()).ordinal();
        GregorianCalendar gc = new GregorianCalendar();
        gc.set(GregorianCalendar.YEAR, year);
        gc.set(GregorianCalendar.MONTH, month);
        gc.set(GregorianCalendar.DAY_OF_MONTH, 1);
        Collection<CnPerDistributorView> creditNotes = cnPerDistributorViewDao.lookupCreditNotesByYearAndMonthAndDistributor(year, gc.getTime(), distributorId);
        return creditNotes;

    }

    private void addDistributorCreditNotes(Map<String, DistributorCnView> tempHashMap, Collection<DistributorCnView> distributorCreditNotes, boolean sent, SapDistributor distributor) {
        Iterator<DistributorCnView> iterator;
        iterator = distributorCreditNotes.iterator();
        while (iterator.hasNext()) {
            DistributorCnView distributorCnView = iterator.next();
            if (distributor == null || (distributor != null && String.valueOf(distributor.getId()).equals(distributorCnView.getDistId()))) {
                distributorCnView.setCreditNoteSent(sent);
                if (tempHashMap.get(distributorCnView.getSymId()) == null) {
                    tempHashMap.put(distributorCnView.getSymId(), distributorCnView);
                }
            }
        }
    }

    @RemotingInclude
    @Transactional(timeout = 600)
    public void saveCreditNotes(Collection<CnPerDistributorView> pendingCreditNotes, int year, String toMonth) {

        Integer month = months.valueOf(toMonth.toLowerCase()).ordinal();
        GregorianCalendar gc = new GregorianCalendar();
        gc.set(GregorianCalendar.YEAR, year);
        gc.set(GregorianCalendar.MONTH, month);
        gc.set(GregorianCalendar.DAY_OF_MONTH, 1);
        gc.set(GregorianCalendar.HOUR, 0);
        gc.set(GregorianCalendar.MINUTE, 0);
        gc.set(GregorianCalendar.SECOND, 0);
        gc.set(GregorianCalendar.MILLISECOND, 0);
        Date startingDate = gc.getTime();
        gc.add(GregorianCalendar.MONTH, 1);
        Date endingDate = gc.getTime();
        LOGGER.debug(startingDate);
        LOGGER.debug(endingDate);

        for (CnPerDistributorView pendingCreditNote : pendingCreditNotes) {
            ProgramQuarter programQuarter = programQuarterDao.findByPrimaryKey(
                    ProgramQuarter.class,
                    pendingCreditNote.getProgramQuarterId().intValue());
            //(1)For each valid quarter sum every already payed credit note for this distributor in the current quarter
            //(2)Calculate the total accumulated incentive for the distributor for the current quarter
            //Subtract (2) minus (1). If the result is bigger than zero then create a new Credit Note with this amount, and assign the orphan sales to the new credit note otherwise don´t do nothing.
            BigDecimal[] incentiveCalculations = salesQtrDlrDistViewDao.
                    findIncentiveDebtByDistQuarterYearGroupedByDist(
                            pendingCreditNote.getDistributorId(), pendingCreditNote.getProgramQuarterId());
            BigDecimal accumulatedIncentive = incentiveCalculations[0];
            BigDecimal closingIncentive = incentiveCalculations[1];
            BigDecimal fixedIncentive = incentiveCalculations[2];
            BigDecimal creditNoteAmount = accumulatedIncentive.subtract(fixedIncentive);
            LOGGER.debug("accumulatedIncentive "+accumulatedIncentive);
            LOGGER.debug("closingIncentive "+closingIncentive);
            LOGGER.debug("fixedIncentive "+fixedIncentive);
            LOGGER.debug("creditNoteAmount "+creditNoteAmount);
            if (creditNoteAmount.compareTo(BigDecimal.ZERO) > 0) {
                CreditNote creditNote = createNewCreditNote(pendingCreditNote.getDistributorId(), pendingCreditNote.getTaxReserveId(), creditNoteAmount);
                assignSalesToCreditNote(creditNote, pendingCreditNote.getDistributorId(), pendingCreditNote.getProgramQuarterId());
                //Update incentive amount of Sales for this distributor in the current quarter.
                updateFixSaleIncentive(pendingCreditNote.getDistributorId(), programQuarter);
            }
        }
    }

    private CreditNote createNewCreditNote(Long distributorId, Long taxReserveId, BigDecimal creditNoteAmount) {
        CreditNote creditNote = new CreditNote();
        SapDistributor distributor = new SapDistributor();
        distributor.setId(distributorId.intValue());
        creditNote.setDistributor(distributor);
        Calendar instance = Calendar.getInstance();
        creditNote.setDate(instance.getTime());
        //set Tax Reserve
        TaxReserve taxReserve = new TaxReserve();
        taxReserve.setId(taxReserveId.intValue());
        creditNote.setTaxReserve(taxReserve);
        creditNote.setCode("WS");
        creditNote.setSyncVersion(1);
        creditNote.setAmount(creditNoteAmount);
        creditNoteDao.persist(creditNote);
        return creditNote;
    }

    private void assignSalesToCreditNote(CreditNote creditNote, Long distributorId, Long programQuarterId) {
        //Inserts Sales Credit Note relation in SalesCn.
        Collection<SalesView> salesNotCountedForIncentive = salesViewDao.
                findByDistributorAndProgramQuarterAndCreditNoteNull(
                        distributorId, programQuarterId);
        for (SalesView sale : salesNotCountedForIncentive) {
            LdSalesCn ldSalesCn = new LdSalesCn();
            LdSales persistedSale = ldSalesDao.lookupAllSalesWithId(sale.getSalesId().intValue());
            ldSalesCn.setLdSales(persistedSale);
            ldSalesCn.setCreditNote(creditNote);
            ldSalesCn.setSyncVersion(0);
            ldSalesCn.setCurrentVersion(0);
            SalesQtrDlrDistViewId id = new SalesQtrDlrDistViewId();
            id.setLdDistId(Long.valueOf(persistedSale.getLdDist().getId()));
            id.setProgramQuarterId(programQuarterId);
            SalesQtrDlrDistView localDealerResults = salesQtrDlrDistViewDao.findByPrimaryKey(SalesQtrDlrDistView.class, id);
            BigDecimal incentiveAmount = sale.getPrice().multiply(sale.getVolumeToIncentive())
                    //.multiply(sale.getLtConversionFactor())
                    .multiply(localDealerResults.getIncentivePct());
            ldSalesCn.setIncentiveAmount(incentiveAmount.doubleValue());
            persistedSale.setIncentiveAmount(incentiveAmount.doubleValue());
            //ldSalesDao.persist(persistedSale);
            ldSalesCnDao.persist(ldSalesCn);
        }
    }

    private void updateFixSaleIncentive(Long distributorId, ProgramQuarter programQuarter) {
        Collection<SalesQtrDlrDistView> localDealers = salesQtrDlrDistViewDao.findByDistributorAndProgramQuarterId(distributorId, Long.valueOf(programQuarter.getId()));
        for (SalesQtrDlrDistView localDealer : localDealers) {
            ldSalesDao.updateIncentiveAmount(
                    localDealer.getDistributorId(),
                    localDealer.getDealerId(),
                    programQuarter.getQuarterStart(),
                    programQuarter.getQuarterEnd(),
                    localDealer.getIncentivePct().doubleValue()
            );
        }
    }


    private Double getAmountPaidSoFar(String salesId) {
        Double cumulativeAmt = 0.0;
        Collection<LdSalesCn> salesCns = ldSalesCnDao.lookupAllCreditNotesPerSale(salesId);
        Iterator<LdSalesCn> salesCnIterator = salesCns.iterator();
        while (salesCnIterator.hasNext()) {
            LdSalesCn cn = salesCnIterator.next();
            Double amount = cn.getIncentiveAmount();
            cumulativeAmt += amount;
        }
        return cumulativeAmt;  //To change body of created methods use File | Settings | File Templates.
    }

}
