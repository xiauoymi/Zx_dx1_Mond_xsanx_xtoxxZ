package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.SapProductPrice;
import com.monsanto.eas.cia.vo.SapProductPriceVO;

import java.util.Collection;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 8/02/13
 * Time: 10:33 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SapProductPriceService {

    /**
     * Get all SapProductPrice
     *
     * @return SapProductPrice collection
     */
    Collection<SapProductPrice> lookupAll();

    /**
     * Get SapProductPrice by Id
     *
     * @param id Id
     * @return SapProductPrice
     */
    SapProductPrice lookupProductPriceById(final Integer id);

    /**
     * Get SapProductPrice by transaction date
     *
     * @param productId       Product Id
     * @param transactionDate Transaction date
     * @return SapProductPrice
     */
    SapProductPrice lookupProductPriceByTransDate(final Integer productId, final Date transactionDate);

    /**
     * Get all SapProductPriceVO
     * @return
     */
    Collection<SapProductPriceVO> lookupProductPrices();

    /**
     *  Save or update a SapProductPriceVO
      * @param spp
     * @return
     */
    Collection<String> saveOrUpdateSapProductPrice(SapProductPriceVO spp);
}