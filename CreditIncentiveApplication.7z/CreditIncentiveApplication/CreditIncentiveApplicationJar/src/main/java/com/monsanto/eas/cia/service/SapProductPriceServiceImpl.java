package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.CiaConstants;
import com.monsanto.eas.cia.dao.SalesPerProductDao;
import com.monsanto.eas.cia.dao.SapProductPriceDao;
import com.monsanto.eas.cia.model.SapProduct;
import com.monsanto.eas.cia.model.SapProductPrice;
import com.monsanto.eas.cia.util.DateUtil;
import com.monsanto.eas.cia.vo.SapProductPriceVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.stream.events.StartDocument;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 8/02/13
 * Time: 10:38 AM
 * To change this template use File | Settings | File Templates.
 */

@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "sapProductPriceService")
public class SapProductPriceServiceImpl implements SapProductPriceService {

    public static final Logger LOGGER = Logger.getLogger(SapDistributorServiceImpl.class);

    @Autowired
    private SapProductPriceDao sapProductPriceDao;

    @Autowired
    private FinderService finderService;

    @Autowired
    MessageSource messageSource;

    /**
     * @see SapProductPriceService#lookupAll()
     */
    @RemotingInclude
    public Collection<SapProductPrice> lookupAll() {
        return sapProductPriceDao.lookupAll();
    }

    /**
     * @see SapProductPriceService#lookupProductPriceById(Integer)
     */
    @RemotingInclude
    public SapProductPrice lookupProductPriceById(final Integer id) {
        return sapProductPriceDao.lookupProductPriceById(id);
    }

    /**
     * @see SapProductPriceService#lookupProductPriceByTransDate(Integer, Date)
     */
    @RemotingInclude
    public SapProductPrice lookupProductPriceByTransDate(final Integer productId, final Date transactionDate) {
        return sapProductPriceDao.lookupProductPriceByTransDate(productId, transactionDate);
    }

    @RemotingInclude
    public Collection<SapProductPriceVO> lookupProductPrices() {

        Collection<SapProductPriceVO> list = new ArrayList<SapProductPriceVO>();
        Collection<SapProductPrice> prices = this.lookupAll();

        if(prices != null && !prices.isEmpty()) {
            for(SapProductPrice pp : prices) {
                SapProductPriceVO spp = new SapProductPriceVO();
                spp.setSapProductId(pp.getId());
                spp.setSapProductCode(pp.getSapProduct().getCode());
                spp.setDescription(pp.getSapProduct().getDescription());
                spp.setPrice(pp.getPrice());
                spp.setStartDate(DateUtil.getDate(DateUtil.PATTERN_yyyy_MM_dd_SLASH_SEPARATOR, pp.getStartDate()));
                spp.setEndDate(DateUtil.getDate(DateUtil.PATTERN_yyyy_MM_dd_SLASH_SEPARATOR,pp.getEndDate()));
                list.add(spp);
            }
        }

        return list;
    }

    @RemotingInclude
    @Transactional(timeout = 600)
    public Collection<String> saveOrUpdateSapProductPrice(SapProductPriceVO spp) {

        Collection<String> response = new ArrayList<String>();

        Locale locale = Locale.getDefault();

        if(spp != null && spp.isValid()) {

            Date startDate = DateUtil.getDate(spp.getStartDate(),DateUtil.PATTERN_yyyy_MM_dd_SLASH_SEPARATOR);
            Date endDate = DateUtil.getDate(spp.getEndDate(),DateUtil.PATTERN_yyyy_MM_dd_SLASH_SEPARATOR);
            Double price = spp.getPrice();

            if(spp.getNewRecord()) { // new sap product price

                SapProduct sp = finderService.findSapProductFrom(spp.getSapProductCode());

                if(sp!=null) {

                    if(sapProductPriceDao.checkDateRangeToInsertUpdateSapProductPrice(sp.getId(),startDate,endDate,null)) {
                        SapProductPrice productPrice = new SapProductPrice();
                        productPrice.setSapProduct(sp);
                        productPrice.setStartDate(startDate);
                        productPrice.setEndDate(endDate);
                        productPrice.setPrice(price);
                        sapProductPriceDao.persist(productPrice);
                    }else {
                        response.add(messageSource.getMessage(CiaConstants.SAP_PROD_PRICE_INVALID_DATE_RANGE, null, locale));
                    }
                }else {
                    response.add(messageSource.getMessage(CiaConstants.SAP_PROD_PRICE_NOT_FOUND, new Object[]{spp.getSapProductCode()}, locale));
                }

            }else{ // update exist sap product price
                SapProductPrice productPrice = sapProductPriceDao.findByPrimaryKey(SapProductPrice.class,spp.getSapProductId());

                if(productPrice!=null) {

                    if(sapProductPriceDao.checkDateRangeToInsertUpdateSapProductPrice(productPrice.getSapProduct().getId(),startDate,endDate, productPrice.getId())) {
                        productPrice.setStartDate(startDate);
                        productPrice.setEndDate(endDate);
                        productPrice.setPrice(price);
                        sapProductPriceDao.save(productPrice);
                    }else {
                        response.add(messageSource.getMessage(CiaConstants.SAP_PROD_PRICE_INVALID_DATE_RANGE, null, locale));
                    }
                }else {
                    response.add(messageSource.getMessage(CiaConstants.SAP_PROD_PRICE_UPDATE_NOT_FOUND, null, locale));
                }
            }
        }else{
            response.add(messageSource.getMessage(CiaConstants.SAP_PROD_PRICE_SAVE_INCOMPLETE_INF, null, locale));
        }
        return response;
    }

}
