package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.LdSales;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.model.TaxReserve;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:49 PM To change this template use File |
 * Settings | File Templates.
 */
public interface TaxReserveService {
  Collection<TaxReserve> lookupAllTaxReserves();

}
