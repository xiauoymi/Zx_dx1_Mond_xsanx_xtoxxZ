package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.TaxReserveDao;
import com.monsanto.eas.cia.model.TaxReserve;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 4:59:57 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout = 600)
@RemotingDestination(value = "taxReserveService")
public class TaxReserveServiceImpl implements TaxReserveService {
  @Autowired
  private TaxReserveDao taxReserveDao;

  @RemotingInclude
  public Collection<TaxReserve> lookupAllTaxReserves() {
    return taxReserveDao.lookupTaxReserves();
  }
}
