package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.model.Year;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:41:16 PM To change this template use File |
 * Settings | File Templates.
 */
public interface TestService {
  Collection<Year> testMethod();
}
