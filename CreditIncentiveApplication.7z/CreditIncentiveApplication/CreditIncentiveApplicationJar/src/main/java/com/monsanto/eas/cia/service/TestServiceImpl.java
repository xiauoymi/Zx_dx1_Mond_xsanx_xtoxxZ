package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.YearDao;
import com.monsanto.eas.cia.model.Year;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 20, 2010 Time: 3:32:53 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "testService")
public class TestServiceImpl implements TestService{
  @Autowired
  private YearDao yearDao;

  @RemotingInclude
  public Collection<Year> testMethod() {
    return yearDao.lookupAllYears();
  }
}
