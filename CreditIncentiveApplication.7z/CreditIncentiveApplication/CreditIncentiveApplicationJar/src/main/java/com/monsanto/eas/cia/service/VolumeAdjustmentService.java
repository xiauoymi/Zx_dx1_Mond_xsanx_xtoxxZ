package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.vo.ParamLookupSalesVO;
import com.monsanto.eas.cia.vo.VolumeAdjustmentSearchResultVO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 22/12/2011
 * Time: 04:03:40 PM
 */
public interface VolumeAdjustmentService {

    Collection<VolumeAdjustmentSearchResultVO> lookupSalesByParams(final ParamLookupSalesVO paramLookupSalesVO);

}
