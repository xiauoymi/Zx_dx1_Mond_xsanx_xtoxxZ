package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.LdSalesCnDao;
import com.monsanto.eas.cia.dao.VolumeAdjustmentDao;
import com.monsanto.eas.cia.model.LdSalesCn;
import com.monsanto.eas.cia.vo.ParamLookupSalesVO;
import com.monsanto.eas.cia.vo.VolumeAdjustmentSearchResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 22/12/2011
 * Time: 04:04:13 PM
 */
@Service
@RemotingDestination(value = "volumeAdjustmentService")
public class VolumeAdjustmentServiceImpl implements VolumeAdjustmentService {

    @Autowired
    private VolumeAdjustmentDao volumeAdjustmentDao;

    @Autowired
    private LdSalesCnDao salesCnDao;

    @RemotingInclude
    public Collection<VolumeAdjustmentSearchResultVO> lookupSalesByParams(final ParamLookupSalesVO paramLookupSalesVO) {
        Collection<VolumeAdjustmentSearchResultVO> salesResult = volumeAdjustmentDao.lookupSalesByParams(paramLookupSalesVO);
        handleRecordEdition(salesResult);
        return salesResult;
    }

    private void handleRecordEdition(Collection<VolumeAdjustmentSearchResultVO> collection) {
        if (collection != null && !collection.isEmpty()) {
            Collection<LdSalesCn> creditNotes = null;
            Iterator<VolumeAdjustmentSearchResultVO> iterator = collection.iterator();
            while (iterator.hasNext()) {
                VolumeAdjustmentSearchResultVO tmpVolumeRecord = iterator.next();
                creditNotes = salesCnDao.lookupAllCreditNotesPerSale(String.valueOf(tmpVolumeRecord.getId()));
                tmpVolumeRecord.setEditable(creditNotes == null || creditNotes.isEmpty());
            }
        }
    }
}
