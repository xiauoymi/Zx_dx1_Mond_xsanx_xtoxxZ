package com.monsanto.eas.cia.service;

import com.monsanto.eas.cia.dao.YearDao;
import com.monsanto.eas.cia.model.Year;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 22, 2010 Time: 10:46:35 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional(readOnly = true, timeout=600)
@RemotingDestination(value = "yearService")
public class YearServiceImpl implements YearService {
  @Autowired
  private YearDao yearDao;

  @RemotingInclude  
  public Collection<Year> lookupAllYears() {
    return yearDao.lookupAllYears();
  }

  @RemotingInclude  
  public void saveOrUpdate(Year year) {
//    if (year.getId() == null) {
//      yearDao.save(year);
//    } else {
      yearDao.merge(year);
//    }
  }
}
