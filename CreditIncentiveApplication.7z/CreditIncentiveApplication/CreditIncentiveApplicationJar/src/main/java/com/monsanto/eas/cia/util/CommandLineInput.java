package com.monsanto.eas.cia.util;

import org.apache.commons.cli.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 03:27:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommandLineInput {
    protected String            inputName;
    protected Options           options;
    protected CommandLineParser parser;
    protected CommandLine       commandLine;

    public CommandLineInput(String inputName){
        this.inputName  =   inputName;
        clearOptions();
        parser          =   new GnuParser();
    }

    public void addOption(Option option){
        if(option==null)return;
        options.addOption(option);
    }

    public void clearOptions(){
        options=new Options();
    }

    public boolean parseInput(String...arguments){
        try {
            commandLine = parser.parse( options, arguments);
            return true;
        }
        catch( ParseException exp ) {            
            System.err.println(exp.getMessage());
            printHelp();
        }
        return false;
    }

    public String getOptionValue(String name,String defaultValue){
        if(commandLine==null)throw new IllegalStateException();
        return commandLine.getOptionValue(name,defaultValue);
    }

    public void printHelp(){
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp( inputName, options );
    }
}
