/*
 Copyright:  Copyright  2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.util;

/**
 * Filename:    $RCSfile: CompanyCodeConverterUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-12 20:46:13 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class CompanyCodeConverterUtil {

  public static String convert5114CompanyCodeTo5180(String companyCode) {
    if(companyCode == null){
      throw new IllegalArgumentException("CompanyCodeConverterUtil: Null company code.");
    }
//    if(companyCode.equalsIgnoreCase(CIAConstants.COMPANY_CODE_5114)){
//      companyCode = CIAConstants.COMPANY_CODE_5180;
//    }
    return companyCode;
  }
}
