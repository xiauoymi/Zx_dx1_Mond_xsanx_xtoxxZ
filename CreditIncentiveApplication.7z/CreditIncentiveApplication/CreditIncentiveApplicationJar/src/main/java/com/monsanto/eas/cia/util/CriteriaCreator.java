package com.monsanto.eas.cia.util;

import org.hibernate.Criteria;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 1/02/2011
 * Time: 06:33:09 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CriteriaCreator {
    /**
     * @param session The current hibernate session
     * @return A criteria to create a list from it
     */
    public Criteria createCriteria(Session session);
}
