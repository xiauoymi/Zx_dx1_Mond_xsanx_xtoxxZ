package com.monsanto.eas.cia.util;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 06:33:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CriteriaUtils {
    public static void addSyncVersionRestriction(Criteria criteria){        
        criteria.add(Restrictions.neProperty("currentVersion","syncVersion"));
    }
    
    public static void addSyncVersionRestriction(DetachedCriteria criteria,String alias){        
        criteria.add(Restrictions.neProperty(alias+".currentVersion",alias+".syncVersion"));
    }    
}
