/*
 Copyright:  Copyright  2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.util;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;

/**
 * Filename:    $RCSfile: DAOUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class DAOUtil {

  //todo...add a UT for DAOUtil.

  private PersistentStoreConnection connection;
  private PersistentStoreStatement preparedStatement;
  private PersistentStoreResultSet resultSet;

  public DAOUtil(PersistentStoreConnection connection) {
    this.connection = connection;
  }

  public boolean checkRecordExists(String sqlQueryStatement, String[] codeValues, String countColumnName) throws WrappingException, EmptyResultSetException {
    preparedStatement = connection.prepareStatement(sqlQueryStatement);
    int numberOfCodeValues = codeValues.length;
    for (int i = 0; i < numberOfCodeValues; i++) {
      String codeValue = codeValues[i];
      preparedStatement.setParam(i+1, codeValue);
    }
    resultSet = preparedStatement.executeQuery();
    PersistentStoreResultSetSingleResult singleResultSet = resultSet.getSingleResult();
    return singleResultSet.getString(countColumnName).equalsIgnoreCase("1");
  }

  public void closeResources() {
    closeResources(preparedStatement, resultSet);
  }

  public static void closeResources(PersistentStoreStatement preparedStatement, PersistentStoreResultSet resultSet) {
    try {
      if (preparedStatement != null) {
        preparedStatement.close();
      }
      if (resultSet != null) {
        resultSet.close();
      }
    } catch (WrappingException e) {
      Logger.log(new LoggableError("Logging the error occured while closing resources like prepared statement and result set..."));
      Logger.log(new LoggableError(e));
    }
  }
}
