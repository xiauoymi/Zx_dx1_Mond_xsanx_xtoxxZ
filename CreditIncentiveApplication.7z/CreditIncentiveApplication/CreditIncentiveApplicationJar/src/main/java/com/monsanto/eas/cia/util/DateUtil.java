/*
 Copyright:  Copyright  2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 * Filename:    $RCSfile: DateUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:34 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class DateUtil {

  public static final String PATTERN_dd_MM_yyyy_DOT_SEPARATOR = "dd.MM.yyyy";
  public static final String PATTERN_yyyy_MM_dd_SLASH_SEPARATOR = "yyyy/MM/dd";

  public static String getCurrentDate(String datePattern) {
    return getDate(datePattern, new GregorianCalendar().getTime());
  }

  public static String getDate(String datePattern, Date date) {
    return new SimpleDateFormat(datePattern).format(date);
  }

  public static String getDateString(Date date) {
    if (date != null) {
      return DateUtil.getDate("MM/dd/yyyy", date);
    }
    return null;
  }

  public static Date getDate(String stringDate, String datePattern) {

        SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
        Date date = null;

        if(stringDate!=null && !stringDate.equals("") && datePattern!=null && !datePattern.equals("")) {
            try {
                date = sdf.parse(stringDate);
            } catch (ParseException ex) {
                ex.printStackTrace();
            }
        }

      return date;
  }

  /**
   * Returns date of 2 days from current date. Required for Invoice Batch Process ATs
   * @param datePattern
   * @return
   */
  public static String getFutureDate(String datePattern) {
    int numberOfDays = 2;
    long dateLongValue = System.currentTimeMillis() + new Long(numberOfDays*24*60*60*1000).longValue();
    Date futureDate = new Date(dateLongValue);
    return getDate(datePattern, futureDate);
  }

  public static double getTimeDifferenceBetweenCSTAndGMT() {
    GregorianCalendar gmtTime = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    int i = gmtTime.get(Calendar.HOUR_OF_DAY);
    long inMillis = gmtTime.getTimeInMillis();
    GregorianCalendar cstTime = new GregorianCalendar(TimeZone.getTimeZone("CST"));
    int i1 = cstTime.get(Calendar.HOUR_OF_DAY);
    long inMillis1 = cstTime.getTimeInMillis();

    long l = inMillis1 - inMillis;
    return l /(60 * 60 * 1000);

  }
}
