package com.monsanto.eas.cia.util;

import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.entity.BaseEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 1/02/2011
 * Time: 08:03:44 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DefaultCriteriaCreator<T extends BaseEntity> implements CriteriaCreator {    
    public Criteria createCriteria(Session session) {
        Class<?> baseEntityClass=ObjectUtils.getGenericType(this.getClass(), BaseEntity.class);
        Criteria criteria=session.createCriteria(baseEntityClass);
        modifyCriteria(criteria);
        return criteria;
    }
    public abstract void modifyCriteria(Criteria criteria);
}
