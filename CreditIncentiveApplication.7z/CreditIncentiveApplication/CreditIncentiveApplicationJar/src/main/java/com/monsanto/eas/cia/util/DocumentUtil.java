/*
Copyright:  Copyright  2006 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.util;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.cia.propertyreader.InvalidPropertyRequestException;
//import com.monsanto.eas.cia.propertyreader.PropertyFileReader;
//import com.monsanto.eas.cia.propertyreader.PropertyFileReaderImpl;
//import com.monsanto.eas.cia.propertyreader.model.PropertyList;
import com.monsanto.eas.cia.documentservice.exception.DocumentException;
import com.monsanto.eas.cia.constant.CIAConstants;
import com.monsanto.eas.cia.exception.ServiceException;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

/**
* Filename:    $RCSfile: DocumentUtil.java,v $
* Label:       $Name: not supported by cvs2svn $
* Last Change: $Author: bghale $    	 On:	$Date: 2009-06-10 16:17:36 $
*
* @author rdesai2
* @version $Revision: 1.8 $
*/
public class DocumentUtil {

  public static String extractNameFromFilePath(String absoluteFilePath) {
    if(StringUtils.isNullOrEmpty(absoluteFilePath)){
      throw new IllegalArgumentException("Invalid file path: '" + absoluteFilePath + "'");
    }
    int lastIndex = absoluteFilePath.lastIndexOf("\\");
    if (lastIndex == -1) {
      lastIndex = absoluteFilePath.lastIndexOf("/");
    }
    if (lastIndex != -1) {
      return absoluteFilePath.substring(lastIndex + 1);
    }
    throw new IllegalArgumentException("Invalid file path: '" + absoluteFilePath + "'");
  }

}
