package com.monsanto.eas.cia.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 21/02/2011
 * Time: 02:54:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExecutionContext implements Cloneable{
    public static final ThreadLocal<ExecutionContext> currentExecutionContext=new ThreadLocal<ExecutionContext>();

    public static ExecutionContext getCurrentExecutionContext(){
        ExecutionContext executionContext=currentExecutionContext.get();
        if(executionContext==null){
            setCurrentExecutionContext(executionContext=new ExecutionContext());
        }
        return executionContext;
    }

    public static void setCurrentExecutionContext(ExecutionContext executionContext){
        currentExecutionContext.set(executionContext);
    }         

    protected Map<String,Object> variables=new HashMap<String,Object>();

    public Object getVariable(String key){
        return variables.get(key);
    }

    public <T> T getVariable(String key, T defaultValue){
        Object value=variables.get(key);
        if(value==null)return defaultValue;
        return (T)value;        
    }

    public void setVariable(String key,Object value){
        variables.put(key,value);
    }    

    public void clear(){
        variables.clear();
    }

    public void copyVariables(Map<String,Object> otherVariables){
        if(otherVariables!=null)
            this.variables.putAll(otherVariables);
    }

    public Map<String,Object>getVariables(){
        return variables;
    }

    public ExecutionContext clone(){
        ExecutionContext executionContext=getCurrentExecutionContext();
        if(this==executionContext){
            return this;
        }
        executionContext.copyVariables(getVariables());
        return executionContext;
    }
}
