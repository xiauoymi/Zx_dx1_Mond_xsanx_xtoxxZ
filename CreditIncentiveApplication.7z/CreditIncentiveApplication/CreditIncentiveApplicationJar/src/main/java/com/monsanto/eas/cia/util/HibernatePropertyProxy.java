/*
 Copyright:  Copyright  2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.cia.util;

import flex.messaging.io.BeanProxy;
import flex.messaging.io.PropertyProxyRegistry;
import org.hibernate.proxy.HibernateProxy;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class HibernatePropertyProxy extends BeanProxy {

	private static final long serialVersionUID = 1612371743382649972L;

	/**
	 * Registers this class with BlazeDS to handle HibernateProxy instances
	 */
	public HibernatePropertyProxy() {
		super();
		PropertyProxyRegistry.getRegistry().register(HibernateProxy.class, this);
	}

	/**
	 * Get actual name instead of cglib class name with $$enhancerByCglib in it.
	 */
	protected String getClassName(Object o) {
		if (o instanceof HibernateProxy) {
			HibernateProxy object = (HibernateProxy) o;
			return object.getHibernateLazyInitializer().getEntityName();
		}
		else {
			return super.getClassName(o);
		}
	}
}