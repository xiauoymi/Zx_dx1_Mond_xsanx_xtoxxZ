package com.monsanto.eas.cia.util;

import java.util.HashMap;
import java.util.Map;

public class MapBuilder<K,V>{
	protected Map<K,V> map;

	public MapBuilder() {	
		setMap(new HashMap<K,V>());
	}
	
	public MapBuilder(Map<K, V> map) {	
		setMap(map);
	}

	public Map<K, V> map() {
		return map;
	}

	protected void setMap(Map<K, V> map) {
		this.map = map;
	}		
	
	public MapBuilder<K,V> put(K key, V value){
		this.map.put(key, value);
		return this;
	}	
}
