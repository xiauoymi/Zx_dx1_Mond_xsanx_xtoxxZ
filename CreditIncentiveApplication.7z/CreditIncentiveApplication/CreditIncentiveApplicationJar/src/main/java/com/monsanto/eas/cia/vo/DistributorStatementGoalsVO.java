package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/12/12
 * Time: 10:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class DistributorStatementGoalsVO {


    private String subRegion;

    private String agreementNumber;

    private String fiscalName;

    private String name;

    private String rfc;

    private String municipality;

    private String state;

    private BigDecimal incentivePctFirstQuarter;

    private BigDecimal incentivePctSecondQuarter;

    private BigDecimal incentivePctThirdQuarter;

    private BigDecimal incentivePctFourthQuarter;

    private BigDecimal incentiveVolumeFirstQuarter;

    private BigDecimal incentiveVolumeSecondQuarter;

    private BigDecimal incentiveVolumeThirdQuarter;

    private BigDecimal incentiveVolumeFourthQuarter;

    private BigDecimal pctAnnualGoal;

    private BigDecimal pctFirstQuarterGoal;

    private BigDecimal pctSecondQuarterGoal;

    private BigDecimal pctThirdQuarterGoal;

    private BigDecimal pctFourthQuarterGoal;


    public String getSubRegion() {
        return subRegion;
    }

    public void setSubRegion(String subRegion) {
        this.subRegion = subRegion;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public String getMunicipality() {
        return municipality;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getFiscalName() {
        return fiscalName;
    }

    public void setFiscalName(String fiscalName) {
        this.fiscalName = fiscalName;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }


    public BigDecimal getIncentivePctFirstQuarter() {
        return incentivePctFirstQuarter;
    }

    public void setIncentivePctFirstQuarter(BigDecimal incentivePctFirstQuarter) {
        this.incentivePctFirstQuarter = incentivePctFirstQuarter;
    }

    public BigDecimal getIncentivePctSecondQuarter() {
        return incentivePctSecondQuarter;
    }

    public void setIncentivePctSecondQuarter(BigDecimal incentivePctSecondQuarter) {
        this.incentivePctSecondQuarter = incentivePctSecondQuarter;
    }

    public BigDecimal getIncentivePctThirdQuarter() {
        return incentivePctThirdQuarter;
    }

    public void setIncentivePctThirdQuarter(BigDecimal incentivePctThirdQuarter) {
        this.incentivePctThirdQuarter = incentivePctThirdQuarter;
    }

    public BigDecimal getIncentivePctFourthQuarter() {
        return incentivePctFourthQuarter;
    }

    public void setIncentivePctFourthQuarter(BigDecimal incentivePctFourthQuarter) {
        this.incentivePctFourthQuarter = incentivePctFourthQuarter;
    }

    public BigDecimal getIncentiveVolumeFirstQuarter() {
        return incentiveVolumeFirstQuarter;
    }

    public void setIncentiveVolumeFirstQuarter(BigDecimal incentiveVolumeFirstQuarter) {
        this.incentiveVolumeFirstQuarter = incentiveVolumeFirstQuarter;
    }

    public BigDecimal getIncentiveVolumeSecondQuarter() {
        return incentiveVolumeSecondQuarter;
    }

    public void setIncentiveVolumeSecondQuarter(BigDecimal incentiveVolumeSecondQuarter) {
        this.incentiveVolumeSecondQuarter = incentiveVolumeSecondQuarter;
    }

    public BigDecimal getIncentiveVolumeThirdQuarter() {
        return incentiveVolumeThirdQuarter;
    }

    public void setIncentiveVolumeThirdQuarter(BigDecimal incentiveVolumeThirdQuarter) {
        this.incentiveVolumeThirdQuarter = incentiveVolumeThirdQuarter;
    }

    public BigDecimal getIncentiveVolumeFourthQuarter() {
        return incentiveVolumeFourthQuarter;
    }

    public void setIncentiveVolumeFourthQuarter(BigDecimal incentiveVolumeFourthQuarter) {
        this.incentiveVolumeFourthQuarter = incentiveVolumeFourthQuarter;
    }

    public BigDecimal getPctAnnualGoal() {
        return pctAnnualGoal;
    }

    public void setPctAnnualGoal(BigDecimal pctAnnualGoal) {
        this.pctAnnualGoal = pctAnnualGoal;
    }

    public BigDecimal getPctFirstQuarterGoal() {
        return pctFirstQuarterGoal;
    }

    public void setPctFirstQuarterGoal(BigDecimal pctFirstQuarterGoal) {
        this.pctFirstQuarterGoal = pctFirstQuarterGoal;
    }

    public BigDecimal getPctSecondQuarterGoal() {
        return pctSecondQuarterGoal;
    }

    public void setPctSecondQuarterGoal(BigDecimal pctSecondQuarterGoal) {
        this.pctSecondQuarterGoal = pctSecondQuarterGoal;
    }

    public BigDecimal getPctThirdQuarterGoal() {
        return pctThirdQuarterGoal;
    }

    public void setPctThirdQuarterGoal(BigDecimal pctThirdQuarterGoal) {
        this.pctThirdQuarterGoal = pctThirdQuarterGoal;
    }

    public BigDecimal getPctFourthQuarterGoal() {
        return pctFourthQuarterGoal;
    }

    public void setPctFourthQuarterGoal(BigDecimal pctFourthQuarterGoal) {
        this.pctFourthQuarterGoal = pctFourthQuarterGoal;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
