package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/12/12
 * Time: 10:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class DistributorStatementPerDealerAndProductVO {

    private Long distributorId;

    private String agreementNumber;

    private String dealer;

    private String headerVol;

    private String headerInc;

    private String headerPrices;

    private String family;

    private String presentation;

    private BigDecimal volume;

    private BigDecimal totalToIncentive;

    private BigDecimal price;


    public DistributorStatementPerDealerAndProductVO() {
    }

    public DistributorStatementPerDealerAndProductVO(Long distributorId, String agreementNumber, String dealer, String family, String presentation, BigDecimal volume, BigDecimal totalToIncentive, BigDecimal price) {
        this.distributorId = distributorId;
        this.agreementNumber = agreementNumber;
        this.dealer = dealer;
        this.headerVol = "VOLUMEN REGISTRADO";
        this.headerInc = "DESGLOSE DE INCENTIVO";
        this.headerPrices = "LISTA DE PRECIOS";
        this.family = family;
        this.presentation = presentation;
        this.volume = volume;
        this.totalToIncentive = totalToIncentive;
        this.price = price;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getDealer() {
        return dealer;
    }

    public void setDealer(String dealer) {
        this.dealer = dealer;
    }

    public String getHeaderVol() {
        return headerVol;
    }

    public void setHeaderVol(String headerVol) {
        this.headerVol = headerVol;
    }

    public String getHeaderInc() {
        return headerInc;
    }

    public void setHeaderInc(String headerInc) {
        this.headerInc = headerInc;
    }

    public String getHeaderPrices() {
        return headerPrices;
    }

    public void setHeaderPrices(String headerPrices) {
        this.headerPrices = headerPrices;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public void setVolume(BigDecimal volume) {
        this.volume = volume;
    }

    public BigDecimal getTotalToIncentive() {
        return totalToIncentive;
    }

    public void setTotalToIncentive(BigDecimal totalToIncentive) {
        this.totalToIncentive = totalToIncentive;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
