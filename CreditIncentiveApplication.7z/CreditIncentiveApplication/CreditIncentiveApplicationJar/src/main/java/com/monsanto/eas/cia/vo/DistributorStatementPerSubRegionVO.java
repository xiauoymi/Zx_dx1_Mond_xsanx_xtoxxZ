package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/12/12
 * Time: 10:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class DistributorStatementPerSubRegionVO {

    private String subRegion;

    private BigDecimal amount;

    public DistributorStatementPerSubRegionVO() {
    }

    public DistributorStatementPerSubRegionVO(String subRegion, BigDecimal amount) {
        this.subRegion = subRegion;
        this.amount = amount;
    }

    public String getSubRegion() {
        return subRegion;
    }

    public void setSubRegion(String subRegion) {
        this.subRegion = subRegion;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
