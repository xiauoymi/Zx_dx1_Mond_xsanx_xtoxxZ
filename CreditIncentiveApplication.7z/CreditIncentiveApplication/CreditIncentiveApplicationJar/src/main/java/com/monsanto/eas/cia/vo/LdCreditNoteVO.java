package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/11/12
 * Time: 09:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class LdCreditNoteVO {

    private String quarterLabel;

    private String distributor;

    private BigDecimal totalIncentives;

    public String getQuarterLabel() {
        return quarterLabel;
    }

    public void setQuarterLabel(String quarterLabel) {
        this.quarterLabel = quarterLabel;
    }

    public String getDistributor() {
        return distributor;
    }

    public void setDistributor(String distributor) {
        this.distributor = distributor;
    }

    public BigDecimal getTotalIncentives() {
        return totalIncentives;
    }

    public void setTotalIncentives(BigDecimal totalIncentives) {
        this.totalIncentives = totalIncentives;
    }
}
