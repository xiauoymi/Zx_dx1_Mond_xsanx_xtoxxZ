package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: ACISS
 * Date: 5/11/12
 * Time: 09:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class LdGoalToVolumeRecordVO {

    private String quarterLabel;

    private BigDecimal maxIncentive;

    private BigDecimal minIncentive;

    private BigDecimal volumePerQuarter;

    private BigDecimal incentivePercentage;

    private BigDecimal totalToIncentive;

    public String getQuarterLabel() {
        return quarterLabel;
    }

    public void setQuarterLabel(String quarterLabel) {
        this.quarterLabel = quarterLabel;
    }

    public BigDecimal getMaxIncentive() {
        return maxIncentive;
    }

    public void setMaxIncentive(BigDecimal maxIncentive) {
        this.maxIncentive = maxIncentive;
    }

    public BigDecimal getMinIncentive() {
        return minIncentive;
    }

    public void setMinIncentive(BigDecimal minIncentive) {
        this.minIncentive = minIncentive;
    }

    public BigDecimal getVolumePerQuarter() {
        return volumePerQuarter;
    }

    public void setVolumePerQuarter(BigDecimal volumePerQuarter) {
        this.volumePerQuarter = volumePerQuarter;
    }

    public BigDecimal getIncentivePercentage() {
        return incentivePercentage;
    }

    public void setIncentivePercentage(BigDecimal incentivePercentage) {
        this.incentivePercentage = incentivePercentage;
    }

    public BigDecimal getTotalToIncentive() {
        return totalToIncentive;
    }

    public void setTotalToIncentive(BigDecimal totalToIncentive) {
        this.totalToIncentive = totalToIncentive;
    }
}
