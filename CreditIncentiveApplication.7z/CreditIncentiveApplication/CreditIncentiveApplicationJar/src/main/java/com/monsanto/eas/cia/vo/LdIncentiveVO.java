package com.monsanto.eas.cia.vo;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 26/10/12
 * Time: 10:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class LdIncentiveVO {
    private Integer quarter;
    private BigDecimal minGoal;
    private BigDecimal maxGoal;

    public LdIncentiveVO(Integer quarter) {
        this.quarter = quarter;
        this.minGoal = BigDecimal.ZERO;
        this.maxGoal = BigDecimal.ZERO;
    }

    public Integer getQuarter() {
        return quarter;
    }

    public void setQuarter(Integer quarter) {
        this.quarter = quarter;
    }

    public BigDecimal getMinGoal() {
        return minGoal;
    }

    public void setMinGoal(BigDecimal minGoal) {
        this.minGoal = minGoal;
    }

    public BigDecimal getMaxGoal() {
        return maxGoal;
    }

    public void setMaxGoal(BigDecimal maxGoal) {
        this.maxGoal = maxGoal;
    }
}
