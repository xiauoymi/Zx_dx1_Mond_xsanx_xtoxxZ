package com.monsanto.eas.cia.vo;

import java.util.ArrayList;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 26/10/12
 * Time: 04:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocalDealerStatementRecordVO {
    private String agreement;
	private String dealerName;
	private String territory;
	private String companyName;

    private List<LdIncentiveVO> incentives;

	public LocalDealerStatementRecordVO() {
	    incentives = new ArrayList<LdIncentiveVO>();
        incentives.add(new LdIncentiveVO(1));
        incentives.add(new LdIncentiveVO(2));
        incentives.add(new LdIncentiveVO(3));
        incentives.add(new LdIncentiveVO(4));
	}

    public String getAgreement() {
        return agreement;
    }

    public void setAgreement(String agreement) {
        this.agreement = agreement;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public String getTerritory() {
        return territory;
    }

    public void setTerritory(String territory) {
        this.territory = territory;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public List<LdIncentiveVO> getIncentives() {
        return incentives;
    }

    public BigDecimal getTotal(boolean isExpected) {
        BigDecimal total = BigDecimal.ZERO;
        for(LdIncentiveVO incentiveVO:incentives) {
            total = total.add(isExpected ? incentiveVO.getMaxGoal() : incentiveVO.getMinGoal());
        }
        return total;
    }
}
