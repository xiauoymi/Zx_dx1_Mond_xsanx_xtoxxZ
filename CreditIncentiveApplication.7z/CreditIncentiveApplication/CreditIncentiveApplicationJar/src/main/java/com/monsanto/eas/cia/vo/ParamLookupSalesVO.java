package com.monsanto.eas.cia.vo;

/**
 * Created with IntelliJ IDEA.
 * User: LETORR1
 * Date: 27/02/13
 * Time: 11:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class ParamLookupSalesVO {

    private String date;
    private Integer subRegionId;
    private Integer distributorId;
    private Integer dealerId;

    public String getDate() {
        return date;
    }

    public void setDate(final String date) {
        this.date = date;
    }

    public Integer getSubRegionId() {
        return subRegionId;
    }

    public void setSubRegionId(final Integer subRegionId) {
        this.subRegionId = subRegionId;
    }

    public Integer getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(final Integer distributorId) {
        this.distributorId = distributorId;
    }

    public Integer getDealerId() {
        return dealerId;
    }

    public void setDealerId(final Integer dealerId) {
        this.dealerId = dealerId;
    }
}
