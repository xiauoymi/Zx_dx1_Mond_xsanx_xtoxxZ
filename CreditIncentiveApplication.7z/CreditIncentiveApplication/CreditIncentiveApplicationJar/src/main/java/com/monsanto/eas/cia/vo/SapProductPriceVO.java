package com.monsanto.eas.cia.vo;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JNOLA1
 * Date: 08/02/12
 * Time: 10:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class SapProductPriceVO {

    private Integer sapProductId;
    private String sapProductCode;
    private String startDate;
    private String endDate;
    private Double price;
    private Boolean newRecord;
    private String description;

    public SapProductPriceVO() {

    }

    public String getSapProductCode() {
        return sapProductCode;
    }

    public void setSapProductCode(String sapProductCode) {
        this.sapProductCode = sapProductCode;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getSapProductId() {
        return sapProductId;
    }

    public void setSapProductId(Integer sapProductId) {
        this.sapProductId = sapProductId;
    }

    public Boolean getNewRecord() {
        return newRecord;
    }

    public void setNewRecord(Boolean newRecord) {
        this.newRecord = newRecord;
    }

    public boolean isValid() {
        if(this.sapProductCode!=null && this.startDate!=null && this.endDate!=null && this.price!=null) {
            return true;
        }else{
            return false;
        }
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}