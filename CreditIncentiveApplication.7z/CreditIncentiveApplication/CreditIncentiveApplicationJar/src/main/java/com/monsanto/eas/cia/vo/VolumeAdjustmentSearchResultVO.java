package com.monsanto.eas.cia.vo;

import com.monsanto.eas.cia.model.LdSalesCn;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: JEESCO
 * Date: 22/12/2011
 * Time: 12:17:12 PM
 */
public class VolumeAdjustmentSearchResultVO {
    private Integer id;
    private Date salesDate;
    private String transactionNumber;
    private String agreementNumber;
    private String dealerName;
    private String companyName;
    private String productCode;
    private String productDesc;
    private String transactionTypeDesc;
    private Double salesVolume;
    private String assignedFrom;
    private Double volumeAssigned;
    private Double volumeToIncentive;
    private boolean validForIncentivePlanning;
    private boolean sentToSap;
    private String rfc;
    private String customerSapCode;
    private String customerSapDescription;
    private Double price;
    private Double volumeLts;
    private boolean editable;
    //private Double ltConvFactor;

    public VolumeAdjustmentSearchResultVO() {
    }

    public VolumeAdjustmentSearchResultVO(Integer id, Date salesDate, String transactionNumber, String agreementNumber, String dealerName, String companyName, String productCode, String productDesc, String transactionTypeDesc, Double salesVolume, Double volumeAssigned, Double volumeToIncentive, boolean validForIncentivePlanning, String rfc, String customerSapCode, String customerSapDescription, Double price/*, Double ltConversionFactor*/) {
        this.id = id;
        this.salesDate = salesDate;
        this.transactionNumber = transactionNumber;
        this.agreementNumber = agreementNumber;
        this.dealerName = dealerName;
        this.companyName = companyName;
        this.productCode = productCode;
        this.productDesc = productDesc;
        this.transactionTypeDesc = transactionTypeDesc;
        this.salesVolume = toLiters(salesVolume/*, ltConversionFactor*/);
        this.volumeAssigned = toLiters(volumeAssigned/*, ltConversionFactor*/);
        this.volumeToIncentive = toLiters(volumeToIncentive/*, ltConversionFactor*/);
        this.validForIncentivePlanning = validForIncentivePlanning;
        this.rfc = rfc;
        this.customerSapCode = customerSapCode;
        this.customerSapDescription = customerSapDescription;
        this.price = price;
        //this.ltConvFactor = ltConversionFactor;
    }

    private Double toLiters(Double volume/*, Double convFactor*/) {
        if(volume != null /*& convFactor != null*/){
            return volume /* convFactor*/;
        }
        return 0d;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getSalesDate() {
        return salesDate;
    }

    public void setSalesDate(Date salesDate) {
        this.salesDate = salesDate;
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getTransactionTypeDesc() {
        return transactionTypeDesc;
    }

    public void setTransactionTypeDesc(String transactionTypeDesc) {
        this.transactionTypeDesc = transactionTypeDesc;
    }

    public Double getSalesVolume() {
        return salesVolume;
    }

    public void setSalesVolume(Double salesVolume) {
        this.salesVolume = salesVolume;
    }

    public String getAssignedFrom() {
        return assignedFrom;
    }

    public void setAssignedFrom(String assignedFrom) {
        this.assignedFrom = assignedFrom;
    }

    public Double getVolumeAssigned() {
        return volumeAssigned;
    }

    public void setVolumeAssigned(Double volumeAssigned) {
        this.volumeAssigned = volumeAssigned;
    }

    public Double getVolumeToIncentive() {
        return volumeToIncentive;
    }

    public void setVolumeToIncentive(Double volumeToIncentive) {
        this.volumeToIncentive = volumeToIncentive;
    }

    public boolean isValidForIncentivePlanning() {
        return validForIncentivePlanning;
    }

    public void setValidForIncentivePlanning(boolean validForIncentivePlanning) {
        this.validForIncentivePlanning = validForIncentivePlanning;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getCustomerSapCode() {
        return customerSapCode;
    }

    public void setCustomerSapCode(String customerSapCode) {
        this.customerSapCode = customerSapCode;
    }

    public String getCustomerSapDescription() {
        return customerSapDescription;
    }

    public void setCustomerSapDescription(String customerSapDescription) {
        this.customerSapDescription = customerSapDescription;
    }

    public boolean isSentToSap() {
        return sentToSap;
    }

    public void setSentToSap(boolean sentToSap) {
        this.sentToSap = sentToSap;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getVolumeLts() {
        return volumeLts;
    }

    public void setVolumeLts(Double volumeLts) {
        this.volumeLts = volumeLts;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    /*
    public Double getLtConvFactor() {
        return ltConvFactor;
    }

    public void setLtConvFactor(Double ltConvFactor) {
        this.ltConvFactor = ltConvFactor;
    }
    */
}
