package controller;

import com.monsanto.eas.cia.controller.ExceptionController;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:36:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class ExceptionController_UT extends TestCase {
  @Test
  public void testHandleRequestInternal_GoesToHome() throws Exception {
    ExceptionController controller = new ExceptionController();
    ModelAndView modelAndView = controller.handleRequestInternal(null, null);
    assertEquals("error", modelAndView.getViewName());
  }
}
