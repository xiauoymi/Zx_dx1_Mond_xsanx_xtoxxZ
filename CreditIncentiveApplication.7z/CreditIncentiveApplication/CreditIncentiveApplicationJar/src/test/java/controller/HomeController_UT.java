package controller;

import com.monsanto.eas.cia.controller.HomeController;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:25:44 PM To change this template use File |
 * Settings | File Templates.
 */
public class HomeController_UT extends TestCase {
  @Test
  public void testHandleRequestInternal_GoesToHome() throws Exception {
    HomeController controller = new HomeController();
    ModelAndView modelAndView = controller.handleRequestInternal(null, null);
    assertEquals("home", modelAndView.getViewName());
  }
}