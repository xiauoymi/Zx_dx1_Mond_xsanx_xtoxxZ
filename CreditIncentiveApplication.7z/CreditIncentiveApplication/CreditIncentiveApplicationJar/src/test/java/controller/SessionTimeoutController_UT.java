package controller;

import com.monsanto.ServletFramework.Test.MockHttpServletRequest;
import com.monsanto.eas.cia.CiaConstants;
import com.monsanto.eas.cia.controller.SessionTimeoutController;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 18, 2010 Time: 3:30:24 PM To change this template use File |
 * Settings | File Templates.
 */
public class SessionTimeoutController_UT extends TestCase {
  @Test
  public void testHandleRequestInternal_GoesToSessiontimeout() throws Exception {
    SessionTimeoutController controller = new SessionTimeoutController();
    MockHttpSession httpSession = new MockHttpSession();
    httpSession.setAttribute(CiaConstants.WAM_CIA_USER, "User");
    httpSession.setAttribute(CiaConstants.WAM_USER_ID, "UserId");
    HttpServletRequest request = new MockHttpServletRequest(httpSession);
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("sessiontimeout", modelAndView.getViewName());
  }

  @Test
  public void testClean_ValidSession_CookiesRemoved() throws Exception {
    SessionTimeoutController controller = new SessionTimeoutController();
    MockHttpSession httpSession = new MockHttpSession();
    httpSession.setAttribute(CiaConstants.WAM_CIA_USER, "User");
    httpSession.setAttribute(CiaConstants.WAM_USER_ID, "UserId");
    HttpServletRequest request = new MockHttpServletRequest(httpSession);
    controller.cleanUp(request, null);
    assertNull(httpSession.getAttribute(CiaConstants.WAM_CIA_USER));
    assertNull(httpSession.getAttribute(CiaConstants.WAM_USER_ID));
  }
}
