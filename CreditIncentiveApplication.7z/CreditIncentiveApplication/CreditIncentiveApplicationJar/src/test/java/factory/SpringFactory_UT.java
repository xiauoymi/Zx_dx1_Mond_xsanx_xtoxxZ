package factory;

import com.monsanto.eas.cia.factory.SpringFactory;
import flex.messaging.FactoryInstance;
import flex.messaging.config.ConfigMap;
import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Oct 19, 2010 Time: 2:36:16 PM To change this template use File |
 * Settings | File Templates.
 */
public class SpringFactory_UT extends TestCase {

  @Test
  public void testCreateFactoryInstance() throws Exception {
    SpringFactory factory = new SpringFactory();
    ConfigMap map = new ConfigMap();
    map.addProperty("test", "testValue");
    FactoryInstance instance = factory.createFactoryInstance("testId", map);
    assertNotNull(instance);
    assertEquals("testId", instance.getId());
    assertEquals("testValue", instance.getProperties().getProperty("test"));
    assertEquals("testId", instance.getSource());
    assertEquals("request", instance.getScope());
  }

}
