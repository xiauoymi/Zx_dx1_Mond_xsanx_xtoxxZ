package integration.csv;

import com.monsanto.eas.cia.integration.format.csv.CsvReader;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 13/01/2011
 * Time: 11:06:16 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractCsv_UT {
    private static final Log log                                =   LogFactory.getLog(AbstractCsv_UT.class);


    protected   ByteArrayOutputStream   outputStream            =   null;

    protected   PrintWriter             writer                  =   null;

    protected   CsvWriterConfiguration csvWriterConfiguration   =   null;

    public void setup() throws IOException{
        csvWriterConfiguration=new CsvWriterConfiguration();
        writer=new PrintWriter(outputStream=new ByteArrayOutputStream(),true);
    }   

    public CsvReader getMemoryBasedCSVReader(CsvWriterConfiguration _writerConfiguration){
        CsvReader csvReader = new CsvReader(
            getMemoryBasedBufferedReader(),
            _writerConfiguration.getFieldSeparator(),
            _writerConfiguration.getQuoteCharacter(),
            _writerConfiguration.getEscapeCharacter()
        );
        return csvReader;
    }

    public BufferedReader getMemoryBasedBufferedReader(){
        BufferedReader  reader      =   new BufferedReader(
            new InputStreamReader(
                new ByteArrayInputStream(outputStream.toByteArray())
            )
        );
        return reader;
    }
}
