package integration.csv;

import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.exception.ParseRecordException;
import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import integration.layout.definition.SampleLayout;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 8/02/2011
 * Time: 11:32:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvLayout_UT extends AbstractCsv_UT{
    CsvReaderConfiguration csvReaderConfiguration;
    CsvWriterConfiguration csvWriterConfiguration;
    SampleLayout           sampleLayout;

    @Before
    public void setup() {
        csvWriterConfiguration  =   new CsvWriterConfiguration();
        csvReaderConfiguration  =   new CsvReaderConfiguration();
        sampleLayout    =   new SampleLayout();
        sampleLayout.       setBooleanValue(true);
        sampleLayout.       setDateValue(new Date());
        sampleLayout.       setDecimalValue(-3.1416);
        sampleLayout.       setIntegerValue(-7);
        sampleLayout.       setStringValue("string");          
    }

    @Test
    public void testFailureInSimpleTypeInCsvRecord(){
        CsvRecord record=assertCreateCsvRecord();
        try{
            record.toType(BigDecimal.class);
            fail();
        }
        catch(ParseRecordException cre){
            assertEquals(BigDecimal.class,cre.getConversionType());
            assertEquals(0,cre.getFieldPosition());
            assertNull(cre.getLayout());
            assertEquals(0,cre.getRecordNumber());
        }
    }

    @Test
    public void testFailureInLayoutTypeInCsvRecord(){
        CsvRecord record=assertCreateCsvRecord();
        record.getFieldParsers().remove(Integer.class);
        try{
            record.toLayout(SampleLayout.class);
            fail();
        }
        catch(ParseRecordException cre){
            assertEquals(Integer.class,cre.getConversionType());
            assertEquals(3,cre.getFieldPosition());            
            assertTrue(cre.getLayout() instanceof SampleLayout);
            assertEquals(0,cre.getRecordNumber());
        }
    }

    @Test
    public void testReadLayoutFromCsvRecord(){
        assertReadLayoutFromCsvRecord();
    }

    @Test
    public void testReadLayoutFromCsvRecordWithNullValues(){
        setNullValuesOnSampleLayout();
        assertReadLayoutFromCsvRecord();
    }

    @Test
    public void testCreateCsvRecord(){
        assertCreateCsvRecord();
    }

    @Test
    public void testReadValuesFromCsvRecord(){
        assertReadValuesFromCsvRecord();
    }

    @Test
    public void testReadNullValuesFromCsvRecord(){
        setNullValuesOnSampleLayout();
        assertReadValuesFromCsvRecord();
    }

    @Test
    public void testGetValueMap(){
         assertGetValueMap();
    }

    @Test
    public void testGetFieldsFromLayout(){
        assertGetCsvRecordFromLayout();
}

    @Test
    public void testWrittenLineFromLayout(){
        assertWrittenLineFromLayout();
    }

    @Test
    public void testGetFieldsFromLayoutWithNullValues(){
        setNullValuesOnSampleLayout();
        assertGetCsvRecordFromLayout();
    }

    @Test
    public void testGetValueMapWithNullValues(){
        setNullValuesOnSampleLayout();
        assertGetValueMap();
    }

    @Test
    public void testGetWrittenLineWithNullValues(){
        setNullValuesOnSampleLayout();
        assertWrittenLineFromLayout();
    }

    public CsvRecord assertCreateCsvRecord(){
        long recordPosition=0;
        Map<Class<?>, FieldParser<?,String>> fieldParsers=csvReaderConfiguration.getFieldParserAdapters();
        String[]fields=csvWriterConfiguration.fromLayout(
            sampleLayout
        );
        CsvRecord csvRecord= csvReaderConfiguration.createCsvRecord(recordPosition,fields);
        assertNotNull(csvRecord);
        assertNotNull(csvRecord.getFields());
        assertNotNull(csvRecord.getFieldParsers());
        assertEquals(0,csvRecord.getCurrentFieldPosition());
        assertEquals(recordPosition,csvRecord.getRecordNumber());
        assertTrue(fieldParsers==csvRecord.getFieldParsers());
        assertTrue(fields==csvRecord.getFields());
        return csvRecord;
    }

    public void assertReadValuesFromCsvRecord(){
        CsvRecord csvRecord=assertCreateCsvRecord();
        Class<?>[] _classes=new Class<?>[]{
            String.class,
            Date.class,
            Double.class,
            Integer.class,
            Boolean.class
        };
        Object[]values=new Object[]{
            sampleLayout.getStringValue(),
            sampleLayout.getDateValue(),
            sampleLayout.getDecimalValue(),
            sampleLayout.getIntegerValue(),
            sampleLayout.getBooleanValue()
        };

        for(int i=0;i<_classes.length;i++){
            assertEquals(csvWriterConfiguration.value(values[i]),csvWriterConfiguration.value(csvRecord.toType(i,_classes[i])));
        }

        csvRecord.resetCurrentFieldPosition();
        assertEquals(0,csvRecord.getCurrentFieldPosition());

        for(int i=0;i<_classes.length;i++){
            assertEquals(csvWriterConfiguration.value(values[i]),csvWriterConfiguration.value(csvRecord.toType(_classes[i])));
            assertEquals(i+1,csvRecord.getCurrentFieldPosition());    
        }

        assertEquals(_classes.length,csvRecord.getCurrentFieldPosition());
    }

    public void assertReadLayoutFromCsvRecord(){
        CsvRecord csvRecord=assertCreateCsvRecord();
        SampleLayout layout=csvRecord.toLayout(SampleLayout.class);
        Object[]values1=new Object[]{
            layout.getBooleanValue(),
            layout.getDateValue(),
            layout.getDecimalValue(),
            layout.getIntegerValue(),
            layout.getStringValue()
        };

        Object[]values2=new Object[]{
            sampleLayout.getBooleanValue(),
            sampleLayout.getDateValue(),
            sampleLayout.getDecimalValue(),
            sampleLayout.getIntegerValue(),
            sampleLayout.getStringValue()
        };

        for(int i=0;i<values1.length;i++){
            assertEquals(csvWriterConfiguration.value(values1[i]),csvWriterConfiguration.value(values2[i]));
        }
    }

    public void setNullValuesOnSampleLayout(){
        sampleLayout.setBooleanValue(null);
        sampleLayout.setDateValue(null);
        sampleLayout.setDecimalValue(null);
        sampleLayout.setIntegerValue(null);
        sampleLayout.setStringValue(null);
    }

    public void assertWrittenLineFromLayout(){
        String formatLine=csvWriterConfiguration.formatLayout(sampleLayout);
        String line= assertGetCsvRecordFromLayout();
        assertEquals(formatLine,line);
    }

    public String assertGetCsvRecordFromLayout(){
        String[] values=csvWriterConfiguration.fromLayout(sampleLayout);
        Object[] sampleValues={
            sampleLayout.getStringValue(),
            sampleLayout.getDateValue(),
            sampleLayout.getDecimalValue(),
            sampleLayout.getIntegerValue(),
            sampleLayout.getBooleanValue()
        };

        int i=0;
        StringBuilder builder=new StringBuilder();
        for(Object sampleValue:sampleValues){
            assertWrittenValue(sampleValue,values,i);
            if(i>0){
                builder.append(csvWriterConfiguration.getFieldSeparator());
            }
            builder.append(values[i++]);
        }

        return builder.append(csvWriterConfiguration.getLineEnd()).toString();
    }

    public void assertGetValueMap(){
        TreeMap<Integer,String> values=csvWriterConfiguration.getValueMap(sampleLayout);
        Object[] sampleValues={
            sampleLayout.getStringValue(),
            sampleLayout.getDateValue(),
            sampleLayout.getDecimalValue(),
            sampleLayout.getIntegerValue(),
            sampleLayout.getBooleanValue()
        };

        int i=0;
        for(Object sampleValue:sampleValues){
            assertWrittenValue(sampleValue,values,i++);
        }
    }

    public void assertWrittenValue(Object value,TreeMap<Integer,String> values, Integer position){
        assertEquals(csvWriterConfiguration.value(value),values.get(position));
    }

    public void assertWrittenValue(Object value,String[]values, Integer position){
        assertEquals(csvWriterConfiguration.value(value),values[position]);
    }
}
