package integration.csv;

import com.monsanto.eas.cia.integration.format.csv.CsvReader;
import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 18/01/2011
 * Time: 11:26:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvReaderConfiguration_UT extends AbstractCsv_UT {

    private CsvReaderConfiguration csvReaderConfiguration;

    private String[]                record;

    private Reader                  reader;

    private Integer                 integer;

    private Date                    date;

    private Double                  number;

    private String                  string;

    private String                  stringWithQuotes;

    private String                  stringWithSeparator;

    private String                  nullString;

    @Before
    @Override
    public void setup() throws IOException {
        super.setup();
        csvReaderConfiguration  =   new CsvReaderConfiguration();
        integer                 =   1234;
        number                  =   0d;
        date                    =   new Date();
        string                  =   "value";
        stringWithQuotes        =   "RecordNumberOne\"";
        stringWithSeparator     =   "Record|Number|Two";
        nullString              =   csvReaderConfiguration.getEmptyFieldValue();   
        record                  =   new String[]{
            String.valueOf(integer),
            "0.0000000000000000E+00",
            csvReaderConfiguration.getDateFormat().format(date),
            string,
            stringWithQuotes,
            stringWithSeparator,
            nullString
        };
        writeSampleRecord();
        reader=getMemoryBasedBufferedReader();
    }

    public void writeSampleRecord(){
        try{
            CsvWriter csvWriter=csvWriterConfiguration.createCsvWriter(writer);
            csvWriter.writeNext(record);
            csvWriter.flush();
            csvWriter.close();
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testReadRecords() throws Exception{        
        CsvReader csvReader=csvReaderConfiguration.createCsvReader(reader);
        String [] readRecord=csvReader.readNext();
        assertTrue("Records are not the same",Arrays.equals(readRecord,record));
    }

    @Test
    public void testIsInputNull(){
        assertTrue(csvReaderConfiguration.isInputNull(null));
        assertTrue(
            csvReaderConfiguration.isInputNull(
                csvReaderConfiguration.getEmptyFieldValue()
            )
        );
        assertFalse(
            csvReaderConfiguration.isInputNull("Yeah!!!")
        );
    }

    @Test
    public void testParseInteger() throws Exception{
        Integer temporal=csvReaderConfiguration.parseInteger(record[0]);
        assertEquals("The numbers are not equal",integer,temporal);
    }

    @Test
    public void testParseDouble() throws Exception{
        Number temporal=csvReaderConfiguration.parseDouble(record[1]);
        assertEquals("The numbers are not equal",number.doubleValue(),temporal.doubleValue(),0.001);
    }

    @Test
    public void testParseDate() throws Exception{
        Date temporal=csvReaderConfiguration.parseDate(record[2]);
        assertEquals(   "The dates are not equal",
                        csvWriterConfiguration.value(temporal),
                        csvWriterConfiguration.value(date));        
    }

    @Test
    public void testParseString() throws Exception{
        String temporal=csvReaderConfiguration.parseString(record[3]);
        assertEquals("The strings are not equal",string,temporal);
    }

    @Test
    public void testParseStringWithQuotes() throws Exception{
        String temporal=csvReaderConfiguration.parseString(record[4]);
        assertEquals("The strings are not equal",stringWithQuotes,temporal);
    }

    @Test
    public void testParseStringWithSeparator() throws Exception{
        String temporal=csvReaderConfiguration.parseString(record[5]);
        assertEquals("The strings are not equal",stringWithSeparator,temporal);
    }

    @Test
    public void testNullString() throws Exception{
        assertNull(csvReaderConfiguration.parseInteger(nullString));
        assertNull(csvReaderConfiguration.parseInteger(null));
        assertNull(csvReaderConfiguration.parseDouble(nullString));
        assertNull(csvReaderConfiguration.parseDouble(null));
        assertNull(csvReaderConfiguration.parseDate(nullString));
        assertNull(csvReaderConfiguration.parseDate(null));
        assertNull(csvReaderConfiguration.parseString(nullString));
        assertNull(csvReaderConfiguration.parseString(null));
    }
}
