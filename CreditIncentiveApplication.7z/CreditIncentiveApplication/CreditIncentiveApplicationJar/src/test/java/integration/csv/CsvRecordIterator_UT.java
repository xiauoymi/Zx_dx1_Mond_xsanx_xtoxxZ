package integration.csv;

import com.monsanto.eas.cia.integration.format.Record;
import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIterator;
import integration.util.SampleLayoutIO;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 9/02/2011
 * Time: 12:59:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvRecordIterator_UT {
    protected CsvReaderConfiguration    csvReaderConfiguration;
    protected SampleLayoutIO            sampleLayoutIO;

    @Before
    public void setup() throws IOException {
        csvReaderConfiguration=new CsvReaderConfiguration();
        sampleLayoutIO  =   new SampleLayoutIO(5);        
    }

    @Test
    public void testIterate() throws IOException{
        assertIteration();
    }

    @Test
    public void testIterateEmptyIterator() throws IOException{
        sampleLayoutIO  =   new SampleLayoutIO(0);
        assertIteration();
    }

    public CsvRecordIterator createCsvRecordIterator() throws IOException{
        CsvRecordIterator recordIterator=new CsvRecordIterator(csvReaderConfiguration,sampleLayoutIO.getReader());
        recordIterator.start();
        return recordIterator;
    }

    public void assertIteration() throws IOException{
        CsvRecordIterator recordIterator=createCsvRecordIterator();
        assertNull(recordIterator.getFields());
        assertEquals(-1,recordIterator.getPosition());
        int iteration=0;
        Record record;
        while(recordIterator.hasNext()){
            record=recordIterator.next();
            assertNotNull(record);
            assertEquals(iteration,record.getRecordNumber());
            iteration++;
        }
        assertEquals(iteration, sampleLayoutIO.getRecordNumbers());
    }
}
