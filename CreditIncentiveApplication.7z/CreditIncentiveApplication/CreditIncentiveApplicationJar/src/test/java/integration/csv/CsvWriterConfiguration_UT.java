package integration.csv;

import com.monsanto.eas.cia.integration.format.csv.CsvReader;
import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import integration.layout.definition.SampleLayout;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/01/2011
 * Time: 04:19:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvWriterConfiguration_UT extends AbstractCsv_UT {

    protected   String[][]              records             =   null;    
    protected   SampleLayout            sampleLayout        =   null;

    @Before
    public void setup() throws IOException{
        super.setup();
        records             =   new String[][]{
            new String[]{"field 1.1","field 1.2","field 1.3"},
            new String[]{"field 2.1","field 2.2","field 2.3"},
            new String[]{"field 3.1","field 3.2","field 3.3"},
        };

    }

    @Test
    public void testWriteRecords() throws IOException{
        CsvWriter csvWriter= csvWriterConfiguration.createCsvWriter(writer);
        for(String[]record:records){
            csvWriter.writeNext(record);
        }
        csvWriter.close();

        CsvReader csvReader = getMemoryBasedCSVReader(csvWriterConfiguration);

        List<String[]> writtenRecords=csvReader.readAll();
        assertNotNull("The written records must not be null",writtenRecords);
        assertEquals("Couldn't read the same number of written records",records.length,writtenRecords.size());

        int i=0;
        for(String[]writtenRecord:writtenRecords){
            assertTrue("The records at position #"+i+" don't match", Arrays.equals(writtenRecord,records[i]));
            ++i;
        }
    }

    @Test
    public void testValueDateMethod(){
        Date date=new Date();
        assertEquals(
            "These string representations don't match",
            csvWriterConfiguration.getDateFormat().format(date),
            csvWriterConfiguration.value(date)
        );

        date=null;
        assertEquals(
            "These string representations don't match",
             csvWriterConfiguration.getEmptyFieldValue(),
             csvWriterConfiguration.value(date)
        );
    }

    @Test
    public void testValueDoubleMethod(){
        Double number=7.777d;
        assertEquals(
            "These string representations don't match",
            csvWriterConfiguration.getDecimalFormat().format(number),
            csvWriterConfiguration.value(number)
        );

        number=null;
        assertEquals(
            "These string representations don't match",
             csvWriterConfiguration.getEmptyFieldValue(),
             csvWriterConfiguration.value(number)
        );
    }

    @Test
    public void testValueStringMethod(){
        String string="The string representations match";
        assertEquals(
            "These string representations don't match",
            string,
            csvWriterConfiguration.value(string)
        );

        string=null;
        assertEquals(
            "These string representations don't match",
             csvWriterConfiguration.getEmptyFieldValue(),
             csvWriterConfiguration.value(string)
        );
    }

    @Test
    public void testMultivalueMethod(){
        String string="These string representations match. ";
        String string_1="OK";
        assertEquals(
            "These string representations don't match",
            string+string_1,
            csvWriterConfiguration.value(string,string_1)
        );

        string_1=null;
        assertEquals(
            "These string representations don't match",
             string,
             csvWriterConfiguration.value(string,string_1)
        );

        string=null;
        string_1=null;
        assertEquals(
            "These string representations don't match",
             csvWriterConfiguration.getEmptyFieldValue(),
             csvWriterConfiguration.value(string,string_1)
        );
    }    
}
