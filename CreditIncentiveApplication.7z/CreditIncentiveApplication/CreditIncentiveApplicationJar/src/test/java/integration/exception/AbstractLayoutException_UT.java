package integration.exception;

import com.monsanto.eas.cia.integration.exception.AbstractLayoutException;
import org.junit.Before;
import org.junit.Test;

import java.util.ResourceBundle;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 01:08:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class AbstractLayoutException_UT {
    AbstractLayoutException exception;
    String                  explanation;

    @Before
    public void setup(){
        defaultSetup();
    }

    public void defaultSetup(){
        explanation =   "???";
        exception   =   new AbstractLayoutException(){
            public String explain(ResourceBundle bundle) {
                return explanation;
            }
        };
    }

    @Test
    public void testAlternateSetup(){
        String message="message";
        exception   =   new AbstractLayoutException(message){
            public String explain(ResourceBundle bundle) {
                return explanation;
            }
        };
        assertTrue(exception.getMessage()==message);
        
        Throwable throwable=new RuntimeException();
        exception   =   new AbstractLayoutException(message,throwable){
            public String explain(ResourceBundle bundle) {
                return explanation;
            }
        };
        assertTrue(exception.getCause()==throwable);
    }

    @Test
    public void testConfiguration(){
        Object layout=new Object();
        exception.setLayout(layout);
        assertTrue(exception.getLayout()==layout);
        long recordNumber=7777777;
        exception.setRecordNumber(recordNumber);
        assertTrue(exception.getRecordNumber()==recordNumber);
        String[]fields=new String[]{};                        
    }
}
