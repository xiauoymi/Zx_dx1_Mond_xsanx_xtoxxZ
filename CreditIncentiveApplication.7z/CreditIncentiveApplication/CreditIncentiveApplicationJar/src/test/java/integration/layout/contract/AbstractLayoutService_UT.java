package integration.layout.contract;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.service.FinderService;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 05:14:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class AbstractLayoutService_UT extends EasyMockSupport {
    AbstractLayoutService abstractLayoutService;
    CriteriaDao criteriaDao;
    FinderService finderService;
    
    @Before
    public void setup(){
        abstractLayoutService=new AbstractLayoutService(){};
        criteriaDao=createMock(CriteriaDao.class);
        finderService=createMock(FinderService.class);
    }

    @Test
    public void testConfiguration(){
        abstractLayoutService.setDao(criteriaDao);
        assertTrue(abstractLayoutService.getDao()==criteriaDao);
        abstractLayoutService.setFinderService(finderService);
        assertTrue(abstractLayoutService.getFinderService()==finderService);

        Object element1=new Object();
        Object element2=new Object();

        Collection<Object> elements= ObjectUtils.asCollection(element1,element2);
        assertTrue(elements.size()==2);
        assertTrue(elements.toArray()[0]==element1);        
        assertTrue(elements.toArray()[1]==element2);
    }
}
