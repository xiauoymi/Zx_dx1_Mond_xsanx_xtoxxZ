package integration.layout.definition;

import com.monsanto.eas.cia.integration.contract.Layout;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 03:12:06 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLayout_UT {

    int currentPosition;
    Map<String,Field> fieldMap;

    @Test 
    public abstract void testFields();
    public abstract Class<? extends Layout> getClassUnderTest();

    @Before
    public final void setUp(){
        fieldMap=getLayoutFields();
        resetPosition();
        setup();
    }

    public void resetPosition(){
        currentPosition=0;
    }


    public void setup(){

    }

    @Test
    public void analyzeLayout() throws Exception{
        Layout layout= getNewInstance();
        BeanInfo layoutInfo= Introspector.getBeanInfo(getClassUnderTest());
        PropertyDescriptor[]propertyDescriptors=layoutInfo.getPropertyDescriptors();

        Map<Class<?>,Object> sampleValues=new HashMap<Class<?>,Object>();
        sampleValues.put(String.class,"value");
        sampleValues.put(Boolean.class,Boolean.TRUE);
        sampleValues.put(Date.class,new Date());
        sampleValues.put(Integer.class,7);
        sampleValues.put(Double.class,7.777d);

        Object sampleValue, readValue;
        Method readMethod,writeMethod;
        Field field;
        String fieldName;
        for(PropertyDescriptor propertyDescriptor:propertyDescriptors){
            fieldName=propertyDescriptor.getName();
            if("class".equals(fieldName))continue;
            sampleValue=sampleValues.get(propertyDescriptor.getPropertyType());
            assertNotNull("No sample value for type: "+propertyDescriptor.getPropertyType(),sampleValue);
            writeMethod=propertyDescriptor.getWriteMethod();
            assertNotNull("No write method for "+fieldName,writeMethod);
            writeMethod.invoke(layout,sampleValue);
            readMethod=propertyDescriptor.getReadMethod();
            assertNotNull("No read method for "+fieldName,readMethod);
            readValue=readMethod.invoke(layout);
            assertTrue("Property "+fieldName,sampleValue==readValue);
            field=fieldMap.get(fieldName);
            assertNotNull("No field for "+fieldName,field);
            field.setAccessible(true);
            assertTrue("Field "+fieldName,field.get(layout)==readValue);
            fieldMap.remove(fieldName);
        }

        Layout clonedLayout=layout.clone();
        assertTrue(EqualsBuilder.reflectionEquals(layout,clonedLayout,true,Object.class));        
    }
        
    @After
    public void testedAllFields(){
        assertTrue(fieldMap.size()==0);
    }

    public void assertDateField(String property){
        assertDateField(currentPosition++, property);
        fieldMap.remove(property);
    }

    public void assertDoubleField(String property){
        assertDoubleField(currentPosition++,property);
        fieldMap.remove(property);
    }

    public void assertIntegerField(String property){
        assertIntegerField(currentPosition++,property);
        fieldMap.remove(property);
    }

    public void assertBooleanField(String property){
        assertBooleanField(currentPosition++,property);
        fieldMap.remove(property);
    }

    public void assertStringField(String property){
        assertStringField(currentPosition++,property);
        fieldMap.remove(property);
    }

    public void assertDateField(int position, String property){
        assertField(position, Date.class, property);
    }

    public void assertDoubleField(int position, String property){
        assertField(position,Double.class,property);
    }

    public void assertIntegerField(int position, String property){
        assertField(position,Integer.class,property);
    }

    public void assertBooleanField(int position, String property){
        assertField(position,Boolean.class,property);
    }

    public void assertStringField(int position, String property){
        assertField(position,String.class,property);
    }

    public void assertField(int position, Class<?> _type, String property){
        layoutHasFieldPosition(getClassUnderTest(),position,_type,property);
    }

    public Map<String,Field> getLayoutFields(){
        return getAllFields(getClassUnderTest());
    }

    public Layout getNewInstance(){
        return newInstance(getClassUnderTest());
    }


}
