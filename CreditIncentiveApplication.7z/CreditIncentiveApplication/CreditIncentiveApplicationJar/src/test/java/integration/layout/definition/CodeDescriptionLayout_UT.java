package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.CodeDescriptionLayout;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 04:29:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class CodeDescriptionLayout_UT  extends AbstractLayout_UT{
    @Test
    @Override
    public void testFields() {
        assertStringField("code");
        assertStringField("description");
    }

    @Override
    public Class<CodeDescriptionLayout> getClassUnderTest() {
        return CodeDescriptionLayout.class;
    }
}
