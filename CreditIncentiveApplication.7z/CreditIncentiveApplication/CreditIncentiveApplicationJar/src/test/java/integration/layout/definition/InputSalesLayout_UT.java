package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.InputSalesLayout;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 04:44:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class InputSalesLayout_UT extends AbstractLayout_UT{

    @Test
    @Override
    public void testFields() {
        assertDateField("date");
        assertStringField("transactionType");
        assertStringField("transactionNumber");
        assertStringField("agreement");
        assertStringField("productCode");
        assertDoubleField("salesVolume");
        assertStringField("assignedFrom");
        assertDoubleField("volumeAssigned");
        assertDoubleField("volumeToIncentive");
        assertBooleanField("validForIncentivePlanning");
        assertDoubleField("price");
        assertDoubleField("incentiveAmount");
        assertStringField("creditNoteCode");
        assertBooleanField("sent2Sap");
        assertDateField("creditNoteDate");
        assertStringField("taxReserveNumber");
        assertStringField("magneticStripe");
    }

    @Override
    public Class<InputSalesLayout> getClassUnderTest() {
        return InputSalesLayout.class;
    }
}
