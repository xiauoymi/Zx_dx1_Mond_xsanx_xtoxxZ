package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.LocalDealerLayout;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 04:51:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocalDealerLayout_UT extends AbstractLayout_UT{

    @Test
    @Override
    public void testFields() {
        assertIntegerField("year");
        assertStringField("commercialManager");
        assertStringField("subRegion");
        assertStringField("commercialSupervisor");
        assertStringField("contactName");
        assertStringField("company");
        assertStringField("taxId");
        assertStringField("state");
        assertStringField("district");
        assertStringField("country");
        assertStringField("address");
        assertStringField("zipCode");
        assertStringField("phone");
        assertStringField("fax");
        assertStringField("email");
        assertDateField("birthday");
        assertDateField("anniversary");
        assertStringField("agreementNumber");
        assertStringField("distId");
        assertDoubleField("minQ1");
        assertDoubleField("maxQ1");
        assertDoubleField("minQ2");
        assertDoubleField("maxQ2");
        assertDoubleField("minQ3");
        assertDoubleField("maxQ3");
        assertDoubleField("minQ4");
        assertDoubleField("maxQ4");
        assertDoubleField("maxTarget");
        assertDoubleField("minTarget");
        assertBooleanField("signed");
    }

    @Override
    public Class<LocalDealerLayout> getClassUnderTest() {
        return LocalDealerLayout.class;
    }
}
