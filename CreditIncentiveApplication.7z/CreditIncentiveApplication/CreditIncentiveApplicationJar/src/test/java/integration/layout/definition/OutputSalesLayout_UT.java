package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.OutputSalesLayout;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 04:57:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class OutputSalesLayout_UT extends AbstractLayout_UT{

    @Test
    @Override
    public void testFields() {
        assertStringField("transactionNumber");
        assertDoubleField("volumeAssigned");
        assertDoubleField("volumeToIncentive");
        assertBooleanField("validForIncentivePlanning");
        assertDoubleField("incentiveAmount");
        assertStringField("creditNoteCode");
        assertBooleanField("sent2Sap");
        assertDateField("creditNoteDate");
        assertIntegerField("taxReserveCode");
        assertStringField("assignedFrom");
    }

    @Override
    public Class<OutputSalesLayout> getClassUnderTest() {
        return OutputSalesLayout.class;
    }
}
