package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.InputProductLayout;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 05:01:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductLayout_UT extends AbstractLayout_UT{

    @Test
    @Override
    public void testFields() {
        assertStringField("symId");
        assertStringField("sapId");
        assertStringField("description");
        assertStringField("family");
        assertStringField("product");
        assertStringField("presentation");
        assertStringField("code");
        assertStringField("uom");
        //assertDoubleField("ltConversionFactor");
        //assertDoubleField("regsConversionFactor");
    }

    @Override
    public Class<InputProductLayout> getClassUnderTest() {
        return InputProductLayout.class;
    }
}
