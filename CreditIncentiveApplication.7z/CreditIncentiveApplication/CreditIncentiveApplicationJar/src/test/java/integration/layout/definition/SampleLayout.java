package integration.layout.definition;

import com.monsanto.eas.cia.integration.layout.definition.AbstractLayout;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 9/02/2011
 * Time: 10:47:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class SampleLayout extends AbstractLayout {
    @FieldPosition(0) protected String    stringValue;
    @FieldPosition(1) protected Date      dateValue;
    @FieldPosition(2) protected Double    decimalValue;
    @FieldPosition(3) protected Integer   integerValue;
    @FieldPosition(4) protected Boolean   booleanValue;    
    public SampleLayout() {
    }

    public SampleLayout(SampleLayout other){
        ObjectUtils.copySourceInto(other,this);
    }


    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public Date getDateValue() {
        return dateValue;
    }

    public void setDateValue(Date dateValue) {
        this.dateValue = dateValue;
    }

    public Double getDecimalValue() {
        return decimalValue;
    }

    public void setDecimalValue(Double decimalValue) {
        this.decimalValue = decimalValue;
    }

    public Integer getIntegerValue() {
        return integerValue;
    }

    public void setIntegerValue(Integer integerValue) {
        this.integerValue = integerValue;
    }

    public Boolean getBooleanValue() {
        return booleanValue;
    }

    public void setBooleanValue(Boolean booleanValue) {
        this.booleanValue = booleanValue;
    }

    @Override
    public SampleLayout clone(){
        return new SampleLayout(this);
    }
}
