package integration.layout.exception;

import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.junit.Test;

import java.util.Arrays;
import java.util.ResourceBundle;

import static org.junit.Assert.fail;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 05:35:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceExceptionCode_UT {

    ResourceBundle bundle= LayoutUtils.RESOURCE_BUNDLE;

    @Test
    public void testExceptions(){
        Object[]parameters=new Object[]{};
        Throwable t=new RuntimeException();
        for(LayoutServiceExceptionCode code:LayoutServiceExceptionCode.values()){
            assertException(code.get(),null,null);
            assertException(code.get(parameters),null,parameters);
            assertException(code.get(t),t,null);
            assertException(code.get(t,parameters),t,parameters);

            try{code.fail(t,parameters);fail();}
            catch(LayoutServiceException exception){assertException(exception,t,parameters);}

            try{code.fail(parameters);fail();}
            catch(LayoutServiceException exception){assertException(exception,null,parameters);}

            try{code.fail();fail();}
            catch(LayoutServiceException exception){assertException(exception,null,null);}
        }
    }
    

    public void assertException(LayoutServiceException exception,Throwable t, Object [] parameters){        
        assert exception!=null;
        assert bundle.containsKey(exception.getMessage());
        assert exception.getCause()==t;
        if(parameters!=null&&exception.getParameters()!=null)
            assert Arrays.equals(exception.getParameters(),parameters);
        else
            assert (exception.getParameters()==null||exception.getParameters().length==0)&&(parameters==null||parameters.length==0);
    }
}
