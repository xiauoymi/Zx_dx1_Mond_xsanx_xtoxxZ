package integration.layout.exception;

import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 05:27:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceException_UT {

    String key;
    LayoutServiceException exception;
    Throwable cause;
    String value;

    @Before
    public void setup(){
        key="bundle.value";
        value="value";
        cause=new RuntimeException();
        exception=new LayoutServiceException(key,cause,value);
    }

    @Test
    public void testConfiguration(){
        assertTrue(exception.getMessage()==key);
        Object[] parameters=exception.getParameters();
        assertTrue(parameters.length==1);
        assertTrue(parameters[0]==value);
        String explanation=exception.explain(LayoutUtils.RESOURCE_BUNDLE);
        assertEquals("do not remove "+value,explanation);
    }

}
