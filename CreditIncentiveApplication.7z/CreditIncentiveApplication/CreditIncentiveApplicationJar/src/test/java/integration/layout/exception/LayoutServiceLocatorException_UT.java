package integration.layout.exception;

import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 06:00:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceLocatorException_UT {

    String              serviceId;
    Class<?>            serviceClass;
    RuntimeException    runtimeException;
    LayoutServiceLocatorException exception;

    @Before
    public void setup(){
        serviceId       =   "service-id";
        serviceClass    =   Object.class;
        runtimeException=   new RuntimeException();
        exception       =   new LayoutServiceLocatorException(runtimeException,serviceId,serviceClass);
    }

    @Test
    public void testConfiguration(){        
        assertTrue(exception.getServiceId()==serviceId);
        assertTrue(exception.getServiceClass()==serviceClass);
        assertTrue(exception.getCause() == runtimeException);
    }
}
