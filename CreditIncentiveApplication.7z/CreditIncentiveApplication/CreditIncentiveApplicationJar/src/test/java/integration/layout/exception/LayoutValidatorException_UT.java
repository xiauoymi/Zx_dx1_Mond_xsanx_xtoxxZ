package integration.layout.exception;

import com.monsanto.eas.cia.integration.layout.exception.LayoutValidatorException;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import integration.layout.definition.SampleLayout;
import org.hibernate.validator.InvalidValue;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 06:04:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutValidatorException_UT {
    InvalidValue                invalidValue;
    InvalidValue[]              invalidValues;
    SampleLayout                layout;
    String                      message;
    Class<?>                    _class;
    String                      property;
    String                      value;
    LayoutValidatorException    exception;
    long                        recordNumber;


    @Before
    public void setup(){
        recordNumber=1;
        invalidValue=new InvalidValue(message="message",_class= SampleLayout.class,property="stringProperty",value="value", layout =new SampleLayout());
        invalidValues=new InvalidValue[5];
        for(int i=0;i<invalidValues.length;i++){
            invalidValues[i]=invalidValue;
        }
        exception=new LayoutValidatorException(layout,recordNumber,invalidValues);
    }

    @Test
    public void testConfiguration(){
        assert exception.getLayout()==layout;
        assert exception.getRecordNumber()==recordNumber;
        assert exception.getInvalidValues()==invalidValues;
        String explanation=exception.explain(LayoutUtils.RESOURCE_BUNDLE);
        //System.out.println(explanation);
        assert explanation!=null&&explanation.length()>0;
    }
    
}
