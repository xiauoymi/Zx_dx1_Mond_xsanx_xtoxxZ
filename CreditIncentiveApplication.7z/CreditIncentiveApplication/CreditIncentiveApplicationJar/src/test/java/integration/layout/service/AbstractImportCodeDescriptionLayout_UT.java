package integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.definition.CodeDescriptionLayout;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 07:23:10 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractImportCodeDescriptionLayout_UT<S extends AbstractLayoutService> extends AbstractImportLayoutService_UT<S, CodeDescriptionLayout>{
    @Override
    public void internalSetup(CodeDescriptionLayout sampleLayout){
        super.internalSetup(sampleLayout);
        sampleLayout.setCode("???");
        sampleLayout.setDescription("???");
    }    
}
