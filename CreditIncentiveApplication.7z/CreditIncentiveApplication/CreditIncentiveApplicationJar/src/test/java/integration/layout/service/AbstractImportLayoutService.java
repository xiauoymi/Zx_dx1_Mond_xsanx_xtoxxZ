package integration.layout.service;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 01:13:19 PM
 * To change this template use File | Settings | File Templates.
 */
public interface AbstractImportLayoutService<T extends Layout> extends ImportLayoutService<T> {
}
