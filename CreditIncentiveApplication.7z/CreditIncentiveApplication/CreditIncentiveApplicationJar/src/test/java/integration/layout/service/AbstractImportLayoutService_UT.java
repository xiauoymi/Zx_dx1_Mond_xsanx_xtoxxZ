package integration.layout.service;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 06:50:26 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractImportLayoutService_UT<S extends AbstractLayoutService,L extends Layout> extends AbstractLayoutService_UT<S,L> {
   
    public void assertImportLayout(){
        replayAll();
        ((ImportLayoutService)service).importLayout(inputLayout);
        verifyAll();
    }

    public void assertExceptionUponImportLayout(LayoutServiceExceptionCode code,Object ... params){
        try{
            assertImportLayout();
        }
        catch(LayoutServiceException exception){
            assertLayoutServiceException(code,exception,params);            
        }
    }
}
