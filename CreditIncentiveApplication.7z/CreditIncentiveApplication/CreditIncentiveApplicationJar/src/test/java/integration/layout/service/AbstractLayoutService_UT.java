package integration.layout.service;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.AbstractLayoutService;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.service.FinderService;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.Before;

import static com.monsanto.eas.cia.integration.util.ObjectUtils.getGenericType;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.newInstance;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 06:41:29 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractLayoutService_UT<S extends AbstractLayoutService,L extends Layout>extends EasyMockSupport{
    protected IMocksControl   control;
    protected L               inputLayout;
    protected L               sampleLayout;
    protected S               service;
    protected FinderService   finderService;
    protected CriteriaDao     criteriaDao;

    @Before
    public void setup(){
        control         =   createStrictControl();
        sampleLayout    =   (L)newInstance(getGenericType(getClass(),Layout.class));
        inputLayout     =   (L)control.createMock(getGenericType(getClass(),Layout.class));
        service         =   (S)newInstance(getGenericType(getClass(),AbstractLayoutService.class));
        finderService   =   control.createMock(FinderService.class);
        criteriaDao     =   control.createMock(CriteriaDao.class);
        service.setFinderService(finderService);
        service.setDao(criteriaDao);
        internalSetup(sampleLayout);
    }

    public void internalSetup(L sampleLayout){

    }

    public void assertLayoutServiceException(LayoutServiceExceptionCode code, LayoutServiceException exception, Object ... parameters){
        assertTrue(exception.getMessage()==code.getKey());
        assertNotNull(exception.getParameters());
        assertTrue(exception.getParameters().length==parameters.length);
        int i=0;
        for(Object parameter:parameters){
            assertTrue(exception.getParameters()[i++]==parameter);
        }
        verifyAll();
    }
}
