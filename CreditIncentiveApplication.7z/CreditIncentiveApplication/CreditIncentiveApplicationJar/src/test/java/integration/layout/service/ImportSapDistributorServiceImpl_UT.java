package integration.layout.service;

import com.monsanto.eas.cia.integration.layout.service.ImportSapDistributorServiceImpl;
import com.monsanto.eas.cia.integration.util.Condition;
import com.monsanto.eas.cia.model.SapDistributor;
import org.junit.Test;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.evalArg;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 16/02/2011
 * Time: 07:10:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImportSapDistributorServiceImpl_UT  extends AbstractImportCodeDescriptionLayout_UT<ImportSapDistributorServiceImpl> {

    @Test
    public void testImportExistingSapDistributor(){
        SapDistributor mockDbSapDistributor=createMock(SapDistributor.class);                
        expect(inputLayout.getCode()).andReturn(sampleLayout.getCode());
        expect(finderService.findSapDistributorFrom(sampleLayout.getCode())).andReturn(mockDbSapDistributor);
        expect(inputLayout.getDescription()).andReturn(sampleLayout.getDescription());
        mockDbSapDistributor.setDescription(sampleLayout.getDescription());
        criteriaDao.persist(mockDbSapDistributor);
    }

    @Test
    public void testImportNewSapDistributor(){
        expect(inputLayout.getCode()).andReturn(sampleLayout.getCode());
        expect(finderService.findSapDistributorFrom(sampleLayout.getCode())).andReturn(null);
        expect(inputLayout.getDescription()).andReturn(sampleLayout.getDescription());
        criteriaDao.persist(evalArg(
            new Condition<SapDistributor>(){
                public boolean evaluate(SapDistributor argument) {
                    assertTrue(argument.getCode()==sampleLayout.getCode());
                    assertTrue(argument.getDescription()==sampleLayout.getDescription());
                    return true;
                }
            }
        ));
    }
}
