package integration.layout.service;

import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.layout.service.LayoutServiceLocatorImpl;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import java.io.Serializable;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 15/02/2011
 * Time: 11:57:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutServiceLocatorImpl_UT extends EasyMockSupport {

    ApplicationContext          applicationContext;
    LayoutServiceLocatorImpl    layoutServiceLocatorImpl;
    String                      serviceId;
    Class<?>                    serviceClass;
    Object                      service;

    @Before
    public void setup(){
        serviceId                   =   "service-id";
        serviceClass                =   Serializable.class;
        service                     =   createMock(serviceClass);
        applicationContext          =   createMock(ApplicationContext.class);
        layoutServiceLocatorImpl    =   new LayoutServiceLocatorImpl();
        layoutServiceLocatorImpl.setApplicationContext(applicationContext);
    }

    @Test
    public void testLookup(){
        expect(applicationContext.getBean(serviceId,serviceClass)).andReturn(service);
        replayAll();
        assertTrue(layoutServiceLocatorImpl.lookup(serviceId,serviceClass)==service);
        verifyAll();
    }

    @Test
    public void testExceptionWhileLookingUp(){
        RuntimeException runtimeException=new RuntimeException();
        expect(applicationContext.getBean(serviceId,serviceClass)).andThrow(runtimeException);
        LayoutServiceLocatorException exception=getLayoutServiceLocatorException();        
        assertTrue(exception.getCause()==runtimeException);
    }

    @Test
    public void testReturningNullWhileLookingUp(){
        expect(applicationContext.getBean(serviceId,serviceClass)).andReturn(null);
        LayoutServiceLocatorException exception=getLayoutServiceLocatorException();
        assertTrue(exception.getCause() instanceof NullPointerException);
    }

    public LayoutServiceLocatorException getLayoutServiceLocatorException(){
        LayoutServiceLocatorException layoutServiceLocatorException=null;
        replayAll();
        try{
            layoutServiceLocatorImpl.lookup(serviceId,serviceClass);
        }
        catch(LayoutServiceLocatorException exception){
            assertTrue(exception.getServiceId()==serviceId);
            assertTrue(exception.getServiceClass()==serviceClass);
            layoutServiceLocatorException=exception;
        }
        verifyAll();
        return layoutServiceLocatorException;
    }
}
