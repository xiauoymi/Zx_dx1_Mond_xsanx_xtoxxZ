package integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import integration.layout.definition.SampleLayout;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 12:46:24 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SampleLayoutExportService extends ExportLayoutService<SampleLayout>{
}
