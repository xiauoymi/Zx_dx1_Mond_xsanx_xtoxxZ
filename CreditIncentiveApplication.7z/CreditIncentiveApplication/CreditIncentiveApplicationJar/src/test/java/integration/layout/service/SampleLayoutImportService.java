package integration.layout.service;

import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import integration.layout.definition.SampleLayout;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 11:51:39 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SampleLayoutImportService extends ImportLayoutService<SampleLayout> {
}
