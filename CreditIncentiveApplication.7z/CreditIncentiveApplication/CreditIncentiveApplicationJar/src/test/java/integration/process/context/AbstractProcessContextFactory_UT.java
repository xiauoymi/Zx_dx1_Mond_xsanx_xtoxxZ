package integration.process.context;

import com.monsanto.eas.cia.integration.process.context.AbstractProcessContextFactory;
import com.monsanto.eas.cia.integration.process.contract.EventQueueFactory;
import com.monsanto.eas.cia.integration.process.context.ThrowableEventQueueFactoryImpl;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:18:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class AbstractProcessContextFactory_UT {

    AbstractProcessContextFactory   processContextFactory;
    EventQueueFactory               eventQueueFactory;

    @Before
    public void setup(){
        processContextFactory   =   new AbstractProcessContextFactory(){};
        eventQueueFactory       =   new ThrowableEventQueueFactoryImpl();
    }

    @Test
    public void testSetEventQueueFactory(){
        processContextFactory.setEventQueueFactory(eventQueueFactory);
        assertTrue(processContextFactory.getEventQueueFactory()==eventQueueFactory);
    }
}
