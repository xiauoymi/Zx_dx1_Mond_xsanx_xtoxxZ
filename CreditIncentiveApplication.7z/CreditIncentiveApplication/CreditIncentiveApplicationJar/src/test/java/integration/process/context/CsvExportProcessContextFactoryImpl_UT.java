package integration.process.context;

import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContextFactoryImpl;
import com.monsanto.eas.cia.integration.process.contract.EventQueueFactory;
import com.monsanto.eas.cia.integration.process.context.ThrowableEventQueueFactoryImpl;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringWriter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:21:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvExportProcessContextFactoryImpl_UT {

    CsvExportProcessContextFactoryImpl  contextFactory;
    EventQueueFactory                   eventQueueFactory;
    StringWriter                        writer;
    String                              serviceId;
    StringWriter                        errorLog;

    @Before
    public void setup(){
        contextFactory      =   new CsvExportProcessContextFactoryImpl();
        eventQueueFactory   =   new ThrowableEventQueueFactoryImpl();
        contextFactory.setEventQueueFactory(eventQueueFactory);
        writer              =   new StringWriter();
        serviceId           =   "serviceId";
        errorLog            =   new StringWriter();
    }

    @Test
    public void testContextFactory() throws IOException {
        CsvExportProcessContext context=contextFactory.createProcessContext(writer,serviceId,errorLog);
        assertNotNull(context.getEventQueue());
        assertTrue(context.getWriter()==writer);
        assertTrue(context.getServiceId()==serviceId);
    }
}

