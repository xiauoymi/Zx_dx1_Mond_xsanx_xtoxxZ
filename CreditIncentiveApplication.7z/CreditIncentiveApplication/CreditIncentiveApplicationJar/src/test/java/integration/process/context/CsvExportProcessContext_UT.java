package integration.process.context;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import org.easymock.classextension.EasyMockSupport;
import org.hibernate.ScrollableResults;
import org.junit.Before;
import org.junit.Test;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 12:50:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class CsvExportProcessContext_UT extends EasyMockSupport{

    CsvExportProcessContext context;

    StringWriter            writer;
    CsvWriter               csvWriter;
    Collection<Layout>      layouts;
    ScrollableResults       scrollableResults;
    ExportLayoutService     exportLayoutService;
    Object[]                entities;

    @Before
    public void setup(){
        context             =   new CsvExportProcessContext();
        writer              =   new StringWriter();
        csvWriter           =   new CsvWriter(writer);
        layouts             =   new ArrayList<Layout>();
        scrollableResults   =   createMock(ScrollableResults.class);
        exportLayoutService =   createMock(ExportLayoutService.class);
        entities            =   new Object[]{};
    }

    @Test
    public void testSetProperties(){
        context.setWriter(writer);
        context.setCsvWriter(csvWriter);
        context.setLayouts(layouts);
        context.setScrollableResults(scrollableResults);
        context.setExportLayoutService(exportLayoutService);
        context.setEntities(entities);
        assertProperties();
    }

    public void assertProperties(){
        assertTrue(context.getWriter()              ==writer);
        assertTrue(context.getCsvWriter()           ==csvWriter);
        assertTrue(context.getLayouts()             ==layouts);
        assertTrue(context.getScrollableResults()   ==scrollableResults);
        assertTrue(context.getExportLayoutService() ==exportLayoutService);
        assertTrue(context.getEntities()            ==entities);
    }

    @Test
    public void testClone(){
        testSetProperties();
        CsvExportProcessContext newContext=context.clone();
        context=newContext;
        assertProperties();
    }

}
