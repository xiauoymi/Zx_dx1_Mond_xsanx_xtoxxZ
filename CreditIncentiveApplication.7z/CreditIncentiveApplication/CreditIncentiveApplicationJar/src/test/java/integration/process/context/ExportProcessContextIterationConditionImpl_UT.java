package integration.process.context;

import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.context.ExportProcessContextIterationConditionImpl;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:27:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportProcessContextIterationConditionImpl_UT {

    CsvExportProcessContext context;

    @Before
    public void setup(){
        context=new CsvExportProcessContext();        
    }

    @Test
    public void testCondition(){
        context.setEntities(new Object[]{});
        assertTrue(new ExportProcessContextIterationConditionImpl().evaluate(context));
        context.setEntities(null);
        assertFalse(new ExportProcessContextIterationConditionImpl().evaluate(context));
    }

}
