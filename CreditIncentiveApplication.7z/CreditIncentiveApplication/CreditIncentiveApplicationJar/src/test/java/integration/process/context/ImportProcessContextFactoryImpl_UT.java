package integration.process.context;

import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContextFactoryImpl;
import com.monsanto.eas.cia.integration.process.contract.EventQueueFactory;
import com.monsanto.eas.cia.integration.process.context.ThrowableEventQueueFactoryImpl;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:31:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessContextFactoryImpl_UT {
    ImportProcessContextFactoryImpl contextFactory;
    EventQueueFactory                   eventQueueFactory;
    StringReader                        reader;
    String                              serviceId;
    StringWriter                        errorLog;

    @Before
    public void setup(){
        contextFactory      =   new ImportProcessContextFactoryImpl();
        eventQueueFactory   =   new ThrowableEventQueueFactoryImpl();
        contextFactory.setEventQueueFactory(eventQueueFactory);
        reader              =   new StringReader("");
        serviceId           =   "serviceId";
        errorLog            =   new StringWriter();
    }

    @Test
    public void testContextFactory() throws IOException {
        ImportProcessContext context=contextFactory.createProcessContext(reader,serviceId,errorLog);
        assertNotNull(context.getEventQueue());
        assertTrue(context.getReader()==reader);
        assertTrue(context.getServiceId()==serviceId);
    }

}
