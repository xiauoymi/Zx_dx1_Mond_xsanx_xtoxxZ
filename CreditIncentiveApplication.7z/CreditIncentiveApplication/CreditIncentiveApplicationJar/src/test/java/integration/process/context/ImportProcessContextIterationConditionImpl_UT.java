package integration.process.context;

import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContextIterationConditionImpl;
import org.easymock.classextension.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:37:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessContextIterationConditionImpl_UT extends EasyMockSupport {
    ImportProcessContext context;
    CsvRecord               csvRecord;

    @Before
    public void setup(){
        context=new ImportProcessContext();
        csvRecord=createMock(CsvRecord.class);
    }

    @Test
    public void testCondition(){
        context.setAbstractRecord(csvRecord);
        assertTrue(new ImportProcessContextIterationConditionImpl().evaluate(context));
        context.setAbstractRecord(null);
        assertFalse(new ImportProcessContextIterationConditionImpl().evaluate(context));

    }
}
