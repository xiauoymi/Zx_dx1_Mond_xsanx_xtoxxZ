package integration.process.context;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.FieldAnnotationProcessor;
import com.monsanto.eas.cia.integration.format.FieldParser;
import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIterator;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import integration.layout.definition.SampleLayout;
import org.hibernate.validator.ClassValidator;
import org.junit.Before;
import org.junit.Test;

import java.io.StringReader;
import java.util.HashMap;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 12:21:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessContext_UT {
    ImportProcessContext context;

    String              serviceId;
    StringReader        reader;
    CsvRecord           record;
    Layout              layout;
    Class<?>            _class;
    ClassValidator      validator;
    CsvRecordIterator   iterator;
    String[]            fields;


    @Before
    public void setup(){
        context         =   new ImportProcessContext();
        serviceId       =   "service-id";
        reader          =   new StringReader(serviceId);
        record          =   new CsvRecord(new String[]{},0,new HashMap<Class<?>, FieldParser<?,String>>(),new HashMap<Class<?>, FieldAnnotationProcessor<String>>());
        layout          =   new SampleLayout();
        _class          =   SampleLayout.class;
        validator       =   new ClassValidator(SampleLayout.class);
        iterator        =   new CsvRecordIterator(new CsvReaderConfiguration(),reader);
        fields          =   new String[]{};        
    }

    @Test
    public void testSetProperties(){
        context.setServiceId(serviceId);
        context.setReader(reader);
        context.setAbstractRecord(record);
        context.setLayout(layout);
        context.setImportLayoutType(_class);
        context.setValidator(validator);
        context.setIterator(iterator);

        assertProperties();
    }

    public void assertProperties(){
        assertTrue(context.getServiceId()==serviceId);
        assertTrue(context.getReader()==reader);
        assertTrue(context.getAbstractRecord()==record);
        assertTrue(context.getLayout()==layout);
        assertTrue(context.getImportLayoutType()==_class);
        assertTrue(context.getValidator()==validator);
        assertTrue(context.getIterator()==iterator);
    }

    @Test
    public void testClone(){
        testSetProperties();
        ImportProcessContext newContext=context.clone();
        context=newContext;
        assertProperties();
    }

}
