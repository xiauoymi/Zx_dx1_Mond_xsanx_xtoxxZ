package integration.process.context;

import com.monsanto.eas.cia.integration.process.context.ThrowableEventQueueFactoryImpl;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.eip.SedaProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringWriter;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 01:07:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class ThrowableEventQueueFactoryImpl_UT {

    ThrowableEventQueueFactoryImpl  eventQueueFactory;
    StringWriter                    writer;

    @Before
    public void setup(){
        eventQueueFactory   =   new ThrowableEventQueueFactoryImpl();
        writer              =   new StringWriter();
    }

    @Test
    public void testCreateProcessQueue() throws IOException {
        ProcessQueue eventQueue= eventQueueFactory.createEventQueue(writer);
        assertTrue(eventQueue instanceof SedaProcessQueue);
        SedaProcessQueue sedaProcessQueue=(SedaProcessQueue)eventQueue;
        ProcessEventHandlerRegistry processEventHandlerRegistry;
        assertNotNull(processEventHandlerRegistry=sedaProcessQueue.getProcessEventHandlerRegistry());
        assertNotNull(processEventHandlerRegistry.getProcessEventHandler(Throwable.class));
    }
}
