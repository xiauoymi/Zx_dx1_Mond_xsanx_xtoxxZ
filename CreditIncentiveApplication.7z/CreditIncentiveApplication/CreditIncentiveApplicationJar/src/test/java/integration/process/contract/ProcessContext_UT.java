package integration.process.contract;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 11:13:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessContext_UT extends EasyMockSupport {

    protected ProcessQueue      eventQueue;
    protected ProcessContext    context;
    protected Object            payload;
    protected int               priority;
    int                         recordNumber;

    @Before
    public void setup(){
        priority    =   ProcessEvent.NORMAL_PRIORITY;
        payload     =   new Object();
        eventQueue  =   createMock(ProcessQueue.class);
        context     =   new ProcessContext(eventQueue);
        assertNotNull(context.getEventQueue());
        recordNumber    =   10;
    }

    @Test
    public void testFireEvent(){
        replayEventQueue();
        context.fireEvent(payload);
        assertFalse(context.isInterrupted());
        assertFalse(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireEvent_Interrupted(){
        replayEventQueue();
        context.fireEvent(payload,true);
        assertTrue(context.isInterrupted());
        assertFalse(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireEvent_Failure(){
        replayEventQueue();
        context.fireEvent(payload,true,true);
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireEvent_UrgentException(){
        priority=ProcessEvent.URGENT_PRIORITY;
        replayEventQueue();
        context.fireEvent(payload,true,true,priority);
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireException_Interrupted(){
        replayEventQueue();
        context.fireException(payload);
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireException_Failure(){
        replayEventQueue();
        context.fireException(payload,true);
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testFireException_UrgentException(){
        priority=ProcessEvent.URGENT_PRIORITY;
        replayEventQueue();
        context.fireFatalException(payload);
        assertTrue(context.isHalted());
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
        verifyAll();
    }

    @Test
    public void testInterruptAndHalt(){
        context.setInterrupted(true);
        assertTrue(context.isInterrupted());
        context.setInterrupted(false);
        assertFalse(context.isInterrupted());
        context.halt();
        assertTrue(context.isHalted());
        assertTrue(context.isInterrupted());
        context.setInterrupted(false);
        assertTrue(context.isInterrupted());
    }

    @Test
    public void testProcessOutcome(){
        assertNull(context.getProcessOutcome());
        ProcessOutcome outcome=null;
        context.setProcessOutcome(outcome=new ProcessOutcome());
        assertTrue(outcome==context.getProcessOutcome());

    }

    @Test
    public void testClone(){
        context.setProcessOutcome(new ProcessOutcome());
        context.setExceptionFired(true);
        context.setInterrupted(true);
        context.halt();
        context.setRecordNumber(recordNumber);
        ProcessContext newContext=context.clone();
        assertNotNull(newContext);
        assertTrue(context.getProcessOutcome()==newContext.getProcessOutcome());
        assertTrue(context.getEventQueue()==newContext.getEventQueue());
        assertTrue(context.isHalted()==newContext.isHalted());
        assertTrue(context.isInterrupted()==newContext.isInterrupted());
        assertTrue(context.getRecordNumber()==recordNumber);
        assertTrue(context.isExceptionFired()==newContext.isExceptionFired());
    }

    public void replayEventQueue(){
        eventQueue.send(payload,context,priority);
        replayAll();
    }
}
