package integration.process.contract;

import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 12:09:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessOutcome_UT {

    @Test
    public void testProcessOutcome(){
        ProcessOutcome outcome=new ProcessOutcome();
        assertTrue(outcome.getInterrupted()==0);
        assertTrue(outcome.getExceptionsFired()==0);
        assertTrue(outcome.getFailures()==0);
        assertTrue(outcome.getSuccessful()==0);
        assertTrue(outcome.getProcessed()==0);

        outcome.addInterrupted();
        outcome.addExceptionFired();
        outcome.addFailure();
        outcome.addSuccessful();

        assertTrue(outcome.getInterrupted()==1);
        assertTrue(outcome.getExceptionsFired()==1);
        assertTrue(outcome.getFailures()==1);
        assertTrue(outcome.getSuccessful()==1);
        assertTrue(outcome.getProcessed()==4);
    }
}
