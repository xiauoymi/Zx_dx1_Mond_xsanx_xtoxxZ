package integration.process.definition;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.process.context.*;
import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.integration.process.definition.DefaultProcessDefinition;
import com.monsanto.eas.cia.integration.process.definition.ExportProcessBuilderFactoryImpl;
import com.monsanto.eas.cia.integration.process.definition.ProcessContextAggregatorImpl;
import com.monsanto.eas.cia.integration.process.stage.impl.ExportLayoutServiceExecutionStage;
import com.monsanto.eas.cia.integration.process.stage.impl.IterateDbRecordsStage;
import com.monsanto.eas.cia.integration.process.stage.impl.LookupExportLayoutServiceStage;
import com.monsanto.eas.cia.integration.process.stage.impl.WriteCsvRecordsStage;
import integration.layout.definition.SampleLayout;
import integration.layout.service.SampleLayoutExportService;
import org.easymock.EasyMockSupport;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.junit.Before;
import org.junit.Test;

import java.io.LineNumberReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 12:20:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvExportProcessDefinition_UT extends EasyMockSupport {

    ExportProcessBuilderFactoryImpl processFactory;
    DefaultProcessDefinition<CsvExportProcessContext> exportProcessDefinition;
    CsvExportProcessContextFactoryImpl              processContextFactory;
    ExportProcessContextIterationConditionImpl iterationCondition;
    LookupExportLayoutServiceStage                  lookupExportLayoutServiceStage;
    IterateDbRecordsStage                           iterateRecordsStage;
    ExportLayoutServiceExecutionStage               exportLayoutExecutionStage;
    WriteCsvRecordsStage                            writeRecordsStage;
    ProcessContextAggregatorImpl                    aggregator;

    ThrowableEventQueueFactoryImpl                  eventQueueFactory;
    LayoutServiceLocator                            serviceLocator;
    CriteriaDao                                     criteriaDao;
    CsvWriterConfiguration                          csvWriterConfiguration;
    SampleLayoutExportService                       exportLayoutService;
    ScrollableResults                               scrollableResults;
    String                                          serviceId;
    Object[]                                        entities;
    SampleLayout                                    sampleLayout;
    Collection<SampleLayout>                        layouts;
    StringWriter                                    writer;
    StringWriter                                    errorLog;

    @Before
    public void setup(){

        processContextFactory   =   new CsvExportProcessContextFactoryImpl();
        processFactory          =   new ExportProcessBuilderFactoryImpl<ExportProcessContext>();
        iterationCondition      =   new ExportProcessContextIterationConditionImpl();
        lookupExportLayoutServiceStage  =   new LookupExportLayoutServiceStage();
        iterateRecordsStage     =   new IterateDbRecordsStage();
        exportLayoutExecutionStage  =   new ExportLayoutServiceExecutionStage();
        writeRecordsStage       =   new WriteCsvRecordsStage();
        aggregator              =   new ProcessContextAggregatorImpl();
        eventQueueFactory       =   new ThrowableEventQueueFactoryImpl();
        serviceLocator          =   createMock(LayoutServiceLocator.class);
        criteriaDao             =   createMock(CriteriaDao.class);
        exportLayoutService     =   createMock(SampleLayoutExportService.class);
        scrollableResults       =   createMock(ScrollableResults.class);
        csvWriterConfiguration  =   new CsvWriterConfiguration();
        serviceId               =   "serviceId";
        entities                =   new Object[]{};
        sampleLayout            =   new SampleLayout();
        sampleLayout.setBooleanValue(true);
        sampleLayout.setIntegerValue(7);
        sampleLayout.setStringValue("Yeah!");
        sampleLayout.setDateValue(new Date());
        sampleLayout.setDecimalValue(7.777);
        layouts                 =   new ArrayList<SampleLayout>();
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);

        processContextFactory.setEventQueueFactory(eventQueueFactory);
        lookupExportLayoutServiceStage.setServiceLocator(serviceLocator);
        iterateRecordsStage.setDao(criteriaDao);
        writeRecordsStage.setCsvWriterConfiguration(csvWriterConfiguration);

        exportProcessDefinition =   new DefaultProcessDefinition<CsvExportProcessContext>();
        exportProcessDefinition.setProcessBuilderFactory(processFactory);
        exportProcessDefinition.setProcessContextFactory(processContextFactory);
        processFactory.setIterationCondition(iterationCondition);
        processFactory.setLookupExportLayoutServiceStage(lookupExportLayoutServiceStage);
        processFactory.setIterateRecordsStage(iterateRecordsStage);
        processFactory.setExportLayoutExecutionStage(exportLayoutExecutionStage);
        processFactory.setWriteRecordsStage(writeRecordsStage);
        processFactory.setAggregator(aggregator);

        writer                  =   new StringWriter();
        errorLog                =   new StringWriter();
    }

    @Test
    public void testExecution() throws Exception {
        expect(serviceLocator.lookupExportLayoutService(serviceId)).andReturn(exportLayoutService);
        expect(criteriaDao.getScrollableResults(exportLayoutService, ScrollMode.FORWARD_ONLY)).andReturn(scrollableResults);
        int numberOfIterations=10;
        int synchronizeOnNumberOfRecords=iterateRecordsStage.getSynchronizeOnNumberOfRecords();
        for(int i=0;i<numberOfIterations;i++){
            expect(scrollableResults.next()).andReturn(true);
            expect(scrollableResults.get()).andReturn(entities);
            criteriaDao.synchronize(i,synchronizeOnNumberOfRecords);
            expect(exportLayoutService.exportLayouts(entities)).andReturn(layouts);
        }
        expect(scrollableResults.next()).andReturn(false);
        criteriaDao.synchronize(synchronizeOnNumberOfRecords,synchronizeOnNumberOfRecords);
        scrollableResults.close();

        replayAll();
        CsvExportProcessContext context=exportProcessDefinition.execute(writer,serviceId,errorLog);
        verifyAll();

        ProcessOutcome outcome=context.getProcessOutcome();

        assertNotNull(outcome);

        assertTrue(outcome.getSuccessful()==numberOfIterations);
        assertTrue(outcome.getProcessed()==numberOfIterations);

        String contents=writer.toString();
        System.out.println(contents);
        LineNumberReader reader=new LineNumberReader(new StringReader(contents));
        while(reader.readLine()!=null);
        assertTrue(reader.getLineNumber()==numberOfIterations*layouts.size());
        reader.close();
    }
}
