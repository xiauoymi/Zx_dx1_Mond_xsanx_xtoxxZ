package integration.process.definition;

import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContextFactoryImpl;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContextIterationConditionImpl;
import com.monsanto.eas.cia.integration.process.context.ThrowableEventQueueFactoryImpl;
import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.integration.process.definition.DefaultProcessDefinition;
import com.monsanto.eas.cia.integration.process.definition.ImportProcessBuilderFactoryImpl;
import com.monsanto.eas.cia.integration.process.definition.ProcessContextAggregatorImpl;
import com.monsanto.eas.cia.integration.process.stage.impl.*;
import com.monsanto.eas.cia.integration.util.Condition;
import integration.layout.definition.SampleLayout;
import integration.layout.service.SampleLayoutImportService;
import integration.util.SampleLayoutIO;
import org.easymock.classextension.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import util.TestUtils;

import java.io.IOException;
import java.io.StringWriter;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 08:18:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CsvImportProcessDefinition_UT extends EasyMockSupport {
    protected ImportProcessBuilderFactoryImpl<ImportProcessContext> processFactory;
    protected DefaultProcessDefinition<ImportProcessContext> processDefinition;
    protected String                                serviceId;
    protected SampleLayoutIO                        sampleLayoutIO;
    protected StringWriter                          errorLog;

    protected CsvReaderConfiguration                csvReaderConfiguration;
    protected LayoutServiceLocator                  serviceLocator;
    protected SampleLayoutImportService             layoutImportService;

    protected ThrowableEventQueueFactoryImpl        eventQueueFactory;
    protected ImportLayoutServiceExecutionStage     importLayoutServiceExecution;
    protected InitImportProcessStage initCsvImportProcessStage;
    protected CreateCsvRecordIteratorStage createCsvRecordIteratorStage;
    protected IterateRecordsStage iterateCsvRecordsStage;
    protected ReadLayoutFromAbstractRecordStage readLayoutFromCsvRecordStage;
    protected ValidateLayoutStage                   validateLayoutStage;
    protected ProcessContextAggregatorImpl processAggregator;
    protected ImportProcessContextIterationConditionImpl iterationCondition;
    protected ImportProcessContextFactoryImpl importProcessContextFactory;


    @Before
    public void setup() throws IOException {
        processFactory                  =   new ImportProcessBuilderFactoryImpl<ImportProcessContext>();
        processDefinition               =   new DefaultProcessDefinition<ImportProcessContext>();
        serviceId                       =   "sampleLayoutServiceId";
        sampleLayoutIO                  =   new SampleLayoutIO(100000);
        errorLog                        =   new StringWriter();

        eventQueueFactory               =   new ThrowableEventQueueFactoryImpl();
        csvReaderConfiguration          =   new CsvReaderConfiguration();
        serviceLocator                  =   createMock(LayoutServiceLocator.class);
        layoutImportService             =   createMock(SampleLayoutImportService.class);
        
        importLayoutServiceExecution    =   new ImportLayoutServiceExecutionStage();
        initCsvImportProcessStage       =   new InitImportProcessStage();
        initCsvImportProcessStage           .setServiceLocator(serviceLocator);
        iterateCsvRecordsStage          =   new IterateRecordsStage();
        createCsvRecordIteratorStage    =   new CreateCsvRecordIteratorStage();        
        createCsvRecordIteratorStage.setCsvReaderConfiguration(csvReaderConfiguration);
        readLayoutFromCsvRecordStage    =   new ReadLayoutFromAbstractRecordStage();
        validateLayoutStage             =   new ValidateLayoutStage();
        processAggregator               =   new ProcessContextAggregatorImpl();
        iterationCondition              =   new ImportProcessContextIterationConditionImpl();
        importProcessContextFactory     =   new ImportProcessContextFactoryImpl();
        importProcessContextFactory.setEventQueueFactory(eventQueueFactory);

        processDefinition.setProcessContextFactory(importProcessContextFactory);
        processDefinition.setProcessBuilderFactory(processFactory);
        processFactory.setAggregator(processAggregator);
        processFactory.setImportRecordsStage(importLayoutServiceExecution);
        processFactory.setInitializeProcessStage(initCsvImportProcessStage);
        processFactory.setCreateRecordsIteratorStage(createCsvRecordIteratorStage);
        processFactory.setIterateRecordsStage(iterateCsvRecordsStage);
        processFactory.setNumberOfWorkers(10);
        processFactory.setConvertRecordsStage(readLayoutFromCsvRecordStage);
        processFactory.setValidateRecordsStage(validateLayoutStage);
        processFactory.setIterationCondition(iterationCondition);

    }

    @Test
    public void testImportData() throws Exception{
        expect(serviceLocator.lookupImportLayoutService(serviceId)).andReturn(layoutImportService);        
        layoutImportService.importLayout(TestUtils.evalArg(new Condition<SampleLayout>(){
            public boolean evaluate(SampleLayout argument) {                                
                return argument!=null;
            }
        }));
        expectLastCall().times((int)sampleLayoutIO.getRecordNumbers());

        replayAll();
        ImportProcessContext context=processDefinition.execute(sampleLayoutIO.getReader(),serviceId,errorLog);
        System.out.println(errorLog.toString());
        verifyAll();

        assertNotNull(context);
        ProcessOutcome outcome=context.getProcessOutcome();
        assertNotNull(outcome);
        assertTrue(outcome.getProcessed()==sampleLayoutIO.getRecordNumbers());        
        assertTrue(outcome.getSuccessful()==sampleLayoutIO.getRecordNumbers());
        assertTrue(outcome.getFailures()==0);
        assertTrue(outcome.getExceptionsFired()==0);
        assertTrue(outcome.getInterrupted()==0);
        assertTrue(errorLog.toString().trim().length()==0);
    }
}
