package integration.process.definition;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessOutcome;
import com.monsanto.eas.cia.integration.process.definition.ProcessContextAggregatorImpl;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 08:00:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessContextAggregatorImpl_UT {
    protected ProcessContextAggregatorImpl aggregator;
    protected ProcessContext                        context;
    protected ProcessContext[]                      newContexts;
    protected ProcessOutcome                        outcome;
    @Before
    public void setup(){
        context         =   new ProcessContext();
        outcome         =   new ProcessOutcome();
        context             .setProcessOutcome(outcome);
        aggregator      =   new ProcessContextAggregatorImpl();
        newContexts     =   new ProcessContext[]{
            context.clone(),
            context.clone(),
            context.clone(),
            context.clone()
        };
    }

    @Test
    public void testProcessOutcomeCreated(){
        context.setProcessOutcome(null);
        newContexts=null;
        aggregator.aggregateContexts(context,newContexts);
        assertNotNull(context.getProcessOutcome());
    }

    @Test
    public void testSuccessful(){
        aggregator.aggregateContexts(context,newContexts);
        assertEquals(newContexts.length,outcome.getSuccessful());
    }

    @Test
    public void testInterrupted(){
        for(ProcessContext newContext:newContexts){
            newContext.setInterrupted(true);
        }
        aggregator.aggregateContexts(context,newContexts);
        assertEquals(newContexts.length,outcome.getInterrupted());
    }

    @Test
    public void testException(){
        for(ProcessContext newContext:newContexts){
            newContext.setExceptionFired(true);
        }
        aggregator.aggregateContexts(context,newContexts);
        assertEquals(newContexts.length,outcome.getExceptionsFired());
    }

    @Test
    public void testFailure(){
        for(ProcessContext newContext:newContexts){
            newContext.setExceptionFired(true);
            newContext.setInterrupted(true);
        }
        aggregator.aggregateContexts(context,newContexts);
        assertEquals(newContexts.length,outcome.getFailures());
    }

    @Test
    public void testProcessHalted(){
        newContexts[0].halt();
        newContexts[0].setExceptionFired(true);
        newContexts[0].setInterrupted(true);
        newContexts[1].setExceptionFired(true);
        newContexts[2].setInterrupted(true);        
        aggregator.aggregateContexts(context,newContexts);
        assertTrue(context.isHalted());
        assertEquals(1,outcome.getExceptionsFired());
        assertEquals(1,outcome.getFailures());
        assertEquals(1,outcome.getInterrupted());
        assertEquals(1,outcome.getSuccessful());
    }


}



