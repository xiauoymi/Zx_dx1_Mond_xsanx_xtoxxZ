package integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.eip.Pipeline;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.classextension.EasyMock.*;  

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 9/02/2011
 * Time: 04:28:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class Pipeline_UT extends EasyMockSupport {

    IMocksControl   control;
    Pipeline        pipeline;
    ProcessStage    stage1;
    ProcessStage    stage2;
    ProcessStage    stage3;
    ProcessContext  context;

    @Before
    public void setup(){
        control     =   createStrictControl();        
        context     =   control.createMock(ProcessContext.class);
        stage1      =   control.createMock(ProcessStage.class);
        stage2      =   control.createMock(ProcessStage.class);
        stage3      =   control.createMock(ProcessStage.class);
        pipeline    =   new Pipeline(stage1,stage2,stage3);
    }

    @Test
    public void testPipeline(){
        expect(context.isInterrupted()).andReturn(false);
        stage1.process(context);
        expect(context.isInterrupted()).andReturn(false).times(2);
        stage2.process(context);
        expect(context.isInterrupted()).andReturn(false).times(2);
        stage3.process(context);
        expect(context.isInterrupted()).andReturn(false);
        assertPipelineExecution();
    }

    @Test
    public void testExceptionInPipeline(){
        expect(context.isInterrupted()).andReturn(false);
        stage1.process(context);
        expectLastCall().andThrow(new RuntimeException());
        context.fireException(notNull());
        expect(context.isInterrupted()).andReturn(true);
        context.setInterrupted(false);
        assertPipelineExecution();
    }

    public void assertPipelineExecution(){
        replayAll();
        pipeline.process(context);
        verifyAll();
    }
}
