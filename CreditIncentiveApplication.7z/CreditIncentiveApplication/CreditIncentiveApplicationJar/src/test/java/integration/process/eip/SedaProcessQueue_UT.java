package integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.eip.SedaProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandler;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistryImpl;
import integration.util.MessageSender;
import org.easymock.classextension.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 09:50:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class SedaProcessQueue_UT extends EasyMockSupport {

    int capacity;
    int consumers;
    SedaProcessQueue queue;
    ProcessContext context;
    ProcessEventHandlerRegistry registry;
    @Before
    public void setup(){
        consumers=1;
        capacity =1;
        registry=new ProcessEventHandlerRegistryImpl();
        queue =new SedaProcessQueue(consumers, capacity,registry);
        context= new ProcessContext();
    }

    @Test
    public void testQueueLifecycle() throws Exception {
        assertTrue(queue.getProcessEventHandlerRegistry()==registry);
        assertTrue(queue.getConsumers()==consumers);
        assertTrue(queue.getCapacity()== capacity);

        final String stringMessage="Hello world!";
        final ProcessEventHandler<String>stringEventHandler=createMock(ProcessEventHandler.class);
        stringEventHandler.start();
        stringEventHandler.handleEvent(stringMessage,context);
        stringEventHandler.close();

        final Integer integerMessage=7;
        final ProcessEventHandler<Integer>integerEventHandler=createMock(ProcessEventHandler.class);
        integerEventHandler.start();
        integerEventHandler.handleEvent(integerMessage,context);
        integerEventHandler.close();

        replayAll();

        queue.getProcessEventHandlerRegistry().addProcessEventHandler(String.class,stringEventHandler);
        queue.getProcessEventHandlerRegistry().addProcessEventHandler(Integer.class,integerEventHandler);

        CountDownLatch latch=new CountDownLatch(2);

        new MessageSender(latch){
            public void execute() {
                queue.send(integerMessage,context);
            }
        };

        new MessageSender(latch){
            public void execute() {
                queue.send(stringMessage,context);
            }
        };

        latch.await();
        queue.shutdown();
        verifyAll();
    }    
}
