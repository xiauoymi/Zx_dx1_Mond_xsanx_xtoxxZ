package integration.process.eip;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import com.monsanto.eas.cia.integration.process.eip.Pipeline;
import com.monsanto.eas.cia.integration.process.eip.Splitter;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.util.Condition;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.classextension.EasyMock.expect;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 10:39:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class Splitter_UT extends EasyMockSupport{

    protected IMocksControl                 control;
    protected Splitter<ProcessContext>      splitter;
    protected ProcessContext                context;
    protected int                           numberOfConcurrentWorkers;
    protected ProcessStage<ProcessContext>  iteratorStage;
    protected Condition<ProcessContext>     iterateWhile;
    protected Pipeline<ProcessContext>      pipeline;
    protected Aggregator                    aggregator;

    @Before
    public void setup(){
        splitter                    =   new Splitter<ProcessContext>();
        control                     =   createStrictControl();
        context                     =   control.createMock(ProcessContext.class);
        iteratorStage               =   control.createMock(ProcessStage.class);
        iterateWhile                =   control.createMock(Condition.class);
        pipeline                    =   control.createMock(Pipeline.class);
        aggregator                  =   control.createMock(Aggregator.class);
        numberOfConcurrentWorkers   =   0;
        assertSplitterConfiguration();
    }

    public void assertSplitterConfiguration(){
        assertTrue(splitter.iterationCondition(iterateWhile)==splitter);
        assertTrue(splitter.getIterationCondition()==iterateWhile);
        assertTrue(splitter.iteratorStage(iteratorStage)==splitter);
        assertNotNull(splitter.getIteratorStage());
        assertTrue(splitter.parallelProcessing(1)==splitter);
        assertTrue(splitter.getConcurrentWorkers()==2);
        assertTrue(splitter.parallelProcessing(numberOfConcurrentWorkers)==splitter);
        assertTrue(splitter.getConcurrentWorkers()==numberOfConcurrentWorkers);
        assertTrue(splitter.pipeline(pipeline)==splitter);
        assertTrue(splitter.getPipelineStage()==pipeline);
        assertTrue(splitter.aggregator(aggregator)==splitter);
        assertTrue(splitter.getAggregator()==aggregator);
    }

    @Test
    public void testSplittingProcess(){
        expect(context.isInterrupted()).andReturn(false).times(2);
        iteratorStage.process(context);
        for(int i=0;i<7;i++){
            expect(context.isInterrupted()).andReturn(false);
            expect(iterateWhile.evaluate(context)).andReturn(true);
            expect(context.clone()).andReturn(context);
            pipeline.process(context);
            aggregator.aggregateContexts(context,context);
            expect(context.isInterrupted()).andReturn(false);
            iteratorStage.process(context);    
        }
        expect(context.isInterrupted()).andReturn(false);
        expect(iterateWhile.evaluate(context)).andReturn(false);
    }

    @Test
    public void testInterruptWhileSplitting(){
        expect(context.isInterrupted()).andReturn(false).times(2);
        iteratorStage.process(context);
        for(int i=0;i<7;i++){
            expect(context.isInterrupted()).andReturn(false);
            expect(iterateWhile.evaluate(context)).andReturn(true);
            expect(context.clone()).andReturn(context);
            pipeline.process(context);
            aggregator.aggregateContexts(context,context);
            expect(context.isInterrupted()).andReturn(false);
            iteratorStage.process(context);
        }
        expect(context.isInterrupted()).andReturn(true);
    }


    @Test
    public void testInterruptBeforeSplitting(){
        expect(context.isInterrupted()).andReturn(false).times(2);
        iteratorStage.process(context);
        expect(context.isInterrupted()).andReturn(true);
    }

    @Test
    public void testAtTheBeginning(){
        expect(context.isInterrupted()).andReturn(true);
    }

    @After
    public void assertSplitterExecution(){
        replayAll();
        splitter.process(context);
        verifyAll();
    }
}
