package integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.eip.Aggregator;
import com.monsanto.eas.cia.integration.process.eip.Pipeline;
import com.monsanto.eas.cia.integration.process.event.PipelineProcessEventHandler;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 03:29:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class PipelineProcessEventHandler_UT extends EasyMockSupport {

    IMocksControl               control;
    Pipeline                    pipeline;
    Aggregator                  aggregator;
    ProcessContext              context;
    ProcessContext              newContext;
    PipelineProcessEventHandler eventHandler;

    @Before
    public void setup(){
        control         =   createStrictControl();
        pipeline        =   control.createMock(Pipeline.class);
        aggregator      =   control.createMock(Aggregator.class);
        context         =   control.createMock(ProcessContext.class);
        newContext      =   control.createMock(ProcessContext.class);
        eventHandler    =   new PipelineProcessEventHandler<ProcessContext>(pipeline,aggregator);   
    }

    @Test
    public void testConfiguration(){
        assertTrue(eventHandler.getPipelineStage()  ==  pipeline);
        assertTrue(eventHandler.getAggregator()     ==  aggregator);
    }

    @Test
    public void testHandleEvent(){
        pipeline.process(newContext);
        aggregator.aggregateContexts(context,newContext);
        assertEventHandlerExecution();
    }

    @Test
    public void testMissingPipeline(){
        eventHandler    =   new PipelineProcessEventHandler<ProcessContext>(null,aggregator);
        assertEventHandlerExecution();
    }

    @Test
    public void testMissingAggregator(){
        eventHandler    =   new PipelineProcessEventHandler<ProcessContext>(pipeline,null);
        pipeline.process(newContext);
        assertEventHandlerExecution();
    }

    public void assertEventHandlerExecution(){
        replayAll();
        eventHandler.handleEvent(newContext,context);
        verifyAll();
    }
}
