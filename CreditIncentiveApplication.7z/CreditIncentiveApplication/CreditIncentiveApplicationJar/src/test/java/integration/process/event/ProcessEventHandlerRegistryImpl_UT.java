package integration.process.event;

import com.monsanto.eas.cia.integration.process.event.ProcessEventHandler;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistryImpl;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 01:12:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEventHandlerRegistryImpl_UT extends EasyMockSupport {
    ProcessEventHandlerRegistryImpl processEventHandlerRegistry;

    @Before
    public void setup(){
        processEventHandlerRegistry=new ProcessEventHandlerRegistryImpl();
    }

    @Test
    public void testRemoveAll() throws IOException{
        ProcessEventHandler<Object> objectEventHandler      = assertProcessEventHandler(Object.class);
        ProcessEventHandler<Collection> collectionEventHandler  = assertProcessEventHandler(Collection.class);
        ProcessEventHandler<Set>        setEventHandler         = assertProcessEventHandler(Set.class);
        ProcessEventHandler<SortedSet>  sortedSetEventHandler   = assertProcessEventHandler(SortedSet.class);
        assertTrue(processEventHandlerRegistry.size()==4);
        processEventHandlerRegistry.removeAllProcessEventHandlers();
        assertTrue(processEventHandlerRegistry.size()==0);
    }

    @Test
    public void testHandlerLifecycle() throws IOException{
        ProcessEventHandler<Object> handler=createMock(ProcessEventHandler.class);
        handler.start();
        handler.close();
        replayAll();
        processEventHandlerRegistry.addProcessEventHandler(Object.class,handler);
        processEventHandlerRegistry.removeProcessEventHandler(Object.class);
        verifyAll();
    }

    @Test
    public void testAddRemoveHandler() throws IOException {
        ProcessEventHandler<Object> objectEventHandler      = assertProcessEventHandler(Object.class);
        ProcessEventHandler<Collection> collectionEventHandler  = assertProcessEventHandler(Collection.class);
        ProcessEventHandler<Set>        setEventHandler         = assertProcessEventHandler(Set.class);
        ProcessEventHandler<SortedSet>  sortedSetEventHandler   = assertProcessEventHandler(SortedSet.class);

        assertTrue(objectEventHandler     ==    getHandler(Object.class));
        assertTrue(collectionEventHandler ==    getHandler(Collection.class));
        assertTrue(setEventHandler        ==    getHandler(Set.class));
        assertTrue(sortedSetEventHandler  ==    getHandler(SortedSet.class));

        assertTrue(objectEventHandler     ==    getHandler(String.class));
        assertTrue(collectionEventHandler ==    getHandler(List.class));
        assertTrue(setEventHandler        ==    getHandler(LinkedHashSet.class));
        assertTrue(sortedSetEventHandler  ==    getHandler(TreeSet.class));

        removeHandler(SortedSet.class);
        assertTrue(setEventHandler     ==    getHandler(SortedSet.class));
        assertTrue(setEventHandler     ==    getHandler(TreeSet.class));

        removeHandler(Set.class);
        assertTrue(collectionEventHandler ==    getHandler(Set.class));
        assertTrue(collectionEventHandler ==    getHandler(SortedSet.class));
        assertTrue(collectionEventHandler ==    getHandler(LinkedHashSet.class));
        assertTrue(collectionEventHandler ==    getHandler(Set.class));
        assertTrue(collectionEventHandler ==    getHandler(TreeSet.class));

        removeHandler(Collection.class);
        assertTrue(objectEventHandler     ==    getHandler(Collection.class));
        assertTrue(objectEventHandler     ==    getHandler(Set.class));
        assertTrue(objectEventHandler     ==    getHandler(SortedSet.class));
        assertTrue(objectEventHandler     ==    getHandler(List.class));
        assertTrue(objectEventHandler     ==    getHandler(LinkedHashSet.class));
        assertTrue(objectEventHandler     ==    getHandler(Set.class));
        assertTrue(objectEventHandler     ==    getHandler(TreeSet.class));

        removeHandler(Object.class);
        assertTrue(null     ==    getHandler(Object.class));
        assertTrue(null     ==    getHandler(Collection.class));
        assertTrue(null     ==    getHandler(Set.class));
        assertTrue(null     ==    getHandler(SortedSet.class));
        assertTrue(null     ==    getHandler(List.class));
        assertTrue(null     ==    getHandler(LinkedHashSet.class));
        assertTrue(null     ==    getHandler(Set.class));
        assertTrue(null     ==    getHandler(TreeSet.class));
    }

    public <T> ProcessEventHandler<T> assertProcessEventHandler(Class<T> _class) throws IOException{
        ProcessEventHandler<T> handler=createNiceMock(ProcessEventHandler.class);
        processEventHandlerRegistry.addProcessEventHandler(_class,handler);
        return handler;
    }

    public ProcessEventHandler<?> getHandler(Class<?> _class){
        ProcessEventHandler<?> handler= processEventHandlerRegistry.getProcessEventHandler(_class);
        return handler;
    }

    public void removeHandler(Class<?> _class){
        processEventHandlerRegistry.removeProcessEventHandler(_class);
    }
}
