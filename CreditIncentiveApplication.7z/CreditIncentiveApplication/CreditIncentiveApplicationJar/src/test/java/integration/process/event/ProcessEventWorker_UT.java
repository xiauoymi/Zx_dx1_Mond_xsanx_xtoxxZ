package integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandler;
import com.monsanto.eas.cia.integration.process.event.ProcessEventHandlerRegistry;
import com.monsanto.eas.cia.integration.process.event.ProcessEventWorker;
import org.easymock.EasyMockSupport;
import org.easymock.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 01:23:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEventWorker_UT extends EasyMockSupport {

    IMocksControl               control;
    ProcessContext              context;
    ProcessEvent                event;
    ProcessEventHandler<Object> handler;
    ProcessEventHandlerRegistry registry;
    ProcessEventWorker          worker;
    Integer                     payload;

    @Before
    public void setup(){
        control =   createStrictControl();
        context =   new ProcessContext();
        payload =   new Integer(7);
        event   =   new ProcessEvent(payload,context);
        handler =   control.createMock(ProcessEventHandler.class);
        registry=   control.createMock(ProcessEventHandlerRegistry.class);
        worker  =   new ProcessEventWorker(event,registry);
    }

    @Test
    public void testConstructor(){
        assertTrue(worker.getProcessEvent()==event);
        assertTrue(worker.getProcessEventHandlerRegistry()==registry);
        assertTrue(worker.compareTo(new ProcessEventWorker(event,registry))==0);
    }

    @Test
    public void testSuccessfulRun(){
        registry.getProcessEventHandler(Integer.class);
        expectLastCall().andReturn(handler);
        handler.handleEvent(payload,context);
        assertWorkerRun();
    }

    @Test
    public void testNoHandler(){
        registry.getProcessEventHandler(Integer.class);
        expectLastCall().andReturn(null);        
        assertWorkerRun();
    }

    @Test
    public void testNoRegistry(){
        worker  =   new ProcessEventWorker(event,null);
        assertWorkerRun();
    }

    @Test
    public void testNoEvent(){
        worker  =   new ProcessEventWorker(null,registry);
        assertWorkerRun();
    }

    @Test
    public void testNoInput(){
        worker  =   new ProcessEventWorker(null,null);
        assertWorkerRun();
    }


    public void assertWorkerRun(){
        replayAll();
        worker.run();
        verifyAll();
    }

}
