package integration.process.event;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 08:42:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessEvent_UT {

    ProcessContext  context;
    Object          payload;

    @Before
    public void setup(){
        payload=new Object();
        context=new ProcessContext();
    }

    @Test
    public void testProcessEvent(){
        ProcessEvent processEvent=new ProcessEvent(payload,context);
        assertTrue(processEvent.getPayload()==payload);
        assertTrue(processEvent.getProcessContext()==context);
        assertEquals(processEvent.getPriority(),ProcessEvent.NORMAL_PRIORITY);

        assertTrue(processEvent.setPriority(ProcessEvent.HIGH_PRIORITY)==processEvent);
        assertEquals(processEvent.getPriority(),ProcessEvent.HIGH_PRIORITY);
    }

    @Test(expected = RuntimeException.class)
    public void testMalformedPayload(){
        new ProcessEvent(null,context);
    }

    @Test
    public void testOptionalContext(){
        new ProcessEvent(payload,null);
    }
}
