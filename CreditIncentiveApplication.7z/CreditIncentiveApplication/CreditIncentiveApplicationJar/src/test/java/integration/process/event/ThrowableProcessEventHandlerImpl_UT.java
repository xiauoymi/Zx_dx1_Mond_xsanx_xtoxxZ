package integration.process.event;

import com.monsanto.eas.cia.integration.format.exception.ParseRecordException;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIteratorException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.exception.GenericTypeException;
import com.monsanto.eas.cia.integration.process.exception.ProcessStageException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 09:31:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ThrowableProcessEventHandlerImpl_UT extends WriterProcessEventHandlerImpl_UT{

    ProcessContext context;
    @Before
    public void setup() throws IOException {
        super.setup();
        context=new ProcessContext();
    }

    @Test
    public void testAbstractLayoutException(){
        assertWrittenException(new ParseRecordException("Invalid double field",new RuntimeException(),0,0,Double.class));
    }

    @Test
    public void testCsvRecordIteratorException(){
        assertWrittenException(new CsvRecordIteratorException(new NullPointerException(),1,new String[]{"field"}));
    }

    @Test
    public void testGenericTypeException(){
        assertWrittenException(new GenericTypeException(ThrowableProcessEventHandlerImpl_UT.class));
    }

    @Test
    public void testLayoutServiceLocatorException(){
        assertWrittenException(new LayoutServiceLocatorException(new NullPointerException(),"service-id",Double.class));
    }

    @Test
    public void testProcessStageException(){
        assertWrittenException(new ProcessStageException());
    }

    public void assertWrittenException(Throwable throwable){
        handler.handleEvent(throwable,context);
        String message=writer.toString().trim();
        System.out.println(message);        
        assertTrue(message.length()>0);
    }
}
