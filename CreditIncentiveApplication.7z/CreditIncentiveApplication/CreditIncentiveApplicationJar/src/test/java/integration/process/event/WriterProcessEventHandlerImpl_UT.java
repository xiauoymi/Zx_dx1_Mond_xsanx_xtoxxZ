package integration.process.event;

import com.monsanto.eas.cia.integration.process.event.ThrowableEventHandlerImpl;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.ResourceBundle;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 08:53:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class WriterProcessEventHandlerImpl_UT{
    protected ThrowableEventHandlerImpl       handler;
    protected StringWriter                    writer;
    protected ResourceBundle                  bundle;
    protected boolean                         closed;

    @Before
    public void setup() throws IOException {
        handler=new ThrowableEventHandlerImpl();
        closed=false;
        handler.setWriter(writer=new StringWriter(){
            public void close() throws IOException{
                super.close();
                WriterProcessEventHandlerImpl_UT.this.closed=true;
            }
        });

        handler.setBundle(bundle=ResourceBundle.getBundle("layout"));
        handler.start();
    }

    @Test
    public void testPrintln(){
        String message="hello";
        handler.println(message);
        assertMessageWritten(message);
    }

    @Test
    public void testEmptyPrintln(){
        handler.println(null);
        assertMessageWritten("");                
    }

    @Test
    public void testBundleln(){
        String bundleKey="bundle.value";
        String argument = "Hello world!";
        String message= MessageFormat.format(bundle.getString(bundleKey),argument);
        handler.bundleln(bundleKey,argument);
        assertMessageWritten(message);
    }

    @Test
    public void testInvalidBundleln(){
        handler.bundleln(null);
        assertMessageWritten("");
        handler.bundleln("bin.laden.sucks");
        assertMessageWritten("");
    }

    @Test
    public void testClose(){
        assertFalse(closed);
        handler.close();
        assertTrue(closed);        
    }

    public void assertMessageWritten(String message){
        if(message==null){fail();return;}
        assertEquals(writer.toString().trim(),message.trim());
    }



}


