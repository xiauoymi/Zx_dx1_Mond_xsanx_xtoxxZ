package integration.process.exec;

import com.monsanto.eas.cia.integration.process.exec.BatchExportProcessMain;
import integration.util.Resource;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 29/03/2011
 * Time: 07:52:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchExportProcessMain_UT {
    static Properties properties;

    @BeforeClass
    public static void setup(){
        properties= Resource.getProperties("configuration.properties");
    }

    @Test
    public void testExportData() throws Exception{
        String configurationFile=properties.getProperty("export.configuration.file");        
        StringBuilder cliBuilder=new StringBuilder().append("-configuration ").append(configurationFile);
        String[]	cliArguments=cliBuilder.toString().split("\\s+");
        BatchExportProcessMain.main(cliArguments);
    }

}
