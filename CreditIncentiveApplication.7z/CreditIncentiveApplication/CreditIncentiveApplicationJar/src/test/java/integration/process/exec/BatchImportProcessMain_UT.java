package integration.process.exec;

import com.monsanto.eas.cia.integration.process.exec.BatchImportProcessMain;
import integration.util.Resource;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 23/03/2011
 * Time: 11:29:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchImportProcessMain_UT {

    static Properties properties;

    @BeforeClass
    public static void setup(){
        properties= Resource.getProperties("configuration.properties");
    }

    @Test
    public void testImportData() throws Exception{
        String configurationFile=properties.getProperty("import.configuration.file");        
        StringBuilder cliBuilder=new StringBuilder().append("-configuration ").append(configurationFile);
        String[]	cliArguments=cliBuilder.toString().split("\\s+");
        BatchImportProcessMain.main(cliArguments);
    }        
}
