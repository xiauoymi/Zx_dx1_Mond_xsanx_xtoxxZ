package integration.process.exec;

import com.monsanto.eas.cia.integration.process.exec.ExportProcessMain;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 05:04:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportProcessMain_UT {

    ExportProcessMain exportProcessMain;

    @Before
    public void setup(){
        exportProcessMain=new ExportProcessMain("export-process");    
    }

    @Test
    public void testCommandLineArguments() throws Exception{
        assertCommandLineArguments(true,"-processId csvExportProcessDefinition -serviceId export-local-dealer-service -outputFile output.csv -errorLog errors.log","export-local-dealer-service");
        assertCommandLineArguments(true,"-processId csvExportProcessDefinition -serviceId export-local-dealer-service -outputFile output.csv","export-local-dealer-service");
        assertCommandLineArguments(true,"-processId csvExportProcessDefinition -serviceId export-local-dealer-service","export-local-dealer-service");
        assertCommandLineArguments(false,"-processId csvExportProcessDefinition",null);
        assertCommandLineArguments(false,"-serviceId export-local-dealer-service",null);
    }

    public void assertCommandLineArguments(boolean assertion,String  commandLine, String serviceId) throws IOException {
        String[]arguments=commandLine.split("\\s");
        if(assertion){
            assertTrue(exportProcessMain.commandLineInput(arguments));
            assertEquals(exportProcessMain.getExportLayoutServiceId(),serviceId);
            assertNotNull(exportProcessMain.getProcessDefinition());
            assertNotNull(exportProcessMain.getOutputWriter());
            assertNotNull(exportProcessMain.getErrorLog());
        }
        else
            assertFalse(exportProcessMain.commandLineInput(arguments));
    }
}
