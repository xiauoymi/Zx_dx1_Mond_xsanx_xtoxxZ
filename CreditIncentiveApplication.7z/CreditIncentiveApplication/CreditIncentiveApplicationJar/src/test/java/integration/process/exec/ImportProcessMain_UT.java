package integration.process.exec;

import com.monsanto.eas.cia.integration.process.exec.ImportProcessMain;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 05:18:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImportProcessMain_UT {
    ImportProcessMain importProcessMain;

    @Before
    public void setup(){
        importProcessMain=new ImportProcessMain("import-process");
    }

    @Test
    public void testCommandLineArguments() throws Exception{        
        assertCommandLineArguments(false,"-processId csvImportProcessDefinition",null);
    }
    
    public void assertCommandLineArguments(boolean assertion,String  commandLine, String serviceId) throws IOException {
        String[]arguments=commandLine.split("\\s");
        if(assertion){
            assertTrue(importProcessMain.commandLineInput(arguments));
            assertEquals(importProcessMain.getImportLayoutServiceId(),serviceId);
            assertNotNull(importProcessMain.getProcessDefinition());
            //assertNotNull(importProcessMain.getInputReader());
            //assertNotNull(importProcessMain.getErrorLog());
        }
        else
            assertFalse(importProcessMain.commandLineInput(arguments));
    }
    
    
}
