package integration.process.exec;

import com.monsanto.eas.cia.integration.process.contract.ProcessDefinition;
import com.monsanto.eas.cia.integration.process.exec.ProcessMainContext;
import org.apache.commons.cli.OptionBuilder;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 04:55:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessMainContext_UT {

    @Test
    public void testProcessMainContext(){
        ProcessMainContext context=new ProcessMainContext("main-context","applicationContext-standalone.xml");
        context.addOption(
            OptionBuilder.withArgName( "beanId" )
                            .isRequired()
                            .hasArg()
                            .withDescription("The id of a bean implementing the interface ProcessDefinition")
                            .create("processId")
        );
        assertTrue(context.commandLineInput("-processId","csv-import-process-definition"));
        ProcessDefinition importProcess=context.getServiceFromOptionName("processId", ProcessDefinition.class);
        assertNotNull(importProcess);        
        assertTrue(context.commandLineInput("-processId","csv-export-process-definition"));
        ProcessDefinition exportProcess=context.getServiceFromOptionName("processId", ProcessDefinition.class);
        assertNotNull(exportProcess);
    }
}
