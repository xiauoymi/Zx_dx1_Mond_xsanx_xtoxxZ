package integration.process.stage;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.stage.ProcessStageWorker;
import org.easymock.classextension.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 09:54:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessStageWorker_UT extends EasyMockSupport {

    protected ProcessStage<ProcessContext> stage;
    protected ProcessContext context;
    protected CountDownLatch latch;

    @Before
    public void setup(){
        context=new ProcessContext();
        stage=createMock(ProcessStage.class);
        latch=new CountDownLatch(1);
    }

    @Test
    public void testConstructor(){
        assertProcessStageWorkerConstructor();
    }

    @Test
    public void testRun() throws Exception{
        ProcessStageWorker<ProcessContext>  worker=assertProcessStageWorkerConstructor();
        stage.process(context);
        replayAll();
        worker.run();
        verifyAll();
        latch.await();
    }

    public ProcessStageWorker<ProcessContext> assertProcessStageWorkerConstructor(){
        ProcessStageWorker<ProcessContext> stageWorker=new ProcessStageWorker<ProcessContext>(stage,context,latch);
        assertNotNull(stageWorker.getProcessStage());
        assertTrue(stageWorker.getContext()==context);
        assertTrue(stageWorker.getDoneSignal()==latch);
        return stageWorker;
    }

}
