package integration.process.stage;

import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.exception.ProcessStageException;
import com.monsanto.eas.cia.integration.process.contract.ProcessStage;
import com.monsanto.eas.cia.integration.process.stage.ReliableProcessStage;
import com.monsanto.eas.cia.integration.util.Condition;
import org.easymock.classextension.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.classextension.EasyMock.*;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.evalArg;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 10:25:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReliableProcessStage_UT extends EasyMockSupport {
    ProcessStage stage;
    ProcessContext context;
    ReliableProcessStage reliableStage;

    @Before
    public void setup(){
        stage=createMock(ProcessStage.class);
        context=createMock(ProcessContext.class);
    }

    @Test
    public void testReliableProcessStageConstructor(){
        assertReliableProcessStageConstructor();
    }

    @Test
    public void testReliableProcessStageExecution(){
        reliableStage=assertReliableProcessStageConstructor();
        expect(context.isInterrupted()).andReturn(false);
        stage.process(context);
        assertReliableProcessStageExecution();
    }

    @Test
    public void testReliableProcessStageExecution_ContextInterrupted(){
        reliableStage=assertReliableProcessStageConstructor();
        expect(context.isInterrupted()).andReturn(true);        
        assertReliableProcessStageExecution();
    }

    @Test
    public void testReliableProcessStageExecution_NullContext(){
        reliableStage=assertReliableProcessStageConstructor();
        context=null;
        assertReliableProcessStageExecution();
    }

    @Test
    public void testReliableProcessStageExecution_NullProcessStage(){
        reliableStage=new ReliableProcessStage(null);                   
        expect(context.isInterrupted()).andReturn(false);        
        context.fireFatalException(evalArg(new Condition<ProcessStageException>(){
            public boolean evaluate(ProcessStageException argument) {
                return argument!=null;
            }
        }));
        assertReliableProcessStageExecution();
    }

    @Test
    public void testReliableProcessStageExecution_AnyExceptionProcessingDelegate(){
        reliableStage=assertReliableProcessStageConstructor();
        expect(context.isInterrupted()).andReturn(false);
        stage.process(context);
        expectLastCall().andThrow(new RuntimeException());
        context.fireException(evalArg(new Condition<Exception>(){
            public boolean evaluate(Exception argument) {
                return argument!=null;
            }
        }));
        assertReliableProcessStageExecution();
    }

    public void assertReliableProcessStageExecution(){
        replayAll();
        reliableStage.process(context);
        verifyAll();
    }

    public ReliableProcessStage assertReliableProcessStageConstructor(){
        ReliableProcessStage reliableStage=new ReliableProcessStage(stage);
        assertTrue(reliableStage.getProcessStage()==stage);
        return reliableStage;
    }
    
}
