package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.stage.impl.ExportLayoutServiceExecutionStage;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 11:41:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExportLayoutServiceExecutionStage_UT extends EasyMockSupport {
    ExportLayoutServiceExecutionStage exportStage;
    CsvExportProcessContext             context;
    ExportLayoutService                 exportLayoutService;
    Object[]                            entities;
    Collection<Layout>                  layouts;

    @Before
    public void setup(){
        exportStage         =   new ExportLayoutServiceExecutionStage();
        context             =   new CsvExportProcessContext();
        exportLayoutService =   createMock(ExportLayoutService.class);
        context.setExportLayoutService(exportLayoutService);
        entities            =   new Object[]{};
        context.setEntities(entities);
        layouts             =   new ArrayList<Layout>();
    }

    @Test
    public void testExecution(){
        expect(exportLayoutService.exportLayouts(entities)).andReturn(layouts);
        replayAll();
        exportStage.process(context);
        verifyAll();
        assertTrue(context.getLayouts()==layouts);
    }



}
