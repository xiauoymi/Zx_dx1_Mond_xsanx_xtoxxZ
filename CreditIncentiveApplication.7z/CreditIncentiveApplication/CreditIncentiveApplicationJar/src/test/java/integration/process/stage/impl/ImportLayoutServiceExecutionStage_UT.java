package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceException;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceExceptionCode;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.stage.impl.ImportLayoutServiceExecutionStage;
import com.monsanto.eas.cia.integration.util.Condition;
import integration.layout.definition.SampleLayout;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.assertTrue;
import static util.TestUtils.evalArg;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 04:53:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImportLayoutServiceExecutionStage_UT extends EasyMockSupport {
    ImportLayoutService                 importLayoutService;
    SampleLayout                        sampleLayout;
    ImportLayoutServiceExecutionStage   executionStage;
    ImportProcessContext context;
    ProcessQueue                        eventQueue;
    String[]                            fields;

    @Before
    public void setup(){
        eventQueue          =   createMock(ProcessQueue.class);
        context             =   new ImportProcessContext(eventQueue);
        importLayoutService =   createMock(ImportLayoutService.class);
        sampleLayout        =   new SampleLayout();
        executionStage      =   new ImportLayoutServiceExecutionStage();
        fields              =   new String[]{};
        context                 .setImportLayoutService(importLayoutService);
        context                 .setLayout(sampleLayout);
    }

    @Test
    public void testExecution(){
        importLayoutService.importLayout(sampleLayout);
        assertProcessStageExecution();
    }

    @Test
    public void testLayoutServiceException(){
        LayoutServiceException exception=LayoutServiceExceptionCode.EXCEPTION.get();
        importLayoutService.importLayout(sampleLayout);
        expectLastCall().andThrow(exception);
        eventQueue.send(exception,context, ProcessEvent.NORMAL_PRIORITY);
        assertProcessStageExecution();
        assertTrue(context.isExceptionFired());
        assertTrue(context.isInterrupted());
        assertTrue(exception.getLayout()==sampleLayout);
    }

    @Test
    public void testAnyException(){
        importLayoutService.importLayout(sampleLayout);
        final RuntimeException runtimeException=new RuntimeException();
        expectLastCall().andThrow(runtimeException);
        eventQueue.send(
            evalArg(new Condition<LayoutServiceException>(){
                public boolean evaluate(LayoutServiceException exception) {
                    assertTrue(exception.getCause()==runtimeException);
                    assertTrue(exception.getLayout()==sampleLayout);            
                    return true;
                }
            }),
            evalArg(new Condition<ProcessContext>(){
                public boolean evaluate(ProcessContext argument) {
                    return argument==context;
                }
            }),
            evalArg(new Condition<Integer>(){
                public boolean evaluate(Integer argument) {
                    return new Integer(ProcessEvent.NORMAL_PRIORITY).equals(argument);
                }
            },0)
        );
        assertProcessStageExecution();
        assertTrue(context.isExceptionFired());
        assertTrue(context.isInterrupted());
    }

    public void assertProcessStageExecution(){
        replayAll();
        executionStage.process(context);
        verifyAll();        
    }
}
