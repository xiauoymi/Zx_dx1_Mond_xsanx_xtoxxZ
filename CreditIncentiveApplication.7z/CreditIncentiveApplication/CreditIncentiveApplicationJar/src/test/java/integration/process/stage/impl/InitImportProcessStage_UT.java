package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.contract.ImportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.exception.GenericTypeException;
import com.monsanto.eas.cia.integration.process.stage.impl.InitImportProcessStage;
import integration.layout.definition.SampleLayout;
import integration.layout.service.AbstractImportLayoutService;
import integration.layout.service.SampleLayoutImportService;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 11:03:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class InitImportProcessStage_UT extends EasyMockSupport{

    LayoutServiceLocator            serviceLocator;
    InitImportProcessStage initProcessStage;
    ImportProcessContext context;
    ProcessQueue                    eventQueue;
    SampleLayoutImportService       layoutService;
    AbstractImportLayoutService     abstractLayoutService;
    @Before
    public void setup(){
        abstractLayoutService   =   createMock(AbstractImportLayoutService.class);
        layoutService           =   createMock(SampleLayoutImportService.class);
        eventQueue              =   createMock(ProcessQueue.class);
        context                 =   new ImportProcessContext(eventQueue);
        serviceLocator          =   createMock(LayoutServiceLocator.class);
        initProcessStage        =   new InitImportProcessStage();
        initProcessStage            .setServiceLocator(serviceLocator);
        context.setServiceId("service-id");
    }

    @Test
    public void testSuccessfulProcess(){
        expect(serviceLocator.lookupImportLayoutService(context.getServiceId())).andReturn(layoutService);

        assertNull(context.getImportLayoutService());
        assertNull(context.getValidator());
        assertNull(context.getImportLayoutType());

        replayAll();
        initProcessStage.process(context);
        verifyAll();
        assertNotNull(context.getImportLayoutService());
        assertNotNull(context.getValidator());
        assertNotNull(context.getImportLayoutType());

        assertTrue(context.getImportLayoutType()== SampleLayout.class);
        assertTrue(context.getImportLayoutService()==layoutService);        
    }

    @Test
    public void testNoServiceFound(){
        expect(serviceLocator.lookupImportLayoutService(context.getServiceId())).andReturn(null);

        replayAll();
        try{
            initProcessStage.process(context);
            fail();
        }
        catch(LayoutServiceLocatorException layoutServiceException){
            assertTrue(layoutServiceException.getServiceId()==context.getServiceId());
            assertTrue(layoutServiceException.getServiceClass()== ImportLayoutService.class);
        }
        verifyAll();
    }

    @Test
    public void testGenericTypeException(){
        expect(serviceLocator.lookupImportLayoutService(context.getServiceId())).andReturn(abstractLayoutService);
        replayAll();
        try{
            initProcessStage.process(context);
            fail();
        }
        catch(GenericTypeException genericTypeException){
            assertTrue(genericTypeException.getGenericType()==abstractLayoutService.getClass());
        }
        verifyAll();
    }
}
