package integration.process.stage.impl;

import com.monsanto.eas.cia.dao.CriteriaDao;
import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.stage.impl.IterateDbRecordsStage;
import org.easymock.EasyMockSupport;
import org.easymock.IMocksControl;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 11:08:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class IterateDbRecordsStage_UT extends EasyMockSupport {

    IMocksControl control;
    CsvExportProcessContext     context;
    ProcessQueue                processQueue;
    CriteriaDao                 criteriaDao;
    ExportLayoutService         exportLayoutService;
    ScrollableResults           scrollableResults;
    IterateDbRecordsStage       iteratorStage;
    Object[]                    entities;
    long                        recordNumber;


    @Before
    public void setup(){
        control             =   createStrictControl();
        processQueue        =   createMock(ProcessQueue.class);
        context             =   new CsvExportProcessContext(processQueue);
        exportLayoutService =   control.createMock(ExportLayoutService.class);
        context.setExportLayoutService(exportLayoutService);
        criteriaDao         =   control.createMock(CriteriaDao.class);
        iteratorStage       =   new IterateDbRecordsStage();
        iteratorStage.setDao(criteriaDao);
        scrollableResults   =   control.createMock(ScrollableResults.class);
        entities            =   new Object[]{};
        assertConfiguration();
    }

    @Test
    public void testFirstExecution(){
        recordNumber=0;
        context.setScrollableResults(null);
        expect(criteriaDao.getScrollableResults(exportLayoutService, ScrollMode.FORWARD_ONLY)).andReturn(scrollableResults);
        expect(scrollableResults.next()).andReturn(true);
        expect(scrollableResults.get()).andReturn(entities);
        criteriaDao.synchronize(recordNumber,iteratorStage.getSynchronizeOnNumberOfRecords());
        assertStageAndContext();
    }

    @Test
    public void testWhileIterating(){
        recordNumber=100;
        context.setRecordNumber(recordNumber);
        context.setScrollableResults(scrollableResults);
        expect(scrollableResults.next()).andReturn(true);
        expect(scrollableResults.get()).andReturn(entities);
        criteriaDao.synchronize(++recordNumber,iteratorStage.getSynchronizeOnNumberOfRecords());
        assertStageAndContext();
    }

    @Test
    public void testReachIteratorEnd(){
        recordNumber=101;
        entities=null;
        context.setRecordNumber(recordNumber);
        context.setScrollableResults(scrollableResults);
        expect(scrollableResults.next()).andReturn(false);
        criteriaDao.synchronize(iteratorStage.getSynchronizeOnNumberOfRecords(),iteratorStage.getSynchronizeOnNumberOfRecords());
        scrollableResults.close();
        assertStageAndContext();
    }

    @Test
    public void testException(){
        recordNumber=0;
        context.setScrollableResults(null);
        RuntimeException runtimeException=new RuntimeException();
        expect(criteriaDao.getScrollableResults(exportLayoutService, ScrollMode.FORWARD_ONLY)).andThrow(runtimeException);
        processQueue.send(runtimeException,context, ProcessEvent.URGENT_PRIORITY);
        assertIterateStage();
    }

    public void assertStageAndContext(){
        assertIterateStage();
        assertTrue(context.getEntities()==entities);
        assertTrue(context.getRecordNumber()==recordNumber);
        assertTrue(context.getScrollableResults()==scrollableResults);
    }

    public void assertConfiguration(){
        iteratorStage.setSynchronizeOnNumberOfRecords(0);
        assertTrue(iteratorStage.getSynchronizeOnNumberOfRecords()==100);
        iteratorStage.setSynchronizeOnNumberOfRecords(1);
        assertTrue(iteratorStage.getSynchronizeOnNumberOfRecords()==1);
        assertTrue(iteratorStage.getDao()==criteriaDao);
    }

    public void assertIterateStage(){
        replayAll();
        iteratorStage.process(context);
        verifyAll();
    }
}
