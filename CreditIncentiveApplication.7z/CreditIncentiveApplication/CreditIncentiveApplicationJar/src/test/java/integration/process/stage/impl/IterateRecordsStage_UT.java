package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.format.csv.*;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.stage.impl.IterateRecordsStage;
import com.monsanto.eas.cia.integration.util.Condition;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import static org.junit.Assert.*;
import static util.TestUtils.evalArg;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 01:22:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class IterateRecordsStage_UT extends EasyMockSupport {
    ImportProcessContext context;
    ProcessQueue                    eventQueue;
    CsvReaderConfiguration          csvReaderConfiguration;
    CsvWriterConfiguration          csvWriterConfiguration;
    StringReader                    reader;
    int                             numberOfRecords;
    IterateRecordsStage iterateCsvRecordsStage;

    @Before
    public void setup() throws IOException {
        eventQueue              =   createMock(ProcessQueue.class);
        context                 =   new ImportProcessContext(eventQueue);
        csvReaderConfiguration  =   new CsvReaderConfiguration();
        csvWriterConfiguration  =   new CsvWriterConfiguration();
        reader                  =   new StringReader(writeSampleRecords());
        context.setIterator(new CsvRecordIterator(csvReaderConfiguration,reader).start());
        context.setReader(reader);
        iterateCsvRecordsStage  =   new IterateRecordsStage();
    }    

    @Test
    public void testExecution(){
        for(int i=0;i<=numberOfRecords;i++){
            iterateCsvRecordsStage.process(context);
            assertNotNull(context.getIterator());

            if(i<numberOfRecords){
                assertNotNull(context.getAbstractRecord());
                assertTrue(context.getAbstractRecord().getRecordNumber()==i);
            }
            else{
                assertNull(context.getAbstractRecord());
            }
        }
    }

    @Test
    public void testExceptionFired(){
        context.setIterator(null);
        eventQueue.send(
            evalArg(new Condition<RuntimeException>(){
                public boolean evaluate(RuntimeException argument) {
                    return argument!=null;
                }
            }),
            evalArg(new Condition<ProcessContext>(){
                public boolean evaluate(ProcessContext argument) {
                    return argument==context;
                }
            }),
            evalArg(new Condition<Integer>(){
                public boolean evaluate(Integer argument) {
                    return new Integer(ProcessEvent.URGENT_PRIORITY).equals(argument);
                }
            },0)
        );
        replayAll();
        iterateCsvRecordsStage.process(context);
        verifyAll();
        assertNull(context.getIterator());
        assertNull(context.getAbstractRecord());
        assertTrue(context.isHalted());
        assertTrue(context.isExceptionFired());
        assertTrue(context.isInterrupted());
    }


    public String writeSampleRecords() throws IOException{
        numberOfRecords =   0;
        StringWriter    writer  =   new StringWriter();
        String [][]     records =   new String[][]{
            {"Field1","Field2","Field3"},
            {"Field1","Field2","Field3"},
            {"Field1","Field2","Field3"}
        };

        CsvWriter csvWriter=csvWriterConfiguration.createCsvWriter(writer);
        for(String[]record:records){
            csvWriter.writeNext(record);
            numberOfRecords++;
        }
        csvWriter.flush();
        csvWriter.close();
        return writer.toString();
    }        
}
