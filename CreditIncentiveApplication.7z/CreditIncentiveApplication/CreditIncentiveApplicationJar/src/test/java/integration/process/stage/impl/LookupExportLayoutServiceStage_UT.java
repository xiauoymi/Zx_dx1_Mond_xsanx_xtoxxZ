package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.contract.ExportLayoutService;
import com.monsanto.eas.cia.integration.layout.contract.LayoutServiceLocator;
import com.monsanto.eas.cia.integration.layout.exception.LayoutServiceLocatorException;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.stage.impl.LookupExportLayoutServiceStage;
import integration.layout.definition.SampleLayout;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.classextension.EasyMock.expect;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 12:48:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class LookupExportLayoutServiceStage_UT extends EasyMockSupport {
    IMocksControl                   control;
    String                          serviceId;
    ProcessQueue                    eventQueue;
    CsvExportProcessContext         context;
    ExportLayoutService             exportLayoutService;
    LayoutServiceLocator            serviceLocator;
    LayoutServiceLocatorException   layoutServiceLocatorException;
    LookupExportLayoutServiceStage  lookupServiceStage;

    @Before
    public void setup(){
        control     =   createStrictControl();
        serviceId   =   "serviceId";
        eventQueue  =   control.createMock(ProcessQueue.class);
        context     =   new CsvExportProcessContext(eventQueue);
        context.setServiceId(serviceId);
        exportLayoutService =   control.createMock(ExportLayoutService.class);
        serviceLocator      =   control.createMock(LayoutServiceLocator.class);
        layoutServiceLocatorException=new LayoutServiceLocatorException(null,serviceId, SampleLayout.class);
        lookupServiceStage=new LookupExportLayoutServiceStage();
        lookupServiceStage.setServiceLocator(serviceLocator);
    }

    @Test
    public void testExecution(){
        expect(serviceLocator.lookupExportLayoutService(context.getServiceId())).andReturn(exportLayoutService);
        assertLookupServiceStageExecution();
    }

    @Test
    public void testLayoutServiceException(){
        expect(serviceLocator.lookupExportLayoutService(context.getServiceId())).andThrow(layoutServiceLocatorException);
        eventQueue.send(layoutServiceLocatorException,context, ProcessEvent.URGENT_PRIORITY);        
        assertLookupServiceStageExecution();
        assertTrue(context.isHalted());
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
    }

    public void assertLookupServiceStageExecution(){
        replayAll();
        lookupServiceStage.process(context);
        verifyAll();        
    }
}
