package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.format.csv.CsvReaderConfiguration;
import com.monsanto.eas.cia.integration.format.csv.CsvRecord;
import com.monsanto.eas.cia.integration.format.csv.CsvRecordIterator;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.stage.impl.ReadLayoutFromAbstractRecordStage;
import integration.layout.definition.SampleLayout;
import org.junit.Before;
import org.junit.Test;

import java.io.StringReader;
import java.util.Date;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 03:53:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class ReadLayoutFromAbstractRecordStage_UT {
    ReadLayoutFromAbstractRecordStage readLayoutStage;
    ImportProcessContext context;
    CsvReaderConfiguration          csvReaderConfiguration;
    CsvWriterConfiguration          csvWriterConfiguration;
    CsvRecord                       csvRecord;
    SampleLayout                    sampleLayout;
    @Before
    public void setup(){
        readLayoutStage         =   new ReadLayoutFromAbstractRecordStage();
        context                 =   new ImportProcessContext();
        csvReaderConfiguration  =   new CsvReaderConfiguration();
        csvWriterConfiguration  =   new CsvWriterConfiguration();
        sampleLayout            =   new SampleLayout();
        setupCsvRecord();
        context.setAbstractRecord(csvRecord);
        context.setImportLayoutType(SampleLayout.class);
    }

    @Test
    public void testExecution(){
        assertNull(context.getLayout());


        readLayoutStage.process(context);

        assertTrue(context.getLayout() instanceof SampleLayout);
        assertTrue(csvRecord.getRecordNumber()==context.getRecordNumber());
    }

    public void setupCsvRecord(){
        sampleLayout.setBooleanValue(true);
        sampleLayout.setDateValue(new Date());
        sampleLayout.setDecimalValue(77.7777);
        sampleLayout.setIntegerValue(7);
        sampleLayout.setStringValue("Hello world!");
        StringReader reader=new StringReader(csvWriterConfiguration.formatLayout(sampleLayout));
        CsvRecordIterator iterator=new CsvRecordIterator(csvReaderConfiguration,reader);
        iterator.start();
        csvRecord=(CsvRecord)iterator.next();
    }
}
