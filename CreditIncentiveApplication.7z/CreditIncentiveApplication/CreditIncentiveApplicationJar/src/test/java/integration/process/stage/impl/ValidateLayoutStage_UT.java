package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.layout.exception.LayoutValidatorException;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.stage.impl.ValidateLayoutStage;
import integration.layout.definition.SampleLayout;
import org.easymock.classextension.EasyMockSupport;
import org.hibernate.validator.ClassValidator;
import org.hibernate.validator.InvalidValue;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 11/02/2011
 * Time: 04:28:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidateLayoutStage_UT extends EasyMockSupport {
    SampleLayout                    layout              =   null;
    ClassValidator                  validator           =   null;
    ImportProcessContext context             =   null;
    ValidateLayoutStage             validateLayoutStage =   null;
    
    @Before
    public void setup(){
        layout      =   new SampleLayout();
        validator   =   createMock(ClassValidator.class);
        context     =   new ImportProcessContext();
        context.setLayout(layout);
        context.setValidator(validator);
        context.setRecordNumber(10);        
        validateLayoutStage=new ValidateLayoutStage();
    }

    @Test
    public void testExecution(){
        InvalidValue[] invalidValues=new InvalidValue[]{};
        expect(validator.getInvalidValues(context.getLayout())).andReturn(invalidValues);
        replayAll();
        validateLayoutStage.process(context);
        verifyAll();
    }

    @Test
    public void testException(){
        InvalidValue[] invalidValues=new InvalidValue[]{
            new InvalidValue("Something failed",SampleLayout.class,"booleanValue",null,layout)
        };
        expect(validator.getInvalidValues(context.getLayout())).andReturn(invalidValues);
        replayAll();
        try{
            validateLayoutStage.process(context);
            fail();
        }
        catch(LayoutValidatorException lve){
            assertTrue(lve.getLayout()==context.getLayout());
            assertTrue(lve.getRecordNumber()==context.getRecordNumber());
            assertTrue(lve.getInvalidValues()==invalidValues);
        }
        verifyAll();
    }


}
