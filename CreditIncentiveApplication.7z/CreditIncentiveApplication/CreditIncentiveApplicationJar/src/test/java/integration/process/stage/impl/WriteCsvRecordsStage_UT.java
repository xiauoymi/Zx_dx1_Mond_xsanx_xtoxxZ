package integration.process.stage.impl;

import com.monsanto.eas.cia.integration.contract.Layout;
import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import com.monsanto.eas.cia.integration.process.context.CsvExportProcessContext;
import com.monsanto.eas.cia.integration.process.contract.ProcessQueue;
import com.monsanto.eas.cia.integration.process.event.ProcessEvent;
import com.monsanto.eas.cia.integration.process.stage.impl.WriteCsvRecordsStage;
import integration.layout.definition.SampleLayout;
import org.easymock.classextension.EasyMockSupport;
import org.easymock.classextension.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;

import static org.easymock.classextension.EasyMock.expect;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 11:47:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class WriteCsvRecordsStage_UT extends EasyMockSupport {

    IMocksControl           control;
    ProcessQueue            eventQueue;
    CsvExportProcessContext context;
    CsvWriterConfiguration  csvWriterConfiguration;
    CsvWriter               csvWriter;
    SampleLayout            sampleLayout;
    Collection<Layout>      layouts;
    Object[]                entities;
    StringWriter            writer;
    String[]                fields;
    WriteCsvRecordsStage    writeCsvRecordsStage;

    @Before
    public void setup(){
        control                 =   createStrictControl();
        eventQueue              =   control.createMock(ProcessQueue.class);
        context                 =   new CsvExportProcessContext(eventQueue);
        csvWriterConfiguration  =   control.createMock(CsvWriterConfiguration.class);
        csvWriter               =   control.createMock(CsvWriter.class);
        sampleLayout            =   new SampleLayout();
        layouts                 =   new ArrayList<Layout>();
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        layouts.add(sampleLayout);
        context.setLayouts(layouts);
        entities                =   new Object[]{};
        context.setEntities(entities);
        writer                  =   new StringWriter();
        context.setWriter(writer);
        fields =   new String[]{"field1","field2"};
        writeCsvRecordsStage    =   new WriteCsvRecordsStage();
        writeCsvRecordsStage.setCsvWriterConfiguration(csvWriterConfiguration);
    }

    @Test
    public void testFirstExecution() throws Exception{
        context.setCsvWriter(null);
        expect(csvWriterConfiguration.createCsvWriter(writer)).andReturn(csvWriter);
        for(int i=0;i<layouts.size();i++){
            expect(csvWriterConfiguration.fromLayout(sampleLayout)).andReturn(fields);
            csvWriter.writeNext(fields);                
        }
        assertWriteCsvRecordsExecutionStageAndContext();
    }


    @Test
    public void testIteratingExecution() throws Exception{
        context.setCsvWriter(csvWriter);        
        for(int i=0;i<layouts.size();i++){
            expect(csvWriterConfiguration.fromLayout(sampleLayout)).andReturn(fields);
            csvWriter.writeNext(fields);
        }
        assertWriteCsvRecordsExecutionStageAndContext();
    }

    @Test
    public void testReachedIterationEnd() throws Exception{
        context.setCsvWriter(csvWriter);
        context.setLayouts(null);
        context.setEntities(null);
        csvWriter.flush();
        csvWriter.close();
        assertWriteCsvRecordsExecutionStageAndContext();
    }

    @Test
    public void testException() throws Exception{
        context.setCsvWriter(csvWriter);
        RuntimeException runtimeException=new RuntimeException();
        expect(csvWriterConfiguration.fromLayout(sampleLayout)).andThrow(runtimeException);
        eventQueue.send(runtimeException,context, ProcessEvent.URGENT_PRIORITY);
        assertWriteCsvRecordsExecutionStage();
        assertTrue(context.isHalted());
        assertTrue(context.isInterrupted());
        assertTrue(context.isExceptionFired());
    }

    public void assertWriteCsvRecordsExecutionStageAndContext(){
        assertWriteCsvRecordsExecutionStage();
        assertNull(context.getLayouts());
        assertTrue(context.getCsvWriter()==csvWriter);
    }

    public void assertWriteCsvRecordsExecutionStage(){
        replayAll();
        writeCsvRecordsStage.process(context);
        verifyAll();
    }
}
