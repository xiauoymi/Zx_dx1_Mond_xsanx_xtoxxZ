package integration.util;

import com.monsanto.eas.cia.integration.util.ClassHierarchyType;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;


/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 8/02/2011
 * Time: 04:03:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class ClassHierarchyType_UT {
    Map<ClassHierarchyType, Integer> map;
    PriorityQueue<ClassHierarchyType> queue;
    Class<?>[] types=null;
    @Before
    public void setup(){
        map=new HashMap<ClassHierarchyType, Integer>();
        queue= new PriorityQueue<ClassHierarchyType>();
        types=new Class<?>[]{
            ClassHierarchyTypeException.class,
            RuntimeException.class,
            Exception.class,
            Throwable.class,
            Object.class
        };
        for(Class<?> _type:types){
            addClassHierarchyType(_type);
        }
    }

    public void addClassHierarchyType(Class<?> _type){
        ClassHierarchyType type=new ClassHierarchyType(_type);
        Integer priority=type.getPriority();
        map.put(type,priority);
        queue.add(type);
    }

    public Integer getPriority(Class<?> _class){
        return map.get(new ClassHierarchyType(_class));
    }


    @Test
    public void testClassHierarchyTypeAsKey(){
        assertTrue(getPriority(Object.class)==0);
        assertTrue(getPriority(Throwable.class)>0);
        assertTrue(getPriority(Exception.class)>0);
        assertTrue(getPriority(RuntimeException.class)>0);
        assertTrue(getPriority(ClassHierarchyTypeException.class)>0);
        assertNull(getPriority(ClassHierarchyType_UT.class));
    }

    @Test
    public void testClassAssigns(){
        assertClassAssignment(Object.class,Object.class);
        assertClassAssignment(String.class,Object.class);
        assertClassAssignment(Collection.class, Collection.class);
        assertClassAssignment(List.class, Collection.class);
        assertClassAssignment(Set.class, Set.class);
        assertClassAssignment(LinkedHashSet.class, Set.class);
        assertClassAssignment(SortedSet.class, SortedSet.class);
        assertClassAssignment(TreeSet.class, SortedSet.class);
    }

    public void assertClassAssignment(Class<?> _class, Class<?> _type){
        assertTrue(new ClassHierarchyType(_type).classCanBeAssigned(_class));        
    }


    @Test
    public void testClassHierarchyTypeIteration(){
        int i=0;
        for(ClassHierarchyType type:queue){
            assertNotNull(type.getType());
            assertTrue(type.getType()==types[i++]);
        }
    }

    public static class ClassHierarchyTypeException extends RuntimeException{

    }

}
