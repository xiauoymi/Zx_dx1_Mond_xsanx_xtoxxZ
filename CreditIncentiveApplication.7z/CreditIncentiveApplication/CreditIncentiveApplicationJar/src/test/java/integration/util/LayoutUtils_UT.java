package integration.util;

import com.monsanto.eas.cia.integration.layout.definition.*;
import com.monsanto.eas.cia.integration.layout.service.*;
import com.monsanto.eas.cia.integration.util.LayoutUtils;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 8/02/2011
 * Time: 02:29:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class LayoutUtils_UT {

    @Test
    public void testLayoutObjects(){
        assertLayout(new CodeDescriptionLayout());
        assertLayout(new InputSalesLayout());
        assertLayout(new LocalDealerLayout());
        assertLayout(new OutputSalesLayout());
        assertLayout(new InputProductLayout());
        assertFalse(LayoutUtils.isLayout(this));
    }
    @Test
    public void testLayoutClasses(){
        assertLayout(CodeDescriptionLayout.class);
        assertLayout(InputSalesLayout.class);
        assertLayout(LocalDealerLayout.class);
        assertLayout(OutputSalesLayout.class);
        assertLayout(InputProductLayout.class);
        assertFalse(LayoutUtils.isLayout(LayoutUtils_UT.class));        
    }

    @Test
    public void testGenericTypeIsLayout(){        
        assertGenericTypeLayout(new ExportLocalDealerServiceImpl(), LocalDealerLayout.class);
        assertGenericTypeLayout(new ExportSalesServiceImpl(), OutputSalesLayout.class);
        assertGenericTypeLayout(new ImportSapDistributorServiceImpl(), CodeDescriptionLayout.class);
    }

    @Test
    public void testGetFieldPosition() throws Exception{
        Integer position=LayoutUtils.getFieldPosition(InputProductLayout.class.getDeclaredField("sapId"));
        assertNotNull(position);
        assertTrue(position==1);

        /*
        position=LayoutUtils.getFieldPosition(InputProductLayout.class.getDeclaredField("ltConversionFactor"));
        assertNotNull(position);
        assertTrue(position==8);
        */

    }

    @Test
    public void testGetBundleValue(){
        assertEquals("do not remove {0}",LayoutUtils.getBundleValue("bundle.value"));    
    }

    public void assertLayout(Class<?> _class){
        assertTrue(LayoutUtils.isLayout(_class));
    }

    public void assertLayout(Object layout){
        assertTrue(LayoutUtils.isLayout(layout));
    }

    public void assertGenericTypeLayout(Object object, Class<?> _class){
        assertTrue(LayoutUtils.isGenericTypeLayout(object));
        assertTrue(LayoutUtils.getLayoutGenericType(object)==_class);
    }
}

