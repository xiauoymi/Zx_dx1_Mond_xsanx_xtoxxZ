package integration.util;

import java.util.concurrent.CountDownLatch;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 05:24:07 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class MessageSender extends Thread{
    CountDownLatch latch;
    public MessageSender(CountDownLatch latch) {
        setPriority(Thread.MAX_PRIORITY);
        this.latch=latch;
        start();
    }

    public final void run(){
        try{
            execute();
        }
        finally{
            latch.countDown();
        }
    }

    public abstract void execute();
}
