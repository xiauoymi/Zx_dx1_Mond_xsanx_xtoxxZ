package integration.util;

import com.monsanto.eas.cia.integration.layout.definition.*;
import com.monsanto.eas.cia.integration.layout.service.*;
import com.monsanto.eas.cia.integration.process.context.ImportProcessContext;
import com.monsanto.eas.cia.integration.process.event.ThrowableEventHandlerImpl;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import org.junit.Test;

import static com.monsanto.eas.cia.integration.util.ObjectUtils.absOrValue;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 8/02/2011
 * Time: 11:17:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObjectUtils_UT {
    @Test
    public void testGetGenericTypes(){
        assertGenericType(new ExportLocalDealerServiceImpl(), LocalDealerLayout.class);
        assertGenericType(new ExportSalesServiceImpl(), OutputSalesLayout.class);
        assertGenericType(new ImportSapDistributorServiceImpl(), CodeDescriptionLayout.class);
        assertGenericType(new ThrowableEventHandlerImpl(),Throwable.class);
        failGenericType(this);
        failGenericType(new Object());
    }

    @Test
    public void testCopySourceInto(){
        ImportProcessContext context = new ImportProcessContext();
        String[]fields={"a","b","c"};
        //Property declared by this class
        //Inherited property
        context.setExceptionFired(true);
        ImportProcessContext newContext = new ImportProcessContext();
        ObjectUtils.copySourceInto(context,newContext);
        assertTrue(context.isExceptionFired()==newContext.isExceptionFired());
    }

    @Test
    public void testAbsOrValue(){
        assertTrue(absOrValue(-10,0,1)==10);
        assertTrue(absOrValue(0,0,1)==1);
        assertTrue(absOrValue(1,0,1)==1);
        assertTrue(absOrValue(-1,0,1)==1);
        assertTrue(absOrValue(2,0,1)==2);

        assertTrue(absOrValue(-10,1)==10);
        assertTrue(absOrValue(0,1)==1);
        assertTrue(absOrValue(1,1)==1);
        assertTrue(absOrValue(-1,1)==1);
        assertTrue(absOrValue(2,1)==2);
    }

    public void assertGenericType(Object object, Class<?> _class){
        assertTrue(ObjectUtils.getGenericType(object.getClass(),_class)!=null);
    }

    public void failGenericType(Object object){
        assertTrue(ObjectUtils.getGenericType(object.getClass(),Object.class)==null);
    }

}
