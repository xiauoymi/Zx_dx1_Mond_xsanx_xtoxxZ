package integration.util;

import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 24/03/2011
 * Time: 06:12:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class Resource {
    public static Properties getProperties(String resource){
        // file . properties
        if(resource==null)return new Properties();
        resource=resource.trim();
        resource=resource.replaceAll("\\s*\\.\\s*","/");
        resource=resource.toLowerCase().endsWith("/properties")?resource.substring(0,resource.length()-"/properties".length()):resource;
        resource=resource+".properties";
        resource=resource.startsWith("/")?resource.substring(1):resource;
        try{
            return PropertiesLoaderUtils.loadAllProperties(resource,Thread.currentThread().getContextClassLoader());
        }
        catch(Exception e){
            throw new RuntimeException(e);   
        }
    }
}
