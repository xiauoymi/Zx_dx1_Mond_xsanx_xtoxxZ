package integration.util;

import com.monsanto.eas.cia.integration.format.csv.CsvWriter;
import com.monsanto.eas.cia.integration.format.csv.CsvWriterConfiguration;
import integration.layout.definition.SampleLayout;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 09:19:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SampleLayoutIO {
    protected String contents;
    protected SampleLayout sampleLayout;
    protected long recordNumbers;
    protected CsvWriterConfiguration csvWriterConfiguration;

    public SampleLayoutIO(long recordNumbers) throws IOException{
        sampleLayout    =   new SampleLayout();
        sampleLayout.       setBooleanValue(true);
        sampleLayout.       setDateValue(new Date());
        sampleLayout.       setDecimalValue(-3.1416);
        sampleLayout.       setIntegerValue(-7);
        sampleLayout.       setStringValue("string");
        this.recordNumbers= recordNumbers;
        this.csvWriterConfiguration=new CsvWriterConfiguration();
        generateContents();
    }

    public SampleLayoutIO(SampleLayout sampleLayout, long recordNumbers,CsvWriterConfiguration csvWriterConfiguration){
        this.sampleLayout=sampleLayout;
        this.recordNumbers=recordNumbers;
        this.csvWriterConfiguration=csvWriterConfiguration;
    }

    public StringReader generateContents() throws IOException {
        return generateContents(this.csvWriterConfiguration);
    }

    public StringReader generateContents(CsvWriterConfiguration csvWriterConfiguration) throws IOException {
        StringWriter writer=new StringWriter();
        CsvWriter csvWriter=csvWriterConfiguration.createCsvWriter(writer);
        for(int i=0;i< recordNumbers;i++){
            csvWriter.writeNext(csvWriterConfiguration.fromLayout(sampleLayout));
        }
        csvWriter.flush();
        csvWriter.close();
        contents=writer.toString();
        return getReader();
    }

    public void setSampleLayout(SampleLayout sampleLayout) {
        this.sampleLayout = sampleLayout;
    }

    public SampleLayout getSampleLayout() {
        return sampleLayout;
    }

    public StringReader getReader(){
        return new StringReader(contents);
    }

    public long getRecordNumbers() {
        return recordNumbers;
    }
}
