/*
 Copyright:  Copyright  2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package service;

import com.monsanto.eas.cia.dao.LdSalesDao;
import com.monsanto.eas.cia.integration.process.stage.ReliableProcessStage;
import com.monsanto.eas.cia.model.LdSales;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.service.FinderService;
import com.monsanto.eas.cia.service.LdSalesService;
import com.monsanto.eas.cia.service.LdSalesServiceImpl;
import integration.layout.service.AbstractImportLayoutService;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.junit.Assert.assertTrue;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class LdSalesServiceImpl_UT extends EasyMockSupport {
  private LdSalesServiceImpl ldSalesService;
  private FinderService finderService;
  private LdSalesDao ldSalesDao;
  private List<LdSales> ldSalesList;

  @Before
  public void setUp() throws Exception {
    ldSalesService = new LdSalesServiceImpl();
    finderService = createMock(FinderService.class);
    ldSalesDao = createMock(LdSalesDao.class);
    ldSalesList = new ArrayList<LdSales>();
    ldSalesList.add(new LdSales());
    ldSalesList.add(new LdSales());
  }

  @Test
  public void testUpdate() {
    for (LdSales sale : ldSalesList) {
      ldSalesDao.merge(sale);
      expectLastCall().once();
    }

    //ldSalesService.setLdSalesDao(ldSalesDao);

    replayAll();
    ldSalesService.update(ldSalesList);
    verifyAll();
  }
}