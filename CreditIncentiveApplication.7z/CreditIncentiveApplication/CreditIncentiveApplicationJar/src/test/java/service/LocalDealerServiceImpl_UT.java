package service;

import com.monsanto.eas.cia.dao.LocalDealerDao;
import com.monsanto.eas.cia.model.LocalDealer;
import com.monsanto.eas.cia.service.LocalDealerServiceImpl;
//import org.easymock.EasyMock;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Dec 2, 2010 Time: 2:39:18 PM To change this template use File |
 * Settings | File Templates.
 */
public class LocalDealerServiceImpl_UT {

  private LocalDealerServiceImpl localDealerService;

  private Collection<LocalDealer> localDealers;

  @Before
  public void setUp() throws Exception {
    localDealerService = new LocalDealerServiceImpl();
    localDealers = new ArrayList<LocalDealer>();
    LocalDealer ld1 = new LocalDealer();
    ld1.setId(12);
    localDealers.add(ld1);
    LocalDealer ld2 = new LocalDealer();
    ld2.setId(13);
    localDealers.add(ld2);
  }

  @Test
  public void testLookupAllLocalDealers() {
    /** Create Mocks */
    LocalDealerDao localDealerDaoMock = EasyMock.createNiceMock(LocalDealerDao.class);

    /** Setup expectations on created mocks */
    EasyMock.expect(localDealerDaoMock.lookupAllLocalDealers()).andReturn(localDealers);
    EasyMock.expectLastCall().anyTimes();
    //localDealerService.setLocalDealerDao(localDealerDaoMock);

    EasyMock.replay(localDealerDaoMock);

    assertNotNull(localDealerService.lookupAllLocalDealers());
    assertEquals(2, localDealerService.lookupAllLocalDealers().size());
    Iterator<LocalDealer> iterator = localDealerService.lookupAllLocalDealers().iterator();
    assertEquals(12, iterator.next().getId().intValue());
    assertEquals(13, iterator.next().getId().intValue());

    EasyMock.verify(localDealerDaoMock);
  }

  @Test
  public void testSaveOrUpdate() {

    
//    /** Create Mocks */
//    LocalDealerDao localDealerDaoMock = EasyMock.createNiceMock(LocalDealerDao.class);
//
//    LocalDealer ld = new LocalDealer();
//    ld.setName("Test ld");
//
//    localDealerDaoMock.merge(ld);
//    EasyMock.expectLastCall().anyTimes();
//
//    localDealerService.setLocalDealerDao(localDealerDaoMock);
//
//    EasyMock.replay(localDealerDaoMock);
//
//    EasyMock.verify(localDealerDaoMock);
  }
}
