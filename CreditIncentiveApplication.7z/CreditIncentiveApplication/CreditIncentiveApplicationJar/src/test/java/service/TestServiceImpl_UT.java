package service;

import com.monsanto.eas.cia.service.TestService;
import com.monsanto.eas.cia.service.TestServiceImpl;
import dao.factory.BaseAbstractJpaTests;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Nov 19, 2010 Time: 2:40:56 PM To change this template use File |
 * Settings | File Templates.
 */
public class TestServiceImpl_UT extends BaseAbstractJpaTests {

  @Autowired
  private TestService testService;

  @Test
  public void testLookupAllYears() {
    testService.testMethod();
  }
}
