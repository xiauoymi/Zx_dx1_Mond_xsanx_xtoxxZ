package util;

import com.monsanto.eas.cia.integration.util.Condition;
import org.easymock.IArgumentMatcher;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 12/02/2011
 * Time: 07:38:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class ArgumentMatcher<T> implements IArgumentMatcher {

    Condition<T> condition;

    public ArgumentMatcher(Condition<T> condition){
        this.condition=condition;
    }
    
    public boolean matches(Object argument) {
        return condition!=null&&condition.evaluate((T)argument); 
    }

    public void appendTo(StringBuffer buffer) {
        buffer.append("argumentMatcher()");
    }
}
