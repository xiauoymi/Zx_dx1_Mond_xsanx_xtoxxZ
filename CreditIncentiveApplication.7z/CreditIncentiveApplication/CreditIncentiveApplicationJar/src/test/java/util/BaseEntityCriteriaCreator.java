package util;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.hibernate.Criteria;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 15/02/2011
 * Time: 12:50:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseEntityCriteriaCreator extends DefaultCriteriaCreator<BaseEntity> {
    public void modifyCriteria(Criteria criteria) {
    }
}