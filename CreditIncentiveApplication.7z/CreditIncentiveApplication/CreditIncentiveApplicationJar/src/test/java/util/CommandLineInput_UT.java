package util;

import com.monsanto.eas.cia.util.CommandLineInput;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 14/02/2011
 * Time: 04:46:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommandLineInput_UT {
    protected CommandLineInput commandLineInput;
    protected String processIdValue;
    protected String serviceIdValue;
    protected String outputFileValue;
    protected String errorLogValue; 

    @Before
    public void setup(){
        commandLineInput=new CommandLineInput("input-name");
        Option processId    = OptionBuilder.withArgName( "beanId" )
                                .isRequired()
                                .hasArg()
                                .withDescription("The id of a bean implementing the interface ProcessDefinition")
                                .create("processId");
        commandLineInput.addOption(processId);

        Option serviceId    = OptionBuilder.withArgName( "beanId" )
                                .isRequired()
                                .hasArg()
                                .withDescription("The id of a bean implementing the interface ExportLayoutService")
                                .create("serviceId");
        commandLineInput.addOption(serviceId);

        Option outputFile   = OptionBuilder.withArgName("file")
                                .hasArg()
                                .withDescription("Output of this process execution")
                                .create( "outputFile" );
        commandLineInput.addOption(outputFile);

        Option errorLog      = OptionBuilder.withArgName("logFile")
                                .hasArg()
                                .withDescription("The error log")
                                .create( "errorLog" );
        commandLineInput.addOption(errorLog);

        processIdValue="processIdValue";
        serviceIdValue="serviceIdValue";
        outputFileValue="outputFileValue";
        errorLogValue="errorLogValue";
    }

    @Test
    public void testParseInput(){
        assertTrue(commandLineInput.parseInput("-processId",processIdValue,"-serviceId",serviceIdValue,"-outputFile",outputFileValue,"-errorLog",errorLogValue));
        assertEquals(commandLineInput.getOptionValue("processId",null),processIdValue);
        assertEquals(commandLineInput.getOptionValue("serviceId",null),serviceIdValue);
        assertEquals(commandLineInput.getOptionValue("outputFile",null),outputFileValue);
        assertEquals(commandLineInput.getOptionValue("errorLog",null),errorLogValue);
    }



}
