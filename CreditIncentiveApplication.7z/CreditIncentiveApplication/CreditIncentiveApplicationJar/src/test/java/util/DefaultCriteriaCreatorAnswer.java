package util;

import com.monsanto.eas.cia.integration.util.Condition;
import com.monsanto.eas.cia.integration.util.ObjectUtils;
import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.CriteriaCreator;
import org.easymock.EasyMockSupport;
import org.easymock.IAnswer;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.IdentifierEqExpression;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.getCurrentArguments;
import static util.TestUtils.evalArg;
import static util.TestUtils.objectHasField;

/**
 * Created by IntelliJ IDEA. User: OVEGAGO Date: 15/02/2011 Time: 05:18:28 PM To change this template use File |
 * Settings | File Templates.
 */
public abstract class DefaultCriteriaCreatorAnswer<T> extends EasyMockSupport implements IAnswer<T> {
  protected T answer;
  protected Class<?> _advisedClass;

  public DefaultCriteriaCreatorAnswer(T answer) {
    this.answer = answer;
  }

  public DefaultCriteriaCreatorAnswer(Class<?> _advisedClass, T answer) {
    this(answer);
    this._advisedClass = _advisedClass;
  }

  public abstract void expectations(Criteria criteria);

  public T answer() throws Throwable {
    Session session = createMock(Session.class);
    Criteria criteria = createMock(Criteria.class);
    expectations(criteria);
    Class<T> _class = (Class<T>) (_advisedClass == null ?
        ObjectUtils.getGenericType(this.getClass(), BaseEntity.class) : _advisedClass);
    expect(session.createCriteria(_class)).andReturn(criteria);
    CriteriaCreator criteriaCreator = (CriteriaCreator) getCurrentArguments()[0];
    replayAll();
    criteriaCreator.createCriteria(session);
    verifyAll();
    return answer;
  }

  public SimpleExpression equalsExpression(String name, Object value) {
    return simpleExpression(Restrictions.eq(name, value).toString());
  }

  public Criterion betweenExpression(String name, Object lo, Object hi) {
    return betweenExpression(Restrictions.between(name, lo, hi).toString());
  }

  public IdentifierEqExpression idExpression(Object value) {
    return identifierEqExpression(Restrictions.idEq(value).toString());
  }

  public IdentifierEqExpression identifierEqExpression(final String value) {
    return evalArg(new Condition<IdentifierEqExpression>() {
      public boolean evaluate(IdentifierEqExpression argument) {
        return value != null && value.equals(argument.toString());
      }
    });
  }

  public SimpleExpression simpleExpression(final String value) {
    return evalArg(new Condition<SimpleExpression>() {
      public boolean evaluate(SimpleExpression argument) {
        return value != null && value.equals(argument.toString());
      }
    });
  }

  public Criterion betweenExpression(final String value) {
    return evalArg(new Condition<Criterion>() {
      public boolean evaluate(Criterion argument) {
        return value != null && value.equals(argument.toString());
      }
    });
  }

  public void answerHasField(String property, Class<?> _type) {
    objectHasField(answer, property, _type);
  }


}
