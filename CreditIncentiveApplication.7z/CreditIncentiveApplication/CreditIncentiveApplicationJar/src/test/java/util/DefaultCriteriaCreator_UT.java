package util;

import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.easymock.classextension.EasyMockSupport;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.classextension.EasyMock.expect;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 15/02/2011
 * Time: 12:28:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultCriteriaCreator_UT extends EasyMockSupport {
    Session                             session;
    Criteria                            criteria;
    DefaultCriteriaCreator<BaseEntity>  baseEntityCriteriaCreator;

    @Before
    public void setup(){
        session                 =   createMock(Session.class);
        baseEntityCriteriaCreator =   createMockBuilder(BaseEntityCriteriaCreator.class).
            addMockedMethod("modifyCriteria").
                createMock();
        criteria                =   createMock(Criteria.class);
    }

    @Test
    public void testCreateCriteria(){
        expect(session.createCriteria(BaseEntity.class)).andReturn(criteria);
        baseEntityCriteriaCreator.modifyCriteria(criteria);
        replayAll();
        baseEntityCriteriaCreator.createCriteria(session);
        verifyAll();
    }
}
