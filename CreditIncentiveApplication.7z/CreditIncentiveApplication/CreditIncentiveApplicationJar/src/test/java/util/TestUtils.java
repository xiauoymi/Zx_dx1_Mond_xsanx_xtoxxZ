package util;

import com.monsanto.eas.cia.integration.util.Condition;
import com.monsanto.eas.cia.integration.util.FieldPosition;
import com.monsanto.eas.cia.model.entity.BaseEntity;
import com.monsanto.eas.cia.util.DefaultCriteriaCreator;
import org.apache.commons.lang.ClassUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static org.easymock.EasyMock.reportMatcher;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: OVEGAGO
 * Date: 10/02/2011
 * Time: 04:18:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestUtils {

    public static Method getMethod(Class<?> _class, String name, Class<?> ... argumentTypes){
        try {
            return _class.getDeclaredMethod(name,argumentTypes);
        } catch (NoSuchMethodException e) {
            
        }
        return null;
    }

    public static <T> T newInstance(Class<T> _class){
        try{
            return _class.newInstance();
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }

    public static <T> T evalArg(Condition<T> condition){
        return evalArg(condition,null);
    }

    public static <T> T evalArg(Condition<T> condition, T dummy){
        reportMatcher(new ArgumentMatcher<T>(condition));        
        return dummy;
    }

    public static void objectHasField(Object object, String property, Class<?> _type){
        assertTrue(TestUtils.objectContains(object, property, _type));
    }

    public static void classHasField(Class<?> _class, String property, Class<?> _type){
        assertTrue(TestUtils.classContains(_class,property,_type));
    }    

    public static void layoutHasFieldPosition(Class<?> _class,int position,Class<?>_type,String property){        
        assertTrue(TestUtils.classContains(_class,property,_type,position));
    }

    public static boolean objectContains(Object object, String field, Class<?> _type){
        if(object==null)return false;
        return classContains(object.getClass(),field,_type);
    }

    public static boolean classContains(Class<?> _class, String fieldName, Class<?> _type){
        if(_class==null||fieldName==null||_type==null)return false;
        try{            
            Field _field=_class.getDeclaredField(fieldName);
            return ClassUtils.isAssignable(_field.getType(),_type);            
        }
        catch(Exception e){
            return classContains(_class.getSuperclass(),fieldName,_type);
        }
    }

    public static Map<String,Field> getAllFields(Class<?> _class){
        Map<String,Field> fieldMap=new HashMap<String,Field>();
        findAllFields(_class,fieldMap);
        return fieldMap;
    }

    public static void findAllFields(Class<?> _class,Map<String,Field> fieldMap){
        if(_class==null||_class==Object.class)return;
        Field[] fields=_class.getDeclaredFields();
        for(Field field:fields){
            fieldMap.put(field.getName(),field);
        }
        findAllFields(_class.getSuperclass(),fieldMap);
    }

    public static boolean classContains(Class<?> _class, String fieldName, Class<?> _type, int position){                
        if(_class==null||fieldName==null||_type==null)return false;
        try{            
            Field _field=_class.getDeclaredField(fieldName);
            if(ClassUtils.isAssignable(_field.getType(),_type)){
                FieldPosition fieldPosition=_field.getAnnotation(FieldPosition.class);
                if(fieldPosition!=null){
                    return fieldPosition.value()==position;
                }
            }
            return false;
        }
        catch(Exception e){
            return classContains(_class.getSuperclass(),fieldName,_type);
        }
    }

    public static <T extends BaseEntity> DefaultCriteriaCreator<T> anyDefaultCriteriaCreator(Class<T> _class){
        reportMatcher(new ArgumentMatcher<DefaultCriteriaCreator<T>>(
            new Condition<DefaultCriteriaCreator<T>>(){
                public boolean evaluate(DefaultCriteriaCreator<T> argument) {
                    return argument!=null;
                }
            }
        ));
        return null;
    }
}
