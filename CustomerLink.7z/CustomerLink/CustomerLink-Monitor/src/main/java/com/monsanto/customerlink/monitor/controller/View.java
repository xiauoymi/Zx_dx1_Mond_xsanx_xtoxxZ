package com.monsanto.customerlink.monitor.controller;

public interface View {
    static final String MONITOR = "monitor";
}
