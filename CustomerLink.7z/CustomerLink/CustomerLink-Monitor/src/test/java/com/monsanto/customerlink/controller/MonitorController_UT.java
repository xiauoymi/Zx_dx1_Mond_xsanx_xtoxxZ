package com.monsanto.customerlink.controller;

import com.monsanto.customerlink.monitor.controller.MonitorController;
import com.monsanto.customerlink.monitor.controller.View;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

public class MonitorController_UT {

    private MonitorController controller;

    @Before
    public void setUp() throws Exception {
        controller = new MonitorController();
    }

    @Test
    public void goToHome_returnsNotNull() throws Exception {
        assertNotNull(controller.goToMonitor());
    }

    @Test
    public void goToHome_returnsValidViewName() throws Exception {
        assertEquals(View.MONITOR, controller.goToMonitor().getViewName());
    }
}
