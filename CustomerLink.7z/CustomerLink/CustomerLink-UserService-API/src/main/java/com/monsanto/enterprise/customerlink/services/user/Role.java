package com.monsanto.enterprise.customerlink.services.user;

import com.google.common.base.Predicate;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.xml.bind.annotation.XmlElement;

public final class Role {

    public static final Predicate<Role> ADMIN = new Predicate<Role>() {
        @Override
        public boolean apply(Role role) {
            return role.getRoleDescription().equals("ADMINISTRATOR");
        }
    };

    @XmlElement
    private long userId;
    @XmlElement
    private String roleDescription;
    @XmlElement
    private String subregion;
    @XmlElement
    private String roleCode;

    /*Used by JAX-WS*/
    Role() {

    }

    public Role(long userId, String roleDescription, String subregion, String roleCode) {
        this.userId = userId;
        this.roleDescription = roleDescription;
        this.subregion = subregion;
        this.roleCode = roleCode;
    }

    // simple getters for the properties - no tests needed
    public long getUserId() {
        return userId;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public String getSubregion() {
        return subregion;
    }

    public String getRoleCode() {
        return roleCode;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Role)) {
            return false;
        }
        if (this == o) {
            return true;
        }
        Role oAsRole = (Role) o;
        return new EqualsBuilder()
                .append(userId, oAsRole.userId)
                .append(roleDescription, oAsRole.roleDescription)
                .append(subregion, oAsRole.subregion)
                .append(roleCode,oAsRole.roleCode)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(userId)
                .append(roleDescription)
                .append(subregion)
                .append(roleCode)
                .toHashCode();
    }

    @Override
    public String toString() {
        StringBuilder toStringBuilder = new StringBuilder(getClass().getName());
        toStringBuilder.append(String.format("[userId: %d, roleDescription:\"%s\", subregion:\"%s\"]", userId, roleDescription, subregion));
        return toStringBuilder.toString();
    }
}
