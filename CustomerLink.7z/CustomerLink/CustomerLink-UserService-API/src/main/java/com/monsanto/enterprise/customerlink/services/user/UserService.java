package com.monsanto.enterprise.customerlink.services.user;

import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

@WebService
public interface UserService {

    List<Role> findRolesByUsername(@WebParam(name="username") String username);
}
