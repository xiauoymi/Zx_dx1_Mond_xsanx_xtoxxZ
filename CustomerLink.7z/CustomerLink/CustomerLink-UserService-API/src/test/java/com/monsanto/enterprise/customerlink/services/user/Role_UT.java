package com.monsanto.enterprise.customerlink.services.user;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Test;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class Role_UT {

    @Test
    public void twoRolesAreEqualIfTheUserIdTheRoleDescriptionAndTheSubregionAreAllEqual() {
        Role one = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        Role two = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        assertThat(one, is(equalTo(two)));
    }

    @Test
    public void twoEqualRolesYieldTheSameHashCode() {
        Role one = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        Role two = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        assertThat(one, hasTheSameHashCodeThan(two));
    }

    private Matcher<Object> hasTheSameHashCodeThan(final Object object) {
        return new BaseMatcher<Object>() {

            @Override
            public boolean matches(Object o) {
                return o.hashCode() == object.hashCode();
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("an object whose hash code is ");
                description.appendValue(object.hashCode());
            }

            @Override
            public void describeMismatch(Object item, Description mismatchDescription) {
                mismatchDescription.appendText("was an object whose hash code is ");
                mismatchDescription.appendValue(item.hashCode());
            }
        };
    }

    @Test
    public void toStringReturnsAFullRepresentationOfTheRole() {
        Role role = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        assertThat(role.toString(), is("com.monsanto.enterprise.customerlink.services.user.Role[userId: 1, roleDescription:\"test_roleDescription\", subregion:\"test_subregion\"]"));
        assertNotNull(role.getUserId());
        assertNotNull(role.getSubregion());
        assertNotNull(role.getRoleDescription());
        assertNotNull(role.getRoleCode());
    }

    @Test
    public void equalsReturnsFalseIfNotARole(){
        Role role = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        assertFalse(role.equals(new Object()));
    }

    @Test
    public void equalsReturnsTrueIfItsTheSameObject(){
        Role role = new Role(1l, "test_roleDescription", "test_subregion","test_role_code");
        assertTrue(role.equals(role));
    }
}
