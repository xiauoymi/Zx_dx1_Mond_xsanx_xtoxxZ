package com.monsanto.customerlink.core.batch;

import com.monsanto.customerlink.core.batch.exec.ProcessMain;
import com.monsanto.customerlink.core.service.ProcessAgrementService;
import com.monsanto.customerlink.core.service.ProcessAtpService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

public class BatchProcessMain extends ProcessMain {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public BatchProcessMain(ApplicationContext applicationContext) {
        super(applicationContext);
    }

    public BatchProcessMain() {
    }

    protected void process() {
        if (turnOnBatchProcess("TURN_ON_SEED_BATCH_PROCESS")) {
            getProcessAtpService().processAtp();
        }
        if (turnOnBatchProcess("TURN_ON_AGROCHEMICAL_BATCH_PROCESS")) {
            getProcessAgrementService().processAgreementService();
        }
    }

    protected ProcessAtpService getProcessAtpService() {
        return this.getService(ProcessAtpService.class);
    }

    protected ProcessAgrementService getProcessAgrementService(){
         return this.getService(ProcessAgrementService.class);
    }

    public static void main(String[] args) {
        new BatchProcessMain().process();
    }

    private boolean turnOnBatchProcess(String turnOnProcessType) {
        boolean turnOn = Boolean.FALSE;
        String property = System.getProperty(turnOnProcessType);
        if (StringUtils.isEmpty(property)) {
            turnOn = Boolean.FALSE;
        } else {
            turnOn = Boolean.valueOf(property);
        }
        return turnOn;
    }
}
