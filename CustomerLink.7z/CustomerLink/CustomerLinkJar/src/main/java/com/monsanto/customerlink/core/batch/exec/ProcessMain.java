package com.monsanto.customerlink.core.batch.exec;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ResourceBundle;

public class ProcessMain {
    public static final String DEFAULT_APPLICATION_CONTEXT = "applicationContext-batch.xml";
    private static final String BATCH_JOB_PROPERTIES = "standalone";
    private static final String ENV_D_PARAM = "env";
    private static final String LSI_FUNCTION = "lsi.function";

    private ApplicationContext applicationContext;

    public ProcessMain() {
        this(DEFAULT_APPLICATION_CONTEXT);
    }

    public ProcessMain(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
        initializeDataSource();
    }

    public ProcessMain(String applicationContextId) {
        this.applicationContext = new ClassPathXmlApplicationContext(applicationContextId);
        initializeDataSource();
    }

    protected <T> T getService(String serviceId, Class<T> _class) {
        return (T) applicationContext.getBean(serviceId, _class);
    }

    protected <T> T getService(Class<T> _class) {
        return (T) applicationContext.getAutowireCapableBeanFactory().getBean(_class);
    }

    private void initializeDataSource() {
        BasicDataSource dataSource = this.getService("clDataSource", BasicDataSource.class);
        dataSource.setUrl(getDatabaseUrl());
        dataSource.setUsername(getDatabaseUsername());
        dataSource.setPassword(getPassword());
    }

    private static String getDatabaseUrl() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".connection.url");
    }

    private static String getDatabaseUsername() {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
        return bundle.getString(env + ".username");
    }

    private static String getPassword() {
        String encryptedPwd = null;
        try {
            encryptedPwd = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "customerlink", "CipherValue.hex", "KeyValue.hex");
        } catch (EncryptorException e) {
            throw new RuntimeException("No database pwd found. Please pass a -Denv param with value dev,test or prod.", e);
        }
        return encryptedPwd;
    }

    private static String getEnvironment() {
        String env = System.getProperty(ENV_D_PARAM);
        if (env == null) {
            env = System.getProperty(LSI_FUNCTION);
        }
        env = env == null ? "dev" : env;
        return env;
    }

    protected ApplicationContext getApplicationContext() {
        return applicationContext;
    }

}
