package com.monsanto.customerlink.core.email;

import java.util.Collection;

public interface AddresseeFetcher {
    Collection<String> getTos(Object... args);
    Collection<String> getCcs(Object... args);
    Collection<String> getBccs(Object... args);
}
