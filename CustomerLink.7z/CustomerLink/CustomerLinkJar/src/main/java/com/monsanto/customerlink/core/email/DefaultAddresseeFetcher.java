package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

import java.util.Collection;
import java.util.Collections;
import java.util.Properties;

public class DefaultAddresseeFetcher implements AddresseeFetcher {

    private Collection<String> tos;

    public DefaultAddresseeFetcher(Properties properties) {
        Preconditions.checkNotNull(properties);
        Preconditions.checkArgument(properties.containsKey(getToPropertyKey()));
        this.tos = Collections.unmodifiableCollection(Lists.newArrayList(properties.getProperty(getToPropertyKey()).split(",")));
    }

    @Override
    public Collection<String> getTos(Object... args) {
        return tos;
    }

    @Override
    public Collection<String> getCcs(Object... args) {
        return null;
    }

    @Override
    public Collection<String> getBccs(Object... args) {
        return null;
    }

    protected String getToPropertyKey() {
        return "to";
    }
}
