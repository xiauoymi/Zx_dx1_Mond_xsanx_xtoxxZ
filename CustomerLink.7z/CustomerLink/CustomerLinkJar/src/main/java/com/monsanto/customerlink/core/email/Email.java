package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;

public class Email {

    private static Predicate<String> ELEMENT_IS_A_VALID_ADDRESSEE = new Predicate<String>() {
        @Override
        public boolean apply(@Nullable String element) {
            return element != null && StringUtils.isNotEmpty(element);
        }
    };

    private Collection<String> tos;
    @Nullable
    private Collection<String> ccs;
    @Nullable
    private Collection<String> bccs;
    private String subject;
    private EmailBody body;

    public Email(Collection<String> tos, @Nullable Collection<String> ccs, @Nullable Collection<String> bccs, String subject, EmailBody body) {
        Preconditions.checkNotNull(tos);
        Preconditions.checkArgument(!tos.isEmpty());
        Preconditions.checkArgument(Iterables.all(tos, ELEMENT_IS_A_VALID_ADDRESSEE));
        this.tos = tos;
        if (ccs != null && !ccs.isEmpty()) {
            Preconditions.checkArgument(Iterables.all(ccs, ELEMENT_IS_A_VALID_ADDRESSEE));
            this.ccs = ccs;
        }
        if (bccs != null && !bccs.isEmpty()) {
            Preconditions.checkArgument(Iterables.all(bccs, ELEMENT_IS_A_VALID_ADDRESSEE));
            this.bccs = bccs;
        }
        Preconditions.checkNotNull(subject);
        Preconditions.checkArgument(StringUtils.isNotEmpty(subject));
        this.subject = subject;
        Preconditions.checkNotNull(body);
        this.body = body;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Email)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        Email oAsEmail = (Email) o;
        return new EqualsBuilder()
                .append(tos, oAsEmail.tos)
                .append(subject, oAsEmail.subject)
                .append(body, oAsEmail.body)
                .append(ccs, oAsEmail.ccs)
                .append(bccs, oAsEmail.bccs)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(tos)
                .append(subject)
                .append(body)
                .append(ccs)
                .append(bccs)
                .toHashCode();
    }

    public Collection<String> tos() {
        return Collections.unmodifiableCollection(tos);
    }

    @Nullable
    public Collection<String> ccs() {
        return ccs != null ? Collections.unmodifiableCollection(ccs) : null;
    }

    @Nullable
    public Collection<String> bccs() {
        return bccs != null ? Collections.unmodifiableCollection(bccs) : null;
    }

    public String subject() {
        return subject;
    }

    public EmailBody body() {
        return body;
    }

    @Nullable
    private String from;

    public void setFrom(@Nullable String from) {
        this.from = from;
    }

    @Nullable
    public String getFrom() {
        return from;
    }
}
