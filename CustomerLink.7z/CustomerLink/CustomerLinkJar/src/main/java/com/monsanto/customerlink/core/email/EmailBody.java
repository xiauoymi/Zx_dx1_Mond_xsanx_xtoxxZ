package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class EmailBody {

    private String text;
    private boolean html;

    public EmailBody(String text, boolean html) {
        Preconditions.checkNotNull(text);
        Preconditions.checkArgument(StringUtils.isNotEmpty(text));
        this.text = text;
        this.html = html;
    }

    public EmailBody(String text) {
        Preconditions.checkNotNull(text);
        Preconditions.checkArgument(StringUtils.isNotEmpty(text));
        this.text = text;
        this.html = StringUtils.startsWith(text, "<html");
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof EmailBody)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        return new EqualsBuilder()
                .append(text, ((EmailBody) o).text)
                .append(html, ((EmailBody) o).html)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(text)
                .append(html)
                .toHashCode();
    }

    public String getText() {
        return text;
    }

    public boolean isHtml() {
        return html;
    }
}
