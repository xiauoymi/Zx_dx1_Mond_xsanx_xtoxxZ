package com.monsanto.customerlink.core.email;

import com.monsanto.customerlink.core.email.exceptions.EmailingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

public class EmailSender {

    @Autowired
    private ClassPathResource bannerResource;

    @Autowired
    private JavaMailSender javaMailSender;

    public void send(Email email) {
        MimeMessageHelper mimeMessageHelper = null;
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            mimeMessageHelper = new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_MIXED);
            mimeMessageHelper.setTo(email.tos().toArray(new String[]{}));
            if (email.ccs() != null) {
                mimeMessageHelper.setCc(email.ccs().toArray(new String[]{}));
            }
            if (email.bccs() != null) {
                mimeMessageHelper.setBcc(email.bccs().toArray(new String[]{}));
            }
            if (email.getFrom() != null) {
                mimeMessageHelper.setFrom(email.getFrom());
            }
            mimeMessageHelper.setSubject(email.subject());
            mimeMessageHelper.setText(email.body().getText(), email.body().isHtml());
            mimeMessageHelper.addInline("mailHeader", bannerResource);
        } catch (MessagingException e) {
            throw new EmailingException(e);
        }
        javaMailSender.send(mimeMessageHelper.getMimeMessage());
    }
}