package com.monsanto.customerlink.core.email;

import com.monsanto.customerlink.core.email.AddresseeFetcher;
import com.monsanto.customerlink.core.email.DefaultAddresseeFetcher;

import java.util.Collection;
import java.util.Properties;

public class EnvironmentAwareAddresseeFetcher extends DefaultAddresseeFetcher {

    public EnvironmentAwareAddresseeFetcher(Properties properties) {
        super(properties);
    }

    @Override
    public String getToPropertyKey() {
        String lsiFunction = System.getProperty("lsi.function");
        if (lsiFunction == null || "prod".equals(lsiFunction)) {
            return super.getToPropertyKey();
        }
        return lsiFunction + "." + super.getToPropertyKey();
    }
}
