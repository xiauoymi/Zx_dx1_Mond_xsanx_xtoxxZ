
package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;

public class Notification {

    private String renderedSubject, renderedBody;

    private Collection<String> tos = Lists.newArrayList();
    private Collection<String> ccs = Lists.newArrayList();
    private Collection<String> bccs = Lists.newArrayList();

    public Notification(String renderedSubject, String renderedBody) {
        Preconditions.checkNotNull(renderedSubject);
        Preconditions.checkArgument(StringUtils.isNotEmpty(renderedSubject));
        this.renderedSubject = renderedSubject;

        Preconditions.checkNotNull(renderedBody);
        Preconditions.checkArgument(StringUtils.isNotEmpty(renderedBody));
        this.renderedBody = renderedBody;
    }

    public Notification tos(Collection<String> tos) {
        this.tos = tos;
        return this;
    }

    public Collection<String> tos() {
        return Collections.unmodifiableCollection(tos);
    }

    // this might never get invoked
    public Notification ccs(@Nullable Collection<String> ccs) {
        if (ccs != null) {
            this.ccs.addAll(ccs);
        }
        return this;
    }

    // this might never get invoked
    public Notification bccs(@Nullable Collection<String> bccs) {
        if (bccs != null) {
            this.bccs.addAll(bccs);
        }
        return this;
    }

    /**
     * @throws IllegalArgumentException if no valid addressees have been set by invoking tos(Collection<String>)
     */
    Email email() {
        Email email = new Email(tos, ccs, bccs, renderedSubject, new EmailBody(renderedBody));
        return email;
    }
}
