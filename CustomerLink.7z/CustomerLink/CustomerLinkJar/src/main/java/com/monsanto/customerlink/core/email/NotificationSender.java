package com.monsanto.customerlink.core.email;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import java.util.Map;

public class NotificationSender {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private EmailSender emailSender;

    @Resource(name = "velocityTemplateRenderer")
    private TemplateRenderer templateRenderer;

    public void send(NotificationType type, @Nullable Map<String, ?> parameters) {
        if (type.supportsAutomaticAddresseeResolving()) {
            emailSender.send(type.newNotification(parameters).email());
        } else {
            throw new UnsupportedOperationException("Cannot send notifications of the " + type.name() + " type without specifying the addressees because" +
                    " the notification type does not support automatic addressee setting. Please get a <Notification> object, set the addressees & then send it" +
                    " using the send(Notification) method.");
        }
    }

    public void send(Notification notification) {
        try {
            emailSender.send(notification.email());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
