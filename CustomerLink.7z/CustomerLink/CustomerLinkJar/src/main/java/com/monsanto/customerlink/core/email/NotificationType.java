package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.monsanto.customerlink.core.email.exceptions.TemplateLoadingException;
import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

public enum NotificationType {

    EXAMPLE,
    MINIMUM_INVENTORY_MX01 {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    INVALID_SKU {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    INVALID_PRICE {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    MINIMUM_INVENTORY_MX20 {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    PURCHASE_ORDER_WITHOUT_APPROVAL {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    WF_SPECIAL_ORDER_APPROVAL,
    WF_SPECIAL_ORDER_REJECTED {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    MISSING_INVENTORY_MX01 {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    MISSING_INVENTORY_MX20 {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    INVALID_CURRENCY {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    ORDER_CREATED {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    ORDER_UPDATED {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    ORDER_POSTED_WITH_ERROR {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    PURCHASE_ORDER_TO_APPROVE {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    AGREEMENT_TO_APPROVE {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    MINIMUM_INVENTORY_REGULAR_AGROCHEMICALS_MX01 {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },
    AGREEMENT_DIFFERENCES_IN_ORDER {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },WF_SPECIAL_ORDER_CSR_NOTIFICATION {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    },WF_SPECIAL_ORDER_CSR_NOTIFICATION_INIT {
        @Nullable
        protected AddresseeFetcher newAddresseeFetcher() {
            return new RoleAddresseeFetcher(emailRecoveryService, properties);
        }
    };

    protected Properties properties;
    private Template subjectTemplate;
    private Template bodyTemplate;

    @Nullable
    private AddresseeFetcher addresseeFetcher;

    @Resource
    private TemplateRenderer templateRenderer;

    @Resource
    protected EmailRecoveryService emailRecoveryService;

    private NotificationType() {
        loadTheProperties();
        Preconditions.checkArgument(properties.containsKey("subjectTemplate"));
        subjectTemplate = new Template(properties.getProperty("subjectTemplate"), name() + "_subject");
        Preconditions.checkArgument(properties.containsKey("bodyTemplate"));
        bodyTemplate = new Template(properties.getProperty("bodyTemplate"), name() + "_body");
    }

    private void loadTheProperties() {
        properties = new Properties();
        try {
            properties.load(getClass().getResourceAsStream(name() + "-notification.properties"));
        } catch (IOException e) {
            throw new TemplateLoadingException(name(), e);
        }
    }

    @Nullable
    protected AddresseeFetcher newAddresseeFetcher() {
        return new DefaultAddresseeFetcher(properties);
    }

    public AddresseeFetcher getAddresseeFetcher() {
        if (addresseeFetcher == null) {
            addresseeFetcher = newAddresseeFetcher();
        }
        return addresseeFetcher;
    }

    public boolean supportsAutomaticAddresseeResolving() {
        return getAddresseeFetcher() != null;
    }

    public Notification newNotification(Map<String, ?> parameters) {
        Notification notification = new Notification(templateRenderer.render(subjectTemplate, parameters), templateRenderer.render(bodyTemplate, parameters));
        if (supportsAutomaticAddresseeResolving()) {
            notification.tos(getAddresseeFetcher().getTos());
            notification.ccs(getAddresseeFetcher().getCcs());
            notification.bccs(getAddresseeFetcher().getBccs());
        }
        return notification;
    }

    public Notification newNotification(DistributorConfigDTO distributorProfile, Map<String, ?> parameters) {
        Notification notification = new Notification(templateRenderer.render(subjectTemplate, parameters), templateRenderer.render(bodyTemplate, parameters));
        if (supportsAutomaticAddresseeResolving()) {
            notification.tos(getAddresseeFetcher().getTos(distributorProfile));
            notification.ccs(getAddresseeFetcher().getCcs(distributorProfile));
            notification.bccs(getAddresseeFetcher().getBccs(distributorProfile));
        }
        return notification;
    }
}
