package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

public class RoleAddresseeFetcher implements AddresseeFetcher {

    private List<String> roles;
    private EmailRecoveryService emailRecoveryService;

    public RoleAddresseeFetcher(EmailRecoveryService emailRecoveryService, Properties properties) {
        Preconditions.checkNotNull(emailRecoveryService);
        Preconditions.checkNotNull(properties);
        Preconditions.checkArgument(properties.containsKey(getRolePropertyKey()));
        this.roles = Lists.newArrayList(properties.getProperty(getRolePropertyKey()).split(","));
        this.emailRecoveryService = emailRecoveryService;
    }

    @Override
    public Collection<String> getTos(Object... args) {
        DistributorConfigDTO distributorConfigDTO = (DistributorConfigDTO) Iterables.find(Lists.newArrayList(args), new Predicate<Object>() {
            @Override
            public boolean apply(@Nullable Object o) {
                return o instanceof DistributorConfigDTO;
            }
        });
        return emailRecoveryService.retrieveEmailByRoleAndDistributorConfig(roles, distributorConfigDTO);
    }

    @Override
    public Collection<String> getCcs(Object... args) {
        return null;
    }

    @Override
    public Collection<String> getBccs(Object... args) {
        return null;
    }

    protected String getRolePropertyKey() {
        return "role";
    }
}
