package com.monsanto.customerlink.core.email;

public class Template {

    private String text;
    private String name;

    public Template(String text, String name) {
        this.text = text;
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public String name() {
        return name;
    }
}
