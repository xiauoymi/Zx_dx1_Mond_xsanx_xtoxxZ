package com.monsanto.customerlink.core.email;

import java.util.Map;

public interface TemplateRenderer {

    String render(Template template, Map<String, ?> parameters);
}
