package com.monsanto.customerlink.core.email;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.StringWriter;
import java.util.Map;

public class VelocityTemplateRenderer implements TemplateRenderer {

    @Autowired
    private VelocityEngine velocityEngine;

    @Override
    public String render(Template template, Map<String, ?> parameters) {
        StringWriter writer = new StringWriter();
        velocityEngine.evaluate(new VelocityContext(parameters), writer, template.name(), template.getText());
        return writer.toString();
    }
}
