package com.monsanto.customerlink.core.email.dto.messages;

import java.io.Serializable;

public class DistributorMessageVO implements Serializable {

    private String distributorCode;
    private String distributorDesc;
    private String salesDistrictCode;
    private String salesDistrictDesc;
    private String distributionChannel;
    private String distributionChannelDesc;

    private String salesDivisionCode;
    private String salesDivisionDesc;
    private String  salesOrgCode;
    private String  salesOrgDesc;

    public String getDistributorCode() {
        return distributorCode;
    }

    public void setDistributorCode(String distributorCode) {
        this.distributorCode = distributorCode;
    }

    public String getDistributorDesc() {
        return distributorDesc;
    }

    public void setDistributorDesc(String distributorDesc) {
        this.distributorDesc = distributorDesc;
    }

    public String getSalesDistrictCode() {
        return salesDistrictCode;
    }

    public void setSalesDistrictCode(String salesDistrictCode) {
        this.salesDistrictCode = salesDistrictCode;
    }

    public String getSalesDistrictDesc() {
        return salesDistrictDesc;
    }

    public void setSalesDistrictDesc(String salesDistrictDesc) {
        this.salesDistrictDesc = salesDistrictDesc;
    }

    public String getDistributionChannel() {
        return distributionChannel;
    }

    public void setDistributionChannel(String distributionChannel) {
        this.distributionChannel = distributionChannel;
    }

    public String getSalesDivisionCode() {
        return salesDivisionCode;
    }

    public void setSalesDivisionCode(String salesDivisionCode) {
        this.salesDivisionCode = salesDivisionCode;
    }

    public String getSalesDivisionDesc() {
        return salesDivisionDesc;
    }

    public void setSalesDivisionDesc(String salesDivisionDesc) {
        this.salesDivisionDesc = salesDivisionDesc;
    }

    public String getSalesOrgCode() {
        return salesOrgCode;
    }

    public void setSalesOrgCode(String salesOrgCode) {
        this.salesOrgCode = salesOrgCode;
    }

    public String getSalesOrgDesc() {
        return salesOrgDesc;
    }

    public void setSalesOrgDesc(String salesOrgDesc) {
        this.salesOrgDesc = salesOrgDesc;
    }

    public String getDistributionChannelDesc() {
        return distributionChannelDesc;
    }

    public void setDistributionChannelDesc(String distributionChannelDesc) {
        this.distributionChannelDesc = distributionChannelDesc;
    }
}
