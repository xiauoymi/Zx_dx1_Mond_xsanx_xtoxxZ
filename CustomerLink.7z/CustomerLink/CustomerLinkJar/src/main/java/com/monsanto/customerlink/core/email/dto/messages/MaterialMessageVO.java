package com.monsanto.customerlink.core.email.dto.messages;

import java.io.Serializable;

public class MaterialMessageVO  implements Serializable {

    private String material;
    private double unrestqty;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getUnrestqty() {
        return unrestqty;
    }

    public void setUnrestqty(double unrestqty) {
        this.unrestqty = unrestqty;
    }
}