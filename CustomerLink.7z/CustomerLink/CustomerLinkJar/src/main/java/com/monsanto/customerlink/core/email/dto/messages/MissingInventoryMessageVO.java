package com.monsanto.customerlink.core.email.dto.messages;

import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;

import java.util.List;

public class MissingInventoryMessageVO extends DistributorMessageVO {

    private List<ErrorOrderDTO> errors;
    private List<HybridMessageVO> hybrids;
    private List<MaterialMessageVO> materials;

    public List<HybridMessageVO> getHybrids() {
        return hybrids;
    }

    public void setHybrids(List<HybridMessageVO> hybrids) {
        this.hybrids = hybrids;
    }

    public List<ErrorOrderDTO> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorOrderDTO> errors) {
        this.errors = errors;
    }

    public List<MaterialMessageVO> getMaterials() {
        return materials;
    }

    public void setMaterials(List<MaterialMessageVO> materials) {
        this.materials = materials;
    }
}