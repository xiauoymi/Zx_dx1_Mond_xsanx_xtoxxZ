package com.monsanto.customerlink.core.email.dto.messages;

public class WFSpecialOrderMessageVO extends DistributorMessageVO {

    private Long orderId;
    private String urlSpecialOrder;
    private String userName;
    private String userRole;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getUrlSpecialOrder() {
        return urlSpecialOrder;
    }

    public void setUrlSpecialOrder(String urlSpecialOrder) {
        this.urlSpecialOrder = urlSpecialOrder;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }
}