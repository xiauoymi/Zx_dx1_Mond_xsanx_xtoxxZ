package com.monsanto.customerlink.core.email.exceptions;

import javax.mail.MessagingException;

public class EmailingException extends RuntimeException {

    public EmailingException(MessagingException cause) {
        super(cause);
    }

    @Override
    public String getMessage() {
        return "Exception while attempting to send an e-mail.";
    }
}
