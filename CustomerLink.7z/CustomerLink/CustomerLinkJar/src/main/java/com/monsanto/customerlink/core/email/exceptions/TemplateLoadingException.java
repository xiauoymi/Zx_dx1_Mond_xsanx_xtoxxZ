package com.monsanto.customerlink.core.email.exceptions;

import java.io.IOException;

public class TemplateLoadingException extends RuntimeException {

    private String typeName;

    public TemplateLoadingException(String typeName, IOException cause) {
        super(cause);
        this.typeName = typeName;
    }

    @Override
    public String getMessage() {
        return "Exception while loading the " + typeName + " notification templates.";
    }
}
