package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 27/05/13
 * Time: 12:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface AgreementService {

    public List<AgreementDTO> retrieveAgreementByParameters(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO) throws AgreementRetrieveByParametersNotFoundException;

    public AgreementDTO createAgreement(AgreementDTO agreementVO, DistributorConfigDTO distributorConfigDTO) throws AgreementNotFoundException, DistributorConfigNotFoundException,
            AgreementAlreadyExistsException, AgreementWithoutVolumeGoalException, AgreementWithoutIncentivePackageException, VolumeGoalWithoutPeriodException, VolumenGoalNotEnoughPeriodsException,
            InvalidProductForPrivateDistributor;

    public AgreementDTO updateAgreement(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO)
            throws AgreementNotFoundException, InvalidProductForPrivateDistributor, DistributorConfigNotFoundException;

    public AgreementDTO deleteAgreement(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO) throws AgreementNotFoundException, DistributorConfigNotFoundException;

}
