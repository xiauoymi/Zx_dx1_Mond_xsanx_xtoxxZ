package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.persistence.entities.AgreementVO;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.web.services.autogen.agreement.FiscalYearDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;

import java.util.List;

public interface AgreementServiceHelper {

    AgreementVO obtainAgreementByParameters(FiscalYearVO yearVo, DistributorProfileVO distvo, RepresentativeDTO representativeDTO);

    List<Long> getFiscalYearList(FiscalYearDTO fy);

}
