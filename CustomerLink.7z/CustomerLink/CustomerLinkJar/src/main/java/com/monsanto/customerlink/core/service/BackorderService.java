package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.List;

public interface BackorderService {

    /**
     * Creates a backorder in Customer Link data model
     *
     * @param backorderDTO
     * @return the saved backorder
     * @throws DistributorConfigNotFoundException If the distributor profile not found in the repository
     */
    BackorderDTO createBackorder(final BackorderDTO backorderDTO) throws DistributorConfigNotFoundException;

    /**
     * Retrieves all backorders associated to the search criteria
     *
     * @param distributorProfileDTO
     * @return the orders
     * @throws OrdersNotFoundException If orders not found in the repository
     */
    List<BackorderDTO> retrieveBackorders(final DistributorConfigDTO distributorProfileDTO) throws OrdersNotFoundException;

}
