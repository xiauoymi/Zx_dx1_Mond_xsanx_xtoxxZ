package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.dto.*;
import com.monsanto.customerlink.persistence.entities.UserVO;

import java.util.List;

public interface CatalogService {

    /**
     * Get the list of roles currently configured in the system
     * @return list of RoleDTO
     * @see com.monsanto.customerlink.core.service.dto.RoleDTO
     */
    List<RoleDTO> getListOfRoles();

    /**
     * Get a list of brands that are currently configured on the system.
     * @return list of BrandDTO
     * @see com.monsanto.customerlink.core.service.dto.BrandDTO
     */
    List<BrandDTO> getListOfBrands();

    /**
     * Get a list of distributors that are currently configured on the system.
     * @return list of DistributorDTO
     * @see com.monsanto.customerlink.core.service.dto.DistributorDTO
     */
    List<DistributorDTO> getListOfDistributors();

    /**
     * Get a list of sub regions that are currently configured on the system.
     * @return list of SubRegionDTO
     * @see com.monsanto.customerlink.core.service.dto.SubRegionDTO
     */
    List<SubRegionDTO> getListOfSubRegions();

    /**
     * Get a list of distributors profile by sub region, that are currently configured on the system.
     * @param subRegionCode identifier of sub region
     * @param distributorCodeOrName (optional) if non-null, is part of the search and is validated against the user name or ID of the distributor
     * @return list of GridDistributorProfileDTO
     * @see com.monsanto.customerlink.core.service.dto.GridDistributorProfileDTO
     **/
    List<GridDistributorProfileDTO> getDistributorsBySubRegionAndDistributorCodeOrName(String subRegionCode, String distributorCodeOrName);

    /**
     * Get a list of distributors that are currently configured on the system.
     * @param userId identifier of user
     * @return list of DistributorDTO
     * @see com.monsanto.customerlink.core.service.dto.DistributorDTO
     */
    List<DistributorDTO> getListOfDistributorsByUser(Long userId);

    /**
     * Get list of currently configured users-role in the system for a Distributor Profile ID.
     * @param idDistributorProfile identifier of distributor profile
     * @return list of UserRoleDTO
     * @see com.monsanto.customerlink.core.service.dto.UserRoleDTO
     **/
    List<UserRoleDTO> getListOfUserRoleByDistributorProfileId(Long idDistributorProfile);

    /**
     * Get list of currently configured users-role in the system for a Distributor Profile ID.
     * @param idDistributorProfile identifier of distributor profile
     * @return list of GridUserRoleDTO
     * @see com.monsanto.customerlink.core.service.dto.GridUserRoleDTO
     **/
    List<GridUserRoleDTO> getListOfGridUserRoleByDistributorProfileId(Long idDistributorProfile);
}