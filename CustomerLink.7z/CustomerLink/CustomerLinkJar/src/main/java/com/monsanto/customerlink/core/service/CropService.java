package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.persistence.entities.CropVO;

public interface CropService {

    CropVO obtainCropByCode(String cropCode);

}
