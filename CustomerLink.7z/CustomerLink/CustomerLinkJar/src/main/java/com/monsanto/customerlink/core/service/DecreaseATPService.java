package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface DecreaseATPService {

    void decreaseATPProcess(SAPOrderDTO sapOrder, OrderDTO atpOrder)  throws CustomerLinkBusinessException;

}