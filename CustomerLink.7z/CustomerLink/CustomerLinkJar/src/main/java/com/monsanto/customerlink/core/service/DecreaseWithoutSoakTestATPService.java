package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.Map;

public interface DecreaseWithoutSoakTestATPService {

    Map<OrderDTO, SAPOrderDTO> decreaseWhitAWithoutSoakTestOrder(OrderDTO atpOrder, SAPOrderDTO sapOrder);
}
