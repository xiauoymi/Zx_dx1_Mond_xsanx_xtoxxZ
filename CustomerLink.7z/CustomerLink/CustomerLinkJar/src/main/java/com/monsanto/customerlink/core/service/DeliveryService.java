package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.DeleteDeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryProductNotFoundException;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalDeliveryDTO;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalSavedDeliveryDTO;

import java.util.List;

public interface DeliveryService {

    List<TemporalDeliveryDTO> existSavedDeliveries(List<String> orderIdentifiers);

    List<TemporalSavedDeliveryDTO> getSavedDeliveriesBySapOrderId(List<String> sapOrderIds);

    Boolean updateSavedDeliveries(List<TemporalSavedDeliveryDTO> deliveries) throws DeliveryNotFoundException, DeliveryProductNotFoundException;

    Boolean deleteDelivery(Long idDelivery) throws DeleteDeliveryNotFoundException;

}