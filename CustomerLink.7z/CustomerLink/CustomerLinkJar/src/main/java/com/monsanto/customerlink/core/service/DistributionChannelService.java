package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.DistributionChannelNotFoundException;
import com.monsanto.customerlink.persistence.entities.DistributionChannelVO;

public interface DistributionChannelService {

    /**
     * Retrieves the distribution channel associated at input parameter
     *
     * @param distChCode Distribution channel code
     * @return the distribution channel
     * @throws DistributionChannelNotFoundException If the distribution channel not found in the repository
     */
    DistributionChannelVO retrieveDistributionChannel(final String distChCode) throws DistributionChannelNotFoundException;

}
