package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.exception.DistributorNotFoundException;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;

public interface DistributorService {

    /**
     * Retrieves the distributor associated at distributor code
     *
     * @param distributorCode
     * @return the distributor
     * @throws DistributorNotFoundException
     */
    DistributorDTO retrieveDistributor(final String distributorCode) throws DistributorNotFoundException;

    /**
     * retrieves one disributor profile according to config parameters received
     *
     * @param distributorConfigDTO parameters to look for the distributor profile: follows are mandatory fields:
     *                             <li>distributorConfigDTO.getSalesOrgCode </li>
     *                             <li>distributorConfigDTO.getDistChCode</li>
     *                             <li>distributorConfigDTO.getSalesDivCode</li>
     *                             <li>distributorConfigDTO.getSubRegionCode</li>
     *                             <li> distributorConfigDTO.getDistributor().getDistributorCode</li>
     * @return
     * @throws DistributorConfigNotFoundException
     *                                  if distributor profile is not found with the last parameters
     * @throws IllegalArgumentException if missing someone of the parameters
     */
    DistributorProfileVO retrieveDistributorConfigByConfig(DistributorConfigDTO distributorConfigDTO) throws DistributorConfigNotFoundException;

    /**
     * Verify in table for distributor with private brand if exists the distributor received
     *
     * @param distributorCode
     * @return <li>true: if distributor is for private brand</li>
     *         <li>false: otherwise</li>
     */
    boolean verifyIsPrivateBrandDistributor(final String distributorCode);
}