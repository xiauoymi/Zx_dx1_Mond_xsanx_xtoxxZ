package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.List;

public interface EmailRecoveryService {

    /**
     * Retrieves a list containing the email addresses associated to a set of roles and :
     * @param roles list containing roles for the search
     * @param distributorConfigDTO an object of type DistributorConfigDTO which contains the following information
     *          Sales organization code.
     *          Distribution Chanel code
     *          Sales division code
     *          SubRegion code
     *          Distributor code
     * @see com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO
     * @return list of email addresses
     */
    List<String> retrieveEmailByRoleAndDistributorConfig( List<String> roles , DistributorConfigDTO distributorConfigDTO);

    /**
     * Retrieves the email address associated with a distributor
     * @param distributorCode
     * @return
     */
    String retrieveByDistributor(String distributorCode);
}