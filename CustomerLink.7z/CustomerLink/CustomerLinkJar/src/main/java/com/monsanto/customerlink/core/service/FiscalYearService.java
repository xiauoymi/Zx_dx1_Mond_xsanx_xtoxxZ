package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.FiscalYearNotFoundException;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;

import java.util.Date;

public interface FiscalYearService {

    /**
     * Retrieves the active fiscal year for the input date
     *
     * @param date Date
     * @return Fiscal year
     * @throws FiscalYearNotFoundException If fiscal year not found in the repository
     */
    FiscalYearVO retrieveActiveFiscalYear(Date date) throws FiscalYearNotFoundException;

    /**
     * Retrieves a search period according to current fiscal year
     *
     * @return a search period
     * @throws FiscalYearNotFoundException If fiscal year not found in the repository
     */
    SearchPeriodDTO retrieveSearchPeriod() throws FiscalYearNotFoundException;
}
