package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface IncreaseATPService {

    void increaseATPProcess(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isIncreasePerNewHybrids) throws CustomerLinkBusinessException;

    OrderDTO excludesAndProcessNewHybrids(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws CustomerLinkBusinessException;

}
