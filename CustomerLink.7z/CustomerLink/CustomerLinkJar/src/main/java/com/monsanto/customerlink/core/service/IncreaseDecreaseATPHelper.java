package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.SapOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;

import java.util.List;
import java.util.Map;

public interface IncreaseDecreaseATPHelper {

    boolean existHybridsToProcess(OrderDTO orderDTO);

    Map<String, List<MaterialDTO>> groupByHybrid(List<HybridDTO> listOfHybrid);

    void validateInputParameters(OrderDTO atpOrder) throws AtpOrderMissingArgumentsException;

    void validateInputParameters(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws SapOrderMissingArgumentsException, AtpOrderMissingArgumentsException;

    List<OrderDetailDTO> obtainHybridsToIncreaseOrDecrease(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean obtainHybridsIncrease)  throws AtpOrderMissingArgumentsException;

}