package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface IncreaseDecreaseATPService {

    /**
     * Processing an seeds order due to an increase, decrease or new products as a result of a change in the ATP
     * @param atpOrder
     * @throws CustomerLinkBusinessException
     */
    void runProcessChangeInATP(OrderDTO atpOrder) throws CustomerLinkBusinessException;

}