package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.facade.dto.InventoryInDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;

import java.util.List;
import java.util.Map;

public interface InventoryHelper {

    /**
     * Make the request to retrieve the inventory
     * @param hybridsIncreased
     * @param distributorConfigDTO
     * @return
     */
    List<InventoryInDTO> createRequestInventory(List<OrderDetailDTO> hybridsIncreased, DistributorConfigDTO distributorConfigDTO);

    /**
     * Allows sending email notifications
     * @param sapOrder
     * @param inventoryListConfig
     * @param details
     * @param listError
     * @param type
     * @param distributorProfile
     */
    void sendNotification(SAPOrderDTO sapOrder, List<InventoryInDTO> inventoryListConfig,
                                  List<OrderDetailDTO> details,
                                  List<ErrorOrderDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorProfile);

    /**
     * To send the notice of lack of inventory
     * @param details
     * @param distributorConfigDTO
     * @param isCornOrSorghum
     * @param errors
     */
    void sendNotificationOfInsufficientInventory(List<OrderDetailDTO> details, DistributorConfigDTO distributorConfigDTO,
                                                         boolean isCornOrSorghum, List<ErrorOrderDTO> errors);

    /**
     *  Allows sending email notifications
     * @param listError
     * @param type
     * @param distributorProfile
     */
    void sendNotification(List<SAPOrderErrorDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorProfile);

    /**
     * Send email messages
     * @param type
     * @param distributorProfile
     * @param parameters
     */
    void sendMessage(NotificationType type, DistributorConfigDTO distributorProfile, Map<String, Object> parameters);
}