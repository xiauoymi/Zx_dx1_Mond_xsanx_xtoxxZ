package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.InventoryWithAlgorithmDTO;
import com.monsanto.customerlink.core.service.facade.dto.InventoryWithOutAlgorithmDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface InventoryIncreaseHelper {

    void assignInventoryCornOrSorghum(SAPOrderDTO sapOrder, OrderDTO atpOrder, List<InventoryWithAlgorithmDTO> inventory,
                                              List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException;

    void assignInventoryCottonOrSoybean(SAPOrderDTO sapOrder, OrderDTO atpOrder, List<InventoryWithOutAlgorithmDTO> inventory,
                                                List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException;

}