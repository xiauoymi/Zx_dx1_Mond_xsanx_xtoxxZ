package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.facade.dto.InventoryWithAlgorithmDTO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;

import java.util.List;

public interface InventoryPlantPriorityHelper {

    void assignPlantPriorityPerHybridCornOrSorghum(OrderDetailDTO detail, DistributorConfigDTO distributorConfigDTO, List<InventoryWithAlgorithmDTO> inventory);

}
