package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;

import java.util.List;
import java.util.Map;

public interface MailUtilService {

    public Map<String, Object> buildDistributorMessageNotification(DistributorConfigDTO distributorConfigDTO,
                                                                 List<ErrorOrderDTO> listError) ;


}
