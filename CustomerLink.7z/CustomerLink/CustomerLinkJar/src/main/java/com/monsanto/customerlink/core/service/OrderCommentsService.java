package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.persistence.entities.OrderCommentVO;

public interface OrderCommentsService {

    OrderCommentVO saveComment(Long idOrder, String comments) throws Exception;

}
