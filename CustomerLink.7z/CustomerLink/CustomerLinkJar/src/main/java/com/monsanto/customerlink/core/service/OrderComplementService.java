package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface OrderComplementService {

    /**
     * Fills the order with missing information
     *
     * @param orderDTO order to complement
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    void complement(OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Fills the order with missing information for the search
     * @param orderDTO
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    void complementToSearch(OrderDTO orderDTO) throws CustomerLinkBusinessException;
}
