package com.monsanto.customerlink.core.service;

import java.util.List;

public interface OrderDetailService {

    void deleteOrderDetails(Long idOrder, List<String> hybridsForDelete) throws Exception;

}
