package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface OrderErrorService {

    public void saveOrderAndErrors(OrderDTO orderDTO) throws CustomerLinkBusinessException;

    public boolean containErrors(OrderDTO orderDTO);

    public OrderDTO filterHybridsWithErrors(OrderDTO orderDTO);

    public List<ErrorOrderDTO> obtainPricesErrors(OrderDTO responseOrderDTO);

    public List<ErrorOrderDTO> obtainSkuErrors(OrderDTO responseOrderDTO);


}
