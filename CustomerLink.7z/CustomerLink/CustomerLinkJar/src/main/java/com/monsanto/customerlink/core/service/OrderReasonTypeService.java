package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.OrderReasonNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderReasonTypeVO;

public interface OrderReasonTypeService {

    /**
     * Retrieves the order reason type
     *
     * @param clOrderTypeCode the order type in customer link
     * @param cropCode        crop code
     * @return the order reason type
     * @throws OrderReasonNotFoundException If the order reason type is not found in the repository
     */
    OrderReasonTypeVO retrieveOrderReasonType(String clOrderTypeCode, String cropCode) throws OrderReasonNotFoundException;

    OrderReasonTypeVO retrieveOrderReasonTypeByCode(String orderReasonCode) throws OrderReasonNotFoundException;
}
