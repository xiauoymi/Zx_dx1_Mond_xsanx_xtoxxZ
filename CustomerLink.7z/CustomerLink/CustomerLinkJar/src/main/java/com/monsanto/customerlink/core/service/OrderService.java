package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.dto.SpecialOrderDTO;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface OrderService {

    /**
     * Creates a order in Customer Link data model
     *
     * @param orderDTO
     * @return the saved order
     * @throws CustomerLinkBusinessException If throws business exception
     */
    OrderDTO createOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Changes order status in oracle after it was posted
     *
     * @param orderDTO a posted order
     * @return a oracle order with posted status
     * @throws CustomerLinkBusinessException
     */
    OrderDTO changeOrderToPosted(OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Retrieves all orders of the current season active associated to the search criteria
     *
     * @param orderDTO
     * @return the orders
     * @throws OrdersNotFoundException If orders not found in the repository
     */
    List<OrderDTO> retrieveOrders(OrderDTO orderDTO) throws OrdersNotFoundException;

    /**
     * Retrieves special orders are in "Pending approval" for a specific user and region
     *
     * @param userId identifier related to the combination of UserName, Role, Region
     * @return list containing the orders with pending approval status
     */
    List<SpecialOrderDTO> retrieveSpecialOrdersPendingApprovalByUser(Long userId);
}
