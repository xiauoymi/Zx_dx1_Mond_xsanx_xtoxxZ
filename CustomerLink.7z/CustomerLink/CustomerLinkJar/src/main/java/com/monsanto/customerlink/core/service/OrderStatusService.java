package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.OrderStatusNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface OrderStatusService {

    /**
     * Retrieves the order status initial
     *
     * @param orderDTO the order
     * @return the order status initial
     * @throws OrderStatusNotFoundException if the order status initial not be found
     */
    OrderStatusVO retrieveOrderStatusInitial(OrderDTO orderDTO) throws OrderStatusNotFoundException;
}
