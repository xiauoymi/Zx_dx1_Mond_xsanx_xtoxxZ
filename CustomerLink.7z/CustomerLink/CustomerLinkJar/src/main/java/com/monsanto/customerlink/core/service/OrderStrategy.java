package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class OrderStrategy {

    @Autowired
    private DistributorService distributorBusiness;

    @Autowired
    private OrderComplementService orderComplementBusiness;

    @Autowired
    private SeasonService seasonBusiness;

    @Autowired
    private UserService userService;

    @Autowired
    private ErrorTypeRepository errorTypeRepository;

    @Autowired
    private OrderDetailRepository orderDetailRepository;

    @Autowired
    private OrdersTypeRepository ordersTypeRepository;

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private Mapper mapper;

    public OrderVO createOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateInputParameters(orderDTO);
        orderComplementBusiness.complement(orderDTO);
        final OrderVO orderVO = new OrderVO();
        setPropertiesToOrder(orderVO, orderDTO);
        if (orderDTO.getErrors().isEmpty()) {
            orderVO.setOrderStatusByOrderStatusId(retrieveOrderStatus(OrderStatusEnum.PENDING_POST.toString()));
        } else {
            orderVO.setOrderStatusByOrderStatusId(retrieveOrderStatus(OrderStatusEnum.WITH_ERROR.toString()));
        }
        return saveOrder(orderVO);
    }

    public OrderVO updateOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateOrderDetail(orderDTO.getDetail());
        validateOrderStatus(orderDTO.getOrderId(), OrderStatusEnum.PENDING_POST);
        clearOrderDetail(orderDTO.getOrderId());
        final OrderVO orderVO = retrieveOrder(orderDTO.getOrderId());
        setChildToOrder(orderVO, orderDTO);
        return saveOrder(orderVO);
    }

    public OrderVO changeOrderToPosted(Long orderId) throws CustomerLinkBusinessException {
        validateOrderStatus(orderId, OrderStatusEnum.PENDING_POST);
        return changeOrderStatus(orderId, OrderStatusEnum.POST);
    }

    protected void validateInputParameters(OrderDTO orderDTO) {
        validateInputParametersCommon(orderDTO);
        CustomerLinkUtils.isValidParameter(orderDTO.getCurrency());
        validateOrderDetail(orderDTO.getDetail());
        //CustomerLinkUtils.isValidParameter(orderDTO.getRepresentativeDTO());
        //CustomerLinkUtils.isValidParameter(orderDTO.getRepresentativeDTO().getSapUserId());
    }

    protected void setPropertiesToOrder(OrderVO orderVO, OrderDTO orderDTO) throws CustomerLinkBusinessException {
        setCommonPropertiesToOrder(orderVO, orderDTO);
        orderVO.setSapOrderTypeByOrderTypeId(mapper.map(orderDTO.getSapOrderTypeDTO(), OrderTypeVO.class));
        orderVO.setOrderReasonTypeByOrderReasonTypeId(mapper.map(orderDTO.getSapOrderReasonTypeDTO(), OrderReasonTypeVO.class));
        //RBU to not saving price group if agrochemical order
        if (!SalesDivisionEnum.AGROCHEMICALS.getCode().equals(orderDTO.getDistributorConfigDTO().getSalesDivCode())) {
            orderVO.setPriceGroupByPriceGroupId(mapper.map(orderDTO.getPriceGroup(), PriceGroupVO.class));
        }
        orderVO.setCurrency(orderDTO.getCurrency());
        orderVO.setPoNumber(orderDTO.getPoNumber());
        orderVO.setIncoterms1(orderDTO.getIncoterms1());
        orderVO.setIncoterms2(orderDTO.getIncoterms2());
        orderVO.setSoldTo(orderDTO.getSoldTo());
        orderVO.setShipTo(orderDTO.getShipTo());
    }

    protected void validateInputParametersCommon(OrderDTO orderDTO) {
        CustomerLinkUtils.checkDistributorProfileArgument(orderDTO.getDistributorConfigDTO());
    }

    protected void setCommonPropertiesToOrder(OrderVO orderVO, OrderDTO orderDTO) throws CustomerLinkBusinessException {
        setRepresentative(orderVO, orderDTO);
        orderVO.setDistributorProfileByDistributorProfileId(distributorBusiness.retrieveDistributorConfigByConfig(orderDTO.getDistributorConfigDTO()));
        orderVO.setSeasonBySeasonId(seasonBusiness.retrieveActiveSeason(orderDTO.getDistributorConfigDTO().getSubRegionCode(), new Date()));
        orderVO.setClOrderTypeByOrdersTypeId(retrieveCLOrderType(orderDTO.getClOrderTypeCode()));
        setChildToOrder(orderVO, orderDTO);
    }

    protected OrderStatusVO retrieveOrderStatus(String orderStatusCode) throws OrderStatusNotFoundException {
        final OrderStatusVO orderStatusVO = orderStatusRepository.findByOrderStatusCode(orderStatusCode);
        if (null == orderStatusVO) {
            throw new OrderStatusNotFoundException(new Object[]{orderStatusCode});
        }
        return orderStatusVO;
    }

    protected OrderVO saveOrder(OrderVO orderVO) {
        return orderRepository.save(orderVO);
    }

    protected void validateOrderStatus(Long orderId, OrderStatusEnum orderStatusEnum) throws CustomerLinkBusinessException {
        final String orderStatus = orderRepository.getOrderStatus(orderId);
        if (null == orderStatus) {
            final OrdersNotFoundException ordersNotFoundException = new OrdersNotFoundException(new Object[]{orderId});
            ordersNotFoundException.setCode("orderNotFoundException");
            throw ordersNotFoundException;
        }
        if (!StringUtils.equals(orderStatusEnum.toString(), orderStatus)) {
            throw new UpdateOrderException(new Object[]{orderId});
        }
    }

    protected OrderVO retrieveOrder(Long orderId) {
        return orderRepository.findOne(orderId);
    }

    protected void validateOrderDetail(List<OrderDetailDTO> orderDetailDTOList) {
        for (OrderDetailDTO orderDetailDTO : orderDetailDTOList) {
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getProductCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getCropCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getBrandCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getQuantity());
        }
    }

    protected void clearOrderDetail(Long orderId) {
        final List<OrderDetailVO> orderDetailVOList = orderDetailRepository.findByOrderId(orderId);
        orderDetailRepository.delete(orderDetailVOList);
        orderDetailRepository.flush();
    }

    protected void setChildToOrder(OrderVO orderVO, OrderDTO orderDTO) {
        orderVO.setOrderDetailsByOrderId(mapper.mapList(OrderDetailVO.class, orderDTO.getDetail()));
        orderVO.setOrderErrorsByOrderId(transformErrorsDTOToErrorsVO(orderDTO.getErrors()));
        setOrderDetailToOrder(orderVO);
        setOrderErrorsToOrder(orderVO);
    }

    private OrdersTypeVO retrieveCLOrderType(String orderTypeCode) throws OrderTypeNotFoundException {
        final OrdersTypeVO ordersTypeVO = ordersTypeRepository.findByOrdersTypeCode(orderTypeCode);
        if (null == ordersTypeVO) {
            throw new OrderTypeNotFoundException(new Object[]{orderTypeCode});
        }
        return ordersTypeVO;
    }

    private List<OrderErrorVO> transformErrorsDTOToErrorsVO(List<ErrorOrderDTO> errorOrderDTOList) {
        final List<OrderErrorVO> orderErrorVOList = new ArrayList<OrderErrorVO>();
        for (ErrorOrderDTO errorOrderDTO : errorOrderDTOList) {
            final OrderErrorVO orderErrorVO = new OrderErrorVO();
            orderErrorVO.setErrorTypeByErrorTypeId(errorTypeRepository.findByErrorTypeCode(errorOrderDTO.getErrorTypes().getErrorTypeCode()));
            if (orderErrorVO.getErrorTypeByErrorTypeId() == null) {
                orderErrorVO.setErrorTypeByErrorTypeId(errorTypeRepository.findByErrorTypeCode(ErrorTypeEnum.GENERIC.getCode()));
            }
            orderErrorVO.setObjectWithError(errorOrderDTO.getObjectWithError());
            orderErrorVOList.add(orderErrorVO);
        }
        return orderErrorVOList;
    }

    private void setOrderDetailToOrder(final OrderVO orderVO) {
        CollectionUtils.forAllDo(orderVO.getOrderDetailsByOrderId(), new Closure() {
            @Override
            public void execute(Object object) {
                OrderDetailVO orderDetailVO = (OrderDetailVO) object;
                orderDetailVO.setOrderByOrderId(orderVO);
            }
        });
    }

    private void setOrderErrorsToOrder(final OrderVO orderVO) {
        CollectionUtils.forAllDo(orderVO.getOrderErrorsByOrderId(), new Closure() {
            @Override
            public void execute(Object object) {
                OrderErrorVO orderErrorVO = (OrderErrorVO) object;
                orderErrorVO.setOrderByOrderId(orderVO);
            }
        });
    }

    private OrderVO changeOrderStatus(Long orderId, OrderStatusEnum nextStatus) throws CustomerLinkBusinessException {
        final OrderStatusVO orderStatusVO = retrieveOrderStatus(nextStatus.toString());
        final OrderVO orderVO = retrieveOrder(orderId);
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        return saveOrder(orderVO);
    }

    private void setRepresentative(OrderVO orderVO, OrderDTO orderDTO) throws RCDNotFoundException {
        if (null != orderDTO.getRepresentativeDTO() && !StringUtils.isEmpty(orderDTO.getRepresentativeDTO().getSapUserId())) {
            userService.retrieveRCD(orderDTO.getRepresentativeDTO().getSapUserId(), orderDTO.getDistributorConfigDTO());
            orderVO.setRcdSAPCode(orderDTO.getRepresentativeDTO().getSapUserId());
        }
    }
}