package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;

public interface PONumberService {

    /**
     * Generates the PO Number for the season orders with or without algorithm.
     * PONumber_Base = Season + two last digits of the fiscal year + space + region
     * PONumber = PONumber_Base + someString
     * Where someString = S/ST when clOrderType is equals to CLOrderTypeEnum.SSTO
     * or someString = <DistChannelShortName> when clOrderType is not equals to CLOrderTypeEnum.SSTO
     *
     * @param clOrderType   Order type in customer link
     *                      Is SSTO     -> If the season order is without soak test
     *                      Is Not SSTO -> For the remaining orders (Only crops)
     * @param subRegionCode Sales district code
     * @param distChCode    Distribution channel code
     * @return PO Number
     * @throws CustomerLinkBusinessException If occurs some business exception
     */
    String generatePONumber(String clOrderType, String subRegionCode, String distChCode) throws CustomerLinkBusinessException;
}
