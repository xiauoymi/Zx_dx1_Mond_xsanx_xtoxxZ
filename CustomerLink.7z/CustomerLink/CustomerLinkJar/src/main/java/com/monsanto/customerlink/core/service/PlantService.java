package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.List;

public interface PlantService {

    /**
     * Lets get plants recover configured by type of CROP
     * @param cropConfig
     * @param distributorConfigDTO
     * @return
     */
    List<PlantVO> obtainPlantsAccordingToCrop(CropVO cropConfig, DistributorConfigDTO distributorConfigDTO);

    List<PlantVO> obtainPlantsAccordingToCrop(String cropCode, DistributorConfigDTO distributorConfigDTO);
}
