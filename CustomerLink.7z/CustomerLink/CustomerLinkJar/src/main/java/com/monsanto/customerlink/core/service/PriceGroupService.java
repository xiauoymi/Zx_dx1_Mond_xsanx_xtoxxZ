package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.ConditionTypeNotFoundForProductException;
import com.monsanto.customerlink.core.service.exception.PriceGroupNotFoundForOrderException;
import com.monsanto.customerlink.persistence.entities.PriceGroupVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;

public interface PriceGroupService {

    public PriceGroupDTO findPriceGroupForOrder(DistributorConfigDTO configDTO, String brandCode,
                                                String cropCode) throws PriceGroupNotFoundForOrderException, ActiveSeasonNotFoundException;

    public String findConditionTypeForProduct(ProductDTO productDTO) throws ConditionTypeNotFoundForProductException;

    PriceGroupVO retrievePriceGroupByCode(String priceGroupCode) throws PriceGroupNotFoundForOrderException;
}
