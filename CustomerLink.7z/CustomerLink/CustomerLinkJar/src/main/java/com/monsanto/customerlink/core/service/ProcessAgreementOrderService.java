package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;
import java.util.Map;

public interface ProcessAgreementOrderService {
    /**
     * @param mapOrdersAgreement map that contains a list of order per agreement. Each list will be processed to know
     *                           if matches or fulfill the agreement, if an order dot not full fill , it is sended  to  be created
     *                           to agrochemical service,  if  an order not matches with its order in sap a mail is sended
     *                           if  an order was created and  matches with agreement so nothings happened.
     *                           <p/>
     *                           When all orders for each agreement are completed the status for the agreement is changed to POSTED
     */
    public boolean processAgrochemicalOrders(Map<AgreementDTO, List<OrderDTO>> mapOrdersAgreement);
}
