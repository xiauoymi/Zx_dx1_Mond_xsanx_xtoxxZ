package com.monsanto.customerlink.core.service;

public interface ProcessAgrementService {


    /**
     * Takes Agreement with status Approved and aimed to private brands distributor,
     * and send these are sended to sap service to create agrochemicals orders
     * <p/>
     * <li>First step:  obtain distributor for private brands</li>
     * <li>Second step: obtain all agreements Approved for the last ditributors</li>
     * <li>Consult currency and divide orders if necessary</li>
     * <li>Verify if order exist in SAP</li>
     * <li>Consult inventory and obtain plants for the order</li>
     * <li>Send order to be created in SAP</li>
     */
    public void processAgreementService();
}
