package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;

public interface ProcessAtpService {

    public void processAtp() ;
}
