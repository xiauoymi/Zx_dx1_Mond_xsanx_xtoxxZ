package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.Map;

public interface ProcessOrderInSapService {

    public boolean processOrdersWithSapOrder(Map<OrderDTO, SAPOrderDTO> mapAllOrdersSapOrder, AgreementDTO agreementDTO) ;

}
