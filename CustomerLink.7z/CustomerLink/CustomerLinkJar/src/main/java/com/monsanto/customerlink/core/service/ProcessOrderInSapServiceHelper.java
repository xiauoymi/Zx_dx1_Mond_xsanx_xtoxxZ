package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;

import java.util.List;

public interface ProcessOrderInSapServiceHelper {

    void filterMaterialsWithIncreaseQuantity(OrderDTO orderDTO,List<MaterialSkuDTO> materialsWithDifference);

    boolean updateAgrochemicalOrderOnSAP(OrderDTO orderDTO, SAPOrderDTO sapOrderDTO);

}
