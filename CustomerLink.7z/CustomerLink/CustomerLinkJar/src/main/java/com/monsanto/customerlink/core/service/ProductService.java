package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;

import java.util.List;

public interface ProductService {

    /**
     * @param salesDivision
     * @param subSalesDivision
     * @param privateBrandDistributor
     * @param productCodes
     * @param isByhHybrid
     * @return
     * @throws Exception
     */
    List<ProductDTO> getProductsByParameters(String salesDivision, String subSalesDivision, String privateBrandDistributor, List<String> productCodes, Boolean isByhHybrid);

}