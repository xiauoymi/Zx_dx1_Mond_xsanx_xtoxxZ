package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurcharseOrderDTO;

import java.util.List;

public interface PurchaseOrderService {

    /**
     * @param purcharseOrderDTO
     * @return list of purchase order which meet with parameters
     * @throws PurchaseOrderNotFoundException if any purchase order is found with parameters received an empty list is returned
     */
    public List<PurcharseOrderDTO> retrievePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO) throws PurchaseOrderNotFoundException;

    /**
     * @param purcharseOrderDTO
     * @param distributorConfigDTO
     * @return
     * @throws PurchaseOrderWithoutDetailException
     *
     * @throws SeasonNotFoundException
     * @throws DistributorConfigNotFoundException
     *
     * @throws PurchaseorderAlreadyExistException
     *
     */
    public PurcharseOrderDTO createPurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO) throws PurchaseOrderWithoutDetailException,
            SeasonNotFoundException, DistributorConfigNotFoundException, PurchaseorderAlreadyExistException;

    /**
     * @param purcharseOrderDTO
     * @param distributorConfigDTO
     * @return
     * @throws PurchaseOrderNotFoundException
     * @throws SeasonNotFoundException
     * @throws DistributorConfigNotFoundException
     *
     */
    public PurcharseOrderDTO deletePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO)
            throws PurchaseOrderNotFoundException, SeasonNotFoundException, DistributorConfigNotFoundException;

    /**
     * @param purcharseOrderVO
     * @param distributorConfigDTO
     * @return
     * @throws PurchaseOrderNotFoundException
     * @throws SeasonNotFoundException
     * @throws DistributorConfigNotFoundException
     *
     */
    public PurcharseOrderDTO updatePurchaseOrder(PurcharseOrderDTO purcharseOrderVO, DistributorConfigDTO distributorConfigDTO)
            throws PurchaseOrderNotFoundException, SeasonNotFoundException, DistributorConfigNotFoundException;

    /**
     * @param orderDTO
     * @throws SeasonNotFoundException
     * @throws DistributorConfigNotFoundException
     *
     * @throws PurchaseOrderApprovedNotFoundException
     *
     */
    public void validateExistPurchaseOrderApproved(OrderDTO orderDTO) throws SeasonNotFoundException,
            DistributorConfigNotFoundException, PurchaseOrderApprovedNotFoundException;

    /**
     * @param purcharseOrderVO
     * @param distributorConfigDTO
     * @throws SeasonNotFoundException
     * @throws DistributorConfigNotFoundException
     *
     * @throws PurchaseOrderApprovedNotFoundException
     *
     */
    public void approvePurchaseOrder(PurcharseOrderDTO purcharseOrderVO, DistributorConfigDTO distributorConfigDTO) throws SeasonNotFoundException,
            DistributorConfigNotFoundException, PurchaseOrderNotFoundException;
}
