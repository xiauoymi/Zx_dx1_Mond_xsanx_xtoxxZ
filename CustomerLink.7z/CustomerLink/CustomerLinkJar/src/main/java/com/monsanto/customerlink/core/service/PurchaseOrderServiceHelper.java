package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.PurchaseOrderVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;

import java.util.Collection;

public interface PurchaseOrderServiceHelper {
    Collection<PurchaseOrderVO> obtainPurchaseOrderByParameters(SeasonVO seasonVo, DistributorProfileVO distvo, RepresentativeDTO representative);
}
