package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderInventoryNotFoundException;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.AgrochemicalMaterialDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface RegularAgrochemicalInventoryHelper {

    /**
     *  Allows the assignment of inventory recovered from sap, if the total materials may be assigned by the order is created in sap
     *  If it is not possible to assign at least one material with inventory available AgrochemicalOrderInventoryNotFoundException exception is thrown.
     *  If when creating the order in sap errors exist, the exception is thrown AgrochemicalCreateOrderErrorException
     * @param orderDTO
     * @param inventory
     * @param errors
     * @throws CustomerLinkBusinessException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalCreateOrderErrorException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderInventoryNotFoundException
     */
    void assignInventoryAgrochemicalOrder(OrderDTO orderDTO, List<AgrochemicalMaterialDTO> inventory,
                                                List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException;

    /**
     * Builds and sends notification for lack of inventory to create an order of agrochemicals, once sent the notice
     * AgrochemicalOrderInventoryNotFoundException exception is thrown.
     * @param orderDTO
     * @param errors
     * @throws AgrochemicalOrderInventoryNotFoundException
     */
    void notifyInventoryNotFound(OrderDTO orderDTO, List<ErrorOrderDTO> errors)
            throws AgrochemicalOrderInventoryNotFoundException;

}