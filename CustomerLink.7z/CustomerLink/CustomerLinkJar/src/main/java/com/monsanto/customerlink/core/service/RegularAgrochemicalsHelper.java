package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderPlantsNotFoundException;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;

import java.util.List;

public interface RegularAgrochemicalsHelper {

    /**
     * Gets the request to obtain inventory for the regular agrochemicals.
     * If there are no plants configured for inventory, the system throws exception AgrochemicalOrderPlantsNotFoundException
     * @param orderDTO
     * @return
     * @throws AgrochemicalOrderPlantsNotFoundException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderPlantsNotFoundException
     */
    List<MaterialDTO> createRequestInventory(OrderDTO orderDTO) throws AgrochemicalOrderPlantsNotFoundException;

    /**
     * Validates the input parameters for an order, if the input parameters are incomplete the system throws
     * the following exception AgrochemicalOrderMissingArgumentsException
     * @param orderDTO
     * @throws AgrochemicalOrderMissingArgumentsException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderMissingArgumentsException
     */
    void validateInputParametersForAgrochemicals(OrderDTO orderDTO) throws AgrochemicalOrderMissingArgumentsException;

    /**
     * plants get configured for a regular agrochemicals order if there are no plants configured, the system
     * throws the following exception AgrochemicalOrderPlantsNotFoundException
     * @param orderDTO
     * @return
     * @throws AgrochemicalOrderPlantsNotFoundException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderPlantsNotFoundException
     */
    List<PlantVO> obtainRegularAgrochemicalPlants(OrderDTO orderDTO) throws AgrochemicalOrderPlantsNotFoundException;

    /**
     * Builds and sends the message to notify lack of inventory in creating regular agrochemicals order
     * @param listOfSku
     * @param distributorConfigDTO
     * @param listError
     */
    void sendMessageMissingInventory(List<MaterialSkuDTO> listOfSku,
                                     DistributorConfigDTO distributorConfigDTO,
                                     List<ErrorOrderDTO> listError);

}