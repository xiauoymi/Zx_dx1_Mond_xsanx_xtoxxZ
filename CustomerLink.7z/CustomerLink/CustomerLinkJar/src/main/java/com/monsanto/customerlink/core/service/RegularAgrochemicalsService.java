package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface RegularAgrochemicalsService {

    /**
     * Processing an Agrochemicals order as a result of the approval of agreement.
     * If there are no plants configured to process the order, the system throws the following exception AgrochemicalOrderPlantsNotFoundException
     * If there is no complete inventory to fill the order, the system throws the following exception AgrochemicalOrderInventoryNotFoundException
     * If when creating the order in sap errors exist, the exception is thrown AgrochemicalCreateOrderErrorException
     * @param atpOrder
     * @throws com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderPlantsNotFoundException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalOrderInventoryNotFoundException
     * @see com.monsanto.customerlink.core.service.exception.AgrochemicalCreateOrderErrorException
     *
     */
    void processAgrochemicalsOrder(OrderDTO atpOrder, boolean isUpdate) throws CustomerLinkBusinessException;
}