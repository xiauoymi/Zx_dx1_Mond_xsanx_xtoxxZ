package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface RetrieveSAPOrderHelper {

    SAPOrderDTO retrieveSeedSAPOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException;

    SAPOrderDTO retrieveAgrochemicalSAPOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException;
}
