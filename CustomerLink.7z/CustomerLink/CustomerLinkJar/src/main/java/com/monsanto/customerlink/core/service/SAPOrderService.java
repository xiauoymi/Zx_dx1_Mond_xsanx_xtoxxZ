package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.FoundMoreThanASAPOrderException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface SAPOrderService {

    /**
     * Creates/Updates the SAP Order
     * if orderDTO.getOrderIdSAP == null -> create the order
     * else                              -> update the order
     *
     * @param orderDTO the order to create/update
     * @return the SAP Order
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    SAPOrderDTO postOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Retrieves SAP order associated with search parameters
     * Sales Organization,
     * Distribution Channel,
     * Sales Division,
     * Distributor Code,
     * Order Reason Code
     *
     * @param orderDTO object with search parameters
     * @return the order if it's found at the repository
     *         null if isn´t found at the repository
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    SAPOrderDTO retrieveOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException;


    /**
     * Creates/Updates the SAP Order
     * if orderDTO.getOrderIdSAP == null -> create the order
     * else                              -> update the order
     *
     * @param orderDTO the order to create/update
     * @return the SAP Order
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    SAPOrderDTO postOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;
}
