package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.OrderTypeNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderTypeVO;

public interface SAPOrderTypeService {

    OrderTypeVO retrieveSapOrderType(String distributionChannelCode, String cropCode) throws OrderTypeNotFoundException;

    OrderTypeVO retrieveSapOrderTypeByCode(String orderTypeCode) throws OrderTypeNotFoundException;
}
