package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;

import java.util.Date;

public interface SeasonService {

    /**
     * Retrieves the active season for the combination sub-region and date
     *
     * @param subRegionCode
     * @param date
     * @return the active season
     * @throws ActiveSeasonNotFoundException if the active season not be found
     */
    SeasonVO retrieveActiveSeason(String subRegionCode, Date date) throws ActiveSeasonNotFoundException;

    /**
     * Retrieves a search period according to current season and sub-region
     *
     * @return a search period
     * @throws ActiveSeasonNotFoundException if the active season not be found
     */
    SearchPeriodDTO retrieveSearchPeriod(String subRegionCode) throws ActiveSeasonNotFoundException;
}
