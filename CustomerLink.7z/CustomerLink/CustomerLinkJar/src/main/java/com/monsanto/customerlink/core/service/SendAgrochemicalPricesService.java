package com.monsanto.customerlink.core.service;


import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface SendAgrochemicalPricesService {
    public List<OrderDTO> obtainOrderByCurrency(List<OrderDTO> list);

}
