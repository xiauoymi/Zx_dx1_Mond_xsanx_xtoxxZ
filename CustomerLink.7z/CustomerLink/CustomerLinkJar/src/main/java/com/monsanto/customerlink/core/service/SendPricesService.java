package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CurrencyNotFoundException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface SendPricesService {

    /**
     * @param list orders list wich will be examinated and separated in the same number of orders or more
     *             depending if their hybrids has one o more currencies
     * @return
     */
    public List<OrderDTO> obtainOrderByCurrency(List<OrderDTO> list) ;
}
