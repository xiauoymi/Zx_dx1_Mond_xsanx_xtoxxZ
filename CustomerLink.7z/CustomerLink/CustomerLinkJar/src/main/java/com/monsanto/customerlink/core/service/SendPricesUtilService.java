package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface SendPricesUtilService {

    public void obtainCurrencies(OrderDTO orderDTO, List<OrderDTO> orderDTOListByCurrency) throws CustomerLinkBusinessException;

    public void obtainAgrochemicalCurrencies(OrderDTO orderDTO, List<OrderDTO> orderDTOListByCurrency) throws CustomerLinkBusinessException;

}
