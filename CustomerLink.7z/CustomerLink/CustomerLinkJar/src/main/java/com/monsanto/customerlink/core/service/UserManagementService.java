package com.monsanto.customerlink.core.service;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.customerlink.core.service.dto.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.InvalidUserException;
import com.monsanto.customerlink.core.service.exception.UserNotAvailableForRemoveException;
import com.monsanto.customerlink.persistence.entities.UserVO;

import java.util.List;

public interface UserManagementService {

    /**
     * Get list of currently configured users-role in the system for a role type
     * @param roleCode identifier of role type
     * @return list of UserRoleDTO
     * @see com.monsanto.customerlink.core.service.dto.GridUserRoleDTO
     */
    List<GridUserRoleDTO> getListOfUsersByRole(String roleCode);

    /**
     * Creates or updates an object of type UserRoleDTO, for the case of RCD-RBM roles can only upgrade the "UserName"
     * @param userRole contains the information to update user-role information
     * @return true if the create/update was executed successfully, false otherwise
     * @throws InvalidUserException If the user name is not a valid user monsanto
     * @see com.monsanto.customerlink.core.service.exception.InvalidUserException
     **/
    boolean createUpdateUserRole(UserRoleDTO userRole) throws CustomerLinkBusinessException;

    /**
     * Delete the user-role combination does not apply for roles RCD-RBM
     * @param userRole contains the information to update user-role information
     * @return true if the create/update was executed successfully, false otherwise
     * @throws UserNotAvailableForRemoveException if the user is associated with any process within the system
     * @see com.monsanto.customerlink.core.service.exception.UserNotAvailableForRemoveException
     **/
    boolean removeUserRole(UserRoleDTO userRole)throws CustomerLinkBusinessException;

    /**
     * Get list of currently configured users-role in the system for a Distributor Profile ID.
     * @param idDistributorProfile identifier of distributor profile
     * @return list of UserVO
     * @see com.monsanto.customerlink.core.service.dto.UserRoleDTO
     **/
    List<UserVO> getListOfUserByDistributorProfileId(Long idDistributorProfile);

    public PersonInfo[] getPeople(String userName) throws Exception;
}