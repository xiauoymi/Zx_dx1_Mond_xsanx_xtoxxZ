package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.dto.UserRoleDTO;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.UserVO;

import java.util.List;

public interface UserManagementServiceHelper {

    void filterUsers(List<UserVO> list,String roleCode);

    boolean replicateProcessForRCD(UserVO u, UserRoleDTO userRoleDTO, RoleEnum roleEnum, UserManagementService ums) throws CustomerLinkBusinessException;

    boolean isCsrOrApprover(RoleEnum roleEnum);

}