package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.RCDNotFoundException;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.List;

public interface UserService {

    public List<UserVO> findUserBySubregionAndRole(String subregionCode, Long roleCode);

    public List<UserVO> findRoleByUserCode(String userCode);

    public UserVO saveUser(UserVO userVO, String subRegionCode, Long roleCode);

    public List<UserVO> findRoleByUserName(String userName);

    UserVO retrieveRCD(String userCode, DistributorConfigDTO distributorProfile) throws RCDNotFoundException;

    List<UserVO> retrieveRCDs(DistributorConfigDTO distributorProfile);

    List<UserVO> retrieveUsersByDistributorAndRole(String idDistributor,RoleEnum roleEnum);

}