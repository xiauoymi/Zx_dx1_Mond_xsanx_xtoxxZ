package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;

import java.util.Collection;

public interface WFApprovalService {

    /**
     * Create a workflow approval for a business entity
     * @param businessEntityId business object identifier to be approve
     * @return true if the creation was executed successfully, false otherwise
     * @throws com.monsanto.customerlink.core.service.exception.WFApprovalMissingConfigurationException if There is no configuration for the approval workflow
     * @throws com.monsanto.customerlink.core.service.exception.WFApprovalAlreadyExistException if There is already a workflow with the same characteristics with pending status or in progress
     * @throws com.monsanto.customerlink.core.service.exception.WFApprovalMissingUsersMembersConfigurationException if There are no users configured to create the workflow members for the sub Region
     *
     */
    boolean createWorkFlowApproval(Long businessEntityId)  throws CustomerLinkBusinessException;

    /**
     * Get a collection of business object identifiers that are in status "Pending approval" for a user
     * @param userId identifier related to the combination of UserName, Role, Region
     * @return ids list of business entities pending approval status by the user
     */
    Collection<Long> obtainApprovalsPendingBusinessByUser(Long userId);

    /**
     * Allows approve the workflow associated with a user and a business entity
     * @param businessEntityId identifier of the business entity that you want to approve
     * @param userId identifier related to the combination of UserName, Role, Region
     * @return true if it was possible to adopt the workflow, false otherwise
     */
    boolean approveWorkflowByUser(Long businessEntityId, Long userId);

    /**
     * Rejects the workflow associated to a user and a business entity
     * @param businessEntityId identifier of the business entity that you want to approve
     * @param userId identifier related to the combination of UserName, Role, Region
     * @return true if it was possible to reject the workflow, false otherwise
     */
    boolean rejectWorkflowByUser(Long businessEntityId, Long userId);
}