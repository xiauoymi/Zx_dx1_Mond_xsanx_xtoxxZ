package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;

import java.util.Map;

public interface WFApprovalServiceHelper {

    void updateFinalMapWithUser(Long userId, Map<String, Object> map);

    Map<String, ?> getMessageMapFromFinalMap(Map<String, Object> map);

    DistributorConfigDTO getDistributorConfigFromFinalMap(Map<String, Object> map);
}