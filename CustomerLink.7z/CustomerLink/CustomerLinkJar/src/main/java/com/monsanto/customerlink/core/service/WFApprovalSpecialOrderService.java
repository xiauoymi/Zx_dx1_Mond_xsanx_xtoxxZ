package com.monsanto.customerlink.core.service;

public interface WFApprovalSpecialOrderService extends WFApprovalService{

}