package com.monsanto.customerlink.core.service.catalog;

import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;

import java.util.List;

public interface SubregionService {

    public List<SubRegionDTO> findAllSubregions();
}
