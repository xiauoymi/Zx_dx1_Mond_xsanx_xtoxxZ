package com.monsanto.customerlink.core.service.catalog.impl;

import com.monsanto.customerlink.core.service.catalog.SubregionService;
import com.monsanto.customerlink.persistence.entities.SubRegionVO;
import com.monsanto.customerlink.persistence.repositories.SubRegionRepository;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SubregionServiceImpl implements SubregionService {


    private SubRegionRepository subRegionRepository;
    private Mapper mapper;

    @Autowired
    public SubregionServiceImpl(SubRegionRepository subRegionRepository, Mapper mapper ) {
        this.subRegionRepository = subRegionRepository;
        this.mapper=mapper;
    }

    @Override
    public List<SubRegionDTO> findAllSubregions() {

        List<SubRegionDTO> subRegionDTOList= new ArrayList<SubRegionDTO>();
        List<SubRegionVO> subRegionVOList=subRegionRepository.findAll();

        for(SubRegionVO subRegionVO: subRegionVOList){
            SubRegionDTO subRegionDTO= mapper.map(subRegionVO, SubRegionDTO.class);
            subRegionDTOList.add(subRegionDTO);
        }

        return subRegionDTOList;
    }
}
