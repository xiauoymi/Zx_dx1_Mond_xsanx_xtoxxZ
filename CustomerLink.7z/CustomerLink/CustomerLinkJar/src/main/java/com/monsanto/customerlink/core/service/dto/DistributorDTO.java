package com.monsanto.customerlink.core.service.dto;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributorDTO extends BaseDTO {

    @JsonProperty
    private String distributorCode;

    @JsonProperty
    private String distributorDesc;

    @JsonProperty
    private KeyDTO keyDTO;

    public DistributorDTO() {
    }

    public DistributorDTO(String distributorCode, String distributorDesc) {
        this.distributorCode = distributorCode;
        this.distributorDesc = distributorDesc;
    }

    public String getDistributorCode() {
        return distributorCode;
    }

    public void setDistributorCode(String distributorCode) {
        this.distributorCode = distributorCode;
    }

    public String getDistributorDesc() {
        return distributorDesc;
    }

    public void setDistributorDesc(String distributorDesc) {
        this.distributorDesc = distributorDesc;
    }

    public KeyDTO getKeyDTO() {
        return keyDTO;
    }

    public void setKeyDTO(KeyDTO keyDTO) {
        this.keyDTO = keyDTO;
    }
}