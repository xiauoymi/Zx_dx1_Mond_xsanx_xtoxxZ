package com.monsanto.customerlink.core.service.dto;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KeyDTO extends BaseDTO {

    @JsonProperty
    private Long distributorProfileId;

    @JsonProperty
    private String salesOrgCode;

    @JsonProperty
    private String salesOrgDesc;

    @JsonProperty
    private String salesDivCode;

    @JsonProperty
    private String salesDivDesc;

    @JsonProperty
    private String distChannelCode;

    @JsonProperty
    private String distChannelDesc;

    @JsonProperty
    private String subRegionCode;

    @JsonProperty
    private String subRegionDesc;

    public KeyDTO() {

    }

    public KeyDTO(String salesOrgCode, String salesDivCode, String distChannelCode) {
        this.salesOrgCode = salesOrgCode;
        this.salesDivCode = salesDivCode;
        this.distChannelCode = distChannelCode;
    }

    public Long getDistributorProfileId() {
        return distributorProfileId;
    }

    public void setDistributorProfileId(Long distributorProfileId) {
        this.distributorProfileId = distributorProfileId;
    }

    public String getSalesOrgCode() {
        return salesOrgCode;
    }

    public void setSalesOrgCode(String salesOrgCode) {
        this.salesOrgCode = salesOrgCode;
    }

    public String getSalesOrgDesc() {
        return salesOrgDesc;
    }

    public void setSalesOrgDesc(String salesOrgDesc) {
        this.salesOrgDesc = salesOrgDesc;
    }

    public String getSalesDivCode() {
        return salesDivCode;
    }

    public void setSalesDivCode(String salesDivCode) {
        this.salesDivCode = salesDivCode;
    }

    public String getSalesDivDesc() {
        return salesDivDesc;
    }

    public void setSalesDivDesc(String salesDivDesc) {
        this.salesDivDesc = salesDivDesc;
    }

    public String getDistChannelCode() {
        return distChannelCode;
    }

    public void setDistChannelCode(String distChannelCode) {
        this.distChannelCode = distChannelCode;
    }

    public String getDistChannelDesc() {
        return distChannelDesc;
    }

    public void setDistChannelDesc(String distChannelDesc) {
        this.distChannelDesc = distChannelDesc;
    }

    public String getSubRegionCode() {
        return subRegionCode;
    }

    public void setSubRegionCode(String subRegionCode) {
        this.subRegionCode = subRegionCode;
    }

    public String getSubRegionDesc() {
        return subRegionDesc;
    }

    public void setSubRegionDesc(String subRegionDesc) {
        this.subRegionDesc = subRegionDesc;
    }
}