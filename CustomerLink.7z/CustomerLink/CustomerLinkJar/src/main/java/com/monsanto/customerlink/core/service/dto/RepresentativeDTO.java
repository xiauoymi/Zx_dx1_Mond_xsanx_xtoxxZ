package com.monsanto.customerlink.core.service.dto;

import java.io.Serializable;

public class RepresentativeDTO extends BaseDTO{

    private String salesOrgCode;
    private String distChCode;
    private String salesDivCode;
    private String subRegionCode;
    private String userName;
    private String brand;
    private String sapUserId;
    private Long roleCode;
    private String roleDesc;
    private String email;

    public RepresentativeDTO() {
    }

    public RepresentativeDTO(String userName, String brand, String roleDesc, String subRegionCode) {
        this.userName = userName;
        this.brand = brand;
        this.roleDesc = roleDesc;
        this.subRegionCode = subRegionCode;
    }

    public String getSalesOrgCode() {
        return salesOrgCode;
    }

    public void setSalesOrgCode(String salesOrgCode) {
        this.salesOrgCode = salesOrgCode;
    }

    public String getDistChCode() {
        return distChCode;
    }

    public void setDistChCode(String distChCode) {
        this.distChCode = distChCode;
    }

    public String getSalesDivCode() {
        return salesDivCode;
    }

    public void setSalesDivCode(String salesDivCode) {
        this.salesDivCode = salesDivCode;
    }

    public String getSubRegionCode() {
        return subRegionCode;
    }

    public void setSubRegionCode(String subRegionCode) {
        this.subRegionCode = subRegionCode;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSapUserId() {
        return sapUserId;
    }

    public void setSapUserId(String sapUserId) {
        this.sapUserId = sapUserId;
    }

    public Long getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(Long roleCode) {
        this.roleCode = roleCode;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}