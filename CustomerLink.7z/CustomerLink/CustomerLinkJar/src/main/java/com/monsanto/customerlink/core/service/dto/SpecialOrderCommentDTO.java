package com.monsanto.customerlink.core.service.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SpecialOrderCommentDTO extends BaseDTO {

    @JsonProperty
    private String comment;
    @JsonProperty
    private String date;
    @JsonProperty
    private String createdBy;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof SpecialOrderCommentDTO)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        SpecialOrderCommentDTO oAsSpecialOrderHybridDTO = (SpecialOrderCommentDTO) o;
        return new EqualsBuilder().
                append(comment, oAsSpecialOrderHybridDTO.comment).
                append(date, oAsSpecialOrderHybridDTO.date).
                append(createdBy, oAsSpecialOrderHybridDTO.createdBy).
                isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().
                append(comment).
                append(date).
                append(createdBy).
                toHashCode();
    }
}
