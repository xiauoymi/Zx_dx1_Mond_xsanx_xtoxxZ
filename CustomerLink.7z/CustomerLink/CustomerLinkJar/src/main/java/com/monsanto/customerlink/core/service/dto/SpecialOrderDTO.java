package com.monsanto.customerlink.core.service.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SpecialOrderDTO extends BaseDTO {

    @JsonProperty
    private Long idSpecialOrder;

    @JsonProperty
    private Long userId;

    @JsonProperty
    private DistributorDTO distributorDTO;

    @JsonProperty
    private List<SpecialOrderHybridDTO> hybrids;

    @JsonProperty
    private String createDate;

    @JsonProperty
    private List<SpecialOrderCommentDTO> comments;


    public Long getIdSpecialOrder() {
        return idSpecialOrder;
    }

    public void setIdSpecialOrder(Long idSpecialOrder) {
        this.idSpecialOrder = idSpecialOrder;
    }

    public List<SpecialOrderHybridDTO> getHybrids() {
        return hybrids;
    }

    public void setHybrids(List<SpecialOrderHybridDTO> hybrids) {
        this.hybrids = hybrids;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public DistributorDTO getDistributorDTO() {
        return distributorDTO;
    }

    public void setDistributorDTO(DistributorDTO distributorDTO) {
        this.distributorDTO = distributorDTO;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public List<SpecialOrderCommentDTO> getComments() {
        return comments;
    }

    public void setComments(List<SpecialOrderCommentDTO> comments) {
        this.comments = comments;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof SpecialOrderDTO)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        SpecialOrderDTO oAsSpecialOrderDTO = (SpecialOrderDTO) o;
        return new EqualsBuilder().
                append(idSpecialOrder, oAsSpecialOrderDTO.idSpecialOrder).
                append(hybrids, oAsSpecialOrderDTO.hybrids).
                append(userId, oAsSpecialOrderDTO.userId).
                append(comments, oAsSpecialOrderDTO.comments).
                isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(idSpecialOrder).append(hybrids).append(userId).append(comments).toHashCode();
    }
}