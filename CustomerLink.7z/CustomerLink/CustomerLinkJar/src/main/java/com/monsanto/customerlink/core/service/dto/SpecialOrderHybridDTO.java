package com.monsanto.customerlink.core.service.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SpecialOrderHybridDTO  extends BaseDTO {

    @JsonProperty
    private String hybrid;
    @JsonProperty
    private Double quantity;
    @JsonProperty
    private String umb;
    @JsonProperty
    private String orderDetailId;

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getUmb() {
        return umb;
    }

    public void setUmb(String umb) {
        this.umb = umb;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof SpecialOrderHybridDTO)) {
            return false;
        }
        if (o == this) {
            return true;
        }
        SpecialOrderHybridDTO oAsSpecialOrderHybridDTO = (SpecialOrderHybridDTO) o;
        return new EqualsBuilder().
                append(hybrid, oAsSpecialOrderHybridDTO.hybrid).
                append(quantity, oAsSpecialOrderHybridDTO.quantity).
                append(umb, oAsSpecialOrderHybridDTO.umb).
                append(orderDetailId,oAsSpecialOrderHybridDTO.orderDetailId).
                isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().
                append(hybrid).
                append(quantity).
                append(umb).
                append(orderDetailId).
                toHashCode();
    }

    public String getOrderDetailId() {
        return orderDetailId;
    }

    public void setOrderDetailId(String orderDetailId) {
        this.orderDetailId = orderDetailId;
    }
}
