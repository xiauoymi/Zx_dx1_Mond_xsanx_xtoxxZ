package com.monsanto.customerlink.core.service.dto;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubRegionDTO  extends BaseDTO {

    @JsonProperty
    private String subRegionCode;

    @JsonProperty
    private String subRegionDesc;

    public String getSubRegionCode() {
        return subRegionCode;
    }

    public void setSubRegionCode(String subRegionCode) {
        this.subRegionCode = subRegionCode;
    }

    public String getSubRegionDesc() {
        return subRegionDesc;
    }

    public void setSubRegionDesc(String subRegionDesc) {
        this.subRegionDesc = subRegionDesc;
    }
}