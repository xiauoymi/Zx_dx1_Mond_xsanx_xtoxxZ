package com.monsanto.customerlink.core.service.dto;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserRoleDTO extends BaseDTO{

    @JsonProperty
    private Long idUser;

    @JsonProperty
    private String userName;

    @JsonProperty
    private String email;

    @JsonProperty
    private RoleDTO roleDTO;

    @JsonProperty
    private KeyDTO keyDTO;

    @JsonProperty
    private BrandDTO brandDTO;

    @JsonProperty
    private SubRegionDTO subRegionDTO;

    @JsonProperty
    private List<DistributorDTO> listOfDistributors;

    public UserRoleDTO() {
    }

    public UserRoleDTO(Long idUser) {
        this.idUser = idUser;
    }

    public Long getIdUser() {
        return idUser;
    }

    public void setIdUser(Long idUser) {
        this.idUser = idUser;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public RoleDTO getRoleDTO() {
        return roleDTO;
    }

    public void setRoleDTO(RoleDTO roleDTO) {
        this.roleDTO = roleDTO;
    }

    public KeyDTO getKeyDTO() {
        return keyDTO;
    }

    public void setKeyDTO(KeyDTO keyDTO) {
        this.keyDTO = keyDTO;
    }

    public BrandDTO getBrandDTO() {
        return brandDTO;
    }

    public void setBrandDTO(BrandDTO brandDTO) {
        this.brandDTO = brandDTO;
    }

    public SubRegionDTO getSubRegionDTO() {
        return subRegionDTO;
    }

    public void setSubRegionDTO(SubRegionDTO subRegionDTO) {
        this.subRegionDTO = subRegionDTO;
    }

    public List<DistributorDTO> getListOfDistributors() {
        return listOfDistributors;
    }

    public void setListOfDistributors(List<DistributorDTO> listOfDistributors) {
        this.listOfDistributors = listOfDistributors;
    }
}