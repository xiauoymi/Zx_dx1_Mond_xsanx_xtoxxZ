package com.monsanto.customerlink.core.service.exception;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 30/05/13
 * Time: 04:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgreementAlreadyExistsException extends CustomerLinkBusinessException {

    private String code = "agreementAlreadyExistsException";

    public AgreementAlreadyExistsException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }


}

