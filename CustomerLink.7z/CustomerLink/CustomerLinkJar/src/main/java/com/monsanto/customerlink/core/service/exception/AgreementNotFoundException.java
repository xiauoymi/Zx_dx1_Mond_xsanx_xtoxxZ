package com.monsanto.customerlink.core.service.exception;


public class AgreementNotFoundException extends CustomerLinkBusinessException {

    private String code = "agreementNotFoundException";

    public AgreementNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }


}
