package com.monsanto.customerlink.core.service.exception;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 28/05/13
 * Time: 06:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgreementRetrieveByParametersNotFoundException extends CustomerLinkBusinessException {

    private String code = "agreementRetrieveByParametersNotFoundException";

    public AgreementRetrieveByParametersNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
