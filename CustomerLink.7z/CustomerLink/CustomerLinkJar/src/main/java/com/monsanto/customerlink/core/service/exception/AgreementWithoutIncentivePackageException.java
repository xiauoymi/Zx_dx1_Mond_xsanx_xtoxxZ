package com.monsanto.customerlink.core.service.exception;


public class AgreementWithoutIncentivePackageException extends CustomerLinkBusinessException {

    private String code = "agreementWithoutIncentivePackageException";

    public AgreementWithoutIncentivePackageException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

