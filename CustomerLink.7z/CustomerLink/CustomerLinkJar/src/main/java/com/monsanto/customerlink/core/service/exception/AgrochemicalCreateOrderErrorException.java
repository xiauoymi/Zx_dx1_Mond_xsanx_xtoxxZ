package com.monsanto.customerlink.core.service.exception;

public class AgrochemicalCreateOrderErrorException extends CustomerLinkBusinessException {

    private String code = "agrochemicalCreateOrderErrorException";

    public AgrochemicalCreateOrderErrorException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

