package com.monsanto.customerlink.core.service.exception;

public class AgrochemicalOrderPlantsNotFoundException extends CustomerLinkBusinessException {

    private String code = "agrochemicalOrderPlantsNotFoundException";

    public AgrochemicalOrderPlantsNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

