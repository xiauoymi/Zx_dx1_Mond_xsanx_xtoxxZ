package com.monsanto.customerlink.core.service.exception;


public class CurrencyNotFoundException extends CustomerLinkBusinessException {

    private String code = "currencyNotFoundException";

    public CurrencyNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
