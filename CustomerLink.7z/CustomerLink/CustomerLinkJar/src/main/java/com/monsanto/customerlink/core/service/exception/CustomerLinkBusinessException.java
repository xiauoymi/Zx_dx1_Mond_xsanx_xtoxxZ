package com.monsanto.customerlink.core.service.exception;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class CustomerLinkBusinessException extends Exception {

    private String code = "businessException";

    private Object[] args;

    public void setCode(final String code) {
        this.code = code;
    }

    public void setArgs(final Object[] args) {
        this.args = args;
    }

    public String getMessage() {
        return getLocalizedMessage(Locale.getDefault());
    }

    public String getLocalizedMessage(final Locale currentLocale) {
        final ResourceBundle messages = ResourceBundle.getBundle("messages/MessageErrorBundle", currentLocale);
        final Object[] messageArguments = args;
        final MessageFormat formatter = new MessageFormat("");
        formatter.setLocale(currentLocale);
        formatter.applyPattern(messages.getString(code)==null?"":messages.getString(code));
        return formatter.format(messageArguments);
    }

    public CustomerLinkBusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public CustomerLinkBusinessException(){

    }

    public String getSuperMessage() {
        return super.getMessage();
    }
}

