package com.monsanto.customerlink.core.service.exception;


public class DeleteDeliveryNotFoundException extends CustomerLinkBusinessException {

    private String code = "deleteDeliveryNotFoundException";

    public DeleteDeliveryNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }


}
