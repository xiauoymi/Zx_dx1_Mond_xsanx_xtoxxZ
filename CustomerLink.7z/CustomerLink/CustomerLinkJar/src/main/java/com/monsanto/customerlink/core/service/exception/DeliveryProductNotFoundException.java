package com.monsanto.customerlink.core.service.exception;


public class DeliveryProductNotFoundException extends CustomerLinkBusinessException {

    private String code = "deliveryProductNotFoundException";

    public DeliveryProductNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }


}
