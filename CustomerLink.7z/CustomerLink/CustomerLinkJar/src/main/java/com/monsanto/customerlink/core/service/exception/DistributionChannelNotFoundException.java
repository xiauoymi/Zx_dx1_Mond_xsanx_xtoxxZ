package com.monsanto.customerlink.core.service.exception;

public class DistributionChannelNotFoundException extends CustomerLinkBusinessException {

    private String code = "distributionChannelNotFoundException";

    public DistributionChannelNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

