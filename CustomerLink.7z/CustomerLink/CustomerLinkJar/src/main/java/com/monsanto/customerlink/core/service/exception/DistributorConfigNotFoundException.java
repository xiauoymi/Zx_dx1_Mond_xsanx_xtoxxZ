package com.monsanto.customerlink.core.service.exception;

public class DistributorConfigNotFoundException extends CustomerLinkBusinessException {

    private String code = "distributorConfigNotFoundException";

    public DistributorConfigNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

