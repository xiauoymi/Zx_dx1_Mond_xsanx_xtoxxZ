package com.monsanto.customerlink.core.service.exception;

public class InvalidProductForPrivateDistributor extends CustomerLinkBusinessException {

    private String code = "invalidProductForPrivateDistributor";

    public InvalidProductForPrivateDistributor(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
