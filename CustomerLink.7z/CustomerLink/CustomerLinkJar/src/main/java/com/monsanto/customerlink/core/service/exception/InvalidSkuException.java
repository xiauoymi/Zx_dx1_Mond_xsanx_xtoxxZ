package com.monsanto.customerlink.core.service.exception;


public class InvalidSkuException extends CustomerLinkBusinessException {

    private String code = "invalidSkuException";

    public InvalidSkuException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
