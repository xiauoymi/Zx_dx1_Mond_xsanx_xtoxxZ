package com.monsanto.customerlink.core.service.exception;

public class InvalidUserParametersException extends CustomerLinkBusinessException {

    private String code = "invalidUserParametersException";

    public InvalidUserParametersException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
