package com.monsanto.customerlink.core.service.exception;

public class OrderReasonNotFoundException extends CustomerLinkBusinessException {

    private String code = "orderReasonNotFoundException";

    public OrderReasonNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public void setCode(final String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
