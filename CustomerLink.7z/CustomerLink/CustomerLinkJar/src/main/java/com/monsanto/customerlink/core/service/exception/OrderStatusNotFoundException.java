package com.monsanto.customerlink.core.service.exception;

public class OrderStatusNotFoundException extends CustomerLinkBusinessException {

    private String code = "orderStatusNotFoundException";

    public OrderStatusNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
