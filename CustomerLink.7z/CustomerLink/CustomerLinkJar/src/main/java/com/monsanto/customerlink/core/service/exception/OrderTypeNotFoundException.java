package com.monsanto.customerlink.core.service.exception;

public class OrderTypeNotFoundException extends CustomerLinkBusinessException {

    private String code = "orderTypeNotFoundException";

    public OrderTypeNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public void setCode(final String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
