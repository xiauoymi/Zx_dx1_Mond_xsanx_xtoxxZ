package com.monsanto.customerlink.core.service.exception;

public class OrdersNotFoundException extends CustomerLinkBusinessException {

    private String code = "ordersNotFoundException";

    public OrdersNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public void setCode(final String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
