package com.monsanto.customerlink.core.service.exception;

public class PriceGroupNotFoundForOrderException extends CustomerLinkBusinessException {

    private String code = "priceGroupNotFoundForOrderException";

    public PriceGroupNotFoundForOrderException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
