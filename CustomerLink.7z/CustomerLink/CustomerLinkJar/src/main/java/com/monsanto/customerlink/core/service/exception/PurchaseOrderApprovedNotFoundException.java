package com.monsanto.customerlink.core.service.exception;


public class PurchaseOrderApprovedNotFoundException extends CustomerLinkBusinessException {

    private String code = "purchaseOrderApprovedNotFoundException";

    public PurchaseOrderApprovedNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

