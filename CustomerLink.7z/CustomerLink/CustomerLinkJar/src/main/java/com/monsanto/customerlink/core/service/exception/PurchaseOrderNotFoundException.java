package com.monsanto.customerlink.core.service.exception;

public class PurchaseOrderNotFoundException extends CustomerLinkBusinessException {

    private String code = "purchaseOrderNotFoundException";

    public PurchaseOrderNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
