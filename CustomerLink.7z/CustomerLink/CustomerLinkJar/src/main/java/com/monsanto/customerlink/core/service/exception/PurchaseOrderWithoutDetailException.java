package com.monsanto.customerlink.core.service.exception;


public class PurchaseOrderWithoutDetailException extends CustomerLinkBusinessException {

    private String code = "purchaseOrderWithoutDetailException";

    public PurchaseOrderWithoutDetailException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
