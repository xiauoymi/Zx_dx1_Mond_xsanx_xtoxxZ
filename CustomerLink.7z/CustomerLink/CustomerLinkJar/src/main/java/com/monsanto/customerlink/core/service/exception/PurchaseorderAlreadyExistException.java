package com.monsanto.customerlink.core.service.exception;

public class PurchaseorderAlreadyExistException extends CustomerLinkBusinessException {

    private String code = "purchaseorderAlreadyExistException";

    public PurchaseorderAlreadyExistException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
