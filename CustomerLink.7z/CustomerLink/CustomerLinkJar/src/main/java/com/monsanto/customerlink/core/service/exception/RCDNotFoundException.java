package com.monsanto.customerlink.core.service.exception;

public class RCDNotFoundException extends CustomerLinkBusinessException {

    private String code = "rcdNotFoundException";

    public RCDNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
