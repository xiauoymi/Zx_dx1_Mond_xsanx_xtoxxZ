package com.monsanto.customerlink.core.service.exception;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 30/05/13
 * Time: 10:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class SeasonNotFoundException extends CustomerLinkBusinessException {

    private String code = "seasonNotFoundException";

    public SeasonNotFoundException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}

