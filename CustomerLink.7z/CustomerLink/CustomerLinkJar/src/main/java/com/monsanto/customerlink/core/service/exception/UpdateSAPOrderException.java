package com.monsanto.customerlink.core.service.exception;

public class UpdateSAPOrderException extends CustomerLinkBusinessException {

    private String code = "updateSAPOrderException";

    public UpdateSAPOrderException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
