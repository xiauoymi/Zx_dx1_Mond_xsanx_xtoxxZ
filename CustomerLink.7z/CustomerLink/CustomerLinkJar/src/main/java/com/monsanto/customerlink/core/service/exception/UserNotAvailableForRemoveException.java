package com.monsanto.customerlink.core.service.exception;

public class UserNotAvailableForRemoveException extends CustomerLinkBusinessException {

    private String code = "userNotAvailableForRemoveException";

    public UserNotAvailableForRemoveException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
