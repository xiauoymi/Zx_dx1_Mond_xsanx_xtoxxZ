package com.monsanto.customerlink.core.service.exception;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 4/06/13
 * Time: 01:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class VolumenGoalNotEnoughPeriodsException extends CustomerLinkBusinessException {

    private String code = "volumenGoalNotEnoughPeriodsException";

    public VolumenGoalNotEnoughPeriodsException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
