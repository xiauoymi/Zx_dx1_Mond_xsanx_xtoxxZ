package com.monsanto.customerlink.core.service.exception;

public class WFApprovalAlreadyExistException extends CustomerLinkBusinessException {

    private String code = "wfApprovalAlreadyExistException";

    public WFApprovalAlreadyExistException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
