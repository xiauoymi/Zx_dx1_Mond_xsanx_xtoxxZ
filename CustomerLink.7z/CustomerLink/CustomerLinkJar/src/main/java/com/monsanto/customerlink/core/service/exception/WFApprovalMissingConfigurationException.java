package com.monsanto.customerlink.core.service.exception;

public class WFApprovalMissingConfigurationException extends CustomerLinkBusinessException {

    private String code = "wfApprovalMissingConfigurationException";

    public WFApprovalMissingConfigurationException(final Object[] args) {
        super.setArgs(args);
    }

    @Override
    public String getMessage() {
        super.setCode(code);
        return super.getMessage();
    }
}
