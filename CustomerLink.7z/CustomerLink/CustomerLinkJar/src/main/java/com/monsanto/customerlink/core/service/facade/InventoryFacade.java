package com.monsanto.customerlink.core.service.facade;


import com.monsanto.customerlink.core.service.facade.dto.InventoryInDTO;

import java.util.List;
import java.util.Map;

public interface InventoryFacade {

    Map<String, List<?>> getInventory(List<InventoryInDTO> hybridList);

}
