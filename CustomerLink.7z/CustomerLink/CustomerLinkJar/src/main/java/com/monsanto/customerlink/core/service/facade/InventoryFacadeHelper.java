package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YsdsaErrref;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;

import java.util.List;

public interface InventoryFacadeHelper {

    Object[] execute(YSdsaSendInventory inSendInventory) throws Exception;

    List<ErrorOrderDTO> obtainError(List<YsdsaErrref> errorList);

    ErrorOrderDTO buildErrorDTO(YsdsaErrref item);

}