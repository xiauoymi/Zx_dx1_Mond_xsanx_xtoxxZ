package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;

import java.util.List;
import java.util.Map;

public interface InventoryRegularAgrochemicalsFacade {

    Map<String, List<?>> getInventory(List<MaterialDTO> materialList);

}