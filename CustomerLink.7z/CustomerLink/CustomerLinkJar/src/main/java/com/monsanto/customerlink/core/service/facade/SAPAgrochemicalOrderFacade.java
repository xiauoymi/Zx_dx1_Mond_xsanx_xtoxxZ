package com.monsanto.customerlink.core.service.facade;

public interface SAPAgrochemicalOrderFacade {
}
