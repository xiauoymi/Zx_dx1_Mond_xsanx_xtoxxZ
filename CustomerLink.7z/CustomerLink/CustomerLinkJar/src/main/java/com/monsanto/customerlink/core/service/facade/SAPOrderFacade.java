package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.util.List;

public interface SAPOrderFacade {

    /**
     * Executes the calling to the SAP Service for the creation of a order without algorithm
     *
     * @param orderDTO Order Customer Link
     * @return sapOrder SAP Order
     */
    SAPOrderDTO createSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Executes the calling to the SAP Service for the modification of a order without algorithm
     *
     * @param orderDTO Order Customer Link
     * @return sapOrder SAP Order
     */
    SAPOrderDTO updateSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Retrieves SAP orders associated with search parameters
     * Order Id SAP
     * Sales Organization
     * Distribution Channel
     * Sales Division
     * Distributor Code
     * Order Reason Code
     * Order Type Code
     *
     * @param orderDTO object with search parameters
     * @return the orders
     */
    List<SAPOrderDTO> retrieveOrders(final OrderDTO orderDTO) throws CustomerLinkBusinessException;

     /**
     * Executes the calling to the SAP Service for the creation of a order with algorithm
     *
     * @param orderDTO Order Customer Link
     * @return sapOrder SAP Order
     */
    SAPOrderDTO createSAPOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;

    /**
     * Executes the calling to the SAP Service for the modification of a order with algorithm
     *
     * @param orderDTO Order Customer Link
     * @return sapOrder SAP Order
     */
    SAPOrderDTO updateSAPOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException;
}