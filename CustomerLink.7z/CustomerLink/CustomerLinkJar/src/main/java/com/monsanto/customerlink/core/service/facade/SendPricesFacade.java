package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;

import java.util.List;

public interface SendPricesFacade {

    /**
     * return product list wich contains currency
     *
     * @param orderDTO product list for whose will be obtained their prices and currency, each pne of them must contain at least
     *                       one material to be abble to consult its price
     * @return
     */
    public List<MaterialSkuDTO> obtainCurrencies(OrderDTO orderDTO) throws Exception;
}
