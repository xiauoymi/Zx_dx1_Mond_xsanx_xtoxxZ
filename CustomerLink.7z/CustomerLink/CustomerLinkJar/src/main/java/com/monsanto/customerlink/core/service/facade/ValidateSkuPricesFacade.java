package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.InvalidPriceException;
import com.monsanto.customerlink.core.service.exception.InvalidSkuException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

public interface ValidateSkuPricesFacade {
    public OrderDTO validateSkuPrices(OrderDTO orderDTO)
            throws CustomerLinkBusinessException ;

}
