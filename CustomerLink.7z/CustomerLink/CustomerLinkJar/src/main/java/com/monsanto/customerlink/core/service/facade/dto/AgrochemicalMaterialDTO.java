package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AgrochemicalMaterialDTO implements Serializable{

    private String material;
    private Map<String,AgrochemicalPlantDTO> mapOfPlants;
    private List<AgrochemicalPlantDTO> listOfPlants;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public Map<String, AgrochemicalPlantDTO> getMapOfPlants() {

        if(mapOfPlants == null) {
            mapOfPlants = new HashMap<String, AgrochemicalPlantDTO>();
        }

        return mapOfPlants;
    }

    public void setMapOfPlants(Map<String, AgrochemicalPlantDTO> mapOfPlants) {
        this.mapOfPlants = mapOfPlants;
    }

    public List<AgrochemicalPlantDTO> getListOfPlants() {

        if(this.listOfPlants == null) {
            this.listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        }
        return listOfPlants;
    }

    public void setListOfPlants(List<AgrochemicalPlantDTO> listOfPlants) {
        this.listOfPlants = listOfPlants;
    }
}