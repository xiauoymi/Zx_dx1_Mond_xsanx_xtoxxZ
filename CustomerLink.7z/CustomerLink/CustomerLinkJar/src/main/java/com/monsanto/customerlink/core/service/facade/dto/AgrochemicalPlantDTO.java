package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class AgrochemicalPlantDTO implements Serializable, Comparable<AgrochemicalPlantDTO>{

    private String plant;
    private BigDecimal totalQty;
    private Long priority;
    private Map<String,AgrochemicalWareHouseDTO> warehouses;

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public BigDecimal getTotalQty() {

        if(totalQty == null) {
            totalQty = BigDecimal.ZERO;
        }

        return totalQty;
    }

    public void setTotalQty(BigDecimal totalQty) {
        this.totalQty = totalQty;
    }

    public Map<String, AgrochemicalWareHouseDTO> getWarehouses() {

        if(warehouses == null) {
            warehouses = new HashMap<String, AgrochemicalWareHouseDTO>();
        }

        return warehouses;
    }

    public void setWarehouses(Map<String, AgrochemicalWareHouseDTO> warehouses) {
        this.warehouses = warehouses;
    }


    public Long getPriority() {
        return priority;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }

    @Override
    public int compareTo(AgrochemicalPlantDTO o) {
        return this.priority.compareTo(o.getPriority());
    }
}