package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class AgrochemicalWareHouseDTO implements Serializable{

    private String storagelocation;
    private BigDecimal partialQty;

    public AgrochemicalWareHouseDTO() {

    }

    public AgrochemicalWareHouseDTO(String storagelocation, BigDecimal partialQty) {
        this.storagelocation = storagelocation;
        this.partialQty = partialQty;
    }

    public String getStoragelocation() {
        return storagelocation;
    }

    public void setStoragelocation(String storagelocation) {
        this.storagelocation = storagelocation;
    }

    public BigDecimal getPartialQty() {
        return partialQty;
    }

    public void setPartialQty(BigDecimal partialQty) {
        this.partialQty = partialQty;
    }
}