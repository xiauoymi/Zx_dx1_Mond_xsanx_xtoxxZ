package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HybridDTO implements Serializable {

    private String hybridCode;
    private double totalQty = 0;
    private List<MaterialDTO> skus;
    private String status;

    public String getHybridCode() {
        return hybridCode;
    }

    public void setHybridCode(final String hybridCode) {
        this.hybridCode = hybridCode;
    }

    public double getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(double totalQty) {
        this.totalQty = totalQty;
    }

    public List<MaterialDTO> getSkus() {
        if (skus == null) {
            skus = new ArrayList<MaterialDTO>();
        }
        return this.skus;
    }

    public void setSkus(final List<MaterialDTO> skus) {
        this.skus = skus;
        for (MaterialDTO materialDTO : getSkus()) {
            totalQty += materialDTO.getReq_qty();
        }
    }

    public void addSku(MaterialDTO sku) {
        this.getSkus();
        this.skus.add(sku);
        totalQty += sku.getReq_qty();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
