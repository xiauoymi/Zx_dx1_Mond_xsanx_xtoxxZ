package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.util.List;

public class InventoryInDTO implements Serializable {

    private String hybrid;
    private String salesorganization;
    private String salesdistrict;
    private String altuom;
    private String acronym;
    private String spTreatment;

    private SpecieDTO specieDTO;
    private List<PlantWareHouseDTO> plantWarehouses;


    public InventoryInDTO() {}

    public InventoryInDTO(SpecieDTO specieDTO) {
        this.specieDTO = specieDTO;
    }

    public InventoryInDTO(String hybrid, String salesorganization, String salesdistrict, String altuom, SpecieDTO specieDTO, String acronym, String spTreatment) {
        this.hybrid = hybrid;
        this.salesorganization = salesorganization;
        this.salesdistrict = salesdistrict;
        this.altuom = altuom;
        this.specieDTO = specieDTO;
        this.acronym = acronym;
        this.spTreatment = spTreatment;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public String getSalesorganization() {
        return salesorganization;
    }

    public void setSalesorganization(String salesorganization) {
        this.salesorganization = salesorganization;
    }

    public String getSalesdistrict() {
        return salesdistrict;
    }

    public void setSalesdistrict(String salesdistrict) {
        this.salesdistrict = salesdistrict;
    }

    public String getAltuom() {
        return altuom;
    }

    public void setAltuom(String altuom) {
        this.altuom = altuom;
    }

    public List<PlantWareHouseDTO> getPlantWarehouses() {
        return plantWarehouses;
    }

    public void setPlantWarehouses(List<PlantWareHouseDTO> plantWarehouses) {
        this.plantWarehouses = plantWarehouses;
    }

    public SpecieDTO getSpecieDTO() {
        return specieDTO;
    }

    public void setSpecieDTO(SpecieDTO specieDTO) {
        this.specieDTO = specieDTO;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public String getSpTreatment() {
        return spTreatment;
    }

    public void setSpTreatment(String spTreatment) {
        this.spTreatment = spTreatment;
    }
}