package com.monsanto.customerlink.core.service.facade.dto;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class InventoryOutDTO implements Serializable{

    private String hybrid;
    private BigDecimal denominator;
    private BigDecimal numerator;
    private String baseuom;
    private String altuom;

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public BigDecimal getDenominator() {
        return denominator;
    }

    public void setDenominator(BigDecimal denominator) {
        this.denominator = denominator;
    }

    public BigDecimal getNumerator() {
        return numerator;
    }

    public void setNumerator(BigDecimal numerator) {
        this.numerator = numerator;
    }

    public String getBaseuom() {
        return baseuom;
    }

    public void setBaseuom(String baseuom) {
        this.baseuom = baseuom;
    }

    public String getAltuom() {
        return altuom;
    }

    public void setAltuom(String altuom) {
        this.altuom = altuom;
    }
}
