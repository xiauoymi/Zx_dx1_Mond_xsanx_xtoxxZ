package com.monsanto.customerlink.core.service.facade.dto;

import java.util.List;

public class InventoryWithAlgorithmDTO extends InventoryOutDTO{

    List<PlantWithAlgorithmDTO> plants;

    public List<PlantWithAlgorithmDTO> getPlants() {
        return plants;
    }

    public void setPlants(List<PlantWithAlgorithmDTO> plants) {
        this.plants = plants;
    }
}
