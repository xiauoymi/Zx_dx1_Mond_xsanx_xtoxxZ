package com.monsanto.customerlink.core.service.facade.dto;


import java.util.ArrayList;
import java.util.List;

public class InventoryWithOutAlgorithmDTO extends InventoryOutDTO{

    private List<MaterialDTO> materials;

    public List<MaterialDTO> getMaterials() {
        if(materials==null){
            materials = new ArrayList<MaterialDTO>();
        }
        return materials;
    }

    public void setMaterials(List<MaterialDTO> materials) {
        this.materials = materials;
    }
}