package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class MaterialDTO implements Serializable, Comparable<MaterialDTO> {

    private String plant;
    private String material;
    private String storagelocation;
    private String batch;
    private BigDecimal unrestqty;
    private Long itemNumber;
    private String route;
    private BigDecimal netvalue;
    private BigDecimal tax;
    private String transType;

    // added fields that are used in the query sap order
    private Double req_qty;
    private Double del_qty;
    private String description;
    private String uom;

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getStoragelocation() {
        return storagelocation;
    }

    public void setStoragelocation(String storagelocation) {
        this.storagelocation = storagelocation;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public BigDecimal getUnrestqty() {
        return unrestqty;
    }

    public void setUnrestqty(BigDecimal unrestqty) {
        this.unrestqty = unrestqty;
    }

    public Long getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(Long itemNumber) {
        this.itemNumber = itemNumber;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public BigDecimal getNetvalue() {
        return netvalue;
    }

    public void setNetvalue(BigDecimal netvalue) {
        this.netvalue = netvalue;
    }

    public BigDecimal getTax() {
        return tax;
    }

    public void setTax(BigDecimal tax) {
        this.tax = tax;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public Double getReq_qty() {
        return req_qty;
    }

    public void setReq_qty(Double req_qty) {
        this.req_qty = req_qty;
    }

    public Double getDel_qty() {
        return del_qty;
    }

    public void setDel_qty(Double del_qty) {
        this.del_qty = del_qty;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    @Override
    public int compareTo(MaterialDTO o) {
        return this.getUnrestqty().compareTo(o.getUnrestqty());
    }


}
