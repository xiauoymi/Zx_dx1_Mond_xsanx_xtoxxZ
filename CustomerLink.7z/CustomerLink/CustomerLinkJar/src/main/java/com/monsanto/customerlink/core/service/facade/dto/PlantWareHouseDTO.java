package com.monsanto.customerlink.core.service.facade.dto;


import java.io.Serializable;

public class PlantWareHouseDTO implements Serializable {

    private String plant;
    private String storagelocation;

    public PlantWareHouseDTO(){

    }

    public PlantWareHouseDTO(String plant, String storagelocation){
        this.plant = plant;
        this.storagelocation = storagelocation;
    }

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public String getStoragelocation() {
        return storagelocation;
    }

    public void setStoragelocation(String storagelocation) {
        this.storagelocation = storagelocation;
    }
}
