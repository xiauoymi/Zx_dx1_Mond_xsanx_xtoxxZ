package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class PlantWithAlgorithmDTO implements Serializable{

    private String plant;
    private BigDecimal unrestqty;
    private String transactionType;
    private Long priority;

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public BigDecimal getUnrestqty() {
        return unrestqty;
    }

    public void setUnrestqty(BigDecimal unrestqty) {
        this.unrestqty = unrestqty;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public Long getPriority() {
        return priority;
    }

    public void setPriority(Long priority) {
        this.priority = priority;
    }
}