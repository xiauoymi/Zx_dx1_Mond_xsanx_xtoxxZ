package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SAPOrderDTO implements Serializable {

    private String salesorder;
    private String docType;
    private String salesOrg;
    private String distrChan;
    private String division;
    private String salesDis;
    private String soldTo;
    private String salesRep;
    private String purchNoC;
    private String ordReason;
    private String incoterms1;
    private String incoterms2;
    private String priceGrp;
    private String currency;
    private String status;
    private Date createDate;
    private SAPOrderDTO withoutSoakTestOrder;
    private List<HybridDTO> hybrids;
    private List<SAPOrderErrorDTO> errors;

    public String getSalesorder() {
        return salesorder;
    }

    public void setSalesorder(final String salesorder) {
        this.salesorder = salesorder;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(final String docType) {
        this.docType = docType;
    }

    public String getSalesOrg() {
        return salesOrg;
    }

    public void setSalesOrg(final String salesOrg) {
        this.salesOrg = salesOrg;
    }

    public String getDistrChan() {
        return distrChan;
    }

    public void setDistrChan(final String distrChan) {
        this.distrChan = distrChan;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(final String division) {
        this.division = division;
    }

    public String getSalesDis() {
        return salesDis;
    }

    public void setSalesDis(String salesDis) {
        this.salesDis = salesDis;
    }

    public String getSoldTo() {
        return soldTo;
    }

    public void setSoldTo(final String soldTo) {
        this.soldTo = soldTo;
    }

    public String getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(String salesRep) {
        this.salesRep = salesRep;
    }

    public String getPurchNoC() {
        return purchNoC;
    }

    public void setPurchNoC(final String purchNoC) {
        this.purchNoC = purchNoC;
    }

    public String getOrdReason() {
        return ordReason;
    }

    public void setOrdReason(final String ordReason) {
        this.ordReason = ordReason;
    }

    public String getIncoterms1() {
        return incoterms1;
    }

    public void setIncoterms1(final String incoterms1) {
        this.incoterms1 = incoterms1;
    }

    public String getIncoterms2() {
        return incoterms2;
    }

    public void setIncoterms2(final String incoterms2) {
        this.incoterms2 = incoterms2;
    }

    public String getPriceGrp() {
        return priceGrp;
    }

    public void setPriceGrp(final String priceGrp) {
        this.priceGrp = priceGrp;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(final String currency) {
        this.currency = currency;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public SAPOrderDTO getWithoutSoakTestOrder() {
        return withoutSoakTestOrder;
    }

    public void setWithoutSoakTestOrder(SAPOrderDTO withoutSoakTestOrder) {
        this.withoutSoakTestOrder = withoutSoakTestOrder;
    }

    public List<HybridDTO> getHybrids() {
        if (hybrids == null) {
            hybrids = new ArrayList<HybridDTO>();
        }
        return this.hybrids;
    }

    public void setHybrids(final List<HybridDTO> hybrids) {
        this.hybrids = hybrids;
    }

    public List<SAPOrderErrorDTO> getErrors() {
        if (errors == null) {
            errors = new ArrayList<SAPOrderErrorDTO>();
        }
        return this.errors;
    }

    public void setErrors(final List<SAPOrderErrorDTO> errors) {
        this.errors = errors;
    }

    public void setCreateDate(String createDate) throws ParseException {
        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        this.createDate = sdf.parse(createDate);
    }
}
