package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;

public class SAPOrderErrorDTO implements Serializable {

    private String type;
    private String id;
    private String number;
    private String message;

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(final String number) {
        this.number = number;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }
}
