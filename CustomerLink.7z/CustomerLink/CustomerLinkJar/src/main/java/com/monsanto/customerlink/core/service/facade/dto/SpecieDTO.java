package com.monsanto.customerlink.core.service.facade.dto;

import java.io.Serializable;

public class SpecieDTO implements Serializable {

    private String speciecode;
    private String specieclass;
    private String classtype;
    private String alg;

    public String getSpeciecode() {
        return speciecode;
    }

    public void setSpeciecode(String speciecode) {
        this.speciecode = speciecode;
    }

    public String getSpecieclass() {
        return specieclass;
    }

    public void setSpecieclass(String specieclass) {
        this.specieclass = specieclass;
    }

    public String getClasstype() {
        return classtype;
    }

    public void setClasstype(String classtype) {
        this.classtype = classtype;
    }

    public String getAlg() {
        return alg;
    }

    public void setAlg(String alg) {
        this.alg = alg;
    }
}
