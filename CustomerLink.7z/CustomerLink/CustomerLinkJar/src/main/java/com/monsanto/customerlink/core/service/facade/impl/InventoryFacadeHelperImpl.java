package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.service.facade.InventoryFacadeHelper;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryClient;
import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YsdsaErrref;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InventoryFacadeHelperImpl implements InventoryFacadeHelper {

    public Object[] execute(YSdsaSendInventory inSendInventory) throws Exception {

        // create builder and processor
        SendInventoryRequestBuilder builder = new SendInventoryRequestBuilder(inSendInventory);
        SendInventoryResponseProcessor processor = new SendInventoryResponseProcessor();

        // obtain webservice client
        SendInventoryClient sendInventoryClient = new SendInventoryClient(builder, processor, this.getJAXWSClientFactory().getSendInventoryPortType());

        // execute service
        Object[] outSendInventory = (Object[]) sendInventoryClient.execute();

        return outSendInventory;
    }

    public JAXWSClientFactory getJAXWSClientFactory() {
        return JAXWSClientFactoryImpl.getInstance();
    }

    public List<ErrorOrderDTO> obtainError(List<YsdsaErrref> errorList) {
        List<ErrorOrderDTO> errorOrderDTOs = new ArrayList<ErrorOrderDTO>();
        for (YsdsaErrref errref : errorList) {
            errorOrderDTOs.add(buildErrorDTO(errref));
        }
        return errorOrderDTOs;
    }

    public ErrorOrderDTO buildErrorDTO(YsdsaErrref item) {
        ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setObjectWithError(CustomerLinkUtils.safeNull(item.getYyhybrid() + item.getYymaterial(), ""));
        ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();
        errorTypeDTO.setDescription(CustomerLinkUtils.safeNull(item.getYyerrdesc(), ""));
        errorTypeDTO.setErrorTypeCode(item.getYyerrcode());

        errorOrderDTO.setErrorTypes(errorTypeDTO);

        return errorOrderDTO;
    }

}
