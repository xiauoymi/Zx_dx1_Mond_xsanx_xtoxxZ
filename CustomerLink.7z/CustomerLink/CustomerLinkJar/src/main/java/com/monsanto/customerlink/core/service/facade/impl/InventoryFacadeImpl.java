package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.service.facade.InventoryFacade;
import com.monsanto.customerlink.core.service.facade.InventoryFacadeHelper;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class InventoryFacadeImpl implements InventoryFacade {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Mapper mapper;

    @Autowired
    private InventoryFacadeHelper inventoryFacadeHelper;

    @Override
    public Map<String, List<?>> getInventory(List<InventoryInDTO> hybridList) {

        Map<String, List<?>> out = new HashMap<String, List<?>>();

        if (hybridList != null && !hybridList.isEmpty()) {
            YSdsaSendInventory inSendInventory = getInSendInventory(hybridList);
            try {
                out = getOutSendInventory(inventoryFacadeHelper.execute(inSendInventory));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        return out;
    }

    private YSdsaSendInventory getInSendInventory(List<InventoryInDTO> hybridList) {

        YSdsaSendInventory inSendInventory = new YSdsaSendInventory();

        List<YsdsaSpeciesAlg> inSpecies = new ArrayList<YsdsaSpeciesAlg>();
        List<YsdsaSdorgSpec> inSdOrgS = new ArrayList<YsdsaSdorgSpec>();
        List<YsdsaInhybrids> inHybrids = new ArrayList<YsdsaInhybrids>();

        List<String> speciesKeys = new ArrayList<String>();
        List<String> sdOrgSKeys = new ArrayList<String>();

        for (InventoryInDTO i : hybridList) {

            String specieKey = i.getSpecieDTO().getSpeciecode();
            if (!speciesKeys.contains(specieKey)) {
                inSpecies.add(mapper.map(i.getSpecieDTO(), YsdsaSpeciesAlg.class));
                speciesKeys.add(specieKey);
            }

            String sdOrgKey = i.getHybrid() + specieKey + i.getSalesorganization() + i.getSalesdistrict();
            if (!sdOrgSKeys.contains(sdOrgKey)) {
                YsdsaSdorgSpec inSdorg = mapper.map(i, YsdsaSdorgSpec.class);
                mapper.map(i.getSpecieDTO(), inSdorg);
                inSdOrgS.add(inSdorg);
                sdOrgSKeys.add(sdOrgKey);
            }

            if (!i.getPlantWarehouses().isEmpty()) {
                for (PlantWareHouseDTO pw : i.getPlantWarehouses()) {
                    YsdsaInhybrids h = mapper.map(i, YsdsaInhybrids.class);
                    mapper.map(pw, h);
                    mapper.map(i.getSpecieDTO(), h);
                    inHybrids.add(h);
                }
            }

        }

        YttSdsaInhybrids yttSdsaInhybrids = new YttSdsaInhybrids();
        yttSdsaInhybrids.setItem(inHybrids);
        inSendInventory.setInhybrids(yttSdsaInhybrids);

        YttSdsaSdorgSpec yttSdsaSdorgSpec = new YttSdsaSdorgSpec();
        yttSdsaSdorgSpec.setItem(inSdOrgS);
        inSendInventory.setSdorg(yttSdsaSdorgSpec);

        YttSdsaSpeciesAlg yttSdsaSpeciesAlg = new YttSdsaSpeciesAlg();
        yttSdsaSpeciesAlg.setItem(inSpecies);
        inSendInventory.setSpecies(yttSdsaSpeciesAlg);

        YttSdsaInskus yttSdsaInskus = new YttSdsaInskus();
        inSendInventory.setInskus(yttSdsaInskus);

        return inSendInventory;
    }

    public Map<String, List<?>> getOutSendInventory(Object[] outSendInventory) {

        Map<String, List<?>> map = new HashMap<String, List<?>>();

        if (outSendInventory != null) {
            // applies when request is per hybrids
            YttSdsaOuthybalg outhybalg = (YttSdsaOuthybalg) outSendInventory[1];
            if (outhybalg != null && !outhybalg.getItem().isEmpty()) {
                map.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM, getInventoryListWithAlgorithm(outhybalg.getItem()));
            }

            // applies when request is per materials
            YttSdsaOuthybrids outhybrids = (YttSdsaOuthybrids) outSendInventory[3];
            YttSdsaOuthybinv outhybinv = (YttSdsaOuthybinv) outSendInventory[2];
            if (outhybrids != null && !outhybrids.getItem().isEmpty()) {
                map.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, getInventoryListWithOutAlgorithm(outhybrids.getItem(), outhybinv.getItem()));
            }

            YttSdsaErrref errors = (YttSdsaErrref) outSendInventory[0];
            if (errors != null && !errors.getItem().isEmpty()) {
                map.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR, inventoryFacadeHelper.obtainError(errors.getItem()));
            }

        }

        return map;
    }

    private List<InventoryWithAlgorithmDTO> getInventoryListWithAlgorithm(List<YsdsaOuthybalg> ysdsaOuthybalgs) {

        List<InventoryWithAlgorithmDTO> inventoryList = new ArrayList<InventoryWithAlgorithmDTO>();

        Map<String, InventoryWithAlgorithmDTO> mapOfHybrid = new HashMap<String, InventoryWithAlgorithmDTO>();

        // gets all the hybrids with algorithm for the response
        for (YsdsaOuthybalg h : ysdsaOuthybalgs) {
            if (!mapOfHybrid.containsKey(h.getYyhybrid())) {
                InventoryWithAlgorithmDTO inv = mapper.map(h, InventoryWithAlgorithmDTO.class);
                mapOfHybrid.put(h.getYyhybrid(), inv);
            }
        }

        Iterator it = mapOfHybrid.entrySet().iterator();

        // Plants and amounts are obtained for each hybrid
        while (it.hasNext()) {

            Map.Entry<String, InventoryWithAlgorithmDTO> pairs = (Map.Entry) it.next();
            String hybridToSearch = pairs.getKey();
            InventoryWithAlgorithmDTO inv = pairs.getValue();

            List<PlantWithAlgorithmDTO> plants = new ArrayList<PlantWithAlgorithmDTO>();

            for (YsdsaOuthybalg h : ysdsaOuthybalgs) {
                if (h.getYyhybrid().equals(hybridToSearch)) {
                    plants.add(mapper.map(h, PlantWithAlgorithmDTO.class));
                }
            }

            inv.setPlants(plants);

            inventoryList.add(inv);
        }

        return inventoryList;
    }

    private List<InventoryWithOutAlgorithmDTO> getInventoryListWithOutAlgorithm(List<YsdsaOuthybrids> outHybrids, List<YsdsaOuthybinv> outHybInvs) {

        List<InventoryWithOutAlgorithmDTO> inventoryList = new ArrayList<InventoryWithOutAlgorithmDTO>();

        Map<String, List<String>> hybridsAndMaterialsGrouped = groupHybridsAndMaterials(outHybrids, outHybInvs);

        Iterator it = hybridsAndMaterialsGrouped.entrySet().iterator();

        while (it.hasNext()) {

            Map.Entry<String, List<String>> pairs = (Map.Entry) it.next();
            String hybridToSearch = pairs.getKey();

            for (YsdsaOuthybrids outH : outHybrids) {

                if (outH.getYyhybrid().equals(hybridToSearch)) {
                    inventoryList.add(getHybridWithOutAlgorithmDTO(outH, pairs.getValue(), outHybInvs));
                    break;
                }
            }
        }

        return inventoryList;
    }

    private InventoryWithOutAlgorithmDTO getHybridWithOutAlgorithmDTO(YsdsaOuthybrids outH, List<String> materials, List<YsdsaOuthybinv> outHybInvList) {

        // common values
        InventoryWithOutAlgorithmDTO inventoryWithOutAlgorithmDTO = mapper.map(outH, InventoryWithOutAlgorithmDTO.class);

        if (!materials.isEmpty()) {

            List<MaterialDTO> materialList = new ArrayList<MaterialDTO>();

            for (String m : materials) {

                for (YsdsaOuthybinv inventory : outHybInvList) {

                    if (m.equals(inventory.getYymaterial())) {
                        materialList.add(mapper.map(inventory, MaterialDTO.class));
                        break;
                    }
                }
            }

            inventoryWithOutAlgorithmDTO.setMaterials(materialList);
        }

        return inventoryWithOutAlgorithmDTO;
    }


    private Map<String, List<String>> groupHybridsAndMaterials(List<YsdsaOuthybrids> outHybrids, List<YsdsaOuthybinv> outHybInvs) {
        Map<String, List<String>> map = new HashMap<String, List<String>>();

        for (YsdsaOuthybrids out : outHybrids) {

            List<String> materials = new ArrayList<String>();

            if (outHybInvs != null && !outHybInvs.isEmpty()) {

                for (YsdsaOuthybinv outInv : outHybInvs) {
                    if (outInv.getYymaterial().equals(out.getYymaterial())) {
                        materials.add(outInv.getYymaterial());
                    }
                }

            }

            List<String> updateMaterials = materials;

            if (map.containsKey(out.getYyhybrid())) {
                updateMaterials = map.get(out.getYyhybrid());
                updateMaterials.addAll(materials);
            }

            map.put(out.getYyhybrid(), updateMaterials);
        }

        return map;
    }

}