package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.service.facade.InventoryFacadeHelper;
import com.monsanto.customerlink.core.service.facade.InventoryRegularAgrochemicalsFacade;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class InventoryRegularAgrochemicalsFacadeImpl implements InventoryRegularAgrochemicalsFacade {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private InventoryFacadeHelper inventoryFacadeHelper;

    @Override
    public Map<String, List<?>> getInventory(List<MaterialDTO> materialList) {

        Map<String, List<?>> out = new HashMap<String, List<?>>();

        if (materialList != null && !materialList.isEmpty()) {
            YSdsaSendInventory inSendInventory = getInSendInventory(materialList);
            try {
                out = getOutSendInventory(inventoryFacadeHelper.execute(inSendInventory));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        return out;
    }

    private YSdsaSendInventory getInSendInventory(List<MaterialDTO> materialList) {

        YSdsaSendInventory inSendInventory = new YSdsaSendInventory();

        inSendInventory.setInhybrids(new YttSdsaInhybrids());
        inSendInventory.setSdorg(new YttSdsaSdorgSpec());
        inSendInventory.setSpecies(new YttSdsaSpeciesAlg());

        // list of skus
        List<YsdsaInskus> ysdsaInskuses = new ArrayList<YsdsaInskus>();
        for(MaterialDTO m : materialList) {
            YsdsaInskus sku = new YsdsaInskus();
            sku.setYymaterial(m.getMaterial());
            sku.setYyplant(m.getPlant());
            sku.setYystLocation(m.getStoragelocation());
            sku.setYyaltoum(m.getUom());
            ysdsaInskuses.add(sku);
        }

        YttSdsaInskus yttSdsaInskus = new YttSdsaInskus();
        yttSdsaInskus.setItem(ysdsaInskuses);

        inSendInventory.setInskus(yttSdsaInskus);

        return inSendInventory;
    }

    public Map<String, List<?>> getOutSendInventory(Object[] outSendInventory) {

        Map<String, List<?>> map = new HashMap<String, List<?>>();

        if (outSendInventory != null) {

            // applies when request is per materials
            YttSdsaOuthybrids outhybrids = (YttSdsaOuthybrids) outSendInventory[3];
            YttSdsaOuthybinv outhybinv = (YttSdsaOuthybinv) outSendInventory[2];
            if (outhybrids != null && !outhybrids.getItem().isEmpty()) {
                if(outhybinv!=null && !outhybinv.getItem().isEmpty()) {
                    map.put(CustomerLinkCoreConstants.AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM, getInventoryListOfMaterials(outhybrids.getItem(), outhybinv.getItem()));
                }
            }

            YttSdsaErrref errors = (YttSdsaErrref) outSendInventory[0];
            if (errors != null && !errors.getItem().isEmpty()) {
                map.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR, inventoryFacadeHelper.obtainError(errors.getItem()));
            }
        }

        return map;
    }

    private List<AgrochemicalMaterialDTO> getInventoryListOfMaterials(List<YsdsaOuthybrids> outhybrids, List<YsdsaOuthybinv> outhybinv ) {

        List<AgrochemicalMaterialDTO> materials = new ArrayList<AgrochemicalMaterialDTO>();

        Map<String, AgrochemicalMaterialDTO> mapMaterials = new HashMap<String, AgrochemicalMaterialDTO>();

        for(YsdsaOuthybrids oh : outhybrids) {
            AgrochemicalMaterialDTO agrochemicalMaterial = getAgrochemicalMaterial(mapMaterials,oh.getYymaterial());
            updateMaterialValues(agrochemicalMaterial, outhybinv);
            mapMaterials.put(oh.getYymaterial(),agrochemicalMaterial);
        }

        if(!mapMaterials.isEmpty()) {
            materials = new ArrayList<AgrochemicalMaterialDTO>(mapMaterials.values());
            for(AgrochemicalMaterialDTO am: materials) {
                am.setListOfPlants( new ArrayList<AgrochemicalPlantDTO>(am.getMapOfPlants().values()));
            }
        }

        return materials;
    }

    public AgrochemicalMaterialDTO getAgrochemicalMaterial(Map<String, AgrochemicalMaterialDTO> mapMaterials, String materialName) {
        AgrochemicalMaterialDTO agrochemicalMaterial = new AgrochemicalMaterialDTO();
        agrochemicalMaterial.setMaterial(materialName);
        agrochemicalMaterial.setMapOfPlants(new HashMap<String, AgrochemicalPlantDTO>());
        return agrochemicalMaterial;
    }

    public void updateMaterialValues(AgrochemicalMaterialDTO agrochemicalMaterial, List<YsdsaOuthybinv> outhybinv) {

        String materialName = agrochemicalMaterial.getMaterial();

        for(YsdsaOuthybinv inv : outhybinv) {

            if(inv.getYymaterial().equals(materialName)) {
                AgrochemicalPlantDTO p = new AgrochemicalPlantDTO();
                p.setPlant(inv.getYyplant());
                p = updatePlantsAndWarehouses(agrochemicalMaterial,inv,p);
                agrochemicalMaterial.getMapOfPlants().put(inv.getYyplant(),p);
            }
        }

    }

    private AgrochemicalPlantDTO updatePlantsAndWarehouses(AgrochemicalMaterialDTO agrochemicalMaterial, YsdsaOuthybinv inv, AgrochemicalPlantDTO p) {

        if(agrochemicalMaterial.getMapOfPlants().containsKey(inv.getYyplant())) {
            p = agrochemicalMaterial.getMapOfPlants().get(inv.getYyplant());
        }

        // update total quantity
        p.setTotalQty(BigDecimal.valueOf((p.getTotalQty().doubleValue() + inv.getYyunrestqty().doubleValue())));

        AgrochemicalWareHouseDTO wh = new AgrochemicalWareHouseDTO(inv.getYystLocation(),inv.getYyunrestqty());

        // validate if map of warehouses contains the current warehouse
        if(p.getWarehouses().containsKey(inv.getYystLocation())) {
            wh = p.getWarehouses().get(inv.getYystLocation());
            wh.setPartialQty(BigDecimal.valueOf(wh.getPartialQty().doubleValue() + inv.getYyunrestqty().doubleValue()));
        }

        // update warehouse in plant
        p.getWarehouses().put(inv.getYystLocation(), wh);

        return p;
    }

}