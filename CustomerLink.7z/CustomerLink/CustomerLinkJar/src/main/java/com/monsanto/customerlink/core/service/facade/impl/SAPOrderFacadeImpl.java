package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.SAPOrderFacade;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.*;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.*;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailClient;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("sapOrderFacade")
public class SAPOrderFacadeImpl implements SAPOrderFacade {

    /**
     * @see SAPOrderFacade#createSAPOrderWithoutAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO createSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        final CreateSalesOrdWithoutAlgorithmRequestBuilder builder = new CreateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);
        final SalesOrdWithoutAlgorithmResponseProcessor processor = new SalesOrdWithoutAlgorithmResponseProcessor();
        final CreateSalesOrdWithoutAlgorithmClient client = new CreateSalesOrdWithoutAlgorithmClient(builder, processor, JAXWSClientFactoryImpl.getInstance().getCreChanSalesOrdPortType());
        try {
            return (SAPOrderDTO) client.execute();
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }
    }

    /**
     * @see SAPOrderFacade#updateSAPOrderWithoutAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO updateSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        final UpdateSalesOrdWithoutAlgorithmRequestBuilder builder = new UpdateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);
        final SalesOrdWithoutAlgorithmResponseProcessor processor = new SalesOrdWithoutAlgorithmResponseProcessor();
        final UpdateSalesOrdWithoutAlgorithmClient client = new UpdateSalesOrdWithoutAlgorithmClient(builder, processor, JAXWSClientFactoryImpl.getInstance().getCreChanSalesOrdPortType());
        try {
            return (SAPOrderDTO) client.execute();
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }

    }

    /**
     * @see SAPOrderFacade#retrieveOrders(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public List<SAPOrderDTO> retrieveOrders(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        final SendSalesOrdDetailRequestBuilder builder = new SendSalesOrdDetailRequestBuilder(orderDTO);
        final SendSalesOrdDetailResponseProcessor processor = new SendSalesOrdDetailResponseProcessor();
        final SendSalesOrdDetailClient client = new SendSalesOrdDetailClient(builder, processor, JAXWSClientFactoryImpl.getInstance().getSendSalesOrdDetailPortType());
        try {
            return (List<SAPOrderDTO>) client.execute();
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }

    }


    /**
     * @see SAPOrderFacade#createSAPOrderWithoutAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO createSAPOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        final CreateSalesOrdWithAlgorithmRequestBuilder builder = new CreateSalesOrdWithAlgorithmRequestBuilder(orderDTO);
        final SalesOrdWithAlgorithmResponseProcessor processor = new SalesOrdWithAlgorithmResponseProcessor();
        final CreateSalesOrdWithAlgorithmClient client = new CreateSalesOrdWithAlgorithmClient(builder, processor, JAXWSClientFactoryImpl.getInstance().getCreChanSalesOrdWithAlgorithmPortType());
        try {
            return (SAPOrderDTO) client.execute();
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }

    }

    /**
     * @see SAPOrderFacade#updateSAPOrderWithAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO updateSAPOrderWithAlgorithm(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        final UpdateSalesOrdWithAlgorithmRequestBuilder builder = new UpdateSalesOrdWithAlgorithmRequestBuilder(orderDTO);
        final SalesOrdWithAlgorithmResponseProcessor processor = new SalesOrdWithAlgorithmResponseProcessor();
        final UpdateSalesOrdWithAlgorithmClient client = new UpdateSalesOrdWithAlgorithmClient(builder, processor, JAXWSClientFactoryImpl.getInstance().getCreChanSalesOrdWithAlgorithmPortType());
        try {
            return (SAPOrderDTO) client.execute();
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }

    }
}