package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.facade.SendPricesFacade;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesClient;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondin;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SendPricesFacadeImpl implements SendPricesFacade {

    private PriceGroupService priceGroupService;

    @Autowired
    public SendPricesFacadeImpl(PriceGroupService priceGroupService){
        this.priceGroupService = priceGroupService;
    }

    @Override
    public List<MaterialSkuDTO> obtainCurrencies(OrderDTO orderDTO) throws Exception {
        if(orderDTO.getPriceGroup()==null){
        orderDTO.setPriceGroup(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(),
                orderDTO.getDetail().get(0).getProductDTO().getBrandCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()));
        }
        // create builder and processor
        JAXWSRequestBuilder<YttSdsaCondin> requestBuilder = new SendPricesRequestBuilder(orderDTO);

        JAXWSResponseProcessor<Object[]> responseProcessor = new SendPricesResponseProcessor();

        // obtain webservice client
        SendPricesClient sendPricesClient = new SendPricesClient(requestBuilder, responseProcessor,
                this.getJAXWSClientFactory().getSendPricesServicePortType());

        // execute service
        return (List<MaterialSkuDTO>) sendPricesClient.execute();
    }

    public JAXWSClientFactory getJAXWSClientFactory() {
        return JAXWSClientFactoryImpl.getInstance();
    }

}
