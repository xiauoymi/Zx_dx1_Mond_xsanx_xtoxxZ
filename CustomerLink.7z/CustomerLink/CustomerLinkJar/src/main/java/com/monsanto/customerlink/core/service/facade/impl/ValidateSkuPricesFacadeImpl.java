package com.monsanto.customerlink.core.service.facade.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.OrderErrorService;
import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.InvalidPriceException;
import com.monsanto.customerlink.core.service.facade.ValidateSkuPricesFacade;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceClient;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceResponseProcessor;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ValidateSkuPricesFacadeImpl implements ValidateSkuPricesFacade {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private CropRepository cropRepository;
    private OrderErrorService orderErrorService;
    private NotificationSender mailNotificationSender;
    private PriceGroupService priceGroupService;
    private MailUtilService mailUtilService;

    @Autowired
    public ValidateSkuPricesFacadeImpl(CropRepository cropRepository, OrderErrorService orderErrorService,
                                       NotificationSender mailNotificationSender, PriceGroupService priceGroupService,
                                       MailUtilService mailUtilService) {
        this.cropRepository = cropRepository;
        this.orderErrorService = orderErrorService;
        this.mailNotificationSender = mailNotificationSender;
        this.priceGroupService = priceGroupService;
        this.mailUtilService=mailUtilService;
    }

    @Override
    public OrderDTO validateSkuPrices(OrderDTO orderDTO) throws CustomerLinkBusinessException {

        orderDTO.setPriceGroup(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(),
                orderDTO.getDetail().get(0).getProductDTO().getBrandCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()));
        OrderDTO responseOrderDTO = null;

        try {
            responseOrderDTO = validateSkuAndPrices(orderDTO, this.getJAXWSClientFactory());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            orderDTO.setDetail(new ArrayList<OrderDetailDTO>()); //send empty to not process anything
            return orderDTO;
        }
        if (containErrors(responseOrderDTO)) {
            saveOrderAndErrors(responseOrderDTO);
        }
        try {
            sendNotifications(responseOrderDTO, orderDTO.getDistributorConfigDTO());
        } catch (InvalidPriceException e) {
            orderDTO.setDetail(new ArrayList<OrderDetailDTO>());
            return orderDTO;
        }
        return orderErrorService.filterHybridsWithErrors(orderDTO);// TODO complete with response and then filter
    }

    private void sendNotifications(OrderDTO responseOrderDTO, DistributorConfigDTO distributorProfile) throws InvalidPriceException {
        List<ErrorOrderDTO> listErrorSku = orderErrorService.obtainSkuErrors(responseOrderDTO);
        List<ErrorOrderDTO> listErrorPrice = orderErrorService.obtainPricesErrors(responseOrderDTO);

        sendNotification(listErrorSku, getInvalidSkuNotificationType(), distributorProfile);
        sendNotification(listErrorPrice, getInvalidPriceNotificationType(), distributorProfile);

        if (!listErrorPrice.isEmpty()) {
            throw new InvalidPriceException(new Object[]{obtainErrorMessage(listErrorPrice)});
        }
    }

    public NotificationType getInvalidSkuNotificationType() {
        return NotificationType.INVALID_SKU;
    }

    public NotificationType getInvalidPriceNotificationType() {
        return NotificationType.INVALID_PRICE;
    }

    private void sendNotification(List<ErrorOrderDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorConfigDTO) {
        if (!listError.isEmpty()) {
            Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, listError);


            mailNotificationSender.send(type.newNotification(distributorConfigDTO, parameters));
        }
    }

    private String obtainErrorMessage(List<ErrorOrderDTO> listError) {
        StringBuffer errorBuffer = new StringBuffer();
        for (ErrorOrderDTO errorOrderDTO : listError) {
            errorBuffer.append(errorOrderDTO.getObjectWithError() + " " + errorOrderDTO.getErrorTypes().getDescription());
        }
        return errorBuffer.toString();
    }

    public OrderDTO validateSkuAndPrices(OrderDTO orderDTO, JAXWSClientFactory jaxwsClientFactory) throws Exception {
        List<CropVO> cropVOList = cropRepository.findAll();

        JAXWSRequestBuilder<ValidationSkuPriceDTO> jaxwsRequestBuilder = new ValidationSkuPriceRequestBuilder(orderDTO, cropVOList);

        JAXWSResponseProcessor<ValidationSkuPriceDTO> jaxwsResponseProcessor = new ValidationSkuPriceResponseProcessor();
        ValidationSkuPriceClient client = new ValidationSkuPriceClient(jaxwsRequestBuilder, jaxwsResponseProcessor,
                jaxwsClientFactory.getValidationSkuPricePortType());

        return (OrderDTO) client.execute();
    }

    private boolean containErrors(OrderDTO responseOrderDTO) {
        return this.orderErrorService.containErrors(responseOrderDTO);
    }

    private void saveOrderAndErrors(OrderDTO responseOrderDTO) throws CustomerLinkBusinessException {
        this.orderErrorService.saveOrderAndErrors(responseOrderDTO);
    }

    public JAXWSClientFactory getJAXWSClientFactory() {
        return JAXWSClientFactoryImpl.getInstance();
    }

}
