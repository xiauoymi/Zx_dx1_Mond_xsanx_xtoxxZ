package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.AgreementServiceHelper;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.RepresentativeUtils;
import com.monsanto.customerlink.persistence.entities.AgreementVO;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.persistence.repositories.AgreementRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.FiscalYearDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class AgreementServiceHelperImpl implements AgreementServiceHelper {

    private AgreementRepository agreementRepository;

    @Autowired
    public AgreementServiceHelperImpl(AgreementRepository agreementRepository) {
        this.agreementRepository = agreementRepository;
    }

    @Override
    public AgreementVO obtainAgreementByParameters(FiscalYearVO yearVo, DistributorProfileVO distvo, RepresentativeDTO representativeDTO) {
        AgreementVO agreementVO;
        if(RepresentativeUtils.isAvailableRCD(representativeDTO)) {
            agreementVO = agreementRepository.
                    findByDistributorProfileAndFiscalYearAndRcdSAPCode(
                            distvo.getDistributorProfileId(), yearVo.getFiscalYear(), representativeDTO.getSapUserId());
        } else {
            agreementVO = agreementRepository.
                    findByDistributorProfileAndFiscalYear(
                            distvo.getDistributorProfileId(), yearVo.getFiscalYear());
        }
        return agreementVO;
    }

    @Override
    public List<Long> getFiscalYearList(FiscalYearDTO fy) {
        List<Long> fyList = new ArrayList<Long>();
        if(null != fy) {
            fyList.add(fy.getFiscalYear());
            fyList.add(fy.getFiscalYear()-1);
        }else {
            fyList.add(Long.valueOf(CustomerLinkUtils.getFiscalYear(new Date())));
        }
        return fyList;
    }
}