package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.AgreementService;
import com.monsanto.customerlink.core.service.AgreementServiceHelper;
import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.agreement.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

@Service
public class AgreementServiceImpl implements AgreementService {

    private AgreementRepository agreementRepository;
    private VolumeGoalRepository volumeGoalRepository;
    private IncentivePackageRepository incentivePackageRepository;
    private DistributorService distributorService;
    private AgreementEmailRepository agreementEmailRepository;
    private VolumeGoalPeriodRepository volumeGoalPeriodRepository;
    private PrivateBrandDistributorRepository privateBrandDistributorRepository;
    private Mapper mapper;
    private MailUtilService mailUtilService;
    private NotificationSender mailNotificationSender;
    private AgreementServiceHelper agreementServiceHelper;

    @Autowired
    public AgreementServiceImpl(AgreementRepository agreementRepository, Mapper mapper,
                                VolumeGoalRepository volumeGoalRepository,
                                IncentivePackageRepository incentivePackageRepository,
                                AgreementEmailRepository agreementEmailRepository,
                                DistributorService distributorService,
                                VolumeGoalPeriodRepository volumeGoalPeriodRepository,
                                PrivateBrandDistributorRepository privateBrandDistributorRepository,
                                MailUtilService mailUtilService,
                                NotificationSender mailNotificationSender,
                                AgreementServiceHelper agreementServiceHelper) {
        this.agreementRepository = agreementRepository;
        this.mapper = mapper;
        this.incentivePackageRepository = incentivePackageRepository;
        this.volumeGoalRepository = volumeGoalRepository;
        this.distributorService = distributorService;
        this.agreementEmailRepository = agreementEmailRepository;
        this.volumeGoalPeriodRepository = volumeGoalPeriodRepository;
        this.privateBrandDistributorRepository = privateBrandDistributorRepository;
        this.mailUtilService = mailUtilService;
        this.mailNotificationSender = mailNotificationSender;
        this.agreementServiceHelper = agreementServiceHelper;
    }

    @Override
    public List<AgreementDTO> retrieveAgreementByParameters(AgreementDTO agreementDTO,
                                                            DistributorConfigDTO distributorConfigDTO) throws AgreementRetrieveByParametersNotFoundException {

        Collection<AgreementVO> agreementVOLis = retrieveAgreements(agreementDTO, distributorConfigDTO);

        return mapper.mapList(AgreementDTO.class, agreementVOLis);
    }

    private Collection<AgreementVO> retrieveAgreements(AgreementDTO agreementDTO,
                                                       DistributorConfigDTO distributorConfigDTO) {
        if (isEspecificAgreement(agreementDTO)) {
            return findEspecificAgreement(agreementDTO);
        }
        return findByParameters(agreementDTO, distributorConfigDTO);
    }

    private Collection<AgreementVO> findEspecificAgreement(AgreementDTO agreementDTO) {

        Collection<AgreementVO> agreementVOs = new ArrayList<AgreementVO>();
        agreementVOs.add(this.agreementRepository.findOne(agreementDTO.getAgreementId()));
        return agreementVOs;
    }


    private Collection<AgreementVO> findByParameters(AgreementDTO agreementDTO,
                                                     DistributorConfigDTO distributorConfigDTO) {
        return this.agreementRepository.findByParameters(
                agreementServiceHelper.getFiscalYearList(agreementDTO.getFiscalYear()), getDistributorCode(distributorConfigDTO),
                getValue(distributorConfigDTO.getSalesOrgCode()), getValue(distributorConfigDTO.getDistChCode()),
                getValue(distributorConfigDTO.getSalesDivCode()),
                getValue(distributorConfigDTO.getSubRegionCode()), getValue(agreementDTO.getApproved()),
                getValue(agreementDTO.getStatus())
        );
    }

    private boolean isEspecificAgreement(AgreementDTO agreementDTO) {
        return  (agreementDTO.getAgreementId() > 0);
    }

    @Override
    @Transactional
    public AgreementDTO createAgreement(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO) throws AgreementNotFoundException, DistributorConfigNotFoundException, AgreementAlreadyExistsException,
            AgreementWithoutVolumeGoalException, AgreementWithoutIncentivePackageException, VolumeGoalWithoutPeriodException, VolumenGoalNotEnoughPeriodsException,
            InvalidProductForPrivateDistributor {

        validateCreateAgreementParameters(agreementDTO, distributorConfigDTO);

        DistributorProfileVO distvo = distributorService.retrieveDistributorConfigByConfig(distributorConfigDTO);

        FiscalYearVO yearVo = new FiscalYearVO();
        yearVo.setFiscalYear(getFiscalYear());

        AgreementVO vo = validateIfExistAgreement(yearVo, distvo, distributorConfigDTO,agreementDTO.getRepresentative());
        vo.setStatus(StatusEnum.ACTIVE.getId());
        vo.setApproved(StatusEnum.NOT_APPROVED.getId());
        vo.setIncoterm(agreementDTO.getIncoterm());
        vo.setPoNumber(agreementDTO.getPoNumber());
        vo.setRcdSAPCode(RepresentativeUtils.isAvailableRCD(agreementDTO.getRepresentative())?agreementDTO.getRepresentative().getSapUserId():null);
        vo = this.agreementRepository.save(vo);
        saveUpdateIncentivePackages(agreementDTO, vo);
        saveUpdateVolumeGoals(agreementDTO, vo);
        saveUpdateAgreementMails(agreementDTO, vo);

        final Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, null);
        parameters.put("currentDate", CustomerLinkUtils.SDF_DDMMYYYY.format(new Date()));
        parameters.put("agreementId", vo.getAgreementId());
        mailNotificationSender.send(NotificationType.AGREEMENT_TO_APPROVE.newNotification(distributorConfigDTO, parameters));

        agreementRepository.flush();
        return mapper.map(agreementRepository.findOne(vo.getAgreementId()),AgreementDTO.class);
    }

    @Override
    public AgreementDTO updateAgreement(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO)
            throws AgreementNotFoundException, InvalidProductForPrivateDistributor,
            DistributorConfigNotFoundException {

        validateUpdateAgreementParameters(agreementDTO, distributorConfigDTO);

        DistributorProfileVO distvo = distributorService.retrieveDistributorConfigByConfig(distributorConfigDTO);

        FiscalYearVO yearVo = new FiscalYearVO();
        yearVo.setFiscalYear(getFiscalYear());//agreementDTO.getFiscalYear().getFiscalYear());

        AgreementVO vo = obtainExistAgreement(yearVo, distvo,agreementDTO.getRepresentative());
        if (vo == null) {

            throw new AgreementNotFoundException(new Object[]{
                    distributorConfigDTO.getDistributor().getDistributorCode(),
                    distributorConfigDTO.getSalesOrgCode(),
                    distributorConfigDTO.getSalesDivCode(),
                    distributorConfigDTO.getDistChCode()
            });
        }

        vo.setIncoterm(agreementDTO.getIncoterm());
        vo.setPoNumber(agreementDTO.getPoNumber());

        //{0}, organización de ventas {1}, subregion {2}, división ventas {3}, canal distribución {4}, representante canal {5}
        vo.setApproved(agreementDTO.getApproved());
        //vo.setStatus(agreementDTO.getStatus());

        this.agreementRepository.save(vo);

        saveUpdateIncentivePackages(agreementDTO, vo);
        saveUpdateVolumeGoals(agreementDTO, vo);
        saveUpdateAgreementMails(agreementDTO, vo);

        return mapper.map(agreementRepository.findOne(vo.getAgreementId()),AgreementDTO.class);
    }

    @Override
    public AgreementDTO deleteAgreement(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO)
            throws AgreementNotFoundException, DistributorConfigNotFoundException {

        DistributorProfileVO distvo = distributorService.retrieveDistributorConfigByConfig(distributorConfigDTO);

        FiscalYearVO yearVo = new FiscalYearVO();
        yearVo.setFiscalYear(getFiscalYear());

        AgreementVO vo = obtainExistAgreement(yearVo, distvo,agreementDTO.getRepresentative());

        if (vo == null) {
            throw new AgreementNotFoundException(new Object[]{/*agreementDTO.getAgreementId()*/});
        }

        vo.setStatus(StatusEnum.DELETED.getId());
        this.agreementRepository.save(vo);
        return agreementDTO;
    }

    private void saveUpdateIncentivePackages(AgreementDTO agreementDTO, AgreementVO agreementVO) {

        for (IncentivePackageDTO incentiveDTO : agreementDTO.getIncentivePackages()) {
            IncentivePackageVO incentivePackageVO = new IncentivePackageVO();

            incentivePackageVO.setAgreementByAgreementId(agreementVO);
            incentivePackageVO.setDiscountOnInvoice(incentiveDTO.getDiscountOnInvoice());
            incentivePackageVO.setFamilyCode(incentiveDTO.getFamilyCode());
            if (incentiveDTO.getIncentivePackageId() != 0) {
                incentivePackageVO.setIncentivePackageId(incentiveDTO.getIncentivePackageId());
            }
            incentivePackageVO.setIncentiveVolumeGoalPeriod(incentiveDTO.getIncentiveVolumeGoalPeriod());
            incentivePackageVO.setSku(incentiveDTO.getSku());
            incentivePackageVO.setTotal(incentiveDTO.getTotal());
            incentivePackageRepository.save(incentivePackageVO);
        }
    }

    private void saveUpdateVolumeGoals(AgreementDTO agreementDTO, AgreementVO agreementVO) {
        for (VolumeGoalDTO volumeDTO : agreementDTO.getVolumeGoals()) {
            VolumeGoalVO volumeVO = saveVolumeGoal(volumeDTO, agreementVO);

            for (VolumeGoalPeriodDTO volumeGoalPeriodDTO : volumeDTO.getVolumeGoalPeriods()) {
                saveVolumeGoal(volumeGoalPeriodDTO, volumeVO, volumeDTO);
            }
        }
    }

    private void saveVolumeGoal(VolumeGoalPeriodDTO volumeGoalPeriodDTO, VolumeGoalVO volumeVO, VolumeGoalDTO volumeDTO) {
        PeriodVO periodVO = new PeriodVO();
        periodVO.setPeriodId(volumeGoalPeriodDTO.getPeriod().getPeriodId());

        VolumeGoalPeriodVO volumeGoalPeriodVO = new VolumeGoalPeriodVO();

        if (volumeDTO.getVolumeGoalId() != 0) {
            volumeGoalPeriodVO.setVolumeGoalPeriodId(volumeGoalPeriodDTO.getVolumeGoalPeriodId());
        }

        volumeGoalPeriodVO.setVolumeGoalByVolumeGoalId(volumeVO);
        volumeGoalPeriodVO.setQty(volumeGoalPeriodDTO.getQty());

        volumeGoalPeriodVO.setPeriodByPeriodId(periodVO);

        volumeGoalPeriodVO = volumeGoalPeriodRepository.save(volumeGoalPeriodVO);
    }

    private VolumeGoalVO saveVolumeGoal(VolumeGoalDTO volumeDTO, AgreementVO agreementVO) {
        VolumeGoalVO volumeVO = new VolumeGoalVO();

        volumeVO.setFamilyCode(volumeDTO.getFamilyCode());
        volumeVO.setSku(volumeDTO.getSku());
        volumeVO.setTotalVolume(volumeDTO.getTotalVolume());
        volumeVO.setUmBase(volumeDTO.getUmBase());
        volumeVO.setAgreementByAgreementId(agreementVO);
        if (volumeDTO.getVolumeGoalId() != 0) {
            volumeVO.setVolumeGoalId(volumeDTO.getVolumeGoalId());
        }

        return volumeGoalRepository.save(volumeVO);
    }

    private void saveUpdateAgreementMails(AgreementDTO agreementDTO, AgreementVO agreementVO) {

        for (AgreementEmailDTO emailDTO : agreementDTO.getAgreementEmails()) {
            AgreementEmailVO emailVO = new AgreementEmailVO();

            if (emailDTO.getAgreementEmailId() != 0) {
                emailVO.setAgreementEmailId(emailDTO.getAgreementEmailId());
            }

            emailVO.setAgreementByAgreementId(agreementVO);
            emailVO.setEmail(emailDTO.getEmail());

            agreementEmailRepository.save(emailVO);
        }
    }

    private AgreementVO validateIfExistAgreement(FiscalYearVO yearVo, DistributorProfileVO distvo,
                                                 DistributorConfigDTO distributorConfigDTO, RepresentativeDTO representativeDTO)throws AgreementAlreadyExistsException {

        AgreementVO vo = obtainExistAgreement(yearVo, distvo, representativeDTO);

        if (vo != null) {
            throw new AgreementAlreadyExistsException(new Object[]{
                    distributorConfigDTO.getDistributor().getDistributorCode(),
                    distributorConfigDTO.getSalesOrgCode(),
                    distributorConfigDTO.getSalesDivCode(),
                    distributorConfigDTO.getDistChCode()
            });
        }
        vo = new AgreementVO();

        vo.setFiscalYearByFiscalYear(yearVo);

        vo.setDistributorProfileByDistributorProfileId(distvo);

        Timestamp time = new Timestamp(new Date().getTime());
        vo.setCreateDate(time);
        vo.setUpdateDate(time);
        vo.setStatus(StatusEnum.ACTIVE.getId());
        return vo;
    }

    private AgreementVO obtainExistAgreement(FiscalYearVO yearVo, DistributorProfileVO distvo, RepresentativeDTO representativeDTO) {
        return agreementServiceHelper.obtainAgreementByParameters(yearVo,distvo,representativeDTO);
    }

    private void validateCreateAgreementParameters(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO) throws AgreementWithoutVolumeGoalException, AgreementWithoutIncentivePackageException,
            VolumeGoalWithoutPeriodException, VolumenGoalNotEnoughPeriodsException, InvalidProductForPrivateDistributor {

        if (agreementDTO.getVolumeGoals().isEmpty()) {
            throw new AgreementWithoutVolumeGoalException(
                    new Object[]{
                            distributorConfigDTO.getDistributor().getDistributorCode(),
                            distributorConfigDTO.getSalesOrgCode(),
                            distributorConfigDTO.getSalesDivCode(),
                            distributorConfigDTO.getDistChCode()
                    }
            );
        }

        CustomerLinkUtils.isValidParameter(agreementDTO.getIncentivePackages());
        if (agreementDTO.getIncentivePackages().isEmpty()) {
            throw new AgreementWithoutIncentivePackageException(new Object[]{
                    distributorConfigDTO.getDistributor().getDistributorCode(),
                    distributorConfigDTO.getSalesOrgCode(),
                    distributorConfigDTO.getSalesDivCode(),
                    distributorConfigDTO.getDistChCode()
            });
        }

        boolean isPrivate = isPrivateBrandDistributor(distributorConfigDTO);
        validateVolumenGoalsPeriod(agreementDTO, isPrivate, distributorConfigDTO);
        validateProductsForPrivateBrand(agreementDTO, distributorConfigDTO, isPrivate);
    }

    private void validateUpdateAgreementParameters(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO) throws
            InvalidProductForPrivateDistributor {


        boolean isPrivate = isPrivateBrandDistributor(distributorConfigDTO);
        validateProductsForPrivateBrand(agreementDTO, distributorConfigDTO, isPrivate);
    }

    private void validateVolumenGoalsPeriod(AgreementDTO agreementDTO, boolean isPrivateBrand, DistributorConfigDTO distributorConfigDTO) throws VolumeGoalWithoutPeriodException, VolumenGoalNotEnoughPeriodsException {

        for (VolumeGoalDTO volumeGoalDTO : agreementDTO.getVolumeGoals()) {
            boolean emptyPeriods = volumeGoalDTO.getVolumeGoalPeriods() == null || volumeGoalDTO.getVolumeGoalPeriods().isEmpty();
            if (emptyPeriods) {
                throw new VolumeGoalWithoutPeriodException(new Object[]{
                        distributorConfigDTO.getDistributor().getDistributorCode(),
                        distributorConfigDTO.getSalesOrgCode(),
                        distributorConfigDTO.getSalesDivCode(),
                        distributorConfigDTO.getDistChCode()
                });
            }
            boolean privateBrandWithDifferentNumOfPeriods = isPrivateBrand && volumeGoalDTO.getVolumeGoalPeriods().size() != PeriodsEnum.PERIODS_BY_PRIVATE_BRAND.getId();
            if (privateBrandWithDifferentNumOfPeriods) {
                throw new VolumenGoalNotEnoughPeriodsException(new Object[]{
                        distributorConfigDTO.getDistributor().getDistributorCode(),
                        distributorConfigDTO.getSalesOrgCode(),
                        distributorConfigDTO.getSalesDivCode(),
                        distributorConfigDTO.getDistChCode()
                });
            }

            boolean notPrivateBrandWithDifferentNumOfPeriods = !isPrivateBrand && volumeGoalDTO.getVolumeGoalPeriods().size() != PeriodsEnum.PERIODS_BY_NOT_PRIVATE_BRAND.getId();
            if (notPrivateBrandWithDifferentNumOfPeriods) {
                throw new VolumenGoalNotEnoughPeriodsException(new Object[]{
                        distributorConfigDTO.getDistributor().getDistributorCode(),
                        distributorConfigDTO.getSalesOrgCode(),
                        distributorConfigDTO.getSalesDivCode(),
                        distributorConfigDTO.getDistChCode(),
                });
            }
        }
    }

    private boolean isPrivateBrandDistributor(DistributorConfigDTO distributorConfigDTO) {
        return distributorService.verifyIsPrivateBrandDistributor(distributorConfigDTO.getDistributor().getDistributorCode());
    }

    private void validateProductsForPrivateBrand(AgreementDTO agreementDTO, DistributorConfigDTO distributorConfigDTO, boolean isPrivateDistributor) throws InvalidProductForPrivateDistributor {
        if (!isPrivateDistributor) {
            return;
        }

        List<PrivateBrandDistributorVO> privateBrandDistributorVOList = this.privateBrandDistributorRepository.findByDistributorCode(distributorConfigDTO.getDistributor().getDistributorCode());

        for (VolumeGoalDTO volumeDTO : agreementDTO.getVolumeGoals()) {
            boolean isInPrivateProducts = false;

            for (PrivateBrandDistributorVO privateBrandDistributorVO : privateBrandDistributorVOList) {
                if (volumeDTO.getSku().equals(privateBrandDistributorVO.getProductByProductCode().getProductCode())) {
                    isInPrivateProducts = true;
                    break;
                }
            }

            if (!isInPrivateProducts) {
                throw new InvalidProductForPrivateDistributor(new Object[]{volumeDTO.getSku()});
            }
        }
    }

    private Long getFiscalYear() {
        return Long.valueOf(CustomerLinkUtils.getFiscalYear(new Date()));
    }

    private String getDistributorCode(DistributorConfigDTO configDTO) {
        if (configDTO != null && configDTO.getDistributor() != null && !StringUtils.isEmpty(configDTO.getDistributor().getDistributorCode())) {
            return configDTO.getDistributor().getDistributorCode();
        }
        return "-1";
    }

    private String getValue(String val) {
        if (val == null) {
            return "-1";
        }
        return val;
    }

    private Long getValue(Long val) {
        if (val == null) {
            return -1l;
        }
        return val;
    }
}
