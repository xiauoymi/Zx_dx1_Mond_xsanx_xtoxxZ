package com.monsanto.customerlink.core.service.impl;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class ApplicationContextProvider implements ApplicationContextAware {

    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        ApplicationContextProvider.assignApplicationContext(applicationContext);
    }

    public static void assignApplicationContext(ApplicationContext applicationContext){
        if(context == null) {
            context = applicationContext;
        }
    }

    public static Object getBeanByClass(Class clazz) {
        return context.getBean(clazz);
    }

    public static void closeContext() {
        ((ConfigurableApplicationContext)ApplicationContextProvider.context).close();
    }
}