package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.BackorderService;
import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.BackorderVO;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.repositories.BackorderRepository;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderDTO;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Service("backorderBusiness")
public class BackorderServiceImpl implements BackorderService {

    @Autowired
    private DistributorService distributorBusiness;

    @Autowired
    private BackorderRepository backorderRepository;

    @Autowired
    private Mapper mapper;

    /**
     * @see BackorderService#createBackorder(BackorderDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public BackorderDTO createBackorder(final BackorderDTO backorderDTO) throws DistributorConfigNotFoundException {
        validateInputParameters(backorderDTO);
        final DistributorProfileVO distributorProfileVO = distributorBusiness.retrieveDistributorConfigByConfig(backorderDTO.getDistributorConfigDTO());
        final List<BackorderVO> backorderVOList = mapper.mapList(BackorderVO.class, backorderDTO.getDetail());
        final Timestamp dateWithTime = new Timestamp(new Date().getTime());
        CollectionUtils.forAllDo(backorderVOList, new Closure() {
            @Override
            public void execute(final Object object) {
                final BackorderVO backorderVO = (BackorderVO) object;
                backorderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
                backorderVO.setCreateDate(dateWithTime);
            }
        });
        backorderRepository.save(backorderVOList);
        return backorderDTO;
    }

    /**
     * @see BackorderService#retrieveBackorders(DistributorConfigDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public List<BackorderDTO> retrieveBackorders(final DistributorConfigDTO distributorProfileDTO) throws OrdersNotFoundException {
        final List<DistributorProfileVO> distributorProfileVOList = backorderRepository.findByParameters(distributorProfileDTO);
        if (distributorProfileVOList.isEmpty()) {
            throw new OrdersNotFoundException(new Object[]{});
        }
        return mapper.mapList(BackorderDTO.class, distributorProfileVOList);
    }

    /**
     * Validates input parameters
     *
     * @param backorderDTO
     */
    private void validateInputParameters(final BackorderDTO backorderDTO) {
        CustomerLinkUtils.isValidParameter(backorderDTO);
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getSalesOrgCode());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getDistChCode());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getSalesDivCode());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getSubRegionCode());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getDistributor());
        CustomerLinkUtils.isValidParameter(backorderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
        if (backorderDTO.getDetail().isEmpty()) {
            throw new IllegalArgumentException();
        } else {
            CollectionUtils.forAllDo(backorderDTO.getDetail(), new Closure() {
                @Override
                public void execute(final Object object) {
                    final BackorderDetailDTO backorderDetailDTO = (BackorderDetailDTO) object;
                    CustomerLinkUtils.isValidParameter(backorderDetailDTO.getProductDTO());
                    CustomerLinkUtils.isValidParameter(backorderDetailDTO.getProductDTO().getProductCode());
                    CustomerLinkUtils.isValidParameter(backorderDetailDTO.getQuantity());
                }
            });
        }
    }

}
