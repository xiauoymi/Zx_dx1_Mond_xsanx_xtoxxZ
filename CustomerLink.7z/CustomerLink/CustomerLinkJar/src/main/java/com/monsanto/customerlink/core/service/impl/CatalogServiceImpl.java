package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CatalogService;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CatalogServiceImpl implements CatalogService{

    private RoleRepository roleRepository;
    private Mapper mapper;
    private BrandRepository brandRepository;
    private SubRegionRepository subRegionRepository;
    private DistributorRepository distributorRepository;
    private DistributorProfileRepository distributorProfileRepository;
    private UserManagementService userManagementService;

    @Autowired
    public CatalogServiceImpl(RoleRepository roleRepository, Mapper mapper, BrandRepository brandRepository,
                              SubRegionRepository subRegionRepository,DistributorRepository distributorRepository,
                              DistributorProfileRepository distributorProfileRepository,
                              UserManagementService userManagementService) {
        this.roleRepository = roleRepository;
        this.mapper = mapper;
        this.brandRepository = brandRepository;
        this.subRegionRepository = subRegionRepository;
        this.distributorRepository = distributorRepository;
        this.distributorProfileRepository = distributorProfileRepository;
        this.userManagementService = userManagementService;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfRoles()
     */
    public List<RoleDTO> getListOfRoles() {

        List<RoleDTO> listOfRoles = new ArrayList<RoleDTO>();
        List<RoleVO> l = roleRepository.findRolesNotIn(Arrays.asList(new String[]{RoleEnum.ADMINISTRATOR.getCode(), RoleEnum.DISTRIBUTOR.getCode()}));

        if(!l.isEmpty()) {
            listOfRoles = mapper.mapList(RoleDTO.class,l);
        }

        return listOfRoles;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfBrands()
     */
    public List<BrandDTO> getListOfBrands() {

        List<BrandDTO> listOfBrands = new ArrayList<BrandDTO>();

        List<BrandVO> l = brandRepository.findAll();

        if(!l.isEmpty()) {
            listOfBrands = mapper.mapList(BrandDTO.class,l);
        }

        return listOfBrands;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfSubRegions()
     */
    public List<SubRegionDTO> getListOfSubRegions() {

        List<SubRegionDTO> listOfSubRegion = new ArrayList<SubRegionDTO>();

        List<SubRegionVO> l = subRegionRepository.findSubRegionNotIn(Arrays.asList(new String[]{CustomerLinkCoreConstants.SUB_REGION_ALL}));

        if(!l.isEmpty()) {
            listOfSubRegion = mapper.mapList(SubRegionDTO.class,l);
        }

        return listOfSubRegion;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfDistributors()
     */
    @Transactional(timeout = 300)
    public List<DistributorDTO> getListOfDistributors() {

        List<DistributorDTO> listOfDistributor = new ArrayList<DistributorDTO>();

        List<DistributorVO> l = distributorRepository.getAllDistributors();

        if(!l.isEmpty()) {
            for(DistributorVO d : l) {
                listOfDistributor.add(new DistributorDTO(d.getDistributorCode(),d.getName()));
            }
        }

        return listOfDistributor;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getDistributorsBySubRegionAndDistributorCodeOrName(String, String)
     */
    public List<GridDistributorProfileDTO> getDistributorsBySubRegionAndDistributorCodeOrName(String subRegionCode, String distributorCodeOrName) {

        List<GridDistributorProfileDTO> listOfDistributors = new ArrayList<GridDistributorProfileDTO>();

        if(StringUtils.isNotEmpty(subRegionCode)) {

            List<DistributorProfileVO> listOfDistributorProfiles;

            if(StringUtils.isNotEmpty(distributorCodeOrName) && StringUtils.isNotEmpty(distributorCodeOrName.trim())) {
                listOfDistributorProfiles = distributorProfileRepository.findBySubRegionCodeAndDistributorCodeOrName(subRegionCode,distributorCodeOrName);
            }else {
                listOfDistributorProfiles = distributorProfileRepository.findBySubRegionCode(subRegionCode);
            }

            if(!listOfDistributorProfiles.isEmpty()) {
                listOfDistributors = mapper.mapList(GridDistributorProfileDTO.class,listOfDistributorProfiles);
            }
        }

        return listOfDistributors;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfDistributorsByUser(Long)
     */
    public List<DistributorDTO> getListOfDistributorsByUser(Long userId) {

        List<DistributorDTO> distributors = new ArrayList<DistributorDTO>();

        if(userId!=null) {

            List<DistributorVO> list = distributorRepository.findByUserId(userId);

            if(!list.isEmpty()) {
                distributors = mapper.mapList(DistributorDTO.class, list );
            }
        }

        return distributors;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfUserRoleByDistributorProfileId(Long)
     */
    public List<UserRoleDTO> getListOfUserRoleByDistributorProfileId(Long idDistributorProfile) {

        List<UserRoleDTO> users = new ArrayList<UserRoleDTO>();

        List<UserVO> totalRoles = userManagementService.getListOfUserByDistributorProfileId(idDistributorProfile);

        if(!totalRoles.isEmpty()) {
            users = mapper.mapList(UserRoleDTO.class,totalRoles);
        }

        return users;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.CatalogService#getListOfGridUserRoleByDistributorProfileId(Long)
     */
    public List<GridUserRoleDTO> getListOfGridUserRoleByDistributorProfileId(Long idDistributorProfile) {

        List<GridUserRoleDTO> users = new ArrayList<GridUserRoleDTO>();

        List<UserVO> totalRoles = userManagementService.getListOfUserByDistributorProfileId(idDistributorProfile);

        if(!totalRoles.isEmpty()) {
            users = mapper.mapList(GridUserRoleDTO.class,totalRoles);
        }

        return users;
    }
}