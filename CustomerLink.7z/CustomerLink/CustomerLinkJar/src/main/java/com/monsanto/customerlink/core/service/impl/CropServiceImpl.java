package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CropServiceImpl implements CropService {

    private CropRepository cropRepository;

    @Autowired
    public CropServiceImpl(CropRepository cropRepository) {
        this.cropRepository = cropRepository;
    }


    @Override
    public CropVO obtainCropByCode(String cropCode) {
        return cropRepository.findByCropCode(cropCode);
    }

}
