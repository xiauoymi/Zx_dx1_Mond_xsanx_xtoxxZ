package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DecreaseATPService;
import com.monsanto.customerlink.core.service.DecreaseWithoutSoakTestATPService;
import com.monsanto.customerlink.core.service.IncreaseDecreaseATPHelper;
import com.monsanto.customerlink.core.service.SAPOrderService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.SeedsSalesOrganizationEnum;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

@Service
public class DecreaseATPServiceImpl implements DecreaseATPService{

    private Mapper mapper;
    private SAPOrderService sapOrderService;
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;
    private DecreaseWithoutSoakTestATPService decreaseWithoutSoakTestATPService;

    @Autowired
    public DecreaseATPServiceImpl(Mapper mapper,
                                  SAPOrderService sapOrderService,
                                  IncreaseDecreaseATPHelper increaseDecreaseATPHelper,
                                  DecreaseWithoutSoakTestATPService decreaseWithoutSoakTestATPService) {
        this.mapper = mapper;
        this.sapOrderService = sapOrderService;
        this.increaseDecreaseATPHelper = increaseDecreaseATPHelper;
        this.decreaseWithoutSoakTestATPService = decreaseWithoutSoakTestATPService;
    }

    /**
     * If there is a list of hybrids to decrease, the system is chosen the way to go depending on whether it is
     * "Corn-Sorghum" or "Cotton-Soybean"
     * @param sapOrder
     * @param atpOrder
     */
    public void decreaseATPProcess(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws CustomerLinkBusinessException {

        increaseDecreaseATPHelper.validateInputParameters(sapOrder,atpOrder);

        // hybrids are assigned to decrease
        atpOrder.setDetail(increaseDecreaseATPHelper.obtainHybridsToIncreaseOrDecrease(sapOrder,atpOrder,false));

        // The validation is performed again since hybrids may not exist to decrease
        if (existHybridsToProcess(atpOrder)) {
            // It decrement if exist a without-soak test order and a normal season order
            Map<OrderDTO, SAPOrderDTO> ordersToDecrease = decreaseWithoutSoakTestATPService.decreaseWhitAWithoutSoakTestOrder(atpOrder, sapOrder);
            for (OrderDTO orderToDecrease : ordersToDecrease.keySet()) {
                SAPOrderDTO sapOrderToDecrease = ordersToDecrease.get(orderToDecrease);
                if (orderToDecrease.getDistributorConfigDTO().getSalesOrgCode().equals(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode())) {

                    decreaseAtp(sapOrderToDecrease,orderToDecrease,true);

                } else if (orderToDecrease.getDistributorConfigDTO().getSalesOrgCode().equals(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode())) {

                    decreaseAtp(sapOrderToDecrease,orderToDecrease,false);
                }
            }
        }
    }

    /**
     * It allows the process to decrease the inventory
     * @param sapOrder
     * @param atpOrder
     * @param isCornOrSorghum
     */
    private void decreaseAtp(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isCornOrSorghum ) throws CustomerLinkBusinessException {

        for(OrderDetailDTO detail : atpOrder.getDetail()) {

            String hybrid = detail.getProductDTO().getProductCode();
            double amountToDecrementing = detail.getQuantity();

            // hybrids grouped (SAP ORDER)
            Map<String, List<MaterialDTO>> groupByHybrid = increaseDecreaseATPHelper.groupByHybrid(sapOrder.getHybrids());

             // materials obtained by hybrid
            List<MaterialDTO> listOfMaterial = groupByHybrid.get(hybrid);

            if ( listOfMaterial!=null && !listOfMaterial.isEmpty()) {
                detail.getProductDTO().setListOfSku(decreaseInventoryOfMaterialList(listOfMaterial,amountToDecrementing, isCornOrSorghum));
            }
        }

        List<OrderDetailDTO> detailsToRemove = new ArrayList<OrderDetailDTO>();

        for(OrderDetailDTO detail : atpOrder.getDetail()) {
            if(detail.getProductDTO().getListOfSku() == null || (detail.getProductDTO().getListOfSku()).isEmpty()) {
                detailsToRemove.add(detail);
            }
        }

        if(!detailsToRemove.isEmpty()) {
            atpOrder.getDetail().removeAll(detailsToRemove);
        }

        if(!atpOrder.getDetail().isEmpty()) {

            // is assigned the identifier of the order
            atpOrder.setOrderIdSAP(sapOrder.getSalesorder());

            // service is invoked to update the order
            sapOrderService.postOrderWithoutAlgorithm(atpOrder);
        }
    }

    /**
     * Contains the main process to decrease the inventory and launches specialized processes decrease of
     * "Corn-Sorghum" or "Cotton-Sybean"
     * @param listOfMaterial
     * @param amountToDecrementing
     * @param isCornOrSorghum
     * @return
     */
    private List<MaterialSkuDTO> decreaseInventoryOfMaterialList(List<MaterialDTO> listOfMaterial, double amountToDecrementing, boolean isCornOrSorghum) {

        List<MaterialSkuDTO> listOfItemsToDecrease = new ArrayList<MaterialSkuDTO>();

        // containing the items for decrease
        List<MaterialDecreaseAtpDTO> availableItemList = new ArrayList<MaterialDecreaseAtpDTO>();

        // containing the amount available to decrease
        double availableForDecrease = eliminateItemsNotHaveInventoryAvailableDecrease(availableItemList,listOfMaterial, isCornOrSorghum);

        if(!availableItemList.isEmpty()) {

            // valid if sufficient inventory for the decrease
            if( availableForDecrease - amountToDecrementing < 0 ) {
                // there is not enough inventory for the decrease, is assigned the "amount available to decrease"
                amountToDecrementing = availableForDecrease;
            }

            // contains the percentage to be decremented for each item
            double percentageDecrease = amountToDecrementing / availableForDecrease;

            // decrease inventory
            decreaseInventory(availableItemList, percentageDecrease, amountToDecrementing, isCornOrSorghum);

            listOfItemsToDecrease = getDecreaseInventoryList(availableItemList);
        }

        return listOfItemsToDecrease;
    }

    /**
     * Process for selecting the items that have inventory available for the decrease. If the amount for allocation less
     * the delivery quantity is greater than zero, the item is taken into account for the decrease of inventory,
     * otherwise it is omitted. If the item does not have deliveries, becomes a candidate for deletion
     *
     * @param availableItemList
     * @param listOfMaterial
     * @param isCornOrSorghum
     * @return
     */
    private double eliminateItemsNotHaveInventoryAvailableDecrease(List<MaterialDecreaseAtpDTO> availableItemList, List<MaterialDTO> listOfMaterial, boolean isCornOrSorghum) {

        double availableForDecrease = 0D;

        // eliminate items that do not have inventory available to decrease
        for(MaterialDTO item : listOfMaterial) {

            double difference =  item.getReq_qty().doubleValue() - item.getDel_qty().doubleValue();

            if( difference > 0 ) {

                MaterialDecreaseAtpDTO m = new MaterialDecreaseAtpDTO(isCornOrSorghum);
                m.setMaxQuantityToDecrease(difference);
                m.setItem(item);

                // valid if the item does not have deliveries
                if(difference == item.getReq_qty().doubleValue()) {
                    // the item is a candidate to eliminate
                    m.setDeleteCandidate(true);
                }

                // add element to list
                availableItemList.add(m);

                // increases the amount available to remove
                availableForDecrease += difference;
            }
        }

        return availableForDecrease;
    }

    /**
     * Gets the list of items that should be modified or deleted as applicable and builds a list of objects to be sent
     * to the process that updates the order of sap
     * @param availableItemList
     * @return
     */
    private List<MaterialSkuDTO> getDecreaseInventoryList(List<MaterialDecreaseAtpDTO> availableItemList) {

        List<MaterialSkuDTO> listOfItemsToDecrease = new ArrayList<MaterialSkuDTO>();

         for(MaterialDecreaseAtpDTO item : availableItemList) {

            if(item.getQuantityToDecrease() != 0) {

                // values ​​are assigned batch, plant, storage location
                MaterialSkuDTO materialSku =  mapper.map(item.getItem(), MaterialSkuDTO.class);

                // is assigned to the amount of inventory item to update
                materialSku.setUnrestqty(item.getItem().getReq_qty() - item.getQuantityToDecrease());

                // assigned the status "Update" to item
                materialSku.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());

                // valid if the item is eligible to be removed and its inventory was used entirely for the decrease
                if( item.isDeleteCandidate() && item.getAvailableToAllocate() == 0 ) {
                    materialSku.setTransactionType(TransactionTypeMaterial.DELETE.getCode());
                }

                listOfItemsToDecrease.add(materialSku);
            }
        }

        return listOfItemsToDecrease;
    }

    /**
     * Contains the process to decrease the inventory of seeds "Corn-Sorghum" or "Cotton-Soybean".
     * @param availableItemList
     * @param percentageDecrease
     * @param amountToDecrementing
     * @param isCornOrSorghum
     */
    private void decreaseInventory(List<MaterialDecreaseAtpDTO> availableItemList, double percentageDecrease, double amountToDecrementing, boolean isCornOrSorghum) {

        double unallocated = 0;

        if(isCornOrSorghum) {

            // contain the amount allocated after the first decrease process
            double amountAllocated = assignInventoryPercentage(availableItemList,percentageDecrease);

            // amount was not allocated to inventory decrease
            unallocated = amountToDecrementing - amountAllocated;

        } else {
            unallocated = amountToDecrementing;
        }

        // validates the amount that was allocated to inventory decrease
        if(unallocated>0) {

            // sort
            Collections.sort(availableItemList);

            while(unallocated > 0) {
                unallocated = assignMissingInventoryForDecrease(unallocated, availableItemList);
            }
        }

    }

    /**
     * for each of the items get the proportionate amount that should decrease, just take the integer part.
     * The decimal portion is not taken into account because in a later process is evaluated
     *
     * @param availableItemList
     * @param percentageDecrease
     * @return
     */
    private double assignInventoryPercentage(List<MaterialDecreaseAtpDTO> availableItemList, double percentageDecrease) {

         double amountAllocated = 0;

        for(MaterialDecreaseAtpDTO item : availableItemList) {

            // is obtained to reduce the proportional amount
            double decrease =  item.getMaxQuantityToDecrease() * percentageDecrease;

            // remove decimal part
            BigDecimal integerDecrease = (BigDecimal.valueOf(decrease)).setScale(0, RoundingMode.FLOOR);

            // set integer decrease
            item.setQuantityToDecrease(integerDecrease.doubleValue());

            // increases the amount that was allocated to decrement the inventory
            amountAllocated += integerDecrease.doubleValue();
        }

        return amountAllocated;
    }

    /**
     *
     * Gets the amount to be allocated and a list of items that contain inventory. It evaluates each item to cover the
     * amount to be allocated
     *
     * @param unallocated
     * @param availableItemList
     * @return
     */
    private double assignMissingInventoryForDecrease(double unallocated, List<MaterialDecreaseAtpDTO> availableItemList ) {

        for(MaterialDecreaseAtpDTO item : availableItemList) {

            if(unallocated == 0) {
                break;
            }

            double availableToAllocate = item.getAvailableToAllocate();

            if(  availableToAllocate > 0) {

                double allocate = availableToAllocate - unallocated;

                if(allocate <= 0 ) {

                    // decrements the total free to assign
                    unallocated -= availableToAllocate;

                    // updates the available quantity equal to the maximum available to allocate
                    item.setQuantityToDecrease(item.getMaxQuantityToDecrease());

                } else {
                    item.setQuantityToDecrease( item.getQuantityToDecrease() + unallocated  );
                    unallocated = 0;
                }
            }
        }

        return unallocated;
    }

    private boolean existHybridsToProcess(OrderDTO orderDTO) {
        return !orderDTO.getDetail().isEmpty();
    }

    private class MaterialDecreaseAtpDTO implements Comparable<MaterialDecreaseAtpDTO> {

        private boolean isCornOrSorghum;
        private boolean deleteCandidate;
        private double maxQuantityToDecrease;
        private double quantityToDecrease;
        private MaterialDTO item;

        public MaterialDecreaseAtpDTO(boolean isCornOrSorghum) {
            this.isCornOrSorghum = isCornOrSorghum;
        }

        public double getMaxQuantityToDecrease() {
            return maxQuantityToDecrease;
        }

        public void setMaxQuantityToDecrease(double maxQuantityToDecrease) {
            this.maxQuantityToDecrease = maxQuantityToDecrease;
        }

        public MaterialDTO getItem() {
            return item;
        }

        public void setItem(MaterialDTO item) {
            this.item = item;
        }

        public double getQuantityToDecrease() {
            return quantityToDecrease;
        }

        public void setQuantityToDecrease(double quantityToDecrease) {
            this.quantityToDecrease = quantityToDecrease;
        }

        public double getAvailableToAllocate() {
            return maxQuantityToDecrease-quantityToDecrease;
        }

        public boolean isDeleteCandidate() {
            return deleteCandidate;
        }

        public void setDeleteCandidate(boolean deleteCandidate) {
            this.deleteCandidate = deleteCandidate;
        }

        public boolean isCornOrSorghum() {
            return isCornOrSorghum;
        }

        @Override
        public int compareTo(MaterialDecreaseAtpDTO o) {

            int i = 0;

            if(this.isCornOrSorghum()) {
                i = compareCornOrSorghum(o);
            } else {
                i = compareCottonOrSoybean(o);
            }

            return i;
        }

        public int compareCornOrSorghum(MaterialDecreaseAtpDTO o) {

            int i = 0;

            // assessment if both elements are candidates to eliminate or both are not candidates to eliminate
            if((this.isDeleteCandidate() && o.isDeleteCandidate()) || (!this.isDeleteCandidate() && !o.isDeleteCandidate())) {

                // in this case select the one with largest inventory available to decrease

                if(this.getAvailableToAllocate() < o.getAvailableToAllocate()) {
                    i = 1;
                }else if(this.getAvailableToAllocate() > o.getAvailableToAllocate()) {
                    i = -1;
                }

            } else if( this.isDeleteCandidate() && !o.isDeleteCandidate() ) {
                i = -1;
            } else if(!this.isDeleteCandidate() && o.isDeleteCandidate()) {
                i = 1;
            }

            return i;
        }

        public int compareCottonOrSoybean(MaterialDecreaseAtpDTO o) {

            int i = 0;

            if(this.getAvailableToAllocate() < o.getAvailableToAllocate()) {
                i = -1;
            } else if(this.getAvailableToAllocate() > o.getAvailableToAllocate()) {
                i = 1;
            }

            return i;
        }

    }

}
