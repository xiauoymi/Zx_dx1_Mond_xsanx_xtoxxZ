package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DecreaseWithoutSoakTestATPService;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DecreaseWithoutSoakTestATPServiceImpl implements DecreaseWithoutSoakTestATPService {

    private HybridDTO normalSeasonHybrid;
    private HybridDTO withoutSoakTestHybrid;
    private List<OrderDetailDTO> atpDetailNormalSeasonOrder;
    private List<OrderDetailDTO> atpDetailWithoutSoakTestOrder;
    private Map<OrderDTO, SAPOrderDTO> orderDTOMap;

    @Autowired
    private Mapper mapper;

    public Map<OrderDTO, SAPOrderDTO> decreaseWhitAWithoutSoakTestOrder(OrderDTO atpOrder, SAPOrderDTO sapOrder) {
        orderDTOMap = new HashMap<OrderDTO, SAPOrderDTO>();
        if (null == sapOrder.getWithoutSoakTestOrder()) {
            orderDTOMap.put(atpOrder, sapOrder);
        } else {
            atpDetailWithoutSoakTestOrder = new ArrayList<OrderDetailDTO>();
            atpDetailNormalSeasonOrder = new ArrayList<OrderDetailDTO>();
            for (OrderDetailDTO atpHybrid : atpOrder.getDetail()) {
                normalSeasonHybrid = findHybridInSAPOrder(sapOrder.getHybrids(), atpHybrid.getProductDTO().getProductCode());
                withoutSoakTestHybrid = findHybridInSAPOrder(sapOrder.getWithoutSoakTestOrder().getHybrids(), atpHybrid.getProductDTO().getProductCode());
                generateDecrements(atpHybrid, atpHybrid.getQuantity());
            }
            generateOrders(atpOrder, sapOrder);
        }
        return orderDTOMap;
    }

    private HybridDTO findHybridInSAPOrder(List<HybridDTO> hybridDTOList, final String hybridCode) {
        return (HybridDTO) CollectionUtils.find(hybridDTOList, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                HybridDTO hybrid = (HybridDTO) o;
                return StringUtils.equals(hybridCode, hybrid.getHybridCode());
            }
        });
    }

    private void generateDecrements(OrderDetailDTO atpHybrid, double qtyToDecrease) {
        if (null == withoutSoakTestHybrid) {
            generateNormalSeasonDecrement(atpHybrid, qtyToDecrease);
        } else {
            double qtyToDecreaseWithoutSoakTest = generateWithoutSoakTestDecrement(atpHybrid, qtyToDecrease);
            if (qtyToDecreaseWithoutSoakTest < 0) {
                generateNormalSeasonDecrement(atpHybrid, qtyToDecreaseWithoutSoakTest);
            }
        }
    }

    private void generateOrders(OrderDTO atpOrder, SAPOrderDTO sapOrder) {
        generateWithoutSoakTestOrder(atpOrder, sapOrder.getWithoutSoakTestOrder());
        generateNormalSeasonOrder(atpOrder, sapOrder);
    }

    private double generateWithoutSoakTestDecrement(OrderDetailDTO atpHybrid, double qtyToDecrease) {
        double qtyToDecreaseWithoutSoakTest = withoutSoakTestHybrid.getTotalQty() - qtyToDecrease;
        final OrderDetailDTO atpHybridToDecrease = mapper.map(atpHybrid, OrderDetailDTO.class);
        atpHybridToDecrease.setQuantity((qtyToDecreaseWithoutSoakTest >= 0 ? qtyToDecrease : withoutSoakTestHybrid.getTotalQty()));
        atpDetailWithoutSoakTestOrder.add(atpHybridToDecrease);
        return qtyToDecreaseWithoutSoakTest;
    }

    private void generateNormalSeasonDecrement(OrderDetailDTO atpHybrid, double qtyToDecreaseWithoutSoakTest) {
        if (null != normalSeasonHybrid) {
            final double qtyToDecreaseNormalSeason = normalSeasonHybrid.getTotalQty() - Math.abs(qtyToDecreaseWithoutSoakTest);
            final OrderDetailDTO atpHybridToDecrease = mapper.map(atpHybrid, OrderDetailDTO.class);
            atpHybridToDecrease.setQuantity((qtyToDecreaseNormalSeason >= 0 ? Math.abs(qtyToDecreaseWithoutSoakTest) : normalSeasonHybrid.getTotalQty()));
            atpDetailNormalSeasonOrder.add(atpHybridToDecrease);
        }
    }

    private void generateWithoutSoakTestOrder(OrderDTO atpOrder, SAPOrderDTO sapOrder) {
        if (!atpDetailWithoutSoakTestOrder.isEmpty()) {
            final OrderDTO atpWithoutSoakTestOrder = mapper.map(atpOrder, OrderDTO.class);
            atpWithoutSoakTestOrder.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code());
            atpWithoutSoakTestOrder.setDetail(atpDetailWithoutSoakTestOrder);
            orderDTOMap.put(atpWithoutSoakTestOrder, sapOrder);
        }
    }

    private void generateNormalSeasonOrder(OrderDTO atpOrder, SAPOrderDTO sapOrder) {
        if (!atpDetailNormalSeasonOrder.isEmpty()) {
            final OrderDTO atpNormalSeasonOrder = mapper.map(atpOrder, OrderDTO.class);
            atpNormalSeasonOrder.setDetail(atpDetailNormalSeasonOrder);
            orderDTOMap.put(atpNormalSeasonOrder, sapOrder);
        }
    }
}
