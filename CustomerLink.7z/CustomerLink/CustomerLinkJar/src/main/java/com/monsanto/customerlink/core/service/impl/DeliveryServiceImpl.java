package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DeliveryService;
import com.monsanto.customerlink.core.service.exception.DeleteDeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryProductNotFoundException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.DeliveryProductVO;
import com.monsanto.customerlink.persistence.entities.DeliveryVO;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.persistence.repositories.DeliveryProductRepository;
import com.monsanto.customerlink.persistence.repositories.DeliveryRepository;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalDeliveryDTO;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalSavedDeliveryDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

@Service
public class DeliveryServiceImpl implements DeliveryService{

    @Autowired
    private Mapper mapper;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Autowired
    private DeliveryProductRepository deliveryProductRepository;

    @Override
    public List<TemporalDeliveryDTO> existSavedDeliveries(List<String> orderIdentifiers){

        List<TemporalDeliveryDTO> list = new ArrayList<TemporalDeliveryDTO>();

        Map<String, Boolean> deliveries = null;

        if(orderIdentifiers!=null && !orderIdentifiers.isEmpty()) {

            deliveries = new HashMap<String, Boolean>();

            List<DeliveryVO> l = deliveryRepository.getDeliveriesBySapOrdersId(orderIdentifiers);

            for(String sapId : orderIdentifiers) {
                deliveries.put(sapId, false);
                if(!l.isEmpty()) {
                    for(DeliveryVO d : l ) {
                        if(d.getOrderIdSap().equals(sapId)) {
                            deliveries.put(sapId, true);
                            break;
                        }
                    }
                }
            }
        }

        if(deliveries!=null) {
            Iterator it = deliveries.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Boolean> pairs = (Map.Entry)it.next();
                TemporalDeliveryDTO temp = new TemporalDeliveryDTO();
                temp.setSapOrderId(pairs.getKey());
                temp.setExistDeliveriesSaved(pairs.getValue());
                list.add(temp);
            }
        }

        return list;
    }

    @Override
    @Transactional
    public List<TemporalSavedDeliveryDTO> getSavedDeliveriesBySapOrderId(List<String> sapOrderIds){

        List<TemporalSavedDeliveryDTO> deliveries = new ArrayList<TemporalSavedDeliveryDTO>();

        if(null != sapOrderIds && !sapOrderIds.isEmpty()) {

            List<DeliveryVO> list = deliveryRepository.getDeliveriesBySapOrdersId(sapOrderIds);

            if(!list.isEmpty()) {
                deliveries = mapper.mapList(TemporalSavedDeliveryDTO.class,list);
            }
        }

        return deliveries;
    }

    @Override
    @Transactional(timeout = 300, propagation = Propagation.REQUIRED)
    public Boolean updateSavedDeliveries(List<TemporalSavedDeliveryDTO> deliveries) throws DeliveryNotFoundException, DeliveryProductNotFoundException {
        Boolean success = Boolean.FALSE;

        if(deliveries!=null && !deliveries.isEmpty()) {

            List<DeliveryVO> list = mapper.mapList(DeliveryVO.class,deliveries);

            for(DeliveryVO d : list) {
                if(d.getDeliveryId() == null) {
                    this.createDelivery(d);
                }else {
                    this.updateDelivery(d);
                }
            }

            success = Boolean.TRUE;
        }

        return success;
    }

    private void createDelivery(DeliveryVO d) throws DeliveryNotFoundException, DeliveryProductNotFoundException {

        if(d.getOrderIdSap() != null && !d.getOrderIdSap().trim().equals("") ) {

            // create new Delivery
            d.setCreateDate(new Timestamp(System.currentTimeMillis()));
            deliveryRepository.save(d);

            // save new Delivery Products
            this.addProductsToDelivery(d.getDeliveryProductsByDeliveryId(),d);

        } else {
            throw new IllegalArgumentException("The new Delivery not contains SAP Order Id");
        }

    }

    private void updateDelivery(DeliveryVO d) throws DeliveryNotFoundException, DeliveryProductNotFoundException {


        if(d.getOrderIdSap() != null && !d.getOrderIdSap().trim().equals("") ) {

            DeliveryVO delivery = deliveryRepository.findOne(d.getDeliveryId());

            if(delivery!=null) {

                delivery.setIdMdTransp(d.getIdMdTransp());
                delivery.setDeliveryDate(d.getDeliveryDate());
                delivery.setStatus(d.getStatus());
                delivery.setShipto(d.getShipto());
                delivery.setTimeDlv(d.getTimeDlv());

                deliveryRepository.save(delivery);

                // deleting the last DeliveryProducts.
                this.removeProductsFromDelivery(delivery.getDeliveryProductsByDeliveryId());

                // save new delivery products
                this.addProductsToDelivery(d.getDeliveryProductsByDeliveryId(),delivery);

            }else {
                throw new DeliveryNotFoundException(new Object[]{d.getDeliveryId()});
            }


        } else {
            throw new IllegalArgumentException("The Delivery "+ d.getDeliveryId() +" not contains SAP Order Id. Do not possible update.");
        }
    }

    private void removeProductsFromDelivery(Collection<DeliveryProductVO> products){
        if(products!=null && !products.isEmpty()) {
            deliveryProductRepository.delete(products);
            deliveryProductRepository.flush();
        }
    }

    private void addProductsToDelivery(Collection<DeliveryProductVO> products, DeliveryVO delivery) throws DeliveryProductNotFoundException {

        if(products!=null && !products.isEmpty()) {

             for(DeliveryProductVO p : products) {

                ProductVO product = this.getProductToAssign(p.getProductByProductCode());

                 if(product != null) {
                    p.setProductByProductCode(product);
                    p.setDeliveryByDeliveryId(delivery);
                 }else {
                     throw new DeliveryProductNotFoundException(new Object[]{delivery.getDeliveryId() == null ? "" : delivery.getDeliveryId()});
                 }

                 deliveryProductRepository.save(p);
             }
        }
    }

    private ProductVO getProductToAssign(ProductVO p) {

        ProductVO product = null;

        if(p!=null && p.getProductCode()!=null && !p.getProductCode().trim().equals("")) {
            product = productRepository.findByProductCode(p.getProductCode());
        }

        return product;
    }

    @Transactional(timeout = 300)
    public Boolean deleteDelivery(Long idDelivery) throws DeleteDeliveryNotFoundException {

        Boolean success = Boolean.FALSE;

        if(idDelivery!=null) {

            DeliveryVO delivery = deliveryRepository.findOne(idDelivery);

            if(delivery!=null) {
                deliveryRepository.delete(delivery);
                deliveryRepository.flush();
                success = Boolean.TRUE;
            }else{
                throw new DeleteDeliveryNotFoundException(new Object[]{idDelivery});
            }
        }

        return success;
    }

}