package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributionChannelService;
import com.monsanto.customerlink.core.service.exception.DistributionChannelNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.DistributionChannelVO;
import com.monsanto.customerlink.persistence.repositories.DistributionChannelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("distributionChannelBusiness")
public class DistributionChannelServiceImpl implements DistributionChannelService {

    @Autowired
    private DistributionChannelRepository distributionChannelRepository;

    /**
     * @see DistributionChannelService#retrieveDistributionChannel(String)
     */
    @Override
    public DistributionChannelVO retrieveDistributionChannel(final String distChCode) throws DistributionChannelNotFoundException {
        CustomerLinkUtils.isValidParameter(distChCode);
        final DistributionChannelVO distributionChannelVO = distributionChannelRepository.findByDistributionChannelCode(distChCode);
        if (null == distributionChannelVO) {
            throw new DistributionChannelNotFoundException(new Object[]{distChCode});
        }
        return distributionChannelVO;
    }

}
