package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.exception.DistributorNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service("distributorBusiness")
public class DistributorServiceImpl implements DistributorService {

    @Autowired
    private UserService userService;
    @Autowired
    private DistributorRepository distributorRepository;
    @Autowired
    private DistributorConfigRepository distributorConfigRepository;
    @Autowired
    private PrivateBrandDistributorRepository privateBrandDistributorRepository;

    @Autowired
    private DistributionChannelMappingRepository distChannelMappingRepository;

    @Autowired
    private Mapper mapper;

    /**
     * @throws IllegalArgumentException     if the distributorCode is null or is empty.
     * @throws DistributorNotFoundException if the distributor not be found
     * @see com.monsanto.customerlink.core.service.DistributorService#retrieveDistributor(String)
     */
    @Override
    @Transactional(timeout = 360)
    public DistributorDTO retrieveDistributor(final String distributorCode) throws DistributorNotFoundException {
        CustomerLinkUtils.isValidParameter(distributorCode);
        final DistributorVO distributorVO = distributorRepository.findByDistributorCode(distributorCode);
        if (null == distributorVO) {
            throw new DistributorNotFoundException(new Object[]{distributorCode});
        }
        final DistributorDTO distributorDTO = mapper.map(distributorVO, DistributorDTO.class);
        setIsBrandOwnDistributor(distributorDTO, distributorVO.getPrivateBrandDistributorsByDistributorCode());
        setIsConsignmentDistributor(distributorDTO, distributorVO.getDistributorProfilesByDistributorCode());
        setRepresentatives(distributorDTO.getConfig(),distributorCode);
        setListOfCsr(distributorDTO);
        setListOfApprovers(distributorDTO);
        return distributorDTO;
    }

    public DistributorProfileVO retrieveDistributorConfigByConfig(DistributorConfigDTO distributorConfigDTO) throws
            DistributorConfigNotFoundException {

        validateParameters(distributorConfigDTO);

        DistributorProfileVO distributorConfigVO = this.distributorConfigRepository.findByParameters(
                distributorConfigDTO.getSalesOrgCode(),
                distributorConfigDTO.getDistChCode(), distributorConfigDTO.getSalesDivCode(),
                distributorConfigDTO.getSubRegionCode(), distributorConfigDTO.getDistributor().getDistributorCode()
        );
        // Change to support interchange of Distribution Channels
        if(distributorConfigVO == null) {
            distributorConfigVO = searchDistributorProfileMappedByDistributionChannel(distributorConfigDTO);
        }

        if (distributorConfigVO == null) {
            throw new DistributorConfigNotFoundException(new Object[]{distributorConfigDTO.getDistributor().getDistributorCode(),
            distributorConfigDTO.getSalesOrgCode(), distributorConfigDTO.getSubRegionCode(),
            distributorConfigDTO.getSalesDivCode(),  distributorConfigDTO.getDistChCode()});
        }

        return distributorConfigVO;
    }


    private void validateParameters(DistributorConfigDTO distributorConfigDTO) {

        if (distributorConfigDTO.getSalesOrgCode() == null
                || distributorConfigDTO.getDistChCode() == null
                || distributorConfigDTO.getSalesDivCode() == null
                || distributorConfigDTO.getSubRegionCode() == null
                || distributorConfigDTO.getDistributor() == null
                || distributorConfigDTO.getDistributor().getDistributorCode() == null
                ) {

            throw new IllegalArgumentException();
        }
    }


    @Override
    public boolean verifyIsPrivateBrandDistributor(String distributorCode) {

        List<PrivateBrandDistributorVO> privateBrandDistributorVOList = privateBrandDistributorRepository.findByDistributorCode(distributorCode);
        if (privateBrandDistributorVOList.isEmpty()) {
            return false;
        }
        return true;
    }

    private void setIsBrandOwnDistributor(DistributorDTO distributorDTO, Collection<PrivateBrandDistributorVO> privateBrandDistributorVOs) {
        if (!privateBrandDistributorVOs.isEmpty()) {
            distributorDTO.setBrandOwn(Boolean.TRUE);
        }
    }

    private void setIsConsignmentDistributor(DistributorDTO distributorDTO, Collection<DistributorProfileVO> distributorProfileVOs) {
        DistributorProfileVO distributorProfileVO = (DistributorProfileVO) CollectionUtils.find(distributorProfileVOs, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                DistributorProfileVO distributorProfileVO = (DistributorProfileVO) o;
                return (StringUtils.equals(distributorProfileVO.getDistributionChannelCode(),
                        CustomerLinkCoreConstants.CONSIGNMENT_DIST_CHANNEL) &&
                        StringUtils.equals(distributorProfileVO.getSalesDivisionCode(),
                                CustomerLinkCoreConstants.AGROCHEMICAL_SALES_DIV));
            }
        });
        if (null != distributorProfileVO) {
            distributorDTO.setConsignment(Boolean.TRUE);
        }
    }

    private void setRepresentatives(List<DistributorConfigDTO> distributorProfiles,String distributorCode) {
        for (DistributorConfigDTO distributorProfile : distributorProfiles) {
            DistributorDTO distributorDTO = new DistributorDTO();
            distributorDTO.setDistributorCode(distributorCode);
            distributorProfile.setDistributor(distributorDTO);
            List<UserVO> representatives = userService.retrieveRCDs(distributorProfile);
            distributorProfile.setRepresentatives(mapper.mapList(RepresentativeDTO.class, representatives));
        }
    }

    private void setListOfCsr(DistributorDTO distributorDTO) {
        List<UserVO> csrs = userService.retrieveUsersByDistributorAndRole(distributorDTO.getDistributorCode(),RoleEnum.CSR);
        distributorDTO.setCsr(mapper.mapList(RepresentativeDTO.class, csrs));
    }

    private void setListOfApprovers(DistributorDTO distributorDTO) {
        List<UserVO> approvers = userService.retrieveUsersByDistributorAndRole(distributorDTO.getDistributorCode(), RoleEnum.APPROVER);
        CollectionUtils.forAllDo(approvers,new Closure() {
            @Override
            public void execute(Object input) {
                ((UserVO)input).setRepresentativeName(RoleEnum.APPROVER.getCode());
            }
        });
        distributorDTO.getCsr().addAll(mapper.mapList(RepresentativeDTO.class, approvers));
    }

    public DistributorProfileVO searchDistributorProfileMappedByDistributionChannel(DistributorConfigDTO distributorConfigDTO) {
        DistributorProfileVO vo = null;
        Collection<DistributionChannelMappingVO> mappings = distChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(distributorConfigDTO.getDistChCode());
        if(CollectionUtils.isNotEmpty(mappings)) {
            for(DistributionChannelMappingVO mapping : mappings) {
                vo = this.distributorConfigRepository.findByParameters(
                        distributorConfigDTO.getSalesOrgCode(),
                        mapping.getClCode(), distributorConfigDTO.getSalesDivCode(),
                        distributorConfigDTO.getSubRegionCode(), distributorConfigDTO.getDistributor().getDistributorCode()
                );
                if(vo != null) {
                    break;
                }
            }
        }
        return vo;
    }
}