package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmailRecoveryServiceImpl implements EmailRecoveryService{


    private DistributorRepository distributorRepository;
    private UserManagementService userManagementService;
    private DistributorService distributorService;

    @Autowired
    public EmailRecoveryServiceImpl(DistributorRepository distributorRepository,
                                    UserManagementService userManagementService,
                                    DistributorService distributorService) {
        this.distributorRepository = distributorRepository;
        this.userManagementService = userManagementService;
        this.distributorService = distributorService;

    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.EmailRecoveryService#retrieveByDistributor(String)
     */
    public String retrieveByDistributor(String distributorCode) {

        String email = StringUtils.EMPTY;

        if( StringUtils.isNotEmpty(distributorCode)) {

            DistributorVO d = distributorRepository.findOne(distributorCode);

            if(d!=null) {
                email = d.getEmail();
            }
        }

        return email;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.EmailRecoveryService#retrieveEmailByRoleAndDistributorConfig(java.util.List, com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO)
     */
    public List<String> retrieveEmailByRoleAndDistributorConfig(List<String> roles, DistributorConfigDTO config) {

        List<String> emails = new ArrayList<String>();

        if( roles!=null && !roles.isEmpty() && config!=null && config.getDistributor()!=null) {

            removeAndObtainDistributorEmail(emails,roles,config);

            DistributorProfileVO distributorProfileVO = null;

            try {
                distributorProfileVO = distributorService.retrieveDistributorConfigByConfig(config);
            } catch (DistributorConfigNotFoundException e) {
                e.printStackTrace();
            }

            if(distributorProfileVO!=null) {

                List<UserVO> listOfUsers = userManagementService.getListOfUserByDistributorProfileId(distributorProfileVO.getDistributorProfileId());

                if(!listOfUsers.isEmpty()) {
                    emails = extractEmails(emails, listOfUsers, roles);
                }
            }
        }

        return emails;
    }

    private List<String> extractEmails(List<String> emails, List<UserVO> listOfUsers, List<String> roles) {

        for(String role : roles) {
            for(UserVO user : listOfUsers) {
                if(user.getRoleVO().getCode().equals(role)) {
                    emails.add(user.getEmail());
                }
            }
        }

        return emails;
    }

    private void removeAndObtainDistributorEmail(List<String> emails, List<String> roles, DistributorConfigDTO config ) {

        List<String> distributors = new ArrayList<String>();

        for(String role : roles) {
            if(role.toUpperCase().equals(RoleEnum.DISTRIBUTOR.getCode())) {
                distributors.add(role);
            }
        }

        if(!distributors.isEmpty()) {

            roles.removeAll(distributors);

            String distributorEmail = retrieveByDistributor(config.getDistributor().getDistributorCode());

            if(StringUtils.isNotEmpty(distributorEmail)) {
                emails.add(distributorEmail);
            }
        }
    }
}