package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.FiscalYearService;
import com.monsanto.customerlink.core.service.exception.FiscalYearNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.persistence.repositories.FiscalYearRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("fiscalYearBusiness")
public class FiscalYearServiceImpl implements FiscalYearService {

    @Autowired
    private FiscalYearRepository fiscalYearRepository;

    /**
     * @see FiscalYearService#retrieveActiveFiscalYear(Date)
     */
    @Override
    public FiscalYearVO retrieveActiveFiscalYear(final Date date) throws FiscalYearNotFoundException {
        CustomerLinkUtils.isValidParameter(date);
        final FiscalYearVO fiscalYearVO = fiscalYearRepository.findActiveFiscalYear(date);
        if (null == fiscalYearVO) {
            throw new FiscalYearNotFoundException(new Object[]{CustomerLinkUtils.SDF_DDMMYYYY.format(date)});
        }
        return fiscalYearVO;
    }

    /**
     * @see FiscalYearService#retrieveSearchPeriod()
     */
    @Override
    public SearchPeriodDTO retrieveSearchPeriod() throws FiscalYearNotFoundException {
        FiscalYearVO fiscalYearVO = retrieveActiveFiscalYear(new Date());
        final SearchPeriodDTO searchPeriodDTO = new SearchPeriodDTO();
        searchPeriodDTO.setStartDate(CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(fiscalYearVO.getStartDate()));
        searchPeriodDTO.setEndDate(CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(fiscalYearVO.getEndDate()));
        return searchPeriodDTO;
    }
}
