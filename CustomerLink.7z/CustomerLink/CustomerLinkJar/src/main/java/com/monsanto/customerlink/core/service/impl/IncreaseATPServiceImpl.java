package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.InventoryFacade;
import com.monsanto.customerlink.core.service.facade.ValidateSkuPricesFacade;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class IncreaseATPServiceImpl implements IncreaseATPService {

    private Mapper mapper;
    private InventoryFacade inventoryFacade;
    private ValidateSkuPricesFacade validateSkuPricesFacade;
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;
    private InventoryHelper inventoryHelper;
    private InventoryIncreaseHelper inventoryIncreaseHelper;

    @Autowired
    public IncreaseATPServiceImpl(IncreaseDecreaseATPHelper increaseDecreaseATPHelper,
                                  ValidateSkuPricesFacade validateSkuPricesFacade,  InventoryFacade inventoryFacade,
                                  Mapper mapper, InventoryHelper inventoryHelper,
                                  InventoryIncreaseHelper inventoryIncreaseHelper) {
        this.mapper = mapper;
        this.inventoryFacade = inventoryFacade;
        this.validateSkuPricesFacade = validateSkuPricesFacade;
        this.increaseDecreaseATPHelper = increaseDecreaseATPHelper;
        this.inventoryHelper = inventoryHelper;
        this.inventoryIncreaseHelper = inventoryIncreaseHelper;
    }

    /**
     * If there is a list of hybrids to increase, the system is chosen the way to go depending on whether it is
     * "Corn-Sorghum" or "Cotton-Soybean"
     *
     * @param sapOrder
     * @param atpOrder
     */
    public void increaseATPProcess(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isIncreasePerNewHybrids) throws CustomerLinkBusinessException {

        increaseDecreaseATPHelper.validateInputParameters(atpOrder);

        if (!isIncreasePerNewHybrids) {
            atpOrder.setDetail(increaseDecreaseATPHelper.obtainHybridsToIncreaseOrDecrease(sapOrder, atpOrder, true));
        }

        // again performs validation, because it may not contain hybrids after obtain hybrids to increase decrease
        if (increaseDecreaseATPHelper.existHybridsToProcess(atpOrder)) {

            // validations performed prices and skus. Order will only be processed if there is a list of hybrids
            atpOrder = validateSkuPricesFacade.validateSkuPrices(atpOrder);

            // again performs validation, because it may not contain hybrids after sku validation
            if (increaseDecreaseATPHelper.existHybridsToProcess(atpOrder)) {

                if (atpOrder.getDistributorConfigDTO().getSalesOrgCode().equals(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode())) {

                    postOrderToEccSeeds(sapOrder, atpOrder, true); // init post order ecc process with Algorithm

                } else if (atpOrder.getDistributorConfigDTO().getSalesOrgCode().equals(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode())) {

                    postOrderToEccSeeds(sapOrder, atpOrder, false); // init post order ecc process without Algorithm
                }
            }
        }
    }

    private void postOrderToEccSeeds(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isCornOrSorghum) throws CustomerLinkBusinessException {

        List<InventoryInDTO> inventoryListInput = inventoryHelper.createRequestInventory(atpOrder.getDetail(), atpOrder.getDistributorConfigDTO());
        Map<String, List<?>> inventoryListOutPut = inventoryFacade.getInventory(inventoryListInput);
        boolean noInventoryAvailable = true;

        List<InventoryWithOutAlgorithmDTO> inventoryWithOutAlgorithm;
        List<InventoryWithAlgorithmDTO> inventoryWithAlgorithm;

        List<ErrorOrderDTO> errorOrderDTOs = new ArrayList<ErrorOrderDTO>();

        if (inventoryListOutPut.containsKey(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR)) {
            errorOrderDTOs = (List<ErrorOrderDTO>) inventoryListOutPut.get(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR);
        }

        if (isCornOrSorghum) {

            if (inventoryListOutPut.containsKey(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM)) {

                inventoryWithAlgorithm = (List<InventoryWithAlgorithmDTO>) inventoryListOutPut.get(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM);

                if (!inventoryWithAlgorithm.isEmpty()) {
                    noInventoryAvailable = false;
                    inventoryIncreaseHelper.assignInventoryCornOrSorghum(sapOrder, atpOrder, inventoryWithAlgorithm, errorOrderDTOs);
                }
            }

        } else {

            if (inventoryListOutPut.containsKey(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM)) {

                inventoryWithOutAlgorithm = (List<InventoryWithOutAlgorithmDTO>) inventoryListOutPut.get(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM);

                if (!inventoryWithOutAlgorithm.isEmpty()) {
                    noInventoryAvailable = false;
                    inventoryIncreaseHelper.assignInventoryCottonOrSoybean(sapOrder, atpOrder, inventoryWithOutAlgorithm, errorOrderDTOs);
                }
            }
        }

        if (noInventoryAvailable) {

            if (isCornOrSorghum) {
                inventoryHelper.sendNotification(null, inventoryListInput
                        , atpOrder.getDetail(),
                        errorOrderDTOs, InventoryUtil.getMinimumMX20NotificationType(), atpOrder.getDistributorConfigDTO());
            } else {
                inventoryHelper.sendNotification(null, inventoryListInput, atpOrder.getDetail(),
                        errorOrderDTOs, InventoryUtil.getMinimumMX01NotificationType(), atpOrder.getDistributorConfigDTO());
            }
        }
    }

    public OrderDTO excludesAndProcessNewHybrids(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws CustomerLinkBusinessException {

        increaseDecreaseATPHelper.validateInputParameters(sapOrder, atpOrder);

        // hybrids grouped (SAP ORDER)
        Map<String, List<MaterialDTO>> groupByHybrid = increaseDecreaseATPHelper.groupByHybrid(sapOrder.getHybrids());

        if (!groupByHybrid.isEmpty()) {
            // eliminates new hybrids, processes and returns the order without them
            atpOrder = validatesExistenceOfNewHybrids(sapOrder, atpOrder, groupByHybrid);
        }

        return atpOrder;
    }

    private OrderDTO validatesExistenceOfNewHybrids(SAPOrderDTO sapOrder, OrderDTO atpOrder, Map<String, List<MaterialDTO>> groupByHybrid) throws CustomerLinkBusinessException {

        List<OrderDetailDTO> listOfNewHybrid = new ArrayList<OrderDetailDTO>();

        for (OrderDetailDTO detail : atpOrder.getDetail()) {

            // valid if the received hybrid not exist in sap order
            if (!groupByHybrid.containsKey(detail.getProductDTO().getProductCode())) {
                listOfNewHybrid.add(detail);
            }

        }

        if (!listOfNewHybrid.isEmpty()) {

            // creates copy of orderAtp
            OrderDTO atpOrderWithNewHybrids = mapper.map(atpOrder, OrderDTO.class);

            // allocation of new hybrids
            atpOrderWithNewHybrids.setDetail(listOfNewHybrid);

            // new hybrids eliminates the original order atp
            atpOrder.getDetail().removeAll(listOfNewHybrid);

            // starts the process to include the new Hybrids in existing sap order
            this.increaseATPProcess(sapOrder, atpOrderWithNewHybrids, true);
        }

        return atpOrder;
    }

}