package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.IncreaseDecreaseATPHelper;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.SapOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IncreaseDecreaseATPHelperImpl implements IncreaseDecreaseATPHelper {

    @Override
    public List<OrderDetailDTO> obtainHybridsToIncreaseOrDecrease(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean obtainHybridsIncrease) throws AtpOrderMissingArgumentsException {

        List<OrderDetailDTO> listOfHybrid = atpOrder.getDetail();

        // if sap order is null, then order atp creates a new order
        if (sapOrder != null) {

            if (!sapOrder.getHybrids().isEmpty()) {

                // again performs validation, because it may not contain hybrids after excludes new hybrids
                if (existHybridsToProcess(atpOrder)) {

                    List<OrderDetailDTO> hybridsIncreased = new ArrayList<OrderDetailDTO>();
                    List<OrderDetailDTO> hybridsDecreased = new ArrayList<OrderDetailDTO>();

                    if (null == sapOrder.getWithoutSoakTestOrder()) {
                        for (OrderDetailDTO detail : atpOrder.getDetail()) {
                            String hybridCode = detail.getProductDTO().getProductCode();
                            HybridDTO sapHybridNormalSeason = findHybridInSAPOrder(sapOrder.getHybrids(), hybridCode);
                            increaseOrDecrease(sapHybridNormalSeason.getTotalQty(), detail, hybridsIncreased, hybridsDecreased);
                        }
                    } else {
                        for (OrderDetailDTO detail : atpOrder.getDetail()) {
                            String hybridCode = detail.getProductDTO().getProductCode();
                            increaseOrDecrease(accumulateSAPHybridTotalQty(sapOrder, hybridCode), detail, hybridsIncreased, hybridsDecreased);
                        }
                    }

                    listOfHybrid = obtainHybridsIncrease ? hybridsIncreased : hybridsDecreased;
                }
            }
        }

        return listOfHybrid;
    }

    /**
     * To obtain a list of sku grouped by hybrid
     *
     * @param listOfHybrid
     * @return
     */
    public Map<String, List<MaterialDTO>> groupByHybrid(List<HybridDTO> listOfHybrid) {

        Map<String, List<MaterialDTO>> group = new HashMap<String, List<MaterialDTO>>();

        if (listOfHybrid != null && !listOfHybrid.isEmpty()) {

            for (HybridDTO item : listOfHybrid) {

                if (StringUtils.isNotEmpty(item.getHybridCode())) {  // ##### se cambio item.getHybrid por item.getHybridCode()
                    group.put(item.getHybridCode(), item.getSkus());//Validated inside getSkus method
                }
            }
        }

        return group;
    }

    /**
     * Validates the amount obtained as the sum of the list-linked SKU hybrid versus the amount recovered to the same
     * hybrid in the new ATP if an increase adds it to the list "hybridsIncreased" with the key "Hybrid", "Quantity"
     * if decreased adds it to the list "hybridsDecreased" with the key "Hybrid", "Quantity"
     *
     * @param summation
     * @param detail
     * @param hybridsIncreased
     * @param hybridsDecreased
     */
    private void increaseOrDecrease(double summation, OrderDetailDTO detail, List<OrderDetailDTO> hybridsIncreased, List<OrderDetailDTO> hybridsDecreased) {

        double hybridQuantity = detail.getQuantity();

        if (summation > hybridQuantity) {

            // is decrease ATP, adds to map
            detail.setQuantity(summation - hybridQuantity);
            hybridsDecreased.add(detail);
        } else if (summation < hybridQuantity) {

            // is increase ATP, adds to map
            detail.setQuantity(hybridQuantity - summation);
            hybridsIncreased.add(detail);
        }
    }

    public boolean existHybridsToProcess(OrderDTO orderDTO) {
        return !orderDTO.getDetail().isEmpty();
    }

    /**
     * Validate the input parameters
     *
     * @param atpOrder
     * @return
     */
    public void validateInputParameters(OrderDTO atpOrder) throws AtpOrderMissingArgumentsException {

        if(atpOrder == null) {
            throw new AtpOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(atpOrder)});
        }

        if(atpOrder.getDetail().isEmpty()) {
            throw new AtpOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(atpOrder)});
        }

        if(atpOrder.getDistributorConfigDTO() == null) {
            throw new AtpOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(atpOrder)});
        }

    }

    /**
     * Validate the input parameters
     *
     * @param atpOrder
     * @return
     */
    public void validateInputParameters(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws SapOrderMissingArgumentsException, AtpOrderMissingArgumentsException {

        if(sapOrder == null) {
            throw new SapOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(sapOrder), ToStringBuilder.reflectionToString(atpOrder)});
        }

        if(sapOrder.getHybrids().isEmpty()) {
            throw new SapOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(sapOrder), ToStringBuilder.reflectionToString(atpOrder)});
        }

        validateInputParameters(atpOrder);
    }

    private double accumulateSAPHybridTotalQty(SAPOrderDTO sapOrder, String atpHybrid) {
        HybridDTO normalSeasonHybrid = findHybridInSAPOrder(sapOrder.getHybrids(), atpHybrid);
        HybridDTO withoutSoakTestHybrid = findHybridInSAPOrder(sapOrder.getWithoutSoakTestOrder().getHybrids(), atpHybrid);
        return ((null == normalSeasonHybrid) ? 0 : normalSeasonHybrid.getTotalQty()) +
                ((null == withoutSoakTestHybrid) ? 0 : withoutSoakTestHybrid.getTotalQty());
    }

    private HybridDTO findHybridInSAPOrder(List<HybridDTO> hybridDTOList, final String hybridCode) {
        return (HybridDTO) CollectionUtils.find(hybridDTOList, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                HybridDTO hybrid = (HybridDTO) o;
                return StringUtils.equals(hybridCode, hybrid.getHybridCode());
            }
        });
    }
}