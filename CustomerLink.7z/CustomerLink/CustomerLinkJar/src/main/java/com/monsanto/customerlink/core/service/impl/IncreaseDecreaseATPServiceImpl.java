package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IncreaseDecreaseATPServiceImpl implements IncreaseDecreaseATPService {

    private Mapper mapper;
    private SAPOrderService sapOrderService;
    private IncreaseATPService increaseATPService;
    private DecreaseATPService decreaseATPService;
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;

    @Autowired
    public IncreaseDecreaseATPServiceImpl(IncreaseATPService increaseATPService, DecreaseATPService decreaseATPService,
                                          SAPOrderService sapOrderService, Mapper mapper, IncreaseDecreaseATPHelper increaseDecreaseATPHelper) {
        this.mapper = mapper;
        this.decreaseATPService = decreaseATPService;
        this.increaseATPService = increaseATPService;
        this.sapOrderService = sapOrderService;
        this.increaseDecreaseATPHelper = increaseDecreaseATPHelper;
    }

    public void runProcessChangeInATP(OrderDTO atpOrder) throws CustomerLinkBusinessException {

        increaseDecreaseATPHelper.validateInputParameters(atpOrder);

        SAPOrderDTO sapOrder = sapOrderService.retrieveOrder(atpOrder);

        if(sapOrder == null) {

            // process is invoked to increase atp for new product with a null value Sap order
            increaseATPService.increaseATPProcess(sapOrder, atpOrder, true);

        }else {

            // the new hybrids are removed and processed separately.
            atpOrder = increaseATPService.excludesAndProcessNewHybrids(sapOrder, atpOrder);

            // again performs validation, because it may not contain hybrids after "excludesAndProcessNewHybrids"
            if( increaseDecreaseATPHelper.existHybridsToProcess(atpOrder) ) {
                // runs the process due to a change in ATP by increasing or decreasing
                runProcessDecreasedIncreaseAtp(sapOrder, atpOrder);
            }
        }

    }

    private void  runProcessDecreasedIncreaseAtp(SAPOrderDTO sapOrder, OrderDTO atpOrder) throws AtpOrderMissingArgumentsException, CustomerLinkBusinessException{

         // creates a copy of the object order atp
        OrderDTO atpOrderCopy = mapper.map(atpOrder, OrderDTO.class);

        // invoke increase ATP process. executes only If exist hybrids with increase
        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        // invoke decrease ATP process. executes only If exist hybrids with decrease
        decreaseATPService.decreaseATPProcess(sapOrder, atpOrderCopy);
    }

}