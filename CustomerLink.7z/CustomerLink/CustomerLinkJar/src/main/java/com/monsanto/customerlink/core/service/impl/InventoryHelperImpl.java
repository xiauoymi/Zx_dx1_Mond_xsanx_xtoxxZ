package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.email.dto.messages.HybridMessageVO;
import com.monsanto.customerlink.core.email.dto.messages.MissingInventoryMessageVO;
import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.InventoryHelper;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class InventoryHelperImpl implements InventoryHelper{

    private CropService cropService;
    private PlantService plantService;
    private MailUtilService mailUtilService;
    private NotificationSender mailNotificationSender;

    @Autowired
    public InventoryHelperImpl(CropService cropService, PlantService plantService,
                               MailUtilService mailUtilService,
                               NotificationSender mailNotificationSender) {
        this.cropService = cropService;
        this.plantService = plantService;
        this.mailNotificationSender = mailNotificationSender;
        this.mailUtilService = mailUtilService;
    }

    public List<InventoryInDTO> createRequestInventory(List<OrderDetailDTO> hybridsIncreased, DistributorConfigDTO distributorConfigDTO) {

        List<InventoryInDTO> inventoryList = new ArrayList<InventoryInDTO>();

        CropVO cottonConfig = cropService.obtainCropByCode(SeedsCropCodeEnum.COTTON.getCode());
        CropVO soybeanConfig = cropService.obtainCropByCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        CropVO cornConfig = cropService.obtainCropByCode(SeedsCropCodeEnum.CORN.getCode());
        CropVO sorghumConfig = cropService.obtainCropByCode(SeedsCropCodeEnum.SORGHUM.getCode());

        List<OrderDetailDTO> cottonHybrids = new ArrayList<OrderDetailDTO>();
        List<OrderDetailDTO> soybeanHybrids = new ArrayList<OrderDetailDTO>();
        List<OrderDetailDTO> cornHybrids = new ArrayList<OrderDetailDTO>();
        List<OrderDetailDTO> sorghumHybrids = new ArrayList<OrderDetailDTO>();

        for (OrderDetailDTO detail : hybridsIncreased) {

            if (detail.getProductDTO().getSubDivisionCode().equals(SeedsCropCodeEnum.COTTON.getCode())) {
                cottonHybrids.add(detail);
            }

            if (detail.getProductDTO().getSubDivisionCode().equals(SeedsCropCodeEnum.SOYBEAN.getCode())) {
                soybeanHybrids.add(detail);
            }

            if (detail.getProductDTO().getSubDivisionCode().equals(SeedsCropCodeEnum.CORN.getCode())) {
                cornHybrids.add(detail);
            }

            if (detail.getProductDTO().getSubDivisionCode().equals(SeedsCropCodeEnum.SORGHUM.getCode())) {
                sorghumHybrids.add(detail);
            }
        }

        if (!cottonHybrids.isEmpty()) {
            inventoryList.addAll(appendHybridList(cottonHybrids, cottonConfig, distributorConfigDTO));
        }

        if (!soybeanHybrids.isEmpty()) {
            inventoryList.addAll(appendHybridList(soybeanHybrids, soybeanConfig, distributorConfigDTO));
        }

        if (!cornHybrids.isEmpty()) {
            inventoryList.addAll(appendHybridList(cornHybrids, cornConfig, distributorConfigDTO));
        }

        if (!sorghumHybrids.isEmpty()) {
            inventoryList.addAll(appendHybridList(sorghumHybrids, sorghumConfig, distributorConfigDTO));
        }

        return inventoryList;
    }

    private List<InventoryInDTO> appendHybridList(List<OrderDetailDTO> hybrids, CropVO cropConfig, DistributorConfigDTO distributorConfigDTO) {

        //also  consulting region for cotton
        String salesOrg = distributorConfigDTO.getSalesOrgCode();
        String salesDist = distributorConfigDTO.getSubRegionCode();
        String altUom = CustomerLinkCoreConstants.ALTUOM;

        List<InventoryInDTO> inventoryList = new ArrayList<InventoryInDTO>();

        // retrieve list of plants to cropConfig
        List<PlantVO> plantList = plantService.obtainPlantsAccordingToCrop(cropConfig, distributorConfigDTO);

        for (OrderDetailDTO detail : hybrids) {

            String hybrid = detail.getProductDTO().getProductCode();
            String acronym = detail.getProductDTO().getFamilyCode();
            String spTreatment = detail.getProductDTO().getTreatmentCode();
            InventoryInDTO i = new InventoryInDTO(hybrid, salesOrg, salesDist, altUom, configSpecieToSpecie(cropConfig),acronym,spTreatment);

            if (!plantList.isEmpty()) {

                List<PlantWareHouseDTO> plantsWarehouses = new ArrayList<PlantWareHouseDTO>();

                for (PlantVO plant : plantList) {
                    if (!plant.getWarehousesByPlantId().isEmpty()) {
                        for (WarehouseVO w : plant.getWarehousesByPlantId()) {
                            plantsWarehouses.add(new PlantWareHouseDTO(plant.getPlantCode(), w.getWarehouseCode()));
                        }
                    }
                }

                i.setPlantWarehouses(plantsWarehouses);
            }

            inventoryList.add(i);
        }

        return inventoryList;
    }

    private SpecieDTO configSpecieToSpecie(CropVO config) {
        SpecieDTO specie = new SpecieDTO();
        specie.setSpeciecode(config.getSpecieCode());
        specie.setSpecieclass(config.getSpecieClass());
        specie.setClasstype(config.getSpecieType());
        String algorithm = config.getSpecieAlg() ? SeedsSapAlgorithm.WITH.getCode() : SeedsSapAlgorithm.WITHOUT.getCode();
        specie.setAlg(algorithm);
        return specie;
    }

    public void sendNotification(SAPOrderDTO sapOrder, List<InventoryInDTO> inventoryListConfig,
                                  List<OrderDetailDTO> details,
                                  List<ErrorOrderDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorProfile) {

        Map<String, Object> parameters = buildObjectMessageNotification(inventoryListConfig, details, distributorProfile,
                listError);

        if (sapOrder != null) {
            parameters.put("sapOrder", sapOrder);
        }
        sendMessage(type, distributorProfile, parameters);
    }

     protected Map<String, Object> buildObjectMessageNotification(List<InventoryInDTO> inventoryListConfig,
                                                                 List<OrderDetailDTO> details,
                                                                 DistributorConfigDTO distributorConfigDTO,
                                                                 List<ErrorOrderDTO> listError) {
        Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, listError);


        MissingInventoryMessageVO msg = new MissingInventoryMessageVO();

        List<HybridMessageVO> hybrids = new ArrayList<HybridMessageVO>();

        for (OrderDetailDTO d : details) {
            for (InventoryInDTO i : inventoryListConfig) {
                if (i.getHybrid().equals(d.getProductDTO().getProductCode())) {
                    HybridMessageVO h = new HybridMessageVO();
                    h.setCode(CustomerLinkUtils.getHybridName(d.getProductDTO()));
                    h.setQuantity(String.valueOf(d.getQuantity()));
                    hybrids.add(h);
                }
            }
        }

        msg.setHybrids(hybrids);

        parameters.put("msg", msg);

        return parameters;
    }

    public void sendNotificationOfInsufficientInventory(List<OrderDetailDTO> details, DistributorConfigDTO distributorConfigDTO,
                                                         boolean isCornOrSorghum, List<ErrorOrderDTO> errors) {

        if (!details.isEmpty()) {

            List<InventoryInDTO> inventoryListConfig = this.createRequestInventory(details, distributorConfigDTO);

            if (!inventoryListConfig.isEmpty()) {

                if (isCornOrSorghum) {
                    sendNotification(null, inventoryListConfig, details, errors, InventoryUtil.getMissingMX20NotificationType(), distributorConfigDTO);

                } else {
                    sendNotification(null, inventoryListConfig, details, errors, InventoryUtil.getMissingMX01NotificationType(), distributorConfigDTO);
                }
            }
        }
    }

    public void sendNotification(List<SAPOrderErrorDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorProfile) {

        Map<String, Object> parameters = buildObjectMessageNotification(
                new ArrayList<InventoryInDTO>(), new ArrayList<OrderDetailDTO>(), distributorProfile, null);

        if (!listError.isEmpty()) {
            parameters.put("errors", listError);
        }
        sendMessage(type, distributorProfile, parameters);
    }

    public void sendMessage(NotificationType type, DistributorConfigDTO distributorProfile, Map<String, Object> parameters) {
        mailNotificationSender.send(type.newNotification(distributorProfile, parameters));
    }

}