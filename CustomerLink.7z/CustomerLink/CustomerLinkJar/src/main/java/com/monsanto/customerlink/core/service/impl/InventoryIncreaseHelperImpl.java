package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class InventoryIncreaseHelperImpl implements InventoryIncreaseHelper {

    private Mapper mapper;
    private InventoryHelper inventoryHelper;
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;
    private SAPOrderService sapOrderService;
    private InventoryPlantPriorityHelper inventoryPlantPriorityHelper;

    @Autowired
    public InventoryIncreaseHelperImpl(Mapper mapper, InventoryHelper inventoryHelper,
                                       IncreaseDecreaseATPHelper increaseDecreaseATPHelper,
                                       SAPOrderService sapOrderService,
                                       InventoryPlantPriorityHelper inventoryPlantPriorityHelper) {
        this.mapper = mapper;
        this.inventoryHelper = inventoryHelper;
        this.increaseDecreaseATPHelper = increaseDecreaseATPHelper;
        this.sapOrderService = sapOrderService;
        this.inventoryPlantPriorityHelper = inventoryPlantPriorityHelper;
    }

    public void assignInventoryCornOrSorghum(SAPOrderDTO sapOrder, OrderDTO atpOrder, List<InventoryWithAlgorithmDTO> inventory,
                                              List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException {

        for (OrderDetailDTO detail : atpOrder.getDetail()) {
            inventoryPlantPriorityHelper.assignPlantPriorityPerHybridCornOrSorghum(detail,atpOrder.getDistributorConfigDTO(),inventory);
            this.assignHybridInventoryCornOrSorghum(detail, inventory);
        }

        // remove details without inventory and invokes method to save or update sap order
        this.removeDetailsWithoutInventory(sapOrder, atpOrder, true, errors);
    }

    private void assignHybridInventoryCornOrSorghum(OrderDetailDTO detail, List<InventoryWithAlgorithmDTO> inventory) {

        List<PlantWithAlgorithmDTO> plantsToAllocate = new ArrayList<PlantWithAlgorithmDTO>();

        InventoryWithAlgorithmDTO inv = getInventoryPerHybridCornOrSorghum(detail.getProductDTO().getProductCode(), inventory);

        if (inv != null) {

            // initially tries to perform the complete assignment for each of the plant that are sorted from highest to lowest priority
            Double quantity = allocateTotalInventoryInPlantWithMoreInventoryAvailable(detail,inv,plantsToAllocate);

            // valid if it was possible to assign all inventory on one PLANT
            if(quantity.doubleValue()>0) {

                // the allocation of inventory is done with plants ordered high to low inventory
                quantity = assignInventoryInMultiplePlants(inv,quantity,plantsToAllocate);
            }

            // valid if it was possible to make the entire assignment in inventory
            if (quantity.doubleValue() == 0) {

                // assignment is performed with quantity and plant
                detail.getProductDTO().setListOfPlants(mapper.mapList(PlantDTO.class, plantsToAllocate));

                for (PlantDTO p : detail.getProductDTO().getListOfPlants()) {
                    // is assigned the status "Insert"
                    p.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
                }
            }
        }
    }

    public Double assignInventoryInMultiplePlants(InventoryWithAlgorithmDTO inv, Double quantity, List<PlantWithAlgorithmDTO> plantsToAllocate) {

        // ascending sort by quantity
        Collections.sort(inv.getPlants(), new Comparator<PlantWithAlgorithmDTO>() {
            @Override
            public int compare(PlantWithAlgorithmDTO o1, PlantWithAlgorithmDTO o2) {
                return  o1.getUnrestqty().compareTo(o2.getUnrestqty());
            }
        });

        // descending sort by quantity (the plant which have the most quantity of stock)
        Collections.reverse(inv.getPlants());

        for (PlantWithAlgorithmDTO p : inv.getPlants()) {

            if (quantity == 0) {
                break;
            }

            quantity = assignAvailableStockInPlant(quantity,p,plantsToAllocate);
        }

        return quantity;
    }

    public Double assignAvailableStockInPlant(Double quantity, PlantWithAlgorithmDTO p, List<PlantWithAlgorithmDTO> plantsToAllocate) {

        Double difference = quantity.doubleValue() - p.getUnrestqty().doubleValue();

        if (difference <= 0) {
            // assigns the entire available inventory of the hybrid
            plantsToAllocate.add(mapper.map(p, PlantWithAlgorithmDTO.class));
            quantity = 0D;
        } else {
            // is assigned only the amount of missing
            PlantWithAlgorithmDTO plant = mapper.map(p, PlantWithAlgorithmDTO.class);
            plant.setUnrestqty(BigDecimal.valueOf(quantity));
            plantsToAllocate.add(plant);
            quantity = difference;
        }

        return quantity;
    }

    public Double allocateTotalInventoryInPlantWithMoreInventoryAvailable(OrderDetailDTO detail,InventoryWithAlgorithmDTO inv, List<PlantWithAlgorithmDTO> plantsToAllocate) {

        Double quantity = detail.getQuantity();

        for (PlantWithAlgorithmDTO p : inv.getPlants()) {
            Double difference = quantity.doubleValue() - p.getUnrestqty().doubleValue();
            if (difference <= 0) {
                    PlantWithAlgorithmDTO plant = mapper.map(p, PlantWithAlgorithmDTO.class);
                    // assigns the entire available inventory of the hybrid
                    plant.setUnrestqty(BigDecimal.valueOf(quantity));
                    plantsToAllocate.add(plant);
                    quantity = 0D;
                    break;
            }
        }

        return quantity;
    }

    private InventoryWithAlgorithmDTO getInventoryPerHybridCornOrSorghum(String hybrid, List<InventoryWithAlgorithmDTO> inventory) {

        InventoryWithAlgorithmDTO inventoryPerHybrid = null;

        for (InventoryWithAlgorithmDTO invHybrid : inventory) {
            if (invHybrid.getHybrid().equals(hybrid)) {
                inventoryPerHybrid = invHybrid;
                break;
            }
        }

        return inventoryPerHybrid;
    }

    private void removeDetailsWithoutInventory(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isCornOrSorghum,
                                               List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException {

        // list of detail to remove
        List<OrderDetailDTO> detailsToRemove = new ArrayList<OrderDetailDTO>();
        List<OrderDetailDTO> detailsWithIncompleteInventory = new ArrayList<OrderDetailDTO>();
        List<OrderDetailDTO> detailsToReportMissingInventory = new ArrayList<OrderDetailDTO>();


        // for each of the detail, the detail is removed if not contains a list of the plants
        for (OrderDetailDTO detail : atpOrder.getDetail()) {

            if (isCornOrSorghum) {

                // for corn or sorghum validates the list of plants
                if (detail.getProductDTO().getListOfPlants() == null || detail.getProductDTO().getListOfPlants().isEmpty()) {
                    detailsToRemove.add(detail);
                }

            } else {

                // for cotton or soybean validates the list of sku
                if (detail.getProductDTO().getListOfSku() == null || detail.getProductDTO().getListOfSku().isEmpty()) {
                    detailsToRemove.add(detail);
                } else {

                    // valid if the detail presented incomplete inventory
                    if (detail.isInventoryIncomplete()) {
                        detailsWithIncompleteInventory.add(detail);
                    }
                }
            }
        }

        if (!detailsToRemove.isEmpty()) {

            // eliminating details without plants
            atpOrder.getDetail().removeAll(detailsToRemove);

            // add the details to notify lack of inventory
            detailsToReportMissingInventory.addAll(detailsToRemove);
        }

        if (!detailsWithIncompleteInventory.isEmpty()) {
            // added the details with inventory partially covered
            detailsToReportMissingInventory.addAll(detailsWithIncompleteInventory);
        }

        // post order
        this.postOrderGeneric(sapOrder, atpOrder, isCornOrSorghum);

        // notification is sent by lack of inventory
        inventoryHelper.sendNotificationOfInsufficientInventory(detailsToReportMissingInventory, atpOrder.getDistributorConfigDTO(), isCornOrSorghum, errors);
    }

    private void postOrderGeneric(SAPOrderDTO sapOrder, OrderDTO atpOrder, boolean isCornOrSorghum) throws CustomerLinkBusinessException {

        // again performs validation, because it may not contain hybrids after assign of inventory
        if (increaseDecreaseATPHelper.existHybridsToProcess(atpOrder)) {
            NotificationType type = NotificationType.ORDER_CREATED;
            // null is assigned by default to the creation of a new order
            atpOrder.setOrderIdSAP(null);

            // if sap order exists, the identifier is assigned
            if (sapOrder != null && sapOrder.getSalesorder() != null) {
                atpOrder.setOrderIdSAP(sapOrder.getSalesorder());
                type = NotificationType.ORDER_UPDATED;
            }


            if (isCornOrSorghum) {
                sapOrder = sapOrderService.postOrderWithAlgorithm(atpOrder);

                if (sapOrder.getErrors().isEmpty()) {
                    inventoryHelper.sendNotification(sapOrder, new ArrayList<InventoryInDTO>(), new ArrayList<OrderDetailDTO>(),
                            null, type, atpOrder.getDistributorConfigDTO());
                } else {
                    inventoryHelper.sendNotification(sapOrder.getErrors(), NotificationType.ORDER_POSTED_WITH_ERROR, atpOrder.getDistributorConfigDTO());
                }

            } else {
                sapOrder = sapOrderService.postOrderWithoutAlgorithm(atpOrder);

                if (sapOrder.getErrors().isEmpty()) {
                    inventoryHelper.sendNotification(sapOrder, new ArrayList<InventoryInDTO>(), new ArrayList<OrderDetailDTO>(),
                            null, type, atpOrder.getDistributorConfigDTO());
                } else {
                    inventoryHelper.sendNotification(sapOrder.getErrors(), NotificationType.ORDER_POSTED_WITH_ERROR, atpOrder.getDistributorConfigDTO());
                }
            }

        }
    }

    public void assignInventoryCottonOrSoybean(SAPOrderDTO sapOrder, OrderDTO atpOrder, List<InventoryWithOutAlgorithmDTO> inventory,
                                                List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException {

        // sorted in ascending order the materials list per hybrid
        for (InventoryWithOutAlgorithmDTO inv : inventory) {
            Collections.sort(inv.getMaterials());
        }

        for (OrderDetailDTO detail : atpOrder.getDetail()) {
            this.assignHybridInventoryCottonOrSoybean(sapOrder, detail, inventory);
        }

        // remove details without inventory and invokes method to save or update sap order
        this.removeDetailsWithoutInventory(sapOrder, atpOrder, false, errors);
    }

    private void assignHybridInventoryCottonOrSoybean(SAPOrderDTO sapOrder, OrderDetailDTO detail, List<InventoryWithOutAlgorithmDTO> inventory) {

        Double originalQuantity = detail.getQuantity();
        Double amountByAssigning = detail.getQuantity();
        List<MaterialDTO> materialsToAllocate = new ArrayList<MaterialDTO>();

        InventoryWithOutAlgorithmDTO inv = getInventoryPerHybridCottonOrSoybean(detail.getProductDTO().getProductCode(), inventory);

        if (inv != null) {

            for (MaterialDTO m : inv.getMaterials()) {

                if (amountByAssigning == 0) {
                    break;
                }

                Double difference = amountByAssigning.doubleValue() - m.getUnrestqty().doubleValue();

                if (difference >= 0) {

                    // assigns the entire available inventory of the material
                    materialsToAllocate.add(mapper.map(m, MaterialDTO.class));
                    amountByAssigning = difference;
                } else {

                    MaterialDTO material = mapper.map(m, MaterialDTO.class);
                    // is assigned only the amount of the material missing
                    material.setUnrestqty(BigDecimal.valueOf(amountByAssigning));

                    materialsToAllocate.add(material);
                    amountByAssigning = 0D;
                }
            }

            // valid if it was possible to assign the inventory full or partial amount
            if (originalQuantity.doubleValue() - amountByAssigning.doubleValue() > 0) {

                Long id = getLatestMaterialIdOfSapOrder(sapOrder, detail.getProductDTO().getProductCode());

                for (MaterialDTO m : materialsToAllocate) {
                    id += CustomerLinkCoreConstants.MATERIAL_UNITS_INCREASE;
                    m.setItemNumber(id);
                }

                // assignment is performed with material quantity, plant, storage location and batch.
                detail.getProductDTO().setListOfSku(mapper.mapList(MaterialSkuDTO.class, materialsToAllocate));

                for (MaterialSkuDTO materialSku : detail.getProductDTO().getListOfSku()) {
                    // is assigned the status "Insert"
                    materialSku.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
                }

                if (amountByAssigning.doubleValue() != 0) {
                    detail.setInventoryIncomplete(true);
                }
            }
        }
    }

    private InventoryWithOutAlgorithmDTO getInventoryPerHybridCottonOrSoybean(String hybrid, List<InventoryWithOutAlgorithmDTO> inventory) {

        InventoryWithOutAlgorithmDTO inventoryPerHybrid = null;

        for (InventoryWithOutAlgorithmDTO invHybrid : inventory) {
            if (invHybrid.getHybrid().equals(hybrid)) {
                inventoryPerHybrid = invHybrid;
                break;
            }
        }

        return inventoryPerHybrid;
    }

    private Long getLatestMaterialIdOfSapOrder(SAPOrderDTO sapOrder, String hybrid) {

        Long id = CustomerLinkCoreConstants.MATERIAL_UNITS_INCREASE;

        if (sapOrder != null) {

            // map obtained by hybrid materials
            Map<String, List<MaterialDTO>> groupByHybrid = increaseDecreaseATPHelper.groupByHybrid(sapOrder.getHybrids());

            // materials obtained by hybrid
            List<MaterialDTO> listOfMaterial = groupByHybrid.get(hybrid);

            if (!listOfMaterial.isEmpty()) {

                List<Long> ids = new ArrayList<Long>();

                for (MaterialDTO item : listOfMaterial) {
                    ids.add(item.getItemNumber()); // ##### item.getItm_number() por item.getItemNumber()
                }

                // the identifiers of the items (which make up the hybrid order) are sorted to obtain the greatest
                Collections.sort(ids);

                // gets the biggest identifier
                id = ids.get(ids.size() - 1);
            }
        }

        return id;
    }

}