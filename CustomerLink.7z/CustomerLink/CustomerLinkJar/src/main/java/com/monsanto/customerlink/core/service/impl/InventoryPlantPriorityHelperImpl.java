package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.InventoryPlantPriorityHelper;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.facade.dto.InventoryWithAlgorithmDTO;
import com.monsanto.customerlink.core.service.facade.dto.PlantWithAlgorithmDTO;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class InventoryPlantPriorityHelperImpl implements InventoryPlantPriorityHelper {

    private PlantService plantService;

    @Autowired
    public InventoryPlantPriorityHelperImpl(PlantService plantService) {
        this.plantService = plantService;
    }

    @Override
    public void assignPlantPriorityPerHybridCornOrSorghum(OrderDetailDTO detail, DistributorConfigDTO distributorConfigDTO, List<InventoryWithAlgorithmDTO> inventory){

        List<PlantVO> cornPlants = plantService.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.CORN.getCode(),distributorConfigDTO);
        List<PlantVO> sorghumPlants = plantService.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.SORGHUM.getCode(),distributorConfigDTO);

        for(InventoryWithAlgorithmDTO inv : inventory) {
            if(inv.getHybrid().equals(detail.getProductDTO().getProductCode())) {
                assignPlantPriority(this.getConfiguredPlantsCornOrSorghum(detail,cornPlants,sorghumPlants),inv);
                break;
            }
        }

    }

    public List<PlantVO> getConfiguredPlantsCornOrSorghum(OrderDetailDTO detail,List<PlantVO> cottonPlants, List<PlantVO> soybeanPlants){
        if(detail.getProductDTO().getCropCode().equals(SeedsCropCodeEnum.CORN.getCode())) {
            return cottonPlants;
        }   else {
            return soybeanPlants;
        }
    }

    public void assignPlantPriority(List<PlantVO> configuredPlants,InventoryWithAlgorithmDTO inv) {

        for(PlantWithAlgorithmDTO plant : inv.getPlants()) {
            for(PlantVO p : configuredPlants) {
                if(plant.getPlant().equals(p.getPlantCode())) {
                    plant.setPriority(p.getPriority());
                    break;
                }
            }
        }

        // ascending sort by priority of plant
        Collections.sort(inv.getPlants(), new Comparator<PlantWithAlgorithmDTO>() {
            @Override
            public int compare(PlantWithAlgorithmDTO o1, PlantWithAlgorithmDTO o2) {
                return  o1.getPriority().compareTo(o2.getPriority());
            }
        });
    }

}