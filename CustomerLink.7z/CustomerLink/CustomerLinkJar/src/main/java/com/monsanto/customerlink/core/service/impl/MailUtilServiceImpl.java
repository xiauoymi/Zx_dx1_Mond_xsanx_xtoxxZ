package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.dto.messages.DistributorMessageVO;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MailUtilServiceImpl implements MailUtilService {


    private DistributorRepository distributorRepository;
    private DistributionChannelRepository distributionChannelRepository;
    private SubRegionRepository subRegionRepository;
    private SalesDivisionRepository salesDivisionRepository;
    private SalesOrganizationRepository salesOrganizationRepository;

    @Autowired
    public MailUtilServiceImpl(DistributorRepository distributorRepository, DistributionChannelRepository distributionChannelRepository,
                               SubRegionRepository subRegionRepository,
                               SalesDivisionRepository salesDivisionRepository,
                               SalesOrganizationRepository salesOrganizationRepository) {
        this.distributorRepository = distributorRepository;
        this.distributionChannelRepository = distributionChannelRepository;
        this.subRegionRepository = subRegionRepository;
        this.salesDivisionRepository = salesDivisionRepository;
        this.salesOrganizationRepository = salesOrganizationRepository;
    }

    public Map<String, Object> buildDistributorMessageNotification(DistributorConfigDTO distributorConfigDTO,
                                                                   List<ErrorOrderDTO> listError) {

        Map<String, Object> parameters = new HashMap<String, Object>();
        DistributorMessageVO distributorMessageVO = new DistributorMessageVO();

        DistributorVO distributorVO = distributorRepository.findByDistributorCode(distributorConfigDTO.getDistributor().getDistributorCode());
        distributorMessageVO.setDistributorCode(distributorConfigDTO.getDistributor().getDistributorCode());
        distributorMessageVO.setDistributorDesc(distributorVO != null ? distributorVO.getName() : "");

        DistributionChannelVO distributionChannelVO = distributionChannelRepository.findByDistributionChannelCode(distributorConfigDTO.getDistChCode());
        distributorMessageVO.setDistributionChannel(distributorConfigDTO.getDistChCode());
        distributorMessageVO.setDistributionChannelDesc(distributionChannelVO != null ? distributionChannelVO.getDescription() : "");

        SubRegionVO subRegionVO = subRegionRepository.findBySubRegionCode(distributorConfigDTO.getSubRegionCode());
        distributorMessageVO.setSalesDistrictCode(distributorConfigDTO.getSubRegionCode());
        distributorMessageVO.setSalesDistrictDesc(subRegionVO != null ? subRegionVO.getDescription() : "");

        SalesDivisionVO salesDivisionVO = salesDivisionRepository.findOne(distributorConfigDTO.getSalesDivCode());
        distributorMessageVO.setSalesDivisionCode(distributorConfigDTO.getSalesDivCode());
        distributorMessageVO.setSalesDivisionDesc(salesDivisionVO != null ? salesDivisionVO.getSalesDivDesc() : "");

        SalesOrganizationVO salesOrganizationVO = salesOrganizationRepository.findOne(distributorConfigDTO.getSalesOrgCode());

        distributorMessageVO.setSalesOrgCode(distributorConfigDTO.getSalesOrgCode());
        distributorMessageVO.setSalesOrgDesc(salesOrganizationVO != null ? salesOrganizationVO.getSalesOrgDesc() : "");

        parameters.put("distributor", distributorMessageVO);

        if (listError != null && !listError.isEmpty()) {
            parameters.put("errors", listError);
        }

        parameters.put("currentDate", CustomerLinkUtils.SDF_DDMMYYYY.format(new Date()));

        return parameters;
    }
}
