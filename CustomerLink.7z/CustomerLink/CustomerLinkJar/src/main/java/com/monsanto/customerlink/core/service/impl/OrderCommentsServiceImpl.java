package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderCommentsService;
import com.monsanto.customerlink.persistence.entities.OrderCommentVO;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.repositories.OrderCommentsRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderCommentsServiceImpl implements OrderCommentsService {

    private OrderCommentsRepository orderCommentsRepository;

    @Autowired
    public OrderCommentsServiceImpl(OrderCommentsRepository orderCommentsRepository) {
        this.orderCommentsRepository = orderCommentsRepository;
    }

    @Override
    public OrderCommentVO saveComment(Long idOrder, String comments) throws Exception {
        validateInputParameters(idOrder,comments);
        OrderVO orderVO = new OrderVO();
        orderVO.setOrderId(idOrder);
        OrderCommentVO orderCommentVO = new OrderCommentVO();
        orderCommentVO.setOrderByOrderId(orderVO);
        orderCommentVO.setComments(comments);
        return orderCommentsRepository.save(orderCommentVO);
    }

    public void validateInputParameters(Long idOrder, String comments) {
        if(idOrder == null ) {
            throw new IllegalArgumentException(" The id order can not be null");
        }
        if (StringUtils.isBlank(comments)) {
            throw new IllegalArgumentException(" The comments for the order can not be null or empty");
        }
    }
}