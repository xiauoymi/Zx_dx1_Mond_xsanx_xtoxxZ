package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.OrderReasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.OrderTypeNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderTypeDTO;
import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderComplementBusiness")
public class OrderComplementServiceImpl implements OrderComplementService {

    @Autowired
    private FiscalYearService fiscalYearService;

    @Autowired
    private OrderReasonTypeService orderReasonTypeBusiness;

    @Autowired
    private PONumberService poNumberBusiness;

    @Autowired
    private PriceGroupService priceGroupBusiness;

    @Autowired
    private SAPOrderTypeService sapOrderTypeBusiness;

    @Autowired
    private SeasonService seasonBusiness;

    @Autowired
    private Mapper mapper;

    /**
     * @see OrderComplementService#complement(OrderDTO)
     */
    @Override
    public void complement(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        orderDTO.setSapOrderTypeDTO(retrievesSapOrderType(orderDTO));
        orderDTO.setSapOrderReasonTypeDTO(retrievesSapOrderReasonType(orderDTO));
        if (!StringUtils.equals(CustomerLinkCoreConstants.AGROCHEMICAL_SALES_DIV, orderDTO.getDistributorConfigDTO().getSalesDivCode())) {
            finishToFillASeedOrder(orderDTO);
        }
    }

    /**
     * @see OrderComplementService#complementToSearch(OrderDTO)
     */
    @Override
    public void complementToSearch(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        orderDTO.setSapOrderTypeDTO(retrievesSapOrderType(orderDTO));
        orderDTO.setSapOrderReasonTypeDTO(retrievesSapOrderReasonType(orderDTO));
        if (StringUtils.equals(CustomerLinkCoreConstants.AGROCHEMICAL_SALES_DIV, orderDTO.getDistributorConfigDTO().getSalesDivCode())) {
            orderDTO.setSearchPeriodDTO(fiscalYearService.retrieveSearchPeriod());
        } else {
            orderDTO.setSearchPeriodDTO(seasonBusiness.retrieveSearchPeriod(orderDTO.getDistributorConfigDTO().getSubRegionCode()));
            orderDTO.setPriceGroup(retrievesPriceGroup(orderDTO));
        }
    }

    private void finishToFillASeedOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        orderDTO.setPoNumber(retrievesPONumber(orderDTO));
        orderDTO.setIncoterms1(CustomerLinkCoreConstants.INCOTERMS1);
        orderDTO.setIncoterms2(CustomerLinkCoreConstants.INCOTERMS2);
        orderDTO.setPriceGroup(retrievesPriceGroup(orderDTO));
        orderDTO.setSoldTo(orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
        orderDTO.setShipTo(orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
    }

    private SAPOrderTypeDTO retrievesSapOrderType(OrderDTO orderDTO) throws OrderTypeNotFoundException {
        return mapper.map(sapOrderTypeBusiness.retrieveSapOrderType(orderDTO.getDistributorConfigDTO().getDistChCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()), SAPOrderTypeDTO.class);
    }

    private String retrievesPONumber(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        return poNumberBusiness.generatePONumber(orderDTO.getClOrderTypeCode(),
                orderDTO.getDistributorConfigDTO().getSubRegionCode(), orderDTO.getDistributorConfigDTO().getDistChCode());
    }

    private SAPOrderReasonTypeDTO retrievesSapOrderReasonType(OrderDTO orderDTO) throws OrderReasonNotFoundException {
        return mapper.map(orderReasonTypeBusiness.retrieveOrderReasonType(orderDTO.getClOrderTypeCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()), SAPOrderReasonTypeDTO.class);
    }

    private PriceGroupDTO retrievesPriceGroup(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        return priceGroupBusiness.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(),
                orderDTO.getDetail().get(0).getProductDTO().getBrandCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode());
    }
}
