package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderCommentsService;
import com.monsanto.customerlink.core.service.OrderDetailService;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.persistence.entities.OrderDetailVO;
import com.monsanto.customerlink.persistence.repositories.OrderDetailRepository;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {

    private OrderDetailRepository orderDetailRepository;
    private OrderCommentsService orderCommentsService;

    @Autowired
    public OrderDetailServiceImpl(OrderDetailRepository orderDetailRepository, OrderCommentsService orderCommentsService) {
        this.orderDetailRepository = orderDetailRepository;
        this.orderCommentsService = orderCommentsService;
    }

    @Override
    public synchronized void deleteOrderDetails(Long idOrder, List<String> hybridsForDelete) throws Exception {
        validateInputParameters(idOrder,hybridsForDelete);
        for(String id : hybridsForDelete) {
            Long idDetail = Long.valueOf(id);
            OrderDetailVO detail = orderDetailRepository.findByOrderDetailId(idDetail);
            orderDetailRepository.delete(idDetail);
            orderCommentsService.saveComment(idOrder, CustomerLinkCoreConstants.ORDER_DETAIL_DELETE_MESSAGE+detail.toString());
        }
    }

    public void validateInputParameters(Long idOrder, List<String> hybridsForDelete) {
        if(idOrder == null ) {
            throw new IllegalArgumentException(" The id order can not be null");
        }
        if (CollectionUtils.isEmpty(hybridsForDelete)) {
            throw new IllegalArgumentException(" The list of details order can not be null or empty");
        }
    }



}
