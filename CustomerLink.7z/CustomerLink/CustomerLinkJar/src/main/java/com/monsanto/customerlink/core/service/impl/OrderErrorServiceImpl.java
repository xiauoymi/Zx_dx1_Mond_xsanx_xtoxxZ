package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderErrorService;
import com.monsanto.customerlink.core.service.OrderService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.util.SkuPricesErrorsEnum;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderErrorServiceImpl implements OrderErrorService {

    private OrderService orderService;

    @Autowired
    public OrderErrorServiceImpl(OrderService orderService) {
        this.orderService = orderService;
    }

    @Override
    public void saveOrderAndErrors(OrderDTO orderDTO) throws CustomerLinkBusinessException {

        List<ErrorOrderDTO> orderDTOList = obtainErrors(orderDTO);

        orderDTO.setErrors(orderDTOList);
        orderService.createOrder(orderDTO);
    }

    @Override
    public boolean containErrors(OrderDTO orderDTO) {
        List<ErrorOrderDTO> orderDTOList = obtainErrors(orderDTO);
        return !orderDTOList.isEmpty();
    }


    @Override
    public OrderDTO filterHybridsWithErrors(OrderDTO orderDTO) {
        List<OrderDetailDTO> filterOrderDetail = new ArrayList<OrderDetailDTO>();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            if (orderDetailDTO.getErrors().isEmpty()) {
                filterOrderDetail.add(orderDetailDTO);
            }
        }

        orderDTO.setDetail(filterOrderDetail);

        return orderDTO;
    }

    @Override
    public List<ErrorOrderDTO> obtainPricesErrors(OrderDTO responseOrderDTO) {
        List<ErrorOrderDTO> listErrorPrice = new ArrayList<ErrorOrderDTO>();

        for (OrderDetailDTO orderDetailDTO : responseOrderDTO.getDetail()) {
            for (ErrorOrderDTO errorOrderDTO : orderDetailDTO.getErrors()) {
                if (isPriceError(errorOrderDTO)) {
                    listErrorPrice.add(errorOrderDTO);
                }
            }
        }
        return listErrorPrice;
    }

    @Override
    public List<ErrorOrderDTO> obtainSkuErrors(OrderDTO responseOrderDTO) {
        List<ErrorOrderDTO> listErrorSku = new ArrayList<ErrorOrderDTO>();

        for (OrderDetailDTO orderDetailDTO : responseOrderDTO.getDetail()) {
            for (ErrorOrderDTO errorOrderDTO : orderDetailDTO.getErrors()) {
                if (!isPriceError(errorOrderDTO)) {
                    listErrorSku.add(errorOrderDTO);
                }
            }
        }
        return listErrorSku;
    }

    private boolean isPriceError(ErrorOrderDTO errorOrderDTO) {
        return StringUtils.equals(errorOrderDTO.getErrorTypes().getErrorTypeCode(), SkuPricesErrorsEnum.PRICE_ERROR_7.toString());
    }


    private List<ErrorOrderDTO> obtainErrors(OrderDTO orderDTO) {
        List<ErrorOrderDTO> orderDTOList = new ArrayList<ErrorOrderDTO>();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            orderDTOList.addAll(orderDetailDTO.getErrors());
        }

        orderDTOList.addAll(orderDTO.getErrors());

        return orderDTOList;
    }

}
