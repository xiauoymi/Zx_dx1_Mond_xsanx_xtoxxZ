package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderReasonTypeService;
import com.monsanto.customerlink.core.service.exception.OrderReasonNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderReasonTypeVO;
import com.monsanto.customerlink.persistence.repositories.OrderReasonTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderReasonTypeBusiness")
public class OrderReasonTypeServiceImpl implements OrderReasonTypeService {

    @Autowired
    private OrderReasonTypeRepository orderReasonTypeRepository;

    /**
     * @see OrderReasonTypeService#retrieveOrderReasonType(String, String)
     */
    @Override
    public OrderReasonTypeVO retrieveOrderReasonType(String clOrderTypeCode, String cropCode) throws OrderReasonNotFoundException {
        final OrderReasonTypeVO orderReasonTypeVO = orderReasonTypeRepository.findByCLOrderTypeAndCrop(clOrderTypeCode, cropCode);
        if (null == orderReasonTypeVO) {
            throw new OrderReasonNotFoundException(new Object[]{clOrderTypeCode, cropCode});
        }
        return orderReasonTypeVO;
    }

    /**
     * @see OrderReasonTypeService#retrieveOrderReasonTypeByCode(String)
     */
    @Override
    public OrderReasonTypeVO retrieveOrderReasonTypeByCode(String orderReasonCode) throws OrderReasonNotFoundException {
        final OrderReasonTypeVO orderReasonTypeVO = orderReasonTypeRepository.findByOrderReasonCode(orderReasonCode);
        if (null == orderReasonTypeVO) {
            final OrderReasonNotFoundException orderReasonNotFoundException = new OrderReasonNotFoundException(new Object[]{orderReasonCode});
            orderReasonNotFoundException.setCode("orderReasonByCodeNotFoundException");
            throw orderReasonNotFoundException;
        }
        return orderReasonTypeVO;
    }
}
