package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderService;
import com.monsanto.customerlink.core.service.OrderStrategy;
import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.WFApprovalSpecialOrderService;
import com.monsanto.customerlink.core.service.dto.SpecialOrderDTO;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.core.service.exception.RCDNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.OrderRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service("orderBusiness")
public class OrderServiceImpl implements OrderService {

    private static final Logger logger = Logger.getLogger(OrderServiceImpl.class);

    @Autowired
    private UserService userService;

    @Autowired
    private WFApprovalSpecialOrderService wfApprovalSpecialOrderService;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private Mapper mapper;

    @Autowired
    private ApplicationContext applicationContext;

    /**
     * @see OrderService#createOrder(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public OrderDTO createOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        CustomerLinkUtils.isValidParameter(orderDTO);
        OrderStrategy orderStrategy = getOrderStrategy(orderDTO.getClOrderTypeCode());
        OrderVO orderVO = null;
        if (null == orderDTO.getOrderId()) {
            orderVO = orderStrategy.createOrder(orderDTO);
        } else {
            orderVO = orderStrategy.updateOrder(orderDTO);
        }

        DistributorDTO distributor = orderDTO.getDistributorConfigDTO().getDistributor();
        final OrderDTO order = mapper.map(orderVO, OrderDTO.class);
        order.getDistributorConfigDTO().setDistributor(distributor);
        order.setRepresentativeDTO(getRepresentative(orderVO.getRcdSAPCode(), order.getDistributorConfigDTO()));
        return order;
    }

    /**
     * @see OrderService#changeOrderToPosted(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public OrderDTO changeOrderToPosted(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        CustomerLinkUtils.isValidParameter(orderDTO);
        CustomerLinkUtils.isValidParameter(orderDTO.getOrderId());
        OrderStrategy orderStrategy = getOrderStrategy(orderDTO.getClOrderTypeCode());
        return mapper.map(orderStrategy.changeOrderToPosted(orderDTO.getOrderId()), OrderDTO.class);
    }

    /**
     * @see OrderService#retrieveOrders(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED, timeout = 360)
    public List<OrderDTO> retrieveOrders(OrderDTO parameters) throws OrdersNotFoundException {
        List<OrderDTO> orders = null;
        final List<OrderVO> orderVOList = orderRepository.findByParametersAndCurrentSeasonActive(parameters);
        if (orderVOList.isEmpty()) {
            throw new OrdersNotFoundException(new Object[]{});
        } else {
            orders = new ArrayList<OrderDTO>();
            DistributorDTO distributor = parameters.getDistributorConfigDTO().getDistributor();
            for (OrderVO orderVO : orderVOList) {
                final OrderDTO orderDTO = mapper.map(orderVO, OrderDTO.class);
                orderDTO.getDistributorConfigDTO().setDistributor(distributor);
                orderDTO.setRepresentativeDTO(getRepresentative(orderVO.getRcdSAPCode(), orderDTO.getDistributorConfigDTO()));
                orders.add(orderDTO);
            }
        }
        return orders;
    }

    /**
     * @see com.monsanto.customerlink.core.service.OrderService#retrieveSpecialOrdersPendingApprovalByUser(Long)
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, timeout = 360)
    public List<SpecialOrderDTO> retrieveSpecialOrdersPendingApprovalByUser(Long userId) {

        List<SpecialOrderDTO> orders = new ArrayList<SpecialOrderDTO>();
        Collection<OrderVO> listOfOrders = new ArrayList<OrderVO>();

        Collection<Long> ids = wfApprovalSpecialOrderService.obtainApprovalsPendingBusinessByUser(userId);

        if (!ids.isEmpty()) {
            for (Long id : ids) {
                OrderVO o = orderRepository.findByOrderId(id);
                if(o != null) {
                    listOfOrders.add(o);
                }
            }
        }

        if (!listOfOrders.isEmpty()) {

            for(OrderVO order : listOfOrders) {
                SpecialOrderDTO so = mapper.map(order,SpecialOrderDTO.class);
                so.setUserId(userId);
                orders.add(so);
            }
        }

        return orders;
    }

    /**
     * Gets the suit strategy to works with a order type
     *
     * @param clOrderTypeCode Customer Link order type
     * @return the strategy
     */
    private OrderStrategy getOrderStrategy(String clOrderTypeCode) {
        CustomerLinkUtils.isValidParameter(clOrderTypeCode);
        final StringBuilder bean = new StringBuilder("orderStrategy").append(clOrderTypeCode);
        return applicationContext.getBean(bean.toString(), OrderStrategy.class);
    }

    private RepresentativeDTO getRepresentative(String rcdSAPCode, DistributorConfigDTO distributorProfile) {
        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        if (!StringUtils.isEmpty(rcdSAPCode)) {
            UserVO userVO = null;
            try {
                userVO = userService.retrieveRCD(rcdSAPCode, distributorProfile);
                mapper.map(userVO, representativeDTO);
            } catch (RCDNotFoundException e) {
                logger.error(e.getMessage(), e);
                representativeDTO.setSapUserId(rcdSAPCode);
            }
        }
        return representativeDTO;
    }
}