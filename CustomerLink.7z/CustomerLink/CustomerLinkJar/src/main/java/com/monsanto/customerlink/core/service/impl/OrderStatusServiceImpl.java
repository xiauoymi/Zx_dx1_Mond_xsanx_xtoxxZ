package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderStatusService;
import com.monsanto.customerlink.core.service.exception.OrderStatusNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.OrderStatusEnum;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.persistence.repositories.OrderStatusRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderStatusBusiness")
public class OrderStatusServiceImpl implements OrderStatusService {

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    /**
     * @see OrderStatusService#retrieveOrderStatusInitial(OrderDTO)
     */
    public OrderStatusVO retrieveOrderStatusInitial(OrderDTO orderDTO) throws OrderStatusNotFoundException {
        CustomerLinkUtils.isValidParameter(orderDTO);
        String orderStatusCode = OrderStatusEnum.PENDING_APPROVAL.toString();
        if (!orderDTO.getErrors().isEmpty()) {
            orderStatusCode = OrderStatusEnum.WITH_ERROR.toString();
        }
        final OrderStatusVO orderStatusVO = orderStatusRepository.findByOrderStatusCode(orderStatusCode);
        if (null == orderStatusVO) {
            throw new OrderStatusNotFoundException(new Object[]{orderStatusCode});
        }
        return orderStatusVO;
    }
}
