package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderStrategy;

public class OrderWithAlgorithmStrategyImpl extends OrderStrategy {
}
