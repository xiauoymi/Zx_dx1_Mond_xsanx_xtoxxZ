package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderReasonTypeService;
import com.monsanto.customerlink.core.service.OrderStrategy;
import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.SAPOrderTypeService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.OrderStatusEnum;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.springframework.beans.factory.annotation.Autowired;

public class OrderWithoutSoakTestStrategyImpl extends OrderStrategy {

    @Autowired
    private OrderReasonTypeService orderReasonTypeBusiness;

    @Autowired
    private PriceGroupService priceGroupService;

    @Autowired
    private SAPOrderTypeService sapOrderTypeBusiness;

    /*@Autowired
    private UserService userService;*/

    @Override
    public OrderVO createOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateInputParameters(orderDTO);
        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(retrieveOrderStatus(OrderStatusEnum.PENDING_POST.toString()));
        setPropertiesToOrder(orderVO, orderDTO);
        return saveOrder(orderVO);
    }

    @Override
    protected void validateInputParameters(OrderDTO orderDTO) {
        validateInputParametersCommon(orderDTO);
        CustomerLinkUtils.isValidParameter(orderDTO.getOrderIdSAP());
        CustomerLinkUtils.isValidParameter(orderDTO.getSapOrderTypeDTO());
        CustomerLinkUtils.isValidParameter(orderDTO.getSapOrderTypeDTO().getOrderTypeCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getSapOrderReasonTypeDTO());
        CustomerLinkUtils.isValidParameter(orderDTO.getSapOrderReasonTypeDTO().getOrderReasonTypeCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getPriceGroup());
        CustomerLinkUtils.isValidParameter(orderDTO.getPriceGroup().getPriceGroupCode());
        //CustomerLinkUtils.isValidParameter(orderDTO.getRepresentativeDTO());
        //CustomerLinkUtils.isValidParameter(orderDTO.getRepresentativeDTO().getSapUserId());
        CustomerLinkUtils.isValidParameter(orderDTO.getCurrency());
        CustomerLinkUtils.isValidParameter(orderDTO.getPoNumber());
        CustomerLinkUtils.isValidParameter(orderDTO.getIncoterms1());
        CustomerLinkUtils.isValidParameter(orderDTO.getIncoterms2());
        CustomerLinkUtils.isValidParameter(orderDTO.getSoldTo());
        CustomerLinkUtils.isValidParameter(orderDTO.getShipTo());
        validateOrderDetail(orderDTO.getDetail());
    }

    @Override
    protected void setPropertiesToOrder(OrderVO orderVO, OrderDTO orderDTO) throws CustomerLinkBusinessException {
        setCommonPropertiesToOrder(orderVO, orderDTO);
        orderVO.setSapOrderTypeByOrderTypeId(sapOrderTypeBusiness.retrieveSapOrderTypeByCode(orderDTO.getSapOrderTypeDTO().getOrderTypeCode()));
        orderVO.setOrderReasonTypeByOrderReasonTypeId(orderReasonTypeBusiness.retrieveOrderReasonTypeByCode(orderDTO.getSapOrderReasonTypeDTO().getOrderReasonTypeCode()));
        orderVO.setPriceGroupByPriceGroupId(priceGroupService.retrievePriceGroupByCode(orderDTO.getPriceGroup().getPriceGroupCode()));
        //orderVO.setRcdByUserId(userService.retrieveRCD(orderDTO.getRepresentativeDTO().getSapUserId(), orderDTO.getDistributorConfigDTO()));
        orderVO.setOrderIdSap(orderDTO.getOrderIdSAP());
        orderVO.setCurrency(orderDTO.getCurrency());
        orderVO.setPoNumber(orderDTO.getPoNumber());
        orderVO.setIncoterms1(orderDTO.getIncoterms1());
        orderVO.setIncoterms2(orderDTO.getIncoterms2());
        orderVO.setSoldTo(orderDTO.getSoldTo());
        orderVO.setShipTo(orderDTO.getShipTo());
    }
}
