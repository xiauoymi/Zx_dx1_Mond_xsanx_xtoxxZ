package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributionChannelService;
import com.monsanto.customerlink.core.service.FiscalYearService;
import com.monsanto.customerlink.core.service.PONumberService;
import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.FiscalYearNotFoundException;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.DistributionChannelVO;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("poNumberBusiness")
public class PONumberServiceImpl implements PONumberService {

    @Autowired
    private DistributionChannelService distributionChannelBusiness;

    @Autowired
    private FiscalYearService fiscalYearBusiness;

    @Autowired
    private SeasonService seasonBusiness;

    /**
     * @see PONumberService#generatePONumber(String, String, String)
     */
    @Override
    public String generatePONumber(String clOrderType, String subRegionCode, String distChCode) throws CustomerLinkBusinessException {
        validateInputParameters(clOrderType, subRegionCode, distChCode);
        StringBuilder poNumber = null;
        if (StringUtils.equals(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), clOrderType)) {
            poNumber = generatePONumberBase(subRegionCode);
            poNumber.append(' ')
                    .append(CustomerLinkCoreConstants.WITHOUT_SOAK_TEST);
        } else {
            final DistributionChannelVO distributionChannelVO = distributionChannelBusiness.retrieveDistributionChannel(distChCode);
            poNumber = generatePONumberBase(subRegionCode);
            if (null != distributionChannelVO.getShortName()) {
                poNumber.append(' ')
                        .append(distributionChannelVO.getShortName());
            }
        }
        return poNumber.toString();
    }

    /**
     * Generates the PO Number base
     * PONumber_Base = Season + two last digits of the fiscal year + space + region
     *
     * @param subRegionCode Sales district code
     * @return PO Number base
     * @throws ActiveSeasonNotFoundException If active season not found in the repository
     * @throws FiscalYearNotFoundException   If active fiscal year not found in the repository
     */
    private StringBuilder generatePONumberBase(String subRegionCode) throws ActiveSeasonNotFoundException, FiscalYearNotFoundException {
        final Date date = new Date();
        final SeasonVO seasonVO = seasonBusiness.retrieveActiveSeason(subRegionCode, date);
        final FiscalYearVO fiscalYearVO = fiscalYearBusiness.retrieveActiveFiscalYear(date);
        final StringBuilder poNumberBase = new StringBuilder(16);
        poNumberBase.append(seasonVO.getSeasonTypeBySeasonTypeId().getSeasonTypeCode())
                .append(fiscalYearVO.getFiscalYear().toString().substring(2))
                .append(' ')
                .append(subRegionCode);
        return poNumberBase;
    }

    /**
     * Validates input parameters
     *
     * @param clOrderType   Order type in customer link
     *                      Is SSTO     -> If the season order is without soak test
     *                      Is Not SSTO -> For the remaining orders (Only crops)
     * @param subRegionCode Sales district code
     * @param distChCode    Distribution channel code
     */
    private void validateInputParameters(String clOrderType, String subRegionCode, String distChCode) {
        CustomerLinkUtils.isValidParameter(clOrderType);
        CustomerLinkUtils.isValidParameter(subRegionCode);
        if (!StringUtils.equals(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), clOrderType)) {
            CustomerLinkUtils.isValidParameter(distChCode);
        }
    }

}
