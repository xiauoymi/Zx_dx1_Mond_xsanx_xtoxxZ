package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.persistence.entities.SubRegionVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlantServiceImpl implements PlantService {

    private CropService cropService;
    private PlantRepository plantRepository;
    private DistributorRepository distributorRepository;

    @Autowired
    public PlantServiceImpl(CropService cropService, PlantRepository plantRepository, DistributorRepository distributorRepository) {
        this.cropService = cropService;
        this.plantRepository = plantRepository;
        this.distributorRepository = distributorRepository;
    }

    public List<PlantVO> obtainPlantsAccordingToCrop(CropVO cropConfig, DistributorConfigDTO distributorConfigDTO) {

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode(distributorConfigDTO.getSubRegionCode());

        DistributorVO distributorVO = distributorRepository.findByDistributorCode(distributorConfigDTO.getDistributor().getDistributorCode());

        if ((SeedsCropCodeEnum.COTTON.getCode().equals(cropConfig.getCropCode()) || SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode().equals(cropConfig.getCropCode()))
                && distributorVO.getRegion() != null) {
            return plantRepository.findByParameters(cropConfig.getCropId(), subRegionVO.getSubRegionCode(), distributorVO.getRegion());
        }
        return plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(cropConfig, subRegionVO);
    }

    @Override
    public List<PlantVO> obtainPlantsAccordingToCrop(String cropCode, DistributorConfigDTO distributorConfigDTO) {
        CropVO cropConfig = cropService.obtainCropByCode(cropCode);
        return this.obtainPlantsAccordingToCrop(cropConfig,distributorConfigDTO);
    }

}