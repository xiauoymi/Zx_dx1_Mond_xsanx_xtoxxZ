package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.ConditionTypeNotFoundForProductException;
import com.monsanto.customerlink.core.service.exception.PriceGroupNotFoundForOrderException;
import com.monsanto.customerlink.core.service.util.BrandEnum;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PriceGroupVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PriceGroupRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class PriceGroupServiceImpl implements PriceGroupService {

    private PriceGroupRepository priceGroupRepository;
    private SeasonService seasonService;
    private Mapper mapper;
    private DistributorRepository distributorRepository;

    @Autowired
    public PriceGroupServiceImpl(PriceGroupRepository priceGroupRepository, Mapper mapper,
                                 SeasonService seasonService, DistributorRepository distributorRepository) {
        this.priceGroupRepository = priceGroupRepository;
        this.mapper = mapper;
        this.seasonService = seasonService;
        this.distributorRepository = distributorRepository;
    }

    @Override
    public PriceGroupDTO findPriceGroupForOrder(DistributorConfigDTO configDTO, String brandCode,
                                                String cropCode) throws PriceGroupNotFoundForOrderException, ActiveSeasonNotFoundException {

        String region = "-1";

        if (SeedsCropCodeEnum.COTTON.getCode().equals(cropCode)) {
            DistributorVO distributorVO = distributorRepository.findByDistributorCode(configDTO.getDistributor().getDistributorCode());

            if (distributorVO.getRegion() != null) {
                region = distributorVO.getRegion();
            }
        }
        SeasonVO seasonVO = seasonService.retrieveActiveSeason(configDTO.getSubRegionCode(), new Date());

        String brand = getBrandCode(brandCode);

        PriceGroupVO priceGroupVO;

        if(brand == null) {
            priceGroupVO = priceGroupRepository.findByParametersWithOutBrand(configDTO.getSubRegionCode(), seasonVO.getSeasonTypeBySeasonTypeId().getSeasonTypeCode(),cropCode, configDTO.getDistChCode(), region);
        }else {
            priceGroupVO = priceGroupRepository.findByParameters(brand, configDTO.getSubRegionCode(), seasonVO.getSeasonTypeBySeasonTypeId().getSeasonTypeCode(), cropCode, configDTO.getDistChCode(), region);
        }

        if (priceGroupVO == null) {
            throw new PriceGroupNotFoundForOrderException(new Object[]{
                    configDTO.getSubRegionCode(),
                    seasonVO.getSeasonTypeBySeasonTypeId().getSeasonTypeCode(),
                    configDTO.getDistChCode(), cropCode, brand
            });
        }
        return mapper.map(priceGroupVO, PriceGroupDTO.class);
    }

    @Override
    public String findConditionTypeForProduct(ProductDTO productDTO) throws ConditionTypeNotFoundForProductException {
        return null;
    }

    @Override
    public PriceGroupVO retrievePriceGroupByCode(String priceGroupCode) throws PriceGroupNotFoundForOrderException {
        final PriceGroupVO priceGroupVO = priceGroupRepository.findByPriceGroupCode(priceGroupCode);
        if (priceGroupVO == null) {
            throw new PriceGroupNotFoundForOrderException(new Object[]{});
        }
        return priceGroupVO;
    }

    private String getBrandCode(String brandCode) {
        if (brandCode != null && brandCode.equals(BrandEnum.CB.getId())) {
            return brandCode;
        }
        return null;
    }
}
