package com.monsanto.customerlink.core.service.impl;


import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProcessAgreementOrderServiceImpl implements ProcessAgreementOrderService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());


    private SAPOrderService sapOrderService;
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;
    private ProcessOrderInSapService processOrderInSapService;
    private ProcessOrderNotInSapService processOrderNotInSapService;

    @Autowired
    public ProcessAgreementOrderServiceImpl(
            IncreaseDecreaseATPHelper increaseDecreaseATPHelper,
            SAPOrderService sapOrderService,
            ProcessOrderInSapService processOrderInSapService,
            ProcessOrderNotInSapService processOrderNotInSapService
    ) {
        this.increaseDecreaseATPHelper = increaseDecreaseATPHelper;
        this.sapOrderService = sapOrderService;
        this.processOrderInSapService = processOrderInSapService;
        this.processOrderNotInSapService = processOrderNotInSapService;
    }

    @Override
    public boolean processAgrochemicalOrders(Map<AgreementDTO, List<OrderDTO>> mapOrdersAgreement) {

        /*
        consult order in sap
        if order not matches with current agreement send it to  be created
        if order not matches in quantities with  agreement send notification
        if order was sended  do nothing
        if all orders were posted change agrement status to POSTED
        */

        boolean updated = true;
        if(!mapOrdersAgreement.isEmpty()) {
            int agreementsUpdated = 0;
            for (AgreementDTO agreementDTO : mapOrdersAgreement.keySet()) {
                List<OrderDTO> ordersByAgreement = mapOrdersAgreement.get(agreementDTO);
                Map<OrderDTO, SAPOrderDTO> mapOrderSapOrder = obtainSapOrderByOrder(ordersByAgreement);
                if(processAgreementOrders(mapOrderSapOrder, agreementDTO)) {
                    agreementsUpdated++;
                }
            }
            updated = agreementsUpdated == mapOrdersAgreement.values().size();
        }
        return updated;
    }

    public boolean processAgreementOrders(Map<OrderDTO, SAPOrderDTO> mapOrderSapOrder, AgreementDTO agreementDTO) {
        boolean agreementUpdated = false;
        boolean processOrdersWithSapOrderFlag = processOrderInSapService.processOrdersWithSapOrder(mapOrderSapOrder, agreementDTO);
        boolean processOrdersWithoutSapOrderFlag = processOrderNotInSapService.processOrdersWithoutSapOrder(mapOrderSapOrder, agreementDTO);
        if(processOrdersWithSapOrderFlag && processOrdersWithoutSapOrderFlag) {
            processOrderNotInSapService.changeAgreementStatusToPosted(agreementDTO);
            agreementUpdated = true;
        }
        return agreementUpdated;
    }

    private Map<OrderDTO, SAPOrderDTO> obtainSapOrderByOrder(List<OrderDTO> orderDTOs) {
        Map<OrderDTO, SAPOrderDTO> mapOrderSapOrderDTO = new HashMap<OrderDTO, SAPOrderDTO>();
        for (OrderDTO orderDTO : orderDTOs) {
            try {
                SAPOrderDTO sapOrderDTO = obtainOrderInSap(orderDTO);
                mapOrderSapOrderDTO.put(orderDTO, sapOrderDTO);
            } catch (CustomerLinkBusinessException e) {
                log.error(e.getSuperMessage(), e);
            }
        }
        return mapOrderSapOrderDTO;
    }

    private SAPOrderDTO obtainOrderInSap(OrderDTO atpOrder) throws CustomerLinkBusinessException {
        increaseDecreaseATPHelper.validateInputParameters(atpOrder);
        return sapOrderService.retrieveOrder(atpOrder);
    }
}