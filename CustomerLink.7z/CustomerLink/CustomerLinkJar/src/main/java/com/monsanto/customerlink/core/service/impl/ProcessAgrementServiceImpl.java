package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.AgreementService;
import com.monsanto.customerlink.core.service.ProcessAgreementOrderService;
import com.monsanto.customerlink.core.service.ProcessAgrementService;
import com.monsanto.customerlink.core.service.SendAgrochemicalPricesService;
import com.monsanto.customerlink.core.service.exception.AgreementRetrieveByParametersNotFoundException;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PrivateBrandDistributorVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProcessAgrementServiceImpl implements ProcessAgrementService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private DistributorRepository distributorRepository;
    private AgreementService agreementService;
    private SendAgrochemicalPricesService sendAgrochemicalPricesService;
    private Mapper mapper;
    private ProcessAgreementOrderService processAgreementOrderService;

    @Autowired
    public ProcessAgrementServiceImpl(DistributorRepository distributorRepository, AgreementService agreementService,
                                      Mapper mapper, SendAgrochemicalPricesService sendAgrochemicalPricesService,
                                      ProcessAgreementOrderService processAgreementOrderService) {
        this.distributorRepository = distributorRepository;
        this.agreementService = agreementService;
        this.mapper = mapper;
        this.sendAgrochemicalPricesService = sendAgrochemicalPricesService;
        this.processAgreementOrderService = processAgreementOrderService;
    }

    /**
     * Takes Agreement with status Approved and aimed to private brands distributor,
     * and send these are sended to sap service to create agrochemicals orders
     * <p/>
     * <li>First step:  obtain distributor for private brands</li>
     * <li>Second step: obtain all agreements Approved for the last ditributors</li>
     * <li>Consult currency and divide orders if necessary</li>
     * <li>Verify if order exist in SAP</li>
     * <li>Consult inventory and obtain plants for the order</li>
     * <li>Send order to be created in SAP</li>
     */
    @Override
    public void processAgreementService() {
        Map<DistributorVO, List<PrivateBrandDistributorVO>> privateBrandDistributors = obtainDistributorsPrivateBrandWithProducts();

        Map<AgreementDTO, OrderDTO> orderAgreementMap = obtainOrderAgreement(privateBrandDistributors.keySet());

        //here i have one order by agreement
        //then for each  agreement consult currency and group orders in map
        //for each entry in the map  send  process of posting the order
        //if each one of the orders per agreement are correctly posted then update agreement status to
        //posted
        Map<AgreementDTO, List<OrderDTO>> mapOrdersAgreement = obtainOrdersWithCurrencyByAgreement(orderAgreementMap);
        processAgreementOrderService.processAgrochemicalOrders(mapOrdersAgreement);
    }

    private Map<AgreementDTO, List<OrderDTO>> obtainOrdersWithCurrencyByAgreement(Map<AgreementDTO, OrderDTO> orderAgreementMap) {
        Map<AgreementDTO, List<OrderDTO>> mapOrdersAgreement = new HashMap<AgreementDTO, List<OrderDTO>>();
        for (AgreementDTO agreementDTO : orderAgreementMap.keySet()) {
            OrderDTO orderDTO = orderAgreementMap.get(agreementDTO);

            mapOrdersAgreement.put(agreementDTO, sendAgrochemicalPricesService.obtainOrderByCurrency(Arrays.asList(orderDTO)));
        }
        return mapOrdersAgreement;
    }

    private PriceGroupDTO obtainAgrochemicalPriceGroup() {
        PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode(PriceGroupEnum.AGROCHEMICAL.getCode());
        return priceGroupDTO;
    }

    private Map<AgreementDTO, OrderDTO> obtainOrderAgreement(Set<DistributorVO> privateBrandDistributors) {
        List<AgreementDTO> agreementDTOList = new ArrayList<AgreementDTO>();
        for (DistributorVO distributorVO : privateBrandDistributors) {
            try {
                agreementDTOList.addAll(agreementService.retrieveAgreementByParameters(getAgreement(), obtainDistributorConfigDTO(distributorVO)));
            } catch (AgreementRetrieveByParametersNotFoundException e) {
                log.error(e.getSuperMessage(), e);
            }
        }

        return obtainMapAgreementOrder(agreementDTOList);
    }

    private AgreementDTO getAgreement() {
        AgreementDTO agreementDTO = new AgreementDTO();
        agreementDTO.setStatus(StatusEnum.ACTIVE.getId());
        agreementDTO.setApproved(StatusEnum.APPROVED.getId());
        return agreementDTO;
    }

    private Map<AgreementDTO, OrderDTO> obtainMapAgreementOrder(List<AgreementDTO> agreementDTOList) {

        Map<AgreementDTO, OrderDTO> mapAgreementOrder = new HashMap<AgreementDTO, OrderDTO>();
        for (AgreementDTO agreementDTO : agreementDTOList) {
            mapAgreementOrder.put(agreementDTO, buildOrder(agreementDTO));
        }
        return mapAgreementOrder;
    }

    private OrderDTO buildOrder(AgreementDTO agreementDTO) {
        OrderDTO orderDTO = mapper.map(agreementDTO, OrderDTO.class);
        orderDTO.getDetail().add(obtainDetail(agreementDTO));
        orderDTO.setShipTo(agreementDTO.getDistributorConfig().getDistributor().getDistributorCode());
        orderDTO.setSoldTo(agreementDTO.getDistributorConfig().getDistributor().getDistributorCode());
        orderDTO.setPriceGroup(obtainAgrochemicalPriceGroup());
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code());
        return orderDTO;
    }

    private OrderDetailDTO obtainDetail(AgreementDTO agreementDTO) {
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getDescription());
        productDTO.setFamilyCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());
        productDTO.getListOfSku().addAll(mapper.mapList(MaterialSkuDTO.class, agreementDTO.getVolumeGoals()));
        productDTO.setCropCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());
        productDTO.setBrandCode(BrandEnum.MONSANTO.getId());
        orderDetailDTO.setProductDTO(productDTO);

        return orderDetailDTO;
    }

    private DistributorConfigDTO obtainDistributorConfigDTO(DistributorVO distributorVO) {
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode(distributorVO.getDistributorCode());
        //configDTO.setDistChCode(DistributionChannelEnum.WHOLESAL.getId());
        configDTO.setSalesDivCode(SalesDivisionEnum.AGROCHEMICALS.getCode());
        configDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        configDTO.setDistributor(distributorDTO);
        return configDTO;
    }

    private Map<DistributorVO, List<PrivateBrandDistributorVO>> obtainDistributorsPrivateBrandWithProducts() {
        Map<DistributorVO, List<PrivateBrandDistributorVO>> mapDistributorProducts = new HashMap<DistributorVO, List<PrivateBrandDistributorVO>>();
        List<DistributorVO> privateBrandDistributors = distributorRepository.findPrivateBrand();

        for (DistributorVO distributorVO : privateBrandDistributors) {

            if (!mapDistributorProducts.containsKey(distributorVO)) {
                mapDistributorProducts.put(distributorVO, new ArrayList<PrivateBrandDistributorVO>());
            }

            mapDistributorProducts.get(distributorVO).addAll(distributorVO.getPrivateBrandDistributorsByDistributorCode());
        }

        return mapDistributorProducts;
    }
}
