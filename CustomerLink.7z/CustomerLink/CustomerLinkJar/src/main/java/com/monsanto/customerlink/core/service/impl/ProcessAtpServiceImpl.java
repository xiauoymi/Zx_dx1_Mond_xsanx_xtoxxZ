package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.catalog.SubregionService;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpClient;
import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpResponseProcessor;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.SeasonRepository;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpExceptionException;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProcessAtpServiceImpl implements ProcessAtpService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private IncreaseDecreaseATPService increaseDecreaseATPService;
    private SubregionService subregionService;
    private PurchaseOrderService purchaseOrderService;
    private NotificationSender mailNotificationSender;
    private SendPricesService sendPricesService;
    private MailUtilService mailUtilService;
    private SeasonRepository seasonRepository;

    @Autowired
    public ProcessAtpServiceImpl(IncreaseDecreaseATPService increaseDecreaseATPService,
                                 SubregionService subregionService, PurchaseOrderService purchaseOrderService,
                                 NotificationSender mailNotificationSender, SendPricesService sendPricesService,
                                 MailUtilService mailUtilService, SeasonRepository seasonRepository) {
        this.increaseDecreaseATPService = increaseDecreaseATPService;
        this.subregionService = subregionService;
        this.purchaseOrderService = purchaseOrderService;
        this.mailNotificationSender = mailNotificationSender;
        this.sendPricesService = sendPricesService;
        this.mailUtilService = mailUtilService;
        this.seasonRepository = seasonRepository;
    }

    @Override
    public void processAtp() {
        Map<SubRegionDTO, SeasonVO> mapSubRegionSeason = loadSubregions();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();

        try {
            orderDTOList = loadAtp(mapSubRegionSeason, getJaxwsClientFactory());
        } catch (Exception e) {
            log.error(e.getMessage(), e); //error can be that sub region does not exist in both systems
            if (!(e instanceof InventoryAtpExceptionException)) {
                throw new RuntimeException(e.getMessage(), e);
            }
        }

        List<OrderDTO> filteredOrderDTOList = filterOrdersWithPurchaseOrder(orderDTOList);

        List<OrderDTO> currencyOrderDTOList = separateOrdersByCurrency(filteredOrderDTOList);

        for (OrderDTO orderDTO : currencyOrderDTOList) {
            try {
                increaseDecreaseATPService.runProcessChangeInATP(orderDTO);
            } catch (AtpOrderMissingArgumentsException e) {
                log.error(e.getSuperMessage(), e);
            } catch (CustomerLinkBusinessException e) {
                log.error(e.getSuperMessage(), e);
            }
        }
    }

    private List<OrderDTO> filterOrdersWithPurchaseOrder(List<OrderDTO> orderDTOList) {
        List<OrderDTO> filteredOrderDTOList = new ArrayList<OrderDTO>();
        for (OrderDTO orderDTO : orderDTOList) {
            try {
                validateExistPurchaseOrderApproved(orderDTO);
                filteredOrderDTOList.add(orderDTO);
            } catch (DistributorConfigNotFoundException e) {
                log.error(e.getSuperMessage(), e);
                sendNotification(orderDTO.getDistributorConfigDTO());
            } catch (SeasonNotFoundException e) {
                log.error(e.getSuperMessage(), e);
                sendNotification(orderDTO.getDistributorConfigDTO());
            } catch (PurchaseOrderApprovedNotFoundException e) {
                log.error(e.getSuperMessage(), e);
                sendNotification(orderDTO.getDistributorConfigDTO());
            } catch (RCDNotFoundException e) {
                log.error(e.getSuperMessage(), e);
                sendNotification(orderDTO.getDistributorConfigDTO());
            }
        }
        return filteredOrderDTOList;
    }

    private List<OrderDTO> separateOrdersByCurrency(List<OrderDTO> orderDTOList) {
        return sendPricesService.obtainOrderByCurrency(orderDTOList);
    }

    private void sendNotification(DistributorConfigDTO distributorConfigDTO) {
        Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, null);

        mailNotificationSender.send(getPurchasenotification().newNotification(distributorConfigDTO, parameters));

    }

    public NotificationType getPurchasenotification() {
        return NotificationType.PURCHASE_ORDER_WITHOUT_APPROVAL;
    }

    private void validateExistPurchaseOrderApproved(OrderDTO orderDTO) throws SeasonNotFoundException, DistributorConfigNotFoundException, PurchaseOrderApprovedNotFoundException, RCDNotFoundException {
        purchaseOrderService.validateExistPurchaseOrderApproved(orderDTO);
    }

    private Map<SubRegionDTO, SeasonVO> loadSubregions() {

        Map<SubRegionDTO, SeasonVO> mapRegionSeason = new HashMap<SubRegionDTO, SeasonVO>();
        List<SubRegionDTO> subRegionDTOList = this.subregionService.findAllSubregions();
        Date date = new Date();
        for (SubRegionDTO dto : subRegionDTOList) {
            SeasonVO season = seasonRepository.findActiveSeasonBySubRegionCodeAndDate(dto.getSubRegionCode(), date);
            if (season != null) {
                mapRegionSeason.put(dto, season);
            }
        }

        return mapRegionSeason;
    }

    public List<OrderDTO> loadAtp(Map<SubRegionDTO, SeasonVO> mapSubregionSeason, JAXWSClientFactory jaxwsClientFactory
    ) throws Exception {
        InventoryAtpRequestBuilder builder = new InventoryAtpRequestBuilder(
                mapSubregionSeason, CustomerLinkUtils.getFiscalYear(new Date()),
                false);
        JAXWSResponseProcessor responseProcessor = new InventoryAtpResponseProcessor();

        InventoryAtpClient client = new InventoryAtpClient(builder, responseProcessor,
                jaxwsClientFactory.getInventoryAtpPortType());
        return (List<OrderDTO>) client.execute();
    }

    public JAXWSClientFactory getJaxwsClientFactory() {
        return JAXWSClientFactoryImpl.getInstance();
    }

}
