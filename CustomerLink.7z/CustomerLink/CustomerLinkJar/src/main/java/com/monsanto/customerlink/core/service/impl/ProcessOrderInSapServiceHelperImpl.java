package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProcessOrderInSapServiceHelper;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProcessOrderInSapServiceHelperImpl implements ProcessOrderInSapServiceHelper {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private RegularAgrochemicalsService regularAgrochemicalsService;

    @Autowired
    public ProcessOrderInSapServiceHelperImpl(RegularAgrochemicalsService regularAgrochemicalsService) {
        this.regularAgrochemicalsService = regularAgrochemicalsService;
    }

    @Override
    public void filterMaterialsWithIncreaseQuantity(OrderDTO orderDTO,List<MaterialSkuDTO> materialsWithDifference){
        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            List<MaterialSkuDTO> filterListOfSku = new ArrayList<MaterialSkuDTO>();
            for(MaterialSkuDTO sku : orderDetailDTO.getProductDTO().getListOfSku()) {
                for(MaterialSkuDTO skuIncreased : materialsWithDifference) {
                    if(skuIncreased.getMaterial().equals(sku.getMaterial())) {
                        sku.setUnrestqty(skuIncreased.getUnrestqty());
                        filterListOfSku.add(sku);
                        break;
                    }
                }
            }
            orderDetailDTO.getProductDTO().setListOfSku(filterListOfSku);
        }
    }

    @Override
    public boolean updateAgrochemicalOrderOnSAP(OrderDTO orderDTO, SAPOrderDTO sapOrderDTO) {
        boolean updated = true;
        try {
            orderDTO.setOrderIdSAP(sapOrderDTO.getSalesorder());
            regularAgrochemicalsService.processAgrochemicalsOrder(orderDTO,true);
        } catch (CustomerLinkBusinessException e) {
            log.error(e.getSuperMessage(), e);
            updated = false;
        }
        return updated;
    }
}