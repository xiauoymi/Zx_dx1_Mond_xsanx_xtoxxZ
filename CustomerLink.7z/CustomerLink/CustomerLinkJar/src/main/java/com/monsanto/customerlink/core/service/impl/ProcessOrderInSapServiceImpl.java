package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.ProcessOrderInSapService;
import com.monsanto.customerlink.core.service.ProcessOrderInSapServiceHelper;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProcessOrderInSapServiceImpl implements ProcessOrderInSapService {

    private Mapper mapper;
    private ProcessOrderInSapServiceHelper helper;

    @Autowired
    public ProcessOrderInSapServiceImpl(Mapper mapper, ProcessOrderInSapServiceHelper helper) {
        this.mapper = mapper;
        this.helper = helper;
    }

    public boolean processOrdersWithSapOrder(Map<OrderDTO, SAPOrderDTO> mapAllOrdersSapOrder, AgreementDTO agreementDTO) {
        boolean completeUpdate = true;
        Map<OrderDTO, SAPOrderDTO> mapOrdersWithSapOrder = obtainOrderWitOrderInsap(mapAllOrdersSapOrder);

        if(!mapOrdersWithSapOrder.isEmpty()) {
            int totalSuccessUpdate = 0;
            for (OrderDTO orderDTO : mapOrdersWithSapOrder.keySet()) {
                SAPOrderDTO sapOrderDTO = mapOrdersWithSapOrder.get(orderDTO);
                List<MaterialSkuDTO> materialsWithDifference = obtainMaterialsWithDifferenceByOrder(orderDTO, sapOrderDTO);
                if (!materialsWithDifference.isEmpty()) {//exist increase materials?
                    helper.filterMaterialsWithIncreaseQuantity(orderDTO,materialsWithDifference);
                    if(helper.updateAgrochemicalOrderOnSAP(orderDTO,sapOrderDTO)) {
                        totalSuccessUpdate++;
                    }
                }
            }
            completeUpdate = totalSuccessUpdate == mapOrdersWithSapOrder.values().size();// total orders was updated successfully?
        }

        return completeUpdate;
    }

    private Map<OrderDTO, SAPOrderDTO> obtainOrderWitOrderInsap(Map<OrderDTO, SAPOrderDTO> mapOrderSapOrder) {
        Map<OrderDTO, SAPOrderDTO> mapOrdersWithSapOrder = new HashMap<OrderDTO, SAPOrderDTO>();

        for (OrderDTO orderDTO : mapOrderSapOrder.keySet()) {
            SAPOrderDTO sapOrderDTO = mapOrderSapOrder.get(orderDTO);
            if (sapOrderDTO != null) {
                mapOrdersWithSapOrder.put(orderDTO, sapOrderDTO);
            }
        }
        return mapOrdersWithSapOrder;
    }

    public NotificationType getAgrochemicalDifferencesNotificationType() {
        return NotificationType.AGREEMENT_DIFFERENCES_IN_ORDER;
    }

    /**
     * To know if there are differences between  the posted order and the order contained in the agreement
     * return list  of MaterialSkuDto with the difference in quantity or if the material was not created  returns it
     *
     * @param orderDTO
     * @param sapOrderDTO
     */
    private List<MaterialSkuDTO> obtainMaterialsWithDifferenceByOrder(OrderDTO orderDTO, SAPOrderDTO sapOrderDTO) {
        List<MaterialSkuDTO> materialByOrder = obtainMaterialsOrder(orderDTO);
        List<MaterialDTO> materialsByOrderSap = obtainMaterialSapOrder(sapOrderDTO);

        List<MaterialSkuDTO> materialWithDifference = new ArrayList<MaterialSkuDTO>();
        for (MaterialSkuDTO materialSkuDTO : materialByOrder) {
            Double total = findDifferences(materialsByOrderSap, materialSkuDTO);
            if (total.doubleValue() > 0d) { // exist a positive delta difference?
                materialWithDifference.add(obtainNewMaterial(materialSkuDTO, total));
            }
        }
        return materialWithDifference;
    }

    private MaterialSkuDTO obtainNewMaterial(MaterialSkuDTO materialSkuDTO, Double total) {
        MaterialSkuDTO newMaterialSkuDTO = mapper.map(materialSkuDTO, MaterialSkuDTO.class);
        newMaterialSkuDTO.setUnrestqty(total);
        return newMaterialSkuDTO;
    }

    private Double findDifferences(List<MaterialDTO> materialsByOrderSap, MaterialSkuDTO materialSkuDTO) {
        Double total = 0d;
        for (MaterialDTO materialDTO : materialsByOrderSap) {
            if (materialDTO.getMaterial().contains(materialSkuDTO.getMaterial())) {
                total = materialSkuDTO.getUnrestqty() - materialDTO.getReq_qty();
                break;
            }
        }
        return total;
    }

    private List<MaterialDTO> obtainMaterialSapOrder(SAPOrderDTO sapOrderDTO) {
        Map<String,MaterialDTO> mapMaterials = new HashMap<String, MaterialDTO>();
        for (HybridDTO hybridDTO : sapOrderDTO.getHybrids()) {
            for(MaterialDTO m : hybridDTO.getSkus()){
                MaterialDTO sumOfMaterial = mapMaterials.get(m.getMaterial());
                if(null == sumOfMaterial) {
                    sumOfMaterial = new MaterialDTO();
                    sumOfMaterial.setMaterial(m.getMaterial());
                    sumOfMaterial.setReq_qty(Double.valueOf(0));
                }
                sumOfMaterial.setReq_qty(sumOfMaterial.getReq_qty().doubleValue() + m.getReq_qty());
                mapMaterials.put(m.getMaterial(),sumOfMaterial);
            }
        }
        return new ArrayList<MaterialDTO>(mapMaterials.values());
    }

    private List<MaterialSkuDTO> obtainMaterialsOrder(OrderDTO orderDTO) {
        List<MaterialSkuDTO> materialByOrder = new ArrayList<MaterialSkuDTO>();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            materialByOrder.addAll(orderDetailDTO.getProductDTO().getListOfSku());
        }

        return materialByOrder;
    }
}
