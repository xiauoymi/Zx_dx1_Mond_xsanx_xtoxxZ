package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProcessOrderNotInSapService;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.StatusEnum;
import com.monsanto.customerlink.persistence.entities.AgreementVO;
import com.monsanto.customerlink.persistence.repositories.AgreementRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ProcessOrderNotInSapServiceImpl implements ProcessOrderNotInSapService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private AgreementRepository agreementRepository;
    private RegularAgrochemicalsService regularAgrochemicalsService;

    @Autowired
    public ProcessOrderNotInSapServiceImpl(
            AgreementRepository agreementRepository,
            RegularAgrochemicalsService regularAgrochemicalsService) {
        this.agreementRepository = agreementRepository;
        this.regularAgrochemicalsService = regularAgrochemicalsService;
    }


    @Override
    public boolean processOrdersWithoutSapOrder(Map<OrderDTO, SAPOrderDTO> mapOrderSapOrder, AgreementDTO agreementDTO) {
        boolean completeUpdate = true;
        Map<OrderDTO, SAPOrderDTO> mapOrdersWithoutSapOrder = obtainOrderWithoutOrderInsap(mapOrderSapOrder);
        if(CollectionUtils.isNotEmpty(mapOrdersWithoutSapOrder.values())) {
            int ordersWithError = sendOrders(mapOrdersWithoutSapOrder);
            completeUpdate = ordersWithError == 0;
        }
        return completeUpdate;
    }

    @Override
    public void changeAgreementStatusToPosted(AgreementDTO agreementDTO) {
        AgreementVO agreementVO = agreementRepository.findOne(agreementDTO.getAgreementId());
        agreementVO.setStatus(StatusEnum.POSTED.getId());
        agreementRepository.save(agreementVO);
    }

    private int sendOrders(Map<OrderDTO, SAPOrderDTO> mapOrdersWithoutSapOrder) {
        int ordersWithError = 0;
        for (OrderDTO orderDTO : mapOrdersWithoutSapOrder.keySet()) {
            try {
                regularAgrochemicalsService.processAgrochemicalsOrder(orderDTO,false);//runProcessAgrochemicalsOrder
            } catch (CustomerLinkBusinessException e) {
                log.error(e.getSuperMessage(), e);
                ordersWithError++;
            }
        }

        return ordersWithError;
    }

    private Map<OrderDTO, SAPOrderDTO> obtainOrderWithoutOrderInsap(Map<OrderDTO, SAPOrderDTO> mapOrderSapOrder) {
        Map<OrderDTO, SAPOrderDTO> mapOrdersWithoutSapOrder = new HashMap<OrderDTO, SAPOrderDTO>();

        for (OrderDTO orderDTO : mapOrderSapOrder.keySet()) {
            SAPOrderDTO sapOrderDTO = mapOrderSapOrder.get(orderDTO);
            if (!existOrderInSap(sapOrderDTO)) {
                mapOrdersWithoutSapOrder.put(orderDTO, sapOrderDTO);
            }
        }
        return mapOrdersWithoutSapOrder;
    }

    private boolean existOrderInSap(SAPOrderDTO sapOrderDTO) {
        return (sapOrderDTO != null);
    }

}
