package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProductService;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private Mapper mapper;

    public List<ProductDTO> getProductsByParameters(String salesDivision, String subSalesDivision,
                                                    String privateBrandDistributor, List<String> productCodes,
                                                    Boolean isByhHybrid) {
        return mapper.mapList(ProductDTO.class, productRepository.findByParameters(salesDivision, subSalesDivision,
                privateBrandDistributor, productCodes, isByhHybrid));
    }
}