package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.PurchaseOrderServiceHelper;
import com.monsanto.customerlink.core.service.util.RepresentativeUtils;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.PurchaseOrderVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.PurchaseOrderRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class PurchaseOrderServiceHelperImpl implements PurchaseOrderServiceHelper {

    private PurchaseOrderRepository purcharseOrderRepository;

    @Autowired
    public PurchaseOrderServiceHelperImpl(PurchaseOrderRepository purcharseOrderRepository) {
        this.purcharseOrderRepository = purcharseOrderRepository;
    }

    @Override
    public Collection<PurchaseOrderVO> obtainPurchaseOrderByParameters(SeasonVO seasonVo, DistributorProfileVO distvo, RepresentativeDTO representative) {
        Collection<PurchaseOrderVO> purcharseOrderVO;
        if(RepresentativeUtils.isAvailableRCD(representative)) {
            purcharseOrderVO = this.purcharseOrderRepository.findByDistributorProfileAndSeasonAndRCD(distvo.getDistributorProfileId(), seasonVo.getSeasonId(),representative.getSapUserId());
        }else{
            purcharseOrderVO = this.purcharseOrderRepository.findByDistributorProfileAndSeason(distvo.getDistributorProfileId(), seasonVo.getSeasonId());
        }

        return purcharseOrderVO;
    }
}