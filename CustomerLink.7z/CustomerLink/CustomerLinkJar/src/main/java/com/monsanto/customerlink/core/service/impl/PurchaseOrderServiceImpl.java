package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.PurchaseOrderService;
import com.monsanto.customerlink.core.service.PurchaseOrderServiceHelper;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurcharseOrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderEmailDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

@Service("purchaseOrderBusiness")
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

    private PurchaseOrderRepository purcharseOrderRepository;
    private SeasonRepository seasonRepository;
    private PurchaseOrderDetailRepository purchaseOrderDetailRepository;
    private PurchaseOrderEmailRepository purchaseOrderEmailRepository;
    private Mapper mapper;
    private MailUtilService mailUtilService;
    private NotificationSender mailNotificationSender;
    private PurchaseOrderServiceHelper purchaseOrderServiceHelper;
    private DistributorService distributorService;

    @Autowired
    public PurchaseOrderServiceImpl(PurchaseOrderRepository purcharseOrderRepository, Mapper mapper,
                                    SeasonRepository seasonRepository, PurchaseOrderDetailRepository purchaseOrderDetailRepository,
                                    PurchaseOrderEmailRepository purchaseOrderEmailRepository,
                                    MailUtilService mailUtilService,
                                    NotificationSender mailNotificationSender,
                                    PurchaseOrderServiceHelper purchaseOrderServiceHelper,
                                    DistributorService distributorService) {
        this.purcharseOrderRepository = purcharseOrderRepository;
        this.mapper = mapper;
        this.seasonRepository = seasonRepository;
        this.purchaseOrderDetailRepository = purchaseOrderDetailRepository;
        this.purchaseOrderEmailRepository = purchaseOrderEmailRepository;
        this.mailUtilService = mailUtilService;
        this.mailNotificationSender = mailNotificationSender;
        this.purchaseOrderServiceHelper = purchaseOrderServiceHelper;
        this.distributorService = distributorService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public List<PurcharseOrderDTO> retrievePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO)
            throws PurchaseOrderNotFoundException {
        Collection<PurchaseOrderVO> voList = findPurchaseOrders(purcharseOrderDTO);

        //obtain detail and mails for each purchase order founded
        setMailsAndDetails(voList);

        List<PurcharseOrderDTO> purcharseOrderDTOList = obtainPurchaseDTO(voList);

        //order detail by crop
        sortDetailsForEachPurchaseOrder(purcharseOrderDTOList);

        return purcharseOrderDTOList;
    }

    private void sortDetailsForEachPurchaseOrder(List<PurcharseOrderDTO> purcharseOrderDTOList) {
        //order detail by crop
        for (PurcharseOrderDTO dto : purcharseOrderDTOList) {

            Collections.sort(dto.getPurchaseOrderDetailsByPurchaseOrderId(), new Comparator<PurchaseOrderDetailDTO>() {
                @Override
                public int compare(PurchaseOrderDetailDTO o1, PurchaseOrderDetailDTO o2) {
                    return o1.getCrop().compareTo(o2.getCrop());
                }
            });
        }
    }

    private void setMailsAndDetails(Collection<PurchaseOrderVO> voList) {
        for (PurchaseOrderVO orderVO : voList) {
            List<PurchaseOrderDetailVO> purchaseOrderDetailVOs = purchaseOrderDetailRepository.findByPurchaseOrder(orderVO);
            orderVO.setPurchaseOrderDetailsByPurchaseOrderId(purchaseOrderDetailVOs);

            List<PurchaseOrderEmailVO> emailVOList = purchaseOrderEmailRepository.findByPurchaseOrder(orderVO);
            orderVO.setPurchaseOrderEmailsByPurchaseOrderId(emailVOList);
        }
    }

    private Collection<PurchaseOrderVO> findPurchaseOrders(PurcharseOrderDTO purcharseOrderDTO) {

        if (consultEspecificPurchase(purcharseOrderDTO)) {
            return consultOnePurchaseOrder(purcharseOrderDTO);
        }
        return findByParameters(purcharseOrderDTO);
    }

    private Collection<PurchaseOrderVO> findByParameters(PurcharseOrderDTO purcharseOrderDTO) {
        return purcharseOrderRepository.findByParameters(
                getParameter(purcharseOrderDTO.getApproved()),
                getParameter(purcharseOrderDTO.getStatus()),
                getDistributorCode(purcharseOrderDTO.getDistributor()),
                getParameter(purcharseOrderDTO.getSubRegionCode()), new Date());
    }

    private Collection<PurchaseOrderVO> consultOnePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO) {
        Collection<PurchaseOrderVO> voList = new ArrayList<PurchaseOrderVO>();
        voList.add(purcharseOrderRepository.findOne(purcharseOrderDTO.getPurchaseOrderId()));
        return voList;
    }

    private boolean consultEspecificPurchase(PurcharseOrderDTO purcharseOrderDTO) {
        return purcharseOrderDTO.getPurchaseOrderId()!=null && purcharseOrderDTO.getPurchaseOrderId() > 0;
    }

    private List<PurcharseOrderDTO> obtainPurchaseDTO(Collection<PurchaseOrderVO> voList) {
        List<PurcharseOrderDTO> purcharseOrderDTOList = new ArrayList<PurcharseOrderDTO>();
        for (PurchaseOrderVO vo : voList) {
            DistributorConfigDTO distributorConfDTO = mapper.map(vo.getDistributorProfileByDistributorProfileId(), DistributorConfigDTO.class);
            DistributorDTO distributorDTO = mapper.map(vo.getDistributorProfileByDistributorProfileId().getDistributorByDistributorCode(), DistributorDTO.class);
            distributorConfDTO.setDistributor(distributorDTO);

            PurcharseOrderDTO dto = mapper.map(vo, PurcharseOrderDTO.class);

            dto.setDistributor(distributorConfDTO);

            purcharseOrderDTOList.add(dto);
        }
        return purcharseOrderDTOList;
    }

    @Override
    @Transactional
    public PurcharseOrderDTO createPurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO) throws PurchaseOrderWithoutDetailException, SeasonNotFoundException,
            DistributorConfigNotFoundException, PurchaseorderAlreadyExistException {

        validatePurchaseorderToCreate(purcharseOrderDTO, distributorConfigDTO);

        SeasonVO seasonVo = this.retrieveSeason(distributorConfigDTO.getSubRegionCode());

        DistributorProfileVO distvo = distributorService.retrieveDistributorConfigByConfig(distributorConfigDTO);

        PurchaseOrderVO purcharseOrderVO =
                this.verifyExistPurchaseOrderWithoutStatusDeleted(seasonVo, distvo, distributorConfigDTO, purcharseOrderDTO.getRepresentative());

        purcharseOrderVO = this.purcharseOrderRepository.save(purcharseOrderVO);
        purcharseOrderDTO.setPurchaseOrderId(purcharseOrderVO.getPurchaseOrderId());
        saveOrUpdatePurchaseOrderDetail(purcharseOrderDTO, purcharseOrderVO);
        saveUpdatePurchaseOrderDetailMail(purcharseOrderDTO, purcharseOrderVO);
        purcharseOrderDTO.setSeasonCode(purcharseOrderVO.getSeasonBySeasonId().getSeasonTypeBySeasonTypeId().getSeasonTypeCode());

        final Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, null);
        parameters.put("currentDate", CustomerLinkUtils.SDF_DDMMYYYY.format(new Date()));
        parameters.put("purchaseOrderId", purcharseOrderVO.getPurchaseOrderId());
        mailNotificationSender.send(NotificationType.PURCHASE_ORDER_TO_APPROVE.newNotification(distributorConfigDTO, parameters));

        return purcharseOrderDTO;
    }

    @Override
    public PurcharseOrderDTO deletePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO)
            throws PurchaseOrderNotFoundException, SeasonNotFoundException, DistributorConfigNotFoundException {

        PurchaseOrderVO vo = this.obtainPurchaseOrder(purcharseOrderDTO, distributorConfigDTO);

        vo.setStatus(PurchaseOrderStatusEnum.STATUS_DELETED.getStatus());

        this.purcharseOrderRepository.save(vo);
        purcharseOrderDTO.setPurchaseOrderId(vo.getPurchaseOrderId());

        return purcharseOrderDTO;
    }

    @Override
    public PurcharseOrderDTO updatePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO)
            throws PurchaseOrderNotFoundException, SeasonNotFoundException, DistributorConfigNotFoundException {

        PurchaseOrderVO vo = this.obtainPurchaseOrder(purcharseOrderDTO, distributorConfigDTO);

        vo.setApproved(purcharseOrderDTO.getApproved());
        vo.setStatus(purcharseOrderDTO.getStatus());

        vo.setUpdateDate(new Timestamp(new Date().getTime()));

        vo = this.purcharseOrderRepository.save(vo);

        saveOrUpdatePurchaseOrderDetail(purcharseOrderDTO, vo);
        saveUpdatePurchaseOrderDetailMail(purcharseOrderDTO, vo);
        purcharseOrderDTO.setSeasonCode(vo.getSeasonBySeasonId().getSeasonTypeBySeasonTypeId().getSeasonTypeCode());

        purcharseOrderDTO.setPurchaseOrderId(vo.getPurchaseOrderId());

        return purcharseOrderDTO;
    }

    @Override
    public void validateExistPurchaseOrderApproved(OrderDTO orderDTO) throws SeasonNotFoundException,
            DistributorConfigNotFoundException, PurchaseOrderApprovedNotFoundException {
        validateParametersPurchaseorder(orderDTO.getDistributorConfigDTO());
        retrieveSeason(orderDTO.getDistributorConfigDTO().getSubRegionCode());
        distributorService.retrieveDistributorConfigByConfig(orderDTO.getDistributorConfigDTO());

        final PurcharseOrderDTO parameters = mapper.map(orderDTO, PurcharseOrderDTO.class);
        parameters.setApproved(PurchaseOrderStatusEnum.APPROVAL_APPROVED.getStatus());
        parameters.setStatus(1L);

        final List<PurchaseOrderVO> purchaseOrders = purcharseOrderRepository.findByParametersAndCurrentSeasonActive(parameters);
        if (purchaseOrders.isEmpty()) {
            throw new PurchaseOrderApprovedNotFoundException(new Object[]{
                    orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode(),
                    orderDTO.getDistributorConfigDTO().getSalesOrgCode(),
                    orderDTO.getDistributorConfigDTO().getSubRegionCode(),
                    orderDTO.getDistributorConfigDTO().getSalesDivCode(),
                    orderDTO.getDistributorConfigDTO().getDistChCode()
            });
        }
    }

    @Override
    public void approvePurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO)
            throws SeasonNotFoundException, DistributorConfigNotFoundException, PurchaseOrderNotFoundException {

        PurchaseOrderVO vo = this.obtainPurchaseOrder(purcharseOrderDTO, distributorConfigDTO);

        vo.setApproved(PurchaseOrderStatusEnum.APPROVAL_APPROVED.getStatus());

        vo.setUpdateDate(new Timestamp(new Date().getTime()));

        vo = this.purcharseOrderRepository.save(vo);
    }


    private PurchaseOrderVO obtainPurchaseOrder(PurcharseOrderDTO purcharseOrderDTO, DistributorConfigDTO distributorConfigDTO) throws SeasonNotFoundException,
            DistributorConfigNotFoundException, PurchaseOrderNotFoundException {

        /*
        validateParametersPurchaseorder(distributorConfigDTO);

        SeasonVO seasonVo = this.retrieveSeason(distributorConfigDTO.getSubRegionCode());

        DistributorProfileVO distvo = distributorService.retrieveDistributorConfigByConfig(distributorConfigDTO);

        PurchaseOrderVO vo = purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(seasonVo, distvo, purcharseOrderDTO.getRepresentative());
         */

        PurchaseOrderVO vo = purcharseOrderRepository.findOne(purcharseOrderDTO.getPurchaseOrderId());

        if (vo == null) {
            throw new PurchaseOrderNotFoundException(new Object[]{
                    distributorConfigDTO.getDistributor().getDistributorCode(),
                    distributorConfigDTO.getSalesOrgCode(),
                    distributorConfigDTO.getSubRegionCode(),
                    distributorConfigDTO.getSalesDivCode(),
                    distributorConfigDTO.getDistChCode()
            });
        }
        return vo;
    }


    private PurchaseOrderVO verifyExistPurchaseOrderWithoutStatusDeleted(SeasonVO seasonVo, DistributorProfileVO distvo,
                                                                         DistributorConfigDTO distributorConfigDTO, RepresentativeDTO representative
    ) throws
            PurchaseorderAlreadyExistException {

        Collection<PurchaseOrderVO> pos = purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(seasonVo,distvo,representative);

        if(CollectionUtils.isNotEmpty(pos)) {
            for(PurchaseOrderVO po : pos) {
                if(PurchaseOrderStatusEnum.STATUS_ACTIVE.getStatus().equals(po.getStatus())) {
                    if(PurchaseOrderStatusEnum.APPROVAL_PENDING.getStatus().equals(po.getApproved())
                            || PurchaseOrderStatusEnum.APPROVAL_APPROVED.getStatus().equals(po.getApproved()) ) {
                        throw new PurchaseorderAlreadyExistException(new Object[]{
                                distributorConfigDTO.getDistributor().getDistributorCode(),
                                distributorConfigDTO.getSalesOrgCode(),
                                distributorConfigDTO.getSubRegionCode(),
                                distributorConfigDTO.getSalesDivCode(),
                                distributorConfigDTO.getDistChCode()
                        });
                    }
                }

            }
        }

        PurchaseOrderVO purcharseOrderVO = new PurchaseOrderVO();
        purcharseOrderVO.setStatus(PurchaseOrderStatusEnum.STATUS_ACTIVE.getStatus());
        purcharseOrderVO.setApproved(PurchaseOrderStatusEnum.APPROVAL_PENDING.getStatus());
        Timestamp time = new Timestamp(new Date().getTime());
        purcharseOrderVO.setCreateDate(time);
        purcharseOrderVO.setUpdateDate(time);
        purcharseOrderVO.setDistributorProfileByDistributorProfileId(distvo);
        purcharseOrderVO.setSeasonBySeasonId(seasonVo);
        purcharseOrderVO.setRcdSAPCode(RepresentativeUtils.isAvailableRCD(representative)?representative.getSapUserId():null);

        return purcharseOrderVO;
    }

    private void saveOrUpdatePurchaseOrderDetail(PurcharseOrderDTO purcharseOrderDTO, PurchaseOrderVO purcharseOrderVO) {

        for (PurchaseOrderDetailDTO detailDTO : purcharseOrderDTO.getPurchaseOrderDetailsByPurchaseOrderId()) {

            PurchaseOrderDetailVO detailVO = new PurchaseOrderDetailVO();

            if (detailDTO.getOrderDetailPurchaseId() != 0) {
                detailVO.setOrderDetailPurchaseId(detailDTO.getOrderDetailPurchaseId());
            }

            detailVO.setPurchaseOrder(purcharseOrderVO);
            detailVO.setCrop(detailDTO.getCrop());
            detailVO.setHybrid(detailDTO.getHybrid());
            detailVO.setPresentation(detailDTO.getPresentation());
            detailVO.setSacks(detailDTO.getSacks());
            detailVO.setUnits(detailDTO.getUnits());
            this.purchaseOrderDetailRepository.save(detailVO);
        }
    }

    private void saveUpdatePurchaseOrderDetailMail(PurcharseOrderDTO purcharseOrderDTO, PurchaseOrderVO purcharseOrderVO) {

        for (PurchaseOrderEmailDTO emailDTO : purcharseOrderDTO.getPurchaseOrderEmailsByPurchaseOrderId()) {

            PurchaseOrderEmailVO mailVO = new PurchaseOrderEmailVO();

            if (emailDTO.getOrderEmailPurchaseId() != 0) {
                mailVO.setOrderEmailPurchaseId(emailDTO.getOrderEmailPurchaseId());
            }
            mailVO.setPurchaseOrder(purcharseOrderVO);
            mailVO.setEmail(emailDTO.getEmail());
            this.purchaseOrderEmailRepository.save(mailVO);
        }
    }

    private void validatePurchaseorderToCreate(PurcharseOrderDTO purcharseOrderDTO,
                                               DistributorConfigDTO distributorConfigDTO)
            throws PurchaseOrderWithoutDetailException {

        if (purcharseOrderDTO.getPurchaseOrderDetailsByPurchaseOrderId().isEmpty()) {
            throw new PurchaseOrderWithoutDetailException(new Object[]{
                    distributorConfigDTO.getDistributor().getDistributorCode(),
                    distributorConfigDTO.getSalesOrgCode(),
                    distributorConfigDTO.getSubRegionCode(),
                    distributorConfigDTO.getSalesDivCode(),
                    distributorConfigDTO.getDistChCode()
            });
        }

        validateParametersPurchaseorder(distributorConfigDTO);
    }

    private void validateParametersPurchaseorder(
            DistributorConfigDTO distributorConfigDTO) {
        CustomerLinkUtils.checkDistributorProfileArgument(distributorConfigDTO);
    }

    private SeasonVO retrieveSeason(String subregionCode)
            throws SeasonNotFoundException {

        SeasonVO seasonVO = this.seasonRepository.findActiveSeasonBySubRegionCodeAndDate(
                subregionCode, new Date());

        if (seasonVO == null) {
            throw new SeasonNotFoundException(new Object[]{subregionCode});
        }

        return seasonVO;
    }

    private Long getParameter(Long param) {
        if (param == null || param.equals(0l)) {
            return -1l;
        }
        return param;
    }

    private String getParameter(String param) {
        if (StringUtils.isEmpty(param)) {
            return "-1";
        }
        return param;
    }

    private String getDistributorCode(DistributorConfigDTO configDTO) {
        if (configDTO != null && configDTO.getDistributor() != null && !StringUtils.isEmpty(configDTO.getDistributor().getDistributorCode())) {
            return configDTO.getDistributor().getDistributorCode();
        }
        return "-1";
    }

}
