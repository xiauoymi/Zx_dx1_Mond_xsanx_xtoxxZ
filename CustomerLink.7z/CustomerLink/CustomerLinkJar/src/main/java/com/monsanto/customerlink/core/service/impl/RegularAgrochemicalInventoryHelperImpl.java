package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.InventoryHelper;
import com.monsanto.customerlink.core.service.RegularAgrochemicalInventoryHelper;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper;
import com.monsanto.customerlink.core.service.SAPOrderService;
import com.monsanto.customerlink.core.service.exception.AgrochemicalCreateOrderErrorException;
import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderInventoryNotFoundException;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class RegularAgrochemicalInventoryHelperImpl implements RegularAgrochemicalInventoryHelper {

    private Mapper mapper;
    private RegularAgrochemicalsHelper regularAgrochemicalsHelper;
    private SAPOrderService sapOrderService;
    private InventoryHelper inventoryHelper;

    @Autowired
    public RegularAgrochemicalInventoryHelperImpl(RegularAgrochemicalsHelper regularAgrochemicalsHelper, Mapper mapper
                                                    , SAPOrderService sapOrderService, InventoryHelper inventoryHelper) {
        this.regularAgrochemicalsHelper = regularAgrochemicalsHelper;
        this.mapper = mapper;
        this.sapOrderService = sapOrderService;
        this.inventoryHelper = inventoryHelper;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalInventoryHelper#assignInventoryAgrochemicalOrder(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO, java.util.List, java.util.List)
     */
    public void assignInventoryAgrochemicalOrder(OrderDTO orderDTO, List<AgrochemicalMaterialDTO> inventory,
                                                List<ErrorOrderDTO> errors) throws CustomerLinkBusinessException {

        List<PlantVO> configuredPlants = regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(orderDTO);

        for(AgrochemicalMaterialDTO am : inventory ) {
            assignPlantPriority(am,configuredPlants);
        }

        List<MaterialDTO> materialsToAllocate = new ArrayList<MaterialDTO>();

        for(MaterialSkuDTO sku : orderDTO.getDetail().get(0).getProductDTO().getListOfSku()) {
            materialsToAllocate = allocateInventoryByMaterial(orderDTO,sku, inventory, materialsToAllocate,errors);
        }

        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(obtainListOfMaterialSkuToCreateOrder(materialsToAllocate));

        SAPOrderDTO sapOrder = sapOrderService.postOrderWithoutAlgorithm(orderDTO);

        if (sapOrder.getErrors().isEmpty()) {
            inventoryHelper.sendNotification(sapOrder, new ArrayList<InventoryInDTO>(), new ArrayList<OrderDetailDTO>(),
                    null, NotificationType.ORDER_CREATED, orderDTO.getDistributorConfigDTO());
        } else {
            // notify error on create order
            inventoryHelper.sendNotification(sapOrder.getErrors(), NotificationType.ORDER_POSTED_WITH_ERROR, orderDTO.getDistributorConfigDTO());

            throw new AgrochemicalCreateOrderErrorException(
                new Object[]{
                        ToStringBuilder.reflectionToString(orderDTO.getDistributorConfigDTO()),
                        ToStringBuilder.reflectionToString(orderDTO.getDistributorConfigDTO().getDistributor())});

        }

    }

    public void assignPlantPriority(AgrochemicalMaterialDTO am, List<PlantVO> configuredPlants) {

        // for each plant from inventory, assign priority.
        for(AgrochemicalPlantDTO plant : am.getListOfPlants()) {
            for(PlantVO p : configuredPlants) {
                if(plant.getPlant().equals(p.getPlantCode())) {
                    plant.setPriority(p.getPriority());
                    break;
                }
            }
        }

        // sort plants in ascending order
        Collections.sort(am.getListOfPlants());
    }

    public List<MaterialDTO> allocateInventoryByMaterial(OrderDTO orderDTO,MaterialSkuDTO sku,
                                                         List<AgrochemicalMaterialDTO> inventory,
                                                         List<MaterialDTO> materialsToAllocate,
                                                         List<ErrorOrderDTO> errors) throws AgrochemicalOrderInventoryNotFoundException {
        Double quantity;

        AgrochemicalMaterialDTO inv =  this.obtainInventoryByMaterial(sku.getMaterial(), inventory);

        if (inv != null) {

            quantity = allocateTotalInventoryInPlantWithMoreInventoryAvailable(sku, inv, materialsToAllocate);

            // valid if it was possible to allocate the entire amount on one plant
            if(quantity.doubleValue() > 0) {

                quantity = allocateTotalInventoryInVariousPlants(sku,inv,materialsToAllocate, quantity);

                // valid if it was possible to allocate the entire amount in various plants
                if(quantity.doubleValue() > 0) {
                    notifyInventoryNotFound(orderDTO,errors);
                }
            }
        }else {
            notifyInventoryNotFound(orderDTO,errors);
        }

        return materialsToAllocate;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalInventoryHelper#notifyInventoryNotFound(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO, java.util.List)
     */
    public void notifyInventoryNotFound(OrderDTO orderDTO, List<ErrorOrderDTO> errors) throws AgrochemicalOrderInventoryNotFoundException {

        regularAgrochemicalsHelper.sendMessageMissingInventory(orderDTO.getDetail().get(0).getProductDTO().getListOfSku(),orderDTO.getDistributorConfigDTO(),errors);

        throw new AgrochemicalOrderInventoryNotFoundException(
                new Object[]{
                        ToStringBuilder.reflectionToString(orderDTO.getDistributorConfigDTO()),
                        ToStringBuilder.reflectionToString(orderDTO.getDistributorConfigDTO().getDistributor())});
    }

    public List<MaterialSkuDTO> obtainListOfMaterialSkuToCreateOrder(List<MaterialDTO> materialsToAllocate) {

        List<MaterialSkuDTO> materialsList;

        Long id = CustomerLinkCoreConstants.MATERIAL_UNITS_INCREASE;

        for (MaterialDTO m : materialsToAllocate) {
            m.setItemNumber(id);
            id += CustomerLinkCoreConstants.MATERIAL_UNITS_INCREASE;
        }

        // assignment is performed with material quantity, plant, storage location and batch.
        materialsList = mapper.mapList(MaterialSkuDTO.class, materialsToAllocate);

        for (MaterialSkuDTO materialSku : materialsList) {
            // is assigned the status "Insert"
            materialSku.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        }

        return materialsList;
    }

    public AgrochemicalMaterialDTO obtainInventoryByMaterial(String material, List<AgrochemicalMaterialDTO> inventory) {

        AgrochemicalMaterialDTO agrochemicalMaterialDTO = null;

        for(AgrochemicalMaterialDTO am: inventory) {
            if(am.getMaterial().contains(material)) {  //RBUCI Here we make the comparison with contains function because the materials from service response comes with all zeros
                //TODO use wava or apache utils to complete or cut zeros at left
                agrochemicalMaterialDTO = am;
                break;
            }
        }

        return agrochemicalMaterialDTO;
    }

    public Double allocateTotalInventoryInPlantWithMoreInventoryAvailable(MaterialSkuDTO sku, AgrochemicalMaterialDTO inv, List<MaterialDTO> materialsToAllocate) {

        Double quantity = sku.getUnrestqty();

        for (AgrochemicalPlantDTO plant :  inv.getListOfPlants()) {

            Double difference = quantity.doubleValue() - plant.getTotalQty().doubleValue();

            if (difference <= 0) {
                materialsToAllocate = assigningRemainingAmountOfPlant(sku.getMaterial(),materialsToAllocate,plant,quantity);
                quantity = 0D;
                break;
            }

        }

        return quantity;
    }

    public Double allocateTotalInventoryInVariousPlants(MaterialSkuDTO sku, AgrochemicalMaterialDTO inv, List<MaterialDTO> materialsToAllocate, Double quantity) {

        for (AgrochemicalPlantDTO plant :  inv.getListOfPlants()) {

            if (quantity == 0) {
                break;
            }

            Double difference = quantity.doubleValue() - plant.getTotalQty().doubleValue();

            if (difference >= 0) {
                materialsToAllocate = assignEntirePlant(sku.getMaterial(),materialsToAllocate,plant);
                quantity = difference;
            } else {
                materialsToAllocate = assigningRemainingAmountOfPlant( sku.getMaterial(), materialsToAllocate, plant, new Double(quantity.doubleValue()));
                quantity = 0D;
            }

        }

        return quantity;
    }


    public List<MaterialDTO> assignEntirePlant(String material, List<MaterialDTO> materialsToAllocate, AgrochemicalPlantDTO plant) {

        for(AgrochemicalWareHouseDTO wh : plant.getWarehouses().values() ) {

            MaterialDTO m = new MaterialDTO();
            m.setMaterial(material);
            m.setPlant(plant.getPlant());
            m.setStoragelocation(wh.getStoragelocation());
            m.setUnrestqty(wh.getPartialQty());

            // in agrochemicals the batch is not required
            m.setBatch(CustomerLinkCoreConstants.BLANK_VALUE);

            materialsToAllocate.add(m);
        }

        return materialsToAllocate;
    }

    public List<MaterialDTO> assigningRemainingAmountOfPlant(String material, List<MaterialDTO> materialsToAllocate, AgrochemicalPlantDTO plant, Double quantityToAssign) {

        for(AgrochemicalWareHouseDTO wh : plant.getWarehouses().values() ) {

            if(quantityToAssign == 0) {
                break;
            }

            Double difference = quantityToAssign.doubleValue() -  wh.getPartialQty().doubleValue();

            MaterialDTO m = new MaterialDTO();
            m.setMaterial(material);
            m.setPlant(plant.getPlant());
            m.setStoragelocation(wh.getStoragelocation());

            //in agrochemicals the batch is not required
            m.setBatch(CustomerLinkCoreConstants.BLANK_VALUE);

            if(difference >= 0 ) {
                m.setUnrestqty(wh.getPartialQty());
                quantityToAssign = difference;
            }else {
                m.setUnrestqty(BigDecimal.valueOf(quantityToAssign));
                quantityToAssign = 0D;
            }

            materialsToAllocate.add(m);
        }

        return materialsToAllocate;
    }

}
