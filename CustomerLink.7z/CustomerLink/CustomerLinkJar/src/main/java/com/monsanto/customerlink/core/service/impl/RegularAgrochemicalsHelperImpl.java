package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.email.dto.messages.MaterialMessageVO;
import com.monsanto.customerlink.core.email.dto.messages.MissingInventoryMessageVO;
import com.monsanto.customerlink.core.service.InventoryHelper;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper;
import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderPlantsNotFoundException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.persistence.entities.WarehouseVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class RegularAgrochemicalsHelperImpl implements RegularAgrochemicalsHelper {

    private MailUtilService mailUtilService;
    private InventoryHelper inventoryHelper;
    private PlantService plantService;

    @Autowired
    public RegularAgrochemicalsHelperImpl(InventoryHelper inventoryHelper,
                                          MailUtilService mailUtilService,
                                          PlantService plantService) {
        this.inventoryHelper = inventoryHelper;
        this.mailUtilService = mailUtilService;
        this.plantService = plantService;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper#createRequestInventory(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    public List<MaterialDTO> createRequestInventory(OrderDTO orderDTO) throws AgrochemicalOrderPlantsNotFoundException {

        List<MaterialDTO> materials = new ArrayList<MaterialDTO>();

         // retrieve list of plants to config
        List<PlantVO> plantList = obtainRegularAgrochemicalPlants(orderDTO);

        String altUom = CustomerLinkCoreConstants.ALTUOM;

        for(MaterialSkuDTO sku : orderDTO.getDetail().get(0).getProductDTO().getListOfSku()) {

            for (PlantVO plant : plantList) {

                if (!plant.getWarehousesByPlantId().isEmpty()) {

                    for (WarehouseVO w : plant.getWarehousesByPlantId()) {
                        MaterialDTO m = new MaterialDTO();
                        m.setMaterial(sku.getMaterial());
                        m.setUom(altUom);
                        m.setPlant(plant.getPlantCode());
                        m.setStoragelocation(w.getWarehouseCode());
                        materials.add(m);
                    }
                }
            }
        }

        return materials;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper#validateInputParametersForAgrochemicals(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    public void validateInputParametersForAgrochemicals(OrderDTO orderDTO) throws AgrochemicalOrderMissingArgumentsException {

        if(orderDTO==null) {
            throw new AgrochemicalOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
        }

        if(orderDTO.getDetail().isEmpty()) {
            throw new AgrochemicalOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
        }

        if(orderDTO.getDistributorConfigDTO() == null) {
            throw new AgrochemicalOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
        }

        if(orderDTO.getDetail().get(0).getProductDTO() == null) {
            throw new AgrochemicalOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
        }

        if(orderDTO.getDetail().get(0).getProductDTO().getListOfSku().isEmpty()) {
            throw new AgrochemicalOrderMissingArgumentsException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
        }

    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper#obtainRegularAgrochemicalPlants(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    public List<PlantVO> obtainRegularAgrochemicalPlants(OrderDTO orderDTO) throws AgrochemicalOrderPlantsNotFoundException {
        List<PlantVO> plantList = plantService.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode(),orderDTO.getDistributorConfigDTO());
        if(plantList.isEmpty()) {
            throw new AgrochemicalOrderPlantsNotFoundException(new Object[]{});
        }
        return plantList;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper#sendMessageMissingInventory(java.util.List, com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO, java.util.List)
     */
    public void sendMessageMissingInventory(List<MaterialSkuDTO> listOfSku,
                                                                 DistributorConfigDTO distributorConfigDTO,
                                                                 List<ErrorOrderDTO> listError) {

        Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, listError);

        MissingInventoryMessageVO msg = new MissingInventoryMessageVO();

        List<MaterialMessageVO> materials = new ArrayList<MaterialMessageVO>();

        for(MaterialSkuDTO sku : listOfSku) {
            MaterialMessageVO mm = new MaterialMessageVO();
            mm.setMaterial(sku.getMaterial());
            mm.setUnrestqty(sku.getUnrestqty());
            materials.add(mm);
        }
        msg.setMaterials(materials);

        parameters.put("msg", msg);

        inventoryHelper.sendMessage(NotificationType.MINIMUM_INVENTORY_REGULAR_AGROCHEMICALS_MX01,distributorConfigDTO,parameters);
    }

}