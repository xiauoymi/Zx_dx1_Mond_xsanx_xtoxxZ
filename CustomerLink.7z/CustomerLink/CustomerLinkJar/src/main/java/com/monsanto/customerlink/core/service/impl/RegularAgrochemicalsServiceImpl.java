package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.InventoryRegularAgrochemicalsFacade;
import com.monsanto.customerlink.core.service.facade.dto.AgrochemicalMaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class RegularAgrochemicalsServiceImpl implements RegularAgrochemicalsService {

    private RegularAgrochemicalsHelper regularAgrochemicalsHelper;
    private InventoryRegularAgrochemicalsFacade inventoryRegularAgrochemicalsFacade;
    private RegularAgrochemicalInventoryHelper regularAgrochemicalInventoryHelper;

    @Autowired
    public RegularAgrochemicalsServiceImpl(RegularAgrochemicalsHelper regularAgrochemicalsHelper,
                                           InventoryRegularAgrochemicalsFacade inventoryRegularAgrochemicalsFacade,
                                           RegularAgrochemicalInventoryHelper regularAgrochemicalInventoryHelper) {
        this.regularAgrochemicalsHelper = regularAgrochemicalsHelper;
        this.inventoryRegularAgrochemicalsFacade = inventoryRegularAgrochemicalsFacade;
        this.regularAgrochemicalInventoryHelper = regularAgrochemicalInventoryHelper;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.RegularAgrochemicalsService#processAgrochemicalsOrder(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     *
     */
    public void processAgrochemicalsOrder(OrderDTO orderDTO, boolean isUpdate) throws CustomerLinkBusinessException {

        preProcessOrder(orderDTO,isUpdate);

        regularAgrochemicalsHelper.validateInputParametersForAgrochemicals(orderDTO);

        List<MaterialDTO> inventoryListInput = regularAgrochemicalsHelper.createRequestInventory(orderDTO);
        Map<String, List<?>> inventoryListOutPut = inventoryRegularAgrochemicalsFacade.getInventory(inventoryListInput);

        boolean noInventoryAvailable = true;

        List<AgrochemicalMaterialDTO> inventoryWithOutAlgorithm;

        List<ErrorOrderDTO> errorOrderDTOs = new ArrayList<ErrorOrderDTO>();

        if (inventoryListOutPut.containsKey(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR)) {
            errorOrderDTOs = (List<ErrorOrderDTO>) inventoryListOutPut.get(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR);
        }

        if (inventoryListOutPut.containsKey(CustomerLinkCoreConstants.AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM)) {

            inventoryWithOutAlgorithm = (List<AgrochemicalMaterialDTO>) inventoryListOutPut.get(CustomerLinkCoreConstants.AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM);

            if (!inventoryWithOutAlgorithm.isEmpty()) {
                noInventoryAvailable = false;
                regularAgrochemicalInventoryHelper.assignInventoryAgrochemicalOrder(orderDTO, inventoryWithOutAlgorithm,errorOrderDTOs);
            }
        }

        if (noInventoryAvailable) {
            regularAgrochemicalInventoryHelper.notifyInventoryNotFound(orderDTO,null);
        }

    }

    public void preProcessOrder(OrderDTO orderDTO, boolean isUpdate) throws CustomerLinkBusinessException {
        if(!isUpdate) {
            orderDTO.setOrderIdSAP(null);
        }
        if(isUpdate && orderDTO.getOrderIdSAP() == null) {
            throw new CustomerLinkBusinessException("The ORDER SAP ID can not be null",new Exception("The ORDER SAP ID can not be null"));
        }
    }
}