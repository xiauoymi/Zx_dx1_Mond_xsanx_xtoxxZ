package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderReasonTypeService;
import com.monsanto.customerlink.core.service.RetrieveSAPOrderHelper;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.FoundMoreThanASAPOrderException;
import com.monsanto.customerlink.core.service.exception.OrderReasonNotFoundException;
import com.monsanto.customerlink.core.service.facade.SAPOrderFacade;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.StatusSAPOrderEnum;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RetrieveSAPOrderHelperImpl implements RetrieveSAPOrderHelper {

    @Autowired
    private OrderReasonTypeService orderReasonTypeBusiness;

    @Autowired
    private SAPOrderFacade sapOrderFacade;

    @Autowired
    private Mapper mapper;

    public SAPOrderDTO retrieveSeedSAPOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        List<SAPOrderDTO> sapOrderDTOList = filterSAPOrdersSeed(sapOrderFacade.retrieveOrders(orderDTO), orderDTO.getPriceGroup().getPriceGroupCode());
        SAPOrderDTO sapOrderDTO = checkIfExistOnlyOneSAPOrder(sapOrderDTOList, orderDTO);
        if (null != sapOrderDTO && !StringUtils.equals(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), orderDTO.getClOrderTypeCode())) {
            sapOrderDTO.setWithoutSoakTestOrder(retrieveWithoutSoakTest(orderDTO));
        }
        return sapOrderDTO;
    }

    public SAPOrderDTO retrieveAgrochemicalSAPOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        List<SAPOrderDTO> sapOrderDTOList = filterSAPOrdersAgrochemical(sapOrderFacade.retrieveOrders(orderDTO));
        return checkIfExistOnlyOneSAPOrder(sapOrderDTOList, orderDTO);
    }

    private List<SAPOrderDTO> filterSAPOrdersSeed(List<SAPOrderDTO> sapOrderDTOList, final String priceGroup) {
        return (List<SAPOrderDTO>) CollectionUtils.select(sapOrderDTOList, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                final SAPOrderDTO sapOrderDTO = (SAPOrderDTO) o;
                return StringUtils.equals(priceGroup, sapOrderDTO.getPriceGrp()) && checkSAPOrderStatus(sapOrderDTO);
            }
        });
    }

    private List<SAPOrderDTO> filterSAPOrdersAgrochemical(List<SAPOrderDTO> sapOrderDTOList) {
        return (List<SAPOrderDTO>) CollectionUtils.select(sapOrderDTOList, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                final SAPOrderDTO sapOrderDTO = (SAPOrderDTO) o;
                return checkSAPOrderStatus(sapOrderDTO);
            }
        });
    }

    private SAPOrderDTO checkIfExistOnlyOneSAPOrder(List<SAPOrderDTO> sapOrderDTOList, OrderDTO orderDTO) throws FoundMoreThanASAPOrderException {
        SAPOrderDTO sapOrderDTO = null;
        if (!sapOrderDTOList.isEmpty()) {
            if (1 == sapOrderDTOList.size()) {
                sapOrderDTO = sapOrderDTOList.get(0);
            } else {
                throw new FoundMoreThanASAPOrderException(new Object[]{ToStringBuilder.reflectionToString(orderDTO)});
            }
        }
        return sapOrderDTO;
    }

    private SAPOrderDTO retrieveWithoutSoakTest(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        return retrieveSeedSAPOrder(generateWithoutSoakTestOrderDTO(orderDTO));
    }

    private boolean checkSAPOrderStatus(SAPOrderDTO sapOrderDTO) {
        return (StringUtils.equals(StatusSAPOrderEnum.OPEN.code(), sapOrderDTO.getStatus()) ||
                StringUtils.equals(StatusSAPOrderEnum.PARTIAL.code(), sapOrderDTO.getStatus()) ||
                StringUtils.equals(StatusSAPOrderEnum.COMPLETE.code(), sapOrderDTO.getStatus()));
    }

    private OrderDTO generateWithoutSoakTestOrderDTO(OrderDTO orderDTO) throws OrderReasonNotFoundException {
        final OrderDTO withoutSoakTestOrderDTO = new OrderDTO();
        mapper.map(orderDTO, withoutSoakTestOrderDTO);
        withoutSoakTestOrderDTO.setDetail(mapper.mapList(OrderDetailDTO.class, orderDTO.getDetail()));
        withoutSoakTestOrderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code());
        withoutSoakTestOrderDTO.setSapOrderReasonTypeDTO(retrievesSapOrderReasonType(withoutSoakTestOrderDTO));
        return withoutSoakTestOrderDTO;
    }

    private SAPOrderReasonTypeDTO retrievesSapOrderReasonType(OrderDTO orderDTO) throws OrderReasonNotFoundException {
        return mapper.map(orderReasonTypeBusiness.retrieveOrderReasonType(orderDTO.getClOrderTypeCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()), SAPOrderReasonTypeDTO.class);
    }
}
