package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.SAPOrderFacade;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.*;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("sapOrderBusiness")
public class SAPOrderServiceImpl implements SAPOrderService {

    private static final String ROUTE = "000000";
    private static final String FORM_PREF = "F";//"FLAT";
    private static final String SIZE_PREF1 = "G";//"LARGE";
    private static final String SIZE_PREF2 = "M";//"MEDIUM";
    private static final String PREF1 = "PW";
    private static final String PREF2 = "PT";
    private static final String PREF3 = "";
    private static final String PREF4 = "";

    @Autowired
    private OrderComplementService orderComplementBusiness;

    @Autowired
    private OrderErrorService orderErrorService;

    @Autowired
    private RetrieveSAPOrderHelper retrieveSAPOrderHelper;

    @Autowired
    private SAPOrderTypeService sapOrderTypeBusiness;

    @Autowired
    private SAPOrderFacade sapOrderFacade;

    @Autowired
    private Mapper mapper;

    /**
     * @see SAPOrderService#postOrderWithoutAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO postOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        SAPOrderDTO sapOrderDTO = null;
        CustomerLinkUtils.isValidParameter(orderDTO);
        if (null == orderDTO.getOrderIdSAP()) {
            sapOrderDTO = createSAPOrderWithoutAlgorithm(orderDTO);
        } else {
            sapOrderDTO = updateSAPOrderWithoutAlgorithm(orderDTO);
        }
        return sapOrderDTO;
    }

    /**
     * @see SAPOrderService#postOrderWithAlgorithm(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO postOrderWithAlgorithm(OrderDTO orderDTO) throws CustomerLinkBusinessException {

        SAPOrderDTO sapOrderDTO = null;
        CustomerLinkUtils.isValidParameter(orderDTO);

        if (null == orderDTO.getOrderIdSAP()) {
            sapOrderDTO = createSAPOrderWithAlgorithm(orderDTO);
        } else {
            sapOrderDTO = updateSAPOrderWithAlgorithm(orderDTO);
        }
        return sapOrderDTO;
    }

    /**
     * @see SAPOrderService#retrieveOrder(com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO)
     */
    @Override
    public SAPOrderDTO retrieveOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        SAPOrderDTO sapOrderDTO = null;
        CustomerLinkUtils.isValidParameter(orderDTO);
        CustomerLinkUtils.isValidParameter(orderDTO.getClOrderTypeCode());
        CustomerLinkUtils.checkDistributorProfileArgument(orderDTO.getDistributorConfigDTO());
        CustomerLinkUtils.isValidParameter(orderDTO.getCurrency());
        orderComplementBusiness.complementToSearch(orderDTO);
        if (StringUtils.equals(CustomerLinkCoreConstants.AGROCHEMICAL_SALES_DIV, orderDTO.getDistributorConfigDTO().getSalesDivCode())) {
            sapOrderDTO = retrieveSAPOrderHelper.retrieveAgrochemicalSAPOrder(orderDTO);
        } else {
            sapOrderDTO = retrieveSAPOrderHelper.retrieveSeedSAPOrder(orderDTO);
        }
        return sapOrderDTO;
    }

    /**
     * Creates SAP Order
     *
     * @param orderDTO the order to create
     * @return the SAP Order created
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    private SAPOrderDTO createSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateInputParametersForCreateSAPOrder(orderDTO, false);
        complementCreateOrder(orderDTO);
        setPropertiesInMaterial(orderDTO.getDetail());
        final SAPOrderDTO sapOrderDTO = sapOrderFacade.createSAPOrderWithoutAlgorithm(orderDTO);
        logErrors(sapOrderDTO, orderDTO, true);
        return sapOrderDTO;
    }

    /**
     * Updates SAP Order
     *
     * @param orderDTO the order to update
     * @return the SAP order updated
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    private SAPOrderDTO updateSAPOrderWithoutAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateInputParametersForUpdateSAPOrder(orderDTO, false);
        complementUpdateOrder(orderDTO);
        setPropertiesInMaterial(orderDTO.getDetail());
        final SAPOrderDTO sapOrderDTO = sapOrderFacade.updateSAPOrderWithoutAlgorithm(orderDTO);
        logErrors(sapOrderDTO, orderDTO, false);
        return sapOrderDTO;
    }

    /**
     * Validates input parameters for create a SAP order
     *
     * @param orderDTO the order to validate
     */
    private void validateInputParametersForCreateSAPOrder(final OrderDTO orderDTO, boolean isWithAlgorithm) {
        CustomerLinkUtils.isValidParameter(orderDTO.getClOrderTypeCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getSalesOrgCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getDistChCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getSalesDivCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getSubRegionCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getDistributor());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());

        if (orderDTO.getDetail().isEmpty()) {
            throw new IllegalArgumentException("The hybrid list is empty");
        }
        if (isWithAlgorithm) {
            validatePlantListForCreateOrUpdateSAPOrder(orderDTO.getDetail(), true);
        } else {
            validateSKUListForCreateSAPOrder(orderDTO.getDetail(), isAgrochemicalRegular(orderDTO));
        }

    }

    /**
     * Validates input parameters for update SAP order
     *
     * @param orderDTO the order to validate
     */
    private void validateInputParametersForUpdateSAPOrder(final OrderDTO orderDTO, boolean isWithAlgorithm) {
        CustomerLinkUtils.isValidParameter(orderDTO.getClOrderTypeCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getSalesOrgCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getDistChCode());
        CustomerLinkUtils.isValidParameter(orderDTO.getDistributorConfigDTO().getSalesDivCode());
        if (orderDTO.getDetail().isEmpty()) {
            throw new IllegalArgumentException("The hybrid list is empty");
        }
        if (isWithAlgorithm) {
            validatePlantListForCreateOrUpdateSAPOrder(orderDTO.getDetail(), false);
        } else {
            validateSKUListForUpdateSAPOrder(orderDTO.getDetail());
        }
    }

    /**
     * Verifies if the order is regular agrochemicals
     * @param orderDTO
     * @return
     */
    private boolean isAgrochemicalRegular(OrderDTO orderDTO) {

        boolean isAgrochemicalRegular = false;

        if(orderDTO.getDistributorConfigDTO().getSalesOrgCode().equals(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode())
                && orderDTO.getDistributorConfigDTO().getSalesDivCode().equals(SalesDivisionEnum.AGROCHEMICALS.getCode())) {
            isAgrochemicalRegular = true;
        }

        return isAgrochemicalRegular;
    }

    /**
     * Validates the SKU list for every hybrid in the list hybrid when going to create a SAP order.
     * The transaction type property for the all SKU should be 'I'
     *
     * @param detail Hybrid List
     */
    private void validateSKUListForCreateSAPOrder(final List<OrderDetailDTO> detail, boolean isAgrochemicalRegular) {
        for (final OrderDetailDTO orderDetailDTO : detail) {
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getProductCode());
            if (orderDetailDTO.getProductDTO().getListOfSku().isEmpty()) {
                throw new IllegalArgumentException("The SKU list is empty");
            } else {
                for (final MaterialSkuDTO materialSkuDTO : orderDetailDTO.getProductDTO().getListOfSku()) {
                    validateItemNumber(materialSkuDTO.getItemNumber());
                    CustomerLinkUtils.isValidParameter(materialSkuDTO.getTransactionType());
                    if (StringUtils.equals(TransactionTypeMaterial.INSERT.getCode(), materialSkuDTO.getTransactionType())) {
                        validateSKUForCreate(materialSkuDTO,isAgrochemicalRegular);
                    } else {
                        throw new IllegalArgumentException("The transaction type of the SKU not is the required for create a SAP order");
                    }
                }
            }
        }
    }

    /**
     * Validates the SKU list for every hybrid in the list hybrid when going to update a SAP order.
     * The transaction type property for the all SKU should be 'I', 'U' or 'D'
     *
     * @param detail the hybrid list
     */
    private void validateSKUListForUpdateSAPOrder(final List<OrderDetailDTO> detail) {
        for (final OrderDetailDTO orderDetailDTO : detail) {
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getProductCode());
            if (orderDetailDTO.getProductDTO().getListOfSku().isEmpty()) {
                throw new IllegalArgumentException("The SKU list is empty");
            } else {
                for (final MaterialSkuDTO materialSkuDTO : orderDetailDTO.getProductDTO().getListOfSku()) {
                    validateItemNumber(materialSkuDTO.getItemNumber());
                    CustomerLinkUtils.isValidParameter(materialSkuDTO.getTransactionType());
                    if (StringUtils.equals(TransactionTypeMaterial.INSERT.getCode(), materialSkuDTO.getTransactionType())) {
                        validateSKUForCreate(materialSkuDTO,false);
                    } else if (StringUtils.equals(TransactionTypeMaterial.UPDATE.getCode(), materialSkuDTO.getTransactionType())) {
                        CustomerLinkUtils.isValidParameter(materialSkuDTO.getUnrestqty());
                    } else if (!StringUtils.equals(TransactionTypeMaterial.DELETE.getCode(), materialSkuDTO.getTransactionType())) {
                        throw new IllegalArgumentException("The transaction type of the SKU not is the required for update a SAP order");
                    }
                }
            }
        }
    }

    /**
     * Validates all required properties of the SKU when want create it
     *
     * @param materialSkuDTO sku
     */
    private void validateSKUForCreate(final MaterialSkuDTO materialSkuDTO, boolean isAgrochemicalRegular) {
        CustomerLinkUtils.isValidParameter(materialSkuDTO.getMaterial());
        CustomerLinkUtils.isValidParameter(materialSkuDTO.getPlant());
        CustomerLinkUtils.isValidParameter(materialSkuDTO.getStoragelocation());
        if(!isAgrochemicalRegular) {
            CustomerLinkUtils.isValidParameter(materialSkuDTO.getBatch());
        }
        CustomerLinkUtils.isValidParameter(materialSkuDTO.getUnrestqty());
    }

    /**
     * Validates de item number
     *
     * @param itemNumber item number
     */
    private void validateItemNumber(final long itemNumber) {
        if (0 == itemNumber) {
            throw new IllegalArgumentException("The item number can't be zero");
        }
        final long mod = itemNumber % 10;
        if (0 != mod) {
            throw new IllegalArgumentException("The item number not is multiplo of ten");
        }
    }

    /**
     * Sets the missing properties to material
     *
     * @param detail Order detail
     */
    private void setPropertiesInMaterial(final List<OrderDetailDTO> detail) {
        CollectionUtils.forAllDo(detail, new Closure() {
            @Override
            public void execute(final Object object) {
                final OrderDetailDTO orderDetailDTO = (OrderDetailDTO) object;
                CollectionUtils.forAllDo(orderDetailDTO.getProductDTO().getListOfSku(), new Closure() {
                    @Override
                    public void execute(final Object object) {
                        final MaterialSkuDTO materialSkuDTO = (MaterialSkuDTO) object;
                        materialSkuDTO.setRoute(ROUTE);
                    }
                });
            }
        });
    }

    /**
     * Fills the errors of the order
     *
     * @param orderDTO             the order
     * @param sapOrderErrorDTOList the SAP Errors
     */
    private void fillErrors(final OrderDTO orderDTO, final List<SAPOrderErrorDTO> sapOrderErrorDTOList) {
        for (final SAPOrderErrorDTO sapOrderErrorDTO : sapOrderErrorDTOList) {
            final ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();
            errorTypeDTO.setErrorTypeCode(sapOrderErrorDTO.getType());

            final ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
            errorOrderDTO.setObjectWithError(sapOrderErrorDTO.getNumber());
            errorOrderDTO.setErrorTypes(errorTypeDTO);
            System.out.println("erroor" +
                    ToStringBuilder.reflectionToString(sapOrderErrorDTO));
            orderDTO.getErrors().add(errorOrderDTO);
        }
    }

    /**
     * Complements the information of the order for his creation
     *
     * @param orderDTO
     * @throws com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException
     *
     */
    private void complementCreateOrder(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        orderComplementBusiness.complement(orderDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
    }

    /**
     * complements the information of the order for upgrade
     *
     * @param orderDTO
     * @throws com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException
     *
     */
    private void complementUpdateOrder(final OrderDTO orderDTO) throws CustomerLinkBusinessException {
        orderDTO.setSapOrderTypeDTO(mapper.map(sapOrderTypeBusiness.retrieveSapOrderType(orderDTO.getDistributorConfigDTO().getDistChCode(),
                orderDTO.getDetail().get(0).getProductDTO().getCropCode()), SAPOrderTypeDTO.class));
        orderDTO.setTransactionType(TransactionTypeOrder.UPDATE.getCode());
    }

    /**
     * Creates SAP Order With Algorithm
     *
     * @param orderDTO the order to create
     * @return the SAP Order created
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    private SAPOrderDTO createSAPOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {

        validateInputParametersForCreateSAPOrder(orderDTO, true);
        complementCreateOrder(orderDTO);
        setPropertiesInPlant(orderDTO.getDetail());

        final SAPOrderDTO sapOrderDTO = sapOrderFacade.createSAPOrderWithAlgorithm(orderDTO);
        logErrors(sapOrderDTO, orderDTO, true);

        return sapOrderDTO;
    }

    /**
     * Updates SAP Order With Algorithm
     *
     * @param orderDTO the order to update
     * @return the SAP order updated
     * @throws CustomerLinkBusinessException If occurs a business exception
     */
    private SAPOrderDTO updateSAPOrderWithAlgorithm(final OrderDTO orderDTO) throws CustomerLinkBusinessException {

        validateInputParametersForUpdateSAPOrder(orderDTO, true);
        complementUpdateOrder(orderDTO);

        final SAPOrderDTO sapOrderDTO = sapOrderFacade.updateSAPOrderWithAlgorithm(orderDTO);
        logErrors(sapOrderDTO, orderDTO, false);

        return sapOrderDTO;
    }

    /**
     * Logs errors (if any) and throws the appropriate exception for each case
     *
     * @param sapOrderDTO
     * @param orderDTO
     * @param isCreate
     * @throws CustomerLinkBusinessException
     */
    private void logErrors(final SAPOrderDTO sapOrderDTO, final OrderDTO orderDTO, boolean isCreate) throws CustomerLinkBusinessException {

        if (!sapOrderDTO.getErrors().isEmpty()) {

            fillErrors(orderDTO, sapOrderDTO.getErrors());
            orderErrorService.saveOrderAndErrors(orderDTO);

            /*if (isCreate) {
                throw new CreateSAPOrderException(new Object[]{ToStringBuilder.reflectionToString(orderDTO), ToStringBuilder.reflectionToString(sapOrderDTO)});
            } else {
                throw new UpdateSAPOrderException(new Object[]{ToStringBuilder.reflectionToString(orderDTO), ToStringBuilder.reflectionToString(sapOrderDTO)});
            }  */
        }
    }

    /**
     * Validates the Plant list for every hybrid in the list hybrid when going to update a SAP order.
     *
     * @param detail the hybrid list
     */
    private void validatePlantListForCreateOrUpdateSAPOrder(final List<OrderDetailDTO> detail, boolean isCreate) {
        for (final OrderDetailDTO orderDetailDTO : detail) {
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getProductCode());
            if (orderDetailDTO.getProductDTO().getListOfPlants().isEmpty()) {
                throw new IllegalArgumentException("The Plant list is empty");
            } else {
                for (final PlantDTO plantDTO : orderDetailDTO.getProductDTO().getListOfPlants()) {
                    validatePlantForCreateOrUpdate(plantDTO, isCreate);
                }
            }
        }
    }


    /**
     * Validates the information for each of the hybrid plants
     * The transaction type property for the all SKU should be 'I', 'U' or 'D'
     *
     * @param plantDTO
     * @param isCreate
     */
    private void validatePlantForCreateOrUpdate(PlantDTO plantDTO, boolean isCreate) {

        CustomerLinkUtils.isValidParameter(plantDTO.getTransactionType());

        if (isCreate) {

            if (StringUtils.equals(TransactionTypeMaterial.INSERT.getCode(), plantDTO.getTransactionType())) {
                validatePlantParameters(plantDTO);
            } else {
                throw new IllegalArgumentException("The transaction type of plant does not match to create an order in SAP");
            }

        } else {

            if (StringUtils.equals(TransactionTypeMaterial.INSERT.getCode(), plantDTO.getTransactionType())
                    || StringUtils.equals(TransactionTypeMaterial.UPDATE.getCode(), plantDTO.getTransactionType())
                    || StringUtils.equals(TransactionTypeMaterial.DELETE.getCode(), plantDTO.getTransactionType())
                    ) {
                validatePlantParameters(plantDTO);
            } else {
                throw new IllegalArgumentException("The transaction type of plant does not match to update an order in SAP");
            }
        }
    }

    /**
     * Sets the missing properties to plant
     *
     * @param detail Order detail
     */
    private void setPropertiesInPlant(final List<OrderDetailDTO> detail) {
        CollectionUtils.forAllDo(detail, new Closure() {
            @Override
            public void execute(final Object object) {
                final OrderDetailDTO orderDetailDTO = (OrderDetailDTO) object;
                CollectionUtils.forAllDo(orderDetailDTO.getProductDTO().getListOfPlants(), new Closure() {
                    @Override
                    public void execute(final Object object) {
                        final PlantDTO plantDTO = (PlantDTO) object;
                        plantDTO.setRoute(ROUTE);
                        plantDTO.setFormPref(FORM_PREF);
                        plantDTO.setSizePref1(SIZE_PREF1);
                        plantDTO.setSizePref2(SIZE_PREF2);
                        plantDTO.setPref1(PREF1);
                        plantDTO.setPref2(PREF2);
                        plantDTO.setPref3(PREF3);
                        plantDTO.setPref4(PREF4);
                    }
                });
            }
        });
    }

    /**
     * Validates all required properties of the plan when want create/update it
     *
     * @param plantDTO
     */
    private void validatePlantParameters(final PlantDTO plantDTO) {
        if (StringUtils.isEmpty(plantDTO.getPlant())) {
            throw new IllegalArgumentException("The plant code can't null or blank");
        }
        CustomerLinkUtils.isValidParameter(plantDTO.getUnrestqty());
    }
}