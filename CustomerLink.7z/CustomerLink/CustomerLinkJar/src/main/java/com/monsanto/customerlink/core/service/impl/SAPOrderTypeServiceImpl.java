package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SAPOrderTypeService;
import com.monsanto.customerlink.core.service.exception.OrderTypeNotFoundException;
import com.monsanto.customerlink.persistence.entities.OrderTypeVO;
import com.monsanto.customerlink.persistence.repositories.OrderTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("sapOrderTypeBusiness")
public class SAPOrderTypeServiceImpl implements SAPOrderTypeService {

    @Autowired
    private OrderTypeRepository orderTypeRepository;

    /**
     * @see SAPOrderTypeService#retrieveSapOrderType(String, String)
     */
    @Override
    public OrderTypeVO retrieveSapOrderType(String distributionChannelCode, String cropCode) throws OrderTypeNotFoundException {
        final OrderTypeVO orderTypeVO = orderTypeRepository.findByDistributionChannelAndCrop(distributionChannelCode, cropCode);
        if (null == orderTypeVO) {
             throw new OrderTypeNotFoundException(new Object[]{distributionChannelCode, cropCode});
        }
        return orderTypeVO;
    }

    @Override
    public OrderTypeVO retrieveSapOrderTypeByCode(String orderTypeCode) throws OrderTypeNotFoundException {
        final OrderTypeVO orderTypeVO = orderTypeRepository.findByOrderTypeCode(orderTypeCode);
        if (null == orderTypeVO) {
            final OrderTypeNotFoundException orderTypeNotFoundException = new OrderTypeNotFoundException(new Object[]{orderTypeCode});
            orderTypeNotFoundException.setCode("orderTypeByCodeNotFoundException");
            throw orderTypeNotFoundException;
        }
        return orderTypeVO;
    }

}
