package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.SeasonRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("seasonBusiness")
public class SeasonServiceImpl implements SeasonService {

    @Autowired
    private SeasonRepository seasonRepository;

    /**
     * @see SeasonService#retrieveActiveSeason(String, Date)
     */
    public SeasonVO retrieveActiveSeason(String subRegionCode, Date date) throws ActiveSeasonNotFoundException {
        CustomerLinkUtils.isValidParameter(subRegionCode);
        CustomerLinkUtils.isValidParameter(date);
        final SeasonVO seasonVO = seasonRepository.findActiveSeasonBySubRegionCodeAndDate(subRegionCode, date);
        if (null == seasonVO) {
            throw new ActiveSeasonNotFoundException(new Object[]{subRegionCode});
        }
        return seasonVO;
    }

    /**
     * @see SeasonService#retrieveSearchPeriod(String)
     */
    public SearchPeriodDTO retrieveSearchPeriod(String subRegionCode) throws ActiveSeasonNotFoundException {
        SeasonVO seasonVO = retrieveActiveSeason(subRegionCode, new Date());
        final SearchPeriodDTO searchPeriodDTO = new SearchPeriodDTO();
        searchPeriodDTO.setStartDate(CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(seasonVO.getSeasonStartDate()));
        searchPeriodDTO.setEndDate(CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(seasonVO.getSeasonEndDate()));
        return searchPeriodDTO;
    }
}
