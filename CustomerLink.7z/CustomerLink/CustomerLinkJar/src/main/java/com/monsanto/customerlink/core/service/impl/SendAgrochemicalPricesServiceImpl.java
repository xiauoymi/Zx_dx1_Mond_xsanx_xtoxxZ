package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SendAgrochemicalPricesService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SendAgrochemicalPricesServiceImpl implements SendAgrochemicalPricesService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private SendPricesUtilService sendPricesUtilService;

    @Autowired
    public SendAgrochemicalPricesServiceImpl(SendPricesUtilService sendPricesUtilService) {
        this.sendPricesUtilService = sendPricesUtilService;
    }

    @Override
    public List<OrderDTO> obtainOrderByCurrency(List<OrderDTO> list) {
        List<OrderDTO> orderDTOListByCurrency = new ArrayList<OrderDTO>();

        for (OrderDTO orderDTO : list) {
            //then obtain currencies
            try {
                sendPricesUtilService.obtainAgrochemicalCurrencies(orderDTO, orderDTOListByCurrency);
            } catch (CustomerLinkBusinessException e) {
                //if error happen at consulting currency for order, the order is not returned and the error is logged
                log.error(e.getMessage(), e);
            }
        }
        return orderDTOListByCurrency;
    }

}
