package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SendPricesService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SendPricesServiceImpl implements SendPricesService {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private ProductRepository productRepository;
    private SendPricesUtilService sendPricesUtilService;

    @Autowired
    public SendPricesServiceImpl(ProductRepository productRepository,
                                 SendPricesUtilService sendPricesUtilService) {
        this.productRepository = productRepository;
        this.sendPricesUtilService = sendPricesUtilService;
    }

    @Override
    public List<OrderDTO> obtainOrderByCurrency(List<OrderDTO> list) {

        List<OrderDTO> orderDTOListByCurrency = new ArrayList<OrderDTO>();
        //first only one sku is filled
        fillMaterial(list);

        for (OrderDTO orderDTO : list) {
            //then obtain currencies
            try {
                sendPricesUtilService.obtainCurrencies(orderDTO, orderDTOListByCurrency);
            } catch (CustomerLinkBusinessException e) {
                //if error happen at consulting currency for order, the order is not returned
                //and the error is logged
                log.error(e.getSuperMessage(), e);
            }
        }
        return orderDTOListByCurrency;
    }

    private void fillMaterial(List<OrderDTO> list) {
        //first only one sku is filled
        for (OrderDTO orderDTO : list) {
            for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
                ProductDTO productDTO = orderDetailDTO.getProductDTO();
                MaterialSkuDTO material = buildMaterial(productDTO);
                if (material != null) {
                    productDTO.getListOfSku().add(material);
                }
            }
        }
    }

    private MaterialSkuDTO buildMaterial(ProductDTO productDTO) {

        List<ProductVO> productVOList = productRepository.findByFamilyCode(productDTO.getProductCode());

        for (ProductVO productVO : productVOList) {
            MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();

            materialSkuDTO.setMaterial(productVO.getProductCode());
            return materialSkuDTO;
        }
        return null;
    }

}



