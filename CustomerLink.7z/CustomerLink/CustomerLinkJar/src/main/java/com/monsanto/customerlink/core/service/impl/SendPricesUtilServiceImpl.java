package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.SendPricesFacade;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SendPricesUtilServiceImpl implements SendPricesUtilService {

    private SendPricesFacade sendPricesFacade;

    private Mapper mapper;
    private NotificationSender mailNotificationSender;
    private MailUtilService mailUtilService;

    @Autowired
    public SendPricesUtilServiceImpl(SendPricesFacade sendPricesFacade, Mapper mapper,
                                     NotificationSender mailNotificationSender, MailUtilService mailUtilService) {
        this.sendPricesFacade = sendPricesFacade;
        this.mapper = mapper;
        this.mailNotificationSender = mailNotificationSender;
        this.mailUtilService = mailUtilService;
    }

    public void obtainAgrochemicalCurrencies(OrderDTO orderDTO, List<OrderDTO> orderDTOListByCurrency) throws CustomerLinkBusinessException {
        Map<String, Set<OrderDetailDTO>> mapCurrencies = new HashMap<String, Set<OrderDetailDTO>>();
        List<MaterialSkuDTO> errorMaterialSku = new ArrayList<MaterialSkuDTO>();

        Map<String, Set<OrderDetailDTO>> mapDetailByCurrency = obtainCurrencies(orderDTO, mapCurrencies, errorMaterialSku);
        //matter for agrochemical, if a order fails on any currency
        if (!errorMaterialSku.isEmpty()) {
            sendNotificationError(errorMaterialSku, orderDTO);
        } else {
            setCurrenciesInList(orderDTO, orderDTOListByCurrency, mapDetailByCurrency);
        }
    }

    public void obtainCurrencies(OrderDTO orderDTO, List<OrderDTO> orderDTOListByCurrency) throws CustomerLinkBusinessException {
        Map<String, Set<OrderDetailDTO>> mapCurrencies = new HashMap<String, Set<OrderDetailDTO>>();
        List<MaterialSkuDTO> errorMaterialSku = new ArrayList<MaterialSkuDTO>();

        Map<String, Set<OrderDetailDTO>> mapDetailByCurrency = obtainCurrencies(orderDTO, mapCurrencies, errorMaterialSku);

        //matter for others here in by orderDTO
        setCurrenciesInList(orderDTO, orderDTOListByCurrency, mapDetailByCurrency);
        sendNotificationError(errorMaterialSku, orderDTO);
    }

    private void setCurrenciesInList(OrderDTO orderDTO, List<OrderDTO> orderDTOListByCurrency, Map<String, Set<OrderDetailDTO>> mapDetailByCurrency) throws CustomerLinkBusinessException {
        for (String currency : mapDetailByCurrency.keySet()) {

            OrderDTO newOrderDTO = mapper.map(orderDTO, OrderDTO.class);

            newOrderDTO.setCurrency(currency);
            newOrderDTO.setDetail(new ArrayList<OrderDetailDTO>());
            newOrderDTO.getDetail().addAll(mapDetailByCurrency.get(currency));
            //set detail empty
            orderDTOListByCurrency.add(newOrderDTO);
        }
    }

    private Map<String, Set<OrderDetailDTO>> obtainCurrencies(OrderDTO orderDTO,
                                                               Map<String, Set<OrderDetailDTO>> mapCurrencies,
                                                               List<MaterialSkuDTO> errorMaterialSku) throws CustomerLinkBusinessException {
        try {
            List<MaterialSkuDTO> allMaterialsWithCurrency = sendPricesFacade.obtainCurrencies(orderDTO);

            for (MaterialSkuDTO materialWithCurrency : allMaterialsWithCurrency) {
                obtainDetailForMaterial(mapCurrencies, orderDTO, materialWithCurrency, errorMaterialSku);
            }

            return mapCurrencies;
        } catch (Exception e) {
            throw new CustomerLinkBusinessException(e.getMessage(), e);
        }
    }

    private void obtainDetailForMaterial(Map<String, Set<OrderDetailDTO>> mapCurrencies, OrderDTO orderDTO, MaterialSkuDTO materialWithCurrency,
                                         List<MaterialSkuDTO> errorMaterialSku) {
        if (hasError(materialWithCurrency)) {
            errorMaterialSku.add(materialWithCurrency);
        } else {
            obtainDetailForMaterialWithoutError(mapCurrencies, orderDTO, materialWithCurrency);
        }
    }

    private void obtainDetailForMaterialWithoutError(Map<String, Set<OrderDetailDTO>> mapCurrencies,
                                                     OrderDTO orderDTO, MaterialSkuDTO materialWithCurrency) {

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            ProductDTO productDTO = orderDetailDTO.getProductDTO();

            for (MaterialSkuDTO materialSkuDTO : productDTO.getListOfSku()) {

                if (materialWithCurrency != null && materialWithCurrency.getMaterial() != null && materialSkuDTO != null && materialSkuDTO.getMaterial() != null) {
                    if (materialWithCurrency.getMaterial().contains(materialSkuDTO.getMaterial())) {
                        putValueInMap(mapCurrencies, materialWithCurrency.getCurrency(), orderDetailDTO,
                                materialSkuDTO);
                        //if found in order detail material stop to not fill the list with detail order two times
                        break;
                    }
                }
            }
        }
    }

    private void putValueInMap(Map<String, Set<OrderDetailDTO>> mapCurrencies,
                               String currency, OrderDetailDTO orderDetailDTO, MaterialSkuDTO materialSkuDTO) {

        materialSkuDTO.setCurrency(currency);

        if (!mapCurrencies.containsKey(currency)) {
            mapCurrencies.put(currency, new HashSet<OrderDetailDTO>());
        }

        mapCurrencies.get(currency).add(orderDetailDTO);
    }

    private boolean hasError(MaterialSkuDTO materialSkuDTO) {
        return !materialSkuDTO.getErrors().isEmpty();
    }

    private void sendNotificationError(List<MaterialSkuDTO> errorMaterialSku, OrderDTO orderDTO) {
        List<ErrorOrderDTO> errorOrderDTOs = obtainErros(errorMaterialSku);
        if (!errorOrderDTOs.isEmpty()) {
            sendNotification(errorOrderDTOs, getCurrencyNotificationType(), orderDTO.getDistributorConfigDTO());
        }
    }

    private List<ErrorOrderDTO> obtainErros(List<MaterialSkuDTO> errorMaterialSku) {
        List<ErrorOrderDTO> errors = new ArrayList<ErrorOrderDTO>();
        for (MaterialSkuDTO materialSkuDTO : errorMaterialSku) {
            errors.addAll(materialSkuDTO.getErrors());
        }
        return errors;
    }

    public NotificationType getCurrencyNotificationType() {
        return NotificationType.INVALID_CURRENCY;
    }

    private void sendNotification(List<ErrorOrderDTO> listError, NotificationType type,
                                  DistributorConfigDTO distributorConfigDTO) {
        if (!listError.isEmpty()) {
            Map<String, Object> parameters = mailUtilService.buildDistributorMessageNotification(distributorConfigDTO, listError);

            mailNotificationSender.send(type.newNotification(distributorConfigDTO, parameters));
        }
    }
}
