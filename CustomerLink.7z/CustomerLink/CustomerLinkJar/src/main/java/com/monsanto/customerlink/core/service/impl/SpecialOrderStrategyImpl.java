package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderStrategy;
import com.monsanto.customerlink.core.service.WFApprovalService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.UpdateOrderException;
import com.monsanto.customerlink.core.service.exception.WFApprovalIsNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.OrderStatusEnum;
import com.monsanto.customerlink.core.service.util.WFApprovalStatusEnum;
import com.monsanto.customerlink.core.service.util.WFApprovalTypeEnum;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.entities.WFApprovalVO;
import com.monsanto.customerlink.persistence.repositories.WFApprovalRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class SpecialOrderStrategyImpl extends OrderStrategy {

    /*@Autowired
    private UserRepository userRepository;*/

    @Autowired
    private WFApprovalRepository wfApprovalRepository;

    @Autowired
    private WFApprovalService wfApprovalService;

    @Override
    public OrderVO createOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateInputParameters(orderDTO);
        OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(retrieveOrderStatus(OrderStatusEnum.PENDING_APPROVAL.toString()));
        setPropertiesToOrder(orderVO, orderDTO);
        orderVO = saveOrder(orderVO);
        wfApprovalService.createWorkFlowApproval(orderVO.getOrderId());
        return orderVO;
    }

    @Override
    public OrderVO updateOrder(OrderDTO orderDTO) throws CustomerLinkBusinessException {
        validateOrderDetail(orderDTO.getDetail());
        validateOrderStatus(orderDTO.getOrderId());
        clearOrderDetail(orderDTO.getOrderId());
        final OrderVO orderVO = retrieveOrder(orderDTO.getOrderId());
        setChildToOrder(orderVO, orderDTO);
        return saveOrder(orderVO);
    }

    @Override
    protected void validateInputParameters(OrderDTO orderDTO) {
        validateInputParametersCommon(orderDTO);
        validateOrderDetail(orderDTO.getDetail());
        //CustomerLinkUtils.isValidParameter(orderDTO.getRepresentativeDTO());
        //Preconditions.checkArgument(orderDTO.getRepresentativeDTO().getUserId() > 0);
    }

    @Override
    protected void validateOrderDetail(List<OrderDetailDTO> orderDetailDTOList) {
        for (OrderDetailDTO orderDetailDTO : orderDetailDTOList) {
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getProductCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getCropCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getProductDTO().getBrandCode());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getQuantity());
            CustomerLinkUtils.isValidParameter(orderDetailDTO.getUmBase());
        }
    }

    @Override
    protected void setPropertiesToOrder(OrderVO orderVO, OrderDTO orderDTO) throws CustomerLinkBusinessException {
        setCommonPropertiesToOrder(orderVO, orderDTO);
        //orderVO.setRcdByUserId(userRepository.findOne(orderDTO.getRepresentativeDTO().getUserId()));
    }

    private void validateOrderStatus(Long orderId) throws CustomerLinkBusinessException {
        final WFApprovalVO wfApprovalVO = wfApprovalRepository.findByBusinessEntityIdAndType(orderId, WFApprovalTypeEnum.SPECIAL_ORDER.id());
        if (null == wfApprovalVO) {
            throw new WFApprovalIsNotFoundException(new Object[]{orderId});
        }
        if (wfApprovalVO.getStatus().intValue() != WFApprovalStatusEnum.PENDING_APPROVAL.id()) {
            throw new UpdateOrderException(new Object[]{orderId});
        }
    }
}
