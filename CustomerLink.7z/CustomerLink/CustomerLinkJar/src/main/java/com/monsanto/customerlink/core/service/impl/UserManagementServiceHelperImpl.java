package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.UserManagementServiceHelper;
import com.monsanto.customerlink.core.service.dto.UserRoleDTO;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.util.DistributionChannelEnum;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserManagementServiceHelperImpl implements UserManagementServiceHelper {

    private UserRepository userRepository;

    @Autowired
    public UserManagementServiceHelperImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void filterUsers(List<UserVO> list, String roleCode) {
        if(StringUtils.isNotEmpty(roleCode)) {
            if(roleCode.equals(RoleEnum.RCD.getCode())){
                CollectionUtils.filter(list,new Predicate() {
                    @Override
                    public boolean evaluate(Object object) {
                        UserVO u = (UserVO) object;
                        return !u.getDistributionChannelVO().getDistributionChannelCode().equals(DistributionChannelEnum.DEFAULT.getId());
                    }
                });
            }
        }
    }

    @Override
    public boolean replicateProcessForRCD(UserVO u, UserRoleDTO userRoleDTO, RoleEnum roleEnum, UserManagementService ums) throws CustomerLinkBusinessException {
        boolean replicateProcess = false;
        if(roleEnum.equals(RoleEnum.RCD)) {
            if(userRoleDTO.getKeyDTO().getDistChannelCode().equals(DistributionChannelEnum.DIRECT_SALES.getId())) {
                // search the same RCD but with DistributionChannel=00 and same SAP_ID
                UserVO rcdDefaultDistributionChannel = userRepository.findRCDByParameters(u.getRoleVO().getRoleCode()
                        ,u.getSubRegionVO().getSubRegionCode(),u.getSalesOrganizationVO().getSalesOrgCode()
                        ,u.getSalesDivisionVO().getSalesDivCode()
                        ,DistributionChannelEnum.DEFAULT.getId(),u.getSapId());
                if(rcdDefaultDistributionChannel!=null) {
                    userRoleDTO.getKeyDTO().setDistChannelCode(DistributionChannelEnum.DEFAULT.getId());
                    userRoleDTO.setIdUser(rcdDefaultDistributionChannel.getUserID());
                    replicateProcess = ums.createUpdateUserRole(userRoleDTO);
                }
            }
        }
        return replicateProcess;
    }

    @Override
    public boolean isCsrOrApprover(RoleEnum roleEnum) {
        return roleEnum.equals(RoleEnum.CSR) || roleEnum.equals(RoleEnum.APPROVER);
    }
}