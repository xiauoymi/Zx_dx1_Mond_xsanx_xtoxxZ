package com.monsanto.customerlink.core.service.impl;

import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.UserManagementServiceHelper;
import com.monsanto.customerlink.core.service.dto.DistributorDTO;
import com.monsanto.customerlink.core.service.dto.GridUserRoleDTO;
import com.monsanto.customerlink.core.service.dto.UserRoleDTO;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Service
public class UserManagementServiceImpl implements UserManagementService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private Mapper mapper;
    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private BrandRepository brandRepository;
    private SalesOrganizationRepository salesOrganizationRepository;
    private SalesDivisionRepository salesDivisionRepository;
    private DistributionChannelRepository distributionChannelRepository;
    private SubRegionRepository subRegionRepository;
    private UserDistributorRepository userDistributorRepository;
    private DistributorRepository distributorRepository;
    private DistributorProfileRepository distributorProfileRepository;
    private UserManagementServiceHelper helper;

    @Autowired
    public UserManagementServiceImpl(UserRepository userRepository, Mapper mapper,
                                     RoleRepository roleRepository, BrandRepository brandRepository,
                                     SalesOrganizationRepository salesOrganizationRepository, SalesDivisionRepository salesDivisionRepository,
                                     DistributionChannelRepository distributionChannelRepository, SubRegionRepository subRegionRepository,
                                     UserDistributorRepository userDistributorRepository, DistributorRepository distributorRepository,
                                     DistributorProfileRepository distributorProfileRepository,
                                     UserManagementServiceHelper helper) {
        this.userRepository = userRepository;
        this.mapper = mapper;
        this.roleRepository = roleRepository;
        this.brandRepository = brandRepository;
        this.salesOrganizationRepository = salesOrganizationRepository;
        this.salesDivisionRepository = salesDivisionRepository;
        this.distributionChannelRepository = distributionChannelRepository;
        this.subRegionRepository = subRegionRepository;
        this.userDistributorRepository = userDistributorRepository;
        this.distributorRepository = distributorRepository;
        this.distributorProfileRepository = distributorProfileRepository;
        this.helper = helper;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.UserManagementService#getListOfUsersByRole(String)
     */
    public List<GridUserRoleDTO> getListOfUsersByRole(String roleCode) {
        List<GridUserRoleDTO> users = new ArrayList<GridUserRoleDTO>();
        List<UserVO> list = userRepository.findByRoleCode(roleCode);
        helper.filterUsers(list,roleCode);
        if(!list.isEmpty()) {
            users = mapper.mapList(GridUserRoleDTO.class,list);
        }
        return users;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.UserManagementService#createUpdateUserRole(com.monsanto.customerlink.core.service.dto.UserRoleDTO)
     */
    public boolean createUpdateUserRole(UserRoleDTO userRoleDTO) throws CustomerLinkBusinessException {

        boolean createOrUpdate = true;

        // validate input basic parameters and input parameters by role
        RoleEnum roleEnum = validateUserByRole(userRoleDTO);

        // get user if exists
        UserVO user = getUser(userRoleDTO);

        // verify if exist users with same characteristics
        List<UserVO> users = getUsersTypeOfRole( userRoleDTO, user!=null ? user.getUserID() :null );

        if(!users.isEmpty()) {
            throw new AssignedUserException(new Object[]{ToStringBuilder.reflectionToString(userRoleDTO)});
        }

        user = userRepository.save(complementUser(user,userRoleDTO,roleEnum));

        if(helper.isCsrOrApprover(roleEnum)) {
            updateDistributors(user,userRoleDTO);
        }

        helper.replicateProcessForRCD(user,userRoleDTO,roleEnum,this);

        return createOrUpdate;
    }

    @Override
    /**
     * @see com.monsanto.customerlink.core.service.UserManagementService#removeUserRole(com.monsanto.customerlink.core.service.dto.UserRoleDTO)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public boolean removeUserRole(UserRoleDTO userRoleDTO) throws CustomerLinkBusinessException {

        boolean deleted = false;

        if(userRoleDTO!=null) {

            UserVO userVO = getUser(userRoleDTO);

            if(userVO!=null) {

                RoleEnum roleEnum = getTypeRole(userVO.getRoleVO());

                // for RCD and RBM roles can not delete records
                if(!(isType(roleEnum,RoleEnum.RCD) || isType(roleEnum,RoleEnum.RBM))) {

                    validateUserForRemove(userRoleDTO, userVO);

                    if(helper.isCsrOrApprover(roleEnum)) {
                        deleteUserDistributors(userVO);
                    }

                    userRepository.delete(userVO);
                    userRepository.flush();
                    deleted = true;
                }
            }
        }

        return deleted;
    }

    private void validateUserForRemove(UserRoleDTO userRoleDTO,UserVO userVO) throws CustomerLinkBusinessException {

        Collection<WFApprovalMemberVO> members = userVO.getWfApprovalMemberVOs();

        if(!members.isEmpty()) {
            throw new UserNotAvailableForRemoveException(new Object[]{ToStringBuilder.reflectionToString(userRoleDTO)});
        }

        Set<UserDistributorVO> users = userVO.getUserDistributorVOs();

        if(!users.isEmpty()) {
            throw new UserNotAvailableForRemoveException(new Object[]{ToStringBuilder.reflectionToString(userRoleDTO)});
        }
    }

    @Override
    public List<UserVO> getListOfUserByDistributorProfileId(Long idDistributorProfile) {

        List<UserVO> users = new ArrayList<UserVO>();

        if(idDistributorProfile!=null) {

            List<String> commonRolesCodes = new ArrayList<String>();
            commonRolesCodes.add(RoleEnum.MARKETING.getCode());
            commonRolesCodes.add(RoleEnum.PLANNING.getCode());
            commonRolesCodes.add(RoleEnum.PRICING.getCode());

            // append common roles
            appendList(users,userRepository.findByRoleCodes(commonRolesCodes));

            DistributorProfileVO distributorProfileVO = distributorProfileRepository.findOne(idDistributorProfile);

            if(distributorProfileVO!=null) {

                UserVO userVO = mapper.map(distributorProfileVO,UserVO.class);

                // append RCD list if exist
                userVO.setRoleVO(roleRepository.findByCode(RoleEnum.RCD.getCode()));
                appendList(users,userRepository.findByParametersWithOutUserId(userVO,null,distributorProfileVO.getDistributorByDistributorCode().getDistributorCode()));

                // append RBM list if exist
                SubRegionVO subRegionVO = new SubRegionVO();
                subRegionVO.setSubRegionCode(distributorProfileVO.getSubRegionCode());

                userVO = new UserVO();
                userVO.setSubRegionVO(subRegionVO);

                userVO.setRoleVO(roleRepository.findByCode(RoleEnum.RBM.getCode()));
                appendList(users, userRepository.findByParametersWithOutUserId(userVO, null,null));

                // append CSR list if exist
                appendList(users,userRepository.findByRoleAndDistributorCode(RoleEnum.CSR.getCode(), distributorProfileVO.getDistributorByDistributorCode().getDistributorCode()));

                // append AGROCHEMICAL_APPROVER list if exist
                appendList(users,userRepository.findByRoleAndDistributorCode(RoleEnum.APPROVER.getCode(), distributorProfileVO.getDistributorByDistributorCode().getDistributorCode()));
            }
        }

        return users;
    }



    private void appendList(List<UserVO> destination,List<UserVO> source) {
        if(!source.isEmpty()) {
            destination.addAll(source);
        }
    }

    private UserVO getUser(UserRoleDTO userRoleDTO) {

        UserVO user = null;

        // the user already exists
        if(userRoleDTO.getIdUser()!=null) {
            user = userRepository.findByUserID(userRoleDTO.getIdUser());
        }

        return user;
    }

    private void updateDistributors(UserVO user, UserRoleDTO userRoleDTO) {

        deleteUserDistributors(user);

        if(userRoleDTO.getListOfDistributors()!=null && !userRoleDTO.getListOfDistributors().isEmpty()) {

            List<UserDistributorVO> listOfNewDistributors = new ArrayList<UserDistributorVO>();

            for(DistributorDTO d : userRoleDTO.getListOfDistributors()) {

                UserDistributorVO udp = new UserDistributorVO();
                udp.setUserDistributorVO(user);

                udp.setDistributorVO(distributorRepository.findByDistributorCode(d.getDistributorCode()));

                listOfNewDistributors.add(udp);
            }

            userDistributorRepository.save(listOfNewDistributors);
        }
    }

    private void deleteUserDistributors(UserVO user) {

        List<UserDistributorVO> distributors = userDistributorRepository.findByUser(user.getUserID());

        if(!distributors.isEmpty()) {
            userDistributorRepository.delete(distributors);
            userDistributorRepository.flush();
        }

    }

    private RoleVO getRole(UserRoleDTO userRoleDTO) {
        return roleRepository.findByCode(userRoleDTO.getRoleDTO().getCode());
    }

    private RoleEnum validateUserByRole(UserRoleDTO userRoleDTO) throws CustomerLinkBusinessException {

        if(userRoleDTO!=null) {

            validateRole(userRoleDTO);

            RoleEnum roleEnum = getTypeRole(getRole(userRoleDTO));

            if(isType(roleEnum, RoleEnum.PLANNING)) {

                validateUserName(userRoleDTO,roleEnum);
            } else if(isType(roleEnum, RoleEnum.PRICING)) {

                validateUserName(userRoleDTO, roleEnum);
            } else if(helper.isCsrOrApprover(roleEnum)) {

                validateUserName(userRoleDTO, roleEnum);
            } else if(isType(roleEnum, RoleEnum.MARKETING)) {

                validateUserName(userRoleDTO, roleEnum);
                validateBrand(userRoleDTO, roleEnum);
            } else  if(isType(roleEnum, RoleEnum.RCD)) {

                validateUserName(userRoleDTO, roleEnum);
                validateBrand(userRoleDTO, roleEnum);
                validateKey(userRoleDTO, roleEnum);
                validateSubRegion(userRoleDTO, roleEnum);

            } else if(isType(roleEnum, RoleEnum.RBM)) {
                validateUserName(userRoleDTO, roleEnum);
                validateSubRegion(userRoleDTO, roleEnum);
            }

            return roleEnum;

        }else{
            throw new IllegalArgumentException(" The input parameters can not be null ");
        }

    }

    private RoleEnum getTypeRole(RoleVO roleVO) {

        RoleEnum roleEnum = null;

        if(roleVO.getCode().equals(RoleEnum.MARKETING.getCode())) {
            roleEnum = RoleEnum.MARKETING;
        } else if(roleVO.getCode().equals(RoleEnum.RCD.getCode())) {
            roleEnum = RoleEnum.RCD;
        } else if(roleVO.getCode().equals(RoleEnum.RBM.getCode())) {
            roleEnum = RoleEnum.RBM;
        } else if(roleVO.getCode().equals(RoleEnum.CSR.getCode())) {
            roleEnum = RoleEnum.CSR;
        } else if(roleVO.getCode().equals(RoleEnum.PLANNING.getCode())) {
            roleEnum = RoleEnum.PLANNING;
        } else if(roleVO.getCode().equals(RoleEnum.PRICING.getCode())) {
            roleEnum = RoleEnum.PRICING;
        } else if(roleVO.getCode().equals(RoleEnum.APPROVER.getCode())) {
            roleEnum = RoleEnum.APPROVER;
        }

        return roleEnum;
    }


    private void validateRole(UserRoleDTO userRoleDTO) throws CustomerLinkBusinessException{

        if(userRoleDTO.getRoleDTO() == null || userRoleDTO.getRoleDTO().getCode() == null) {
            throw new InvalidUserParametersException(new Object[]{RoleEnum.UNDEFINED_ROLE.getRequiredParameters(),RoleEnum.UNDEFINED_ROLE});
        }

        if( getRole(userRoleDTO) == null) {
            throw new InvalidUserParametersException(new Object[]{RoleEnum.UNDEFINED_ROLE.getRequiredParameters(),RoleEnum.UNDEFINED_ROLE});
        }

    }

    private void validateBrand(UserRoleDTO userRoleDTO, RoleEnum roleEnum) throws CustomerLinkBusinessException {

        if(userRoleDTO.getBrandDTO() == null ||  StringUtils.isEmpty(userRoleDTO.getBrandDTO().getBrandCode())) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if( brandRepository.findOne(userRoleDTO.getBrandDTO().getBrandCode()) == null) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

    }

    private void validateKey(UserRoleDTO userRoleDTO, RoleEnum roleEnum) throws CustomerLinkBusinessException {

        if(userRoleDTO.getKeyDTO() == null) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if( StringUtils.isEmpty(userRoleDTO.getKeyDTO().getSalesOrgCode())) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if(salesOrganizationRepository.findOne(userRoleDTO.getKeyDTO().getSalesOrgCode()) == null) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if( StringUtils.isEmpty(userRoleDTO.getKeyDTO().getSalesDivCode())) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if(salesDivisionRepository.findOne(userRoleDTO.getKeyDTO().getSalesDivCode()) == null) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if( StringUtils.isEmpty(userRoleDTO.getKeyDTO().getDistChannelCode())) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if(distributionChannelRepository.findByDistributionChannelCode(userRoleDTO.getKeyDTO().getDistChannelCode()) == null) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }
    }

    private void validateSubRegion(UserRoleDTO userRoleDTO, RoleEnum roleEnum) throws CustomerLinkBusinessException {

        if(userRoleDTO.getSubRegionDTO() == null || StringUtils.isEmpty(userRoleDTO.getSubRegionDTO().getSubRegionCode())) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

        if( subRegionRepository.findBySubRegionCode(userRoleDTO.getSubRegionDTO().getSubRegionCode()) == null ) {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }

    }

    private boolean isType(RoleEnum type, RoleEnum otherType) {
        return type.equals(otherType);
    }

    private List<UserVO> getUsersTypeOfRole(UserRoleDTO userRoleDTO, Long userId) throws InvalidUserParametersException {

        UserVO userToSearch = mapper.map(userRoleDTO, UserVO.class );

        List<UserVO> users = userRepository.findByParametersWithOutUserId(userToSearch, userId, null);

        return users;

    }

    private UserVO complementUser(UserVO currentUser,UserRoleDTO userRoleDTO, RoleEnum roleEnum) {

        if(currentUser == null) {
            currentUser = new UserVO();
            currentUser.setRoleVO(getRole(userRoleDTO));
        }

        if(isType(roleEnum, RoleEnum.MARKETING) || isType(roleEnum, RoleEnum.RCD )) {
            currentUser.setBrandVO(brandRepository.findOne(userRoleDTO.getBrandDTO().getBrandCode()));
        }

        currentUser.setUserName( userRoleDTO.getUserName() );
        currentUser.setEmail(userRoleDTO.getEmail());

        return currentUser;
    }

    private void validateUserName(UserRoleDTO userRoleDTO, RoleEnum roleEnum) throws CustomerLinkBusinessException {

        if(StringUtils.isNotEmpty(userRoleDTO.getUserName())){

            boolean userNameValid = false;
            userRoleDTO.setUserName(userRoleDTO.getUserName().toUpperCase());

            try {

                prepareUserSearch();

                PersonInfo[] listOfPersons = getPeople(userRoleDTO.getUserName());

                if(listOfPersons.length>0){

                    for(PersonInfo p : listOfPersons) {
                        if(p.getUserId().equals(userRoleDTO.getUserName())) {
                            userRoleDTO.setEmail(p.getEmail()+ CustomerLinkCoreConstants.MONSANTO_EMAIL_DOMAIN);
                            userNameValid = true;
                            break;
                        }
                    }
                }

            } catch (Exception e) {
                log.error("Error when trying to retrieve data for the [user name] : "+userRoleDTO.getUserName());
            }

            if(!userNameValid) {
                throw new InvalidUserException(new Object[]{userRoleDTO.getUserName()});
            }

        } else {
            throw new InvalidUserParametersException(new Object[]{roleEnum.getRequiredParameters(),roleEnum});
        }
    }

    private void prepareUserSearch() {
        System.setProperty(CustomerLinkCoreConstants.PEOPLE_PICKER_SERVER, CustomerLinkCoreConstants.PEOPLE_PICKER_SERVER_VALUE);
        System.setProperty(CustomerLinkCoreConstants.PEOPLE_PICKER_VDIR, CustomerLinkCoreConstants.PEOPLE_PICKER_VDIR_VALUE);
		System.setProperty(CustomerLinkCoreConstants.PEOPLE_PICKER_END_POINT, CustomerLinkCoreConstants.PEOPLE_PICKER_END_POINT_VALUE);
    }

    public PersonInfo[] getPeople(String userName) throws Exception {
        PeopleService peopleService = new PeopleService();
        return peopleService.GetPeople(CustomerLinkCoreConstants.BLANK_VALUE,
                CustomerLinkCoreConstants.BLANK_VALUE,
                CustomerLinkCoreConstants.BLANK_VALUE,
                CustomerLinkCoreConstants.BLANK_VALUE,
                userName,
                CustomerLinkCoreConstants.BLANK_VALUE,
                CustomerLinkCoreConstants.BLANK_VALUE);
    }
}