package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.exception.RCDNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<UserVO> findUserBySubregionAndRole(String subregionCode, Long roleCode) {

        UserVO userVO = new UserVO();
        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode(subregionCode);

        RoleVO roleVO = new RoleVO();
        roleVO.setRoleCode(roleCode);

        userVO.setSubRegionVO(subRegionVO);
        userVO.setRoleVO(roleVO);

        return userRepository.findByParameters(userVO,null);
    }

    @Override
    public List<UserVO> findRoleByUserCode(String userCode) {
        UserVO paramUserVO = new UserVO();
        paramUserVO.setSapId(userCode);
        return userRepository.findByParameters(paramUserVO,null);
    }

    public UserVO saveUser(UserVO userVO, String subRegionCode, Long roleCode) {

        validateParameters(userVO, subRegionCode, roleCode);
        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode(subRegionCode);

        RoleVO roleVO = new RoleVO();
        roleVO.setRoleCode(roleCode);

        userVO.setSubRegionVO(subRegionVO);
        userVO.setRoleVO(roleVO);

        List<UserVO> userVOList = userRepository.findByParameters(userVO,null);

        if (userVOList.isEmpty()) {//checking if not exist user with that configuration
            userVO = userRepository.save(userVO);
        }//else update

        return userVO;
    }

    @Override
    public List<UserVO> findRoleByUserName(String userName) {
        return userRepository.findByUserName(userName);
    }

    @Override
    public UserVO retrieveRCD(String userCode, DistributorConfigDTO distributorProfile) throws RCDNotFoundException {
        validateInputParameters(userCode, distributorProfile);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode(distributorProfile.getSubRegionCode());

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        UserVO userVO = new UserVO();
        userVO.setSalesOrganizationVO(new SalesOrganizationVO(distributorProfile.getSalesOrgCode()));
        userVO.setDistributionChannelVO(new DistributionChannelVO(distributorProfile.getDistChCode()));
        userVO.setSalesDivisionVO(new SalesDivisionVO(distributorProfile.getSalesDivCode()));
        userVO.setSubRegionVO(subRegionVO);
        userVO.setSapId(userCode);
        userVO.setRoleVO(roleVO);

        List<UserVO> listRepresentativeVO = userRepository.findByParameters(userVO, distributorProfile.getDistributor().getDistributorCode());

        if (listRepresentativeVO.isEmpty()) {
            throw new RCDNotFoundException(new Object[]{userCode, ToStringBuilder.reflectionToString(distributorProfile)});
        }

        return listRepresentativeVO.get(0);
    }

    @Override
    public List<UserVO> retrieveRCDs(DistributorConfigDTO distributorProfile) {
        UserVO parameters = new UserVO();
        parameters.setRoleVO(new RoleVO(RoleEnum.RCD.getCode()));
        if (null != distributorProfile) {
            parameters.setSalesOrganizationVO(new SalesOrganizationVO(distributorProfile.getSalesOrgCode()));
            parameters.setDistributionChannelVO(new DistributionChannelVO(distributorProfile.getDistChCode()));
            parameters.setSalesDivisionVO(new SalesDivisionVO(distributorProfile.getSalesDivCode()));
            parameters.setSubRegionVO(new SubRegionVO(distributorProfile.getSubRegionCode()));
        }
        return userRepository.findByParameters(parameters, distributorProfile.getDistributor().getDistributorCode());
    }

    @Override
    public List<UserVO> retrieveUsersByDistributorAndRole(String idDistributor, RoleEnum roleEnum) {
        List<UserVO> users = null;
        if(StringUtils.isNotBlank(idDistributor) && roleEnum != null) {
            users  = userRepository.findByRoleAndDistributorCode(roleEnum.getCode(), idDistributor);
        }
        return users;
    }

    private void validateInputParameters(String sapUserId, DistributorConfigDTO distributorProfile) {
        CustomerLinkUtils.isValidParameter(sapUserId);
        CustomerLinkUtils.isValidParameter(distributorProfile);
        CustomerLinkUtils.isValidParameter(distributorProfile.getSalesOrgCode());
        CustomerLinkUtils.isValidParameter(distributorProfile.getDistChCode());
        CustomerLinkUtils.isValidParameter(distributorProfile.getSalesDivCode());
        CustomerLinkUtils.isValidParameter(distributorProfile.getSubRegionCode());
    }

    private void validateParameters(UserVO userVO, String subRegionCode, Long roleCode) {
        if (userVO.getSapId() == null || StringUtils.isEmpty(subRegionCode) || roleCode == null) {
            throw new IllegalArgumentException();
        }
    }
}
