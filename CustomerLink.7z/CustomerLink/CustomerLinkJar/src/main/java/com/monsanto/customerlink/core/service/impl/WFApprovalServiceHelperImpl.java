package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.dto.messages.WFSpecialOrderMessageVO;
import com.monsanto.customerlink.core.service.WFApprovalServiceHelper;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class WFApprovalServiceHelperImpl implements WFApprovalServiceHelper {


    private UserRepository userRepository;

    @Autowired
    public WFApprovalServiceHelperImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Map<String, ?> getMessageMapFromFinalMap(Map<String, Object> map) {
        Map<String, ?> messageMap = (Map<String, ?>) map.get(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE);
        if(messageMap == null) {
            throw new RuntimeException("The message information is required to build the e-mail correctly.");
        }
        return messageMap;
    }

    @Override
    public DistributorConfigDTO getDistributorConfigFromFinalMap(Map<String, Object> map) {
        DistributorConfigDTO dc = (DistributorConfigDTO) map.get(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MESSAGE);
        if(dc == null){
            throw new RuntimeException("The DistributorConfigDTO is required to build the e-mail correctly.");
        }
        return dc;
    }

    @Override
    public void updateFinalMapWithUser(Long userId, Map<String, Object> map) {
        if(userId != null) {
            UserVO user = userRepository.findByUserID(userId);
            if(user == null) {
                throw new RuntimeException("The user information is required to build the e-mail correctly.");
            }
            Map<String, Object> mapMessage = (Map<String, Object>) map.get(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE);
            WFSpecialOrderMessageVO msg = (WFSpecialOrderMessageVO) mapMessage.get(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE);
            msg.setUserName(user.getUserName());
            msg.setUserRole(user.getRoleVO().getDescription());
            mapMessage.put(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE,msg);
            map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE, mapMessage);
        }
    }
}