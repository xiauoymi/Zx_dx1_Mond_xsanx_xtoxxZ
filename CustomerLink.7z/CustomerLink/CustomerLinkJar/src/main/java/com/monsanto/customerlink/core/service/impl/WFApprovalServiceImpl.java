package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.Notification;
import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.WFApprovalServiceHelper;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.exception.WFApprovalAlreadyExistException;
import com.monsanto.customerlink.core.service.exception.WFApprovalMissingConfigurationException;
import com.monsanto.customerlink.core.service.exception.WFApprovalMissingUsersMembersConfigurationException;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.WFApprovalMemberRepository;
import com.monsanto.customerlink.persistence.repositories.WFApprovalRepository;
import com.monsanto.customerlink.persistence.repositories.WFApprovalTypeRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public abstract class WFApprovalServiceImpl {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private WFApprovalRepository wfApprovalRepository;
    private WFApprovalTypeRepository wfApprovalTypeRepository;
    private WFApprovalMemberRepository wfApprovalMemberRepository;
    private NotificationSender notificationSender;
    private WFApprovalTypeEnum workFlowType;
    private WFApprovalServiceHelper helper;

    public WFApprovalServiceImpl(WFApprovalRepository wfApprovalRepository, WFApprovalTypeRepository wfApprovalTypeRepository,
                                 WFApprovalMemberRepository wfApprovalMemberRepository, NotificationSender notificationSender,
                                 WFApprovalTypeEnum wfApprovalTypeEnum, WFApprovalServiceHelper helper) {
        this.wfApprovalRepository = wfApprovalRepository;
        this.wfApprovalTypeRepository = wfApprovalTypeRepository;
        this.wfApprovalMemberRepository = wfApprovalMemberRepository;
        this.notificationSender = notificationSender;
        this.workFlowType = wfApprovalTypeEnum;
        this.helper = helper;
    }

    /**
     * Build the notification message object by approval
     * @param businessEntityId businessEntityId business object identifier to be approve
     * @return
     */
    protected abstract Map<String, ?> buildObjectMessageNotificationOfApproval(Long businessEntityId);

    /**
     * Build the notification message object by rejection
     * @param businessEntityId businessEntityId business object identifier to be approve
     * @return
     */
    protected abstract Map<String, ?> buildObjectMessageNotificationOfRejection(Long businessEntityId);

    /**
     * Retrieves users - roles associated with business entity
     * @param businessEntityId
     * @return
     */
    protected abstract List<UserVO> obtainUsersByBusinessEntity(Long businessEntityId);

    /**
     * @see com.monsanto.customerlink.core.service.WFApprovalService#createWorkFlowApproval(Long)
     */
    public boolean createWorkFlowApproval(Long businessEntityId) throws CustomerLinkBusinessException {

        boolean created;

        if(businessEntityId!=null) {

            List<Integer> listOfStatus = Arrays.asList(new Integer[]{WFApprovalStatusEnum.PENDING_APPROVAL.id(),WFApprovalStatusEnum.IN_PROGRESS.id()});
            Collection<WFApprovalVO> listOfWFApproval = wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(businessEntityId, listOfStatus, workFlowType.id());

            if(null == listOfWFApproval || listOfWFApproval.isEmpty()) {

                created = createWorkFlowApprovalProcess(businessEntityId);

            }else {
                throw new WFApprovalAlreadyExistException(new Object[]{businessEntityId,workFlowType});
            }

        }else{
            throw new IllegalArgumentException("Input parameters are incomplete");
        }

        return  created;
    }

    private boolean createWorkFlowApprovalProcess(Long businessEntityId)  throws CustomerLinkBusinessException  {

        boolean created;

        WFApprovalTypeVO approvalTypeVO = wfApprovalTypeRepository.findOne(workFlowType.id());

        if(approvalTypeVO != null && approvalTypeVO.getWfApprovalHierarchyVOs()!=null && !approvalTypeVO.getWfApprovalHierarchyVOs().isEmpty()) {

            WFApprovalVO wfApprovalVO = new WFApprovalVO();
            wfApprovalVO.setBusinessEntityId(businessEntityId);
            wfApprovalVO.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
            wfApprovalVO.setWfApprovalTypeVO(approvalTypeVO);
            wfApprovalVO.setWfApprovalMemberVOs(buildListOfApprovalMembers(wfApprovalVO, approvalTypeVO.getWfApprovalHierarchyVOs(), businessEntityId));

            wfApprovalRepository.save(wfApprovalVO);

            this.sendNotificationOfApproval(this.getFirstEmailsToApprove(wfApprovalVO),1,wfApprovalVO,businessEntityId,null);

            created = true;

        }else {
            throw new WFApprovalMissingConfigurationException(new Object[]{workFlowType,workFlowType.id()});
        }

        return created;
    }

    private List<String> getFirstEmailsToApprove(WFApprovalVO wfApprovalVO) {
        List<String> email = new ArrayList<String>();
        for(WFApprovalMemberVO m : wfApprovalVO.getWfApprovalMemberVOs()) {
            if(m.getHierarchyOrder().longValue() == 1) {
                email.add(m.getUserVO().getEmail());
            }
        }
        return email;
    }

    private Collection<WFApprovalMemberVO> buildListOfApprovalMembers(WFApprovalVO wfApprovalVO, Set<WFApprovalHierarchyVO> listOfApprovalHierarchy, Long businessEntityI) throws WFApprovalMissingUsersMembersConfigurationException{

        Collection<WFApprovalMemberVO> members = new HashSet<WFApprovalMemberVO>();

        int status = 0, statusCount = 0;

        List<UserVO> usersByBusinessEntity = obtainUsersByBusinessEntity(businessEntityI);

        if(!usersByBusinessEntity.isEmpty()) {

            for(WFApprovalHierarchyVO h : listOfApprovalHierarchy) {

                if(statusCount == 0) {
                    status = WFApprovalStatusEnum.PENDING_APPROVAL.id();
                } else if(statusCount == 1) {
                    status = WFApprovalStatusEnum.PENDING_PREVIOUS_APPROVAL.id();
                }

                List<UserVO> listOfUser = retrieveUsersByRole(h.getRoleHierarchy().getCode(), usersByBusinessEntity);

                if(listOfUser!=null && !listOfUser.isEmpty()) {

                    for(UserVO u : listOfUser) {

                        WFApprovalMemberVO   member = new WFApprovalMemberVO();
                        member.setUserVO(u);
                        member.setWfApprovalVO(wfApprovalVO);
                        member.setStatus(status);
                        member.setHierarchyOrder(h.getHierarchyOrder());
                        members.add(member);
                    }

                }else {
                    throw new WFApprovalMissingUsersMembersConfigurationException(new Object[]{workFlowType,workFlowType.id()});
                }

                statusCount++;
            }

        }else {
            throw new WFApprovalMissingUsersMembersConfigurationException(new Object[]{workFlowType,workFlowType.id()});
        }

        return members;
    }


    private List<UserVO> retrieveUsersByRole(String code, List<UserVO> usersByBusinessEntity) {

        List<UserVO> users = new ArrayList<UserVO>();

        for(UserVO u : usersByBusinessEntity) {
            if(u.getRoleVO().getCode().equals(code)) {
                users.add(u);
            }
        }

        return users;
    }


    /**
     * @see com.monsanto.customerlink.core.service.WFApprovalService#obtainApprovalsPendingBusinessByUser(Long)
     */
    public Collection<Long> obtainApprovalsPendingBusinessByUser(Long userId) {
        Collection<Long> listOfBusinessEntityId = new ArrayList<Long>();
        if(userId!= null && workFlowType!=null) {
            List<Integer> listOfStatus = Arrays.asList(new Integer[]{WFApprovalStatusEnum.PENDING_APPROVAL.id(),WFApprovalStatusEnum.IN_PROGRESS.id()});
            listOfBusinessEntityId = wfApprovalRepository.findBusinessIdsByParameters(workFlowType.id(), listOfStatus, WFApprovalStatusEnum.PENDING_APPROVAL.id(), userId);
        }
        return listOfBusinessEntityId;
    }

    /**
     * @see com.monsanto.customerlink.core.service.WFApprovalService#approveWorkflowByUser(Long,Long)
     */
    public synchronized boolean approveWorkflowByUser(Long businessEntityId, Long userId) {

        boolean approved = false;

        if(validateInputParameters(businessEntityId, workFlowType, userId)) {

            List<Integer> listOfStatus = Arrays.asList(new Integer[]{WFApprovalStatusEnum.PENDING_APPROVAL.id(),WFApprovalStatusEnum.IN_PROGRESS.id()});
            Collection<WFApprovalVO> listOfWFApproval = wfApprovalRepository.findByParameters(businessEntityId, listOfStatus, workFlowType.id(), WFApprovalStatusEnum.PENDING_APPROVAL.id(), userId);

            if(!listOfWFApproval.isEmpty()) {

                WFApprovalVO approval = listOfWFApproval.iterator().next();

                // updates the status of the members by an approval
                updateStatusListOfMembersByAnApproval(approval, businessEntityId, userId);

                approved = true;
            }
        }

        return approved;
    }

    private void updateStatusListOfMembersByAnApproval(WFApprovalVO approval, Long businessEntityId, Long userId) {

        long hierarchyOrder = 0;

        // will look for all the elements to find those where the status is pending approval and change the status to Approved
        for(WFApprovalMemberVO m : approval.getWfApprovalMemberVOs()) {
            if(m.getStatus().equals(WFApprovalStatusEnum.PENDING_APPROVAL.id())) {
                m.setStatus(WFApprovalStatusEnum.APPROVED.id());
                hierarchyOrder = m.getHierarchyOrder();
            }
        }

        // increases the order of hierarchy
        hierarchyOrder++;

        // look for all elements until you find those that match the following hierarchical order and updated your status to pending approval

        // list containing the emails to inform members that continue in the approval workflow
        List<String> listOfEmail = new ArrayList<String>();

        for(WFApprovalMemberVO m : approval.getWfApprovalMemberVOs()) {
            if(m.getHierarchyOrder().longValue() == hierarchyOrder) {
                m.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
                listOfEmail.add(m.getUserVO().getEmail());
            }
        }

        wfApprovalMemberRepository.save(approval.getWfApprovalMemberVOs());

        // update the status of workflow by an approval
        updateWorkFlowStatusByAnApproval(approval);

        if(!listOfEmail.isEmpty()) {
            sendNotificationOfApproval(listOfEmail, hierarchyOrder-1, approval, businessEntityId,userId);
        }
    }

    private void updateWorkFlowStatusByAnApproval(WFApprovalVO approval) {

        boolean allApprovals = true;

        for(WFApprovalMemberVO m : approval.getWfApprovalMemberVOs()) {
            if(m.getStatus().longValue() != WFApprovalStatusEnum.APPROVED.id() ) {
                allApprovals = false;
                break;
            }
        }

        // checks if all approvals have been made in this case, the workflow updates the status of "approved"
        if(allApprovals) {
            approval.setStatus(WFApprovalStatusEnum.APPROVED.id());
            wfApprovalRepository.save(approval);
        }

        // checks whether the workflow is in "pending approval", in this case, change the status to "in progress"
        if(approval.getStatus().equals(WFApprovalStatusEnum.PENDING_APPROVAL.id())){
            approval.setStatus(WFApprovalStatusEnum.IN_PROGRESS.id());
            wfApprovalRepository.save(approval);
        }
    }

    /**
     * @see com.monsanto.customerlink.core.service.WFApprovalService#rejectWorkflowByUser(Long, Long)
     */
    public synchronized boolean rejectWorkflowByUser(Long businessEntityId, Long userId) {

        boolean rejected = false;

        if(validateInputParameters(businessEntityId, workFlowType, userId)) {

            List<Integer> listOfStatus = Arrays.asList(new Integer[]{WFApprovalStatusEnum.PENDING_APPROVAL.id(),WFApprovalStatusEnum.IN_PROGRESS.id()});
            Collection<WFApprovalVO> listOfWFApproval = wfApprovalRepository.findByParameters(businessEntityId, listOfStatus, workFlowType.id(), WFApprovalStatusEnum.PENDING_APPROVAL.id(), userId);

            if(!listOfWFApproval.isEmpty()) {

                WFApprovalVO approval = listOfWFApproval.iterator().next();

                updateStatusListOfMembersByRejection(approval, businessEntityId, userId);

                rejected = true;
            }
        }

        return rejected;
    }

    private void updateStatusListOfMembersByRejection(WFApprovalVO approval, Long businessEntityId, Long userId) {

        long hierarchyOrder = 0;

        // will look for all the elements to find those where the status is pending approval and change the status to REJECTED
        for(WFApprovalMemberVO m : approval.getWfApprovalMemberVOs()) {
            if(m.getStatus().equals(WFApprovalStatusEnum.PENDING_APPROVAL.id())) {
                m.setStatus(WFApprovalStatusEnum.REJECTED.id());
                wfApprovalMemberRepository.save(m);
                hierarchyOrder = m.getHierarchyOrder();
            }
        }

        // is assigned the status "Rejected"
        approval.setStatus(WFApprovalStatusEnum.REJECTED.id());

        // updating the workflow
        wfApprovalRepository.save(approval);

        sendNotificationOfRejection(hierarchyOrder,approval,businessEntityId,userId);
    }

     private void sendNotificationOfRejection(long hierarchyOrder, WFApprovalVO approval, Long businessEntityId, Long userId) {

        Integer IdRejectionMessage = null;

        for(WFApprovalHierarchyVO h : approval.getWfApprovalTypeVO().getWfApprovalHierarchyVOs()) {
            if(h.getHierarchyOrder().longValue() == hierarchyOrder) {
                IdRejectionMessage = h.getIdRejectionMessage();
                break;
            }
        }

        if(IdRejectionMessage!=null) {
            Map<String, Object> map = (Map<String, Object>)this.buildObjectMessageNotificationOfRejection(businessEntityId);
            helper.updateFinalMapWithUser(userId,map);
            try{
                notificationSender.send(getNotificationByIdMessage(IdRejectionMessage).newNotification(helper.getDistributorConfigFromFinalMap(map), helper.getMessageMapFromFinalMap(map)));
            } catch (Exception e) {
                log.error("was not possible to send notification of rejection approval workflow, Entity Business: "+businessEntityId+" WFApprovalVO: "+ToStringBuilder.reflectionToString(approval) +" DistributorConfigDTO: "+ ToStringBuilder.reflectionToString(helper.getDistributorConfigFromFinalMap(map)),e);
            }
        }
    }

    private boolean validateInputParameters(Long businessEntityId, WFApprovalTypeEnum workFlowTypeEnum, Long userId) {

        boolean isValid = false;

        if(businessEntityId!=null && workFlowTypeEnum!=null && userId!=null) {
            isValid = true;
        }

        return isValid;
    }

    private void sendNotificationOfApproval(List<String> listOfEmail, long hierarchyOrder, WFApprovalVO approval, Long businessEntityId, Long userId) {

        Integer idApprovalMessage = null;

        for(WFApprovalHierarchyVO h : approval.getWfApprovalTypeVO().getWfApprovalHierarchyVOs()) {
            if(h.getHierarchyOrder().longValue() == hierarchyOrder) {
                idApprovalMessage = h.getIdApprovalMessage();
                break;
            }
        }

        if(idApprovalMessage!=null) {

            Map<String, Object> map = (Map<String, Object>)this.buildObjectMessageNotificationOfApproval(businessEntityId);
            helper.updateFinalMapWithUser(userId,map);
            Notification notification = buildNotificationOfApproval(listOfEmail,idApprovalMessage, helper.getMessageMapFromFinalMap(map));

            if(notification!=null) {
                try{
                    notificationSender.send(notification);
                    NotificationType nt = userId == null ? NotificationType.WF_SPECIAL_ORDER_CSR_NOTIFICATION_INIT: NotificationType.WF_SPECIAL_ORDER_CSR_NOTIFICATION;
                    notificationSender.send(nt.newNotification(helper.getDistributorConfigFromFinalMap(map),helper.getMessageMapFromFinalMap(map)));
                }catch (Exception e) {
                    log.error("It was not possible to send mail for approval flow, Entity Business: "+businessEntityId+" WFApprovalVO: "+ToStringBuilder.reflectionToString(approval)+" listOfEmail: "+listOfEmail+" idApprovalMessage: "+idApprovalMessage,e);
                }
            }
        }
    }

    /**
     * Can build the notification On approval of a workflow
     * @param listOfEmail
     * @param idApprovalMessage
     * @param map
     * @return
     */
    public Notification buildNotificationOfApproval(List<String> listOfEmail, Integer idApprovalMessage, Map<String,?> map) {
        return getNotificationByIdMessage(idApprovalMessage).newNotification(map).tos(listOfEmail);
    }

    /**
     * Get the kind of modification of email input using as parameter the identifier associated
     * @param id message type identifier
     * @return  NotificationType is the notification type identifier associated
     */
    protected NotificationType getNotificationByIdMessage(int id) {

        NotificationType notificationType = null;

        switch(id){
            case 1:
               notificationType = NotificationType.WF_SPECIAL_ORDER_APPROVAL;
               break;
            case 2:
               notificationType = NotificationType.WF_SPECIAL_ORDER_REJECTED;
               break;
            default:
        }

        return notificationType;
    }

}