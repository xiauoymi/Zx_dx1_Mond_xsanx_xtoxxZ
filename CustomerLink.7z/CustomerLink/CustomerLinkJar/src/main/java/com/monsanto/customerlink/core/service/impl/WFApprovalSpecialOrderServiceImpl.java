package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.dto.messages.WFSpecialOrderMessageVO;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.WFApprovalServiceHelper;
import com.monsanto.customerlink.core.service.WFApprovalSpecialOrderService;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class WFApprovalSpecialOrderServiceImpl extends  WFApprovalServiceImpl implements WFApprovalSpecialOrderService {

    private OrderRepository orderRepository;
    private SubRegionRepository subRegionRepository;
    private UserManagementService userManagementService;
    private OrderDetailRepository orderDetailRepository;

    @Autowired
    public WFApprovalSpecialOrderServiceImpl(WFApprovalRepository wfApprovalRepository, WFApprovalTypeRepository wfApprovalTypeRepository,
                                             WFApprovalMemberRepository wfApprovalMemberRepository,
                                             NotificationSender notificationSender, OrderRepository orderRepository,
                                             SubRegionRepository subRegionRepository,
                                             UserManagementService userManagementService,
                                             OrderDetailRepository orderDetailRepository,
                                             WFApprovalServiceHelper helper) {
        super(wfApprovalRepository, wfApprovalTypeRepository,wfApprovalMemberRepository, notificationSender, WFApprovalTypeEnum.SPECIAL_ORDER,helper);
        this.orderRepository = orderRepository;
        this.subRegionRepository = subRegionRepository;
        this.userManagementService = userManagementService;
        this.orderDetailRepository = orderDetailRepository;
    }

    @Override
    protected Map<String, ?> buildObjectMessageNotificationOfApproval(Long businessEntityId) {
        return genericBuildObjectMessageNotification(businessEntityId);
    }

    @Override
    protected Map<String, ?> buildObjectMessageNotificationOfRejection(Long businessEntityId) {
        return genericBuildObjectMessageNotification(businessEntityId);
    }

    private Map<String, ?> genericBuildObjectMessageNotification(Long businessEntityId) {
        OrderVO order = orderRepository.findByOrderId(businessEntityId);
        Map<String, Object> map = new HashMap<String, Object>();
        if(validateOrder(order)) {
            addDistributorConfigToFinalMap(map,order.getDistributorProfileByDistributorProfileId());
            addSpecialOrderMessageToFinalMap(map,order);
        }
        return map;
    }

    private void addSpecialOrderMessageToFinalMap(Map<String, Object> map, OrderVO order ) {

        DistributorProfileVO dp = order.getDistributorProfileByDistributorProfileId();

        WFSpecialOrderMessageVO msg = new WFSpecialOrderMessageVO();
        msg.setOrderId(order.getOrderId());
        msg.setDistributorCode(dp.getDistributorByDistributorCode().getDistributorCode());
        msg.setDistributorDesc(dp.getDistributorByDistributorCode().getName());
        msg.setSalesDistrictCode(dp.getSubRegionCode());
        msg.setDistributionChannel(dp.getDistributionChannelCode());

        SubRegionVO subRegionVO = subRegionRepository.findBySubRegionCode(msg.getSalesDistrictCode());

        if(subRegionVO!=null) {
            msg.setSalesDistrictDesc(subRegionVO.getDescription());
        }

        msg.setUrlSpecialOrder(CustomerLinkUtils.getPropertyFromFile(CustomerLinkCoreConstants.WF_APPROVAL_SPECIAL_ORDERS_FILE_NAME, CustomerLinkCoreConstants.WF_APPROVAL_SPECIAL_ORDERS_URL_PROPERTY));

        Map<String, Object> mapMessage = new HashMap<String, Object>();
        mapMessage.put(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE,msg);

        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE, mapMessage);
    }

    private void addDistributorConfigToFinalMap(Map<String, Object> map, DistributorProfileVO dp) {

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode(dp.getSalesOrganizationCode());
        distributorConfigDTO.setSalesDivCode(dp.getSalesDivisionCode());
        distributorConfigDTO.setDistChCode(dp.getDistributionChannelCode());
        distributorConfigDTO.setSubRegionCode(dp.getSubRegionCode());

        DistributorDTO distributor = new DistributorDTO();
        distributor.setDistributorCode(dp.getDistributorByDistributorCode().getDistributorCode());
        distributorConfigDTO.setDistributor(distributor);

        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MESSAGE,distributorConfigDTO);
    }

    @Override
    protected List<UserVO> obtainUsersByBusinessEntity(Long businessEntityId) {
        List<UserVO> users = new ArrayList<UserVO>();
        OrderVO order = orderRepository.findByOrderId(businessEntityId);
        if(validateOrder(order)) {
            order.setOrderDetailsByOrderId(orderDetailRepository.findByOrderId(order.getOrderId()));
            DistributorProfileVO distributorProfileVO = order.getDistributorProfileByDistributorProfileId();
            users = userManagementService.getListOfUserByDistributorProfileId(distributorProfileVO.getDistributorProfileId());
            filterRoles(users,order);
        }
        return users;
    }

    private boolean validateOrder(OrderVO order) {
        boolean success = false;
        if(order!=null && order.getDistributorProfileByDistributorProfileId()!=null && order.getDistributorProfileByDistributorProfileId().getDistributorByDistributorCode() !=null ) {
            success = true;
        }
        return success;
    }

    public void filterRoles(List<UserVO> users, final OrderVO order) {
        CollectionUtils.filter(users,new Predicate() {
            @Override
            public boolean evaluate(Object object) {
                boolean applyFilter = true;
                UserVO u = (UserVO) object;
                if(u.getRoleVO().getCode().equals(RoleEnum.RCD.getCode())) {
                    applyFilter = order.getRcdSAPCode().equals(u.getSapId());
                } else if (u.getRoleVO().getCode().equals(RoleEnum.MARKETING.getCode())) {
                    applyFilter = isValidMarketingRoleByProductAndBrand(order.getOrderDetailsByOrderId().iterator().next().getBrandCode(),u);
                }
                return applyFilter;
            }
        });
    }

    public boolean isValidMarketingRoleByProductAndBrand(String brandCode, UserVO u) {
        boolean isValidMarketing = false;
        if(StringUtils.isNotBlank(brandCode)) {
            isValidMarketing = brandCode.equals(u.getBrandVO().getBrandCode());
        }else if(brandCode == null && u.getBrandVO().getBrandCode().equals(BrandEnum.NO_BRAND.getId()) ) {
            isValidMarketing = true;
        }
        return isValidMarketing;
    }
}