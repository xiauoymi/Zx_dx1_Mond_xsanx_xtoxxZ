package com.monsanto.customerlink.core.service.util;

public enum BrandEnum {

    DEKALB("DK", "DEKALB"),
    DELTA_PINE("DP", "DELTA PINE"),
    ASGROW("AS", "ASGROW"),
    MONSANTO("MS", "MONSANTO"),
    CB("CB", "CB"),
    AGROCERES("AC", "AGROCERES"),
    ANY("ANY", "ANY BRAND"),
    NO_BRAND("_","NO BRAND");// this last brand is used to differentiate CB from the rest of the brands

    BrandEnum(String id, String desc) {
        this.id = id;
        this.desc = desc;
    }

    private String id;
    private String desc;

    public String getId() {
        return id;
    }


    public String getDesc() {
        return desc;
    }

}
