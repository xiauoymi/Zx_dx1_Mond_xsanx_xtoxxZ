package com.monsanto.customerlink.core.service.util;

public enum CLOrderTypeEnum {

    WITH_ALGORITHM("WA"),
    CB("CB"),
    WITHOUT_ALGORITHM("WOA"),
    WITHOUT_SOAK_TEST("WOST"),
    SPECIAL("SP"),
    REGULAR_AGROCHEMICAL("RA"),
    PRIVATE_AGROCHEMICAL("PA");

    private String code;

    private CLOrderTypeEnum(final String code) {
        this.code = code;
    }

    public String code() {
        return this.code;
    }
}
