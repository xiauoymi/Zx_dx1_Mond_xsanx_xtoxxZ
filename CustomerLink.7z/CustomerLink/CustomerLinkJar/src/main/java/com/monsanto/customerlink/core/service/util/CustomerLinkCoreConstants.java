package com.monsanto.customerlink.core.service.util;

public class CustomerLinkCoreConstants {

    public static final String ALTUOM = "SSU";
    public static final String HYBRIDS_WITH_ALGORITHM = "HYBRIDS_WITH_ALGORITHM";
    public static final String HYBRIDS_WITHOUT_ALGORITHM = "HYBRIDS_WITHOUT_ALGORITHM";
    public static final String AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM = "AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM";
    public static final long MATERIAL_UNITS_INCREASE = 10;
    public static final String ORDER_WITHOUT_SOAK_TEST = "X";
    public static final String ORDER_WITH_SOAK_TEST = "";
    public static final String HYBRIDS_WITH_ERROR = "HYBRIDS_WITH_ERROR";

    public static final String INCOTERMS1 = "DAP";
    public static final String INCOTERMS2 = "ENVIAR A CLIENTE";
    public static final String WITHOUT_SOAK_TEST = "S/ST";

    public static final String DISTRIBUTOR_CONFIG_KEY_MESSAGE = "distributorConfig";
    public static final String DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE = "mapMessage";
    public static final String NOTIFICATION_KEY_MESSAGE = "msg";

    public static final String CONSIGNMENT_DIST_CHANNEL = "91";
    public static final String AGROCHEMICAL_SALES_DIV = "15";

    public static final String SUB_REGION_ALL = "ALL";
    public static final String MONSANTO_EMAIL_DOMAIN = "@monsanto.com";

    public static final String PEOPLE_PICKER_SERVER = "xmlservice.peoplepicker.server";
    public static final String PEOPLE_PICKER_SERVER_VALUE = "w3.ent.monsanto.com";

    public static final String PEOPLE_PICKER_VDIR = "xmlservice.peoplepicker.vdir";
    public static final String PEOPLE_PICKER_VDIR_VALUE = "/ccca/pps";

    public static final String PEOPLE_PICKER_END_POINT = "xmlservice.peoplepicker.endpoint";
    public static final String PEOPLE_PICKER_END_POINT_VALUE = "PeoplePicker.rem";

    public static final String BLANK_VALUE = "";

    public static final String ENV_D_PARAM = "env";
    public static final String LSI_FUNCTION = "lsi.function";
    public static final String WF_APPROVAL_SPECIAL_ORDERS_URL_PROPERTY = ".wfapproval.specialorders.url";
    public static final String WF_APPROVAL_SPECIAL_ORDERS_FILE_NAME = "specialOrders-urls";
    public static final String WF_APPROVAL_SPECIAL_STATUS_DESCRTIPTION = "specialOrderStatus";
    public static final String ORDER_DETAIL_DELETE_MESSAGE = "Se eliminó el hibrido ";

}