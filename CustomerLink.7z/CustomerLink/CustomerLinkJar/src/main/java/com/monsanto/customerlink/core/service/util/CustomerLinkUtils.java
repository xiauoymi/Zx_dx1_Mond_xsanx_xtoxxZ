package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

public class CustomerLinkUtils {
    public static final SimpleDateFormat SDF_DDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
    public static final SimpleDateFormat SDF_YYYYMMDD_SAP = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Determinate if a parameter is valid
     *
     * @param parameter
     * @throws IllegalArgumentException if not is a valid parameter
     */
    public static void isValidParameter(final Object parameter) {
        if (null == parameter) {
            throw new IllegalArgumentException();
        } else if (parameter instanceof String
                && StringUtils.isEmpty(parameter.toString())) {
            throw new IllegalArgumentException();
        }
    }

    public static int getFiscalYear(Date date) {
        Calendar calendar = getCaledarFromCurrentDate(date);
        int year = calendar.get(Calendar.YEAR);
        if (calendar.get(Calendar.MONTH) >= Calendar.SEPTEMBER) {
            year++;
        }
        return year;
    }

    private static Calendar getCaledarFromCurrentDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }


    public static String getHybridName(ProductDTO productDTO) {
        return productDTO.getProductCode();
    }

    public static String getHybridName(String productCode, String treatmentCode) {
        return productCode + getTreatmentDesc(treatmentCode);
    }

    private static String getTreatmentDesc(String treatmentCode) {
        if ("0".equals(treatmentCode)) {
            return "";
        }
        return treatmentCode;
    }

    public static boolean isDateInRange(Date date, Date startDate, Date endDate) {
        boolean boReturn = Boolean.FALSE;
        if ((DateUtils.truncatedCompareTo(startDate, date, Calendar.DATE) < 0 ||
                DateUtils.truncatedCompareTo(startDate, date, Calendar.DATE) == 0) &&
                (DateUtils.truncatedCompareTo(date, endDate, Calendar.DATE) < 0 ||
                        DateUtils.truncatedCompareTo(date, endDate, Calendar.DATE) == 0)) {
            boReturn = Boolean.TRUE;
        } else {
            boReturn = Boolean.FALSE;
        }
        return boReturn;
    }

    public static <T> T safeNull(T testValue, T replacementValue) {
        return testValue != null ? testValue : replacementValue;
    }


    public static String getPriceCondition(String cropCode) {

        if (SeedsCropCodeEnum.CORN.getCode().equals(cropCode) ||
                SeedsCropCodeEnum.SORGHUM.getCode().equals(cropCode)) {
            return PriceConditionsEnum.ZL01.getCode();
        } else if(SeedsCropCodeEnum.COTTON.getCode().equals(cropCode) ||
                SeedsCropCodeEnum.SOYBEAN.getCode().equals(cropCode)) {
            return PriceConditionsEnum.ZR38.getCode();
        } else if(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode().equals(cropCode)) {
            return PriceConditionsEnum.ZR11.getCode();
        }

        return null;
    }

    public static String filterChannels(String distributionChannel) {
        if ( DistributionChannelEnum.DIRECT_SALES.getId().equals(distributionChannel)) {
            return DistributionChannelEnum.DEFAULT.getId();
        }
        return distributionChannel;
    }

    private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    public static String formatSapDate(Date date) {
        return format.format(date);
    }

    public static String complete10Zeros(String s) {
        int zeros = 10 - s.length();
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < zeros; i++) {
            buf.append("0");
        }
        buf.append(s);
        return buf.toString();
    }

    public static void checkDistributorProfileArgument(DistributorConfigDTO distributorProfile) {
        isValidParameter(distributorProfile);
        isValidParameter(distributorProfile.getSalesOrgCode());
        isValidParameter(distributorProfile.getDistChCode());
        isValidParameter(distributorProfile.getSalesDivCode());
        isValidParameter(distributorProfile.getSubRegionCode());
        checkDistributorArgument(distributorProfile.getDistributor());
    }

    public static void checkDistributorArgument(DistributorDTO distributorDTO) {
        isValidParameter(distributorDTO);
        isValidParameter(distributorDTO.getDistributorCode());
    }

    public static String getPropertyFromFile(String fileName, String propertyName) {
        String env = getEnvironment();
        ResourceBundle bundle = ResourceBundle.getBundle(fileName);
        return bundle.getString(env + propertyName);
    }

    private static String getEnvironment() {
        String env = System.getProperty(CustomerLinkCoreConstants.ENV_D_PARAM);
        if (env == null) {
            env = System.getProperty(CustomerLinkCoreConstants.LSI_FUNCTION);
        }
        env = env == null ? "win" : env;
        return env;
    }




}
