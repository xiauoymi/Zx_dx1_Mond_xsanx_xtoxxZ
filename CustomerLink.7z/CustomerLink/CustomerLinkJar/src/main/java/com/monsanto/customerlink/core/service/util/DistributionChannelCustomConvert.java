package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.core.service.impl.ApplicationContextProvider;
import com.monsanto.customerlink.persistence.entities.DistributionChannelMappingVO;
import com.monsanto.customerlink.persistence.repositories.DistributionChannelMappingRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.ConfigurableCustomConverter;
import org.dozer.MappingException;

import java.util.Collection;

public class DistributionChannelCustomConvert implements ConfigurableCustomConverter{

    private String param;
    private final String ENTITY_TO_DTO = "entity-to-dto";
    private DistributionChannelMappingRepository distributionChannelMappingRepository;

    @Override
    public void setParameter(String s) {
        param = s;
        initRepository();
    }

    @Override
    public Object convert(Object destination, Object source, Class<?> destClass, Class<?> sourceClass) {
        Object finalObject = null;
        if(param != null) {
            finalObject = convert(source);
        }
        return finalObject;
    }

    public Object convert(Object source) {
        String finalObject = null;
        if (source != null) {
            if (source instanceof String) {
                if(StringUtils.isNotBlank((String)source)) {
                    finalObject =  param.equalsIgnoreCase(ENTITY_TO_DTO) ? getFinalObjectEntityToDto(source) : getFinalObjectDtoToEntity(source);
                }
            } else {
                throw new MappingException("Converter DistributionChannelCustomConvert used incorrectly, " +
                        "wrong Arguments passed ");
            }
        }
        return finalObject;
    }

    public String getFinalObjectEntityToDto(Object source) {
        DistributionChannelMappingVO mapping = distributionChannelMappingRepository.findByClCode((String) source);
        if(mapping!=null) {
            return mapping.getSapCode();
        }
        return null;
    }

    public String getFinalObjectDtoToEntity(Object source) {
        Collection<DistributionChannelMappingVO> mappings =
                distributionChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc((String)source);
        if(CollectionUtils.isNotEmpty(mappings)) {
            return mappings.iterator().next().getClCode();
        }
        return null;
    }

    private void initRepository() {
        this.distributionChannelMappingRepository = obtainRepository();
        if(distributionChannelMappingRepository == null) {
            throw new MappingException("Converter DistributionChannelCustomConvert "
                    + " the bean of Type :"+DistributionChannelMappingRepository.class.getName() + " not found ");
        }
    }

    public DistributionChannelMappingRepository obtainRepository() {
        return (DistributionChannelMappingRepository)
                ApplicationContextProvider.getBeanByClass(DistributionChannelMappingRepository.class);
    }
}