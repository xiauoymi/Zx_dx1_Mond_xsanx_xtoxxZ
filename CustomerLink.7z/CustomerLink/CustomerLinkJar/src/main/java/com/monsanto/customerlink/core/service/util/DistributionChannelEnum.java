package com.monsanto.customerlink.core.service.util;

public enum DistributionChannelEnum {

    DIRECT_SALES("80", "DIRECT SALES"),
    EDUCAMPO("3E", "EDUCAMPO"),
    RIESGO_COMPARTIDO("3R", "RIESGO COMPARTIDO"),
    WHOLESAL("91", "DISTRIBUTOR/WHOLESAL"),
    DEFAULT("00", "DEFAULT");


    DistributionChannelEnum(String id, String desc) {
        this.id = id;
        this.desc = desc;
    }


    private String id;
    private String desc;

    public String getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }
}
