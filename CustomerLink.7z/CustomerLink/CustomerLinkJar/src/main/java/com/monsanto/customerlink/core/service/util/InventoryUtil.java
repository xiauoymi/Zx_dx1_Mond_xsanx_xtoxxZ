package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.core.email.NotificationType;

public class InventoryUtil {

    public static NotificationType getMinimumMX20NotificationType() {
        return NotificationType.MINIMUM_INVENTORY_MX20;
    }

    public static NotificationType getMinimumMX01NotificationType() {
        return NotificationType.MINIMUM_INVENTORY_MX01;
    }

    public static NotificationType getMissingMX20NotificationType() {
        return NotificationType.MISSING_INVENTORY_MX20;
    }

    public static NotificationType getMissingMX01NotificationType() {
        return NotificationType.MISSING_INVENTORY_MX01;
    }

    public static NotificationType getMissingRegularAgrochemicalsMX01NotificationType() {
        return NotificationType.MINIMUM_INVENTORY_REGULAR_AGROCHEMICALS_MX01;
    }




}