package com.monsanto.customerlink.core.service.util;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class Mapper extends DozerBeanMapper {

	public <T> List<T> mapList(Class<? extends T> clazz, Collection<?> c)  throws org.dozer.MappingException {

		if (c == null) {
			return null;
		}

		List<T> r = new ArrayList<T>(c.size());
		for (Object o : c) {
            r.add(this.map(o, clazz));
        }

		return r;
	}

}
