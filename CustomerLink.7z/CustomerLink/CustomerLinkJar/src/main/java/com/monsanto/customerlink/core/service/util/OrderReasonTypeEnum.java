package com.monsanto.customerlink.core.service.util;

public enum OrderReasonTypeEnum {
    ALGORITHM("H55"),
    CB("H5"),
    SST("H6"),
    VD("H7"),
    SBT("H83"),
    SPL("H82"),
    SPGS("H84");

    private String orderReason;

    private OrderReasonTypeEnum(final String orderReason) {
        this.orderReason = orderReason;
    }

    public String toString() {
        return orderReason;
    }

}
