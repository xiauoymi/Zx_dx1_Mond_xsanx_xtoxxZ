package com.monsanto.customerlink.core.service.util;

public enum OrderStatusEnum {
    PENDING_APPROVAL("PA"),
    PENDING_POST("PP"),
    POST("P"),
    WITH_ERROR("WE");

    private String orderStatus;

    private OrderStatusEnum(final String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String toString() {
        return orderStatus;
    }
}
