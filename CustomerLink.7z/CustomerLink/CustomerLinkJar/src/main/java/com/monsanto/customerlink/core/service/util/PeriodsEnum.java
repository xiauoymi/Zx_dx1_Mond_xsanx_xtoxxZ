package com.monsanto.customerlink.core.service.util;


public enum PeriodsEnum {

    PERIODS_BY_PRIVATE_BRAND(1l, "Periodos por marca privada"),
    PERIODS_BY_NOT_PRIVATE_BRAND(4l, "Periodos por marca no privada"),
    PERIOD_SEP_DIC(1l, "Sep-Dic"),
    PERIOD_ENE_ABR(2l, "Ene-Abr"),
    PERIOD_MAY_JUN(3l, "May-Jun"),
    PERIOD_JUL_AGO(4l, "Jul-Ago"),
    PERIOD_SEP_AGO(5l, "Sep-Ago");

    PeriodsEnum(Long id, String desc) {
        this.id = id;
        this.desc = desc;
    }


    private Long id;
    private String desc;

    public Long getId() {
        return id;
    }


    public String getDesc() {
        return desc;
    }

}
