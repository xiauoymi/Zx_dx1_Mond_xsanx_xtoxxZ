package com.monsanto.customerlink.core.service.util;

public enum PriceConditionsEnum {
    ZL01("ZL01", "Seed Mex Pricing (Maíz/Sorgo semilla)"),
    ZL57("ZL57", "Treatment (Maíz/Sorgo tratamiento)"),
    ZR38("ZR38", "TchMx Mex Pricing (Algodón/Soya semilla)"),
    ZR59("ZR59", "CROPMX Techfee (Algodón/Soya tecnología)"),
    ZR11("ZR11", "Agrochemical");


    PriceConditionsEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    private String code;
    private String description;


    public String getCode() {
        return code;
    }


    public String getDescription() {
        return description;
    }
}
