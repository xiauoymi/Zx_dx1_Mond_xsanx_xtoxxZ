package com.monsanto.customerlink.core.service.util;

/**
 * Created by IntelliJ IDEA.
 * User: RBUCI
 * Date: 13/09/13
 * Time: 11:50 AM
 * To change this template use File | Settings | File Templates.
 */
public enum PriceGroupEnum {

    AGROCHEMICAL("00", "Agrochemical");

    PriceGroupEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    ;

    private String code;
    private String description;

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
