package com.monsanto.customerlink.core.service.util;


public enum PurchaseOrderStatusEnum {

    APPROVAL_PENDING("PA", 0l),
    APPROVAL_APPROVED("AP", 1L),
    APPROVAL_REJECTED("RE", 2L),
    STATUS_DELETED("DE", 0L),
    STATUS_ACTIVE("AC", 1L);

    private Long status;
    private String description;

    private PurchaseOrderStatusEnum(final String description, final Long status) {
        this.status = status;
        this.description = description;
    }

    public Long getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

}
