package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.apache.commons.lang3.StringUtils;

public class RepresentativeUtils {
    public static boolean isAvailableRCD(RepresentativeDTO representativeDTO) {
        boolean available = false;
        if(representativeDTO != null && !StringUtils.isBlank(representativeDTO.getSapUserId())) {
            available = true;
        }
        return available;
    }
}
