package com.monsanto.customerlink.core.service.util;

public enum RoleEnum {

    CSR("CSR","[user name, role]"),
    DISTRIBUTOR("DISTRB",""),
    RCD("RCD","[user name, role, brand, sales organization, sales division, distribution channel]"),
    RBM("RBM","[user name, role, brand, sales organization, sales division, distribution channel]"),
    MARKETING("MRKT","[user name, role, brand]"),
    PLANNING("PLNG","[user name, role]"),
    PRICING("PRC","[user name, role]"),
    UNDEFINED_ROLE("UNDEFINED_ROLE","[role]"),
    ADMINISTRATOR("ADMIN",""),
    APPROVER("APPROVER","[user name, role]");

    private String code;
    private String requiredParameters;

    private RoleEnum(final String code, final String requiredParameters) {
        this.code = code;
        this.requiredParameters = requiredParameters;
    }

    public String getCode() {
        return code;
    }

    public String getRequiredParameters(){
        return this.requiredParameters;
    }

}
