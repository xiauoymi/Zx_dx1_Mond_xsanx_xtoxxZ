package com.monsanto.customerlink.core.service.util;

public enum SalesDivisionEnum {

    SEEDS("17"),
    AGROCHEMICALS("15");

    private String code;

    private SalesDivisionEnum(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
