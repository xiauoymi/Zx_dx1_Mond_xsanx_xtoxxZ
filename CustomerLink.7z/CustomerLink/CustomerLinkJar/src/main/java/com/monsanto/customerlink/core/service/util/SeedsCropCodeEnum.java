package com.monsanto.customerlink.core.service.util;

public enum SeedsCropCodeEnum {

    CORN("GC010"),
    SORGHUM("GS010"),
    COTTON("GT010"),
    SOYBEAN("GB010"),
    REGULAR_AGROCHEMICALS("AR010", "REGULAR_AGROCHEMICALS");

    private String code;
    private String description;


    private SeedsCropCodeEnum(final String code) {
        this.code = code;
    }

    private SeedsCropCodeEnum(final String code, final String description) {
        this.code = code;
        this.description=description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
