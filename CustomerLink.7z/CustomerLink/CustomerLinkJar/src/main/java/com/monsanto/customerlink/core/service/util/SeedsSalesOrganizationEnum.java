package com.monsanto.customerlink.core.service.util;

public enum SeedsSalesOrganizationEnum {

    CORN_OR_SORGHUM("MX20"),
    COTTON_OR_SOYBEAN("MX01");

    private String code;

    private SeedsSalesOrganizationEnum(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
