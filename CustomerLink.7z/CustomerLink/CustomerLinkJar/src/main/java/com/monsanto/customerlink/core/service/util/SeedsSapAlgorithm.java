package com.monsanto.customerlink.core.service.util;

public enum SeedsSapAlgorithm {

    WITH("X"),
    WITHOUT("");

    private String code;

    private SeedsSapAlgorithm(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
