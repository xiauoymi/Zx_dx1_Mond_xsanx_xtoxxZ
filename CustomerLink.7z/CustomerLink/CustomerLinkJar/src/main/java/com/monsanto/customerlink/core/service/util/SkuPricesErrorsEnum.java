package com.monsanto.customerlink.core.service.util;

public enum SkuPricesErrorsEnum {

    SKU_ERROR_1(1, "SKU", "Class & not found"),
    SKU_ERROR_2(2, "SKU", "Characteristics not found"),
    SKU_ERROR_3(3, "SKU", "Hybrid & not found"),
    SKU_ERROR_4(4, "SKU", "Material & not maintained in language &"),
    SKU_ERROR_5(5, "SKU", "Material & Conversion units PAL and/or SSU not maintained"),
    SKU_ERROR_6(6, "SKU", "Material & not maintained in sales organization & channel distribution &"),
    PRICE_ERROR_7(7, "PRICE", "Material & in sales organization & channel distribution & and price group & has not valid prices");

    SkuPricesErrorsEnum(Integer id, String type, String desc) {
        this.id = id;
        this.desc = desc;
        this.type = type;
    }

    private Integer id;
    private String desc;
    private String type;

    public Integer getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }

    public String getType() {
        return type;
    }


    @Override
    public String toString() {
        return id.toString();
    }
}
