package com.monsanto.customerlink.core.service.util;

public enum StatusEnum {


    DELETED(0l, "Borrado"), ACTIVE(1l, "Activo"), NOT_APPROVED(0l, "not approved"), APPROVED(1l, "Approved"),
    POSTED(2l, "Posted");

    StatusEnum(Long id, String desc) {
        this.id = id;
        this.desc = desc;
    }

    private Long id;
    private String desc;

    public Long getId() {
        return id;
    }


    public String getDesc() {
        return desc;
    }

}
