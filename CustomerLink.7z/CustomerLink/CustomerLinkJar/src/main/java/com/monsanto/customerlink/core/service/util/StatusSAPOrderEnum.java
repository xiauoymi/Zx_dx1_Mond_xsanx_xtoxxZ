package com.monsanto.customerlink.core.service.util;

public enum StatusSAPOrderEnum {

    OPEN("A"),
    PARTIAL("B"),
    COMPLETE("C");

    private String code;

    private StatusSAPOrderEnum(final String code) {
        this.code = code;
    }

    public String code() {
        return code;
    }
}
