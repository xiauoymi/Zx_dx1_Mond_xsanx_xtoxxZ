package com.monsanto.customerlink.core.service.util;

public enum TransactionTypeMaterial {

    INSERT("I"),
    UPDATE("U"),
    DELETE("D");

    private String code;

    private TransactionTypeMaterial(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
