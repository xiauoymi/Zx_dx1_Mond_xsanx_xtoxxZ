package com.monsanto.customerlink.core.service.util;

public enum TransactionTypeOrder {

    INSERT("I"),
    UPDATE("U");

    private String code;

    private TransactionTypeOrder(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
