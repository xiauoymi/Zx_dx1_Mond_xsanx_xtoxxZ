package com.monsanto.customerlink.core.service.util;


public enum TreatmentEnum {

    ST_BAYTAN("BA", "ST_BAYTAN"),
    STANDARD("0", "STANDARD"),
    ST_APRON("A", "ST_APRON"),
    ST_PONCHO("PO", "ST_PONCHO"),
    ST_PONCHO_BAYTAN("PB", "ST_PONCHO/BAYTAN"),
    ST_PONCHO_APRON("AP", "ST_PONCHO/APRON"),

    ST_PONCHO_PM("PM", "ST_PONCHO"),
    ST_PONCHO_CP("CP", "ST_PONCHO"),
    ST_PONCHO_P5("P5", "ST_PONCHO");



    TreatmentEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    private String code;
    private String description;


    public String getCode() {
        return code;
    }


    public String getDescription() {
        return description;
    }
}
