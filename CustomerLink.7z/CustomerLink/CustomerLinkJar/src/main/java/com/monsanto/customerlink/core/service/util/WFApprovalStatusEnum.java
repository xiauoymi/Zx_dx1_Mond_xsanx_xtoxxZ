package com.monsanto.customerlink.core.service.util;

public enum WFApprovalStatusEnum {

    PENDING_APPROVAL(1),
    PENDING_PREVIOUS_APPROVAL(2),
    APPROVED(3),
    REJECTED(4),
    IN_PROGRESS(5);

    private int id;

    private WFApprovalStatusEnum(final int id) {
        this.id = id;
    }

    public int id() {
        return this.id;
    }

}
