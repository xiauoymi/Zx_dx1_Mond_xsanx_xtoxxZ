package com.monsanto.customerlink.core.service.util;

public enum WFApprovalTypeEnum {

    SPECIAL_ORDER(1),
    PURCHASE_ORDER(2),
    AGREEMENT(3);

    private int id;

    private WFApprovalTypeEnum(final int id) {
        this.id = id;
    }

    public int id() {
        return this.id;
    }

}
