package com.monsanto.customerlink.core.webservices;

import javax.xml.namespace.QName;
import javax.xml.soap.*;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.util.Set;

public class ClientHeaderHandler implements SOAPHandler<SOAPMessageContext> {
    private static final String AUTH_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";//"http://schemas.xmlsoap.org/ws/2002/12/secext";
    private static final String AUTH_PREFIX = "nl";

    @Override
    public boolean handleMessage(SOAPMessageContext smc) {

        boolean direction = ((Boolean) smc.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue();

        String userName = (String) smc.get(BindingProvider.USERNAME_PROPERTY);
        String password = (String) smc.get(BindingProvider.PASSWORD_PROPERTY);

        if (direction) {
            try {
                SOAPEnvelope envelope = smc.getMessage().getSOAPPart().getEnvelope();

                SOAPFactory soapFactory= getSOAPFactory();

                // WSSecurity <Security> header
                SOAPElement wsSecHeaderElm = soapFactory.createElement(
                        "Security", AUTH_PREFIX, AUTH_NS);
                SOAPElement userNameTokenElm = soapFactory.createElement("UsernameToken",
                        AUTH_PREFIX, AUTH_NS);
                SOAPElement userNameElm = soapFactory.createElement("Username",
                        AUTH_PREFIX, AUTH_NS);
                userNameElm.addTextNode(userName);

                SOAPElement passwdElm = soapFactory.createElement("Password",
                        AUTH_PREFIX, AUTH_NS);
                passwdElm.addTextNode(password);

                userNameTokenElm.addChildElement(userNameElm);
                userNameTokenElm.addChildElement(passwdElm);

                // add child elements to the root element
                wsSecHeaderElm.addChildElement(userNameTokenElm);

                // create SOAPHeader instance for SOAP envelope
                SOAPHeader sh = envelope.addHeader();

                // add SOAP element for header to SOAP header object
                sh.addChildElement(wsSecHeaderElm);

            } catch (SOAPException ex) {
               return false;
            }
        }
        return true;
    }

    public SOAPFactory getSOAPFactory() throws SOAPException {
        return SOAPFactory.newInstance();
    }

    @Override
    public boolean handleFault(SOAPMessageContext context) {
        return true;
    }

    @Override
    public void close(MessageContext context) {
    }

    @Override
    public Set<QName> getHeaders() {
        return null;
    }
}