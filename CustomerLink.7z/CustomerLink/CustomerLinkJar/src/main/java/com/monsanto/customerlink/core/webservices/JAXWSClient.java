package com.monsanto.customerlink.core.webservices;


import javax.xml.ws.Service;

public abstract class JAXWSClient {

    //private Service ws;
    private final JAXWSRequestBuilder jaxwsRequestBuilder;
    private final JAXWSResponseProcessor jaxwsResponseProcessor;

    //private final Logger log = LoggerFactory.getLogger(this.getClass());

    public JAXWSClient(JAXWSRequestBuilder jaxwsRequestBuilder, JAXWSResponseProcessor jaxwsResponseProcessor) {
        this.jaxwsRequestBuilder = jaxwsRequestBuilder;
        this.jaxwsResponseProcessor = jaxwsResponseProcessor;
    }

    public Object execute() throws Exception {
        //try {
        return jaxwsResponseProcessor.process(callWebService(jaxwsRequestBuilder.build()));
       // } catch (Exception e) {
        //log.error(e.getMessage());
        //e.printStackTrace();
          //  throw e;
        //return null;
        //}
    }

    protected abstract Object callWebService(Object request) throws Exception;
}
