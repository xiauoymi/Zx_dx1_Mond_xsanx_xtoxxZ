package com.monsanto.customerlink.core.webservices;


import com.monsanto.customerlink.web.services.autogen.agreement.AgreementServicePortType;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderServicePortType;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpPortType;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.YESSDSACRECHANSALESORD;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YESSDSASENDINVENTORY;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YESSDSASENDSODETAIL;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import com.monsanto.customerlink.web.services.autogen.delivery.DeliveryServicePortType;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorServicePortType;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderServicePortType;
import com.monsanto.customerlink.web.services.autogen.product.ProductServicePortType;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderServicePortType;

public interface JAXWSClientFactory {

    public InventoryAtpPortType getInventoryAtpPortType();

    public YESSDSASENDINVENTORY getSendInventoryPortType();

    public YESSDSACRECHANSALESORD getCreChanSalesOrdPortType();

    public YESSDSAVALIDATESKU getValidationSkuPricePortType();

    public YESSDSASENDSODETAIL getSendSalesOrdDetailPortType();

    public YESSDSAYSDSALAN01RFC getCreChanSalesOrdWithAlgorithmPortType();

    public OrderServicePortType getOrderServicePortType();

    public AgreementServicePortType getAgreementServicePortType();

    public BackorderServicePortType getBackorderServicePortType();

    public DeliveryServicePortType getDeliveryServicePortType();

    public DistributorServicePortType getDistributorServicePortType();

    public ProductServicePortType getProductServicePortType();

    public PurchaseOrderServicePortType getPurchaseOrderServicePortType();

    public YESSDSASENDCONDITIONS getSendPricesServicePortType();

}
