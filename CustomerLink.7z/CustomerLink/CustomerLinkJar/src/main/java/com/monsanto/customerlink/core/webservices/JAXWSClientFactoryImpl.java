package com.monsanto.customerlink.core.webservices;

import com.monsanto.customerlink.core.webservices.util.URLLocator;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementServicePortType;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderServicePortType;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpPortType;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.YESSDSACRECHANSALESORD;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YESSDSASENDINVENTORY;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YESSDSASENDSODETAIL;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import com.monsanto.customerlink.web.services.autogen.delivery.DeliveryServicePortType;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorServicePortType;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderServicePortType;
import com.monsanto.customerlink.web.services.autogen.product.ProductServicePortType;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderServicePortType;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import java.net.URL;
import java.util.List;

public class JAXWSClientFactoryImpl implements JAXWSClientFactory {

    private static final String MESSAGEURL_BUNDLE = "customerlink-webservices-urls";
    private static JAXWSClientFactory instance;

    /* PortTypes */
    private static InventoryAtpPortType inventoryAtpPortType;
    private static YESSDSASENDINVENTORY sendInventoryPortType;
    private static YESSDSACRECHANSALESORD creChanSalesOrdPortType;
    private static YESSDSASENDSODETAIL sendSalesOrdDetailPortType;
    private static YESSDSAYSDSALAN01RFC creChanSalesOrdWithAlgorithmPortType;
    private static YESSDSASENDCONDITIONS sendPricesPortType;
    private static YESSDSAVALIDATESKU validationSkuPrice;

    // CL PortTypes
    private static OrderServicePortType orderServicePortType;
    private static AgreementServicePortType agreementServicePortType;
    private static BackorderServicePortType backorderServicePortType;
    private static DeliveryServicePortType deliveryServicePortType;
    private static DistributorServicePortType distributorServicePortType;
    private static ProductServicePortType productServicePortType;
    private static PurchaseOrderServicePortType purchaseOrderServicePortType;

    private JAXWSClientFactoryImpl() {
    }

    public static JAXWSClientFactory getInstance() {

        if (instance == null) {
            instance = new JAXWSClientFactoryImpl();
        }
        return instance;
    }

    public InventoryAtpPortType getInventoryAtpPortType() {

        if (inventoryAtpPortType == null) {
            inventoryAtpPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("atp"),
                    new QName("http://www.monsanto.com/scpif/wsdl/InventoryAtp", "InventoryAtpServiceImplService")).getPort(InventoryAtpPortType.class);
            if (inventoryAtpPortType instanceof BindingProvider) {
               setCredentials((BindingProvider) inventoryAtpPortType);
            }
        }

        return inventoryAtpPortType;
    }

    public Service getServiceClient(URL wsdlLocation, QName serviceName) {
        return new ServiceClient(wsdlLocation, serviceName);
    }

    public YESSDSASENDINVENTORY getSendInventoryPortType() {

        if (sendInventoryPortType == null) {
            sendInventoryPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("sendinventory"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_SEND_INVENTORY")).getPort(YESSDSASENDINVENTORY.class);
            if (sendInventoryPortType instanceof BindingProvider) {
                setCredentials((BindingProvider) sendInventoryPortType);
            }
        }

        return sendInventoryPortType;
    }

    public YESSDSACRECHANSALESORD getCreChanSalesOrdPortType() {

        if (creChanSalesOrdPortType == null) {
            creChanSalesOrdPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("crechansalesord"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_CRE_CHAN_SALES_ORD")).getPort(YESSDSACRECHANSALESORD.class);
            if (creChanSalesOrdPortType instanceof BindingProvider) {
                setCredentials((BindingProvider) creChanSalesOrdPortType);
            }
        }

        return creChanSalesOrdPortType;
    }


    public YESSDSAVALIDATESKU getValidationSkuPricePortType() {
        if (validationSkuPrice == null) {
            validationSkuPrice = getServiceClient(
                    new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("skuprice"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_VALIDATE_SKU")).getPort(YESSDSAVALIDATESKU.class);
            if (validationSkuPrice instanceof BindingProvider) {
                setCredentials((BindingProvider) validationSkuPrice);
            }
        }

        return validationSkuPrice;
    }

    public YESSDSASENDSODETAIL getSendSalesOrdDetailPortType() {

        if (sendSalesOrdDetailPortType == null) {
            sendSalesOrdDetailPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("sendsalesorddetail"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_SEND_SO_DETAIL")).getPort(YESSDSASENDSODETAIL.class);
            if (sendSalesOrdDetailPortType instanceof BindingProvider) {
                setCredentials((BindingProvider) sendSalesOrdDetailPortType);
            }
        }

        return sendSalesOrdDetailPortType;
    }

    @Override
    public OrderServicePortType getOrderServicePortType() {
        if (orderServicePortType == null) {
            orderServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("cl-orderservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/DummyOrder", "OrderPortTypeImplService")).getPort(OrderServicePortType.class);

            if (orderServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) orderServicePortType);
            }
        }

        return orderServicePortType;
    }


    @Override
    public AgreementServicePortType getAgreementServicePortType() {

        if (agreementServicePortType == null) {
            agreementServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-agreementservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/Agreement", "WSAgreementService")).getPort(AgreementServicePortType.class);
            if (agreementServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) agreementServicePortType);
            }
        }
        return agreementServicePortType;
    }

    @Override
    public BackorderServicePortType getBackorderServicePortType() {
        if (backorderServicePortType == null) {
            backorderServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-backorderservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/Backorder", "OrderService")).
                    getPort(BackorderServicePortType.class);
            if (backorderServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) backorderServicePortType);
            }
        }
        return backorderServicePortType;
    }

    @Override
    public DeliveryServicePortType getDeliveryServicePortType() {
        if (deliveryServicePortType == null) {
            deliveryServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-deliveryservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/Delivery", "WSDeliveryService")).getPort(DeliveryServicePortType.class);
            if (backorderServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) backorderServicePortType);
            }
        }

        return deliveryServicePortType;
    }

    @Override
    public DistributorServicePortType getDistributorServicePortType() {
        if (distributorServicePortType == null) {
            distributorServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-distributorservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/Distributor", "WSDistributorService")).getPort(DistributorServicePortType.class);
            if (backorderServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) backorderServicePortType);
            }
        }

        return distributorServicePortType;
    }

    @Override
    public ProductServicePortType getProductServicePortType() {
        if (productServicePortType == null) {
            productServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-productservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/Product", "WSProductService")).getPort(ProductServicePortType.class);
            if (productServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) productServicePortType);
            }
        }
        return productServicePortType;
    }

    @Override
    public PurchaseOrderServicePortType getPurchaseOrderServicePortType() {
        if (purchaseOrderServicePortType == null) {
            purchaseOrderServicePortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).
                    getWSDLURL("cl-purchaseorderservice"),
                    new QName("http://www.monsanto.com/customerlink/web/services/autogen/PurchaseOrder", "WSPurchaseOrderService")).getPort(PurchaseOrderServicePortType.class);
            if (purchaseOrderServicePortType instanceof BindingProvider) {
                setCredentials((BindingProvider) purchaseOrderServicePortType);
            }
        }
        return purchaseOrderServicePortType;
    }

    public YESSDSAYSDSALAN01RFC getCreChanSalesOrdWithAlgorithmPortType() {
        if (creChanSalesOrdWithAlgorithmPortType == null) {
            creChanSalesOrdWithAlgorithmPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("crechansalesord.with.algorithm"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_YSDSALAN01_RFC")).getPort(YESSDSAYSDSALAN01RFC.class);
            if (creChanSalesOrdWithAlgorithmPortType instanceof BindingProvider) {
                setCredentials((BindingProvider) creChanSalesOrdWithAlgorithmPortType);
            }
        }

        return creChanSalesOrdWithAlgorithmPortType;
    }

    @Override
    public YESSDSASENDCONDITIONS getSendPricesServicePortType() {

        if (sendPricesPortType == null) {
            sendPricesPortType = getServiceClient(new URLLocator(MESSAGEURL_BUNDLE).getWSDLURL("sendPrices"),
                    new QName("urn:sap-com:document:sap:soap:functions:mc-style", "YES_SDSA_SEND_CONDITIONS")).
                    getPort(YESSDSASENDCONDITIONS.class);
            if (sendPricesPortType instanceof BindingProvider) {
                setCredentials((BindingProvider) sendPricesPortType);
            }
        }

        return sendPricesPortType;
    }


    public void setCredentials(BindingProvider port) {

        URLLocator locator = new URLLocator(MESSAGEURL_BUNDLE);
        port.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, locator.getUserClCredentials());
        port.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, locator.getUserClPassword());

        ////////////////
        List<Handler> handlerChain = new java.util.ArrayList<Handler>();
        ClientHeaderHandler wsSecurity = new ClientHeaderHandler();
        handlerChain.add(wsSecurity);
        port.getBinding().setHandlerChain(handlerChain);
    }

}