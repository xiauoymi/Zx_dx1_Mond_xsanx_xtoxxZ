package com.monsanto.customerlink.core.webservices;


public abstract class JAXWSRequestBuilder<T> {
    public abstract T build() throws Exception;

    public String getDescription(){
        return "";
    }
    public String getSuccessMessage(){
        return "Successful";
    }
}

