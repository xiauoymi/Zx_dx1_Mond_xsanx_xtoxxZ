package com.monsanto.customerlink.core.webservices;

public abstract class JAXWSResponseProcessor<T> {
    public abstract Object process(T response) throws Exception;

    public String getDescription(){
        return "";
    }
    public String getSuccessMessage(){
        return "Successful";
    }
}