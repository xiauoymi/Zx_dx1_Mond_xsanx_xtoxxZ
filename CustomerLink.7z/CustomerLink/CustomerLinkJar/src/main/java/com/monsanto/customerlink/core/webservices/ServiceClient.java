package com.monsanto.customerlink.core.webservices;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

public class ServiceClient extends Service {


    public ServiceClient(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }
}
