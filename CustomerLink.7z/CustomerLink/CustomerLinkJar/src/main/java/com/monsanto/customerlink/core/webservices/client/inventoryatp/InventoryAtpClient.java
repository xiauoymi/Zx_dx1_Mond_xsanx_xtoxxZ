package com.monsanto.customerlink.core.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpPortType;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class InventoryAtpClient extends JAXWSClient {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    public InventoryAtpPortType inventoryAtpPortType;

    public InventoryAtpClient(JAXWSRequestBuilder<List<Object[]>> jaxwsRequestBuilder,
                              JAXWSResponseProcessor<Map<String, Result>> jaxwsResponseProcessor,
                              InventoryAtpPortType inventoryAtpPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.inventoryAtpPortType = inventoryAtpPortType;
    }

    @Override
    protected Object callWebService(Object request) throws Exception {

        List<Object[]> parameters = (List<Object[]>) request;
        Map<String, Result> resultMap = new HashMap<String, Result>();
        for (Object[] objects : parameters) {

            String subregion = (String) objects[0];

                try {
                    Result result =
                            inventoryAtpPortType.obtainAtp(subregion, (Integer) objects[1], (Boolean) objects[2],
                                   (String) objects[3], (String) objects[4]);

                    resultMap.put(subregion, result);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

        }

        return resultMap;
    }

}
