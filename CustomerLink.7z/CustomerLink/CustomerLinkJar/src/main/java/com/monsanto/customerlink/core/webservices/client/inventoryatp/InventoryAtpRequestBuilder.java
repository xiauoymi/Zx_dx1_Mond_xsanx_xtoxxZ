package com.monsanto.customerlink.core.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


public class InventoryAtpRequestBuilder extends JAXWSRequestBuilder<List<Object[]>> {

    private Map<SubRegionDTO, SeasonVO> mapSubRegionseason;
    private Integer fiscalYear;
    private Boolean queryListAtp;

    public InventoryAtpRequestBuilder(Map<SubRegionDTO, SeasonVO> mapSubRegionseason, Integer fiscalYear, boolean queryListAtp) {
        this.mapSubRegionseason= mapSubRegionseason;
        this.fiscalYear = fiscalYear;
        this.queryListAtp = queryListAtp;
        this.mapSubRegionseason=mapSubRegionseason;
    }

    @Override
    public List<Object[]> build() throws Exception {
        List<Object[]> parameters= new ArrayList<Object[]>();

        for(SubRegionDTO subRegionDTO: mapSubRegionseason.keySet()){
            SeasonVO seasonVO= mapSubRegionseason.get(subRegionDTO);

            Object[]array=new Object[]{subRegionDTO.getSubRegionCode(),fiscalYear, queryListAtp, CustomerLinkUtils.formatSapDate(seasonVO.getSeasonStartDate()),
                    CustomerLinkUtils.formatSapDate(seasonVO.getSeasonEndDate())};
            parameters.add(array);
        }
        return parameters;
    }


}
