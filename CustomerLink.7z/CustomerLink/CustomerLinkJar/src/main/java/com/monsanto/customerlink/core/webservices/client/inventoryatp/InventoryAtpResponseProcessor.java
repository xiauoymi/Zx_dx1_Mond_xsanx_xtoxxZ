package com.monsanto.customerlink.core.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.service.util.BrandEnum;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.util.ClientUtils;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

public class InventoryAtpResponseProcessor extends JAXWSResponseProcessor<Map<String, Result>> {

    @Override
    public List<OrderDTO> process(Map<String, Result> resultMap) throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        Map<MultiKey, OrderDTO> multiKeyOrderDTOMap = new HashMap<MultiKey, OrderDTO>();

        for (String subregion : resultMap.keySet()) {

            Result response = resultMap.get(subregion);

            if (response.getSalesDivision() != null) {

                for (Result.SalesDivision.Distributor distributor : response.getSalesDivision().getDistributor()) {

                    for (Result.SalesDivision.Distributor.SalesOrg salesOrg : distributor.getSalesOrg()) {

                        for (Result.SalesDivision.Distributor.SalesOrg.DistributionChannel distributionChannel : salesOrg.getDistributionChannel()) {

                            //filterChannels(distributionChannel);

                            for (Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand brand : distributionChannel.getBrand()) {

                                if (areThereHybridsDifferentToSoybean(brand.getHybrid())) {
                                    String brandCodeToGroupOrders = obtainBrand(brand.getBrandBwId());

                                    for (Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid hybrid : brand.getHybrid()) {
                                        hybrid.setTreatmentBwId(ClientUtils.filterTreatment(hybrid.getTreatmentBwId()));
                                        OrderDTO orderDTO = findOrder(multiKeyOrderDTOMap, response.getSalesDivision(),
                                                distributor, salesOrg,
                                                distributionChannel, subregion, brandCodeToGroupOrders,
                                                obtainCLOrderType(brand.getBrandBwId(), hybrid.getCropCode()));

                                        if (!isSoybean(hybrid.getCropCode())) {
                                            addDetailOrder(orderDTO, hybrid, brand.getBrandBwId());
                                        }

                                        multiKeyOrderDTOMap.put(buildKeyForOrder(orderDTO, brandCodeToGroupOrders), orderDTO);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        orderDTOList.addAll(filterSoy(multiKeyOrderDTOMap.values()));

        return orderDTOList;
    }


    private String obtainCLOrderType(String brand, String cropCode) {

        if (isBrandCB(brand)) {
            return CLOrderTypeEnum.CB.code();// "CB";
        }
        if (isCornOrShorgum(cropCode)) {
            return CLOrderTypeEnum.WITH_ALGORITHM.code();//"WA";
        }
        if (isCottonOrSoy(cropCode)) {
            return CLOrderTypeEnum.WITHOUT_ALGORITHM.code();//"WOA";
        }

        return "";
    }

    private String obtainBrand(String brand) {
        if (isBrandCB(brand)) {
            return brand;
        }
        return BrandEnum.ANY.getId();
    }

    private boolean isCornOrShorgum(String cropCode) {

        if (SeedsCropCodeEnum.CORN.getCode().equals(cropCode)) {
            return true;
        }
        if (SeedsCropCodeEnum.SORGHUM.getCode().equals(cropCode)) {
            return true;
        }

        return false;
    }

    private boolean isCottonOrSoy(String cropCode) {

        if (SeedsCropCodeEnum.COTTON.getCode().equals(cropCode)) {
            return true;
        }
        if (SeedsCropCodeEnum.SOYBEAN.getCode().equals(cropCode)) {
            return true;
        }

        return false;
    }

    private boolean isBrandCB(String brand) {
        if (BrandEnum.CB.getId().equals(brand)) {
            return true;
        }
        return false;
    }

    private Collection<OrderDTO> filterSoy(Collection<OrderDTO> orderDTOCollection) {
        Collection<OrderDTO> filterSoyCollection = new ArrayList<OrderDTO>();

        for (OrderDTO orderDTO : orderDTOCollection) {
            boolean isSoy = false;

            for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
                if (StringUtils.equals(orderDetailDTO.getProductDTO().getCropCode(), SeedsCropCodeEnum.SOYBEAN.getCode())) {
                    isSoy = true;
                    break;
                }
            }

            if (!isSoy) {
                filterSoyCollection.add(orderDTO);
            }
        }

        return filterSoyCollection;
    }

    private void addDetailOrder(OrderDTO orderDTO, Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid hybrid,
                                String brandBw) {



        String productCode=CustomerLinkUtils.getHybridName(hybrid.getHybridBwId(), hybrid.getTreatmentBwId());
        String cropCode=hybrid.getCropCode();

        OrderDetailDTO orderDetailDTO =findProduct(orderDTO.getDetail(), productCode, cropCode, brandBw);

        if(orderDetailDTO==null){
            orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO= new ProductDTO();
            productDTO.setProductCode(CustomerLinkUtils.getHybridName(hybrid.getHybridBwId(), hybrid.getTreatmentBwId()));
            productDTO.setCropCode(hybrid.getCropCode());
            productDTO.setSubDivisionCode(hybrid.getCropCode());
            productDTO.setBrandCode(brandBw);
            productDTO.setTreatmentCode(hybrid.getTreatmentBwId());
            productDTO.setFamilyCode(hybrid.getHybridBwId());
            orderDetailDTO.setProductDTO(productDTO);
            orderDetailDTO.setQuantity(hybrid.getAtp().doubleValue());
            orderDTO.getDetail().add(orderDetailDTO);
        }else{
            orderDetailDTO.setQuantity(orderDetailDTO.getQuantity()+ hybrid.getAtp().doubleValue());
        }
    }

    private OrderDetailDTO findProduct(List<OrderDetailDTO> detailForOrder, String productCode, String cropCode, String brand){
        for(OrderDetailDTO orderDetailDTO: detailForOrder){
            ProductDTO productDTO= orderDetailDTO.getProductDTO();
            if(productDTO.getProductCode().equals(productCode) && productDTO.getCropCode().equals(cropCode) &&
                    productDTO.getBrandCode().equals(brand)){
                return orderDetailDTO;
            }
        }
        return null;
    }

    private OrderDTO findOrder(Map<MultiKey, OrderDTO> map,
                               Result.SalesDivision salesDivision,
                               Result.SalesDivision.Distributor distributor,
                               Result.SalesDivision.Distributor.SalesOrg salesOrg,
                               Result.SalesDivision.Distributor.SalesOrg.DistributionChannel distributionChannel,
                               String subregionCode, String brandCode, String clOrderType) {

        MultiKey key = buildKeyForOrder(salesDivision, distributor, salesOrg, distributionChannel, subregionCode, brandCode);

        OrderDTO orderDTO = map.get(key);

        if (orderDTO == null) {
            orderDTO = new OrderDTO();
            orderDTO.setClOrderTypeCode(clOrderType);
            DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
            distributorConfigDTO.setDistChCode(distributionChannel.getDistributionChannelBwId());
            distributorConfigDTO.setSalesDivCode(salesDivision.getSalesDivisionBwId());
            distributorConfigDTO.setSalesOrgCode(salesOrg.getSalesOrgBwId());
            distributorConfigDTO.setSubRegionCode(subregionCode);

            DistributorDTO distributorDTO = new DistributorDTO();
            distributorDTO.setDistributorCode(distributor.getDistributorBwId());

            distributorConfigDTO.setDistributor(distributorDTO);
            orderDTO.setDistributorConfigDTO(distributorConfigDTO);

            RepresentativeDTO representativeDTO= new RepresentativeDTO();
            representativeDTO.setName(distributor.getRcdName());
            representativeDTO.setSapUserId(distributor.getRcdBwId());

            orderDTO.setRepresentativeDTO(representativeDTO);

            map.put(key, orderDTO);
        }
        return orderDTO;
    }

    private MultiKey buildKeyForOrder(OrderDTO dummyOrderDTO, String brandCode) {
        DistributorConfigDTO configDTO = dummyOrderDTO.getDistributorConfigDTO();
        return new MultiKey(new Object[]{
                configDTO.getDistChCode(),
                configDTO.getSalesDivCode(),
                configDTO.getSubRegionCode(),
                configDTO.getSalesOrgCode(),
                configDTO.getDistributor().getDistributorCode(),
                dummyOrderDTO.getRepresentativeDTO().getSapUserId(),
                brandCode
        });
    }

    private MultiKey buildKeyForOrder(Result.SalesDivision salesDivision,
                                      Result.SalesDivision.Distributor distributor,
                                      Result.SalesDivision.Distributor.SalesOrg salesOrg,
                                      Result.SalesDivision.Distributor.SalesOrg.DistributionChannel distributionChannel,
                                      String subRegionCode, String brandCode) {
        return new MultiKey(new Object[]{
                distributionChannel.getDistributionChannelBwId(),
                salesDivision.getSalesDivisionBwId(),
                subRegionCode,
                salesOrg.getSalesOrgBwId(),
                distributor.getDistributorBwId(),
                distributor.getRcdBwId(),
                brandCode
        });
    }

    private boolean areThereHybridsDifferentToSoybean(List<Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid> hybrids) {
        boolean boReturn = Boolean.TRUE;
        Collection<Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid> soybeanHybrids = CollectionUtils.select(hybrids, new Predicate() {
            @Override
            public boolean evaluate(Object o) {
                return isSoybean(((Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid) o).getCropCode());
            }
        });
        if (hybrids.size() == soybeanHybrids.size()) {
            boReturn = Boolean.FALSE;
        }
        return boReturn;
    }

    private boolean isSoybean(String cropCode) {
        boolean isSoybean = Boolean.FALSE;
        if (StringUtils.equals(SeedsCropCodeEnum.SOYBEAN.getCode(), cropCode)) {
            isSoybean = Boolean.TRUE;
        }
        return isSoybean;
    }
}
