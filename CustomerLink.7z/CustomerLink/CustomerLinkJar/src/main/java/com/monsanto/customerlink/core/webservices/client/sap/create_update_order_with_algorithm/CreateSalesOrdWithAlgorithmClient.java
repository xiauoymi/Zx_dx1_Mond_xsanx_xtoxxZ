package com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.util.TransactionTypeOrder;
import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YsdsaExpSlsHeader;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YttSdsaSlsErrors;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YttSdsaSlsItemOut;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.RequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;

import javax.xml.ws.Holder;
import java.util.ArrayList;
import java.util.List;

public class CreateSalesOrdWithAlgorithmClient extends JAXWSClient {

    private YESSDSAYSDSALAN01RFC createSalesOrdPortType;

    public CreateSalesOrdWithAlgorithmClient(JAXWSRequestBuilder<ListRequestCreateUpdateOrderWithAlgorithm> jaxwsRequestBuilder,
                                             JAXWSResponseProcessor<List<ResponseCreateUpdateOrderWithAlgorithm>> jaxwsResponseProcessor,
                                             YESSDSAYSDSALAN01RFC createSalesOrdPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.createSalesOrdPortType = createSalesOrdPortType;
    }

    @Override
    public Object callWebService(Object request) throws Exception {
        final ListRequestCreateUpdateOrderWithAlgorithm reqList = (ListRequestCreateUpdateOrderWithAlgorithm) request;

        List<ResponseCreateUpdateOrderWithAlgorithm> responsesList = new ArrayList<ResponseCreateUpdateOrderWithAlgorithm>();

        RequestCreateUpdateOrderWithAlgorithm reqCreate = findRequestCreate(reqList);
        String salesOrder = sendRequestCreate(reqCreate, responsesList);

        sendUpdateRequests(responsesList, reqCreate, salesOrder, reqList);

        return responsesList;
    }

    private void sendUpdateRequests(List<ResponseCreateUpdateOrderWithAlgorithm> responsesList,
                                    RequestCreateUpdateOrderWithAlgorithm reqCreate, String salesOrder,
                                    ListRequestCreateUpdateOrderWithAlgorithm reqList) {


        if (reqCreate != null && salesOrder != null) {
            for (RequestCreateUpdateOrderWithAlgorithm req : reqList.getRequestCreateUpdateOrderWithAlgorithms()) {

                if (req.getTranType().equals(TransactionTypeOrder.UPDATE.getCode())) {
                    req.setSalesOrder(salesOrder);

                    Holder<YttSdsaSlsErrors> errors = new Holder<YttSdsaSlsErrors>();
                    Holder<YsdsaExpSlsHeader> headerOut = new Holder<YsdsaExpSlsHeader>();
                    Holder<YttSdsaSlsItemOut> itemOut = new Holder<YttSdsaSlsItemOut>();

                    createSalesOrdPortType.ySdsaYsdsalan01Rfc(req.getInputSlsHeader(), req.getInputSlsItem(),
                            req.getSalesOrder(), req.getTranType(), errors, headerOut, itemOut);


                    ResponseCreateUpdateOrderWithAlgorithm response = new ResponseCreateUpdateOrderWithAlgorithm();
                    response.setYsdsaExpSlsHeader(headerOut.value);
                    response.setYttSdsaSlsErrors(errors.value);
                    response.setYttSdsaSlsItemOut(itemOut.value);
                    responsesList.add(response);
                }
            }
        }
    }

    private String sendRequestCreate(RequestCreateUpdateOrderWithAlgorithm reqCreate,
                                     List<ResponseCreateUpdateOrderWithAlgorithm> responsesList) {
        String salesOrder = null;

        if (reqCreate != null) {
            Holder<YttSdsaSlsErrors> errors = new Holder<YttSdsaSlsErrors>();
            Holder<YsdsaExpSlsHeader> headerOut = new Holder<YsdsaExpSlsHeader>();
            Holder<YttSdsaSlsItemOut> itemOut = new Holder<YttSdsaSlsItemOut>();

            createSalesOrdPortType.ySdsaYsdsalan01Rfc(reqCreate.getInputSlsHeader(), reqCreate.getInputSlsItem(),
                    reqCreate.getSalesOrder(), reqCreate.getTranType(), errors, headerOut, itemOut);

            salesOrder = getSalesOrder(headerOut);
            ResponseCreateUpdateOrderWithAlgorithm response = new ResponseCreateUpdateOrderWithAlgorithm();
            response.setYsdsaExpSlsHeader(headerOut.value);
            response.setYttSdsaSlsErrors(errors.value);
            response.setYttSdsaSlsItemOut(itemOut.value);
            responsesList.add(response);
        }
        return salesOrder;
    }

    private RequestCreateUpdateOrderWithAlgorithm findRequestCreate(ListRequestCreateUpdateOrderWithAlgorithm reqList) {

        for (RequestCreateUpdateOrderWithAlgorithm req : reqList.getRequestCreateUpdateOrderWithAlgorithms()) {
            if (TransactionTypeOrder.INSERT.getCode().equals(req.getTranType())) {
                return req;
            }
        }
        return null;
    }

    public String getSalesOrder(Holder<YsdsaExpSlsHeader> headerOut) {
        return headerOut.value != null ? headerOut.value.getYysalesOrder() : null;
    }

}
