package com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.*;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SalesOrdWithAlgorithmResponseProcessor extends JAXWSResponseProcessor<List<ResponseCreateUpdateOrderWithAlgorithm>> {


    @Override
    public Object process(final List<ResponseCreateUpdateOrderWithAlgorithm> responseList) throws Exception {

        SAPOrderDTO sapOrderDTO = null;
        for (ResponseCreateUpdateOrderWithAlgorithm response : responseList) {
            if (sapOrderDTO == null) {
                sapOrderDTO = buildSAPOrderDTO(response.getYsdsaExpSlsHeader());
            }  //TODO quitar hybrid
            sapOrderDTO.getHybrids().addAll(buildHybridDTOList(response.getYttSdsaSlsItemOut()));
            sapOrderDTO.getErrors().addAll(buildSAPOrderErrorDTOList(response.getYttSdsaSlsErrors()));
            //return sapOrderDTO;
        }
        return sapOrderDTO;
    }

    private SAPOrderDTO buildSAPOrderDTO(final YsdsaExpSlsHeader outputSlsHeader) {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        if (null != outputSlsHeader) {
            sapOrderDTO.setSalesorder(outputSlsHeader.getYysalesOrder());
            sapOrderDTO.setDocType(outputSlsHeader.getYydocType());
            sapOrderDTO.setSalesOrg(outputSlsHeader.getYysalesOrg());
            sapOrderDTO.setDistrChan(outputSlsHeader.getYydistrChan());
            sapOrderDTO.setDivision(outputSlsHeader.getYydivision());
            sapOrderDTO.setSoldTo(outputSlsHeader.getYysoldTo());
            sapOrderDTO.setPurchNoC(outputSlsHeader.getYypurchNoC());
            sapOrderDTO.setOrdReason(outputSlsHeader.getYyordReason());
            sapOrderDTO.setIncoterms1(outputSlsHeader.getYyincoterms1());
            sapOrderDTO.setIncoterms2(outputSlsHeader.getYyincoterms2());
            sapOrderDTO.setPriceGrp(outputSlsHeader.getYypriceGrp());
            sapOrderDTO.setCurrency(outputSlsHeader.getYycurrency());
            sapOrderDTO.setSalesRep(outputSlsHeader.getYysalesRep());
        }
        return sapOrderDTO;
    }

    private List<HybridDTO> buildHybridDTOList(final YttSdsaSlsItemOut outputSlsItemWrapper) {
        final List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        if (null != outputSlsItemWrapper) {
            final Map<String, List<YsdsaSlsItemOut>> ysdsaSlsitemoutByHybridList = groupByHybrid(outputSlsItemWrapper.getItem());
            for (final Map.Entry<String, List<YsdsaSlsItemOut>> ysdsaSlsitemoutByHybrid : ysdsaSlsitemoutByHybridList.entrySet()) {
                final HybridDTO hybridDTO = new HybridDTO();
                hybridDTO.setHybridCode(ysdsaSlsitemoutByHybrid.getKey());
                for (final YsdsaSlsItemOut ysdsaSlsitemout : ysdsaSlsitemoutByHybrid.getValue()) {
                    hybridDTO.getSkus().add(buildMaterialDTO(ysdsaSlsitemout));
                }
                hybrids.add(hybridDTO);
            }
        }
        return hybrids;
    }

    private List<SAPOrderErrorDTO> buildSAPOrderErrorDTOList(final YttSdsaSlsErrors outputErrorWrapper) {
        final List<SAPOrderErrorDTO> errors = new ArrayList<SAPOrderErrorDTO>();
        if (null != outputErrorWrapper) {
            for (final YsdsaSlsErrors outputError : outputErrorWrapper.getItem()) {
               // System.out.println(outputError.getYymessage()+"//"+
               // outputError.getYynumber()+"//"+outputError.getYytype());
                errors.add(buildSAPOrderErrorDTO(outputError));
            }
        }
        return errors;
    }

    private Map<String, List<YsdsaSlsItemOut>> groupByHybrid(final List<YsdsaSlsItemOut> ysdsaSlsitemoutList) {
        final Map<String, List<YsdsaSlsItemOut>> group = new HashMap<String, List<YsdsaSlsItemOut>>();
        for (final YsdsaSlsItemOut outputSlsItem : ysdsaSlsitemoutList) {
            List<YsdsaSlsItemOut> outputSlsItemsByHbyrid = new ArrayList<YsdsaSlsItemOut>();
            if (group.containsKey("outputSlsItem.getHybrid()")) {//TODO
                outputSlsItemsByHbyrid = group.get("outputSlsItem.getHybrid()");//TODO  missing hybrid
            }
            outputSlsItemsByHbyrid.add(outputSlsItem);
            group.put("outputSlsItem.getHybrid()", outputSlsItemsByHbyrid);//TODO  missing hybrid
        }
        return group;
    }

    private MaterialDTO buildMaterialDTO(final YsdsaSlsItemOut outputSlsItem) {
        final MaterialDTO materialDTO = new MaterialDTO();
        materialDTO.setItemNumber(Long.valueOf(outputSlsItem.getYyitmNumber()));
        materialDTO.setMaterial(outputSlsItem.getYymaterial());
        materialDTO.setPlant(outputSlsItem.getYyplant());
        materialDTO.setStoragelocation(outputSlsItem.getYystoreLoc());
        materialDTO.setBatch(outputSlsItem.getYybatch());
        materialDTO.setUnrestqty(outputSlsItem.getYyreqQty());
        materialDTO.setRoute(outputSlsItem.getYyroute());
        materialDTO.setNetvalue(outputSlsItem.getYynetvalue());
        materialDTO.setTax(outputSlsItem.getYytax());
        materialDTO.setTransType(outputSlsItem.getYyitmtrty());
        return materialDTO;
    }

    private SAPOrderErrorDTO buildSAPOrderErrorDTO(final YsdsaSlsErrors outputError) {
        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setId(outputError.getYyid());
        sapOrderErrorDTO.setMessage(outputError.getYymessage());
        sapOrderErrorDTO.setNumber(outputError.getYynumber());
        sapOrderErrorDTO.setType(outputError.getYytype());
        return sapOrderErrorDTO;
    }
}
