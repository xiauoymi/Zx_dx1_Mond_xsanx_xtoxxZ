package com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YsdsaExpSlsHeader;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YttSdsaSlsErrors;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YttSdsaSlsItemOut;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.RequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;

import javax.xml.ws.Holder;
import java.util.ArrayList;
import java.util.List;

public class UpdateSalesOrdWithAlgorithmClient extends JAXWSClient {

    private YESSDSAYSDSALAN01RFC updateSalesOrdPortType;

    public UpdateSalesOrdWithAlgorithmClient(JAXWSRequestBuilder<ListRequestCreateUpdateOrderWithAlgorithm> jaxwsRequestBuilder,
                                             JAXWSResponseProcessor<List<ResponseCreateUpdateOrderWithAlgorithm>> jaxwsResponseProcessor,
                                             YESSDSAYSDSALAN01RFC updateSalesOrdPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.updateSalesOrdPortType = updateSalesOrdPortType;
    }

    @Override
    public Object callWebService(Object request) throws Exception {
        final ListRequestCreateUpdateOrderWithAlgorithm reqList = (ListRequestCreateUpdateOrderWithAlgorithm) request;

        List<ResponseCreateUpdateOrderWithAlgorithm> responsesList = new ArrayList<ResponseCreateUpdateOrderWithAlgorithm>();

        for (RequestCreateUpdateOrderWithAlgorithm req : reqList.getRequestCreateUpdateOrderWithAlgorithms()) {

            Holder<YttSdsaSlsErrors> errors = new Holder<YttSdsaSlsErrors>();
            Holder<YsdsaExpSlsHeader> headerOut = new Holder<YsdsaExpSlsHeader>();
            Holder<YttSdsaSlsItemOut> itemOut = new Holder<YttSdsaSlsItemOut>();

            updateSalesOrdPortType.ySdsaYsdsalan01Rfc(req.getInputSlsHeader(), req.getInputSlsItem(),
                    req.getSalesOrder(), req.getTranType(), errors, headerOut, itemOut);

            ResponseCreateUpdateOrderWithAlgorithm response = new ResponseCreateUpdateOrderWithAlgorithm();
            response.setYsdsaExpSlsHeader(headerOut.value);
            response.setYttSdsaSlsErrors(errors.value);
            response.setYttSdsaSlsItemOut(itemOut.value);
            responsesList.add(response);
        }
        return responsesList;
    }
}