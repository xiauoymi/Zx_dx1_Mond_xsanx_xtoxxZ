package com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YsdsaSlsHeader;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YsdsaSlsItem;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YttSdsaSlsItem;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.RequestCreateUpdateOrderWithAlgorithm;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UpdateSalesOrdWithAlgorithmRequestBuilder extends JAXWSRequestBuilder<ListRequestCreateUpdateOrderWithAlgorithm> {

    protected static String PLANTS_WITH_ALL_MATERIAL = "allMaterial";
    protected static String PLANTS_WITH_PARTIAL_MATERIAL = "partialMaterial";
    protected OrderDTO orderDTO;

    public UpdateSalesOrdWithAlgorithmRequestBuilder(final OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }


    @Override
    public ListRequestCreateUpdateOrderWithAlgorithm build() throws Exception {
        final ListRequestCreateUpdateOrderWithAlgorithm request = new ListRequestCreateUpdateOrderWithAlgorithm();
        request.setRequestCreateUpdateOrderWithAlgorithms(obtainsListRequestUpdate());

        return request;
    }

    protected List<RequestCreateUpdateOrderWithAlgorithm> obtainsListRequestUpdate() {

        List<RequestCreateUpdateOrderWithAlgorithm> list = new ArrayList<RequestCreateUpdateOrderWithAlgorithm>();

        Map<String, Object> plantstToPost = obtainPlantsToPost(orderDTO);

        Map<PlantDTO, List<OrderDetailDTO>> plantsWithAllMaterial = (Map<PlantDTO, List<OrderDetailDTO>>) plantstToPost.get(PLANTS_WITH_ALL_MATERIAL);
        Map<PlantDTO, List<OrderDetailDTO>> plantsWithPartialMaterial = (Map<PlantDTO, List<OrderDetailDTO>>) plantstToPost.get(PLANTS_WITH_PARTIAL_MATERIAL);

        for (PlantDTO plantDTO : plantsWithAllMaterial.keySet()) {
            List<OrderDetailDTO> orderDetailDTOList = plantsWithAllMaterial.get(plantDTO);
            list.add(buildRequestUpdate(orderDetailDTOList, plantDTO));
        }

        for (PlantDTO plantDTO : plantsWithPartialMaterial.keySet()) {
            List<OrderDetailDTO> orderDetailDTOList = plantsWithAllMaterial.get(plantDTO);
            list.add(buildRequestUpdate(orderDetailDTOList, plantDTO));
        }

        return list;
    }

    protected RequestCreateUpdateOrderWithAlgorithm buildRequestUpdate(List<OrderDetailDTO> orderDetailDTOs, PlantDTO plantDTO) {
        final RequestCreateUpdateOrderWithAlgorithm request = new RequestCreateUpdateOrderWithAlgorithm();
        request.setSalesOrder(orderDTO.getOrderIdSAP());
        request.setTranType(this.orderDTO.getTransactionType());

        request.setInputSlsHeader(buildOrderHeaderUpdate(plantDTO));
        request.setInputSlsItem(buildItemsTableUpdate(orderDetailDTOs, plantDTO));
        return request;
    }

    protected YsdsaSlsHeader buildOrderHeaderUpdate(PlantDTO plantDTO) {
        final YsdsaSlsHeader inputSlsHeader = new YsdsaSlsHeader();
        inputSlsHeader.setYydocType(orderDTO.getSapOrderTypeDTO().getOrderTypeCode());
        inputSlsHeader.setYyplant(plantDTO.getPlant());

        inputSlsHeader.setYysalesOrg(this.orderDTO.getDistributorConfigDTO().getSalesOrgCode());
        inputSlsHeader.setYydistrChan(this.orderDTO.getDistributorConfigDTO().getDistChCode());
        inputSlsHeader.setYydivision(this.orderDTO.getDistributorConfigDTO().getSalesDivCode());
        inputSlsHeader.setYypurchNoC(this.orderDTO.getPoNumber());
        inputSlsHeader.setYyordReason(this.orderDTO.getSapOrderReasonTypeDTO().getOrderReasonTypeCode());
        inputSlsHeader.setYypriceGrp(this.orderDTO.getPriceGroup().getPriceGroupCode());
        inputSlsHeader.setYysoldTo(CustomerLinkUtils.complete10Zeros(this.orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode()));
        inputSlsHeader.setYyshipTo(CustomerLinkUtils.complete10Zeros(this.orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode()));

        inputSlsHeader.setYysalesDist(this.orderDTO.getDistributorConfigDTO().getSubRegionCode());
        inputSlsHeader.setYysalesRep(getSalesRep());
        inputSlsHeader.setYycurrency(this.orderDTO.getCurrency());

        return inputSlsHeader;
    }

    protected YttSdsaSlsItem buildItemsTableUpdate(List<OrderDetailDTO> orderDetailDTOs, PlantDTO plantDTO) {
        final YttSdsaSlsItem inputSlsItemWrapper = new YttSdsaSlsItem();
        for (final OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            //for (final PlantDTO plantDTO : orderDetailDTO.getProductDTO().getListOfPlants()) {
            inputSlsItemWrapper.getItem().add(buildItemUpdate(orderDetailDTO, orderDetailDTO.getProductDTO().getProductCode(), plantDTO));
            //}
        }
        return inputSlsItemWrapper;
    }

    protected YsdsaSlsItem buildItemUpdate(OrderDetailDTO orderDetailDTO, final String hybrid, final PlantDTO plantDTO) {
        final YsdsaSlsItem inputSlsItem = new YsdsaSlsItem();
        inputSlsItem.setYyhybrid(hybrid);
        inputSlsItem.setYyformPref(plantDTO.getFormPref());
        inputSlsItem.setYysizePref1(plantDTO.getSizePref1());
        inputSlsItem.setYysizePref2(plantDTO.getSizePref2());
        inputSlsItem.setYypref1(plantDTO.getPref1());
        inputSlsItem.setYypref2(plantDTO.getPref2());
        inputSlsItem.setYypref3(plantDTO.getPref3());
        inputSlsItem.setYypref4(plantDTO.getPref4());
        inputSlsItem.setYyreqQty(BigDecimal.valueOf(orderDetailDTO.getQuantity()));
        inputSlsItem.setYyroute(plantDTO.getRoute());
        inputSlsItem.setYyitmtrty(plantDTO.getTransactionType());
        return inputSlsItem;
    }


    protected Map<String, Object> obtainPlantsToPost(OrderDTO orderDTO) {

        Map<String, Object> map = new HashMap<String, Object>();

        Map<PlantDTO, List<OrderDetailDTO>> plantsWithAllMaterial = new HashMap<PlantDTO, List<OrderDetailDTO>>();
        Map<PlantDTO, List<OrderDetailDTO>> plantsWithPartialMaterial = new HashMap<PlantDTO, List<OrderDetailDTO>>();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {

            for (PlantDTO plantDTO : orderDetailDTO.getProductDTO().getListOfPlants()) {

                if (orderDetailDTO.getQuantity() <= plantDTO.getUnrestqty()) {//complete allocation

                    if (!plantsWithAllMaterial.containsKey(plantDTO)) {
                        plantsWithAllMaterial.put(plantDTO, new ArrayList<OrderDetailDTO>());
                    }
                    plantsWithAllMaterial.get(plantDTO).add(orderDetailDTO);

                } else {//partial

                    if (!plantsWithPartialMaterial.containsKey(plantDTO)) {
                        plantsWithPartialMaterial.put(plantDTO, new ArrayList<OrderDetailDTO>());
                    }
                    plantsWithPartialMaterial.get(plantDTO).add(orderDetailDTO);
                }
            }
        }

        map.put(PLANTS_WITH_ALL_MATERIAL, plantsWithAllMaterial);
        map.put(PLANTS_WITH_PARTIAL_MATERIAL, plantsWithPartialMaterial);

        return map;
    }


    /*protected List<OrderDetailDTO> obtainAllPartialMaterial(Map<PlantDTO, List<OrderDetailDTO>> plantsWithPartialMaterial) {
        List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        for (PlantDTO plantDTO : plantsWithPartialMaterial.keySet()) {
            List<OrderDetailDTO> auxlist = plantsWithPartialMaterial.get(plantDTO);
            orderDetailDTOList.addAll(auxlist);
        }

        return orderDetailDTOList;
    }  */

    private String getSalesRep() {
        String salesRep = "";
        if (null != this.orderDTO.getRepresentativeDTO() &&
                !StringUtils.isEmpty(this.orderDTO.getRepresentativeDTO().getSapUserId())) {
            salesRep = this.orderDTO.getRepresentativeDTO().getSapUserId().trim();
        }
        return salesRep;
    }
}
