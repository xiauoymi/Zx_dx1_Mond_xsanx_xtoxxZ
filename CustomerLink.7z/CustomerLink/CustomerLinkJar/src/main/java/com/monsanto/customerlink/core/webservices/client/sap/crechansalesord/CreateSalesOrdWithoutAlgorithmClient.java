package com.monsanto.customerlink.core.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;

import javax.xml.ws.Holder;

public class CreateSalesOrdWithoutAlgorithmClient extends JAXWSClient {

    private YESSDSACRECHANSALESORD createSalesOrdPortType;

    public CreateSalesOrdWithoutAlgorithmClient(JAXWSRequestBuilder<YSdsaCreChanSalesOrd> jaxwsRequestBuilder,
                                                JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor,
                                                YESSDSACRECHANSALESORD createSalesOrdPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.createSalesOrdPortType = createSalesOrdPortType;
    }

    @Override
    public Object callWebService(Object request) throws Exception {
        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = (YSdsaCreChanSalesOrd) request;

        Holder<YttSdsaErrors> errors = new Holder<YttSdsaErrors>();
        Holder<YsdsaExpParam> expParam = new Holder<YsdsaExpParam>();
        Holder<YttSdsaSlsitemout> slsitemout = new Holder<YttSdsaSlsitemout>();

        createSalesOrdPortType.ySdsaCreChanSalesOrd(ySdsaCreChanSalesOrd.getImpParam(),
                ySdsaCreChanSalesOrd.getSlsheader(), ySdsaCreChanSalesOrd.getSlsitem(),
                errors, expParam, slsitemout);
        return new Object[]{errors.value, expParam.value, slsitemout.value};
    }

}
