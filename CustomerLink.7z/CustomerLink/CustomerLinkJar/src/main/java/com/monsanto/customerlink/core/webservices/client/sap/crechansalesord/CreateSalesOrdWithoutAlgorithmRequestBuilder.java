package com.monsanto.customerlink.core.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

public class CreateSalesOrdWithoutAlgorithmRequestBuilder extends JAXWSRequestBuilder<YSdsaCreChanSalesOrd> {

    private OrderDTO orderDTO;

    public CreateSalesOrdWithoutAlgorithmRequestBuilder(final OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    @Override
    public YSdsaCreChanSalesOrd build() throws Exception {
        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = new YSdsaCreChanSalesOrd();
        ySdsaCreChanSalesOrd.setImpParam(buildSAPOrder());
        ySdsaCreChanSalesOrd.setSlsheader(buildOrderHeaderTable());
        ySdsaCreChanSalesOrd.setSlsitem(buildItemsTable());
        return ySdsaCreChanSalesOrd;
    }

    private YsdsaImpParam buildSAPOrder() {
        final YsdsaImpParam ysdsaImpParam = new YsdsaImpParam();
        ysdsaImpParam.setTrantype(this.orderDTO.getTransactionType());
        return ysdsaImpParam;
    }

    private YttSdsaSlsheader buildOrderHeaderTable() {
        final YttSdsaSlsheader yttSdsaSlsheader = new YttSdsaSlsheader();
        yttSdsaSlsheader.getItem().add(buildOrderHeader());
        return yttSdsaSlsheader;
    }

    private YsdsaSlsheader buildOrderHeader() {
        final YsdsaSlsheader ysdsaSlsheader = new YsdsaSlsheader();
        ysdsaSlsheader.setYydocType(this.orderDTO.getSapOrderTypeDTO().getOrderTypeCode());
        ysdsaSlsheader.setYysalesOrg(this.orderDTO.getDistributorConfigDTO().getSalesOrgCode());
        ysdsaSlsheader.setYydistrChan(this.orderDTO.getDistributorConfigDTO().getDistChCode());
        ysdsaSlsheader.setYydivision(this.orderDTO.getDistributorConfigDTO().getSalesDivCode());
        ysdsaSlsheader.setYypurchNoC(this.orderDTO.getPoNumber());
        ysdsaSlsheader.setYyordReason(this.orderDTO.getSapOrderReasonTypeDTO().getOrderReasonTypeCode());
        ysdsaSlsheader.setYysalesDist(this.orderDTO.getDistributorConfigDTO().getSubRegionCode());//RBU missing paramters
        ysdsaSlsheader.setYyincoterms1(this.orderDTO.getIncoterms1());
        ysdsaSlsheader.setYyincoterms2(this.orderDTO.getIncoterms2());
        ysdsaSlsheader.setYypriceGrp(this.orderDTO.getPriceGroup().getPriceGroupCode());
        ysdsaSlsheader.setYycurrency(this.orderDTO.getCurrency());
        ysdsaSlsheader.setYysoldTo(this.orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
        ysdsaSlsheader.setYyshipTo(this.orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
        ysdsaSlsheader.setYysalesRep(getSalesRep());
        return ysdsaSlsheader;
    }

    private YttSdsaSlsitem buildItemsTable() {
        final YttSdsaSlsitem yttSdsaSlsitem = new YttSdsaSlsitem();
        for (final OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            for (final MaterialSkuDTO materialSkuDTO : orderDetailDTO.getProductDTO().getListOfSku()) {
                yttSdsaSlsitem.getItem().add(buildItem(orderDetailDTO.getProductDTO().getProductCode(), materialSkuDTO));
            }

        }
        return yttSdsaSlsitem;
    }

    private YsdsaSlsitem buildItem(final String hybrid, final MaterialSkuDTO materialSkuDTO) {
        final YsdsaSlsitem ysdsaSlsitem = new YsdsaSlsitem();
        ysdsaSlsitem.setYyitmNumber(String.valueOf(materialSkuDTO.getItemNumber()));
        ysdsaSlsitem.setYymaterial(materialSkuDTO.getMaterial());
        ysdsaSlsitem.setYyhybrid(hybrid);
        ysdsaSlsitem.setYyplant(materialSkuDTO.getPlant());
        ysdsaSlsitem.setYystoreLoc(materialSkuDTO.getStoragelocation());
        ysdsaSlsitem.setYybatch(materialSkuDTO.getBatch());
        ysdsaSlsitem.setYyreqQty(BigDecimal.valueOf(materialSkuDTO.getUnrestqty()));
        ysdsaSlsitem.setYyroute(materialSkuDTO.getRoute());
        ysdsaSlsitem.setYypoItmNo(materialSkuDTO.getPoItmNo());
        // TransactionTypeMaterial.INSERT.getCode() only send
        ysdsaSlsitem.setYyitmtrty(materialSkuDTO.getTransactionType());
        return ysdsaSlsitem;
    }

    private String getSalesRep() {
        String salesRep = "";
        if (null != this.orderDTO.getRepresentativeDTO() &&
                !StringUtils.isEmpty(this.orderDTO.getRepresentativeDTO().getSapUserId())) {
            salesRep = this.orderDTO.getRepresentativeDTO().getSapUserId().trim();
        }
        return salesRep;
    }
}
