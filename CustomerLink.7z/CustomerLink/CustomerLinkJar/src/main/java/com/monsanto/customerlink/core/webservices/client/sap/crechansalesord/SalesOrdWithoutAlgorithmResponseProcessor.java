package com.monsanto.customerlink.core.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SalesOrdWithoutAlgorithmResponseProcessor extends JAXWSResponseProcessor<Object[]> {

    @Override
    public Object process(final Object[] response) throws Exception {
        final SAPOrderDTO sapOrderDTO = buildSAPOrderDTO((YsdsaExpParam) response[1]);
        sapOrderDTO.setHybrids(buildHybridDTOList((YttSdsaSlsitemout) response[2]));
        sapOrderDTO.setErrors(buildSAPOrderErrorDTOList((YttSdsaErrors) response[0]));
        return sapOrderDTO;
    }

    private SAPOrderDTO buildSAPOrderDTO(final YsdsaExpParam ysdsaExpParam) {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        if (null != ysdsaExpParam) {
            sapOrderDTO.setSalesorder(ysdsaExpParam.getSalesorder());
            sapOrderDTO.setDocType(ysdsaExpParam.getDocType());
            sapOrderDTO.setSalesOrg(ysdsaExpParam.getSalesOrg());
            sapOrderDTO.setDistrChan(ysdsaExpParam.getDistrChan());
            sapOrderDTO.setDivision(ysdsaExpParam.getDivision());
            sapOrderDTO.setSoldTo(ysdsaExpParam.getSoldTo());
            sapOrderDTO.setPurchNoC(ysdsaExpParam.getPurchNoC());
            sapOrderDTO.setOrdReason(ysdsaExpParam.getOrdReason());
            sapOrderDTO.setIncoterms1(ysdsaExpParam.getIncoterms1());
            sapOrderDTO.setIncoterms2(ysdsaExpParam.getIncoterms2());
            sapOrderDTO.setPriceGrp(ysdsaExpParam.getPriceGrp());
            sapOrderDTO.setCurrency(ysdsaExpParam.getCurrency());
            sapOrderDTO.setSalesRep(ysdsaExpParam.getSalesRep());
        }
        return sapOrderDTO;
    }

    private List<HybridDTO> buildHybridDTOList(final YttSdsaSlsitemout yttSdsaSlsitemout) {
        final List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        if (null != yttSdsaSlsitemout) {
            final Map<String, List<YsdsaSlsitemout>> ysdsaSlsitemoutByHybridList = groupByHybrid(yttSdsaSlsitemout.getItem());
            for (final Map.Entry<String, List<YsdsaSlsitemout>> ysdsaSlsitemoutByHybrid : ysdsaSlsitemoutByHybridList.entrySet()) {
                final HybridDTO hybridDTO = new HybridDTO();
                hybridDTO.setHybridCode(ysdsaSlsitemoutByHybrid.getKey());
                for (final YsdsaSlsitemout ysdsaSlsitemout : ysdsaSlsitemoutByHybrid.getValue()) {
                    hybridDTO.getSkus().add(buildMaterialDTO(ysdsaSlsitemout));
                }
                hybrids.add(hybridDTO);
            }
        }
        return hybrids;
    }

    private List<SAPOrderErrorDTO> buildSAPOrderErrorDTOList(final YttSdsaErrors yttSdsaErrors) {
        final List<SAPOrderErrorDTO> errors = new ArrayList<SAPOrderErrorDTO>();
        if (null != yttSdsaErrors) {
            for (final YsdsaErrors ysdsaErrors : yttSdsaErrors.getItem()) {
                errors.add(buildSAPOrderErrorDTO(ysdsaErrors));
            }
        }
        return errors;
    }

    private Map<String, List<YsdsaSlsitemout>> groupByHybrid(final List<YsdsaSlsitemout> ysdsaSlsitemoutList) {
        final Map<String, List<YsdsaSlsitemout>> group = new HashMap<String, List<YsdsaSlsitemout>>();
        for (final YsdsaSlsitemout ysdsaSlsitemout : ysdsaSlsitemoutList) {
            List<YsdsaSlsitemout> ysdsaSlsitemoutListByHbyrid = new ArrayList<YsdsaSlsitemout>();
            if (group.containsKey(ysdsaSlsitemout.getYyhybrid())) {
                ysdsaSlsitemoutListByHbyrid = group.get(ysdsaSlsitemout.getYyhybrid());
            }
            ysdsaSlsitemoutListByHbyrid.add(ysdsaSlsitemout);
            group.put(ysdsaSlsitemout.getYyhybrid(), ysdsaSlsitemoutListByHbyrid);
        }
        return group;
    }

    private MaterialDTO buildMaterialDTO(final YsdsaSlsitemout ysdsaSlsitemout) {
        final MaterialDTO materialDTO = new MaterialDTO();
        materialDTO.setItemNumber(Long.valueOf(ysdsaSlsitemout.getYyitmNumber()));
        materialDTO.setMaterial(ysdsaSlsitemout.getYymaterial());
        materialDTO.setPlant(ysdsaSlsitemout.getYyplant());
        materialDTO.setStoragelocation(ysdsaSlsitemout.getYystoreLoc());
        materialDTO.setBatch(ysdsaSlsitemout.getYybatch());
        materialDTO.setUnrestqty(ysdsaSlsitemout.getYyreqQty());
        materialDTO.setRoute(ysdsaSlsitemout.getYyroute());
        materialDTO.setNetvalue(ysdsaSlsitemout.getYynetvalue());
        materialDTO.setTax(ysdsaSlsitemout.getYytax());
        materialDTO.setTransType(ysdsaSlsitemout.getYyitmtrty());
        return materialDTO;
    }

    private SAPOrderErrorDTO buildSAPOrderErrorDTO(final YsdsaErrors ysdsaErrors) {
        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setId(ysdsaErrors.getYyid());
        sapOrderErrorDTO.setMessage(ysdsaErrors.getYymessage());
        sapOrderErrorDTO.setNumber(ysdsaErrors.getYynumber());
        sapOrderErrorDTO.setType(ysdsaErrors.getYytype());
        return sapOrderErrorDTO;
    }
}
