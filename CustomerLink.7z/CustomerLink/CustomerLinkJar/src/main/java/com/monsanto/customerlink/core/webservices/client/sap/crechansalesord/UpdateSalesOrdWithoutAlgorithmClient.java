package com.monsanto.customerlink.core.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;

import javax.xml.ws.Holder;

public class UpdateSalesOrdWithoutAlgorithmClient extends JAXWSClient {

    private YESSDSACRECHANSALESORD updateSalesOrdPortType;

    public UpdateSalesOrdWithoutAlgorithmClient(JAXWSRequestBuilder<YSdsaCreChanSalesOrd> jaxwsRequestBuilder,
                                 JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor,
                                 YESSDSACRECHANSALESORD updateSalesOrdPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.updateSalesOrdPortType = updateSalesOrdPortType;
    }

    @Override
    public Object callWebService(Object request) throws Exception {
        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = (YSdsaCreChanSalesOrd) request;

        Holder<YttSdsaErrors> errors= new Holder<YttSdsaErrors>();
        Holder<YsdsaExpParam> expParam= new Holder<YsdsaExpParam>();
        Holder<YttSdsaSlsitemout> slsitemout= new Holder<YttSdsaSlsitemout>();

        updateSalesOrdPortType.ySdsaCreChanSalesOrd(ySdsaCreChanSalesOrd.getImpParam(), ySdsaCreChanSalesOrd.getSlsheader(),
                ySdsaCreChanSalesOrd.getSlsitem(), errors, expParam, slsitemout);



        return new Object[]{errors.value, expParam.value, slsitemout.value};
    }
}
