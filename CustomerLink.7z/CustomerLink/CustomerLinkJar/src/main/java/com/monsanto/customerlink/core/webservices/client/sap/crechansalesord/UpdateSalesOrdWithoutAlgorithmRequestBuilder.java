package com.monsanto.customerlink.core.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;

public class UpdateSalesOrdWithoutAlgorithmRequestBuilder extends JAXWSRequestBuilder<YSdsaCreChanSalesOrd> {

    private OrderDTO orderDTO;

    public UpdateSalesOrdWithoutAlgorithmRequestBuilder(final OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    @Override
    public YSdsaCreChanSalesOrd build() throws Exception {
        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = new YSdsaCreChanSalesOrd();
        ySdsaCreChanSalesOrd.setImpParam(buildSAPOrder(this.orderDTO));
        ySdsaCreChanSalesOrd.setSlsheader(buildOrderHeaderTable(orderDTO));
        ySdsaCreChanSalesOrd.setSlsitem(buildItemsTable(orderDTO.getDetail()));
        return ySdsaCreChanSalesOrd;
    }

    private YsdsaImpParam buildSAPOrder(final OrderDTO orderDTO) {
        final YsdsaImpParam ysdsaImpParam = new YsdsaImpParam();
        ysdsaImpParam.setSalesorder(orderDTO.getOrderIdSAP());
        ysdsaImpParam.setTrantype(orderDTO.getTransactionType());
        return ysdsaImpParam;
    }

    private YttSdsaSlsheader buildOrderHeaderTable(final OrderDTO orderDTO) {
        final YttSdsaSlsheader yttSdsaSlsheader = new YttSdsaSlsheader();
        yttSdsaSlsheader.getItem().add(buildOrderHeader(orderDTO));
        return yttSdsaSlsheader;
    }

    private YsdsaSlsheader buildOrderHeader(final OrderDTO orderDTO) {
        final YsdsaSlsheader ysdsaSlsheader = new YsdsaSlsheader();
        ysdsaSlsheader.setYydocType(orderDTO.getSapOrderTypeDTO().getOrderTypeCode());
        return ysdsaSlsheader;
    }

    private YttSdsaSlsitem buildItemsTable(final List<OrderDetailDTO> detail) {
        final YttSdsaSlsitem yttSdsaSlsitem = new YttSdsaSlsitem();
        for (final OrderDetailDTO orderDetailDTO : detail) {
            for (final MaterialSkuDTO materialSkuDTO : orderDetailDTO.getProductDTO().getListOfSku()) {
                yttSdsaSlsitem.getItem().add(buildItem(orderDetailDTO.getProductDTO().getProductCode(), materialSkuDTO));
            }

        }
        return yttSdsaSlsitem;
    }

    private YsdsaSlsitem buildItem(final String hybrid, final MaterialSkuDTO materialSkuDTO) {
        final YsdsaSlsitem ysdsaSlsitem = new YsdsaSlsitem();
        ysdsaSlsitem.setYyitmNumber(String.valueOf(materialSkuDTO.getItemNumber()));
        ysdsaSlsitem.setYyitmtrty(materialSkuDTO.getTransactionType());
         ysdsaSlsitem.setYyroute(materialSkuDTO.getRoute());

        if (StringUtils.equals(TransactionTypeMaterial.INSERT.getCode(), materialSkuDTO.getTransactionType())) {
            ysdsaSlsitem.setYymaterial(materialSkuDTO.getMaterial());
            ysdsaSlsitem.setYyhybrid(hybrid);
            ysdsaSlsitem.setYyplant(materialSkuDTO.getPlant());
            ysdsaSlsitem.setYystoreLoc(materialSkuDTO.getStoragelocation());
            ysdsaSlsitem.setYybatch(materialSkuDTO.getBatch());
            ysdsaSlsitem.setYyreqQty(BigDecimal.valueOf(materialSkuDTO.getUnrestqty()));
            ysdsaSlsitem.setYyroute(materialSkuDTO.getRoute());
            ysdsaSlsitem.setYypoItmNo(materialSkuDTO.getPoItmNo());
        } else if (StringUtils.equals(TransactionTypeMaterial.UPDATE.getCode(), materialSkuDTO.getTransactionType())) {
            ysdsaSlsitem.setYyreqQty(BigDecimal.valueOf(materialSkuDTO.getUnrestqty()));
        }
        // TransactionTypeMaterial.DELETE.getCode() only send itemNumber and transaction type
        return ysdsaSlsitem;
    }
}
