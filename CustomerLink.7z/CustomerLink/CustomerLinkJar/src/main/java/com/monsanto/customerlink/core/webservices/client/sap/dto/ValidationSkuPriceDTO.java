package com.monsanto.customerlink.core.webservices.client.sap.dto;

import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;

import java.io.Serializable;
import java.util.List;

public class ValidationSkuPriceDTO implements Serializable {

    private YttSdsaConditions conditions;
    private YttSdsaHybrids hybrids;
    private YttSdsaSdorg sdorg;
    private YttSdsaSpecies species;
    private YttSdsaErrref yttSdsaErrref;
    private OrderDTO orderDTO;
    private List<CropVO> cropVOList;


    public YttSdsaConditions getConditions() {
        return conditions;
    }

    public void setConditions(YttSdsaConditions conditions) {
        this.conditions = conditions;
    }

    public YttSdsaHybrids getHybrids() {
        return hybrids;
    }

    public void setHybrids(YttSdsaHybrids hybrids) {
        this.hybrids = hybrids;
    }

    public YttSdsaSdorg getSdorg() {
        return sdorg;
    }

    public void setSdorg(YttSdsaSdorg sdorg) {
        this.sdorg = sdorg;
    }

    public YttSdsaSpecies getSpecies() {
        return species;
    }

    public void setSpecies(YttSdsaSpecies species) {
        this.species = species;
    }

    public YttSdsaErrref getYttSdsaErrref() {
        return yttSdsaErrref;
    }

    public void setYttSdsaErrref(YttSdsaErrref yttSdsaErrref) {
        this.yttSdsaErrref = yttSdsaErrref;
    }

    public List<CropVO> getCropVOList() {
        return cropVOList;
    }

    public void setCropVOList(List<CropVO> cropVOList) {
        this.cropVOList = cropVOList;
    }

    public OrderDTO getOrderDTO() {
        return orderDTO;
    }

    public void setOrderDTO(OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }
}
