package com.monsanto.customerlink.core.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.xml.ws.Holder;

public class SendInventoryClient extends JAXWSClient {

    private YESSDSASENDINVENTORY sendInventoryPortType;

    public SendInventoryClient(JAXWSRequestBuilder<YSdsaSendInventory> jaxwsRequestBuilder,
                               JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor,
                               YESSDSASENDINVENTORY sendInventoryPortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.sendInventoryPortType = sendInventoryPortType;

    }

    @Override
    public Object callWebService(Object request) throws Exception {
        YSdsaSendInventory ySdsaSendInventory = (YSdsaSendInventory) request;

        Holder<YttSdsaErrref> errors = new Holder<YttSdsaErrref>();
        Holder<YttSdsaOuthybalg> outhybalg = new Holder<YttSdsaOuthybalg>();
        Holder<YttSdsaOuthybinv> outhybinv = new Holder<YttSdsaOuthybinv>();
        Holder<YttSdsaOuthybrids> outhybrids = new Holder<YttSdsaOuthybrids>();

        sendInventoryPortType.ySdsaSendInventory(ySdsaSendInventory.getInhybrids(),ySdsaSendInventory.getInskus(),ySdsaSendInventory.getSdorg(),
                ySdsaSendInventory.getSpecies(), errors, outhybalg, outhybinv, outhybrids);
        return new Object[]{errors.value,outhybalg.value,outhybinv.value,outhybrids.value};
    }

}