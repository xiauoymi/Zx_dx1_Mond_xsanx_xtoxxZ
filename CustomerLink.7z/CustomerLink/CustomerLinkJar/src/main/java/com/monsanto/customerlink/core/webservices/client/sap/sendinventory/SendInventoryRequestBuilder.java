package com.monsanto.customerlink.core.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;

public class SendInventoryRequestBuilder  extends JAXWSRequestBuilder<YSdsaSendInventory> {

    private YSdsaSendInventory ySdsaSendInventory;

    public SendInventoryRequestBuilder(YSdsaSendInventory ySdsaSendInventory) {
        this.ySdsaSendInventory = ySdsaSendInventory;
    }

    @Override
    public YSdsaSendInventory build() throws Exception {
        return this.ySdsaSendInventory;
    }

}