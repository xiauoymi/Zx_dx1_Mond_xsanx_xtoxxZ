package com.monsanto.customerlink.core.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;

public class SendInventoryResponseProcessor  extends JAXWSResponseProcessor<Object[]> {

    @Override
    public Object process(Object[] response) throws Exception {
        return response;
    }
}
