package com.monsanto.customerlink.core.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondin;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaErrors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.ws.Holder;

public class SendPricesClient extends JAXWSClient {

    private YESSDSASENDCONDITIONS yessdsasendconditions;

    public SendPricesClient(JAXWSRequestBuilder<YttSdsaCondin> jaxwsRequestBuilder,
                            JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor,
                            YESSDSASENDCONDITIONS yessdsasendconditions) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);

        this.yessdsasendconditions = yessdsasendconditions;
    }

    @Override
    protected Object callWebService(Object request) throws Exception {
        YttSdsaCondin yttSdsaCondin = (YttSdsaCondin) request;

        Holder<YttSdsaCondout> condout = new Holder<YttSdsaCondout>();
        Holder<YttSdsaErrors> errors = new Holder<YttSdsaErrors>();

        yessdsasendconditions.ySdsaSendConditions(yttSdsaCondin, condout, errors);

        return new Object[]{errors.value, condout.value};
    }
}
