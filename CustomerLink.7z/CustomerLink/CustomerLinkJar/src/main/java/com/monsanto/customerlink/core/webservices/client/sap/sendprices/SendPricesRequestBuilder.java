package com.monsanto.customerlink.core.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YsdsaCondin;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondin;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;

public class SendPricesRequestBuilder extends JAXWSRequestBuilder<YttSdsaCondin> {

    private OrderDTO orderDTO;

    public SendPricesRequestBuilder(OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    @Override
    public YttSdsaCondin build() throws Exception {

        DistributorConfigDTO configDTO = orderDTO.getDistributorConfigDTO();
        YttSdsaCondin yttSdsaCondin = new YttSdsaCondin();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {

            ProductDTO productDTO = orderDetailDTO.getProductDTO();
            String condType = CustomerLinkUtils.getPriceCondition(productDTO.getCropCode());

            for (MaterialSkuDTO materialSkuDTO : productDTO.getListOfSku()) {
                yttSdsaCondin.getItem().add(buildYsdsaCondin(condType, materialSkuDTO, configDTO));
            }
        }

        return yttSdsaCondin;
    }


    private YsdsaCondin buildYsdsaCondin(String condType, MaterialSkuDTO materialSkuDTO, DistributorConfigDTO configDTO) {

        YsdsaCondin ysdsaCondin = new YsdsaCondin();
        ysdsaCondin.setYycondition(condType);
        ysdsaCondin.setYydistrChan(configDTO.getDistChCode());
        ysdsaCondin.setYymaterial(materialSkuDTO.getMaterial());
        ysdsaCondin.setYysalesOrg(configDTO.getSalesOrgCode());
        ysdsaCondin.setYysoldTo(configDTO.getDistributor().getDistributorCode());
        ysdsaCondin.setYydivision(configDTO.getSalesDivCode());
        ysdsaCondin.setYydistrChan(CustomerLinkUtils.filterChannels(configDTO.getDistChCode()));
        ysdsaCondin.setYypriceGrp(orderDTO.getPriceGroup().getPriceGroupCode());
        ysdsaCondin.setYyshipTo(configDTO.getDistributor().getDistributorCode());
        return ysdsaCondin;
    }

}
