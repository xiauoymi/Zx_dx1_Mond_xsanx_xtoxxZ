package com.monsanto.customerlink.core.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YsdsaCondout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YsdsaErrors;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaErrors;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class SendPricesResponseProcessor extends JAXWSResponseProcessor<Object[]> {

    @Override
    public Object process(Object[] response) throws Exception {
        List<MaterialSkuDTO> materials = new ArrayList<MaterialSkuDTO>();
        YttSdsaCondout yttSdsaCondout = (YttSdsaCondout) response[1];
        YttSdsaErrors yttSdsaErrors = (YttSdsaErrors) response[0];

        if (yttSdsaCondout != null) {
            for (YsdsaCondout ysdsaCondout : yttSdsaCondout.getItem()) {
                materials.add(buildMaterial(ysdsaCondout));
            }
        }
        if(yttSdsaErrors!=null && !yttSdsaErrors.getItem().isEmpty()){
            materials.add(buildErrors(yttSdsaErrors));
        }
        //i need to return the errors in another array or in material alone
        //at processing  i need to verify that the maerial dosnt have errors
        return materials;
    }

    private MaterialSkuDTO buildErrors(YttSdsaErrors errors){
        MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();

        materialSkuDTO.setErrors(buildErrorsDTO(errors));
        return materialSkuDTO;
    }

    private MaterialSkuDTO buildMaterial(YsdsaCondout ysdsaCondout ) {
        MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();

        materialSkuDTO.setMaterial(ysdsaCondout.getYymaterial());
        materialSkuDTO.setCurrency(ysdsaCondout.getYyunit());
        return materialSkuDTO;
    }

    private List<ErrorOrderDTO> buildErrorsDTO(YttSdsaErrors item) {
        List<ErrorOrderDTO> errorOrderDTOs = new ArrayList<ErrorOrderDTO>();
        if (item != null) {
            for (YsdsaErrors error : item.getItem()) {
                errorOrderDTOs.add(buildErrorDTO(error));
            }
        }
        return errorOrderDTOs;
    }

    private ErrorOrderDTO buildErrorDTO(YsdsaErrors item) {
        ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setObjectWithError(CustomerLinkUtils.safeNull(item.getYyid(), ""));
        ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();
        errorTypeDTO.setDescription(CustomerLinkUtils.safeNull(item.getYymessage(), ""));
        errorTypeDTO.setErrorTypeCode(item.getYytype());

        errorOrderDTO.setErrorTypes(errorTypeDTO);

       return errorOrderDTO;
    }
}
