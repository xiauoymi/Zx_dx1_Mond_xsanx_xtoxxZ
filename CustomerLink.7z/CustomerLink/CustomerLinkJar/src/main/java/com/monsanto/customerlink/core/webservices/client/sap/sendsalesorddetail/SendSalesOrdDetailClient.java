package com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.*;

import javax.xml.ws.Holder;

public class SendSalesOrdDetailClient extends JAXWSClient {

    private YESSDSASENDSODETAIL sendSalesOrdDetail;

    public SendSalesOrdDetailClient(JAXWSRequestBuilder<YSdsaSendSoDetail> jaxwsRequestBuilder,
                                    JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor,
                                    YESSDSASENDSODETAIL sendSalesOrdDetail) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.sendSalesOrdDetail = sendSalesOrdDetail;
    }

    @Override
    public Object callWebService(Object request) throws Exception {
        final YSdsaSendSoDetail ySdsaSendSoDetail = (YSdsaSendSoDetail) request;

        Holder<YttSdsaErrors> errors = new Holder<YttSdsaErrors>();
        Holder<YttSdsaSlsheadout> slsheadout = new Holder<YttSdsaSlsheadout>();
        Holder<YttSdsaSlsitemout2> slsitemout = new Holder<YttSdsaSlsitemout2>();

            sendSalesOrdDetail.ySdsaSendSoDetail(ySdsaSendSoDetail.getSalesorder(), ySdsaSendSoDetail.getSlshead(),
                ySdsaSendSoDetail.getSlsordtyp(), errors, slsheadout, slsitemout);

        return new Object[]{errors.value, slsheadout.value, slsitemout.value};
    }
}
