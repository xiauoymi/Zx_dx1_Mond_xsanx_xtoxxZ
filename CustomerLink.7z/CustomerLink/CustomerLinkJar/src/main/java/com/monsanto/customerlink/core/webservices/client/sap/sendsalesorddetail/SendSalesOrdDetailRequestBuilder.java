package com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class SendSalesOrdDetailRequestBuilder extends JAXWSRequestBuilder<YSdsaSendSoDetail> {

    private OrderDTO orderDTO;

    public SendSalesOrdDetailRequestBuilder(final OrderDTO orderDTO) {
        this.orderDTO = orderDTO;
    }

    @Override
    public YSdsaSendSoDetail build() throws Exception {
        final YSdsaSendSoDetail ySdsaSendSoDetail = new YSdsaSendSoDetail();
        ySdsaSendSoDetail.setSalesorder(orderDTO.getOrderIdSAP());
        ySdsaSendSoDetail.setSlshead(buildOrderHead());
        ySdsaSendSoDetail.setSlsordtyp(buildOrderType());
        return ySdsaSendSoDetail;
    }

    private YttSdsaSlshead buildOrderHead() {
        final YttSdsaSlshead yttSdsaSlshead = new YttSdsaSlshead();
        yttSdsaSlshead.setItem(buildOrderHeadTable());
        return yttSdsaSlshead;
    }

    private YttSdsaSlsordtyp buildOrderType() {
        final YttSdsaSlsordtyp yttSdsaSlsordtyp = new YttSdsaSlsordtyp();
        yttSdsaSlsordtyp.setItem(buildOrderTypeTable());
        return yttSdsaSlsordtyp;
    }

    private List<YsdsaSlshead> buildOrderHeadTable() {
        final List<YsdsaSlshead> ysdsaSlsheadList = new ArrayList<YsdsaSlshead>();
        ysdsaSlsheadList.add(buildOrderHeadItem());
        return ysdsaSlsheadList;
    }

    private List<YsdsaSlsordtyp> buildOrderTypeTable() {
        final List<YsdsaSlsordtyp> ysdsaSlsordtypList = new ArrayList<YsdsaSlsordtyp>();
        ysdsaSlsordtypList.add(buildOrderTypeItem());
        return ysdsaSlsordtypList;
    }

    private YsdsaSlshead buildOrderHeadItem() {
        final YsdsaSlshead ysdsaSlshead = new YsdsaSlshead();
        setDistributorProfile(ysdsaSlshead);
        ysdsaSlshead.setYyordReason(orderDTO.getSapOrderReasonTypeDTO().getOrderReasonTypeCode());
        ysdsaSlshead.setYycurrency(orderDTO.getCurrency());
        ysdsaSlshead.setYydateFrom(orderDTO.getSearchPeriodDTO().getStartDate());
        ysdsaSlshead.setYydateTo(orderDTO.getSearchPeriodDTO().getEndDate());
        ysdsaSlshead.setYysalesRep(getSalesRep());
        return ysdsaSlshead;
    }

    private YsdsaSlsordtyp buildOrderTypeItem() {
        final YsdsaSlsordtyp ysdsaSlsordtyp = new YsdsaSlsordtyp();
        ysdsaSlsordtyp.setYyorderType(orderDTO.getSapOrderTypeDTO().getOrderTypeCode());
        return ysdsaSlsordtyp;
    }

    private void setDistributorProfile(final YsdsaSlshead ysdsaSlshead) {
        if (null != orderDTO.getDistributorConfigDTO()) {
            ysdsaSlshead.setYysalesOrg(orderDTO.getDistributorConfigDTO().getSalesOrgCode());
            ysdsaSlshead.setYydistrChan(orderDTO.getDistributorConfigDTO().getDistChCode());
            ysdsaSlshead.setYydivision(orderDTO.getDistributorConfigDTO().getSalesDivCode());
            ysdsaSlshead.setYysalesDistr(orderDTO.getDistributorConfigDTO().getSubRegionCode());
            if (null != orderDTO.getDistributorConfigDTO().getDistributor()) {
                ysdsaSlshead.setYysoldTo(orderDTO.getDistributorConfigDTO().getDistributor().getDistributorCode());
            }
        }
    }

    private String getSalesRep() {
        String salesRep = "";
        if (null != orderDTO.getRepresentativeDTO() &&
                !StringUtils.isEmpty(orderDTO.getRepresentativeDTO().getSapUserId())) {
            salesRep = orderDTO.getRepresentativeDTO().getSapUserId().trim();
        }
        return salesRep;
    }
}
