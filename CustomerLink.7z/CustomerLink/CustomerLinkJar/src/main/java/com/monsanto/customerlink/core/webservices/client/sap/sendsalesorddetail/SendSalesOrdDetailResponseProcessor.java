package com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class SendSalesOrdDetailResponseProcessor extends JAXWSResponseProcessor<Object[]> {

    @Override
    public Object process(Object[] response) throws Exception {
        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();

        if (null != response) {
            //YttSdsaErrors errors = (YttSdsaErrors) response[0];
            YttSdsaSlsheadout slsheadout = (YttSdsaSlsheadout) response[1];
            YttSdsaSlsitemout2 slsitemout = (YttSdsaSlsitemout2) response[2];

            if ((null != slsheadout && !slsheadout.getItem().isEmpty())) {
                YttSdsaSlsitemout2 yttSdsaSlsitemout = slsitemout;
                if (null == yttSdsaSlsitemout) {
                    yttSdsaSlsitemout = new YttSdsaSlsitemout2();
                }
                for (final YsdsaSlsheadout ysdsaSlsheadout : slsheadout.getItem()) {
                    sapOrderDTOList.add(buildSAPOrderDTO(ysdsaSlsheadout, yttSdsaSlsitemout));
                }
            }
        }
        return sapOrderDTOList;
    }

    private SAPOrderDTO buildSAPOrderDTO(final YsdsaSlsheadout ysdsaSlsheadout, final YttSdsaSlsitemout2 yttSdsaSlsitemout) throws ParseException {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.setSalesorder(ysdsaSlsheadout.getYysalesorder());
        sapOrderDTO.setDocType(ysdsaSlsheadout.getYydocType());
        sapOrderDTO.setSalesOrg(ysdsaSlsheadout.getYysalesOrg());
        sapOrderDTO.setDistrChan(ysdsaSlsheadout.getYydistrChan());
        sapOrderDTO.setDivision(ysdsaSlsheadout.getYydivision());
        sapOrderDTO.setSalesDis(ysdsaSlsheadout.getYysalesDistr());
        sapOrderDTO.setSoldTo(ysdsaSlsheadout.getYysoldTo());
        sapOrderDTO.setPurchNoC(ysdsaSlsheadout.getYypurchNoC());
        sapOrderDTO.setOrdReason(ysdsaSlsheadout.getYyordReason());
        sapOrderDTO.setIncoterms1(ysdsaSlsheadout.getYyincoterms1());
        sapOrderDTO.setIncoterms2(ysdsaSlsheadout.getYyincoterms2());
        sapOrderDTO.setPriceGrp(ysdsaSlsheadout.getYypriceGrp());
        sapOrderDTO.setCurrency(ysdsaSlsheadout.getYycurrency());
        sapOrderDTO.setStatus(ysdsaSlsheadout.getYystatus());
        sapOrderDTO.setCreateDate(ysdsaSlsheadout.getYyrecDate());
        sapOrderDTO.setSalesRep(ysdsaSlsheadout.getYysalesRep());
        setHybrids(sapOrderDTO, yttSdsaSlsitemout.getItem());
        return sapOrderDTO;
    }

    private void setHybrids(final SAPOrderDTO sapOrderDTO, final List<YsdsaSlsitemout2> ysdsaSlsitemoutList) {
        final List<YsdsaSlsitemout2> ysdsaSlsitemoutListByOrder = getItemsByOrder(ysdsaSlsitemoutList, sapOrderDTO.getSalesorder());
        if (ysdsaSlsitemoutListByOrder.isEmpty()) {
            setErrors(sapOrderDTO, "The order is incomplete");
        } else {
            for (final YsdsaSlsitemout2 ysdsaSlsitemout : ysdsaSlsitemoutListByOrder) {
                HybridDTO hybridDTO = findHybrid(sapOrderDTO.getHybrids(), ysdsaSlsitemout.getYyhybrid());
                if (null == hybridDTO) {
                    hybridDTO = new HybridDTO();
                    hybridDTO.setHybridCode(ysdsaSlsitemout.getYyhybrid());
                    hybridDTO.setStatus(ysdsaSlsitemout.getYystatus());
                    sapOrderDTO.getHybrids().add(hybridDTO);
                }
                //hybridDTO.getSkus().add(buildMaterialDTO(ysdsaSlsitemout));
                hybridDTO.addSku(buildMaterialDTO(ysdsaSlsitemout));
            }
        }
    }


    private void setErrors(final SAPOrderDTO sapOrderDTO, final String message) {
        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setMessage(message);
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
    }

    private List<YsdsaSlsitemout2> getItemsByOrder(final List<YsdsaSlsitemout2> ysdsaSlsitemoutList, final String orderIdSAP) {
        return (List<YsdsaSlsitemout2>) CollectionUtils.select(ysdsaSlsitemoutList, new Predicate() {
            @Override
            public boolean evaluate(final Object o) {
                return (StringUtils.equals(orderIdSAP, ((YsdsaSlsitemout2) o).getYysalesorder()));
            }
        });
    }

    private HybridDTO findHybrid(final List<HybridDTO> hybrids, final String hybrid) {
        return (HybridDTO) CollectionUtils.find(hybrids, new Predicate() {
            @Override
            public boolean evaluate(final Object o) {
                return (StringUtils.equals(hybrid, ((HybridDTO) o).getHybridCode()));
            }
        });
    }

    private MaterialDTO buildMaterialDTO(final YsdsaSlsitemout2 ysdsaSlsitemout) {
        final MaterialDTO materialDTO = new MaterialDTO();
        materialDTO.setItemNumber(Long.valueOf(ysdsaSlsitemout.getYyitmNumber()));
        materialDTO.setMaterial(ysdsaSlsitemout.getYymaterial());
        materialDTO.setDescription(ysdsaSlsitemout.getYydescription());
        materialDTO.setPlant(ysdsaSlsitemout.getYyplant());
        materialDTO.setUom(ysdsaSlsitemout.getYyuom());
        materialDTO.setStoragelocation(ysdsaSlsitemout.getYystoreLoc());
        materialDTO.setBatch(ysdsaSlsitemout.getYybatch());
        materialDTO.setReq_qty(ysdsaSlsitemout.getYyreqQty().doubleValue());
        materialDTO.setDel_qty(ysdsaSlsitemout.getYydelQty().doubleValue());
        materialDTO.setRoute(ysdsaSlsitemout.getYyroute());
        materialDTO.setNetvalue(ysdsaSlsitemout.getYynetvalue());
        materialDTO.setTax(ysdsaSlsitemout.getYytax());
        return materialDTO;
    }
}
