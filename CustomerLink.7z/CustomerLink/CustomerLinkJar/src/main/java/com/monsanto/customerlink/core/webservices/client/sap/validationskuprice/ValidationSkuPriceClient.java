package com.monsanto.customerlink.core.webservices.client.sap.validationskuprice;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YttSdsaErrref;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValidationSkuPriceClient extends JAXWSClient {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private YESSDSAVALIDATESKU validationSkuPricePortType;


    public ValidationSkuPriceClient(JAXWSRequestBuilder<ValidationSkuPriceDTO> jaxwsRequestBuilder,
                                    JAXWSResponseProcessor<ValidationSkuPriceDTO> jaxwsResponseProcessor,
                                    YESSDSAVALIDATESKU validationSkuPricePortType) {
        super(jaxwsRequestBuilder, jaxwsResponseProcessor);
        this.validationSkuPricePortType = validationSkuPricePortType;
    }

    @Override
    protected Object callWebService(Object request) throws Exception {
        ValidationSkuPriceDTO validationSkuPriceDTO = (ValidationSkuPriceDTO) request;

        YttSdsaErrref yttSdsaErrref = validationSkuPricePortType.ySdsaValidateSku(validationSkuPriceDTO.getConditions(),
                validationSkuPriceDTO.getHybrids(), validationSkuPriceDTO.getSdorg(),
                validationSkuPriceDTO.getSpecies());

        validationSkuPriceDTO.setYttSdsaErrref(yttSdsaErrref);

        return validationSkuPriceDTO;
    }
}
