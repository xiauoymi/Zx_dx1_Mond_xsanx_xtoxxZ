package com.monsanto.customerlink.core.webservices.client.sap.validationskuprice;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.service.util.PriceConditionsEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.service.util.TreatmentEnum;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;

import java.text.SimpleDateFormat;
import java.util.*;

public class ValidationSkuPriceRequestBuilder extends JAXWSRequestBuilder<ValidationSkuPriceDTO> {

    private OrderDTO _orderDTO;
    private List<CropVO> _cropVOList;

    public ValidationSkuPriceRequestBuilder(OrderDTO orderDTO, List<CropVO> cropVOList) {
        this._orderDTO = orderDTO;
        this._cropVOList = cropVOList;
    }

    @Override
    public ValidationSkuPriceDTO build() throws Exception {

        List<ProductDTO> productDTOList = this.obtainProducts(_orderDTO);

        ValidationSkuPriceDTO validationSkuPriceDTO = new ValidationSkuPriceDTO();
        validationSkuPriceDTO.setOrderDTO(_orderDTO);
        validationSkuPriceDTO.setCropVOList(_cropVOList);
        validationSkuPriceDTO.setSpecies(obtainSpecies(productDTOList, _cropVOList));
        validationSkuPriceDTO.setHybrids(obtainHybrids(productDTOList, _cropVOList));
        validationSkuPriceDTO.setSdorg(obtainSdorg(_orderDTO));
        validationSkuPriceDTO.setConditions(obtainConditions(_orderDTO));

        return validationSkuPriceDTO;
    }

    private YttSdsaConditions obtainConditions(OrderDTO orderDTO) {
        YttSdsaConditions conditions = new YttSdsaConditions();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            ProductDTO productDTO = orderDetailDTO.getProductDTO();

            YsdsaConditions condition = new YsdsaConditions();

            condition.setYyhybrid(getHybridName(productDTO));
            condition.setYycondType(CustomerLinkUtils.getPriceCondition(productDTO.getCropCode()));
            condition.setYypriceDate(CustomerLinkUtils.formatSapDate(new Date()));   //31.12.9999
            condition.setYypriceGroup(orderDTO.getPriceGroup().getPriceGroupCode());
            condition.setYyvkorg(orderDTO.getDistributorConfigDTO().getSalesOrgCode());
            condition.setYyvtweg(CustomerLinkUtils.filterChannels(orderDTO.getDistributorConfigDTO().getDistChCode()));

            conditions.getItem().add(condition);
        }
        return conditions;
    }

    private YttSdsaSdorg obtainSdorg(OrderDTO orderDTO) {

        YttSdsaSdorg sdorgs = new YttSdsaSdorg();

        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            ProductDTO productDTO = orderDetailDTO.getProductDTO();

            YsdsaSdorg sdorg = new YsdsaSdorg();
            sdorg.setYyhybrid(getHybridName(productDTO));
            sdorg.setYyvkorg(orderDTO.getDistributorConfigDTO().getSalesOrgCode());
            sdorg.setYyvtweg(CustomerLinkUtils.filterChannels(orderDTO.getDistributorConfigDTO().getDistChCode()));

            sdorgs.getItem().add(sdorg);
        }

        return sdorgs;
    }

    private YttSdsaHybrids obtainHybrids(List<ProductDTO> productDTOList, List<CropVO> cropVOList) {

        YttSdsaHybrids hybrids = new YttSdsaHybrids();

        for (ProductDTO productDTO : productDTOList) {

            CropVO cropVO = findInCropList(productDTO, cropVOList);
            YsdsaHybrids hybrid = new YsdsaHybrids();
            hybrid.setYyhybrid(getHybridName(productDTO));
            hybrid.setYyspecieCode(cropVO.getSpecieCode());
            hybrid.setYyacronym(productDTO.getFamilyCode());
            hybrid.setYyspTreatment(productDTO.getTreatmentCode());
            hybrids.getItem().add(hybrid);

        }

        return hybrids;
    }

    private YttSdsaSpecies obtainSpecies(List<ProductDTO> productDTOList, List<CropVO> cropVOList) {

        YttSdsaSpecies species = new YttSdsaSpecies();
        Map<String, CropVO> cropVOMap = groupByCrop(productDTOList, cropVOList);

        for (String cropCode : cropVOMap.keySet()) {

            CropVO cropVO = cropVOMap.get(cropCode);
            YsdsaSpecies specie = new YsdsaSpecies();
            specie.setYyclass(cropVO.getSpecieClass());
            specie.setYyclassType(cropVO.getSpecieType());
            specie.setYyspecieCode(cropVO.getSpecieCode());
            specie.setYylanguage("S");

            species.getItem().add(specie);
        }

        return species;
    }

    private Map<String, CropVO> groupByCrop(List<ProductDTO> productDTOList, List<CropVO> cropVOList) {
        Map<String, CropVO> cropVOMap = new HashMap<String, CropVO>();

        for (ProductDTO productDTO : productDTOList) {
            CropVO cropVO = findInCropList(productDTO, cropVOList);
            cropVOMap.put(cropVO.getCropCode(), cropVO);
        }
        return cropVOMap;
    }

    private CropVO findInCropList(ProductDTO productDTO, List<CropVO> cropVOList) {
        for (CropVO cropVO : cropVOList) {
            if (productDTO.getCropCode().equals(cropVO.getCropCode())) {
                return cropVO;
            }
        }
        return null;
    }

    private List<ProductDTO> obtainProducts(OrderDTO orderDTO) {
        List<ProductDTO> productDTOList = new ArrayList<ProductDTO>();
        for (OrderDetailDTO orderDetailDTO : orderDTO.getDetail()) {
            ProductDTO productDTO = orderDetailDTO.getProductDTO();
            productDTOList.add(productDTO);
        }
        return productDTOList;
    }

    private String getHybridName(ProductDTO productDTO) {
        return CustomerLinkUtils.getHybridName(productDTO);
    }


}
