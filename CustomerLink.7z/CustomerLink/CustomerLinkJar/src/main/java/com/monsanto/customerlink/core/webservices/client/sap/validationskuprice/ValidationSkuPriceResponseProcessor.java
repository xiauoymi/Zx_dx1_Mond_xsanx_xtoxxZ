package com.monsanto.customerlink.core.webservices.client.sap.validationskuprice;

import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YsdsaErrref;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.apache.commons.lang3.StringUtils;


public class ValidationSkuPriceResponseProcessor extends JAXWSResponseProcessor<ValidationSkuPriceDTO> {

    @Override
    public OrderDTO process(ValidationSkuPriceDTO validationSkuPriceDTO) throws Exception {
        groupAndSetErrosByHybrid(validationSkuPriceDTO);
        return validationSkuPriceDTO.getOrderDTO();
    }

    private void groupAndSetErrosByHybrid(ValidationSkuPriceDTO validationSkuPriceDTO) {

        for (OrderDetailDTO orderDetailDTO : validationSkuPriceDTO.getOrderDTO().getDetail()) {

            String hybrid =orderDetailDTO.getProductDTO().getProductCode(); //CustomerLinkUtils.getHybridName(orderDetailDTO.getProductDTO());
            for (YsdsaErrref item : validationSkuPriceDTO.getYttSdsaErrref().getItem()) {
                if (StringUtils.equals(hybrid, item.getYyhybrid())) {
                    orderDetailDTO.getErrors().add(buildErrorDTO(item));
                }
            }
        }
    }

    private ErrorOrderDTO buildErrorDTO(YsdsaErrref item) {
        ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setObjectWithError(CustomerLinkUtils.safeNull(item.getYyhybrid(),"")+ " " + CustomerLinkUtils.safeNull(item.getYymaterial(), ""));
        ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();
        errorTypeDTO.setDescription(CustomerLinkUtils.safeNull(item.getYyerrdesc(), "")+  "  " + CustomerLinkUtils.safeNull(item.getYymaterial(),""));
        errorTypeDTO.setErrorTypeCode(item.getYyerrcode());

        errorOrderDTO.setErrorTypes(errorTypeDTO);

        return errorOrderDTO;
    }


}
