package com.monsanto.customerlink.core.webservices.util;

import com.monsanto.customerlink.core.service.util.TreatmentEnum;

public class ClientUtils {


/*
** filtrar

*/

    /**
     * recibe treatment and filter it according to the follow rules
     * <p/>
     * <li>IF SPECIAL_TREATMENT IN (PM,CP,P5,PO):
     * THEN SPECIAL_TREATMENT = ST_PONCHO</li>
     * <li>IF SPECIAL_TREATMENT = PB
     * THEN SPECIAL_TREATMENT = ST_PONCHO/BAYTAN</li>
     * <li>IF SPECIAL_TREATMENT = A
     * THEN SPECIAL_TREATMENT = ST_APRON</li>
     * <li>IF SPECIAL_TREATMENT= AP
     * THEN SPECIAL_TREATMENT = ST_PONCHO/APRON</li>
     * <li>IF SPECIAL_TREATMENT = BA
     * THEN SPECIAL_TREATMENT = ST_BAYTAN</li>
     * <li>ANY OTHER SPECIAL_TREATMENT = STANDARD</li>
     *
     * @param treatment
     * @return
     */
    public static String filterTreatment(String treatment) {
        if (TreatmentEnum.ST_PONCHO_CP.getCode().equals(treatment)) {
            return TreatmentEnum.ST_PONCHO_P5.getCode();
        }
        if (TreatmentEnum.ST_PONCHO.getCode().equals(treatment)) {
            return TreatmentEnum.ST_PONCHO_P5.getCode();
        }
        if (TreatmentEnum.ST_PONCHO_PM.getCode().equals(treatment)) {
            return TreatmentEnum.ST_PONCHO_P5.getCode();
        }

        return treatment;
    }

}
