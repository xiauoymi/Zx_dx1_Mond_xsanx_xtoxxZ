package com.monsanto.customerlink.core.webservices.util;



import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class URLLocator {
    private static final String LSI_FUNCTION_PROPERTY_KEY = "lsi.function";
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final String propertyFile;
    private final String URL_SUFFIX = ".wsdl.url";
    private final String PERIOD = ".";
    private final String USER_NAME="ws-cl-username";
    private final String PASSWORD="ws-cl-password";

    public URLLocator(String propertyFile) {
        this.propertyFile = propertyFile;
    }

    public URL getWSDLURL(String serviceName) {
        try {
            String url = createURL(serviceName);
            log.info("getWSDLURL url="+url+" lsi.function=" + getEnvironment());
            return new URL(url);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public String createURL(String serviceName) {
        log.info("propertyFile="+this.propertyFile);
        return ResourceBundle.getBundle(this.propertyFile).getString(
                getEnvironment() + PERIOD + serviceName + URL_SUFFIX);
    }

    public String getEnvironment() {
        return System.getProperty(LSI_FUNCTION_PROPERTY_KEY);
    }

    public String getUserClCredentials() {
        return ResourceBundle.getBundle(this.propertyFile).getString(
                getEnvironment() + PERIOD + USER_NAME);
    }

    public String getUserClPassword() {
        return ResourceBundle.getBundle(this.propertyFile).getString(
                getEnvironment() + PERIOD + PASSWORD);

    }



}
