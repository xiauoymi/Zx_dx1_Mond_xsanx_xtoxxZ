package com.monsanto.customerlink.core.batch;

public class BatchProcessMain_DT {

    /* invoke batch process in dev environment*/
    public static void main(String[] args) {
        String LSI_FUNCTION_PROPERTY_KEY = "lsi.function";
        String MONCRYPTJV_PROPERTY_KEY = "MONCRYPTJV";

        System.setProperty(LSI_FUNCTION_PROPERTY_KEY, "dev");
        System.setProperty(MONCRYPTJV_PROPERTY_KEY, "C:\\webapps\\keys");
        new BatchProcessMain().process();
    }
}
