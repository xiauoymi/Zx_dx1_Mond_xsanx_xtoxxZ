package com.monsanto.customerlink.core.batch;

import com.monsanto.customerlink.core.service.OrderErrorService;
import com.monsanto.customerlink.core.service.ProcessAgrementService;
import com.monsanto.customerlink.core.service.ProcessAtpService;
import com.monsanto.customerlink.core.service.catalog.SubregionService;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BatchProcessMain_UT {

    BatchProcessMain batchProcessMain;

    @Mock
    SubregionService subregionService;
    @Mock
    CropRepository cropRepository;
    @Mock
    OrderErrorService orderErrorService;
    @Mock
    ApplicationContext applicationContext;
    @Mock
    BasicDataSource basicDataSource;
    @Mock
    AutowireCapableBeanFactory autowireCapableBeanFactory;
    @Mock
    ProcessAtpService processAtpService;
    @Mock
    ProcessAgrementService processAgrementService;

    List<SubRegionDTO> subRegionDTOList = new ArrayList<SubRegionDTO>();

    @Before
    public void setup() {

        reset(applicationContext);
        when(applicationContext.getBean("clDataSource", BasicDataSource.class)).thenReturn(basicDataSource);
        when(applicationContext.getAutowireCapableBeanFactory()).thenReturn(autowireCapableBeanFactory);

        when(autowireCapableBeanFactory.getBean(SubregionService.class)).thenReturn(subregionService);
        when(autowireCapableBeanFactory.getBean(CropRepository.class)).thenReturn(cropRepository);
        when(autowireCapableBeanFactory.getBean(OrderErrorService.class)).thenReturn(orderErrorService);
        when(autowireCapableBeanFactory.getBean(ProcessAtpService.class)).thenReturn(processAtpService);
        when(autowireCapableBeanFactory.getBean(ProcessAgrementService.class)).thenReturn(processAgrementService);

        for (int i = 0; i < 10; i++) {
            SubRegionDTO subRegionDTO = new SubRegionDTO();
            subRegionDTOList.add(subRegionDTO);
        }
    }

    @Test(expected = RuntimeException.class)
    public void testProcessAtpServiceIsReturnedAndStartedProcessOfAtp() {
        batchProcessMain = new BatchProcessMain(applicationContext);
        batchProcessMain.process();
    }
}
