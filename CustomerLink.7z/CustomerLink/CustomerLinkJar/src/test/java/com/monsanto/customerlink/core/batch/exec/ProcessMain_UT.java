package com.monsanto.customerlink.core.batch.exec;

import com.monsanto.customerlink.core.service.AgreementService;
import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Ignore
public class ProcessMain_UT {

    ProcessMain processMain;

    @Mock
    ApplicationContext applicationContext;

    @Mock
    AgreementService agreementService;

    @Mock
    BasicDataSource basicDataSource;

    @Mock
    AutowireCapableBeanFactory autowireCapableBeanFactory;

    @Before
    public void setup() {
        if (System.getProperty("env") != null) {
            System.getProperties().remove(System.getProperty("env"));
        }
        if (System.getProperty("lsi.function") != null) {
            System.getProperties().remove(System.getProperty("lsi.function"));
        }
        System.setProperty("MONCRYPTJV", "C:\\webapps\\keys");
    }

    @Test
    @Ignore
    public void testInitialiseDataSourceAndGetAgreementServiceWhenItIsRequired() {
        System.setProperty("env", "dev");
        reset(applicationContext);
        when(applicationContext.getBean("clDataSource", BasicDataSource.class)).thenReturn(basicDataSource);
        when(applicationContext.getAutowireCapableBeanFactory()).thenReturn(autowireCapableBeanFactory);
        when(autowireCapableBeanFactory.getBean(AgreementService.class)).thenReturn(agreementService);

        processMain = new ProcessMain(applicationContext);

        Assert.assertNotNull(processMain.getService(AgreementService.class));
    }

    @Test
    @Ignore
    public void testInitialiseDataSourceAndGetAgreementServiceWhenItIsRequiredFromApplicationContext() {
        System.setProperty("lsi.function", "dev");
        reset(applicationContext);
        when(applicationContext.getBean("clDataSource", BasicDataSource.class)).thenReturn(basicDataSource);
        when(applicationContext.getAutowireCapableBeanFactory()).thenReturn(autowireCapableBeanFactory);
        when(autowireCapableBeanFactory.getBean(AgreementService.class)).thenReturn(agreementService);

        processMain = new ProcessMain(applicationContext);

        processMain.getApplicationContext().getBean(AgreementService.class);
    }

    @Test
    @Ignore
    public void testConstructorForTestingContextFileIsInitializedCorrectly() {
        new ProcessMain();
    }

    @Test(expected = RuntimeException.class)
    @Ignore
    public void throwsRuntimeExceptionWhenCipherPasswordIsNotExist() {
        System.setProperty("MONCRYPTJV", "C:\\MONCRYPTJV_test");
        new ProcessMain();
    }
}
