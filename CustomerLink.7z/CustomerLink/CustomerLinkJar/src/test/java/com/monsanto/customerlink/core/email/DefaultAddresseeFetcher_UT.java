package com.monsanto.customerlink.core.email;

import com.google.common.collect.Iterables;
import org.hamcrest.core.IsCollectionContaining;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Properties;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.fail;

public class DefaultAddresseeFetcher_UT {

    private DefaultAddresseeFetcher theDefaultAddresseeFetcher;

    @Before
    public void setUpTheDefaultAddresseeFetcher() {
        Properties properties = new Properties();
        properties.put("to", "carlos.rodarte@monsanto.com");
        theDefaultAddresseeFetcher = new DefaultAddresseeFetcher(properties);
    }

    @Test
    public void getTosReturnsACollectionContainingTheToPropertyInThePropertiesObjectPassedOnConstruction() throws Exception {
        assertThat(theDefaultAddresseeFetcher.getTos(), is(IsCollectionContaining.<String>hasItem("carlos.rodarte@monsanto.com")));
    }

    @Test
    public void getCcsAlwaysReturnsNull() throws Exception {
        assertThat(theDefaultAddresseeFetcher.getCcs(), is(nullValue()));
    }

    @Test
    public void getBccsAlwaysReturnsNull() throws Exception {
        assertThat(theDefaultAddresseeFetcher.getBccs(), is(nullValue()));
    }

    @Test
    public void throwsAnExceptionIfTheToPropertyIsUnavailableInThePropertiesObjectPassedOnConstruction() throws Exception {
        try {
            new DefaultAddresseeFetcher(new Properties());
            fail("should have thrown an Exception since there is no 'to' property in the passed Properties object");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfPassedANullPropertiesObjectOnConstruction() throws Exception {
        try {
            new DefaultAddresseeFetcher(null);
            fail("should have thrown an Exception since the constructor was passed a null Properties object");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void ifTheToPropertyContainsAListOfCommaSeparatedAddressesEachAddressIsAMemberOfTheCollectionReturnedByTheGetTosMethod() throws Exception {
        Properties properties = new Properties();
        properties.put("to", "carlos1.rodarte@monsanto.com,carlos2.rodarte@monsanto.com");
        AddresseeFetcher addresseeFetcher = new DefaultAddresseeFetcher(properties);
        Collection<String> tos = addresseeFetcher.getTos();
        assertThat(tos.size(), is(2));
        assertThat(Iterables.get(tos, 0), is("carlos1.rodarte@monsanto.com"));
        assertThat(Iterables.get(tos, 1), is("carlos2.rodarte@monsanto.com"));
    }
}
