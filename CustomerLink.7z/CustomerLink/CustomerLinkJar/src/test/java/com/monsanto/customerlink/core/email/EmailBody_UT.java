package com.monsanto.customerlink.core.email;

import org.junit.Ignore;
import org.junit.Test;

import static junit.framework.TestCase.fail;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;

public class EmailBody_UT {

    @Test
    public void isEqualToAnotherEmailBodyIfAndOnlyIfAllPropertiesAreEqual() throws Exception {
        EmailBody one = new EmailBody("text", false);
        EmailBody two = new EmailBody("text", false);
        assertThat(one, is(equalTo(two)));

        two = new EmailBody("a different text", false);
        assertThat(one, is(not(equalTo(two))));

        two = new EmailBody("text", true);
        assertThat(one, is(not(equalTo(two))));
    }

    @Test
    public void throwsAnExceptionIfTheTextIsNull() throws Exception {
        try {
            new EmailBody(null, false);
            fail("should have thrown an exception since the body's text can't be null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void isEqualToAnotherEmailBodyIfTheTwoAreTheSameInstance() throws Exception {
        EmailBody one = new EmailBody("text", false);
        EmailBody two = one;

        assertThat(one, is(equalTo(two)));
    }

    @Test
    public void equalEmailBodiesYieldTheSameHashCode() throws Exception {
        EmailBody one = new EmailBody("text", false);
        EmailBody two = new EmailBody("text", false);

        assertThat(one.hashCode(), is(two.hashCode()));
    }

    @Test
    public void autoDeterminesIfTheTextIsHtml() throws Exception {
        EmailBody emailBody = new EmailBody("test");
        assertThat(emailBody.isHtml(), is(false));

        emailBody = new EmailBody("<html>test</html>");
        assertThat(emailBody.isHtml(), is(true));
    }
}
