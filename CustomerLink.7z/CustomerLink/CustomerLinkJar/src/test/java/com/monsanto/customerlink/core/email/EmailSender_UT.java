package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.hamcrest.CoreMatchers;
import org.hamcrest.beans.HasPropertyWithValue;
import org.hamcrest.collection.IsArrayContaining;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EmailSender_UT {

    @Mock
    private ClassPathResource bannerResource;

    @Mock
    private JavaMailSender theUnderlyingJavaMailSender;

    @InjectMocks
    private EmailSender theActualSender;

    @Test
    public void theUnderlyingJavaMailSenderGetsInvokedWithTheRightMimeMessage() throws Exception {
        MimeMessage theMockMimeMessage = mock(MimeMessage.class);
        when(theUnderlyingJavaMailSender.createMimeMessage()).thenReturn(theMockMimeMessage);
        when(bannerResource.getFilename()).thenReturn(new String("banner.png"));

        Email theActualEmail = new Email(Lists.newArrayList("test_to@monsanto.com"), Lists.newArrayList("test_cc@monsanto.com"), Lists.newArrayList("test_bcc@monsanto.com"), "test_subject", new EmailBody("test_body", true));
        theActualEmail.setFrom("test_from@monsanto.com");
        theActualSender.send(theActualEmail);

        verify(theMockMimeMessage).setRecipients(same(Message.RecipientType.TO), argThat(IsArrayContaining.<Address>hasItemInArray(HasPropertyWithValue.<Address>hasProperty("address", equalTo("test_to@monsanto.com")))));
        verify(theMockMimeMessage).setRecipients(same(Message.RecipientType.CC), argThat(IsArrayContaining.<Address>hasItemInArray(HasPropertyWithValue.<Address>hasProperty("address", equalTo("test_cc@monsanto.com")))));
        verify(theMockMimeMessage).setRecipients(same(Message.RecipientType.BCC), argThat(IsArrayContaining.<Address>hasItemInArray(HasPropertyWithValue.<Address>hasProperty("address", equalTo("test_bcc@monsanto.com")))));

        verify(theMockMimeMessage).setFrom(Matchers.<Address>argThat(HasPropertyWithValue.<Address>hasProperty("address", equalTo("test_from@monsanto.com"))));

        verify(theMockMimeMessage).setSubject(eq("test_subject"));

        verify(theMockMimeMessage).setContent(any(MimeMultipart.class));

        verify(theUnderlyingJavaMailSender).send(theMockMimeMessage);
    }

    @Test
    public void ifTheCcsOrBccsAreNotSpecifiedThenThoseFieldsAreNotSetInTheMimeMessageWithWhichTheUnderlyingJavaMailSenderGetsInvoked() throws Exception {
        MimeMessage theMockMimeMessage = mock(MimeMessage.class);
        when(theUnderlyingJavaMailSender.createMimeMessage()).thenReturn(theMockMimeMessage);
        when(bannerResource.getFilename()).thenReturn(new String("banner.png"));

        Email theActualEmail = new Email(Lists.newArrayList("test_to@monsanto.com"), null, null, "test_subject", new EmailBody("test_body", false));
        theActualSender.send(theActualEmail);

        verify(theMockMimeMessage, never()).setRecipients(same(Message.RecipientType.CC), argThat(IsArrayContaining.<Address>hasItemInArray(HasPropertyWithValue.<Address>hasProperty("address", CoreMatchers.any(String.class)))));
        verify(theMockMimeMessage, never()).setRecipients(same(Message.RecipientType.BCC), argThat(IsArrayContaining.<Address>hasItemInArray(HasPropertyWithValue.<Address>hasProperty("address", CoreMatchers.any(String.class)))));
    }

    @Test
    public void ifTheFromFieldIsNotSetInTheActualEmailThenThatFieldIsNotSetInTheMimeMessageWithWhichTheUnderlyingJavaMailSenderGetsInvoked() throws Exception {
        MimeMessage theMockMimeMessage = mock(MimeMessage.class);
        when(theUnderlyingJavaMailSender.createMimeMessage()).thenReturn(theMockMimeMessage);
        when(bannerResource.getFilename()).thenReturn(new String("banner.png"));

        Email theActualEmail = new Email(Lists.newArrayList("test_to@monsanto.com"), Lists.newArrayList("test_cc@monsanto.com"), Lists.newArrayList("test_bcc@monsanto.com"), "test_subject", new EmailBody("test_body", false));
        theActualSender.send(theActualEmail);

        verify(theMockMimeMessage, never()).setFrom(Matchers.<Address>argThat(HasPropertyWithValue.<Address>hasProperty("address", equalTo("test_from@monsanto.com"))));
    }

    @Test
    public void ifTheBodyIsNotHtmlTheContentTypeIsNotSpecified() throws Exception {
        MimeMessage theMockMimeMessage = mock(MimeMessage.class);
        when(theUnderlyingJavaMailSender.createMimeMessage()).thenReturn(theMockMimeMessage);
        when(bannerResource.getFilename()).thenReturn(new String("banner.png"));

        Email theActualEmail = new Email(Lists.newArrayList("test_to@monsanto.com"), Lists.newArrayList("test_cc@monsanto.com"), Lists.newArrayList("test_bcc@monsanto.com"), "test_subject", new EmailBody("test_body", false));
        theActualSender.send(theActualEmail);

        verify(theMockMimeMessage).setContent(any(Multipart.class));
    }
}
