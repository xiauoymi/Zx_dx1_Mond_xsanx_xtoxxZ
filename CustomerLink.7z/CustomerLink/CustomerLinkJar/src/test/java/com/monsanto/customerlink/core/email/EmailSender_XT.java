package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:application-context-notifications.xml")
public class EmailSender_XT {

    @Autowired
    private EmailSender theActualEmailSender;

    @Test
    public void sendEmail() throws Exception {
        theActualEmailSender.send(new Email(Lists.newArrayList("carlos.rodarte@monsanto.com"), null, null, "hello world!", new EmailBody("hello world!", false)));
    }
}
