package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.hamcrest.collection.IsCollectionContaining;
import org.junit.Test;

import java.util.Collection;

import static junit.framework.TestCase.fail;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class Email_UT {

    @Test
    public void isEqualToAnotherEmailIfAllThePropertiesAreEqual() throws Exception {
        Email one = new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));
        Email two = new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));

        assertThat(one, is(equalTo(two)));
    }

    @Test
    public void throwsAnExceptionIfTheTosCollectionIsNull() throws Exception {
        try {
            new Email(null, Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));
            fail("should have thrown an exception since the 'to' field can't be null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfTheSubjectIsNull() throws Exception {
        try {
            new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), null, new EmailBody("test_body", false));
            fail("should have thrown an exception since the subject can't be null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfTheBodyIsNull() throws Exception {
        try {
            new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", null);
            fail("should have thrown an exception since the body can't be null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void doesntThrowAnExceptionIfTheCcsBccsCollectionsOrTheFromFieldAreNull() throws Exception {
        new Email(Lists.newArrayList("test_to"), null, Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));
        new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), null, "test_subject", new EmailBody("test_body", false));
        new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));
    }

    @Test
    public void equalEmailsYieldTheSameHashCode() throws Exception {
        Email one = new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));
        Email two = new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "test_subject", new EmailBody("test_body", false));

        assertThat(one.hashCode(), is(two.hashCode()));
    }

    @Test
    public void throwsAnExceptionIfTheSubjectIsAnEmptyString() throws Exception {
        try {
            new Email(Lists.newArrayList("test_to"), Lists.newArrayList("test_cc"), Lists.newArrayList("test_bcc"), "", new EmailBody("test_body", false));
            fail("should have thrown an exception since the subject is an empty string");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfPassedAnEmptyCollectionAsTosOnConstruction() throws Exception {
        try {
            new Email(Lists.<String>newArrayList(), null, null, "test_subject", new EmailBody("test_body"));
            fail("Should have thrown an exception since the 'to' collection is empty");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfPassedANullCollectionAsTosOnConstruction() throws Exception {
        try {
            new Email((Collection<String>) null, null, null, "test_subject", new EmailBody("test_body"));
            fail("Should have thrown an exception since the 'to' collection is null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void getAddresseesMethodsReturnTheElementsPassedAtConstruction() throws Exception {
        Email email = new Email(Lists.newArrayList("test1_to", "test2_to"), Lists.newArrayList("test1_cc", "test2_cc"), Lists.newArrayList("test1_bcc", "test2_bcc"), "test_subject", new EmailBody("test_body"));
        assertThat(email.tos(), IsCollectionContaining.<String>hasItems(equalTo("test1_to"), equalTo("test2_to")));
        assertThat(email.ccs(), IsCollectionContaining.<String>hasItems(equalTo("test1_cc"), equalTo("test2_cc")));
        assertThat(email.bccs(), IsCollectionContaining.<String>hasItems(equalTo("test1_bcc"), equalTo("test2_bcc")));
    }

    @Test
    public void getCcAddresseesAndGetBccAddresseesMethodsReturnNullIfPassedNullCollectionsAtConstruction() throws Exception {
        Email email = new Email(Lists.newArrayList("test_to"), null, null, "test_subject", new EmailBody("test_body"));
        assertThat(email.ccs(), is(nullValue()));
        assertThat(email.bccs(), is(nullValue()));
    }

    @Test
    public void getCcAddresseesAndGetBccAddresseesMethodsReturnNullIfPassedEmptyCollectionsAtConstruction() throws Exception {
        Email email = new Email(Lists.newArrayList("test_to"), Lists.<String>newArrayList(), Lists.<String>newArrayList(), "test_subject", new EmailBody("test_body"));
        assertThat(email.ccs(), is(nullValue()));
        assertThat(email.bccs(), is(nullValue()));
    }
}
