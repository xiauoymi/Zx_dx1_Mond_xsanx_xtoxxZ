package com.monsanto.customerlink.core.email;

import com.google.common.base.Preconditions;
import com.google.common.collect.Iterables;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.Properties;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class EnvironmentAwareAddresseeFetcher_UT {

    @Test
    public void retrievesTheWinToPropertyIfTheLsiFunctionIsWin() throws Exception {
        assertThat(retrieveTheResolvedToProperty("win"), is("win@monsanto.com"));
    }

    @Test
    public void retrievesTheDevToPropertyIfTheLsiFunctionIsDev() throws Exception {
        assertThat(retrieveTheResolvedToProperty("dev"), is("dev@monsanto.com"));
    }

    @Test
    public void retrievesTheTestToPropertyIfTheLsiFunctionIsTest() throws Exception {
        assertThat(retrieveTheResolvedToProperty("test"), is("test@monsanto.com"));
    }

    @Test
    public void retrievesTheDefaultPropertyIfTheLsiFunctionIsProd() throws Exception {
        assertThat(retrieveTheResolvedToProperty("prod"), is("default@monsanto.com"));
    }

    @Test
    public void retrievesTheDefaultPropertyIfNoLsiFunctionIsSet() throws Exception {
        assertThat(retrieveTheResolvedToProperty(null), is("default@monsanto.com"));
    }

    private String retrieveTheResolvedToProperty(String environment) throws Exception {
        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.redirectErrorStream(true);
        String classPathOption = buildTheClassPathOption(getClass(), EnvironmentAwareAddresseeFetcher.class, DefaultAddresseeFetcher.class, AddresseeFetcher.class, Preconditions.class);
        processBuilder.command("java", classPathOption, environment != null ? "-Dlsi.function=" + environment : "", PrintTheFirstToAddresseeToTheOutputStream.class.getName());
        return getTheStandardOutputFromTheProcessAndWaitForItToEnd(processBuilder.start());
    }

    private String buildTheClassPathOption(Class<?>... classes) throws IOException {
        StringBuilder classPathOptionBuilder = new StringBuilder("-Djava.class.path=");
        for(Class<?> clazz : classes) {
            classPathOptionBuilder.append(new File(URLDecoder.decode(clazz.getProtectionDomain().getCodeSource().getLocation().getPath(), "UTF-8")));
            classPathOptionBuilder.append(';');
        }
        return classPathOptionBuilder.toString();
    }

    private String getTheStandardOutputFromTheProcessAndWaitForItToEnd(Process process) throws IOException, InterruptedException {
        BufferedReader inputStreamBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String previousLine = null;
        String currentLine;
        while((currentLine = inputStreamBufferedReader.readLine()) != null) {
            previousLine = currentLine;
        }
        process.waitFor();
        return previousLine;
    }

    private static class PrintTheFirstToAddresseeToTheOutputStream {

        private static Properties properties;

        static {
            properties = new Properties();
            properties.put("to", "default@monsanto.com");
            properties.put("win.to", "win@monsanto.com");
            properties.put("dev.to", "dev@monsanto.com");
            properties.put("test.to", "test@monsanto.com");
        }

        public static void main(String[] args) {
            AddresseeFetcher addresseeFetcher = new EnvironmentAwareAddresseeFetcher(properties);
            System.out.println(Iterables.getOnlyElement(addresseeFetcher.getTos()));
        }
    }
}
