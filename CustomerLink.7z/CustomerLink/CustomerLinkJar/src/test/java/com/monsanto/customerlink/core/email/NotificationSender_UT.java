package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.hamcrest.core.IsCollectionContaining;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(NotificationType.class)
public class NotificationSender_UT {

    @Mock
    private EmailSender mockEmailSender;

    @InjectMocks
    private NotificationSender theNotificationSender = new NotificationSender();

    @Test
    public void sendUsingDirectlyANotificationType() throws Exception {
        NotificationType stubNotificationType = PowerMockito.mock(NotificationType.class);
        Whitebox.setInternalState(stubNotificationType, "name", "stubNotificationType");

        when(stubNotificationType.supportsAutomaticAddresseeResolving()).thenReturn(true);

        Map<String, ?> parameters = new HashMap<String, Object>();
        Notification stubNotification = mock(Notification.class);
        when(stubNotificationType.newNotification(same(parameters))).thenReturn(stubNotification);
        Email stubEmail = mock(Email.class);
        when(stubNotification.email()).thenReturn(stubEmail);

        theNotificationSender.send(stubNotificationType, parameters);

        verify(mockEmailSender).send(same(stubEmail));
    }

    @Test
    public void sendUsingDirectlyANotificationType_throwsExceptionIfTheTypeDoesNotSupportAutomaticAddresseeResolving() throws Exception {
        NotificationType stubNotificationType = PowerMockito.mock(NotificationType.class);
        Whitebox.setInternalState(stubNotificationType, "name", "stubNotificationType");

        when(stubNotificationType.supportsAutomaticAddresseeResolving()).thenReturn(false);

        try {
            theNotificationSender.send(stubNotificationType, null);
            fail("An exception should have been thrown since the NotificationType does not support automatic addressee resolving.");
        } catch (UnsupportedOperationException e) {
            // normal flow
        }
    }

    @Test
    public void sendUsingANotification() throws Exception {
        Notification stubNotification = mock(Notification.class);
        Email stubEmail = mock(Email.class);
        when(stubNotification.email()).thenReturn(stubEmail);

        theNotificationSender.send(stubNotification);

        verify(mockEmailSender).send(same(stubEmail));
    }
}
