package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:application-context-notifications.xml")
public class NotificationSender_XT {

    @Autowired
    private NotificationSender theActualNotificationSender;

    @Test
    public void sendsANotificationUsingTheNotificationTypeOnly() throws Exception {
        theActualNotificationSender.send(NotificationType.EXAMPLE, null);
    }

    @Test
    public void sendsANotificationUsingANotificationObject() throws Exception {
        Notification notification = NotificationType.EXAMPLE.newNotification(null);
        theActualNotificationSender.send(notification.tos(Lists.newArrayList("carlos.rodarte@monsanto.com")));
    }
}
