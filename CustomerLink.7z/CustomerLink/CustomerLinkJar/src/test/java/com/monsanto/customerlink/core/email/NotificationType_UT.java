package com.monsanto.customerlink.core.email;

import org.hamcrest.beans.HasPropertyWithValue;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NotificationType_UT {

    @BeforeClass
    public static void dynamicallyAddANewTestNotificationType() {
        DynamicEnumModifier.addEnum(NotificationType.class, "TEST");
    }

    @Test
    public void theDefaultImplementationSupportsAutomaticAddresseeResolving() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        // the default implementation has an addressee fetcher by default
        assertThat(notificationType.supportsAutomaticAddresseeResolving(), is(true));
    }

    @Test
    public void automaticAddresseeResolvingIsntSupportedUnlessAnAddresseeFetcherIsSet() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        AddresseeFetcher defaultAddresseeFetcher = (AddresseeFetcher) Whitebox.getInternalState(notificationType, "addresseeFetcher");

        Whitebox.setInternalState(notificationType, "addresseeFetcher", null);

        assertThat(notificationType.supportsAutomaticAddresseeResolving(), is(true));

        Whitebox.setInternalState(notificationType, "addresseeFetcher", defaultAddresseeFetcher);
    }

    @Test
    public void newNotificationRendersTheSubjectAndTheBody() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        Notification notification = notificationType.newNotification(null);

        assertThat((String) Whitebox.getInternalState(notification, "renderedSubject"), is("rendered test subject template"));
        assertThat((String) Whitebox.getInternalState(notification, "renderedBody"), is("rendered test body template"));
    }

    private Template templateWithTextEqualTo(String templatedText) {
        return argThat(HasPropertyWithValue.<Template>hasProperty("text", equalTo(templatedText)));
    }

    @Test
    public void newNotificationSetsTheAddresseesIfThisTypeSupportsAutomaticAddresseeResolving() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        Notification notification = notificationType.newNotification(null);

        // the 'to' addressee was automatically set - the default notification type supports automatic addressee resolving
        assertThat(notification.tos().contains("carlos.rodarte@monsanto.com"), is(true));
    }

    @Test
    public void newNotificationDoesntSetTheAddresseesIfThisTypeSupportsAutomaticAddresseeResolving() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        AddresseeFetcher addresseeFetcher = (AddresseeFetcher) Whitebox.getInternalState(notificationType, "addresseeFetcher");
        Whitebox.setInternalState(notificationType, "addresseeFetcher", null);

        Notification notification = notificationType.newNotification(null);

        assertThat(notification.tos().isEmpty(), is(false));

        Whitebox.setInternalState(notificationType, "addresseeFetcher", addresseeFetcher);
    }

    @Test
    public void newNotificationSendingDistributorProfileRendersTheSubjectAndTheBody() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        Notification notification = notificationType.newNotification(null, null);

        assertThat((String) Whitebox.getInternalState(notification, "renderedSubject"), is("rendered test subject template"));
        assertThat((String) Whitebox.getInternalState(notification, "renderedBody"), is("rendered test body template"));
    }

    @Test
    public void newNotificationSendingDistributorProfileSetsTheAddresseesIfThisTypeSupportsAutomaticAddresseeResolving() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        Notification notification = notificationType.newNotification(null, null);

        // the 'to' addressee was automatically set - the default notification type supports automatic addressee resolving
        assertThat(notification.tos().contains("carlos.rodarte@monsanto.com"), is(true));
    }

    @Test
    public void newNotificationSendingDistributorProfileDoesntSetTheAddresseesIfThisTypeSupportsAutomaticAddresseeResolving() throws Exception {
        NotificationType notificationType = NotificationType.valueOf("TEST");

        TemplateRenderer mockTemplateRenderer = mock(TemplateRenderer.class);
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test subject template"), anyMap())).thenReturn("rendered test subject template");
        when(mockTemplateRenderer.render(templateWithTextEqualTo("test body template"), anyMap())).thenReturn("rendered test body template");
        Whitebox.setInternalState(notificationType, "templateRenderer", mockTemplateRenderer);

        AddresseeFetcher addresseeFetcher = (AddresseeFetcher) Whitebox.getInternalState(notificationType, "addresseeFetcher");
        Whitebox.setInternalState(notificationType, "addresseeFetcher", null);

        Notification notification = notificationType.newNotification(null, null);

        assertThat(notification.tos().isEmpty(), is(false));

        Whitebox.setInternalState(notificationType, "addresseeFetcher", addresseeFetcher);
    }

    @Test
    public void throwsAnExceptionIfTheSubjectTemplateIsNotAvailableInTheMatchingPropertiesFile() {
        try {
            DynamicEnumModifier.addEnum(NotificationType.class, "incomplete_TEST_misses_subject");
            fail("Should've thrown an exception since incomplete_TEST_misses_subject-notification.properties does not have a 'subjectTemplate' property");
        } catch (RuntimeException e) {
            assertThat(e.getCause().getCause(), is(instanceOf(IllegalArgumentException.class)));
        }
    }

    @Test
    public void throwsAnExceptionIfTheBodyTemplateIsNotAvailableInTheMatchingPropertiesFile() {
        try {
            DynamicEnumModifier.addEnum(NotificationType.class, "incomplete_TEST_misses_body");
            fail("Should've thrown an exception since incomplete_TEST_misses_body-notification.properties does not have a 'bodyTemplate' property");
        } catch (RuntimeException e) {
            assertThat(e.getCause().getCause(), is(instanceOf(IllegalArgumentException.class)));
        }
    }
}
