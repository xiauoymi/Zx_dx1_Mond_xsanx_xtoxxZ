package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

public class Notification_UT {

    @Test
    public void throwsNullPointerExceptionWhenPassedANullSubjectOnConstruction() {
        try {
            new Notification(null, "renderedBody");
            fail("A NullPointerException should have been thrown since the subject is null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void throwsIllegalArgumentExceptionWhenPassedAnEmptySubjectOnConstruction() {
        try {
            new Notification("", "renderedBody");
            fail("An IllegalArgumentException should have been thrown since the subject is empty");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void throwsNullPointerExceptionWhenPassedANullBodyOnConstruction() {
        try {
            new Notification("subject", null);
            fail("A NullPointerException should have been thrown since the body is null");
        } catch (NullPointerException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnIllegalArgumentExceptionWhenPassedAnEmptyBodyOnConstruction() {
        try {
            new Notification("subject", "");
            fail("An IllegalArgumentException should have been thrown since the body is empty");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void theEmailConstructedThroughTheEmailMethodHasTheSameFieldsAsThisNotification() {
        Notification notification = new Notification("subject", "body");
        notification.tos(Lists.newArrayList("test_to@monsanto.com"));
        notification.ccs(Lists.newArrayList("test_cc@monsanto.com"));
        notification.bccs(Lists.newArrayList("test_bcc@monsanto.com"));

        Email email = notification.email();

        assertThat(email.subject(), is(equalTo("subject")));
        assertThat(email.body(), is(equalTo(new EmailBody("body"))));
        assertThat(email.tos().contains("test_to@monsanto.com"), is(true));
        assertThat(email.ccs().contains("test_cc@monsanto.com"), is(true));
        assertThat(email.bccs().contains("test_bcc@monsanto.com"), is(true));
    }

    @Test
    public void ifTheTosMethodWasNeverUsingTheEmailMethodThrowsAnIllegalArgumentException() {
        try {
            new Notification("subject", "body").email();
            fail("An IllegalArgumentException should have been thrown since no addressees have been set prior to invoking the email() method on the Notification");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

}
