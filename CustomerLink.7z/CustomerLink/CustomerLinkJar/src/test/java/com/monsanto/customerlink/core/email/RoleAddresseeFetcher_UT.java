package com.monsanto.customerlink.core.email;

import com.google.common.collect.Lists;
import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.hamcrest.core.IsCollectionContaining;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;
import java.util.Properties;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RoleAddresseeFetcher_UT {

    @Mock
    private EmailRecoveryService emailRecoveryService;

    private RoleAddresseeFetcher roleAddresseeFetcher;

    @Before
    public void setUpTheRoleAddresseeFetcher() {
        Properties properties = new Properties();
        properties.put("role", "CSR,DIST");
        roleAddresseeFetcher = new RoleAddresseeFetcher(emailRecoveryService, properties);
    }

    @Test
    public void getTosReturnsTheTosFromRepositoryWhenRolesContainsDIST() throws Exception {
        final List<String> emails = Lists.newArrayList();
        emails.add("letorr1@monsanto.com");
        when(emailRecoveryService.retrieveEmailByRoleAndDistributorConfig(Matchers.<List<String>>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(emails);

        assertThat(roleAddresseeFetcher.getTos(new DistributorConfigDTO()), is(IsCollectionContaining.<String>hasItem("letorr1@monsanto.com")));
    }

    @Test
    public void getTosReturnsTheTosFromRepositoryWhenRolesNotContainsDIST() throws Exception {
        Properties properties = new Properties();
        properties.put("role", "CSR");
        roleAddresseeFetcher = new RoleAddresseeFetcher(emailRecoveryService, properties);

        final List<String> emails = Lists.newArrayList();
        emails.add("letorr1@monsanto.com");
        when(emailRecoveryService.retrieveEmailByRoleAndDistributorConfig(Matchers.<List<String>>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(emails);

        assertThat(roleAddresseeFetcher.getTos(new DistributorConfigDTO()), is(IsCollectionContaining.<String>hasItem("letorr1@monsanto.com")));
    }

    @Test
    public void getCcsAlwaysReturnsNull() throws Exception {
        assertThat(roleAddresseeFetcher.getCcs(), is(nullValue()));
    }

    @Test
    public void getBccsAlwaysReturnsNull() throws Exception {
        assertThat(roleAddresseeFetcher.getBccs(), is(nullValue()));
    }

    @Test
    public void throwsAnExceptionIfTheRolePropertyIsUnavailableInThePropertiesObjectPassedOnConstruction() throws Exception {
        try {
            new RoleAddresseeFetcher(emailRecoveryService, new Properties());
            fail("should have thrown an Exception since there is no 'role' property in the passed Properties object");
        } catch (IllegalArgumentException e) {
            // normal flow
        }
    }

    @Test
    public void throwsAnExceptionIfPassedANullPropertiesObjectOnConstruction() throws Exception {
        try {
            new RoleAddresseeFetcher(null, null);
            fail("should have thrown an Exception since the constructor was passed a null EmailRecoveryService object and a null Properties object");
        } catch (NullPointerException e) {
            // normal flow
        }
    }
}
