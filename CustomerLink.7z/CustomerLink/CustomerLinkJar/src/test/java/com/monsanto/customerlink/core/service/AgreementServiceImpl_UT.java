package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.impl.AgreementServiceImpl;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.agreement.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:AgreementServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class AgreementServiceImpl_UT {


    private AgreementService agreementService;

    @Autowired
    private AgreementRepository agreementRepository;
    @Autowired
    private Mapper mapper;

    private PurchaseOrderVO purchaseOrderVO;

    @Autowired
    private VolumeGoalRepository volumeGoalRepository;
    @Autowired
    private IncentivePackageRepository incentivePackageRepository;
    @Autowired
    private DistributorConfigRepository distributorConfigRepository;
    @Autowired
    private DistributorService distributorService;
    @Autowired
    private AgreementEmailRepository agreementEmailRepository;
    @Autowired
    private VolumeGoalPeriodRepository volumeGoalPeriodRepository;
    @Autowired
    private PrivateBrandDistributorRepository privateBrandDistributorRepository;
    @Autowired
    private MailUtilService mailUtilService;
    @Autowired
    private NotificationSender mailNotificationSender;
    @Autowired
    private AgreementServiceHelper agreementServiceHelper;

    AgreementDTO agreementDTO = new AgreementDTO();
    FiscalYearDTO year = new FiscalYearDTO();
    List<AgreementVO> agreementVOList = new ArrayList<AgreementVO>();
    DistributorConfigDTO disDto = new DistributorConfigDTO();
    List<IncentivePackageDTO> incentiveList = new ArrayList<IncentivePackageDTO>();
    List<VolumeGoalDTO> volumeGoalDTOList = new ArrayList<VolumeGoalDTO>();
    List<AgreementEmailDTO> agreementEmailVOList = new ArrayList<AgreementEmailDTO>();

    List<PrivateBrandDistributorVO> privateBrandDistributorVOList = new ArrayList<PrivateBrandDistributorVO>();


    @Before
    public void setup() {
        agreementService = new AgreementServiceImpl(agreementRepository, mapper,
                volumeGoalRepository, incentivePackageRepository,
                 agreementEmailRepository,
                distributorService, volumeGoalPeriodRepository, privateBrandDistributorRepository,
                mailUtilService, mailNotificationSender,agreementServiceHelper);
        purchaseOrderVO = new PurchaseOrderVO();

        agreementDTO.setFiscalYear(year);
        for (int i = 0; i < 10; i++) {


            AgreementVO vo = new AgreementVO();

            agreementVOList.add(vo);
        }


        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        FiscalYearDTO year = new FiscalYearDTO();
        year.setFiscalYear(2013l);


        agreementDTO.setFiscalYear(year);


        for (int i = 0; i < 10; i++) {
            IncentivePackageDTO inc = new IncentivePackageDTO();
            inc.setDiscountOnInvoice(BigDecimal.TEN);
            inc.setFamilyCode("family" + i);
            inc.setIncentiveVolumeGoalPeriod(BigDecimal.ONE);
            inc.setSku("sku" + i);
            inc.setTotal(BigDecimal.TEN);
            incentiveList.add(inc);
        }


        for (int i = 0; i < 10; i++) {
            VolumeGoalDTO volume = new VolumeGoalDTO();
            volume.setFamilyCode("family" + i);
            volume.setSku("sku" + i);
            volume.setTotalVolume(BigDecimal.TEN);
            volume.setUmBase("umBase" + i);

            List<VolumeGoalPeriodDTO> volumeGoalPeriodDTOList = new ArrayList<VolumeGoalPeriodDTO>();
            VolumeGoalPeriodDTO volumeGoalPeriodDTO = new VolumeGoalPeriodDTO();
            volumeGoalPeriodDTO.setQty(BigDecimal.TEN);
            PeriodDTO periodDTO = new PeriodDTO();
            periodDTO.setPeriodId(1l);

            volumeGoalPeriodDTO.setPeriod(periodDTO);
            volumeGoalPeriodDTOList.add(volumeGoalPeriodDTO);
            volume.setVolumeGoalPeriods(volumeGoalPeriodDTOList);

            volumeGoalDTOList.add(volume);

            PrivateBrandDistributorVO privateBrandDistributorVO = new PrivateBrandDistributorVO();
            ProductVO productVO = new ProductVO();
            productVO.setProductCode("sku" + i);
            privateBrandDistributorVO.setProductByProductCode(productVO);
            privateBrandDistributorVOList.add(privateBrandDistributorVO);

        }

        for (int i = 0; i < 10; i++) {
            AgreementEmailDTO dto = new AgreementEmailDTO();
            agreementEmailVOList.add(dto);
        }

        agreementDTO.setIncentivePackages(incentiveList);
        agreementDTO.setVolumeGoals(volumeGoalDTOList);
        agreementDTO.setAgreementEmails(agreementEmailVOList);

    }


    @Test//(expected = AgreementAlreadyExistsException.class)
    public void retrieveListAgreementEmptyWithGivenParametersAndIsDistributorForPrivateBrand() throws Exception {


        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(false);

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        reset(agreementRepository);
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(new AgreementVO());

        when(agreementRepository.findByParameters(Matchers.anyListOf(Long.class),Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()
                , Matchers.<String>any(), Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(new ArrayList<AgreementVO>());
        Assert.assertNotNull(agreementService.retrieveAgreementByParameters(agreementDTO, new DistributorConfigDTO()));
    }

    public void retrieveListAgreementNotEmptyWithGivenParameters() throws Exception {

        when(agreementRepository.findByParameters(Matchers.anyListOf(Long.class),Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()
                , Matchers.<String>any(), Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(agreementVOList);

        when(mapper.map(Matchers.<Object>any(), AgreementDTO.class)).thenReturn(new AgreementDTO());
        Assert.assertTrue(agreementService.retrieveAgreementByParameters(agreementDTO, new DistributorConfigDTO()).isEmpty());
    }


    @Test
    public void createAgreementForNotPrivateDistributor() throws Exception {

        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(privateBrandDistributorVOList);

        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(true);

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(null);

        when(agreementRepository.save(Matchers.<AgreementVO>any())).thenReturn(new AgreementVO());

        when(agreementRepository.findOne(Matchers.any(Long.class))).thenReturn(new AgreementVO());

        Assert.assertNotNull(agreementService.createAgreement(agreementDTO, disDto));

    }

    @Test(expected = AgreementAlreadyExistsException.class)
    public void throwsAgreementAlrweadyexistWhenOrderExistPreviously() throws Exception {

        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(true);

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        reset(agreementRepository);
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(new AgreementVO());

        agreementService.createAgreement(agreementDTO, disDto);

    }

    @Test(expected = AgreementWithoutIncentivePackageException.class)
    public void throwsAgreementWithoutIncentivePackageExceptionWhenIncentivePackagesIsNull() throws Exception {

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        reset(agreementRepository);
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(null);

        agreementDTO.setIncentivePackages(null);
        agreementDTO.setVolumeGoals(volumeGoalDTOList);
        Assert.assertNotNull(agreementService.createAgreement(agreementDTO, disDto));

    }

    @Test(expected = AgreementWithoutVolumeGoalException.class)
    public void throwsAgreementWithoutVolumeGoalExceptionWhenVolumenGoalsIsNull() throws Exception {

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        reset(agreementRepository);
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(null);

        agreementDTO.setVolumeGoals(null);
        agreementDTO.setIncentivePackages(incentiveList);
        Assert.assertNotNull(agreementService.createAgreement(agreementDTO, disDto));

    }

    @Test
    public void updateAgreementWithGivenParametersAndAndDetailsWithoutId() throws Exception {
        reset(privateBrandDistributorRepository);
        reset(distributorService);
        reset(distributorService);
        reset(agreementRepository);
        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(privateBrandDistributorVOList);
        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(true);
        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());
        when(agreementServiceHelper.obtainAgreementByParameters(Matchers.<FiscalYearVO>any(), Matchers.<DistributorProfileVO>any(), Matchers.<RepresentativeDTO>any())).thenReturn(new AgreementVO());
        when(agreementRepository.findOne(Matchers.any(Long.class))).thenReturn(new AgreementVO());

        Assert.assertNotNull(agreementService.updateAgreement(agreementDTO, disDto));
    }

    @Test(expected = AgreementNotFoundException.class)
    public void throwsAgreementNotFoundExceptionATUpdateAndAgreementNotExist() throws Exception {
        reset(privateBrandDistributorRepository);
        reset(distributorService);
        reset(distributorService);
        reset(agreementRepository);
        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(privateBrandDistributorVOList);
        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(true);
        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(null);

        Assert.assertNotNull(agreementService.updateAgreement(agreementDTO, disDto));
    }


    @Test
    public void updateAgreementWithGivenParametersAndAndDetailsWithId() throws Exception {
        when(this.agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());

        agreementDTO.setIncentivePackages(incentiveList);
        agreementDTO.setVolumeGoals(volumeGoalDTOList);
        agreementDTO.setAgreementEmails(agreementEmailVOList);

        for (IncentivePackageDTO dto : agreementDTO.getIncentivePackages()) {
            dto.setIncentivePackageId(1l);
        }
        for (VolumeGoalDTO dto : agreementDTO.getVolumeGoals()) {
            dto.setVolumeGoalId(1l);
        }

        for (AgreementEmailDTO dto : agreementDTO.getAgreementEmails()) {
            dto.setAgreementEmailId(1l);
        }

        //Assert.assertNotNull(agreementService.updateAgreement(agreementDTO));
    }


    @Test(expected = AgreementNotFoundException.class)
    public void throwsAgreementNotFoundExceptionAtDeleteAndAgreementNotExist() throws Exception {
        reset(privateBrandDistributorRepository);
        reset(distributorService);
        reset(distributorService);
        reset(agreementRepository);

        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(privateBrandDistributorVOList);

        when(distributorService.verifyIsPrivateBrandDistributor(Matchers.<String>any())).thenReturn(true);

        when(distributorService.retrieveDistributorConfigByConfig(Matchers.<DistributorConfigDTO>any())).thenReturn(new DistributorProfileVO());

        when(agreementServiceHelper.obtainAgreementByParameters(Matchers.<FiscalYearVO>any(), Matchers.<DistributorProfileVO>any(), Matchers.<RepresentativeDTO>any())).thenReturn(null);

        Assert.assertNotNull(agreementService.deleteAgreement(agreementDTO, disDto));
    }
    /*
  @Test(expected = AgreementNotFoundException.class)
  public void throwsAgreementNotFoundWhenDelete() throws Exception {
      when(this.agreementRepository.findOne(Matchers.<Long>any())).thenReturn(null);

      //agreementService.deleteAgreement(agreementDTO);
  }  */


}
