package com.monsanto.customerlink.core.service;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.service.exception.PurchaseOrderApprovedNotFoundException;
import com.monsanto.customerlink.core.service.exception.PurchaseOrderNotFoundException;
import com.monsanto.customerlink.core.service.exception.SeasonNotFoundException;
import com.monsanto.customerlink.core.service.impl.PurchaseOrderServiceImpl;
import com.monsanto.customerlink.core.service.util.DistributionChannelEnum;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.PurchaseOrderStatusEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.agreement.FiscalYearDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.*;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:PurchaseOrderServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class PurchaseOrderServiceImpl_UT {

    @Autowired
    private PurchaseOrderRepository purcharseOrderRepository;
    @Autowired
    private SeasonRepository seasonRepository;
    @Autowired
    private PurchaseOrderDetailRepository purchaseOrderDetailRepository;
    @Autowired
    private PurchaseOrderEmailRepository purchaseOrderEmailRepository;
    @Autowired
    private Mapper mapper;
    @Autowired
    private MailUtilService mailUtilService;
    @Autowired
    private NotificationSender notificationSender;
    @Autowired
    private DistributorService distributorService;
    @Autowired
    private PurchaseOrderServiceHelper purchaseOrderServiceHelper;

    PurchaseOrderService purchaseOrderService;
    PurcharseOrderDTO purcharseOrderDTO;
    List<PurchaseOrderVO> purcharseOrderVOList = new ArrayList<PurchaseOrderVO>();
    PurcharseOrderDTO createPurcharseOrder = new PurcharseOrderDTO();
    DistributorConfigDTO createDistributor = new DistributorConfigDTO();
    OrderDTO createOrderDTO = new OrderDTO();
    RepresentativeDTO representativeDTO = new RepresentativeDTO();

    @Before
    public void setup() {
        purchaseOrderService = new PurchaseOrderServiceImpl(purcharseOrderRepository, mapper, seasonRepository,
                purchaseOrderDetailRepository, purchaseOrderEmailRepository,mailUtilService, notificationSender,purchaseOrderServiceHelper, distributorService);

        purcharseOrderDTO = new PurcharseOrderDTO();


        createPurcharseOrder.setApproved(1l);
        createPurcharseOrder.setStatus(1l);
        SeasonDTO seasonDto = new SeasonDTO();
        seasonDto.setSeasonCode("1");

        createDistributor = new DistributorConfigDTO();
        createDistributor.setDistributorConfigId(1111);

        createDistributor.setSalesOrgCode("1234");
        createDistributor.setDistChCode("1234");
        createDistributor.setSalesDivCode("9800");
        createDistributor.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        createDistributor.setDistributor(distributorDTO);
        createOrderDTO.setDistributorConfigDTO(createDistributor);

        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");
        seasonDto.setSubRegionBySubRegionId(subregiondto);


        FiscalYearDTO fiscalYearByFiscalYear = new FiscalYearDTO();
        fiscalYearByFiscalYear.setFiscalYear(2013l);

        seasonDto.setFiscalYearByFiscalYear(fiscalYearByFiscalYear);
        seasonDto.setSeasonId(1l);
        //createPurcharseOrder.setSeasonBySeasonId(seasonDto);


        List<PurchaseOrderDetailDTO> detailList = new ArrayList<PurchaseOrderDetailDTO>();
        for (int i = 0; i < 2; i++) {
            PurchaseOrderDetailDTO detaildto = new PurchaseOrderDetailDTO();
            detaildto.setCrop("crop" + i);
            detaildto.setHybrid("hybrid" + i);
            detaildto.setPresentation("pres" + i);
            detaildto.setSacks(BigDecimal.TEN);
            detaildto.setUnits(BigDecimal.TEN);
            detailList.add(detaildto);
        }

        List<PurchaseOrderEmailDTO> mailList = new ArrayList<PurchaseOrderEmailDTO>();

        for (int i = 0; i < 2; i++) {
            PurchaseOrderEmailDTO mail = new PurchaseOrderEmailDTO();
            mail.setEmail("mail" + i);
            mailList.add(mail);
        }

        createPurcharseOrder.setPurchaseOrderDetailsByPurchaseOrderId(detailList);
        createPurcharseOrder.setPurchaseOrderEmailsByPurchaseOrderId(mailList);

        //purcharseOrderDTO.setSeasonBySeasonId(seasonDto);
        createPurcharseOrder.setPurchaseOrderDetailsByPurchaseOrderId(detailList);
        createPurcharseOrder.setPurchaseOrderEmailsByPurchaseOrderId(mailList);

        //createPurcharseOrder.setRepresentative(representativeDTO);
    }

    @Test
    public void retrieveListOfPurchaseOrderEmptyWithGivenParameters() throws Exception {

        when(purcharseOrderRepository.findByParameters(Matchers.<Long>any(), Matchers.<Long>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new ArrayList<PurchaseOrderVO>());


        Assert.assertNotNull(purchaseOrderService.retrievePurchaseOrder(purcharseOrderDTO));
    }


    @Test
    public void retrieveListOfPurchaseOrderNotEmptyWithGivenParameters() throws Exception {

        List<PurchaseOrderVO> purchaseOrderVOs = new ArrayList<PurchaseOrderVO>();
        List<PurchaseOrderDetailVO> purchaseOrderDetailVOs = new ArrayList<PurchaseOrderDetailVO>();
        List<PurchaseOrderEmailVO> purchaseOrderEmailVOs = new ArrayList<PurchaseOrderEmailVO>();
        reset(mapper);

        for (int i = 0; i < 10; i++) {

            PurchaseOrderVO vo = new PurchaseOrderVO();
            DistributorProfileVO profileVO = new DistributorProfileVO();
            vo.setDistributorProfileByDistributorProfileId(profileVO);

            DistributorVO distributorVO = new DistributorVO();
            profileVO.setDistributorByDistributorCode(distributorVO);

            purchaseOrderVOs.add(vo);

            PurchaseOrderDetailVO detailVO = new PurchaseOrderDetailVO();
            detailVO.setCrop("crop" + i);
            purchaseOrderDetailVOs.add(detailVO);


            DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
            distributorConfigDTO.setDistChCode( (i%2) == 0 ? DistributionChannelEnum.DIRECT_SALES.getId():DistributionChannelEnum.DEFAULT.getId());

            when(mapper.map(profileVO, DistributorConfigDTO.class)).thenReturn(distributorConfigDTO);

            DistributorDTO distributorDTO = new DistributorDTO();

            when(mapper.map(distributorVO, DistributorDTO.class)).thenReturn(distributorDTO);

            PurcharseOrderDTO dto = new PurcharseOrderDTO();

            when(mapper.map(vo, PurcharseOrderDTO.class)).thenReturn(dto);

            //when(mapper.map(Matchers.any(), Matchers.any(Class.class))).thenReturn(distributorConfigDTO);

            PurchaseOrderEmailVO emailVO = new PurchaseOrderEmailVO();
            purchaseOrderEmailVOs.add(emailVO);
        }

        when(purchaseOrderDetailRepository.findByPurchaseOrder(Matchers.<PurchaseOrderVO>any())).thenReturn(purchaseOrderDetailVOs);
        when(purchaseOrderEmailRepository.findByPurchaseOrder(Matchers.<PurchaseOrderVO>any())).thenReturn(purchaseOrderEmailVOs);


        when(purcharseOrderRepository.findByParameters(Matchers.<Long>any(), Matchers.<Long>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<Date>any())).thenReturn(purchaseOrderVOs);


        Assert.assertNotNull(purchaseOrderService.retrievePurchaseOrder(purcharseOrderDTO));
    }


    @Test
    public void createPurchaseOrderWithGivenParameters() throws Exception {

        SeasonTypeVO seasonType = new SeasonTypeVO();
        seasonType.setSeasonTypeCode("OI");
        SeasonVO season = new SeasonVO();
        season.setSeasonTypeBySeasonTypeId(seasonType);
        PurchaseOrderVO po = new PurchaseOrderVO();
        po.setSeasonBySeasonId(season);

        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);
        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(po);

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());
        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(po);

        purchaseOrderService.createPurchaseOrder(createPurcharseOrder, createDistributor);
    }

    @Test
    public void deletePurchaseOrderWithGivenParameters() throws Exception {
        reset(seasonRepository);
        reset(distributorService);
        reset(purcharseOrderRepository);

        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(new PurchaseOrderVO());
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());
        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        //when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(new PurchaseOrderVO());
        when(purcharseOrderRepository.findOne(anyLong())).thenReturn(new PurchaseOrderVO());
        purchaseOrderService.deletePurchaseOrder(purcharseOrderDTO, createDistributor);
    }

    @Test(expected = PurchaseOrderNotFoundException.class)
    public void throwsPurchaseExceptionWhenNotFoundIndelete() throws Exception {

        reset(seasonRepository);
        reset(distributorService);
        reset(purcharseOrderRepository);
        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(new PurchaseOrderVO());

        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());
        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        when(purcharseOrderRepository.findByDistributorProfileAndSeason(
                Matchers.<Long>any(), Matchers.<Long>any())).thenReturn(null);

        purchaseOrderService.deletePurchaseOrder(purcharseOrderDTO, createDistributor);
    }

    @Test
    public void updatePurchaseOrderWithGivenParameters() throws Exception {
        reset(seasonRepository);
        reset(distributorService);
        reset(purcharseOrderRepository);

        SeasonTypeVO seasonType = new SeasonTypeVO();
        seasonType.setSeasonTypeCode("OI");
        SeasonVO season = new SeasonVO();
        season.setSeasonTypeBySeasonTypeId(seasonType);
        PurchaseOrderVO po = new PurchaseOrderVO();
        po.setSeasonBySeasonId(season);

        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(po);

        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);
        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        //when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(po);
        when(purcharseOrderRepository.findOne(anyLong())).thenReturn(po);

        purchaseOrderService.updatePurchaseOrder(createPurcharseOrder, createDistributor);

        //
        //Assert.assertNotNull(purchaseOrderService.updatePurchaseOrder( new PurcharseOrderDTO()));
    }

    @Test(expected = PurchaseOrderNotFoundException.class)
    public void throwsPurchaseOrderNotFoundAtUpdate() throws Exception {
        when(purcharseOrderRepository.findOne(anyLong())).thenReturn(null);

        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());
        when(purcharseOrderRepository.save(Matchers.<PurchaseOrderVO>any())).thenReturn(new PurchaseOrderVO());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        Assert.assertNotNull(purchaseOrderService.updatePurchaseOrder(purcharseOrderDTO, createDistributor));
    }

    @Test(expected = PurchaseOrderApprovedNotFoundException.class)
    public void throwsPurchaseOrderApprovedNotFoundExceptionWhenAllIsOkForDistributorAndSeasonButStatusIsDeleted()
            throws Exception {
        reset(purcharseOrderRepository);
        reset(seasonRepository);
        reset(distributorService);
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());
        PurchaseOrderVO vo = new PurchaseOrderVO();
        vo.setApproved(PurchaseOrderStatusEnum.APPROVAL_APPROVED.getStatus());

        vo.setStatus(PurchaseOrderStatusEnum.STATUS_DELETED.getStatus());
       // when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(vo);

        purchaseOrderService.validateExistPurchaseOrderApproved(createOrderDTO);
    }

    @Test(expected = PurchaseOrderApprovedNotFoundException.class)
    public void throwsPurchaseOrderApprovedNotFoundExceptionWhenAllIsOkForDistributorAndSeasonButApprovedIsPending()
            throws Exception {
        reset(purcharseOrderRepository);
        reset(seasonRepository);
        reset(distributorService);
        when(seasonRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new SeasonVO());
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());
        PurchaseOrderVO vo = new PurchaseOrderVO();
        vo.setApproved(PurchaseOrderStatusEnum.APPROVAL_PENDING.getStatus());
        vo.setStatus(PurchaseOrderStatusEnum.STATUS_ACTIVE.getStatus());
        //when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(vo);

        purchaseOrderService.validateExistPurchaseOrderApproved(createOrderDTO);
    }

    @Test(expected = PurchaseOrderApprovedNotFoundException.class)
    public void throwsDistributornotFoundExceptionWhenNotExistInRepository() throws Exception {
        reset(purcharseOrderRepository);
        reset(seasonRepository);
        reset(distributorService);
        when(seasonRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new SeasonVO());
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());
        when(mapper.map(Matchers.<OrderDTO>any(), Matchers.<Class>any())).thenReturn(new PurcharseOrderDTO());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());
        PurchaseOrderVO vo = new PurchaseOrderVO();
        when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(null);


        purchaseOrderService.validateExistPurchaseOrderApproved(createOrderDTO);
    }

    @Test(expected = SeasonNotFoundException.class)
    public void throwsSeasonNotFoundExceptionWhenNotExistInRepository() throws Exception {
        reset(purcharseOrderRepository);
        reset(seasonRepository);
        reset(distributorService);
        when(seasonRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any())).thenReturn(null);
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(null);

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        purchaseOrderService.validateExistPurchaseOrderApproved(createOrderDTO);

    }

    @Test(expected = PurchaseOrderApprovedNotFoundException.class)
    public void purchaseOrderIsFoundedWhenExistInRepositoryAndItsStatusIsNotDeletedAndHasBeenApprroved() throws Exception {
        reset(purcharseOrderRepository);
        reset(seasonRepository);
        reset(distributorService);
        when(seasonRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new SeasonVO());
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());
        PurchaseOrderVO vo = new PurchaseOrderVO();
        vo.setApproved(PurchaseOrderStatusEnum.APPROVAL_APPROVED.getStatus());

        vo.setStatus(PurchaseOrderStatusEnum.STATUS_ACTIVE.getStatus());
        //when(purchaseOrderServiceHelper.obtainPurchaseOrderByParameters(Matchers.<SeasonVO>any(),Matchers.<DistributorProfileVO>any(),Matchers.<RepresentativeDTO>any())).thenReturn(vo);

        purchaseOrderService.validateExistPurchaseOrderApproved(createOrderDTO);
    }

}
