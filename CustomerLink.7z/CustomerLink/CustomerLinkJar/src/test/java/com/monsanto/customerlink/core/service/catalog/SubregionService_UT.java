package com.monsanto.customerlink.core.service.catalog;

import com.monsanto.customerlink.core.service.catalog.impl.SubregionServiceImpl;
import com.monsanto.customerlink.persistence.entities.SubRegionVO;
import com.monsanto.customerlink.persistence.repositories.SubRegionRepository;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SubregionService_UT {

    @Mock
    private SubRegionRepository subRegionRepository;
    @Mock
    private org.dozer.Mapper mapper;

    private SubregionService subregionService;

    List<SubRegionVO> subRegionVOList = new ArrayList<SubRegionVO>();

    @Before
    public void setup() {
        subregionService = new SubregionServiceImpl(subRegionRepository, mapper);

        for (int i = 0; i < 10; i++) {
            SubRegionVO subRegionVO = new SubRegionVO();
            subRegionVOList.add(subRegionVO);
        }
    }

    @Test
    public void findAllSubregionsNotEmptyList() {

        reset(subRegionRepository);
        reset(mapper);
        when(subRegionRepository.findAll()).thenReturn(subRegionVOList);
        when(mapper.map(Matchers.<Object>any(), Matchers.<Class>any())).thenReturn(new SubRegionDTO());

        Assert.assertNotNull(subregionService.findAllSubregions());
    }

    @Test
    public void findAllSubregionsEmptyList() {

        reset(subRegionRepository);
        reset(mapper);
        when(subRegionRepository.findAll()).thenReturn(new ArrayList<SubRegionVO>());
        when(mapper.map(Matchers.<Object>any(), Matchers.<Class>any())).thenReturn(new SubRegionDTO());

        Assert.assertEquals(subregionService.findAllSubregions().size(), 0);
    }
}
