package com.monsanto.customerlink.core.service.dto;

import com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class SpecialOrderDTO_UT {

    @Test
    public void twoSpecialOrdersAreEqualIfAllTheirPropertiesAreEqual() throws Exception {
        SpecialOrderDTO one = new SpecialOrderDTO();
        SpecialOrderHybridDTO firstHybridForOne = new SpecialOrderHybridDTO();
        firstHybridForOne.setHybrid("test_hybrid");
        firstHybridForOne.setQuantity(1d);
        firstHybridForOne.setUmb("test_umb");
        SpecialOrderHybridDTO secondHybridForOne = new SpecialOrderHybridDTO();
        secondHybridForOne.setHybrid("test_hybrid_2");
        secondHybridForOne.setQuantity(2d);
        secondHybridForOne.setUmb("test_umb_2");
        one.setHybrids(Lists.newArrayList(firstHybridForOne, secondHybridForOne));

        SpecialOrderDTO two = new SpecialOrderDTO();
        SpecialOrderHybridDTO firstHybridForTwo = new SpecialOrderHybridDTO();
        firstHybridForTwo.setHybrid("test_hybrid");
        firstHybridForTwo.setQuantity(1d);
        firstHybridForTwo.setUmb("test_umb");
        SpecialOrderHybridDTO secondHybridForTwo = new SpecialOrderHybridDTO();
        secondHybridForTwo.setHybrid("test_hybrid_2");
        secondHybridForTwo.setQuantity(2d);
        secondHybridForTwo.setUmb("test_umb_2");
        two.setHybrids(Lists.newArrayList(firstHybridForTwo, secondHybridForTwo));

        assertThat(one.equals(two), is(true));
        assertThat(one.hashCode(), is(two.hashCode()));
    }
}
