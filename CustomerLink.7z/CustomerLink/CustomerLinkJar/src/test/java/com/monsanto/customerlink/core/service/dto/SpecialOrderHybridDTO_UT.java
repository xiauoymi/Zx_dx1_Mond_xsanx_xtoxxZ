package com.monsanto.customerlink.core.service.dto;

import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class SpecialOrderHybridDTO_UT {

    @Test
    public void twoHybridsAreEqualIfAllTheirPropertiesAreEqual() throws Exception {
        SpecialOrderHybridDTO one = buildAHybrid("test_hybrid", 1d, "test_umb");
        SpecialOrderHybridDTO two = buildAHybrid("test_hybrid", 1d, "test_umb");

        assertThat(one.equals(two), is(true));
        assertThat(one.hashCode(), is(two.hashCode()));
    }

    private SpecialOrderHybridDTO buildAHybrid(String hybrid, double quantity, String umb) {
        SpecialOrderHybridDTO hybridDto = new SpecialOrderHybridDTO();
        hybridDto.setHybrid(hybrid);
        hybridDto.setQuantity(quantity);
        hybridDto.setUmb(umb);
        return hybridDto;
    }
}
