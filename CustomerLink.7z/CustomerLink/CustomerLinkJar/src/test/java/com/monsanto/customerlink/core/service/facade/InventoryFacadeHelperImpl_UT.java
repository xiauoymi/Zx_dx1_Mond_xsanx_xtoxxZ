package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.facade.impl.InventoryFacadeHelperImpl;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:InventoryFacadeHelper_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class InventoryFacadeHelperImpl_UT {

    @Autowired
    private InventoryFacadeHelper unit ;

    @Test
    public void execute() throws Exception {

        JAXWSClientFactory jaxwsClientFactory = Mockito.mock(JAXWSClientFactory.class);
        YESSDSASENDINVENTORY yessdsasendinventory = Mockito.mock(YESSDSASENDINVENTORY.class);

        InventoryFacadeHelperImpl aSpy = (InventoryFacadeHelperImpl) Mockito.spy(unit);
        Mockito.doReturn(jaxwsClientFactory).when(aSpy).getJAXWSClientFactory();

        when(jaxwsClientFactory.getSendInventoryPortType()).thenReturn(yessdsasendinventory);

        YSdsaSendInventory inSendInventory = new YSdsaSendInventory();
        inSendInventory.setInhybrids(new YttSdsaInhybrids());
        inSendInventory.setSdorg(new YttSdsaSdorgSpec());
        inSendInventory.setSpecies(new YttSdsaSpeciesAlg());

        Object[] outSendInventory = aSpy.execute(inSendInventory);

        assertTrue(outSendInventory.length == 4 );
    }

    @Test
    public void obtainErrors() throws Exception {

        List<YsdsaErrref> errorList = new ArrayList<YsdsaErrref>();

        int i = 0;
        while(i<10) {
            YsdsaErrref ysdsaErrref = new YsdsaErrref();
            ysdsaErrref.setYyerrcode("ERROR_CODE"+i);
            ysdsaErrref.setYyerrdate("DATE"+i);
            ysdsaErrref.setYyerrdesc("DESC"+i);
            ysdsaErrref.setYyhybrid("HYBRID"+i);
            ysdsaErrref.setYymaterial("MATERIAL"+i);
            errorList.add(ysdsaErrref);
            i++;
        }

        List<ErrorOrderDTO> processedErrors =  unit.obtainError(errorList);
        assertTrue(!processedErrors.isEmpty());
    }

}
