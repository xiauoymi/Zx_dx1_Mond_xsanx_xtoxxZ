package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.facade.dto.InventoryInDTO;
import com.monsanto.customerlink.core.service.facade.dto.PlantWareHouseDTO;
import com.monsanto.customerlink.core.service.facade.dto.SpecieDTO;
import com.monsanto.customerlink.core.service.facade.impl.InventoryFacadeImpl;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.SeedsSapAlgorithm;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:InventoryFacadeImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class InventoryFacadeImpl_UT {

    @Autowired
    Mapper mapper;

    @Autowired
    private InventoryFacadeImpl inventoryFacade;

    @Autowired
    private InventoryFacadeHelper inventoryFacadeHelper;

    @Test
    public void inputParameterIsNull() throws Exception {
        inventoryFacade.getInventory(null);
    }

    @Test
    public void inputParameterIsEmpty() throws Exception {
        inventoryFacade.getInventory(Arrays.asList(new InventoryInDTO[]{}));
    }

    @Test
    public void catch_exception_getInventory_WhenOccursUnExpectedException() throws Exception {
        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        Mockito.doThrow(Exception.class).when(aSpy).getOutSendInventory(Matchers.<Object[]>anyObject());
        Object[] outSendInventory = new Object[]{null, null, null, null};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        Map<String, List<?>> out = aSpy.getInventory(inventoryListInput);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventoryList_When_SapSendInventoryReturnValues_CottonOrSoybean_When_outSendInventoryIsNull() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        //////////////////////////////////////////////////////////////////////////////

        InventoryInDTO inv2 = new InventoryInDTO();

        inv2.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv2.setSalesorganization("MX20"); // cotton or soybean
        inv2.setSalesdistrict("MXBAJ");
        inv2.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO2 = new SpecieDTO();
        specieDTO2.setSpeciecode("B");
        specieDTO2.setSpecieclass("SG_SOYBEAM");
        specieDTO2.setClasstype("001");
        specieDTO2.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv2.setSpecieDTO(specieDTO2);

        List<PlantWareHouseDTO> plantWarehouses2 = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw12 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw22 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses2.add(pw12);
        plantWarehouses2.add(pw22);
        inv2.setPlantWarehouses(plantWarehouses2);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);
        inventoryListInput.add(inv2);

        Object[] outSendInventory = null;

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_When_SapSendInventoryReturnValues_CottonOrSoybean_When_yttSdsaOuthybinv_IsNull() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        YttSdsaOuthybinv yttSdsaOuthybinv = null;

         List<YsdsaErrref> ysdsaErrrefList = new ArrayList<YsdsaErrref>();
        for (int i = 0; i < 5; i++) {
            YsdsaErrref ysdsaErrref = new YsdsaErrref();
            ysdsaErrref.setYyerrcode("CODE"+i);
            ysdsaErrref.setYyerrdesc("DESC"+i);
            ysdsaErrref.setYyerrdate("DATE"+i);
            ysdsaErrref.setYyhybrid("HYBRID"+i);
            ysdsaErrref.setYymaterial("MATERIAL"+i);
            ysdsaErrrefList.add(ysdsaErrref);
        }

        YttSdsaErrref errors = new YttSdsaErrref();
        errors.setItem(ysdsaErrrefList);


        Object[] outSendInventory = new Object[]{errors, null, yttSdsaOuthybinv, null};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_When_SapSendInventoryReturnValues_CottonOrSoybean_When_yttSdsaOuthybrids_IsNull() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

         YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_2");
        m2.setYyplant("PLANT_2");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);

        YttSdsaOuthybrids yttSdsaOuthybrids = null;
        YttSdsaErrref errors = new YttSdsaErrref();

        Object[] outSendInventory = new Object[]{errors, null, yttSdsaOuthybinv, yttSdsaOuthybrids};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }


    @Test
    public void getInventoryList_When_SapSendInventoryReturnValues_CottonOrSoybean() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_2");
        m2.setYyplant("PLANT_2");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);
        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_When_SapSendInventoryReturnNullValues_CottonOrSoybean() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX20"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_2");
        m2.setYyplant("PLANT_2");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        YttSdsaErrref errors = new YttSdsaErrref();

        Object[] outSendInventory = new Object[]{errors, null, new YttSdsaOuthybinv(), yttSdsaOuthybrids};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }


    @Test
    public void getInventoryList_When_SapSendInventoryReturnValues_CornOrSorghum() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX10"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        YsdsaOuthybalg outHh1 = new YsdsaOuthybalg();
        outHh1.setYyhybrid("CANGURO");
        outHh1.setYyplant("PLANTA_3");
        outHh1.setYyunrestqty(BigDecimal.valueOf(123.33D));
        outHh1.setYybaseuom("baseUOM");
        outHh1.setYyaltuom("SSU");
        outHh1.setYydenom(BigDecimal.valueOf(0.5D));
        outHh1.setYynumerator(BigDecimal.valueOf(0.5D));

        YsdsaOuthybalg outHh2 = new YsdsaOuthybalg();
        outHh2.setYyhybrid("GORILA");
        outHh2.setYyplant("PLANTA_4");
        outHh2.setYyunrestqty(BigDecimal.valueOf(775.15));
        outHh2.setYybaseuom("baseUOM");
        outHh2.setYyaltuom("SSU");
        outHh2.setYydenom(BigDecimal.valueOf(0.5D));
        outHh2.setYynumerator(BigDecimal.valueOf(0.5D));

        List<YsdsaOuthybalg> ysdsaOuthybalgs = Arrays.asList(new YsdsaOuthybalg[]{outHh1, outHh2});
        YttSdsaOuthybalg yttSdsaOuthybalg = new YttSdsaOuthybalg();
        yttSdsaOuthybalg.setItem(ysdsaOuthybalgs);
        Object[] outSendInventory = new Object[]{null, yttSdsaOuthybalg, null, null};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_WhenReturnValues_From_SapSendInventoryService_AreNull_CornOrSorghum() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX10"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);
        Object[] outSendInventory = new Object[]{null, null, null, null};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_WhenReturnValues_From_SapSendInventoryService_AreNotNullAndListIsNull_CornOrSorghum() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX10"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        Object[] outSendInventory = new Object[]{null, new YttSdsaOuthybalg(), null, null};
        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

    @Test
    public void getInventoryList_WhenReturnValues_From_SapSendInventoryService_AreNotNullAndListEmpty_CornOrSorghum() throws Exception {

        InventoryInDTO inv = new InventoryInDTO();

        inv.setHybrid("CANGURO");
        inv.setAcronym("CANGURO");
        inv.setSpTreatment("0");
        inv.setSalesorganization("MX10"); // cotton or soybean
        inv.setSalesdistrict("MXBAJ");
        inv.setAltuom(CustomerLinkCoreConstants.ALTUOM);

        SpecieDTO specieDTO = new SpecieDTO();
        specieDTO.setSpeciecode("B");
        specieDTO.setSpecieclass("SG_SOYBEAM");
        specieDTO.setClasstype("001");
        specieDTO.setAlg(SeedsSapAlgorithm.WITHOUT.getCode());
        inv.setSpecieDTO(specieDTO);

        List<PlantWareHouseDTO> plantWarehouses = new ArrayList<PlantWareHouseDTO>();
        PlantWareHouseDTO pw1 = new PlantWareHouseDTO("5528", "CWM1");
        PlantWareHouseDTO pw2 = new PlantWareHouseDTO("6265", "A001");
        plantWarehouses.add(pw1);
        plantWarehouses.add(pw2);
        inv.setPlantWarehouses(plantWarehouses);

        List<InventoryInDTO> inventoryListInput = new ArrayList<InventoryInDTO>();
        inventoryListInput.add(inv);

        YttSdsaOuthybalg yttSdsaOuthybalg = new YttSdsaOuthybalg();
        yttSdsaOuthybalg.setItem(new ArrayList<YsdsaOuthybalg>());

        Object[] outSendInventory = new Object[]{null, yttSdsaOuthybalg, null, null};

        InventoryFacadeImpl aSpy = Mockito.spy(inventoryFacade);
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = aSpy.getInventory(inventoryListInput);
    }

}