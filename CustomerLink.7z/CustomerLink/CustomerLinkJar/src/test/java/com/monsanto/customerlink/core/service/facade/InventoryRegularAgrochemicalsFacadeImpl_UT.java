package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.impl.InventoryRegularAgrochemicalsFacadeImpl;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:InventoryRegularAgrochemicalsFacadeImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class InventoryRegularAgrochemicalsFacadeImpl_UT {

    @Autowired
    private InventoryFacadeHelper inventoryFacadeHelper;

    @Autowired
    private InventoryRegularAgrochemicalsFacade unit;

    @Test
    public void getInventory_WhenInputListIsNull() throws Exception {
        Map<String, List<?>> out = unit.getInventory(null);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_WhenInputListIsEmpty() throws Exception {
        Map<String, List<?>> out = unit.getInventory(new ArrayList<MaterialDTO>());
        assertTrue(out.isEmpty());
    }

    @Test
    public void catch_exception_getInventory_WhenOccursUnExpectedException() throws Exception {
        InventoryRegularAgrochemicalsFacade aSpy = Mockito.spy(unit);
        Mockito.doThrow(Exception.class).when((InventoryRegularAgrochemicalsFacadeImpl)aSpy).getOutSendInventory(Matchers.<Object[]>anyObject());
        Object[] outSendInventory = new Object[]{null, null, null, null};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = aSpy.getInventory(materialsInputList);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_When_outSendInventory_IsNull() throws Exception {
        Object[] outSendInventory = null;
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = unit.getInventory(materialsInputList);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_When_outSendInventory_IsNotNull_And_outhybrids_isNull() throws Exception {
        YttSdsaOuthybrids yttSdsaOuthybrids = null;
        Object[] outSendInventory = new Object[]{null, null, null, yttSdsaOuthybrids};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = unit.getInventory(materialsInputList);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_When_outSendInventory_IsNotNull_And_yttSdsaOuthybinv_isNull() throws Exception {

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        YsdsaOuthybrids outH3 = new YsdsaOuthybrids();
        outH3.setYyhybrid("CANGURO");
        outH3.setYymaterial("MATERIAL_1");
        outH3.setYybaseuom("baseUOM");
        outH3.setYydenom(BigDecimal.valueOf(0.5D));
        outH3.setYynumerator(BigDecimal.valueOf(0.5D));
        outH3.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2, outH3});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YttSdsaOuthybinv yttSdsaOuthybinv = null;
        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};

        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = unit.getInventory(materialsInputList);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_When_outSendInventory_IsNotNull_And_yttSdsaOuthybinv_isEmpty_AndErrorsIsEmpty() throws Exception {

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YttSdsaErrref errors = new YttSdsaErrref();

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        Object[] outSendInventory = new Object[]{errors, null, yttSdsaOuthybinv, yttSdsaOuthybrids};

        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = unit.getInventory(materialsInputList);
        assertTrue(out.isEmpty());
    }

    @Test
    public void getInventory_When_outSendInventory_IsNotNull_And_yttSdsaOuthybinv_isEmpty_AndErrorsIsNotEmpty() throws Exception {

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        List<YsdsaErrref> ysdsaErrrefList = new ArrayList<YsdsaErrref>();
        for (int i = 0; i < 5; i++) {
            YsdsaErrref ysdsaErrref = new YsdsaErrref();
            ysdsaErrref.setYyerrcode("CODE"+i);
            ysdsaErrref.setYyerrdesc("DESC"+i);
            ysdsaErrref.setYyerrdate("DATE"+i);
            ysdsaErrref.setYyhybrid("HYBRID"+i);
            ysdsaErrref.setYymaterial("MATERIAL"+i);
            ysdsaErrrefList.add(ysdsaErrref);
        }

        YttSdsaErrref errors = new YttSdsaErrref();
        errors.setItem(ysdsaErrrefList);

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        Object[] outSendInventory = new Object[]{errors, null, yttSdsaOuthybinv, yttSdsaOuthybrids};

        List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        for (int i = 0; i < 5; i++) {
            errorOrderDTOList.add(new ErrorOrderDTO());
            ErrorOrderDTO error = new ErrorOrderDTO();
            error.setErrorOrderId(i);
            error.setObjectWithError("ERROR"+i);
            error.setErrorTypes(new ErrorTypeDTO());
            errorOrderDTOList.add(error);
        }

        when(inventoryFacadeHelper.obtainError(Matchers.<List<YsdsaErrref>>any())).thenReturn(errorOrderDTOList);

        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());
        Map<String, List<?>> out = unit.getInventory(materialsInputList);
        assertTrue(!out.isEmpty());
    }

    @Test
    public void getInventory_WhenExistDifferentMaterials() throws Exception {

        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        YsdsaOuthybrids outH2 = new YsdsaOuthybrids();
        outH2.setYyhybrid("CANGURO");
        outH2.setYymaterial("MATERIAL_2");
        outH2.setYybaseuom("baseUOM");
        outH2.setYydenom(BigDecimal.valueOf(0.5D));
        outH2.setYynumerator(BigDecimal.valueOf(0.5D));
        outH2.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1, outH2});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_2");
        m2.setYyplant("PLANT_2");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);

        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = unit.getInventory(materialsInputList);

        assertTrue(!map.isEmpty());
    }

    @Test
    public void getInventory_SameMaterialDifferentPlant() throws Exception {

        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_1");
        m2.setYyplant("PLANT_2");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);

        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);

        Map<String, List<?>> map = unit.getInventory(materialsInputList);

        assertTrue(!map.isEmpty());
    }

    @Test
    public void getInventory_SameMaterialSamePlantDifferentWarehouse() throws Exception {

        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_1");
        m2.setYyplant("PLANT_1");
        m2.setYystLocation("STORAGE_LOCATION_2");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);

        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        Map<String, List<?>> map = unit.getInventory(materialsInputList);

        assertTrue(!map.isEmpty());
    }

    @Test
    public void getInventory_SameMaterialSamePlanSameWarehouseDifferentBatch() throws Exception {

        List<MaterialDTO> materialsInputList = new ArrayList<MaterialDTO>();
        materialsInputList.add(new MaterialDTO());

        YsdsaOuthybrids outH1 = new YsdsaOuthybrids();
        outH1.setYyhybrid("CANGURO");
        outH1.setYymaterial("MATERIAL_1");
        outH1.setYybaseuom("baseUOM");
        outH1.setYydenom(BigDecimal.valueOf(0.5D));
        outH1.setYynumerator(BigDecimal.valueOf(0.5D));
        outH1.setYyaltuom("SSU");

        List<YsdsaOuthybrids> outHybridList = Arrays.asList(new YsdsaOuthybrids[]{outH1});

        YttSdsaOuthybrids yttSdsaOuthybrids = new YttSdsaOuthybrids();
        yttSdsaOuthybrids.setItem(outHybridList);

        YsdsaOuthybinv m1 = new YsdsaOuthybinv();
        m1.setYymaterial("MATERIAL_1");
        m1.setYyplant("PLANT_1");
        m1.setYystLocation("STORAGE_LOCATION_1");
        m1.setYybatch("BATCH_1");
        m1.setYyunrestqty(BigDecimal.valueOf(1500D));

        YsdsaOuthybinv m2 = new YsdsaOuthybinv();
        m2.setYymaterial("MATERIAL_1");
        m2.setYyplant("PLANT_1");
        m2.setYystLocation("STORAGE_LOCATION_1");
        m2.setYybatch("BATCH_2");
        m2.setYyunrestqty(BigDecimal.valueOf(325D));

        List<YsdsaOuthybinv> outHybInvList = Arrays.asList(new YsdsaOuthybinv[]{m1, m2});

        YttSdsaOuthybinv yttSdsaOuthybinv = new YttSdsaOuthybinv();
        yttSdsaOuthybinv.setItem(outHybInvList);

        Object[] outSendInventory = new Object[]{null, null, yttSdsaOuthybinv, yttSdsaOuthybrids};
        when(inventoryFacadeHelper.execute(any(YSdsaSendInventory.class))).thenReturn(outSendInventory);
        Map<String, List<?>> map = unit.getInventory(materialsInputList);

        assertTrue(!map.isEmpty());
    }

}
