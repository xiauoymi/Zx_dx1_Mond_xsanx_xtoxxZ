package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.impl.SAPOrderFacadeImpl;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.service.util.SeedsSalesOrganizationEnum;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.core.service.util.TransactionTypeOrder;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.hamcrest.MatcherAssert.assertThat;

@ContextConfiguration(locations = {"classpath:SAPOrderFacadeImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class SAPOrderFacadeImpl_UT {

    @Autowired
    private SAPOrderFacadeImpl sapOrderFacade;

    @Test
    public void retrievesSAPOrderDTOWhenSAPOrderIsCreated() throws Exception {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

        final SAPOrderFacadeImpl aSpy = Mockito.spy(sapOrderFacade);
        Mockito.doReturn(sapOrderDTO).when((SAPOrderFacadeImpl) aSpy).createSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any());

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);

        final SAPOrderDTO sapOrderDTO1 = aSpy.createSAPOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO1, is(sameInstance(sapOrderDTO)));
    }

    @Test
    public void retrievesSAPOrderDTOWhenSAPOrderIsUpdated() throws Exception {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

        final SAPOrderFacadeImpl aSpy = Mockito.spy(sapOrderFacade);
        Mockito.doReturn(sapOrderDTO).when((SAPOrderFacadeImpl) aSpy).updateSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any());

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final MaterialSkuDTO materialSkuDTOI = new MaterialSkuDTO();
        materialSkuDTOI.setItemNumber(30);
        materialSkuDTOI.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTOI.setMaterial("COTTON 1");
        materialSkuDTOI.setPlant("5528");
        materialSkuDTOI.setStoragelocation("CWM1");
        materialSkuDTOI.setBatch("45");
        materialSkuDTOI.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOU = new MaterialSkuDTO();
        materialSkuDTOU.setItemNumber(10);
        materialSkuDTOU.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());
        materialSkuDTOU.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOD = new MaterialSkuDTO();
        materialSkuDTOD.setItemNumber(20);
        materialSkuDTOD.setTransactionType(TransactionTypeMaterial.DELETE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTOI);
        productDTO.getListOfSku().add(materialSkuDTOU);
        productDTO.getListOfSku().add(materialSkuDTOD);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");
        orderDTO.setTransactionType(TransactionTypeOrder.UPDATE.getCode());

        final SAPOrderDTO sapOrderDTO1 = aSpy.updateSAPOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO1, is(sameInstance(sapOrderDTO)));
    }

    @Test
    public void retrievesSAPOrderList() throws Exception {
        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();

        final SAPOrderFacadeImpl aSpy = Mockito.spy(sapOrderFacade);
        Mockito.doReturn(sapOrderDTOList).when((SAPOrderFacadeImpl) aSpy).retrieveOrders(Matchers.<OrderDTO>any());

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);

        final List<SAPOrderDTO> sapOrderDTOList1 = aSpy.retrieveOrders(orderDTO);
        assertThat(sapOrderDTOList1, is(sameInstance(sapOrderDTOList)));
    }
}
