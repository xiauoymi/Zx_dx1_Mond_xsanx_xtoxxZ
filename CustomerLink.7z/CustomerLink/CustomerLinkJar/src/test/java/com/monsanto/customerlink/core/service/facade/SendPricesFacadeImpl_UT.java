package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.PriceGroupNotFoundForOrderException;
import com.monsanto.customerlink.core.service.facade.impl.SendPricesFacadeImpl;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesClient;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesRequestBuilder;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondin;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SendPricesFacadeImpl_UT {

    @Mock
    private PriceGroupService priceGroupService;
    @Mock
    JAXWSClientFactory jaxwsClientFactory;
    @Mock
    YESSDSASENDCONDITIONS yessdsasendconditions;


    SendPricesFacade sendPricesFacade;

    @Before
    public void setup() {
        sendPricesFacade = new SendPricesFacadeImpl(priceGroupService);
    }

    @Test
    public void testorderIsCompletedWithPriceGroupAndthenIsSendedToConsultPrices() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDTO.getDetail().add(orderDetailDTO);

        reset(jaxwsClientFactory);
        reset(priceGroupService);

        //Mockito.verify(priceGroupService).findPriceGroupForOrder(Matchers.<DistributorConfigDTO>any(), Matchers.<String>any(), Matchers.<String>any());

        when(jaxwsClientFactory.getSendPricesServicePortType()).thenReturn(yessdsasendconditions);
        SendPricesFacadeImpl aSpy = (SendPricesFacadeImpl) Mockito.spy(sendPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when(aSpy).getJAXWSClientFactory();
        aSpy.obtainCurrencies(orderDTO);
    }

    @Test
    public void testorderIsCompleteAndIsSendedToConsultPrices() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setPriceGroup(new PriceGroupDTO());

        reset(jaxwsClientFactory);
        reset(priceGroupService);

        //Mockito.verify(priceGroupService).findPriceGroupForOrder(Matchers.<DistributorConfigDTO>any(), Matchers.<String>any(), Matchers.<String>any());

        when(jaxwsClientFactory.getSendPricesServicePortType()).thenReturn(yessdsasendconditions);
        SendPricesFacadeImpl aSpy = (SendPricesFacadeImpl) Mockito.spy(sendPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when(aSpy).getJAXWSClientFactory();
        aSpy.obtainCurrencies(orderDTO);
    }


    @Test(expected = PriceGroupNotFoundForOrderException.class)
    public void testorderIsCompletedWithPriceGroupAndthenIsSendedToConsultPricesErrorIsthrows() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDTO.getDetail().add(orderDetailDTO);
        reset(jaxwsClientFactory);
        reset(priceGroupService);
        when(priceGroupService.findPriceGroupForOrder(Matchers.<DistributorConfigDTO>any(), Matchers.<String>any(), Matchers.<String>any())).thenThrow(new PriceGroupNotFoundForOrderException(new Object[]{}));

        when(jaxwsClientFactory.getSendPricesServicePortType()).thenReturn(yessdsasendconditions);
        SendPricesFacadeImpl aSpy = (SendPricesFacadeImpl) Mockito.spy(sendPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when(aSpy).getJAXWSClientFactory();
        aSpy.obtainCurrencies(orderDTO);
    }


    @Test(expected = ActiveSeasonNotFoundException.class)
    public void testorderIsCompletedWithPriceGroupAndthenIsSendedToConsultPricesErrorIsthrowsActiveSeasonException() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDTO.getDetail().add(orderDetailDTO);
        reset(jaxwsClientFactory);
        reset(priceGroupService);
        when(priceGroupService.findPriceGroupForOrder(Matchers.<DistributorConfigDTO>any(), Matchers.<String>any(), Matchers.<String>any())).thenThrow(new ActiveSeasonNotFoundException(new Object[]{}));
        when(jaxwsClientFactory.getSendPricesServicePortType()).thenReturn(yessdsasendconditions);
        SendPricesFacadeImpl aSpy = (SendPricesFacadeImpl) Mockito.spy(sendPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when(aSpy).getJAXWSClientFactory();
        aSpy.obtainCurrencies(orderDTO);

    }

}
