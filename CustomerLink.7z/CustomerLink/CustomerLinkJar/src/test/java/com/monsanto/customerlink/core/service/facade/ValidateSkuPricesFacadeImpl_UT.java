package com.monsanto.customerlink.core.service.facade;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.OrderErrorService;
import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.facade.impl.ValidateSkuPricesFacadeImpl;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ValidateSkuPricesFacadeImpl_UT {

    @Mock
    private CropRepository cropRepository;
    @Mock
    private OrderErrorService orderErrorService;

    ValidateSkuPricesFacadeImpl validateSkuPricesFacade;
    @Mock
    JAXWSClientFactory jaxwsClientFactory;
    @Mock
    YESSDSAVALIDATESKU yessdsavalidatesku;
    @Mock
    private NotificationSender mailNotificationSender;
    @Mock
    private PriceGroupService priceGroupService;
    @Mock
    private NotificationType notificationType;
    @Mock
    private MailUtilService mailUtilService;

    @Before
    public void setup() {
        validateSkuPricesFacade = new ValidateSkuPricesFacadeImpl(cropRepository, orderErrorService,
                mailNotificationSender, priceGroupService, mailUtilService);
    }


    @Test
    public void validateCorrectlyAllSkuAndPricesNotContainErrorsTheOrder() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);
        List<CropVO> cropVOList = new ArrayList<CropVO>();
        reset(jaxwsClientFactory);
        reset(cropRepository);
        reset(jaxwsClientFactory);

        when(jaxwsClientFactory.getValidationSkuPricePortType()).thenReturn(yessdsavalidatesku);
        when(cropRepository.findAll()).thenReturn(cropVOList);
        when(orderErrorService.containErrors(Matchers.<OrderDTO>any())).thenReturn(true);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        ValidateSkuPricesFacadeImpl aSpy = Mockito.spy(validateSkuPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when((ValidateSkuPricesFacadeImpl) aSpy).getJAXWSClientFactory();
        aSpy.validateSkuPrices(orderDTO);
    }


    @Test
    public void saveErrorsForAndOrderThatContainsErrorsAtValidateSkuAndPrices() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);

        List<CropVO> cropVOList = new ArrayList<CropVO>();
        reset(jaxwsClientFactory);
        reset(cropRepository);
        reset(jaxwsClientFactory);

        when(jaxwsClientFactory.getValidationSkuPricePortType()).thenReturn(yessdsavalidatesku);
        when(cropRepository.findAll()).thenReturn(cropVOList);
        when(orderErrorService.containErrors(Matchers.<OrderDTO>any())).thenReturn(true);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        ValidateSkuPricesFacadeImpl aSpy = Mockito.spy(validateSkuPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when((ValidateSkuPricesFacadeImpl) aSpy).getJAXWSClientFactory();
        aSpy.validateSkuPrices(orderDTO);
    }

    @Test
    public void testOrderContainsSkuErrorsAndNotificacionsAreSended() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);
        DistributorConfigDTO configDTO= new DistributorConfigDTO();
        configDTO.setDistributor(new DistributorDTO());
        orderDTO.setDistributorConfigDTO(configDTO);

        List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        for (int i = 0; i < 5; i++) {
            errorOrderDTOList.add(new ErrorOrderDTO());
            ErrorOrderDTO error = new ErrorOrderDTO();
            error.setErrorTypes(new ErrorTypeDTO());
            errorOrderDTOList.add(error);
        }

        List<CropVO> cropVOList = new ArrayList<CropVO>();
        reset(jaxwsClientFactory);
        reset(cropRepository);
        reset(jaxwsClientFactory);
        reset(orderErrorService);

        when(orderErrorService.obtainSkuErrors(Matchers.<OrderDTO>any())).thenReturn(errorOrderDTOList);
        when(jaxwsClientFactory.getValidationSkuPricePortType()).thenReturn(yessdsavalidatesku);
        when(cropRepository.findAll()).thenReturn(cropVOList);
        when(orderErrorService.containErrors(Matchers.<OrderDTO>any())).thenReturn(true);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        ValidateSkuPricesFacadeImpl aSpy = Mockito.spy(validateSkuPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when((ValidateSkuPricesFacadeImpl) aSpy).getJAXWSClientFactory();
        Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidPriceNotificationType();
        Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidSkuNotificationType();

        aSpy.validateSkuPrices(orderDTO);
    }

    @Test
    public void testOrderConstainsPirceErrorNotificacionIsSendedAndIsReturnedAndEmtpyListOfHybrids() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);
        DistributorConfigDTO configDTO= new DistributorConfigDTO();
        configDTO.setDistributor(new DistributorDTO());
        orderDTO.setDistributorConfigDTO(configDTO);
        List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        for (int i = 0; i < 5; i++) {
            ErrorOrderDTO error = new ErrorOrderDTO();
            error.setErrorTypes(new ErrorTypeDTO());
            errorOrderDTOList.add(error);
        }

        List<CropVO> cropVOList = new ArrayList<CropVO>();
        reset(jaxwsClientFactory);
        reset(cropRepository);
        reset(jaxwsClientFactory);
        reset(orderErrorService);

        when(orderErrorService.obtainPricesErrors(Matchers.<OrderDTO>any())).thenReturn(errorOrderDTOList);
        when(jaxwsClientFactory.getValidationSkuPricePortType()).thenReturn(yessdsavalidatesku);
        when(cropRepository.findAll()).thenReturn(cropVOList);
        when(orderErrorService.containErrors(Matchers.<OrderDTO>any())).thenReturn(false);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        ValidateSkuPricesFacadeImpl aSpy = Mockito.spy(validateSkuPricesFacade);
        Mockito.doReturn(jaxwsClientFactory).when((ValidateSkuPricesFacadeImpl) aSpy).getJAXWSClientFactory();
        Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidPriceNotificationType();
        Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidSkuNotificationType();

        aSpy.validateSkuPrices(orderDTO);
    }
    //

    @Test
      public void testOrderContainsSkuErrorsAndNotificacionsAreSended_() throws Exception {
          final ProductDTO productDTO = new ProductDTO();
          productDTO.setProductCode("1111");
          productDTO.setBrandCode("CB");
          productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

          final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
          orderDetailDTO.setProductDTO(productDTO);
          orderDetailDTO.setQuantity(34);

          final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
          orderDetailDTOList.add(orderDetailDTO);

          OrderDTO orderDTO = new OrderDTO();
          orderDTO.setDetail(orderDetailDTOList);
          DistributorConfigDTO configDTO= new DistributorConfigDTO();
          configDTO.setDistributor(new DistributorDTO());
          orderDTO.setDistributorConfigDTO(configDTO);

          List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
          for (int i = 0; i < 5; i++) {
              errorOrderDTOList.add(new ErrorOrderDTO());
              ErrorOrderDTO error = new ErrorOrderDTO();
              error.setErrorTypes(new ErrorTypeDTO());
              errorOrderDTOList.add(error);
          }
           orderDTO.setErrors(errorOrderDTOList);

          List<CropVO> cropVOList = new ArrayList<CropVO>();
          reset(jaxwsClientFactory);
          reset(cropRepository);
          reset(jaxwsClientFactory);
          reset(orderErrorService);

          when(orderErrorService.obtainSkuErrors(Matchers.<OrderDTO>any())).thenReturn(errorOrderDTOList);
          when(jaxwsClientFactory.getValidationSkuPricePortType()).thenReturn(yessdsavalidatesku);
          when(cropRepository.findAll()).thenReturn(cropVOList);
          when(orderErrorService.containErrors(Matchers.<OrderDTO>any())).thenReturn(true);
          when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
          ValidateSkuPricesFacadeImpl aSpy = Mockito.spy(validateSkuPricesFacade);
          Mockito.doReturn(jaxwsClientFactory).when((ValidateSkuPricesFacadeImpl) aSpy).getJAXWSClientFactory();
          Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidPriceNotificationType();
          Mockito.doReturn(notificationType).when((ValidateSkuPricesFacadeImpl) aSpy).getInvalidSkuNotificationType();
        Mockito.doReturn(orderDTO).when((ValidateSkuPricesFacadeImpl) aSpy).validateSkuPrices(Matchers.<OrderDTO>any());

          aSpy.validateSkuPrices(orderDTO);
      }

}
