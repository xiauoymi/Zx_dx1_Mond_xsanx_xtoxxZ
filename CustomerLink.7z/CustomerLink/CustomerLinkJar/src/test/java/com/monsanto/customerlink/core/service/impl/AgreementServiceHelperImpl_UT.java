package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.AgreementServiceHelper;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.AgreementRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.FiscalYearDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AgreementServiceHelperImpl_UT {

    @Mock
    private AgreementRepository agreementRepository;
    @Mock
    private AgreementServiceHelper unit;

    @Before
    public void before() {
        reset(agreementRepository);
        unit = new AgreementServiceHelperImpl(agreementRepository);
    }

    @Test
    public void obtainAgreementByParameters_WhenRepresentativeIsNotAvailable() throws Exception {
        FiscalYearVO yearVo = new FiscalYearVO();
        yearVo.setFiscalYear(2013L);
        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorProfileId(1L);
        AgreementVO agreementVO = new AgreementVO();
        RepresentativeDTO representativeDTO = null;
        when(agreementRepository.findByDistributorProfileAndFiscalYear(Matchers.any(Long.class),Matchers.any(Long.class))).thenReturn(agreementVO);
        assertThat(agreementVO, is( unit.obtainAgreementByParameters(yearVo,distributorProfileVO,representativeDTO)));
        verify(agreementRepository).findByDistributorProfileAndFiscalYear(Matchers.any(Long.class),Matchers.any(Long.class));
    }

    @Test
    public void obtainPurchaseOrderByParameters_WhenRepresentativeIsAvailable() throws Exception {
        FiscalYearVO yearVo = new FiscalYearVO();
        yearVo.setFiscalYear(2013L);
        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorProfileId(1L);
        AgreementVO agreementVO = new AgreementVO();
        RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("USER_SAP_ID");
        when(agreementRepository.findByDistributorProfileAndFiscalYearAndRcdSAPCode(Matchers.any(Long.class), Matchers.any(Long.class), Matchers.any(String.class))).thenReturn(agreementVO);
        assertThat(agreementVO, is(unit.obtainAgreementByParameters(yearVo,distributorProfileVO,representativeDTO)));
        verify(agreementRepository).findByDistributorProfileAndFiscalYearAndRcdSAPCode(Matchers.any(Long.class), Matchers.any(Long.class), Matchers.any(String.class));
    }

    @Test
    public void getFiscalYearList_WhenFiscalYearIsNull() throws Exception{
        FiscalYearDTO fy = null;
        List<Long> fyList = unit.getFiscalYearList(fy);
        assertThat(fyList.size() == 1,is(true));
    }

    @Test
    public void getFiscalYearList_WhenFiscalYearIsNotNull() throws Exception{
        FiscalYearDTO fy = new FiscalYearDTO();
        fy.setFiscalYear(2013);
        fy.setStatus(1);
        List<Long> fyList = unit.getFiscalYearList(fy);
        assertThat(fyList.size() == 2,is(true));
    }

}