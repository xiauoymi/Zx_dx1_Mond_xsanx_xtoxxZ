package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.AgreementService;
import com.monsanto.customerlink.web.services.autogen.agreement.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class AgreementServiceImpl_ST {

    @Autowired
    private AgreementService agreementService;

    @Test
    @Ignore
    public void createAgreement() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1014256");

        final DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setDistChCode("3R");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setSubRegionCode("AMXSUR");

        final PeriodDTO periodDTO1 = new PeriodDTO();
        periodDTO1.setPeriodId(1);

        final PeriodDTO periodDTO2 = new PeriodDTO();
        periodDTO2.setPeriodId(2);

        final PeriodDTO periodDTO3 = new PeriodDTO();
        periodDTO3.setPeriodId(3);

        final PeriodDTO periodDTO4 = new PeriodDTO();
        periodDTO4.setPeriodId(4);

        final VolumeGoalPeriodDTO volumeGoalPeriodDTO1 = new VolumeGoalPeriodDTO();
        volumeGoalPeriodDTO1.setPeriod(periodDTO1);

        final VolumeGoalPeriodDTO volumeGoalPeriodDTO2 = new VolumeGoalPeriodDTO();
        volumeGoalPeriodDTO2.setPeriod(periodDTO2);

        final VolumeGoalPeriodDTO volumeGoalPeriodDTO3 = new VolumeGoalPeriodDTO();
        volumeGoalPeriodDTO3.setPeriod(periodDTO3);

        final VolumeGoalPeriodDTO volumeGoalPeriodDTO4 = new VolumeGoalPeriodDTO();
        volumeGoalPeriodDTO4.setPeriod(periodDTO4);

        final List<VolumeGoalPeriodDTO> volumeGoalPeriodDTOList = new ArrayList<VolumeGoalPeriodDTO>();
        volumeGoalPeriodDTOList.add(volumeGoalPeriodDTO1);
        volumeGoalPeriodDTOList.add(volumeGoalPeriodDTO2);
        volumeGoalPeriodDTOList.add(volumeGoalPeriodDTO3);
        volumeGoalPeriodDTOList.add(volumeGoalPeriodDTO4);

        final VolumeGoalDTO volumeGoalDTO = new VolumeGoalDTO();
        volumeGoalDTO.setFamilyCode("HARNESS");
        volumeGoalDTO.setVolumeGoalPeriods(volumeGoalPeriodDTOList);

        final List<VolumeGoalDTO> volumeGoalDTOList = new ArrayList<VolumeGoalDTO>();
        volumeGoalDTOList.add(volumeGoalDTO);

        final IncentivePackageDTO incentivePackageDTO = new IncentivePackageDTO();
        incentivePackageDTO.setFamilyCode("HARNESS");

        final List<IncentivePackageDTO> incentivePackageDTOList = new ArrayList<IncentivePackageDTO>();
        incentivePackageDTOList.add(incentivePackageDTO);

        final AgreementDTO agreementDTO = new AgreementDTO();
        agreementDTO.setVolumeGoals(volumeGoalDTOList);
        agreementDTO.setIncentivePackages(incentivePackageDTOList);

        agreementService.createAgreement(agreementDTO, distributorConfigDTO);
    }
}
