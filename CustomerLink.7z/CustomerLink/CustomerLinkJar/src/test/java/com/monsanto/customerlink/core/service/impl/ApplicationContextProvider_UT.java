package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.persistence.repositories.DistributionChannelMappingRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationContextProvider_UT {

    @Test
    public void setApplicationContext() {
        ApplicationContextProvider unit = new ApplicationContextProvider();
        unit.setApplicationContext(new ClassPathXmlApplicationContext("classpath:ApplicationContextProvider_UT.xml"));
        DistributionChannelMappingRepository repository = (DistributionChannelMappingRepository)ApplicationContextProvider.getBeanByClass(DistributionChannelMappingRepository.class);
        assertThat(repository, is(notNullValue()));
        ApplicationContextProvider.closeContext();
    }

}
