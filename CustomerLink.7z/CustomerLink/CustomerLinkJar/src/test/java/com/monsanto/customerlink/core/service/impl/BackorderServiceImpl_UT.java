package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.BackorderService;
import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.BackorderVO;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.repositories.BackorderRepository;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderDTO;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyCollectionOf;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BackorderServiceImpl_UT {

    @Mock
    private DistributorService distributorBusiness;

    @Mock
    private BackorderRepository backorderRepository;

    @Mock
    private Mapper mapper;

    @InjectMocks
    private BackorderService unit = new BackorderServiceImpl();

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionWhenProductListToPersistIsEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final BackorderDTO backorderDTO = new BackorderDTO();
        backorderDTO.setDistributorConfigDTO(distributorProfileDTO);

        unit.createBackorder(backorderDTO);
    }

    @Test
    public void retrievesBackorderDTOWhenItCreate() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");

        final BackorderDetailDTO backorderDetailDTO = new BackorderDetailDTO();
        backorderDetailDTO.setProductDTO(productDTO);

        final List<BackorderDetailDTO> backorderDetailDTOList = new ArrayList<BackorderDetailDTO>();
        backorderDetailDTOList.add(backorderDetailDTO);

        final BackorderDTO backorderDTO = new BackorderDTO();
        backorderDTO.setDistributorConfigDTO(distributorProfileDTO);
        backorderDTO.setDetail(backorderDetailDTOList);

        final BackorderVO backorderVO = new BackorderVO();

        final List<BackorderVO> backorderVOList = new ArrayList<BackorderVO>();
        backorderVOList.add(backorderVO);

        when(distributorBusiness.retrieveDistributorConfigByConfig((DistributorConfigDTO) anyObject())).thenReturn(new DistributorProfileVO());
        when(mapper.mapList(BackorderVO.class, backorderDetailDTOList)).thenReturn(backorderVOList);

        final BackorderDTO backorderDTO1 = unit.createBackorder(backorderDTO);
        assertThat(backorderDTO1, is(notNullValue()));
        assertThat(backorderDTO1, is(sameInstance(backorderDTO)));
    }

    @Test(expected = OrdersNotFoundException.class)
    public void throwsOrdersNotFoundExceptionWhenBackorderNotFoundInTheRepository() throws Exception {
        when(backorderRepository.findByParameters((DistributorConfigDTO) anyObject())).thenReturn(new ArrayList<DistributorProfileVO>());

        unit.retrieveBackorders(new DistributorConfigDTO());
    }

    @Test
    public void retrievesBackorders() throws Exception {
        final DistributorProfileVO distributorProfileVO = new DistributorProfileVO();

        final List<DistributorProfileVO> distributorProfileVOList = new ArrayList<DistributorProfileVO>();
        distributorProfileVOList.add(distributorProfileVO);

        when(backorderRepository.findByParameters((DistributorConfigDTO) anyObject())).thenReturn(distributorProfileVOList);

        final BackorderDTO backorderDTO = new BackorderDTO();

        final List<BackorderDTO> backorderDTOList = new ArrayList<BackorderDTO>();
        backorderDTOList.add(backorderDTO);

        when(mapper.mapList(BackorderDTO.class, distributorProfileVOList)).thenReturn(backorderDTOList);

        final List<BackorderDTO> backorderDTOList1 = unit.retrieveBackorders(new DistributorConfigDTO());
        assertThat(backorderDTOList1, is(notNullValue()));
        Assert.assertTrue(!backorderDTOList1.isEmpty());
        assertThat(backorderDTOList1, is(sameInstance(backorderDTOList)));
    }

}
