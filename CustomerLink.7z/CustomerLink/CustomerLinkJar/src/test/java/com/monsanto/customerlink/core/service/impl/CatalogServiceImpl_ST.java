package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CatalogService;
import com.monsanto.customerlink.core.service.dto.*;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@ContextConfiguration(locations={"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class CatalogServiceImpl_ST {

    @Autowired
    private CatalogService unit;

    @Test
    @Ignore
    public void getListOfRoles() throws Exception {
        List<RoleDTO> roles = unit.getListOfRoles();
    }

    @Test
    @Ignore
    public void getListOfBrands() throws Exception {
        List<BrandDTO> brands = unit.getListOfBrands();
    }

    @Test
    @Ignore
    public void getListOfSubRegions() throws Exception {
        List<SubRegionDTO> subRegions = unit.getListOfSubRegions();
    }

    @Test
    @Ignore
    public void getListOfDistributors() throws Exception {
        List<DistributorDTO> distributors = unit.getListOfDistributors();
    }

    @Test
    @Ignore
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenSubRegionsIsNull() throws Exception {
        unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXOCC","TEST");
    }

    @Test
    @Ignore
    public void getListOfDistributorsByUserId() throws Exception {
        List<DistributorDTO> distributors = unit.getListOfDistributorsByUser(70L);
    }
}