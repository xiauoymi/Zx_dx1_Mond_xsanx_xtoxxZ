package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CatalogService;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.dto.*;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CatalogServiceImpl__UT {

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private Mapper mapper;

    @Mock
    private CatalogService unit;

    @Mock
    private BrandRepository brandRepository;

    @Mock
    private SubRegionRepository subRegionRepository;

    @Mock
    private DistributorRepository distributorRepository;

    @Mock
    private DistributorProfileRepository distributorProfileRepository;

    @Mock
    private UserManagementService userManagementService;

    @Before
    public void before() {
        reset(roleRepository,mapper, brandRepository, subRegionRepository, distributorRepository, distributorProfileRepository,userManagementService);
        unit = new CatalogServiceImpl(roleRepository,mapper,brandRepository,subRegionRepository, distributorRepository,distributorProfileRepository,userManagementService);
    }

    @Test
    public void getListOfRoles_WhenListOfRolesIsEmpty() throws Exception {
        List<RoleDTO> roles = unit.getListOfRoles();
        assertTrue(roles.isEmpty());
    }

    @Test
    public void getListOfRoles_WhenListOfRolesIsNotEmpty() throws Exception {

        RoleVO r1 = new RoleVO();
        r1.setRoleCode(1L);
        r1.setDescription("RCD");

        List<RoleVO> listOfRolesFromRepository = Arrays.asList(new RoleVO[]{r1});
        when(roleRepository.findRolesNotIn(anyList())).thenReturn(listOfRolesFromRepository);

        RoleDTO d1   = new RoleDTO();
        d1.setCode("RCD");
        d1.setDesc("RCD");

        List<RoleDTO> listOfRolesFromMapper = Arrays.asList(new RoleDTO[]{d1});
        when(mapper.mapList(eq(RoleDTO.class),anyList())).thenReturn(listOfRolesFromMapper);

        List<RoleDTO> roles = unit.getListOfRoles();
        assertTrue(!roles.isEmpty());
    }

    @Test
    public void getListOfBrands_WhenListOfBrandsIsEmpty() throws Exception {
        List<BrandDTO> brands = unit.getListOfBrands();
        assertTrue(brands.isEmpty());
    }

    @Test
    public void getListOfBrands_WhenListOfBrandsIsNotEmpty() throws Exception {

        BrandVO b1 = new BrandVO();
        b1.setBrandCode("DK");
        b1.setBrandDesc("DEKALB");

        List<BrandVO> listOfRolesFromRepository = Arrays.asList(new BrandVO[]{b1});

        when(brandRepository.findAll()).thenReturn(listOfRolesFromRepository);

        BrandDTO bb1   = new BrandDTO();
        bb1.setBrandCode("DK");
        bb1.setBrandDesc("DEKALB");

        List<BrandDTO> listOfBrandsFromMapper = Arrays.asList(new BrandDTO[]{bb1});
        when(mapper.mapList(eq(BrandDTO.class),anyList())).thenReturn(listOfBrandsFromMapper);

        List<BrandDTO> brands = unit.getListOfBrands();
        assertTrue(!brands.isEmpty());
    }

    @Test
    public void getListOfSubRegions_WhenListOfSubRegionsIsEmpty() throws Exception {
        List<SubRegionDTO> subRegions = unit.getListOfSubRegions();
        assertTrue(subRegions.isEmpty());
    }

    @Test
    public void getListOfSubRegions_WhenListOfSubRegionsIsNotEmpty() throws Exception {

        SubRegionVO s1 = new SubRegionVO();
        s1.setSubRegionCode("AMXBAJ");
        s1.setDescription("AMXBAJ-DESC");

        List<SubRegionVO> listOfSubRegionsFromRepository = Arrays.asList(new SubRegionVO[]{s1});
        when( subRegionRepository.findSubRegionNotIn(anyList())).thenReturn(listOfSubRegionsFromRepository);

        SubRegionDTO ss1 = new SubRegionDTO();
        ss1.setSubRegionCode("AMXBAJ");
        ss1.setSubRegionDesc("AMXBAJ-DESC");

        List<SubRegionDTO> listOfSubRegionsFromMapper = Arrays.asList(new SubRegionDTO[]{ss1});
        when(mapper.mapList(eq(SubRegionDTO.class),anyList())).thenReturn(listOfSubRegionsFromMapper);

        List<SubRegionDTO> subRegions = unit.getListOfSubRegions();
        assertTrue(!subRegions.isEmpty());
    }

    @Test
    public void getListOfDistributors_WhenListOfDistributorsIsEmpty() throws Exception {
        List<DistributorDTO> distributors = unit.getListOfDistributors();
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getListOfDistributors_WhenListOfDistributorsIsNotEmpty() throws Exception {

        DistributorVO d = new DistributorVO();
        d.setDistributorCode("123456789");
        d.setName("PRODUCTOS AGROPECUARIOS S.A DE C.V. ");

        List<DistributorVO> listOfDistributorsFromRepository = Arrays.asList(new DistributorVO[]{d});
        when( distributorRepository.getAllDistributors()).thenReturn(listOfDistributorsFromRepository);

        DistributorDTO d1 = new DistributorDTO();

        List<DistributorDTO> listOfDistributorsFromMapper = Arrays.asList(new DistributorDTO[]{d1});
        when(mapper.mapList(eq(DistributorDTO.class),anyList())).thenReturn(listOfDistributorsFromMapper);

        List<DistributorDTO> distributors = unit.getListOfDistributors();
        assertTrue(!distributors.isEmpty());
    }

        @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenSubRegionIsNull() throws Exception {
        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName(null, null);
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenSubRegionIsEmpty() throws Exception {
        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("",null);
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenDistributorCodeOrNameIsNull_AndListOfDistributorProfilesIsEmpty() throws Exception {

        List<DistributorProfileVO> distributorsProfilesRetrieves = Arrays.asList(new DistributorProfileVO[]{});
        when(distributorProfileRepository.findBySubRegionCode("AMXBAJ")).thenReturn(distributorsProfilesRetrieves);
        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXBAJ",null);
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenDistributorCodeOrNameIsEmpty_AndListOfDistributorProfilesIsEmpty() throws Exception {

        List<DistributorProfileVO> distributorsProfilesRetrieves = Arrays.asList(new DistributorProfileVO[]{});
        when(distributorProfileRepository.findBySubRegionCode("AMXBAJ")).thenReturn(distributorsProfilesRetrieves);
        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXBAJ","");
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenDistributorCodeOrNameIsEmpty_AndListOfDistributorProfilesIsNotEmpty() throws Exception {

        DistributorProfileVO dp = new DistributorProfileVO();
        List<DistributorProfileVO> distributorsProfilesRetrieves = Arrays.asList(new DistributorProfileVO[]{dp});
        when(distributorProfileRepository.findBySubRegionCode("AMXBAJ")).thenReturn(distributorsProfilesRetrieves);

        List<GridDistributorProfileDTO> listOfDistributorsMapped = new ArrayList<GridDistributorProfileDTO>();
        listOfDistributorsMapped.add(new GridDistributorProfileDTO());
        when(mapper.mapList  (GridDistributorProfileDTO.class, distributorsProfilesRetrieves)).thenReturn(listOfDistributorsMapped);

        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXBAJ","");
        assertTrue(!distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenDistributorCodeOrNameIsNotEmpty_AndListOfDistributorProfilesIsEmpty() throws Exception {

        List<DistributorProfileVO> distributorsProfilesRetrieves = Arrays.asList(new DistributorProfileVO[]{});
        when(distributorProfileRepository.findBySubRegionCode("AMXBAJ")).thenReturn(distributorsProfilesRetrieves);
        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXBAJ","DISTRIBUTOR_NAME");
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsBySubRegionAndDistributorCodeOrName_WhenDistributorCodeOrNameIsNotEmpty_AndListOfDistributorProfilesIsNotEmpty() throws Exception {

        DistributorProfileVO dp = new DistributorProfileVO();
        List<DistributorProfileVO> distributorsProfilesRetrieves = Arrays.asList(new DistributorProfileVO[]{dp});
        when(distributorProfileRepository.findBySubRegionCodeAndDistributorCodeOrName("AMXBAJ","DISTRIBUTOR_NAME")).thenReturn(distributorsProfilesRetrieves);

        List<GridDistributorProfileDTO> listOfDistributorsMapped = new ArrayList<GridDistributorProfileDTO>();
        listOfDistributorsMapped.add(new GridDistributorProfileDTO());
        when(mapper.mapList  (GridDistributorProfileDTO.class, distributorsProfilesRetrieves)).thenReturn(listOfDistributorsMapped);

        List<GridDistributorProfileDTO> distributors = unit.getDistributorsBySubRegionAndDistributorCodeOrName("AMXBAJ","DISTRIBUTOR_NAME");
        assertTrue(!distributors.isEmpty());
    }

    @Test
    public void getDistributorsByUser_WhenUserIdIsNull() throws Exception {
        List<DistributorDTO> distributors = unit.getListOfDistributorsByUser(null);
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsByUser_WhenListDistributorsIsEmpty() throws Exception {

        Long userId = 1L;

        List<DistributorVO> distributorsFromRepository = new ArrayList<DistributorVO>();
        when(distributorRepository.findByUserId(eq(userId))).thenReturn(distributorsFromRepository);

        List<DistributorDTO> distributors = unit.getListOfDistributorsByUser(userId);
        assertTrue(distributors.isEmpty());
    }

    @Test
    public void getDistributorsByUser_WhenListDistributorsIsNotEmpty() throws Exception {

        Long userId = 1L;

        List<DistributorVO> distributorsFromRepository = new ArrayList<DistributorVO>();
        distributorsFromRepository.add(new DistributorVO());

        when(distributorRepository.findByUserId(eq(userId))).thenReturn(distributorsFromRepository);

        List<DistributorDTO> distributorsMapped = new ArrayList<DistributorDTO>();
        distributorsMapped.add(new DistributorDTO());

        when(mapper.mapList(DistributorDTO.class,distributorsFromRepository)).thenReturn(distributorsMapped);

        List<DistributorDTO> distributors = unit.getListOfDistributorsByUser(userId);
        assertTrue(!distributors.isEmpty());
    }


    @Test
    public void getListOfGridUserRoleByDistributorProfileId_WhenCommonRolesListIsEmpty_AndDistributorProfileIsNull() {
        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(new ArrayList<UserVO>());
        List<GridUserRoleDTO> list = unit.getListOfGridUserRoleByDistributorProfileId(1L);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getListOfGridUserRoleByDistributorProfileId_WhenCommonRolesListIsNotEmpty_AndDistributorProfileIsNull() {

        List<UserVO> commonRoles = Arrays.asList( new UserVO[]{new UserVO()});
        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(commonRoles);

        List<GridUserRoleDTO> totalRoles =  Arrays.asList(new GridUserRoleDTO[]{new GridUserRoleDTO()});
        when(mapper.mapList(GridUserRoleDTO.class,commonRoles)).thenReturn(totalRoles);

        List<GridUserRoleDTO> list = unit.getListOfGridUserRoleByDistributorProfileId(1L);
        assertTrue(!list.isEmpty());
    }


    @Test
    public void getListOfUserRoleByDistributorProfileId_WhenIdDistributorProfileIsNull() {
        List<UserRoleDTO> list = unit.getListOfUserRoleByDistributorProfileId(null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getListOfUserRoleByDistributorProfileId_WhenCommonRolesListIsEmpty_AndDistributorProfileIsNull() {

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(new ArrayList<UserVO>());
        List<UserRoleDTO> list = unit.getListOfUserRoleByDistributorProfileId(1L);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getListOfUserRoleByDistributorProfileId_WhenCommonRolesListIsNotEmpty_AndDistributorProfileIsNull() {

        List<UserVO> commonRoles = Arrays.asList( new UserVO[]{new UserVO()});
        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(commonRoles);

        List<UserRoleDTO> totalRoles =  Arrays.asList(new UserRoleDTO[]{new UserRoleDTO()});
        when(mapper.mapList(UserRoleDTO.class,commonRoles)).thenReturn(totalRoles);

        List<UserRoleDTO> list = unit.getListOfUserRoleByDistributorProfileId(1L);
        assertTrue(!list.isEmpty());
    }


}