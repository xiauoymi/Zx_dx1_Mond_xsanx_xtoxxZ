package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CropServiceImpl_UT {

    @Mock
    private CropRepository cropRepository;

    @Mock
    private CropService unit;

    @Before
    public void before() {
        reset(cropRepository);
        unit = new CropServiceImpl(cropRepository);
    }

    @Test
    public void createRequestInventory() throws Exception{
        when(cropRepository.findByCropCode(eq("GT010"))).thenReturn(new CropVO());
        CropVO crop = unit.obtainCropByCode(SeedsCropCodeEnum.COTTON.getCode());
        assertTrue(crop!=null);
    }

}