package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.IncreaseDecreaseATPHelper;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@ContextConfiguration(locations={"classpath:DecreaseATPServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class DecreaseATPServiceImpl_UT {

    @Autowired
    Mapper mapper;

    @Autowired
    private DecreaseATPServiceImpl decreaseATPService;

    @Autowired
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;

    @Test
    public void decreaseOnATP_CornOrSorghum_When_ThereIsNoInventoryAvailable_ToDecrement() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(24D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(0D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(40D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(42D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);


        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(50); // the new amount of ATP is small, but there is no inventory available to decrement items

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder, atpOrder);

        double expectedQuantityDecrease = 104;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder,sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );

        assertTrue(true);
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_MaterialListOfSap_AndTheMaterialAlreadyHasAllDelivered() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(24D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(0D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(40D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(42D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(133);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 77; // this is the max amount for decrease
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_And_All_Assigned() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(12D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(35D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(40D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(20D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);


        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(120);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 90;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_And_All_Assigned_AndNotAvailableForDecrease() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(24D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(70D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(74D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(42D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(120);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 0;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_And_Not_All_Assigned() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(12D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(35D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(37D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(117);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 93;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_When_Unallocated_AfterAssignIsZero() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(24D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(35D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(37D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(117);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 93;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_When_Unallocated_AfterAssignNotZero() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(0D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(35D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(37D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(117);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 93;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_When_Unallocated_AfterAssignNotZero_AndMaterial_IsCandidateToDelete() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(4D);
        sku1.setDel_qty(0D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(60D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(35D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(155);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 35;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CornOrSorghum_When_InventoryIsAvailable_ToDecrement_When_DecreaseQuantityIsEqualOne() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(4D);
        sku1.setDel_qty(0D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(60D);
        sku2.setMaterial("SKU2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(35D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(189);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 1;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CottonOrSoybean_When_InventoryIsAvailable_ToDecrement() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(12D);
        sku1.setMaterial("SKU1");
        sku1.setPlant("PLANT_1");
        sku1.setStoragelocation("STORAGE_LOCATION_1");
        sku1.setBatch("BATCH_1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(35D);
        sku2.setMaterial("SKU2");
        sku2.setPlant("PLANT_2");
        sku2.setStoragelocation("STORAGE_LOCATION_2");
        sku2.setBatch("BATCH_2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(35D);
        sku3.setMaterial("SKU3");
        sku3.setPlant("PLANT_3");
        sku3.setStoragelocation("STORAGE_LOCATION_3");
        sku3.setBatch("BATCH_3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setPlant("PLANT_4");
        sku4.setStoragelocation("STORAGE_LOCATION_4");
        sku4.setBatch("BATCH_4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(118);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 92;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CottonOrSoybean_When_InventoryIsAvailable_ToDecrement_AndMaterial_IsCandidateToDelete() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(24D);
        sku1.setDel_qty(0D);
        sku1.setMaterial("SKU1");
        sku1.setPlant("PLANT_1");
        sku1.setStoragelocation("STORAGE_LOCATION_1");
        sku1.setBatch("BATCH_1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(0D);
        sku2.setMaterial("SKU2");
        sku2.setPlant("PLANT_2");
        sku2.setStoragelocation("STORAGE_LOCATION_2");
        sku2.setBatch("BATCH_2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(35D);
        sku3.setMaterial("SKU3");
        sku3.setPlant("PLANT_3");
        sku3.setStoragelocation("STORAGE_LOCATION_3");
        sku3.setBatch("BATCH_3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setPlant("PLANT_4");
        sku4.setStoragelocation("STORAGE_LOCATION_4");
        sku4.setBatch("BATCH_4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(118);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 92;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    @Test
    public void decreaseOnATP_CottonOrSoybean_When_InventoryIsAvailable_ToDecrement_When_DecreaseQuantityIsEqualOne() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(4D);
        sku1.setDel_qty(0D);
        sku1.setMaterial("SKU1");
        sku1.setPlant("PLANT_1");
        sku1.setStoragelocation("STORAGE_LOCATION_1");
        sku1.setBatch("BATCH_1");
        sku1.setItemNumber(10L);

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(70D);
        sku2.setDel_qty(60D);
        sku2.setMaterial("SKU2");
        sku2.setPlant("PLANT_2");
        sku2.setStoragelocation("STORAGE_LOCATION_2");
        sku2.setBatch("BATCH_2");
        sku2.setItemNumber(20L);

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(74D);
        sku3.setDel_qty(35D);
        sku3.setMaterial("SKU3");
        sku3.setPlant("PLANT_3");
        sku3.setStoragelocation("STORAGE_LOCATION_3");
        sku3.setBatch("BATCH_3");
        sku3.setItemNumber(30L);

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(42D);
        sku4.setDel_qty(21D);
        sku4.setMaterial("SKU4");
        sku4.setPlant("PLANT_4");
        sku4.setStoragelocation("STORAGE_LOCATION_4");
        sku4.setBatch("BATCH_4");
        sku4.setItemNumber(40L);


        HybridDTO h = new HybridDTO();
        h.setHybridCode("GORILA");
        h.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2, sku3,sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("GORILA");
        dto.setProductDTO(p);
        dto.setQuantity(189);

        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(dto);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // hybrids are assigned to increase
        decreaseATPService.decreaseATPProcess(sapOrder,atpOrder);

        double expectedQuantityDecrease = 1;
        double finalQuantityDecreased = this.quantityDecreased(atpOrder, sapOrder);

        assertTrue(expectedQuantityDecrease == finalQuantityDecreased );
    }

    private double quantityDecreased(OrderDTO orderDTO, SAPOrderDTO sapOrder) {

        double quantity = 0;

        for(OrderDetailDTO detail : orderDTO.getDetail()) {
            if(detail.getProductDTO().getListOfSku() != null && !(detail.getProductDTO().getListOfSku()).isEmpty()) {

                for(MaterialSkuDTO m : detail.getProductDTO().getListOfSku()) {

                    if(sapOrder.getHybrids()!=null && !sapOrder.getHybrids().isEmpty()) {

                        for(HybridDTO h : sapOrder.getHybrids()) {

                            if(h.getSkus() != null && !h.getSkus().isEmpty()) {

                                for(MaterialDTO o : h.getSkus()) {

                                    if( o.getItemNumber().longValue() == m.getItemNumber() ) {
                                        if(m.getTransactionType().equals(TransactionTypeMaterial.DELETE.getCode())) {
                                            quantity += o.getReq_qty();
                                        }else {
                                            quantity += (o.getReq_qty() - m.getUnrestqty());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //System.out.println(" quantity :  "+quantity);

        return quantity;
    }

    @Test
    public void doAnythingWhenNotExistHybridsToProcess() throws Exception {
        final HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("H1");
        hybridDTO1.setTotalQty(20);

        final List<HybridDTO> withoutSoakTestSAPOrderDetail = new ArrayList<HybridDTO>();
        withoutSoakTestSAPOrderDetail.add(hybridDTO1);

        final SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setHybrids(withoutSoakTestSAPOrderDetail);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(20);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setDistributorConfigDTO(new DistributorConfigDTO());

        decreaseATPService.decreaseATPProcess(sapOrder, orderDTO);
        assertThat(orderDTO, is(notNullValue()));
        assertThat(orderDTO.getDetail().size(), is(0));
    }

}