package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DecreaseWithoutSoakTestATPService;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

@ContextConfiguration(locations = {"classpath:DecreaseWithoutSoakTestATPServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class DecreaseWithoutSoakTestATPServiceImpl_UT {

    @Autowired
    private DecreaseWithoutSoakTestATPService decreaseWithoutSoakTestATPService;

    @Test
    public void decreaseWhitAWithoutSoakTestOrder_00() throws Exception {
        final HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("H1");
        hybridDTO1.setTotalQty(20);

        final HybridDTO hybridDTO2 = new HybridDTO();
        hybridDTO2.setHybridCode("H2");
        hybridDTO2.setTotalQty(20);

        final HybridDTO hybridDTO3 = new HybridDTO();
        hybridDTO3.setHybridCode("H3");
        hybridDTO3.setTotalQty(0);

        final HybridDTO hybridDTO4 = new HybridDTO();
        hybridDTO4.setHybridCode("H4");
        hybridDTO4.setTotalQty(10);

        final HybridDTO hybridDTO9 = new HybridDTO();
        hybridDTO9.setHybridCode("H6");
        hybridDTO9.setTotalQty(18);

        final List<HybridDTO> withoutSoakTestSAPOrderDetail = new ArrayList<HybridDTO>();
        withoutSoakTestSAPOrderDetail.add(hybridDTO1);
        withoutSoakTestSAPOrderDetail.add(hybridDTO2);
        withoutSoakTestSAPOrderDetail.add(hybridDTO3);
        withoutSoakTestSAPOrderDetail.add(hybridDTO4);
        withoutSoakTestSAPOrderDetail.add(hybridDTO9);

        final SAPOrderDTO withoutSoakTestSAPOrder = new SAPOrderDTO();
        withoutSoakTestSAPOrder.setHybrids(withoutSoakTestSAPOrderDetail);

        final HybridDTO hybridDTO5 = new HybridDTO();
        hybridDTO5.setHybridCode("H1");
        hybridDTO5.setTotalQty(10);

        final HybridDTO hybridDTO6 = new HybridDTO();
        hybridDTO6.setHybridCode("H2");
        hybridDTO6.setTotalQty(0);

        final HybridDTO hybridDTO7 = new HybridDTO();
        hybridDTO7.setHybridCode("H3");
        hybridDTO7.setTotalQty(10);

        final HybridDTO hybridDTO8 = new HybridDTO();
        hybridDTO8.setHybridCode("H5");
        hybridDTO8.setTotalQty(10);

        final HybridDTO hybridDTO10 = new HybridDTO();
        hybridDTO10.setHybridCode("H6");
        hybridDTO10.setTotalQty(10);

        final List<HybridDTO> normalSeasonSAPOrderDetail = new ArrayList<HybridDTO>();
        normalSeasonSAPOrderDetail.add(hybridDTO5);
        normalSeasonSAPOrderDetail.add(hybridDTO6);
        normalSeasonSAPOrderDetail.add(hybridDTO7);
        normalSeasonSAPOrderDetail.add(hybridDTO8);
        normalSeasonSAPOrderDetail.add(hybridDTO10);

        final SAPOrderDTO normalSeasonSAPOrder = new SAPOrderDTO();
        normalSeasonSAPOrder.setHybrids(normalSeasonSAPOrderDetail);
        normalSeasonSAPOrder.setWithoutSoakTestOrder(withoutSoakTestSAPOrder);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("H2");

        final ProductDTO productDTO3 = new ProductDTO();
        productDTO3.setProductCode("H3");

        final ProductDTO productDTO4 = new ProductDTO();
        productDTO4.setProductCode("H4");

        final ProductDTO productDTO5 = new ProductDTO();
        productDTO5.setProductCode("H5");

        final ProductDTO productDTO6 = new ProductDTO();
        productDTO6.setProductCode("H6");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(10);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(15);

        final OrderDetailDTO orderDetailDTO3 = new OrderDetailDTO();
        orderDetailDTO3.setProductDTO(productDTO3);
        orderDetailDTO3.setQuantity(5);

        final OrderDetailDTO orderDetailDTO4 = new OrderDetailDTO();
        orderDetailDTO4.setProductDTO(productDTO4);
        orderDetailDTO4.setQuantity(5);

        final OrderDetailDTO orderDetailDTO5 = new OrderDetailDTO();
        orderDetailDTO5.setProductDTO(productDTO5);
        orderDetailDTO5.setQuantity(5);

        final OrderDetailDTO orderDetailDTO6 = new OrderDetailDTO();
        orderDetailDTO6.setProductDTO(productDTO6);
        orderDetailDTO6.setQuantity(30);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);
        orderDetailDTOList.add(orderDetailDTO3);
        orderDetailDTOList.add(orderDetailDTO4);
        orderDetailDTOList.add(orderDetailDTO5);
        orderDetailDTOList.add(orderDetailDTO6);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        Map<OrderDTO, SAPOrderDTO> ordersToDecrease = decreaseWithoutSoakTestATPService.decreaseWhitAWithoutSoakTestOrder(orderDTO, normalSeasonSAPOrder);
        assertThat(ordersToDecrease, is(notNullValue()));
        assertThat(ordersToDecrease.size(), is(2));
        for (OrderDTO key : ordersToDecrease.keySet()) {
            SAPOrderDTO sapOrderDTO = ordersToDecrease.get(key);
            assertThat(key, is(not(sameInstance(orderDTO))));
            if (StringUtils.equals(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), key.getClOrderTypeCode())) {
                assertThat(key.getDetail().size(), is(5));
                assertThat(sapOrderDTO, is(sameInstance(withoutSoakTestSAPOrder)));
                assertThat(key.getDetail().get(0).getQuantity(), is(10D));
                assertThat(sapOrderDTO.getHybrids().get(0).getTotalQty(), is(20D));
                assertThat(key.getDetail().get(1).getQuantity(), is(15D));
                assertThat(sapOrderDTO.getHybrids().get(1).getTotalQty(), is(20D));
                assertThat(key.getDetail().get(2).getQuantity(), is(0D));
                assertThat(sapOrderDTO.getHybrids().get(2).getTotalQty(), is(0D));
                assertThat(key.getDetail().get(3).getQuantity(), is(5D));
                assertThat(sapOrderDTO.getHybrids().get(3).getTotalQty(), is(10D));
                assertThat(key.getDetail().get(4).getQuantity(), is(18D));
                assertThat(sapOrderDTO.getHybrids().get(4).getTotalQty(), is(18D));
            } else {
                assertThat(key.getDetail().size(), is(3));
                assertThat(sapOrderDTO, is(sameInstance(normalSeasonSAPOrder)));
                assertThat(key.getDetail().get(0).getQuantity(), is(5D));
                assertThat(sapOrderDTO.getHybrids().get(0).getTotalQty(), is(10D));
                assertThat(key.getDetail().get(1).getQuantity(), is(5D));
                assertThat(sapOrderDTO.getHybrids().get(3).getTotalQty(), is(10D));
                assertThat(key.getDetail().get(2).getQuantity(), is(10D));
                assertThat(sapOrderDTO.getHybrids().get(4).getTotalQty(), is(10D));
            }
        }
    }

    @Test
    public void retrievesOrderDTOMapEmptyWhenNotExistIntersection() throws Exception {
        final HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("H6");
        hybridDTO1.setTotalQty(20);

        final HybridDTO hybridDTO2 = new HybridDTO();
        hybridDTO2.setHybridCode("H7");
        hybridDTO2.setTotalQty(20);

        final HybridDTO hybridDTO3 = new HybridDTO();
        hybridDTO3.setHybridCode("H8");
        hybridDTO3.setTotalQty(0);

        final HybridDTO hybridDTO4 = new HybridDTO();
        hybridDTO4.setHybridCode("H9");
        hybridDTO4.setTotalQty(10);

        final List<HybridDTO> withoutSoakTestSAPOrderDetail = new ArrayList<HybridDTO>();
        withoutSoakTestSAPOrderDetail.add(hybridDTO1);
        withoutSoakTestSAPOrderDetail.add(hybridDTO2);
        withoutSoakTestSAPOrderDetail.add(hybridDTO3);
        withoutSoakTestSAPOrderDetail.add(hybridDTO4);

        final SAPOrderDTO withoutSoakTestSAPOrder = new SAPOrderDTO();
        withoutSoakTestSAPOrder.setHybrids(withoutSoakTestSAPOrderDetail);

        final HybridDTO hybridDTO5 = new HybridDTO();
        hybridDTO5.setHybridCode("H6");
        hybridDTO5.setTotalQty(10);

        final HybridDTO hybridDTO6 = new HybridDTO();
        hybridDTO6.setHybridCode("H7");
        hybridDTO6.setTotalQty(0);

        final HybridDTO hybridDTO7 = new HybridDTO();
        hybridDTO7.setHybridCode("H8");
        hybridDTO7.setTotalQty(10);

        final HybridDTO hybridDTO8 = new HybridDTO();
        hybridDTO8.setHybridCode("H9");
        hybridDTO8.setTotalQty(10);

        final List<HybridDTO> normalSeasonSAPOrderDetail = new ArrayList<HybridDTO>();
        normalSeasonSAPOrderDetail.add(hybridDTO5);
        normalSeasonSAPOrderDetail.add(hybridDTO6);
        normalSeasonSAPOrderDetail.add(hybridDTO7);
        normalSeasonSAPOrderDetail.add(hybridDTO8);

        final SAPOrderDTO normalSeasonSAPOrder = new SAPOrderDTO();
        normalSeasonSAPOrder.setHybrids(normalSeasonSAPOrderDetail);
        normalSeasonSAPOrder.setWithoutSoakTestOrder(withoutSoakTestSAPOrder);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("H2");

        final ProductDTO productDTO3 = new ProductDTO();
        productDTO3.setProductCode("H3");

        final ProductDTO productDTO4 = new ProductDTO();
        productDTO4.setProductCode("H4");

        final ProductDTO productDTO5 = new ProductDTO();
        productDTO5.setProductCode("H5");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(10);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(15);

        final OrderDetailDTO orderDetailDTO3 = new OrderDetailDTO();
        orderDetailDTO3.setProductDTO(productDTO3);
        orderDetailDTO3.setQuantity(5);

        final OrderDetailDTO orderDetailDTO4 = new OrderDetailDTO();
        orderDetailDTO4.setProductDTO(productDTO4);
        orderDetailDTO4.setQuantity(5);

        final OrderDetailDTO orderDetailDTO5 = new OrderDetailDTO();
        orderDetailDTO5.setProductDTO(productDTO5);
        orderDetailDTO5.setQuantity(5);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);
        orderDetailDTOList.add(orderDetailDTO3);
        orderDetailDTOList.add(orderDetailDTO4);
        orderDetailDTOList.add(orderDetailDTO5);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);

        Map<OrderDTO, SAPOrderDTO> ordersToDecrease = decreaseWithoutSoakTestATPService.decreaseWhitAWithoutSoakTestOrder(orderDTO, normalSeasonSAPOrder);
        assertThat(ordersToDecrease, is(notNullValue()));
        assertThat(ordersToDecrease.size(), is(0));
    }

    @Test
    public void retrievesMapWithOriginalOrderWhenThereIsNotWithoutSoakTestOrder() throws Exception {
        final HybridDTO hybridDTO5 = new HybridDTO();
        hybridDTO5.setHybridCode("H6");
        hybridDTO5.setTotalQty(10);

        final HybridDTO hybridDTO6 = new HybridDTO();
        hybridDTO6.setHybridCode("H7");
        hybridDTO6.setTotalQty(0);

        final HybridDTO hybridDTO7 = new HybridDTO();
        hybridDTO7.setHybridCode("H8");
        hybridDTO7.setTotalQty(10);

        final HybridDTO hybridDTO8 = new HybridDTO();
        hybridDTO8.setHybridCode("H9");
        hybridDTO8.setTotalQty(10);

        final List<HybridDTO> normalSeasonSAPOrderDetail = new ArrayList<HybridDTO>();
        normalSeasonSAPOrderDetail.add(hybridDTO5);
        normalSeasonSAPOrderDetail.add(hybridDTO6);
        normalSeasonSAPOrderDetail.add(hybridDTO7);
        normalSeasonSAPOrderDetail.add(hybridDTO8);

        final SAPOrderDTO normalSeasonSAPOrder = new SAPOrderDTO();
        normalSeasonSAPOrder.setHybrids(normalSeasonSAPOrderDetail);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("H2");

        final ProductDTO productDTO3 = new ProductDTO();
        productDTO3.setProductCode("H3");

        final ProductDTO productDTO4 = new ProductDTO();
        productDTO4.setProductCode("H4");

        final ProductDTO productDTO5 = new ProductDTO();
        productDTO5.setProductCode("H5");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(10);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(15);

        final OrderDetailDTO orderDetailDTO3 = new OrderDetailDTO();
        orderDetailDTO3.setProductDTO(productDTO3);
        orderDetailDTO3.setQuantity(5);

        final OrderDetailDTO orderDetailDTO4 = new OrderDetailDTO();
        orderDetailDTO4.setProductDTO(productDTO4);
        orderDetailDTO4.setQuantity(5);

        final OrderDetailDTO orderDetailDTO5 = new OrderDetailDTO();
        orderDetailDTO5.setProductDTO(productDTO5);
        orderDetailDTO5.setQuantity(5);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);
        orderDetailDTOList.add(orderDetailDTO3);
        orderDetailDTOList.add(orderDetailDTO4);
        orderDetailDTOList.add(orderDetailDTO5);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(orderDetailDTOList);

        Map<OrderDTO, SAPOrderDTO> ordersToDecrease = decreaseWithoutSoakTestATPService.decreaseWhitAWithoutSoakTestOrder(orderDTO, normalSeasonSAPOrder);
        assertThat(ordersToDecrease, is(notNullValue()));
        assertThat(ordersToDecrease.size(), is(1));
        for (Map.Entry<OrderDTO, SAPOrderDTO> entry : ordersToDecrease.entrySet()) {
            assertThat(entry.getKey(), is(sameInstance(orderDTO)));
            assertThat(entry.getValue(), is(sameInstance(normalSeasonSAPOrder)));
        }
    }
}
