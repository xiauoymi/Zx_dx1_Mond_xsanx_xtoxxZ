package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DeliveryService;
import com.monsanto.customerlink.core.service.exception.DeleteDeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryNotFoundException;
import com.monsanto.customerlink.core.service.exception.DeliveryProductNotFoundException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.DeliveryProductVO;
import com.monsanto.customerlink.persistence.entities.DeliveryVO;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.persistence.repositories.DeliveryProductRepository;
import com.monsanto.customerlink.persistence.repositories.DeliveryRepository;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalDeliveryDTO;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalSavedDeliveryDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isNotNull;
import static org.mockito.Matchers.isNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DeliveryServiceImpl_UT {

    @Mock
    Mapper mapper;

    @Mock
    private DeliveryRepository deliveryRepository;

    @Mock
    private DeliveryProductRepository deliveryProductRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private DeliveryService unit = new DeliveryServiceImpl();

    @Test
    public void getEmptyListOfExistSavedDeliveries_When_OrderIdentifiers_ListIsNull() throws Exception{
        List<TemporalDeliveryDTO> list = unit.existSavedDeliveries(null);
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getEmptyListOfExistSavedDeliveries_When_OrderIdentifiers_ListIsEmpty() throws Exception{
        List<TemporalDeliveryDTO> list = unit.existSavedDeliveries(new ArrayList<String>());
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getNonEmptyListOfExistSavedDeliveries_When_NotFoundDeliveries_InRepository() throws Exception{

        List<String> ordersIdentifiers = Arrays.asList(new String[]{"1","2"});
        List<DeliveryVO> listFromRepository = new ArrayList<DeliveryVO>();

        when(deliveryRepository.getDeliveriesBySapOrdersId(eq(ordersIdentifiers))).thenReturn(listFromRepository);

        List<TemporalDeliveryDTO> list = unit.existSavedDeliveries(ordersIdentifiers);

        assertTrue(list!=null);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void getNonEmptyListOfExistSavedDeliveries_When_ExistDeliveries_InRepository_AndSapIdentifiers_AreEquals() throws Exception{

        List<String> ordersIdentifiers = Arrays.asList(new String[]{"1","2"});
        List<DeliveryVO> listFromRepository = new ArrayList<DeliveryVO>();

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap("1");
        listFromRepository.add(d1);

        DeliveryVO d2 = new DeliveryVO();
        d2.setOrderIdSap("2");
        listFromRepository.add(d2);

        when(deliveryRepository.getDeliveriesBySapOrdersId(eq(ordersIdentifiers))).thenReturn(listFromRepository);

        List<TemporalDeliveryDTO> list = unit.existSavedDeliveries(ordersIdentifiers);

        assertTrue(list!=null);
        assertTrue(!list.isEmpty());
        assertThat(list, is(notNullValue()));
    }

    @Test
    public void getNonEmptyListOfExistSavedDeliveries_When_ExistDeliveries_InRepository_AndSapIdentifiers_AreNotEquals() throws Exception{

        List<String> ordersIdentifiers = Arrays.asList(new String[]{"1","2"});

        List<DeliveryVO> listFromRepository = new ArrayList<DeliveryVO>();

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap("1");
        listFromRepository.add(d1);

        DeliveryVO d2 = new DeliveryVO();
        d2.setOrderIdSap("NOT_EQUAL_ID");
        listFromRepository.add(d2);

        when(deliveryRepository.getDeliveriesBySapOrdersId(eq(ordersIdentifiers))).thenReturn(listFromRepository);

        List<TemporalDeliveryDTO> list = unit.existSavedDeliveries(ordersIdentifiers);

        assertTrue(list!=null);
        assertTrue(!list.isEmpty());
        assertThat(list, is(notNullValue()));
    }

    @Test
    public void getEmptyListOfSavedDeliveries_When_SapOrderId_IsNull() throws Exception{
        List<TemporalSavedDeliveryDTO> list = unit.getSavedDeliveriesBySapOrderId(null);
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getEmptyListOfSavedDeliveries_When_SapOrderIds_IsEmpty() throws Exception{
        final List<String> sapOrderIds = new ArrayList<String>();

        List<TemporalSavedDeliveryDTO> list = unit.getSavedDeliveriesBySapOrderId(sapOrderIds);
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getEmptyListOfSavedDeliveries_When_SapOrderId_IsEmpty() throws Exception{
        final List<String> sapOrderIds = new ArrayList<String>();
        sapOrderIds.add("    ");

        List<TemporalSavedDeliveryDTO> list = unit.getSavedDeliveriesBySapOrderId(sapOrderIds);
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getEmptyListOfSavedDeliveries_When_NotFoundDeliveries_InRepository() throws Exception{
        final List<String> sapOrderIds = new ArrayList<String>();
        sapOrderIds.add("ORDER_ID_TEST");

        List<DeliveryVO> listFromRepository = new ArrayList<DeliveryVO>();

        when(deliveryRepository.getDeliveriesBySapOrdersId(Matchers.<List<String>>any())).thenReturn(listFromRepository);

        List<TemporalSavedDeliveryDTO> list = unit.getSavedDeliveriesBySapOrderId(sapOrderIds);

        assertTrue(list!=null);
        assertTrue(list.isEmpty());
    }

    @Test
    public void getNonEmptyListOfSavedDeliveries_When_NotFoundDeliveries_InRepository() throws Exception{
        final List<String> sapOrderIds = new ArrayList<String>();
        sapOrderIds.add("1");

        List<DeliveryVO> listFromRepository = new ArrayList<DeliveryVO>();

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap("1");
        listFromRepository.add(d1);

        DeliveryVO d2 = new DeliveryVO();
        d2.setOrderIdSap("2");
        listFromRepository.add(d2);

        when(deliveryRepository.getDeliveriesBySapOrdersId(Matchers.<List<String>>any())).thenReturn(listFromRepository);

        List<TemporalSavedDeliveryDTO> mappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        TemporalSavedDeliveryDTO t2 = new TemporalSavedDeliveryDTO();

        mappedList.add(t1);
        mappedList.add(t2);

        when(mapper.mapList(TemporalSavedDeliveryDTO.class, listFromRepository)).thenReturn(mappedList);

        List<TemporalSavedDeliveryDTO> list = unit.getSavedDeliveriesBySapOrderId(sapOrderIds);

        assertTrue(list!=null);
        assertTrue(!list.isEmpty());
        assertThat(list, is(notNullValue()));
    }

    @Test
    public void notSuccessUpdateSavedDeliveries_When_InputDeliveriesList_IsNull() throws Exception{
        boolean success = unit.updateSavedDeliveries(null);
        assertFalse(success);
    }

    @Test
    public void notSuccessUpdateSavedDeliveries_When_InputDeliveriesList_IsEmpty() throws Exception{
        boolean success = unit.updateSavedDeliveries(new ArrayList<TemporalSavedDeliveryDTO>());
        assertFalse(success);
    }

    @Test
    public void successUpdateSavedDeliveries_When_InputDeliveriesList_NotEmpty_CheckMapped() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        TemporalSavedDeliveryDTO t2 = new TemporalSavedDeliveryDTO();

        toMappedList.add(t1);
        toMappedList.add(t2);

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap("1");
        mappedList.add(d1);

        DeliveryVO d2 = new DeliveryVO();
        d2.setOrderIdSap("2");
        mappedList.add(d2);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = IllegalArgumentException.class)
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = null;

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = IllegalArgumentException.class)
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsEmpty() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "  ";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductLisIsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);
        d1.setDeliveryProductsByDeliveryId(null);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductLisIsEmpty() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);
        d1.setDeliveryProductsByDeliveryId(new ArrayList<DeliveryProductVO>());
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = DeliveryProductNotFoundException.class)
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductContainsValues_When_ProductIsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();

        List<DeliveryProductVO> deliveryProducts = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        // product is null
        dp.setProductByProductCode(null);
        deliveryProducts.add(dp);

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);

        //Delivery product contains values
        d1.setDeliveryProductsByDeliveryId(deliveryProducts);

        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = DeliveryProductNotFoundException.class)
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductContainsValues_When_ProductIsNotNull_AndProductCodeIsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();

        List<DeliveryProductVO> deliveryProducts = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        ProductVO product = new ProductVO();
        // Product Code is null
        product.setProductCode(null);

        // product is not null
        dp.setProductByProductCode(product);
        deliveryProducts.add(dp);


        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);

        //Delivery product contains values
        d1.setDeliveryProductsByDeliveryId(deliveryProducts);

        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = DeliveryProductNotFoundException.class)
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductContainsValues_When_ProductIsNotNull_AndProductCodeIsEmpty() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();

        List<DeliveryProductVO> deliveryProducts = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        ProductVO product = new ProductVO();
        // Product Code is empty
        product.setProductCode("    ");

        // product is not null
        dp.setProductByProductCode(product);
        deliveryProducts.add(dp);


        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);

        //Delivery product contains values
        d1.setDeliveryProductsByDeliveryId(deliveryProducts);

        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_NewDelivery_When_OrderSapId_IsValid_And_DeliveryProductContainsValues_When_ProductIsNotNull_AndProductCodeIsValid() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "ValidOrderSapId";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();

        List<DeliveryProductVO> deliveryProducts = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        String sapProductCode = "SAP_PRODUCT_CODE_VALID";

        ProductVO product = new ProductVO();
        // Product Code is valid
        product.setProductCode("SAP_PRODUCT_CODE_VALID");

        // product is not null
        dp.setProductByProductCode(product);
        deliveryProducts.add(dp);

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap(ValidOrderSapId);

        //Delivery product contains values
        d1.setDeliveryProductsByDeliveryId(deliveryProducts);

        when(productRepository.findByProductCode(product.getProductCode())).thenReturn(product);

        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

        @Test(expected = IllegalArgumentException.class)
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = null;

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = IllegalArgumentException.class)
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_Empty() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "   ";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = DeliveryNotFoundException.class)
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsValid_And_DeliveryNotFound() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "VALID_ORDER_SAP_ID";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);
        d1.setIdMdTransp("IdMdTransp");
        d1.setShipto("shipto");
        d1.setTimeDlv("08:00");
        d1.setDeliveryDate(new Date());
        d1.setStatus(1);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        when(deliveryRepository.findOne(eq(d1.getDeliveryId()))).thenReturn(null);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

        @Test
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsValid_DeliveryExist_And_DeliveryProductsListIsNull() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "VALID_ORDER_SAP_ID";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        DeliveryVO deliveryFromRepository = new DeliveryVO();
        deliveryFromRepository.setDeliveryProductsByDeliveryId(null);

        when(deliveryRepository.findOne(eq(d1.getDeliveryId()))).thenReturn(deliveryFromRepository);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsValid_DeliveryExist_And_DeliveryProductsListIsEmpty() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "VALID_ORDER_SAP_ID";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        DeliveryVO deliveryFromRepository = new DeliveryVO();
        deliveryFromRepository.setDeliveryProductsByDeliveryId(new ArrayList<DeliveryProductVO>());

        when(deliveryRepository.findOne(eq(d1.getDeliveryId()))).thenReturn(deliveryFromRepository);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsValid_DeliveryExist_And_DeliveryProductsList_ContainsValues() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "VALID_ORDER_SAP_ID";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        List<DeliveryProductVO> listDeliveryProductFromRepository = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        listDeliveryProductFromRepository.add(dp);

        DeliveryVO deliveryFromRepository = new DeliveryVO();
        deliveryFromRepository.setDeliveryProductsByDeliveryId(listDeliveryProductFromRepository);

        when(deliveryRepository.findOne(eq(d1.getDeliveryId()))).thenReturn(deliveryFromRepository);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test(expected = DeliveryProductNotFoundException.class)
    public void successUpdateSavedDeliveries_UpdateDelivery_When_OrderSapId_IsValid_DeliveryExist_AndDeliveryProductIsNotNull_And_DeliveryProductsList_ContainsValues() throws Exception{

        List<TemporalSavedDeliveryDTO> toMappedList = new ArrayList<TemporalSavedDeliveryDTO>();
        TemporalSavedDeliveryDTO t1 = new TemporalSavedDeliveryDTO();
        toMappedList.add(t1);

        String ValidOrderSapId = "VALID_ORDER_SAP_ID";

        List<DeliveryVO> mappedList = new ArrayList<DeliveryVO>();
        DeliveryVO d1 = new DeliveryVO();

        List<DeliveryProductVO> deliveryProductList = new ArrayList<DeliveryProductVO>();
        deliveryProductList.add(new DeliveryProductVO());

        d1.setDeliveryProductsByDeliveryId(deliveryProductList);

        // the delivery exist.
        Long idDelivery = 1L;

        // assign delivery ID.
        d1.setDeliveryId(idDelivery);

        d1.setOrderIdSap(ValidOrderSapId);
        mappedList.add(d1);

        when(mapper.mapList(DeliveryVO.class,toMappedList)).thenReturn(mappedList);

        List<DeliveryProductVO> listDeliveryProductFromRepository = new ArrayList<DeliveryProductVO>();
        DeliveryProductVO dp = new DeliveryProductVO();

        listDeliveryProductFromRepository.add(dp);

        DeliveryVO deliveryFromRepository = new DeliveryVO();
        deliveryFromRepository.setDeliveryId(1L);
        deliveryFromRepository.setDeliveryProductsByDeliveryId(listDeliveryProductFromRepository);

        when(deliveryRepository.findOne(eq(d1.getDeliveryId()))).thenReturn(deliveryFromRepository);

        boolean success = unit.updateSavedDeliveries(toMappedList);

        assertTrue(success);
    }

    @Test
    public void notSuccessDeleteDelivery_When_deliveryId_IsNull() throws Exception{
        Boolean success = unit.deleteDelivery(null);
        assertFalse(success);
    }

    @Test(expected = DeleteDeliveryNotFoundException.class)
    public void exceptionDeleteDelivery_When_DeliveryNotFound_InRepository() throws Exception{

        Long deliveryId = 1L;

        when(deliveryRepository.findOne(deliveryId)).thenReturn(null);
        Boolean success = unit.deleteDelivery(deliveryId);

        assertFalse(success);
    }

    @Test
    public void successDeleteDelivery_When_DeliveryFound_InRepository() throws Exception{

        Long deliveryId = 1L;

        DeliveryVO delivery = new DeliveryVO();

        when(deliveryRepository.findOne(deliveryId)).thenReturn(delivery);
        Boolean success = unit.deleteDelivery(deliveryId);

        assertTrue(success);
    }

}