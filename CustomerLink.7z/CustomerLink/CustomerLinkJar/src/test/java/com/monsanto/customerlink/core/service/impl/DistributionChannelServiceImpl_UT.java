package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributionChannelService;
import com.monsanto.customerlink.core.service.exception.DistributionChannelNotFoundException;
import com.monsanto.customerlink.persistence.entities.DistributionChannelVO;
import com.monsanto.customerlink.persistence.repositories.DistributionChannelRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DistributionChannelServiceImpl_UT {

    @Mock
    private DistributionChannelRepository distributionChannelRepository;

    @InjectMocks
    private DistributionChannelService unit = new DistributionChannelServiceImpl();

    @Test(expected = DistributionChannelNotFoundException.class)
    public void throwsDistributionChannelNotFoundExceptionWhenDistributionChannelIsNotFoundInTheRepository() throws Exception {
        when(distributionChannelRepository.findByDistributionChannelCode(Matchers.<String>any())).thenReturn(null);

        unit.retrieveDistributionChannel("3R");
    }

    @Test
    public void retrievesTheDistributionChannelFromTheRepositoryWhoseParametersMatches() throws Exception {
        final DistributionChannelVO distributionChannelVO = new DistributionChannelVO();

        when(distributionChannelRepository.findByDistributionChannelCode(Matchers.<String>any())).thenReturn(distributionChannelVO);

        final DistributionChannelVO distributionChannelVO1 = unit.retrieveDistributionChannel("3R");
        assertThat(distributionChannelVO1, is(notNullValue()));
        assertThat(distributionChannelVO1, is(sameInstance(distributionChannelVO)));
    }

}
