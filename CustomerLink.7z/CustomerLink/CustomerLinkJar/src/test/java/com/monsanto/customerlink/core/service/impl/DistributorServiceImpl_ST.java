package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class DistributorServiceImpl_ST {

    @Autowired
    private DistributorService distributorService;

    @Test
    @Ignore
    public void retrieveDistributor() throws Exception {
        DistributorDTO distributor = distributorService.retrieveDistributor("3101380");
        System.out.println(distributor);
    }
}
