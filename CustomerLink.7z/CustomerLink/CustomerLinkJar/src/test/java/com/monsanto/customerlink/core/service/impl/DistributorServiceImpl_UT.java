package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.exception.DistributorConfigNotFoundException;
import com.monsanto.customerlink.core.service.exception.DistributorNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.DistributionChannelMappingRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorConfigRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PrivateBrandDistributorRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DistributorServiceImpl_UT {

    @Mock
    private UserService userService;
    @Mock
    private DistributorRepository distributorRepository;
    @Mock
    private Mapper mapper;
    @Mock
    private DistributorConfigRepository distributorConfigRepository;
    @Mock
    private PrivateBrandDistributorRepository privateBrandDistributorRepository;

    @Mock
    private DistributionChannelMappingRepository distChannelMappingRepository;

    @InjectMocks
    private DistributorService unit = new DistributorServiceImpl();

    @Test(expected = DistributorNotFoundException.class)
    public void throwsDistributorNotFoundExceptionIfTheDistributorIsNotFoundInTheRepository() throws Exception {
        when(distributorRepository.findByDistributorCode(eq("TEST"))).thenReturn(null);

        unit.retrieveDistributor("TEST");
    }

    @Test
    public void retrievesTheDistributorFromTheRepositoryWhoseCodeMatches_IsConsignmentAndIsBrandOwn() throws Exception {
        final PrivateBrandDistributorVO privateBrandDistributorVO = new PrivateBrandDistributorVO();

        final List<PrivateBrandDistributorVO> privateBrandDistributorVOList = new ArrayList<PrivateBrandDistributorVO>();
        privateBrandDistributorVOList.add(privateBrandDistributorVO);

        final DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setStatus(1L);
        distributorProfileVO.setDistributionChannelCode(CustomerLinkCoreConstants.CONSIGNMENT_DIST_CHANNEL);
        distributorProfileVO.setSalesDivisionCode(CustomerLinkCoreConstants.AGROCHEMICAL_SALES_DIV);

        final List<DistributorProfileVO> distributorProfileVOList = new ArrayList<DistributorProfileVO>();
        distributorProfileVOList.add(distributorProfileVO);

        final DistributorVO voFromTheRepository = new DistributorVO();
        voFromTheRepository.setDistributorProfilesByDistributorCode(distributorProfileVOList);
        voFromTheRepository.setPrivateBrandDistributorsByDistributorCode(privateBrandDistributorVOList);

        when(distributorRepository.findByDistributorCode(eq("TEST"))).thenReturn(voFromTheRepository);

        final DistributorDTO mappedDTO = new DistributorDTO();
        mappedDTO.getConfig().add(new DistributorConfigDTO());

        when(mapper.map(voFromTheRepository, DistributorDTO.class)).thenReturn(mappedDTO);

        final List<RepresentativeDTO> representatives = new ArrayList<RepresentativeDTO>();
        representatives.add(new RepresentativeDTO());

        when(mapper.mapList(Matchers.<Class<RepresentativeDTO>>any(), Matchers.<List<UserVO>>any())).thenReturn(representatives);

        final DistributorDTO distributor = unit.retrieveDistributor("TEST");
        assertThat(distributor, is(notNullValue()));
        assertThat(distributor, is(sameInstance(mappedDTO)));
        assertThat(distributor.isBrandOwn(), is(Boolean.TRUE));
        assertThat(distributor.isConsignment(), is(Boolean.TRUE));
        assertThat(distributor.getConfig().get(0).getRepresentatives().isEmpty(), is(Boolean.FALSE));
    }

    @Test
    public void retrievesTheDistributorFromTheRepositoryWhoseCodeMatches_IsNotConsignmentAndIsBrandOwn() throws Exception {
        final PrivateBrandDistributorVO privateBrandDistributorVO = new PrivateBrandDistributorVO();

        final List<PrivateBrandDistributorVO> privateBrandDistributorVOList = new ArrayList<PrivateBrandDistributorVO>();
        privateBrandDistributorVOList.add(privateBrandDistributorVO);

        final DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributionChannelCode("80");
        distributorProfileVO.setSalesDivisionCode("17");

        final List<DistributorProfileVO> distributorProfileVOList = new ArrayList<DistributorProfileVO>();
        distributorProfileVOList.add(distributorProfileVO);

        final DistributorVO voFromTheRepository = new DistributorVO();
        voFromTheRepository.setDistributorProfilesByDistributorCode(distributorProfileVOList);
        voFromTheRepository.setPrivateBrandDistributorsByDistributorCode(privateBrandDistributorVOList);
        when(distributorRepository.findByDistributorCode(eq("TEST"))).thenReturn(voFromTheRepository);
        final DistributorDTO mappedDTO = new DistributorDTO();
        when(mapper.map(voFromTheRepository, DistributorDTO.class)).thenReturn(mappedDTO);

        final DistributorDTO distributor = unit.retrieveDistributor("TEST");
        assertThat(distributor, is(notNullValue()));
        assertThat(distributor, is(sameInstance(mappedDTO)));
        assertThat(distributor.isBrandOwn(), is(Boolean.TRUE));
        assertThat(distributor.isConsignment(), is(Boolean.FALSE));
    }

    @Test
    public void retrievesTheDistributorFromTheRepositoryWhoseCodeMatches_IsNotConsignmentAndIsNotBrandOwn() throws Exception {
        final List<PrivateBrandDistributorVO> privateBrandDistributorVOList = new ArrayList<PrivateBrandDistributorVO>();

        final List<DistributorProfileVO> distributorProfileVOList = new ArrayList<DistributorProfileVO>();

        final DistributorVO voFromTheRepository = new DistributorVO();
        voFromTheRepository.setDistributorProfilesByDistributorCode(distributorProfileVOList);
        voFromTheRepository.setPrivateBrandDistributorsByDistributorCode(privateBrandDistributorVOList);
        String distributorCode = "TEST";
        when(distributorRepository.findByDistributorCode(eq(distributorCode))).thenReturn(voFromTheRepository);
        final DistributorDTO mappedDTO = new DistributorDTO();
        mappedDTO.setDistributorCode(distributorCode);
        when(mapper.map(voFromTheRepository, DistributorDTO.class)).thenReturn(mappedDTO);

        /*
        private void setListOfCsr(DistributorDTO distributorDTO) {
            List<UserVO> csrs = userService.retrieveUsersByDistributorAndRole(distributorDTO.getDistributorCode(),RoleEnum.CSR);
            distributorDTO.setCsr(mapper.mapList(RepresentativeDTO.class, csrs));
        }

        private void setListOfApprovers(DistributorDTO distributorDTO) {
            List<UserVO> approvers = userService.retrieveUsersByDistributorAndRole(distributorDTO.getDistributorCode(), RoleEnum.APPROVER);
            CollectionUtils.forAllDo(approvers,new Closure() {
                @Override
                public void execute(Object input) {
                    ((UserVO)input).setRepresentativeName(RoleEnum.APPROVER.getCode());
                }
            });
            distributorDTO.getCsr().addAll(mapper.mapList(RepresentativeDTO.class, approvers));
        }*/

        List<UserVO> csrList = new ArrayList<UserVO>();
        csrList.add(new UserVO());
        when(userService.retrieveUsersByDistributorAndRole(eq(distributorCode), eq(RoleEnum.CSR))).thenReturn(csrList);

        List<UserVO> approverList = new ArrayList<UserVO>();
        approverList.add(new UserVO());
        when(userService.retrieveUsersByDistributorAndRole(eq(distributorCode), eq(RoleEnum.APPROVER))).thenReturn(approverList);

        //mapper.mapList(RepresentativeDTO.class, csrs
        List<RepresentativeDTO> csrsMapped = new ArrayList<RepresentativeDTO>();
        csrsMapped.add(new RepresentativeDTO());
        when(mapper.mapList(eq(RepresentativeDTO.class), eq(csrList))).thenReturn(csrsMapped);

        List<RepresentativeDTO> approversMapped = new ArrayList<RepresentativeDTO>();
        approversMapped.add(new RepresentativeDTO());
        when(mapper.mapList(eq(RepresentativeDTO.class), eq(approverList))).thenReturn(approversMapped);

        final DistributorDTO distributor = unit.retrieveDistributor(distributorCode);
        assertThat(distributor, is(notNullValue()));
        assertThat(distributor, is(sameInstance(mappedDTO)));
        assertThat(distributor.isBrandOwn(), is(Boolean.FALSE));
        assertThat(distributor.isConsignment(), is(Boolean.FALSE));
    }


    @Test
    public void retrieveDistributorConfigWhoseConfigMatches() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(new DistributorProfileVO());

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
        assertThat(disConfig, is(notNullValue()));
    }


    //@Test(expected = DistributorConfigNotFoundException.class)
    public void throwsDistributorNotFoundWhen() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");
        reset(distributorConfigRepository);
        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(null);

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
    }

    @Test(expected = RuntimeException.class)
    public void throwsRuntimeIfNotEnoughParameters() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
    }

    @Test
    public void verifyReturnTrueWhenDistributorExistInPrivateBrandConfiguration(){
        List<PrivateBrandDistributorVO> privateBrandDistributorVOList= new ArrayList<PrivateBrandDistributorVO>();
        privateBrandDistributorVOList.add(new PrivateBrandDistributorVO());

        reset(privateBrandDistributorRepository);
        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(privateBrandDistributorVOList);
        Assert.assertTrue(unit.verifyIsPrivateBrandDistributor(""));
    }

    @Test
    public void verifyReturnFalseWhenDistributorNotExistInPrivateBrandConfiguration(){
        reset(privateBrandDistributorRepository);
        when(privateBrandDistributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(new ArrayList<PrivateBrandDistributorVO>());
        Assert.assertFalse(unit.verifyIsPrivateBrandDistributor(""));
    }

    @Test(expected = DistributorConfigNotFoundException.class)
    public void exceptionRetrieveDistributorConfig_WhenChannelMappingRetrieveNullOrEmptyCollection() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(null);

        when(distChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(new ArrayList<DistributionChannelMappingVO>());

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
        assertThat(disConfig, is(notNullValue()));
    }

    @Test(expected = DistributorConfigNotFoundException.class)
    public void exceptionRetrieveDistributorConfig_WhenChannelMappingRetrieveNotEmptyCollection_AndFindByParametersRetrieveNull() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(null);

        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setClCode("00");
        List<DistributionChannelMappingVO> mappings = new ArrayList<DistributionChannelMappingVO>();
        mappings.add(mappingVO);
        when(distChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(mappings);
        when(distributorConfigRepository.findByParameters(anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(null);

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
        assertThat(disConfig, is(notNullValue()));
    }

    @Test
     public void retrieveDistributorConfig_WhenChannelMappingRetrieveNotEmptyCollection_AndFindByParametersRetrieveNotNull() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(null);

        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setClCode("00");
        List<DistributionChannelMappingVO> mappings = new ArrayList<DistributionChannelMappingVO>();
        mappings.add(mappingVO);
        when(distChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(mappings);
        when(distributorConfigRepository.findByParameters(anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(new DistributorProfileVO());

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
        assertThat(disConfig, is(notNullValue()));
    }

    @Test
    public void retrieveDistributorConfig_WhenChannelMappingRetrieveNotEmptyCollection_AndFindByParametersRetrieveNotNull_WhenCsrAndApproversListIsNotEmpty() throws Exception {

        DistributorConfigDTO disDto = new DistributorConfigDTO();

        disDto.setSalesOrgCode("1234");
        disDto.setDistChCode("1234");
        disDto.setSalesDivCode("9800");
        disDto.setSubRegionCode("AMXBAJ");
        DistributorDTO distributorDTO = new DistributorDTO();
        String distributorCode = "1111";
        distributorDTO.setDistributorCode(distributorCode);

        disDto.setDistributor(distributorDTO);
        SubRegionDTO subregiondto = new SubRegionDTO();

        subregiondto.setSubRegionId(1l);
        subregiondto.setSubRegionCode("1");

        when(distributorConfigRepository.findByParameters(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any()
        )).thenReturn(null);

        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setClCode("00");
        List<DistributionChannelMappingVO> mappings = new ArrayList<DistributionChannelMappingVO>();
        mappings.add(mappingVO);
        when(distChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(mappings);
        when(distributorConfigRepository.findByParameters(anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(new DistributorProfileVO());

        DistributorProfileVO disConfig = unit.retrieveDistributorConfigByConfig(disDto);
        assertThat(disConfig, is(notNullValue()));
    }

}