package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class EmailRecoveryServiceImpl_ST {

    @Autowired
    private EmailRecoveryService emailRecoveryService;

    @Test
    @Ignore
    public void approveWorkflowByUser() throws Exception {

        List<String> roles = new ArrayList<String>();

        roles.add(RoleEnum.PRICING.getCode());
        roles.add(RoleEnum.PLANNING.getCode());
        roles.add(RoleEnum.MARKETING.getCode());
        roles.add(RoleEnum.RCD.getCode());
        roles.add(RoleEnum.DISTRIBUTOR.getCode());

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();

        String salesOrganization = "MX20";
        String distributionChanel = "3R";
        String salesDivision = "17";
        String subRegionCode = "AMXBAJ";

        distributorConfigDTO.setSalesOrgCode(salesOrganization);
        distributorConfigDTO.setDistChCode(distributionChanel);
        distributorConfigDTO.setSalesDivCode(salesDivision);
        distributorConfigDTO.setSubRegionCode(subRegionCode);

        String distributorCode = "1111";
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode(distributorCode);

        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> emails = emailRecoveryService.retrieveEmailByRoleAndDistributorConfig(roles, distributorConfigDTO);

        System.out.println(emails);
    }
}