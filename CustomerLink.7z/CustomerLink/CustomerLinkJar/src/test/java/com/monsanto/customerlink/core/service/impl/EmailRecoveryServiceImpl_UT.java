package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributorService;
import com.monsanto.customerlink.core.service.EmailRecoveryService;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.RoleVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EmailRecoveryServiceImpl_UT {

    @Mock
    DistributorRepository distributorRepository;

    @Mock
    private DistributorProfileRepository distributorProfileRepository;

    @Mock
    private EmailRecoveryService unit;

    @Mock
    private DistributorService distributorService;

    @Mock
    private UserManagementService userManagementService;

    @Before
    public void before() {
        reset(distributorRepository,distributorProfileRepository,userManagementService);
        unit = new EmailRecoveryServiceImpl(distributorRepository,userManagementService, distributorService);
    }

    @Test
    public void retrieveByDistributorWhen_DistributorCodeIsNull() throws Exception{
        String distributorCode = null;
        String email = unit.retrieveByDistributor(distributorCode);
        assertTrue(StringUtils.isEmpty(email));
    }

    @Test
    public void retrieveByDistributorWhen_DistributorCodeIsEmpty() throws Exception{
        String distributorCode = StringUtils.EMPTY;
        String email = unit.retrieveByDistributor(distributorCode);
        assertTrue(StringUtils.isEmpty(email));
    }

    @Test
    public void retrieveByDistributorWhen_DistributorNotFound() throws Exception{
        String distributorCode = "0123456789";

        when(distributorRepository.findOne(anyString())).thenReturn(null);
        String email = unit.retrieveByDistributor(distributorCode);

        assertTrue(StringUtils.isEmpty(email));
        verify(distributorRepository).findOne(anyString());
    }

    @Test
    public void retrieveByDistributorWhen_DistributorFound() throws Exception{
        String distributorCode = "0123456789";

        DistributorVO distributor = new DistributorVO();
        distributor.setEmail("distributor@email.com");
        when(distributorRepository.findOne(anyString())).thenReturn(distributor);
        String email = unit.retrieveByDistributor(distributorCode);

        assertTrue(StringUtils.isNotEmpty(email));
        verify(distributorRepository).findOne(anyString());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_RolesAreNull() throws Exception{

        List<String> roles = null;
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,null);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_RolesAreEmpty() throws Exception{

        List<String> roles = new ArrayList<String>();
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,null);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorIsNull() throws Exception{

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(null);
        List<String> roles = Arrays.asList(new String[]{"RCD","MKT"});
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNull() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = Arrays.asList(new String[]{"RCD","MKT"});
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNull_AndListOfRolesIsNull() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = null;
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNull_AndListOfRolesIsEmpty() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = new ArrayList<String>();
        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(emails.isEmpty());
    }


    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNotNull_AndUsersAreEmpty() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = Arrays.asList(new String[]{"RCD","MKT"});

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(new ArrayList<UserVO>());
        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNotNull_AndUsersAreNotEmpty() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = new ArrayList<String>();
        roles.add("RCD");
        roles.add("MKT");

        UserVO u1 = new UserVO();
        u1.setEmail("1@monsanto.com");
        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.RCD.getCode());
        u1.setRoleVO(r1);

        UserVO u2 = new UserVO();
        u2.setEmail("2@monsanto.com");
        RoleVO r2 = new RoleVO();
        r2.setCode(RoleEnum.MARKETING.getCode());
        u2.setRoleVO(r2);

        List<UserVO> listOfUsersFromRepository = new ArrayList<UserVO>();
        listOfUsersFromRepository.add(u1);
        listOfUsersFromRepository.add(u2);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(listOfUsersFromRepository);

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(!emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNotNull_AndUsersAreNotEmptyAndRoleIsDistributor_AndEmailDistributorIsEmpty() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = new ArrayList<String>();
        roles.add(RoleEnum.RCD.getCode());
        roles.add(RoleEnum.DISTRIBUTOR.getCode());
        roles.add(RoleEnum.MARKETING.getCode());
        roles.add(RoleEnum.DISTRIBUTOR.getCode());

        UserVO u1 = new UserVO();
        u1.setEmail("1@monsanto.com");
        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.RCD.getCode());
        u1.setRoleVO(r1);

        UserVO u2 = new UserVO();
        u2.setEmail("2@monsanto.com");
        RoleVO r2 = new RoleVO();
        r2.setCode(RoleEnum.MARKETING.getCode());
        u2.setRoleVO(r2);

        List<UserVO> listOfUsersFromRepository = new ArrayList<UserVO>();
        listOfUsersFromRepository.add(u1);
        listOfUsersFromRepository.add(u2);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(listOfUsersFromRepository);

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        List<String> emails = unit.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(!emails.isEmpty());
    }

    @Test
    public void retrieveEmailByRoleAndDistributorConfigWhen_DistributorProfileIsNotNull_AndUsersAreNotEmptyAndRoleIsDistributor_AndEmailDistributorIsNotEmpty() throws Exception{

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);

        List<String> roles = new ArrayList<String>();
        roles.add(RoleEnum.RCD.getCode());
        roles.add(RoleEnum.DISTRIBUTOR.getCode());
        roles.add(RoleEnum.MARKETING.getCode());
        roles.add(RoleEnum.DISTRIBUTOR.getCode());

       UserVO u1 = new UserVO();
        u1.setEmail("1@monsanto.com");
        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.RCD.getCode());
        u1.setRoleVO(r1);

        UserVO u2 = new UserVO();
        u2.setEmail("2@monsanto.com");
        RoleVO r2 = new RoleVO();
        r2.setCode(RoleEnum.MARKETING.getCode());
        u2.setRoleVO(r2);

        List<UserVO> listOfUsersFromRepository = new ArrayList<UserVO>();
        listOfUsersFromRepository.add(u1);
        listOfUsersFromRepository.add(u2);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(listOfUsersFromRepository);

        EmailRecoveryService aSpy = Mockito.spy(unit);
        Mockito.doReturn("emailDistributor@monsanto.com").when((EmailRecoveryService)aSpy).retrieveByDistributor(anyString());

        when(distributorService.retrieveDistributorConfigByConfig(any(DistributorConfigDTO.class))).thenReturn(new DistributorProfileVO());

        List<String> emails = aSpy.retrieveEmailByRoleAndDistributorConfig(roles,distributorConfigDTO);
        assertTrue(!emails.isEmpty());
    }

}