package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.FiscalYearService;
import com.monsanto.customerlink.core.service.exception.FiscalYearNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.persistence.repositories.FiscalYearRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.Date;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FiscalYearServiceImpl_UT {

    @Mock
    private FiscalYearRepository fiscalYearRepository;

    @InjectMocks
    private FiscalYearService unit = new FiscalYearServiceImpl();

    @Test(expected = FiscalYearNotFoundException.class)
    public void throwsFiscalYearNotFoundExceptionWhenActiveFiscalYearIsNotFoundInTheRepository() throws Exception {
        when(fiscalYearRepository.findActiveFiscalYear(Matchers.<Date>any())).thenReturn(null);

        unit.retrieveActiveFiscalYear(new Date());
    }

    @Test
    public void retrievesTheFiscalYearFromTheRepositoryWhoseParametersMatches() throws Exception {
        final FiscalYearVO fiscalYearVO = new FiscalYearVO();

        when(fiscalYearRepository.findActiveFiscalYear(Matchers.<Date>any())).thenReturn(fiscalYearVO);

        final FiscalYearVO fiscalYearVO1 = unit.retrieveActiveFiscalYear(new Date());
        assertThat(fiscalYearVO1, is(notNullValue()));
        assertThat(fiscalYearVO1, is(sameInstance(fiscalYearVO)));
    }

    @Test
    public void retrieveSearchPeriod() throws Exception {
        final Date startDate = CustomerLinkUtils.SDF_DDMMYYYY.parse("01/09/2013");
        final Date endDate = CustomerLinkUtils.SDF_DDMMYYYY.parse("31/08/2014");
        final FiscalYearVO fiscalYearVO = new FiscalYearVO();
        fiscalYearVO.setStartDate(new Timestamp(startDate.getTime()));
        fiscalYearVO.setEndDate(new Timestamp(endDate.getTime()));
        when(fiscalYearRepository.findActiveFiscalYear(Matchers.<Date>any())).thenReturn(fiscalYearVO);

        final SearchPeriodDTO searchPeriodDTO = unit.retrieveSearchPeriod();
        assertThat(searchPeriodDTO, is(notNullValue()));
        assertThat(searchPeriodDTO.getStartDate(), StringUtils.equals("2013-09-01", CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(startDate)));
        assertThat(searchPeriodDTO.getEndDate(), StringUtils.equals("2014-08-31", CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(endDate)));
    }
}
