package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.facade.InventoryFacade;
import com.monsanto.customerlink.core.service.facade.ValidateSkuPricesFacade;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@ContextConfiguration(locations = {"classpath:IncreaseATPServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class IncreaseATPServiceImpl_UT {

    @Autowired
    Mapper mapper;

    @Autowired
    private CropRepository cropRepository;

    @Autowired
    private PlantService plantService;

    @Autowired
    private CropService cropService;

    @Autowired
    private InventoryPlantPriorityHelper inventoryPlantPriorityHelper;

    @Autowired
    private PlantRepository plantRepository;

    @Autowired
    private InventoryFacade inventoryFacade;

    @Autowired
    private ValidateSkuPricesFacade validateSkuPricesFacade;

    @Autowired
    private IncreaseATPServiceImpl increaseATPService;

    @Autowired
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;

    @Autowired
    private InventoryHelper inventoryHelper;

    @Autowired
    private InventoryIncreaseHelper inventoryIncreaseHelper;

    @Autowired
    private SAPOrderService sapOrderService;

    @Autowired
    private NotificationSender mailNotificationSender;

    @Autowired
    private DistributorRepository distributorRepository;

    @Before
    public void before() {
        reset(mailNotificationSender, sapOrderService);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsNull() throws Exception {
        increaseATPService.increaseATPProcess(null, null, false);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsEmpty() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        increaseATPService.increaseATPProcess(null, atpOrder, false);

    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailIsEmpty() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        atpOrder.setDetail(new ArrayList<OrderDetailDTO>());
        increaseATPService.increaseATPProcess(null, atpOrder, false);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailNoEmpty_AndDistributorConfigIsNull() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(orderDetailDTO);
        atpOrder.setDetail(list);

        increaseATPService.increaseATPProcess(null, atpOrder, false);
    }

    @Test
    public void increaseOnATP_CottonOrSoybean_AfterValidationSKUS_NotHybridsAvailable() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // order after sku validations.
        OrderDTO orderAfterSkuValidations = mapper.map(atpOrder, OrderDTO.class);
        // detail list is empty, ie not hybrids available for increase process
        orderAfterSkuValidations.setDetail(new ArrayList<OrderDetailDTO>());

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(orderAfterSkuValidations);

        increaseATPService.increaseATPProcess(null, atpOrder, false);
    }

    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryNotFound() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");
        distributorConfigDTO.setDistributor(new DistributorDTO());
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setCropId(1l);
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);

        CropVO soybean = new CropVO();
        soybean.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        soybean.setCropId(2l);
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);
        when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(new DistributorVO());
        when(plantRepository.findByParameters(eq(cotton.getCropId()), Matchers.<String>any(), Matchers.<String>any())).thenReturn(getCottonPlants());
        when(plantRepository.findByParameters(eq(soybean.getCropId()), Matchers.<String>any(), Matchers.<String>any())).thenReturn(getCottonPlants());

        increaseATPService.increaseATPProcess(null, atpOrder, false);

        //verify(mailNotificationSender).send(NotificationType.MINIMUM_INVENTORY_MX01, null);
    }

    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryIsEmpty() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");
        distributorConfigDTO.setDistributor(new DistributorDTO());
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        CropVO soybean = new CropVO();
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);
        soybean.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);
        increaseATPService.increaseATPProcess(null, atpOrder, false);

        // for kangaroo hybrid send email
        //verify(mailNotificationSender).send(NotificationType.MINIMUM_INVENTORY_MX01, null);
    }

    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryNotEmpty_AvailableForAllHybrids() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(80L);

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));
        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(10L);

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");
        distributorConfigDTO.setDistributor(new DistributorDTO());
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        CropVO soybean = new CropVO();
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);
        soybean.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        MaterialDTO m11 = new MaterialDTO();
        m11.setUnrestqty(BigDecimal.valueOf(5));
        m11.setBatch("BATCH_MATERIAL_11");
        m11.setMaterial("SKU_MATERIAL_11");
        m11.setPlant("PLANT_MATERIAL_11");
        m11.setStoragelocation("STORAGE_LOCATION_MATERIAL_11");

        MaterialDTO m12 = new MaterialDTO();
        m12.setUnrestqty(BigDecimal.valueOf(6));
        m12.setBatch("BATCH_MATERIAL_12");
        m12.setMaterial("SKU_MATERIAL_12");
        m12.setPlant("PLANT_MATERIAL_12");
        m12.setStoragelocation("STORAGE_LOCATION_MATERIAL_12");

        MaterialDTO m13 = new MaterialDTO();
        m13.setUnrestqty(BigDecimal.valueOf(4));
        m13.setBatch("BATCH_MATERIAL_13");
        m13.setMaterial("SKU_MATERIAL_13");
        m13.setPlant("PLANT_MATERIAL_13");
        m13.setStoragelocation("STORAGE_LOCATION_MATERIAL_13");

        List<MaterialDTO> mlist11 = new ArrayList<MaterialDTO>();
        mlist11.add(m11);
        mlist11.add(m12);
        mlist11.add(m13);

        InventoryWithOutAlgorithmDTO inv11 = new InventoryWithOutAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setMaterials(mlist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m22 = new MaterialDTO();
        m22.setUnrestqty(BigDecimal.valueOf(20));
        m22.setBatch("BATCH_MATERIAL_21");
        m22.setMaterial("SKU_MATERIAL_21");
        m22.setPlant("PLANT_MATERIAL_21");
        m22.setStoragelocation("STORAGE_LOCATION_MATERIAL_21");

        MaterialDTO m23 = new MaterialDTO();
        m23.setUnrestqty(BigDecimal.valueOf(20));
        m23.setBatch("BATCH_MATERIAL_23");
        m23.setMaterial("SKU_MATERIAL_23");
        m23.setPlant("PLANT_MATERIAL_23");
        m23.setStoragelocation("STORAGE_LOCATION_MATERIAL_23");

        List<MaterialDTO> mlist22 = new ArrayList<MaterialDTO>();
        mlist22.add(m22);
        mlist22.add(m23);

        InventoryWithOutAlgorithmDTO inv22 = new InventoryWithOutAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setMaterials(mlist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m33 = new MaterialDTO();
        m33.setUnrestqty(BigDecimal.valueOf(20));
        m33.setBatch("BATCH_MATERIAL_31");
        m33.setMaterial("SKU_MATERIAL_31");
        m33.setPlant("PLANT_MATERIAL_31");
        m33.setStoragelocation("STORAGE_LOCATION_MATERIAL_31");

        List<MaterialDTO> mlist33 = new ArrayList<MaterialDTO>();
        mlist33.add(m33);

        InventoryWithOutAlgorithmDTO inv33 = new InventoryWithOutAlgorithmDTO();
        inv33.setHybrid("PUMA");
        inv33.setMaterials(mlist33);
        inventoryListInput.add(inv33);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);

        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        //verify(sapOrderService).postOrderWithoutAlgorithm(Matchers.<OrderDTO>any());
    }

    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryNotEmpty_AndForKangarooHybrid_ThereIsNotEnoughInventory() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(80L);

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));
        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(10L);

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("code");
        distributorConfigDTO.setDistributor(distributorDTO);


        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        CropVO soybean = new CropVO();
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);
        soybean.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        MaterialDTO m11 = new MaterialDTO();
        m11.setUnrestqty(BigDecimal.valueOf(1));
        m11.setBatch("BATCH_MATERIAL_11");
        m11.setMaterial("SKU_MATERIAL_11");
        m11.setPlant("PLANT_MATERIAL_11");
        m11.setStoragelocation("STORAGE_LOCATION_MATERIAL_11");

        MaterialDTO m12 = new MaterialDTO();
        m12.setUnrestqty(BigDecimal.valueOf(1));
        m12.setBatch("BATCH_MATERIAL_12");
        m12.setMaterial("SKU_MATERIAL_12");
        m12.setPlant("PLANT_MATERIAL_12");
        m12.setStoragelocation("STORAGE_LOCATION_MATERIAL_12");

        MaterialDTO m13 = new MaterialDTO();
        m13.setUnrestqty(BigDecimal.valueOf(1));
        m13.setBatch("BATCH_MATERIAL_13");
        m13.setMaterial("SKU_MATERIAL_13");
        m13.setPlant("PLANT_MATERIAL_13");
        m13.setStoragelocation("STORAGE_LOCATION_MATERIAL_13");

        List<MaterialDTO> mlist11 = new ArrayList<MaterialDTO>();
        mlist11.add(m11);
        mlist11.add(m12);
        mlist11.add(m13);

        InventoryWithOutAlgorithmDTO inv11 = new InventoryWithOutAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setMaterials(mlist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m22 = new MaterialDTO();
        m22.setUnrestqty(BigDecimal.valueOf(20));
        m22.setBatch("BATCH_MATERIAL_21");
        m22.setMaterial("SKU_MATERIAL_21");
        m22.setPlant("PLANT_MATERIAL_21");
        m22.setStoragelocation("STORAGE_LOCATION_MATERIAL_21");

        MaterialDTO m23 = new MaterialDTO();
        m23.setUnrestqty(BigDecimal.valueOf(20));
        m23.setBatch("BATCH_MATERIAL_23");
        m23.setMaterial("SKU_MATERIAL_23");
        m23.setPlant("PLANT_MATERIAL_23");
        m23.setStoragelocation("STORAGE_LOCATION_MATERIAL_23");

        List<MaterialDTO> mlist22 = new ArrayList<MaterialDTO>();
        mlist22.add(m22);
        mlist22.add(m23);

        InventoryWithOutAlgorithmDTO inv22 = new InventoryWithOutAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setMaterials(mlist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m33 = new MaterialDTO();
        m33.setUnrestqty(BigDecimal.valueOf(20));
        m33.setBatch("BATCH_MATERIAL_31");
        m33.setMaterial("SKU_MATERIAL_31");
        m33.setPlant("PLANT_MATERIAL_31");
        m33.setStoragelocation("STORAGE_LOCATION_MATERIAL_31");

        List<MaterialDTO> mlist33 = new ArrayList<MaterialDTO>();
        mlist33.add(m33);

        InventoryWithOutAlgorithmDTO inv33 = new InventoryWithOutAlgorithmDTO();
        inv33.setHybrid("PUMA");
        inv33.setMaterials(mlist33);
        inventoryListInput.add(inv33);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);

        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        verify(sapOrderService).postOrderWithoutAlgorithm(Matchers.<OrderDTO>any());

        // send emal for kangaroo
        //verify(mailNotificationSender).send(Matchers.any(Notification.class));
    }

    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryNotEmpty_And_ThereIsNotEnoughInventory_ForAllHybrids() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(80L);

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));
        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(10L);

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("code");
        distributorConfigDTO.setDistributor(distributorDTO);

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        CropVO soybean = new CropVO();
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);
        cotton.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        MaterialDTO m11 = new MaterialDTO();
        m11.setUnrestqty(BigDecimal.valueOf(1));
        m11.setBatch("BATCH_MATERIAL_11");
        m11.setMaterial("SKU_MATERIAL_11");
        m11.setPlant("PLANT_MATERIAL_11");
        m11.setStoragelocation("STORAGE_LOCATION_MATERIAL_11");

        MaterialDTO m12 = new MaterialDTO();
        m12.setUnrestqty(BigDecimal.valueOf(1));
        m12.setBatch("BATCH_MATERIAL_12");
        m12.setMaterial("SKU_MATERIAL_12");
        m12.setPlant("PLANT_MATERIAL_12");
        m12.setStoragelocation("STORAGE_LOCATION_MATERIAL_12");

        MaterialDTO m13 = new MaterialDTO();
        m13.setUnrestqty(BigDecimal.valueOf(1));
        m13.setBatch("BATCH_MATERIAL_13");
        m13.setMaterial("SKU_MATERIAL_13");
        m13.setPlant("PLANT_MATERIAL_13");
        m13.setStoragelocation("STORAGE_LOCATION_MATERIAL_13");

        List<MaterialDTO> mlist11 = new ArrayList<MaterialDTO>();
        mlist11.add(m11);
        mlist11.add(m12);
        mlist11.add(m13);

        InventoryWithOutAlgorithmDTO inv11 = new InventoryWithOutAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setMaterials(mlist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m22 = new MaterialDTO();
        m22.setUnrestqty(BigDecimal.valueOf(1));
        m22.setBatch("BATCH_MATERIAL_21");
        m22.setMaterial("SKU_MATERIAL_21");
        m22.setPlant("PLANT_MATERIAL_21");
        m22.setStoragelocation("STORAGE_LOCATION_MATERIAL_21");

        MaterialDTO m23 = new MaterialDTO();
        m23.setUnrestqty(BigDecimal.valueOf(1));
        m23.setBatch("BATCH_MATERIAL_23");
        m23.setMaterial("SKU_MATERIAL_23");
        m23.setPlant("PLANT_MATERIAL_23");
        m23.setStoragelocation("STORAGE_LOCATION_MATERIAL_23");

        List<MaterialDTO> mlist22 = new ArrayList<MaterialDTO>();
        mlist22.add(m22);
        mlist22.add(m23);

        InventoryWithOutAlgorithmDTO inv22 = new InventoryWithOutAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setMaterials(mlist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m33 = new MaterialDTO();
        m33.setUnrestqty(BigDecimal.valueOf(1));
        m33.setBatch("BATCH_MATERIAL_31");
        m33.setMaterial("SKU_MATERIAL_31");
        m33.setPlant("PLANT_MATERIAL_31");
        m33.setStoragelocation("STORAGE_LOCATION_MATERIAL_31");

        List<MaterialDTO> mlist33 = new ArrayList<MaterialDTO>();
        mlist33.add(m33);

        InventoryWithOutAlgorithmDTO inv33 = new InventoryWithOutAlgorithmDTO();
        inv33.setHybrid("PUMA");
        inv33.setMaterials(mlist33);
        inventoryListInput.add(inv33);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        // send emal for all hybrids
//        verify(mailNotificationSender).send(Matchers.any(Notification.class));
    }

    @Test
    public void increaseOnATP_ExcludesAndProcessNewHybrids_WhenExistNewHybrids() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");


        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(80L);

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));


        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(10L);

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("code");
        distributorConfigDTO.setDistributor(distributorDTO);

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        OrderDetailDTO dto3 = new OrderDetailDTO();
        ProductDTO p3 = new ProductDTO();
        p3.setProductCode("JAGUAR");
        p3.setFamilyCode("JAGUAR");
        p3.setTreatmentCode("0");
        p3.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto3.setProductDTO(p3);
        dto3.setQuantity(10);
        list.add(dto3);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);

        CropVO soybean = new CropVO();
        cotton.setCropCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        MaterialDTO m11 = new MaterialDTO();
        m11.setUnrestqty(BigDecimal.valueOf(5));
        m11.setBatch("BATCH_MATERIAL_11");
        m11.setMaterial("SKU_MATERIAL_11");
        m11.setPlant("PLANT_MATERIAL_11");
        m11.setStoragelocation("STORAGE_LOCATION_MATERIAL_11");

        MaterialDTO m12 = new MaterialDTO();
        m12.setUnrestqty(BigDecimal.valueOf(6));
        m12.setBatch("BATCH_MATERIAL_12");
        m12.setMaterial("SKU_MATERIAL_12");
        m12.setPlant("PLANT_MATERIAL_12");
        m12.setStoragelocation("STORAGE_LOCATION_MATERIAL_12");

        MaterialDTO m13 = new MaterialDTO();
        m13.setUnrestqty(BigDecimal.valueOf(4));
        m13.setBatch("BATCH_MATERIAL_13");
        m13.setMaterial("SKU_MATERIAL_13");
        m13.setPlant("PLANT_MATERIAL_13");
        m13.setStoragelocation("STORAGE_LOCATION_MATERIAL_13");

        List<MaterialDTO> mlist11 = new ArrayList<MaterialDTO>();
        mlist11.add(m11);
        mlist11.add(m12);
        mlist11.add(m13);

        InventoryWithOutAlgorithmDTO inv11 = new InventoryWithOutAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setMaterials(mlist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m22 = new MaterialDTO();
        m22.setUnrestqty(BigDecimal.valueOf(20));
        m22.setBatch("BATCH_MATERIAL_21");
        m22.setMaterial("SKU_MATERIAL_21");
        m22.setPlant("PLANT_MATERIAL_21");
        m22.setStoragelocation("STORAGE_LOCATION_MATERIAL_21");

        MaterialDTO m23 = new MaterialDTO();
        m23.setUnrestqty(BigDecimal.valueOf(20));
        m23.setBatch("BATCH_MATERIAL_23");
        m23.setMaterial("SKU_MATERIAL_23");
        m23.setPlant("PLANT_MATERIAL_23");
        m23.setStoragelocation("STORAGE_LOCATION_MATERIAL_23");

        List<MaterialDTO> mlist22 = new ArrayList<MaterialDTO>();
        mlist22.add(m22);
        mlist22.add(m23);

        InventoryWithOutAlgorithmDTO inv22 = new InventoryWithOutAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setMaterials(mlist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m33 = new MaterialDTO();
        m33.setUnrestqty(BigDecimal.valueOf(5));
        m33.setBatch("BATCH_MATERIAL_31");
        m33.setMaterial("SKU_MATERIAL_31");
        m33.setPlant("PLANT_MATERIAL_31");
        m33.setStoragelocation("STORAGE_LOCATION_MATERIAL_31");

        List<MaterialDTO> mlist33 = new ArrayList<MaterialDTO>();
        mlist33.add(m33);

        InventoryWithOutAlgorithmDTO inv33 = new InventoryWithOutAlgorithmDTO();
        inv33.setHybrid("PUMA");
        inv33.setMaterials(mlist33);
        inventoryListInput.add(inv33);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);


        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.excludesAndProcessNewHybrids(sapOrder, atpOrder);
    }

    @Test
    public void increaseOnATP_ExcludesAndProcessNewHybrids_WhenNotExistNewHybrids() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");
        sku1.setItemNumber(80L);

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");
        sku3.setItemNumber(30L);

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");
        sku4.setItemNumber(10L);

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SOYBEAN.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.COTTON.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO cotton = new CropVO();
        cotton.setSpecieCode("T");
        cotton.setSpecieClass("SG_COTTON");
        cotton.setSpecieType("001");
        cotton.setSpecieAlg(false);

        CropVO soybean = new CropVO();
        soybean.setSpecieCode("B");
        soybean.setSpecieClass("SG_SOYBEAM");
        soybean.setSpecieType("001");
        soybean.setSpecieAlg(false);

        when(cropService.obtainCropByCode(eq("GT010"))).thenReturn(cotton);
        when(cropService.obtainCropByCode(eq("GB010"))).thenReturn(soybean);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(cotton), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(soybean), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithOutAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithOutAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        MaterialDTO m11 = new MaterialDTO();
        m11.setUnrestqty(BigDecimal.valueOf(5));
        m11.setBatch("BATCH_MATERIAL_11");
        m11.setMaterial("SKU_MATERIAL_11");
        m11.setPlant("PLANT_MATERIAL_11");
        m11.setStoragelocation("STORAGE_LOCATION_MATERIAL_11");

        MaterialDTO m12 = new MaterialDTO();
        m12.setUnrestqty(BigDecimal.valueOf(6));
        m12.setBatch("BATCH_MATERIAL_12");
        m12.setMaterial("SKU_MATERIAL_12");
        m12.setPlant("PLANT_MATERIAL_12");
        m12.setStoragelocation("STORAGE_LOCATION_MATERIAL_12");

        MaterialDTO m13 = new MaterialDTO();
        m13.setUnrestqty(BigDecimal.valueOf(4));
        m13.setBatch("BATCH_MATERIAL_13");
        m13.setMaterial("SKU_MATERIAL_13");
        m13.setPlant("PLANT_MATERIAL_13");
        m13.setStoragelocation("STORAGE_LOCATION_MATERIAL_13");

        List<MaterialDTO> mlist11 = new ArrayList<MaterialDTO>();
        mlist11.add(m11);
        mlist11.add(m12);
        mlist11.add(m13);

        InventoryWithOutAlgorithmDTO inv11 = new InventoryWithOutAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setMaterials(mlist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m22 = new MaterialDTO();
        m22.setUnrestqty(BigDecimal.valueOf(20));
        m22.setBatch("BATCH_MATERIAL_21");
        m22.setMaterial("SKU_MATERIAL_21");
        m22.setPlant("PLANT_MATERIAL_21");
        m22.setStoragelocation("STORAGE_LOCATION_MATERIAL_21");

        MaterialDTO m23 = new MaterialDTO();
        m23.setUnrestqty(BigDecimal.valueOf(20));
        m23.setBatch("BATCH_MATERIAL_23");
        m23.setMaterial("SKU_MATERIAL_23");
        m23.setPlant("PLANT_MATERIAL_23");
        m23.setStoragelocation("STORAGE_LOCATION_MATERIAL_23");

        List<MaterialDTO> mlist22 = new ArrayList<MaterialDTO>();
        mlist22.add(m22);
        mlist22.add(m23);

        InventoryWithOutAlgorithmDTO inv22 = new InventoryWithOutAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setMaterials(mlist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        MaterialDTO m33 = new MaterialDTO();
        m33.setUnrestqty(BigDecimal.valueOf(5));
        m33.setBatch("BATCH_MATERIAL_31");
        m33.setMaterial("SKU_MATERIAL_31");
        m33.setPlant("PLANT_MATERIAL_31");
        m33.setStoragelocation("STORAGE_LOCATION_MATERIAL_31");

        List<MaterialDTO> mlist33 = new ArrayList<MaterialDTO>();
        mlist33.add(m33);

        InventoryWithOutAlgorithmDTO inv33 = new InventoryWithOutAlgorithmDTO();
        inv33.setHybrid("PUMA");
        inv33.setMaterials(mlist33);
        inventoryListInput.add(inv33);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITHOUT_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.excludesAndProcessNewHybrids(sapOrder, atpOrder);
    }


    ////////////////////////////////////////////////////// CORN OR SORGHUM /////////////////////////////////////////////
    @Test
    public void increaseOnATP_CornOrSorghum_AfterValidationSKUS_NotHybridsAvailable() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        // order after sku validations.
        OrderDTO orderAfterSkuValidations = mapper.map(atpOrder, OrderDTO.class);
        // detail list is empty, ie not hybrids available for increase process
        orderAfterSkuValidations.setDetail(new ArrayList<OrderDetailDTO>());

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(orderAfterSkuValidations);

        increaseATPService.increaseATPProcess(null, atpOrder, false);
    }

    @Test
    public void increaseOnATP_CornAndSorghum_When_InventoryNotFound() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO dist = new DistributorDTO();
        dist.setDistributorCode("DIST_CODE");

        distributorConfigDTO.setDistributor(dist);

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SORGHUM.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO corn = new CropVO();
        corn.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        corn.setSpecieCode("C");
        corn.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        corn.setSpecieClass("SG_CORN");
        corn.setSpecieType("001");
        corn.setSpecieAlg(true);

        CropVO sorghum = new CropVO();
        corn.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());

        sorghum.setSpecieCode("S");
        sorghum.setSpecieClass("SG_SORGHUM");
        sorghum.setSpecieType("001");
        sorghum.setSpecieAlg(true);

        when(cropService.obtainCropByCode(eq("GC010"))).thenReturn(corn);
        when(cropService.obtainCropByCode(eq("GS010"))).thenReturn(sorghum);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(corn), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(sorghum), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);
        increaseATPService.increaseATPProcess(null, atpOrder, false);


        //verify(mailNotificationSender).send(NotificationType.MINIMUM_INVENTORY_MX20, null);
    }

    @Test
    public void increaseOnATP_CornOrSorghum_When_InventoryIsEmpty() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        distributorConfigDTO.setDistributor(new DistributorDTO());
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SORGHUM.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO corn = new CropVO();
        corn.setSpecieCode("C");
        corn.setSpecieClass("SG_CORN");
        corn.setSpecieType("001");
        corn.setSpecieAlg(true);
        corn.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        CropVO sorghum = new CropVO();
        sorghum.setSpecieCode("S");
        sorghum.setSpecieClass("SG_SORGHUM");
        sorghum.setSpecieType("001");
        sorghum.setSpecieAlg(true);
        sorghum.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());
        when(cropService.obtainCropByCode(eq("GC010"))).thenReturn(corn);
        when(cropService.obtainCropByCode(eq("GS010"))).thenReturn(sorghum);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(corn), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(sorghum), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithAlgorithmDTO>();

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);
        increaseATPService.increaseATPProcess(null, atpOrder, false);

        //verify(mailNotificationSender).send(NotificationType.MINIMUM_INVENTORY_MX20, null);
    }


    @Test
    public void increaseOnATP_CornOrSorghum_When_InventoryNotEmpty_() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");


        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));
        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");
        distributorConfigDTO.setDistributor(new DistributorDTO());
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SORGHUM.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO corn = new CropVO();
        corn.setSpecieCode("C");
        corn.setSpecieClass("SG_CORN");
        corn.setSpecieType("001");
        corn.setSpecieAlg(true);
        corn.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        CropVO sorghum = new CropVO();
        sorghum.setSpecieCode("S");
        sorghum.setSpecieClass("SG_SORGHUM");
        sorghum.setSpecieType("001");
        sorghum.setSpecieAlg(true);
        sorghum.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());

        when(cropService.obtainCropByCode(eq("GC010"))).thenReturn(corn);
        when(cropService.obtainCropByCode(eq("GS010"))).thenReturn(sorghum);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(corn), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(sorghum), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        InventoryWithAlgorithmDTO i1 = new InventoryWithAlgorithmDTO();

        PlantWithAlgorithmDTO p11 = new PlantWithAlgorithmDTO();
        p11.setPlant("PLANT_11");
        p11.setUnrestqty(BigDecimal.valueOf(5));

        PlantWithAlgorithmDTO p12 = new PlantWithAlgorithmDTO();
        p12.setPlant("PLANT_12");
        p12.setUnrestqty(BigDecimal.valueOf(6));

        PlantWithAlgorithmDTO p13 = new PlantWithAlgorithmDTO();
        p13.setPlant("PLANT_13");
        p13.setUnrestqty(BigDecimal.valueOf(4));

        List<PlantWithAlgorithmDTO> plist11 = new ArrayList<PlantWithAlgorithmDTO>();
        plist11.add(p11);
        plist11.add(p12);
        plist11.add(p13);

        InventoryWithAlgorithmDTO inv11 = new InventoryWithAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setPlants(plist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p21 = new PlantWithAlgorithmDTO();
        p21.setPlant("PLANT_21");
        p21.setUnrestqty(BigDecimal.valueOf(20));

        PlantWithAlgorithmDTO p22 = new PlantWithAlgorithmDTO();
        p22.setPlant("PLANT_22");
        p22.setUnrestqty(BigDecimal.valueOf(20));

        List<PlantWithAlgorithmDTO> plist22 = new ArrayList<PlantWithAlgorithmDTO>();
        plist22.add(p22);
        plist22.add(p22);

        InventoryWithAlgorithmDTO inv22 = new InventoryWithAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setPlants(plist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p31 = new PlantWithAlgorithmDTO();
        p31.setPlant("PLANT_31");
        p31.setUnrestqty(BigDecimal.valueOf(20));


        List<PlantWithAlgorithmDTO> plist31 = new ArrayList<PlantWithAlgorithmDTO>();
        plist31.add(p31);

        InventoryWithAlgorithmDTO inv31 = new InventoryWithAlgorithmDTO();
        inv31.setHybrid("PUMA");
        inv31.setPlants(plist31);

        inventoryListInput.add(inv31);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);

        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        verify(sapOrderService).postOrderWithAlgorithm(Matchers.<OrderDTO>any());
    }

    @Test
    public void increaseOnATP_CornOrSorghum_When_InventoryNotEmpty_AndForKangarooHybrid_ThereIsNotEnoughInventory() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder(null);

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);  // sap order contains one unit of kangaroo
        sku1.setMaterial("SKU1");


        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));

        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("code");
        distributorConfigDTO.setDistributor(distributorDTO);

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SORGHUM.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO corn = new CropVO();
        corn.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        corn.setSpecieCode("C");
        corn.setSpecieClass("SG_CORN");
        corn.setSpecieType("001");
        corn.setSpecieAlg(true);

        CropVO sorghum = new CropVO();
        sorghum.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());
        sorghum.setSpecieCode("S");
        sorghum.setSpecieClass("SG_SORGHUM");
        sorghum.setSpecieType("001");
        sorghum.setSpecieAlg(true);

        when(cropService.obtainCropByCode(eq("GC010"))).thenReturn(corn);
        when(cropService.obtainCropByCode(eq("GS010"))).thenReturn(sorghum);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(corn), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(sorghum), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        InventoryWithAlgorithmDTO i1 = new InventoryWithAlgorithmDTO();

        PlantWithAlgorithmDTO p11 = new PlantWithAlgorithmDTO();
        p11.setPlant("PLANT_11");
        p11.setUnrestqty(BigDecimal.valueOf(1));

        PlantWithAlgorithmDTO p12 = new PlantWithAlgorithmDTO();
        p12.setPlant("PLANT_12");
        p12.setUnrestqty(BigDecimal.valueOf(1));

        PlantWithAlgorithmDTO p13 = new PlantWithAlgorithmDTO();
        p13.setPlant("PLANT_13");
        p13.setUnrestqty(BigDecimal.valueOf(1));

        //  in the inventory, the total is 3 for the hybrid kangaroo

        List<PlantWithAlgorithmDTO> plist11 = new ArrayList<PlantWithAlgorithmDTO>();
        plist11.add(p11);
        plist11.add(p12);
        plist11.add(p13);

        InventoryWithAlgorithmDTO inv11 = new InventoryWithAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setPlants(plist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p21 = new PlantWithAlgorithmDTO();
        p21.setPlant("PLANT_21");
        p21.setUnrestqty(BigDecimal.valueOf(20));

        PlantWithAlgorithmDTO p22 = new PlantWithAlgorithmDTO();
        p22.setPlant("PLANT_22");
        p22.setUnrestqty(BigDecimal.valueOf(20));

        List<PlantWithAlgorithmDTO> plist22 = new ArrayList<PlantWithAlgorithmDTO>();
        plist22.add(p22);
        plist22.add(p22);

        InventoryWithAlgorithmDTO inv22 = new InventoryWithAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setPlants(plist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p31 = new PlantWithAlgorithmDTO();
        p31.setPlant("PLANT_31");
        p31.setUnrestqty(BigDecimal.valueOf(20));


        List<PlantWithAlgorithmDTO> plist31 = new ArrayList<PlantWithAlgorithmDTO>();
        plist31.add(p31);

        InventoryWithAlgorithmDTO inv31 = new InventoryWithAlgorithmDTO();
        inv31.setHybrid("PUMA");
        inv31.setPlants(plist31);

        inventoryListInput.add(inv31);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        when(sapOrderService.postOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(sapOrderService.postOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrder);

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        verify(sapOrderService).postOrderWithAlgorithm(Matchers.<OrderDTO>any());

        // for kangaroo hybrid send email
        //verify(mailNotificationSender).send(Matchers.any(Notification.class));
    }


    @Test
    public void increaseOnATP_CottonAndSoybean_When_InventoryNotEmpty_AndForAllHybrids_ThereIsNotEnoughInventory() throws Exception {

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("123456789");

        ///////////////////////////////////////////
        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(1D);
        sku1.setMaterial("SKU1");


        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1}));

        ///////////////////////////////////////////
        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(1D);
        sku3.setMaterial("SKU3");

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("GORILA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));
        ///////////////////////////////////////////
        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(1D);
        sku4.setMaterial("SKU4");

        HybridDTO h4 = new HybridDTO();
        h4.setHybridCode("PUMA");
        h4.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));
        ///////////////////////////////////////////

        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h3);
        hybrids.add(h4);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setSubRegionCode("SUB_REG_1");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("code");
        distributorConfigDTO.setDistributor(distributorDTO);

        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        p.setFamilyCode("CANGURO");
        p.setTreatmentCode("0");
        p.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto.setProductDTO(p);
        dto.setQuantity(10);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        p1.setFamilyCode("GORILA");
        p1.setTreatmentCode("0");
        p1.setSubDivisionCode(SeedsCropCodeEnum.SORGHUM.getCode());
        dto1.setProductDTO(p1);
        dto1.setQuantity(10);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        p2.setFamilyCode("PUMA");
        p2.setTreatmentCode("0");
        p2.setSubDivisionCode(SeedsCropCodeEnum.CORN.getCode());
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        CropVO corn = new CropVO();
        corn.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        corn.setSpecieCode("C");
        corn.setSpecieClass("SG_CORN");
        corn.setSpecieType("001");
        corn.setSpecieAlg(true);

        CropVO sorghum = new CropVO();
        sorghum.setSpecieCode("S");
        sorghum.setSpecieClass("SG_SORGHUM");
        sorghum.setSpecieType("001");
        sorghum.setSpecieAlg(true);

        when(cropService.obtainCropByCode(eq("GC010"))).thenReturn(corn);
        when(cropService.obtainCropByCode(eq("GS010"))).thenReturn(sorghum);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXNTE");

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(corn), any(SubRegionVO.class))).thenReturn(getCottonPlants());
        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(eq(sorghum), any(SubRegionVO.class))).thenReturn(getCottonPlants());

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        List<InventoryWithAlgorithmDTO> inventoryListInput = new ArrayList<InventoryWithAlgorithmDTO>();


        /////////////// INVENTORY RESULT FOR CANGURO ///////////////////////////////////////////////////////////////////

        InventoryWithAlgorithmDTO i1 = new InventoryWithAlgorithmDTO();

        PlantWithAlgorithmDTO p11 = new PlantWithAlgorithmDTO();
        p11.setPlant("PLANT_11");
        p11.setUnrestqty(BigDecimal.valueOf(1));

        PlantWithAlgorithmDTO p12 = new PlantWithAlgorithmDTO();
        p12.setPlant("PLANT_12");
        p12.setUnrestqty(BigDecimal.valueOf(1));

        PlantWithAlgorithmDTO p13 = new PlantWithAlgorithmDTO();
        p13.setPlant("PLANT_13");
        p13.setUnrestqty(BigDecimal.valueOf(1));

        //  in the inventory, the total is 3 for the hybrid kangaroo

        List<PlantWithAlgorithmDTO> plist11 = new ArrayList<PlantWithAlgorithmDTO>();
        plist11.add(p11);
        plist11.add(p12);
        plist11.add(p13);

        InventoryWithAlgorithmDTO inv11 = new InventoryWithAlgorithmDTO();
        inv11.setHybrid("CANGURO");
        inv11.setPlants(plist11);

        inventoryListInput.add(inv11);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p21 = new PlantWithAlgorithmDTO();
        p21.setPlant("PLANT_21");
        p21.setUnrestqty(BigDecimal.valueOf(1));

        PlantWithAlgorithmDTO p22 = new PlantWithAlgorithmDTO();
        p22.setPlant("PLANT_22");
        p22.setUnrestqty(BigDecimal.valueOf(1));

        List<PlantWithAlgorithmDTO> plist22 = new ArrayList<PlantWithAlgorithmDTO>();
        plist22.add(p22);
        plist22.add(p22);

        InventoryWithAlgorithmDTO inv22 = new InventoryWithAlgorithmDTO();
        inv22.setHybrid("GORILA");
        inv22.setPlants(plist22);

        inventoryListInput.add(inv22);

        /////////////// INVENTORY RESULT FOR GORILA ////////////////////////////////////////////////////////////////////

        PlantWithAlgorithmDTO p31 = new PlantWithAlgorithmDTO();
        p31.setPlant("PLANT_31");
        p31.setUnrestqty(BigDecimal.valueOf(1));

        List<PlantWithAlgorithmDTO> plist31 = new ArrayList<PlantWithAlgorithmDTO>();
        plist31.add(p31);

        InventoryWithAlgorithmDTO inv31 = new InventoryWithAlgorithmDTO();
        inv31.setHybrid("PUMA");
        inv31.setPlants(plist31);

        inventoryListInput.add(inv31);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ALGORITHM, inventoryListInput);
        when(inventoryFacade.getInventory(anyListOf(InventoryInDTO.class))).thenReturn(inventoryListOutPut);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        when(validateSkuPricesFacade.validateSkuPrices(any(OrderDTO.class))).thenReturn(atpOrder);

        increaseATPService.increaseATPProcess(sapOrder, atpOrder, false);

        // for all hibrids send email, there is not enough inventory
        //verify(mailNotificationSender).send(Matchers.any(Notification.class));
    }

    private List<PlantVO> getCottonPlants() {

        List<PlantVO> plants = new ArrayList<PlantVO>();

        WarehouseVO w1 = new WarehouseVO();
        w1.setWarehouseCode("CWM1");

        WarehouseVO w2 = new WarehouseVO();
        w2.setWarehouseCode("A001");

        PlantVO p1 = new PlantVO();
        p1.setPlantCode("5528");
        p1.setWarehousesByPlantId(Arrays.asList(new WarehouseVO[]{w1}));

        PlantVO p2 = new PlantVO();
        p2.setPlantCode("6265");
        p2.setWarehousesByPlantId(Arrays.asList(new WarehouseVO[]{w2}));

        plants.add(p1);
        plants.add(p2);

        return plants;
    }

}