package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.IncreaseDecreaseATPHelper;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.exception.SapOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.persistence.repositories.CropRepository;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class IncreaseDecreaseATPHelperImpl_UT {

    @Mock
    private CropRepository cropRepository;

    @Mock
    private PlantRepository plantRepository;

    @Mock
    private DistributorRepository distributorRepository;

    @Mock
    private IncreaseDecreaseATPHelper unit;

     @Before
    public void before() {
        reset(cropRepository, plantRepository, distributorRepository);
        unit = new IncreaseDecreaseATPHelperImpl();
    }

    @Test
    public void obtainHybridsToIncreaseOrDecrease_WhenGroupByHybridIsEmpty() throws Exception {
        OrderDTO atpOrderDTO = new OrderDTO();
        atpOrderDTO.setDetail(new ArrayList<OrderDetailDTO>());
        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        List<OrderDetailDTO> list = unit.obtainHybridsToIncreaseOrDecrease(sapOrderDTO,atpOrderDTO,true);
        assertTrue(list.isEmpty());
    }

    @Test
    public void obtainHybridsToIncreaseOrDecrease_WhenGroupByHybridIsNotEmpty() throws Exception {

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

        IncreaseDecreaseATPHelper aSpy = Mockito.spy(unit);
        Mockito.doReturn(false).when(aSpy).existHybridsToProcess(atpOrder);


        Map<String, List<MaterialDTO>> groupByHybrid = new HashMap<String, List<MaterialDTO>>();
        groupByHybrid.put("HYBRID", new ArrayList<MaterialDTO>());
        Mockito.doReturn(groupByHybrid).when(aSpy).groupByHybrid(anyList());

        List<OrderDetailDTO> listDetails = aSpy.obtainHybridsToIncreaseOrDecrease(sapOrderDTO,atpOrder,true);
        assertTrue(!listDetails.isEmpty());
    }

    @Test
    public void groupByHybrid_WhenListOfHybridsIsNull() throws Exception {
        Map<String, List<MaterialDTO>> group = unit.groupByHybrid(null);
        assertTrue(group.isEmpty());
    }

    @Test
    public void groupByHybrid_WhenListOfHybridsIsEmpty() throws Exception {
        Map<String, List<MaterialDTO>> group = unit.groupByHybrid(new ArrayList<HybridDTO>());
        assertTrue(group.isEmpty());
    }

    @Test
    public void groupByHybrid() throws Exception {

        HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("HYBRID_1");

        MaterialDTO mat = new MaterialDTO();
        mat.setReq_qty(10D);
        List<MaterialDTO> m = new ArrayList<MaterialDTO>();
        m.add(mat);

        hybridDTO1.setSkus(m);

        HybridDTO hybridDTO2 = new HybridDTO();
        hybridDTO2.setHybridCode("HYBRID_2");
        hybridDTO2.setSkus(null);

        HybridDTO hybridDTO3 = new HybridDTO();
        hybridDTO3.setHybridCode("");

        ArrayList<HybridDTO> listOfHybrids = new ArrayList<HybridDTO>();
        listOfHybrids.add(hybridDTO1);
        listOfHybrids.add(hybridDTO2);
        listOfHybrids.add(hybridDTO3);

        Map<String, List<MaterialDTO>> group = unit.groupByHybrid(listOfHybrids);
        assertTrue(!group.isEmpty());
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsNull() throws Exception {
        unit.validateInputParameters(null);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsEmpty() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        unit.validateInputParameters(atpOrder);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailIsEmpty() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        atpOrder.setDetail(new ArrayList<OrderDetailDTO>());
        unit.validateInputParameters(atpOrder);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailNoEmpty_AndDistributorConfigIsNull() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(orderDetailDTO);
        atpOrder.setDetail(list);

        unit.validateInputParameters(atpOrder);
    }

    @Test
    public void exceptionWhen_OrderDTONotEmpty_AndDetailNoEmpty_AndDistributorConfigIsNotNull() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(orderDetailDTO);
        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        unit.validateInputParameters(atpOrder);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsNull_() throws Exception {
        unit.validateInputParameters(null,null);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsEmpty_() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        unit.validateInputParameters(null,atpOrder);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailIsEmpty_() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();
        atpOrder.setDetail(new ArrayList<OrderDetailDTO>());
        unit.validateInputParameters(null,atpOrder);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailNoEmpty_AndDistributorConfigIsNull_() throws Exception {
        // order detail empty
        OrderDTO atpOrder = new OrderDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();
        list.add(orderDetailDTO);
        atpOrder.setDetail(list);

        unit.validateInputParameters(null,atpOrder);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsNull_SapOrder() throws Exception {
        unit.validateInputParameters(null,null);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTOIsEmpty_SapOrder() throws Exception {
        SAPOrderDTO s = new SAPOrderDTO();
        unit.validateInputParameters(s,null);
    }

    @Test(expected = SapOrderMissingArgumentsException.class)
    public void exceptionWhen_OrderDTONotEmpty_AndDetailIsEmpty_SapOrder() throws Exception {
        SAPOrderDTO s = new SAPOrderDTO();
        s.setHybrids(new ArrayList<HybridDTO>());
        unit.validateInputParameters(s,null);
    }

    /*
    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenOrderIsNull() throws Exception {
        unit.validateInputParametersForAgrochemicals(null);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenDetailIsNull() throws Exception {
        unit.validateInputParametersForAgrochemicals(new OrderDTO());
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenDetailIsEmpty() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(new ArrayList<OrderDetailDTO>());
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenDistributorConfigIsNull() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        detail.add(orderDetailDTO);
        orderDTO.setDetail(detail);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenProductIsNull() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        detail.add(orderDetailDTO);
        orderDTO.setDetail(detail);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void validateInputParametersForAgrochemicals_WhenListOfSkuIsNull() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        detail.add(orderDetailDTO);
        orderDTO.setDetail(detail);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        unit.validateInputParametersForAgrochemicals(orderDTO);
    }
    */

    @Test
    public void validateInputParametersForAgrochemicals() throws Exception {

        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        ProductDTO productDTO = new ProductDTO();
        orderDetailDTO.setProductDTO(productDTO);
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        detail.add(orderDetailDTO);
        orderDTO.setDetail(detail);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        List<HybridDTO> list = new ArrayList<HybridDTO>();
        list.add(new HybridDTO());
        sapOrderDTO.setHybrids(list);

        unit.validateInputParameters(sapOrderDTO,orderDTO);
    }

    @Test
    public void retrievesHybridsToDecrease() throws Exception {
        final HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("H1");
        hybridDTO1.setTotalQty(20);

        final HybridDTO hybridDTO2 = new HybridDTO();
        hybridDTO2.setHybridCode("H2");
        hybridDTO2.setTotalQty(20);

        final HybridDTO hybridDTO3 = new HybridDTO();
        hybridDTO3.setHybridCode("H3");
        hybridDTO3.setTotalQty(0);

        final HybridDTO hybridDTO4 = new HybridDTO();
        hybridDTO4.setHybridCode("H4");
        hybridDTO4.setTotalQty(10);

        final List<HybridDTO> withoutSoakTestSAPOrderDetail = new ArrayList<HybridDTO>();
        withoutSoakTestSAPOrderDetail.add(hybridDTO1);
        withoutSoakTestSAPOrderDetail.add(hybridDTO2);
        withoutSoakTestSAPOrderDetail.add(hybridDTO3);
        withoutSoakTestSAPOrderDetail.add(hybridDTO4);

        final SAPOrderDTO withoutSoakTestSAPOrder = new SAPOrderDTO();
        withoutSoakTestSAPOrder.setHybrids(withoutSoakTestSAPOrderDetail);

        final HybridDTO hybridDTO5 = new HybridDTO();
        hybridDTO5.setHybridCode("H1");
        hybridDTO5.setTotalQty(10);

        final HybridDTO hybridDTO6 = new HybridDTO();
        hybridDTO6.setHybridCode("H2");
        hybridDTO6.setTotalQty(0);

        final HybridDTO hybridDTO7 = new HybridDTO();
        hybridDTO7.setHybridCode("H3");
        hybridDTO7.setTotalQty(10);

        final HybridDTO hybridDTO8 = new HybridDTO();
        hybridDTO8.setHybridCode("H5");
        hybridDTO8.setTotalQty(10);

        final List<HybridDTO> normalSeasonSAPOrderDetail = new ArrayList<HybridDTO>();
        normalSeasonSAPOrderDetail.add(hybridDTO5);
        normalSeasonSAPOrderDetail.add(hybridDTO6);
        normalSeasonSAPOrderDetail.add(hybridDTO7);
        normalSeasonSAPOrderDetail.add(hybridDTO8);

        final SAPOrderDTO normalSeasonSAPOrder = new SAPOrderDTO();
        normalSeasonSAPOrder.setHybrids(normalSeasonSAPOrderDetail);
        normalSeasonSAPOrder.setWithoutSoakTestOrder(withoutSoakTestSAPOrder);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("H2");

        final ProductDTO productDTO3 = new ProductDTO();
        productDTO3.setProductCode("H3");

        final ProductDTO productDTO4 = new ProductDTO();
        productDTO4.setProductCode("H4");

        final ProductDTO productDTO5 = new ProductDTO();
        productDTO5.setProductCode("H5");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(10);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(15);

        final OrderDetailDTO orderDetailDTO3 = new OrderDetailDTO();
        orderDetailDTO3.setProductDTO(productDTO3);
        orderDetailDTO3.setQuantity(5);

        final OrderDetailDTO orderDetailDTO4 = new OrderDetailDTO();
        orderDetailDTO4.setProductDTO(productDTO4);
        orderDetailDTO4.setQuantity(5);

        final OrderDetailDTO orderDetailDTO5 = new OrderDetailDTO();
        orderDetailDTO5.setProductDTO(productDTO5);
        orderDetailDTO5.setQuantity(5);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);
        orderDetailDTOList.add(orderDetailDTO3);
        orderDetailDTOList.add(orderDetailDTO4);
        orderDetailDTOList.add(orderDetailDTO5);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        List<OrderDetailDTO> hybridsToDecrease = unit.obtainHybridsToIncreaseOrDecrease(normalSeasonSAPOrder, orderDTO, false);
        assertThat(hybridsToDecrease, is(notNullValue()));
        assertThat(hybridsToDecrease.size(), is(5));
        assertThat(hybridsToDecrease.get(0).getQuantity(), is(20D));
        assertThat(hybridsToDecrease.get(1).getQuantity(), is(5D));
        assertThat(hybridsToDecrease.get(2).getQuantity(), is(5D));
        assertThat(hybridsToDecrease.get(3).getQuantity(), is(5D));
        assertThat(hybridsToDecrease.get(4).getQuantity(), is(5D));
    }

    @Test
    public void retrievesHybridsToIncrease() throws Exception {
        final HybridDTO hybridDTO1 = new HybridDTO();
        hybridDTO1.setHybridCode("H1");
        hybridDTO1.setTotalQty(20);

        final HybridDTO hybridDTO2 = new HybridDTO();
        hybridDTO2.setHybridCode("H2");
        hybridDTO2.setTotalQty(20);

        final HybridDTO hybridDTO3 = new HybridDTO();
        hybridDTO3.setHybridCode("H3");
        hybridDTO3.setTotalQty(0);

        final HybridDTO hybridDTO4 = new HybridDTO();
        hybridDTO4.setHybridCode("H4");
        hybridDTO4.setTotalQty(10);

        final List<HybridDTO> withoutSoakTestSAPOrderDetail = new ArrayList<HybridDTO>();
        withoutSoakTestSAPOrderDetail.add(hybridDTO1);
        withoutSoakTestSAPOrderDetail.add(hybridDTO2);
        withoutSoakTestSAPOrderDetail.add(hybridDTO3);
        withoutSoakTestSAPOrderDetail.add(hybridDTO4);

        final SAPOrderDTO withoutSoakTestSAPOrder = new SAPOrderDTO();
        withoutSoakTestSAPOrder.setHybrids(withoutSoakTestSAPOrderDetail);

        final HybridDTO hybridDTO5 = new HybridDTO();
        hybridDTO5.setHybridCode("H1");
        hybridDTO5.setTotalQty(10);

        final HybridDTO hybridDTO6 = new HybridDTO();
        hybridDTO6.setHybridCode("H2");
        hybridDTO6.setTotalQty(0);

        final HybridDTO hybridDTO7 = new HybridDTO();
        hybridDTO7.setHybridCode("H3");
        hybridDTO7.setTotalQty(10);

        final HybridDTO hybridDTO8 = new HybridDTO();
        hybridDTO8.setHybridCode("H5");
        hybridDTO8.setTotalQty(10);

        final List<HybridDTO> normalSeasonSAPOrderDetail = new ArrayList<HybridDTO>();
        normalSeasonSAPOrderDetail.add(hybridDTO5);
        normalSeasonSAPOrderDetail.add(hybridDTO6);
        normalSeasonSAPOrderDetail.add(hybridDTO7);
        normalSeasonSAPOrderDetail.add(hybridDTO8);

        final SAPOrderDTO normalSeasonSAPOrder = new SAPOrderDTO();
        normalSeasonSAPOrder.setHybrids(normalSeasonSAPOrderDetail);
        normalSeasonSAPOrder.setWithoutSoakTestOrder(withoutSoakTestSAPOrder);

        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("H1");

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("H2");

        final ProductDTO productDTO3 = new ProductDTO();
        productDTO3.setProductCode("H3");

        final ProductDTO productDTO4 = new ProductDTO();
        productDTO4.setProductCode("H4");

        final ProductDTO productDTO5 = new ProductDTO();
        productDTO5.setProductCode("H5");

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(40);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(25);

        final OrderDetailDTO orderDetailDTO3 = new OrderDetailDTO();
        orderDetailDTO3.setProductDTO(productDTO3);
        orderDetailDTO3.setQuantity(10);

        final OrderDetailDTO orderDetailDTO4 = new OrderDetailDTO();
        orderDetailDTO4.setProductDTO(productDTO4);
        orderDetailDTO4.setQuantity(0);

        final OrderDetailDTO orderDetailDTO5 = new OrderDetailDTO();
        orderDetailDTO5.setProductDTO(productDTO5);
        orderDetailDTO5.setQuantity(0);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);
        orderDetailDTOList.add(orderDetailDTO3);
        orderDetailDTOList.add(orderDetailDTO4);
        orderDetailDTOList.add(orderDetailDTO5);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        List<OrderDetailDTO> hybridsToDecrease = unit.obtainHybridsToIncreaseOrDecrease(normalSeasonSAPOrder, orderDTO, true);
        assertThat(hybridsToDecrease, is(notNullValue()));
        assertThat(hybridsToDecrease.size(), is(2));
        assertThat(hybridsToDecrease.get(0).getQuantity(), is(10D));
        assertThat(hybridsToDecrease.get(1).getQuantity(), is(5D));
    }

    @Test
    public void retrieveEmptyListWhenOrderDTOIsEmpty() throws Exception {
        HybridDTO hybridDTO = new HybridDTO();

        List<HybridDTO> hybridDTOList = new ArrayList<HybridDTO>();
        hybridDTOList.add(hybridDTO);

        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.setHybrids(hybridDTOList);

        OrderDTO orderDTO = new OrderDTO();

        List<OrderDetailDTO> hybridsToDecrease = unit.obtainHybridsToIncreaseOrDecrease(sapOrderDTO, orderDTO, true);
        assertThat(hybridsToDecrease, is(notNullValue()));
        assertThat(hybridsToDecrease.size(), is(0));
    }
}