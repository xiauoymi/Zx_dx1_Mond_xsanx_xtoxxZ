package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DecreaseATPService;
import com.monsanto.customerlink.core.service.IncreaseATPService;
import com.monsanto.customerlink.core.service.IncreaseDecreaseATPHelper;
import com.monsanto.customerlink.core.service.SAPOrderService;
import com.monsanto.customerlink.core.service.exception.AtpOrderMissingArgumentsException;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

import static org.mockito.Mockito.*;

@ContextConfiguration(locations={"classpath:IncreaseDecreaseATPServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class IncreaseDecreaseATPServiceImpl_UT {

    @Autowired
    Mapper mapper;

    @Autowired
    private IncreaseATPService increaseATPService;

    @Autowired
    private DecreaseATPService decreaseATPService;

    @Autowired
    private SAPOrderService sapOrderService;

    @Autowired
    private IncreaseDecreaseATPServiceImpl increaseDecreaseATPService;

    @Autowired
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;

    @Before
    public void before() {
        reset(increaseDecreaseATPHelper, sapOrderService, decreaseATPService, increaseATPService);
    }

    @Test(expected = AtpOrderMissingArgumentsException.class)
    public void exceptionWhen_InputParametersAreInvalid() throws Exception{
        OrderDTO orderDTO = new OrderDTO();
        doThrow(new AtpOrderMissingArgumentsException( new Object[]{orderDTO} )).when(increaseDecreaseATPHelper).validateInputParameters(eq(orderDTO));
        increaseDecreaseATPService.runProcessChangeInATP(orderDTO);
    }

    @Test
    public void runProcessChangeInATP() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("idSapOrder");

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(10D);
        sku1.setMaterial("SKU1");

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(10D);
        sku2.setMaterial("SKU2");

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2}));

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(15D);
        sku3.setMaterial("SKU3");

        HybridDTO h2 = new HybridDTO();
        h2.setHybridCode("GORILA");
        h2.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(10D);
        sku4.setMaterial("SKU4");

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("PUMA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));



        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h2);
        hybrids.add(h3);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when( increaseATPService.excludesAndProcessNewHybrids(Matchers.<SAPOrderDTO>any(),Matchers.<OrderDTO>any())).thenReturn(atpOrder);
        when(increaseDecreaseATPHelper.existHybridsToProcess(eq(atpOrder))).thenReturn(true);

        increaseDecreaseATPService.runProcessChangeInATP(atpOrder);

        verify(sapOrderService).retrieveOrder(Matchers.<OrderDTO>any());
        verify(increaseATPService).excludesAndProcessNewHybrids(Matchers.<SAPOrderDTO>any(), Matchers.<OrderDTO>any());
        verify(increaseDecreaseATPHelper).existHybridsToProcess(atpOrder);
        verify(increaseATPService).increaseATPProcess(eq(sapOrder), eq(atpOrder), eq(false));
        verify(decreaseATPService).decreaseATPProcess(Matchers.<SAPOrderDTO>any(), Matchers.<OrderDTO>any());
    }

    @Test
    public void increaseOnATP_When_ExistHybridsToProcess_ReturnFalse() throws Exception{

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setSalesorder("idSapOrder");

        MaterialDTO sku1 = new MaterialDTO();
        sku1.setReq_qty(10D);
        sku1.setMaterial("SKU1");

        MaterialDTO sku2 = new MaterialDTO();
        sku2.setReq_qty(10D);
        sku2.setMaterial("SKU2");

        HybridDTO h1 = new HybridDTO();
        h1.setHybridCode("CANGURO");
        h1.setSkus(Arrays.asList(new MaterialDTO[]{sku1, sku2}));

        MaterialDTO sku3 = new MaterialDTO();
        sku3.setReq_qty(15D);
        sku3.setMaterial("SKU3");

        HybridDTO h2 = new HybridDTO();
        h2.setHybridCode("GORILA");
        h2.setSkus(Arrays.asList(new MaterialDTO[]{sku3}));

        MaterialDTO sku4 = new MaterialDTO();
        sku4.setReq_qty(10D);
        sku4.setMaterial("SKU4");

        HybridDTO h3 = new HybridDTO();
        h3.setHybridCode("PUMA");
        h3.setSkus(Arrays.asList(new MaterialDTO[]{sku4}));



        List<HybridDTO> hybrids = new ArrayList<HybridDTO>();
        hybrids.add(h1);
        hybrids.add(h2);
        hybrids.add(h3);

        sapOrder.setHybrids(hybrids);

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(sapOrder);
        when(increaseATPService.excludesAndProcessNewHybrids(Matchers.<SAPOrderDTO>any(),Matchers.<OrderDTO>any())).thenReturn(atpOrder);
        when(increaseDecreaseATPHelper.existHybridsToProcess(eq(atpOrder))).thenReturn(false);

        increaseDecreaseATPService.runProcessChangeInATP(atpOrder);

        verify(sapOrderService).retrieveOrder(Matchers.<OrderDTO>any());
        verify(increaseATPService).excludesAndProcessNewHybrids(Matchers.<SAPOrderDTO>any(), Matchers.<OrderDTO>any());
        verify(increaseDecreaseATPHelper).existHybridsToProcess(atpOrder);
    }

    @Test
    public void increaseOnATP_When_WhenSapOrderIsNull() throws Exception{

        OrderDTO atpOrder = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("CANGURO");
        dto.setProductDTO(p);
        dto.setQuantity(50);
        list.add(dto);

        OrderDetailDTO dto1 = new OrderDetailDTO();
        ProductDTO p1 = new ProductDTO();
        p1.setProductCode("GORILA");
        dto1.setProductDTO(p1);
        dto1.setQuantity(50);
        list.add(dto1);

        OrderDetailDTO dto2 = new OrderDetailDTO();
        ProductDTO p2 = new ProductDTO();
        p2.setProductCode("PUMA");
        dto2.setProductDTO(p2);
        dto2.setQuantity(10);
        list.add(dto2);

        atpOrder.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        atpOrder.setDistributorConfigDTO(distributorConfigDTO);

        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(null);

        increaseDecreaseATPService.runProcessChangeInATP(atpOrder);

        verify(sapOrderService).retrieveOrder(Matchers.<OrderDTO>any());
        verify(increaseATPService).increaseATPProcess(Matchers.<SAPOrderDTO>any(),eq(atpOrder),eq(true));
    }

    /*
    @Test
    public void runProcessAgrochemicalsOrder_WhenExistSapOrder() throws Exception{

        OrderDTO orderDTO = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("AGROCHEMICAL");
        dto.setProductDTO(p);
        list.add(dto);

        orderDTO.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());

        increaseDecreaseATPService.runProcessAgrochemicalsOrder(orderDTO);

        verify(sapOrderService).retrieveOrder(Matchers.<OrderDTO>any());
    }

    @Test
    public void runProcessAgrochemicalsOrder_WhenNotExistSapOrder() throws Exception{

        OrderDTO orderDTO = new OrderDTO();
        List<OrderDetailDTO> list = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO dto = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("AGROCHEMICAL");
        dto.setProductDTO(p);
        list.add(dto);

        orderDTO.setDetail(list);

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(null);

        increaseDecreaseATPService.runProcessAgrochemicalsOrder(orderDTO);

        verify(sapOrderService).retrieveOrder(Matchers.<OrderDTO>any());
        verify(increaseATPService).processingAgrochemicalsOrder(eq(orderDTO));
    }
    */

}