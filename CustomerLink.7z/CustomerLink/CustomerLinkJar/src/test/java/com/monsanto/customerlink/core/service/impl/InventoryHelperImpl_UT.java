package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.InventoryHelper;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.facade.dto.InventoryInDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Mockito.reset;

@RunWith(MockitoJUnitRunner.class)
public class InventoryHelperImpl_UT {

    @Mock
    private CropService cropService;
    @Mock
    private PlantService plantService;

    @Mock
    private MailUtilService mailUtilService;
    @Mock
    private NotificationSender mailNotificationSender;

    private InventoryHelper unit;


    @Before
    public void before() {
        reset(cropService,plantService,mailUtilService,mailNotificationSender);
        unit = new InventoryHelperImpl(cropService,plantService,mailUtilService,mailNotificationSender);
    }

    @Test
    public void sendNotificationOfInsufficientInventory_WhenInventoryListIsEmpty() throws Exception {

        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();
        details.add(new OrderDetailDTO());

        InventoryHelper aSpy = Mockito.spy(unit);
        Mockito.doReturn(new ArrayList<InventoryInDTO>()).when(aSpy).createRequestInventory(Matchers.anyList(),any(DistributorConfigDTO.class));

        aSpy.sendNotificationOfInsufficientInventory(details, new DistributorConfigDTO(),true, new ArrayList<ErrorOrderDTO>());
    }

    @Test
    public void sendNotificationOfInsufficientInventory_CornOrSorghumWhenInventoryListIsNotEmpty() throws Exception {

        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO od = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("PRODUCT_CODE");
        od.setProductDTO(p);
        details.add(od);

        InventoryHelperImpl aSpy = (InventoryHelperImpl) Mockito.spy(unit);

        ArrayList<InventoryInDTO> inventory = new ArrayList<InventoryInDTO>();
        InventoryInDTO i = new InventoryInDTO();
        i.setHybrid("PRODUCT_CODE");
        inventory.add(i);

        Mockito.doReturn(inventory).when(aSpy).createRequestInventory(Matchers.anyList(),any(DistributorConfigDTO.class));
        Mockito.doNothing().when(aSpy).sendMessage(any(NotificationType.class),any(DistributorConfigDTO.class),anyMap());

        aSpy.sendNotificationOfInsufficientInventory(details, new DistributorConfigDTO(),true, new ArrayList<ErrorOrderDTO>());
    }

    @Test
    public void sendNotificationOfInsufficientInventory_CottonOrSoybeanWhenInventoryListIsNotEmpty() throws Exception {

        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();

        OrderDetailDTO od = new OrderDetailDTO();
        ProductDTO p = new ProductDTO();
        p.setProductCode("PRODUCT_CODE");
        od.setProductDTO(p);
        details.add(od);

        InventoryHelperImpl aSpy = (InventoryHelperImpl) Mockito.spy(unit);

        ArrayList<InventoryInDTO> inventory = new ArrayList<InventoryInDTO>();
        InventoryInDTO i = new InventoryInDTO();
        i.setHybrid("PRODUCT_CODE");
        inventory.add(i);

        Mockito.doReturn(inventory).when(aSpy).createRequestInventory(Matchers.anyList(),any(DistributorConfigDTO.class));
        Mockito.doNothing().when(aSpy).sendMessage(any(NotificationType.class),any(DistributorConfigDTO.class),anyMap());

        aSpy.sendNotificationOfInsufficientInventory(details, new DistributorConfigDTO(),false, new ArrayList<ErrorOrderDTO>());
    }

}