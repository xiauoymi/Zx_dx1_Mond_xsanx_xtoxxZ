package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.InventoryPlantPriorityHelper;
import com.monsanto.customerlink.core.service.PONumberService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.facade.dto.InventoryWithAlgorithmDTO;
import com.monsanto.customerlink.core.service.facade.dto.PlantWithAlgorithmDTO;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.persistence.entities.SubRegionVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InventoryPlantPriorityHelperImpl_UT {

    @Mock
    private PlantService plantService;

    @Mock
    private InventoryPlantPriorityHelper unit;

    @Before
    public void before() {
        reset(plantService);
        unit = new InventoryPlantPriorityHelperImpl(plantService);
    }

    @Test
    public void obtainPlantsAccordingToCrop_Corn() throws Exception{

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();

        PlantVO cornPlant = new PlantVO();
        cornPlant.setPriority(1L);
        cornPlant.setPlantCode("PLANT_CODE_1");
        List<PlantVO> cornPlants = new ArrayList<PlantVO>();
        cornPlants.add(cornPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.CORN.getCode()), eq(distributorConfigDTO))).thenReturn(cornPlants);

        PlantVO sorghumPlant = new PlantVO();
        sorghumPlant.setPriority(2L);
        sorghumPlant.setPlantCode("PLANT_CODE_2");
        List<PlantVO> sorghumPlants = new ArrayList<PlantVO>();
        sorghumPlants.add(sorghumPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.SORGHUM.getCode()), eq(distributorConfigDTO))).thenReturn(sorghumPlants);


        InventoryWithAlgorithmDTO inv = new InventoryWithAlgorithmDTO();
        inv.setHybrid("H1");

        PlantWithAlgorithmDTO pwa = new PlantWithAlgorithmDTO();
        pwa.setPlant("PLANT_CODE_1");

        List<PlantWithAlgorithmDTO> plantWithAlgorithmDTOs = new ArrayList<PlantWithAlgorithmDTO>();
        plantWithAlgorithmDTOs.add(pwa);

        inv.setPlants(plantWithAlgorithmDTOs);

        InventoryWithAlgorithmDTO inv2 = new InventoryWithAlgorithmDTO();
        inv2.setHybrid("H2");


        List<InventoryWithAlgorithmDTO> inventory = new ArrayList<InventoryWithAlgorithmDTO>();
        inventory.add(inv);
        inventory.add(inv2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("H1");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        OrderDetailDTO detail = new OrderDetailDTO();
        detail.setProductDTO(productDTO);

        unit.assignPlantPriorityPerHybridCornOrSorghum(detail,distributorConfigDTO,inventory);
    }

    @Test
    public void obtainPlantsAccordingToCrop_Sorghum() throws Exception{

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();

        PlantVO cornPlant = new PlantVO();
        cornPlant.setPriority(1L);
        cornPlant.setPlantCode("PLANT_CODE_1");
        List<PlantVO> cornPlants = new ArrayList<PlantVO>();
        cornPlants.add(cornPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.CORN.getCode()), eq(distributorConfigDTO))).thenReturn(cornPlants);

        PlantVO sorghumPlant = new PlantVO();
        sorghumPlant.setPriority(2L);
        sorghumPlant.setPlantCode("PLANT_CODE_2");
        List<PlantVO> sorghumPlants = new ArrayList<PlantVO>();
        sorghumPlants.add(sorghumPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.SORGHUM.getCode()), eq(distributorConfigDTO))).thenReturn(sorghumPlants);


        InventoryWithAlgorithmDTO inv = new InventoryWithAlgorithmDTO();
        inv.setHybrid("H1");

        PlantWithAlgorithmDTO pwa = new PlantWithAlgorithmDTO();
        pwa.setPlant("PLANT_CODE_1");

        List<PlantWithAlgorithmDTO> plantWithAlgorithmDTOs = new ArrayList<PlantWithAlgorithmDTO>();
        plantWithAlgorithmDTOs.add(pwa);

        inv.setPlants(plantWithAlgorithmDTOs);

        InventoryWithAlgorithmDTO inv2 = new InventoryWithAlgorithmDTO();
        inv2.setHybrid("H2");


        List<InventoryWithAlgorithmDTO> inventory = new ArrayList<InventoryWithAlgorithmDTO>();
        inventory.add(inv);
        inventory.add(inv2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("H1");
        productDTO.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());

        OrderDetailDTO detail = new OrderDetailDTO();
        detail.setProductDTO(productDTO);

        unit.assignPlantPriorityPerHybridCornOrSorghum(detail,distributorConfigDTO,inventory);
    }

    @Test
    public void obtainPlantsAccordingToCrop_SorghumDifferentPlants() throws Exception{

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();

        PlantVO cornPlant = new PlantVO();
        cornPlant.setPriority(1L);
        cornPlant.setPlantCode("PLANT_CODE_1");

        List<PlantVO> cornPlants = new ArrayList<PlantVO>();
        cornPlants.add(cornPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.CORN.getCode()), eq(distributorConfigDTO))).thenReturn(cornPlants);

        PlantVO sorghumPlant = new PlantVO();
        sorghumPlant.setPriority(2L);
        sorghumPlant.setPlantCode("PLANT_CODE_2");

        PlantVO sorghumPlant2 = new PlantVO();
        sorghumPlant2.setPriority(2L);
        sorghumPlant2.setPlantCode("PLANT_CODE_1");

        List<PlantVO> sorghumPlants = new ArrayList<PlantVO>();
        sorghumPlants.add(sorghumPlant);
        sorghumPlants.add(sorghumPlant2);

        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.SORGHUM.getCode()), eq(distributorConfigDTO))).thenReturn(sorghumPlants);


        InventoryWithAlgorithmDTO inv = new InventoryWithAlgorithmDTO();
        inv.setHybrid("H1");

        PlantWithAlgorithmDTO pwa = new PlantWithAlgorithmDTO();
        pwa.setPlant("PLANT_CODE_1");

        PlantWithAlgorithmDTO pwa2 = new PlantWithAlgorithmDTO();
        pwa2.setPlant("PLANT_CODE_2");

        List<PlantWithAlgorithmDTO> plantWithAlgorithmDTOs = new ArrayList<PlantWithAlgorithmDTO>();
        plantWithAlgorithmDTOs.add(pwa);
        plantWithAlgorithmDTOs.add(pwa2);

        inv.setPlants(plantWithAlgorithmDTOs);

        InventoryWithAlgorithmDTO inv2 = new InventoryWithAlgorithmDTO();
        inv2.setHybrid("H2");


        List<InventoryWithAlgorithmDTO> inventory = new ArrayList<InventoryWithAlgorithmDTO>();
        inventory.add(inv);
        inventory.add(inv2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("H1");
        productDTO.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());

        OrderDetailDTO detail = new OrderDetailDTO();
        detail.setProductDTO(productDTO);

        unit.assignPlantPriorityPerHybridCornOrSorghum(detail,distributorConfigDTO,inventory);
    }

    @Test
    public void obtainPlantsAccordingToCrop_SorghumDifferentHybrid() throws Exception{

        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();

        PlantVO cornPlant = new PlantVO();
        cornPlant.setPriority(1L);
        cornPlant.setPlantCode("PLANT_CODE_1");
        List<PlantVO> cornPlants = new ArrayList<PlantVO>();
        cornPlants.add(cornPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.CORN.getCode()), eq(distributorConfigDTO))).thenReturn(cornPlants);

        PlantVO sorghumPlant = new PlantVO();
        sorghumPlant.setPriority(2L);
        sorghumPlant.setPlantCode("PLANT_CODE_2");
        List<PlantVO> sorghumPlants = new ArrayList<PlantVO>();
        sorghumPlants.add(sorghumPlant);
        when(plantService.obtainPlantsAccordingToCrop(eq(SeedsCropCodeEnum.SORGHUM.getCode()), eq(distributorConfigDTO))).thenReturn(sorghumPlants);

        InventoryWithAlgorithmDTO inv = new InventoryWithAlgorithmDTO();
        inv.setHybrid("H1");

        PlantWithAlgorithmDTO pwa = new PlantWithAlgorithmDTO();
        pwa.setPlant("PLANT_CODE_1");

        List<PlantWithAlgorithmDTO> plantWithAlgorithmDTOs = new ArrayList<PlantWithAlgorithmDTO>();
        plantWithAlgorithmDTOs.add(pwa);

        inv.setPlants(plantWithAlgorithmDTOs);

        InventoryWithAlgorithmDTO inv2 = new InventoryWithAlgorithmDTO();
        inv2.setHybrid("H2");


        List<InventoryWithAlgorithmDTO> inventory = new ArrayList<InventoryWithAlgorithmDTO>();
        inventory.add(inv);
        inventory.add(inv2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("H5");
        productDTO.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());

        OrderDetailDTO detail = new OrderDetailDTO();
        detail.setProductDTO(productDTO);

        unit.assignPlantPriorityPerHybridCornOrSorghum(detail,distributorConfigDTO,inventory);
    }

}