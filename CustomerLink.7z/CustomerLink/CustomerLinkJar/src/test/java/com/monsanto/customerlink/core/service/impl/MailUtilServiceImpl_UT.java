package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MailUtilServiceImpl_UT {


    @Mock
    private DistributorRepository distributorRepository;
    @Mock
    private DistributionChannelRepository distributionChannelRepository;
    @Mock
    private SubRegionRepository subRegionRepository;
    @Mock
    private SalesDivisionRepository salesDivisionRepository;
    @Mock
    private SalesOrganizationRepository salesOrganizationRepository;

    MailUtilService mailUtilService;

    @Before
    public void setup() {
        mailUtilService = new MailUtilServiceImpl(distributorRepository, distributionChannelRepository,
                subRegionRepository, salesDivisionRepository, salesOrganizationRepository);
    }

    @Test
    public void testMessageIsBuildedWithoutError() {

        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO dto = new DistributorDTO();
        configDTO.setDistributor(dto);

        Mockito.when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(new DistributorVO());

        when(distributionChannelRepository.findByDistributionChannelCode(Matchers.<String>any())).thenReturn(new DistributionChannelVO());
        when(subRegionRepository.findBySubRegionCode(Matchers.<String>any())).thenReturn(new SubRegionVO());
        when(salesDivisionRepository.findOne(Matchers.<String>any())).thenReturn(new SalesDivisionVO());
        when(salesOrganizationRepository.findOne(Matchers.<String>any())).thenReturn(new SalesOrganizationVO());

        Assert.assertNotNull(mailUtilService.buildDistributorMessageNotification(configDTO, null));
    }


    @Test
    public void testMessageIsBuildedWithoutErrorButWithNullValues() {

        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO dto = new DistributorDTO();
        configDTO.setDistributor(dto);

        Mockito.when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(null);

        when(distributionChannelRepository.findByDistributionChannelCode(Matchers.<String>any())).thenReturn(null);
        when(subRegionRepository.findBySubRegionCode(Matchers.<String>any())).thenReturn(null);
        when(salesDivisionRepository.findOne(Matchers.<String>any())).thenReturn(null);
        when(salesOrganizationRepository.findOne(Matchers.<String>any())).thenReturn(null);

        Assert.assertNotNull(mailUtilService.buildDistributorMessageNotification(configDTO, null));
    }


    @Test
    public void testMessageIsBuildedWithoutErrorAndWithErrorList() {

        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO dto = new DistributorDTO();
        configDTO.setDistributor(dto);

        List<ErrorOrderDTO> listError = new ArrayList<ErrorOrderDTO>();
        for (int i = 0; i < 2; i++) {
            listError.add(new ErrorOrderDTO());
        }
        Mockito.when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(new DistributorVO());

        when(distributionChannelRepository.findByDistributionChannelCode(Matchers.<String>any())).thenReturn(new DistributionChannelVO());
        when(subRegionRepository.findBySubRegionCode(Matchers.<String>any())).thenReturn(new SubRegionVO());
        when(salesDivisionRepository.findOne(Matchers.<String>any())).thenReturn(new SalesDivisionVO());
        when(salesOrganizationRepository.findOne(Matchers.<String>any())).thenReturn(new SalesOrganizationVO());

        Assert.assertNotNull(mailUtilService.buildDistributorMessageNotification(configDTO, listError));
    }
}

