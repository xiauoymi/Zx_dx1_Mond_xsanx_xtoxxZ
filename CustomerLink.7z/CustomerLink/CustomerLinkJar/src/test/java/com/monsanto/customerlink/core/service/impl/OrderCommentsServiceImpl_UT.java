package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderCommentsService;
import com.monsanto.customerlink.persistence.entities.OrderCommentVO;
import com.monsanto.customerlink.persistence.repositories.OrderCommentsRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderCommentsServiceImpl_UT {

    @Mock
    private OrderCommentsRepository orderCommentsRepository;

    @Mock
    private OrderCommentsService unit;

    @Before
    public void before() {
        reset(orderCommentsRepository);
        unit = new OrderCommentsServiceImpl(orderCommentsRepository);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenIdOrderIsNull() throws Exception {
        Long idOrder = null;
        String comments = null;
        unit.saveComment(idOrder,comments);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenCommentsAreNull() throws Exception {
        Long idOrder = 1L;
        String comments = null;
        unit.saveComment(idOrder,comments);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenCommentsAreBlank() throws Exception {
        Long idOrder = 1L;
        String comments = "  ";
        unit.saveComment(idOrder,comments);
    }

    @Test
    public void saveComment() throws Exception {
        Long idOrder = 1L;
        String comments = "COMMENTS ";
        when(orderCommentsRepository.save(any(OrderCommentVO.class))).thenReturn(new OrderCommentVO());
        OrderCommentVO commentCreated = unit.saveComment(idOrder,comments);
        assertThat(commentCreated, is(notNullValue()));
        verify(orderCommentsRepository).save(any(OrderCommentVO.class));
    }
}