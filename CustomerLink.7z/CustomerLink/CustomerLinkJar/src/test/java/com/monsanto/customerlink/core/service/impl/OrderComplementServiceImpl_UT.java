package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.dozer.Mapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderComplementServiceImpl_UT {

    @Mock
    private FiscalYearService fiscalYearService;

    @Mock
    private OrderReasonTypeService orderReasonTypeBusiness;

    @Mock
    private PONumberService poNumberBusiness;

    @Mock
    private PriceGroupService priceGroupBusiness;

    @Mock
    private SAPOrderTypeService sapOrderTypeBusiness;

    @Mock
    private SeasonService seasonBusiness;

    @Mock
    private Mapper mapper;

    @InjectMocks
    private OrderComplementService unit = new OrderComplementServiceImpl();

    @Test
    public void complementTheOrderWhenCropIsSeed() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        unit.complement(orderDTO);
        assertThat(orderDTO, is(notNullValue()));
    }

    @Test
    public void complementTheOrderWhenCropIsAgrochemical() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX01");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setCropCode("AG010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code());
        orderDTO.setDetail(orderDetailDTOList);

        unit.complement(orderDTO);
        assertThat(orderDTO, is(notNullValue()));
        assertThat(orderDTO.getPoNumber(), is(nullValue()));
        assertThat(orderDTO.getIncoterms1(), is(nullValue()));
        assertThat(orderDTO.getIncoterms2(), is(nullValue()));
        assertThat(orderDTO.getPriceGroup(), is(nullValue()));
        assertThat(orderDTO.getSoldTo(), is(nullValue()));
        assertThat(orderDTO.getShipTo(), is(nullValue()));
    }

    @Test
    public void complementToSearchWhenCropIsSeed() throws Exception {
        final SearchPeriodDTO searchPeriodDTO = new SearchPeriodDTO();
        when(seasonBusiness.retrieveSearchPeriod(Matchers.<String>any())).thenReturn(searchPeriodDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        unit.complementToSearch(orderDTO);
        assertThat(orderDTO, is(notNullValue()));
        assertThat(orderDTO.getSearchPeriodDTO(), is(notNullValue()));
        assertThat(orderDTO.getSearchPeriodDTO(), is(sameInstance(searchPeriodDTO)));
    }

    @Test
    public void complementToSearchWhenCropIsAgrochemical() throws Exception {
        final SearchPeriodDTO searchPeriodDTO = new SearchPeriodDTO();
        when(fiscalYearService.retrieveSearchPeriod()).thenReturn(searchPeriodDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setBrandCode("CB");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.REGULAR_AGROCHEMICAL.code());
        orderDTO.setDetail(orderDetailDTOList);

        unit.complementToSearch(orderDTO);
        assertThat(orderDTO, is(notNullValue()));
        assertThat(orderDTO.getSearchPeriodDTO(), is(notNullValue()));
        assertThat(orderDTO.getSearchPeriodDTO(), is(sameInstance(searchPeriodDTO)));
    }
}
