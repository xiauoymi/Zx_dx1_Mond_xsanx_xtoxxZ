package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderCommentsService;
import com.monsanto.customerlink.persistence.entities.OrderDetailVO;
import com.monsanto.customerlink.persistence.repositories.OrderDetailRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderDetailServiceImpl_UT {

    @Mock
    private OrderDetailRepository orderDetailRepository;

    @Mock
    private OrderCommentsService orderCommentsService;

    @Mock
    private OrderDetailServiceImpl unit;

    @Before
    public void before() {
        reset(orderDetailRepository,orderCommentsService);
        unit = new OrderDetailServiceImpl(orderDetailRepository,orderCommentsService);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenIdOrderIsNull() throws Exception {
        Long idOrder = null;
        List<String> hybridsForDelete = null;
        unit.deleteOrderDetails(idOrder,hybridsForDelete);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenListOfHybridsIsNull() throws Exception {
        Long idOrder = 1L;
        List<String> hybridsForDelete = null;
        unit.deleteOrderDetails(idOrder, hybridsForDelete);
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnCreateCommentWhenListOfHybridsIsEmpty() throws Exception {
        Long idOrder = 1L;
        List<String> hybridsForDelete = new ArrayList<String>();
        unit.deleteOrderDetails(idOrder,hybridsForDelete);
    }

    @Test
    public void deleteOrderDetails() throws Exception {
        Long idOrder = 1L;
        List<String> hybridsForDelete = Arrays.asList( new String[]{"1"} );
        when(orderDetailRepository.findByOrderDetailId(anyLong())).thenReturn(new OrderDetailVO());
        unit.deleteOrderDetails(idOrder,hybridsForDelete);
        verify(orderDetailRepository).findByOrderDetailId(eq(idOrder));
        verify(orderDetailRepository).delete(eq(1L));
        verify(orderCommentsService).saveComment(anyLong(),anyString());
    }
}