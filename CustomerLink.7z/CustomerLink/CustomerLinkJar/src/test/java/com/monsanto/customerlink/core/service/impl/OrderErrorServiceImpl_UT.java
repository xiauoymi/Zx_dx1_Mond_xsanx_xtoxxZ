package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderErrorService;
import com.monsanto.customerlink.core.service.OrderService;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.OrderStatusEnum;
import com.monsanto.customerlink.core.service.util.SkuPricesErrorsEnum;
import com.monsanto.customerlink.persistence.entities.ErrorTypeVO;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.repositories.ErrorTypeRepository;
import com.monsanto.customerlink.persistence.repositories.OrderErrorRepository;
import com.monsanto.customerlink.persistence.repositories.OrderRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderErrorServiceImpl_UT {

    @Mock
    private OrderErrorRepository orderErrorRepository;
    @Mock
    private OrderRepository orderRepository;
    @Mock
    private ErrorTypeRepository errorTypeRepository;
    @Mock
    private OrderService orderService;
    @Mock
    private Mapper mapper;

    OrderErrorService orderErrorService;

    List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
    OrderDTO orderWithErrorsDTO = new OrderDTO();

    @org.junit.Before
    public void setup() {
        orderErrorService = new OrderErrorServiceImpl(orderService);

        for (int i = 0; i < 1; i++) {
            ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
            ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();
            errorOrderDTO.setErrorTypes(errorTypeDTO);
            errorOrderDTOList.add(errorOrderDTO);
        }

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setErrors(errorOrderDTOList);
        orderWithErrorsDTO.getDetail().add(orderDetailDTO);
    }


    @Test
    public void testSaveAllErrorsWhenOrderNotExistInRepositoryAndIsCreatedNewOne() throws Exception {
        reset(orderRepository);
        reset(errorTypeRepository);
        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(new ArrayList<OrderVO>());
        when(errorTypeRepository.findByErrorTypeCode(Matchers.<String>any())).thenReturn(new ErrorTypeVO());

        OrderDTO saveorderDTO = new OrderDTO();
        when(orderService.createOrder(Matchers.<OrderDTO>any())).thenReturn(saveorderDTO);
        when(mapper.map(saveorderDTO, OrderVO.class)).thenReturn(new OrderVO());

        orderErrorService.saveOrderAndErrors(orderWithErrorsDTO);

    }


    @Test
    public void testSaveAllErrorsWhenOrderExistpreviouslyInRepositoryAndhasPendingStatus() throws Exception {
        List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        OrderVO orderVO = new OrderVO();
        OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.PENDING_APPROVAL.toString());
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        orderVOList.add(orderVO);
        reset(orderRepository);
        reset(errorTypeRepository);
        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(orderVOList);

        when(errorTypeRepository.findByErrorTypeCode(Matchers.<String>any())).thenReturn(new ErrorTypeVO());
        orderErrorService.saveOrderAndErrors(orderWithErrorsDTO);
    }


    @Test
    public void testSaveAllErrorsWhenOrderExistpreviouslyInRepositoryWithTheGivenParametersButNotHasPendingStatus() throws Exception {
        List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        OrderVO orderVO = new OrderVO();
        OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.WITH_ERROR.toString());
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        orderVOList.add(orderVO);
        reset(orderRepository);
        reset(errorTypeRepository);
        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(orderVOList);

        when(errorTypeRepository.findByErrorTypeCode(Matchers.<String>any())).thenReturn(new ErrorTypeVO());
        orderErrorService.saveOrderAndErrors(orderWithErrorsDTO);
    }

    @Test
    public void testThatContainsErrorsReturnTrueWhenThereAreErrorInAProductOfTheOrder() {
        OrderDTO orderDTO = new OrderDTO();

        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            orderDetailDTO.getErrors().add(new ErrorOrderDTO());
            orderDTO.getDetail().add(orderDetailDTO);
        }

        Assert.assertTrue(orderErrorService.containErrors(orderDTO));
    }

    @Test
    public void testThatContainsErrorsReturnTrueWhenThereAreErrorInTheOrder() {
        OrderDTO orderDTO = new OrderDTO();

        for (int i = 0; i < 5; i++) {
            orderDTO.getErrors().add(new ErrorOrderDTO());
        }

        Assert.assertTrue(orderErrorService.containErrors(orderDTO));
    }

    @Test
    public void testThatContainsErrorsReturnFalseWhenThereAreNotErrorInTheOrder() {
        OrderDTO orderDTO = new OrderDTO();

        Assert.assertFalse(orderErrorService.containErrors(orderDTO));
    }

    @Test
    public void testThatAllProductsAreFilteredWhenAllOfThemContainsErrors() {

        OrderDTO orderDTO = new OrderDTO();

        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            orderDetailDTO.getErrors().add(new ErrorOrderDTO());
            orderDTO.getDetail().add(orderDetailDTO);
        }

        Assert.assertEquals(orderErrorService.filterHybridsWithErrors(orderDTO).getErrors().size(), 0);

    }


    @Test
    public void testThatNotAllProductsAreFilteredWhenAsLessOneOfThemNotContainsErrors() {

        OrderDTO orderDTO = new OrderDTO();

        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            orderDetailDTO.getErrors().add(new ErrorOrderDTO());
            orderDTO.getDetail().add(orderDetailDTO);
        }
        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            orderDTO.getDetail().add(orderDetailDTO);
        }

        orderErrorService.filterHybridsWithErrors(orderDTO).getErrors().size();
    }

    @Test
    public void testThatEmptyListIsreturnedWhenOrderNotContainsPriceErrors() {
        OrderDTO orderDTO = new OrderDTO();

        Assert.assertEquals(orderErrorService.obtainPricesErrors(orderDTO).size(), 0);
    }

    @Test
    public void testNotEmptyListIsReturnedWhenOrderContainsPriceErrors() {
        OrderDTO orderDTO = new OrderDTO();

        List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ErrorOrderDTO error = new ErrorOrderDTO();
            ErrorTypeDTO type = new ErrorTypeDTO();
            type.setErrorTypeCode(SkuPricesErrorsEnum.PRICE_ERROR_7.toString());
            error.setErrorTypes(type);
            orderDetailDTO.getErrors().add(error);
            orderDetailDTOList.add(orderDetailDTO);
        }

        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ErrorOrderDTO error = new ErrorOrderDTO();
            ErrorTypeDTO type = new ErrorTypeDTO();
            type.setErrorTypeCode(SkuPricesErrorsEnum.SKU_ERROR_1.toString());
            error.setErrorTypes(type);
            orderDetailDTO.getErrors().add(error);
            orderDetailDTOList.add(orderDetailDTO);
        }

        orderDTO.setDetail(orderDetailDTOList);

        orderErrorService.obtainPricesErrors(orderDTO).size();
    }

    @Test
    public void testThatEmptyListIsreturnedWhenOrderNotContainsSkuErrors() {
        OrderDTO orderDTO = new OrderDTO();

        Assert.assertEquals(orderErrorService.obtainSkuErrors(orderDTO).size(), 0);
    }

    @Test
    public void testNotEmptyListIsReturnedWhenOrderContainsSkuErrors() {

        OrderDTO orderDTO = new OrderDTO();
        List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ErrorOrderDTO error = new ErrorOrderDTO();
            ErrorTypeDTO type = new ErrorTypeDTO();
            type.setErrorTypeCode(SkuPricesErrorsEnum.SKU_ERROR_1.toString());
            error.setErrorTypes(type);
            orderDetailDTO.getErrors().add(error);
            orderDetailDTOList.add(orderDetailDTO);
        }

        for (int i = 0; i < 5; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ErrorOrderDTO error = new ErrorOrderDTO();
            ErrorTypeDTO type = new ErrorTypeDTO();
            type.setErrorTypeCode(SkuPricesErrorsEnum.PRICE_ERROR_7.toString());
            error.setErrorTypes(type);
            orderDetailDTO.getErrors().add(error);
            orderDetailDTOList.add(orderDetailDTO);
        }
        orderDTO.setDetail(orderDetailDTOList);
        orderErrorService.obtainSkuErrors(orderDTO).size();
    }

}
