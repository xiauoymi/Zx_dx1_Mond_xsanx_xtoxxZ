package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderReasonTypeService;
import com.monsanto.customerlink.core.service.exception.OrderReasonNotFoundException;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.OrderReasonTypeEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.OrderReasonTypeVO;
import com.monsanto.customerlink.persistence.repositories.OrderReasonTypeRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Locale;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderReasonTypeServiceImpl_UT {

    @Mock
    private OrderReasonTypeRepository orderReasonTypeRepository;

    @InjectMocks
    private OrderReasonTypeService unit = new OrderReasonTypeServiceImpl();

    @Before
    public void run() {
        Locale.setDefault(new Locale("es", "MX"));
    }

    @Test
    public void throwsOrderReasonNotFoundExceptionIfTheOrderReasonTypeIsNotFoundInTheRepository() throws Exception {
        when(orderReasonTypeRepository.findByCLOrderTypeAndCrop(Matchers.<String>any(), Matchers.<String>any())).thenReturn(null);

        try {
            unit.retrieveOrderReasonType(CLOrderTypeEnum.SPECIAL.code(), SeedsCropCodeEnum.CORN.getCode());
        } catch (OrderReasonNotFoundException e) {
            assertThat(e.getMessage(), is("No se encontró una razón de orden para el tipo de orden " + CLOrderTypeEnum.SPECIAL.code() + " y el crop " + SeedsCropCodeEnum.CORN.getCode()));
        }

    }

    @Test
    public void retrievesTheOrderReasonTypeFromTheRepositoryWhoseParametersMatches() throws Exception {
        when(orderReasonTypeRepository.findByCLOrderTypeAndCrop(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final OrderReasonTypeVO orderReasonTypeVO = unit.retrieveOrderReasonType(CLOrderTypeEnum.SPECIAL.code(), SeedsCropCodeEnum.CORN.getCode());
        assertThat(orderReasonTypeVO, is(notNullValue()));
    }

    @Test
    public void throwsOrderReasonNotFoundExceptionIfTheOrderReasonTypeIsNotFoundInTheRepository_ByCode() throws Exception {
        when(orderReasonTypeRepository.findByOrderReasonCode(Matchers.<String>any())).thenReturn(null);

        try {
            unit.retrieveOrderReasonTypeByCode(OrderReasonTypeEnum.SST.toString());
        } catch (OrderReasonNotFoundException e) {
            assertThat(e.getMessage(), is("No se encontró una razón de orden para el código " + OrderReasonTypeEnum.SST.toString()));
        }

    }

    @Test
    public void retrievesTheOrderReasonTypeFromTheRepositoryWhoseParametersMatches_ByCode() throws Exception {
        when(orderReasonTypeRepository.findByOrderReasonCode(Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final OrderReasonTypeVO orderReasonTypeVO = unit.retrieveOrderReasonTypeByCode(OrderReasonTypeEnum.SST.toString());
        assertThat(orderReasonTypeVO, is(notNullValue()));
    }
}
