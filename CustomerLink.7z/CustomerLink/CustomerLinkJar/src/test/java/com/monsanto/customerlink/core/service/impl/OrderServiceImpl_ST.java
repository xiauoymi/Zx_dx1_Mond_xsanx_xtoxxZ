package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderService;
import com.monsanto.customerlink.core.service.dto.SpecialOrderDTO;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.*;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class OrderServiceImpl_ST {

    @Autowired
    private OrderService orderBusiness;

    @Test
    @Ignore
    public void createOrderTest() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.CB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376711");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO order = orderBusiness.createOrder(orderDTO);
        System.out.println(order);
    }

    @Test
    @Ignore
    public void updateOrderTest() throws Exception {
        final ProductDTO productDTO1 = new ProductDTO();
        productDTO1.setProductCode("11111");
        productDTO1.setBrandCode(BrandEnum.CB.getDesc());
        productDTO1.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final ProductDTO productDTO2 = new ProductDTO();
        productDTO2.setProductCode("22222");
        productDTO2.setBrandCode(BrandEnum.CB.getDesc());
        productDTO2.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO1);
        orderDetailDTO1.setQuantity(35);

        final OrderDetailDTO orderDetailDTO2 = new OrderDetailDTO();
        orderDetailDTO2.setProductDTO(productDTO2);
        orderDetailDTO2.setQuantity(40);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO1);
        orderDetailDTOList.add(orderDetailDTO2);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(239L);
        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO order = orderBusiness.createOrder(orderDTO);
        System.out.println(order);
    }

    @Test
    @Ignore
    public void retrieveSpecialOrdersPendingApprovalByUser() throws Exception {
        Long userId = 1L;
        List<SpecialOrderDTO> orders = orderBusiness.retrieveSpecialOrdersPendingApprovalByUser(userId);
        System.out.println(orders);
    }

    @Test
    @Ignore
    public void createSpecialOrder() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("3101380");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXSUR");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("GALIOPO");
        productDTO.setBrandCode(BrandEnum.ASGROW.getId());
        productDTO.setCropCode(SeedsCropCodeEnum.SORGHUM.getCode());
        productDTO.setUmBase("BG");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);
        orderDetailDTO.setUmBase("BG");

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("3111806");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.SPECIAL.code());
        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO orderDTO1 = orderBusiness.createOrder(orderDTO);
    }

    @Test
    @Ignore
    public void createOrderWithoutSoakTest() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("AG7088PRO2CR");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SST.toString());

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("PGTESTLETY");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376711");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code());
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setOrderIdSAP("1234567892");
        orderDTO.setCurrency("MXN");
        orderDTO.setPoNumber("OI13 AMXBAJ S/ST");
        orderDTO.setIncoterms1(CustomerLinkCoreConstants.INCOTERMS1);
        orderDTO.setIncoterms2(CustomerLinkCoreConstants.INCOTERMS2);
        orderDTO.setSoldTo(distributorDTO.getDistributorCode());
        orderDTO.setShipTo(distributorDTO.getDistributorCode());

        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO orderDTO1 = orderBusiness.createOrder(orderDTO);
    }

    @Test
    @Ignore
    public void createOrderCB() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.CB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.CB.code());
        orderDTO.setDetail(orderDetailDTOList);

        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO orderDTO1 = orderBusiness.createOrder(orderDTO);
    }

    @Test
    @Ignore
    public void createOrderCBWithErrors() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.CB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final ErrorTypeDTO errorTypeDTO1 = new ErrorTypeDTO();
        errorTypeDTO1.setErrorTypeCode("001");

        final ErrorTypeDTO errorTypeDTO2 = new ErrorTypeDTO();
        errorTypeDTO2.setErrorTypeCode("002");

        final ErrorOrderDTO errorOrderDTO1 = new ErrorOrderDTO();
        errorOrderDTO1.setErrorTypes(errorTypeDTO1);
        errorOrderDTO1.setObjectWithError("123456789");

        final ErrorOrderDTO errorOrderDTO2 = new ErrorOrderDTO();
        errorOrderDTO2.setErrorTypes(errorTypeDTO2);
        errorOrderDTO2.setObjectWithError("123456789");

        final List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        errorOrderDTOList.add(errorOrderDTO1);
        errorOrderDTOList.add(errorOrderDTO2);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.CB.code());
        orderDTO.setCurrency("MXN");
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setErrors(errorOrderDTOList);

        orderDTO.setDetail(orderDetailDTOList);

        final OrderDTO orderDTO1 = orderBusiness.createOrder(orderDTO);
    }
}
