package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderService;
import com.monsanto.customerlink.core.service.OrderStrategy;
import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.WFApprovalSpecialOrderService;
import com.monsanto.customerlink.core.service.dto.SpecialOrderDTO;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.core.service.exception.RCDNotFoundException;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.OrderDetailVO;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.OrderRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceImpl_UT {

    @Mock
    private UserService userService;

    @Mock
    private WFApprovalSpecialOrderService wfApprovalSpecialOrderService;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private Mapper mapper;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private OrderStrategy orderStrategy;

    @InjectMocks
    private OrderService unit = new OrderServiceImpl();

    @Before
    public void run() {
        Locale.setDefault(new Locale("es", "MX"));
    }

    @Test
    public void retrievesOrderDTOWhenCreate() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("1111");
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setCurrency("MXN");

        final OrderDetailVO orderDetailVO = new OrderDetailVO();
        orderDetailVO.setProductCode("1111");
        orderDetailVO.setQty(BigDecimal.valueOf(40));

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);

        final OrderVO orderVO = new OrderVO();

        when(applicationContext.getBean(Matchers.<String>any(), Matchers.<Class>any())).thenReturn(orderStrategy);
        when(orderStrategy.createOrder(Matchers.<OrderDTO>any())).thenReturn(orderVO);

        when(mapper.mapList(OrderDetailVO.class, orderDTO.getDetail())).thenReturn(orderDetailVOList);

        final OrderDTO mappedDTO = new OrderDTO();
        mappedDTO.setDistributorConfigDTO(new DistributorConfigDTO());
        when(mapper.map(orderVO, OrderDTO.class)).thenReturn(mappedDTO);

        final OrderDTO savedOrder = unit.createOrder(orderDTO);
        assertThat(savedOrder, is(notNullValue()));
        assertThat(savedOrder, is(sameInstance(mappedDTO)));
    }

    @Test
    public void retrievesOrderDTOWhenUpdate() throws Exception {
        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setOrderId(1L);

        orderDTO.setDistributorConfigDTO(new DistributorConfigDTO());

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.PENDING_APPROVAL.toString());

        final OrderDetailVO orderDetailVO = new OrderDetailVO();
        orderDetailVO.setProductCode("1111");
        orderDetailVO.setQty(BigDecimal.valueOf(40));

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(mapper.mapList(OrderDetailVO.class, orderDTO.getDetail())).thenReturn(orderDetailVOList);

        final OrderVO orderVO = new OrderVO();

        when(applicationContext.getBean(Matchers.<String>any(), Matchers.<Class>any())).thenReturn(orderStrategy);
        when(orderStrategy.updateOrder(Matchers.<OrderDTO>any())).thenReturn(orderVO);

        final OrderDTO mappedDTO = new OrderDTO();
        mappedDTO.setDistributorConfigDTO(new DistributorConfigDTO());
        when(mapper.map(orderVO, OrderDTO.class)).thenReturn(mappedDTO);

        final OrderDTO savedOrder = unit.createOrder(orderDTO);
        assertThat(savedOrder, is(notNullValue()));
        assertThat(savedOrder, is(sameInstance(mappedDTO)));
    }

    @Test
    public void throwsOrdersNotFoundExceptionWhenOrdersNotFoundInTheRepository() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);

        final List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        final List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();

        when(orderRepository.findByParametersAndCurrentSeasonActive(orderDTO)).thenReturn(orderVOList);
        when(mapper.mapList(OrderDTO.class, orderVOList)).thenReturn(orderDTOList);

        try {
            unit.retrieveOrders(orderDTO);
        } catch (OrdersNotFoundException e) {
            assertThat(e.getMessage(), is("No existen órdenes para los criterios de búsqueda seleccionados"));
        }
    }

    @Test
    public void retrievesOrdersByParametersAndCurrentSeasonActive_00() throws Exception {
        final OrderVO orderVO = new OrderVO();
        orderVO.setRcdSAPCode("1234567890");

        final List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        orderVOList.add(orderVO);

        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(orderVOList);

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);

        when(mapper.map(Matchers.<OrderVO>any(), Matchers.<Class<OrderDTO>>any())).thenReturn(orderDTO);


        final UserVO userVO = new UserVO();

        when(userService.retrieveRCD(Matchers.<String>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(userVO);

        final OrderDTO orderDTORetriever = new OrderDTO();
        orderDTORetriever.setDistributorConfigDTO(new DistributorConfigDTO());
        final List<OrderDTO> orderDTOList = unit.retrieveOrders(orderDTORetriever);
        assertThat(orderDTOList.isEmpty(), is(Boolean.FALSE));
    }

    @Test
    public void retrievesOrdersByParametersAndCurrentSeasonActive_01() throws Exception {
        final OrderVO orderVO = new OrderVO();
        orderVO.setRcdSAPCode(null);

        final List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        orderVOList.add(orderVO);

        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(orderVOList);

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);

        when(mapper.map(Matchers.<OrderVO>any(), Matchers.<Class<OrderDTO>>any())).thenReturn(orderDTO);


        final UserVO userVO = new UserVO();

        when(userService.retrieveRCD(Matchers.<String>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(userVO);

        final OrderDTO orderDTORetriever = new OrderDTO();
        orderDTORetriever.setDistributorConfigDTO(new DistributorConfigDTO());
        final List<OrderDTO> orderDTOList = unit.retrieveOrders(orderDTORetriever);
        assertThat(orderDTOList.isEmpty(), is(Boolean.FALSE));
    }

    @Test
    public void retrievesOrdersByParametersAndCurrentSeasonActive_ThrowsRCDNotFoundException() throws Exception {
        final OrderVO orderVO = new OrderVO();
        orderVO.setRcdSAPCode("1234567890");

        final List<OrderVO> orderVOList = new ArrayList<OrderVO>();
        orderVOList.add(orderVO);

        when(orderRepository.findByParametersAndCurrentSeasonActive(Matchers.<OrderDTO>any())).thenReturn(orderVOList);

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);

        when(mapper.map(Matchers.<OrderVO>any(), Matchers.<Class<OrderDTO>>any())).thenReturn(orderDTO);

        when(userService.retrieveRCD(Matchers.<String>any(), Matchers.<DistributorConfigDTO>any())).thenThrow(new RCDNotFoundException(new Object[1]));

        final OrderDTO orderDTORetriever = new OrderDTO();
        orderDTORetriever.setDistributorConfigDTO(new DistributorConfigDTO());
        final List<OrderDTO> orderDTOList = unit.retrieveOrders(orderDTORetriever);
        assertThat(orderDTOList.isEmpty(), is(Boolean.FALSE));
    }

    @Test
    public void retrieveSpecialOrdersPendingApprovalByUser_When_ListOfIdsIsEmpty() throws Exception {
        when(wfApprovalSpecialOrderService.obtainApprovalsPendingBusinessByUser(anyLong())).thenReturn(new ArrayList<Long>());
        List<SpecialOrderDTO> orders = unit.retrieveSpecialOrdersPendingApprovalByUser(1L);
        assertTrue(orders.isEmpty());
    }

    @Test
    public void retrieveSpecialOrdersPendingApprovalByUser_When_ListOfIdsNotEmpty() throws Exception {

        OrderVO o = new OrderVO();

        when(orderRepository.findByOrderId(anyLong())).thenReturn(o);

        when(mapper.map(o, SpecialOrderDTO.class)).thenReturn(new SpecialOrderDTO());

        when(wfApprovalSpecialOrderService.obtainApprovalsPendingBusinessByUser(anyLong())).thenReturn(Arrays.asList(new Long[]{100L}));
        List<SpecialOrderDTO> orders = unit.retrieveSpecialOrdersPendingApprovalByUser(1L);
        assertTrue(!orders.isEmpty());
    }

    @Test
    public void retrieveOrderDTOWhenStatusOrderChangeToPosted() throws Exception {
        when(applicationContext.getBean(Matchers.<String>any(), Matchers.<Class>any())).thenReturn(orderStrategy);

        final OrderVO orderVO = new OrderVO();
        when(orderStrategy.changeOrderToPosted(Matchers.<Long>any())).thenReturn(orderVO);

        final OrderDTO mappedDTO = new OrderDTO();
        when(mapper.map(orderVO, OrderDTO.class)).thenReturn(mappedDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(1L);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final OrderDTO orderDTO1 = unit.changeOrderToPosted(orderDTO);
        assertThat(orderDTO1, is(notNullValue()));
        assertThat(orderDTO1, is(sameInstance(mappedDTO)));
    }
}
