package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderStatusService;
import com.monsanto.customerlink.core.service.exception.OrderStatusNotFoundException;
import com.monsanto.customerlink.core.service.util.OrderStatusEnum;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.persistence.repositories.OrderStatusRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderStatusServiceImpl_UT {

    @Mock
    private OrderStatusRepository orderStatusRepository;

    @InjectMocks
    private OrderStatusService unit = new OrderStatusServiceImpl();

    @Test
    public void retrievesOrderStatusWithErrorWhenTheOrdersHavesErrors() throws Exception {
        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.WITH_ERROR.toString());

        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();

        final List<ErrorOrderDTO> errorOrderDTOs = new ArrayList<ErrorOrderDTO>();
        errorOrderDTOs.add(errorOrderDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setErrors(errorOrderDTOs);

        final OrderStatusVO orderStatusVO1 = unit.retrieveOrderStatusInitial(orderDTO);
        assertThat(orderStatusVO1, is(notNullValue()));
        assertThat(orderStatusVO1, is(sameInstance(orderStatusVO)));
        assertThat(orderStatusVO1.getOrderStatusCode(), is(OrderStatusEnum.WITH_ERROR.toString()));
    }

    @Test
    public void retrievesOrderStatusPendingApproval() throws Exception {
        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.PENDING_APPROVAL.toString());

        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderStatusVO orderStatusVO1 = unit.retrieveOrderStatusInitial(new OrderDTO());
        assertThat(orderStatusVO1, is(notNullValue()));
        assertThat(orderStatusVO1, is(sameInstance(orderStatusVO)));
        assertThat(orderStatusVO1.getOrderStatusCode(), is(OrderStatusEnum.PENDING_APPROVAL.toString()));
    }

    @Test(expected = OrderStatusNotFoundException.class)
    public void throwsOrderStatusNotFoundExceptionIfOrderStatusInitialNotFoundInTheRepository() throws Exception {
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(null);

        unit.retrieveOrderStatusInitial(new OrderDTO());
    }
}
