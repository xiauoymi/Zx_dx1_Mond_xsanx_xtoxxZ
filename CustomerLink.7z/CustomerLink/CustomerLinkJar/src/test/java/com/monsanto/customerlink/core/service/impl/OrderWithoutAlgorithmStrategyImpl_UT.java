package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.OrderStatusNotFoundException;
import com.monsanto.customerlink.core.service.exception.OrderTypeNotFoundException;
import com.monsanto.customerlink.core.service.exception.OrdersNotFoundException;
import com.monsanto.customerlink.core.service.exception.UpdateOrderException;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.OrderDetailVO;
import com.monsanto.customerlink.persistence.entities.OrderStatusVO;
import com.monsanto.customerlink.persistence.entities.OrderVO;
import com.monsanto.customerlink.persistence.entities.OrdersTypeVO;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderWithoutAlgorithmStrategyImpl_UT {

    @Mock
    private DistributorService distributorBusiness;

    @Mock
    private OrderComplementService orderComplementBusiness;

    @Mock
    private SeasonService seasonBusiness;

    @Mock
    private UserService userService;

    @Mock
    private ErrorTypeRepository errorTypeRepository;

    @Mock
    private OrderDetailRepository orderDetailRepository;

    @Mock
    private OrdersTypeRepository ordersTypeRepository;

    @Mock
    private OrderStatusRepository orderStatusRepository;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private Mapper mapper;

    @InjectMocks
    private OrderStrategy orderStrategy = new OrderWithoutAlgorithmStrategyImpl();

    @Before
    public void run() {
        Locale.setDefault(new Locale("es", "MX"));
    }

    @Test(expected = OrderStatusNotFoundException.class)
    public void throwsOrderStatusNotFoundExceptionWhenTheStatusIsNotExistInTheRepository() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(new OrdersTypeVO());

        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(null);

        final OrderVO orderVO = new OrderVO();
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setCurrency("MXN");

        orderStrategy.createOrder(orderDTO);
    }

    @Test(expected = OrderTypeNotFoundException.class)
    public void throwsOrderTypeNotFoundExceptionWhenTheCustomerLinkOrderTypeIsNotExistInTheRepository() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(null);

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.PENDING_POST.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setCurrency("MXN");

        orderStrategy.createOrder(orderDTO);
    }

    @Test
    public void throwsOrdersNotFoundExceptionWhenTheOrderToUpdateIsNotFoundInTheRepository() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(1L);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        when(orderRepository.getOrderStatus(Matchers.<Long>any())).thenReturn(null);

        try {
            orderStrategy.updateOrder(orderDTO);
        } catch (OrdersNotFoundException e) {
            assertThat(e.getMessage(), is("No se encontró la orden " + orderDTO.getOrderId()));
        }
    }

    @Test(expected = UpdateOrderException.class)
    public void throwsUpdateOrderExceptionWhenTheOrderToUpdateItCanNotUpdate() throws Exception {
        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(1L);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        when(orderRepository.getOrderStatus(Matchers.<Long>any())).thenReturn(OrderStatusEnum.POST.toString());

        orderStrategy.updateOrder(orderDTO);
    }

    @Test
    public void createOrderWithoutAlgorithm() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(new OrdersTypeVO());

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.PENDING_POST.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final OrderDetailVO orderDetailVO = new OrderDetailVO();

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(mapper.mapList(Matchers.<Class>any(), Matchers.<List<OrderDetailDTO>>any())).thenReturn(orderDetailVOList);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setCurrency("MXN");

        final OrderVO orderVO1 = orderStrategy.createOrder(orderDTO);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1.getOrderStatusByOrderStatusId().getOrderStatusCode(), is(OrderStatusEnum.PENDING_POST.toString()));
    }

    @Test
    public void createOrderWithoutAlgorithmWithErrors() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(new OrdersTypeVO());

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.WITH_ERROR.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final OrderDetailVO orderDetailVO = new OrderDetailVO();

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(mapper.mapList(Matchers.<Class>any(), Matchers.<List<OrderDetailDTO>>any())).thenReturn(orderDetailVOList);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();

        final ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setErrorTypes(errorTypeDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        errorOrderDTOList.add(errorOrderDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("0003376712");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setErrors(errorOrderDTOList);
        orderDTO.setCurrency("MXN");

        final OrderVO orderVO1 = orderStrategy.createOrder(orderDTO);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1.getOrderStatusByOrderStatusId().getOrderStatusCode(), is(OrderStatusEnum.WITH_ERROR.toString()));
    }

    @Test
    public void createOrderWithoutRepresentative_00() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(new OrdersTypeVO());

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.WITH_ERROR.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final OrderDetailVO orderDetailVO = new OrderDetailVO();

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(mapper.mapList(Matchers.<Class>any(), Matchers.<List<OrderDetailDTO>>any())).thenReturn(orderDetailVOList);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();

        final ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setErrorTypes(errorTypeDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        errorOrderDTOList.add(errorOrderDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setErrors(errorOrderDTOList);
        orderDTO.setCurrency("MXN");

        final OrderVO orderVO1 = orderStrategy.createOrder(orderDTO);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1.getOrderStatusByOrderStatusId().getOrderStatusCode(), is(OrderStatusEnum.WITH_ERROR.toString()));
    }

    @Test
    public void createOrderWithoutRepresentative_01() throws Exception {
        when(ordersTypeRepository.findByOrdersTypeCode(Matchers.<String>any())).thenReturn(new OrdersTypeVO());

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.WITH_ERROR.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderStatusByOrderStatusId(orderStatusVO);
        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final OrderDetailVO orderDetailVO = new OrderDetailVO();

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(mapper.mapList(Matchers.<Class>any(), Matchers.<List<OrderDetailDTO>>any())).thenReturn(orderDetailVOList);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final ErrorTypeDTO errorTypeDTO = new ErrorTypeDTO();

        final ErrorOrderDTO errorOrderDTO = new ErrorOrderDTO();
        errorOrderDTO.setErrorTypes(errorTypeDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final List<ErrorOrderDTO> errorOrderDTOList = new ArrayList<ErrorOrderDTO>();
        errorOrderDTOList.add(errorOrderDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setErrors(errorOrderDTOList);
        orderDTO.setCurrency("MXN");

        final OrderVO orderVO1 = orderStrategy.createOrder(orderDTO);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1.getOrderStatusByOrderStatusId().getOrderStatusCode(), is(OrderStatusEnum.WITH_ERROR.toString()));
    }

    @Test
    public void updateOrderWithoutAlgorithm() throws Exception {
        when(orderRepository.getOrderStatus(Matchers.<Long>any())).thenReturn(OrderStatusEnum.PENDING_POST.toString());

        final OrderDetailVO orderDetailVO = new OrderDetailVO();

        final List<OrderDetailVO> orderDetailVOList = new ArrayList<OrderDetailVO>();
        orderDetailVOList.add(orderDetailVO);
        when(orderDetailRepository.findByOrderId(Matchers.<Long>any())).thenReturn(orderDetailVOList);

        final OrderVO orderVO = new OrderVO();
        orderVO.setOrderId(1L);
        orderVO.setOrderDetailsByOrderId(orderDetailVOList);
        when(orderRepository.findOne(Matchers.<Long>any())).thenReturn(orderVO);

        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("11111");
        productDTO.setBrandCode(BrandEnum.DEKALB.getDesc());
        productDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(34);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(1L);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITHOUT_ALGORITHM.code());
        orderDTO.setDetail(orderDetailDTOList);

        final OrderVO orderVO1 = orderStrategy.updateOrder(orderDTO);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1, is(sameInstance(orderVO)));
    }

    @Test
    public void retrieveOrderVOWhenStatusOrderChangeToPosted() throws Exception {
        String orderStatusCode = OrderStatusEnum.PENDING_POST.toString();
        when(orderRepository.getOrderStatus(Matchers.<Long>any())).thenReturn(orderStatusCode);

        final OrderStatusVO orderStatusVO = new OrderStatusVO();
        orderStatusVO.setOrderStatusCode(OrderStatusEnum.POST.toString());
        when(orderStatusRepository.findByOrderStatusCode(Matchers.<String>any())).thenReturn(orderStatusVO);

        final OrderVO orderVO = new OrderVO();
        when(orderRepository.findOne(Matchers.<Long>any())).thenReturn(orderVO);

        when(orderRepository.save(Matchers.<OrderVO>any())).thenReturn(orderVO);

        final OrderVO orderVO1 = orderStrategy.changeOrderToPosted(1L);
        assertThat(orderVO1, is(notNullValue()));
        assertThat(orderVO1, is(sameInstance(orderVO)));
        assertThat(orderVO1.getOrderStatusByOrderStatusId().getOrderStatusCode(), is(OrderStatusEnum.POST.toString()));
    }
}
