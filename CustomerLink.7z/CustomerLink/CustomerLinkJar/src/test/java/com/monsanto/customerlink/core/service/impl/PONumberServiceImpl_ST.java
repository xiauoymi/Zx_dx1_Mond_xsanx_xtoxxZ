package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.PONumberService;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class PONumberServiceImpl_ST {

    @Autowired
    private PONumberService poNumberBusiness;

    @Test
    @Ignore
    public void retrievesPONumberWhenWithoutSoakTest() throws Exception {
        final String poNumber = poNumberBusiness.generatePONumber(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), "AMXBAJ", null);
        assertThat(poNumber, is("OI13 AMXBAJ S/ST"));
    }

    @Test
    @Ignore
    public void retrievesPONumberWhenTheRemainingOrdersWhenDistChanShortNameIsNull() throws Exception {
        final String poNumber = poNumberBusiness.generatePONumber(CLOrderTypeEnum.WITH_ALGORITHM.code(), "AMXBAJ", "80");
        assertThat(poNumber, is("OI13 AMXBAJ"));
    }

    @Test
    @Ignore
    public void retrievesPONumberWhenTheRemainingOrdersWhenDistChanShortNameIsNotNull() throws Exception {
        final String poNumber = poNumberBusiness.generatePONumber(CLOrderTypeEnum.WITH_ALGORITHM.code(), "AMXBAJ", "3R");
        assertThat(poNumber, is("OI13 AMXBAJ CONV"));
    }
}
