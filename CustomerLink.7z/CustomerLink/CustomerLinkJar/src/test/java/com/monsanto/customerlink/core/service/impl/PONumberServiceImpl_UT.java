package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.DistributionChannelService;
import com.monsanto.customerlink.core.service.FiscalYearService;
import com.monsanto.customerlink.core.service.PONumberService;
import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.persistence.entities.DistributionChannelVO;
import com.monsanto.customerlink.persistence.entities.FiscalYearVO;
import com.monsanto.customerlink.persistence.entities.SeasonTypeVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PONumberServiceImpl_UT {

    @Mock
    private DistributionChannelService distributionChannelBusiness;

    @Mock
    private FiscalYearService fiscalYearBusiness;

    @Mock
    private SeasonService seasonBusiness;

    @InjectMocks
    private PONumberService unit = new PONumberServiceImpl();

    @Test
    public void retrievesPONumberWhenWithoutSoakTest() throws Exception {
        final SeasonTypeVO seasonTypeVO = new SeasonTypeVO();
        seasonTypeVO.setSeasonTypeCode("OI");

        final SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonTypeBySeasonTypeId(seasonTypeVO);

        when(seasonBusiness.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        final FiscalYearVO fiscalYearVO = new FiscalYearVO();
        fiscalYearVO.setFiscalYear(2013L);

        when(fiscalYearBusiness.retrieveActiveFiscalYear(Matchers.<Date>any())).thenReturn(fiscalYearVO);

        final String poNumber = unit.generatePONumber(CLOrderTypeEnum.WITHOUT_SOAK_TEST.code(), "AMXBAJ", "3R");
        assertThat(poNumber, is(notNullValue()));
        assertThat(poNumber, is("OI13 AMXBAJ S/ST"));
    }

    @Test
    public void retrievesPONumberWhenTheRemainingOrdersWhenDistChanShortNameIsNull() throws Exception {
        final SeasonTypeVO seasonTypeVO = new SeasonTypeVO();
        seasonTypeVO.setSeasonTypeCode("OI");

        final SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonTypeBySeasonTypeId(seasonTypeVO);

        when(seasonBusiness.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        final FiscalYearVO fiscalYearVO = new FiscalYearVO();
        fiscalYearVO.setFiscalYear(2013L);

        when(fiscalYearBusiness.retrieveActiveFiscalYear(Matchers.<Date>any())).thenReturn(fiscalYearVO);

        final DistributionChannelVO distributionChannelVO = new DistributionChannelVO();

        when(distributionChannelBusiness.retrieveDistributionChannel("3R")).thenReturn(distributionChannelVO);

        final String poNumber = unit.generatePONumber(CLOrderTypeEnum.WITH_ALGORITHM.code(), "AMXBAJ", "3R");
        assertThat(poNumber, is(notNullValue()));
        assertThat(poNumber, is("OI13 AMXBAJ"));
    }

    @Test
    public void retrievesPONumberWhenTheRemainingOrdersWhenDistChanShortNameIsNotNull() throws Exception {
        final SeasonTypeVO seasonTypeVO = new SeasonTypeVO();
        seasonTypeVO.setSeasonTypeCode("OI");

        final SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonTypeBySeasonTypeId(seasonTypeVO);

        when(seasonBusiness.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        final FiscalYearVO fiscalYearVO = new FiscalYearVO();
        fiscalYearVO.setFiscalYear(2013L);

        when(fiscalYearBusiness.retrieveActiveFiscalYear(Matchers.<Date>any())).thenReturn(fiscalYearVO);

        final DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setShortName("CONV");

        when(distributionChannelBusiness.retrieveDistributionChannel("3R")).thenReturn(distributionChannelVO);

        final String poNumber = unit.generatePONumber(CLOrderTypeEnum.WITH_ALGORITHM.code(), "AMXBAJ", "3R");
        assertThat(poNumber, is(notNullValue()));
        assertThat(poNumber, is("OI13 AMXBAJ CONV"));
    }

}
