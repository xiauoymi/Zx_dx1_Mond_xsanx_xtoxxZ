package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.CropService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.dto.SubRegionDTO;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PlantVO;
import com.monsanto.customerlink.persistence.entities.SubRegionVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PlantRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PlantServiceImpl_UT {

    @Mock
    private CropService cropService;

    @Mock
    private PlantRepository plantRepository;

    @Mock
    private DistributorRepository distributorRepository;

    @Mock
    private PlantService unit;

    @Before
    public void before() {
        reset(plantRepository,cropService,distributorRepository);
        unit = new PlantServiceImpl(cropService,plantRepository,distributorRepository);
    }

    @Test
    public void obtainPlantsAccordingToCrop_Corn() throws Exception{
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSubRegionCode("SUB_REGION");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorConfigDTO.setDistributor(distributorDTO);

        CropVO cropVO = new CropVO();
        cropVO.setCropId(1L);
        cropVO.setCropCode(SeedsCropCodeEnum.CORN.getCode());

        List<PlantVO> plants = new ArrayList<PlantVO>();
        plants.add(new PlantVO());

        when(plantRepository.findByCropByCropIdAndSubRegionBySubRegionCode(any(CropVO.class), any(SubRegionVO.class))).thenReturn(plants);

        List<PlantVO> listOfPlants = unit.obtainPlantsAccordingToCrop(cropVO, distributorConfigDTO);
        assertTrue(!listOfPlants.isEmpty());
    }

    @Test
    public void obtainPlantsAccordingToCrop_Cotton() throws Exception{
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSubRegionCode("SUB_REGION");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorConfigDTO.setDistributor(distributorDTO);

        CropVO cropVO = new CropVO();
        cropVO.setCropId(1L);
        cropVO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        List<PlantVO> plants = new ArrayList<PlantVO>();
        plants.add(new PlantVO());

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);
        when(plantRepository.findByParameters(anyLong(), anyString(), anyString())).thenReturn(plants);

        List<PlantVO> listOfPlants = unit.obtainPlantsAccordingToCrop(cropVO, distributorConfigDTO);
        assertTrue(!listOfPlants.isEmpty());
    }

    @Test
    public void obtainPlantsAccordingToCropByCropCode_Cotton() throws Exception{
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSubRegionCode("SUB_REGION");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorConfigDTO.setDistributor(distributorDTO);

        CropVO cropVO = new CropVO();
        cropVO.setCropId(1L);
        cropVO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        List<PlantVO> plants = new ArrayList<PlantVO>();
        plants.add(new PlantVO());

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);
        when(plantRepository.findByParameters(anyLong(), anyString(), anyString())).thenReturn(plants);

        when(cropService.obtainCropByCode(anyString())).thenReturn(cropVO);
        List<PlantVO> listOfPlants = unit.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.COTTON.getCode(), distributorConfigDTO);


        assertTrue(!listOfPlants.isEmpty());
    }


    @Test
    public void obtainPlantsAccordingToCropByCropCode_RegularAgrochemical() throws Exception{
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSubRegionCode("SUB_REGION");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorConfigDTO.setDistributor(distributorDTO);

        CropVO cropVO = new CropVO();
        cropVO.setCropId(1L);
        cropVO.setCropCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());

        List<PlantVO> plants = new ArrayList<PlantVO>();
        plants.add(new PlantVO());

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("REGION");
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);
        when(plantRepository.findByParameters(anyLong(), anyString(), anyString())).thenReturn(plants);

        when(cropService.obtainCropByCode(anyString())).thenReturn(cropVO);
        List<PlantVO> listOfPlants = unit.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.COTTON.getCode(), distributorConfigDTO);

        assertTrue(!listOfPlants.isEmpty());
    }

    @Test
    public void obtainPlantsAccordingToCropByCropCode_RegularAgrochemical_WhenSubRegionIsNull() throws Exception{
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSubRegionCode("SUB_REGION");

        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorConfigDTO.setDistributor(distributorDTO);

        CropVO cropVO = new CropVO();
        cropVO.setCropId(1L);
        cropVO.setCropCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());

        List<PlantVO> plants = new ArrayList<PlantVO>();
        plants.add(new PlantVO());

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion(null);     // subregion is null
        when(distributorRepository.findByDistributorCode(anyString())).thenReturn(distributorVO);
        when(plantRepository.findByParameters(anyLong(), anyString(), anyString())).thenReturn(plants);

        when(cropService.obtainCropByCode(anyString())).thenReturn(cropVO);
        List<PlantVO> listOfPlants = unit.obtainPlantsAccordingToCrop(SeedsCropCodeEnum.COTTON.getCode(), distributorConfigDTO);

        assertTrue(listOfPlants.isEmpty());
    }

}