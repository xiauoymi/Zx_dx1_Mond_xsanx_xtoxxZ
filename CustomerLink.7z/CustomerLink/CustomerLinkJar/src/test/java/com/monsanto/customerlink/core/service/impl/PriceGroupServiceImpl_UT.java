package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.PriceGroupService;
import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.exception.PriceGroupNotFoundForOrderException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PriceGroupVO;
import com.monsanto.customerlink.persistence.entities.SeasonTypeVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.persistence.repositories.PriceGroupRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PriceGroupServiceImpl_UT {

    @Mock
    private PriceGroupRepository priceGroupRepository;
    @Mock
    private Mapper mapper;
    @Mock
    private SeasonService seasonService;
    @Mock
    private DistributorRepository distributorRepository;

    private PriceGroupService priceGroupService;

    @org.junit.Before
    public void setup() {
        priceGroupService = new PriceGroupServiceImpl(priceGroupRepository, mapper, seasonService, distributorRepository);
    }

    @Test
    public void findConditionForProductWhenExistInRepository() throws Exception {
        ProductDTO productDTO = new ProductDTO();
        priceGroupService.findConditionTypeForProduct(productDTO);
    }

    @Test
    public void findValidPriceGroupForOrderWhenExistInRepository() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(configDTO);
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        when(priceGroupRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()))
                .thenReturn(priceGroupVO);

        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "CB",
                SeedsCropCodeEnum.CORN.getCode()));
    }

    @Test(expected = PriceGroupNotFoundForOrderException.class)
    public void throwsPriceGroupNotFoundWhenNotFoundInRepository() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        orderDTO.setDistributorConfigDTO(configDTO);
        reset(priceGroupRepository);
        when(priceGroupRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any())).thenReturn(null);
        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "CB",
                SeedsCropCodeEnum.CORN.getCode());
    }

    @Test(expected = ActiveSeasonNotFoundException.class)
    public void throwsActiveSeasonNotFoundWhentryToGetItInRepositoryButNotExists() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        orderDTO.setDistributorConfigDTO(configDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        when(priceGroupRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any())).thenReturn(priceGroupVO);

        Mockito.doThrow(ActiveSeasonNotFoundException.class).when(seasonService).retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any());

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "CB",
                SeedsCropCodeEnum.CORN.getCode()));
    }

    @Test(expected = PriceGroupNotFoundForOrderException.class)
    public void throwsPriceGroupNotFoundExceptionWhenPriceGroupIsNotFoundInTheRepository_ByCode() throws Exception {
        when(priceGroupRepository.findByPriceGroupCode(Matchers.<String>any())).thenReturn(null);

        priceGroupService.retrievePriceGroupByCode("MN");
    }

    @Test
    public void retrievesPriceGroupVO_ByCode() throws Exception {
        when(priceGroupRepository.findByPriceGroupCode(Matchers.<String>any())).thenReturn(new PriceGroupVO());

        final PriceGroupVO priceGroupVO = priceGroupService.retrievePriceGroupByCode("MN");
        assertThat(priceGroupVO, is(notNullValue()));
    }

    @Test
    public void findValidPriceGroupForForCottonOrderWhenExistInRepositoryAndDistrubutorDoesNotHaveRegion() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(configDTO);
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        reset(distributorRepository);

        when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(new DistributorVO());

        when(priceGroupRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()))
                .thenReturn(priceGroupVO);

        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "CB",
                SeedsCropCodeEnum.CORN.getCode()));
    }

    @Test
    public void findValidPriceGroupForForCottonOrderWhenExistInRepositoryAndDistrubutorHasRegion() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(configDTO);
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        reset(distributorRepository);

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("AMXNET");

        when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(distributorVO);

        when(priceGroupRepository.findByParameters(Matchers.<String>any(), Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()))
                .thenReturn(priceGroupVO);

        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "CB",
                SeedsCropCodeEnum.COTTON.getCode()));
    }

    @Test
    public void findValidPriceGroupForForCottonOrderWhenExistInRepositoryAndDistrubutorHasRegion_AndBrandIsNot_CB() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(configDTO);
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        reset(distributorRepository);

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("AMXNET");

        when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(distributorVO);

        when(priceGroupRepository.findByParametersWithOutBrand(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()))
                .thenReturn(priceGroupVO);

        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), "OtherBrand",
                SeedsCropCodeEnum.COTTON.getCode()));
    }

    @Test
    public void findValidPriceGroupForForCottonOrderWhenExistInRepositoryAndDistrubutorHasRegion_AndBrandIsNull() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(configDTO);
        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);
        PriceGroupVO priceGroupVO = new PriceGroupVO();
        reset(mapper);
        reset(priceGroupRepository);
        reset(distributorRepository);

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setRegion("AMXNET");

        when(distributorRepository.findByDistributorCode(Matchers.<String>any())).thenReturn(distributorVO);

        when(priceGroupRepository.findByParametersWithOutBrand(Matchers.<String>any(),
                Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any(), Matchers.<String>any()))
                .thenReturn(priceGroupVO);

        SeasonVO seasonVO = new SeasonVO();
        SeasonTypeVO vo = new SeasonTypeVO();
        seasonVO.setSeasonTypeBySeasonTypeId(vo);
        when(seasonService.retrieveActiveSeason(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        when(mapper.map(priceGroupVO, PriceGroupDTO.class)).thenReturn(new PriceGroupDTO());
        Assert.assertNotNull(priceGroupService.findPriceGroupForOrder(orderDTO.getDistributorConfigDTO(), null,
                SeedsCropCodeEnum.COTTON.getCode()));
    }




}
