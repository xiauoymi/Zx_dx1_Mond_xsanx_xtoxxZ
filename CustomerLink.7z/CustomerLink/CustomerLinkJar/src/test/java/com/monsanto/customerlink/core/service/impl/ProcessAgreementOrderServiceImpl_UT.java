package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProcessAgreementOrderServiceImpl_UT {

    ProcessAgreementOrderService processAgreementOrderService;

    @Mock
    private SAPOrderService sapOrderService;
    @Mock
    private IncreaseDecreaseATPHelper increaseDecreaseATPHelper;
    @Mock
    private ProcessOrderInSapService processOrderInSapService;
    @Mock
    private ProcessOrderNotInSapService processOrderNotInSapService;

    Map<AgreementDTO, List<OrderDTO>> map = new HashMap<AgreementDTO, List<OrderDTO>>();

    @Before
    public void setup() {
        processAgreementOrderService = new ProcessAgreementOrderServiceImpl(
                increaseDecreaseATPHelper,
                sapOrderService,
                processOrderInSapService,
                processOrderNotInSapService);

        for (int i = 0; i < 5; i++) {

            AgreementDTO agreementDTO = new AgreementDTO();
            List<OrderDTO> list = new ArrayList<OrderDTO>();

            for (int j = 0; j < 5; j++) {
                OrderDTO orderDTO = new OrderDTO();
                list.add(orderDTO);
            }

            map.put(agreementDTO, list);
        }
    }

    @Test
    public void testThatWhenProcessAgrochemicalOrdersReceiveEmptyOrdersSoNothingIsProcessed() {

        processAgreementOrderService.processAgrochemicalOrders(new HashMap<AgreementDTO, List<OrderDTO>>());
    }

    @Test
    public void testAgreementAndTheirOrdersAreProcessedAndAllHaveSapOrder() throws Exception {
        reset(sapOrderService);
        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());
        processAgreementOrderService.processAgrochemicalOrders(map);
    }

    @Test
    public void testAgreementAreprocessedButExceptionIsThrowedWhenConsultingInsap() throws Exception {
        reset(sapOrderService);
        when(sapOrderService.retrieveOrder(Matchers.<OrderDTO>any())).thenThrow(new CustomerLinkBusinessException());
        processAgreementOrderService.processAgrochemicalOrders(map);
    }

    @Test
    public void processAgreementOrdersWhen_BothSubProcessWasNotCompleted() throws Exception {
        reset(sapOrderService);
        when(processOrderInSapService.processOrdersWithSapOrder(anyMap(),any(AgreementDTO.class))).thenReturn(false);
        when(processOrderNotInSapService.processOrdersWithoutSapOrder(anyMap(), any(AgreementDTO.class))).thenReturn(false);
        processAgreementOrderService.processAgrochemicalOrders(map);
        assertFalse(processAgreementOrderService.processAgrochemicalOrders(map));

    }

    @Test
    public void processAgreementOrdersWhen_OrdersWithSapOrderWasCompleted() throws Exception {
        reset(sapOrderService);
        when(processOrderInSapService.processOrdersWithSapOrder(anyMap(),any(AgreementDTO.class))).thenReturn(true);
        when(processOrderNotInSapService.processOrdersWithoutSapOrder(anyMap(), any(AgreementDTO.class))).thenReturn(false);
        processAgreementOrderService.processAgrochemicalOrders(map);
        assertFalse(processAgreementOrderService.processAgrochemicalOrders(map));
    }

    @Test
    public void processAgreementOrdersWhen_OrdersWithOutSapOrderWasCompleted() throws Exception {
        reset(sapOrderService);
        when(processOrderInSapService.processOrdersWithSapOrder(anyMap(),any(AgreementDTO.class))).thenReturn(false);
        when(processOrderNotInSapService.processOrdersWithoutSapOrder(anyMap(), any(AgreementDTO.class))).thenReturn(true);
        processAgreementOrderService.processAgrochemicalOrders(map);
        assertFalse(processAgreementOrderService.processAgrochemicalOrders(map));

    }

    @Test
    public void processAgreementOrdersWhen_BothSubProcessWasCompleted() throws Exception {
        reset(sapOrderService);
        when(processOrderInSapService.processOrdersWithSapOrder(anyMap(),any(AgreementDTO.class))).thenReturn(true);
        when(processOrderNotInSapService.processOrdersWithoutSapOrder(anyMap(), any(AgreementDTO.class))).thenReturn(true);
        processAgreementOrderService.processAgrochemicalOrders(map);
        assertTrue(processAgreementOrderService.processAgrochemicalOrders(map));
    }
}