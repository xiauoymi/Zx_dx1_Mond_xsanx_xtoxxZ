package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.AgreementService;
import com.monsanto.customerlink.core.service.ProcessAgreementOrderService;
import com.monsanto.customerlink.core.service.ProcessAgrementService;
import com.monsanto.customerlink.core.service.SendAgrochemicalPricesService;
import com.monsanto.customerlink.core.service.exception.AgreementRetrieveByParametersNotFoundException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.DistributorVO;
import com.monsanto.customerlink.persistence.entities.PrivateBrandDistributorVO;
import com.monsanto.customerlink.persistence.repositories.DistributorRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ProcessAgrementServiceImpl_UT {


    @Mock
    private DistributorRepository distributorRepository;
    @Mock
    private AgreementService agreementService;
    @Mock
    private SendAgrochemicalPricesService sendAgrochemicalPricesService;
    @Mock
    private Mapper mapper;
    @Mock
    private ProcessAgreementOrderService processAgreementOrderService;

    ProcessAgrementService processAgrementService;

    List<DistributorVO> distributorVOs = new ArrayList<DistributorVO>();
    List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
    List<AgreementDTO> agreementDTOs = new ArrayList<AgreementDTO>();

    @Before
    public void setup() {
        processAgrementService = new ProcessAgrementServiceImpl(distributorRepository, agreementService,
                mapper, sendAgrochemicalPricesService,
                processAgreementOrderService);

        for (int i = 0; i < 5; i++) {
            DistributorVO distributorVO = new DistributorVO();
            distributorVO.setDistributorCode("code" + i);
            distributorVO.setPrivateBrandDistributorsByDistributorCode(new ArrayList<PrivateBrandDistributorVO>());
            distributorVOs.add(distributorVO);
        }

        for (int j = 0; j < 5; j++) {
            OrderDTO orderDTO = new OrderDTO();
            orderDTOList.add(orderDTO);

            AgreementDTO agreementDTO = new AgreementDTO();
            DistributorConfigDTO configDTO = new DistributorConfigDTO();
            DistributorDTO distributorDTO = new DistributorDTO();
            distributorDTO.setDistributorCode("code" + j);
            configDTO.setDistributor(distributorDTO);
            agreementDTO.setDistributorConfig(configDTO);
            agreementDTOs.add(agreementDTO);
        }
    }

    @Test
    public void testNotExistPrivateBrandDistributorsSoAnyAgreementIsProcessed() {
        reset(distributorRepository);
        when(distributorRepository.findPrivateBrand()).thenReturn(new ArrayList<DistributorVO>());
        processAgrementService.processAgreementService();
        verify(distributorRepository).findPrivateBrand();
    }

    @Test
    public void testExistPrivateBrandDistributorsButThereIsNotAnyAgreementForThem() throws Exception {
        reset(distributorRepository);
        when(distributorRepository.findPrivateBrand()).thenReturn(distributorVOs);

        reset(agreementService);
        when(agreementService.retrieveAgreementByParameters(Matchers.<AgreementDTO>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(new ArrayList<AgreementDTO>());

        processAgrementService.processAgreementService();
        verify(distributorRepository).findPrivateBrand();
        //verify(agreementService).retrieveAgreementByParameters(Matchers.<AgreementDTO>any(), Matchers.<DistributorConfigDTO>any());
    }


    @Test
    public void testExistPrivateBrandDistributorsButExceptionIsLoggedWhenConsultingTheirAgreements() throws Exception {
        reset(distributorRepository);
        when(distributorRepository.findPrivateBrand()).thenReturn(distributorVOs);

        reset(agreementService);
        AgreementRetrieveByParametersNotFoundException e = new AgreementRetrieveByParametersNotFoundException(new Object[]{});
        when(agreementService.retrieveAgreementByParameters(Matchers.<AgreementDTO>any(), Matchers.<DistributorConfigDTO>any())).thenThrow(e);

        processAgrementService.processAgreementService();
        verify(distributorRepository).findPrivateBrand();
    }

    @Test
    public void testExistAgreementsButSkuDontHaveValidCurrencies() throws Exception {
        reset(distributorRepository);
        when(distributorRepository.findPrivateBrand()).thenReturn(distributorVOs);

        reset(agreementService);
        when(agreementService.retrieveAgreementByParameters(Matchers.<AgreementDTO>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(new ArrayList<AgreementDTO>());

        reset(sendAgrochemicalPricesService);
        when(sendAgrochemicalPricesService.obtainOrderByCurrency(Matchers.<List<OrderDTO>>any())).thenReturn(new ArrayList<OrderDTO>());

        processAgrementService.processAgreementService();
        verify(distributorRepository).findPrivateBrand();
    }

    @Test
    public void testThereAreAgreementWitCorrectCurrenciesAndAreSendedToProcess() throws Exception {
        reset(distributorRepository);
        when(distributorRepository.findPrivateBrand()).thenReturn(distributorVOs);

        reset(agreementService);
        when(agreementService.retrieveAgreementByParameters(Matchers.<AgreementDTO>any(), Matchers.<DistributorConfigDTO>any())).thenReturn(agreementDTOs);

        reset(sendAgrochemicalPricesService);
        when(sendAgrochemicalPricesService.obtainOrderByCurrency(Matchers.<List<OrderDTO>>any())).thenReturn(orderDTOList);

        when(mapper.map(Matchers.<Object>any(), any(Class.class))).thenReturn(new OrderDTO());

        processAgrementService.processAgreementService();
        verify(distributorRepository).findPrivateBrand();
        verify(processAgreementOrderService).processAgrochemicalOrders(Matchers.<Map<AgreementDTO, List<OrderDTO>>>any());
    }

}
