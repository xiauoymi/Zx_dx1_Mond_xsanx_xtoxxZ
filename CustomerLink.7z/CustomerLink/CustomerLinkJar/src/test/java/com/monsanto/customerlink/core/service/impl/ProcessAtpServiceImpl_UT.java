package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.catalog.SubregionService;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.SeasonRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.*;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProcessAtpServiceImpl_UT {

    ProcessAtpService processAtpService;
    @Mock
    IncreaseDecreaseATPService increaseDecreaseATPService;
    @Mock
    SubregionService subregionService;
    @Mock
    PurchaseOrderService purchaseOrderService;
    @Mock
    NotificationSender mailNotificationSender;
    @Mock
    private SendPricesService sendPricesService;
    @Mock
    NotificationType notificationType;

    @Mock
    JAXWSClientFactory jaxwsClientFactory;
    @Mock
    JAXWSClientFactory jaxwsClientFactorytest;

    @Mock
    MailUtilService mailUtilService;
    @Mock
    private SeasonRepository seasonRepository;

    @Before
    public void setup() {
        processAtpService = new ProcessAtpServiceImpl(increaseDecreaseATPService, subregionService,
                purchaseOrderService, mailNotificationSender, sendPricesService, mailUtilService, seasonRepository);
    }


    @Test
    public void testLoadAtpButSubregionAndSeasonAreFounded() throws Exception {

        List<SubRegionDTO> list = new ArrayList<SubRegionDTO>();
        for (int i = 0; i < 10; i++) {
            SubRegionDTO reg = new SubRegionDTO();
            list.add(reg);
        }

        reset(seasonRepository);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        reset(subregionService);
        when(subregionService.findAllSubregions()).thenReturn(list);
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        aSpy.processAtp();
    }

    @Test
    public void testLoadAtpButTheResultIsEmpty() throws Exception {
        reset(subregionService);
        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        aSpy.processAtp();
    }

    @Test
    public void testAtpIsChargedAndSendedToProcessButAtpOrderMissingArgumentsExceptionIsThrow() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            orderDTOList.add(new OrderDTO());
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);
        reset(sendPricesService);
        when(sendPricesService.obtainOrderByCurrency(Matchers.<List<OrderDTO>>any())).thenReturn(orderDTOList);

        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(AtpOrderMissingArgumentsException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }

    @Test
    public void testAtpIsChargedAndSendedToProcessButCustomerLinkBusinessExceptionIsThrow() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            orderDTOList.add(new OrderDTO());
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);
        reset(sendPricesService);
        when(sendPricesService.obtainOrderByCurrency(Matchers.<List<OrderDTO>>any())).thenReturn(orderDTOList);

        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(CustomerLinkBusinessException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }

    @Test
    public void testAtpIsChargeThenOrderAreFilteredAndSeasonNotFoundExceptionIsThrownForAllOfThem() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            OrderDTO orderDTO = new OrderDTO();
            DistributorConfigDTO configDTO = new DistributorConfigDTO();
            DistributorDTO dto = new DistributorDTO();
            configDTO.setDistributor(dto);
            orderDTO.setDistributorConfigDTO(configDTO);
            orderDTOList.add(orderDTO);
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        Mockito.doThrow(SeasonNotFoundException.class).when(purchaseOrderService).validateExistPurchaseOrderApproved(Matchers.<OrderDTO>any());
        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(CustomerLinkBusinessException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }

    @Test
    public void testAtpIsChargeThenOrderAreFilteredAndDistributorNotFoundExceptionIsThrownForAllOfThem() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            OrderDTO orderDTO = new OrderDTO();
            DistributorConfigDTO configDTO = new DistributorConfigDTO();
            DistributorDTO dto = new DistributorDTO();
            configDTO.setDistributor(dto);
            orderDTO.setDistributorConfigDTO(configDTO);
            orderDTOList.add(orderDTO);
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        Mockito.doThrow(DistributorConfigNotFoundException.class).when(purchaseOrderService).validateExistPurchaseOrderApproved(Matchers.<OrderDTO>any());
        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);

        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(CustomerLinkBusinessException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }

    @Test
    public void testAtpIsChargeThenOrderAreFilteredAndPurchaseOrderApprovedNotFoundExceptionIsThrownForAllOfThem() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            OrderDTO orderDTO = new OrderDTO();
            DistributorConfigDTO configDTO = new DistributorConfigDTO();
            DistributorDTO dto = new DistributorDTO();
            configDTO.setDistributor(dto);
            orderDTO.setDistributorConfigDTO(configDTO);
            orderDTOList.add(orderDTO);
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        Mockito.doThrow(PurchaseOrderApprovedNotFoundException.class).when(purchaseOrderService).validateExistPurchaseOrderApproved(Matchers.<OrderDTO>any());
        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(CustomerLinkBusinessException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }


    @Test
    public void testAtpIsChargeThenRCDNotFoundExceptionIsThrownForAllOfThem() throws Exception {

        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        for (int i = 0; i < 2; i++) {
            OrderDTO orderDTO = new OrderDTO();
            DistributorConfigDTO configDTO = new DistributorConfigDTO();
            DistributorDTO dto = new DistributorDTO();
            configDTO.setDistributor(dto);
            orderDTO.setDistributorConfigDTO(configDTO);
            orderDTOList.add(orderDTO);
        }
        reset(subregionService);
        reset(jaxwsClientFactory);
        reset(purchaseOrderService);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        when(subregionService.findAllSubregions()).thenReturn(new ArrayList<SubRegionDTO>());
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        Mockito.doThrow(RCDNotFoundException.class).when(purchaseOrderService).validateExistPurchaseOrderApproved(Matchers.<OrderDTO>any());
        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.when(aSpy.getPurchasenotification()).thenReturn(notificationType);
        Mockito.doReturn(jaxwsClientFactory).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();
        Mockito.doReturn(orderDTOList).when((ProcessAtpServiceImpl) aSpy).loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any());
        Mockito.doThrow(CustomerLinkBusinessException.class).when(increaseDecreaseATPService).runProcessChangeInATP(Matchers.<OrderDTO>any());
        aSpy.processAtp();
    }


    @Test
    public void testThatExceptionisControlledWhenAtInvokeAtpClientAnErrorsOcurrs() throws Exception {

        List<SubRegionDTO> list = new ArrayList<SubRegionDTO>();
        for (int i = 0; i < 10; i++) {
            SubRegionDTO reg = new SubRegionDTO();
            list.add(reg);
        }

        reset(seasonRepository);
        SeasonVO season = new SeasonVO();
        season.setSeasonEndDate(new Timestamp(new Date().getTime()));
        season.setSeasonStartDate(new Timestamp(new Date().getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(season);

        reset(subregionService);
        when(subregionService.findAllSubregions()).thenReturn(list);
        reset(mailUtilService);
        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        ProcessAtpServiceImpl aSpy = Mockito.spy((ProcessAtpServiceImpl) processAtpService);
        Mockito.doReturn(jaxwsClientFactorytest).when((ProcessAtpServiceImpl) aSpy).getJaxwsClientFactory();

        //Mockito.doThrow(new InventoryAtpExceptionException("exception logged in test", new  InventoryAtpException())).when(aSpy.loadAtp(Matchers.<Map<SubRegionDTO, SeasonVO>>any(), Matchers.<JAXWSClientFactory>any()));
        aSpy.processAtp();
    }
}
