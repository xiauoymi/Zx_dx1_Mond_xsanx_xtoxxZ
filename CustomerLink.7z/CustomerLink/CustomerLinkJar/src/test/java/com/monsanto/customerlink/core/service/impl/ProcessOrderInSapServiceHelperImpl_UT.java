package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProcessOrderInSapServiceHelper;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Mockito.reset;

@RunWith(MockitoJUnitRunner.class)
public class ProcessOrderInSapServiceHelperImpl_UT {

    @Mock
    private RegularAgrochemicalsService regularAgrochemicalsService;

    private ProcessOrderInSapServiceHelper unit;

    @Before
    public void before() {
        reset(regularAgrochemicalsService);
        unit = new ProcessOrderInSapServiceHelperImpl(regularAgrochemicalsService);
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsInOnePlant_InFirstPlantInPriority() throws Exception{

        List<MaterialSkuDTO> listSku = new ArrayList<MaterialSkuDTO>();

        MaterialSkuDTO m0 = new MaterialSkuDTO();
        m0.setMaterial("MAT_00");
        m0.setUnrestqty(60);
        listSku.add(m0);

        MaterialSkuDTO m1 = new MaterialSkuDTO();
        m1.setMaterial("MAT_01");
        m1.setUnrestqty(55);
        listSku.add(m1);

        MaterialSkuDTO m2 = new MaterialSkuDTO();
        m2.setMaterial("MAT_02");
        m2.setUnrestqty(40);
        listSku.add(m2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setListOfSku(listSku);

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        List<OrderDetailDTO> detailList = new ArrayList<OrderDetailDTO>();
        detailList.add(orderDetailDTO);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDetail(detailList);

        List<MaterialSkuDTO> materialsWithDifference = new ArrayList<MaterialSkuDTO>();

        MaterialSkuDTO mA = new MaterialSkuDTO();
        mA.setMaterial("MAT_00");
        mA.setUnrestqty(15);
        materialsWithDifference.add(mA);

        MaterialSkuDTO mB = new MaterialSkuDTO();
        mB.setMaterial("MAT_01");
        mB.setUnrestqty(5);
        materialsWithDifference.add(mB);

        MaterialSkuDTO mC = new MaterialSkuDTO();
        mC.setMaterial("MAT_05");
        mC.setUnrestqty(12);
        materialsWithDifference.add(mC);

        unit.filterMaterialsWithIncreaseQuantity(orderDTO,materialsWithDifference);
        assertTrue(orderDTO.getDetail().get(0).getProductDTO().getListOfSku().size() == 2);
    }

    @Test
    public void updateAgrochemicalOrderOnSAP_WithOutErrors() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.setSalesorder("SALES_ORDER_ID");
        assertTrue(unit.updateAgrochemicalOrderOnSAP(orderDTO,sapOrderDTO));
    }

    @Test
    public void updateAgrochemicalOrderOnSAP_WithErrors() throws Exception {
        OrderDTO orderDTO = new OrderDTO();
        SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.setSalesorder("SALES_ORDER_ID");
        Mockito.doThrow(CustomerLinkBusinessException.class).when(regularAgrochemicalsService).processAgrochemicalsOrder(any(OrderDTO.class), anyBoolean());
        assertFalse(unit.updateAgrochemicalOrderOnSAP(orderDTO, sapOrderDTO));
    }
}