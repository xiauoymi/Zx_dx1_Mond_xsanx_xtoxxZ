package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.ProcessOrderInSapService;
import com.monsanto.customerlink.core.service.ProcessOrderInSapServiceHelper;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.AgreementVO;
import com.monsanto.customerlink.persistence.repositories.AgreementRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class ProcessOrderInSapServiceImpl_UT {

    ProcessOrderInSapService processOrderInSapService;
    @Mock
    private Mapper mapper;
    @Mock
    private MailUtilService mailUtilService;
    @Mock
    private NotificationSender mailNotificationSender;

    @Mock
    private AgreementRepository agreementRepository;

    @Mock
    private NotificationType notificationType;

    @Mock
    private ProcessOrderInSapServiceHelper helper;

    Map<OrderDTO, SAPOrderDTO> map = new HashMap<OrderDTO, SAPOrderDTO>();
    Map<OrderDTO, SAPOrderDTO> mapWithNulls = new HashMap<OrderDTO, SAPOrderDTO>();

    Map<OrderDTO, SAPOrderDTO> mapWithDetail = new HashMap<OrderDTO, SAPOrderDTO>();
    Map<OrderDTO, SAPOrderDTO> mapWithDetailDif = new HashMap<OrderDTO, SAPOrderDTO>();

    @Before
    public void setup() {
        processOrderInSapService = new ProcessOrderInSapServiceImpl(mapper,helper);

        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
            map.put(orderDTO, sapOrderDTO);
        }

        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = null;
            mapWithNulls.put(orderDTO, sapOrderDTO);
        }


        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            for (int k = 0; k < 10; k++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + k);
                materialSkuDTO.setUnrestqty(0d);

                productDTO.getListOfSku().add(materialSkuDTO);
            }

            orderDetailDTO.setProductDTO(productDTO);
            orderDTO.getDetail().add(orderDetailDTO);

            HybridDTO hybridDTO = new HybridDTO();

            for (int k = 0; k < 5; k++) {
                MaterialDTO materialDTO = new MaterialDTO();
                materialDTO.setUnrestqty(BigDecimal.ZERO);
                materialDTO.setReq_qty(0d);

                materialDTO.setMaterial("material" + k);
                hybridDTO.getSkus().add(materialDTO);
            }

            sapOrderDTO.getHybrids().add(hybridDTO);
            mapWithDetail.put(orderDTO, sapOrderDTO);
        }


        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            for (int k = 0; k < 10; k++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + k);
                materialSkuDTO.setUnrestqty(5d);
                productDTO.getListOfSku().add(materialSkuDTO);
            }

            orderDetailDTO.setProductDTO(productDTO);
            orderDTO.getDetail().add(orderDetailDTO);

            HybridDTO hybridDTO = new HybridDTO();

            for (int k = 0; k < 5; k++) {
                MaterialDTO materialDTO = new MaterialDTO();
                materialDTO.setUnrestqty(BigDecimal.ZERO);
                materialDTO.setMaterial("material" + k);
                materialDTO.setReq_qty(0d);
                hybridDTO.getSkus().add(materialDTO);
            }

            sapOrderDTO.getHybrids().add(hybridDTO);
            mapWithDetailDif.put(orderDTO, sapOrderDTO);
        }
    }

    @Test
    public void notProcessAnyAgreeement() {
        processOrderInSapService.processOrdersWithSapOrder(new HashMap<OrderDTO, SAPOrderDTO>(), new AgreementDTO());
    }

    @Test
    public void notProcessAnyOrderBecauseTheseDoesNotHaveSapOrder() {
        processOrderInSapService.processOrdersWithSapOrder(mapWithNulls, new AgreementDTO());
    }

    @Test
    public void processOrderWhichAllHasSapOrderButWithoutDetail() {

        Mockito.reset(mapper);
        reset(agreementRepository);
        when(mapper.map(Matchers.any(), Matchers.any(Class.class))).thenReturn(new MaterialSkuDTO());

        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());
        processOrderInSapService.processOrdersWithSapOrder(map, new AgreementDTO());
    }

    @Test
    public void processOrderWhichAllHasSapOrderAndDetailButThereAreNotDifferences() {
        Mockito.reset(mapper);
        reset(agreementRepository);
        when(mapper.map(Matchers.any(), Matchers.any(Class.class))).thenReturn(new MaterialSkuDTO());

        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());

        processOrderInSapService.processOrdersWithSapOrder(mapWithDetail, new AgreementDTO());
    }

    @Test
    public void processOrderWhichAllHasSapOrderAndDetailAndThereAreDifferences() {

        Mockito.reset(mapper);
        reset(agreementRepository);
        when(mapper.map(Matchers.any(), Matchers.any(Class.class))).thenReturn(new MaterialSkuDTO());

        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());

        ProcessOrderInSapService aSpy = Mockito.spy(processOrderInSapService);
        Mockito.doReturn(notificationType).when((ProcessOrderInSapServiceImpl) aSpy).getAgrochemicalDifferencesNotificationType();

        aSpy.processOrdersWithSapOrder(mapWithDetailDif, new AgreementDTO());

    }

    @Test
    public void processOrderWhichAllHasSapOrderAndDetailAndThereAreDifferences_WhenUpdateWasSuccess() {

        Mockito.reset(mapper);
        reset(agreementRepository);
        when(mapper.map(Matchers.any(), Matchers.any(Class.class))).thenReturn(new MaterialSkuDTO());

        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());

        ProcessOrderInSapService aSpy = Mockito.spy(processOrderInSapService);
        Mockito.doReturn(notificationType).when((ProcessOrderInSapServiceImpl) aSpy).getAgrochemicalDifferencesNotificationType();
        when(helper.updateAgrochemicalOrderOnSAP(any(OrderDTO.class),any(SAPOrderDTO.class))).thenReturn(true);

        aSpy.processOrdersWithSapOrder(mapWithDetailDif, new AgreementDTO());

    }
}