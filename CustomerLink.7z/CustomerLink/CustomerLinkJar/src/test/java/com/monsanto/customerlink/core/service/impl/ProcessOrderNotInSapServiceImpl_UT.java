package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProcessOrderNotInSapService;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.dto.HybridDTO;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.StatusEnum;
import com.monsanto.customerlink.persistence.entities.AgreementVO;
import com.monsanto.customerlink.persistence.repositories.AgreementRepository;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProcessOrderNotInSapServiceImpl_UT {


    ProcessOrderNotInSapService processOrderNotInSapService;

    @Mock
    private AgreementRepository agreementRepository;
    @Mock
    private RegularAgrochemicalsService regularAgrochemicalsService;

    Map<OrderDTO, SAPOrderDTO> map = new HashMap<OrderDTO, SAPOrderDTO>();
    Map<OrderDTO, SAPOrderDTO> mapWithNulls = new HashMap<OrderDTO, SAPOrderDTO>();

    Map<OrderDTO, SAPOrderDTO> mapWithDetail = new HashMap<OrderDTO, SAPOrderDTO>();
    Map<OrderDTO, SAPOrderDTO> mapWithDetailDif = new HashMap<OrderDTO, SAPOrderDTO>();

    @Before
    public void setup() {
        processOrderNotInSapService = new ProcessOrderNotInSapServiceImpl(
                agreementRepository, regularAgrochemicalsService);


        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
            map.put(orderDTO, sapOrderDTO);
        }

        for (int i = 0; i < 2; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = null;
            mapWithNulls.put(orderDTO, sapOrderDTO);
        }


        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            for (int k = 0; k < 10; k++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + k);
                materialSkuDTO.setUnrestqty(0d);
                productDTO.getListOfSku().add(materialSkuDTO);
            }

            orderDetailDTO.setProductDTO(productDTO);
            orderDTO.getDetail().add(orderDetailDTO);

            HybridDTO hybridDTO = new HybridDTO();

            for (int k = 0; k < 5; k++) {
                MaterialDTO materialDTO = new MaterialDTO();
                materialDTO.setUnrestqty(BigDecimal.ZERO);
                materialDTO.setMaterial("material" + k);
                hybridDTO.getSkus().add(materialDTO);
            }

            sapOrderDTO.getHybrids().add(hybridDTO);
            mapWithDetail.put(orderDTO, sapOrderDTO);
        }


        for (int i = 0; i < 5; i++) {
            OrderDTO orderDTO = new OrderDTO();
            SAPOrderDTO sapOrderDTO = new SAPOrderDTO();

            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            for (int k = 0; k < 10; k++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + k);
                materialSkuDTO.setUnrestqty(5d);
                productDTO.getListOfSku().add(materialSkuDTO);
            }

            orderDetailDTO.setProductDTO(productDTO);
            orderDTO.getDetail().add(orderDetailDTO);

            HybridDTO hybridDTO = new HybridDTO();

            for (int k = 0; k < 5; k++) {
                MaterialDTO materialDTO = new MaterialDTO();
                materialDTO.setUnrestqty(BigDecimal.ZERO);
                materialDTO.setMaterial("material" + k);
                hybridDTO.getSkus().add(materialDTO);
            }

            sapOrderDTO.getHybrids().add(hybridDTO);
            mapWithDetailDif.put(orderDTO, sapOrderDTO);
        }
    }


    @Test
    public void emptyMapIsSendedToProcessSoAnythingHappens() {

        processOrderNotInSapService.processOrdersWithoutSapOrder(new HashMap<OrderDTO, SAPOrderDTO>(), new AgreementDTO());
    }


    @Test
    public void testAllOrdersHaveSapOrderAreSendSuccessfullyToIncreaseDecreaseAtPServiceThenAgreementStatusIsUpdated() {
        reset(agreementRepository);
        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());
        reset(regularAgrochemicalsService);

        processOrderNotInSapService.processOrdersWithoutSapOrder(mapWithDetail, new AgreementDTO());
    }

    @Test
    public void testAllSomeOrdersHaveSapOrderAreSendSuccessfullyToIncreaseDecreaseAtPServiceThenAgreementStatusIsUpdated() {
        reset(agreementRepository);
        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());
        reset(regularAgrochemicalsService);

        processOrderNotInSapService.processOrdersWithoutSapOrder(mapWithNulls, new AgreementDTO());
    }

    @Test
    public void testSomeOrdersFailsWhenAreSendingToIncreaseDecreaseService() throws Exception {
        reset(agreementRepository);
        when(agreementRepository.findOne(Matchers.<Long>any())).thenReturn(new AgreementVO());
        reset(regularAgrochemicalsService);
        Mockito.doThrow(new CustomerLinkBusinessException()).when(regularAgrochemicalsService).processAgrochemicalsOrder(Matchers.<OrderDTO>any(),anyBoolean());
        processOrderNotInSapService.processOrdersWithoutSapOrder(mapWithNulls, new AgreementDTO());
    }

    @Test
    public void changeAgreementStatusToPosted() throws Exception {
        AgreementDTO agreementDTO = new AgreementDTO();
        agreementDTO.setAgreementId(1L);
        AgreementVO agreementVO = new AgreementVO();
        when(agreementRepository.findOne(eq(1L))).thenReturn(agreementVO);
        processOrderNotInSapService.changeAgreementStatusToPosted(agreementDTO);
        verify(agreementRepository).save(agreementVO);
        assertTrue(agreementVO.getStatus() == StatusEnum.POSTED.getId());
    }
}