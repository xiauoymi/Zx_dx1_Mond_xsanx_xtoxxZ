package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.ProductService;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProductServiceImpl_UT {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private Mapper mapper;

    @InjectMocks
    private ProductService unit = new ProductServiceImpl();

    @Test
    public void retrieveProducts() throws Exception {
        List<ProductVO> listFromRepository = new ArrayList<ProductVO>();
        ProductVO productVO = new ProductVO();
        listFromRepository.add(productVO);

        when(productRepository.findAll(Matchers.<Sort>anyObject())).thenReturn(listFromRepository);

        List<ProductDTO> listMapped = new ArrayList<ProductDTO>();
        ProductDTO productDTO = new ProductDTO();
        listMapped.add(productDTO);

        when(mapper.mapList(ProductDTO.class, listFromRepository)).thenReturn(listMapped);

        final List<ProductDTO> products = unit.getProductsByParameters(null, null, null, null, Boolean.FALSE);
        assertThat(products, is(notNullValue()));
    }
}