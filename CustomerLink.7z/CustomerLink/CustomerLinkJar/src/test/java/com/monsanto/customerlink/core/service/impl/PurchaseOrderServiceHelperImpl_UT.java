package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.persistence.entities.DistributorProfileVO;
import com.monsanto.customerlink.persistence.entities.PurchaseOrderVO;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.PurchaseOrderRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import com.monsanto.customerlink.core.service.PurchaseOrderServiceHelper;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PurchaseOrderServiceHelperImpl_UT {

    @Mock
    private PurchaseOrderRepository purcharseOrderRepository;
    @Mock
    private PurchaseOrderServiceHelper unit;

    @Before
    public void before() {
        reset(purcharseOrderRepository);
        unit = new PurchaseOrderServiceHelperImpl(purcharseOrderRepository);
    }

    @Test
    public void obtainPurchaseOrderByParameters_WhenRepresentativeIsNotAvailable() throws Exception {
        SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonId(1L);
        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorProfileId(1L);
        PurchaseOrderVO purchaseOrderVO = new PurchaseOrderVO();
        RepresentativeDTO representativeDTO = null;

        List<PurchaseOrderVO> pos = new ArrayList<PurchaseOrderVO>();
        pos.add(purchaseOrderVO);
        when(purcharseOrderRepository.findByDistributorProfileAndSeason(Matchers.any(Long.class), Matchers.any(Long.class))).thenReturn(pos);
        assertThat(purchaseOrderVO, is(unit.obtainPurchaseOrderByParameters(seasonVO, distributorProfileVO, representativeDTO).iterator().next()));
        verify(purcharseOrderRepository).findByDistributorProfileAndSeason(Matchers.any(Long.class),Matchers.any(Long.class));
    }

    @Test
    public void obtainPurchaseOrderByParameters_WhenRepresentativeIsAvailable() throws Exception {
        SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonId(1L);
        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorProfileId(1L);
        PurchaseOrderVO purchaseOrderVO = new PurchaseOrderVO();
        RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("USER_SAP_ID");

        List<PurchaseOrderVO> pos = new ArrayList<PurchaseOrderVO>();
        pos.add(purchaseOrderVO);

        when(purcharseOrderRepository.findByDistributorProfileAndSeasonAndRCD(Matchers.any(Long.class), Matchers.any(Long.class), Matchers.any(String.class))).thenReturn(pos);
        assertThat(purchaseOrderVO, is(unit.obtainPurchaseOrderByParameters(seasonVO,distributorProfileVO,representativeDTO).iterator().next()));
        verify(purcharseOrderRepository).findByDistributorProfileAndSeasonAndRCD(Matchers.any(Long.class), Matchers.any(Long.class), Matchers.any(String.class));
    }

}
