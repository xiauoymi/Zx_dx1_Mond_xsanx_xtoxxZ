package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.PurchaseOrderService;
import com.monsanto.customerlink.core.service.exception.PurchaseOrderApprovedNotFoundException;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurcharseOrderDTO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderDetailDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class PurchaseOrderServiceImpl_ST {

    @Autowired
    private PurchaseOrderService purchaseOrderService;

    @Test
    @Ignore
    public void createPurchaseOrderWithGivenParameters() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1014256");

        final DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setDistChCode("3R");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setSubRegionCode("AMXSUR");

        final PurchaseOrderDetailDTO purchaseOrderDetailDTO = new PurchaseOrderDetailDTO();
        purchaseOrderDetailDTO.setCrop("Prueba 1");

        final List<PurchaseOrderDetailDTO> detail = new ArrayList<PurchaseOrderDetailDTO>();
        detail.add(purchaseOrderDetailDTO);

        final PurcharseOrderDTO purcharseOrderDTO = new PurcharseOrderDTO();
        purcharseOrderDTO.setPurchaseOrderDetailsByPurchaseOrderId(detail);

        purchaseOrderService.createPurchaseOrder(purcharseOrderDTO, distributorConfigDTO);
    }

    @Test
    @Ignore
    public void retrievePurchaseOrders() throws Exception {
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("3101380");
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setDistributor(distributorDTO);
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setDistChCode("80");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setSubRegionCode("AMXSUR");
        PurcharseOrderDTO purcharseOrderDTO = new PurcharseOrderDTO();
        purcharseOrderDTO.setDistributor(distributorConfigDTO);
        final List<PurcharseOrderDTO> purchaseOrderDTOs = purchaseOrderService.retrievePurchaseOrder(purcharseOrderDTO);
        System.out.println(purchaseOrderDTOs.size());
    }

    @Test(expected = PurchaseOrderApprovedNotFoundException.class)
    @Ignore
    public void validateIfOrderExist() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1049450");

        final DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX20");
        distributorConfigDTO.setDistChCode("80");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setSubRegionCode("AMXPAC");
        distributorConfigDTO.setDistributor(distributorDTO);

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("1234567890");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);

        purchaseOrderService.validateExistPurchaseOrderApproved(orderDTO);
    }
}
