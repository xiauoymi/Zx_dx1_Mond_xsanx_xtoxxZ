package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.AgrochemicalCreateOrderErrorException;
import com.monsanto.customerlink.core.service.exception.AgrochemicalOrderInventoryNotFoundException;
import com.monsanto.customerlink.core.service.facade.dto.*;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RegularAgrochemicalInventoryHelperImpl_UT {

    @Mock
    private RegularAgrochemicalsHelper regularAgrochemicalsHelper;

    @Mock
    private RegularAgrochemicalInventoryHelper unit;

    @Mock
    private Mapper mapper;

    @Mock
    private SAPOrderService sapOrderService;

    @Mock
    private InventoryHelper inventoryHelper;

    @Before
    public void before() {
        reset(regularAgrochemicalsHelper, mapper, sapOrderService,inventoryHelper);
        unit = new RegularAgrochemicalInventoryHelperImpl(regularAgrochemicalsHelper, mapper, sapOrderService,inventoryHelper);
    }

    private List<PlantVO> getConfiguredPlants() {

        PlantVO p1 = new PlantVO();
        p1.setPlantCode("PLANT_1");
        p1.setPriority(3L);

        PlantVO p2 = new PlantVO();
        p2.setPlantCode("PLANT_2");
        p2.setPriority(1L);

        PlantVO p3 = new PlantVO();
        p3.setPlantCode("PLANT_3");
        p3.setPriority(2L);

        PlantVO p4 = new PlantVO();
        p4.setPlantCode("PLANT_4");
        p4.setPriority(4L);

        PlantVO p5 = new PlantVO();
        p5.setPlantCode("PLANT_5");
        p5.setPriority(5L);

        List<PlantVO> configuredPlants = new ArrayList<PlantVO>();
        configuredPlants.add(p1);
        configuredPlants.add(p2);
        configuredPlants.add(p3);
        configuredPlants.add(p4);

        return configuredPlants;
    }

    private OrderDTO getOrderForTest() {

        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("MXBAJ");
        distributorConfigDTO.setDistributor(new DistributorDTO());
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        ProductDTO productDTO = new ProductDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        List<OrderDetailDTO> listOfDetails = new ArrayList<OrderDetailDTO>();
        listOfDetails.add(orderDetailDTO);

        orderDTO.setDetail(listOfDetails);

        return orderDTO;
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsInOnePlant_InFirstPlantInPriority() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(250));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(250));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(500));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(150));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(150));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(300));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setErrors(new ArrayList<SAPOrderErrorDTO>());
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsInOnePlant_InSecondPlantInPriority() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(250));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(250));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(500));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(40));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(40));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(80));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setErrors(new ArrayList<SAPOrderErrorDTO>());
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsVariousPlants() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(30));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(30));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(60));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(40));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(40));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(80));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setErrors(new ArrayList<SAPOrderErrorDTO>());
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsVariousPlantsOtherCase() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(25));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(30));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(55));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(15));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(35));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(50));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        ///////////////////////////////// PLANT 4

        AgrochemicalWareHouseDTO wh_31 = new AgrochemicalWareHouseDTO();
        wh_31.setPartialQty(BigDecimal.valueOf(5));
        wh_31.setStoragelocation("WH_31");

        AgrochemicalWareHouseDTO wh_32 = new AgrochemicalWareHouseDTO();
        wh_32.setPartialQty(BigDecimal.valueOf(5));
        wh_32.setStoragelocation("WH_32");

        Map<String, AgrochemicalWareHouseDTO> whouses_3 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_3.put("WH_21",wh_31);
        whouses_3.put("WH_22",wh_32);

        AgrochemicalPlantDTO ap3 = new AgrochemicalPlantDTO();
        ap3.setTotalQty(BigDecimal.valueOf(10));
        ap3.setPlant("PLANT_4");
        ap3.setWarehouses(whouses_3);

        ////////////////// list of plants

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);
        listOfPlants.add(ap3);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setErrors(new ArrayList<SAPOrderErrorDTO>());
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test(expected = AgrochemicalCreateOrderErrorException.class)
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsVariousPlantsOtherCase_AndOccursErrorsInPostOrder() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(25));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(30));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(55));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(15));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(35));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(50));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        ///////////////////////////////// PLANT 4

        AgrochemicalWareHouseDTO wh_31 = new AgrochemicalWareHouseDTO();
        wh_31.setPartialQty(BigDecimal.valueOf(5));
        wh_31.setStoragelocation("WH_31");

        AgrochemicalWareHouseDTO wh_32 = new AgrochemicalWareHouseDTO();
        wh_32.setPartialQty(BigDecimal.valueOf(5));
        wh_32.setStoragelocation("WH_32");

        Map<String, AgrochemicalWareHouseDTO> whouses_3 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_3.put("WH_21",wh_31);
        whouses_3.put("WH_22",wh_32);

        AgrochemicalPlantDTO ap3 = new AgrochemicalPlantDTO();
        ap3.setTotalQty(BigDecimal.valueOf(10));
        ap3.setPlant("PLANT_4");
        ap3.setWarehouses(whouses_3);

        ////////////////// list of plants

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);
        listOfPlants.add(ap3);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        List<SAPOrderErrorDTO> errors = new ArrayList<SAPOrderErrorDTO>();
        errors.add(new SAPOrderErrorDTO());
        sapOrder.setErrors(errors);
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test(expected = AgrochemicalOrderInventoryNotFoundException.class)
    public void assignInventoryAgrochemicalOrder_WhenWasNotPossiblePerformAssignment() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(20));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(20));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(40));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(15));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(15));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(30));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test(expected = AgrochemicalOrderInventoryNotFoundException.class)
    public void assignInventoryAgrochemicalOrder_WhenInventoryNotContainsMaterial() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_2");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(20));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(20));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(40));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(15));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(15));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(30));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        unit.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

    @Test
    public void assignInventoryAgrochemicalOrder_WhenTheAssignIsInOnePlant_InFirstPlantInPriority_And_MapperReturnList() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        when(regularAgrochemicalsHelper.obtainRegularAgrochemicalPlants(Matchers.any(OrderDTO.class))).thenReturn(this.getConfiguredPlants());

        ////////////////////////////////////// inventory recovery from SAP /////////////////////////////////////////////
        //////////////////////////////////////////// MATERIAL 1 ///////////////////////////////////////////////////

        ///////////////////////////////// PLANT 1

        AgrochemicalWareHouseDTO wh_11 = new AgrochemicalWareHouseDTO();
        wh_11.setPartialQty(BigDecimal.valueOf(250));
        wh_11.setStoragelocation("WH_11");

        AgrochemicalWareHouseDTO wh_12 = new AgrochemicalWareHouseDTO();
        wh_12.setPartialQty(BigDecimal.valueOf(250));
        wh_12.setStoragelocation("WH_12");

        Map<String, AgrochemicalWareHouseDTO> whouses_1 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_1.put("WH_11",wh_11);
        whouses_1.put("WH_12",wh_12);

        AgrochemicalPlantDTO ap1 = new AgrochemicalPlantDTO();
        ap1.setTotalQty(BigDecimal.valueOf(500));
        ap1.setPlant("PLANT_1");
        ap1.setWarehouses(whouses_1);

        ///////////////////////////////// PLANT 2

        AgrochemicalWareHouseDTO wh_21 = new AgrochemicalWareHouseDTO();
        wh_21.setPartialQty(BigDecimal.valueOf(150));
        wh_21.setStoragelocation("WH_21");

        AgrochemicalWareHouseDTO wh_22 = new AgrochemicalWareHouseDTO();
        wh_22.setPartialQty(BigDecimal.valueOf(150));
        wh_22.setStoragelocation("WH_22");

        Map<String, AgrochemicalWareHouseDTO> whouses_2 = new HashMap<String, AgrochemicalWareHouseDTO>();

        whouses_2.put("WH_21",wh_21);
        whouses_2.put("WH_22",wh_22);

        AgrochemicalPlantDTO ap2 = new AgrochemicalPlantDTO();
        ap2.setTotalQty(BigDecimal.valueOf(300));
        ap2.setPlant("PLANT_2");
        ap2.setWarehouses(whouses_2);

        List<AgrochemicalPlantDTO> listOfPlants = new ArrayList<AgrochemicalPlantDTO>();
        listOfPlants.add(ap1);
        listOfPlants.add(ap2);

        AgrochemicalMaterialDTO am1 = new AgrochemicalMaterialDTO();
        am1.setMaterial("MATERIAL_1");
        am1.setListOfPlants(listOfPlants);

        List<AgrochemicalMaterialDTO> inventory = new ArrayList<AgrochemicalMaterialDTO>();
        inventory.add(am1);

        SAPOrderDTO sapOrder = new SAPOrderDTO();
        sapOrder.setErrors(new ArrayList<SAPOrderErrorDTO>());
        when(sapOrderService.postOrderWithoutAlgorithm(any(OrderDTO.class))).thenReturn(sapOrder);


        RegularAgrochemicalInventoryHelperImpl aSpy = (RegularAgrochemicalInventoryHelperImpl) Mockito.spy(unit);

        List<MaterialSkuDTO> materialsList = new ArrayList<MaterialSkuDTO>();

        for(int i = 0 ; i< 5; i++) {
            MaterialSkuDTO m = new MaterialSkuDTO();
            m.setMaterial("MATERIAL_"+i);
            m.setPlant("PLANT_"+i);
            m.setStoragelocation("STORAGE_LOCATION_"+i);
            m.setBatch("BATCH_"+i);
            m.setUnrestqty(i);
            materialsList.add(m);
        }

        List<MaterialDTO> materialsToAllocate = new ArrayList<MaterialDTO>();
        materialsToAllocate.add(new MaterialDTO());

        Mockito.doReturn(materialsToAllocate).when(aSpy).allocateInventoryByMaterial(any(OrderDTO.class), any(MaterialSkuDTO.class), anyList(), anyList(), anyList());
        when(mapper.mapList(eq(MaterialSkuDTO.class),eq(materialsToAllocate))).thenReturn(materialsList);

        aSpy.assignInventoryAgrochemicalOrder(orderDTO,inventory,null);
    }

}