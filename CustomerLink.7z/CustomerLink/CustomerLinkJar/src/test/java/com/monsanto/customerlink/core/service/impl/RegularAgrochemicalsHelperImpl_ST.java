package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@ContextConfiguration(locations = {"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class RegularAgrochemicalsHelperImpl_ST {

    @Autowired
    private RegularAgrochemicalsHelper regularAgrochemicalsHelper;

    private OrderDTO getOrderForTest() {

        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("AMXSON");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setDistChCode("80");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1001485");
        distributorConfigDTO.setDistributor(distributorDTO);
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        ProductDTO productDTO = new ProductDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        List<OrderDetailDTO> listOfDetails = new ArrayList<OrderDetailDTO>();
        listOfDetails.add(orderDetailDTO);

        orderDTO.setDetail(listOfDetails);

        return orderDTO;
    }

    @Test
    @Ignore
    public void sendMessageMissingInventory() throws Exception {

        OrderDTO orderDTO = this.getOrderForTest();

        MaterialSkuDTO sku1 = new MaterialSkuDTO();
        sku1.setMaterial("MATERIAL_1");
        sku1.setUnrestqty(100);

        MaterialSkuDTO sku2 = new MaterialSkuDTO();
        sku2.setMaterial("MATERIAL_2");
        sku2.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku1);
        listOfSku.add(sku2);

        regularAgrochemicalsHelper.sendMessageMissingInventory(listOfSku,orderDTO.getDistributorConfigDTO(),new ArrayList<ErrorOrderDTO>());
    }

}