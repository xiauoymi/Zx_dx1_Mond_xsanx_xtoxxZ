package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.InventoryHelper;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.PlantService;
import com.monsanto.customerlink.core.service.RegularAgrochemicalsHelper;
import com.monsanto.customerlink.core.service.exception.*;
import com.monsanto.customerlink.core.service.facade.dto.MaterialDTO;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import com.monsanto.customerlink.web.services.autogen.distributor.*;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class RegularAgrochemicalsHelperImpl_UT {

    @Mock
    private PlantService plantService;

    @Mock
    private MailUtilService mailUtilService;

    @Mock
    private InventoryHelper inventoryHelper;

    @Mock
    private RegularAgrochemicalsHelper unit;

    @Before
    public void before() {
        reset(plantService, mailUtilService, inventoryHelper);
        unit = new RegularAgrochemicalsHelperImpl(inventoryHelper,mailUtilService,plantService);
    }

    private List<PlantVO> getConfiguredPlants() {

        WarehouseVO w1  = new WarehouseVO();
        w1.setWarehouseCode("WH1");

        WarehouseVO w2  = new WarehouseVO();
        w2.setWarehouseCode("WH2");

        List<WarehouseVO> whs = new ArrayList<WarehouseVO>();
        whs.add(w1);
        whs.add(w2);

        PlantVO p1 = new PlantVO();
        p1.setPlantCode("PLANT_1");
        p1.setPriority(1L);
        p1.setWarehousesByPlantId(whs);

        WarehouseVO w3  = new WarehouseVO();
        w3.setWarehouseCode("WH3");

        WarehouseVO w4  = new WarehouseVO();
        w4.setWarehouseCode("WH4");

        List<WarehouseVO> whs1 = new ArrayList<WarehouseVO>();
        whs1.add(w3);
        whs1.add(w4);

        PlantVO p2 = new PlantVO();
        p2.setPlantCode("PLANT_2");
        p2.setPriority(2L);
        p2.setWarehousesByPlantId(whs1);

        PlantVO p3 = new PlantVO();
        p3.setPlantCode("PLANT_3");
        p3.setPriority(3L);
        p3.setWarehousesByPlantId(new ArrayList<WarehouseVO>());

        List<PlantVO> configuredPlants = new ArrayList<PlantVO>();
        configuredPlants.add(p1);
        configuredPlants.add(p2);
        configuredPlants.add(p3);


        return configuredPlants;
    }

    private OrderDTO getOrderForTest() {

        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("MXBAJ");
        distributorConfigDTO.setDistributor(new com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO());
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        ProductDTO productDTO = new ProductDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        List<OrderDetailDTO> listOfDetails = new ArrayList<OrderDetailDTO>();
        listOfDetails.add(orderDetailDTO);

        orderDTO.setDetail(listOfDetails);

        return orderDTO;
    }

    @Test
    public void createRequestInventory() throws Exception{

        /////////// materials for allocate
        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        OrderDTO orderDTO = this.getOrderForTest();
        // assign list of sku for allocate
        orderDTO.getDetail().get(0).getProductDTO().setListOfSku(listOfSku);

        RegularAgrochemicalsHelper aSpy = Mockito.spy(unit);

        Mockito.doReturn( this.getConfiguredPlants() ).when(aSpy).obtainRegularAgrochemicalPlants(any(OrderDTO.class));


        List<MaterialDTO> materials = aSpy.createRequestInventory(orderDTO);

        assertTrue(!materials.isEmpty());
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void exception_validateInputParametersForAgrochemicals_WhenOrderIsNull() throws Exception{
        unit.validateInputParametersForAgrochemicals(null);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void exception_validateInputParametersForAgrochemicals_WhenDetailIsEmpty() throws Exception{
        unit.validateInputParametersForAgrochemicals(new OrderDTO());
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void exception_validateInputParametersForAgrochemicals_WhenDistributorConfigIsNull() throws Exception{
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();
        details.add(orderDetailDTO);
        orderDTO.setDetail(details);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void exception_validateInputParametersForAgrochemicals_WhenProductIsNull() throws Exception{
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();
        details.add(orderDetailDTO);
        orderDTO.setDetail(details);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test(expected = AgrochemicalOrderMissingArgumentsException.class)
    public void exception_validateInputParametersForAgrochemicals_WhenSkuListIsEmpty() throws Exception{
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(new ProductDTO());
        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();
        details.add(orderDetailDTO);
        orderDTO.setDetail(details);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test
    public void exception_validateInputParametersForAgrochemicals() throws Exception{
        OrderDTO orderDTO = new OrderDTO();
        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();

        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setListOfSku(listOfSku);
        orderDetailDTO.setProductDTO(productDTO);

        orderDetailDTO.setProductDTO(productDTO);
        List<OrderDetailDTO> details = new ArrayList<OrderDetailDTO>();
        details.add(orderDetailDTO);
        orderDTO.setDetail(details);
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);
        unit.validateInputParametersForAgrochemicals(orderDTO);
    }

    @Test
    public void obtainRegularAgrochemicalPlants_WhenListOfPlantsIsNotEmpty() throws Exception{

        OrderDTO orderDTO = getOrderForTest();

        CropVO agrochemical = new CropVO();
        agrochemical.setCropCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());
        agrochemical.setCropId(5L);
        agrochemical.setSpecieCode("");
        agrochemical.setSpecieClass(null);
        agrochemical.setSpecieType(null);
        agrochemical.setSpecieAlg(false);

        when(plantService.obtainPlantsAccordingToCrop(eq("AR010"),any(DistributorConfigDTO.class))).thenReturn(this.getConfiguredPlants());

        List<PlantVO> plants = unit.obtainRegularAgrochemicalPlants(orderDTO);
        assertTrue(!plants.isEmpty());
    }

    @Test(expected = AgrochemicalOrderPlantsNotFoundException.class)
    public void obtainRegularAgrochemicalPlants_WhenListOfPlantsIsEmpty() throws Exception{

        OrderDTO orderDTO = getOrderForTest();

        CropVO agrochemical = new CropVO();
        agrochemical.setCropCode(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());
        agrochemical.setCropId(5L);
        agrochemical.setSpecieCode("");
        agrochemical.setSpecieClass(null);
        agrochemical.setSpecieType(null);
        agrochemical.setSpecieAlg(false);

        when(plantService.obtainPlantsAccordingToCrop(eq("AR010"),any(DistributorConfigDTO.class))).thenReturn(new ArrayList<PlantVO>());

        List<PlantVO> plants = unit.obtainRegularAgrochemicalPlants(orderDTO);
        assertTrue(!plants.isEmpty());
    }

    @Test
    public void sendMessageMissingInventory() throws Exception {

        OrderDTO orderDTO = this.getOrderForTest();

        when(mailUtilService.buildDistributorMessageNotification(any(DistributorConfigDTO.class),anyList())).thenReturn(new HashMap<String, Object>());

        MaterialSkuDTO sku1 = new MaterialSkuDTO();
        sku1.setMaterial("MATERIAL_1");
        sku1.setUnrestqty(100);

        MaterialSkuDTO sku2 = new MaterialSkuDTO();
        sku2.setMaterial("MATERIAL_2");
        sku2.setUnrestqty(100);

        List<MaterialSkuDTO> listOfSku = new ArrayList<MaterialSkuDTO>();
        listOfSku.add(sku1);
        listOfSku.add(sku2);
        unit.sendMessageMissingInventory(listOfSku,orderDTO.getDistributorConfigDTO(),new ArrayList<ErrorOrderDTO>());
    }

}