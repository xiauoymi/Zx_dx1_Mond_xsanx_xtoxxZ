package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.InventoryRegularAgrochemicalsFacade;
import com.monsanto.customerlink.core.service.facade.dto.AgrochemicalMaterialDTO;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class RegularAgrochemicalsServiceImpl_UT {

    @Mock
    private RegularAgrochemicalsHelper regularAgrochemicalsHelper;

    @Mock
    private InventoryRegularAgrochemicalsFacade inventoryRegularAgrochemicalsFacade;

    @Mock
    private RegularAgrochemicalInventoryHelper regularAgrochemicalInventoryHelper;

    @Mock
    private RegularAgrochemicalsService unit;

    @Before
    public void before() {
        reset(regularAgrochemicalsHelper, inventoryRegularAgrochemicalsFacade, regularAgrochemicalInventoryHelper);
        unit = new RegularAgrochemicalsServiceImpl(regularAgrochemicalsHelper, inventoryRegularAgrochemicalsFacade, regularAgrochemicalInventoryHelper);
    }

    private OrderDTO getOrderForTest() {

        OrderDTO orderDTO = new OrderDTO();
        DistributorConfigDTO distributorConfigDTO = new DistributorConfigDTO();
        distributorConfigDTO.setSalesOrgCode("MX01");
        distributorConfigDTO.setSubRegionCode("AMXSON");
        distributorConfigDTO.setSalesDivCode("17");
        distributorConfigDTO.setDistChCode("80");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1001485");
        distributorConfigDTO.setDistributor(distributorDTO);
        orderDTO.setDistributorConfigDTO(distributorConfigDTO);

        MaterialSkuDTO sku = new MaterialSkuDTO();
        sku.setMaterial("MATERIAL_1");
        sku.setUnrestqty(100);

        ProductDTO productDTO = new ProductDTO();

        OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        List<OrderDetailDTO> listOfDetails = new ArrayList<OrderDetailDTO>();
        listOfDetails.add(orderDetailDTO);

        orderDTO.setDetail(listOfDetails);

        return orderDTO;
    }

    @Test
    public void createRequestInventory_noInventoryAvailable() throws Exception{

        OrderDTO orderDTO = this.getOrderForTest();
        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.HYBRIDS_WITH_ERROR,new ArrayList<Object>());
        when(inventoryRegularAgrochemicalsFacade.getInventory(anyList())).thenReturn(inventoryListOutPut);
        unit.processAgrochemicalsOrder(orderDTO,false);
    }

    @Test
    public void createRequestInventory_InventoryEmpty() throws Exception{

        OrderDTO orderDTO = this.getOrderForTest();
        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        List<AgrochemicalMaterialDTO> inventoryWithOutAlgorithm = new ArrayList<AgrochemicalMaterialDTO>();
        inventoryListOutPut.put(CustomerLinkCoreConstants.AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM,inventoryWithOutAlgorithm);
        when(inventoryRegularAgrochemicalsFacade.getInventory(anyList())).thenReturn(inventoryListOutPut);
        unit.processAgrochemicalsOrder(orderDTO,false);

    }

    @Test
    public void createRequestInventory_InventoryIsNotEmpty() throws Exception{
        OrderDTO orderDTO = this.getOrderForTest();
        Map<String, List<?>> inventoryListOutPut = new HashMap<String, List<?>>();
        List<AgrochemicalMaterialDTO> inventoryWithOutAlgorithm = new ArrayList<AgrochemicalMaterialDTO>();
        inventoryWithOutAlgorithm.add(new AgrochemicalMaterialDTO());
        inventoryListOutPut.put(CustomerLinkCoreConstants.AGROCHEMICAL_MATERIALS_WITHOUT_ALGORITHM,inventoryWithOutAlgorithm);
        when(inventoryRegularAgrochemicalsFacade.getInventory(anyList())).thenReturn(inventoryListOutPut);
        unit.processAgrochemicalsOrder(orderDTO,false);
    }

    @Test
    public void preProcessOrder_NotUpdate() throws Exception{
        OrderDTO orderDTO = this.getOrderForTest();
        orderDTO.setOrderIdSAP("SAP_ORDER_ID");
        RegularAgrochemicalsServiceImpl otherUnit = (RegularAgrochemicalsServiceImpl)Mockito.spy(unit);
        otherUnit.preProcessOrder(orderDTO,false);
        assertTrue(null == orderDTO.getOrderIdSAP());
    }

    @Test(expected = CustomerLinkBusinessException.class)
    public void preProcessOrder_IsUpdate_WhenSapIdIsNull() throws Exception{
        OrderDTO orderDTO = this.getOrderForTest();
        orderDTO.setOrderIdSAP(null);
        RegularAgrochemicalsServiceImpl otherUnit = (RegularAgrochemicalsServiceImpl)Mockito.spy(unit);
        otherUnit.preProcessOrder(orderDTO,true);
    }

    @Test
    public void preProcessOrder_IsUpdate_WhenSapIdIsNotNull() throws Exception{
        OrderDTO orderDTO = this.getOrderForTest();
        orderDTO.setOrderIdSAP("ORDER_ID_SAP");
        RegularAgrochemicalsServiceImpl otherUnit = (RegularAgrochemicalsServiceImpl)Mockito.spy(unit);
        otherUnit.preProcessOrder(orderDTO,true);
    }
}