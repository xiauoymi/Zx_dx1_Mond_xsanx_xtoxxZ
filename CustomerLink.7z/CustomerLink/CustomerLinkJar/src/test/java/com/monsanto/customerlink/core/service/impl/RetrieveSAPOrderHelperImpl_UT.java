package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.OrderReasonTypeService;
import com.monsanto.customerlink.core.service.RetrieveSAPOrderHelper;
import com.monsanto.customerlink.core.service.exception.FoundMoreThanASAPOrderException;
import com.monsanto.customerlink.core.service.facade.SAPOrderFacade;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.service.util.SeedsSalesOrganizationEnum;
import com.monsanto.customerlink.core.service.util.StatusSAPOrderEnum;
import com.monsanto.customerlink.persistence.entities.OrderReasonTypeVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@ContextConfiguration(locations = {"classpath:RetrieveSAPOrderHelperImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class RetrieveSAPOrderHelperImpl_UT {

    @Autowired
    private SAPOrderFacade sapOrderFacade;

    @Autowired
    private OrderReasonTypeService orderReasonTypeBusiness;

    @Autowired
    private RetrieveSAPOrderHelper retrieveSAPOrderHelper;

    @Before
    public void before() {
        reset(sapOrderFacade, orderReasonTypeBusiness);
    }

    @Test
    public void retrieveSeedSAPOrderWhenIsNormalSeasonOrder() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setPriceGrp("MC");
        sapOrderDTO1.setStatus(StatusSAPOrderEnum.OPEN.code());

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setPriceGrp("MB");
        sapOrderDTO2.setStatus(StatusSAPOrderEnum.PARTIAL.code());

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setPriceGrp("MB");
        sapOrderDTO3.setStatus(StatusSAPOrderEnum.COMPLETE.code());

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setPriceGrp("MC");
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("GC010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MC");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setDetail(orderDetailDTOList);

        final SAPOrderDTO sapOrderDTO = retrieveSAPOrderHelper.retrieveSeedSAPOrder(orderDTO);
        assertThat(orderDTO.getClOrderTypeCode(), is(CLOrderTypeEnum.WITH_ALGORITHM.code()));
        assertThat(sapOrderDTO, is(notNullValue()));
        assertThat(sapOrderDTO, is(sameInstance(sapOrderDTO1)));
        assertThat(sapOrderDTO.getWithoutSoakTestOrder(), is(sameInstance(sapOrderDTO1)));
    }

    @Test(expected = FoundMoreThanASAPOrderException.class)
    public void throwsFoundMoreThanASAPOrderExceptionWhenExistMoreThanAOpenSeedSAPOrder() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setPriceGrp("MB");
        sapOrderDTO1.setStatus(StatusSAPOrderEnum.OPEN.code());

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setPriceGrp("MC");
        sapOrderDTO2.setStatus(StatusSAPOrderEnum.PARTIAL.code());

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setPriceGrp("MC");
        sapOrderDTO3.setStatus(StatusSAPOrderEnum.COMPLETE.code());

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setPriceGrp("MC");
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("GC010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MC");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setDetail(orderDetailDTOList);

        retrieveSAPOrderHelper.retrieveSeedSAPOrder(orderDTO);
    }

    @Test
    public void retrieveSeedSAPOrderNullNotExistOpenNormalSeasonOrder() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setPriceGrp("MB");
        sapOrderDTO1.setStatus(StatusSAPOrderEnum.OPEN.code());

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setPriceGrp("MB");
        sapOrderDTO2.setStatus(StatusSAPOrderEnum.PARTIAL.code());

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setPriceGrp("MB");
        sapOrderDTO3.setStatus(StatusSAPOrderEnum.COMPLETE.code());

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setPriceGrp("MC");
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("GC010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MC");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setDetail(orderDetailDTOList);

        final SAPOrderDTO sapOrderDTO = retrieveSAPOrderHelper.retrieveSeedSAPOrder(orderDTO);
        assertThat(orderDTO.getClOrderTypeCode(), is(CLOrderTypeEnum.WITH_ALGORITHM.code()));
        assertThat(sapOrderDTO, is(nullValue()));
    }

    @Test
    public void retrieveAgrochemicalSAPOrder() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setStatus(StatusSAPOrderEnum.OPEN.code());

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setStatus("OTRO ESTADO");

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setStatus("OTRO ESTADO");

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("AG010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode("AG010");
        orderDTO.setDetail(orderDetailDTOList);

        final SAPOrderDTO sapOrderDTO = retrieveSAPOrderHelper.retrieveAgrochemicalSAPOrder(orderDTO);
        assertThat(orderDTO.getClOrderTypeCode(), is(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code()));
        assertThat(sapOrderDTO, is(notNullValue()));
        assertThat(sapOrderDTO, is(sameInstance(sapOrderDTO1)));
        assertThat(sapOrderDTO.getWithoutSoakTestOrder(), is(nullValue()));
    }

    @Test(expected = FoundMoreThanASAPOrderException.class)
    public void throwsFoundMoreThanASAPOrderExceptionWhenExistMoreThanAOpenAgrochemicalSAPOrder() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setStatus(StatusSAPOrderEnum.OPEN.code());

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setStatus(StatusSAPOrderEnum.PARTIAL.code());

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setStatus(StatusSAPOrderEnum.COMPLETE.code());

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("AG010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode("AG010");
        orderDTO.setDetail(orderDetailDTOList);

        retrieveSAPOrderHelper.retrieveAgrochemicalSAPOrder(orderDTO);
    }

    @Test
    public void retrieveAgrochemicalSAPOrderNull() throws Exception {
        final SAPOrderDTO sapOrderDTO1 = new SAPOrderDTO();
        sapOrderDTO1.setStatus("OTRO ESTADO");

        final SAPOrderDTO sapOrderDTO2 = new SAPOrderDTO();
        sapOrderDTO2.setStatus("OTRO ESTADO");

        final SAPOrderDTO sapOrderDTO3 = new SAPOrderDTO();
        sapOrderDTO3.setStatus("OTRO ESTADO");

        final SAPOrderDTO sapOrderDTO4 = new SAPOrderDTO();
        sapOrderDTO4.setStatus("OTRO ESTADO");

        final List<SAPOrderDTO> sapOrderDTOList = new ArrayList<SAPOrderDTO>();
        sapOrderDTOList.add(sapOrderDTO1);
        sapOrderDTOList.add(sapOrderDTO2);
        sapOrderDTOList.add(sapOrderDTO3);
        sapOrderDTOList.add(sapOrderDTO4);

        when(sapOrderFacade.retrieveOrders(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTOList);

        when(orderReasonTypeBusiness.retrieveOrderReasonType(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderReasonTypeVO());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setCropCode("AG010");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();
        orderDetailDTOList.add(orderDetailDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode("AG010");
        orderDTO.setDetail(orderDetailDTOList);

        final SAPOrderDTO sapOrderDTO = retrieveSAPOrderHelper.retrieveAgrochemicalSAPOrder(orderDTO);
        assertThat(orderDTO.getClOrderTypeCode(), is(CLOrderTypeEnum.PRIVATE_AGROCHEMICAL.code()));
        assertThat(sapOrderDTO, is(nullValue()));
    }
}
