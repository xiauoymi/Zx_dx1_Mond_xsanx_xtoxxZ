package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.*;
import com.monsanto.customerlink.core.service.facade.SAPOrderFacade;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.service.facade.dto.SAPOrderErrorDTO;
import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.persistence.entities.OrderTypeVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SAPOrderServiceImpl_UT {

    @Mock
    private OrderComplementService orderComplementBusiness;

    @Mock
    private OrderErrorService orderErrorService;

    @Mock
    private RetrieveSAPOrderHelper retrieveSAPOrderHelper;

    @Mock
    private SAPOrderTypeService sapOrderTypeBusiness;

    @Mock
    private SAPOrderFacade sapOrderFacade;

    @Mock
    private Mapper mapper;

    @InjectMocks
    private SAPOrderService unit = new SAPOrderServiceImpl();

    @Test
    public void throwIllegalArgumentExceptionWhenHybridListIsEmptyAndOrderIdSAPIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The hybrid list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenSKUListIsEmptyAndOrderIdSAPIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The SKU list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNullAndItemNumberIsZero() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The item number can't be zero"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNullAndItemNumberIsNotMultiploOfTen() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());
        materialSkuDTO.setItemNumber(55);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The item number not is multiplo of ten"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNullAndItemTransactionTypeIsNotI() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The transaction type of the SKU not is the required for create a SAP order"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenHybridListIsEmptyAndOrderIdSAPIsNotNull() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.setOrderIdSAP("12345678");

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The hybrid list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenSKUListIsEmptyAndOrderIdSAPIsNotNull() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The SKU list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNotNullAndItemNumberIsZero() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setTransactionType("E");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The item number can't be zero"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNotNullAndItemNumberIsNotMultiploOfTen() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setTransactionType("E");
        materialSkuDTO.setItemNumber(55);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The item number not is multiplo of ten"));
        }
    }

    @Test
    public void throwIllegalArgumentExceptionWhenOrderIdSAPIsNotNullAndItemTransactionTypeIsNotIOrUOrD() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType("E");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        try {
            unit.postOrderWithoutAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The transaction type of the SKU not is the required for update a SAP order"));
        }
    }

    /*@Test(expected = CreateSAPOrderException.class)
    public void throwsCreateSAPOrderExceptionWhenOrderIdSAPIsNullAndSAPOrderErrorsIsNotEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setNumber("12345");
        sapOrderErrorDTO.setType("SKU");
        sapOrderErrorDTO.setMessage("Error de SKU");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
        when(sapOrderFacade.createSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO1, is(notNullValue()));
    }

    @Test(expected = UpdateSAPOrderException.class)
    public void throwsUpdateSAPOrderExceptionWhenOrderIdSAPIsNotNullAndSAPOrderErrorsIsNotEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setNumber("12345");
        sapOrderErrorDTO.setType("SKU");
        sapOrderErrorDTO.setMessage("Error de SKU");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
        when(sapOrderFacade.updateSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);


        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final MaterialSkuDTO materialSkuDTOI = new MaterialSkuDTO();
        materialSkuDTOI.setItemNumber(30);
        materialSkuDTOI.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTOI.setMaterial("COTTON 1");
        materialSkuDTOI.setPlant("5528");
        materialSkuDTOI.setStoragelocation("CWM1");
        materialSkuDTOI.setBatch("45");
        materialSkuDTOI.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOU = new MaterialSkuDTO();
        materialSkuDTOU.setItemNumber(10);
        materialSkuDTOU.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());
        materialSkuDTOU.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOD = new MaterialSkuDTO();
        materialSkuDTOD.setItemNumber(20);
        materialSkuDTOD.setTransactionType(TransactionTypeMaterial.DELETE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTOI);
        productDTO.getListOfSku().add(materialSkuDTOU);
        productDTO.getListOfSku().add(materialSkuDTOD);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO1, is(notNullValue()));
    }*/

    @Test
    public void retrievesSAPOrderDTOAfterCreateSAPOrderWhenOrderIdSAPIsNotNull() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        when(sapOrderFacade.updateSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final MaterialSkuDTO materialSkuDTOI = new MaterialSkuDTO();
        materialSkuDTOI.setItemNumber(30);
        materialSkuDTOI.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTOI.setMaterial("COTTON 1");
        materialSkuDTOI.setPlant("5528");
        materialSkuDTOI.setStoragelocation("CWM1");
        materialSkuDTOI.setBatch("45");
        materialSkuDTOI.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOU = new MaterialSkuDTO();
        materialSkuDTOU.setItemNumber(10);
        materialSkuDTOU.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());
        materialSkuDTOU.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOD = new MaterialSkuDTO();
        materialSkuDTOD.setItemNumber(20);
        materialSkuDTOD.setTransactionType(TransactionTypeMaterial.DELETE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTOI);
        productDTO.getListOfSku().add(materialSkuDTOU);
        productDTO.getListOfSku().add(materialSkuDTOD);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        final SAPOrderDTO sapOrderDTO = unit.postOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO, is(notNullValue()));
    }

    @Test
    public void retrievesSAPOrderDTOAfterCreateSAPOrderWhenOrderIdSAPIsNull() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        when(sapOrderFacade.createSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(new SAPOrderDTO());

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO = unit.postOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO, is(notNullValue()));
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenPlantListIsEmptyAndOrderIdSAPIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP(null); // OrderIdSAPIsNull
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The Plant list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenPlantListIsEmptyAndOrderIdSAPIsNotNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789"); // OrderIdSAPIsNotNull
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The Plant list is empty"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNullAndItemTransactionTypeIsNotI() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The transaction type of plant does not match to create an order in SAP"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNotNullAndPlantTransactionTypeIsNot_I_OR_U_OR_D() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType("OTHER_TRANSACTION_TYPE");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789");
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The transaction type of plant does not match to update an order in SAP"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNullAndPlantCodeIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant(null); // is null

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP(null);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The plant code can't null or blank"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNullAndPlantCodeIsBlank() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant(""); // is blank

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP(null);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The plant code can't null or blank"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNotNullAndPlantCodeIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant(null); // is null

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789");
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The plant code can't null or blank"));
        }
    }

    @Test
    public void throwIllegalArgumentException_WithAlgorithm_WhenOrderIdSAPIsNotNullAndPlantCodeIsBlank() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant(""); // is blank

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789");
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        try {
            unit.postOrderWithAlgorithm(orderDTO);
        } catch (final IllegalArgumentException e) {
            assertThat(e.getLocalizedMessage(), is("The plant code can't null or blank"));
        }
    }

    /*@Test(expected = CreateSAPOrderException.class)
    public void throwsCreateSAPOrderException_WithAlgorithm_WhenOrderIdSAPIsNull_AndSAPOrderErrorsIsNotEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setNumber("12345");
        sapOrderErrorDTO.setType("SKU");
        sapOrderErrorDTO.setMessage("Error de SKU");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
        when(sapOrderFacade.createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);


        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant("CODE_PANT");
        plantDTO.setUnrestqty(50);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithAlgorithm(orderDTO);
    }

    @Test(expected = UpdateSAPOrderException.class)
    public void throwsCreateSAPOrderException_WithAlgorithm_WhenOrderIdSAPIsNotNull_AndSAPOrderErrorsIsNotEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setNumber("12345");
        sapOrderErrorDTO.setType("SKU");
        sapOrderErrorDTO.setMessage("Error de SKU");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
        when(sapOrderFacade.updateSAPOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant("CODE_PANT");
        plantDTO.setUnrestqty(50);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789");
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithAlgorithm(orderDTO);
    }*/

    @Test
    public void createSAPOrderException_WithAlgorithm_WhenOrderIdSAPIsNull_AndSAPOrderErrorsIsNull() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        when(sapOrderFacade.createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);


        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant("CODE_PANT");
        plantDTO.setUnrestqty(50);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithAlgorithm(orderDTO);

        assertThat(sapOrderDTO1, is(notNullValue()));
        verify(sapOrderFacade).createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
        verify(sapOrderFacade).createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
    }

    @Test
    public void updateSAPOrderException_WithAlgorithm_WhenOrderIdSAPIsNotNull_AndSAPOrderErrorsIsEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        when(sapOrderFacade.updateSAPOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);


        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant("CODE_PANT");
        plantDTO.setUnrestqty(50);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderIdSAP("123456789");
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithAlgorithm(orderDTO);

        assertThat(sapOrderDTO1, is(notNullValue()));
        verify(sapOrderFacade).updateSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
        verify(sapOrderFacade).updateSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
    }

    @Test
    public void createSAPOrderException_WithAlgorithm_WhenOrderIdSAPIsNull_WithSoakTest_AndSAPOrderErrorsIsNull() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        when(sapOrderFacade.createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);


        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setPlant("CODE_PANT");
        plantDTO.setUnrestqty(50);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithAlgorithm(orderDTO);

        assertThat(sapOrderDTO1, is(notNullValue()));
        verify(sapOrderFacade).createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
        verify(sapOrderFacade).createSAPOrderWithAlgorithm(Matchers.<OrderDTO>any());
    }

    @Test
    public void retrieveSeedSAPOrders() throws Exception {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        when(retrieveSAPOrderHelper.retrieveSeedSAPOrder(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.CORN_OR_SORGHUM.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCurrency("MXN");

        final SAPOrderDTO sapOrderDTOReturn = unit.retrieveOrder(orderDTO);
        assertThat(sapOrderDTOReturn, is(notNullValue()));
        assertThat(sapOrderDTOReturn, is(sameInstance(sapOrderDTO)));
    }

    @Test
    public void retrieveAgrochemicalSAPOrders() throws Exception {
        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        when(retrieveSAPOrderHelper.retrieveAgrochemicalSAPOrder(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("15");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCurrency("MXN");

        final SAPOrderDTO sapOrderDTOReturn = unit.retrieveOrder(orderDTO);
        assertThat(sapOrderDTOReturn, is(notNullValue()));
        assertThat(sapOrderDTOReturn, is(sameInstance(sapOrderDTO)));
    }

    @Test
    public void saveSAPErrorsWhenOrderIdSAPIsNullAndSAPOrderErrorsIsNotEmpty() throws Exception {
        final OrderTypeVO orderTypeVO = new OrderTypeVO();
        orderTypeVO.setOrderTypeCode("ZPM2");

        final SAPOrderErrorDTO sapOrderErrorDTO = new SAPOrderErrorDTO();
        sapOrderErrorDTO.setNumber("12345");
        sapOrderErrorDTO.setType("SKU");
        sapOrderErrorDTO.setMessage("Error de SKU");

        final SAPOrderDTO sapOrderDTO = new SAPOrderDTO();
        sapOrderDTO.getErrors().add(sapOrderErrorDTO);
        when(sapOrderFacade.createSAPOrderWithoutAlgorithm(Matchers.<OrderDTO>any())).thenReturn(sapOrderDTO);

        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setClOrderTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);

        final SAPOrderDTO sapOrderDTO1 = unit.postOrderWithoutAlgorithm(orderDTO);
        assertThat(sapOrderDTO1, is(notNullValue()));
    }
}