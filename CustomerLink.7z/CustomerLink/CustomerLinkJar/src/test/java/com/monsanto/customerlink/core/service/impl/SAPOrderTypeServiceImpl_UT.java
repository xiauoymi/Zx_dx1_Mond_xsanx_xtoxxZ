package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SAPOrderTypeService;
import com.monsanto.customerlink.core.service.exception.OrderTypeNotFoundException;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.persistence.entities.OrderTypeVO;
import com.monsanto.customerlink.persistence.repositories.OrderTypeRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Locale;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SAPOrderTypeServiceImpl_UT {

    @Mock
    private OrderTypeRepository orderTypeRepository;

    @InjectMocks
    private SAPOrderTypeService unit = new SAPOrderTypeServiceImpl();

    @Before
    public void run() {
        Locale.setDefault(new Locale("es", "MX"));
    }

    @Test
    public void throwsOrderTypeNotFoundExceptionIfTheOrderTypeIsNotFoundInTheRepository() throws Exception {
        when(orderTypeRepository.findByDistributionChannelAndCrop(Matchers.<String>any(), Matchers.<String>any())).thenReturn(null);

        try {
            unit.retrieveSapOrderType("3R", SeedsCropCodeEnum.CORN.getCode());
        } catch (OrderTypeNotFoundException e) {
            assertThat(e.getMessage(), is("No se encontró el tipo de orden para el canal de distribución " + "3R" + " y el crop " + SeedsCropCodeEnum.CORN.getCode()));
        }

    }

    @Test
    public void retrievesTheOrderTypeFromTheRepositoryWhoseParametersMatches() throws Exception {
        when(orderTypeRepository.findByDistributionChannelAndCrop(Matchers.<String>any(), Matchers.<String>any())).thenReturn(new OrderTypeVO());

        final OrderTypeVO orderTypeVO = unit.retrieveSapOrderType("3R", SeedsCropCodeEnum.CORN.getCode());
        assertThat(orderTypeVO, is(notNullValue()));
    }

    @Test
    public void throwsOrderTypeNotFoundExceptionIfTheOrderTypeIsNotFoundInTheRepository_ByCode() throws Exception {
        when(orderTypeRepository.findByOrderTypeCode(Matchers.<String>any())).thenReturn(null);

        try {
            unit.retrieveSapOrderTypeByCode("ZPM9");
        } catch (OrderTypeNotFoundException e) {
            assertThat(e.getMessage(), is("No se encontró el tipo de orden para el código " + "ZPM9"));
        }

    }

    @Test
    public void retrievesTheOrderTypeFromTheRepositoryWhoseParametersMatches_ByCode() throws Exception {
        when(orderTypeRepository.findByOrderTypeCode(Matchers.<String>any())).thenReturn(new OrderTypeVO());

        final OrderTypeVO orderTypeVO = unit.retrieveSapOrderTypeByCode("ZPM9");
        assertThat(orderTypeVO, is(notNullValue()));
    }
}
