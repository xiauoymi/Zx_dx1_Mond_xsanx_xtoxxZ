package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SeasonService;
import com.monsanto.customerlink.core.service.exception.ActiveSeasonNotFoundException;
import com.monsanto.customerlink.core.service.util.CustomerLinkUtils;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.persistence.repositories.SeasonRepository;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SeasonServiceImpl_UT {

    @Mock
    private SeasonRepository seasonRepository;

    @InjectMocks
    private SeasonService unit = new SeasonServiceImpl();

    @Test(expected = ActiveSeasonNotFoundException.class)
    public void throwsActiveSeasonNotFoundExceptionIfTheActiveSeasonIsNotFoundInTheRepository() throws Exception {
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(null);

        unit.retrieveActiveSeason("AMXBAJ", new Date());
    }

    @Test
    public void retrievesTheDistributorConfigFromTheRepositoryWhoseParametersMatches() throws Exception {
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(new SeasonVO());

        final SeasonVO seasonVO = unit.retrieveActiveSeason("AMBAJ", new Date());
        assertThat(seasonVO, is(notNullValue()));
    }

    @Test
    public void retrieveSearchPeriod() throws Exception {
        final Date startDate = CustomerLinkUtils.SDF_DDMMYYYY.parse("01/09/2013");
        final Date endDate = CustomerLinkUtils.SDF_DDMMYYYY.parse("31/08/2014");
        final SeasonVO seasonVO = new SeasonVO();
        seasonVO.setSeasonStartDate(new Timestamp(startDate.getTime()));
        seasonVO.setSeasonEndDate(new Timestamp(endDate.getTime()));
        when(seasonRepository.findActiveSeasonBySubRegionCodeAndDate(Matchers.<String>any(), Matchers.<Date>any())).thenReturn(seasonVO);

        final SearchPeriodDTO searchPeriodDTO = unit.retrieveSearchPeriod("AMXBAJ");
        assertThat(searchPeriodDTO, is(notNullValue()));
        assertThat(searchPeriodDTO.getStartDate(), StringUtils.equals("2013-09-01", CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(startDate)));
        assertThat(searchPeriodDTO.getEndDate(), StringUtils.equals("2014-08-31", CustomerLinkUtils.SDF_YYYYMMDD_SAP.format(endDate)));
    }
}
