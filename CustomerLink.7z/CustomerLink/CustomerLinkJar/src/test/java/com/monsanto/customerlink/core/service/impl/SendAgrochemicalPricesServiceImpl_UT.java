package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.SendAgrochemicalPricesService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.reset;

@RunWith(MockitoJUnitRunner.class)
public class SendAgrochemicalPricesServiceImpl_UT {

    SendAgrochemicalPricesService sendAgrochemicalPricesService;

    @Mock
    private SendPricesUtilService sendPricesUtilService;

    @Before
    public void setup() {
        sendAgrochemicalPricesService = new SendAgrochemicalPricesServiceImpl(sendPricesUtilService);
    }

    @Test
    public void testEmptyListOfOrdersArePassedToObtainCurrenciesSoAnyThingHappened() {
        sendAgrochemicalPricesService.obtainOrderByCurrency(new ArrayList<OrderDTO>());
    }

    @Test
    public void testPricesUtilServiceReturnsNotEmptyListOfCurrencies() {
        reset(sendPricesUtilService);


        List<OrderDTO> list = new ArrayList<OrderDTO>();
        for (int i = 0; i < 3; i++) {
            list.add(new OrderDTO());
        }

        sendAgrochemicalPricesService.obtainOrderByCurrency(list);
        Assert.assertNotNull(list);
        //when(sendPricesUtilService.obtainAgrochemicalCurrencies(Matchers.<OrderDTO>any(), Matchers.<List<OrderDTO>>any())).(new ArrayList())
    }

    @Test
    public void testPricesUtilServiceThrowsExceptionAndItIsLogged() throws Exception {

        reset(sendPricesUtilService);
        List<OrderDTO> list = new ArrayList<OrderDTO>();
        for (int i = 0; i < 3; i++) {
            list.add(new OrderDTO());
        }

        Mockito.doThrow(new CustomerLinkBusinessException()).when(sendPricesUtilService).obtainAgrochemicalCurrencies(Matchers.<OrderDTO>any(), Matchers.<List<OrderDTO>>any());
       sendAgrochemicalPricesService.obtainOrderByCurrency(list);
        Assert.assertNotNull(list);
    }



}
