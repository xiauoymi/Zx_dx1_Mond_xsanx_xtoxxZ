package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.SendPricesService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.SendPricesFacade;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.persistence.repositories.ProductRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SendPricesServiceImpl_UT {

    SendPricesService sendPricesService;

    @Mock
    SendPricesFacade sendPricesFacade;
    @Mock
    ProductRepository productRepository;
    @Mock
    Mapper mapper;
    @Mock
    NotificationType notificationType;
    @Mock
    private NotificationSender mailNotificationSender;

    @Mock
    private SendPricesUtilService sendPricesUtilService;

    @Mock
    private MailUtilService mailUtilService;




    @Test
    public void ordersAreDividedIntoMoreOrderWhenThereAreMoreThanOneCurrency() throws Exception {

        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();


        sendPricesService = new SendPricesServiceImpl(productRepository, sendPricesUtilService);
        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();


                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                productVOList.add(productVO);

                productVOListWithErrors.add(productVO);

                materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(productRepository);
        reset(sendPricesFacade);
        when(productRepository.findByFamilyCode(Matchers.<String>any())).thenReturn(productVOList);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesServiceImpl aSpy = Mockito.spy((SendPricesServiceImpl) sendPricesService);
        //Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        aSpy.obtainOrderByCurrency(orderDTOList);
    }


    @Test
    public void ordersAreDividedIntoMoreOrderWhenThereAreMoreThanOneCurrencyAndSomeContainsErros() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        sendPricesService = new SendPricesServiceImpl(productRepository, sendPricesUtilService);
        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(productRepository);
        reset(sendPricesFacade);
        when(productRepository.findByFamilyCode(Matchers.<String>any())).thenReturn(productVOList);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesServiceImpl aSpy = Mockito.spy((SendPricesServiceImpl) sendPricesService);
        // Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainOrderByCurrency(orderDTOList);
    }


    @Test
    public void ordersAreNotDividedIntoMoreOrderBercauseProductsAreNotFoundedinRepository() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        sendPricesService = new SendPricesServiceImpl(productRepository, sendPricesUtilService);
        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(productRepository);
        reset(sendPricesFacade);
        when(productRepository.findByFamilyCode(Matchers.<String>any())).thenReturn(new ArrayList<ProductVO>());
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesServiceImpl aSpy = Mockito.spy((SendPricesServiceImpl) sendPricesService);
        //Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainOrderByCurrency(orderDTOList);
    }


    @Test
    public void ordersAreNotDividedIntoMoreOrderBecauseAndExceptionThrows() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        sendPricesService = new SendPricesServiceImpl(productRepository, sendPricesUtilService);
        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(productRepository);
        reset(sendPricesFacade);
        when(productRepository.findByFamilyCode(Matchers.<String>any())).thenReturn(new ArrayList<ProductVO>());
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenThrow(new Exception("Error intentionally logged in test"));

        SendPricesServiceImpl aSpy = Mockito.spy((SendPricesServiceImpl) sendPricesService);
        //Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainOrderByCurrency(orderDTOList);
    }


    @Test
    public void ordersAreNotDividedBecauseExceptionsOccurs() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        sendPricesService = new SendPricesServiceImpl(productRepository, sendPricesUtilService);
        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(productRepository);
        reset(sendPricesFacade);
        when(productRepository.findByFamilyCode(Matchers.<String>any())).thenReturn(new ArrayList<ProductVO>());
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenThrow(new Exception("Error intentionally logged in test"));
        Mockito.doThrow(CustomerLinkBusinessException.class).when(sendPricesUtilService).obtainCurrencies(Matchers.<OrderDTO>any(), Matchers.<List<OrderDTO>>any());
        SendPricesServiceImpl aSpy = Mockito.spy((SendPricesServiceImpl) sendPricesService);
        //Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainOrderByCurrency(orderDTOList);
    }
}
