package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.email.NotificationType;
import com.monsanto.customerlink.core.service.MailUtilService;
import com.monsanto.customerlink.core.service.SendPricesUtilService;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.facade.SendPricesFacade;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.persistence.entities.ProductVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.ErrorOrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SendPricesUtilServiceImpl_UT {

    SendPricesUtilService sendPricesUtilService;

    @Mock
    private SendPricesFacade sendPricesFacade;

    @Mock
    private Mapper mapper;
    @Mock
    private NotificationSender mailNotificationSender;
    @Mock
    private MailUtilService mailUtilService;
    @Mock
    NotificationType notificationType;

    @Before
    public void setup() {
        sendPricesUtilService = new SendPricesUtilServiceImpl(sendPricesFacade, mapper, mailNotificationSender, mailUtilService);
    }


    @Test
    public void ordersAreDividedIntoMoreOrderWhenThereAreMoreThanOneCurrency() throws Exception {

        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();


        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();


                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                productVOList.add(productVO);

                productVOListWithErrors.add(productVO);

                materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }


        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, orderDTOList);
    }


    @Test
    public void ordersAreDividedIntoMoreOrderWhenThereAreMoreThanOneCurrencyAndSomeContainsErros() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();


        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }


        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, orderDTOList);
    }


    @Test
    public void ordersAreNotDividedIntoMoreOrderBercauseProductsAreNotFoundedinRepository() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);

        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, orderDTOList);
    }

    @Test(expected = CustomerLinkBusinessException.class)
    public void ordersAreNotDividedBecauseExceptionsOccurs() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenThrow(new Exception("Error intentionally logged in test"));
        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, orderDTOList);
    }


    @Test(expected = CustomerLinkBusinessException.class)
    public void obtainOrderForAgrochemicalButExceptionOccursAtInvokePricesFacade() throws Exception {

        reset(sendPricesFacade);
        Mockito.doThrow(new Exception()).when(sendPricesFacade).obtainCurrencies(Matchers.<OrderDTO>any());

        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, new ArrayList<OrderDTO>());
    }

    @Test
    public void obtainOrderForAgrochemicalButEmptyMaterialIsReturnedByPricesFacade() throws Exception {

        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(new ArrayList<MaterialSkuDTO>());

        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainCurrencies(orderDTO, new ArrayList<OrderDTO>());
    }

    @Test
    public void obtainOrderForSeedsWithoutAnyError() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        OrderDTO auxorderDTO = new OrderDTO();
        for (int k = 0; k < 3; k++) {
            OrderDetailDTO detailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            detail.add(detailDTO);
            for (int j = 0; j < 5; j++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);
            }
            detailDTO.setProductDTO(productDTO);
        }

        auxorderDTO.setDetail(detail);

        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }


        }
        when(mapper.map(Matchers.<Object>any(), any(Class.class))).thenReturn(auxorderDTO);
        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);
        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainCurrencies(auxorderDTO, orderDTOList);
    }


        @Test
    public void obtainOrderForAgrochemicalWithoutAnyError() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();
        List<OrderDetailDTO> detail = new ArrayList<OrderDetailDTO>();
        OrderDTO auxorderDTO = new OrderDTO();
        for (int k = 0; k < 3; k++) {
            OrderDetailDTO detailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            detail.add(detailDTO);
            for (int j = 0; j < 5; j++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);
            }
            detailDTO.setProductDTO(productDTO);
        }

        auxorderDTO.setDetail(detail);

        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }


        }
        when(mapper.map(Matchers.<Object>any(), any(Class.class))).thenReturn(auxorderDTO);
        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);
        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());

        aSpy.obtainAgrochemicalCurrencies(auxorderDTO, orderDTOList);
    }

    @Test
    public void obtainOrderForAgrochemicalWithSomeErrorAndNotificationIsSent() throws Exception {
        List<ProductVO> productVOList = new ArrayList<ProductVO>();
        List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
        List<MaterialSkuDTO> allMaterialsWithCurrency = new ArrayList<MaterialSkuDTO>();
        List<ProductVO> productVOListWithErrors = new ArrayList<ProductVO>();

        for (int i = 0; i < 10; i++) {
            OrderDTO orderDTO = new OrderDTO();
            for (int j = 0; j < 20; j++) {
                OrderDetailDTO detailDTO = new OrderDetailDTO();
                ProductDTO productDTO = new ProductDTO();

                detailDTO.setProductDTO(productDTO);
                orderDTO.getDetail().add(detailDTO);
                orderDTOList.add(orderDTO);

                ProductVO productVO = new ProductVO();

                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
                materialSkuDTO.setMaterial("material" + j);
                materialSkuDTO.setCurrency("currency" + j);
                productDTO.getListOfSku().add(materialSkuDTO);

                for (int k = 0; k < 2; k++) {
                    materialSkuDTO.getErrors().add(new ErrorOrderDTO());
                }

                productVOList.add(productVO);
                productVOListWithErrors.add(productVO);
                allMaterialsWithCurrency.add(materialSkuDTO);
            }

            when(mapper.map(orderDTO, OrderDTO.class)).thenReturn(new OrderDTO());
        }

        reset(sendPricesFacade);
        when(sendPricesFacade.obtainCurrencies(Matchers.<OrderDTO>any())).thenReturn(allMaterialsWithCurrency);
        SendPricesUtilServiceImpl aSpy = Mockito.spy((SendPricesUtilServiceImpl) sendPricesUtilService);
        Mockito.doReturn(notificationType).when(aSpy).getCurrencyNotificationType();

        when(mailUtilService.buildDistributorMessageNotification(Matchers.<DistributorConfigDTO>any(), Matchers.<List<ErrorOrderDTO>>any())).thenReturn(new HashMap<String, Object>());
        OrderDTO orderDTO = new OrderDTO();
        aSpy.obtainAgrochemicalCurrencies(orderDTO, orderDTOList);
    }
    //

}
