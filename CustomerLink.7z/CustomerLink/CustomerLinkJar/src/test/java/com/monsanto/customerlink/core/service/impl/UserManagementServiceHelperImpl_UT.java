package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.UserManagementServiceHelper;
import com.monsanto.customerlink.core.service.dto.KeyDTO;
import com.monsanto.customerlink.core.service.dto.UserRoleDTO;
import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.customerlink.core.service.util.DistributionChannelEnum;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class UserManagementServiceHelperImpl_UT {

    private UserRepository userRepository;

    @Mock
    private UserManagementServiceHelper unit;

    @Before
    public void before() {
        userRepository = Mockito.mock(UserRepository.class);
        unit = new UserManagementServiceHelperImpl(userRepository);
    }

    @Test
    public void noFilterWhenRoleCodeIsNull() {
        String roleCode = null;
        List<UserVO> list = new ArrayList<UserVO>();
        list.add(new UserVO());
        unit.filterUsers(list,roleCode);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void noFilterWhenRoleCodeIsEmpty() {
        String roleCode = "";
        List<UserVO> list = new ArrayList<UserVO>();
        list.add(new UserVO());
        unit.filterUsers(list,roleCode);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void noFilterWhenRoleCodeIsNotRCD() {
        String roleCode = RoleEnum.MARKETING.getCode();
        List<UserVO> list = new ArrayList<UserVO>();
        list.add(new UserVO());
        unit.filterUsers(list,roleCode);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void noFilterWhenRoleCodeIsRCD_AndDistChannelIsDefault() {
        String roleCode = RoleEnum.RCD.getCode();

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setDistributionChannelCode(DistributionChannelEnum.DEFAULT.getId());
        UserVO u = new UserVO();
        u.setDistributionChannelVO(distributionChannelVO);

        List<UserVO> list = new ArrayList<UserVO>();
        list.add(u);

        unit.filterUsers(list,roleCode);
        assertTrue(list.isEmpty());
    }

    @Test
    public void noFilterWhenRoleCodeIsRCD_AndDistChannelIsNotDefault() {
        String roleCode = RoleEnum.RCD.getCode();

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setDistributionChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());
        UserVO u = new UserVO();
        u.setDistributionChannelVO(distributionChannelVO);

        List<UserVO> list = new ArrayList<UserVO>();
        list.add(u);

        unit.filterUsers(list,roleCode);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void replicateProcessWhenRoleIsNotEqualRcd() throws Exception{
        assertFalse(unit.replicateProcessForRCD(null,null,RoleEnum.CSR,null));
    }

    @Test
    public void replicateProcessWhenDistributionChannelIsDifferentDirectSales() throws Exception{

        KeyDTO k = new KeyDTO();
        k.setDistChannelCode(DistributionChannelEnum.RIESGO_COMPARTIDO.getId());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setKeyDTO(k);

        assertFalse(unit.replicateProcessForRCD(null, userRoleDTO, RoleEnum.RCD, null));
    }

    @Test
    public void replicateProcessWhenDistributionChannelIsDirectSales_AndUserRcdNotFound() throws Exception{

        KeyDTO k = new KeyDTO();
        k.setDistChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setKeyDTO(k);

        RoleVO roleVO = new RoleVO();
        roleVO.setRoleCode(1L);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXBAJ");

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        salesOrganizationVO.setSalesOrgCode("MX20");

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        salesDivisionVO.setSalesDivCode("17");

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setDistributionChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserVO userToEvaluate = new UserVO();
        userToEvaluate.setRoleVO(roleVO);
        userToEvaluate.setSubRegionVO(subRegionVO);
        userToEvaluate.setSalesOrganizationVO(salesOrganizationVO);
        userToEvaluate.setSalesDivisionVO(salesDivisionVO);
        userToEvaluate.setDistributionChannelVO(distributionChannelVO);

        UserVO rcdDefaultDistributionChannel = null;
        when(userRepository.findRCDByParameters(anyLong(),anyString(),anyString(),anyString(),anyString(),anyString())).thenReturn(rcdDefaultDistributionChannel);
        assertFalse(unit.replicateProcessForRCD(userToEvaluate, userRoleDTO, RoleEnum.RCD, null));
    }

    @Test
    public void replicateProcessWhenDistributionChannelIsDirectSales_AndUserRcdExist() throws Exception{

        UserManagementService userManagementServiceMock = Mockito.mock(UserManagementService.class);

        KeyDTO k = new KeyDTO();
        k.setDistChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setKeyDTO(k);

        RoleVO roleVO = new RoleVO();
        roleVO.setRoleCode(1L);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXBAJ");

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        salesOrganizationVO.setSalesOrgCode("MX20");

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        salesDivisionVO.setSalesDivCode("17");

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setDistributionChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserVO userToEvaluate = new UserVO();
        userToEvaluate.setRoleVO(roleVO);
        userToEvaluate.setSubRegionVO(subRegionVO);
        userToEvaluate.setSalesOrganizationVO(salesOrganizationVO);
        userToEvaluate.setSalesDivisionVO(salesDivisionVO);
        userToEvaluate.setDistributionChannelVO(distributionChannelVO);

        UserVO rcdDefaultDistributionChannel = new UserVO();
        rcdDefaultDistributionChannel.setSapId("123456789");

        when(userRepository.findRCDByParameters(anyLong(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(rcdDefaultDistributionChannel);
        when(userManagementServiceMock.createUpdateUserRole(any(UserRoleDTO.class))).thenReturn(true);

        assertTrue(unit.replicateProcessForRCD(userToEvaluate, userRoleDTO, RoleEnum.RCD, userManagementServiceMock));
    }

    @Test(expected = CustomerLinkBusinessException.class)
    public void replicateProcessWhenDistributionChannelIsDirectSales_AndUserRcdExist_AndCreateUpdateUserRoleThrowException() throws Exception{

        UserManagementService userManagementServiceMock = Mockito.mock(UserManagementService.class);

        KeyDTO k = new KeyDTO();
        k.setDistChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setKeyDTO(k);

        RoleVO roleVO = new RoleVO();
        roleVO.setRoleCode(1L);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setSubRegionCode("AMXBAJ");

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        salesOrganizationVO.setSalesOrgCode("MX20");

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        salesDivisionVO.setSalesDivCode("17");

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        distributionChannelVO.setDistributionChannelCode(DistributionChannelEnum.DIRECT_SALES.getId());

        UserVO userToEvaluate = new UserVO();
        userToEvaluate.setRoleVO(roleVO);
        userToEvaluate.setSubRegionVO(subRegionVO);
        userToEvaluate.setSalesOrganizationVO(salesOrganizationVO);
        userToEvaluate.setSalesDivisionVO(salesDivisionVO);
        userToEvaluate.setDistributionChannelVO(distributionChannelVO);

        UserVO rcdDefaultDistributionChannel = new UserVO();
        rcdDefaultDistributionChannel.setSapId("123456789");

        when(userRepository.findRCDByParameters(anyLong(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(rcdDefaultDistributionChannel);
        doThrow(new CustomerLinkBusinessException()).when(userManagementServiceMock).createUpdateUserRole(any(UserRoleDTO.class));

        assertFalse(unit.replicateProcessForRCD(userToEvaluate, userRoleDTO, RoleEnum.RCD, userManagementServiceMock));
    }

    @Test
    public void isCsrOrApprover_WhenIsCsr() {
        assertTrue(unit.isCsrOrApprover(RoleEnum.CSR));
    }

    @Test
    public void isCsrOrApprover_WhenIsApprover() {
        assertTrue(unit.isCsrOrApprover(RoleEnum.APPROVER));
    }

    @Test
    public void isCsrOrApprover_WhenInNotCsrOrApprover() {
        assertFalse(unit.isCsrOrApprover(RoleEnum.RCD));
    }
 }