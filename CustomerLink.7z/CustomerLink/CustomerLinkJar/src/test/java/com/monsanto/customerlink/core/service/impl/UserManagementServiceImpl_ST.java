package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.dto.*;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Arrays;
import java.util.List;

@ContextConfiguration(locations={"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class UserManagementServiceImpl_ST {

    @Autowired
    private UserManagementService unit;

    @Test
    @Ignore
    public void getListOfUsersByRole() throws Exception {
        List<GridUserRoleDTO> users = unit.getListOfUsersByRole("MRKT");
    }

    @Test
    @Ignore
    public void createUserRolePricingPlanning() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("PRC");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("OILHUIC");

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void updateUserRolePricingPlanning() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("PRC");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JNOLA1");
        userRoleDTO.setIdUser(19L);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void createUserRoleMarketing() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("MRKT");

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("CB");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setUserName("JNOLA1");

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void updateUserRoleMarketing() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("MRKT");

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setUserName("JNOLA1");
        userRoleDTO.setIdUser(13L);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void updateUserRoleRCD() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setUserName("LETORR1");
        userRoleDTO.setIdUser(25L);

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("RCD");
        userRoleDTO.setRoleDTO(roleDTO);

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");
        userRoleDTO.setBrandDTO(brandDTO);

        KeyDTO keyDTO = new KeyDTO("MX20","17","3R");
        userRoleDTO.setKeyDTO(keyDTO);

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void updateUserRoleRBM() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setUserName("VVPARE");
        userRoleDTO.setIdUser(12L);

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("RBM");
        userRoleDTO.setRoleDTO(roleDTO);

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");
        userRoleDTO.setBrandDTO(brandDTO);

        KeyDTO keyDTO = new KeyDTO("MX20","17","3R");
        userRoleDTO.setKeyDTO(keyDTO);

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void createUserRoleCSR() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("CSR");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("FJSIBA");

        DistributorDTO d1 = new DistributorDTO();
        d1.setDistributorCode("1695901");
        DistributorDTO d2 = new DistributorDTO();
        d2.setDistributorCode("1702969");
        DistributorDTO d3 = new DistributorDTO();
        d3.setDistributorCode("1718989");
        List<DistributorDTO> distributors = Arrays.asList( new DistributorDTO[]{d1,d2,d3});
        userRoleDTO.setListOfDistributors(distributors);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void updateUserRoleCSR() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("CSR");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCAPI");
        userRoleDTO.setIdUser(48L);

        DistributorDTO d1 = new DistributorDTO();
        d1.setDistributorCode("1757444");
        DistributorDTO d2 = new DistributorDTO();
        d2.setDistributorCode("1758363");

        DistributorDTO d3 = new DistributorDTO();
        d3.setDistributorCode("1111");

        List<DistributorDTO> distributors = Arrays.asList( new DistributorDTO[]{d1,d2,d3});
        userRoleDTO.setListOfDistributors(distributors);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void deleteRecord() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(13L);

        unit.removeUserRole(userRoleDTO);
    }

    @Test
    @Ignore
    public void getListOfUsersByRoleByDistributorProfile() throws Exception {
        unit.getListOfUserByDistributorProfileId(1L);
    }
}